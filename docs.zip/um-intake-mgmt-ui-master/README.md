# um-intake-mgmt-ui

### [ECP Docs](https://github.optum.com/pages/ecp/docs/)
###### Contains all documentation for the Enterprise Clinical Platform

# Getting started

0. Prerequisite is having npm installed:

   Install Node.js via the [app store for pc](http://appstore.uhc.com/AppInfo/AppVersionId/17515?BackToList=/AppList/AppList) or [download online for mac](https://nodejs.org/en/)

1. Go to project folder and install dependencies:

```sh
npm install
```

2. Launch development server, and open `localhost:4200` in your browser:

```sh
npm run start
```

3. Optional: [Setup Intellij IDEA Auto Linting](https://github.optum.com/raw/ecp/docs/master/images/lint-plugins.png)
    - Be sure to [enable TSLint](https://github.optum.com/raw/ecp/docs/master/images/enable-tslint.png) in the preferences menu
    - [Setup Intellij IDEA Sonar Linting](https://github.optum.com/pages/ecp/docs/engineering-guide/3-coding-guide/9-sonar-lint-setup)

# Project structure

    dist/                        web app production build (untracked)
    e2e/                         end-to-end cucumber tests
    helm/                        helm template files for deploying to Azure
    nginx/                       nginx configuration files
    node_modules/                project dependencies specified in package.json (untracked)
    src/                         project source code
    |- app/                      app components
    |  |- components/            components folder
    |  |- directives/            directives folder
    |  |- models/                models folder (classes, enums, interfaces, etc.)
    |  |- pipes/                 pipes folder
    |  |- services/              services folder
    |  |- coverage/              test and coverage reports (untracked)
    |  |- app.component.*        app root component (shell)
    |  |- app.module.ts          app root module definition
    |  |- app-routing.module.ts  app routes
    |- assets/                   app assets (images, fonts, etc.)
    |- environments/             values for various build environments
    |- single-spa/               single spa configuration files
    |- index.html                html entry point
    |- main.single-spa.ts        single spa entry point
    |- main.ts                   app entry point
    |- polyfills.ts              polyfills needed by Angular
    |- styles.scss               global style entry point
    |- test.ts                   unit tests entry point

# Development process

Task automation is based on [NPM scripts](https://docs.npmjs.com/misc/scripts).

| Task                                | Description                                                                                          |
| ------------------------------------| -----------------------------------------------------------------------------------------------------|
| "ng"                                | Pass-through to run an `ng` (Angular CLI) command                                                    |
| "start"                             | Run development server on `http://localhost:4200/`                                                   |
| "start:local"                       | Run development server on `http://localhost:4200/` with local single-spa configuration               |
| "start:dev"                         | Run development server on `http://localhost:4200/` with hot-swapping for @clinical/@ecp dependencies |
| "build"                             | Build web app for production in `dist/` folder                                                       |
| "test"                              | Run unit tests with Karma                                                                            |
| "e2e"                               | Run e2e tests using [Protractor](http://www.protractortest.org)                                      |
| "build:single-spa:um-intake-mgmt-ui" | Single spa build                                                                                     |
| "serve:single-spa:um-intake-mgmt-ui" | Single spa serve                                                                                     |

When building the application, you can specify the target configuration using the additional flag
`--configuration <name>` (do not forget to prepend `--` to pass arguments to npm scripts, like so: `-- --configuration <name>`).

Currently supported configurations:
- local
- dev
- prod

When running with no configuration specified, the `environment.ts` file is used, which contains the same environment variables as
dev but can be customized for local development.

## Development server

Run `npm start` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change
any of the source files.
You should not use `ng serve` directly, as it does not use certain configurations that the NPM script does by default.

## Authorization
Micro Product UIs will all be run within the [main shell app](https://github.optum.com/ecp/root-spa-ui) that handles login/logout with Ping Federate and the [ECP Authorization Service](https://github.optum.com/ecp/authorization-service).

Please protect your pages with the [Auth Guard Service](https://github.optum.com/ecp/auth-library#micro-product-use).

## Code scaffolding

Run `cd src/app/core && npm run generate -- component <name>` to generate a new component. You can also use
`npm run generate -- directive|pipe|service|class|module`.

If you have installed [angular-cli](https://www.npmjs.com/package/@angular/cli) globally with `npm install -g @angular/cli`,
you can also use the command `ng generate` directly.

## Useful Links

[Form Control Info](https://blog.angular-university.io/introduction-to-angular-2-forms-template-driven-vs-model-driven)

[Comparing AngularJS to Angular](https://angular.io/guide/ajs-quick-reference)

## Additional tools

Tasks are mostly based on the `angular-cli` tool. Use `ng help` to get more help or go check out the
[Angular-CLI README](https://github.com/angular/angular-cli#angular-cli).

## Code formatting

All `.ts`, `.js` & `.scss` files in this project are formatted automatically using [Prettier](https://prettier.io).

A pre-commit git hook has been configured on this project to automatically format staged files, using
[pretty-quick](https://github.com/azz/pretty-quick), so you don't have to care for it.

You can also force code formatting by running the command `npm run pretty-quick`.

# What's in this repo

The app is based on [HTML5](http://whatwg.org/html), [TypeScript](http://www.typescriptlang.org) and
[Sass](http://sass-lang.com).

#### Tools

Development, build and quality processes are based on [angular-cli](https://github.com/angular/angular-cli) and
[NPM scripts](https://docs.npmjs.com/misc/scripts), which includes:

- Optimized build and bundling process with [Webpack](https://webpack.github.io)
- [Development server](https://webpack.github.io/docs/webpack-dev-server.html) with backend proxy and live reload
- Cross-browser CSS with [autoprefixer](https://github.com/postcss/autoprefixer) and
  [browserslist](https://github.com/ai/browserslist)
- Unit tests using [Jasmine](http://jasmine.github.io) and [Karma](https://karma-runner.github.io)
- End-to-end tests using [Protractor](https://github.com/angular/protractor)
- Static code analysis: [TSLint](https://github.com/palantir/tslint), [Codelyzer](https://github.com/mgechev/codelyzer),
  [Stylelint](http://stylelint.io) and [HTMLHint](http://htmlhint.com/)
- Automatic code formatting with [Prettier](https://prettier.io)

#### Libraries

- [Angular](https://angular.io)
- [RxJS](http://reactivex.io/rxjs)
- [Lodash](https://lodash.com)

#### [Coding guides](https://github.optum.com/pages/ecp/docs/engineering-guide/3-coding-guide)

### Running Docker Locally

If you have [Docker installed locally](http://appstore.uhc.com/AppInfo/AppVersionId/17763?BackToList=/AppList/AppList) 
you are able to build an image of this project and run it locally:

- To build: `docker build -t um-intake-mgmt-ui .`
- To run: `docker run -it -p 80:8082 -p 8443:8443 um-intake-mgmt-ui`

### Troubleshooting

If you're having issues with NPM scripts, try running the following command (for Mac):

`sudo chown -R $USER /usr/local/lib/node_modules`

Or checking out [this site](https://docs.npmjs.com/resolving-eacces-permissions-errors-when-installing-packages-globally).
