// Protractor configuration file, see link for more information
// https://github.com/angular/protractor/blob/master/lib/config.ts
exports.config = {
  allScriptsTimeout: 800000,
  getPageTimeout: 400000,
  specs: ['./src/features/**/*.feature'],

  params: {
    pageObjects: require['./src/pages/**/*.po.ts'],
    customTimeout: 200000
  },
  capabilities: {
    browserName: 'chrome',
    chromeOptions: {
      args: [
        "--no-sandbox",
        "--headless",
        "--disable-setuid-sandbox",
        "--disable-gpu",
        "--window-size=800x600"
      ]
    },
    shardTestFiles: true,
    maxInstances: 1
  },
  // Only works with Chrome and Firefox
  directConnect: false,
  baseUrl: "http://localhost:4200/",
  useAllAngular2AppRoots: true,
  framework: 'custom',
  frameworkPath: require.resolve('protractor-cucumber-framework'),
  cucumberOpts: {
    compiler: "ts:ts-node/register",
    require: ['./src/steps/**/*.steps.ts'],
    format: 'json:e2e/reports/cucumber_report.json',
    monochrome: true,
    strict: true,
    // tags: "@Smoke"
    tags: "@Regression"
  },

  beforeLaunch: () => {
    var fs = require('fs');
    var dirPath = './reports';

    try { var files = fs.readdirSync(dirPath); }
    catch (e) { return; }
    if (files.length > 0)
      for (var i = 0; i < files.length; i++) {
        if (files[i] === '.keep') continue;
        var filePath = dirPath + '/' + files[i];
        if (fs.statSync(filePath).isFile())
          fs.unlinkSync(filePath);
        else
          rmDir(filePath);
      }
  },

  onPrepare() {
    // If you need to navigate to a page which does not use Angular,
    // you can turn off waiting for Angular
    browser.ignoreSynchronization = true;
    require("ts-node").register({
      project: require("path").join(__dirname, "./tsconfig.e2e.json")
    });
  },

  afterLaunch: () => {
    var reporter = require('cucumber-html-reporter');
    var options = {
      theme: 'bootstrap',
      jsonDir: './e2e/reports',
      output: './e2e/reports/cucumber_report.html',
      ignoreBadJsonFile: true,
      reportSuiteAsScenarios: true,
      launchReport: false,
      metadata: {
        "App Version": "0.3.2",
        "Test Environment": "STAGING",
        "Browser": "Chrome 80.0.3987.163",
        "Platform": "Mac",
        "Parallel": "Scenarios",
        "Executed": "Remote"
      }
    };

    reporter.generate(options);
  },
};
