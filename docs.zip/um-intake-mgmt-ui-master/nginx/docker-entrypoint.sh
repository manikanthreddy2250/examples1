#!/usr/bin/env sh

set -e

# The below code snippet can be used to replace env vars with their values in compiled javascript files
for var in $(env) ; do
  IFS='=' read -r key value <<EOF
$var
EOF
  sed -i "s#\${$key}#$value#g" /usr/share/nginx/html/main*.js
done
sed -i "s#assets#microproduct/um-intake-mgmt-ui-service.default.svc.cluster.local/assets#g" /usr/share/nginx/html/main*.js
cat /etc/nginx/nginx.conf

exec "$@"
