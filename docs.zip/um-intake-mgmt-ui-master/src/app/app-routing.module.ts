import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuardService } from '@ecp/auth-library';
import { EmptyRouteComponent } from './components/empty-route/empty-route.component';
import { IntakeDashboardComponent } from './components/intake-dashboard/intake-dashboard.component';
import { IntakeFormComponent } from './components/intake-form/intake-form.component';
import {IntakeConfirmationComponent} from "./components/intake-confirmation/intake-confirmation.component";

const UM_BASE_PATH = 'um/intake/dashboard';



// All routes must start with 'um', which should match
// APPL_VER.bas_mnu_url in the database so single-spa routing will work
// NOTE: the ** path routing to EmptyRouteComponent is necessary for single-spa to work as intended

const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: UM_BASE_PATH },
  { path: 'um', pathMatch: 'full', redirectTo: UM_BASE_PATH },
  { path: UM_BASE_PATH, pathMatch: 'full', component: IntakeDashboardComponent, data: {title: 'Intake Dashboard'}, canActivate: [AuthGuardService] },
  {path: 'um/intake-form/:id/:serviceType/:caseId/:hscId', component: IntakeFormComponent, data: { title: 'Intake Form' }, canActivate: [AuthGuardService]},
  {path: 'um/intake-confirmation', component: IntakeConfirmationComponent, data: { title: 'Intake Confirmation' }, canActivate: [AuthGuardService]},
  { path: '**', component: EmptyRouteComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
