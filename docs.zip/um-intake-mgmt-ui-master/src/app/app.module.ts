import { APP_BASE_HREF } from '@angular/common';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { APP_INITIALIZER, NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AuthGuardService, AuthHttpInterceptor, AuthLibraryModule, LocalHostAuthInitService } from '@ecp/auth-library';
import { GraphqlModule } from '@ecp/gql-tk-beta';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { EmptyRouteComponent } from './components/empty-route/empty-route.component';
import { MatIconModule } from '@angular/material/icon';
import { IntakeDashboardComponent } from './components/intake-dashboard/intake-dashboard.component';
import { UmintakefuncCreateDraftHscService } from './services/um-intake-functions/umintakefunc-create-draft-hsc.service';
import { IntakeSummaryComponent } from './components/intake-summary/intake-summary.component';
import { GenericStepperComponent } from './components/generic-stepper/generic-stepper.component';
import { IntakeFormComponent } from './components/intake-form/intake-form.component';
import { CancelPopupComponent } from './components/cancel-popup/cancel-popup.component';
import { ButtonModule } from '@ecp/angular-ui-component-library/button';
import {
  CaseNotesModule,
  CasetypeModule, ClinicalReviewWrapperModule,
  ContactsModule,
  DiagnosisModule,
  DuplicateModule, GuidelinesBedDayModule,
  MedicalReviewsModule,
  ProcedureModule,
  ProviderModule
} from '@ecp/um-angular-ui-component-library';
import {LinkModule} from '@ecp/angular-ui-component-library/link';
import {IconsModule} from '@ecp/angular-ui-component-library/icons';
import {FormFieldModule} from '@ecp/angular-ui-component-library/form-field';
import {SelectModule} from '@ecp/angular-ui-component-library/select';
import {TableModule} from '@ecp/angular-ui-component-library/table';
import {CardModule} from '@ecp/angular-ui-component-library/card';
import {InputModule} from '@ecp/angular-ui-component-library/input';
import {WizardModule} from '@ecp/angular-ui-component-library/wizard';
import {OptionModule} from '@ecp/angular-ui-component-library/option';
import {ModalModule} from '@ecp/angular-ui-component-library/modal';
import {TabsModule} from '@ecp/angular-ui-component-library/tabs';
import { ProgressSpinnerModule } from '@ecp/angular-ui-component-library/progress-spinner';

import { IntakeConfirmationComponent } from './components/intake-confirmation/intake-confirmation.component';
import {
  ConfigurableMemberHeaderModule,
  DocProcessModule,
  MemberAdvancedSearchModule,
  MemberAdvancedSearchResultsModule
} from '@ecp/common-angular-ui-component-library';
import { ClinicalReviewPopupComponent } from './components/clinical-review-popup/clinical-review-popup.component';
import { MemberSearchPopupComponent } from './components/member-search-popup/member-search-popup.component';

export const MaterialModules = [
  MatIconModule
];

export const AngUIModules = [
  TabsModule,
  ButtonModule,
  CardModule,
  IconsModule,
  ProviderModule,
  ProcedureModule,
  DiagnosisModule,
  LinkModule,
  CasetypeModule,
  DocProcessModule,
  MemberAdvancedSearchModule,
  MemberAdvancedSearchResultsModule,
  ConfigurableMemberHeaderModule,
  InputModule,
  WizardModule,
  FormFieldModule,
  ModalModule,
  SelectModule,
  OptionModule,
  ContactsModule,
  CaseNotesModule,
  DuplicateModule,
  MedicalReviewsModule,
  GuidelinesBedDayModule,
  ClinicalReviewWrapperModule
];

@NgModule({
  declarations: [
    AppComponent,
    EmptyRouteComponent,
    IntakeDashboardComponent,
    IntakeSummaryComponent,
    GenericStepperComponent,
    IntakeFormComponent,
    CancelPopupComponent,
    IntakeConfirmationComponent,
    ClinicalReviewPopupComponent,
    MemberSearchPopupComponent
  ],
  imports: [
    AppRoutingModule,
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    GraphqlModule,
    HttpClientModule,
    ReactiveFormsModule,
    AuthLibraryModule,
    MaterialModules,
    AngUIModules,
    FormFieldModule,
    TableModule,
    SelectModule,
    OptionModule,
    InputModule,
    ProgressSpinnerModule,
    MedicalReviewsModule,
    GuidelinesBedDayModule,
    ClinicalReviewWrapperModule
  ],
  providers: [
    AuthGuardService, UmintakefuncCreateDraftHscService,
    { provide: APP_BASE_HREF, useValue: '/' },
    { provide: HTTP_INTERCEPTORS, useClass: AuthHttpInterceptor, multi: true },
    {
      provide: APP_INITIALIZER,
      useFactory: (localHostAuthInitService: LocalHostAuthInitService) => () => localHostAuthInitService.init(),
      deps: [LocalHostAuthInitService],
      multi: true
    }
  ],
  bootstrap: [AppComponent],
  entryComponents: []
})
export class AppModule { }
