import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { CancelPopupComponent } from './cancel-popup.component';
import {ModalModule} from '@ecp/angular-ui-component-library/modal';
import {FormFieldModule} from '@ecp/angular-ui-component-library/form-field';

describe('CancelPopupComponent', () => {
  let component: CancelPopupComponent;
  let fixture: ComponentFixture<CancelPopupComponent>;


  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [FormFieldModule, ModalModule],
      declarations: [ CancelPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CancelPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    spyOn(component.cancelModal, 'open');
    spyOn(component.cancelModal, 'close');
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call cancelAndExit method', () => {
    spyOn(component.cancel, 'emit');
    component.cancelAndExit();
    expect(component.cancelModal.close).toHaveBeenCalled();
    expect(component.cancel.emit).toHaveBeenCalled();
  });

  it('should call saveAndExit method', () => {
    spyOn(component.save, 'emit');
    component.saveAndExit();
    expect(component.cancelModal.close).toHaveBeenCalled();
    expect(component.save.emit).toHaveBeenCalled();
  });

  it('should call close method', () => {
    spyOn(component.exit, 'emit');
    component.close();
    expect(component.cancelModal.close).toHaveBeenCalled();
    expect(component.exit.emit).toHaveBeenCalled();
  });
});

