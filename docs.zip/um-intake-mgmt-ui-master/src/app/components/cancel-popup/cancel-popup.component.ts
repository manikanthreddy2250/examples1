import {Component, EventEmitter, Input, OnInit, Output, ViewChild} from '@angular/core';
import {EcpUclModal} from '@ecp/angular-ui-component-library/modal';

@Component({
  selector: 'um-cancel-popup',
  templateUrl: './cancel-popup.component.html',
  styleUrls: ['./cancel-popup.component.scss']
})
export class CancelPopupComponent implements OnInit {

  @ViewChild(EcpUclModal, {static: true})
  cancelModal: EcpUclModal;

  @Input()
  suppressSaveAndExit: boolean;

  @Output()
  cancel = new EventEmitter();

  @Output()
  save = new EventEmitter();

  @Output()
  exit = new EventEmitter();

  constructor() { }

  ngOnInit() {
    this.cancelModal.open();
  }

  cancelAndExit() {
    this.cancelModal.close();
    this.cancel.emit();
  }

  saveAndExit() {
    this.cancelModal.close();
    this.save.emit();
  }

  close() {
    this.cancelModal.close();
    this.exit.emit();
  }
}
