import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import {ModalModule, EcpUclModal} from '@ecp/angular-ui-component-library/modal';
import {FormFieldModule} from '@ecp/angular-ui-component-library/form-field';
import {ClinicalReviewPopupComponent} from './clinical-review-popup.component';

describe('ClinicalReviewPopupComponent', () => {
  let component: ClinicalReviewPopupComponent;
  let fixture: ComponentFixture<ClinicalReviewPopupComponent>;


  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [FormFieldModule, ModalModule],
      declarations: [ ClinicalReviewPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicalReviewPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
//TODO PP
  it('should call close',()=>{
    component.close();
    expect(component.clinicalReviewModal).toBeDefined();
  })
});

