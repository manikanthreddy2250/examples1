import {Component, EventEmitter, Input, OnInit, Output, ViewChild} from '@angular/core';
import {EcpUclModal} from '@ecp/angular-ui-component-library/modal';
import {Constants} from "../../constants/constants";

@Component({
  selector: 'um-clinical-review-popup',
  templateUrl: './clinical-review-popup.component.html',
  styleUrls: ['./clinical-review-popup.component.scss']
})
export class ClinicalReviewPopupComponent implements OnInit {

  @ViewChild(EcpUclModal, {static: true})
  clinicalReviewModal: EcpUclModal;

  @Input()
  hscID;


  @Output()
  exit = new EventEmitter();

  application = Constants.UM_INTAKE_UI_APP_NAME;

  constructor() { }

  ngOnInit() {
    this.clinicalReviewModal.open();
  }

  close() {
    this.clinicalReviewModal.close();
    this.exit.emit();
  }
}
