import { Component } from '@angular/core';

@Component({
  selector: 'um-empty-route',
  template: '',
})
export class EmptyRouteComponent {}
