import { ChangeDetectorRef, CUSTOM_ELEMENTS_SCHEMA, Injectable, NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { GenericStepperComponent } from './generic-stepper.component';
import { RouterTestingModule } from '@angular/router/testing';
import { IntakeDashboardComponent } from '../intake-dashboard/intake-dashboard.component';
import { AuthGuardService, AuthLibraryModule } from '@ecp/auth-library';
import { UserSessionService } from '../../shared/services/user-session/user-session.service';
import { UmIntakeFuncGraphqlService } from '../../services/um-intake-functions/umintakefunc-graphql.service';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { BehaviorSubject } from 'rxjs';
import { StepperDataService } from '../../services/stepper-data/stepper-data.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { CasetypeComponent } from '@ecp/um-angular-ui-component-library';
import { ModalModule } from '@ecp/angular-ui-component-library/modal';
import { EcpUclWizard } from '@ecp/angular-ui-component-library/wizard';
import { ReferenceConstants } from 'src/app/constants/referenceConstants';
import {UtilFuncsNestjsService} from "../../services/util-funcs-nestjs/util-funcs-nestjs.service";

@Injectable()
class UserSessionMockService {
  i = 0;
  getUserName() {
    if (this.i === 0) {
      this.i++;
      return 'breddy88';
    } else if (this.i === 1) {
      this.i = this.i + 2;
      return 'SYSTEM';
    } else if (this.i === 3) {
      return 'abcd';
    }
  }
  getUserOrg() {
    return 'ecp';
  }
  getEcpToken() { }
  getUserHasuraRole() { }
  getActiveClientOrg() { }
  getActiveUserRole() { }
}

@Injectable()
class MockStepperDataService {
  private stepperData = new BehaviorSubject({
    tenantId: 'ecpumintakebaseproductbpmgrp',
    hsc_id: 1345
  });
  sharedStepperData = this.stepperData.asObservable();

  constructor() {
  }

  setStepperData(stepperData: any) {
    this.stepperData.next(stepperData);
  }
}


describe('GenericStepperComponent', () => {
  let component: GenericStepperComponent;
  let umintakeService: UmIntakeFuncGraphqlService;
  let utilFuncsService: UtilFuncsNestjsService;
  let casetypeComponent: CasetypeComponent;
  let fixture: ComponentFixture<GenericStepperComponent>;
  const routes = [
    { path: 'um/intake/dashboard', pathMatch: 'full', component: IntakeDashboardComponent },
  ];
  beforeEach((() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule.withRoutes(routes), HttpClientTestingModule, AuthLibraryModule, ModalModule],
      declarations: [GenericStepperComponent, EcpUclWizard],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      providers: [ChangeDetectorRef, { provide: UserSessionService, useClass: UserSessionMockService }, UmIntakeFuncGraphqlService, CasetypeComponent,
        HttpClient, { provide: StepperDataService, useClass: MockStepperDataService }]
    })
      .compileComponents();
    umintakeService = TestBed.inject(UmIntakeFuncGraphqlService);
    utilFuncsService = TestBed.inject(UtilFuncsNestjsService);
    casetypeComponent = TestBed.inject(CasetypeComponent);
    fixture = TestBed.createComponent(GenericStepperComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    spyOn(component.duplicateModal, 'close');
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call changeEmit method', () => {
    const event = {};
    component.changeEmit(event);
    expect(component.selectChange).toBeDefined();
  });


  it('should call cancelStepActionSuppressSaveAndExit', () => {
    component.cancelStepActionSuppressSaveAndExit();
    expect(component.suppressSaveAndExit).toBeTruthy();
    expect(component.cancelPopupOpen).toBeTruthy();
  });

  it('should call goToPrevious', () => {
    component.goToPrevious();
    expect(component.readOnly).toBeFalse();
  });

  it('should call checkvalidation for true error', () => {
    const data = { diagnosisCountError: true }
    component.checkvalidation(data);
    expect(component.checkvalidation(data)).toBeTrue();
  });
  it('should call checkvalidation for false error', () => {
    const data = { diagnosisCountError: false }
    component.checkvalidation(data);
    expect(component.checkvalidation(data)).toBeFalse();
  });

  it('should call cancelStepAction method', () => {
    expect(component.cancelPopupOpen).toBeFalsy();
    component.cancelStepAction();
    expect(component.cancelPopupOpen).toBeTruthy();
  });

  it('should call closeCancelPopup method', () => {
    component.cancelPopupOpen = true;
    component.closeCancelPopup();
    expect(component.cancelPopupOpen).toBeFalsy();
  });

  it('should call saveAsDraft method', () => {
    component.cancelPopupOpen = true;
    component.saveAsDraft();
    expect(component.cancelPopupOpen).toBeFalsy();
  });

  it('should call cancelAndExit method', () => {
    component.cancelPopupOpen = true;
    component.cancelAndExit();
    expect(component.cancelPopupOpen).toBeFalsy();
  });

  it('should call continueButtonClicked method', () => {
    component.continueButtonClicked({});
    expect(component.duplicateModal.close).toHaveBeenCalled();
  });

  it('should call submitCase method', () => {
    const res: any = {
      data: { hsc: [{ hsc_id: 19250, hsc_sts_ref_id: 19275 }] }
    };
    spyOn(umintakeService, 'submitHsc').and.returnValue(res);
    spyOn(utilFuncsService, 'updateHsc').and.returnValue(res);
    component.submitCase();
    expect(component.submitCase).toBeTruthy();
  });

  it('should call sendStepperSignalVariabletoBPM method', () => {
    component.hscID = 19250;
    component.sendStepperSignalVariabletoBPM();
    expect(component.sendStepperSignalVariabletoBPM).toBeTruthy();
  });

  it('should call saveCaseTypeData', () => {
    component.caseType.caseTypeForm = new FormGroup({
      serviceSetting: new FormControl({ name: 'Inpatient', value: 3737 }, Validators.required),
      placeOfService: new FormControl({ name: 'Acute Hospital', value: 3743 }, Validators.required),
      serviceDetail: new FormControl({ name: 'Medical', value: 4296 }, Validators.required),
      serviceDescription: new FormControl({ name: 'Urgent', value: 4348 }, Validators.required),
      priority: new FormControl({ name: 'Routine', value: 3754 }, Validators.required),
      expectedAdmissionDate: new FormControl('Thu May 20 2021 00:00:00 GMT-0400 (Eastern Daylight Time)', Validators.required),
      expectedDischargeDate: new FormControl('Fri May 21 2021 00:00:00 GMT-0400 (Eastern Daylight Time)', Validators.required),
      actualAdmissionDate: new FormControl('Thu May 13 2021 00:00:00 GMT-0400 (Eastern Daylight Time', Validators.required),
      actualDischargeDate: new FormControl('Fri May 14 2021 00:00:00 GMT-0400 (Eastern Daylight Time)', Validators.required),
    });
    component.saveCaseTypeData();
    expect(component.saveCaseTypeData).toBeTruthy();
  });

  it('should format the date', () => {
    component.formatDate('2021-10-21T00:00:00');
    expect(component.formatDate('2021-10-21T00:00:00')).toBeTruthy();
  });

  it('should format the null date', () => {
    component.formatDate(null);
    expect(component.formatDate(null)).toEqual('')
  });

  it('cancelAndExit should call updateCaseStatus', () => {
    component.caseTypeFormValues = new FormGroup({
      //   serviceSetting: new FormControl({name: 'Inpatient', value: 3737}, Validators.required),
      //   placeOfService: new FormControl({name: 'Acute Hospital', value: 3743}, Validators.required),
      //   serviceDetail: new FormControl({name: 'Medical', value: 4296}, Validators.required),
      //   serviceDescription: new FormControl({name: 'Urgent', value: 4348}, Validators.required),
      //   priority: new FormControl({name: 'Routine', value: 3754}, Validators.required),
      //   expectedAdmissionDate: new FormControl('Thu May 20 2021 00:00:00 GMT-0400 (Eastern Daylight Time)', Validators.required),
      //   expectedDischargeDate: new FormControl('Fri May 21 2021 00:00:00 GMT-0400 (Eastern Daylight Time)', Validators.required),
      //   actualAdmissionDate: new FormControl('Thu May 13 2021 00:00:00 GMT-0400 (Eastern Daylight Time', Validators.required),
      //   actualDischargeDate: new FormControl('Fri May 14 2021 00:00:00 GMT-0400 (Eastern Daylight Time)', Validators.required),
    });
    component.updateCaseStatus(19728);
    expect(component.updateCaseStatus).toBeTruthy();
  });

  it('saveAsDraft should call saveCaseTypeDataAndSetStatus', () => {
    component.caseTypeFormValues = new FormGroup({
      serviceSetting: new FormControl({ name: 'Inpatient', value: 3737 }, Validators.required),
      placeOfService: new FormControl({ name: 'Acute Hospital', value: 3743 }, Validators.required),
      serviceDetail: new FormControl({ name: 'Medical', value: 4296 }, Validators.required),
      serviceDescription: new FormControl({ name: 'Urgent', value: 4348 }, Validators.required),
      priority: new FormControl({ name: 'Routine', value: 3754 }, Validators.required),
      expectedAdmissionDate: new FormControl('Thu May 20 2021 00:00:00 GMT-0400 (Eastern Daylight Time)', Validators.required),
      expectedDischargeDate: new FormControl('Fri May 21 2021 00:00:00 GMT-0400 (Eastern Daylight Time)', Validators.required),
      actualAdmissionDate: new FormControl('Thu May 13 2021 00:00:00 GMT-0400 (Eastern Daylight Time', Validators.required),
      actualDischargeDate: new FormControl('Fri May 14 2021 00:00:00 GMT-0400 (Eastern Daylight Time)', Validators.required),
    });
    component.caseType.caseTypeForm = component.caseTypeFormValues;
    component.saveCaseTypeDataAndSetStatus(19724); //TODO PP
    expect(component.saveCaseTypeDataAndSetStatus).toBeTruthy();
  });

  it('should call diagnosisNext', () => {
    component.caseTypeDetails = {
      srvc_set_ref_cd: {
        ref_id: ReferenceConstants.SERVICESETTINGTYPE_INPATIENT_REFID
      },
      hsc_facls: [{ actul_admis_dttm: 1 }]
    }
    component.stepperData.diagnosisLis = ['1'];
    component.diagnosisNext(); //TODO PP
    expect(ReferenceConstants.SERVICESETTINGTYPE_INPATIENT_REFID).toEqual(component.caseTypeDetails.srvc_set_ref_cd.ref_id)
    expect(component.clinicalReviewPopupOpen).toBeFalse();
  });

  it('should call closeClinicalReviewPopup', () => {
    component.closeClinicalReviewPopup();
    expect(component.clinicalReviewPopupOpen).toBeFalse();
  })
});
