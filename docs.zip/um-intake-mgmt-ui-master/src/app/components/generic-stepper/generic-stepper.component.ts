import { Constants } from '../../constants/constants';
import { ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { environment } from '../../../environments/environment';
import { Router } from '@angular/router';
import { StepperDataService } from '../../services/stepper-data/stepper-data.service';
import { UserSessionService } from '../../shared/services/user-session/user-session.service';
import { UmIntakeFuncGraphqlService } from '../../services/um-intake-functions/umintakefunc-graphql.service';
import { UtilFuncsNestjsService } from '../../services/util-funcs-nestjs/util-funcs-nestjs.service';
import {
  CasetypeComponent,
  DiagnosisComponent,
  ProcedureComponent,
  ProviderComponent,
  ContactsComponent,
  CaseNotesComponent
} from '@ecp/um-angular-ui-component-library';
import { EcpUclWizard } from '@ecp/angular-ui-component-library/wizard';
import { EcpUclModal } from '@ecp/angular-ui-component-library/modal';
import { ReferenceConstants } from "../../constants/referenceConstants";
import { viewClassName } from '@angular/compiler';

const getProvByProvID = (provs, provID) => {
  const result = provs.find((p) => p.hsc_prov_id === provID) || {};
  return result;
};

const getProvByRefID = (provs, refID) => {
  const result = provs.find((p) => {
    const refIDs = p.hsc_prov_roles.map(r => r.prov_role_ref_id);
    return refIDs.includes(refID);
  });
  return result || {};
};


@Component({
  selector: 'um-generic-stepper',
  templateUrl: './generic-stepper.component.html',
  styleUrls: ['./generic-stepper.component.scss'],
})
export class GenericStepperComponent implements OnInit {

  application = Constants.UM_INTAKE_UI_APP_NAME;
  version = environment.version;
  showDuplicate = false;
  showSpinner = false;
  caseTypeFormValues: any;
  duplicateDetailsJSON: any = {};
  @Input() stepNumber: number;
  @Input() orientation;
  @Input() linear;
  @Input() suppressSaveAndExit: boolean;
  @Output() selectChange = new EventEmitter();
  @ViewChild('procedure') procedure: ProcedureComponent;
  @ViewChild('provider') provider: ProviderComponent;
  @ViewChild('caseType') caseType: CasetypeComponent;
  @ViewChild('diagnosis') diagnosis: DiagnosisComponent;
  @ViewChild('contacts') contacts: ContactsComponent;
  @ViewChild('note') note: CaseNotesComponent;
  @ViewChild('document') doc: any;


  hscID;
  clientId;
  showDetailsView = true;
  showFavouriteProviders = true;
  providerDetailsJSON = [];
  typeAheadSearch = true;
  readOnly = false;
  serviceDetails: any;
  caseTypeDetails = null;
  stepperData: any;
  cancelPopupOpen = false;
  clinicalReviewPopupOpen = false;
  caseTypeFormData: any;
  isCaseFoundAsDuplicated = false;
  documentConfig: any;

  refreshSummary = true;
  showConfirmation = false;

  @ViewChild('stepper') stepper: EcpUclWizard;

  @ViewChild(EcpUclModal, { static: true })
  duplicateModal: EcpUclModal;
  isComponentValidationFailed: boolean = false;

  constructor(private readonly router: Router,
    private readonly stepperDataService: StepperDataService,
    private readonly userSessionService: UserSessionService,
    private readonly cdref: ChangeDetectorRef,
    public readonly umIntakeFuncGraphqlService: UmIntakeFuncGraphqlService,
    public readonly utilFuncsNestjsService: UtilFuncsNestjsService) { }

  ngOnInit() {
    this.stepperDataService.sharedStepperData.subscribe((stepperData) => {
      this.stepperData = stepperData;
      this.documentConfig = {
        subjectId: this.stepperData.hsc_id.toString(),
        subjecTypeId: Constants.SUBJECT_ID_TYPE_HSC_ID_REF_ID,
        configAppName: Constants.UM_INTAKE_UI_APP_NAME,
        envID: environment.envID
      };
    });
    this.hscID = this.stepperData.hsc_id;
    this.clientId = this.userSessionService.getActiveClientOrg();
  }

  getCaseTypeFormData() {
    this.caseTypeFormData = this.caseType.caseTypeForm.value;
    return this.caseTypeFormData;
  }

  changeEmit(evt) {
    this.stepperDataService.setStepperData({
      ...this.stepperData, services: this.procedure.serviceDetails,
      provider: this.provider.providerCaseDataDisplay,
      caseTypeData: this.caseTypeDetails,
      diagnosisList: this.diagnosis.diagnosisCaseDataDisplay,
      providerList: this.provider.providerCaseData,
      procedureList: this.procedure.procedureValue,
      contactsList: this.contacts.contacts,
      notesList: this.note.noteDetails,
      documentList: this.doc
    });
    this.refreshSummaryComponent();
    this.selectChange.emit(evt);
  }

  navigateToStep(id) {
    this.stepper.selectedIndex = id;
  }

  cancelStepAction() {
    this.cancelPopupOpen = true;
  }

  isValidationFailed(data) {
    this.isComponentValidationFailed = data?.invalidate || false;
  }

  cancelStepActionSuppressSaveAndExit() {
    this.suppressSaveAndExit = true;
    this.cancelPopupOpen = true;
  }

  goToPrevious() {
    this.readOnly = false;
  }

  checkvalidation(data) {
    if (data.diagnosisCountError) {
      return true;
    }
    return false;
  }

  navigateToUmIntakeDashboard() {
    this.router.navigate(['um/intake/dashboard']);
  }

  async cancelAndExit() {
    this.suppressSaveAndExit = false;
    this.cancelPopupOpen = false;
    this.readOnly = false;
    await this.updateCaseStatus(Constants.HSC_STATUS_CANCELLED);
    this.navigateToUmIntakeDashboard();
  }

  saveAsDraft() {
    this.suppressSaveAndExit = false;
    this.cancelPopupOpen = false;
    this.navigateToUmIntakeDashboard();
  }

  closeCancelPopup() {
    this.suppressSaveAndExit = false;
    this.cancelPopupOpen = false;
  }

  continueButtonClicked($event) {
    this.duplicateModal.close();
  }

  refreshSummaryComponent() {
    this.refreshSummary = false;
    this.cdref.detectChanges();
    this.refreshSummary = true;
    this.cdref.detectChanges();
  }
  buildObjectForDuplicateComponent(input): any {
    const result = [];
    input.forEach((r) => {
      const PROVIDER_ROLE_REF_ID_SUBMITTING = 3764;
      const PROVIDER_ROLE_REF_ID_FACILITY = 3761;
      const submittingProviderDetails = getProvByRefID(r.hsc_provs, PROVIDER_ROLE_REF_ID_SUBMITTING);
      const facilityProviderDetails = getProvByRefID(r.hsc_provs, PROVIDER_ROLE_REF_ID_FACILITY);
      result.push({
        memberDetails: {
          memberName: `${r?.individual?.[0]?.fst_nm} ${r?.individual?.[0]?.lst_nm}`,
          memberDOB: r?.individual?.[0]?.bth_dt,
          memberID: r?.individual?.[0]?.indv_id,
        },
        submittingProviderDetails: {
          providerName: submittingProviderDetails?.prov_loc_affil_dtl?.providerDetails?.bus_nm,
          providerTaxID: "",
        },
        facilityTypeDetails: {
          facilityType: r?.hsc_facls?.[0]?.plsrv_ref_cd?.ref_dspl,
          serviceDescription: r?.hsc_facls?.[0]?.srvc_desc_ref_cd?.ref_dspl,
        },
        facilityProviderDetails: {
          facilityName: facilityProviderDetails?.prov_loc_affil_dtl?.providerDetails?.bus_nm,
          taxID: facilityProviderDetails?.prov_keys?.[0]?.prov_key_val,
          admitDate: r.hsc_facls?.[0].actul_admis_dttm,
          dischargeDate: r.hsc_facls?.[0].actul_dschrg_dttm,
        },
        diagnosisDetails: r.hsc_diags.map((d) => ({
          diagnosisCode: d.diag_cd,
          diagnosisDescription: d.diag_desc,
        })),
        procedureDetails: r.hsc_srvcs.map((s) => {
          const prov = getProvByProvID(r.hsc_provs, s.srvc_hsc_prov_id);
          return {
            procedureCode: s.proc_cd,
            procedureDescription: s.proc_othr_txt,
            servicingProvider: prov?.prov_loc_affil_dtl?.providerDetails?.bus_nm,
            taxID: ""
          };
        }),
        initialContact: { name: r?.flwup_cntc_dtl?.[0]?.name, phone: r?.flwup_cntc_dtl?.[0]?.phone },
        caseTypeDetails: { caseNumber: r?.hsc_id, caseStatus: r?.hsc_sts_ref_cd?.ref_dspl },
      });
    });
    return result;
  };

  async checkDuplicates() {
    const caseTypeFormValues = this.getCaseTypeFormData();
    await this.isDuplicateFn(this.stepperData.hsc_id, caseTypeFormValues.serviceSetting.value, this.stepperData.selectedMember, caseTypeFormValues.placeOfService.value, caseTypeFormValues.serviceDescription.value, caseTypeFormValues.serviceDetail.value, caseTypeFormValues.expectedAdmissionDate, caseTypeFormValues.expectedDischargeDate);
  }

  async isDuplicateFn(hscID, serviceSetting, selectedMember, placeOfService, serviceDescription, srvc_dtl_ref_id, expectedAdmissionDate, expectedDischargeDate): Promise<any> {
    this.showSpinner = true;
    const duplicateResponse: any = await this.utilFuncsNestjsService.duplicateCheck(hscID);
    const hscReponse: any = await this.utilFuncsNestjsService.getHscDetails(hscID);
    this.duplicateDetailsJSON.duplicateCases = this.buildObjectForDuplicateComponent(duplicateResponse?.data?.duplicateCheck?.hsc_duplicates);
    this.duplicateDetailsJSON.currentCase = this.buildObjectForDuplicateComponent(hscReponse?.data?.getHscAuthDetails?.hsc)[0];
    this.showSpinner = false;
    this.isCaseFoundAsDuplicated = this.duplicateDetailsJSON.duplicateCases.length > 0;
    this.showDuplicate = this.duplicateDetailsJSON.duplicateCases.length > 0;
  }

  async saveCaseTypeData() {
    this.saveCaseTypeDataAndSetStatus(null);
  }

  async saveCaseTypeDataAndSetStatus(hscStatusRefId) {
    const caseTypeFormValues = this.getCaseTypeFormData();
    this.serviceDetails = { srvc_set_ref_id: this.caseTypeDetails ? this.caseTypeDetails.srvc_set_ref_id : null };
    if (caseTypeFormValues) {
      this.buildCaseTypeDetailsObj(caseTypeFormValues);
    }
    const updateHscRequest = {
      hsc_id: this.stepperData.hsc_id,
      srvc_set_ref_id: caseTypeFormValues.serviceSetting?.value,
      hsc: {
        ...(hscStatusRefId) && { hsc_sts_ref_id: hscStatusRefId },
        rev_prr_ref_id: caseTypeFormValues?.priority?.value,
        indv_id: this.stepperData?.selectedMember?.indv_id
      },
      hsc_facl: {
        plsrv_ref_id: caseTypeFormValues?.placeOfService?.value,
        srvc_desc_ref_id: caseTypeFormValues?.serviceDescription?.value,
        srvc_dtl_ref_id: caseTypeFormValues?.serviceDetail?.value,
        actul_admis_dttm: this.formatDate(
          caseTypeFormValues.actualAdmissionDate
        ),
        actul_dschrg_dttm: this.formatDate(
          caseTypeFormValues.actualDischargeDate
        ),
        expt_admis_dt: this.formatDate(
          caseTypeFormValues.expectedAdmissionDate
        ),
        expt_dschrg_dt: this.formatDate(
          caseTypeFormValues.expectedDischargeDate
        ),
      },
    };
    await this.utilFuncsNestjsService.updateHsc(
      updateHscRequest
    );
  }

  async updateCaseStatus(hscStatusRefId: number) {
    const updateHscRequest = {
      hsc_id: this.stepperData.hsc_id,
      hsc: {
        hsc_sts_ref_id: hscStatusRefId
      },
    };
    await this.utilFuncsNestjsService.updateHsc(updateHscRequest);
  }

  diagnosisNext() {
    if (ReferenceConstants.SERVICESETTINGTYPE_INPATIENT_REFID == this.caseTypeDetails.srvc_set_ref_cd.ref_id && this.caseTypeDetails.hsc_facls[0].actul_admis_dttm
      && this.stepperData.diagnosisList && this.stepperData.diagnosisList.length > 0) {
      this.clinicalReviewPopupOpen = true;
    }
  }

  closeClinicalReviewPopup() {
    this.clinicalReviewPopupOpen = false;
  }

  formatDate(date) {
    if (date != null) {
      const d = new Date(date);
      let month = '' + (d.getMonth() + 1);
      let day = '' + d.getDate();
      const year = d.getFullYear();

      if (month.length < 2) {
        month = '0' + month;
      }
      if (day.length < 2) {
        day = '0' + day;
      }

      return [year, month, day].join('-');
    } else {
      return '';
    }
  }

  buildCaseTypeDetailsObj(caseTypeFormValues: any) {
    this.caseTypeDetails = {
      hsc_id: this.stepperData.hsc_id,
      hsc_sts_ref_id: this.stepperData?.hsc_sts_ref_id ? this.stepperData.hsc_sts_ref_id : null,
      rev_prr_ref_id: caseTypeFormValues.priority?.value,
      rev_prr_ref_cd: {
        ref_id: caseTypeFormValues.priority?.value,
        ref_dspl: caseTypeFormValues.priority?.name,
      },
      srvc_set_ref_id: caseTypeFormValues.serviceSetting?.name,
      srvc_set_ref_cd: {
        ref_id: caseTypeFormValues.serviceSetting?.value,
        ref_dspl: caseTypeFormValues.serviceSetting?.name,
      },
      hsc_facls: [
        {
          plsrv_ref_id: caseTypeFormValues.placeOfService?.value,
          plsrv_ref_cd: {
            ref_id: caseTypeFormValues.placeOfService?.value,
            ref_dspl: caseTypeFormValues.placeOfService?.name,
          },
          srvc_desc_ref_id: caseTypeFormValues.serviceDescription?.value,
          srvc_desc_ref_cd: {
            ref_id: caseTypeFormValues.serviceDescription?.value,
            ref_dspl: caseTypeFormValues.serviceDescription?.name,
          },
          srvc_dtl_ref_id: caseTypeFormValues.serviceDetail?.value,
          srvc_dtl_ref_cd: {
            ref_id: caseTypeFormValues.serviceDetail?.value,
            ref_dspl: caseTypeFormValues.serviceDetail?.name,
          },
          actul_admis_dttm: this.formatDate(
            caseTypeFormValues.actualAdmissionDate
          ),
          actul_dschrg_dttm: this.formatDate(
            caseTypeFormValues.actualDischargeDate
          ),
          expt_admis_dt: this.formatDate(
            caseTypeFormValues.expectedAdmissionDate
          ),
          expt_dschrg_dt: this.formatDate(
            caseTypeFormValues.expectedDischargeDate
          )
        }
      ]
    }
  }

  async submitCase() {
    const updateHscRequest = {
      hsc_id: this.stepperData.hsc_id,
      hsc: {
        hsc_sts_ref_id: ReferenceConstants.HSCSTATUSTYPE_OPEN_REFID,
        hsc_sts_rsn_ref_id: ReferenceConstants.HSCSTATUSREASONTYPE_PENDING_REVIEW_REFID
      },
    };
    const updateHscResponse: any = await this.utilFuncsNestjsService.updateHsc(updateHscRequest);
    if (updateHscResponse) {
      this.stepperDataService.setStepperData({
        ...this.stepperData,
        hsc: { ...this.stepperData.hsc, hsc_sts_ref_id: ReferenceConstants.HSCSTATUSTYPE_OPEN_REFID },
        showConfirmation: true
      });
      this.showConfirmation = true;
      const ele = document.getElementById('confirmation')
      ele ? ele.scrollIntoView() : null;
    }
    // continue async call to submitHsc to send signal to bpmn.
    // TODO: Cleanup below code when there is no need to send signal on Hsc submission
    const submitHsc = {
      hsc_id: this.hscID.toString(),
      caseId: this.stepperData.busProcessInstId,
      variables: this.sendStepperSignalVariabletoBPM()
    };
    this.readOnly = true;
    this.umIntakeFuncGraphqlService.submitHsc(submitHsc);
  }
  sendStepperSignalVariabletoBPM() {
    const serviceType = this.stepperData.serviceType;
    const caseType = 3737;

    const variables = {
      currentStep: {},
      completedStep: {
        value: 9
      },
      hsc: {
        value: { serviceType, caseType, hsc_key_val: this.stepperData.caseId, hsc_id: this.hscID.toString(), orgId: this.clientId }
      }
    };
    return variables;
  }

}
