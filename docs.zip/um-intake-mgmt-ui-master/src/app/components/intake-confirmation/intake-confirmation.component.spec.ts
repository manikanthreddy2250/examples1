import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IntakeConfirmationComponent } from './intake-confirmation.component';
import {CUSTOM_ELEMENTS_SCHEMA, Injectable, NO_ERRORS_SCHEMA} from '@angular/core';
import {BehaviorSubject} from 'rxjs';
import {HttpClient, HttpHandler} from '@angular/common/http';
import {StepperDataService} from '../../services/stepper-data/stepper-data.service';

@Injectable()
class MockStepperDataService {
  private stepperData = new BehaviorSubject({
    tenantId: 'ecpumintakebaseproductbpmgrp',
    hsc_id: 1345
  });
  sharedStepperData = this.stepperData.asObservable();

  constructor() {
  }

  setStepperData(stepperData: any) {
    this.stepperData.next(stepperData);
  }
}

describe('IntakeConfirmationComponent', () => {
  let component: IntakeConfirmationComponent;
  let fixture: ComponentFixture<IntakeConfirmationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IntakeConfirmationComponent ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      providers: [HttpClient,  {provide: StepperDataService, useClass: MockStepperDataService}]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(IntakeConfirmationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
