import { Component, OnInit, Output, EventEmitter} from '@angular/core';
import { Constants } from '../../constants/constants';
import { environment } from '../../../environments/environment';
import { StepperDataService } from '../../services/stepper-data/stepper-data.service';

@Component({
  selector: 'um-intake-confirmation',
  templateUrl: './intake-confirmation.component.html',
  styleUrls: ['./intake-confirmation.component.scss']
})
export class IntakeConfirmationComponent implements OnInit {
  application = Constants.UM_INTAKE_UI_APP_NAME;
  version = environment.version;
  lockIconSrc: String = "/assets/images/lock.png"
  showDetailsView = true;
  readonly = true;
  hscID;
  services: any;
  showProvider = true;
  showFavouriteProviders = false;
  showCaseProviders = true;
  providerDetailsJSON: any;
  caseTypeDetails: any;
  typeAheadSearch = true;
  stepperData: any;
  documentConfig: any;
  createdDateTime: any = new Date().toJSON().slice(0, 10).replace(/-/g, '/');;

  @Output() gotoStepperId: EventEmitter<any> = new EventEmitter();

  constructor(private readonly stepperDataService: StepperDataService) { }

  ngOnInit() {
    this.stepperDataService.sharedStepperData.subscribe((stepperData) => {
      this.stepperData = stepperData;
      this.hscID = this.stepperData.hsc_id;
      this.services = this.stepperData.services;
      this.providerDetailsJSON = {
        user_favs: [{}],
        hsc_provs: this.stepperData.provider
      };
      this.documentConfig = {
        subjectId: this.stepperData?.hsc_id?.toString(),
        subjecTypeId: Constants.SUBJECT_ID_TYPE_HSC_ID_REF_ID,
        configAppName: Constants.UM_INTAKE_UI_APP_NAME,
        envID: environment.envID
      };
      this.caseTypeDetails = this.stepperData.caseTypeData;
    });
  }
}
