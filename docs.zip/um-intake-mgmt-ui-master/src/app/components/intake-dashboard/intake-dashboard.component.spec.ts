import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AuthLibraryModule, AuthService, MicroProductAuthService } from '@ecp/auth-library';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA, Injectable, NO_ERRORS_SCHEMA } from '@angular/core';
import { UmintakefuncCreateDraftHscService } from '../../services/um-intake-functions/umintakefunc-create-draft-hsc.service';
import { IntakeDashboardComponent } from './intake-dashboard.component';
import { StepperDataService } from '../../services/stepper-data/stepper-data.service';
import { UserSessionService } from '../../shared/services/user-session/user-session.service';
import { IndividualGraphqlService } from 'src/app/services/individual/individual-graphql.service';

@Injectable()
class UserSessionMockService {
  getUserHasuraRole() {
    return 'abcd';
  }
  getActiveClientOrg() {
    return 'ecp';
  }
  getActiveUserRole() { return 'test'; }

  getEcpToken() { return 'hello'; }
}

describe('IntakeDashboardComponent', () => {
  let component: IntakeDashboardComponent;
  let umintakeService: UmintakefuncCreateDraftHscService;
  let individualService: IndividualGraphqlService;
  let authService: AuthService;
  let microProductAuth: MicroProductAuthService;
  let fixture: ComponentFixture<IntakeDashboardComponent>;
  const router = {
    navigate: jasmine.createSpy('navigate')
  };

  beforeEach((() => {
    TestBed.configureTestingModule({
      declarations: [IntakeDashboardComponent],
      imports: [HttpClientTestingModule, AuthLibraryModule, RouterTestingModule],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      providers: [StepperDataService, AuthService, { provide: UserSessionService, useClass: UserSessionMockService },
        UmintakefuncCreateDraftHscService, IndividualGraphqlService]
    })
      .compileComponents();
    umintakeService = TestBed.inject(UmintakefuncCreateDraftHscService);
    individualService = TestBed.inject(IndividualGraphqlService);
    authService = TestBed.inject(AuthService);
    microProductAuth = TestBed.inject(MicroProductAuthService);
    fixture = TestBed.createComponent(IntakeDashboardComponent);
    component = fixture.componentInstance;
    const res: any = { 'x-ecp-claims': { 'x-ecp-attrs': { taxIds: '[\'256556261\',\'806930103\']' } } };
    const userspy = spyOn(microProductAuth, 'getEcpClaims').and.returnValue(res);
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call initiateAuthAndRedirectToInTakeForm method', () => {
    const res: any = {
      data: {
        createDraftAuth: {
          hscId: 17736,
          caseId: '78734a39-a8f4-11eb-b68b-5e049650cdb3',
          tenantId: 'ecpumintakebaseproductbpmgrp',
          isMbrBlocked: false
        }
      }
    };
    const indvRes: any = {
      data: {
        indv_key: [{
          indv_id: 503926748,
          indv_key_typ_ref_id: 2757,
          indv_key_val: '16440436900',
          orig_sys_cd: 'CDB_CS',
          membership: [{
            orig_sys_cd: 'CDB_CS',
            orig_sys_mbr_id: '16440436900',
            mbr_covs: [{
              clm_pltfm_ref_id: 363,
              cov_eff_dt: '2019-05-01',
              cov_end_dt: '2020-01-31',
              cov_typ_ref_cd: { ref_dspl: 'Medical' },
              mbr_cov_id: 90881960,
              pol_nbr: '0752023',
              prdct_catgy_ref_cd: null,
              prdct_ref_id: 226
            }]

          }]

        }]
      }
    };
    component.memberForm.controls.memberCovId.setValue('90881960');
    component.memberForm.controls.memberId.setValue('16440436900');
    const indvspy = spyOn(individualService, 'getMemberDetailsById').and.returnValue(indvRes);
    const userspy = spyOn(umintakeService, 'createHscDraft').and.returnValue(res);
    component.memberHeaderData = true;
    component.selectedMember = {
      claim_platform_ref_Id: 363,
      cov_eff_dt: '2020-02-01',
      cov_end_dt: '9999-12-31',
      coverageTypeDesc: 'Medical',
      indv_id: 503926748,
      indv_key_typ_ref_id: 2757,
      indv_key_val: '16440436900',
      mbr_cov_id: 90881959,
      pol_nbr: '0752023',
      productCatgyTpe: null,
      productCode: 226,
    };
    component.initiateAuthAndRedirectToInTakeForm();
    expect(component.initiateAuthAndRedirectToInTakeForm).toBeTruthy();
  });

  it('should call initiateAuthAndRedirectToInTakeForm method with no form values', () => {
    component.memberForm.controls.memberCovId.setValue(null);
    component.memberForm.controls.memberId.setValue('16440436900');
    component.selectedMember = {
      claim_platform_ref_Id: 363,
      cov_eff_dt: '2020-02-01',
      cov_end_dt: '9999-12-31',
      coverageTypeDesc: 'Medical',
      indv_id: 503926748,
      indv_key_typ_ref_id: 2757,
      indv_key_val: '16440436900',
      mbr_cov_id: 90881959,
      pol_nbr: '0752023',
      productCatgyTpe: null,
      productCode: 226,
    };
    component.initiateAuthAndRedirectToInTakeForm();
    expect(component.initiateAuthAndRedirectToInTakeForm).toBeTruthy();
  });

  it('should call initiateAuthAndRedirectToInTakeForm method with no Membership match', () => {
    const res: any = {
      data: {
        createDraftAuth: {
          hscId: 17736,
          caseId: '78734a39-a8f4-11eb-b68b-5e049650cdb3',
          tenantId: 'ecpumintakebaseproductbpmgrp',
          isMbrBlocked: false
        }
      }
    };
    const indvRes: any = {
      data: {
        indv_key: [{
          indv_id: 503926748,
          indv_key_typ_ref_id: 2757,
          indv_key_val: '16440436900',
          orig_sys_cd: 'CDB_CS',
          membership: [{
            orig_sys_cd: 'CDB_CS',
            orig_sys_mbr_id: '16440436900',
            mbr_covs: [{
              clm_pltfm_ref_id: 363,
              cov_eff_dt: '2019-05-01',
              cov_end_dt: '2020-01-31',
              cov_typ_ref_cd: { ref_dspl: 'Medical' },
              mbr_cov_id: 1234,
              pol_nbr: '0752023',
              prdct_catgy_ref_cd: null,
              prdct_ref_id: 226
            }]

          }]

        }]
      }
    };
    component.memberForm.controls.memberCovId.setValue('90881960');
    component.memberForm.controls.memberId.setValue('16440436900');
    const indvspy = spyOn(individualService, 'getMemberDetailsById').and.returnValue(indvRes);
    const userspy = spyOn(umintakeService, 'createHscDraft').and.returnValue(res);
    component.selectedMember = {
      claim_platform_ref_Id: 363,
      cov_eff_dt: '2020-02-01',
      cov_end_dt: '9999-12-31',
      coverageTypeDesc: 'Medical',
      indv_id: 503926748,
      indv_key_typ_ref_id: 2757,
      indv_key_val: '16440436900',
      mbr_cov_id: 90881959,
      pol_nbr: '0752023',
      productCatgyTpe: null,
      productCode: 226,
    };
    component.initiateAuthAndRedirectToInTakeForm();
    expect(component.initiateAuthAndRedirectToInTakeForm).toBeTruthy();
  });

  it('should call createHsc method', () => {
    const res: any = {
      data: {
        createDraftAuth: {
          hscId: 17736,
          caseId: '78734a39-a8f4-11eb-b68b-5e049650cdb3',
          tenantId: 'ecpumintakebaseproductbpmgrp',
          isMbrBlocked: false
        }
      }
    };
    const userspy = spyOn(umintakeService, 'createHscDraft').and.returnValue(res);
    component.selectedMember = {
      claim_platform_ref_Id: 363,
      cov_eff_dt: '2020-02-01',
      cov_end_dt: '9999-12-31',
      coverageTypeDesc: 'Medical',
      indv_id: 503926748,
      indv_key_typ_ref_id: 2757,
      indv_key_val: '16440436900',
      mbr_cov_id: 90881959,
      pol_nbr: '0752023',
      productCatgyTpe: null,
      productCode: 226,
    };
    const data = { record: { prov_key_val: 1234 } };
    component.onClick(data);
    component.createHsc();
    expect(component.createHsc).toBeTruthy();
  });
  afterAll(() => {
    TestBed.resetTestingModule();
  });
});
