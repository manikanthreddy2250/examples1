import { Component, OnInit, AfterViewInit, ViewEncapsulation, ViewChild, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { Constants } from '../../constants/constants';
import { environment } from '../../../environments/environment';
import { StepperDataService } from 'src/app/services/stepper-data/stepper-data.service';
import { UmintakefuncCreateDraftHscService } from '../../services/um-intake-functions/umintakefunc-create-draft-hsc.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { EcpUclModal } from '@ecp/angular-ui-component-library/modal';
import { IndividualGraphqlService } from 'src/app/services/individual/individual-graphql.service';
import { DatePipe } from '@angular/common';
import { ProviderGraphqlService } from '@ecp/um-angular-ui-component-library';



@Component({
  selector: 'um-intake-dashboard',
  templateUrl: './intake-dashboard.component.html',
  styleUrls: ['./intake-dashboard.component.scss'],
  encapsulation: ViewEncapsulation.None
})

export class IntakeDashboardComponent implements OnInit, AfterViewInit {
  @Output() selectedMemberPolicy = new EventEmitter();

  constructor(private readonly umintakefuncCreateDraftHscService: UmintakefuncCreateDraftHscService, private readonly router: Router,
    private readonly stepperDataService: StepperDataService, private individualGraphqlService: IndividualGraphqlService, private datePipe: DatePipe,
    private readonly providerService: ProviderGraphqlService
  ) { }

  hscId = 18112;
  showDetailsView = false;
  showProvider = true;
  showFavouriteProviders = false;
  showLandingPageProviders = true;
  memberForm: FormGroup;
  selectedMember: any;
  providerDetailsJSON = [];
  stepperData: any;
  submittingProvider: any;
  @ViewChild(EcpUclModal, { static: true })
  modal: EcpUclModal;
  errorMessage: string;
  version = environment.version;
  envId = environment.envID;
  application = Constants.UM_INTAKE_UI_APP_NAME;
  todayDate: any;
  memberResults;
  memberHeaderData;
  memberSearchPopupOpen = false;
  documentSelectedHTMLElements: NodeList;

  ngOnInit() {
    this.stepperDataService.sharedStepperData.subscribe((stepperData) => {
      this.stepperData = stepperData;
    });
    this.memberForm = new FormGroup({
      memberCovId: new FormControl(null, Validators.required),
      memberId: new FormControl(null, Validators.required),
    });
    this.errorMessage = null;
  }

  async initiateAuthAndRedirectToInTakeForm() {
    if (this.memberHeaderData) {
      this.mapSelectedMemberDetails();
      await this.createHsc();
    }
    else {
      this.errorMessage = 'Membership Details not found';
      this.modal ? this.modal.open() : null;
    }
  }


  mapSelectedMemberDetails() {
    this.selectedMember = {
      claim_platform_ref_Id: null,
      cov_eff_dt: this.memberHeaderData.policy ? this.memberHeaderData.policy.startDate : null,
      cov_end_dt: this.memberHeaderData.policy ? this.memberHeaderData.policy.endDate : null,
      coverageTypeDesc: null,
      indv_id: this.memberHeaderData.record ? this.memberHeaderData.record.individualID : null,
      indv_key_typ_ref_id: this.memberHeaderData.policy ? this.memberHeaderData.policy.originalSystemReferenceID : null,
      indv_key_val: this.memberHeaderData.record ? this.memberHeaderData.record.memberId : null,
      mbr_cov_id: 93706493,
      pol_nbr: this.memberHeaderData.policy ? this.memberHeaderData.policy.policyNum : null,
      productCatgyTpe: this.memberHeaderData.policy ? this.memberHeaderData.policy.insuranceTypeId : null,
      productCode: null
    };
  }

  async createHsc() {
    const createHsc = {
      serviceType: 'Generic',
      hsc: {
        indv_id: this.selectedMember?.indv_id?.toString(),
        indv_key_typ_ref_id: this.selectedMember.indv_key_typ_ref_id,
        indv_key_val: this.selectedMember.indv_key_val,
        hsc_rev_typ_ref_id: 20402,
        mbr_cov_dtl: this.selectedMember
      },
      coverage: {
        policyNumber: this.selectedMember.pol_nbr,
        productCode: this.selectedMember.productCode ? this.selectedMember.productCode : 0,
        claimPlatform: this.selectedMember.claim_platform_ref_Id ? this.selectedMember.claim_platform_ref_Id : 0,
        sourceChannel: ''
      }
    };
    this.stepperDataService.setStepperData({ ...this.stepperData, serviceType: 'Generic', selectedMember: this.selectedMember });
    try {
      const data: any = await this.umintakefuncCreateDraftHscService.createHscDraft(createHsc);
      if (data && !data.data.createDraftAuth.isMbrBlocked) {
        this.stepperDataService.setStepperData({
          ...this.stepperData, busProcessInstId: data.data.createDraftAuth.caseId, hsc_id: data.data.createDraftAuth.hscId,
          tenantId: data.data.createDraftAuth.tenantId, flowType: 'new'
        });
        if (this.submittingProvider && data.data.createDraftAuth.hscId) {
          // Save Submitting Provider After Case Creation
          // Should wait in order to save to DB
          this.submittingProvider.record.hsc_prov_roles = [{ prov_role_ref_id: 3764 }];
          await this.providerService.saveProvider(data.data.createDraftAuth.hscId,
            this.submittingProvider.record,
            this.submittingProvider.role,
            Constants.UM_INTAKE_UI_APP_NAME);
        }
        if (this.selectedMember && this.selectedMember.indv_key_val) {
          this.router.navigate(['/um/intake-form', this.selectedMember.indv_key_val,
            'Generic', data.data.createDraftAuth.caseId, data.data.createDraftAuth.hscId]);
        }
      } else {
        console.error('Member is blocked , cannot create HSC');
      }
    }
    catch (e) { console.error(e); }
  }

  onClick(data: any) {
    this.submittingProvider = data;
  }

  memberSearchResults(event: any) {
    this.memberResults = event;
  }

  changeEmit(evt) {
    this.memberHeaderData = evt;
    if (this.memberHeaderData) {
      this.mapSelectedMemberDetails();
      this.documentSelectedHTMLElements = document.querySelectorAll('ecp-comn-member-advanced-search, ' +
        'ecp-comn-member-advanced-search-results, #advance-search-card-id, #advance-search-card-child-id, ' +
        '.ecp-ucl-card-content, .ecp-ucl-card.ecp-ucl-card--boxShadow, .ecp-ucl-card.ecp-ucl-card--box');
      [].forEach.call(this.documentSelectedHTMLElements, (e) => {
        e.style.width = '90vw';
      });
      (document.querySelector('#memberSearchContainerDiv') as HTMLElement).style.height = '520px';
      (document.querySelector('.ecp-ucl-card.ecp-ucl-card--boxShadow, .ecp-ucl-card.ecp-ucl-card--box') as HTMLElement).style.boxSizing = 'border-box';
      // (document.querySelector('.advance-search-hide-icon') as HTMLElement).style.display = 'none';
      this.memberSearchPopupOpen = true;
    } else {
      this.errorMessage = 'Member details not found!';
      this.modal ? this.modal.open() : null;
    }
  }

  closeMemberSearchPopup() {
    this.memberSearchPopupOpen = false;
  }
  ngAfterViewInit() {
    // (document.querySelector('.advance-search-hide-icon') as HTMLElement).style.display = 'none';
  }
}
