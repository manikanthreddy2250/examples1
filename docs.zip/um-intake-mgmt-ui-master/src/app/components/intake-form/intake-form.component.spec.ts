import {NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA, Injectable, ChangeDetectorRef} from '@angular/core';
import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { IntakeFormComponent } from './intake-form.component';
import {BehaviorSubject} from 'rxjs';
import {UserSessionService} from '../../shared/services/user-session/user-session.service';
import {UmIntakeFuncGraphqlService} from '../../services/um-intake-functions/umintakefunc-graphql.service';
import {CasetypeComponent} from '@ecp/um-angular-ui-component-library';
import {HttpClient, HttpHandler} from '@angular/common/http';
import {StepperDataService} from '../../services/stepper-data/stepper-data.service';


@Injectable()
class MockStepperDataService {
  private stepperData = new BehaviorSubject({
    tenantId: 'ecpumintakebaseproductbpmgrp',
    hsc_id: 1345,
    selectedMember: {
      indv_id: 18029351,
      pol_nbr: '0196819'
    }
  });
  sharedStepperData = this.stepperData.asObservable();

  constructor() {
  }

  setStepperData(stepperData: any) {
    this.stepperData.next(stepperData);
  }
}

describe('IntakeFormComponent', () => {
  let component: IntakeFormComponent;
  let fixture: ComponentFixture<IntakeFormComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ IntakeFormComponent ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      providers: [HttpClient,  {provide: StepperDataService, useClass: MockStepperDataService}]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IntakeFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call navigateToStep method', () => {
    const event = {};
    component.selectChange(event);
    expect(component.selectChange).toBeDefined();
  });
});
