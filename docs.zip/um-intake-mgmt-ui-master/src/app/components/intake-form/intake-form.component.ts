import { Component, OnInit } from '@angular/core';
import {environment} from '../../../environments/environment';
import {Constants} from '../../constants/constants';
import {StepperDataService} from '../../services/stepper-data/stepper-data.service';


@Component({
  selector: 'um-intake-form',
  templateUrl: './intake-form.component.html',
  styleUrls: ['./intake-form.component.scss']
})
export class IntakeFormComponent implements OnInit {


  constructor( private readonly stepperDataService: StepperDataService) { }

  stepperData: any;
  public currentStep = 1;

  public stepperLabels = [
    { id: 1, label: 'Case Type', value: '1' },
    { id: 2, label: 'Facility / Provider', value: '2' },
    { id: 3, label: 'Diagnosis / Procedures', value: '3' },
    { id: 4, label: 'Contacts', value: '4' },
    { id: 5, label: 'Documentation', value: '5' },
    { id: 6, label: 'Summary', value: '6' }
  ];

  version = environment.version;
  envId = environment.envID;
  application = Constants.UM_INTAKE_UI_APP_NAME;

  ngOnInit() {
      this.stepperDataService.sharedStepperData.subscribe((stepperData) => {
        this.stepperData = stepperData;
      });
  }

  selectChange(event) {
    console.log(event);
  }

}
