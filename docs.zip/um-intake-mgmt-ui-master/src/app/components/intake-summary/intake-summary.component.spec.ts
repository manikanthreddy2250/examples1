import { CUSTOM_ELEMENTS_SCHEMA, Injectable, NO_ERRORS_SCHEMA} from '@angular/core';
import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { IntakeSummaryComponent } from './intake-summary.component';
import {BehaviorSubject} from 'rxjs';
import {HttpClient, HttpHandler} from '@angular/common/http';
import {StepperDataService} from '../../services/stepper-data/stepper-data.service';

@Injectable()
class MockStepperDataService {
  private stepperData = new BehaviorSubject({
    tenantId: 'ecpumintakebaseproductbpmgrp',
    hsc_id: 1345
  });
  sharedStepperData = this.stepperData.asObservable();

  constructor() {
  }

  setStepperData(stepperData: any) {
    this.stepperData.next(stepperData);
  }
}

describe('IntakeSummaryComponent', () => {
  let component: IntakeSummaryComponent;
  let fixture: ComponentFixture<IntakeSummaryComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ IntakeSummaryComponent ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      providers: [HttpClient,  {provide: StepperDataService, useClass: MockStepperDataService}]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IntakeSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call goToStepper method', () => {
    const id = 2;
  component.goToStepper(id);
  expect(component.gotoStepperId).toBeDefined();
});
});
