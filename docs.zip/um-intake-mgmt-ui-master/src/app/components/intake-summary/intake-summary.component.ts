import { Component, OnInit, ViewChild, Output, EventEmitter, AfterViewInit, Input } from '@angular/core';
import { Constants } from '../../constants/constants';
import { environment } from '../../../environments/environment';
import { ProcedureComponent } from '@ecp/um-angular-ui-component-library';
import { StepperDataService } from '../../services/stepper-data/stepper-data.service';

@Component({
  selector: 'um-intake-summary',
  templateUrl: './intake-summary.component.html',
  styleUrls: ['./intake-summary.component.scss']
})
export class IntakeSummaryComponent implements OnInit, AfterViewInit {
  @Input() readOnly = true;

  application = Constants.UM_INTAKE_UI_APP_NAME;
  version = environment.version;

  lockIconSrc: String = "/assets/images/lock.png"
  showDetailsView = true;
  hscID;
  services: any;
  showProvider = true;
  showFavouriteProviders = false;
  showCaseProviders = true;
  providerDetailsJSON: any;
  caseTypeDetails: any;
  typeAheadSearch = true;
  stepperData: any;
  documentConfig: any;

  @ViewChild('procedure') procedure: ProcedureComponent;
  @Output() gotoStepperId: EventEmitter<any> = new EventEmitter();

  constructor(private readonly stepperDataService: StepperDataService) {
    this.stepperDataService.sharedStepperData.subscribe((stepperData) => {
      this.stepperData = stepperData;
      this.hscID = this.stepperData.hsc_id;
      this.services = this.stepperData.services;
      this.providerDetailsJSON = {
        user_favs: [{}],
        hsc_provs: this.stepperData.provider
      };
      this.caseTypeDetails = this.stepperData.caseTypeData;
    });
  }

  ngOnInit() {
    this.documentConfig = {
      subjectId: this.stepperData.hsc_id.toString(),
      subjecTypeId: Constants.SUBJECT_ID_TYPE_HSC_ID_REF_ID,
      configAppName: Constants.UM_INTAKE_UI_APP_NAME,
      envID: environment.envID
    };
  }

  ngAfterViewInit() { }

  goToStepper(id) {
    this.gotoStepperId.emit(id);
  }
}
