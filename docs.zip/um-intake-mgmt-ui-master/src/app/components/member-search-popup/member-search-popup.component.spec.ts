import { ComponentFixture, TestBed } from '@angular/core/testing';
import {ModalModule} from '@ecp/angular-ui-component-library/modal';
import { MemberSearchPopupComponent } from './member-search-popup.component';

describe('MemberSearchPopupComponent', () => {
  let component: MemberSearchPopupComponent;
  let fixture: ComponentFixture<MemberSearchPopupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ModalModule],
      declarations: [ MemberSearchPopupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MemberSearchPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
});
