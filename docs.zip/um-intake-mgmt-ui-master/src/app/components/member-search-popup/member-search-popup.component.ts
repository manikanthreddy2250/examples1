import {Component, EventEmitter, Input, OnInit, AfterViewInit, Output, ViewChild, ViewEncapsulation} from '@angular/core';
import {EcpUclModal} from '@ecp/angular-ui-component-library/modal';
import {Constants} from '../../constants/constants';
import {environment} from '../../../environments/environment';

@Component({
  selector: 'um-member-search-popup',
  templateUrl: './member-search-popup.component.html',
  styleUrls: ['./member-search-popup.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class MemberSearchPopupComponent implements OnInit, AfterViewInit {
  @ViewChild(EcpUclModal, {static: true}) memberSearchModal: EcpUclModal;
  @Input() hscID;
  @Input() selectedMember: any;
  @Output() exit = new EventEmitter();
  application = Constants.UM_INTAKE_UI_APP_NAME;
  envId = environment.envID;
  constructor() { }

  ngOnInit() {
    this.memberSearchModal.open();
  }
  close() {
    this.memberSearchModal.close();
    this.exit.emit();
  }
  ngAfterViewInit() {
    (document.querySelector('.cdk-overlay-pane') as HTMLElement).style.maxWidth = '95vw';
  }
}
