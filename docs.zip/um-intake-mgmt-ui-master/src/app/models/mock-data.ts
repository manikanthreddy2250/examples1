import {Injectable} from '@angular/core';

@Injectable({
    providedIn: 'root'
})
export class IntakeSummaryMockData {
    procedureData = [];
    diagnosisData = [];
    providerData = [];

    constructor() {
        this.diagnosisData = [
            {
                name: 'S123 - Description needs to be added upto 40 character',
                updated: '02/03/2021 11:11 am'
            },
            {
                name: 'Cyanosis, new onset or worsening',
                updated: '03/03/2021 11:11 am'
            }
        ];
        this.procedureData = [
            {
                shrt_desc: 'NONEMERG TRNSPRT: MEALS-RECIP',
                proc_cd: 'A0190',
                dateOfProcedure: '12/12/2020 11:18 am',
                updated: '04/12/2021 03:18 pm'
            },
            {
                shrt_desc: 'Cyanosis, new onset or worsening',
                proc_cd: 'G0156',
                dateOfProcedure: '12/12/2020 11:18 am',
                updated: '04/20/2021 04:18 pm'
            }
        ];
    }

    getDiagnosisData() {
        return this.diagnosisData;
    }
    getProcedureData() {
        return this.procedureData;
    }
    getProviderData() {
        return this.providerData;
    }
}
