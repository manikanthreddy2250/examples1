import { TestBed } from '@angular/core/testing';
import { IndividualGraphqlService } from './individual-graphql.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { AuthLibraryModule } from '@ecp/auth-library';
import {  HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { of } from 'rxjs/internal/observable/of';

@Injectable()
class MockHttpClient {
  post(url: string, body: any | null, options?: any) {
    switch (url) {
      case 'https://dev-ecp-analytical-api.optum.com/paeta/api/eta':
        return of({data: {eta: 2}});
      default:
        return of({});
    }
  }
}

describe('IndividualGraphqlService', () => {

  let service: IndividualGraphqlService;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, AuthLibraryModule],
      providers: [ { provide: HttpClient, useClass: MockHttpClient }] 
    });
    service = TestBed.inject(IndividualGraphqlService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should be created', () => {
    const createHsc:any = {}
    service.getMemberDetailsById(createHsc);
    expect(service.getMemberDetailsById).toHaveBeenCalled;
  });

});
