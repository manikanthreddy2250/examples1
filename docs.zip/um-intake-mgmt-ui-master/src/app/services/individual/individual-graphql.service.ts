import { Injectable } from '@angular/core';
import {UserSessionService} from '../../shared/services/user-session/user-session.service';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { getMemberDetailsQuery } from 'src/app/shared/graphql/individualQuery';


@Injectable({
  providedIn: 'root'
})
export class IndividualGraphqlService {

  constructor( public  userSessionService: UserSessionService,public  http: HttpClient) { }

 getMemberDetailsById(indvkeyVal:any): Promise<any> {
    const getMemberDetailsByMemberId = {
      query: getMemberDetailsQuery,
      variables: {
        indvkeyVal
      }
    };
    return this.http.post(environment.INDIVIDUAL_DOMAIN_URL, JSON.stringify(getMemberDetailsByMemberId), { headers: this.userSessionService.getApiHeaders()}).toPromise();
  }
}
