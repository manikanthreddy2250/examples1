import { TestBed } from '@angular/core/testing';

import { UmintakefuncCreateDraftHscService } from './umintakefunc-create-draft-hsc.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { AuthLibraryModule } from '@ecp/auth-library';
import {  HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { of } from 'rxjs/internal/observable/of';

@Injectable()
class MockHttpClient {
  post(url: string, body: any | null, options?: any) {
    switch (url) {
      case 'https://dev-ecp-analytical-api.optum.com/paeta/api/eta':
        return of({data: {eta: 2}});
      default:
        return of({});
    }
  }
}

describe('UmintakefuncCreateDraftHscService', () => {

  let service: UmintakefuncCreateDraftHscService;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, AuthLibraryModule],
      providers: [ { provide: HttpClient, useClass: MockHttpClient }] 
    });
    service = TestBed.inject(UmintakefuncCreateDraftHscService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should be created', () => {
    const createHsc:any = {}
    service.createHscDraft(createHsc);
    expect(service.createHscDraft).toHaveBeenCalled;
  });

});
