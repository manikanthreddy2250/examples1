import {HttpClient, HttpHeaders} from '@angular/common/http';
import { Injectable } from '@angular/core';
import {environment} from '../../../environments/environment';
import {Constants} from '../../constants/constants';
import {createHscDraftMutationQuery} from '../../shared/graphql/umintakefunctions/umIntakeFuncQuery';
import {UserSessionService} from '../../shared/services/user-session/user-session.service';

@Injectable({
  providedIn: 'root'
})
export class UmintakefuncCreateDraftHscService{
  constructor(public  userSessionService: UserSessionService,public  http: HttpClient) {}

  getApiHeaders(): HttpHeaders {
    return new HttpHeaders()
      .set('Content-Type', 'application/json')
      .set('x-hasura-role', this.userSessionService.getUserHasuraRole(Constants.UM_INTAKE_UI_APP_NAME))
      .set('x-bpm-cli-org-id', this.userSessionService.getActiveClientOrg())
      .set('x-bpm-func-role',  this.userSessionService.getActiveUserRole())
      .set('Authorization', 'Bearer ' + this.userSessionService.getEcpToken());
  }

  createHscDraft(createHsc:any): Promise<any> {
    const createHscDraftMutation = {
      query: createHscDraftMutationQuery,
      variables: {
        createHsc
      }
    };
    return this.http.post(environment.UMINTAKEFUNC_SERVICE_API, JSON.stringify(createHscDraftMutation), { headers: this.getApiHeaders()}).toPromise();
  }
}
