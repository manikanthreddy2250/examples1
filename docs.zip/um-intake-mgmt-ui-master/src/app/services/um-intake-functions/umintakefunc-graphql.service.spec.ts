import {HttpClient, HttpHandler} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {TestBed} from '@angular/core/testing';
import {BehaviorSubject, of} from 'rxjs';
import {Constants} from '../../constants/constants';
import {UserSessionService} from 'src/app/shared/services/user-session/user-session.service';
import {UmIntakeFuncGraphqlService} from './umintakefunc-graphql.service';
import {StepperDataService} from '../stepper-data/stepper-data.service';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import {AuthLibraryModule} from '@ecp/auth-library';


@Injectable()
class UserSessionMockService {
  i = 0;
  getUserName() {
    if (this.i === 0) {
      this.i++;
      return 'breddy88';
    } else if (this.i === 1) {
      this.i = this.i + 2;
      return 'SYSTEM';
    } else if (this.i === 3)  {
      return 'abcd';
    }
  }
  getUserOrg() {
    return 'ecp';
  }
  getEcpToken() {}
 getUserHasuraRole() {}
  getActiveClientOrg() {}
  getActiveUserRole() {}
}
@Injectable()
class MockHttpClient {
  post(url: string, body: any | null, options?: any) {
     if (body.includes('submitHsc')) {
      return of({data: { submitHsc: { hsc_id : 15466, hsc_sts_ref_id: 19275}}});
    }
  }
}

@Injectable()
class MockStepperDataService {
  private stepperData = new BehaviorSubject({tenantId: 'ecpumintakebaseproductbpmgrp'}
    );
  sharedStepperData = this.stepperData.asObservable();

  constructor() { }

  setStepperData(stepperData: any) {
    this.stepperData.next(stepperData);
  }
}

describe('UmIntakeFuncGraphqlService', () => {
  let service: UmIntakeFuncGraphqlService;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, AuthLibraryModule],
      providers: [
        { provide: UserSessionService, useClass: UserSessionMockService }, { provide: StepperDataService, useClass: MockStepperDataService },  { provide: HttpClient, useClass: MockHttpClient }
      ]});
    service = TestBed.inject(UmIntakeFuncGraphqlService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should submit Hsc ', () => {
    const variables = {
      hsc_id: '15466',
      caseId: '6867868c-9325-11eb-8989-228a5ac1243a',
      variables: {
        currentStep: {},
        completedStep: {
          value: 9
        },
        completedStepIds: {
          value: [
            1,
            10,
            2,
            7,
            8,
            9
          ]
        },
        hsc: {
          value: {
            serviceType: 'Generic',
            caseType: 3738,
            requestCategory: 'Outpatient',
            facilityType: 'Home',
            clinicalInformationRecieved: 'Yes',
            admissionType: 'ADVNTF - Advance Notification',
            lineOfBusiness: '13 - CIP M&R',
            procedureCode: 'E0465',
            networkStatus: '1 - In Network',
            stateOfIssue: 'MN',
            priority: 'Routine',
            tatPeriodType: 'Notification to Decision',
            tatCategoryType: 'Decision',
            triggerTatPointType: 'Notification',
            notificationDate: new Date(),
            hsc_key_val: '6867868c-9325-11eb-8989-228a5ac1243a',
            hsc_id: '15466',
            orgId: 'ecp'
          }
        }
      }
    };
    expectAsync(service.submitHsc(variables)).toBeResolved()
  });

});
