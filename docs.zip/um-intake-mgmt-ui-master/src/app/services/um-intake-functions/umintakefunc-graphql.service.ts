import {HttpClient, HttpHeaders} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import {Constants} from '../../constants/constants';
import {StepperDataService} from '../stepper-data/stepper-data.service';
import {UserSessionService} from '../../shared/services/user-session/user-session.service';
import {submitHscMutation} from '../../shared/graphql/umintakefunctions/umIntakeFuncQuery';
import {Subscription} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
@Injectable({
  providedIn: 'root'
})
export class UmIntakeFuncGraphqlService{
  stepperData: any;
  stepperDataSubscription: Subscription;
  constructor(public userSessionService: UserSessionService, public stepperDataService: StepperDataService, public http: HttpClient) {
    this.stepperDataSubscription = this.stepperDataService.sharedStepperData.subscribe((stepperData) => {
      this.stepperData = stepperData;
    });
  }

  getApiHeaders(): HttpHeaders {
    return new HttpHeaders()
      .set('Content-Type', 'application/json')
      .set('x-hasura-role', this.userSessionService.getUserHasuraRole(Constants.UM_INTAKE_UI_APP_NAME))
      .set('x-bpm-tenant-id', this.stepperData.tenantId)
      .set('x-bpm-cli-org-id', this.userSessionService.getActiveClientOrg())
      .set('x-bpm-func-role',  this.userSessionService.getActiveUserRole())
      .set('Authorization', 'Bearer ' + this.userSessionService.getEcpToken());
  }



  submitHsc(submitHsc): Promise<any> {
    const submitHscMutationQuery = {
      query: submitHscMutation,
      variables: { submitHsc }
    };
    return this.http.post(environment.UMINTAKEFUNC_SERVICE_API, JSON.stringify(submitHscMutationQuery), { headers: this.getApiHeaders()}).toPromise();
  }

}
