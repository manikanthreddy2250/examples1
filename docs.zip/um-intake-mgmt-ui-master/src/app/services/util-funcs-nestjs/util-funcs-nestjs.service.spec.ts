import { TestBed } from '@angular/core/testing';

import { UtilFuncsNestjsService } from './util-funcs-nestjs.service';
import { Injectable } from '@angular/core';
import { of } from 'rxjs';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import {AuthLibraryModule} from '@ecp/auth-library';
import {HttpClient, HttpHandler} from '@angular/common/http';

@Injectable()
class MockHttpClient {
  post(url: string, body: any | null, options?: any) {
    switch (url) {
      case 'https://dev-ecp-api.optum.com/util-funcs-nestjs/api/graphql':
        return of({
          data: {
            updateHsc: {
              hsc: [
                {
                  hsc_id: 19368,
                  hsc_facls: [
                    {
                      plsrv_ref_id: 3743,
                      expt_admis_dt: '2021-03-02',
                      expt_dschrg_dt: '2021-03-04',
                    },
                  ],
                },
              ],
            },
          },
        });
      default:
        return of({});
    }
  }
}

describe('UtilFuncsNestjsService', () => {
  let service: UtilFuncsNestjsService;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, AuthLibraryModule],
      providers: [ { provide: HttpClient, useClass: MockHttpClient }]
    });
    service = TestBed.inject(UtilFuncsNestjsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should save casetype data', () => {
    const updateHscRequest = {
        hsc_id: 19368,
        srvc_set_ref_id: 3737,
        rev_prr_ref_id: 3754,
        hsc_facl: {
          plsrv_ref_id: 3743,
          srvc_desc_ref_id: 4347,
          srvc_dtl_ref_id: 4296,
          actul_admis_dttm: null,
          actul_dschrg_dttm: null,
          expt_admis_dt: '2021-12-12',
          expt_dschrg_dt: '2021-13-14',
        },
    };
    service.updateHsc(updateHscRequest);
    expect(service.updateHsc(updateHscRequest)).toBeTruthy();
  });
});
