import { Constants } from '../../constants/constants';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { UserSessionService } from '../../shared/services/user-session/user-session.service';
import { Injectable } from '@angular/core';
import { updateHscMutation, getHscDetailsQuery, duplicateCheckQuery } from '../../shared/graphql/utilizationfunctionsnestJs/utilizationfuncnestJsQuery';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root',
})
export class UtilFuncsNestjsService {
  constructor(
    public userSessionService: UserSessionService,
    public http: HttpClient
  ) { }

  getApiHeaders(): HttpHeaders {
    return new HttpHeaders()
      .set('Content-Type', 'application/json')
      .set('x-hasura-role', this.userSessionService.getUserHasuraRole(Constants.UM_INTAKE_UI_APP_NAME))
      .set('x-bpm-cli-org-id', this.userSessionService.getActiveClientOrg())
      .set('x-bpm-func-role', this.userSessionService.getActiveUserRole())
      .set('Authorization', 'Bearer ' + this.userSessionService.getEcpToken());
   }

  updateHsc(updateHscRequest: any): Promise<any> {
    const updateHscReqObj = {
      query: updateHscMutation,
      variables: {
        updateHscRequest,
      },
    };
    return this.http.post(
      environment.UTILIZATION_MGMNT_FUNCS_URL, JSON.stringify(updateHscReqObj),
      { headers: this.getApiHeaders() }
    ).toPromise();
  }
  getHscDetails(hscID: any): Promise<any> {
    const getHscDetailsMutation = {
      query: getHscDetailsQuery,
      variables: {
        getHscAuthRequest: {
          hsc: {
            hsc_id: hscID
          }
        }
      },
    };

    return this.http.post(
      environment.UTILIZATION_MGMNT_FUNCS_URL, JSON.stringify(getHscDetailsMutation),
      { headers: this.getApiHeaders() }
    ).toPromise();
  }
  duplicateCheck(hscID: any): Promise<any> {
    const duplicateCheckMutation = {
      query: duplicateCheckQuery,
      variables:
      {
        "duplicateCheckRequestInput": {
          "hsc": {
            "hsc_id": hscID
          }
        }
      }

      ,
    };
   
    return this.http.post(
      environment.UTILIZATION_MGMNT_FUNCS_URL, JSON.stringify(duplicateCheckMutation),
      { headers: this.getApiHeaders() }
    ).toPromise();
  }
}

