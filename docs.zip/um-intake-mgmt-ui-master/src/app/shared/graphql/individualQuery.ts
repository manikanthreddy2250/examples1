export const getMemberDetailsQuery = `
           query getCovDetails($indvkeyVal:  String){
              indv_key(where: {indv_key_val: {_eq: $indvkeyVal}}){
                        indv_id
                        indv_key_val
                        indv_key_typ_ref_id
                        orig_sys_cd
                        membership{
                            orig_sys_mbr_id
                            orig_sys_cd
                            mbr_covs{
                              pol_nbr
                              mbr_cov_id
                              cov_end_dt
                              cov_eff_dt
                              clm_pltfm_ref_id
                              prdct_ref_id
                              prdct_catgy_ref_cd {
                                ref_dspl
                              }
                              cov_typ_ref_cd{
                                ref_dspl
                              }
                            }
                         }
                }
            }
           `;