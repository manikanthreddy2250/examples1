export const createHscDraftMutationQuery = `
           mutation createDraftAuth($createHsc : DraftAuthRequest! ){
             createDraftAuth(draftAuthRequest : $createHsc){
                                                       hscId
                                                       caseId
                                                       tenantId
                                                       isMbrBlocked
                }
             }
           `;

export const submitHscMutation = `
          mutation submitHsc($submitHsc : SubmitHscRequest! ){
        submitHsc(submitHscRequest : $submitHsc){
          hsc_id
          hsc_sts_ref_id
        }
      }
           `;
