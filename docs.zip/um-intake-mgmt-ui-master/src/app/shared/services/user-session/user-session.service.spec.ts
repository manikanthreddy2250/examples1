import {HttpClient, HttpHandler} from '@angular/common/http';
import {CUSTOM_ELEMENTS_SCHEMA, Injectable, NO_ERRORS_SCHEMA } from '@angular/core';
import {async, TestBed } from '@angular/core/testing';
import {MicroProductAuthService, AuthService, AuthLibraryModule} from '@ecp/auth-library';
import {of} from 'rxjs/internal/observable/of';
import { UserSessionService } from './user-session.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('UserSessionService', () => {
  let service: UserSessionService;
  let authService: AuthService;
  let microProductAuth: MicroProductAuthService;



  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [AuthLibraryModule, HttpClientTestingModule],
      providers: [ UserSessionService],
    }).compileComponents();
    authService = TestBed.inject(AuthService);
    microProductAuth = TestBed.inject(MicroProductAuthService);
    service = TestBed.inject(UserSessionService);
  }));

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should call getUserHasuraRole', () => {
    spyOn(authService, 'getActiveLoginClientRole').and.returnValue(['ecp','sys_admin']);
    
    spyOn(microProductAuth, 'getHasuraRole').and.returnValue('hasura');
    const role = service.getUserHasuraRole('case-wf');
    expect(role).toBeDefined();
  });

  it('should call getActiveUserRole', () => {
    const spy = spyOn(microProductAuth, 'getAltUserID').and.returnValue('testid');
    spyOn(authService, 'getActiveLoginClientRole').and.returnValue(['ecp','sys_admin']);
    spyOn(microProductAuth, 'getHasuraRole').and.returnValue('hasura');
    spyOn(microProductAuth, 'getUserID').and.returnValue('001373415');
    const role = service.getActiveUserRole();
    expect(service.getActiveUserRole).toBeDefined();
  });

  it('should call getActiveClientOrg', () => {
    const spy = spyOn(microProductAuth, 'getAltUserID').and.returnValue('testid');
    spyOn(authService, 'getActiveLoginClientRole').and.returnValue(['ecp','sys_admin']);
    spyOn(microProductAuth, 'getHasuraRole').and.returnValue('hasura');
    spyOn(microProductAuth, 'getUserID').and.returnValue('001373415');
    const role = service.getActiveClientOrg();
    expect(role).toEqual('ecp');
  });

  it('should call getUserID', () => {
    const spy = spyOn(microProductAuth, 'getAltUserID').and.returnValue('testid');
    spyOn(authService, 'getActiveLoginClientRole').and.returnValue(['ecp','sys_admin']);
    spyOn(microProductAuth, 'getHasuraRole').and.returnValue('hasura');
    spyOn(microProductAuth, 'getUserID').and.returnValue('001373415');
    const id = service.getUserName();
    expect(service.getUserName).toBeDefined();
  });


});
