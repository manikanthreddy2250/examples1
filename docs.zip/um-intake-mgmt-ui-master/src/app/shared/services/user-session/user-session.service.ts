import { Injectable } from '@angular/core';
import { AuthService, MicroProductAuthService } from '@ecp/auth-library';
import { HttpHeaders } from '@angular/common/http';
import { Constants } from 'src/app/constants/constants';

@Injectable({
  providedIn: 'root'
})
export class UserSessionService {
  constructor(private readonly authService: AuthService,
              private readonly microProductAuthService: MicroProductAuthService) {
  }

  public getUserHasuraRole(product: string) {
    const [org, role] = this.authService.getActiveLoginClientRole();
    const hasuraRole = this.microProductAuthService.getHasuraRole(org || '', role || '', product) || null;
    return hasuraRole;
  }

  public getActiveUserRole() {
    const [org, role] = this.authService.getActiveLoginClientRole();
    return role;
  }

  public getActiveClientOrg() {
    const [org, role] = this.authService.getActiveLoginClientRole();
    return org;
  }

  getEcpToken() {
    return this.microProductAuthService.getEcpToken();
  }

  getUserName() {
    return this.microProductAuthService.getUserID();
  }

  getApiHeaders(): HttpHeaders {
    return new HttpHeaders()
      .set('Content-Type', 'application/json')
      .set('x-hasura-role', this.getUserHasuraRole(Constants.UM_INTAKE_UI_APP_NAME))
      .set('x-bpm-cli-org-id', this.getActiveClientOrg())
      .set('x-bpm-func-role', this.getActiveUserRole())
      .set('Authorization', 'Bearer ' + this.getEcpToken());
  }
}
