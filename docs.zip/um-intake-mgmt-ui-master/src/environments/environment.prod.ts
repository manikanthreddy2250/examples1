import env from './.env';

export const environment = {
  production: true,
  hmr: false,
  version: env.npm_package_version,
  envID: '${ENVIRONMENT_ID}',
  UMINTAKEFUNC_SERVICE_API: '${UMINTAKEFUNC_SERVICE_API}',
  INDIVIDUAL_DOMAIN_URL: '${INDIVIDUAL_DOMAIN_URL}',
  UTILIZATION_MGMNT_FUNCS_URL: '${UTILIZATION_MGMNT_FUNCS_URL}'
};
