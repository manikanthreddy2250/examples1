package atdd.common;

import java.util.Map;

public class CompareReport<T, V> {

    public enum Status {MISSING, EQUAL, NOT_EQUAL, IGNORE, UNPREDICTABLE}

    public static String toString(Map<String, CompareReport> reportMap) {
        StringBuilder sb = new StringBuilder();
        for (String key : reportMap.keySet()) {
            sb.append(reportMap.get(key).toString());
            sb.append("\r\n");
        }
        return sb.toString();
    }

    public static void append(Map<String, String> map, Map<String, CompareReport> reports, String prefix) {
        for (String key : map.keySet()) {
            if (key.startsWith(prefix)) {
                map.put(key, Status.IGNORE.name());
            }
        }
        for (String table_column : reports.keySet()) {
            CompareReport r = reports.get(table_column);
            String key = prefix + table_column;
                map.put(key, r.getStatus().toString() + "\t" + r.getExpectedValue() + "\t" + r.getActualValue());
        }
    }

    private T key;
    private V expectedValue;
    private V actualValue;

    private T getKey() {
        return this.key;
    }

    private V getExpectedValue() {
        return this.expectedValue;
    }

    private V getActualValue() {
        return this.actualValue;
    }

    public void setKey(T key) {
        this.key = key;
    }

    public void setExpectedValue(V expectedValue) {
        this.expectedValue = expectedValue;
    }

    public void setActualValue(V actualValue) {
        this.actualValue = actualValue;
    }

    public Status getStatus() {
        if (null == actualValue) {
            return Status.MISSING;
        } else if (expectedValue.equals(actualValue)) {
            return Status.EQUAL;
        } else {
            return Status.NOT_EQUAL;
        }
    }

    @Override
    public String toString() {
        return "| " + key + " | " + getStatus() + " | " + expectedValue + " | " + actualValue + " |";
    }
}
