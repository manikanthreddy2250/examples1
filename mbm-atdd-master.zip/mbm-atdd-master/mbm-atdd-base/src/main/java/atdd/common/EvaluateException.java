package atdd.common;

public class EvaluateException extends Throwable {
    public EvaluateException(String s) {
        super(s);
    }
    public EvaluateException(Throwable e) {
        super(e);
    }
}
