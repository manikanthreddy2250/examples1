package atdd.common;

public interface ICondition {

    final ICondition ALWAYS_TRUE = new ICondition() {
        @Override
        public boolean evaluate() throws Exception {
            return true;
        }
    };

    boolean evaluate() throws Exception;
}
