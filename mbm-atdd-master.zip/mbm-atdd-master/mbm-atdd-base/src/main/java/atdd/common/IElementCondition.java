package atdd.common;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public interface IElementCondition {
    public static IElementCondition ALWAYS_TRUE = new IElementCondition(){
        @Override
        public boolean evaluate(WebDriver webDriver, WebElement element) {
            return true;
        }
    };

    boolean evaluate(WebDriver webDriver, WebElement element);
}
