package atdd.common;

public abstract class IORunnable<I, O> implements Runnable {
    protected I input = null;
    protected O output = null;

    public IORunnable(I input) {
        this.input = input;
    }

    public I getIutput() {
        return this.input;
    }

    public O getOutput() {
        return this.output;
    }
}