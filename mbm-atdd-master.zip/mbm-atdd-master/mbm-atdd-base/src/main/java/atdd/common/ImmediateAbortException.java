package atdd.common;

public class ImmediateAbortException extends RuntimeException {
    public ImmediateAbortException(String msg) {
        super(msg);
    }
}
