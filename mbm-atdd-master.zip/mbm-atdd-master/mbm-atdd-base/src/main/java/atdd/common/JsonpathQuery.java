package atdd.common;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import org.apache.log4j.Logger;

/**
 * QueryBase implementation to support jsonpath query
 */
public class JsonpathQuery extends QueryBase {

    public static final Logger log = Logger.getLogger(JsonpathQuery.class.getName());

    private String body = null;
    private DocumentContext dc = null;

    /**
     * Constructor using a valid json string
     *
     * @param body
     */
    public JsonpathQuery(String body) {
        this.body = body;
        this.dc = JsonPath.parse(body);
        log.warn(body);
    }

    /**
     * Query by jsonpath
     *
     * @param jsonpath
     * @return
     */
    @Override
    public String query(String jsonpath) {
        try {
            return this.dc.read(jsonpath.replace(",", "\\,")).toString();
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Cast as one line json string
     *
     * @return
     */
    @Override
    public String toString() {
        return this.body;
    }

}