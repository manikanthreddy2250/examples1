package atdd.common;

import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/**
 * Compare two maps with same key type T and value type V
 *
 * @param <T>
 * @param <V>
 */
public class MapComparer<T, V> {
    private final Map<T, V> left;
    private final Map<T, V> right;

    /**
     * Constructor usage: provide a left map and a right map to compare
     * Accept optional filters (regex expressions)
     *
     * @param left
     * @param right
     * @param keyFiltersInclude
     */
    public MapComparer(Map<T, V> left, Map<T, V> right, String[] keyFiltersInclude) {
        this.left = left;
        this.right = right;

        this.applyFilters(this.left, keyFiltersInclude);
        this.applyFilters(this.right, keyFiltersInclude);

    }

    private void applyFilters(Map<T, V> map, String[] keyFiltersInclude) {
        if (null == keyFiltersInclude || keyFiltersInclude.length <= 0) {
            return;
        }

        Set<T> keysToBeRemoved = new HashSet<T>();
        for (T key : map.keySet()) {
            boolean matches = false;
            for (String filter : keyFiltersInclude) {
                if (key.toString().matches(filter)) {
                    matches = true;
                }
            }
            if (!matches) {
                keysToBeRemoved.add(key);
            }
        }
        for (T key : keysToBeRemoved) {
            map.remove(key);
        }
    }

    /**
     * Provide a compare result based on the left map
     *
     * @return
     */
    public Map<T, CompareReport<T, V>> bareLeft() {
        Map<T, CompareReport<T, V>> reportList = new LinkedHashMap<>(this.left.size());
        for (T key : this.left.keySet()) {
            CompareReport<T, V> report = new CompareReport<T, V>();
            report.setKey(key);
            report.setExpectedValue(this.left.get(key));
            report.setActualValue(this.right.get(key));
            reportList.put(key, report);
        }
        return reportList;
    }

    /**
     * Provide a compare result based on the right map
     *
     * @return
     */
    public Map<T, CompareReport<T, V>> bareRight() {
        Map<T, CompareReport<T, V>> reportList = new LinkedHashMap<>(this.left.size());
        for (T key : this.right.keySet()) {
            CompareReport<T, V> report = new CompareReport<T, V>();
            report.setKey(key);
            report.setExpectedValue(this.right.get(key));
            report.setActualValue(this.left.get(key));
            reportList.put(key, report);
        }
        return reportList;
    }
}
