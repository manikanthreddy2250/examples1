package atdd.common;

import atdd.utils.DataTableUtils;
import atdd.utils.StringUtils;
import atdd.utils.WhiteBoard;
import org.junit.Assert;

import java.util.*;

public class MapsComparer {

    private final List<Map<String, String>> mapsExpected;
    private final List<Map<String, String>> mapsActual;
    private final ScenarioLogger scenarioLogger;
    private List<String> ignoredKeys = new ArrayList<>(0);

    public MapsComparer(List<Map<String, String>> mapsExpected, List<Map<String, String>> mapsActual, ScenarioLogger scenarioLogger) {
        this.mapsExpected = mapsExpected;
        this.mapsActual = mapsActual;
        this.scenarioLogger = scenarioLogger;
    }

    public void setIgnoredKeys(String... keys) {
        ignoredKeys = Arrays.asList(keys);
    }

    public void assertMatches() {
        assertMatches(true, null);
    }

    public void assertMatches(boolean strict) {
        assertMatches(strict, null);
    }

    public void assertMatches(boolean strict, Map<Integer, Integer> mapping) {
        if (strict) {
            Assert.assertEquals("Number of rows mismatch.", mapsExpected.size(), mapsActual.size());
        } else {
            Assert.assertTrue("Too few actual rows.", mapsExpected.size() <= mapsActual.size());
        }

        if (null == mapping) {
            mapping = new LinkedHashMap<>(mapsExpected.size());
            for (int i = 0; i < mapsExpected.size(); i++) {
                mapping.put(i + 1, i + 1);
            }
        }

        for (int rowExpected : mapping.keySet()) {
            int rowActual = mapping.get(rowExpected);

            Map<String, String> mapExpected = new LinkedHashMap<>(mapsExpected.get(rowExpected - 1));
            Map<String, String> mapActual = new LinkedHashMap<>(mapsActual.get(rowActual - 1));
            assertMatches(strict, mapExpected, mapActual, ignoredKeys);
        }
    }

    public void assertMatches(boolean strict, String anchorKey, Map<String, String> mapping) {
        Map<String, Map<String, String>> indexedMapsExpected = DataTableUtils.dataTableAsMapsIndexedByKeyHeader(anchorKey, mapsExpected);
        Map<String, Map<String, String>> indexedMapsActual = DataTableUtils.dataTableAsMapsIndexedByKeyHeader(anchorKey, mapsActual);
        Set<String> keysExpected = indexedMapsExpected.keySet();
        Set<String> keysActual = indexedMapsActual.keySet();

        if (strict) {
            Assert.assertEquals("Keys mismatch.", keysExpected, keysActual);
        } else {
            Assert.assertTrue("Too few actual keys.", keysExpected.size() <= keysActual.size());
        }

        if (null == mapping) {
            mapping = new LinkedHashMap<>(keysExpected.size());
            for (String key : keysExpected) {
                mapping.put(key, key);
            }
        }

        int row = 1;
        for (String keyExpected : mapping.keySet()) {
            scenarioLogger.warn("\r\n>>>>>Comparing Row " + (row++));
            String keyActual = mapping.get(keyExpected);

            Map<String, String> mapExpected = new LinkedHashMap<>(indexedMapsExpected.get(keyExpected));
            Map<String, String> mapActual = new LinkedHashMap<>(indexedMapsActual.get(keyActual));
            List<String> ignoredKeyList = new ArrayList<>(this.ignoredKeys);
            ignoredKeyList.add(anchorKey);
            assertMatches(strict, mapExpected, mapActual, ignoredKeyList);
        }

    }

    private void assertMatches(boolean strict, Map<String, String> mapExpected, Map<String, String> mapActual, List<String> ignoredKeyList) {
        for (String ignoredKey : ignoredKeyList) {
            mapExpected.remove(ignoredKey.trim());
            mapActual.remove(ignoredKey.trim());
        }
        scenarioLogger.warn("Row Expected: " + mapExpected.toString());
        scenarioLogger.warn("Row Actual: " + mapActual.toString());


        List<String> expectedHeaders = new ArrayList<String>(mapExpected.keySet());
        List<String> actualHeaders = new ArrayList<String>(mapActual.keySet());
        scenarioLogger.warn("Headers Expected: " + expectedHeaders.toString());
        scenarioLogger.warn("Headers Actual: " + actualHeaders.toString());
        if (strict) {
            Assert.assertEquals("Headers mismatch.", expectedHeaders, actualHeaders);
        } else {
            Assert.assertTrue("Headers Actual is missing some values in Headers Expected", actualHeaders.containsAll(expectedHeaders));
        }

        for (String key : mapExpected.keySet()) {
            String valueActual0 = mapActual.get(key);
            String valueExpected0 = mapExpected.get(key);
            WhiteBoard.getInstance().putString(owner(), "actual", valueActual0);

            String valueActual1 = WhiteBoard.resolve(owner(), valueActual0);
            String valueExpected1 = WhiteBoard.resolve(owner(), valueExpected0);

            String valueActual2 = StringUtils.isEmpty(valueActual1) ? "" : valueActual1;
            String valueExpected2 = StringUtils.isEmpty(valueExpected1) ? "" : valueExpected1;

            scenarioLogger.warn("\r\nComparing Column " + key + ":");
            scenarioLogger.warn("\tExpected: " + valueExpected2 + (valueExpected2.equals(valueExpected0) ? "" : ("<<" + valueExpected0)));
            scenarioLogger.warn("\tActual: " + valueActual2 + (valueActual2.equals(valueActual0) ? "" : ("<<" + valueActual0)));

            if (strict) {
                Assert.assertEquals("Values not equal", valueExpected2, valueActual2);
            } else {
                Assert.assertTrue("Values mismatch: Expected=[" + valueExpected2 + "] Actual=[" + valueActual2 + "]",
                        valueActual2.equals(valueExpected2) || valueActual2.replaceAll("\n", " ").matches(valueExpected2));
            }
            scenarioLogger.warn("OK\r\n");
        }
    }

    private String owner() {
        return scenarioLogger.getOwner();
    }
}
