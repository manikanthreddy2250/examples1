package atdd.common;

import atdd.utils.MyBatisUtils;

import java.util.HashMap;
import java.util.Map;

public abstract class QueryBase {

    private static Map<String, QueryBase> buffer = new HashMap<>();

    /**
     * Query method to be implemented by concrete classes.
     *
     * @param path
     * @return
     */
    public abstract Object query(String path);

    /**
     * Factory method to return a JsonpathQuery instance
     *
     * @param body
     * @return
     */
    public static QueryBase jsonpathSource(String body) {
        try {
            if (!buffer.containsKey(body)) {
                buffer.put(body, new JsonpathQuery(body));
            }
            return buffer.get(body);
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Factory method to return a text based QueryBase instance
     *
     * @param text0
     * @return
     */
    public static QueryBase textSource(String text0) {
        if (!buffer.containsKey(text0)) {
            buffer.put(text0, new QueryBase() {

                String text = null;
                String[] lines = null;

                {
                    this.text = null == text0 ? "" : text0;
                    this.lines = this.text.split(System.getProperty("line.separator"));
                }

                @Override
                public String query(String lineNum) {
                    return lines[Integer.parseInt(lineNum) - 1];
                }

                @Override
                public String toString() {
                    return this.text;
                }

            });
        }
        return buffer.get(text0);
    }

    public static QueryBase mybatisSource(String factoryClassName) {
        try {
            //do not hit buffer for db queries
            //- data source may change
            return new MyBatisQuery(MyBatisUtils.getSqlSessionFactory(factoryClassName));
        } catch (Exception e) {
            return null;
        }
    }

}