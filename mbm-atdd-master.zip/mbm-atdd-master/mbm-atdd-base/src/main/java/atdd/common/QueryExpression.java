package atdd.common;

public class QueryExpression {
    private String type;
    private String query;

    /**
     * Constructor using a string.
     * Supported format:
     *  line 1
     *  jsonpath $.[?(@.workQueueId=='1')].status
     *
     * @param queryExpression
     */
    public QueryExpression(String queryExpression) {
        String[] p = queryExpression.trim().split("\\s+", 2);
        this.type = p[0];
        this.query = p[1];
    }

    /**
     * According to the query type, generate a QueryBase instance for the source string
     *
     * @param source
     * @return
     */
    public QueryBase compile(String source) {
        switch (this.type) {
            case "line":
                return QueryBase.textSource(source);
            case "jsonpath":
                return QueryBase.jsonpathSource(source);
            case "mybatis":
                return QueryBase.mybatisSource(source);
            default:
                throw new RuntimeException("Unsupported query type: " + type);
        }
    }

    /**
     * Getter for type
     *
     * @return
     */
    public String getType() {
        return this.type;
    }

    /**
     * Getter for query
     *
     * @return
     */
    public String getQuery() {
        return this.query;
    }
}
