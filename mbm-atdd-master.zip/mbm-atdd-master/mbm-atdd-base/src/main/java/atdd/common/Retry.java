package atdd.common;

import org.apache.log4j.Logger;
import org.junit.Assert;

import java.util.Objects;

public abstract class Retry {
    private static Logger log = Logger.getLogger(Retry.class);

    private final String trace;

    protected Object outcomeCompleted = null;
    protected Object outcomeTimeout = null;

    private long timeoutInMillis = 60 * 1000; // timeout in millis, default to 1 minute
    private long sleepInMillis = 1 * 1000; // give it a break next call to tryOnce(), default to 1 second
    private long breakInMillis = 1 * 1000; // give it a break between tryOnce() and until(), default to 1 second
    private ICondition untilCondition = ICondition.ALWAYS_TRUE;

    public Retry(String trace) {
        Objects.requireNonNull(trace);
        this.trace = (null == trace ? "" : trace.trim()) + ">";
        log.warn(trace);
    }

    public Retry(String trace, ICondition untilCondition) {
        this(trace);
        Objects.requireNonNull(untilCondition);
        this.untilCondition = untilCondition;
    }

    public Retry(String trace, long timeoutInMillis, long sleepInMillis, long breakInMillis) {
        this(trace);

        if (timeoutInMillis >= 0) {
            this.timeoutInMillis = timeoutInMillis;
        }
        if (sleepInMillis >= 0) {
            this.sleepInMillis = sleepInMillis;
        }
        if (breakInMillis >= 0) {
            this.breakInMillis = breakInMillis;
        }
    }

    public Retry(String trace, long timeoutInMillis, long sleepInMillis, long breakInMillis, ICondition untilCondition) {
        this(trace, timeoutInMillis, sleepInMillis, breakInMillis);
        this.untilCondition = untilCondition;
    }

    abstract protected void tryOnce() throws Throwable;

    public boolean execute() {
        //early evaluation
        if (ICondition.ALWAYS_TRUE != untilCondition) {
            try {
                if (this.untilCondition.evaluate() && until()) {
                    return true;
                }
            } catch (Throwable e) {
                //do nothing
            }
        }
        long t0 = System.currentTimeMillis();
        long t1 = t0 + this.getTimeoutMillis();
        int retries = 0;
        while (System.currentTimeMillis() < t1) {
            try {
                log.debug(trace + "#" + retries + " Try once ...");
                this.tryOnce();
                log.debug(trace + "#" + retries + "... try once success.");
            } catch (AssertionError f) {
                log.warn(trace + "Unexpected error at tryOnce(): " + f.getMessage());
                Assert.fail();
            } catch (ImmediateAbortException e) {
                log.error(trace + "Immediate Abort at tryOnce(): " + e.getMessage());
                throw e;
            } catch (Exception e) {
                log.debug(trace + e.getMessage());
                log.debug(trace + "... try once fail.");
                try {
                    sleep(this.getSleepMillis());
                    log.debug(trace + "Calling recover...");
                    this.weakRecover(e);
                    log.debug(trace + "... recover success.");
                } catch (AssertionError f) {
                    log.warn(trace + "Unexpected error at weakRecover(): " + f.getMessage());
                    Assert.fail();
                } catch (ImmediateAbortException e1) {
                    log.error(trace + "Immediate Abort at weakRecover(): " + e.getMessage());
                    throw e1;
                } catch (Exception e1) {
                    log.debug(trace + e.getMessage());
                    log.debug(trace + "... recover fail.");
                }
                log.debug(trace + "Retry after recover success or fail.");
                continue;
            } catch (Throwable throwable) {
                throwable.printStackTrace();
            } finally {
                retries++;
            }
            try {
                log.debug(trace + "Take a break before revealing.");
                sleep(this.getBreakMillis());
                log.debug(trace + "Until check ...");
                boolean isUntil = this.untilCondition.evaluate() && until();
                if (isUntil) {
                    log.debug(trace + "... until check success");
                    return true;
                } else {
                    log.debug(trace + "... until check fail.");
                }
            } catch (AssertionError f) {
                log.warn(trace + "Unexpected error at until(): " + f.getMessage());
                Assert.fail();
            } catch (ImmediateAbortException e) {
                log.error(trace + "Immediate abort at until(): " + e.getMessage());
                throw e;
            } catch (Exception e) {
                log.debug(trace + e.getMessage());
                log.debug(trace + "... until check exception.");
            }
            log.debug(trace + "Wait a while and retry.");
            sleep(this.getSleepMillis());
        }

        // timeout exit
        this.timeout();
        log.warn(trace + "Timeout after retrying " + (retries + 1) + " time(s) in " + ((System.currentTimeMillis() - t0) / 1000) + " seconds.");
        return false;
    }

    public Object getOutcomeCompleted() {
        return this.outcomeCompleted;
    }

    public void setOutcomeCompleted(Object o) {
        this.outcomeCompleted = o;
    }

    public Object getOutcomeTimeout() {
        return this.outcomeTimeout;
    }

    public void setOutcomeTimeout(Object o) {
        this.outcomeTimeout = o;
    }

    protected boolean until() throws Exception {
        // no until check by default
        log.debug(trace + "No implementation for until() method.");
        return true;
    }

    protected void weakRecover(Exception e) throws Exception {
        // do nothing by default
        // to be overridden
        log.debug(trace + "No implementation for weakRecover() method.");
    }

    protected long getBreakMillis() {
        return this.breakInMillis;
    }

    protected long getSleepMillis() {
        return this.sleepInMillis;
    }

    protected long getTimeoutMillis() {
        return this.timeoutInMillis;
    }

    protected void timeout() {
        // do nothing by default
        log.debug(trace + "No implementation for timeout() method.");
    }

    private void sleep(long millis) {
        if (millis <= 0) {
            return;
        }
        try {
            log.debug(trace + "Wait for " + (millis / 1000) + " seconds.");
            Thread.sleep(millis);
        } catch (Exception e) {
            // do nothing
        }
    }
}
