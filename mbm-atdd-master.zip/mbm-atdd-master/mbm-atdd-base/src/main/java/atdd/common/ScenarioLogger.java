package atdd.common;

import cucumber.api.Scenario;
import org.apache.log4j.Logger;

public class ScenarioLogger {

    private Scenario scenario = null;

    private Logger logger = null;

    public ScenarioLogger(Scenario scenario, Logger logger) {
        this.scenario = scenario;
        this.logger = logger;
    }

    public void warn(String message) {
        try {
            scenario.write(message + "\r\n");
            logger.warn(message);
        } catch (Exception e) {
            System.out.println(message);
        }
    }

    public void error(String message) {
        try {
            scenario.write(" ERROR: " + message + "\r\n");
            logger.error(message);
        } catch (Exception e) {
            System.out.println(message);
        }
    }

    public String getOwner() {
        try {
            return this.scenario.getId();
        } catch (Exception e) {
            return null;
        }
    }

    public Scenario getScenario() {
        return this.scenario;
    }
}
