package atdd.common;

public class WaitUntil extends Retry {

    public WaitUntil(String trace, ICondition untilCondition) {
        super(trace, untilCondition);
    }

    public WaitUntil(String trace, long timeoutInMillis, long sleepInMillis, long breakInMillis, ICondition untilCondition) {
        super(trace, timeoutInMillis, sleepInMillis, breakInMillis, untilCondition);
    }

    @Override
    final protected void tryOnce() throws Exception {
        // do nothing
    }
}
