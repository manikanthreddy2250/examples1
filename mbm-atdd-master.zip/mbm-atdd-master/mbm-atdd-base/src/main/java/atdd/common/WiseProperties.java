package atdd.common;

import atdd.utils.DateUtils;
import org.apache.log4j.Logger;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class WiseProperties extends Properties {

    public static final Logger log = Logger.getLogger(WiseProperties.class.getName());

    public static final String ENVSET = "envset";

    public static final String ENV = "env";

    public static final String RESERVED_YESTERDAY = "yesterday";
    public static final String RESERVED_TODAY = "today";
    public static final String RESERVED_TODAY_REVERSED = "today_reversed";
    public static final String RESERVED_TOMORROW = "tomorrow";

    public static final String[] RESERVED_KEYS = new String[]{ENVSET, ENV, RESERVED_YESTERDAY, RESERVED_TODAY, RESERVED_TODAY_REVERSED, RESERVED_TOMORROW};

    private String separator = ".";

    public WiseProperties() {
        super();
    }

    public WiseProperties(String separator) {
        super();
        this.separator = separator;
    }

    public WiseProperties(Properties defaults) {
        super(defaults);
    }

    @Override
    public synchronized Object get(Object key0) {
        log.debug(">>>>> get(" + key0 + ")");
        if (!(key0 instanceof String)) {
            log.debug("<<<<<0 get(" + key0 + ")=" + super.get(key0));
            return super.get(key0);
        }
        String key = key0.toString().trim();

        Object envsetObject = null;
        envsetObject = System.getProperty(ENVSET);
        log.debug("System.getProperty(ENVSET)=" + envsetObject);
        if (!isValid(envsetObject)) {
            envsetObject = System.getenv(ENVSET);
            log.debug("System.getenv(ENVSET)=" + envsetObject);
        }
        if (!isValid(envsetObject)) {
            envsetObject = super.get(ENVSET);
            log.debug("super.get(ENVSET)=" + envsetObject);
        }
        String envset = isValid(envsetObject) ? envsetObject.toString().trim() : "";
        String env = envset.isEmpty() ? "" : envset.split(separator, 2)[0];

        //reserved keys
        switch (key) {
            case ENV:
                return env;
            case ENVSET:
                return envset;
            case RESERVED_YESTERDAY:
                return DateUtils.mmDdYyyyYesterday();
            case RESERVED_TODAY:
                return DateUtils.mmDdYyyy();
            case RESERVED_TODAY_REVERSED:
                DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                Date date = new Date();
                return dateFormat.format(date);
            case RESERVED_TOMORROW:
                return DateUtils.mmDdYyyyTomorrow();
        }

        Object value = null;
        if (envset.isEmpty()) {
            value = System.getProperty(key);
            log.debug("System.getProperty(" + key + ")=" + value);
            if (!isValid(value)) {
                value = System.getenv(key);
                log.debug("System.getenv(" + key + ")=" + value);
            }
            if (!isValid(value)) {
                value = super.get(key);
                log.debug("super.get(" + key + ")=" + value);
            }
        } else {
            String keyWithEnvset = envset + this.separator + key;
            value = System.getProperty(keyWithEnvset);
            log.debug("System.getProperty(" + keyWithEnvset + ")=" + value);
            if (!isValid(value)) {
                value = System.getenv(keyWithEnvset);
                log.debug("System.getenv(" + keyWithEnvset + ")=" + value);
            }
            if (!isValid(value)) {
                value = super.get(keyWithEnvset);
                log.debug("super.get(" + keyWithEnvset + ")=" + value);
            }
            if (!isValid(value)) {
                value = System.getProperty(key);
                log.debug("System.getProperty(" + key + ")=" + value);
            }
            if (!isValid(value)) {
                value = System.getenv(key);
                log.debug("System.getenv(" + key + ")=" + value);
            }
            if (!isValid(value)) {
                value = super.get(key);
                log.debug("super.get(" + key + ")=" + value);
            }
        }
        log.debug("<<<<< get(" + key0 + ")=" + value);
        return value;
    }

    private boolean isValid(Object value) {
        if (null == value) {
            return false;
        }
        if (!(value instanceof String)) {
            return false;
        }
        String v = ((String) value).trim();
        return !v.isEmpty();
    }

    @Override
    public String getProperty(String key) {
        Object v = this.get(key);
        if (isValid(v)) {
            return (String) v;
        } else {
            return null;
        }
    }

    @Override
    public Set<String> stringPropertyNames() {
        Set<String> names0 = new HashSet<String>(super.stringPropertyNames());
        names0.addAll(System.getenv().keySet());
        names0.addAll(getSystemStringPropertyNames());
        Set<String> names1 = new HashSet<String>();
        String prefix = this.getProperty(ENVSET) + this.separator;
        int l = prefix.length();
        for (String name : names0) {
            if (name.startsWith(prefix)) {
                names1.add(name.substring(l));
            } else {
                names1.add(name);
            }
        }
        names1.addAll(Arrays.asList(RESERVED_KEYS));
        return names1;
    }

    @Override
    public String toString(){
        return "Content protected.";
    }

    private Set<String> getSystemStringPropertyNames() {
        Set<Object> all = System.getProperties().keySet();
        Set<String> result = new HashSet<String>(all.size());
        for (Object o : all) {
            if (null != o && o instanceof String) {
                result.add((String) o);
            }
        }
        return result;
    }

    public String getPropertyDeep(String key) {
        String value = this.getProperty(key);
        while(this.containsKey(value)){
            value = this.getProperty(value);
        }
        return value;
    }
}