package atdd.common.ui;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public abstract class Editable {
    protected final Logger log;

    protected final WebDriver webDriver;
    protected final WebElement element;

    public Editable(WebDriver webDriver, WebElement element) {
        log = Logger.getLogger(this.getClass());
        this.webDriver = webDriver;
        this.element = element;
    }

    public abstract boolean edit(String text);
}
