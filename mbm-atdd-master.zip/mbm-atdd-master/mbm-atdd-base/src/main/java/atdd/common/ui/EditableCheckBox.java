package atdd.common.ui;

import atdd.common.ICondition;
import atdd.utils.TestUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class EditableCheckBox extends Editable {
    public EditableCheckBox(WebDriver webDriver, WebElement element) {
        super(webDriver, element);
    }

    @Override
    public boolean edit(String text) {
        boolean targetIsChecked = "Yes".equalsIgnoreCase(text) || "true".equalsIgnoreCase(text);
        if (element.isSelected() && targetIsChecked || !element.isSelected() && !targetIsChecked) {
            return false;
        }
        if (targetIsChecked) {
            TestUtils.clickUntil(webDriver, element, new ICondition() {
                @Override
                public boolean evaluate() throws Exception {
                    return element.isSelected();
                }
            });
        } else {
            TestUtils.clickUntil(webDriver, element, new ICondition() {
                @Override
                public boolean evaluate() throws Exception {
                    return !element.isSelected();
                }
            });
        }
        return true;
    }
}
