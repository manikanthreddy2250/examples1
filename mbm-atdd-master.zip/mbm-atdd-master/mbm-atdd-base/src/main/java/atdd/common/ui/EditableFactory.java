package atdd.common.ui;

import atdd.common.IElementCondition;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

public class EditableFactory {
    public static final Logger log = Logger.getLogger(EditableFactory.class.getName());
    public static final IElementCondition EDITABLE = new IElementCondition() {
        @Override
        public boolean evaluate(WebDriver webDriver, WebElement element) {
            return null != EditableFactory.asEditable(webDriver, element);
        }
    };

    public static Editable asEditable(WebDriver d, WebElement el) {

        String tag = el.getTagName().toLowerCase();
        try {
            switch (tag) {
                case "input":
                    String type = el.getAttribute("type");
                    switch (type) {
                        case "checkbox":
                            return new EditableCheckBox(d, el);
                        default:
                            return new EditableInputBox(d, el);
                    }
                case "textarea":
                    return new EditableInputBox(d, el);
                case "select":
                    return new EditableSelect(d, el);
                case "ocm:typeahead":
                case "ocm-typeahead":
                    return new OcmTypeAheadElement(d, el);
                case "ocm:calendar":
                case "ocm-calendar":
                    return new OcmCalendar(d, el);
                case "uitk:select":
                case "uitk-select":
                    return new EditableUitkSelect(d, el);
                case "span":
                    String aClass = el.getAttribute("class");
                    if (aClass.contains("tk-multi-sel")) {
                        return new EditableTkMultiSel(d, el);
                    } else {
                        List<WebElement> els = el.findElements(By.xpath("./*"));
                        if (1 != els.size()) {
                            log.error("Unsupported span class: " + aClass);
                            return null;
                        } else {
                            return asEditable(d, els.get(0));
                        }
                    }
                default:
                    log.error("Unsupported tag: " + el.getTagName());
                    return null;
            }
        } catch (Exception e) {
            log.error(e.getMessage());
            log.error("Unknown element: " + el);
            return null;
        }
    }
}
