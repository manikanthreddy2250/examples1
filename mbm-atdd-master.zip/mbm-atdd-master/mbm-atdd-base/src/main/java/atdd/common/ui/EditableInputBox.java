package atdd.common.ui;

import atdd.common.Retry;
import atdd.utils.StringUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class EditableInputBox extends Editable {
    public EditableInputBox(WebDriver webDriver, WebElement element) {
        super(webDriver, element);
    }

    @Override
    public boolean edit(String text) {
        //clear
        element.clear();
        //input
        if (StringUtils.isEmpty(text)) {
            log.warn("Skip input because empty value is specified.");
            return false;
        } else {
            Retry retry = new Retry("Retry sendKeys.",
                    20 * 1000, 1000, 0) {
                @Override
                protected void tryOnce() throws Exception {
                    element.clear();
                    element.sendKeys(text);
                }

                @Override
                protected boolean until() throws Exception {
                    return text.equalsIgnoreCase(element.getAttribute("value"));
                }
            };

            return retry.execute();
        }
    }
}
