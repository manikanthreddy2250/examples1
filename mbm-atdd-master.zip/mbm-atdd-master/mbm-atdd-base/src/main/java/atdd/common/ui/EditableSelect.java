package atdd.common.ui;

import atdd.common.ImmediateAbortException;
import atdd.common.Retry;
import atdd.utils.StringUtils;
import atdd.utils.TestUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class EditableSelect extends Editable {
    public EditableSelect(WebDriver webDriver, WebElement element) {
        super(webDriver, element);
    }

    @Override
    public boolean edit(String text) {
        Select sel = TestUtils.asSelect(element);
        //clear
        if (sel.isMultiple()) {
            sel.deselectAll();
        } else {
            try {
                sel.selectByValue("");
            } catch (Exception e) {
                // do nothing
            }
        }
        //select
        if (StringUtils.isEmpty(text)) {
            log.warn("Skip select because empty value is specified.");
            return false;
        } else {
            boolean success = new Retry("Retry selecting.") {

                @Override
                protected void tryOnce() throws Exception {
                    try {
                        TestUtils.select(sel, text);
                    } catch (ImmediateAbortException e) {
                        // The error would be "No such option".
                        // But maybe the dropdown option is showing in a few seconds.
                        TestUtils.wait(3);
                        TestUtils.select(sel, text);
                    }
                }
            }.execute();

            return success;
        }
    }
}
