package atdd.common.ui;

import atdd.utils.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class EditableTkMultiSel extends Editable {
    public EditableTkMultiSel(WebDriver webDriver, WebElement element) {
        super(webDriver, element);
    }

    @Override
    public boolean edit(String text) {
        element.findElement(By.xpath(".//button[@role='listbox']|//button[contains(@class,'multiSelectButton')]")).click();
        element.findElement(By.xpath(".//button[.='None']")).click();
        try {
            if (StringUtils.isEmpty(text)) {
                return false;
            } else {
                if ("All".equals(text)) {
                    element.findElement(By.xpath(".//button[.='All']")).click();
                } else {
                    String[] labels = text.split(">");
                    for (String label : labels) {
                        element.findElement(By.xpath(".//span[.='" + label + "']")).click();
                    }
                }
                return true;
            }
        } catch (Exception e) {
            log.error("Unable to select: " + e.getMessage());
            return false;
        } finally {
            element.findElement(By.xpath(".//button[@role='listbox']|//button[contains(@class,'multiSelectButton')]")).click();
        }
    }
}
