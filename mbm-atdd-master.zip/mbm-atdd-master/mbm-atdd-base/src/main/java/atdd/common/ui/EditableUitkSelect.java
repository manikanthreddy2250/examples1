package atdd.common.ui;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class EditableUitkSelect extends Editable {
    public EditableUitkSelect(WebDriver webDriver, WebElement element) {
        super(webDriver, element);
    }

    @Override
    public boolean edit(String text) {
        return EditableFactory.asEditable(webDriver, element.findElement(By.xpath("./select"))).edit(text);
    }
}
