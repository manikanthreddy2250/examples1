package atdd.common.ui;

import atdd.common.ICondition;
import atdd.common.Retry;
import atdd.common.WaitUntil;
import atdd.utils.StringUtils;
import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

public class OcmTypeAheadElement extends Editable {
    public static final Logger log = Logger.getLogger(OcmTypeAheadElement.class.getName());

    public OcmTypeAheadElement(WebDriver webDriver, WebElement element) {
        super(webDriver, element);
    }

    @Override
    public boolean edit(String s) {

        WebElement input = element.findElement(By.xpath("./input"));

        boolean clearSuccess = new Retry("Retry clear type-ahead element " + element, 30 * 1000, 100, 100) {
            @Override
            protected void tryOnce() throws Exception {
                input.clear();
            }

            @Override
            protected boolean until() throws Exception {
                String s = TestUtils.simpleContent(input);
                return null == s || s.trim().isEmpty();
            }
        }.execute();

        if (!clearSuccess) {
            log.error("Cannot clear type-ahead element: " + element);
            return false;
        }

        //input and select
        if (StringUtils.isEmpty(s)) {
            log.warn("Skip input because empty value is specified.");
            return true;
        } else {
            final String text = s.trim();
            String xpathExactMatch = "./ul/li/a[.=\"" + text + "\"]";
            String xpathContains = "./ul/li/a[contains(., \"" + text + "\")]";

            WaitUntil waitDropdown = new WaitUntil(
                    "Wait for the option [" + text + "] in dropdown of typeahead: " + element,
                    15 * 1000, 100, 100,
                    new ICondition() {
                        @Override
                        public boolean evaluate() throws Exception {
                            List<WebElement> options = TestUtils.getSubElements(webDriver, element, xpathContains);
                            if (null == options || 0 == options.size()) {
                                return false;
                            } else {
                                log.warn("Dropdown listed: " + options);
                                return true;
                            }
                        }
                    }
            );

            Retry retry = new Retry("Retry input [" + s + "] in typeahead: " + element, 45 * 1000, 1000, 1000) {

                private boolean clickSuccess = false;

                @Override
                protected void tryOnce() throws Exception {
                    clickSuccess = false;
                    input.clear();
                    input.sendKeys(text);
                    TestUtils.waitForAngularRequestsToFinish(webDriver);
                    if (waitDropdown.execute()) {
                        List<WebElement> options = TestUtils.getSubElements(webDriver, element, xpathExactMatch);
                        if (null == options || options.size() <= 0) {
                            options = TestUtils.getSubElements(webDriver, element, xpathContains);
                        }
                        if (null == options || options.size() <= 0) {
                            log.warn("Dropdown disappeared.");
                            return;
                        }
                        options.get(0).click();
                        TestUtils.waitForAngularRequestsToFinish(webDriver);
                        clickSuccess = true;
                    } else {
                        throw new RuntimeException("No dropdown listed.");
                    }
                }

                @Override
                protected boolean until() throws Exception {
                    return clickSuccess;
                }
            };
            return retry.execute();
        }
    }

}
