package atdd.common.ui;

import atdd.common.IElementCondition;
import atdd.utils.InvalidLocatorException;
import atdd.utils.PageObjectUtils;
import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.*;

public abstract class SlowBy {

    public static final Logger log = Logger.getLogger(SlowBy.class.getName());

    private static Map<String, SlowBy> namedSlowBy = new LinkedHashMap<>();

    public static final String FINDER_ID = "id";

    public static final String FINDER_NAME = "name";

    public static final String FINDER_TEXT = "text";

    public static final String FINDER_CLASS = "class";

    public static final String FINDER_LINK_TEXT = "linkText";

    public static final String FINDER_PARTIAL_LINK_TEXT = "partialLinkText";

    public static final String FINDER_CSS_SELECTOR = "cssSelector";

    public static final String FINDER_VALUE = "value";

    public static final String FINDER_STYLE = "style";

    public static final String FINDER_XPATH = "xpath";

    public static final String FINDER_LABEL_FOR = "labelFor";

    public static final String FINDER_LABEL_FOR_REF_NM = "labelForRefNm";

    public static final String FINDER_LABEL_FOR_ID = "labelForId";

    public static final String FINDER_RIGHT_SIDE_TD = "rightSideTd";

    public static final String FINDER_DOWN_SIDE_TD = "downSideTd";

    static {
        namedSlowBy.put(FINDER_ID, new SlowBy() {
            @Override
            public By slowBy(WebDriver driver, String locatorString, String parentXpath) {
                By by = By.id(locatorString);
                if (TestUtils.isValidLocator(driver, by)) {
                    return by;
                } else {
                    return null;
                }
            }
        });
        namedSlowBy.put(FINDER_NAME, new SlowBy() {
            @Override
            public By slowBy(WebDriver driver, String locatorString, String parentXpath) {
                By by = By.name(locatorString);
                if (TestUtils.isValidLocator(driver, by)) {
                    return by;
                } else {
                    return null;
                }
            }
        });
        namedSlowBy.put(FINDER_VALUE, new SlowBy() {
            @Override
            public By slowBy(WebDriver driver, String locatorString, String parentXpath) {
                parentXpath = null == parentXpath ? "" : parentXpath.trim();
                By by = By.xpath(parentXpath + "//input[@value='" + locatorString + "']");
                if (TestUtils.isValidLocator(driver, by)) {
                    return by;
                } else {
                    return null;
                }
            }
        });
        namedSlowBy.put(FINDER_XPATH, new SlowBy() {
            @Override
            public By slowBy(WebDriver driver, String locatorString, String parentXpath) {
                parentXpath = null == parentXpath ? "" : parentXpath.trim();
                By by = By.xpath(parentXpath + locatorString);
                if (TestUtils.isValidLocator(driver, by)) {
                    return by;
                } else {
                    return null;
                }
            }
        });
        namedSlowBy.put(FINDER_TEXT, new SlowBy() {
            @Override
            public By slowBy(WebDriver driver, String locatorString, String parentXpath) {
                parentXpath = null == parentXpath ? "" : parentXpath.trim();
                By by = By.xpath(parentXpath + "//*[text()='" + locatorString + "']");
                if (TestUtils.isValidLocator(driver, by)) {
                    return by;
                } else {
                    return null;
                }
            }
        });
        namedSlowBy.put(FINDER_CLASS, new SlowBy() {
            @Override
            public By slowBy(WebDriver driver, String locatorString, String parentXpath) {
                parentXpath = null == parentXpath ? "" : parentXpath.trim();
                By by = By.xpath(parentXpath + "//*[contains(@class, '" + locatorString + "')]");
                if (TestUtils.isValidLocator(driver, by)) {
                    return by;
                } else {
                    return null;
                }
            }
        });
        namedSlowBy.put(FINDER_STYLE, new SlowBy() {
            @Override
            public By slowBy(WebDriver driver, String locatorString, String parentXpath) {
                parentXpath = null == parentXpath ? "" : parentXpath.trim();
                By by = By.xpath(parentXpath + "//*[contains(@style, '" + locatorString + "')]");
                if (TestUtils.isValidLocator(driver, by)) {
                    return by;
                } else {
                    return null;
                }
            }
        });
        namedSlowBy.put(FINDER_LINK_TEXT, new SlowBy() {
            @Override
            public By slowBy(WebDriver driver, String locatorString, String parentXpath) {
                By by = By.linkText(locatorString);
                if (TestUtils.isValidLocator(driver, by)) {
                    return by;
                } else {
                    return null;
                }
            }
        });
        namedSlowBy.put(FINDER_PARTIAL_LINK_TEXT, new SlowBy() {
            @Override
            public By slowBy(WebDriver driver, String locatorString, String parentXpath) {
                By by = By.partialLinkText(locatorString);
                if (TestUtils.isValidLocator(driver, by)) {
                    return by;
                } else {
                    return null;
                }
            }
        });
        namedSlowBy.put(FINDER_CSS_SELECTOR, new SlowBy() {
            @Override
            public By slowBy(WebDriver driver, String locatorString, String parentXpath) {
                By by = By.cssSelector(locatorString);
                if (TestUtils.isValidLocator(driver, by)) {
                    return by;
                } else {
                    return null;
                }
            }
        });
        namedSlowBy.put(FINDER_LABEL_FOR, new SlowBy() {
            @Override
            public By slowBy(WebDriver driver, String locatorString, String parentXpath) {
                parentXpath = null == parentXpath ? "" : parentXpath.trim();
                By by = By.xpath("(//*[@ref-nm=" + parentXpath + "//label[text()='" + locatorString + "']/@for])[1]");
                if (TestUtils.isValidLocator(driver, by)) {
                    return by;
                } else {
                    return null;
                }
            }
        });
        namedSlowBy.put(FINDER_LABEL_FOR_REF_NM, new SlowBy() {
            @Override
            public By slowBy(WebDriver driver, String locatorString, String parentXpath) {
                parentXpath = null == parentXpath ? "" : parentXpath.trim();
                String xpathLabelForId = "//*[@ref-nm=" + parentXpath + "//label[text()='" + locatorString + "']/@for]";
                By by = By.xpath(xpathLabelForId);
                if (TestUtils.isValidLocator(driver, by)) {
                    log.warn("Locator provided by ");
                    return by;
                } else {
                    return null;
                }
            }
        });
        namedSlowBy.put(FINDER_LABEL_FOR_ID, new SlowBy() {
            @Override
            public By slowBy(WebDriver driver, String locatorString, String parentXpath) {
                parentXpath = null == parentXpath ? "" : parentXpath.trim();
                String xpathLabelForId = "//*[@id=" + parentXpath + "//label[text()='" + locatorString + "']/@for]";
                By by = By.xpath(xpathLabelForId);
                if (TestUtils.isValidLocator(driver, by)) {
                    return by;
                } else {
                    return null;
                }
            }
        });
        namedSlowBy.put(FINDER_RIGHT_SIDE_TD, new SlowBy() {
            @Override
            public By slowBy(WebDriver driver, String locatorString, String parentXpath) {
                parentXpath = null == parentXpath ? "" : parentXpath.trim();
                String xpathTdRight = "(" + parentXpath + "//td[not(.//table) and contains(.,'" + locatorString + "')]/following-sibling::td[1]/*)[1]";
                By by = By.xpath(xpathTdRight);
                if (TestUtils.isValidLocator(driver, by)) {
                    return by;
                } else {
                    xpathTdRight += "//input";
                    by = By.xpath(xpathTdRight);
                    if (TestUtils.isValidLocator(driver, by)) {
                        return by;
                    }
                    return null;
                }
            }
        });
        namedSlowBy.put(FINDER_DOWN_SIDE_TD, new SlowBy() {
            @Override
            public By slowBy(WebDriver driver, String locatorString, String parentXpath) {
                parentXpath = null == parentXpath ? "" : parentXpath.trim();
                String xpathTdDown = getXpathTdDown(driver, parentXpath + "//td[not(.//table) and contains(.,'" + locatorString + "')]");
                if (null == xpathTdDown) {
                    xpathTdDown = getXpathTdDown(driver, parentXpath + "//td[not(.//table) and contains(text(),'" + locatorString + "')]");
                }
                By by = By.xpath("(" + xpathTdDown + "/*)[1]");
                if (TestUtils.isValidLocator(driver, by)) {
                    return by;
                } else {
                    return null;
                }
            }
        });
    }

    public static String findersPrefix(List<String> allFinderNames) {
        String prefix = "";
        for (int i = 0; i < allFinderNames.size(); i++) {
            String s = allFinderNames.get(i);
            prefix = prefix + s + ">>";
        }
        return prefix;
    }

    abstract public By slowBy(WebDriver driver, String locatorString, String parentXpath);

    private static String getXpathTdDown(WebDriver d, String xpathTd) {
        try {
            if (1 != TestUtils.countElementsByXpath(d, xpathTd)) {
                return null;
            }
            String xpathTr = xpathTd + "/ancestor-or-self::tr[1]";
            if (1 != TestUtils.countElementsByXpath(d, xpathTr)) {
                return null;
            }
            String xpathTrDown = xpathTr + "/following-sibling::tr[1]";
            if (1 != TestUtils.countElementsByXpath(d, xpathTrDown)) {
                return null;
            }

            String text = d.findElement(By.xpath(xpathTd)).getText();
            List<WebElement> tds = d.findElements(By.xpath(xpathTr + "/td"));
            int i = 1;
            for (WebElement td : tds) {
                if (td.getText().equals(text)) {
                    break;
                } else {
                    i++;
                }
            }

            String xpathTdDown = xpathTrDown + "/td[" + i + "]";

            return xpathTdDown;
        } catch (Exception e) {
            return null;
        }
    }

    private static final Set<String> ALL_FINDER_NAMES = namedSlowBy.keySet();

    public static final List<String> allFinderNames() {
        return new ArrayList<>(ALL_FINDER_NAMES);
    }

//    public static By by(WebDriver driver, String locatorString, PageObjectUtils pageObjectUtils, String parentXpath) {
//        //1. by specified iframe or previous content (default content or iframe)
//        By by = bySpecifiedIframeOrPreviousContent(driver, locatorString, pageObjectUtils, parentXpath);
//        if (null != by) {
//            return by;
//        }
//
//        if (!locatorString.startsWith("iframe:")) {
//
//            //2. by default content
//            driver.switchTo().defaultContent();
//            by = bySpecifiedIframeOrPreviousContent(driver, locatorString, pageObjectUtils, parentXpath);
//            if (null != by) {
//                return by;
//            }
//
//            //3. go through all iframe elements
//            List<WebElement> iframes = driver.findElements(By.tagName("iframe"));
//            if (null != iframes && iframes.size() > 0) {
//                for (WebElement iframe : iframes) {
//                    driver.switchTo().defaultContent();
//                    driver.switchTo().frame(iframe);
//                    by = bySpecifiedIframeOrPreviousContent(driver, locatorString, pageObjectUtils, parentXpath);
//                    if (null != by) {
//                        return by;
//                    }
//                }
//
//            }
//        }
//        return null;
//    }

    public static By by(WebDriver driver, String locatorString, PageObjectUtils pageObjectUtils, IElementCondition elementCondition, String parentXpath) {
        //1. by specified iframe or previous content (default content or iframe)
        By by = bySpecifiedIframeOrPreviousContent(driver, locatorString, pageObjectUtils, elementCondition, parentXpath);
        if (null != by) {
            return by;
        }

        if (!locatorString.startsWith("iframe:")) {

            //2. by default content
            driver.switchTo().defaultContent();
            by = bySpecifiedIframeOrPreviousContent(driver, locatorString, pageObjectUtils, elementCondition, parentXpath);
            if (null != by) {
                return by;
            }

            //3. go through all iframe elements
            List<WebElement> iframes = driver.findElements(By.tagName("iframe"));
            if (null != iframes && iframes.size() > 0) {
                for (WebElement iframe : iframes) {
                    driver.switchTo().defaultContent();
                    driver.switchTo().frame(iframe);
                    by = bySpecifiedIframeOrPreviousContent(driver, locatorString, pageObjectUtils, elementCondition, parentXpath);
                    if (null != by) {
                        return by;
                    }
                }

            }
        }
        return null;
    }

//    private static By bySpecifiedIframeOrPreviousContent(WebDriver driver, String locatorString, PageObjectUtils pageObjectUtils, String parentXpath) {
//        if (null != pageObjectUtils) {
//            try {
//                By by = pageObjectUtils.getLocator(locatorString);
//                if (TestUtils.isValidLocator(driver, by)) {
//                    return by;
//                }
//            } catch (InvalidLocatorException e) {
//                // do nothing
//            }
//            return null;
//        }
//
//        String[] p = locatorString.split(">>");
//        if (1 == p.length) {
//            for (String name : namedSlowBy.keySet()) {
//                By by = namedSlowBy.get(name).slowBy(driver, locatorString, parentXpath);
//                if (TestUtils.isValidLocator(driver, by)) {
//                    return by;
//                }
//            }
//            return null;
//        } else {
//            for (int i = 0; i < p.length - 1; i++) {
//                String name = p[i];
//                if (name.startsWith("iframe:")) {
//                    String iframeNameOrId = name.split(":", 2)[1];
//                    boolean success = switchToIframe(driver, iframeNameOrId);
//                    if (!success) {
//                        log.debug("No such iframe: " + iframeNameOrId);
//                        return null;
//                    }
//                } else {
//                    By by = namedSlowBy.get(name).slowBy(driver, p[p.length - 1], parentXpath);
//                    if (TestUtils.isValidLocator(driver, by)) {
//                        return by;
//                    }
//                }
//            }
//            return null;
//        }
//    }

    private static By bySpecifiedIframeOrPreviousContent(WebDriver driver, String locatorString, PageObjectUtils pageObjectUtils, IElementCondition elementCondition, String parentXpath) {
        if (null != pageObjectUtils) {
            try {
                By by = pageObjectUtils.getLocator(locatorString);
                if (TestUtils.isValidLocator(driver, by, elementCondition)) {
                    return by;
                }
            } catch (InvalidLocatorException e) {
                // do nothing
            }
            return null;
        }

        String[] p = locatorString.split(">>");
        if (1 == p.length) {
            for (String name : namedSlowBy.keySet()) {
                By by = namedSlowBy.get(name).slowBy(driver, locatorString, parentXpath);
                if (TestUtils.isValidLocator(driver, by, elementCondition)) {
                    return by;
                }
            }
            return null;
        } else {
            for (int i = 0; i < p.length - 1; i++) {
                String name = p[i];
                if (name.startsWith("iframe:")) {
                    String iframeNameOrId = name.split(":", 2)[1];
                    boolean success = switchToIframe(driver, iframeNameOrId);
                    if (!success) {
                        log.debug("No such iframe: " + iframeNameOrId);
                        return null;
                    }
                } else {
                    By by = namedSlowBy.get(name).slowBy(driver, p[p.length - 1], parentXpath);
                    if (TestUtils.isValidLocator(driver, by, elementCondition)) {
                        return by;
                    }
                }
            }
            return null;
        }
    }

    private static boolean switchToIframe(WebDriver driver, String iframeNameOrId) {
        try {
            driver.switchTo().defaultContent();
            if ("defaultContent".equals(iframeNameOrId)) {
                return true;
            } else {
                List<WebElement> iframes = driver.findElements(By.tagName("iframe"));
                for (WebElement iframe : iframes) {
                    if (iframeNameOrId.equals(iframe.getAttribute("name")) || iframeNameOrId.equals(iframe.getAttribute("id"))) {
                        driver.switchTo().frame(iframe);
                        return true;
                    }
                }
                return false;
            }
        } catch (Exception e) {
            return false;
        }
    }
}
