package atdd.test.core;

import atdd.common.ScenarioLogger;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

public class AbstractStepSet {

    protected final Logger logger;

    protected final ScenarioLogger scenarioLogger;

    private Scenario scenario;
    private WebDriver webDriver;
    private String owner;

    public AbstractStepSet(Scenario scenario, WebDriver webDriver) {
        this.logger = Logger.getLogger(this.getClass());
        this.scenarioLogger = new ScenarioLogger(scenario, logger);
        this.setScenario(scenario);
        this.setDriver(webDriver);
    }

    /**
     * Get the Scenario
     *
     * @return
     */
    public Scenario scenario() {
        TestUtils.immediateAbortCheck(scenario);
        return this.scenario;
    }

    /**
     * Get the Scenario
     *
     * @return
     */
    public void setScenario(Scenario scenario) {
        this.scenario = scenario;
        this.owner = scenario.getId();
    }

    /**
     * Get the WebDriver
     *
     * @return
     */
    public WebDriver driver() {
        TestUtils.immediateAbortCheck(scenario);
        return this.webDriver;
    }

    /**
     * Set the WebDriver
     *
     * @param webDriver
     */
    protected void setDriver(WebDriver webDriver) {
        TestUtils.immediateAbortCheck(scenario);
        this.webDriver = webDriver;
    }

    /**
     * Get the owner
     *
     * @return
     */
    public String getOwner() {
        TestUtils.immediateAbortCheck(scenario);
        return this.owner;
    }

}
