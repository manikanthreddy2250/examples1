package atdd.test.core;

import org.openqa.selenium.By;

/**
 * To be implemented by any searchable Page Objects.
 * A searchable page should be able to provide below information:
 * - Filter table xpath
 * - Result table xpath
 * - Search button locator
 * - Clear button locator
 * - Has pagination control or not
 *
 * TODO: resolve searchable pages that is not using filters in a table element
 * TODO: integrate with SearchCriteria class
 */
public interface ISearchable {

    String getFilterTableXpath();

    String getResultTableXpath();

    By getSearchButtonLocator();

    By getClearButtonLocator();

    boolean hasPagination();
}
