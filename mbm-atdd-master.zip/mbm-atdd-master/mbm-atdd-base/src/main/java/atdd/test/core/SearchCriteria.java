package atdd.test.core;

import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import java.util.Map;

public class SearchCriteria extends AbstractStepSet {
    private static Logger log = Logger.getLogger(SearchCriteria.class);

    public SearchCriteria(Scenario scenario, WebDriver webDriver) {
        super(scenario, webDriver);
    }

    /**
     * Fill in search criteria.
     * Can be applied to any search page as long as the criteria fields are organized in a table element.
     *
     * @param criteria
     * @param filterTableXpath
     */
    public void setCriteria(Map<String, String> criteria, String filterTableXpath) {

        TestUtils.inputAllByLabels(driver(), criteria, filterTableXpath);
    }

}
