package atdd.test.shared;

import atdd.utils.Conf;
import atdd.utils.Drivers;
import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

public class BaseCucumber {

    /**
     * @Deprecated To be removed. Use local method driver() for temporary solution.
     */
    @Deprecated
    public static WebDriver driver;

    /**
     * @Deprecated To be removed. Use local method obj() for temporary solution.
     */
    @Deprecated
    public static Globals gv;
    public static Logger log = Logger.getLogger("BaseCucumber");
    public static int pass = 0;
    public static int fail = 0;
    public static int run = 0;
    public static String failMethods = "";
    public static Properties Config = new Properties();

    /**
     * @Deprecated To be removed. Use TestUtils static methods for temporary solution.
     */
    @Deprecated
    public static TestUtils utils;

    //public static Globals gv;
    public static boolean demo;
    public static boolean localTest;

    public static void setUp() {

        System.out.println("Test #: " + run);

        String localFromConfig = Conf.getInstance().getProperty("localTest").trim();
        localTest = Boolean.parseBoolean(localFromConfig);
        run++;
    }

    public static void printReport() {
        System.out.println("\nTesting is finished!");
        System.out.println("Tests runs:   \t" + run);
        System.out.println("Tests passed: \t" + pass);
        System.out.println("Tests failed: \t" + fail);
        if (fail != 0)
            System.out.println("Failed methods:\n" + failMethods);
    }

    /**
     * Getting driver by param
     *
     * @param dr
     */
    public static void setDriver(String dr) {
        dr = dr.toLowerCase();

        //Getting info about local test
//        String localFromConfig = Config.getProperty("localTest").trim();
//        boolean localTest = Boolean.parseBoolean(localFromConfig);
//        log.warn("Localtest flag is: " + localFromConfig);

        if (!localTest) {
            if (dr.equals("firefoxlocalmac") ||
                    dr.equals("firefoxlocal") ||
                    dr.equals("firefoxremote") ||
                    dr.equals("firefoxdocker") ||
                    dr.equals("chromedocker") ||
                    dr.equals("chromelocalmac") ||
                    dr.equals("chromelocal") ||
                    dr.equals("chromeremote") ||
                    dr.equals("ieremote") ||
                    dr.equals("safari") ||
                    dr.equals("internetexplorer")) {
                System.out.println("Browser: " + dr);

                driver = Drivers.getDriver(dr);
                driver.manage().deleteAllCookies();


            } else if (dr.toLowerCase().contains("jenkins")) {

                dr = System.getenv("Browser");
                log.warn("Jenkins Browser: " + dr);

                //Dev mistake case---------------
                if (dr == null) {
                    dr = Conf.getInstance().getProperty("browser");
                    log.error("CHECK CONFIG FILE!!! TAKING DRIVER FROM CONFIG. <<<<<<-----------------");
                }
                //-------------------------------

                driver = Drivers.getDriver(dr);
                driver.manage().deleteAllCookies();
            } else {
                log.error("Can't initialize Driver: " + dr);
                throw new RuntimeException("Can't initialize Driver: " + dr);
            }
        }
        //For local test. localTest = true
        else {
            dr = Conf.getInstance().getProperty("browser");
            log.warn("Driver LOCAL: " + dr);
            driver = Drivers.getDriver(dr);
            driver.manage().deleteAllCookies();
            //driver.manage().window().maximize();
        }

        //Initialize it after how Driver was defined
        utils = new TestUtils();
//        obj = new PageObject();

        //driver.manage().window().maximize();
        //obj.CommonPage.maximizeBrowser();

    }


    //-------------------------------------------------------------------------

    //private static final String className = getClass().getSimpleName();

    public static void failed() {
        //Saving HTML page source for debug
        TestUtils.wait(2);

        String name = "_Failed_" + getTimestamp().replace(" ", "_");

        TestUtils.safeHTMLsoureCode(driver, Conf.getOutputPath() + "FailHtmlSave/", name);

        String out;

        //Enter here anything that you need after test fail
        printHeader();

        out = "\n" + printFailureInfo();

        printHeader();
        fail++;
        //For cucumber jenkins report
        Assert.fail(out);
    }


    public static void succeeded() {
        System.out.println("\n\nTest succeeded!\n");
        printHeader();
        pass++;
    }

    private static String printFailureInfo() {

        String out;

        out = "Failure. Time:  " + getTimestamp();
        System.out.println("Failure. Time:  " + getTimestamp());

        //Getting text from Alert window
        try {
            Alert alert = driver.switchTo().alert();
            String AlertText = alert.getText();
            System.out.println("Alert text is: " + AlertText);
            out = out + "\nAlert text is: " + AlertText;
            alert.accept();
        } catch (Exception e) {
        }

        try {
            Capabilities caps = ((RemoteWebDriver) driver).getCapabilities();
            String browserName = caps.getBrowserName();
            String browserVersion = caps.getVersion();
            String os = caps.getPlatform().toString();

            System.out.println("OS: " + os);
            System.out.println("Browser: " + browserName + " " + browserVersion);
            out = out + "\nOS: " + os + "\nBrowser: " + browserName + " " + browserVersion;
        } catch (Exception e) {
            out = out + "\nRemoteWebDriver - cannot get OS or Browser version.";
            System.out.println("RemoteWebDriver - cannot get OS or Browser version.");
        }

        try {
            out = out + "\nCurrent URL: " + driver.getCurrentUrl() + "\nCookie info: " + getSessionInfoFromCookie(driver);
            System.out.println("Current URL: " + driver.getCurrentUrl());
            System.out.println("Cookie info: " + getSessionInfoFromCookie(driver));
        } catch (Exception e2) {
            out = out + "\nBrowser closed - cannot get URL or session data";
            System.out.println("Browser closed - cannot get URL or session data");
        }
        return out;
    }

    private static void printHeader() {
        System.out.println("**********************************************************************************************************");
    }


    private static String getTimestamp() {
        SimpleDateFormat formatter = new SimpleDateFormat("MMM-dd-yyyy HH:mm:ss");
        String string = formatter.format(new Date());
        return string;
    }

    public static String getSessionInfoFromCookie(WebDriver driver) {
        final String cookie = (String) ((JavascriptExecutor) driver).executeScript("return document.cookie;");
        return cookie;
    }

    /**
     * Close browser ignoring any exception
     *
     * @param driver
     */
    public static void closeBrowser(WebDriver driver) {
        if (!Conf.getInstance().isDemo()) {
            log.warn("Closing browser...");
            if (driver != null) {
                try {
                    driver.manage().deleteAllCookies();
                    driver.quit();
                } catch (Exception e) {
                    e.printStackTrace();
                    log.debug("Fail to close browser: " + e.getMessage());
                    //do nothing
                }
            } else {
                log.warn("No browser to be closed.");
            }
        }
    }

    /**
     * reset page objects in case the webDriver is reconnected or trying to manipulate multiple webDrivers
     */
    public static void resetPageObjects(WebDriver webDriver) {
        driver = webDriver;
    }

}
