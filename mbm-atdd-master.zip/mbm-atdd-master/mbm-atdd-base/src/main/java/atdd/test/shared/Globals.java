package atdd.test.shared;

import java.util.ArrayList;
import java.util.List;

@Deprecated
public class Globals {

    private static String dbUserName;
    private static String hsc_id;
    private static String requestNumber;
    private static String prisrvcrefnbr;
    private static String lastName;
    private static String firstName;
    private static String subscriberId;
    private static String status;
    private static String startDate;
    private static String endDate;
    private static String requestingProvider;
    private static String servicingProvider;
    private static String creatorFirstName;
    private static String creatorLastName;
    private static String reqProviderTIN;
    private static List<String> id;
    private static String paanTIN;
    private static String clinicalTrialName;
    private static String clinicalTrialPhase;
    private static String traversalID;
    private static String traversalDescription;
    private static String authdurmocnt;
    private static String diseasetype;
    private static String clinvartypid;


    //get 10 first traversal id NOT linked to hsc with occurrence more than 2
    public String getTraversalIDsNOTLinkedToHsc = "SELECT a.dses_trvrs_id, b.dses_trvrs_desc \n" +
            "from hsc \n" +
            "as a INNER JOIN (SELECT dses_trvrs_id, dses_trvrs_desc from dses_trvrs ) \n" +
            "as b on b.dses_trvrs_id = a.dses_trvrs_id\n" +
            "group by a.dses_trvrs_id\n" +
            "having count(a.dses_trvrs_id) > 2\n" +
            "limit 10";
    //get 10 first traversal id linked to hsc with occurrence more than 2
    public String getTraversalIDsLinkedToHscProstate = "SELECT a.dses_trvrs_id, b.dses_trvrs_desc, b.dses_typ_id\n" +
            "from hsc\n" +
            "  as a INNER JOIN (SELECT dses_trvrs_id, dses_trvrs_desc, dses_typ_id from dses_trvrs )\n" +
            "  as b on b.dses_trvrs_id = a.dses_trvrs_id\n" +
            "  where b.dses_typ_id = 36\n" +
            "group by a.dses_trvrs_id\n" +
            "having count(a.dses_trvrs_id) > 2\n" +
            "order by dses_trvrs_id asc\n" +
            "limit 10";

    public Globals() {
        id = new ArrayList<String>();
    }

    //All from Submitted priorAuthSearch. First 10
    public String submittedDBSearch = "select hsc_id, vend_cse_id, pri_srvc_ref_nbr, lst_nm, fst_nm, mbr_id_txt, hscOverallStatusDesc, creat_dttm, srvc_end_dt, reqProviderFullName, serProviderFullName\n" +
            "from hscmemprovview\n" +
            "where hsc_sts_typ_id <> 5 and hsc_sts_typ_id <> 9 \n" +
            "order by chg_dttm desc\n" +
            "LIMIT 10;";

    //All from Draft priorAuthSearch. First 10
    public String draftDBsearch = "select hsc_id, lst_nm, fst_nm, mbr_id_txt, creat_dttm, reqProviderFullName, serProviderFullName, creatorFirstName, creatorLastName\n" +
            "from hscmemprovview\n" +
            "where hsc_sts_typ_id = 5 \n" +
            "order by chg_dttm desc\n" +
            "limit 10";

    //Submitted tab query created by expected user
    public String getSubmittedDBSearchCreatedByUser(String user){
        String query = "select hsc_id, vend_cse_id, pri_srvc_ref_nbr, lst_nm, fst_nm, mbr_id_txt, hscOverallStatusDesc, creat_dttm, srvc_end_dt, reqProviderFullName, serProviderFullName, reqProviderTIN\n" +
                "from hscmemprovview\n" +
                "where hsc_sts_typ_id <> 5 and hsc_sts_typ_id <> 9 and creat_user_id = '" + user + "'\n" +
                "order by chg_dttm desc\n" +
                "LIMIT 10;";
        return query;
    }

    //Submitted tab query created by expected user for E&I
    public String getSubmittedDBSearchCreatedByUserForIandI(String user) {
        String query = "select hsc_id, vend_cse_id, pri_srvc_ref_nbr, lst_nm, fst_nm, mbr_id_txt, hscOverallStatusDesc, creat_dttm, srvc_end_dt, reqProviderFullName, serProviderFullName, reqProviderTIN\n" +
                "from hscmemprovview\n" +
                "where hsc_sts_typ_id <> 5 and hsc_sts_typ_id <> 9 and creat_user_id = '" + user + "' and mbr_id in (Select mbr_id from mbr_cov where prdct_catgy_cd=0)\n" +
                "order by chg_dttm desc\n" +
                "LIMIT 10;";
        return query;
    }

    //Draft tab query created by expected user
    public String getDraftDBsearchCreatedByUser(String user){
        String query = "select hsc_id, lst_nm, fst_nm, mbr_id_txt, creat_dttm, reqProviderFullName, serProviderFullName, creatorFirstName, creatorLastName, reqProviderTIN\n" +
                "from hscmemprovview\n" +
                "where hsc_sts_typ_id = 5 and creat_user_id = '" + user + "'\n" +
                "order by chg_dttm desc\n" +
                "limit 10";
        return query;
    }


    /**
     * Query to get traversal which contains description
     * @param descr
     * @return
     */
    public String getTraversalInfoByDescription(String cancerType, String descr){
        String query = "SELECT\n" +
                "    *\n" +
                "FROM\n" +
                "    (\n" +
                "        SELECT\n" +
                "            d.dses_trvrs_id, auth_dur_mo_cnt,\n" +
                "            group_concat(clin_var_typ_id ORDER BY clin_var_typ_id ASC separator '__')  AS clin_var_typ_id,\n" +
                "            group_concat(clin_var_val ORDER BY clin_var_typ_id ASC separator '__')    AS clin_var_val,\n" +
                "            ref_desc as disease_type\n" +
                "        FROM\n" +
                "            dses_trvrs d\n" +
                "        JOIN dses_trvrs_clin_var cv ON cv.dses_trvrs_id = d.dses_trvrs_id\n" +
                "        JOIN ref r ON cv.dses_typ_id = r.ref_cd AND ref_nm='diseaseType' AND ref_desc = '" + cancerType + "'\n" +
                "        GROUP BY\n" +
                "            d.dses_trvrs_id\n" +
                "        ORDER BY\n" +
                "            clin_Var_typ_id) a\n" +
                "WHERE\n" +
                "    a.clin_var_val LIKE '%" + descr + "%';";
        return query;
    }

    public String getAuthdurmocnt() {
        return authdurmocnt;
    }

    public void setAuthdurmocnt(String authdurmocnt) {
        Globals.authdurmocnt = authdurmocnt;
    }

    public String getDiseasetype() {
        return diseasetype;
    }

    public void setDiseasetype(String diseasetype) {
        Globals.diseasetype = diseasetype;
    }

    public String getClinvartypid() {
        return clinvartypid;
    }

    public void setClinvartypid(String clinvartypid) {
        Globals.clinvartypid = clinvartypid;
    }

    public String getTraversalDescription() {
        return traversalDescription;
    }

    public void setTraversalDescription(String traversalDescription) {
        Globals.traversalDescription = traversalDescription;
    }

    public String getTraversalID() {
        return traversalID;
    }

    public void setTraversalID(String traversalID) {
        Globals.traversalID = traversalID;

    }

    public List<String> getListOfId() {
        return id;
    }

    /**
     * Adding element in to id List
     *
     * @param ids
     */
    public void addToIDList(String ids) {
        Globals.id.add(ids);
    }

    public String getReqProviderTIN() {
        return reqProviderTIN;
    }

    public void setReqProviderTIN(String reqProviderTIN) {
        Globals.reqProviderTIN = reqProviderTIN;
    }

    public String getCreatorFirstName() {
        return creatorFirstName;
    }

    public void setCreatorFirstName(String creatorFirstName) {
        Globals.creatorFirstName = creatorFirstName;
    }

    public String getCreatorLastName() {
        return creatorLastName;
    }

    public void setCreatorLastName(String creatorLastName) {
        Globals.creatorLastName = creatorLastName;
    }

    public String getPrisrvcrefnbr() {
        return prisrvcrefnbr;
    }

    public void setPrisrvcrefnbr(String prisrvcrefnbr) {
        Globals.prisrvcrefnbr = prisrvcrefnbr;
    }

    public String getHsc_id() {
        return hsc_id;
    }

    public void setHsc_id(String hsc_id) {
        Globals.hsc_id = hsc_id;
    }

    public String getRequestNumber() {
        return requestNumber;
    }

    public void setRequestNumber(String requestNumber) {
        Globals.requestNumber = requestNumber;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        Globals.lastName = lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        Globals.firstName = firstName;
    }

    public String getSubscriberId() {
        return subscriberId;
    }

    public void setSubscriberId(String subscriberId) {
        Globals.subscriberId = subscriberId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        Globals.status = status;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        Globals.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        Globals.endDate = endDate;
    }

    public String getRequestingProvider() {
        return requestingProvider;
    }

    public void setRequestingProvider(String requestingProvider) {
        Globals.requestingProvider = requestingProvider;
    }

    public String getServicingProvider() {
        return servicingProvider;
    }

    public void setServicingProvider(String servicingProvider) {
        Globals.servicingProvider = servicingProvider;
    }

    public String getDbUserName() {
        return dbUserName;
    }

    public void setDbUserName(String dbUserName) {
        Globals.dbUserName = dbUserName;
    }

    public String getpaanTIN() {
        return paanTIN;
    }

    public void setpaanTIN(String paanTIN) {
        Globals.paanTIN = paanTIN;
    }

    public String getClinicalTrialName() {
        return clinicalTrialName;
    }

    public void setClinicalTrialName(String clinicalTrialName) {
        Globals.clinicalTrialName = clinicalTrialName;
    }

    public String getClinicalTrialPhase() {
        return clinicalTrialPhase;
    }

    public void setClinicalTrialPhase(String clinicalTrialPhase) {
        Globals.clinicalTrialPhase = clinicalTrialPhase;
    }

}