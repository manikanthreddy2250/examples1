package atdd.utils;

import org.junit.Assert;

public class AssertUtils {
    public static String assertEquals(Object o1, Object o2) {
        try {
            if (null == o1 && null == o2) {
                return "";
            }
            Assert.assertEquals(o1, o2);
            return "";
        } catch (Throwable t) {
            return t.getMessage();
        }
    }
}
