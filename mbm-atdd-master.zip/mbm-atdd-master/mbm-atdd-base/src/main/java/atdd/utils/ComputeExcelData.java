package atdd.utils;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;

import java.io.File;


public class ComputeExcelData {

    /**
     * Method to read an Excel file to be used for Data Driven Testing, create a
     * String Array from the Data, and pass it on to any Data Provider method
     * that called it.
     *
     * @param xlFilePath Provided by the calling method. This is the File Path to where
     *                   the excel sheet containing the data resides.
     * @param sheetName  Provided by the calling method. This is the name of the
     *                   Work-Sheet in the excel workbook containing the data.
     * @param tableName  Provided by the calling method. This is the name of the Table
     *                   that contains all the data to be used for the testing.
     * @return tabArray - Returns a String Array containing the data that has
     * been read from the Excel sheet specified above.
     * @throws Exception
     */

    public static String[][] getTableArray(String xlFilePath, String sheetName, String tableName) throws Exception {

        int startRow, startCol, endRow, endCol, ci, cj;
        String[][] tabArray = null;

        Workbook workbook = Workbook.getWorkbook(new File(xlFilePath));

        Sheet sheet = workbook.getSheet(sheetName);
        if (sheet == null) {
            System.out.println("Sheet " + sheetName + " is not found!!!");
            throw new Exception("Sheet " + sheetName + " is not found!!!");
        }

        Cell tableStart = sheet.findCell(tableName);
        if (tableStart == null) {
            System.out.println("Table " + tableName + " is not found!!!");
            throw new Exception("Table " + tableName + " is not found!!!");
        }

        startRow = tableStart.getRow();
        startCol = tableStart.getColumn();

        Cell tableEnd = sheet.findCell(tableName, startCol + 1, startRow + 1, 100, 64000, false);
        endRow = tableEnd.getRow();
        endCol = tableEnd.getColumn();

        System.out.println("The Data file boundaries are: ");
        System.out.println("\n Sheet " + sheetName + " Table " + tableName + " Start Row = " + startRow + ", End Row = " + endRow + ", " + "Start Col = " + startCol + ", End Col = " + endCol);

        tabArray = new String[endRow - startRow - 1][endCol - startCol - 1];

        ci = 0;
        for (int i = startRow + 1; i < endRow; i++, ci++) {

            cj = 0;
            for (int j = startCol + 1; j < endCol; j++, cj++) {
                tabArray[ci][cj] = sheet.getCell(j, i).getContents();

            }

        }

        return (tabArray);

    }

    /**
     * Getting number of Rows
     *
     * @param xlFilePath
     * @param sheetName
     * @param tableName
     * @return
     * @throws Exception
     */
    public static int getTableRowSize(String xlFilePath, String sheetName, String tableName) throws Exception {

        Workbook workbook = Workbook.getWorkbook(new File(xlFilePath));
        Sheet sheet = workbook.getSheet(sheetName);

        int startRow, startCol, endRow, sizeRow;

        Cell tableStart = sheet.findCell(tableName);
        startRow = tableStart.getRow();
        startCol = tableStart.getColumn();

        Cell tableEnd = sheet.findCell(tableName, startCol + 1, startRow + 1, 100, 64000, false);
        endRow = tableEnd.getRow();

        sizeRow = endRow - startRow - 1;

        System.out.println("Rows: " + sizeRow);

        return sizeRow;

    }

    /**
     * Getting number of columns
     *
     * @param xlFilePath
     * @param sheetName
     * @param tableName
     * @return
     * @throws Exception
     */
    public static int getTableColumnSize(String xlFilePath, String sheetName, String tableName) throws Exception {

        Workbook workbook = Workbook.getWorkbook(new File(xlFilePath));
        Sheet sheet = workbook.getSheet(sheetName);

        int startRow, startCol, endCol, sizecolumn;

        Cell tableStart = sheet.findCell(tableName);
        startRow = tableStart.getRow();
        startCol = tableStart.getColumn();

        Cell tableEnd = sheet.findCell(tableName, startCol + 1, startRow + 1, 100, 64000, false);
        endCol = tableEnd.getColumn();

        sizecolumn = endCol - startCol - 1;

        System.out.println("Columns: " + sizecolumn);

        return sizecolumn;

    }

}
