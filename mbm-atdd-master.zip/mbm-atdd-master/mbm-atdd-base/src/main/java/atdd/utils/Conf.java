package atdd.utils;

public class Conf extends ConfBase {
    private static ConfBase instance = new Conf();

    private Conf() {
        super(BASE_PROJECT, "config");

        loadTunnelProperties(DATA);
    }

    public static ConfBase getInstance() {
        return instance;
    }
}
