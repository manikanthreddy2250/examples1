package atdd.utils;

import atdd.common.WiseProperties;
import org.apache.log4j.Logger;

import java.io.File;
import java.io.FileInputStream;
import java.util.*;

public abstract class ConfBase extends WiseProperties {

    public static final Logger log = Logger.getLogger(ConfBase.class.getName());

    public static final String PROJECT_KEY = "project";

    public static final String COMMON_PROJECT = "mbm-atdd-common";
    public static final String BASE_PROJECT = "mbm-atdd-base";

    public static final String TEST_HOST_KEY = "testHost";
    public static final String TEST_ENDPOINT_KEY = "testEndpoint";
    public static final String TIME_ZONE_KEY = "timeZone";

    public static final String DATA = "data";

    private final static String[] PROTECTED_KEYS = new String[]{
            "PAANUserPass",
            "sauce_key",
            "icueDatabasePass",
            "DatabasePass",
            "msidDbPass",
            "userPassword"
    };

    protected ConfBase(String myProject, String... fns) {
        super("_");

        String home = "src" + File.separator + "main" + File.separator + "resources" + File.separator;
        loadProperties(myProject, home, fns);

        this.setProperty(PROJECT_KEY, myProject);
    }

    protected void loadTunnelProperties(String tunnelKey) {
        Map<String, String> map = new LinkedHashMap<>();

        String stringMap = this.getProperty(tunnelKey);
        if (!StringUtils.isEmpty(stringMap)) {
            try {
                map.putAll(DataTableUtils.asMap(stringMap));
            } catch (Exception e) {
                // do nothing
            }
        }

        for (String key : map.keySet()) {
            String value = map.get(key);
            this.setProperty(key, value);
            this.setProperty(tunnelKey + "." + key, value);
        }

    }

    private void loadProperties(String myProject, String home, String[] fns) {
        for (String fn : fns) {
            try {
                File file = TestUtils.projectFile(myProject, home + fn + "_local.properties");
                this.load(new FileInputStream(file));
                log.warn("Properties file loaded: " + file.getAbsolutePath());
            } catch (Exception e) {
                try {
                    File file = TestUtils.projectFile(myProject, home + fn + ".properties");
                    this.load(new FileInputStream(file));
                    log.warn("Properties file loaded: " + file.getAbsolutePath());
                } catch (Exception e1) {
                    throw new RuntimeException(e.getMessage());
                }
            }
        }
    }

    /**
     * Get the predefined output path
     *
     * @return
     */
    public static String getOutputPath() {
        return Conf.getInstance().getProperty("output", "target/output/");
    }

    /**
     * Get resend retry timeout in minutes
     *
     * @return
     */
    public static int getResendTimeoutInMinutes() {
        return Integer.parseInt(Conf.getInstance().getProperty("resendTimeoutInMinutes", "30"));
    }

    public static long getRefreshTimeoutInMinutes() {
        return Integer.parseInt(Conf.getInstance().getProperty("refreshTimeoutInMinutes", "30"));
    }

    /**
     * Get the predefined demo status
     *
     * @return
     */
    public boolean isDemo() {
        return Boolean.parseBoolean(this.getProperty("demo", "false"));
    }

    /**
     * Get the hard coded protected keys
     *
     * @return
     */
    public String[] getProtectedKeys() {
        return PROTECTED_KEYS;
    }

    /**
     * Copy all string properties into a Map<String, String> object and return
     *
     * @return
     */
    public Map<String, String> asMap() {
        Map<String, String> map = new HashMap<String, String>(this.size());
        for (String key : this.stringPropertyNames()) {
            map.put(key, this.getProperty(key));
        }
        return map;
    }

}
