package atdd.utils;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class CriteriaField {

    private static Logger log = Logger.getLogger(CriteriaField.class.getName());

    /**
     * Retrun all CriteriaField list by specified filterTableXpath
     *
     * @param webDriver
     * @param filterTableXpath
     * @return
     */
    public static Map<String, CriteriaField> getCriteriaFields(WebDriver webDriver, String filterTableXpath) {
        Map<String, CriteriaField> criteriaFields = new LinkedHashMap<>();

        List<List<String>> headerRows = getHeaderRows(webDriver, filterTableXpath);

        for (int row = 0; row < headerRows.size(); row++) {
            List<String> headerRow = headerRows.get(row);
            for (int col = 0; col < headerRow.size(); col++) {
                String header = headerRow.get(col);
                if (!StringUtils.isEmpty(header)) {
                    header = header.trim().split("\n", 2)[0];
                    try {
                        CriteriaField criteriaField = new CriteriaField(webDriver, header, filterTableXpath, row, col);
                        if (TestUtils.isElementVisible(webDriver, criteriaField.getInputXpath())) {
                            criteriaFields.put(header, criteriaField);
                        }
                    } catch (InvalidCriteriaFieldException e) {
                        log.warn(e.getMessage());
                    }
                }
            }
        }

        return criteriaFields;
    }

    private static List<List<String>> getHeaderRows(WebDriver webDriver, String filterTableXpath) {
        List<List<String>> lists = TestUtils.tableAsLists(webDriver, filterTableXpath, 30);
        Assert.assertTrue(0 == lists.size() % 2);

        List<List<String>> headerRows = new ArrayList<>(lists.size() / 2);
        for (int i = 0; i < lists.size(); i = i + 2) {
            headerRows.add(lists.get(i));
        }
        return headerRows;
    }

    private final String header;
    private final String inputXpath;

    private CriteriaField(WebDriver driver, String header, String filterTableXpath, int row, int col) throws InvalidCriteriaFieldException {
        this.header = header;
        this.inputXpath = filterTableXpath + "//tr[" + (row * 2 + 2) + "]/td[" + (col + 1) + "]/*[not(name()='div') and not(name()='label')]";
        if (1 != TestUtils.countElementsByXpath(driver, inputXpath)) {
            throw new InvalidCriteriaFieldException("Invalid or ambiguous xpath: " + inputXpath);
        }
    }

    /**
     * Return the header
     *
     * @return
     */
    public String getHeader() {
        return this.header;
    }

    /**
     * Return the input xpath
     *
     * @return
     */
    public String getInputXpath() {
        return this.inputXpath;
    }

    private class InvalidCriteriaFieldException extends Exception {

        public InvalidCriteriaFieldException(String message) {
            super(message);
        }
    }
}
