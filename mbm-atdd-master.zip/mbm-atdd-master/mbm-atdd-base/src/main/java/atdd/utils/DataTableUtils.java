package atdd.utils;

import cucumber.api.DataTable;
import org.apache.log4j.Logger;

import java.util.*;

public class DataTableUtils {

    public static final String INDEX_ROW_NUMBER = "ROW_NUMBER";

    private static final Logger log = Logger.getLogger(DataTableUtils.class.getName());

    /**
     * Convert a DataTable object into a list of mutable maps.
     *
     * @param dataTable
     * @return
     */
    public static List<Map<String, String>> asMutableMaps(DataTable dataTable) {
        List<Map<String, String>> maps = dataTable.asMaps(String.class, String.class);
        List<Map<String, String>> ret = new ArrayList<Map<String, String>>(maps.size());
        for (Map<String, String> map : maps) {
            ret.add(new LinkedHashMap<String, String>(map));
        }
        return ret;
    }

    /**
     * Transpose a DataTable object and convert if into a list of mutable maps.
     *
     * @param dataTable
     * @return
     */
    public static List<Map<String, String>> asMutableMapsTranspose(DataTable dataTable) {
        List<List<String>> lists = dataTable.asLists(String.class);
        List<List<String>> tLists = transpose(lists);
        DataTable tDataTable = DataTable.create(tLists);
        return asMutableMaps(tDataTable);
    }

    /**
     * Transpose a list of lists object
     *
     * @param table
     * @param <T>
     * @return
     */
    public static <T> List<List<T>> transpose(List<List<T>> table) {
        final int size = table.size();
        final int tSize = table.get(0).size();
        List<List<T>> ret = new ArrayList<List<T>>(tSize);
        for (int i = 0; i < tSize; i++) {
            List<T> tRow = new ArrayList<T>();
            for (List<T> row : table) {
                tRow.add(row.get(i));
            }
            ret.add(tRow);
        }
        return ret;
    }

    /**
     * Prerequisite: each map in dataTable contains a unique value with keyHeader.
     * This method returns the same maps in dataTable but indexed by keyHeader.
     *
     * @param keyHeader Specifies the column name to be indexed. "ROW_NUMBER" will be used if it's null.
     * @param dataTable
     * @return
     */
    public static Map<String, Map<String, String>> dataTableAsMapsIndexedByKeyHeader(String keyHeader, List<Map<String, String>> dataTable) {
        return dataTableAsMapsIndexedByKeyHeader(keyHeader, dataTable, false);
    }

    /**
     * Prerequisite: each map in dataTable contains a unique value with keyHeader.
     * This method returns the same maps in dataTable but indexed by keyHeader.
     *
     * @param keyHeader           Specifies the column name to be indexed. "ROW_NUMBER" will be used if it's null.
     * @param dataTable
     * @param ignoreDuplicatedKey Whether to throw RuntimeException when duplicated keys are detected.
     * @return
     */
    public static Map<String, Map<String, String>> dataTableAsMapsIndexedByKeyHeader(String keyHeader, List<Map<String, String>> dataTable, boolean ignoreDuplicatedKey) {
        log.warn("dataTableAsMapsIndexedByKeyHeader: keyHeader=" + keyHeader);
        log.warn("dataTableAsMapsIndexedByKeyHeader: table=" + dataTable.toString());

        for (int i = 0; i < dataTable.size(); i++) {
            Map<String, String> row = dataTable.get(i);
            row.put(INDEX_ROW_NUMBER, "" + (i + 1));

        }

        if (null == keyHeader || keyHeader.trim().isEmpty()) {
            keyHeader = INDEX_ROW_NUMBER;
        }

        Map<String, Map<String, String>> result = new LinkedHashMap<>(dataTable.size());
        for (Map<String, String> row : dataTable) {
            String key = row.get(keyHeader);
            if (null == key || key.trim().isEmpty()) {
                log.warn("Missing key header: " + row);
                continue;
            }
            if (result.containsKey(key)) {
                String msg = "Duplicated key [" + key + "] in row: " + row;
                if (ignoreDuplicatedKey) {
                    log.warn(msg);
                } else {
                    throw new RuntimeException(msg);
                }
            }
            result.put(key, row);
        }
        log.warn("dataTableAsMapsIndexedByKeyHeader: result=" + result.toString());
        return result;
    }

    /**
     * Merge multiple Data Tables into one given they contain same number of rows and they share the same key column
     * specified by keyHeader. "ROW_NUMBER" will be used if not specified.
     *
     * @param strict
     * @param keyHeader
     * @param dataTables
     * @return
     */
    public static Map<String, Map<String, String>> merge(boolean strict, String keyHeader, List<Map<String, String>>... dataTables) {
        log.warn("merge: keyHeader=" + keyHeader);
        if (null == dataTables || dataTables.length <= 0 || null == dataTables[0]) {
            log.error("Invalid tables");
            return null;
        }
        log.warn("merge: tables=" + dataTables.toString());
        Map<String, Map<String, String>> result = DataTableUtils.dataTableAsMapsIndexedByKeyHeader(keyHeader, dataTables[0]);
        for (int i = 1; i < dataTables.length; i++) {
            if (null == dataTables[i]) {
                continue;
            }
            Map<String, Map<String, String>> m = DataTableUtils.dataTableAsMapsIndexedByKeyHeader(keyHeader, dataTables[i]);
            if (m.size() != result.size()) {
                String err = "Number of rows mismatch: " + m + " VS " + result;
                log.error(err);
                if (strict) {
                    throw new RuntimeException(err);
                } else {
                    continue;
                }
            }
            for (String key : result.keySet()) {
                if (!m.containsKey(key)) {
                    String err = "Missing key [" + key + "] in table: " + m;
                    log.error(err);
                    if (strict) {
                        throw new RuntimeException(err);
                    } else {
                        continue;
                    }
                }
                result.get(key).putAll(m.get(key));
            }
        }
        log.warn("merge: result=" + result.toString());
        return result;
    }

    /**
     * Convert a String like "a=b, c=d" to a Map Object
     *
     * @param stringMap
     * @return
     */
    public static Map<String, String> asMap(String stringMap) {
        return asMap(stringMap, ",", "=");
    }

    /**
     * Convert a String like "a=b, c=d" to a Map Object
     * "," and "=" can be replaced with any two different strings
     *
     * @param stringMap
     * @return
     */
    public static Map<String, String> asMap(String stringMap, String d1, String d2) {
        Map<String, String> result = new LinkedHashMap<>();
        String lastKey = null;
        for (String s : stringMap.split(d1)) {
            s = s.trim();
            if (s.isEmpty()) {
                continue;
            }
            String[] p = s.split(d2, 2);
            if (1 == p.length) {
                if (null == lastKey) {
                    throw new RuntimeException("Cannot split " + s + " by " + d2);
                }
                result.put(lastKey, result.get(lastKey) + d2 + s);
            } else {
                lastKey = p[0].trim();
                result.put(lastKey, p[1].trim());
            }
        }
        return result;
    }

    /**
     * Convert a String like "a=b, c=d" to a Properties Object
     *
     * @param stringMap
     * @return
     */
    public static Properties asProperties(String stringMap) {
        Map<String, String> map = asMap(stringMap);
        Properties prop = new Properties();
        for (String key : map.keySet()) {
            prop.put(key, map.get(key));
        }
        return prop;
    }

    /**
     * Convert an instance from type Map<String, Object> to Map<String, String>
     *
     * @param raw
     * @return
     */
    public static Map<String, String> asMapOfStrings(Map<String, Object> raw) {
        Map<String, String> result = new LinkedHashMap<>(raw.size());
        for (String key : raw.keySet()) {
            Object value = raw.get(key);
            result.put(key, null == value ? "" : value.toString());
        }
        return result;
    }

    /**
     * Convert an instance from type List<Map<String, Object>> to List<Map<String, String>>
     *
     * @param raw
     * @return
     */
    public static List<Map<String, String>> asMapsOfStrings(List<Map<String, Object>> raw) {
        List<Map<String, String>> result = new ArrayList<>(raw.size());
        for (Map<String, Object> map : raw) {
            Map<String, String> stringMap = asMapOfStrings(map);
            result.add(stringMap);
        }
        return result;
    }

    /**
     * Remove all keys from map
     *
     * @param map
     * @param keys
     */
    public static <T> void removeAll(Map<String, T> map, Collection<String> keys) {
        for (String key : keys) {
            map.remove(key);
        }
    }

    /**
     * Remove all keys that match specified regex from map
     *
     * @param map
     * @param regex
     */
    public static <T> void removeAll(Map<String, T> map, String regex) {
        synchronized (map) {
            Set<String> toBeRemoved = new HashSet<>();
            for (String key : map.keySet()) {
                if (key.matches(regex)) {
                    toBeRemoved.add(key);
                }
            }
            removeAll(map, toBeRemoved);
        }
    }

    /**
     * Convert an instance from type Map<String, Map<String, String>> to type DataTable
     *
     * @param maps
     * @return
     */
    public static DataTable asDataTable(Map<String, Map<String, String>> maps) {
        List<Map<String, String>> mapsList = new ArrayList<>(maps.size());
        mapsList.addAll(maps.values());
        return DataTable.create(mapsList);
    }

    /**
     * Extract only the keys that matches the regex expression
     *
     * @param keySet
     * @param regex
     * @return
     */
    public static Set<String> extractKeys(Set<String> keySet, String regex) {
        Set<String> result = new LinkedHashSet<>();
        for (String key : keySet) {
            if (key.matches(regex)) {
                result.add(key);
            }
        }
        return result;
    }

    /**
     * Convert an instance from type List<String> to type Map<String, String> where the keys are row numbers
     *
     * @param list
     * @return
     */
    public static Map<String, String> toMapByRow(List<String> list) {
        Map<String, String> mapByRow = new LinkedHashMap<>(list.size());
        for (int i = 0; i < list.size(); i++) {
            mapByRow.put("" + i, list.get(i));
        }
        return mapByRow;
    }

    public static void removeAllWithPrefix(Map<String, String> map, String prefix) {
        Set<String> keys = new HashSet<>();
        for (String key : map.keySet()) {
            if (key.startsWith(prefix)) {
                keys.add(key);
            }
        }
        removeAll(map, keys);
    }

    public static String mapsToDataTableString(List<Map<String, String>> maps) {
        for (Map<String, String> map : maps) {
            if (map.size() != maps.get(0).size()) {
                for (String key : maps.get(0).keySet()) {
                    if (!map.containsKey(key)) {
                        map.put(key, "-");
                    }
                }
            }
        }

        DataTable dataTable = DataTable.create(maps);

        String s = dataTable.toString();

        return s;
    }

    public static String mapToDataTableString(Map<String, String> map) {
        List<Map<String, String>> maps = new ArrayList<>(1);
        maps.add(map);
        return mapsToDataTableString(maps);
    }

    public static List<String> asList(String stringList) {
        String[] a = stringList.split(",");
        List<String> list = new ArrayList<>(a.length);
        for (int i = 0; i < a.length; i++) {
            list.add(a[i].trim());
        }
        return list;
    }

    public static void removeEmptyValues(Map<String, String> map) {
        Set<String> keys = new HashSet<>();
        for (String key : map.keySet()) {
            if (StringUtils.isEmpty(map.get(key))) {
                keys.add(key);
            }
        }
        removeAll(map, keys);
    }

    public static List<List<String>> asLists(Map<String, String> map) {
        List<List<String>> data = new ArrayList<>(map.size());
        for (String key : map.keySet()) {
            data.add(Arrays.asList(new String[]{key, map.get(key)}));
        }
        return data;
    }

    public static List<String> asListOfStrings(List<Object> objList) {
        if (null == objList) {
            return null;
        }
        List<String> strList = new ArrayList<>(objList.size());
        for (Object obj : objList) {
            strList.add(null == obj ? null : obj.toString());
        }
        return strList;
    }
}
