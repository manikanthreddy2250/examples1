package atdd.utils;



import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class DateUtils {
    private static final SimpleDateFormat mmDdYyyy = new SimpleDateFormat("MM-dd-yyyy");

    private static final SimpleDateFormat timestamp = new SimpleDateFormat("yyyyMMddHHmmssS");


    public static String mmDdYyyy() {
        return mmDdYyyy(new Date());
    }

    public static String mmDdYyyyYesterday() {
        return mmDdYyyy(new Date(), -1, Calendar.DATE);
    }

    public static String mmDdYyyyTomorrow() {
        return mmDdYyyy(new Date(), 1, Calendar.DATE);
    }

    public static String mmDdYyyy(int amount, int field) {
        return mmDdYyyy(new Date(), amount, field);
    }

    public static String mmDdYyyy(Date date) {
        return mmDdYyyy(date, 0, 0);
    }

    public static String timestamp() {
        return timestamp.format(new Date());
    }

    public static String mmDdYyyy(Date date, int amount, int field) {
        if (0 == amount) {
            return mmDdYyyy.format(date);
        } else {
            Date newDate = addTo(date, amount, field);
            return mmDdYyyy.format(newDate);
        }
    }

    public static String calcFormat(Date date, int amount, int field, String format) {
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        if (0 == amount) {
            return sdf.format(date);
        } else {
            Date newDate = addTo(date, amount, field);
            return sdf.format(newDate);
        }
    }

    public static Date addTo(Date date, int amount, int field) {
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(field, amount);
        Date newDate = c.getTime();
        return newDate;
    }

    public static Date mmDdYyyy(String sStart) throws ParseException {
        return mmDdYyyy.parse(sStart);
    }

    public static int monthsBetween(Date startDate, Date endDate) {
        Calendar startCalendar = new GregorianCalendar();
        startCalendar.setTime(startDate);
        Calendar endCalendar = new GregorianCalendar();
        endCalendar.setTime(endDate);

        int diffYear = endCalendar.get(Calendar.YEAR) - startCalendar.get(Calendar.YEAR);
        int diffMonth = diffYear * 12 + endCalendar.get(Calendar.MONTH) - startCalendar.get(Calendar.MONTH);
        return diffMonth;
    }

    public static int weeksBetween(Date startDate, Date endDate) {
        Calendar a = new GregorianCalendar();
        Calendar b = new GregorianCalendar();
        a.setTime(startDate);
        b.setTime(endDate);
        return b.get(Calendar.WEEK_OF_YEAR) - a.get(Calendar.WEEK_OF_YEAR);
    }

    public static int getAge(String dob) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        Date date = null;
        try {
            date = sdf.parse(dob);
        } catch (ParseException e) {

        }
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);


        Calendar today = Calendar.getInstance();

        int curYear = today.get(Calendar.YEAR);
        int dobYear = cal.get(Calendar.YEAR);

        int age = curYear - dobYear;

        // if dob is month or day is behind today's month or day
        // reduce age by 1
        int curMonth = today.get(Calendar.MONTH);
        int dobMonth = cal.get(Calendar.MONTH);
        if (dobMonth > curMonth) { // this year can't be counted!
            age--;
        } else if (dobMonth == curMonth) { // same month? check for day
            int curDay = today.get(Calendar.DAY_OF_MONTH);
            int dobDay = cal.get(Calendar.DAY_OF_MONTH);
            if (dobDay > curDay) { // this year can't be counted!
                age--;
            }
        }

        return age;
    }

    public static String todayWithoutFormat() {
        SimpleDateFormat sdf = new SimpleDateFormat("MMddyyyy");
        Date now = new Date();
        return sdf.format(now);
    }
}
