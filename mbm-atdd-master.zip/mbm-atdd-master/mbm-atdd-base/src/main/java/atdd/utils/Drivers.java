package atdd.utils;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Properties;

public class Drivers {

    public static Properties Config = Conf.getInstance();
    public static Logger log = Logger.getLogger("Drivers");

    private static String sauceUser;
    private static String sauceKey;
    private static String tunnel;

    //Capabilities for remote driver
    private static String platform;
    private static String version = "latest";
    private static String screenResolution;
    private static String parenttunnel;
    private static String maxDuration;
    private static String idleTimeout;
    private static String commandTimeout;


    /**
     * Getting driver
     *
     * @return
     * @throws Exception
     */
    public static WebDriver getDriver(String browser) {

        WebDriver driver = null;
        browser = browser.toLowerCase();

        if (browser != null) {
            if (browser.equals("chromelocal")) {
                driver = setChromeLocalDriver();

            } else if (browser.equals("chromelocalmac")) {
                driver = setChromeLocalDriverForMac();

            } else if (browser.contains("chromedocker")) {
                initializeRemoteCaps();
                driver = setDockerChromeDriver();

            } else if (browser.contains("chromeremote")) {
                initializeRemoteCaps();
                driver = setRemoteChromeDriver(sauceUser, sauceKey, tunnel);

            } else if (browser.equals("firefoxlocal")) {
                driver = setFireFoxLocalDriver();

            } else if (browser.equals("firefoxlocalmac")) {
                driver = setFireFoxLocalDriverForMac();

            } else if (browser.contains("firefoxdocker")) {
                initializeRemoteCaps();
                driver = setDockerFireFoxDriver();

            } else if (browser.contains("firefoxremote")) {
                initializeRemoteCaps();
                driver = setRemoteFireFoxDriver(sauceUser, sauceKey, tunnel);

            } else if (browser.equals("internetexplorer")) {
                driver = setInternetExplorerDriver();

            } else if (browser.contains("ieremote")) {
                initializeRemoteCaps();
                driver = setRemoteIEDriver(sauceUser, sauceKey, tunnel);

            } else
                Assert.fail("Wrong browser parameter: " + browser);
        } else {
            Assert.fail("Browser type not specified.");
        }
        driver.manage().deleteAllCookies();


        return driver;
    }

    /**
     * Get remote IE driver on the SauceLabs
     *
     * @param sauseUser
     * @param sauceKey
     * @param tunnel
     * @return
     */
    private static WebDriver setRemoteIEDriver(String sauseUser, String sauceKey, String tunnel) {

        String url = "https://" + sauseUser + ":" + sauceKey + "@ondemand.us-west-1.saucelabs.com:443/wd/hub";

        WebDriver driver = null;

        DesiredCapabilities caps = DesiredCapabilities.internetExplorer();

        caps.setCapability("platform", platform);
        caps.setCapability("version", version);
        caps.setCapability("screenResolution", screenResolution);
        caps.setCapability("parent-tunnel", parenttunnel);
        caps.setCapability("tunnelIdentifier", tunnel);
        caps.setCapability("maxDuration", maxDuration);
        caps.setCapability("idleTimeout", idleTimeout);
        caps.setCapability("commandTimeout", commandTimeout);
        caps.setCapability("build", "build: " + System.getenv("BUILD_TAG"));
        caps.setCapability("tag", System.getenv("BUILD_NUMBER"));

        String name = Conf.getInstance().getProperty("remoteJobName");
        if (!StringUtils.isEmpty(name)) {
            caps.setCapability("name", name);
        }
        boolean extendedDebugging = Boolean.parseBoolean(Conf.getInstance().getProperty("extendedDebugging"));
        if (extendedDebugging) {
            caps.setCapability("extendedDebugging", true);
        }

        caps.setCapability(ZonedDateUtils.KEY_TIME_ZONE, ZonedDateUtils.shortName(ZonedDateUtils.zone()));

        try {
            driver = new RemoteWebDriver(new URL(url), caps);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }

        return driver;
    }

    /**
     * Getting remote FireFox driver on the Docker
     *
     * @return
     */
    private static WebDriver setDockerFireFoxDriver() {

        WebDriver driver = null;
        DesiredCapabilities caps = DesiredCapabilities.firefox();
        caps.setBrowserName("firefox");
        caps.setPlatform(Platform.LINUX);
//            caps.setVersion("62.0.3");

        try {
            //debug locally
//            driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), caps);
            driver = new RemoteWebDriver(new URL("http://selenium-hub-mbm-atdd-tests.ocp-ctc-core-nonprod.optum.com/wd/hub"), caps);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }

        return driver;
    }

    /**
     * Getting remote Chrome driver on the Docker
     *
     * @return
     */
    private static WebDriver setDockerChromeDriver() {

        WebDriver driver = null;
        DesiredCapabilities caps = DesiredCapabilities.chrome();
        caps.setBrowserName("chrome");
        caps.setPlatform(Platform.LINUX);

        try {
//            driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), caps);
            driver = new RemoteWebDriver(new URL("http://selenium-hub-mbm-atdd-tests.ocp-ctc-core-nonprod.optum.com/wd/hub"), caps);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }

        return driver;
    }

    /**
     * Getting remote FireFox driver on the SauceLabs
     *
     * @param sauseUser
     * @param sauceKey
     * @param tunnel
     * @return
     */
    private static WebDriver setRemoteFireFoxDriver(String sauseUser, String sauceKey, String tunnel) {

        String url = "https://" + sauseUser + ":" + sauceKey + "@ondemand.us-west-1.saucelabs.com:443/wd/hub";

        WebDriver driver = null;

        DesiredCapabilities caps = DesiredCapabilities.firefox();

        caps.setCapability("platform", platform);
        caps.setCapability("version", version);
        caps.setCapability("screenResolution", screenResolution);
        caps.setCapability("parent-tunnel", parenttunnel);
        caps.setCapability("tunnelIdentifier", tunnel);
        caps.setCapability("maxDuration", maxDuration);
        caps.setCapability("idleTimeout", idleTimeout);
        caps.setCapability("commandTimeout", commandTimeout);
        caps.setCapability("build", "build: " + System.getenv("BUILD_TAG"));
        caps.setCapability("tag", System.getenv("BUILD_NUMBER"));

        String name = Conf.getInstance().getProperty("remoteJobName");
        if (!StringUtils.isEmpty(name)) {
            caps.setCapability("name", name);
        }
        boolean extendedDebugging = Boolean.parseBoolean(Conf.getInstance().getProperty("extendedDebugging"));
        if (extendedDebugging) {
            caps.setCapability("extendedDebugging", true);
        }

        caps.setCapability(ZonedDateUtils.KEY_TIME_ZONE, ZonedDateUtils.shortName(ZonedDateUtils.zone()));

        try {
            driver = new RemoteWebDriver(new URL(url), caps);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }

        return driver;
    }


    /**
     * Getting remote Chrome driver on the SauceLabs
     *
     * @param sauseUser
     * @param sauceKey
     * @param tunnel
     * @return
     */
    public static WebDriver setRemoteChromeDriver(String sauseUser, String sauceKey, String tunnel) {

        String url = "https://" + sauseUser + ":" + sauceKey + "@ondemand.us-west-1.saucelabs.com/wd/hub";

        WebDriver driver = null;

        DesiredCapabilities caps = DesiredCapabilities.chrome();

        //Disabling extensions
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--disable-extensions");

        caps.setCapability(ChromeOptions.CAPABILITY, options);

        caps.setCapability("platform", platform);
        caps.setCapability("version", version);
        caps.setCapability("screenResolution", screenResolution);
        caps.setCapability("parent-tunnel", parenttunnel);
        caps.setCapability("tunnelIdentifier", tunnel);
        caps.setCapability("maxDuration", maxDuration);
        caps.setCapability("idleTimeout", idleTimeout);
        caps.setCapability("commandTimeout", commandTimeout);
        caps.setCapability("build", "build: " + System.getenv("BUILD_TAG"));
        caps.setCapability("tag", System.getenv("BUILD_NUMBER"));

        String name = Conf.getInstance().getProperty("remoteJobName");
        if (!StringUtils.isEmpty(name)) {
            caps.setCapability("name", name);
        }
        boolean extendedDebugging = Boolean.parseBoolean(Conf.getInstance().getProperty("extendedDebugging"));
        if (extendedDebugging) {
            caps.setCapability("extendedDebugging", true);
        }

        caps.setCapability(ZonedDateUtils.KEY_TIME_ZONE, ZonedDateUtils.shortName(ZonedDateUtils.zone()));


        try {
            driver = new RemoteWebDriver(new URL(url), caps);
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }

        return driver;

    }


    /**
     * Creating Chrome local driver for Windows
     *
     * @return WebDriver
     */
    private static WebDriver setChromeLocalDriver() {

        System.out.println("\n\nCreating Driver for Chrome Windows");
        String path = TestUtils.projectFile("src/lib/drivers/chrome/chromedriver.exe").getAbsolutePath();
        System.setProperty("webdriver.chrome.driver", path);
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--start-maximized");
        options.addArguments("--js-flags=--expose-gc");
        options.addArguments("--enable-precise-memory-info");
        options.addArguments("--disable-popup-blocking");
        options.addArguments("--disable-default-apps");
        options.addArguments("--enable-automation");
        options.addArguments("test-type=browser");
        options.addArguments("disable-infobars");
        options.addArguments("disable-extensions");
        return new ChromeDriver(options);


    }

    /**
     * Creating Chrome local driver for Mac
     *
     * @return WebDriver
     */
    private static WebDriver setChromeLocalDriverForMac() {
        System.out.println("\n\nCreating Driver for Chrome Mac");
        File file = TestUtils.projectFile("src/lib/drivers/chrome/chromedriver");
        System.setProperty("webdriver.chrome.driver", file.getAbsolutePath());
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--start-fullscreen");
        options.addArguments("disable-infobars");
        options.addArguments("--disable-extensions");
        return new ChromeDriver(options);
    }

    /**
     * Creating Firefox local driver for Mac
     *
     * @return WebDriver
     */
    private static WebDriver setFireFoxLocalDriverForMac() {
        System.out.println("\n\nCreating Driver for Firefox Mac");
        String path = TestUtils.projectFile("src/lib/drivers/firefox/geckodriver").getAbsolutePath();
        System.setProperty("webdriver.gecko.driver", path);
        FirefoxOptions options = new FirefoxOptions();
        options.setAcceptInsecureCerts(true);
        options.setCapability("marionette", true);
        options.addArguments("disable-infobars");
        options.addArguments("--disable-extensions");
        return new FirefoxDriver(options);

    }

    /**
     * Creating Firefox local driver for Windows
     *
     * @return WebDriver
     */
    private static WebDriver setFireFoxLocalDriver() {
        System.out.println("\n\nCreating Driver for Firefox Windows");
        String path = TestUtils.projectFile("src/lib/drivers/firefox/geckodriver.exe").getAbsolutePath();
        System.setProperty("webdriver.gecko.driver", path);
        FirefoxOptions options = new FirefoxOptions();
        options.setAcceptInsecureCerts(true);
        options.setCapability("marionette", true);
        options.addArguments("disable-infobars");
        options.addArguments("--disable-extensions");
        return new FirefoxDriver(options);

    }

    /**
     * Creating IE local driver for Windows
     *
     * @return WebDriver
     */
    private static WebDriver setInternetExplorerDriver() {
        System.out.println("\n\nCreating Driver for internetexplorer Windows");
        String path = TestUtils.projectFile("src/lib/drivers/IE/IEDriverServer.exe").getAbsolutePath();
        System.setProperty("webdriver.ie.driver", path);
        InternetExplorerOptions options = new InternetExplorerOptions();
//        options.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
        //options.setCapability("initialBrowserUrl", "http://www.google.com");
        options.setCapability("ignoreZoomSetting", true);
        options.setCapability("ignoreProtectedModeSettings", true);
        options.setCapability("requireWindowFocus", true);
        options.setCapability("unexpectedAlertBehaviour", "ignore");
        return new InternetExplorerDriver(options);

    }


    /**
     * Initialize Remote Capabilities for remote drivers.
     * If parameter is not found in System variables, if will be taken from local property file
     */
    private static void initializeRemoteCaps() {

        sauceUser = System.getenv("Sauce_User");
        if (sauceUser == null) {
            log.debug("Cant find Sauce_User in System Variables. Taking from local config.");
            sauceUser = Conf.getInstance().getProperty("sauce_user");
        }

        sauceKey = System.getenv("Sauce_Key");
        if (sauceKey == null) {
            log.debug("Cant find Sauce_Key in System Variables. Taking from local config.");
            sauceKey = Conf.getInstance().getProperty("sauce_key");
        }

        tunnel = System.getenv("Sauce_Tunnel");
        if (tunnel == null) {
            log.debug("Cant find Sauce_Tunnel in System Variables. Taking from local config.");
            tunnel = Conf.getInstance().getProperty("tunnelName");
        }

        platform = System.getenv("Platform");
        if (platform == null) {
            log.debug("Cant find Platform in System Variables. Taking from local config.");
            platform = Conf.getInstance().getProperty("platform");
        }

        version = System.getenv("Version_Chrome");
        if (version == null) {
            log.debug("Cant find Version_Chrome in System Variables. Taking from local config.");
            version = Conf.getInstance().getProperty("version");
        }

        version = System.getenv("Version_FireFox");
        if (version == null) {
            log.debug("Cant find Version_FireFox in System Variables. Taking from local config.");
            version = Conf.getInstance().getProperty("version");
        }

        version = System.getenv("Version_IE");
        if (version == null) {
            log.debug("Cant find Version_IE in System Variables. Taking from local config.");
            version = Conf.getInstance().getProperty("version");
        }

        screenResolution = System.getenv("Screen_Resolution");
        if (screenResolution == null) {
            log.debug("Cant find Screen_Resolution in System Variables. Taking from local config.");
            screenResolution = Conf.getInstance().getProperty("screenResolution");
        }

        parenttunnel = System.getenv("Parent_Tunnel");
        if (parenttunnel == null) {
            log.debug("Cant find Parent_Tunnel in System Variables. Taking from local config.");
            parenttunnel = Conf.getInstance().getProperty("parent-tunnel");
        }

        maxDuration = System.getenv("Max_Duration");
        if (maxDuration == null) {
            log.debug("Cant find Max_Duration in System Variables. Taking from local config.");
            maxDuration = Conf.getInstance().getProperty("maxDuration");
        }

        idleTimeout = System.getenv("Idle_Timeout");
        if (idleTimeout == null) {
            log.debug("Cant find Idle_Timeout in System Variables. Taking from local config.");
            idleTimeout = Conf.getInstance().getProperty("idleTimeout");
        }

        commandTimeout = System.getenv("Command_Timeout");
        if (commandTimeout == null) {
            log.debug("Cant find Command_Timeout in System Variables. Taking from local config.");
            commandTimeout = Conf.getInstance().getProperty("commandTimeout");
        }

        log.debug("Sauce_User: " + sauceUser + ", Sauce_Key: " + sauceKey.length() + ", Sauce_Tunnel: " + tunnel +
                ", Platform: " + platform + ", Version Chrome: " + version + ", Version FireFox: " + version +
                ", Version IE: " + version + ", Screen Resolution: " + screenResolution + ", Parent_Tunnel: " + parenttunnel +
                ", Max Duration: " + maxDuration + ", Idle Timeout: " + idleTimeout + ", Command_Timeout: " + commandTimeout);
    }
}
