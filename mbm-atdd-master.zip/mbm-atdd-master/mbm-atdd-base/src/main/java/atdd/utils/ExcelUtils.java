package atdd.utils;


import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.util.NumberToTextConverter;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ExcelUtils {

    /**
     * Given any excel sheet, read the Default Range as maps.
     * Convention of Default Range:
     * 1. It represents the left top range starting from A1.
     * 2. Header cells are in the first row: A1, B1, ..., until the last non-null cell
     * 3. Data rows starts from the second row: #2, #3, ..., until the last non-null row
     *
     * @param sheet
     * @return
     */
    public static List<Map<String, String>> asMaps(Sheet sheet) {
        List<Map<String, String>> result = new ArrayList<>();

        List<String> header = readHeader(sheet);
        if (header.size() <= 0) {
            throw new RuntimeException("Header row is empty.");
        }

        int rn = 1;
        Row row = sheet.getRow(rn++);
        while (null != row) {
            Map<String, String> rowMap = new LinkedHashMap<>();
            for (int i = 0; i < header.size(); i++) {
                Cell cell = row.getCell(i);
                if (null == cell) {
                    rowMap.put(header.get(i), "");
                } else {
                    try {
                        rowMap.put(header.get(i), cell.getStringCellValue().trim());
                    } catch (Exception e) {
                        String s = NumberToTextConverter.toText(cell.getNumericCellValue());
                        rowMap.put(header.get(i), s.trim());
                    }
                }
            }
            result.add(rowMap);
            row = sheet.getRow(rn++);
        }

        return result;
    }

    private static List<String> readHeader(Sheet sheet) {
        List<String> header = new ArrayList<>();

        Row row = sheet.getRow(0);
        int cn = 0;
        Cell cell = row.getCell(cn++);
        while (null != cell) {
            header.add(cell.getStringCellValue());
            cell = row.getCell(cn++);
        }

        return header;
    }
}
