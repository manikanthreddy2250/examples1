package atdd.utils;

public class InvalidLocatorException extends Exception {
    public InvalidLocatorException(String s) {
        super(s);
    }
}
