package atdd.utils;

import java.util.Map;

public class InvalidSearchCriteriaException extends StepSetException {
    public InvalidSearchCriteriaException(String message, Map<String, String> details) {
        super(message, details);
    }
}
