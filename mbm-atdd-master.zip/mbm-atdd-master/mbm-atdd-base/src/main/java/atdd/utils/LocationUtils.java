package atdd.utils;

import org.apache.log4j.Logger;
import org.openqa.selenium.*;

public class LocationUtils {

    public static final Logger log = Logger.getLogger(LocationUtils.class.getName());

    /**
     * Return true only if "left" element is at the left side of "right" element
     *
     * @param driver
     * @param left
     * @param right
     * @return
     */
    public static boolean leftRightSameRow(WebDriver driver, By left, By right) {
        int dis = horizontalDistanceInPixels(driver, left, right);
        log.warn("horizontalDistanceInPixels=" + dis);
        return dis >= -1;
    }

    /**
     * Return true only if "left" element is at the left side of "right" element
     *
     * @param driver
     * @param left
     * @param right
     * @return
     */
    public static int horizontalDistanceInPixels(WebDriver driver, By left, By right) {
        WebElement lel = driver.findElement(left);
        WebElement rel = driver.findElement(right);
        Point lelLocation = lel.getLocation();
        Dimension lelSize = lel.getSize();
        Point relLocation = rel.getLocation();
        Dimension relSize = rel.getSize();

        return relLocation.getX() - lelLocation.getX() - lelSize.getWidth();
    }

    /**
     * Return true only if "up" element is at the up side of "down" element
     *
     * @param driver
     * @param up
     * @param down
     * @return
     */
    public static boolean upDownSameColumn(WebDriver driver, By up, By down) {
        int dis = verticalDistanceInPixels(driver, up, down);
        log.warn("verticalDistanceInPixels=" + dis);
        return dis >= 0;
    }

    /**
     * Return the vertical distance in pixels between "up" and "down" element
     *
     * @param driver
     * @param up
     * @param down
     * @return
     */
    public static int verticalDistanceInPixels(WebDriver driver, By up, By down) {
        WebElement uel = driver.findElement(up);
        WebElement del = driver.findElement(down);
        Point uelLocation = uel.getLocation();
        Dimension uelSize = uel.getSize();
        Point delLocation = del.getLocation();
        Dimension delSize = del.getSize();

        return delLocation.getY() - uelLocation.getY() - uel.getSize().getHeight();
    }
}
