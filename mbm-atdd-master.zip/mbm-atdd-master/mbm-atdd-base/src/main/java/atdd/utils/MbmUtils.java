package atdd.utils;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

public class MbmUtils {

    /**
     * Immediate recover from a known popup.
     *
     * @return
     */
    public static boolean immediateRecover(WebDriver webDriver) {
        try {
            if (TestUtils.tryAccecpt(webDriver)) {
                return true;
            }
            String optumLogoXpath = "//img[@alt='United HealthCare Medical Benefit Management']";
            TestUtils.waitElementVisible(webDriver, optumLogoXpath);
            if (TestUtils.isElementVisible(webDriver, optumLogoXpath)) {
                TestUtils.click(webDriver, By.xpath(optumLogoXpath));
            }
            String globalMessageXbuttonsXpath = "//div[@id='globalMessages']//button";
            if (TestUtils.countElementsByXpath(webDriver, globalMessageXbuttonsXpath) > 0) {
                List<WebElement> xButtons = TestUtils.findElements(webDriver, globalMessageXbuttonsXpath);
                if (null != xButtons && xButtons.size() > 0) {
                    for (WebElement xButton : xButtons) {
                        try {
                            xButton.click();
                        } catch (Exception e) {
                            //do nothing
                        }
                    }
                    return true;
                }
            }
            String closeMessageXpath = "//button[@ng-click='closeMessage()']";
            if (TestUtils.isElementVisible(webDriver, closeMessageXpath)) {
                TestUtils.click(webDriver, By.xpath(closeMessageXpath));
            }
            String pendoCloseGuideXpath = "//button[text()='×']";
            if (TestUtils.isElementVisible(webDriver, pendoCloseGuideXpath)) {
                TestUtils.click(webDriver, By.xpath(pendoCloseGuideXpath));
            }
            String closePendoXpath = "//button[@class='_pendo-close-guide']";
            if (TestUtils.isElementVisible(webDriver, closePendoXpath)) {
                TestUtils.click(webDriver, By.xpath(closePendoXpath));
            }
            String dismissButtonXpath = "//button[.='Dismiss']";
            if (TestUtils.isElementVisible(webDriver, dismissButtonXpath)) {
                TestUtils.click(webDriver, By.xpath(dismissButtonXpath));
            }
            String termsOfUseCheckboxXpath = "//input[@ng-model='termsOfUseCheckbox']";
            if (TestUtils.isElementVisible(webDriver, termsOfUseCheckboxXpath)) {
                TestUtils.input(webDriver, By.xpath(termsOfUseCheckboxXpath), "true");
                TestUtils.click(webDriver, By.xpath("//input[@ng-model='termsOfUseCheckbox']/../../input[@value='Continue']"));
            } else {
                return false;
            }

            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
