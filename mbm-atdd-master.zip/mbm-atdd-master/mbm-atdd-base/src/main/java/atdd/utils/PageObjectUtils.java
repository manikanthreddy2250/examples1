package atdd.utils;

import atdd.test.core.ISearchable;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class PageObjectUtils {
    private final String packageName;

    public PageObjectUtils(String packageName) {
        this.packageName = packageName;
    }

    public Class getPageClass(String pageName) throws ClassNotFoundException {
        String pageObjectClassName = packageName + "." + pageName;
        Class pageObjectClass = Class.forName(pageObjectClassName);
        return pageObjectClass;
    }

    public By getLocator(String pageName, String locatorName) throws InvalidLocatorException {
        Object value = null;
        try {
            Class pageObjectClass = getPageClass(pageName);
            Field locatorField = pageObjectClass.getDeclaredField(locatorName);
            value = locatorField.get(null);
        } catch (ClassNotFoundException e) {
            throw new InvalidLocatorException("No such element: " + pageName);
        } catch (NoSuchFieldException e) {
            throw new InvalidLocatorException("No such element: " + locatorName);
        } catch (Exception e) {
            value = locatorName;
        }
        By by = null;
        if (value instanceof By) {
            by = (By) value;
        } else if (value instanceof String) {
            by = By.xpath((String) value);
        } else {
            throw new InvalidLocatorException("Unsupported locator type: " + value.getClass());
        }

        return by;
    }

    public String getXpath(String pageName, String xpathName) throws InvalidLocatorException {
        Object value = null;
        try {
            Class pageObjectClass = getPageClass(pageName);
            Field locatorField = pageObjectClass.getDeclaredField(xpathName);
            return (String) locatorField.get(null);
        } catch (ClassNotFoundException e) {
            throw new InvalidLocatorException("No such element: " + pageName);
        } catch (NoSuchFieldException e) {
            throw new InvalidLocatorException("No such element: " + xpathName);
        } catch (Exception e) {
            throw new InvalidLocatorException("Undefined xpath: " + xpathName + " on page: " + pageName);
        }
    }

    public By getLocator(String expression) throws InvalidLocatorException {
        try {
            int pos = expression.lastIndexOf('.');
            if (pos > 0) {
                String pageName = expression.substring(0, pos);
                String staticMemberName = expression.substring(pos + 1);
                return getLocator(pageName, staticMemberName);
            } else {
                return null;
            }
        } catch (Exception e) {
            throw new InvalidLocatorException(e.getMessage());
        }
    }

    public String getXpath(String expression) throws InvalidLocatorException {
        try {
            int pos = expression.lastIndexOf('.');
            String pageName = expression.substring(0, pos);
            String staticMemberName = expression.substring(pos + 1);
            return getXpath(pageName, staticMemberName);
        } catch (Exception e) {
            throw new InvalidLocatorException(e.getMessage());
        }
    }

    public By getLocator(String pageName, String locatorMethodName, Object[] args) throws InvalidLocatorException {
        Object value = null;
        try {
            Class pageObjectClass = getPageClass(pageName);

            Class<?>[] types = TestUtils.types(args);
            Method locatorMethod = pageObjectClass.getDeclaredMethod(locatorMethodName, types);
            value = locatorMethod.invoke(null, args);
        } catch (ClassNotFoundException e) {
            throw new InvalidLocatorException("No such page: " + pageName);
        } catch (NoSuchMethodException e) {
            throw new InvalidLocatorException("No such method: " + locatorMethodName);
        } catch (Exception e) {
            throw new InvalidLocatorException(e.getMessage());
        }
        if (value instanceof By) {
            return (By) value;
        } else if (value instanceof String) {
            return By.xpath((String) value);
        } else {
            throw new InvalidLocatorException("Unsupported locator type: " + value.getClass());
        }
    }

    public ISearchable newSearchable(String searchablePageName, WebDriver driver) {
        try {
            Class pageObjectClass = getPageClass(searchablePageName);
            Constructor constructor = pageObjectClass.getConstructor(WebDriver.class);
            return (ISearchable) constructor.newInstance(driver);
        } catch (ClassNotFoundException e) {
            Assert.fail("No such page: " + searchablePageName);
        } catch (Exception e) {
            Assert.fail("Invalid page: " + searchablePageName);
        }
        return null;
    }
}
