package atdd.utils;

import atdd.common.IORunnable;
import atdd.common.ImmediateAbortException;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.jayway.restassured.RestAssured.given;

public class QuickHttp {

    public static final Logger log = Logger.getLogger(QuickHttp.class.getName());

    public static Response http(String wsName, String payload0, String owner) {
        String payload = null;
        if (!StringUtils.isEmpty(payload0)) {
            payload = WhiteBoard.resolve(owner, payload0);
            payload = StringUtils.readOrReturn(payload);
            payload = WhiteBoard.resolve(owner, payload);
            if (StringUtils.isEmpty(payload0)) {
                throw new ImmediateAbortException("Invalid payload: " + payload0);
            }
        }
        log.warn("payload=" + payload);

        String endpoint = WhiteBoard.resolve(owner, Conf.getInstance().getProperty("endpoint_" + wsName));
        log.warn("endpoint=" + endpoint);

        String method = WhiteBoard.resolve(owner, Conf.getInstance().getProperty("method_" + wsName));
        log.warn("method=" + method);

        String sHeaders = Conf.getInstance().getProperty("headers_" + wsName);
        String[] headers = StringUtils.splitHeaders(sHeaders);
        headers = WhiteBoard.resolveArray(owner, headers);
        log.warn("headers=" + Arrays.asList(headers));

        TestUtils.tryWriteStringToFile(DateUtils.timestamp() + "_" + wsName + "_req.json", payload);
        Response response = http(endpoint, method, payload, headers);
        TestUtils.tryWriteStringToFile(DateUtils.timestamp() + "_" + wsName + "_res.json", null == response ? "" : response.asString());

        log.warn("response=" + response.asString());

        return response;
    }

    private static Response http(String endpoint, String method, String reqBodyString, String... headers) {

        if (headers.length % 2 == 1) {
            throw new RuntimeException("Invalid headers.");
        }

        List<String> in = new ArrayList<String>(headers.length + 3);
        in.add(endpoint);
        in.add(method);
        in.add(reqBodyString);
        in.addAll(Arrays.asList(headers));
        IORunnable<List<String>, Response> r = new IORunnable<List<String>, Response>(in) {

            @Override
            public void run() {
                List<String> in = this.getIutput();
                int i = 0;
                String endpoint = in.get(i++);
                String method = in.get(i++);
                String sBody = in.get(i++);

                RequestSpecification req = given();
                if (!StringUtils.isEmpty(sBody)) {
                    req.body(sBody);
                }

                while (i < in.size()) {
                    req = req.header(in.get(i++), in.get(i++));
                }

                Response res = null;
                try {
                    if (method.equalsIgnoreCase("get")) {
                        res = req.get(endpoint);
                    } else if (method.equalsIgnoreCase("post")) {
                            res = req.post(endpoint);
                    }else if (method.equalsIgnoreCase("put")) {
                        res = req.put(endpoint);
                    }
                    else if (method.equalsIgnoreCase("delete")) {
                        res = req.delete(endpoint);
                    } else {
                        throw new RuntimeException("Unsupported method: " + method);
                    }
                } catch (Exception e) {
                    throw new RuntimeException("Fall to call service: \r\n\t" + e.getMessage() + "\r\n\t" + in);
                } finally {
                    this.output = res;
                }

            }

        };

        Thread t = new Thread(r);
        t.start();


        try {
            t.join();
        } catch (InterruptedException e) {
            // do nothing
        }

        return r.getOutput();
    }

}
