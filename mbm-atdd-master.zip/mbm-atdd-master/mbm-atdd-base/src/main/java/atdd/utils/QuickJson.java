package atdd.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.*;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;

public class QuickJson {
    private static final Logger log = Logger.getLogger(QuickJson.class.getName());

    private final static ObjectMapper mapper = new ObjectMapper();

    private final static JsonParser jsonParser = new JsonParser();

    private final static Gson prettyGson = new GsonBuilder().setPrettyPrinting().create();
    private final static Gson onelineGson = new GsonBuilder().create();

    private final static String REGEX_REGULAR_JSON_1 = "\\s*\\{.*\\}\\s*";
    private final static String REGEX_REGULAR_JSON_2 = "\\s*\\[.*\\]\\s*";


    public static String prettyJson(String jsonString) {
        try {
            if (StringUtils.isEmpty(jsonString)) {
                return null;
            }
            if (!jsonString.matches(REGEX_REGULAR_JSON_1) && !jsonString.matches(REGEX_REGULAR_JSON_2)) {
                return null;
            }
            JsonElement jsonElement = jsonParser.parse(jsonString);
            String json = prettyGson.toJson(jsonElement);
            return json;
        } catch (Exception e) {
            log.warn(e.getMessage());
            return null;
        }
    }

    public static String onelineJson(String jsonString) {
        try {
            JsonElement jsonElement = jsonParser.parse(jsonString);
            String json = onelineGson.toJson(jsonElement);
            return json;
        } catch (Exception e) {
            log.warn(e.getMessage());
            return null;
        }
    }

    public static String prettyJson(Object o) {
        try {
            String json = mapper.writeValueAsString(o);
            return prettyJson(json);
        } catch (JsonProcessingException e) {
            log.warn(e.getMessage());
            return null;
        }
    }

    public static String onelineJson(Object o) {
        try {
            String json = mapper.writeValueAsString(o);
            return onelineJson(json);
        } catch (JsonProcessingException e) {
            log.warn(e.getMessage());
            return null;
        }
    }

    public static Object readValue(File file, Class<?> clazz) {
        try {
            return mapper.readValue(file, clazz);
        } catch (Exception e) {
            log.warn(e.getMessage());
            return null;
        }
    }

    public static Object readValue(String s, Class<?> clazz) {
        try {
            String jsonString = StringUtils.readOrReturn(s);
            return mapper.readValue(jsonString, clazz);
        } catch (Exception e) {
            log.warn(e.getMessage());
            return null;
        }
    }

    public static String writeValueAsString(Object obj) {
        try {
            return mapper.writeValueAsString(obj);
        } catch (Exception e) {
            log.warn(e.getMessage());
            return null;
        }
    }

    private static Object readValue(String s, TypeReference<?> typeReference) throws IOException {
        try {
            return mapper.readValue(new ByteArrayInputStream(s.getBytes()), typeReference);
        } catch (Exception e) {
            try {
                s = FileUtils.readFileToString(TestUtils.projectFile(s));
                return mapper.readValue(new ByteArrayInputStream(s.getBytes()), typeReference);
            } catch (Exception e1) {
                log.warn(e1.getMessage());
                return null;
            }
        }
    }

    public static List<Map<String, String>> readMaps(String s) throws IOException {
        return (List<Map<String, String>>) readValue(s, new TypeReference<List<Map<String, String>>>() {
        });
    }

    public static Map<String, String> readMap(String s, String... paths) throws IOException {
        if (0 == paths.length) {
            return (Map<String, String>) readValue(s, new TypeReference<Map<String, String>>() {
            });
        } else {
            for (String path : paths) {
                Map<String, String> map = (Map<String, String>) readValue(path + s, new TypeReference<Map<String, String>>() {
                });
                if (null != map) {
                    return map;
                }
            }
            return null;
        }
    }

    public static Object clone(Object o) {
        String json = writeValueAsString(o);
        Object oClone = readValue(json, o.getClass());
        return oClone;
    }

    public static Map<String, Map<String, String>> readNamedMaps(String s) throws IOException {
        return (Map<String, Map<String, String>>) readValue(s, new TypeReference<Map<String, Map<String, String>>>() {
        });
    }
}
