package atdd.utils;

import com.google.gson.JsonObject;
import com.rallydev.rest.RallyRestApi;
import com.rallydev.rest.request.CreateRequest;
import com.rallydev.rest.request.QueryRequest;
import com.rallydev.rest.response.CreateResponse;
import com.rallydev.rest.response.QueryResponse;
import com.rallydev.rest.util.Fetch;
import com.rallydev.rest.util.QueryFilter;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class RallyUtils {
    RallyRestApi restApi;
    public static final Logger log = Logger.getLogger(RallyUtils.class.getName());


    String workspaceRef = "UHG";//Workspace name


    private RallyRestApi createApiClient() throws URISyntaxException {
        RallyRestApi restApi = null;
        String host = Conf.getInstance().getProperty("Rally_Url");//"https://rally1.rallydev.com";
        String apikey = Conf.getInstance().getProperty("Apikey");
        String wsapiVersion = "v2.0";
        String applicationName = "TestCases";
        try {
            restApi = new RallyRestApi(new URI(host), apikey);
            restApi.setApplicationName(applicationName);
            restApi.setWsapiVersion(wsapiVersion);
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
        //Gets api key for authentication
       //Any name
        return restApi;
    }

    public boolean verifyforTestcaseInRally(String testcasename) throws URISyntaxException {
        boolean flag = false;
        restApi = createApiClient();
        try {
            QueryRequest testCaseRequest = new QueryRequest("TestCase");
            testCaseRequest.setFetch(new Fetch("FormattedID", "Name"));
            testCaseRequest.setQueryFilter(new QueryFilter("Name", "=", testcasename));
            QueryResponse testCaseQueryResponse = restApi.query(testCaseRequest);//search the rally for the existing testcase name
            if (testCaseQueryResponse.getTotalResultCount() > 0) {
                log.warn("Testcase is found in rally");
                flag = true;
            } else {
                log.info("Test Case did not find in Rally");
                flag = false;
            }
        } catch (Exception e) {
            log.error("Exception thrown; printing stack trace", e);
        }
        return flag;
    }

    public void UpdateTCStatusInRally(String testcasename, String ExecutionStatus, String build) throws URISyntaxException, IOException {
        restApi = createApiClient();

        try {
            QueryRequest testCaseRequest = new QueryRequest("TestCase");
            testCaseRequest.setFetch(new Fetch("FormattedID", "Name", "Workspace"));
            testCaseRequest.setWorkspace(workspaceRef);
            testCaseRequest.setQueryFilter(new QueryFilter("Name", "=", testcasename));
            QueryResponse testCaseQueryResponse = restApi.query(testCaseRequest);
            String testCaseRef = testCaseQueryResponse.getResults().get(0).getAsJsonObject().get("_ref").getAsString();
            JsonObject newTestCaseResult = new JsonObject();
            JsonObject response = new JsonObject();
            newTestCaseResult.addProperty("Verdict", ExecutionStatus);
            Date date = new Date();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
            String timestamp = sdf.format(date);
            newTestCaseResult.addProperty("Date", timestamp);
            newTestCaseResult.addProperty("Build", build);
            newTestCaseResult.addProperty("Notes", "ATDD Test case Execution -- iFrame 2.0 " + timestamp);
            newTestCaseResult.addProperty("TestCase", testCaseRef);
            CreateRequest createRequest = new CreateRequest("testcaseresult", newTestCaseResult);
            CreateResponse createResponse = restApi.create(createRequest);
            restApi.close();
        } catch (Exception e) {
            System.out.println(e);
        }

    }


    public String getUserStoryFromRally(String workItem, String testcasename) {
        String workITemRef = "";
        String testCaseDescription;
        String testCaseGroups;
        try {
            QueryRequest workItemRequest = null;
            String USorDE = null;
            if (workItem != null && !(workItem.isEmpty())) {
                if (workItem.length() > 2) {
                    // log.info("running...");
                    USorDE = workItem.substring(0, Math.min(workItem.length(), 2));
                }

                if (USorDE.equalsIgnoreCase("US")) {
                    workItemRequest = new QueryRequest("HierarchicalRequirement");
                } else if (USorDE.equalsIgnoreCase("DE")) {
                    workItemRequest = new QueryRequest("defect");
                }

                workItemRequest.setFetch(new Fetch("FormattedID", "Name", "Workspaces"));
                workItemRequest.setQueryFilter(new QueryFilter("FormattedID", "=", workItem));
                QueryResponse userStoryQueryResponse = restApi.query(workItemRequest);
                if (userStoryQueryResponse.getTotalResultCount() > 0) {
                    JsonObject userStoryJsonObject = userStoryQueryResponse.getResults().get(0).getAsJsonObject();
                    log.info("WorkItem object: " + userStoryJsonObject);
                    String userStoryUrl = userStoryQueryResponse.getResults().get(0).getAsJsonObject().get("_ref")
                            .getAsString();
                    workITemRef = userStoryUrl.substring(userStoryUrl.lastIndexOf("/") + 1, userStoryUrl.length());
                    // log.info("user story ObjectId : " +
                    // userStoryRef);
                } else {

                    log.info("US/DE could not be found in Rally");
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        }

        return workITemRef;
    }

    public void createNewTestCase(String testcasename, String userstoryRef, String testCaseDescription, String testFolderRef) {

        try {
            // Create test case
            JsonObject newTestCase = new JsonObject();
            newTestCase.addProperty("Name", testcasename);
            if (testCaseDescription != null) {
                if (testCaseDescription.isEmpty()) {
                    newTestCase.addProperty("Description", "Created by Product Master automation");
                } else {
                    newTestCase.addProperty("Description", testCaseDescription);
                }
            } else {
                newTestCase.addProperty("Description", "Created by Product Master automation");
            }
            newTestCase.addProperty("Project", "239193921780");
            newTestCase.addProperty("Type", "Functional");
            newTestCase.addProperty("Method", "Automated");
            newTestCase.addProperty("DefectStatus", "NONE");
//          newTestCase.addProperty("TestFolder", getTestFolderOID(testFolderRef));
            newTestCase.addProperty("WorkProduct", userstoryRef);
            CreateRequest createRequest = new CreateRequest("testcase", newTestCase);
            CreateResponse createResponse = restApi.create(createRequest);
            /*
             * checks if testcase was succesfully created if fails, return error
             */
            if (createResponse.wasSuccessful()) {
                log.info("Test case created successfully");
            } else {
                log.info("The test case could not be created");
                String[] createErrors;
                createErrors = createResponse.getErrors();
                log.info("Error occurred creating Test Case: ");
                for (int i = 0; i < createErrors.length; i++) {
                    log.info(createErrors[i]);
                }
            }

        } catch (Exception e) {
            log.error("Exception thrown; printing stack trace", e);
        }

    }

    private String getTestFolderOID(String testFolderRef) throws URISyntaxException {
        restApi = createApiClient();
        String testSetOID = "";

        try {
            // fetch testfolder from rally by 'TestFolderName'
            QueryRequest TestSetQuery = new QueryRequest("TestFolder");
            TestSetQuery.setFetch(new Fetch("FormattedID", "Name"));
            TestSetQuery.setQueryFilter(new QueryFilter("Name", "=", testFolderRef));
            QueryResponse TestSetResultResponse = restApi.query(TestSetQuery);

            /*
             * if query returns expected testset then set the variable
             * 'testSetOID' if false, returns empty string
             */
            if (TestSetResultResponse.wasSuccessful()) {
                if (TestSetResultResponse.getResults().size() > 0) {
                    JsonObject testSetJsonObject = TestSetResultResponse.getResults().get(0).getAsJsonObject();
                    System.out.println("Test Set Object: " + testSetJsonObject);
                    String testSetUrl = TestSetResultResponse.getResults().get(0).getAsJsonObject().get("_ref")
                            .getAsString();
                    testSetOID = testSetUrl.substring(testSetUrl.lastIndexOf("/") + 1, testSetUrl.length());
                    System.out.println("testSetOID: " + testSetOID);
                }
            } else {
                testSetOID = "";
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return testSetOID;
    }

    public void createTestCaseinTestFolder(String testFolder, String testCaseName) throws IOException, URISyntaxException {
        String testFolderOID;
        String testCaseDescription = "";
        restApi = createApiClient();
        try {
            // Create test case
            JsonObject newTestCase = new JsonObject();
            newTestCase.addProperty("Name", testCaseName);
            if (testCaseDescription != null) {
                if (testCaseDescription.isEmpty()) {
                    newTestCase.addProperty("Description", "Created by Product Master automation");
                } else {
                    newTestCase.addProperty("Description", testCaseDescription);
                }
            } else {
                newTestCase.addProperty("Description", "Created by Product Master automation");
            }
            newTestCase.addProperty("Project", "210062121384");
            newTestCase.addProperty("Type", "Functional");
            newTestCase.addProperty("Method", "Automated");
            newTestCase.addProperty("DefectStatus", "NONE");
            newTestCase.addProperty("TestFolder", getTestFolderOID(testFolder));
            CreateRequest createRequest = new CreateRequest("testcase", newTestCase);
            CreateResponse createResponse = restApi.create(createRequest);
            /*
             * checks if testcase was succesfully created if fails, return error
             */
            if (createResponse.wasSuccessful()) {
                log.info("Test case created successfully");
            } else {
                log.info("The test case could not be created");
                String[] createErrors;
                createErrors = createResponse.getErrors();
                log.info("Error occurred creating Test Case: ");
                for (int i = 0; i < createErrors.length; i++) {
                    log.info(createErrors[i]);
                }


            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        restApi.close();
    }

    public boolean createTestFolder(String testFolderName, String parentFolder) throws URISyntaxException, IOException {
        restApi = createApiClient();
        boolean flag = false;
        try {
            // Create test Folder
            JsonObject newTestFolder = new JsonObject();
            newTestFolder.addProperty("Name", testFolderName);
            newTestFolder.addProperty("Project", "210062121384");
            newTestFolder.addProperty("Parent", getTestFolderOID(parentFolder));
            log.info("Project ------------------------- " + restApi.getClient());
            CreateRequest createRequest = new CreateRequest("TestFolder", newTestFolder);
            restApi.setApplicationName("TestFolder");
            CreateResponse createResponse = restApi.create(createRequest);
            if (createResponse.wasSuccessful()) {
                log.warn("Test Folder is created in rally");
                flag = true;
            } else {
                log.info("Test Folder did not created in Rally");
                flag = false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        restApi.close();
        return flag;
    }

    public boolean verifyTestFolderInRally(String testFolderName) throws URISyntaxException {
        boolean flag = false;
        restApi = createApiClient();
        try {
            QueryRequest testCaseRequest = new QueryRequest("TestFolder");
            testCaseRequest.setFetch(new Fetch("FormattedID", "Name", "TestFolder"));
            testCaseRequest.setQueryFilter(new QueryFilter("Name", "=", testFolderName));
            QueryResponse testCaseQueryResponse = restApi.query(testCaseRequest);
            if (testCaseQueryResponse.getTotalResultCount() > 0) {
                log.warn("Test Folder is found in rally");
                flag = true;
            } else {
                log.info("Test Folder is not found in Rally");
                flag = false;
            }
        } catch (Exception e) {
            log.error("Exception thrown; printing stack trace", e);
        }
        return flag;
    }

    public String scenarioStatus(String status) {
        String Status = status.substring(0, 4);
        Status = Status.substring(0, 1).toUpperCase() + Status.substring(1).toLowerCase();
        return Status;
    }

    public String buildVersion(String Build) {
        String currentBuild = Build.substring(0, Build.indexOf("(")).trim();
        return currentBuild;
    }


    public void updateRallyWithResult(String featureName, String testFolderName, String status, String build, String testCaseName) throws URISyntaxException, IOException {
        if (!(verifyTestFolderInRally(featureName))) {
            createTestFolder(featureName, testFolderName);
        }
        if (!(verifyforTestcaseInRally(testCaseName))) {
            createTestCaseinTestFolder(featureName, testCaseName);
        }
        UpdateTCStatusInRally(testCaseName, status, build);
    }

    public void updateRallyWithResultSmoke(String testFolderName, String status, String build, String testCaseName) throws URISyntaxException, IOException {

            if (!(verifyTestFolderInRally(testFolderName))) {
                createTestFolder(testFolderName, "Smoke_Suite");
            }
            if (!(verifyforTestcaseInRally(testCaseName))) {
                createTestCaseinTestFolder(testFolderName, testCaseName);
            }
            UpdateTCStatusInRally(testCaseName, status, build);

        }
    }
