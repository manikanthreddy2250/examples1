package atdd.utils;

import atdd.test.core.AbstractStepSet;
import com.jayway.restassured.response.Response;
import cucumber.api.Scenario;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.WebDriver;

import java.util.Set;

public class RestUtility extends AbstractStepSet {

    private static final String SESSION_KEY = "session";
    private static final String SUBSCRIBER_ID_KEY = "subscriberId";
    private static final String HSC_ID_KEY = "hscId";
    private static final String PRIMARY_SRN_KEY = "primarySRN";
    private static final String COOKIE_KEY = "Cookie";

    /**
     * Constructor
     * Optional webDriver for refresh service calls
     *
     * @param scenario
     * @param webDriver
     */
    public RestUtility(Scenario scenario, WebDriver webDriver) {
        super(scenario, webDriver);
        String host = Conf.getInstance().getProperty(Conf.TEST_HOST_KEY);
        WhiteBoard.getInstance().putString(getOwner(), "host", host);
    }

    /**
     * Call resend service for specified hscId
     *
     * @param hscId
     * @return
     */
    public String resend(String hscId) {
        Set<Cookie> cookies = driver().manage().getCookies();
        String stringCookie = "";
        for (Cookie cookie : cookies) {
            stringCookie += cookie.toString() + "; ";
        }
        WhiteBoard.getInstance().putString(getOwner(), COOKIE_KEY, stringCookie);
        WhiteBoard.getInstance().putString(getOwner(), HSC_ID_KEY, hscId);

        Response res = QuickHttp.http("resend", "{}", getOwner());

        return res.body().asString();
    }

    /**
     * Call member query service for specified subscriberId.
     *
     * @param subscriberId
     * @return
     */
    public String memberQuery(String subscriberId) {
        Cookie jSessionId = driver().manage().getCookieNamed("JSESSIONID");
        WhiteBoard.getInstance().putString(getOwner(), SESSION_KEY, jSessionId.getValue());
        String fn = Conf.getInstance().getProperty("payload_template_member_query");
        WhiteBoard.getInstance().putString(getOwner(), SUBSCRIBER_ID_KEY, subscriberId);

        Response res = QuickHttp.http("member_query", fn, getOwner());

        return res.body().asString();
    }

    /**
     * Call refresh service for specified SRN and hscId
     *
     * @param primarySRN
     * @param hscId
     * @return
     */
    public String refresh(String primarySRN, String hscId) {
        WhiteBoard.getInstance().putString(getOwner(), PRIMARY_SRN_KEY, primarySRN);
        WhiteBoard.getInstance().putString(getOwner(), HSC_ID_KEY, hscId);

        Response res = QuickHttp.http("refresh", null, getOwner());

        return res.body().asString();
    }
}
