package atdd.utils;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;

import java.util.List;

public class SizzleSelector {
    public SizzleSelector() {
    }

    public static WebElement findElementByCss(WebDriver driver, String using) {
        injectSizzleIfNeeded(driver);
        String javascriptExpression = createSizzleSelectorExpression(using);
        List<WebElement> elements = (List)((JavascriptExecutor)driver).executeScript(javascriptExpression, new Object[0]);
        return elements.size() > 0 ? elements.get(0) : null;
    }

    public static List<WebElement> findElementsByCss(WebDriver driver, String using) {
        injectSizzleIfNeeded(driver);
        String javascriptExpression = createSizzleSelectorExpression(using);
        return (List)((JavascriptExecutor)driver).executeScript(javascriptExpression, new Object[0]);
    }

    private static String createSizzleSelectorExpression(String using) {
        return "return Sizzle(\"" + using + "\")";
    }

    private static void injectSizzleIfNeeded(WebDriver driver) {
        if (!sizzleLoaded(driver)) {
            injectSizzle(driver);
        }

    }

    public static Boolean sizzleLoaded(WebDriver driver) {
        Boolean loaded;
        try {
            loaded = (Boolean)((JavascriptExecutor)driver).executeScript("return Sizzle()!=null", new Object[0]);
        } catch (WebDriverException var3) {
            loaded = false;
        }

        return loaded;
    }

    public static void injectSizzle(WebDriver driver) {
        ((JavascriptExecutor)driver).executeScript(" var headID = document.getElementsByTagName('head')[0];var newScript = document.createElement('script');newScript.type = 'text/javascript';newScript.src = 'https://raw.githubusercontent.com/jquery/sizzle/master/src/sizzle.js';headID.appendChild(newScript);");
    }
}
