package atdd.utils;

public class StopAtPageBeginException extends Exception {
    public StopAtPageBeginException(String pageName) {
        super(TestUtils.shortName(pageName));
    }
}
