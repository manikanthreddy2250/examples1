package atdd.utils;

public class StopAtPageException extends Exception {
    public StopAtPageException(String pageName) {
        super(TestUtils.shortName(pageName));
    }
}

