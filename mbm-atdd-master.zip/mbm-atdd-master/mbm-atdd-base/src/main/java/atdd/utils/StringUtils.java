package atdd.utils;

import org.apache.commons.io.FileUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class StringUtils {

    private final static Random r = new Random(System.currentTimeMillis());

    public static String padRight(String s, int n, char c) {
        return String.format("%-" + n + "s", s).replace(' ', c);
    }

    public static String padLeft(String s, int n, char c) {
        return String.format("%" + n + "s", s).replace(' ', c);
    }

    private static final String[][] PEEL_WRAPPERS = {{"{", "}"}, {"[", "]"}, {"(", ")"}, {"\"", "\""},
            {"'", "'"}, {"-", "-"}};

    public static String randomDigits(int l) {
        String s = "" + (Math.abs(r.nextLong()));
        if (s.length() > l) {
            return s.substring(0, l);
        } else {
            return StringUtils.padLeft(s, l, '0');
        }
    }

    /**
     * Take the parameter as a text file name and return the content if success.
     * Return the parameter itself if the above try throws any exception.
     *
     * @param stringOrFile
     * @return
     */
    public static String readOrReturn(String stringOrFile) {
        if (StringUtils.isEmpty(stringOrFile)) {
            return stringOrFile;
        }
        try {
            return FileUtils.readFileToString(TestUtils.projectFile(stringOrFile));
        } catch (Exception e) {
            return stringOrFile;
        }
    }

    /**
     * Split a raw header text in below format:
     * Content-Type:application/json; charset=UTF-8
     * Authorization:Bearer XXXXXXX
     * Version:1.0
     * <p>
     * into an array like this:
     * ["Content-Type", "application/json; charset=UTF-8", "Authorization", "Bearer XXXXXXX", "Version", "1.0"]
     *
     * @param rawHeaders
     * @return
     */
    public static String[] splitHeaders(String rawHeaders) {
        rawHeaders = readOrReturn(rawHeaders);
        List<String> h = new ArrayList<>();
        Scanner scanner = new Scanner(rawHeaders);
        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            String[] p = line.split(":");
            if (2 != p.length) {
                throw new RuntimeException("Missing \":\" in line: " + line);
            }
            h.add(p[0]);
            h.add(p[1]);
        }
        String[] headers = new String[h.size()];
        headers = h.toArray(headers);
        return headers;
    }

    /**
     * Append all strings in array ss to the original string s0.
     * Concatenated by the specified delimiter
     *
     * @param s0
     * @param delimiter
     * @param ss
     * @return
     */
    public static String append(String s0, String delimiter, String... ss) {
        if (StringUtils.isEmpty(s0)) {
            s0 = "";
        }
        s0 = s0.trim();
        if (StringUtils.isEmpty(delimiter)) {
            delimiter = "";
        }
        delimiter = delimiter.trim();

        for (String s : ss) {
            if (!StringUtils.isEmpty(s)) {
                s0 += delimiter + s;
            }
        }
        return s0;
    }

    /**
     * Parse Integer object from a String object without throwing exception.
     * A null Integer will be returned at any exception.
     *
     * @param s
     * @return
     */
    public static Integer tryParseIntOrNull(String s) {
        try {
            return Integer.parseInt(s.trim());
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Parse Integer object from a String object without throwing exception.
     * A "0" Integer will be returned at any exception.
     *
     * @param s
     * @return
     */
    public static Integer tryParseIntOrZero(String s) {
        try {
            return Integer.parseInt(s.trim());
        } catch (Exception e) {
            return 0;
        }
    }

    /**
     * Parse Double object from a String object without throwing exception.
     * A null Double will be returned at any exception.
     *
     * @param s
     * @return
     */
    public static Double tryParseDoubleOrNull(String s) {
        try {
            return Double.parseDouble(s.trim());
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Parse Double object from a String object without throwing exception.
     * A "0" Double will be returned at any exception.
     *
     * @param s
     * @return
     */
    public static Double tryParseDoubleOrZero(String s) {
        try {
            return Double.parseDouble(s.trim());
        } catch (Exception e) {
            return 0d;
        }
    }

    public static String peel(String raw) {
        if (null == raw) {
            return null;
        }
        raw = raw.trim();
        String[] wrapper = outerWrapper(raw);
        while (null != wrapper) {
            raw = peelOne(raw, wrapper);
            wrapper = outerWrapper(raw);
        }

        return raw;
    }

    public static String peel(String raw, String... pair) {
        if (1 == pair.length) {
            return peelOne(raw, new String[]{pair[0], pair[0]});
        } else if (2 == pair.length) {
            return peelOne(raw, pair);
        } else {
            return raw;
        }
    }

    private static String peelOne(String raw, String[] wrapper) {
        if (peelable(raw, wrapper)) {
            return raw.substring(wrapper[0].length(), raw.length() - wrapper[0].length() - wrapper[1].length() + 1).trim();
        } else {
            return raw;
        }
    }

    private static String[] outerWrapper(String raw) {
        if (null == raw) {
            return null;
        }
        for (String[] wrapper : PEEL_WRAPPERS) {
            if (peelable(raw, wrapper)) {
                return wrapper;
            }
        }
        return null;
    }

    private static boolean peelable(String raw, String[] wrapper) {
        return raw.length() >= wrapper[0].length() + wrapper[1].length()
                && raw.startsWith(wrapper[0]) && raw.endsWith(wrapper[1]);
    }

    /**
     * Return true only when s is either of null, "" or "-"
     *
     * @param s
     * @return
     */
    public static boolean isEmpty(String s) {
        return null == s || s.trim().isEmpty() || s.trim().matches("-*");
    }
}
