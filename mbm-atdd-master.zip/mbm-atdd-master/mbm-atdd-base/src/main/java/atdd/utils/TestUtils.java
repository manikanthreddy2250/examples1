package atdd.utils;

import atdd.common.*;
import atdd.common.ui.Editable;
import atdd.common.ui.EditableFactory;
import atdd.common.ui.SlowBy;
import atdd.test.shared.BaseCucumber;
import com.assertthat.selenium_shutterbug.core.Shutterbug;
import com.assertthat.selenium_shutterbug.utils.web.ScrollStrategy;
import com.paulhammant.ngwebdriver.NgWebDriver;
import cucumber.api.DataTable;
import cucumber.api.Scenario;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.joda.time.LocalDate;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.LocalFileDetector;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;


public class TestUtils {
    public static final String CROP_XPATH_KEY = "cropXpath";
    public static final String HIDE_XPATH_KEY = "hideXpath";
    public static final String POPUP_XPATH = "popup_xpath";
    public static final String STICKY_HEADER_XPATH = "sitcky_header_xpath";
    public static final String PENDO_BADGES_XPATH = "pendo_badges_xpath";

    private static WebDriver driver() {
        return BaseCucumber.driver;
    }

    private static final Logger log = Logger.getLogger(TestUtils.class.getName());

    public static String getSectionTableXpath(WebDriver d, String sectionHeader) {
        String tableXpath = "//div[./div/h1[.='" + sectionHeader + "']]/table";
        if (isElementVisible(d, tableXpath)) {
            return tableXpath;
        }
        tableXpath = "//div[./h1[.='" + sectionHeader + "']]/form/table";
        if (isElementVisible(d, tableXpath)) {
            return tableXpath;
        }
        tableXpath = "//div[./div/span/span/h4[.='" + sectionHeader + "']]/form/table";
        if (isElementVisible(d, tableXpath)) {
            return tableXpath;
        }
        tableXpath = "//table[./tbody/tr/td['" + sectionHeader + "' = substring(normalize-space(), string-length(normalize-space()) - string-length('" + sectionHeader + "') + 1, string-length('" + sectionHeader + "'))]]/following-sibling::table";
        if (isElementVisible(d, tableXpath)) {
            return tableXpath;
        }
        return null;
    }

    /**
     * Helping method for stepsets.
     *
     * @param txt
     * @return
     */
    public static boolean checkNullOrDash(String txt) {
        if (txt == null) return true;
        else return txt.trim().equals("-");
    }


    /**
     * Adding text to existing file. Or creating new if it doesn't exests
     *
     * @param pathToFolder
     * @param inputTxt
     */
    public static void addingTxtToFile(String pathToFolder, String fileName, String inputTxt) {

        //Create a folder if doesn't exists
        boolean folderExists = new File(pathToFolder).exists();
        if (!folderExists) {
            new File(pathToFolder).mkdir();
        }

        String path = pathToFolder + fileName;

        try {
            log.debug("Adding txt to " + path + " file");
            FileWriter outFile = new FileWriter(path, true);
            PrintWriter out = new PrintWriter(outFile);
            out.write(inputTxt);
            out.close();
        } catch (IOException e) {
            e.printStackTrace();
            log.error("Failed saving txt to file");
        }
    }

    /**
     * Waiting. Param is in seconds.
     *
     * @param sec
     */
    public static void wait(int sec) {
        if (sec <= 0) {
            return;
        }
        try {
            Thread.sleep(1000 * sec);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    /**
     * Log and wait.
     *
     * @param message
     * @param sec
     */
    public static void wait(String message, int sec) {
        log.warn(message);
        wait(sec);
    }

    /**
     * Waitig. Param is in milliseconds.
     *
     * @param milliseconds
     */
    public static void sleep(long milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    /**
     * Deleting file by path + filename
     *
     * @param pathToFileAndName
     */
    public static void deleteFile(String pathToFileAndName) {

        try {
            log.debug("Deleting old file..");
            File txt = new File(pathToFileAndName);
            if (txt.exists()) {
                txt.delete();
                log.debug("File deleted " + pathToFileAndName);
            } else log.debug("file: " + pathToFileAndName + " does not exists");
        } catch (Exception x) {
            log.error("Fail. Deleting old file..");
        }
    }

    /**
     * Generic: Accessibility test of current page. Saves info in to file
     *
     * @param pathToFile
     */
    public static void aXeTestAccessibility(WebDriver driver, String pathToFile, String fileName) {

        String currUrl = driver.getCurrentUrl();
        String currTitle = driver.getTitle();

        log.warn("Perform aXe web accessibility test on: " + currUrl + " With title: " + currTitle);

        //URL scriptUrl = TestUtils.class.getResource("/axe.min.js");
        //URL scriptUrl = new URL("http://example.com/pages/");
        URL scriptUrl = null;

        //Getting axe.min.js
        String userdir = System.getProperty("user.dir");
        try {
            scriptUrl = new File(userdir + "/src/main/resources/axe.min.js").toURI().toURL();
        } catch (MalformedURLException e) {
            log.error("Can't find axe.min.js by path: " + userdir + "/src/main/resources/axe.min.js");
            e.printStackTrace();
        }

        JSONObject responseJSON = new AXE.Builder(driver, scriptUrl).analyze();

        JSONArray violations = responseJSON.getJSONArray("violations");


        if (violations.length() == 0) {
            log.warn("No violations found");
        } else {
            log.warn("Violations found!!!");
            AXE.writeResults("aXe test", responseJSON);

            String out = "\n\n-------------------------------------------\n" +
                    "URL:\n" +
                    currUrl +
                    "\n----------------\n" +
                    "Titile:\n" +
                    currTitle +
                    "\n----------------\n" +
                    AXE.report(violations) +
                    "\n-------------------------------------------\n";

            log.error(out);
            //Saving to file
            addingTxtToFile(pathToFile, fileName, out);
        }
    }

    /**
     * Generic: Saving URL and HTML page source in to a file by path
     *
     * @param path
     * @param fileName
     */
    public static void safeHTMLsoureCode(WebDriver driver, String path, String fileName) {

        String source = driver.getPageSource();
        String title = driver.getTitle().replace(" ", "_");

        //Create a folder if doesn't exists
        boolean folderExists = new File(path).exists();
        if (!folderExists) {
            new File(path).mkdir();
        }

        path = path + title + fileName + ".html";

        deleteFile(path);

        try {
            log.warn("Creating new file");
            FileWriter outFile = new FileWriter(path, true);
            PrintWriter out = new PrintWriter(outFile);
            out.flush();
            out.write(source);
            out.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        log.warn("HTML saved to: " + path);
    }

    /**
     * Wait until this element will be present for 60 seconds with 1 sec period
     *
     * @param element - WebElement
     */
    public static boolean waitElement(WebElement element) {
        return new WaitUntil("Waiting for element " + element + " not visible... ", new ICondition() {
            @Override
            public boolean evaluate() throws Exception {
                return isElementPresent(element);
            }
        }).execute();
    }

    /**
     * Wait until this element will be present for 60 seconds with 1 sec period
     *
     * @param element - WebElement
     */
    public static boolean waitElement(WebDriver d, WebElement element) {
        return new WaitUntil("Waiting for element " + element + " not visible... ", new ICondition() {
            @Override
            public boolean evaluate() throws Exception {
                return isElementPresent(element);
            }
        }).execute();
    }

    /**
     * Wait until this element will be present for 60 seconds with 1 sec period.
     * Will highlight element
     *
     * @param by - Locator
     * @throws Exception
     */
    public static boolean waitElement(WebDriver d, By by) {
        return new WaitUntil("Waiting for element " + by + " not visible... ", new ICondition() {
            @Override
            public boolean evaluate() throws Exception {
                return isElementPresent(d.findElement(by));
            }
        }).execute();
    }

    /**
     * Wait until this element will be present for expected number seconds with 1 sec period
     *
     * @param by - Locator
     * @throws Exception
     */
    public static boolean waitElement(WebDriver d, By by, int sec) throws Exception {
        return new WaitUntil("Waiting for element " + by + " not visible... ", sec * 1000, 1000, 0,
                new ICondition() {
                    @Override
                    public boolean evaluate() throws Exception {
                        return isElementPresent(d.findElement(by));
                    }
                }
        ).execute();
    }

    /**
     * Wait until this element will be not present for 60 seconds with 1 sec period
     *
     * @param element
     * @return
     */
    public static boolean waitNotElement(WebDriver d, WebElement element) {
        return new WaitUntil("Waiting for element " + element + " not visible... ", new ICondition() {
            @Override
            public boolean evaluate() throws Exception {
                return !isElementPresent(element);
            }
        }).execute();
    }

    /**
     * Wait until this element will be not present with 1 sec period
     *
     * @param by
     * @param seconds - seconds to wait
     * @return
     */
    public static boolean waitNotElement(WebDriver d, By by, int seconds) {
        return new WaitUntil("Waiting for element " + by + " not visible... ",
                seconds * 1000, 1000, 1000,
                new ICondition() {
                    @Override
                    public boolean evaluate() throws Exception {
                        return !isElementPresent(d.findElement(by));
                    }
                }
        ).execute();
    }

    /**
     * Getting item from Browser Local storage by key
     *
     * @param key
     * @return
     */
    public static String getItemFromLocalStorage(WebDriver d, String key) {
        JavascriptExecutor js = (JavascriptExecutor) d;
        String tmp = d.getTitle();
        Long outputLen = (Long) js.executeScript(String.format("return window.localStorage.length;"));
        String output = (String) js.executeScript(String.format("return window.localStorage.getItem('%s');", key));

        return output;
    }

    /**
     * Checking for visibility of element
     *
     * @param element - WebElement
     * @return boolean
     */
    public static boolean isElementPresent(WebElement element) {
        return element.isDisplayed();
    }

    /**
     * Check that array of String is sorted
     *
     * @param arraylist
     * @return
     */
    public static boolean checkSorting(ArrayList<String> arraylist) {
        boolean isSorted = true;
        for (int i = 1; i < arraylist.size(); i++) {
            if (arraylist.get(i - 1).compareTo(arraylist.get(i)) > 0) {
                isSorted = false;
                break;
            }
        }
        return isSorted;
    }

    /**
     * Checking for visibility of element
     *
     * @param by - Locator
     * @return boolean
     */
    public static boolean isElementPresent(WebDriver d, By by) {
        return isElementVisible(d, by);
    }

    /**
     * wait until element to be clicked
     *
     * @param webElem
     */
    public static void explicitClickAbleWait(WebDriver d, By webElem) {
        (new WebDriverWait(d, 30L)).until(ExpectedConditions.elementToBeClickable(webElem));
    }

    /**
     * wait until Text is displayed
     *
     * @param by
     * @param text
     */
    public static String waitUntilTextIsDisplay(WebDriver d, By by, String text) {
        (new WebDriverWait(d, 30L)).until(ExpectedConditions.textToBePresentInElementLocated(by, text));
        return d.findElement(by).getText();
    }

    /**
     * Selecting by Visible Text
     *
     * @param elem,str
     */
    public static void selectByVisibleText(WebElement elem, String str) {
        try {
            Select dr = new Select(elem);
            dr.selectByVisibleText(str);
        } catch (NoSuchElementException var3) {
            log.info("Element Not Found" + elem + "| Error - " + var3);
        }
    }

    /**
     * Selecting by Visible Text
     *
     * @param elem,str
     */
    public static void selectByVisibleText(WebDriver d, By elem, String str) {
        waitElement(d, elem);
        WebElement byElem = d.findElement(elem);

        try {
            Select dr = new Select(byElem);
            dr.selectByVisibleText(str);
        } catch (NoSuchElementException var3) {
            log.info("Element Not Found" + elem + "| Error - " + var3);
        }
    }

    /**
     * Getting todays date format
     *
     * @param
     */
    public static String getTodayDate() {
        DateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy");
        Date date = new Date();
        Calendar c = Calendar.getInstance();
        return dateFormat.format(c.getTime());

    }

    /**
     * Getting Futures date format
     *
     * @param daysAfterToday
     */
    public static String getFutureDate(int daysAfterToday) {
        DateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy");
        Date date = new Date();
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(5, daysAfterToday);
        return dateFormat.format(c.getTime());
    }

    /**
     * Getting past date from given date
     *
     * @param dateValue, daysAfterToday
     */

    public static String getPastDateFromGivenDate(String dateValue, int daysAfterToday) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy");
        Calendar c = Calendar.getInstance();
        c.setTime(sdf.parse(dateValue));
        c.add(5, -daysAfterToday);
        return sdf.format(c.getTime());
    }

    /**
     * validating drop down
     *
     * @param actual, elementsFromDropDown
     */
    public static void validateDropDownOptions(List<String> actual, List<WebElement> elementsFromDropDown) {
        Assert.assertEquals(actual.size(), elementsFromDropDown.size());

        for (int i = 0; i < elementsFromDropDown.size(); ++i) {
            Assert.assertEquals(actual.get(i).trim(), elementsFromDropDown.get(i).getText());
        }

    }

    /**
     * validating drop down using data Table
     *
     * @param actual, elementsFromDropDown , index
     */
    public static void validateDropDownOptionsUsingDataTable(List<List<String>> actual, List<WebElement> elementsFromDropDown, int index) {
        Assert.assertEquals(actual.size(), elementsFromDropDown.size());

        for (int i = 1; i < elementsFromDropDown.size(); ++i) {
            Assert.assertEquals(((String) ((List) actual.get(i)).get(index)).trim(), elementsFromDropDown.get(i).getText());
        }

    }

    /**
     * Getting current date Time stamp
     *
     * @param
     */
    public static String getCurrentTimeStamp() {
        return (new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss")).format(new Date());
    }

    /**
     * Getting last day of Month
     *
     * @param month, year
     */
    public static String getLastDayOfMonth(int month, int year) {
        LocalDate lastDayOfMonth = (new LocalDate(year, month, 1)).dayOfMonth().withMaximumValue();
        return lastDayOfMonth.toString("MM-dd-yyyy");
    }

    /**
     * Getting First day of Month
     *
     * @param month, year
     * @return firstDayOfMonth
     */
    public static String getFirstDayOfMonth(int month, int year) {
        LocalDate firstDayOfMonth = (new LocalDate(year, month, 1)).dayOfMonth().withMinimumValue();
        return firstDayOfMonth.toString("MM-dd-yyyy");
    }

    /**
     * Moving mouse over element by By
     *
     * @param by
     */
    public static void onMouseHover(WebDriver d, By by) {
        Actions action = new Actions(d);
        WebElement we = d.findElement(by);
        action.moveToElement(we).build().perform();
    }


    /**
     * Moving mouse over element by web element
     *
     * @param by - WebElement, d
     */
    public static void onMouseHover(WebDriver d, WebElement by) {
        Actions action = new Actions(d);
        action.moveToElement(by).build().perform();
    }

    /**
     * Getting Day, Month and year From date
     *
     * @param date
     * @return
     */
    public static String getDayMonthAndYearFromDate(String date) {
        SimpleDateFormat sdf1 = new SimpleDateFormat("MM-dd-yyyy");

        try {
            Date date1 = sdf1.parse(date);
            SimpleDateFormat sdf = new SimpleDateFormat("EEEEE MMMMM yyyy");
            return sdf.format(date1);
        } catch (ParseException var4) {
            log.info(var4.getMessage());
            return "";
        }
    }

    /**
     * Scrolling Until Element is displayed
     *
     * @param webElement,d
     */

    public static void scrollUntilElementIsDisplay(WebDriver d, WebElement webElement) {
        ((JavascriptExecutor) d).executeScript("arguments[0].scrollIntoView(true);", webElement);
    }

    /**
     * Getting element using label Name
     *
     * @param labelName, elementType, d
     * @return
     */
    public static WebElement getElementUsingLabelName(WebDriver d, String labelName, String elementType) {
        try {
            String css = elementType.concat("[name ='").concat(labelName).concat("']");
            return d.findElement(By.cssSelector(css));
        } catch (NoSuchElementException var7) {
            try {
                String xpath = ".//label/span[text()= '".concat(labelName).concat("']//ancestor::tr//" + elementType);
                return d.findElement(By.xpath(xpath));
            } catch (NoSuchElementException var6) {
                String xpath = ".//span[text()= '" + labelName + "']//ancestor::td//input";
                return d.findElement(By.xpath(xpath));
            }
        }
    }

    /**
     * checking Label is present
     *
     * @param labelName, d
     * @return
     */
    public static Boolean isLabelPresent(WebDriver d, String labelName) {
        By xpath = By.xpath("//label[text()= '" + labelName + "']");
        waitElement(d, xpath);
        String label = d.findElement(xpath).getText();
        if (label.contains("required")) {
            label = label.substring(0, labelName.length());
        }

        return Boolean.valueOf(StringUtils.equals(labelName, label.trim()));
    }

    /**
     * checking alpha Numeric pattern
     *
     * @param value
     * @return
     */
    public static boolean isAlphaNumeric(String value) {
        String pattern = "^[a-zA-Z0-9]*$";
        return value.matches(pattern);
    }

    /**
     * checking alphabet pattern
     *
     * @param value
     * @return
     */
    public static boolean isAlphabet(String value) {
        String pattern = "^[a-zA-Z]*$";
        return value.matches(pattern);
    }

    /**
     * Generic: Takes a screen shot and saves the file in the filePath specified
     */
    public static String takeScreenShot(WebDriver d, String filePath, String name) {
        System.out.print("Taking screenshot...");
        String fileName = name + "-" + getCurrentTimeStamp();

        try {
            new File(filePath).mkdirs();
            File screenShot = ((TakesScreenshot) d).getScreenshotAs(OutputType.FILE); // take the screen shot

            //Check if it exists
            File f = new File(filePath + fileName + ".png");
            if (f.exists()) {
                System.out.println("File " + fileName + " exists. Adding '_1' to name");
                fileName = fileName + "_1";
            }

            FileUtils.copyFile(screenShot, new File(filePath + fileName + ".png")); // move the file
            System.out.println("Done.");
        } catch (IOException e) {
            System.out.print("Failed...");
        }
        return fileName;
    }

    /**
     * Get selected option from dropdown
     *
     * @param selectVal
     * @return
     */
    public static String getSelectedValueFromDropdown(WebDriver d, By selectVal) {
        Select select = new Select(d.findElement(selectVal));
        WebElement option = select.getFirstSelectedOption();
        String defaultItem = option.getText();
        return defaultItem;
    }

    /**
     * Checking that value is present in the dropdown options
     *
     * @param selectVal
     * @param optionExpexted
     * @return
     */
    public static boolean checkSelectValue(WebDriver d, By selectVal, String optionExpexted) {
        log.warn("Checking dropdown options:");
        boolean present = false;
        highlightElement(d, selectVal);
        WebElement selectElm = d.findElement(selectVal);
        Select elem = new Select(selectElm);
        List<WebElement> options = elem.getOptions();
        for (WebElement option : options) {
            if (option.getText().equals(optionExpexted)) {
                log.warn(option.getText());
                present = true;
            }
        }
        return present;
    }

    /**
     * set a debug break point here and call this static method where ever you need a break during the demo
     *
     * @param scenario
     * @param d
     * @param note
     */
    public static void demoBreakPoint(Scenario scenario, WebDriver d, String note) {
        TestUtils.immediateAbortCheck(scenario);
        ScenarioLogger sLog = new ScenarioLogger(scenario, log);
        try {
            if (null == scenario) {
                sLog.warn(note);
            } else {
                scenario.write(note);
                sLog.warn(scenario.getName() + ": " + note);
            }
            if (null != d) {
                screenshot(scenario, d, note);
            }
        } catch (Exception e) {
            e.printStackTrace();
            sLog.error(e.getMessage());
            // do nothing
        }
    }

    /**
     * A generic screenshot method encapsulating configurable "screenshotMode".
     * <p>
     * NOTE: different browsers could behave differently with the options [VIEWPORT_ONLY|WHOLE_PAGE].
     * So the final screenshot is not guaranteed to be consistent with the configured value.
     * <p>
     * NOTE:
     *
     * @param scenario
     * @param d
     * @param note
     * @throws IOException
     */
    public static void screenshot(Scenario scenario, WebDriver d, String note) throws IOException {
        ScenarioLogger sLog = new ScenarioLogger(scenario, log);
        String s = Conf.getInstance().getProperty("screenshotMode", "OFF").toUpperCase();
        sLog.warn("screenshotMode=" + s);
        switch (s) {
            case "VIEWPORT_ONLY":
                screenshot(scenario, d, note, true);
                break;
            case "WHOLE_PAGE":
                screenshot(scenario, d, note, false);
                break;
            default:
                // do nothing
        }
    }

    /**
     * A generic screenshot method.
     * Output the screenshot to cucumber report and file system
     *
     * @param scenario
     * @param d
     * @param note
     * @param visiblePartOnly
     * @throws IOException
     */
    public static void screenshot(Scenario scenario, WebDriver d, String note, boolean visiblePartOnly) throws IOException {
        String path = Conf.getOutputPath();
        String name = null == scenario ? "" : (scenario.getName() + "_") + DateUtils.timestamp() + "_" + makeName(note);

        int ox = -1;
        int oy = -1;
        try {
            d.manage().window().setSize(new Dimension(1280, 1280));
            ox = Integer.parseInt(js(d, "return window.pageXOffset;"));
            oy = Integer.parseInt(js(d, "return window.pageYOffset;"));
        } catch (Exception e) {
            //do nothing
        }
        try {
            String hideXpath = Conf.getInstance().getProperty(HIDE_XPATH_KEY);
            boolean hideSuccess = false;
            String originalStyle = null;
            try {
                if (isElementVisible(d, hideXpath)) {
                    originalStyle = hide(d, d.findElement(By.xpath(hideXpath)));
                    hideSuccess = true;
                }
            } catch (Exception e) {
                // do nothing
            }
            if (isPopupDisplaying(d)) {
                visiblePartOnly = true;
            }
            if (visiblePartOnly) {
                try {
                    Shutterbug.shootPage(d, ScrollStrategy.VIEWPORT_ONLY, 1000, true).withName(name).save(path);
                    File screenshotFile = new File(path + name + ".png");
                    byte[] screenshot = FileUtils.readFileToByteArray(screenshotFile);
                    if (null != scenario) {
                        scenario.embed(screenshot, "image/png");
                    }
                } catch (Exception e) {
                    byte[] screenshot = ((TakesScreenshot) d).getScreenshotAs(OutputType.BYTES);
                    if (null != scenario) {
                        scenario.embed(screenshot, "image/png");
                    }
                    FileUtils.writeByteArrayToFile(new File(path + name + ".png"), screenshot);
                } finally {
                    if (hideSuccess) {
                        try {
                            show(d, d.findElement(By.xpath(hideXpath)), originalStyle);
                        } catch (Exception e) {
                            //do nothing
                        }
                    }
                }
            } else {
                try {
                    Shutterbug.shootPage(d, ScrollStrategy.WHOLE_PAGE, 1000, true).withName(name).save(path);

                    File screenshotFile = new File(path + name + ".png");
                    String cropXpath = Conf.getInstance().getProperty(CROP_XPATH_KEY);
                    if (!StringUtils.isEmpty(cropXpath) && isElementVisible(d, cropXpath)) {
                        WebElement ele = d.findElement(By.xpath(cropXpath));
                        Point point = ele.getLocation();
                        int eleWidth = ele.getSize().getWidth();
                        int eleHeight = ele.getSize().getHeight();

                        BufferedImage fullImg = ImageIO.read(screenshotFile);
                        BufferedImage eleScreenshot = fullImg.getSubimage(point.getX(), point.getY(), eleWidth, eleHeight);
                        ImageIO.write(eleScreenshot, "png", screenshotFile);
                    }
                    byte[] screenshot = FileUtils.readFileToByteArray(screenshotFile);
                    if (null != scenario) {
                        scenario.embed(screenshot, "image/png");
                    }
                } catch (Exception e) {
                    screenshot(scenario, d, note, true);
                } finally {
                    if (hideSuccess) {
                        try {
                            show(d, d.findElement(By.xpath(hideXpath)), originalStyle);
                        } catch (Exception e) {
                            //do nothing
                        }
                    }
                }
            }
        } catch (Exception e) {
            log.error("Screenshot failed: " + e.getMessage());
        } finally {
            if (ox >= 0 && oy >= 0) {
                try {
                    scrollTo(d, ox, oy);
                } catch (Exception e) {
                    //do nothing
                }
            }
        }
    }

    /**
     * Check if popup is displaying
     *
     * @param d
     * @return
     */
    public static boolean isPopupDisplaying(WebDriver d) {
        return countElementsByXpath(d, Conf.getInstance().getProperty(POPUP_XPATH)) > 0;
    }

    /**
     * Try to X out popup
     *
     * @param d
     * @return
     */
    public static boolean tryXout(WebDriver d) {
        String x = Conf.getInstance().getProperty(POPUP_XPATH) + "//button[.='Close']";
        try {
            d.findElement(By.xpath(x)).click();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static String hide(WebDriver d, WebElement el) {
        return setAttribute(d, el, "style", "display:none");
    }

    public static void show(WebDriver d, WebElement el, String originalDisplay) {
        setAttribute(d, el, "style", originalDisplay);
    }

    public static String setAttribute(WebDriver d, WebElement el, String attName, String attValue) {
        String originalAttValue = el.getAttribute(attName);
        js(d, "arguments[0].setAttribute(arguments[1], arguments[2]);", el, attName, attValue);
        return originalAttValue;
    }

    /**
     * Extract content of a table element as a list of maps
     *
     * @param webDriver
     * @param tableXpath
     * @param timeOutInSeconds
     * @return
     */
    public static List<Map<String, String>> tableAsMaps(WebDriver webDriver, String tableXpath, int timeOutInSeconds) {
        log.warn("tableAsMaps: tableXpath=" + tableXpath);

        List<List<String>> lists = tableAsLists(webDriver, tableXpath, timeOutInSeconds);
        List<String> headers = lists.remove(0);
        List<Map<String, String>> result = new ArrayList<>(lists.size());
        if (lists.size() <= 0) {
            return result;
        }
        while (headers.size() != lists.get(0).size()) {
            if (headers.size() < lists.get(0).size()) {
                headers = lists.remove(0);
            } else {
                lists.remove(0);
                if (lists.size() <= 0) {
                    return result;
                }
            }
        }
        for (int i = 0; i < lists.size(); i++) {
            List<String> list = lists.get(i);
            if (list.size() == headers.size()) {
                Map<String, String> map = new LinkedHashMap<>(headers.size());
                for (int j = 0; j < headers.size(); j++) {
                    String header = headers.get(j).trim();
                    if (!header.isEmpty()) {
                        map.put(headers.get(j), list.get(j));
                    }
                }
                result.add(map);
            } else {
                throw new RuntimeException("Column number mismatch: " + headers + " VS " + list);
            }
        }

        log.warn("tableAsMaps: result=" + result);
        return result;
    }

    /**
     * Extract content of a transposed table element as a list of maps of size 1
     *
     * @param webDriver
     * @param tableXpath
     * @param timeOutInSeconds
     * @return
     */
    public static List<Map<String, String>> transposedTableAsMaps(WebDriver webDriver, String tableXpath, int timeOutInSeconds) {
        List<Map<String, String>> result = new ArrayList<>();
        Map<String, String> map = new LinkedHashMap<>();

        List<List<String>> transposedTable = TestUtils.tableAsLists(webDriver, tableXpath, timeOutInSeconds);
        String lastSingleTdString = null;
        for (List<String> row : transposedTable) {
            if (0 == row.size()) {
                continue;
            }
            if (1 == row.size()) {
                // Header in first row
                // Single Value in second row
                if (null == lastSingleTdString) {
                    lastSingleTdString = row.get(0);
                } else {
                    map.put(lastSingleTdString, row.get(0));
                    lastSingleTdString = null;
                }
                continue;
            }
            lastSingleTdString = null;
            if (1 == row.size() % 2) {
                if (3 == row.size()) {
                    //Clinical Documentation | testFile.txt | Upload Time 09-23-2019 03:34:24 PM
                    //Clinical Documentation testFile.txt --> Upload Time 09-23-2019 03:34:24 PM
                    map.put(row.get(0) + " " + row.get(1), row.get(2));
                }
                continue;
            }
            if (StringUtils.isEmpty(row.get(0))) {
                continue;
            }
            for (int j = 0; j < row.size(); j += 2) {
                map.put(row.get(j).trim(), row.get(j + 1).trim());
            }
        }
        result.add(map);
        return result;
    }

    /**
     * Extract the content of a structured element as a list of list
     *
     * @param webDriver
     * @param rowElementsXpath:       "//form[@name='ocmAssessmentConductorForm']//div[contains(@class, 'question-wrapper')]"
     * @param columnElementSubXpaths: "span[1]", "span[2]"
     * @return
     */
    public static List<List<String>> asLists(WebDriver webDriver, String rowElementsXpath, String... columnElementSubXpaths) {
        log.warn("asLists: rowElementsXpath=" + rowElementsXpath);
        log.warn("asLists: columnElementSubXpaths=" + Arrays.asList(columnElementSubXpaths).toString());
        List<WebElement> rowElements = webDriver.findElements(By.xpath(rowElementsXpath));
        List<List<String>> lists = new ArrayList<List<String>>(rowElements.size());
        for (int i = 0; i < rowElements.size(); i++) {
            List<String> list = new ArrayList<>(columnElementSubXpaths.length);
            int row = i + 1;
            for (int j = 0; j < columnElementSubXpaths.length; j++) {
                String columnText = rowElements.get(i).findElement(By.xpath(columnElementSubXpaths[j])).getText();
                list.add(columnText);
            }
            lists.add(list);
        }

        log.warn("asLists: result=" + lists.toString());
        return lists;

    }

    /**
     * Extract the content of a table element as a list of list
     *
     * @param webDriver
     * @param tableXpath
     * @param timeOutInSeconds
     * @return
     */
    public static List<List<String>> tableAsLists(WebDriver webDriver, String tableXpath, int timeOutInSeconds) {
        final List<List<String>> resultContainer = new ArrayList<List<String>>();
        Retry retry = new Retry("Retry TestUtils.tableAsLists()", 3 * 60 * 1000, 1000, 1000) {
            @Override
            protected void tryOnce() throws Exception {

                log.debug("tableAsLists: tableXpath=" + tableXpath);
                List<WebElement> els = webDriver.findElements(By.xpath(tableXpath));
                if (null == els || els.size() <= 0) {
                    log.debug("No such elements: tableXpath=" + tableXpath);
                    return;
                }
                if (waitElementVisible(webDriver, tableXpath, timeOutInSeconds)) {
                    WebElement theTable = webDriver.findElement(By.xpath(tableXpath));
                    scrollToElement(webDriver, theTable);
                    List<WebElement> trs = theTable.findElements(By.xpath(".//tr"));
                    if (null == trs || trs.size() <= 0) {
                        log.debug("No rows in the table element: " + tableXpath);
                        return;
                    }
                    List<List<String>> lists = new ArrayList<List<String>>(trs.size());
                    for (WebElement tr : trs) {
                        if (isTfoot(tr)) {
                            log.debug("isTfoot");
                            continue;
                        }
                        if (isComplex(tr)) {
                            log.debug("isComplex");
                            continue;
                        }

                        List<WebElement> tds = tr.findElements(By.xpath("./*"));
                        if (null == tds || tds.size() <= 0) {
                            log.debug("Empty tr");
                            continue;
                        }
                        log.debug("tdCount=" + tds.size());
                        List<String> list = new ArrayList<String>(tds.size());
                        for (WebElement td : tds) {
                            List<WebElement> qaWrappers = td.findElements(By.xpath(".//div[contains(@class, 'question-wrapper')]"));
                            if (null == qaWrappers || qaWrappers.size() <= 0) {
                                log.debug("simple td");
                                String tdContent = simpleContentInTdOrTh(td);
                                if (null != tdContent) {
                                    list.add(tdContent);
                                }
                            } else {
                                log.debug(qaWrappers.size() + " qa wrappers found");
                                for (WebElement qaWrapper : qaWrappers) {
                                    String q = qaWrapper.findElement(By.xpath("./span[1]")).getText();
                                    String a = qaWrapper.findElement(By.xpath("./span[2]")).getText();
                                    lists.add(Arrays.asList(q, a));
                                }
                            }
                        }
                        lists.add(list);
                    }
                    log.debug("asLists: result=" + lists.toString());
                    resultContainer.addAll(lists);
                }
            }

            @Override
            protected boolean until() throws Exception {
                return resultContainer.size() > 0;
            }
        };
        retry.execute();
        return resultContainer;
    }

    private static boolean isTfoot(WebDriver driver, String trXpath) {
        WebElement tr = driver.findElement(By.xpath(trXpath));
        return isTfoot(tr);
    }

    private static boolean isTfoot(WebElement tr) {
        if (tr.getAttribute("id").startsWith("trEdiMessageLog")) {
            // ICUE EDI search result message
            return true;
        }
        WebElement parent = tr.findElement(By.xpath("./.."));
        return "tfoot".equalsIgnoreCase(parent.getTagName());
    }

    private static boolean isComplex(WebElement tr) {
        List<WebElement> subTables = tr.findElements(By.xpath(".//table"));
        return null != subTables && subTables.size() > 0;
    }

    /**
     * Return the content of a simple element instead of a structure/control element.
     * Could be:
     * - radio buttons selection
     * <p>
     * - label
     * - text box value
     * - textarea value
     * - dropdown list selection
     * - ocm:calendar value
     * - ocm:time
     * - ocm:typeahead
     *
     * @param webDriver
     * @param tdOrThXpath
     * @return
     */
    public static String simpleContentInTdOrTh(WebDriver webDriver, String tdOrThXpath) {
        return simpleContent(webDriver.findElement(By.xpath(tdOrThXpath)));
    }

    /**
     * Return the content of a simple element instead of a structure/control element.
     * Could be:
     * - radio buttons selection
     * <p>
     * - label
     * - text box value
     * - textarea value
     * - dropdown list selection
     * - ocm:calendar value
     * - ocm:time
     * - ocm:typeahead
     *
     * @param tdOrTh
     * @return
     */
    public static String simpleContentInTdOrTh(WebElement tdOrTh) {
        if (null == tdOrTh) {
            return null;
        }

        log.debug("simpleContentInTdOrTh()");
        log.debug("parent=" + tdOrTh);
        String simpleContent = "";

        if (!"td".equals(tdOrTh.getTagName()) && !"th".equals(tdOrTh.getTagName())) {
            Assert.fail("Parent element must be a <td> element");
        }

        List<WebElement> els = tdOrTh.findElements(By.xpath("./*"));
        log.debug("els=" + els);

        if (1 == els.size()) {
            WebElement el = els.get(0);
            simpleContent = simpleContent(el);
            log.debug("simpleContentInTdOrTh=" + simpleContent);
        } else {
            List<WebElement> radioButtons = tdOrTh.findElements(By.xpath(".//input[@type='radio']"));
            if (null != radioButtons && radioButtons.size() > 0) {
                for (WebElement radioButton : radioButtons) {
                    if (radioButton.isSelected()) {
                        simpleContent = radioButton.findElement(By.xpath("./../label")).getText();
                        break;
                    }
                }
            }
        }

        if (StringUtils.isEmpty(simpleContent) || ", required.".equals(simpleContent.trim())) {
            simpleContent = tdOrTh.getText();
            log.debug("simpleContentInTdOrTh=" + simpleContent);
        }
        if (simpleContent.endsWith(", required.")) {
            simpleContent = simpleContent.split(", required.")[0].trim();
            log.debug("simpleContentInTdOrTh=" + simpleContent);
        }
        simpleContent = simpleContent.trim().replace("\n", "\\n");

        return simpleContent.trim();
    }

    /**
     * Return the content of a simple element instead of a structure/control element.
     * Could be:
     * - label
     * - text box value
     * - textarea value
     * - dropdown list selection
     * - ocm:calendar value
     * - ocm:time
     * - ocm:typeahead
     *
     * @param el
     * @return
     */
    public static String simpleContent(WebElement el) {
        log.debug("simpleContent(el)");
        log.debug("el=" + el);
        String simpleContent = "";
        String tag = el.getTagName().toLowerCase();
        log.debug("tag=" + tag);
        switch (tag) {
            case "label":
            case "span":
                simpleContent = el.getText();
                if (simpleContent.contains("\n")) {
                    simpleContent = simpleContent.split("\n", 2)[0].trim();
                }
                break;
            case "input":
            case "textarea":
                simpleContent = el.getAttribute("value");
                break;
            case "select":
                Select select = new Select(el);
                simpleContent = select.getFirstSelectedOption().getText();
                break;
            case "ocm:calendar":
            case "ocm-calendar":
                WebElement ocmCalendarInput = el.findElement(By.xpath(".//input"));
                simpleContent = ocmCalendarInput.getAttribute("value");
                break;
            case "ocm:typeahead":
            case "ocm-typeahead":
                List<WebElement> ocmTypeaheadElements = el.findElements(By.xpath(".//input"));
                simpleContent = ocmTypeaheadElements.get(0).getAttribute("value");
                break;
            case "ocm:time":
            case "ocm-time":
                List<WebElement> ocmTimeElements = el.findElements(By.xpath(".//input"));
                simpleContent = ocmTimeElements.get(0).getAttribute("value");
                if (ocmTimeElements.get(1).isSelected()) {
                    simpleContent += " AM";
                } else if (ocmTimeElements.get(2).isSelected()) {
                    simpleContent += " PM";
                }
                break;
            case "uitk:select":
            case "uitk-select":
                simpleContent = simpleContent(el.findElement(By.xpath("./select")));
                break;
            default:
                simpleContent = el.getText();
        }
        return simpleContent;
    }

    /**
     * A generic input method
     * !!!Caution: the input text will be written in the log.
     * !!!Use input(WebDriver d, By by, String text, boolean secret) if you are inputting a password.
     *
     * @param d
     * @param by
     * @param text
     */
    public static boolean input(WebDriver d, By by, String text) {
        return input(d, by, text, false);
    }

    /**
     * A generic input method with any locator
     *
     * @param d
     * @param by
     * @param text
     * @param secret
     */
    public static boolean input(WebDriver d, By by, String text, boolean secret) {
        text = null == text ? "" : text;
        waitElementVisible(d, by);
        highlightElement(d, by);

        List<WebElement> els = d.findElements(by);
        if (1 != els.size()) {
            throw new RuntimeException("Too many elements.");
        }

        WebElement el = els.get(0);
        return input(d, el, text, secret);
    }

    /**
     * A generic input method for elements supported by EditableFactory
     *
     * @param d
     * @param el
     * @param text0
     * @param secret
     */
    public static boolean input(WebDriver d, WebElement el, String text0, boolean secret) {
        final String text = WhiteBoard.escape(text0);
        log.warn("input [" + (secret ? "******" : text) + "] with element " + el);

        Editable editable = EditableFactory.asEditable(d, el);
        if (null == editable) {
            log.error("Unsupported element: " + el);
            return false;
        }

        try {
            return editable.edit(text);
        } finally {
            waitForAngularRequestsToFinish(d);
        }
    }

    private static boolean click(WebDriver d, WebElement el, String relativeXpath) {
        try {
            boolean success = new WaitUntil("wait relativeXpath: " + el + ": " + relativeXpath, new ICondition() {
                @Override
                public boolean evaluate() throws Exception {
                    try {
                        List<WebElement> els = el.findElements(By.xpath(relativeXpath));
                        if (null == els) {
                            return false;
                        }
                        return 1 == els.size();
                    } catch (Exception e) {
                        return false;
                    }
                }
            }).execute();
            if (!success) {
                return false;
            }
            el.findElement(By.xpath(relativeXpath)).click();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * A generic method to create a Select instance only when it's possible.
     *
     * @param el
     * @return null if not possible
     */
    public static Select asSelect(WebElement el) {
        try {
            String tag = el.getTagName();
            if ("select".equalsIgnoreCase(tag)) {
                return new Select(el);
            } else {
                return null;
            }
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * A generic select method
     *
     * @param d
     * @param by
     * @param valueOrLabel
     * @return
     */
    public static boolean select(WebDriver d, By by, String valueOrLabel) {
        log.warn("select '" + valueOrLabel + "' " + by.toString());
        waitElementVisible(d, by);
        highlightElement(d, by);
        Select sel = new Select(d.findElement(by));
        return select(sel, valueOrLabel);
    }

    /**
     * A generic select method by index
     *
     * @param d
     * @param by
     * @param index
     * @return
     */
    public static boolean select(WebDriver d, By by, int index) {
        log.warn("select index '" + index + "' " + by.toString());
        waitElementVisible(d, by);
        highlightElement(d, by);
        Select sel = new Select(d.findElement(by));
        try {
            sel.selectByIndex(index);
        } catch (Exception e) {
            log.warn(e.getMessage());
            return false;
        }
        throw new ImmediateAbortException("No such Index: " + index);
    }

    /**
     * A generic select method
     *
     * @param sel
     * @param valueOrLabel
     */
    public static boolean select(Select sel, String valueOrLabel) {
        log.warn("select '" + valueOrLabel + "' " + sel.toString());
        try {
            for (WebElement option : sel.getOptions()) {
                if (valueOrLabel.equals(option.getAttribute("value"))) {
                    log.debug("Select by value");
                    sel.selectByValue(valueOrLabel);
                    TestUtils.wait(2);
                    return true;
                }
                if (valueOrLabel.equals(option.getText())) {
                    log.debug("Select by label");
                    sel.selectByVisibleText(valueOrLabel);
                    TestUtils.wait(2);
                    return true;
                }
            }
        } catch (Exception e) {
            log.warn(e.getMessage());
            return false;
        }

        throw new ImmediateAbortException("No such Option: " + valueOrLabel);
    }

    /**
     * A generic click method
     *
     * @param d
     * @param by
     * @return
     */
    public static boolean click(WebDriver d, By by) {
        log.warn("click " + by.toString());
        if (!isElementVisible(d, by)) {
            throw new RuntimeException("Cannot click element " + by.toString() + " because it's not visible");
        }
        if (!waitElementClickable(d, by)) {
            throw new RuntimeException("Cannot click element " + by.toString() + " because it's not clickable");
        }
        return click(d, findElements(d, by).get(0));
    }

    /**
     * A generic click method
     *
     * @param d
     * @param el
     * @return
     */
    public static boolean click(WebDriver d, WebElement el) {
//        try {
//            String browser = Conf.getInstance().getProperty("Browser");
//            browser = StringUtils.isEmpty(browser) ? Conf.getInstance().getProperty("browser") : browser;
//            log.debug("browser=" + browser);
//            if ("ieRemote".equalsIgnoreCase(browser) || "internetExplorer".equalsIgnoreCase(browser)) {
//                throw new RuntimeException("Must scroll to element for IE.");
//            } else {
//                el.click();
//            }
//        } catch (Exception e) {
//            log.debug(e.getMessage());
        try {
            scrollToElement(d, el);
            el.click();
        } catch (Exception e1) {
            try {
                MbmUtils.immediateRecover(d);
                scrollToElement(d, el);
                el.click();
            } catch (Exception e2) {
                if (hideBadges(d)) {
                    try {
                        scrollToElement(d, el);
                        el.click();
                    } catch (Exception e3) {
                        if (isPopupDisplaying(d)) {
                            tryXout(d);
                            el.click();
                            return true;
                        } else {
                            return false;
                        }
                    }
                } else {
                    return false;
                }
            }
        }
//        }
        waitForAngularRequestsToFinish(d);
        return true;
    }

    /**
     * Hide all pendo-badge elements
     *
     * @param d
     * @return
     */
    public static boolean hideBadges(WebDriver d) {
        String xpath = Conf.getInstance().getProperty(PENDO_BADGES_XPATH);
        if (StringUtils.isEmpty(xpath)) {
            return false;
        } else {
            try {
                List<WebElement> els = d.findElements(By.xpath(xpath));
                for (WebElement el : els) {
                    hide(d, el);
                }
                return true;
            } catch (Exception e) {
                log.error(e.getMessage());
                return false;
            }
        }
    }

    /**
     * A generic method to scroll to an element.
     *
     * @param d
     * @param by
     */
    public static void scrollToElement(WebDriver d, By by) {
        scrollToElement(d, d.findElement(by));
    }

    /**
     * A generic method to scroll to an element.
     *
     * @param d
     * @param el
     */
    public static void scrollToElement(WebDriver d, WebElement el) {
        try {
            if (isPopupDisplaying(d)) {
                return;
            }
            JavascriptExecutor js = (JavascriptExecutor) d;
            Long pageYOffset = (Long) js.executeScript("return window.pageYOffset;");
            Long innerHeight = (Long) js.executeScript("return window.innerHeight;");

            Point elLocation = el.getLocation();
            Dimension elSize = el.getSize();

            if (elSize.getHeight() < innerHeight) {
                long scrollOffset = elLocation.getY() - pageYOffset - (innerHeight / 2) + (elSize.getHeight() / 2);
                js.executeScript("window.scrollBy(0, " + scrollOffset + ")");
            } else {
                long scrollOffset = elLocation.getY() - pageYOffset - getStickyHeaderHeight(d);
                js.executeScript("window.scrollBy(0, " + scrollOffset + ")");
            }
        } catch (Exception e) {
            log.debug("Not able to scroll to element: " + el);
        } finally {
            wait("Let the page settle down after scrolling.", 3);
        }

    }

    private static int getStickyHeaderHeight(WebDriver d) {
        String stickyHeaderXpath = Conf.getInstance().getProperty(STICKY_HEADER_XPATH);
        if (!StringUtils.isEmpty(stickyHeaderXpath)) {
            try {
                WebElement stickyHeader = d.findElement(By.xpath(stickyHeaderXpath));
                Dimension s = stickyHeader.getSize();
                return s.getHeight();
            } catch (Exception e) {
                log.debug(e);
            }
        }
        return 0;
    }


//    private static void scrollOutOfHeader(WebDriver d, WebElement el, String headerBarXpath) {
//        if (waitElementVisible(d, headerBarXpath, 10)) {
//            try {
//                Point p = el.getLocation();
//                WebElement headerElement = d.findElement(By.xpath(headerBarXpath));
//
//                Point headerLocation = headerElement.getLocation();
//                Dimension headerSize = headerElement.getSize();
//                if (p.getY() <= headerLocation.getY() + headerSize.getHeight()) {
//                    log.warn("The element " + el + " is covered by header: " + headerBarXpath);
//                    JavascriptExecutor js = (JavascriptExecutor) d;
//                    js.executeScript("window.scrollBy(0, -" + (headerSize.getHeight() + 100) + ")");
//                }
//            } catch (Exception e) {
//                //do nothing
//            }
//        } else {
//            log.error("No such header: " + headerBarXpath);
//        }
//    }

    /**
     * A generic method to specified position.
     *
     * @param d
     * @param x
     * @param y
     */
    public static void scrollTo(WebDriver d, int x, int y) {

        js(d, "window.scrollTo(arguments[0], arguments[1]);", x, y);

    }

    /**
     * A generic text method to read an element's text
     *
     * @param d
     * @param by
     * @return
     */
    public static String text(WebDriver d, By by) {
        try {
            if (waitElementVisible(d, by)) {
                highlightElement(d, by);
                String text = d.findElement(by).getText();
                log.warn("get text '" + text + "' " + by.toString());
                return text;
            } else {
                return null;
            }
        } catch (Exception e) {
            return null;
        }
    }


    /**
     * A generic text method to read an element's value
     *
     * @param d
     * @param by
     * @return
     */
    public static String value(WebDriver d, By by) {
        waitElementVisible(d, by);
        highlightElement(d, by);
        String value = d.findElement(by).getAttribute("value");

        log.warn("get value '" + value + "' " + by.toString());
        return value;
    }

    /**
     * A generic method to execute javascript
     *
     * @param d
     * @param js
     * @return
     */
    public static String js(WebDriver d, String js, Object... args) {
        Object o = ((JavascriptExecutor) d).executeScript(js, args);

        log.debug("get javascript return value '" + (null == o ? "null" : o.toString()) + "' by executing:\r\n\t"
                + js + "\r\n\t" +
                "with parameters: " + Arrays.asList(args).toString()
        );
        if (null == o) {
            return null;
        } else {
            return o.toString();
        }
    }

    /**
     * A generic method to wait for an element to be visible
     *
     * @param d
     * @param by
     * @return
     */
    public static boolean waitElementVisible(WebDriver d, By by) {
        return waitElementVisible(d, by, 30);
    }

    /**
     * A generic quick method to wait for an element to be visible by xpath
     *
     * @param d
     * @param xpath
     * @return
     */
    public static boolean waitElementVisible(WebDriver d, String xpath) {
        return waitElementVisible(d, xpath, 30);
    }

    /**
     * A generic quick method to wait for an element to be not visible by xpath
     *
     * @param d
     * @param xpath
     * @return
     */
    public static boolean waitElementNotVisible(WebDriver d, String xpath) {
        return waitElementNotVisible(d, xpath, 30);
    }

    /**
     * A generic method to wait for an element to be visible in given timeout seconds
     *
     * @param d
     * @param by
     * @param timeOutInSeconds
     * @return
     */
    public static boolean waitElementVisible(WebDriver d, By by, int timeOutInSeconds) {
        String byString = by.toString();
        log.warn("waitElementVisible: by=" + byString + " timeOutInSeconds=" + timeOutInSeconds);

        String[] p = byString.split(": ", 2);
        if (p[0].equals("By.xpath")) {
            return waitElementVisible(d, p[1], timeOutInSeconds);
        }

        long t1 = System.currentTimeMillis() + (timeOutInSeconds * 1000);
        while (System.currentTimeMillis() < t1) {
            try {
                Wait wait = new WebDriverWait(d, timeOutInSeconds);
                wait.until(ExpectedConditions.visibilityOfElementLocated(by));
                log.warn("waitElementVisible: true");
                return true;
            } catch (Exception e) {
                //do nothing
            }
        }
        log.warn("waitElementVisible: false");
        return false;
    }

    /**
     * A generic quick method to wait for an element to be visible by xpath in given timeout seconds
     *
     * @param d
     * @param xpath
     * @param timeOutInSeconds
     * @return
     */
    public static boolean waitElementVisible(WebDriver d, String xpath, int timeOutInSeconds) {
        log.warn("waitElementVisible: xpath=" + xpath + " timeOutInSeconds=" + timeOutInSeconds);
        return new Retry("waitElementVisible", timeOutInSeconds * 1000, 200, 200) {
            @Override
            protected void tryOnce() throws Exception {
                // do nothing
            }

            @Override
            protected boolean until() throws Exception {
                return isElementVisible(d, xpath);
            }
        }.execute();
    }

    /**
     * A generic quick method to wait for an element to be not visible by xpath in given timeout seconds
     *
     * @param d
     * @param xpath
     * @param timeOutInSeconds
     * @return
     */
    public static boolean waitElementNotVisible(WebDriver d, String xpath, int timeOutInSeconds) {
        log.warn("waitElementNotVisible: xpath=" + xpath + " timeOutInSeconds=" + timeOutInSeconds);
        return new Retry("waitElementNotVisible", timeOutInSeconds * 1000, 0, 0) {
            @Override
            protected void tryOnce() throws Exception {
                // do nothing
            }

            @Override
            protected boolean until() throws Exception {
                return !isElementVisible(d, xpath);
            }
        }.execute();
    }

    /**
     * A generic method to wait for an element to be clickable
     *
     * @param d
     * @param by
     * @return
     */
    public static boolean waitElementClickable(WebDriver d, By by) {
        return waitElementClickable(d, by, 30);
    }

    /**
     * A generic method to wait for a locator to be clickable in given timeout seconds
     *
     * @param d
     * @param by
     * @param timeOutInSeconds
     * @return
     */
    public static boolean waitElementClickable(WebDriver d, By by, int timeOutInSeconds) {
        log.warn("waitElementClickable: by=" + by.toString() + " timeOutInSeconds=" + timeOutInSeconds);
        long t1 = System.currentTimeMillis() + (timeOutInSeconds * 1000);
        while (System.currentTimeMillis() < t1) {
            try {
                Wait wait = new WebDriverWait(d, timeOutInSeconds);
                WebElement el = findElements(d, by).get(0);
                wait.until(ExpectedConditions.elementToBeClickable(el));
                log.warn("waitElementClickable: true");
                return true;
            } catch (Exception e) {
                //do nothing
            }
        }
        log.warn("waitElementClickable: false");
        return false;
    }

    /**
     * A generic method to wait for an element to be clickable in given timeout seconds
     *
     * @param d
     * @param el
     * @param timeOutInSeconds
     * @return
     */
    public static boolean waitElementClickable(WebDriver d, WebElement el, int timeOutInSeconds) {
        log.warn("waitElementClickable: el=" + el.toString() + " timeOutInSeconds=" + timeOutInSeconds);
        long t1 = System.currentTimeMillis() + (timeOutInSeconds * 1000);
        while (System.currentTimeMillis() < t1) {
            try {
                Wait wait = new WebDriverWait(d, timeOutInSeconds);
                wait.until(ExpectedConditions.elementToBeClickable(el));
                log.warn("waitElementClickable: true");
                return true;
            } catch (Exception e) {
                //do nothing
            }
        }
        log.warn("waitElementClickable: false");
        return false;
    }

    /**
     * A generic method to check if an element is clickable or not
     *
     * @param d
     * @param by
     * @return
     */
    public static boolean isElementClickable(WebDriver d, By by) {
        return waitElementClickable(d, by, 1);
    }

    /**
     * A generic method to highlight an element
     *
     * @param d
     * @param by
     */
    public static void highlightElement(WebDriver d, By by) {
//        try {
//            //Turn off by demo in config
//            if (Conf.getInstance().isDemo()) {
//                WebElement el = d.findElement(by);
//                String s = el.getAttribute("style");
//                for (int i = 0; i < 2; i++) {
//                    js(d, "arguments[0].setAttribute('style', arguments[1]);", el, "color: yellow; border: 5px solid yellow;");
//                    Thread.sleep(50);
//                    js(d, "arguments[0].setAttribute('style', arguments[1]);", el, s);
//                }
//            }
//        } catch (InterruptedException e) {
//            // do nothing
//        }
    }

    /**
     * A generic method to highlight an element
     *
     * @param d
     * @param el
     */
    public static void highlightElement(WebDriver d, WebElement el) {
    }

    /**
     * A generic method to switch to the new window
     *
     * @param d
     * @return
     */
    public static String switchToNewWindow(WebDriver d) {
        String oldHandle = d.getWindowHandle();
        for (String h : d.getWindowHandles()) {
            d.switchTo().window(h);
            log.warn("switching window to " + d.getTitle() + "\r\n\turl=" + d.getCurrentUrl() + "\r\n\thandler=" + d.getWindowHandle());
        }
        return oldHandle;
    }

    /**
     * Click an element until success or timeout in 30 seconds.
     * Success means WebDriver.click() method doesn't throw any Exception.
     *
     * @param d
     * @param locator
     */
    public static void safeClick(WebDriver d, By locator) {

        boolean success = new Retry("safeClick") {
            @Override
            protected void tryOnce() {
                click(d, locator);
            }
        }.execute();

        if (!success) {
            throw new RuntimeException("Timeout trying to click: " + locator.toString());
        }

    }

    /**
     * Click an element by specified locator until specified condition.
     *
     * @param d
     * @param locator
     * @param untilCondition
     */
    public static boolean clickUntil(WebDriver d, By locator, ICondition untilCondition) {

        try {
            if (untilCondition.evaluate()) {
                return true;
            }

            return new Retry("clickUntil: " + locator,
                    5 * 60 * 1000,
                    1000,
                    1000,
                    untilCondition) {
                @Override
                protected void tryOnce() {
                    try {
                        if (!click(d, locator)) {
                            throw new ImmediateAbortException("Not able to click: " + locator);
                        }
                    } catch (Exception e) {
                        throw new ImmediateAbortException("Not able to click: " + locator);
                    }
                    TestUtils.wait(1);
                }
            }.execute();
        } catch (Exception e) {
            log.error(e.getMessage());
            return false;
        }

    }

    /**
     * Click an element by specified locator String until specified condition.
     *
     * @param d
     * @param clickLocator
     * @param untilCondition
     */
    public static boolean clickUntil(WebDriver d, String clickLocator, ICondition untilCondition) {

        try {
            if (untilCondition.evaluate()) {
                return true;
            }

            return new Retry("clickUntil: " + clickLocator,
                    5 * 60 * 1000,
                    1000,
                    1000,
                    untilCondition) {
                @Override
                protected void tryOnce() {
                    try {
                        if (!click(d, SlowBy.by(d, clickLocator, null, null, null))) {
                            throw new ImmediateAbortException("Not able to click: " + clickLocator);
                        }
                    } catch (Exception e) {
                        throw new ImmediateAbortException("Not able to click: " + clickLocator);
                    }
                    TestUtils.wait(1);
                }
            }.execute();
        } catch (Exception e) {
            log.error(e.getMessage());
            return false;
        }

    }

    /**
     * Click an element by specified locator String until specified condition.
     *
     * @param d
     * @param locatorString
     * @param untilCondition
     */
    public static boolean clickUntil(WebDriver d, String locatorString, ICondition untilCondition, String parentXpath) {

        try {
            if (untilCondition.evaluate()) {
                return true;
            }

            return new Retry("clickUntil: " + locatorString,
                    5 * 60 * 1000,
                    1000,
                    1000,
                    untilCondition) {
                @Override
                protected void tryOnce() {
                    try {
                        if (!click(d, SlowBy.by(d, locatorString, null, null, parentXpath))) {
                            throw new ImmediateAbortException("Not able to click: " + locatorString + " under " + parentXpath);
                        }
                    } catch (Exception e) {
                        throw new ImmediateAbortException("Not able to click: " + locatorString + " under " + parentXpath);
                    }
                    TestUtils.wait(1);
                }
            }.execute();
        } catch (Exception e) {
            log.error(e.getMessage());
            return false;
        }

    }

    /**
     * Click an element until specified condition.
     *
     * @param d
     * @param el
     * @param untilCondition
     */
    public static boolean clickUntil(WebDriver d, WebElement el, ICondition untilCondition) {

        return new Retry("clickUntil: " + el,
                5 * 60 * 1000,
                1000,
                1000,
                untilCondition) {
            @Override
            protected void tryOnce() {
                try {
                    if (!click(d, el)) {
                        throw new ImmediateAbortException("Not able to click: " + el);
                    }
                } catch (Exception e) {
                    throw new ImmediateAbortException("Not able to click: " + el);
                }
            }
        }.execute();

    }

    /**
     * A generic method to check if a locator is clickable
     *
     * @param d
     * @param by
     * @return
     */
    public static boolean isClickable(WebDriver d, By by) {
        return waitElementClickable(d, by, 1);
    }

    /**
     * A generic method to check if an element is clickable
     *
     * @param d
     * @param el
     * @return
     */
    public static boolean isClickable(WebDriver d, WebElement el) {
        return waitElementClickable(d, el, 1);
    }


    /**
     * Converts a String into something qualifies to be a variable name
     *
     * @param s
     * @return
     */
    public static String makeName(String s) {
        s = s.replaceAll("[^A-Za-z0-9]+", " ").trim().replace(' ', '_');
        s = s.length() > 50 ? s.substring(0, 50) : s;
        return s;
    }

    /**
     * A generic method to check element is visible
     *
     * @param d
     * @param by
     * @return
     */
    public static boolean isElementVisible(WebDriver d, By by) {
        if (null == by) {
            return false;
        }
        log.warn("Check if element is visible: " + by);

        List<WebElement> visibleEls = findElements(d, by);
        if (null == visibleEls || visibleEls.size() <= 0) {
            return false;
        }
        if (0 == visibleEls.size()) {
            return false;
        } else if (1 == visibleEls.size()) {
            return true;
        } else {
            log.error("Too many elements found: " + by.toString());
            return false;
        }
    }

    /**
     * A generic quick method to check element is visible by xpath
     *
     * @param d
     * @param xpath
     * @return
     */
    public static boolean isElementVisible(WebDriver d, String xpath) {
        log.warn("Check if element is visible: " + xpath);
        int count = countElementsByXpath(d, xpath);
        if (0 == count) {
            return false;
        } else if (1 == count) {
            return d.findElement(By.xpath(xpath)).isDisplayed();
        } else {
            return isElementVisible(d, By.xpath(xpath));
        }
    }

    public static List<WebElement> getSubElements(WebDriver d, WebElement el, String xpath) {
        List<WebElement> els = el.findElements(By.xpath(xpath));
        if (null == els || 0 == els.size()) {
            return null;
        }
        List<WebElement> visibleEls = new ArrayList<>(1);
        for (WebElement element : els) {
            if (el.isDisplayed()) {
                visibleEls.add(element);
            }
        }
        return visibleEls;
    }

    /**
     * A generic quick method to get the only visible sub element by xpath
     *
     * @param d
     * @param xpath
     * @return
     */
    public static int countElementsByXpath(WebDriver d, String xpath) {
        try {
            if (StringUtils.isEmpty(xpath)) {
                return 0;
            }
            List<WebElement> els = d.findElements(By.xpath("/html/body | " + xpath));
            return els.size() - 1;
        } catch (Throwable t) {
            return 0;
        }
    }

    /**
     * Write text to file. Ignore any exceptions.
     *
     * @param fn
     * @param text
     */
    public static void outputStringToFile(String fn, String text) {
        try {
            FileUtils.writeStringToFile(new File(Conf.getOutputPath() + fn), text);
        } catch (IOException e) {
            log.error("Unable to output file " + fn);
        }
    }

    /**
     * Accept browser popup alert if any.
     *
     * @param d
     */
    public static boolean tryAccecpt(WebDriver d) {
        try {
            d.switchTo().alert().accept();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Close system message popup if any.
     *
     * @param d
     */
    public static void tryCloseMessage(WebDriver d) {
        try {
            By by = By.xpath("//button[@ng-click='closeMessage()']");
            List<WebElement> els = d.findElements(by);
            if (1 == els.size()) {
                els.get(0).click();
            }
        } catch (Exception e) {
            // do nothing
        }
    }

    /**
     * Decode hsc_id value from the currentURL
     *
     * @return
     */
    public static long getHscIdFromURL(String currentUrl) {
        String s = currentUrl.split("/auth/", 2)[1].split("/")[2];
        long hscId = Long.parseLong(new String(Base64.getDecoder().decode(s)));
        return hscId;
    }


    /**
     * Decode member id value from the currentURL
     *
     * @return
     */
    public static String getMemberIdFromURL(String currentUrl) {
        String[] result = currentUrl.split("/");
        String memberId = new String(Base64.getDecoder().decode(result[result.length - 2]));
        Long.parseLong(memberId);
        return memberId;
    }

    /**
     * Refresh page and accept any alert box
     *
     * @return
     */
    public static void refreshPage(WebDriver d) {
        d.navigate().refresh();
        TestUtils.wait(3);
        try {
            d.switchTo().alert().accept();
        } catch (Exception NoAlertPresentException) {
            // do nothing
        }
    }

    /**
     * Return the short name of a class name.
     *
     * @param className
     * @return
     */
    public static String shortName(String className) {
        if (null != className && className.contains(".")) {
            return className.substring(className.lastIndexOf('.') + 1);
        } else {
            return className;
        }
    }

    /**
     * Return the short name of a class.
     *
     * @param clazz
     * @return
     */
    public static String shortName(Class clazz) {
        String className = clazz.getName();
        return shortName(className);
    }

    /**
     * store Map keys as lowercase
     *
     * @return
     */
    public static Map<String, Object> mapKeysToLowerCase(Map<String, Object> map) {
        Map<String, Object> mapLowerCase = new LinkedHashMap<>();
        for (String key : map.keySet()) {
            mapLowerCase.put(key.toLowerCase(), map.get(key));
        }
        return mapLowerCase;
    }


    /**
     * Upload a file to a web element by id only.
     *
     * @param driver
     * @param elementId
     * @param filePath
     * @return true=success, false=fail
     */
    public static boolean uploadFile(WebDriver driver, String elementId, String filePath, By fileUploadStatus) {
        try {
            log.warn("Uploading a Test file");
            File file = TestUtils.projectFile(filePath);
            String path = null;
            path = file.getCanonicalPath();
            if (RemoteWebDriver.class.getName().equals(driver.getClass().getName())) {
                TestUtils.waitElementVisible(driver, By.id(elementId));

                WebElement el = driver.findElement(By.xpath("//input[@type='file']"));
                ((RemoteWebElement) el).setFileDetector(new LocalFileDetector());
                TestUtils.wait(2);

                el.sendKeys(path);
            } else {
                TestUtils.wait(2);
                TestUtils.waitElementVisible(driver,By.id(elementId));
                ((JavascriptExecutor)driver).executeScript(
                        "HTMLInputElement.prototype.click = function() {                     " +
                                "  if(this.type !== 'file') HTMLElement.prototype.click.call(this);  " +
                                "};                                                                  " );

                WebElement fileInput = driver.findElement(By.id(elementId));
                fileInput.click();
                driver.findElement(By.cssSelector("input[type=file]"))
                        .sendKeys(path);
            }

            TestUtils.waitElementVisible(driver, fileUploadStatus);

            List<WebElement> elements =driver.findElements(fileUploadStatus);
            if(elements.size()==0) {
                Assert.assertTrue("File was not uploaded successfully", TestUtils.isElementVisible(driver, fileUploadStatus));
            }
            else {
                for (int i = 0; i < elements.size(); i++) {
                    Assert.assertTrue("File was not uploaded successfully", isElementPresent(elements.get(i)));
                }
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Write string to file without throwing exceptions
     *
     * @param fn
     * @param s
     */
    public synchronized static void tryWriteStringToFile(String fn, String s) {
        try {
            FileUtils.writeStringToFile(new File(Conf.getOutputPath() + fn), s);
        } catch (Exception e) {
            // do nothing
        }
    }

    /**
     * Capitalizes a String changing the first letter to title case as
     * No other letters are changed
     *
     * @param param
     * @return
     */
    public static String toInitCap(String param) {
        log.warn("Changing the first letter to title case");
        param = StringUtils.capitalize(param.toLowerCase());
        return param;
    }

    /**
     * Return a list of elements as their text representations
     *
     * @param driver
     * @param by
     * @return
     */
    public static List<String> asTextList(WebDriver driver, By by) {
        List<WebElement> els = null;
        try {
            els = driver.findElements(by);
            if (null == els) {
                return null;
            } else {
                List<String> result = new ArrayList<>(els.size());
                for (WebElement el : els) {
                    result.add(el.getText());
                }
                return result;
            }
        } catch (Exception e) {
            throw new RuntimeException("Unable to get elements by " + by);
        }
    }


    /**
     * Waiting for Angular requests to finish
     *
     * @param d
     */
    public static boolean waitForAngularRequestsToFinish(WebDriver d) {
        log.warn("Waiting for NOT busy indicator...");
        try {
            NgWebDriver ngWebDriver = new NgWebDriver((JavascriptExecutor) d);
            ngWebDriver.waitForAngularRequestsToFinish();
            return true;
        } catch (Exception e) {
            wait(5);
            return true;
        }
    }

    /**
     * Wait until element not visible
     *
     * @param d
     * @param by
     */
    public static boolean waitNotElement(WebDriver d, By by) {
        return new WaitUntil("Waiting for element " + by + " not visible... ",
                new ICondition() {
                    @Override
                    public boolean evaluate() throws Exception {
                        return !isElementPresent(d.findElement(by));
                    }
                }
        ).execute();
    }

    /**
     * Wait until element not visible by xpath (quick version)
     *
     * @param d
     * @param xpath
     */
    public static boolean waitNotElement(WebDriver d, String xpath) {
        return new WaitUntil("Waiting for element " + xpath + " not visible... ",
                new ICondition() {
                    @Override
                    public boolean evaluate() throws Exception {
                        return !isElementVisible(d, xpath);
                    }
                }
        ).execute();
    }

    /**
     * Extract grid rows and post on WhiteBoard for references like this:
     * ${<prefix>_rows}
     * ${<prefix>_<keyHeader1>.<label1>}
     * ${<prefix>_<keyHeader1>.<label2>}
     * ${<prefix>_<keyHeader2>.<label1>}
     * ${<prefix>_<keyHeader2>.<label2>}
     * If the grid is empty:
     * ${<prefix>_footer}
     * <p>
     * Below pagination references are available,
     * ${<prefix>_total_records}
     *
     * @param driver
     * @param scenario
     * @param prefix
     * @param keyHeader
     * @param tableXpath
     */
    public static void extractGridToWhiteBoard(WebDriver driver, Scenario scenario, String prefix, String keyHeader, String tableXpath, boolean hasPagination, boolean isTransposed) {
        Assert.assertTrue(new WaitUntil("Wait for table " + tableXpath + " to appear.", new ICondition() {
            @Override
            public boolean evaluate() throws Exception {
                return isElementVisible(driver, tableXpath);
            }
        }).execute());
        boolean isEmpty = new WaitUntil("Wait for table " + tableXpath + " to be populated.",
                new ICondition() {
                    @Override
                    public boolean evaluate() throws Exception {
                        return TestUtils.countElementsByXpath(driver, tableXpath + "//tr") > 1;
                    }
                }
        ).execute();
        if (isEmpty) {
            log.warn("Table " + tableXpath + " is empty.");
        }

        if (hasPagination) {
            TestUtils.wait(1);
            List<String> pagination = TestUtils.asTextList(driver, By.xpath("//div[@class='pagination ng-scope']/ul/li"));
            if (pagination.toString().contains("Total Records:")) {
                //Total Records displayed
                WhiteBoard.getInstance().putString(scenario.getId(), prefix + "_total_records", "" + pagination.get(0).split(":")[1].trim());
            } else {
                //Total Records NOT displayed
                WhiteBoard.getInstance().putString(scenario.getId(), prefix + "_total_records", "0");
            }
        }

        List<Map<String, String>> maps = isTransposed ?
                TestUtils.transposedTableAsMaps(driver, tableXpath, 10)
                : TestUtils.tableAsMaps(driver, tableXpath, 10);

        Map<String, Map<String, String>> namedMaps = DataTableUtils.dataTableAsMapsIndexedByKeyHeader(keyHeader, maps, true);
        WhiteBoard.storeMaps(scenario.getId(), prefix, Conf.getOutputPath(), namedMaps);

        if (maps.size() <= 0) {
            try {
                String footer = TestUtils.text(driver, By.xpath(tableXpath + "/tfoot"));
                WhiteBoard.getInstance().putString(scenario.getId(), prefix + "_footer", footer);
            } catch (Exception e) {
                log.warn("Footer not available.");
            }
        }
        try {
            DataTable dt = DataTable.create(maps);
            String dtString = dt.toString();
            scenario.write(dtString);
            if (Conf.getInstance().isDemo()) {
                String fn = Conf.getOutputPath();
                fn += prefix + "_" + ZonedDateUtils.timestamp() + ".txt";
                FileUtils.writeStringToFile(new File(fn), dtString);
            }
        } catch (Exception e) {
            //do nothing
        }
    }

    /**
     * Get dropdown list options:
     * - if it's a select dropdown: call getOptions()
     * - if it's a ul dropdown: find all li elements
     *
     * @param driver
     * @param locator
     * @return
     */
    public static List<String> getDropdownListOptions(WebDriver driver, By locator) {
        if (!isElementVisible(driver, locator)) {
            return new ArrayList<>(0);
        }
        WebElement el = driver.findElement(locator);

        List<WebElement> optionElements = null;
        if (el.getAttribute("class").contains("tk-multi-sel")) {
            el.findElement(By.xpath(".//button[@role='listbox']")).click();
            TestUtils.wait(2);
            optionElements = el.findElements(By.xpath(".//div[contains(@class, 'tk-multi-item')]"));
        } else {
            String tag = el.getTagName();
            switch (tag) {
                case "uitk-select":
                    el = el.findElement(By.xpath(".//select"));
                case "select":
                    Select select = new Select(el);
                    optionElements = select.getOptions();
                    el.click();
                    TestUtils.wait(1);
                    break;
                case "ul":
                    optionElements = el.findElements(By.xpath("li"));
                    break;
                case "span":
                    optionElements = driver.findElements(By.cssSelector("div[ng-repeat='item in filteredModel | filter:removeGroupEndMarker']"));
                    break;
                default:
                    Assert.fail("Unsupported dropdown tag: " + tag);
            }
        }
        List<String> options = new ArrayList<>(optionElements.size());
        for (WebElement optionElement : optionElements) {
            options.add(optionElement.getText());
        }
        return options;
    }

    /**
     * Find the file based on specified project name and relative path in below order:
     * - specified project
     * - common project
     * - base project
     * - null
     *
     * @param myProject
     * @param relativePath
     * @return
     */
    public static File projectFile(String myProject, String relativePath) {
        File file = oneProjectFile(myProject, relativePath);
        if (file.exists()) {
            return file;
        }
        file = oneProjectFile(ConfBase.COMMON_PROJECT, relativePath);
        if (file.exists()) {
            return file;
        }
        file = oneProjectFile(ConfBase.BASE_PROJECT, relativePath);
        if (file.exists()) {
            return file;
        }
        file = new File(relativePath);

        return file;
    }

    private static File oneProjectFile(String projectName, String relativePath) {
        String root = System.getProperty("user.dir");
        if (root.contains(projectName)) {
            return new File(root + File.separator + relativePath);
        } else {
            File file = new File(root + File.separator + projectName + File.separator + relativePath);
            if (file.exists()) {
                return file;
            }
            return new File(root + File.separator + ".." + File.separator + projectName + File.separator + relativePath);
        }
    }

    /**
     * Find the file based on specified relative path in below order:
     * - current project
     * - common project
     * - base project
     * - null
     *
     * @param relativePath
     * @return
     */
    public static File projectFile(String relativePath) {
        String myProject = Conf.getInstance().getProperty(ConfBase.PROJECT_KEY);
        return projectFile(myProject, relativePath);
    }

    /**
     * Get all the class types of an object array.
     * Useful for reflection.
     *
     * @param args
     * @return
     */
    public static Class<?>[] types(Object[] args) {
        int length = null == args ? 0 : args.length;
        Class<?>[] types = new Class<?>[length];
        if (length <= 0) {
            return types;
        }
        for (int i = 0; i < length; i++) {
            Class<?> clazz = args[i].getClass();
            types[i] = clazz;
        }
        return types;
    }

    /**
     * To check if a radio button/checkbox is checked or not.
     *
     * @param driver
     * @param by
     * @return
     */
    public static boolean isChecked(WebDriver driver, By by) {
        return isChecked(driver.findElement(by));
    }

    /**
     * To check if a radio button/checkbox is checked or not.
     *
     * @param el
     * @return
     */
    public static boolean isChecked(WebElement el) {
        return "true".equalsIgnoreCase(el.getAttribute("checked"));
    }

    /**
     * Find an element by any locator string.
     *
     * @param driver
     * @param locatorString
     * @return
     */
    public static WebElement slowFindElement(WebDriver driver, String locatorString, String parentXpath) {
        return slowFindElement(driver, locatorString, null, parentXpath);
    }

    /**
     * Find an element by any locator string with condition.
     *
     * @param driver
     * @param locatorString
     * @return
     */
    public static WebElement slowFindElement(WebDriver driver, String locatorString, IElementCondition elementCondition, String parentXpath) {
        By by = SlowBy.by(driver, locatorString, null, elementCondition, parentXpath);
        if (null == by) {
            return null;
        } else {
            return findElements(driver, by).get(0);
        }
    }

    /**
     * A generic method to check if a locator is valid not
     *
     * @param driver
     * @param by
     * @return
     */
    public static boolean isValidLocator(WebDriver driver, By by) {
        return isValidLocator(driver, by, null);
    }

    /**
     * A generic method to check if a locator is valid not
     *
     * @param driver
     * @param by
     * @param elementCondition
     * @return
     */
    public static boolean isValidLocator(WebDriver driver, By by, IElementCondition elementCondition) {
        try {
            List<WebElement> els = findElements(driver, by, elementCondition);
            return 1 == els.size();
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Find only visible elements by xpath String
     *
     * @param driver
     * @param xpath
     * @return
     */
    public static List<WebElement> findElements(WebDriver driver, String xpath) {
        return findElements(driver, By.xpath(xpath));
    }

    /**
     * Find only visible elements by locator
     *
     * @param driver
     * @param by
     * @return
     */
    public static List<WebElement> findElements(WebDriver driver, By by) {
        return findElements(driver, by, null);
    }

    /**
     * Find only visible elements that satisfies given condition by locator
     *
     * @param driver
     * @param by
     * @param elementCondition
     * @return
     */
    public static List<WebElement> findElements(WebDriver driver, By by, IElementCondition elementCondition) {
        if (null == elementCondition) {
            elementCondition = IElementCondition.ALWAYS_TRUE;
        }
        List<WebElement> els = driver.findElements(by);
        List<WebElement> elsResult = new ArrayList<>(els.size());
        for (WebElement el : els) {
            String classAtr = el.getAttribute("class");
            if (el.isDisplayed() && !classAtr.contains("hidden") && elementCondition.evaluate(driver, el)) {
                elsResult.add(el);
            }
        }
        return elsResult;
    }

    /**
     * Return a List<String> object representing the specified column in the specified table element.
     *
     * @param driver
     * @param tableXpath
     * @param columnName
     * @return
     */
    public static List<String> tableColumnAsList(WebDriver driver, String tableXpath, String columnName) {
        List<WebElement> headerTds = driver.findElements(By.xpath(tableXpath + "//thead//td"));
        int columnIndex = -1;
        for (int i = 0; i < headerTds.size(); i++) {
            if (headerTds.get(i).getText().trim().equals(columnName.trim())) {
                columnIndex = i;
                break;
            }
        }
        if (-1 == columnIndex) {
            Assert.fail("No column " + columnName + " in table " + tableXpath);
        }
        List<WebElement> columnTds = driver.findElements(By.xpath(tableXpath + "//tbody/tr/td[" + (columnIndex + 1) + "]"));
        List<String> list = new ArrayList<>(columnTds.size());
        for (int i = 0; i < columnTds.size(); i++) {
            list.add(columnTds.get(i).getText());
        }
        return list;
    }

    /**
     * A generic method to input based on label name
     *
     * @param d
     * @param label
     * @param input
     * @return
     */
    public static boolean inputBasedOnLabelName(WebDriver d, String input, String label) {
        By by = By.xpath("(//label[contains(text(),'" + label + "')]//ancestor::td[1]//following::td[1]//*)[1]");
        log.warn("Input based on label : " + label + "");
        TestUtils.waitElementVisible(d, by);
        return input(d, by, input);

    }

    /**
     * A generic method to input based on label name using following-sibling
     *
     * @param d
     * @param criteria
     * @param xpath
     * @return
     */
    public static boolean inputBasedOnLabelName(WebDriver d, Map<String, String> criteria, String xpath) {
        List<List<String>> data = DataTableUtils.asLists(criteria);
        log.warn("Data to be input: " + data.toString());

        for (List<String> list : data) {
            String locatorString = list.get(0);
            String value = list.get(1);

            By by = By.xpath(xpath + "'" + locatorString + "')]/../following-sibling::input");
            log.warn("Input based on label : " + locatorString + "");
            TestUtils.waitElementVisible(d, by);
            return input(d, by, value);
        }
        return true;
    }

    /**
     * Input page field-value pairs specified with List<List<String>> instance in below convention:
     * [["locator1", "value1"], ["locator2", "value2"], ...]
     *
     * @param d
     * @param data
     * @param pageObjectPackageName
     * @return
     */
    public static boolean inputAll(WebDriver d, List<List<String>> data, String pageObjectPackageName, String parentXpath) {
        log.warn("Data to be input: " + data.toString());
        PageObjectUtils pageObjectUtils = null;
        if (null != pageObjectPackageName) {
            pageObjectUtils = new PageObjectUtils(pageObjectPackageName);
        }
        for (List<String> list : data) {
            String locatorString = list.get(0);
            String value = list.get(1);

            List<By> byContainer = new ArrayList<>(1);
            boolean success = TestUtils.waitUntil("Wait Element visible: " + locatorString, 3, new ICondition() {
                @Override
                public boolean evaluate() throws Exception {
                    By by = SlowBy.by(d, locatorString, null, EditableFactory.EDITABLE, parentXpath);
                    if (null == by) {
                        return false;
                    } else {
                        byContainer.add(by);
                        return true;
                    }
                }
            });
            if (!success) {
                log.error("Missing locator: " + locatorString);
                return false;
            }

            By by = byContainer.get(0);
            if (!input(d, by, value)) {
                log.error("Input fail: " + locatorString + "=" + value);
                return false;
            }
        }
        return true;
    }

    /**
     * Input page label-value pairs specified with List<List<String>> instance in below convention:
     * [["label1", "value1"], ["label2", "value2"], ...]
     *
     * @param d
     * @param data
     * @return
     */
    public static boolean inputAllByLabels(WebDriver d, List<List<String>> data, String parentXpath) {
        log.warn("Data to be input: " + data.toString());
        for (List<String> list : data) {
            String locatorString = list.get(0);
            String value = list.get(1);

            List<By> byContainer = new ArrayList<>(1);
            boolean success = TestUtils.waitUntil("Wait labeled element visible: " + locatorString, 3, new ICondition() {
                @Override
                public boolean evaluate() throws Exception {
                    By by = SlowBy.by(d, "labelForId>>rightSideTd>>downSideTd>>" + locatorString, null, EditableFactory.EDITABLE, parentXpath);
                    if (null == by) {
                        return false;
                    } else {
                        byContainer.add(by);
                        return true;
                    }
                }
            });
            if (!success) {
                log.error("Missing label: " + locatorString);
                return false;
            }

            By by = byContainer.get(0);
            if (!input(d, by, value)) {
                log.error("Input fail: " + locatorString + "=" + value);
                return false;
            }
        }
        return true;
    }

    /**
     * Input page label-value pairs specified with Map<String, String> instance in below convention:
     * {"label1"="value1", "label2"="value2", ...}
     *
     * @param d
     * @param map
     * @return
     */
    public static boolean inputAllByLabels(WebDriver d, Map<String, String> map, String parentXpath) {
        List<List<String>> data = DataTableUtils.asLists(map);
        return inputAllByLabels(d, data, parentXpath);
    }

    /**
     * Wait until a custom condition to be true.
     *
     * @param trace
     * @param timeoutInSeconds
     * @param condition
     * @return
     */
    public static boolean waitUntil(String trace, int timeoutInSeconds, ICondition condition) {
        WaitUntil waitUntil = new WaitUntil(trace, timeoutInSeconds * 1000, 100, 100, condition);
        return waitUntil.execute();
    }

    /**
     * Keep clicking a Sort Icon until the sort order is changed.
     *
     * @param d
     * @param sortIcon
     * @return
     */
    public static boolean clickSortIcon(WebDriver d, By sortIcon) {
        WebElement sortElement = d.findElement(sortIcon);
        boolean isDesc0 = isDesc(sortElement);

        Retry retry = new Retry("Retry clicking sort icon: " + sortIcon) {
            @Override
            protected void tryOnce() throws Exception {
                click(d, sortIcon);
            }

            @Override
            protected boolean until() throws Exception {
                return isDesc0 != isDesc(d.findElement(sortIcon));
            }
        };

        return retry.execute();
    }

    private static boolean isDesc(WebElement sortElement) {
        String classAttribute = sortElement.getAttribute("class");
        if (classAttribute.contains("cux-icon-sort_down")) {
            return true;
        } else if (classAttribute.contains("cux-icon-sort_up")) {
            return false;
        } else {
            Assert.fail("Not a sortable column");
            return false;
        }
    }

    public static WebElement slowFindClickableElement(WebDriver d, String locatorString, String parentXpath) {
        try {
            By by = SlowBy.by(d, locatorString, null, new IElementCondition() {
                @Override
                public boolean evaluate(WebDriver webDriver, WebElement element) {
                    return TestUtils.isClickable(webDriver, element);
                }
            }, parentXpath);
            return d.findElement(by);
        } catch (Exception e) {
            return null;
        }
    }

    public static void waitAppearAndDisappear(WebDriver driver, By by, int appearTimeoutInSeconds, int disappearTimeoutInSeconds) {
        if (waitUntil("Wait for appear: " + by, appearTimeoutInSeconds,
                new ICondition() {
                    @Override
                    public boolean evaluate() throws Exception {
                        return TestUtils.isElementVisible(driver, by);
                    }
                })) {
            waitUntil("Wait for disappear: " + by, disappearTimeoutInSeconds,
                    new ICondition() {
                        @Override
                        public boolean evaluate() throws Exception {
                            return !TestUtils.isElementVisible(driver, by);
                        }
                    });
        }
    }

    /**
     * Wait for busyIndicatorImage to appear and disappear
     *
     * @param d
     */
    public static void waitForNotBusy(WebDriver d) {
        waitForAngularRequestsToFinish(d);
        waitAppearAndDisappear(d, By.xpath("//img[@id='busyIndicatorImage']"), 3, 120);
    }

    /**
     * Immediate abort check: throws a RuntimeException
     *
     * @param scenario
     */
    public static void immediateAbortCheck(Scenario scenario) {
        if (null != scenario && scenario.isFailed()) {
            try {
                TestUtils.screenshot(scenario, driver(), "Last Screenshot - Scenario Failed");
            } catch (IOException e) {
                e.printStackTrace();
            }
            throw new ImmediateAbortException("Scenario failure detected: " + scenario.getName());
        }
    }

    /**
     * For logging: write a String or random Object instance as a json file
     *
     * @param name  name
     * @param value value
     */
    public static void tryLoggingJsonString(String name, Object value) {
        try {
            if (StringUtils.isEmpty(name) || null == value) {
                return;
            }
            String jsonString = null;
            if (value instanceof String) {
                String sValue = (String) value;
                if (StringUtils.isEmpty(sValue)) {
                    return;
                }
                jsonString = QuickJson.prettyJson(sValue);
            } else {
                jsonString = QuickJson.prettyJson(value);
            }
            if (StringUtils.isEmpty(jsonString)) {
                return;
            } else {
                String logFileName = name + "_" + ZonedDateUtils.timestamp();
                FileUtils.writeStringToFile(new File(Conf.getOutputPath() + logFileName + ".json"), jsonString);
            }
        } catch (IOException e) {
            e.printStackTrace();
            // do nothing
        }
    }

    public static void closeCurrentTab(WebDriver driver) {
        driver.close();
        Set<String> handles = driver.getWindowHandles();
        driver.switchTo().window(handles.iterator().next());
    }

    public static void swithToOldWindow(WebDriver driver, String handle) {
        driver.switchTo().window(handle);
    }

    public static void swithToWindow(WebDriver driver, String url) {
        Set<String> handles = driver.getWindowHandles(); // Gets all the available windows
        for (String handle : handles) {
            driver.switchTo().window(handle); // switching back to each window in loop
            if (driver.getCurrentUrl().contains(url)) {
                break;
            }
        }

    }

    /**
     * Getting todays date MM-dd-yyyy
     *
     * @param
     */
    public static String getTomorrowDateMMddyyyy() {
        DateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy");
        Date date = new Date();
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(5, 2);
        return dateFormat.format(c.getTime());
    }

    /**
     * Getting element using label Text
     *
     * @param labelName, elementType, driver()
     * @return
     */
    public static WebElement getElementUsingText(String labelName, String elementType) {
        String xpath = elementType.concat("[text() ='").concat(labelName).concat("']");
        return driver().findElement(By.xpath(xpath));

    }

    public static Logger getInstance() {
        String callingClassName = Thread.currentThread().getStackTrace()[2].getClassName();
        return LogManager.getLogger(callingClassName);
    }


    public static void clearTextBox(By by, WebDriver driver) {
        try {
            Thread.sleep(2000);
            driver.findElement(by).clear();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    /**
     * Compare Two Dates Test
     *
     * @param today
     * @param actualDate
     * @return
     * @throws ParseException
     */
    public static int compareTwoDatesTest(String today, String actualDate) throws ParseException {
        SimpleDateFormat sdformat = new SimpleDateFormat("MM-dd-yyy");
        Date d1 = sdformat.parse(today);
        Date d2 = sdformat.parse(actualDate);

        if (d1.compareTo(d2) > 0) {
            // "Date 1 occurs after Date 2"
        } else if (d1.compareTo(d2) < 0) {
            //"Date 1 occurs before Date 2"
            return -1;
        } else if (d1.compareTo(d2) == 0) {
            //"Both dates are equal"
            return 0;
        }
        return 1;
    }


    public static String switchToLatestWindow(WebDriver d) {
        String oldHandle = d.getWindowHandle();
        String newWindowHandle = "";

        for (String windowhandle : d.getWindowHandles()) {

            newWindowHandle = windowhandle;

        }
        log.warn("switching window to " + d.getTitle() +
                "\r\n\turl=" + d.getCurrentUrl() + "\r\n\thandler=" + d.getWindowHandle());

        d.switchTo().window(newWindowHandle);

        return oldHandle;
    }
    /**
     * Getting todays date MM-dd-yyyy
     *
     * @param
     */
    public static String getDaysLaterFromToday(String num) {
        DateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy");
        Date date = new Date();
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        int numParsed = Integer.parseInt(num);
        c.add(5, -numParsed);
        return dateFormat.format(c.getTime());
    }


    /**
     * Getting  business days earlier date MM-dd-yyyy
     *
     * @param
     */
    public static String getBusinessDaysEarlierFromToday(int num) {

        DateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy");

        final List<Integer> NON_BUSINESS_DAYS = Arrays.asList(
                Calendar.SATURDAY,
                Calendar.SUNDAY
        );

        Calendar calendar = Calendar.getInstance();

        for (int i = 0; i <= num;) {
            calendar.add(Calendar.DAY_OF_MONTH, -1);
            if (!NON_BUSINESS_DAYS.contains(calendar.get(Calendar.DAY_OF_WEEK))){
                i++;
            }
        }

        return dateFormat.format(calendar.getTime());
    }


    /**
     * @return The current web driver's URL.
     */
    public static String getCurrentUrl() {
        return driver().getCurrentUrl();
    }

}
