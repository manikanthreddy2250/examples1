package atdd.utils;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ViewAssignmentCollector {
    private static final Logger log = Logger.getLogger(ViewAssignmentCollector.class);

    public static Map<String, String> collect(WebDriver d) {
        new WebDriverWait(d, 20).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(), 'View Assignment')]")));
        if (1 == d.findElements(By.xpath("//*[contains(text(), 'View Assignment')]")).size()) {
            Map<String, List<List<String>>> namedLists = new LinkedHashMap<String, List<List<String>>>();


            //Assignment
            List<List<String>> assignment = TestUtils.tableAsLists(d, "(//div[@id='assignmentPanelIdContent']//div[3]/table/tbody//table)[1]", 10);

            //Assigned To
            List<List<String>> assign_to = TestUtils.tableAsLists(d, "(//div[@id='assignmentPanelIdContent']//div[3]/table/tbody//table)[2]", 10);

            namedLists.put("assignment", assignment);
            namedLists.put("assignto", assign_to);


            Map<String, String> raw = new LinkedHashMap<>();
            Map<String, String> profile = new LinkedHashMap<>();
            for (String name : namedLists.keySet()) {
                List<List<String>> lists = namedLists.get(name);
                for (List<String> list : lists) {
                    if (2 == list.size()) {
                        raw.put(name + "::" + list.get(0), list.get(1));
                        profile.put(name + "_" + TestUtils.makeName(list.get(0)), v(list.get(1)));
                    }
                }
            }

            Map<String, String> result = new LinkedHashMap<>(profile.size());
            for (String key : profile.keySet()) {
                String newKey = key.replace("_", "");
                result.put(newKey, profile.get(key));
                log.warn(newKey + "=" + profile.get(key));
            }

            return result;
        }
        return null;
    }

    private static String v(String s) {
        return s.replace('\n', '>').trim();
    }

}
