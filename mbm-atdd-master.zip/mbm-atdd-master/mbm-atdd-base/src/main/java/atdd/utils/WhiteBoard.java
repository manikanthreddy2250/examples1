package atdd.utils;

import atdd.common.EvaluateException;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class WhiteBoard {

    public static final String OWNER_GLOBAL = "GLOBAL";

    public static final String RESERVED_NOW = "now";

    public static final String RESERVED_TODAY = "today";

    public static final String RESERVED_TODAY_REVERSED = "today_reversed";

    public static final String RESERVED_YESTERDAY = "yesterday";

    public static final String RESERVED_TOMORROW = "tomorrow";

    public static final String RESERVED_RANDOM = "random";

    public static final String RESERVED_RANDOM5 = "random5";

    public static final String RESERVED_RANDOM10 = "random10";

    public static final String RESERVED_CVT_DT = "cvtDt";

    public static final String PARAM_SEPARATOR = ">";

    private static final String WHITEBOARD_GLOBAL = "whiteboard_global";

    private static Logger log = Logger.getLogger(WhiteBoard.class.getName());

    private final static String REGEX_CONTAINS_VAR_EXPRESSION = ".*\\$\\{[^\\{\\}]+\\}.*";

    private final static Pattern PATTERN_STRING_VAR = Pattern.compile("(\\$\\{([^\\{\\}]+)\\})");
    private final static Pattern PATTERN_MAP_VAR = Pattern.compile("(\\$\\{([^\\{\\}\\.]+)\\.([^\\{\\}]+)\\})");

    private final static Pattern PATTERN_ESCAPE = Pattern.compile("(#\\{([^\\{\\}]+)\\})");
    private final static Pattern PATTERN_ESCAPE_MAP = Pattern.compile("(#\\{([^\\{\\}\\.]+)\\.([^\\{\\}]+)\\})");

    private Map<String, Map<String, Map<String, String>>> mapVars = new LinkedHashMap<String, Map<String, Map<String, String>>>();
    private Map<String, Map<String, String>> stringVars = new LinkedHashMap<String, Map<String, String>>();

    private static WhiteBoard ourInstance = new WhiteBoard();

    static {
        ourInstance.putString(OWNER_GLOBAL, "COMMA", ",");
        ourInstance.putString(OWNER_GLOBAL, "DASH", "-");
        ourInstance.putString(OWNER_GLOBAL, "QUOTE", "\"");
    }

    private String[] protectedKeys;

    public static WhiteBoard getInstance() {
        return ourInstance;
    }

    public static List<Map<String, String>> resolve(String owner, List<Map<String, String>> maps) {
        List<Map<String, String>> m = new ArrayList<Map<String, String>>(maps.size());
        for (Map<String, String> map : maps) {
            m.add(resolve(owner, map));
        }
        return m;
    }

    public static String[] resolveArray(String owner, String[] arrayOfStrings) {
        String[] result = new String[arrayOfStrings.length];

        for (int i = 0; i < arrayOfStrings.length; i++) {
            result[i] = WhiteBoard.resolve(owner, arrayOfStrings[i]);
        }

        return result;
    }

    public static List<String> resolveStringList(String owner, List<String> list) {
        List<String> l = new ArrayList<>(list.size());
        for (String s : list) {
            l.add(resolve(owner, s));
        }
        return l;
    }

    // resolve all var-expression values in map
    public static Map<String, String> resolve(String owner, Map<String, String> map) {
        Map<String, String> m = new LinkedHashMap<>(map.size());
        for (String key : map.keySet()) {
            String resolvedKey = resolve(owner, key);
            String resolvedValue = resolve(owner, map.get(key));
            m.put(resolvedKey, resolvedValue);
        }

        return m;
    }

    // return the first non-null result resolving a list of var-expressions
    public static String resolve(String owner, String... expressions) {
        if (null == expressions || 0 == expressions.length) {
            throw new RuntimeException("Nothing to resolve.");
        }

        for (String expression : expressions) {
            if (null == expression) {
                continue;
            } else {
                String result = resolveOne(owner, expression);
                if (null != result && !result.matches(REGEX_CONTAINS_VAR_EXPRESSION)) {
                    return escape(result);
                }
            }
        }
        return null;
    }

    // resolve all var-expression's in a string like "bla... ${var1} bla... ${t1.stage} bla..."
    // returns null if var-expression invalid
    public static String resolveOne(String owner, String expression) {
        String s0 = expression;
        List<String> protectedKeyList = Arrays.asList(getInstance().protectedKeys);

        Pattern pattern = PATTERN_STRING_VAR;
        Matcher matcher = pattern.matcher(expression);
        if (matcher.find()) {
            String key = matcher.group(2);
            if (protectedKeyList.contains(key)) {
                throw new RuntimeException("Not able to resolve protected key: " + key);
            }
            String value = getInstance().getString(owner, key);
            if (null != value) {
                return resolveOne(owner, matcher.replaceFirst(value.replace("$", "_DOLLAR_").replace("\\", "_SLASH_")).replace("_DOLLAR_", "$").replace("_SLASH_", "\\"));
            }
        }

        pattern = PATTERN_MAP_VAR;
        matcher = pattern.matcher(expression);
        if (matcher.find()) {
            String key = matcher.group(2);
            Map<String, String> map = getInstance().getMap(owner, key);
            if (null == map) {
                log.error("Undefined map variable: " + key + " in expression " + s0);
                return null;
            }

            String field = matcher.group(3);
            String value = map.get(field);
            if (null != value) {
                return resolveOne(owner, matcher.replaceFirst(value.replace("$", "_DOLLAR_").replace("\\", "_SLASH_")).replace("_DOLLAR_", "$").replace("_SLASH_", "\\"));
            } else {
                log.error("Undefined field: " + field + " map object " + key + " in expression " + s0);
                return null;
            }
        }

        return expression;

    }

    // resolve all var-expression's in a string like "bla... #{var1} bla... #{t1.stage} bla..."
    // returns null if var-expression invalid
    public static String escape(String expression) {
        String s0 = expression;

        Pattern pattern = PATTERN_ESCAPE;
        Matcher matcher = pattern.matcher(expression);
        if (matcher.find()) {
            String key = matcher.group(2);
            String value = getInstance().getString(OWNER_GLOBAL, key);
            if (null == value) {
                log.error("Undefined special string: " + key + " in expression " + s0);
                return null;
            }
            return escape(matcher.replaceFirst(value.replace("$", "_DOLLAR_").replace("\\", "_SLASH_")).replace("_DOLLAR_", "$").replace("_SLASH_", "\\"));
        }

        pattern = PATTERN_ESCAPE_MAP;
        matcher = pattern.matcher(expression);
        if (matcher.find()) {
            String key = matcher.group(2);
            Map<String, String> map = getInstance().getMap(OWNER_GLOBAL, key);
            if (null == map) {
                log.error("Undefined special map: " + key + " in expression " + s0);
                return null;
            }

            String field = matcher.group(3);
            String value = map.get(field);
            if (null != value) {
                return escape(matcher.replaceFirst(value.replace("$", "_DOLLAR_").replace("\\", "_SLASH_")).replace("_DOLLAR_", "$").replace("_SLASH_", "\\"));
            } else {
                log.error("Undefined special string: " + field + " map object " + key + " in expression " + s0);
                return null;
            }
        }

        return expression;

    }

    public static void putAll(Map<String, String> whiteboardObject, List<Map<String, Object>> daoRows, String prefix, Set<String> ignore) {
        if (0 == daoRows.size()) {
            return;
        }

        prefix = null == prefix ? "" : prefix.trim();
        if (1 == daoRows.size()) {
            for (String key : daoRows.get(0).keySet()) {
                if (!ignore.contains(key)) {
                    whiteboardObject.put(prefix + key, daoRows.get(0).get(key).toString());
                }
            }
        } else {
            for (int i = 0; i < daoRows.size(); i++) {
                Map<String, Object> row = daoRows.get(i);
                for (String key : row.keySet()) {
                    if (!ignore.contains(key)) {
                        whiteboardObject.put(prefix + key + "_" + i, row.get(key).toString());
                    }
                }
            }
        }
    }

    public static Map<String, String> snapshot(Map<String, Map<String, String>> group) {
        Map<String, String> groupPhoto = new TreeMap<>();
        for (String name : group.keySet()) {
            Map<String, String> map = group.get(name);
            for (String key : map.keySet()) {
                String name_key = name + "-" + key;
                groupPhoto.put(name_key, map.get(key));
            }
        }
        return groupPhoto;
    }

    public static void storeMaps(String owner, String prefix, String output, Map<String, Map<String, String>> maps) {
        storeMaps(owner, prefix,output, maps, false);
    }

    public static void storeMaps(String owner, String prefix, String output, Map<String, Map<String, String>> maps, boolean withRestore) {
        if (null == maps) {
            return;
        }
        if (!StringUtils.isEmpty(prefix)) {
            WhiteBoard.getInstance().putString(owner, prefix + "_rows", "" + maps.size());
            WhiteBoard.getInstance().putString(owner, prefix + "_keys", maps.keySet().toString());
            WhiteBoard.getInstance().putList(owner, prefix + "_keyList", new ArrayList<>(maps.keySet()));
        }
        String mapName = null;
        for (String key : maps.keySet()) {
            mapName = StringUtils.isEmpty(prefix) ? key : prefix + "_" + key;
            WhiteBoard.getInstance().putMap(owner, mapName, maps.get(key), withRestore);
        }
    }

    public static boolean evaluate(String owner, String conditionExpression) throws EvaluateException {
        try {
            if (conditionExpression.matches(".+\\s+is\\s+empty\\s*")) {
                String[] p = conditionExpression.split("\\s+is\\s+empty", 2);
                return StringUtils.isEmpty(WhiteBoard.resolve(owner, p[0]));
            } else if (conditionExpression.matches(".+\\s+is\\s+greater\\s+than\\s+.+")) {
                String[] p = conditionExpression.split("\\s+is\\s+greater\\s+than\\s+", 2);
                String p0 = WhiteBoard.resolve(owner, p[0]).trim();
                String p1 = WhiteBoard.resolve(owner, p[1]).trim();
                int left = Integer.parseInt(p0);
                int right = Integer.parseInt(p1);
                return left > right;
            } else if (conditionExpression.matches(".+\\s+matches\\s+.+")) {
                String[] p = conditionExpression.split("\\s+matches\\s+", 2);
                String p0 = WhiteBoard.resolve(owner, p[0]).trim();
                String p1 = WhiteBoard.resolve(owner, p[1]).trim();
                return p0.equals(p1) || p0.matches(p1);
            } else if (conditionExpression.matches(".+\\s+is\\s+not\\s.+")) {
                //"a is not b" --> [a, b]
                //"a is not b is not c" --> [a, b is c]
                String[] p = conditionExpression.split("\\s+is\\s+not\\s+", 2);
                String p0 = WhiteBoard.resolve(owner, p[0]);
                String p1 = WhiteBoard.resolve(owner, p[1]);
                return !p0.equals(p1);
            } else if (conditionExpression.matches(".+\\s+is\\s.+")) {
                //"a is b" --> [a, b]
                //"a is b is c" --> [a, b is c]
                String[] p = conditionExpression.split("\\s+is\\s+", 2);
                String p0 = WhiteBoard.resolve(owner, p[0]);
                String p1 = WhiteBoard.resolve(owner, p[1]);
                return p0.equals(p1);
            }

            return false;
        } catch (Exception e) {
            throw new EvaluateException(e);
        }
    }

    public static List<List<String>> resolveListOfStringList(String owner, List<List<String>> listOfStringList) {
        List<List<String>> result = new ArrayList<>(listOfStringList.size());
        for (List<String> l : listOfStringList) {
            result.add(resolveStringList(owner, l));
        }
        return result;
    }

    public void removeOwner(String owner) {
        this.mapVars.remove(owner);
        this.stringVars.remove(owner);
    }

    public String putString(String owner, String key, String value) {
        if (null == key || key.trim().isEmpty()) {
            throw new RuntimeException("String variable name is empty or is resolved as empty: " + key);
        }
        if (!this.stringVars.containsKey(owner)) {
            this.stringVars.put(owner, new LinkedHashMap<String, String>());
        }
        TestUtils.tryLoggingJsonString(key, value);

        return this.stringVars.get(owner).put(key, value);
    }

    public Map<String, String> putMap(String owner, String key, Map<String, String> value) {
        if (null == key || key.trim().isEmpty()) {
            throw new RuntimeException("Map variable name is empty or is resolved as empty: " + key);
        }
        if (!this.mapVars.containsKey(owner)) {
            this.mapVars.put(owner, new LinkedHashMap<String, Map<String, String>>());
        }
        Map<String, String> previousMap = this.mapVars.get(owner).put(key, value);
        TestUtils.tryLoggingJsonString(key, value);
        return previousMap;
    }

    public Map<String, String> putMap(String owner, String key, Map<String, String> value, boolean withRestore) {
        Map<String, String> previousMap = this.putMap(owner, key, value);
        if (withRestore) {
            try {
                //for restore
                String output = Conf.getOutputPath();
                String jsonString = QuickJson.prettyJson(value);
                FileUtils.writeStringToFile(new File(output + key + ".json"), jsonString);
            } catch (IOException e) {
                e.printStackTrace();
                // do nothing
            }
        }
        return previousMap;
    }

    public String getString(String owner, String key) {
        switch (key) {
            case RESERVED_NOW:
                //${now}
                ZonedDateTime now = ZonedDateTime.now();
                return ZonedDateUtils.calcFormat(now, 0, ChronoUnit.DAYS, ZonedDateUtils.mmDdYyyyHMmA);
            case RESERVED_TODAY:
                //${today}
                return ZonedDateUtils.mmDdYyyy();
            case RESERVED_TODAY_REVERSED:
                //${today_reversed}
                DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                Date date = new Date();
                return dateFormat.format(date);
            case RESERVED_YESTERDAY:
                //${yesterday}
                return ZonedDateUtils.mmDdYyyyYesterday();
            case RESERVED_TOMORROW:
                //${tomorrow}
                return ZonedDateUtils.mmDdYyyyTomorrow();
            case RESERVED_RANDOM10:
                //${random10}
                return StringUtils.randomDigits(10);
            case RESERVED_RANDOM5:
                //${random5}
                return StringUtils.randomDigits(5);
        }

        if (key.contains(PARAM_SEPARATOR)) {
            String[] p = key.split(PARAM_SEPARATOR, 2);
            ZonedDateTime now = ZonedDateTime.now();
            switch (p[0]) {
                case RESERVED_TODAY:
                    if (p[1].contains(PARAM_SEPARATOR)) {
                        //${today>-3>MM-dd-yyyy}
                        String[] pp = p[1].split(PARAM_SEPARATOR, 2);
                        int days = Integer.parseInt(pp[0]);
                        return ZonedDateUtils.calcFormat(now, days, ChronoUnit.DAYS, pp[1]);
                    } else {
                        //${today>MM-dd-yyyy}
                        return ZonedDateUtils.calcFormat(now, 0, ChronoUnit.DAYS, p[1]);
                    }
                case RESERVED_YESTERDAY:
                    //${yesterday>MM-dd-yyyy}
                    return ZonedDateUtils.calcFormat(now, -1, ChronoUnit.DAYS, p[1]);
                case RESERVED_TOMORROW:
                    //${tomorrow>MM-dd-yyyy}
                    return ZonedDateUtils.calcFormat(now, 1, ChronoUnit.DAYS, p[1]);
                case RESERVED_NOW:
                    if (p[1].contains(PARAM_SEPARATOR)) {
                        //${now>-3d>MM-dd-yyyy h:mm a}
                        //${now>+3h>MM-dd-yyyy H:mm}
                        //${now>30m>yyyy-MM-dd'T'HH:mm:ss.SSSZ}
                        String[] pp = p[1].split(PARAM_SEPARATOR, 2);
                        long seconds = ZonedDateUtils.toSeconds(pp[0]);
                        return ZonedDateUtils.calcFormat(now, seconds, ChronoUnit.SECONDS, pp[1]);
                    } else {
                        //${now>MM-dd-yyyy h:mm a}
                        return ZonedDateUtils.calcFormat(now, 0, ChronoUnit.SECONDS, p[1]);
                    }
                case RESERVED_RANDOM:
                    //${radom>7}
                    return StringUtils.randomDigits(Integer.parseInt(p[1]));
                case RESERVED_CVT_DT:
                    String[] pp = p[1].split(PARAM_SEPARATOR);
                    if (5 == pp.length) {
                        //${cvtDt>09-17-2019 9:40 PM>MM-dd-yyyy h:mm a>${timeZoneDb}>MM-dd-yyyy h:mm a>${timeZone}}
                        ZonedDateTime zdt = ZonedDateTime.parse(pp[0], DateTimeFormatter.ofPattern(pp[1]).withZone(ZoneId.of(pp[2])));
                        return DateTimeFormatter.ofPattern(pp[3]).withZone(ZoneId.of(pp[4])).format(zdt);
                    } else if (6 == pp.length) {
                        //${cvtDt>09-17-2019 9:40 PM>MM-dd-yyyy h:mm a>${timeZoneDb}>-3d>MM-dd-yyyy h:mm a>${timeZone}}
                        //${cvtDt>09-17-2019 9:40 PM>MM-dd-yyyy h:mm a>${timeZoneDb}>+3h>MM-dd-yyyy h:mm a>${timeZone}}
                        //${cvtDt>09-17-2019 9:40 PM>MM-dd-yyyy h:mm a>${timeZoneDb}>30m>MM-dd-yyyy h:mm a>${timeZone}}
                        ZonedDateTime zdt = ZonedDateTime.parse(pp[0], DateTimeFormatter.ofPattern(pp[1]).withZone(ZoneId.of(pp[2])));
                        long seconds = ZonedDateUtils.toSeconds(pp[3]);
                        ZonedDateTime newZdt = zdt.plus(seconds, ChronoUnit.SECONDS);
                        return DateTimeFormatter.ofPattern(pp[4]).withZone(ZoneId.of(pp[5])).format(newZdt);
                    }
                default:
                    //do nothing
            }
        }

        String s = this.stringVars.containsKey(owner) ? this.stringVars.get(owner).get(key) : null;
        if (null == s) {
            s = this.stringVars.get(OWNER_GLOBAL).get(key);
        }
        return s;
    }

    public Map<String, String> getMap(String owner, String key) {
        Map<String, String> map = null;
        if (this.mapVars.containsKey(owner)) {
            map = this.mapVars.get(owner).get(key);
        }
        if (null == map) {
            map = this.mapVars.get(OWNER_GLOBAL).get(key);
        }
        return map;
    }

    public Map<String, Object> getMapAsObjectByString(String owner, String key) {
        Map<String, String> map = getMap(owner, key);
        Map<String, Object> objectByString = new LinkedHashMap<>(map.size());
        for (String k : map.keySet()) {
            objectByString.put(k, map.get(k));
        }
        return objectByString;
    }

    public String jsonMapVars(String owner) {
        if (!mapVars.containsKey(owner)) {
            return "Empty";
        }
        Map<String, Map<String, String>> vars = new TreeMap<>(mapVars.get(owner));
        for (String mapName : vars.keySet()) {
            vars.put(mapName, protect(vars.get(mapName)));
        }
        return QuickJson.prettyJson(vars);
    }

    public String jsonStringVars(String owner) {
        if (!stringVars.containsKey(owner)) {
            return "Empty";
        }
        Map<String, String> map = protect(stringVars.get(owner));
        Map<String, String> vars = new TreeMap<>(map);
        return QuickJson.prettyJson(vars);
    }

    public Map<String, String> protect(Map<String, String> map) {
                        Map<String, String> result = new LinkedHashMap<>(map);
                        for (String protectedKey : this.protectedKeys) {
                            for (String key : result.keySet()) {
                                if (key.contains(protectedKey.trim())) {
                                    result.put(key, "******");
                }
            }
        }
        return result;
    }

    public List<String> protect(List<String> list) {
        List<String> protectedList = new ArrayList<>(list);
        for (String protectedKey : this.protectedKeys) {
            for (int i = 0; i < protectedList.size(); i++) {
                String s = protectedList.get(i);
                if (s.contains(protectedKey.trim())) {
                    protectedList.set(i, "******");
                }
            }
        }
        return protectedList;
    }

    public void mergeMapVars(String owner, Map<String, Map<String, Map<String, String>>> mapVars1) {
        if (!this.mapVars.containsKey(owner)) {
            this.mapVars.put(owner, new LinkedHashMap<>());
        }
        Map<String, Map<String, String>> mapVarsTo = this.mapVars.get(owner);
        for (String ownerFrom : mapVars1.keySet()) {
            Map<String, Map<String, String>> mapVarsFrom = mapVars1.get(ownerFrom);
            mapVarsTo.putAll(mapVarsFrom);
        }
    }

    public void mergeStringVars(String owner, Map<String, Map<String, String>> stringVars1) {
        if (!this.stringVars.containsKey(owner)) {
            this.stringVars.put(owner, new LinkedHashMap<>());
        }
        Map<String, String> stringVarsTo = this.stringVars.get(owner);
        for (String ownerFrom : stringVars1.keySet()) {
            Map<String, String> stringVarsFrom = stringVars1.get(owner);
            stringVarsTo.putAll(stringVarsFrom);
        }
    }

    public Set<String> getMapVars(String owner) {
        return this.mapVars.get(owner).keySet();
    }

    private WhiteBoard() {

        this.protectedKeys = Conf.getInstance().getProtectedKeys();

        String whiteboardInit = Conf.getInstance().getProperty(WHITEBOARD_GLOBAL);

        if (!StringUtils.isEmpty(whiteboardInit)) {

            String[] classNames = whiteboardInit.split(",");
            for (String className : classNames) {
                Class clazz = null;
                try {
                    clazz = Class.forName(className);
                } catch (ClassNotFoundException e) {
                    throw new RuntimeException("No such class [" + className + "]: " + e.getMessage());
                }

                try {
                    Field[] fields = clazz.getFields();
                    for (Field field : fields) {
                        if (Modifier.isStatic(field.getModifiers()) && field.getType() == String.class) {
                            this.putString(OWNER_GLOBAL, field.getName(), (String) field.get(null));
                        }
                    }
                    log.warn(fields.length + " variables loaded from class " + className);
                } catch (Exception e) {
                    throw new RuntimeException(className + " fatal error: " + e.getMessage());
                }
            }

        }

        this.refreshProperties();
    }

    public void register(Properties prop) {
        try {
            for (String key : prop.stringPropertyNames()) {
                this.putString(OWNER_GLOBAL, key, prop.getProperty(key));
            }
        } catch (Exception e) {
            throw new RuntimeException("Config reading fatal error: " + e.getMessage());
        }
    }

    public void refreshProperties() {
        try {
            Set<String> keys = Conf.getInstance().stringPropertyNames();
            for (String key : keys) {
                String value = Conf.getInstance().getProperty(key);
                this.putString(OWNER_GLOBAL, key, value);
                log.debug("property refreshed: " + key + "=" + value);
            }
            log.warn(keys.size() + " variables refreshed from Conf instance.");
        } catch (Exception e) {
            throw new RuntimeException("Conf reading fatal error: " + e.getMessage());
        }
    }

    public boolean containsMap(String owner, String key) {
        return this.mapVars.containsKey(owner) && this.mapVars.get(owner).containsKey(key);
    }

    public boolean containsString(String owner, String key) {
        return this.stringVars.containsKey(owner) && this.stringVars.get(owner).containsKey(key);
    }

    public static void register(String owner, Properties properties) {
        owner = null == owner ? OWNER_GLOBAL : owner;
        for (String key : properties.stringPropertyNames()) {
            String value0 = properties.getProperty(key);
            WhiteBoard.getInstance().putString(owner, key, value0);
        }
    }

    public List<Map<String, String>> combine(String owner, String prefix) {
        int rows = Integer.parseInt(this.getString(owner, prefix + "_rows"));
        List<Map<String, String>> maps = new ArrayList<>(rows);
        for (int i = 0; i < rows; i++) {
            maps.add(this.getMap(owner, prefix + "_" + (i + 1)));
        }
        return maps;
    }

    public void putList(String owner, String listName, List<String> list) {
        Map<String, String> map = new LinkedHashMap<>(list.size());
        for (int i = 0; i < list.size(); i++) {
            map.put(i + "", list.get(i));
        }
        putMap(owner, listName, map);
        putString(owner, listName + "_rows", list.size() + "");
    }

    public List<String> getList(String owner, String listName) {
        Map<String, String> map = getMap(owner, listName);
        List<String> list = new ArrayList<>(map.size());
        for (String index : map.keySet()) {
            list.add(map.get(index));
        }
        return list;
    }

    public void removeMap(String owner, String mapVarName) {
        Map<String, Map<String, String>> maps = mapVars.get(owner);
        if (null != maps) {
            maps.remove(mapVarName);
        }
    }

    public void removeAll(String owner, String regex) {
        try {
            if (stringVars.containsKey(owner)) {
                log.warn("Clearing strings: " + owner + "." + regex);
                DataTableUtils.removeAll(stringVars.get(owner), regex);
            }
            if (mapVars.containsKey(owner)) {
                log.warn("Clearing maps: " + owner + "." + regex);
                DataTableUtils.removeAll(mapVars.get(owner), regex);
                File outputDir = TestUtils.projectFile(Conf.getOutputPath());
                File[] files = outputDir.listFiles(new FilenameFilter() {
                    @Override
                    public boolean accept(File dir, String name) {
                        return name.matches(regex);
                    }
                });
                for (File f : files) {
                    log.warn("Clearing file: " + f);
                    FileUtils.forceDelete(f);
                }
            }
        } catch (Exception e) {
            log.warn("Unable to clear: " + e.getMessage());
        }
    }
}