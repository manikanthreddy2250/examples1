package atdd.utils;

import org.junit.Assert;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.TimeZone;

public class ZonedDateUtils {
    public static final String KEY_TIME_ZONE = "timeZone";
    public static final String KEY_TIME_ZONE_DB = "timeZoneDb";

    public static final String mmDdYyyyHMmA = "MM-dd-yyyy h:mm a";

    private static final DateTimeFormatter ddMmYyyy = DateTimeFormatter.ofPattern("dd-MM-yyyy");

    private static final DateTimeFormatter mmDdYyyy = DateTimeFormatter.ofPattern("MM-dd-yyyy");

    private static final DateTimeFormatter timestamp = DateTimeFormatter.ofPattern("yyyyMMddHHmmssS");

    private static final DateTimeFormatter sdf = DateTimeFormatter.ofPattern("MMddyyyy");

    /**
     * Get the configured time zone or system default zone if not configured.
     *
     * @return
     */
    public static String zone() {
        String s = Conf.getInstance().getProperty(KEY_TIME_ZONE);
        if (StringUtils.isEmpty(s)) {
            return ZoneId.systemDefault().getId();
        } else {
            return s;
        }
    }

    /**
     * Get the configured database time zone or UTC if not configured.
     *
     * @return
     */
    public static String dbZone() {
        String s = Conf.getInstance().getProperty(KEY_TIME_ZONE_DB);
        if (StringUtils.isEmpty(s)) {
            return "UTC";
        } else {
            return s;
        }
    }

    /**
     * Get the short name (ignoring path) by given time zone name.
     *
     * @param zone
     * @return
     */
    public static String shortName(String zone) {
        if (zone.contains("/")) {
            return zone.substring(zone.lastIndexOf('/') + 1);
        } else {
            return zone;
        }
    }

    /**
     * Convert a ZonedDateTime instance into a String using format "MM-dd-yyyy" with the configured time zone.
     *
     * @param zdt
     * @return
     */
    public static String mmDdYyyy(ZonedDateTime zdt) {
        return mmDdYyyy.withZone(ZoneId.of(zone())).format(zdt);
    }

    /**
     * Convert today's date into a String using format "MM-dd-yyyy" with the configured time zone.
     *
     * @return
     */
    public static String mmDdYyyy() {
        return mmDdYyyy(ZonedDateTime.now());
    }

    /**
     * Convert yesterday's date into a String using format "MM-dd-yyyy" with the configured time zone.
     *
     * @return
     */
    public static String mmDdYyyyYesterday() {
        ZonedDateTime zdt = ZonedDateTime.now().minus(1, ChronoUnit.DAYS);
        return mmDdYyyy(zdt);
    }

    /**
     * Convert tomorrow's date into a String using format "MM-dd-yyyy" with the configured time zone.
     *
     * @return
     */
    public static String mmDdYyyyTomorrow() {
        ZonedDateTime zdt = ZonedDateTime.now().plus(1, ChronoUnit.DAYS);
        return mmDdYyyy(zdt);
    }

    /**
     * Convert the current timestamp into a String using format "yyyyMMddHHmmssS" with the configured time zone.
     *
     * @return
     */
    public static String timestamp() {
        return timestamp.withZone(ZoneId.of(zone())).format(ZonedDateTime.now());
    }

    /**
     * Calculate and convert the specified ZoneDateTime instance into a String using specified format with the configured time zone.
     *
     * @return
     */
    public static String calcFormat(ZonedDateTime zdt, long amount, ChronoUnit unit, String format) {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern(format).withZone(ZoneId.of(zone()));
        ZonedDateTime newDate = zdt.plus(amount, unit);
        return dtf.format(newDate);
    }

    /**
     * Parse a String in format "MM-dd-yyyy" as a ZonedDateTime instance with specified time zone.
     *
     * @param zone
     * @param s
     * @return
     */
    public static ZonedDateTime mmDdYyyy(String zone, String s) {
        return ZonedDateTime.parse(s, mmDdYyyy.withZone(ZoneId.of(zone)));
    }

    /**
     * Calculate the number of months between two ZonedDateTime instances.
     *
     * @param startZdt
     * @param endZdt
     * @return
     */
    public static long monthsBetween(ZonedDateTime startZdt, ZonedDateTime endZdt) {
        return ChronoUnit.MONTHS.between(startZdt, endZdt);
    }

    /**
     * Calculate the age for specified date of birthday String in format "dd-MM-yyyy" with the configured time zone.
     *
     * @param s
     * @return
     */
    public static long getAge(String s) {
        return ChronoUnit.YEARS.between(ZonedDateTime.parse(s, ddMmYyyy.withZone(ZoneId.of(zone()))), ZonedDateTime.now());
    }

    /**
     * Convert today's date into a String using format "MMddyyyy" with the configured time zone.
     *
     * @return
     */
    public static String todayWithoutFormat() {
        return sdf.withZone(ZoneId.of(zone())).format(ZonedDateTime.now());
    }

    /**
     * Convert a String in specified fromFormat with specified time zone into another String in specified format with specified time zone.
     *
     * @param dateTime
     * @param fromFormat
     * @param fromTz
     * @param toFormat
     * @param toTz
     * @return
     */
    public static String convertDateTime(String dateTime, String fromFormat, String fromTz, String toFormat, String toTz) {
        //formatter
        DateTimeFormatter formatterFrom = DateTimeFormatter.ofPattern(fromFormat);
        DateTimeFormatter formatterTo = DateTimeFormatter.ofPattern(toFormat);

        //Source timezone
        ZoneId fromTimeZone = ZoneId.of(fromTz);

        //Target timezone - check if its set to match config timezone
        ZoneId toTimeZone = ZoneId.of(toTz);

        //convert the string datetime into localdatetime object
        LocalDateTime ldt = LocalDateTime.parse(dateTime, formatterFrom);

        //Zoned date time at source timezone
        ZonedDateTime fromTime = ldt.atZone(fromTimeZone);

        //Zoned date time at target timezone
        ZonedDateTime toTime = fromTime.withZoneSameInstant(toTimeZone);

        //Format datetime into 12 hour format
        String output = formatterTo.format(toTime);

        return output;
    }

    /**
     * Calculate the offset in hours between two time zones.
     *
     * @param zoneA
     * @param zoneB
     * @return
     */
    public static int offsetInHours(String zoneA, String zoneB) {
        TimeZone tzA = TimeZone.getTimeZone(zoneA);
        TimeZone tzB = TimeZone.getTimeZone(zoneB);
        int offsetInMillis = tzA.getRawOffset() - tzB.getRawOffset();
        int offsetInHours = offsetInMillis / (3600 * 1000);
        return offsetInHours;
    }

    /**
     * Parse dtString to ZonedDateTime using pattern "MM-dd-yyyy H:mm a"
     *
     * @param dtString
     * @return
     */
    public static ZonedDateTime parse(String dtString) {
        return parse(dtString, mmDdYyyyHMmA, zone());
    }

    /**
     * Parse dtString to ZonedDateTime using specified pattern
     *
     * @param dtString
     * @param pattern
     * @return
     */
    public static ZonedDateTime parse(String dtString, String pattern, String zone) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern).withZone(ZoneId.of(zone));
        return ZonedDateTime.parse(dtString, formatter);
    }

    public static long toSeconds(String s) {
        //Examples of s:
        //-3d
        //+3h
        //30m
        //360s

        long amount = Long.parseLong(s.substring(0, s.length() - 1));
        String unit = s.substring(s.length() - 1);
        switch (unit) {
            case "d":
                amount = amount * 24 * 60 * 60;
                break;
            case "h":
                amount = amount * 60 * 60;
                break;
            case "m":
                amount = amount * 60;
                break;
            case "s":
                break;
            default:
                Assert.fail("Unsupported unit: " + unit);
        }
        return amount;
    }
}
