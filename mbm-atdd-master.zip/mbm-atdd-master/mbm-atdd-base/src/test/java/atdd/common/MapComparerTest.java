package atdd.common;

import org.junit.Test;

import java.util.LinkedHashMap;
import java.util.Map;

public class MapComparerTest {

    private static Map<String, String> left = new LinkedHashMap<>();
    private static Map<String, String> right = new LinkedHashMap<>();

    static {
        left.put("a", "1");
        left.put("b", "2");
        left.put("c", "3");
        left.put("d", "4");
        left.put("filter", "out");
        right.put("A", "1");
        right.put("b", "20");
        right.put("c", "3");
        right.put("d", "4");
        right.put("out", "filter");
    }

    @Test
    public void bareLeft() {
        Map<String, CompareReport<String, String>> r = new MapComparer<String, String>(left, right, new String[]{"."}).bareLeft();
        for (String key : r.keySet()) {
            System.out.println(key + ": " + r.get(key).getStatus());
        }
    }

    @Test
    public void bareRight() {
        Map<String, CompareReport<String, String>> r = new MapComparer<String, String>(left, right, new String[]{"."}).bareRight();
        for (String key : r.keySet()) {
            System.out.println(key + ": " + r.get(key).getStatus());
        }
    }
}