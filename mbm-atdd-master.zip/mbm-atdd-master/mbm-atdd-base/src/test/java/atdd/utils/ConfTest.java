package atdd.utils;

import org.junit.Assert;
import org.junit.Test;

public class ConfTest {

    @Test
    public void getInstance() {
        System.out.println(Conf.getInstance().toString());
        Assert.assertEquals("mbm-atdd-base", Conf.getInstance().getProperty(ConfBase.PROJECT_KEY));
    }
}