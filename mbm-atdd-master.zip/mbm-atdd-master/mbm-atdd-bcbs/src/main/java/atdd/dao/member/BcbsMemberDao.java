package atdd.dao.member;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.log4j.Logger;

import java.util.List;
import java.util.Map;

public class BcbsMemberDao {

    public final static Logger log = Logger.getLogger(BcbsMemberDao.class);

    private SqlSessionFactory sqlSessionFactory = null;

    public BcbsMemberDao(SqlSessionFactory sqlSessionFactory) {
        this.sqlSessionFactory = sqlSessionFactory;
    }

    public List<Map<String, Object>> getMemberDetails() {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("member.selectGetMemberDetails");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Map<String, Object>> getMemberDetailsfromDb(String subid) {
        List<Map<String, Object>> list = null;
        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("member.selectMemberDetails", subid);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Map<String, Object>> getAddressfromDb(String s) {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("member.selectAddress", s);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Map<String, Object>> getEligibilty(String subscriberid) {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("member.selectEligibilty", subscriberid);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Map<String, Object>> getMemberInformationDetails(String subid) {
        List<Map<String, Object>> list = null;
        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("member.selectMemberInformationDetails", subid);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Map<String, Object>> getMemberInformationDetailsForProvider(String subid) {
        List<Map<String, Object>> list = null;
        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("member.selectMemberInformationDetailsForProvider", subid);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

}


