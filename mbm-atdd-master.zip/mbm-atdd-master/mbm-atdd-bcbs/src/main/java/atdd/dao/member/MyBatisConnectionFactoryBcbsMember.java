package atdd.dao.member;

import atdd.utils.Conf;
import atdd.utils.MyBatisUtils;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.Properties;

public class MyBatisConnectionFactoryBcbsMember {

    private static SqlSessionFactory sqlSessionFactory = null;
    private static Properties lastProperties = null;

    public static synchronized SqlSessionFactory getSqlSessionFactory() {
        MyBatisUtils.FactoryContainer container = new MyBatisUtils.FactoryContainer();
        container.sqlSessionFactory = sqlSessionFactory;
        container.properties = lastProperties;

        if (MyBatisUtils.getSqlSessionFactory(container, "src/main/resources/mybatis/member/config.xml",
                "bcbsMemberDbDriver", "bcbsMemberDbUrl", "DatabaseUser", "DatabasePass",
                "msidUser", "msidDbPass")) {
            sqlSessionFactory = container.sqlSessionFactory;
            lastProperties = container.properties;
            return container.sqlSessionFactory;
        } else {
            throw new RuntimeException("Unable to connect to database \"bcbsMemberDbUrl\": " + Conf.getInstance().getProperty("bcbsMemberDbUrl"));
        }
    }
}
