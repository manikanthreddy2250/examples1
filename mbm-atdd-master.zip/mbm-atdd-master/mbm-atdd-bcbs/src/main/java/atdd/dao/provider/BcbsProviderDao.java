package atdd.dao.provider;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.log4j.Logger;

import java.util.List;
import java.util.Map;

public class BcbsProviderDao {

    public final static Logger log = Logger.getLogger(BcbsProviderDao.class);

    private SqlSessionFactory sqlSessionFactory = null;

    public BcbsProviderDao(SqlSessionFactory sqlSessionFactory) {
        this.sqlSessionFactory = sqlSessionFactory;
    }

    public List<Map<String,Object>> selectByProviderLastName(String lastName) {  List<Map<String, Object>> list = null;

        SqlSession sqlSession = this.sqlSessionFactory.openSession();
        try {
            list = sqlSession.selectList("Provider.selectProviderByLasttName",lastName);
        } finally {
            sqlSession.close();
        }

        return list;
    }
}
