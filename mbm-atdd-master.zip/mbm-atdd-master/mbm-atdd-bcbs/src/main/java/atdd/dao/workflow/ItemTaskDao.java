package atdd.dao.workflow;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.List;
import java.util.Map;

public class ItemTaskDao {

    private SqlSessionFactory sqlSessionFactory = null;

    public ItemTaskDao(SqlSessionFactory sqlSessionFactory) {
        this.sqlSessionFactory = sqlSessionFactory;
    }

    public List<Map<String, Object>> selectDistinctItemIdsOwner(String owner) {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("ItemTask.selectDistinctItemIdsOwner", owner);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
}
