package atdd.dao.workflow;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.List;
import java.util.Map;

public class WorkQueueDao {

    private SqlSessionFactory sqlSessionFactory = null;

    public WorkQueueDao(SqlSessionFactory sqlSessionFactory) {
        this.sqlSessionFactory = sqlSessionFactory;
    }

    public List<Map<String, Object>> selectByWorkQueueId(String queueId) {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("WorkQueue.selectByWorkQueueId", queueId);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    public List<Map<String, Object>> selectByWorkQueueName(String queueName) {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("WorkQueue.selectByWorkQueueName", queueName);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

}
