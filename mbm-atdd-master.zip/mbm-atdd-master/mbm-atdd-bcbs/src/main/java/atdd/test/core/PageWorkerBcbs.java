package atdd.test.core;


import atdd.test.pageobjects.BcbsPageObject;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.openqa.selenium.WebDriver;

import java.util.Map;

public abstract class PageWorkerBcbs extends PageWorkerBase {

    private final BcbsPageObject obj;

    public PageWorkerBcbs(Scenario scenario, WebDriver webDriver, Map<String, String> pf) {
        super(scenario, webDriver, pf);
        this.obj = new BcbsPageObject(scenario, webDriver);
    }

    protected BcbsPageObject obj() {
        TestUtils.immediateAbortCheck(scenario());
        return obj;
    }


}
