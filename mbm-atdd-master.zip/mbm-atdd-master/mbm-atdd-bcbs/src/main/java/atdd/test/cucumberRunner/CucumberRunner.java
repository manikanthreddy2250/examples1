package atdd.test.cucumberRunner;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
		dryRun = false,
		monochrome = true,
		plugin = {"pretty", "html:target/cucumber"},
        features = "src/main/resources/features",
        glue = {"atdd.test.stepdefinitions"},
        tags = {"@TC1203141"}
)
public class CucumberRunner {
}
