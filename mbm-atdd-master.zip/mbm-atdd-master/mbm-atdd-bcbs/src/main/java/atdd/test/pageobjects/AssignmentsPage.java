package atdd.test.pageobjects;

import atdd.common.ICondition;
import atdd.common.Retry;
import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class AssignmentsPage {

    public static final By addAssignmentLink = By.xpath("//a[.='Add Assignment']");
    public static final String ASSIGNMENTS_TABLE_XPATH = "//table[@id='assignmentsMaintenanceTableID']";
    public static final String TOP5_HISTORY_TABLE_XPATH = "//table[@id='viewAssignmentsHistoryTableID']";
    public static final String HISTORY_CREATEDBY_XPATH = "//*[@ng-click='viewAllHistory(record)']/ancestor::tr/td[2]/span";
    public static final String FULL_HISTORY_TABLE_XPATH = "//table[@id='assignmentsHistoryTableID']";

    public static final By closeHistoryButton = By.xpath("//form[@name='assignmentHistoryPopupModelForm']//input[@value='Close']");
    public static final By viewAllHistoryLink = By.xpath("//*[@ng-click='viewAllHistory(record)']");
    public static final By closeViewAssignmentButton = By.xpath("//input[@ng-click='assignmentsMaintenanceTable.closeRecord()']");

    public static final By historyIcon(String row) {
        String xpath = ASSIGNMENTS_TABLE_XPATH + "/tbody/tr[" + row + "]/td[3]/span";
        return By.xpath(xpath);
    }

    private static Logger log = Logger.getLogger(AssignmentsPage.class);
    private WebDriver driver = null;

    /*Page Constructor*/
    public AssignmentsPage(WebDriver driver) {
        this.driver = driver;
    }

    public void clickAddAssignment() {
        Retry retry = new Retry("Click Add Assignment Link") {

            @Override
            protected void tryOnce() throws Exception {
                TestUtils.click(driver, addAssignmentLink);
            }

            @Override
            protected boolean until() throws Exception {
                return TestUtils.isElementVisible(driver, AddAssignmentPage.pageTitleAddAssignmentXpath);
            }
        };

        Assert.assertTrue("Fail to click Add Assignment Link", retry.execute());

        TestUtils.wait(3);
    }

    /**
     * Click Edit Assignment icon for the specified row
     *
     * @param row
     */
    public void clickEditAssignment(int row) {
        Retry retry = new Retry("Click Edit Assignment Link") {

            @Override
            protected void tryOnce() throws Exception {
                By editIcon = By.xpath(ASSIGNMENTS_TABLE_XPATH + "/tbody/tr[" + row + "]/td[2]/span");
                TestUtils.click(driver, editIcon);
            }

            @Override
            protected boolean until() throws Exception {
                return TestUtils.isElementVisible(driver, AddAssignmentPage.pageTitleEditAssignmentXpath);
            }
        };

        Assert.assertTrue("Fail to click Edit Assignment Link", retry.execute());

        TestUtils.wait(3);
    }

    /**
     * Click View Assignment icon for the specified row
     *
     * @param row
     */
    public void clickViewAssignment(int row) {
        Retry retry = new Retry("Click View Assignment Link") {

            @Override
            protected void tryOnce() throws Exception {
                By viewIcon = By.xpath(ASSIGNMENTS_TABLE_XPATH + "/tbody/tr[" + row + "]/td[1]/span");
                TestUtils.click(driver, viewIcon);
            }

            @Override
            protected boolean until() throws Exception {
                return TestUtils.isElementVisible(driver, AddAssignmentPage.pageTitleViewAssignmentXpath);
            }
        };

        Assert.assertTrue("Fail to click View Assignment Link", retry.execute());

        TestUtils.wait(3);
    }

    /**
     * Click the sort icon on the specified header.
     *
     * @param header
     */
    public void clickSortIcon(String header) {
        By sortIcon = By.xpath(ASSIGNMENTS_TABLE_XPATH + "/thead/tr/td[contains(.,'" + header + "')]/span[@title='Sort']");
        Assert.assertTrue(TestUtils.clickSortIcon(driver, sortIcon));
    }

    /**
     * Click the close button on View Assignment section.
     *
     * @param header
     */
    public boolean clickCloseViewAssignmentButton(String header) {
        return TestUtils.clickUntil(driver, closeViewAssignmentButton, new ICondition() {
            @Override
            public boolean evaluate() throws Exception {
                return !TestUtils.isElementVisible(driver, closeViewAssignmentButton);
            }
        });
    }
}
