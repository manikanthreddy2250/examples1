package atdd.test.pageobjects;

import cucumber.api.Scenario;
import org.openqa.selenium.WebDriver;


public class BcbsPageObject extends CommonPageObject {

    public WorkQueueMaintenancePage WorkQueueMaintenancePage = new WorkQueueMaintenancePage(webDriver);
    public AddWorkQueuePage AddWorkQueuePage = new AddWorkQueuePage(webDriver);
    public WorkQueuePage WorkQueuePage = new WorkQueuePage(webDriver);
    public AssignmentsPage AssignmentsPage = new AssignmentsPage(webDriver);
    public AddAssignmentPage AddAssignmentPage = new AddAssignmentPage(webDriver);
    public CaseSummaryNotesSection CaseSummaryNotesSection = new CaseSummaryNotesSection(webDriver);
    public ViewAuthPage ViewAuthPage = new ViewAuthPage(webDriver);
    public CaseSummaryMakeDecisionsSection CaseSummaryMakeDecisionSection = new CaseSummaryMakeDecisionsSection(webDriver);

    public BcbsPageObject(Scenario scenario, WebDriver webDriver) {
        super(scenario, webDriver);
    }

}
