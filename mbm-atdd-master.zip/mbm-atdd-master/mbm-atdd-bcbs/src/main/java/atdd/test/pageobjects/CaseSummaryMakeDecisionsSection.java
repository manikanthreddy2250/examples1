package atdd.test.pageobjects;

import atdd.dao.mbm.MakeDecisionsDao;
import atdd.dao.mbm.MyBatisConnectionFactory;
import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class CaseSummaryMakeDecisionsSection {

    private static Logger log = Logger.getLogger(CaseSummaryMakeDecisionsSection.class);
    private WebDriver driver;

    //Normal Elements
    public static final By makeDecisionButton = By.id("makeDecisionsButton");
    public static final By decisionOutcome = By.xpath("//*[@id='hscServiceDecisionVO-decisionOutcomeType-0']");
    public static final By decisionSubType = By.xpath("//*[@id='hscServiceDecisionVO-decisionSubType-0']");
    public static final By decisionReason = By.xpath("//*[@id='hscServiceDecisionVO-decisionReasonType-1']");
    public static final By decisionSaveButton = By.xpath("//*[@id='saveDecisionsButton']");
    public static final By renderedBy = By.xpath("//*[@id='hscServiceDecisionVO-decisionMadeByUserID-0']");
    public static final By claimComment = By.xpath("//*[@id='claimNote']");
    public static final By decisionDateInputField = By.xpath("//*[@id='decisionDate-date-0']");
    public static final By decisionTime = By.xpath("//*[@id='decisionTime-time-0']");
    public static final By decisionTimeAM = By.xpath("//*[@id='decisionTime-amPm-0']");
    public static final By decisionTimePM = By.xpath("//*[@id='decisionTime-amPm-1']");
    public static final By customRequestReason = By.xpath("//*[@id='hscServiceDecisionVO-customRequestReasonType-0']");
    public static final By resourcesUsed = By.xpath("//*[@id='resourcesUsedSelect']");
    public static final By decisionReason2 = By.xpath("//*[@id='decisionsForm']/form/table/tbody/tr/td[1]/table/tbody/tr[4]/td[2]/*/select");
    public static final By decisionCancelButton = By.xpath("//*[@id='cancelDecisionsButton']");
    public static final By makeDecisionSuccessMSG = By.xpath("//*[@id='globalMessages-description']/span");
    public static final By decisionPopUpMessage = By.xpath("//*[@id='globalMessages-description']");
    public static final By enteredBy = By.xpath("//*[@id='enteredBy']");
    public static final By enteredByUserID = By.xpath("//*[@id='decisionsForm']/form/table/tbody/tr/td[1]/table/tbody/*/td/p[contains(@class,'decisionUserID')]");
    public static final By resourceUsedTextArea = By.xpath("//button[contains(@class,'multiSelectButton')]");
    public static final By resourceUsedOptionList = By.xpath("//*[@id='resourcesUsedSelect']/div[2]/form/div[2]");
    public static final By workQueue = By.linkText("Work Queue");
    public static final By contactUs = By.linkText("Contact Us");
    public static final By globalMessagePopup = By.xpath("//*[@id='globalMessages']/div/button/span[1]");
    public static final By medicalBenefitServicesTable = By.xpath("//*[@id='medicalBenefitServicesTableID']/tbody");


    //Askterik Elements
    public static final By decisionOutcomeStar = By.xpath("//*[@id='decisionOutcome']/label/span[@title='Required']");
    public static final By decisionSubTypeStar = By.xpath("//*[@id='decisionType']/label/span[@title='Required']");
    public static final By decisionReasonStar = By.xpath("//*[@id='decisionReason']/label/span[@title='Required']");
    public static final By customRequestReasonStar = By.xpath("//*[@id='customRequestReasonType']/label/span[@title='Required']");
    public static final By resourcesUsedStar = By.xpath("//*[@id='resourcesUsed']/label/span[@title='Required']");
    public static final By claimNoteStar = By.xpath("//*[@id='claimTypeComment']/label/span[@title='Required']");
    public static final By renderedByStar = By.xpath("//*[@id='renderedBy']/label/span[@title='Required']");
    public static final By decisionDateStar = By.xpath("//*[@id='decisionDate']/label/span[@title='Required']");
    public static final By decisionTimeStar = By.xpath("//*[@id='decisionTime']/label/span[@title='Required']");
    public static final By resourceCommentStar = By.xpath("//*[@id='resourceComment']/label/span[@title='Required']");

    //This is required message elements
    public static final By outcomeTypeErr = By.xpath("//*[@id='hscServiceDecisionVO-decisionOutcomeType_err']");
    public static final By customRequestReasonTypeErr = By.xpath("//*[@id='hscServiceDecisionVO-customRequestReasonType_err']");
    public static final By decisionSubTypeErr = By.xpath("//*[@id='hscServiceDecisionVO-decisionSubType_err']");
    public static final By decisionReasonTypeErr = By.xpath("//*[@id='hscServiceDecisionVO-decisionReasonType_err']");
    public static final By claimNoteErr = By.xpath("//*[@id='hscServiceDecisionVO-claimNote_err']");
    public static final By decisionRenderedByUserID_Err = By.xpath("//*[@id='hscServiceDecisionVO-decisionMadeByUserID_err']");
    public static final By decisionDate_Err = By.xpath("//*[@id='decisionDate-date_err']");
    public static final By decisionTime_Err = By.xpath("//*[@id='decisionTime_err']");
    public static final By resourceCommentErr = By.xpath("//*[@id='hscServiceDecisionVO-decisionSourceComment_err']");

    /*Page Constructor*/
    public CaseSummaryMakeDecisionsSection(WebDriver driver) {
        this.driver = driver;
    }

    /**
     * Validates elements based on the list being passed in
     *
     * @param elementsToValidate
     */
    public void checkValidationMessages(List<String> elementsToValidate) {
        //To account for duplicate elements hscServiceDecisionVO-decisionMadeByUserID_err
        List<WebElement> renderedByErrList = driver.findElements(decisionRenderedByUserID_Err);
        for (Integer element = 0; element < elementsToValidate.size(); element++) {
            String elementAsterisk = elementsToValidate.get(element) + " Asterisk";
            String elementErr = elementsToValidate.get(element) + " Err";
            try {
                String decisionOutcomeDesc = new MakeDecisionsDao(MyBatisConnectionFactory.getSqlSessionFactory()).getOutcomeDescription(driver.findElement(decisionOutcome).getAttribute("value"));
                //If statement accounts for Guideline Resource/Criteria Comment only required if Decision Outcome is Denied/Not Covered
                if (elementsToValidate.get(element).equals("Guideline Resource/Criteria Comment")) {
                    if ((decisionOutcomeDesc == null) || (decisionOutcomeDesc.equals("Approved/Covered"))) {
                        Assert.assertFalse("Decision " + elementsToValidate.get(element) + " star asterisk is visible", TestUtils.isElementPresent(driver.findElement(getDropdownElement(elementAsterisk))));
                        Assert.assertFalse("Decision " + elementsToValidate.get(element) + " required text is shown", TestUtils.isElementVisible(driver, getDropdownElement(elementErr)));
                    } else if (decisionOutcomeDesc.equals("Denied/Not Covered")) {
                        Assert.assertTrue("Decision " + elementsToValidate.get(element) + " star asterisk isn't visible", TestUtils.isElementPresent(driver.findElement(getDropdownElement(elementAsterisk))));
                        Assert.assertTrue("Decision " + elementsToValidate.get(element) + " required text not shown", TestUtils.isElementVisible(driver, getDropdownElement(elementErr)));
                    }
                    //Work around because there's duplicate element IDs for Decision Rendered by _err
                } else if (elementsToValidate.get(element).equals("Decision Rendered by")) {
                    Assert.assertTrue("The " + elementsToValidate.get(element) + " required text not shown", renderedByErrList.get(0).isDisplayed());
                } else {
                    Assert.assertTrue("Decision " + elementsToValidate.get(element) + " star asterisk isn't visible", TestUtils.isElementPresent(driver.findElement(getDropdownElement(elementAsterisk))));
                    if (!(elementsToValidate.get(element).equals("Resource(s) Used")) || (!(elementsToValidate.get(element).equals("Guideline Resource/Criteria Comment")))) {
                        Assert.assertTrue("The " + elementsToValidate.get(element) + " required text not shown", TestUtils.isElementVisible(driver, getDropdownElement(elementErr)));
                    }
                }
            } catch (Exception e) {
                log.warn("Element " + elementsToValidate.get(element) + " does not exist");
            }
        }
    }

    /**
     * Check  a dropdown exists on page or not
     *
     * @param dropdownName
     */
    public boolean checkDropdownexists(String dropdownName) {
        try {
            TestUtils.wait(1);
            log.info(getDropdownElement(dropdownName));
            return TestUtils.isElementPresent(driver.findElement(getDropdownElement(dropdownName)));

        } catch (Exception e) {
            return false;
        }
    }


    /**
     * Returns element id
     *
     * @param dropdownName
     * @return
     */
    public By getDropdownElement(String dropdownName) {
        switch (dropdownName) {
            case "Decision Outcome":
                return decisionOutcome;
            case "Decision Outcome Asterisk":
                return decisionOutcomeStar;
            case "Decision Outcome Err":
                return outcomeTypeErr;
            case "Decision Subtype":
                return decisionSubType;
            case "Decision Subtype Asterisk":
                return decisionSubTypeStar;
            case "Decision Subtype Err":
                return decisionSubTypeErr;
            case "Decision Reason":
                return decisionReason;
            case "Decision Reason 2":
                return decisionReason2;
            case "Decision Reason Asterisk":
                return decisionReasonStar;
            case "Decision Reason Err":
                return decisionReasonTypeErr;
            case "Decision Rendered by":
                return renderedBy;
            case "Decision Rendered by Asterisk":
                return renderedByStar;
            case "Decision Rendered by Err":
                return decisionRenderedByUserID_Err;
            case "Custom Request Reason":
                return customRequestReason;
            case "Custom Request Reason Asterisk":
                return customRequestReasonStar;
            case "Custom Request Reason Err":
                return customRequestReasonTypeErr;
            case "Decision Rendered Date":
                return decisionDateInputField;
            case "Decision Rendered Date Asterisk":
                return decisionDateStar;
            case "Decision Rendered Date Err":
                return decisionDate_Err;
            case "Decision Rendered Time":
                return decisionTime;
            case "Decision Rendered Time Asterisk":
                return decisionTimeStar;
            case "Decision Rendered Time Err":
                return decisionTime_Err;
            case "AM":
                return decisionTimeAM;
            case "PM":
                return decisionTimePM;
            case "Resource(s) Used":
                return resourcesUsed;
            case "Resource(s) Used Asterisk":
                return resourcesUsedStar;
            case "Guideline Resource/Criteria Comment Asterisk":
                return resourceCommentStar;
            case "Guideline Resource/Criteria Comment Err":
                return resourceCommentErr;
            case "Claim Type / Comment":
                return claimComment;
            case "Claim Type / Comment Asterisk":
                return claimNoteStar;
            case "Claim Type / Comment Err":
                return claimNoteErr;
            default:
                log.warn("Could not find element");
                return null;
        }
    }

    //Clicks make decision button
    public void clickMakeDecisionButton() {
        TestUtils.wait(2);
        TestUtils.waitElementClickable(driver, makeDecisionButton);
        TestUtils.click(driver, makeDecisionButton);
    }

    //Checks to see if make decision success message is visible
    public boolean getMakeDecisionSuccessStatus() {
        return TestUtils.isElementVisible(driver, makeDecisionSuccessMSG);
    }

    //Checks to see if make decision button is visible
    public boolean getMakeDecisionButtonStatus() {
        return TestUtils.isElementVisible(driver, makeDecisionButton);
    }

    //Clicks decision save button
    public void clickDecisionSaveButton() {
        TestUtils.wait(2);
        TestUtils.waitElementClickable(driver, decisionSaveButton);
        TestUtils.click(driver, decisionSaveButton);
    }

    //Clicks decision cancel button
    public void clickDecisionCancelButton() {
        TestUtils.wait(2);
        TestUtils.waitElementClickable(driver, decisionCancelButton);
        TestUtils.click(driver, decisionCancelButton);
    }

    //Clicks work queue tab
    public void clickWorkQueueTab() {
        TestUtils.wait(1);
        TestUtils.waitElementClickable(driver, contactUs);
        TestUtils.waitElementClickable(driver, workQueue);
        driver.findElement(workQueue).click();
        Assert.assertEquals("Work Queue", driver.findElement(workQueue).getText());
    }

    //Input Date
    public void inputDate(String dateInput) {
        if (dateInput.equals("Today")) {
            DateTimeFormatter dateTimeFormat = DateTimeFormatter.ofPattern("MM-dd-yyyy");
            LocalDate localDate = LocalDate.now();
            TestUtils.wait(1);
            TestUtils.waitElementClickable(driver, decisionDateInputField);
            TestUtils.click(driver, decisionDateInputField);
            TestUtils.input(driver, decisionDateInputField, dateTimeFormat.format(localDate));
        } else if(dateInput.equals("Yesterday"))
        {
            DateTimeFormatter dateTimeFormat = DateTimeFormatter.ofPattern("MM-dd-yyyy");
            LocalDate localDate = LocalDate.now().minusDays(1);
            TestUtils.wait(1);
            TestUtils.waitElementClickable(driver, decisionDateInputField);
            TestUtils.click(driver, decisionDateInputField);
            TestUtils.input(driver, decisionDateInputField, dateTimeFormat.format(localDate));
        }
        else {
            TestUtils.wait(1);
            TestUtils.waitElementClickable(driver, decisionDateInputField);
            TestUtils.click(driver, decisionDateInputField);
            TestUtils.input(driver, decisionDateInputField, dateInput);
        }
    }

    //Input Time
    public void inputTime(String time, String amPM) {
        TestUtils.waitElementClickable(driver, decisionTime);
        if(time.equalsIgnoreCase("future")){
            TestUtils.input(driver, decisionTime, "08:00");
        }else {
            TestUtils.input(driver, decisionTime, time);
        }
        if (amPM.equalsIgnoreCase("AM")) {
            TestUtils.wait(1);
            TestUtils.waitElementClickable(driver, decisionTimeAM);
            TestUtils.click(driver, decisionTimeAM);
        } else {
            TestUtils.wait(1);
            TestUtils.waitElementClickable(driver, decisionTimePM);
            TestUtils.click(driver, decisionTimePM);
        }
    }
    /*
    Function to check if the user entered correct time
     */
    public void checkFutureTime(String time, String amPm){
        if(time.equalsIgnoreCase("future"))
        {
            time ="08:00";
        }
        String pattern = "yyyy/MM/dd";
        String pattern1 = "yyyy/MM/dd hh:mm aa";
        Date date = new Date();
        SimpleDateFormat df = new SimpleDateFormat(pattern);
        String currentDateString = df.format(date);
        String enteredtDatetimeString = currentDateString + " " + time + " " + amPm;
        SimpleDateFormat sdf = new SimpleDateFormat(pattern1);
        try {
            Date enteredDateTime = sdf.parse(enteredtDatetimeString);
            Date dateNow = new Date();
            Date timeAfter30Mins = new Date(dateNow.getTime() + 30*60*1000);
            if (enteredDateTime.getTime() > timeAfter30Mins.getTime()) {
                Assert.assertEquals("Please correct the Decision Rendered Time", getPopUpMessage());
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }
    /**
     * validates date format
     * @param dateToValidate
     * @param dateFromat
     */
    public boolean dateTimeValidator(String dateToValidate, String dateFromat ){

        if(dateToValidate == null){
            return false;
        }

        SimpleDateFormat sdf = new SimpleDateFormat(dateFromat);
        sdf.setLenient(false);
        try {
            //if not valid, it will throw ParseException
            Date date = sdf.parse(dateToValidate);
            System.out.println(date);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }


    //Get's text from popup message
    public String getPopUpMessage() {
        TestUtils.waitElementClickable(driver, decisionPopUpMessage);
        return driver.findElement(decisionPopUpMessage).getText();
    }

    //Saves or Cancels a Decision based on user input
    public void saveOrCancelDecision(String saveOrCancel) {
        if (saveOrCancel.equalsIgnoreCase("Save")) {
            TestUtils.wait(1);
            clickDecisionSaveButton();
            Assert.assertEquals("Success", getPopUpMessage());
        } else if (saveOrCancel.equals("Cancel")) {
            TestUtils.wait(1);
            TestUtils.click(driver, decisionCancelButton);
            TestUtils.wait(1);
            Assert.assertTrue(TestUtils.isElementVisible(driver, makeDecisionButton));
        } else {
            System.out.println("Not clicking anything");
        }
    }
    /**
     * verifies enteredByName with the user who is logged in
     * @param enteredByName
     *
     */
    public Boolean verifyEnteredBy(String enteredByName) {
        System.out.println("sou: " + enteredByName);

        String compareName = TestUtils.text(driver, enteredByUserID);
        return (enteredByName.equalsIgnoreCase(compareName));
    }

    //Enters ResourceUsed based on input
    public void enterResourcesUsed(String resourceUsed) {
        log.warn("Enter the Resource Used: " + resourceUsed);
        WebElement el = driver.findElement(resourceUsedTextArea);
        el.click();
        if (resourceUsed.contains(";")) {
            String[] Variablevalue = resourceUsed.split(";");
            for (String vv : Variablevalue) {
                TestUtils.wait(1);
                driver.findElement(By.xpath("//span[contains(text(), '" + vv + "')]/preceding-sibling::span")).click();
            }
        } else {
            driver.findElement(By.xpath("//span[contains(text(), '" + resourceUsed + "')]/preceding-sibling::span")).click();
        }
    }

    //Temp pop up acknowledgment because of error popup with user goes to a work queue item
    public void acknowledgePopUp() {
        try {
            TestUtils.click(driver, globalMessagePopup);
        } catch (Exception e) {
            System.out.println("No pop up to close");
        }
    }

    /**
     * Verifies the Resource(s) Used dropdown options against an Excepted list that's passedin
     *
     * @param expectedResourceOptions
     * @return
     */
    public Boolean compareResourceUserOptionList(List<String> expectedResourceOptions) {
        int numberOfOptions = expectedResourceOptions.size();
        String[] resourceUsedDisplayedArray = null;
        String option;
        TestUtils.click(driver, resourceUsedTextArea);
        String resourceUsedDisplayed = driver.findElement(resourceUsedOptionList).getText();
        if (resourceUsedDisplayed.contains("\n")) {
            resourceUsedDisplayedArray = resourceUsedDisplayed.split("\n");
        }
        if (resourceUsedDisplayedArray != null) {
            if (!(numberOfOptions == resourceUsedDisplayedArray.length)) {
                return false;
            }
            for (int row = 0; row < numberOfOptions; row++) {
                option = expectedResourceOptions.get(row);
                if (option.isEmpty()) {
                    break;
                }
                if (!(option.equals(resourceUsedDisplayedArray[row]))) {
                    return false;
                }
            }
        }
        return true;
    }

    //Verifies decision outcome status updated correctly
    public void verifyUpdatedDecisionStatus(String decisionOutcome) {
        TestUtils.wait(1);
        //To locate table.
        WebElement mytable = driver.findElement(medicalBenefitServicesTable);
        //To locate rows of table.
        List<WebElement> rows_table = mytable.findElements(By.tagName("tr"));
        //To calculate no of rows In table.
        int rows_count = rows_table.size();
        //Loop will execute till the last row of table.
        for (int row = 0; row < rows_count; row++) {
            Assert.assertEquals(decisionOutcome, TestUtils.text(driver, By.xpath("//*[@id='medicalBenefitServicesTableID']/tbody/tr[" + row + "]/td[3]/span")));
        }
    }

    /**
     * queryExpression = hscID
     * srcSeqNbr = get individual row in hsc_srvc_decn_src
     * decnSeqNbr = corresponds to decision sequence number
     * <p>
     * A decision sequence number can have multiple src_seq_numbers.  If more than one resource is selected, there will be a
     * new src_seq_number (new row) added in the database.
     */
    public Boolean verifyExpectedResourcesUsed(String expectedResourcesUsed, String queryExpression) {

        String resourceFromDatabase;
        String resourceFromDatabaseDesc;
        String decnSeqNbr = new MakeDecisionsDao(MyBatisConnectionFactory.getSqlSessionFactory()).getDecisionSequenceNumber(queryExpression);

        if (expectedResourcesUsed.contains(";")) {
            String[] resourcesPicked = expectedResourcesUsed.split(";");
            for (Integer arraySize = 0; arraySize < resourcesPicked.length; arraySize++) {
                String srcSeqNbr = String.valueOf(arraySize + 1);
                resourceFromDatabase = new MakeDecisionsDao(MyBatisConnectionFactory.getSqlSessionFactory()).getDecisionResourceTypeBasedOnSrcSeqNumber(queryExpression, srcSeqNbr, decnSeqNbr).replaceFirst(".*=", "");
                resourceFromDatabaseDesc = new MakeDecisionsDao(MyBatisConnectionFactory.getSqlSessionFactory()).getresourceDescription(resourceFromDatabase).replaceFirst(".*=", "");
                if (!(resourcesPicked[arraySize].equals(resourceFromDatabaseDesc))) {
                    log.warn("Expected Resource " + resourcesPicked[arraySize] + " does not match what was in the database " + resourceFromDatabaseDesc);
                    return false;
                }
            }
        } else {
            resourceFromDatabase = new MakeDecisionsDao(MyBatisConnectionFactory.getSqlSessionFactory()).getDecisionResourceTypeBasedOnSrcSeqNumber(queryExpression, "1", decnSeqNbr).replaceFirst(".*=", "");
            resourceFromDatabaseDesc = new MakeDecisionsDao(MyBatisConnectionFactory.getSqlSessionFactory()).getresourceDescription(resourceFromDatabase).replaceFirst(".*=", "");
            if (!(expectedResourcesUsed.equals(resourceFromDatabaseDesc))) {
                log.warn("Expected Resource " + expectedResourcesUsed + " does not match what was in the database " + resourceFromDatabaseDesc);
                return false;
            }
        }
        return true;
    }

    //clicks on save button without validation
    public void clickSaveButtonNoValidation() {
        TestUtils.waitElementClickable(driver, decisionSaveButton);
        TestUtils.click(driver, decisionSaveButton);
    }

    /**
     * verifies service fields in the medicalBenefitServicesTable after decision is made
     * @param queryExpression
     * @param numberOfServices
     */
    public void verifyServiceFields(String queryExpression,Integer numberOfServices){
        log.warn("queryExpression=" + queryExpression);
        String decnSeqNbr = new MakeDecisionsDao(MyBatisConnectionFactory.getSqlSessionFactory()).getDecisionSequenceNumber(queryExpression);
        List<Map<String, Object>> serviceDecisions = new MakeDecisionsDao(MyBatisConnectionFactory.getSqlSessionFactory()).getServiceDecisions(queryExpression, decnSeqNbr);
        for (int row = 1; row < numberOfServices; row++) {
            TestUtils.wait(1);
            Actions actions = new Actions(driver);
            WebElement element= driver.findElement(By.linkText(TestUtils.text(driver, By.xpath("//*[@id='medicalBenefitServicesTableID']/tbody/tr[" + row + "]/td[3]/a"))));
            JavascriptExecutor executor = (JavascriptExecutor) driver;
            executor.executeScript("arguments[0].click();", element);
            Assert.assertEquals(TestUtils.text(driver, By.xpath("//*[@id='selectedDecisionOutcomeType']")), new MakeDecisionsDao(MyBatisConnectionFactory.getSqlSessionFactory()).getOutcomeDescription(serviceDecisions.get(row).get("decn_otcome_typ_id")));
            Assert.assertEquals(TestUtils.text(driver, By.xpath("//*[@id='selectedDecisionSubType']")), new MakeDecisionsDao(MyBatisConnectionFactory.getSqlSessionFactory()).getSubTypeDescription(serviceDecisions.get(row).get("decn_sub_typ_id")));
            Assert.assertEquals(TestUtils.text(driver, By.xpath("//*[@id='selectedDecisionReasonType']")), new MakeDecisionsDao(MyBatisConnectionFactory.getSqlSessionFactory()).getReasonDescription(serviceDecisions.get(row).get("decn_rsn_typ_id")));
            Assert.assertEquals(TestUtils.text(driver, By.xpath("//*[@id='displayClaimNote']")), serviceDecisions.get(row).get("clm_note_txt"));
            Assert.assertEquals(TestUtils.text(driver, By.xpath("//*[@id='selectedRenderedByUserID']")).replace(", ","").toLowerCase(),serviceDecisions.get(row).get("decn_made_by_user_id").toString());
            Assert.assertEquals(TestUtils.text(driver, By.xpath("//*[@id='displayResourceComment']")), serviceDecisions.get(row).get("decn_src_cmmt_txt"));
            Assert.assertEquals(TestUtils.text(driver, By.xpath("//*[@id='selectedDecisionEnteredBy']")).replace(", ","").toLowerCase(), serviceDecisions.get(row).get("decn_entr_by_user_id"));

        }
    }

    public void validateListofCustomRequestReason() {
        String expectedCustReqReasons = "Cancer/Disease State Other, Clinical Status Exception, Max Dosage Exceeded (Specialty), No Regimen Match Found, Non-Formulary, Non-Preferred, Not NCCN Regimen, Not Within Drug Policy/Guideline (Specialty/Oral), Other, Pharmacy : Other, Provider Entry Error, Quantity Limit Exceeded (Oral), Site of Care Exception, System Issues, Tier Exception, Under 18, WBC GF (w/Chemo<14 days)";
        log.warn(expectedCustReqReasons);
        By customDropdwnXpath=By.xpath("//tr[@ng-if='customRequestReason']//span[@class='cux-icon-sort_down']");
        TestUtils.click(driver,customDropdwnXpath);
        TestUtils.wait(2);
        selectAllOrNoneOption("ALL");
        String CustomRequestReasonActual = TestUtils.text(driver,By.xpath("//p[@ng-bind='customstring']"));
        log.warn(CustomRequestReasonActual);
        Assert.assertTrue("Displaying all Custom Request Reasons", expectedCustReqReasons.equals(CustomRequestReasonActual));
    }

    public List<String> getCustomReasonsInHeader(){
        List<String> CustomRequestReasonInHeader = new ArrayList<String>();
        By customReasonTooltipXpath= By.xpath("//span[@id='ocmTooltip-customRequestReasonTooltip']");
        TestUtils.click(driver,customReasonTooltipXpath);
        TestUtils.wait(2);
        List<WebElement>  options = driver.findElements(By.xpath("//p[@ng-repeat='excep in listCustomRequestReasons']"));
        options.forEach(i-> CustomRequestReasonInHeader.add(i.getText().trim()));
        log.warn(CustomRequestReasonInHeader);
        return CustomRequestReasonInHeader;
    }

    public List<String> getCustomReasonsSelected(){
        List<String> CustomReasonSelected = new ArrayList<String>();
        clickCustomReasonDropdown();
        List<WebElement>  options = driver.findElements(By.xpath("//span[@id='customRequestReasonTypeStyle']//div//label//input[@checked='checked']//..//span[@class='tk-multi-label ng-binding']"));
        options.forEach(i-> CustomReasonSelected.add(i.getText().trim()));
        log.warn(CustomReasonSelected);
        clickCustomReasonDropdown();
        return CustomReasonSelected;
    }

    public void selectCustomReason(String reason){
        By dropDwnXpath = By.xpath("//tr[@ng-if='customRequestReason']//span[@class='cux-icon-sort_down']");
        TestUtils.click(driver,dropDwnXpath);
        TestUtils.wait(2);
        By  reasonXpath = By.xpath("//span[@class='tk-multi-label ng-binding'and text()='"+reason+"']//preceding-sibling::span");
        TestUtils.wait(5);
        TestUtils.click(driver,reasonXpath);
        TestUtils.wait(2);
        TestUtils.click(driver,dropDwnXpath);
    }

    public void selectDecisionType(String decisionType){
        log.warn("Enter decision Type " + decisionType);
        TestUtils.wait(2);
        TestUtils.selectByVisibleText(driver, decisionSubType,decisionType);
    }

    public void selectDecisionOutcome(String outcome) {
        log.warn("Enter decision outcome " + outcome);
        TestUtils.wait(2);
        TestUtils.selectByVisibleText(driver, decisionOutcome,outcome);
    }

    public void selectDecisionReason(String reason){
        log.warn("Enter decision outcome " + reason);
        TestUtils.wait(2);
        TestUtils.selectByVisibleText(driver, decisionReason2,reason);
    }

    public void enterResourceDetails(String data){
        By resourceTextAreaXpath=By.xpath("//textarea[@id='resourceDetails']");
        driver.findElement(resourceTextAreaXpath).sendKeys(data);
    }

    public void selectAllOrNoneOption(String option){
        String id = "";
        option=option.toUpperCase();
        switch(option){
            case "ALL" : id = "allBtnAl1yText";
                break;
            case "NONE" : id="noneBtnAl1yText"    ;
                break;
        }
        By optionXpath = By.xpath("//tr[@ng-if='customRequestReason']//button[@aria-describedby='"+id+"']");
        TestUtils.wait(2);
        TestUtils.click(driver,optionXpath);
        TestUtils.wait(3);
    }

    public void selectAllCriteriaResourceUsed(){
        By criteriaDropdwnXpath=By.xpath("//span[@id='resourcesUsedSelect']//span[@class='cux-icon-sort_down']");
        By allXpath= By.xpath("//span[@id='resourcesUsedSelect']//button[@aria-describedby='allBtnAl1yText']");
        TestUtils.click(driver, criteriaDropdwnXpath);
        TestUtils.wait(2);
        TestUtils.click(driver,allXpath);
        TestUtils.wait(2);
    }
    public void clickOverrideDecisionButton(){
        By customReasonDropDwnXpath = By.xpath("//tr[@ng-if='customRequestReason']//span[@class='cux-icon-sort_down']");
        By overrideBtnXpath= By.xpath("//input[@value='Override Decision']");
        TestUtils.wait(2);
        TestUtils.click(driver,overrideBtnXpath);
        TestUtils.wait(3);
        Assert.assertFalse(TestUtils.isElementVisible(driver,customReasonDropDwnXpath));

    }

    public void verifyCustomReasonAutoSelected(String option){

        By optionXpath = By.xpath("//span[@id='customRequestReasonTypeStyle']//div//label//input[@checked='checked']//..//span[@class='tk-multi-label ng-binding' and text()='"+option+"']");
        //clickCustomReasonDropdown();
        Assert.assertTrue(TestUtils.isElementVisible(driver,optionXpath));
        Assert.assertFalse(TestUtils.isElementVisible(driver,By.xpath("//span[@id='ocmTooltip-customRequestReasonTooltip']")));
    }
    public void clickCustomReasonDropdown(){

        By customDropdwnXpath=By.xpath("//tr[@ng-if='customRequestReason']//span[@class='cux-icon-sort_down']");
        TestUtils.click(driver,customDropdwnXpath);
        TestUtils.wait(2);

    }
}
