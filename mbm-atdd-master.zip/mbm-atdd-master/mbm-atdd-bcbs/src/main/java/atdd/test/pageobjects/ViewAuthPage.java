package atdd.test.pageobjects;

import atdd.common.ICondition;
import atdd.common.Retry;
import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ViewAuthPage {

    public static final String STICKY_HEADER_XPATH = "//div[contains(@class, 'stickyMenu')]";

    public static final String AUTH_REQ_HEADER_XPATH = "//span[contains(@class, 'authReqHeader')]";

    public static final String SUMMARY_PANEL_XPATH = "//div[@id='summarySectionPanelId']";
    public static final String MEMBER_PANEL_XPATH = "//div[@id='coveragePanelId']";
    public static final String SERVICES_AND_DECISIONS_PANEL_XPATH = "//div[@id='servicesPanelId']";
    public static final String CLINICAL_PANEL_XPATH = "//div[@id='clinicalSectionPanelId']";
    public static final String ASSIGNMENTS_PANEL_XPATH = "//div[@id='assignmentPanelId']";
    public static final String ACTIVITIES_PANEL_XPATH = "//div[@id='activityHistoryPanelId']";
    public static final String NOTES_PANEL_XPATH = "//div[@id='notesSectionPanelId']";
    public static final String PROVIDER_PANEL_XPATH = "//div[@id='umProviderPanelId']";
    public static final String COMMUNICATION_PANEL_XPATH = "//div[@id='faxRequestPanelId']";

    public static final By stickyHeader = By.xpath(STICKY_HEADER_XPATH);
    public static final By memberHeader = By.xpath(STICKY_HEADER_XPATH + "/div[contains(@class, 'stickyHeader')]");

    public static final By authReqHeader = By.xpath(AUTH_REQ_HEADER_XPATH);

    public static final By tabSummary = By.xpath(STICKY_HEADER_XPATH + "//button[. = 'Summary']");
    public static final By tabMember = By.xpath(STICKY_HEADER_XPATH + "//button[. = 'Member']");
    public static final By tabServiceAndDecisions = By.xpath(STICKY_HEADER_XPATH + "//button[. = 'Services and Decisions']");
    public static final By tabClinical = By.xpath(STICKY_HEADER_XPATH + "//button[. = 'Clinical']");
    public static final By tabAssignments = By.xpath(STICKY_HEADER_XPATH + "//button[. = 'Assignments']");
    public static final By tabActivities = By.xpath(STICKY_HEADER_XPATH + "//button[. = 'Activities']");
    public static final By tabNotes = By.xpath(STICKY_HEADER_XPATH + "//button[. = 'Notes']");
    public static final By tabProvider = By.xpath(STICKY_HEADER_XPATH + "//button[. = 'Provider']");
    public static final By tabCommunication = By.xpath(STICKY_HEADER_XPATH + "//button[. = 'Communication']");

    public static final By panelSummary = By.xpath(SUMMARY_PANEL_XPATH);
    public static final By panelMember = By.xpath(MEMBER_PANEL_XPATH);
    public static final By panelServicesAndDecisions = By.xpath(SERVICES_AND_DECISIONS_PANEL_XPATH);
    public static final By panelClinical = By.xpath(CLINICAL_PANEL_XPATH);
    public static final By panelAssignments = By.xpath(ASSIGNMENTS_PANEL_XPATH);
    public static final By panelActivities = By.xpath(ACTIVITIES_PANEL_XPATH);
    public static final By panelNotes = By.xpath(NOTES_PANEL_XPATH);
    public static final By panelProvider = By.xpath(PROVIDER_PANEL_XPATH);
    public static final By panelCommunication = By.xpath(COMMUNICATION_PANEL_XPATH);

    public static final By cancelAuthorizationRequestLink = By.xpath("//a[.='Cancel Authorization Request']");
    public static final By cancelReasonSelect = By.xpath("//form[@name='cancelWorkqueueAuthPopupModelForm']//select[@ref-nm='hscStatusReasonType']");
    public static final By cancelRequestButton = By.xpath("//form[@name='cancelWorkqueueAuthPopupModelForm']//input[@value='Cancel Request']");

    public static final By assignmentPageIdContent = By.xpath("//*[@id='assignmentPanelIdContent']/div/div[3]/table/tbody/tr//input");
    public static final By closeAssignmentHistoryPopupModalId = By.xpath("//*[@id='assignmentHistoryPopupModelID']//input[@value='Close']");
    public static final By decisionEnteredBy = By.xpath("//*[@id='decisionsForm']/form/table/tbody/tr/td[1]/table/tbody/tr[11]/td[2]/p");
    public static final By decisionForm = By.xpath("//*[@id='decisionsForm']/form/table/tbody");
    public static final By decisionTimeErr = By.xpath("//*[@id='decisionTime_err']");
    public static final By decisionDateErr = By.xpath("//*[@id='decisionDate-date_err']");
    public static final By decisionRenderedBy = By.xpath("//*[@id='hscServiceDecisionVO-decisionMadeByUserID-0']");
    public static final By resourceCommentText = By.id("resourceCommentText");
    public static final By claimNote = By.id("claimNote");
    public static final By medicalBenefitServicesTableRows = By.xpath("//*[@id='medicalBenefitServicesTableID']/tbody/tr");
    public static final By medicalBenefitServicesTableDecisionStatus = By.xpath("//*[@id='medicalBenefitServicesTableID']/tbody/tr[1]/td[3]/a");
    public static final String splitDecisionWarningCloseButtonXpath = "//div[@class='popup-header-wrapper' and .//h2[text()='Split Decision Warning']]//button";

    public static final By makeDecisionsButton = By.id("makeDecisionsButton");
    public static final By saveDecisionsButton = By.id("saveDecisionsButton");

    private static Logger log = Logger.getLogger(ViewAuthPage.class);
    protected WebDriver driver;

    public static boolean isViewAuthPageLoaded(WebDriver d) {
        return true
                && TestUtils.isElementVisible(d, ViewAuthPage.STICKY_HEADER_XPATH)
                && TestUtils.isElementVisible(d, ViewAuthPage.SUMMARY_PANEL_XPATH)
                && TestUtils.isElementVisible(d, ViewAuthPage.MEMBER_PANEL_XPATH)
                && TestUtils.isElementVisible(d, ViewAuthPage.SERVICES_AND_DECISIONS_PANEL_XPATH)
                && TestUtils.isElementVisible(d, ViewAuthPage.CLINICAL_PANEL_XPATH)
                && TestUtils.isElementVisible(d, ViewAuthPage.ASSIGNMENTS_PANEL_XPATH)
                && TestUtils.isElementVisible(d, ViewAuthPage.ACTIVITIES_PANEL_XPATH)
                && TestUtils.isElementVisible(d, ViewAuthPage.NOTES_PANEL_XPATH)
                && TestUtils.isElementVisible(d, ViewAuthPage.PROVIDER_PANEL_XPATH)
                && TestUtils.isElementVisible(d, ViewAuthPage.COMMUNICATION_PANEL_XPATH)
                ;
    }

    public static boolean waitForViewAuthPageLoaded(WebDriver d) {
        TestUtils.waitForNotBusy(d);
        return new Retry("Wait for ViewAuthPage to be loaded.") {
            int wait = 3;

            @Override
            protected void tryOnce() throws Exception {
                if (!landed()) {
                    throw new RuntimeException("Need recover.");
                }
            }

            private boolean landed() {
                TestUtils.wait(wait > 10 ? 10 : wait++);
                return isViewAuthPageLoaded(d);
            }

            @Override
            protected void weakRecover(Exception e) throws Exception {
                TestUtils.refreshPage(d);
            }

        }.execute();
    }

    /*Page Constructor*/
    public ViewAuthPage(WebDriver driver) {
        this.driver = driver;
    }

    public static Map<String, String> dataOfDecision(String option) {
        Map<String, String> map = new LinkedHashMap<>();
        switch (option) {
            case "Denied":
                map.put("Decision Outcome", "Denied/Not Covered");
                map.put("Decision Type", "Administrative");
                map.put("Decision Reason - Medical Benefit", "D1 Deny, Not Medically Necessary");
                map.put("Decision Notes", "decision note");
                map.put("Custom Request Reason", "Max Dosage Exceeded (Specialty)");
                map.put("Resource(s) Used", "All");
                map.put("Resource Details", "resource details");
                map.put("Claim Type / Comment", "claim type / comment");
                return map;
            case "Approved":
                map.put("Decision Outcome", "Approved/Covered");
                map.put("Decision Type", "Administrative");
                map.put("Decision Reason - Medical Benefit", "A1 Approve, Medically Appropriate");
                map.put("Decision Notes", "decision note");
                map.put("Custom Request Reason", "Max Dosage Exceeded (Specialty)");
                map.put("Resource(s) Used", "All");
                map.put("Resource Details", "resource details");
                map.put("Claim Type / Comment", "claim type / comment");
                return map;
            default:
                // do nothing
        }
        return null;
    }

    public void cancelAuthorizationRequest(String reason) {
        TestUtils.click(driver, cancelAuthorizationRequestLink);
        TestUtils.input(driver, cancelReasonSelect, reason);
        TestUtils.click(driver, cancelRequestButton);
        TestUtils.wait(2);
    }

    public List<String> getLinks() {
        List<String> links = new ArrayList<>();
        String xpath = "//div[@ng-if='onLoadHscMemProvView']//a";
        List<WebElement> els = TestUtils.findElements(driver, xpath);
        if (els.size() > 0) {
            for (WebElement el : els) {
                links.add(el.getText().trim());
            }
        }
        return links;
    }

    public boolean clickMakeDecisions() {
        return TestUtils.clickUntil(driver, makeDecisionsButton, new ICondition() {
            @Override
            public boolean evaluate() {
                return TestUtils.isElementVisible(driver, saveDecisionsButton);

            }
        });
    }

    public boolean clickSaveDecisions() {
        return TestUtils.clickUntil(driver, saveDecisionsButton, new ICondition() {
            @Override
            public boolean evaluate() {
                return TestUtils.isElementVisible(driver, saveDecisionsButton);

            }
        });
    }
}
