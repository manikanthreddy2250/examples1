package atdd.test.pageobjects.pageValueObject;

import atdd.utils.AssertUtils;

public class PvoWorkQueueManagerDashboard {
    private PvoWorkQueueManagerDashboardWidget pastDue;
    private PvoWorkQueueManagerDashboardWidget due24;
    private PvoWorkQueueManagerDashboardWidget due48;
    private PvoWorkQueueManagerDashboardWidget allOpenAuthorizations;

    public PvoWorkQueueManagerDashboardWidget getPastDue() {
        return pastDue;
    }

    public void setPastDue(PvoWorkQueueManagerDashboardWidget pastDue) {
        this.pastDue = pastDue;
    }

    public PvoWorkQueueManagerDashboardWidget getDue24() {
        return due24;
    }

    public void setDue24(PvoWorkQueueManagerDashboardWidget due24) {
        this.due24 = due24;
    }

    public PvoWorkQueueManagerDashboardWidget getDue48() {
        return due48;
    }

    public void setDue48(PvoWorkQueueManagerDashboardWidget due48) {
        this.due48 = due48;
    }

    public PvoWorkQueueManagerDashboardWidget getAllOpenAuthorizations() {
        return allOpenAuthorizations;
    }

    public void setAllOpenAuthorizations(PvoWorkQueueManagerDashboardWidget allOpenAuthorizations) {
        this.allOpenAuthorizations = allOpenAuthorizations;
    }

    public void appendHealthyIssues(final StringBuilder healthyIssues) {
        healthyIssues.append("\n");

        //pastDue VS allOpenAuthorizations
        healthyIssues.append(AssertUtils.assertEquals(this.getAllOpenAuthorizations().getPastDue(), this.getPastDue().getPastDue()) + "\n");
        healthyIssues.append(AssertUtils.assertEquals(this.getAllOpenAuthorizations().getDue24(), this.getPastDue().getDue24()) + "\n");
//        Out of scope - 2/27
//        healthyIssues.append(AssertUtils.assertEquals(this.getAllOpenAuthorizations().getDue48(), this.getPastDue().getDue48()) + "\n");
        healthyIssues.append(AssertUtils.assertEquals(this.getAllOpenAuthorizations().getAllOpenAuthorizations(), this.getPastDue().getAllOpenAuthorizations()) + "\n");

        //due24 VS allOpenAuthorizations
        healthyIssues.append(AssertUtils.assertEquals(this.getAllOpenAuthorizations().getPastDue(), this.getDue24().getPastDue()) + "\n");
        healthyIssues.append(AssertUtils.assertEquals(this.getAllOpenAuthorizations().getDue24(), this.getDue24().getDue24()) + "\n");
//        Out of scope - 2/27
//        healthyIssues.append(AssertUtils.assertEquals(this.getAllOpenAuthorizations().getDue48(), this.getDue24().getDue48()) + "\n");
        healthyIssues.append(AssertUtils.assertEquals(this.getAllOpenAuthorizations().getAllOpenAuthorizations(), this.getDue24().getAllOpenAuthorizations()) + "\n");

        //due48 VS allOpenAuthorizations
//        Out of scope - 2/27
//        healthyIssues.append(AssertUtils.assertEquals(this.getAllOpenAuthorizations().getPastDue(), this.getDue48().getPastDue()) + "\n");
//        healthyIssues.append(AssertUtils.assertEquals(this.getAllOpenAuthorizations().getDue24(), this.getDue48().getDue24()) + "\n");
//        healthyIssues.append(AssertUtils.assertEquals(this.getAllOpenAuthorizations().getDue48(), this.getDue48().getDue48()) + "\n");
//        healthyIssues.append(AssertUtils.assertEquals(this.getAllOpenAuthorizations().getAllOpenAuthorizations(), this.getDue48().getAllOpenAuthorizations()) + "\n");

        if (!healthyIssues.toString().trim().isEmpty()) {
            healthyIssues.append("\n\tAbove messages are from " + PvoWorkQueueManagerDashboard.class + "\n\t");
        }

        //pastDue healthy
        this.getPastDue().appendHealthyIssues(healthyIssues);

        //due24 healthy
        this.getDue24().appendHealthyIssues(healthyIssues);

//        //due48 healthy
//        Out of scope - 2/27
//        this.getDue48().appendHealthyIssues(healthyIssues);

        //allOpenAuthorizations healthy
        this.getAllOpenAuthorizations().appendHealthyIssues(healthyIssues);

        healthyIssues.append("\n");
    }
}
