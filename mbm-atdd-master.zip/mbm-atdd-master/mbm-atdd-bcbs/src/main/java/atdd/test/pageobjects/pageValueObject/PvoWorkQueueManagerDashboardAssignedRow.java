package atdd.test.pageobjects.pageValueObject;

public class PvoWorkQueueManagerDashboardAssignedRow {
    private String userFullName;
    private Integer total;
    private Integer urgent;
    private Integer mdReviews;

    public String getUserFullName() {
        return userFullName;
    }

    public void setUserFullName(String userFullName) {
        this.userFullName = userFullName;
    }

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }

    public Integer getUrgent() {
        return urgent;
    }

    public void setUrgent(Integer urgent) {
        this.urgent = urgent;
    }

    public Integer getMdReviews() {
        return mdReviews;
    }

    public void setMdReviews(Integer mdReviews) {
        this.mdReviews = mdReviews;
    }
}
