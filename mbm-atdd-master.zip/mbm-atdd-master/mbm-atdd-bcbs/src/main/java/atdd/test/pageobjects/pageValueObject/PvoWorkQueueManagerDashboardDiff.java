package atdd.test.pageobjects.pageValueObject;

import atdd.utils.QuickJson;

import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

public class PvoWorkQueueManagerDashboardDiff extends PvoWorkQueueManagerDashboard {

    private static Integer calcDiff(Integer a, Integer b) {
        a = null == a ? 0 : a;
        b = null == b ? 0 : b;
        return a - b;
    }

    private PvoWorkQueueManagerDashboardDiff(PvoWorkQueueManagerDashboard pvo) {
        this.setPastDue(pvo.getPastDue());
        this.setDue24(pvo.getDue24());
        this.setDue48(pvo.getDue48());
        this.setAllOpenAuthorizations(pvo.getAllOpenAuthorizations());
    }

    public static PvoWorkQueueManagerDashboardDiff diff(PvoWorkQueueManagerDashboard a, PvoWorkQueueManagerDashboard b) {
        PvoWorkQueueManagerDashboard aClone = (PvoWorkQueueManagerDashboard) QuickJson.clone(a);
        diffWidget(aClone.getPastDue(), b.getPastDue());
        diffWidget(aClone.getDue24(), b.getDue24());
        diffWidget(aClone.getDue48(), b.getDue48());
        diffWidget(aClone.getAllOpenAuthorizations(), b.getAllOpenAuthorizations());

        return new PvoWorkQueueManagerDashboardDiff(aClone);
    }

    private static void diffWidget(PvoWorkQueueManagerDashboardWidget a, PvoWorkQueueManagerDashboardWidget b) {
        a.setTotal(calcDiff(a.getPastDue(), b.getPastDue()));
        a.setPastDue(calcDiff(a.getPastDue(), b.getPastDue()));
        a.setDue24(calcDiff(a.getDue24(), b.getDue24()));
        a.setDue48(calcDiff(a.getDue48(), b.getDue48()));
        a.setAllOpenAuthorizations(calcDiff(a.getAllOpenAuthorizations(), b.getAllOpenAuthorizations()));
        diff(a.getUnassignedList(), b.getUnassignedList());
        diff(a.getAssignedList(), b.getAssignedList());
    }

    private static void diff(PvoWorkQueueManagerDashboardUnassignedList a, PvoWorkQueueManagerDashboardUnassignedList b) {
        a.setTotal(calcDiff(a.getTotal(), b.getTotal()));
        Map<String, PvoWorkQueueManagerDashboardUnassignedRow> aMap = a.getUnassignedRowList();
        Map<String, PvoWorkQueueManagerDashboardUnassignedRow> bMap = b.getUnassignedRowList();
        Set<String> keys = new LinkedHashSet<>(aMap.keySet());
        keys.addAll(bMap.keySet());
        for (String queueName : keys) {
            if (!aMap.containsKey(queueName)) {
                aMap.put(queueName, new PvoWorkQueueManagerDashboardUnassignedRow());
            }
            if (!bMap.containsKey(queueName)) {
                bMap.put(queueName, new PvoWorkQueueManagerDashboardUnassignedRow());
            }
            diff(aMap.get(queueName), bMap.get(queueName));
        }
    }

    private static void diff(PvoWorkQueueManagerDashboardAssignedList a, PvoWorkQueueManagerDashboardAssignedList b) {
        a.setTotal(calcDiff(a.getTotal(), b.getTotal()));
        a.setUrgent(calcDiff(a.getUrgent(), b.getUrgent()));
        a.setMdReviews(calcDiff(a.getMdReviews(), b.getMdReviews()));
        Map<String, PvoWorkQueueManagerDashboardAssignedRow> aMap = a.getAssignedRowList();
        Map<String, PvoWorkQueueManagerDashboardAssignedRow> bMap = b.getAssignedRowList();
        Set<String> keys = new LinkedHashSet<>(aMap.keySet());
        for (String queueName : keys) {
            if (!aMap.containsKey(queueName)) {
                aMap.put(queueName, new PvoWorkQueueManagerDashboardAssignedRow());
            }
            if (!bMap.containsKey(queueName)) {
                bMap.put(queueName, new PvoWorkQueueManagerDashboardAssignedRow());
            }
            diff(aMap.get(queueName), bMap.get(queueName));
        }
    }

    private static void diff(PvoWorkQueueManagerDashboardUnassignedRow a, PvoWorkQueueManagerDashboardUnassignedRow b) {
        a.setTotal(calcDiff(a.getTotal(), b.getTotal()));
    }

    private static void diff(PvoWorkQueueManagerDashboardAssignedRow a, PvoWorkQueueManagerDashboardAssignedRow b) {
        a.setTotal(calcDiff(a.getTotal(), b.getTotal()));
        a.setUrgent(calcDiff(a.getUrgent(), b.getUrgent()));
        a.setMdReviews(calcDiff(a.getMdReviews(), b.getMdReviews()));
    }
}
