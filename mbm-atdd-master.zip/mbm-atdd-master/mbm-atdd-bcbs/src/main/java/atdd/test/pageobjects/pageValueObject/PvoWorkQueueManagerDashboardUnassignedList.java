package atdd.test.pageobjects.pageValueObject;

import atdd.utils.AssertUtils;

import java.util.Map;

public class PvoWorkQueueManagerDashboardUnassignedList {
    private Integer total;
    private Map<String, PvoWorkQueueManagerDashboardUnassignedRow> unassignedRowList;

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }

    public Map<String, PvoWorkQueueManagerDashboardUnassignedRow> getUnassignedRowList() {
        return unassignedRowList;
    }

    public void setUnassignedRowList(Map<String, PvoWorkQueueManagerDashboardUnassignedRow> unassignedRowList) {
        this.unassignedRowList = unassignedRowList;
    }

    public void appendHealthyIssues(StringBuilder healthyIssues) {
        healthyIssues.append("\n");

        healthyIssues.append(AssertUtils.assertEquals(this.getTotal(), this.getSumOfQueueTotals()) + "\n");
        if (!healthyIssues.toString().trim().isEmpty()) {
            healthyIssues.append("\n\tAbove messages are from " + PvoWorkQueueManagerDashboardWidget.class + "\n\t");
        }

        healthyIssues.append("\n");
    }

    private Integer getSumOfQueueTotals() {
        Integer sum = 0;
        for (String queueName : this.getUnassignedRowList().keySet()) {
            Integer queueTotal = this.getUnassignedRowList().get(queueName).getTotal();
            if (null == queueTotal) {
                return null;
            } else {
                sum += queueTotal;
            }
        }
        return sum;
    }
}
