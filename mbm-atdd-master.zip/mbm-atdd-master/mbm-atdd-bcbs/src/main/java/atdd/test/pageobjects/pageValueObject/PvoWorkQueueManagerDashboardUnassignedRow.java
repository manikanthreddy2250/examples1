package atdd.test.pageobjects.pageValueObject;

public class PvoWorkQueueManagerDashboardUnassignedRow {
    private String queueName;
    private Integer total;

    public String getQueueName() {
        return queueName;
    }

    public void setQueueName(String queueName) {
        this.queueName = queueName;
    }

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }

    @Override
    public boolean equals(Object o) {
        if (null == o || !(o instanceof PvoWorkQueueManagerDashboardUnassignedRow)) {
            return false;
        } else {
            PvoWorkQueueManagerDashboardUnassignedRow row = (PvoWorkQueueManagerDashboardUnassignedRow) o;
            return row.getQueueName().equals(this.getQueueName());
        }
    }
}
