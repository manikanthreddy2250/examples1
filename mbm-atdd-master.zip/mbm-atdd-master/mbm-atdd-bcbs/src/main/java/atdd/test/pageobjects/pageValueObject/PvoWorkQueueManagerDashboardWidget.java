package atdd.test.pageobjects.pageValueObject;

import atdd.utils.AssertUtils;

public class PvoWorkQueueManagerDashboardWidget {
    private String widget;
    private Integer total;
    private Integer pastDue;
    private Integer due24;
    private Integer due48;
    private Integer allOpenAuthorizations;
    private PvoWorkQueueManagerDashboardUnassignedList unassignedList;
    private PvoWorkQueueManagerDashboardAssignedList assignedList;

    public String getWidget() {
        return widget;
    }

    public void setWidget(String widget) {
        this.widget = widget;
    }

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }

    public Integer getPastDue() {
        return pastDue;
    }

    public void setPastDue(Integer pastDue) {
        this.pastDue = pastDue;
    }

    public Integer getDue24() {
        return due24;
    }

    public void setDue24(Integer due24) {
        this.due24 = due24;
    }

    public Integer getDue48() {
        return due48;
    }

    public void setDue48(Integer due48) {
        this.due48 = due48;
    }

    public Integer getAllOpenAuthorizations() {
        return allOpenAuthorizations;
    }

    public void setAllOpenAuthorizations(Integer allOpenAuthorizations) {
        this.allOpenAuthorizations = allOpenAuthorizations;
    }

    public PvoWorkQueueManagerDashboardUnassignedList getUnassignedList() {
        return unassignedList;
    }

    public void setUnassignedList(PvoWorkQueueManagerDashboardUnassignedList unassignedList) {
        this.unassignedList = unassignedList;
    }

    public PvoWorkQueueManagerDashboardAssignedList getAssignedList() {
        return assignedList;
    }

    public void setAssignedList(PvoWorkQueueManagerDashboardAssignedList assignedList) {
        this.assignedList = assignedList;
    }

    public void appendHealthyIssues(final StringBuilder healthyIssues) {
        healthyIssues.append("\n");

        healthyIssues.append(AssertUtils.assertEquals(this.getTotal(), this.getUnassignedList().getTotal() + this.getAssignedList().getTotal()) + "\n");
        if (!healthyIssues.toString().trim().isEmpty()) {
            healthyIssues.append("\n\tAbove messages are from " + widget + "/" + PvoWorkQueueManagerDashboardWidget.class + "\n\t");
        }

        this.getUnassignedList().appendHealthyIssues(healthyIssues);
        this.getAssignedList().appendHealthyIssues(healthyIssues);

        healthyIssues.append("\n");
    }
}
