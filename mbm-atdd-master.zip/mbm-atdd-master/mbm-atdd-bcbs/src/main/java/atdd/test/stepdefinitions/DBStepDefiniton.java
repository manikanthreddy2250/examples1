package atdd.test.stepdefinitions;

import atdd.common.MapsComparer;
import atdd.common.ScenarioLogger;
import atdd.dao.mbm.HscDao;
import atdd.dao.mbm.MyBatisConnectionFactory;
import atdd.dao.member.BcbsMemberDao;
import atdd.dao.member.MyBatisConnectionFactoryBcbsMember;
import atdd.dao.provider.BcbsProviderDao;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.stepsets.Login;
import atdd.utils.*;
import cucumber.api.DataTable;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class DBStepDefiniton {
    public static final Logger log = Logger.getLogger(DBStepDefiniton.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }

    @And("^user verifies the search results with the database values for \"([^\"]*)\"$")
    public void userVerifiesTheSearchResultsWithTheDatabaseValues(String LastName) throws Throwable {
        List<Map<String, Object>> ProviderList = new BcbsProviderDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectByProviderLastName(LastName);
        log.warn(ProviderList);
        Assert.assertTrue("firstname dont match", ProviderList.get(0).get(0).equals(LastName));
    }


    @And("^user verifies the total record count for records from db for \"([^\"]*)\" for the following criteria$")
    public void userVerifiesTheTotalRecordCountForRecordsFromDbForForTheFollowingCriteria(String tab, DataTable criteria) throws Throwable {
        List<Map<String, String>> maps = WhiteBoard.resolve(owner, criteria.asMaps(String.class, String.class));
        List<Map<String, Object>> SearchResults;
        int recordcount = obj().PriorAuthorizationSearchSubmittedPage.verifyRecordCount(tab, maps);
        switch (tab) {
            case "Submitted":
                for (Map<String, String> map : maps) {
                    Set<String> values = map.keySet();
                    for (String s : values) {
                        switch (s) {
                            case "providerNPI":
                                SearchResults = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectBycriteriae(map.get(s));
                                log.warn(SearchResults.size() + "results retrived");
                                Assert.assertEquals("db not matches with ui", SearchResults.size(), recordcount);
                                break;
                            case "Member Last Name":
                                SearchResults = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectByMemberLastName(map.get(s));
                                log.warn(SearchResults.size() + "results retrived");
                                Assert.assertEquals("db not matches with ui", SearchResults.size(), recordcount);
                                break;
                            case "Request Number":
                                SearchResults = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectByRequestNumber(map.get(s));
                                log.warn(SearchResults.size() + "results retrived");
                                Assert.assertEquals("db not matches with ui", SearchResults.size(), recordcount);
                                break;
                            case "Subscriber / Member ID":
                                SearchResults = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectBySubscriberId(map.get(s));
                                log.warn(SearchResults.size() + "results retrived");
                                Assert.assertEquals("db not matches with ui", SearchResults.size(), recordcount);
                                break;
                            case "Physician / Facility Name":
                                SearchResults = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectByPhysicianName(map.get(s));
                                log.warn(SearchResults.size() + "results retrived");
                                Assert.assertEquals("db not matches with ui", SearchResults.size(), recordcount);
                                break;
                            case "Physician / Facility TIN":
                                SearchResults = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectByPhysicianTIN(map.get(s));
                                log.warn(SearchResults.size() + "results retrived");
                                Assert.assertEquals("db not matches with ui", SearchResults.size(), recordcount);
                                break;
                            case "Priority":
                                SearchResults = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectByPriority();
                                log.warn(SearchResults.size() + "results retrived");
                                Assert.assertEquals("db not matches with ui", SearchResults.size(), recordcount);
                                break;

                        }
                    }

                }
                break;
            case "Drafts":
                for (Map<String, String> map : maps) {
                    Set<String> values = map.keySet();
                    for (String s : values) {
                        switch (s) {
                            case "providerNPI":
                                SearchResults = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectBycriteriaeDrafts(map.get(s));
                                log.warn(SearchResults.size() + "results retrived");
                                Assert.assertEquals("db not matches with ui", SearchResults.size(), recordcount);
                                break;
                            case "Member Last Name":
                                SearchResults = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectByMemberLastNameDrafts(map.get(s));
                                log.warn(SearchResults.size() + "results retrived");
                                Assert.assertEquals("db not matches with ui", SearchResults.size(), recordcount);
                                break;
                            case "Draft ID":
                                SearchResults = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectByDraftIDDrafts(map.get(s));
                                log.warn(SearchResults.size() + "results retrived");
                                Assert.assertEquals("db not matches with ui", SearchResults.size(), recordcount);
                                break;
                            case "Subscriber / Member ID":
                                SearchResults = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectBySubscriberIdDrafts(map.get(s));
                                log.warn(SearchResults.size() + "results retrived");
                                Assert.assertEquals("db not matches with ui", SearchResults.size(), recordcount);
                                break;
                            case " Creator First Name":
                                SearchResults = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectByCreatorNameDrafts(map.get(s));
                                log.warn(SearchResults.size() + "results retrived");
                                Assert.assertEquals("db not matches with ui", SearchResults.size(), recordcount);
                                break;
                            case " Creator Last Name":
                                SearchResults = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectByCreatorLastNameDrafts(map.get(s));
                                log.warn(SearchResults.size() + "results retrived");
                                Assert.assertEquals("db not matches with ui", SearchResults.size(), recordcount);
                                break;
                            case "Physician / Facility TIN":
                                SearchResults = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectByPhysicianTINDrafts(map.get(s));
                                log.warn(SearchResults.size() + "results retrived");
                                Assert.assertEquals("db not matches with ui", SearchResults.size(), recordcount);
                                break;
                            case "Priority":
                                SearchResults = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectByPriorityDrafts();
                                log.warn(SearchResults.size() + "results retrived");
                                Assert.assertEquals("db not matches with ui", SearchResults.size(), recordcount);
                                break;


                        }
                    }
                    break;
                }
        }
    }

    @And("^user verifies the total record count for records from db for \"([^\"]*)\" for the following criteria for provider$")
    public void userVerifiesTheTotalRecordCountForRecordsFromDbForForTheFollowingCriteriaForProvider(String tab, DataTable criteria) throws Throwable {
        List<Map<String, String>> maps = WhiteBoard.resolve(owner, criteria.asMaps(String.class, String.class));
        int recordcount = obj().PriorAuthorizationSearchSubmittedPage.verifyRecordCount(tab, maps);
        List<Map<String, Object>> SearchResults;
        switch (tab) {
            case "Submitted":
                for (Map<String, String> map : maps) {
                    Set<String> values = map.keySet();
                    for (String s : values) {
                        switch (s) {
                            case "providerNPI":

                                SearchResults = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectBycriteriaeSubmittedrovider(map.get(s));
                                log.warn(SearchResults.size() + "results retrived");
                                Assert.assertEquals("db not matches with ui", SearchResults.size(), recordcount);
                                break;
                            case "Last Name":
                                SearchResults = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectByMemberLastNameProvider(map.get(s));
                                log.warn(SearchResults.size() + "results retrived");
                                Assert.assertEquals("db not matches with ui", SearchResults.size(), recordcount);
                                break;
                            case "Request Number":
                                SearchResults = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectByRequestNumberProvider(map.get(s));
                                log.warn(SearchResults.size() + "results retrived");
                                Assert.assertEquals("db not matches with ui", SearchResults.size(), recordcount);
                                break;
                            case "Subscriber / Member ID":
                                SearchResults = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectBySubscriberIdProvider(map.get(s));
                                log.warn(SearchResults.size() + "results retrived");
                                Assert.assertEquals("db not matches with ui", SearchResults.size(), recordcount);
                                break;
                            case "Physician / Facility Name":
                                SearchResults = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectByPhysicianNameProvider(map.get(s));
                                log.warn(SearchResults.size() + "results retrived");
                                Assert.assertEquals("db not matches with ui", SearchResults.size(), recordcount);
                                break;

                        }
                    }

                }
                break;
            case "Drafts":
                for (Map<String, String> map : maps) {
                    Set<String> values = map.keySet();
                    for (String s : values) {
                        switch (s) {
                            case "providerNPI":
                                SearchResults = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectBycriteriaeDraftsProvider(map.get(s));
                                log.warn(SearchResults.size() + "results retrived");
                                Assert.assertEquals("db not matches with ui", SearchResults.size(), recordcount);
                                break;
                            case "Last Name":
                                SearchResults = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectByMemberLastNameDraftsProvider(map.get(s));
                                log.warn(SearchResults.size() + "results retrived");
                                Assert.assertEquals("db not matches with ui", SearchResults.size(), recordcount);
                                break;
                            case "Draft ID":
                                SearchResults = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectByDraftIDProviderDrafts(map.get(s));
                                log.warn(SearchResults.size() + "results retrived");
                                Assert.assertEquals("db not matches with ui", SearchResults.size(), recordcount);
                                break;
                            case "Subscriber / Member ID":
                                SearchResults = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectBySubscriberIdProviderDrafts(map.get(s));
                                log.warn(SearchResults.size() + "results retrived");
                                Assert.assertEquals("db not matches with ui", SearchResults.size(), recordcount);
                                break;

                        }
                    }
                    break;
                }

                }

        }

    @And("^user validates member information against DB$")
    public void userValidatesMemberInformationAgainstDB() throws Throwable {
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        List<Map<String, Object>> mbrDetails = new BcbsMemberDao(MyBatisConnectionFactoryBcbsMember.getSqlSessionFactory())
                .getMemberInformationDetails(pf.get(MBM.MEMB_SUBSCRIBER_ID));
        List<Map<String, String>> member1 = TestUtils.transposedTableAsMaps(driver(), "//div[@id='memberInformationPanelIdContent']//table", 10);
        List<Map<String, String>> memberDb = DataTableUtils.asMapsOfStrings(mbrDetails);
        MapsComparer mapsComparer = new MapsComparer(memberDb, member1, scenarioLogger);
        mapsComparer.assertMatches(false);
    }
}

