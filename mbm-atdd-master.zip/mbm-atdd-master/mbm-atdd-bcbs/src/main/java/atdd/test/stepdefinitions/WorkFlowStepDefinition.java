//package atdd.test.stepdefinitions;
//
//import atdd.common.ICondition;
//import atdd.common.Retry;
//import atdd.common.ScenarioLogger;
//import atdd.dao.mbm.*;
//import atdd.dao.workflow.MyBatisConnectionFactoryWorkflow;
//import atdd.dao.workflow.QueueItemDao;
//import atdd.dao.workflow.WorkQueueDao;
//import atdd.test.core.SearchCriteria;
//import atdd.test.pageobjects.*;
//import atdd.test.pageobjects.pageValueObject.PvoWorkQueueManagerDashboard;
//import atdd.test.pageobjects.pageValueObject.PvoWorkQueueManagerDashboardDiff;
//import atdd.test.pageobjects.priorAuthSearch.PriorAuthorizationSearchSubmittedPage;
//import atdd.test.stepsets.*;
//import atdd.utils.*;
//import cucumber.api.DataTable;
//import cucumber.api.Scenario;
//import cucumber.api.java.Before;
//import cucumber.api.java.en.And;
//import cucumber.api.java.en.Given;
//import cucumber.api.java.en.Then;
//import cucumber.api.java.en.When;
//import org.apache.log4j.Logger;
//import org.junit.Assert;
//import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
//
//import java.io.StringReader;
//import java.util.*;
//
//public class WorkFlowStepDefinition {
//    public static final Logger log = Logger.getLogger(WorkFlowStepDefinition.class.getName());
//
//    private ScenarioLogger scenarioLogger = null;
//    List<String> customRequestReasonsInHeader;
//    List<String> customRequestReasonInMakeDecision;
//    private Scenario scenario;
//    private String owner;
//
//    private BcbsPageObject obj() throws Throwable {
//        return new BcbsPageObject(scenario, driver());
//    }
//
//    private WebDriver driver() throws Throwable {
//        return Login.login(scenario);
//    }
//
//    @Before
//    public void beforeScenario(Scenario scenario) throws Throwable {
//        this.scenario = scenario;
//        this.owner = scenario.getId();
//        this.scenarioLogger = new ScenarioLogger(scenario, log);
//    }
//
//    @And("^Work Queue items are extracted with prefix \"([^\"]*)\" and key header \"([^\"]*)\"$")
//    public void workQueueItemsAreExtractedWithPrefixAndKeyHeader(String prefix, String keyHeader) throws Throwable {
//        prefix = WhiteBoard.resolve(owner, prefix);
//        TestUtils.demoBreakPoint(scenario, driver(), "Work Queue - Search result");
//        TestUtils.extractGridToWhiteBoard(driver(), scenario, prefix, keyHeader, WorkQueuePage.WORK_QUEUE_ITEMS_TABLE_XPATH, true, false);
//    }
//
//    /**
//     * Use this step to reset WorkQueue items for the member
//     *
//     * @param memberName: Name of the member for whom WorkQueue items are being reset
//     */
//    @And("^workqueue items are reset for member \"([^\"]*)\"$")
//    public void workqueueItemsAreResetForMember(String memberName) throws Throwable {
//        memberName = WhiteBoard.resolve(owner, memberName);
//        log.warn("memberName=" + memberName);
//        List<Map<String, Object>> wqvList = new WorkqueueviewDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectByMemberName(memberName);
//        String in = "";
//        for (Map<String, Object> wqv : wqvList) {
//            long hscId = (long) wqv.get("hscId");
//            in += hscId + ", ";
//        }
//        in += "0";
//        resetWorkqueueWithHscIds(in);
//    }
//
//    /**
//     * Use this step to reset WorkQueue items for authorization request
//     *
//     * @param hscId :  Id for whom WorkQueue items are being reset
//     */
//    @Given("^workqueue items are reset for authorization request \"([^\"]*)\"$")
//    public void workqueueItemsAreResetForAuthorizationRequest(String hscId) throws Throwable {
//        hscId = WhiteBoard.resolve(owner, hscId);
//        resetWorkqueueWithHscIds(hscId);
//    }
//
//    private void resetWorkqueueWithHscIds(String in) {
//        String sql = "";
//        sql += "\r\ndelete from item_task_history where item_task_id in (Select item_task_id from item_task where queue_item_id in (" + in + "));";
//        sql += "\r\ndelete from item_task where queue_item_id in (" + in + ");";
//        sql += "\r\ndelete from queue_item where queue_item_id in (" + in + ");";
//        MyBatisUtils.execute(MyBatisConnectionFactoryWorkflow.getSqlSessionFactory(), new StringReader(sql), true, true);
//    }
//
//    @And("^workqueue items are reset for owner \"([^\"]*)\"$")
//    public void workqueueItemsAreResetForOwner(String ownerName) throws Throwable {
//        ownerName = WhiteBoard.resolve(owner, ownerName);
//        log.warn("owner=" + ownerName);
//
//        QueueItemDao queueItemDao = new QueueItemDao(MyBatisConnectionFactoryWorkflow.getSqlSessionFactory());
//        List<Map<String, Object>> queueItemList = queueItemDao.selectByOwner(ownerName);
//        if (null != queueItemList && queueItemList.size() > 0) {
//            String in = "";
//            for (Map<String, Object> queueItem : queueItemList) {
//                in += queueItem.get("queue_item_id") + ",";
//            }
//            in += "0";
//            resetWorkqueueWithHscIds(in);
//        }
//
//        String sql = "";
//        sql += "\r\ndelete from item_task_history where item_task_id in (select item_task_id from item_task where owner = '" + ownerName + "');";
//        sql += "\r\ndelete from item_task where owner = '" + ownerName + "';";
//
//        MyBatisUtils.execute(MyBatisConnectionFactoryWorkflow.getSqlSessionFactory(), new StringReader(sql), true, true);
//    }
//
//    @And("^workqueue items are reset for queue \"([^\"]*)\"$")
//    public void workqueueItemsAreResetForQueue(String queueName) throws Throwable {
//        queueName = WhiteBoard.resolve(owner, queueName);
//        log.warn("queueName=" + queueName);
//
//        WorkQueueDao workQueueDao = new WorkQueueDao(MyBatisConnectionFactoryWorkflow.getSqlSessionFactory());
//        List<Map<String, Object>> workQueueList = workQueueDao.selectByWorkQueueName(queueName);
//        if (null == workQueueList || workQueueList.size() <= 0) {
//            // custom queue deleted
//            return;
//        }
//        Assert.assertTrue(null != workQueueList && 1 == workQueueList.size());
//        String queueId = workQueueList.get(0).get("work_queue_id").toString();
//
//        QueueItemDao queueItemDao = new QueueItemDao(MyBatisConnectionFactoryWorkflow.getSqlSessionFactory());
//        List<Map<String, Object>> queueItemList = queueItemDao.selectByQueue(queueId);
//        if (null != queueItemList && queueItemList.size() > 0) {
//            String in = "";
//            for (Map<String, Object> queueItem : queueItemList) {
//                in += queueItem.get("queue_item_id") + ",";
//            }
//            in += "0";
//            resetWorkqueueWithHscIds(in);
//        }
//
//        String sql = "";
//        sql += "\r\ndelete from item_task_history where item_task_id in (select item_task_id from item_task where work_queue_id = '" + queueId + "');";
//        sql += "\r\ndelete from item_task where work_queue_id = '" + queueId + "';";
//
//        MyBatisUtils.execute(MyBatisConnectionFactoryWorkflow.getSqlSessionFactory(), new StringReader(sql), true, true);
//    }
//
//    /**
//     * Use this step to click on the action icon of on Work Queue page for member
//     *
//     * @param memberName: Name of the member whose action icon is to be clicked
//     */
//    @And("^user clicks Action icon on Work Queue page for member \"([^\"]*)\"$")
//    public void userClicksActionIconOnWorkQueuePageForMember(String memberName) throws Throwable {
//        memberName = WhiteBoard.resolve(owner, memberName);
//        TestUtils.demoBreakPoint(scenario, driver(), "Before clicking Action icon for member: " + memberName);
//        obj().WorkQueuePage.clickActionIconByMemberName(memberName);
//        TestUtils.demoBreakPoint(scenario, driver(), "After clicking Action icon for member: " + memberName);
//    }
//
//    @And("^user clicks Action icon on Work Queue page for row \"([^\"]*)\"$")
//    public void userClicksActionIconOnWorkQueuePageForRow(String rowOrVarName) throws Throwable {
//        int row = Integer.parseInt(WhiteBoard.resolve(owner, rowOrVarName));
//        TestUtils.demoBreakPoint(scenario, driver(), "Before clicking Action icon on row: #" + row);
//        obj().WorkQueuePage.clickActionIconByRow(row);
//        TestUtils.demoBreakPoint(scenario, driver(), "After clicking Action icon on row: #" + row);
//    }
//
//    @And("^user clicks Action icon on Work Queue page for Request Number \"([^\"]*)\"$")
//    public void userClicksActionIconOnWorkQueuePageForRequestNumber(String requestNumber) throws Throwable {
//        requestNumber = WhiteBoard.resolve(owner, requestNumber);
//        obj().WorkQueuePage.clickActionIconByReferenceNumber(requestNumber);
//    }
//
//    @When("^user clicks on Add Assignment link on Assignments page$")
//    public void userClicksOnAddAssignmentLinkOnAssignmentsPage() throws Throwable {
//        obj().AssignmentsPage.clickAddAssignment();
//    }
//
//    @Then("^user should see Add Assignment section is displayed$")
//    public void userShouldSeeAddAssignmentSectionIsDisplayed() throws Throwable {
//        TestUtils.waitElementVisible(driver(), AddAssignmentPage.pageTitleAddAssignmentXpath);
//    }
//
//    @Then("^user should see Add Assignment section is not displayed$")
//    public void userShouldSeeAddAssignmentSectionIsNotDisplayed() throws Throwable {
//        TestUtils.wait(3);
//        TestUtils.waitNotElement(driver(), AddAssignmentPage.pageTitleAddAssignmentXpath);
//    }
//
//    @Then("^user should see Edit Assignment section is displayed$")
//    public void userShouldSeeEditAssignmentSectionIsDisplayed() throws Throwable {
//        TestUtils.waitElementVisible(driver(), AddAssignmentPage.pageTitleEditAssignmentXpath);
//    }
//
//    @Then("^user should see Edit Assignment section is not displayed$")
//    public void userShouldSeeEditAssignmentSectionIsNotDisplayed() throws Throwable {
//        TestUtils.wait(3);
//        TestUtils.waitNotElement(driver(), AddAssignmentPage.pageTitleEditAssignmentXpath);
//    }
//
//    @When("^user clicks on Cancel button in Add Assignment section$")
//    public void userClicksOnCancelButtonInAddAssignmentSection() throws Throwable {
//        obj().AddAssignmentPage.clickCancel();
//    }
//
//    @Given("^user adds below assignments$")
//    public void userAddsBelowAssignments(List<Map<String, String>> maps) throws Throwable {
//        userAddsBelowAssignments(maps, true);
//    }
//
//    @And("^Assignments are extracted with prefix \"([^\"]*)\" and key header \"([^\"]*)\"$")
//    public void assignmentsAreExtractedWithPrefixAndKeyHeader(String prefix, String keyHeader) throws Throwable {
//        TestUtils.wait(5);
//        TestUtils.click(driver(), ViewAuthPage.tabAssignments);
//        TestUtils.demoBreakPoint(scenario, driver(), "Extracting Assignments page Assignments records");
//        TestUtils.extractGridToWhiteBoard(driver(), scenario, prefix, keyHeader, AssignmentsPage.ASSIGNMENTS_TABLE_XPATH, false, false);
//    }
//
//    @When("^user selects to show \"([^\"]*)\" rows per page on Work Queue pagination$")
//    public void userSelectsToShowRowsPerPageOnWorkQueuePagination(String option) throws Throwable {
//        obj().WorkQueuePage.showPerPage(option);
//    }
//
//    @When("^user selects page \"([^\"]*)\" on Work Queue pagination$")
//    public void userSelectPageOnWorkQueuePagination(String pageNumber) throws Throwable {
//        obj().WorkQueuePage.selectPage(pageNumber);
//        TestUtils.wait(3);
//    }
//
//
//    @And("^user views assignment for \"([^\"]*)\" and stores object \"([^\"]*)\" from View Assignment page$")
//    public void viewAssignmentObjectIsOnTheAssignmentPage(String row, String objectName) throws Throwable {
//        String rowNumber = WhiteBoard.resolve(owner, row);
//        TestUtils.click(driver(), By.xpath("//*[@id='assignmentsMaintenanceTableID']/tbody/tr[" + rowNumber + "]/td[1]/span"));
//        TestUtils.demoBreakPoint(scenario, driver(), "View Assignment");
//        Assert.assertTrue(obj().CommonPage.verifyHeader("View Assignment"));
//        Assert.assertFalse("input fields are visible", TestUtils.isElementVisible(driver(), ViewAuthPage.assignmentPageIdContent));
//        Map<String, Map<String, String>> outcome = null;
//        Map<String, String> requestStatus = ViewAssignmentCollector.collect(driver());
//        outcome = new LinkedHashMap<>();
//        outcome.put("viewAssignment", requestStatus);
//        WhiteBoard.storeMaps(owner, objectName, Conf.getOutputPath(), outcome);
//    }
//
//    @And("^user verifies \"([^\"]*)\" does not exist in View Assignment$")
//    public void verifiesObjectdoesNotExistInViewAssignments(String label) throws Throwable {
//        Assert.assertFalse(label + "is showing", TestUtils.isElementVisible(driver(), "//*[@id='assignmentPanelIdContent']/div/div[3]/table/tbody//label[text()='" + label + "']"));
//    }
//
//    @Given("^Assignments are edit as below table$")
//    public void assignmentsAreEditAsBelowTable(List<Map<String, String>> maps) throws Throwable {
//        maps = WhiteBoard.resolve(owner, maps);
//        for (Map<String, String> map : maps) {
//            int row = Integer.parseInt(map.get("ROW_NUMBER"));
//
//            String method = WhiteBoard.resolve(owner, map.get("method"));
//            if (StringUtils.isEmpty(method)) {
//                method = "list edit icon";
//            }
//
//            switch (method) {
//                case "list edit icon":
//                    obj().AssignmentsPage.clickEditAssignment(row);
//                    break;
//                case "view edit link":
//                    obj().AssignmentsPage.clickViewAssignment(row);
//                    TestUtils.demoBreakPoint(scenario, driver(), "View Assignment in row " + row);
//                    obj().AddAssignmentPage.clickEditAssignmentLink();
//                    break;
//                default:
//                    Assert.fail("Unknown method: " + method);
//            }
//
//            obj().AddAssignmentPage.selectDescriptor(map);
//            obj().AddAssignmentPage.typeComments(map);
//            obj().AddAssignmentPage.selectStatus(map);
//            obj().AddAssignmentPage.selectOutcome(map);
//            obj().AddAssignmentPage.selectPriority(map);
//            obj().AddAssignmentPage.typeDueDate(map);
//            obj().AddAssignmentPage.inputAssignedTo(map);
//
//            TestUtils.demoBreakPoint(scenario, driver(), "Edit Assignment: " + map.toString());
//
//            Assert.assertTrue(obj().AddAssignmentPage.clickSaveAssignment());
//
//            TestUtils.demoBreakPoint(scenario, driver(), "Edit Assignment completed: " + map.toString());
//        }
//    }
//
//    @When("^user clicks the sort icon on header \"([^\"]*)\" in Assignments page$")
//    public void userClicksTheSortIconOnHeaderInAssignmentsPage(String header) throws Throwable {
//        obj().AssignmentsPage.clickSortIcon(header);
//    }
//
//    @When("^user clicks the sort icon on header \"([^\"]*)\" in Work Queue page$")
//    public void userClicksTheSortIconOnHeaderInWorkQueuePage(String header) throws Throwable {
//        obj().WorkQueuePage.clickSortIcon(header);
//    }
//
//    @When("^user clicks Edit Assignment icon in row \"([^\"]*)\"$")
//    public void userClicksEditAssignmentIconInRow(String row) throws Throwable {
//        obj().AssignmentsPage.clickEditAssignment(Integer.parseInt(row));
//    }
//
//    @When("^user clicks View Assignment icon in row \"([^\"]*)\"$")
//    public void userClicksViewAssignmentIconInRow(String row) throws Throwable {
//        String r = WhiteBoard.resolve(owner, row);
//        obj().AssignmentsPage.clickViewAssignment(Integer.parseInt(r));
//    }
//
//    @And("^\"([^\"]*)\" Assignment History is extracted with prefix \"([^\"]*)\" and key header \"([^\"]*)\"$")
//    public void historyIsExtractedWithPrefixAndKeyHeader(String type, String prefix, String keyHeader) throws Throwable {
//        TestUtils.demoBreakPoint(scenario, driver(), "Assignment History");
//
//        switch (type) {
//            case "Full":
//                TestUtils.extractGridToWhiteBoard(driver(), scenario, prefix, keyHeader, AssignmentsPage.FULL_HISTORY_TABLE_XPATH, false, false);
//                break;
//            case "Top5":
//                String s = driver().findElement(By.xpath(AssignmentsPage.HISTORY_CREATEDBY_XPATH)).getText();
//                WhiteBoard.getInstance().putString(owner, "top5_history_Created_By", s);
//                TestUtils.extractGridToWhiteBoard(driver(), scenario, prefix, keyHeader, AssignmentsPage.TOP5_HISTORY_TABLE_XPATH, false, false);
//                break;
//            default:
//                Assert.fail("Unknown method: " + type);
//        }
//    }
//
//    /**
//     * closes history modals
//     *
//     * @param: none
//     */
//    @And("^user closes History Modal$")
//    public void userClosesHistoryModal() throws Throwable {
//        TestUtils.click(driver(), ViewAuthPage.closeAssignmentHistoryPopupModalId);
//        TestUtils.wait(1);
//    }
//
//    @And("^user selects \"([^\"]*)\" as Outcome on Edit Assignment page$")
//    public void userSelectsAsOutcomeOnEditAssignmentPage(String outcome) throws Throwable {
//        obj().AddAssignmentPage.selectOutcome(outcome);
//    }
//
//    @And("^user selects \"([^\"]*)\" on Statusdropdown on Edit Assignment page$")
//    public void userSelectsOnStatusdropdownOnEditAssignmentPage(String status) throws Throwable {
//        obj().AddAssignmentPage.selectStatus(status);
//    }
//
//    @When("^extract result as \"([^\"]*)\" with key header \"([^\"]*)\"$")
//    public void extractResultAsWithKeyHeader(String prefix, String keyHeader) throws Throwable {
//        TestUtils.extractGridToWhiteBoard(driver(), scenario, prefix, keyHeader, WorkQueuePage.WORK_QUEUE_ITEMS_TABLE_XPATH, true, false);
//    }
//
//    @When("^user searches on WorkQueuePage using below criteria and extract result as \"([^\"]*)\" with key header \"([^\"]*)\"$")
//    public void userSearchesOnWorkQueuePageUsingBelowCriteriaAndExtractResultAsWithKeyHeader(String prefix, String keyHeader, List<Map<String, String>> maps) throws Throwable {
//        userSearchesOnWorkQueuePageUsingBelowCriteria(maps);
//        extractResultAsWithKeyHeader(prefix, keyHeader);
//    }
//
//    /**
//     * to perform search on workqueue using certain criteria
//     *
//     * @param maps
//     */
//    @When("^user searches on WorkQueuePage using below criteria$")
//    public void userSearchesOnWorkQueuePageUsingBelowCriteria(List<Map<String, String>> maps) throws Throwable {
//        workQueuePageSearch(maps, false);
//    }
//
//    /**
//     * to perform search on workqueue using certain criteria
//     *
//     * @param maps
//     */
//    @When("^user searches on WorkQueuePage using below advanced criteria$")
//    public void userSearchesOnWorkQueuePageUsingBelowAdvancedCriteria(List<Map<String, String>> maps) throws Throwable {
//        workQueuePageSearch(maps, true);
//    }
//
//    private void workQueuePageSearch(List<Map<String, String>> maps, boolean advanced) throws Throwable {
//        WebDriver driver = driver();
//        BcbsPageObject obj = obj();
//
//        Retry retryNavigation = new Retry("Retry navigation") {
//            @Override
//            protected void tryOnce() throws Exception {
//                obj.NavigationPage.navigatesToMenuItem("${WorkQueuePageTrace}");
//            }
//
//            @Override
//            protected boolean until() throws Exception {
//                return obj.CommonPage.verifyHeader("Work Queue");
//            }
//        };
//        Assert.assertTrue(retryNavigation.execute());
//
//        if (advanced) {
//            Assert.assertTrue(TestUtils.clickUntil(driver, By.xpath(WorkQueuePage.showAdvancedLinkXpath), new ICondition() {
//                @Override
//                public boolean evaluate() throws Exception {
//                    return TestUtils.isElementVisible(driver, WorkQueuePage.hideAdvancedLinkXpath);
//                }
//            }));
//        }
//
//        Retry retry = new Retry("user searches on WorkQueuePage using below criteria") {
//
//            @Override
//            protected void tryOnce() throws Exception {
//                WorkQueueSearchCriteria searchCriteria = new WorkQueueSearchCriteria(scenario, driver);
//                Map<String, String> map = WhiteBoard.resolve(owner, maps).get(0);
//                searchCriteria.setCriteria(map, WorkQueuePage.clearButton);
//                TestUtils.click(driver, WorkQueuePage.filterButton);
//            }
//
//            @Override
//            protected boolean until() throws Exception {
//                return !TestUtils.isElementVisible(driver, CommonPage.requiredFieldValidationMessage);
//            }
//        };
//
//        Assert.assertTrue(retry.execute());
//        TestUtils.wait(3);
//
//        scenarioLogger.warn(maps.toString());
//        TestUtils.demoBreakPoint(scenario, driver(), "user searches on WorkQueuePage using below criteria");
//    }
//
//    @And("^the authorization request \"([^\"]*)\" is assigned to \"([^\"]*)\"$")
//    public void theAuthorizationRequestIsAssignedTo(String hscID, String assignTo) throws Throwable {
//        theAuthorizationRequestIsAssignedToWithComment(hscID, assignTo, null);
//    }
//
//    @And("^the authorization request \"([^\"]*)\" is assigned to \"([^\"]*)\" with comment \"([^\"]*)\"$")
//    public void theAuthorizationRequestIsAssignedToWithComment(String hscID, String assignTo, String comment) throws Throwable {
//        hscID = WhiteBoard.resolve(owner, hscID);
//        WhiteBoard.getInstance().putString(owner, "hscID", hscID);
//        assignTo = WhiteBoard.resolve(owner, assignTo);
//        Assert.assertFalse(StringUtils.isEmpty(assignTo));
//        WorkQueueDao workQueueDao = new WorkQueueDao(MyBatisConnectionFactoryWorkflow.getSqlSessionFactory());
//        List<Map<String, Object>> queues = workQueueDao.selectByWorkQueueName(assignTo);
//        if (null != queues && queues.size() > 0) {
//            if (1 != queues.size()) {
//                Assert.fail("No such case");
//            }
//            Map<String, Object> queue = queues.get(0);
//            String queueId = "" + queue.get("work_queue_id").toString();
//            WhiteBoard.getInstance().putString(owner, "user_id", "null");
//            WhiteBoard.getInstance().putString(owner, "queue_id", queueId);
//        } else {
//            WhiteBoard.getInstance().putString(owner, "user_id", "'" + assignTo + "'");
//            WhiteBoard.getInstance().putString(owner, "queue_id", "700");
//        }
//        if (null == comment) {
//            WhiteBoard.getInstance().putString(owner, "comment", hscID);
//        } else {
//            WhiteBoard.getInstance().putString(owner, "comment", comment);
//        }
//
//        resetWorkqueueWithHscIds(hscID);
//
//        QueryShared myBatisShared = new QueryShared(scenario);
//        String sqlFile = "src/test/resources/features/demo/Manager Dashboard Capability/submit_a_case.sql";
//        myBatisShared.isExecutedInDatabase(sqlFile, "${wfdb_MyBatisConnectionFactory}");
//    }
//
//    /**
//     * use this step to send authorization request to required work queue
//     *
//     * @param hscID:     Id for whom authorizationRequest is sent
//     * @param queueName: required queue to whick authorization request is sent
//     */
//    @And("^the authorization request \"([^\"]*)\" is sent to Work Queue \"([^\"]*)\"$")
//    public void theAuthorizationRequestIsSentToWorkQueue(String hscID, String queueName) throws Throwable {
//        theAuthorizationRequestIsAssignedTo(hscID, queueName);
//
////        hscID = WhiteBoard.resolve(owner, hscID);
////        WhiteBoard.getInstance().putString(owner, "hscID", hscID);
////
////        Map<String, Object> hsc = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectById(Long.parseLong(hscID)).get(0);
////        long memberID = (long) hsc.get("mbr_id");
////
////        Map<String, Object> mbr = new MbrDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectByMemberId(memberID).get(0);
////        String memberBirthDate = mbr.get("bth_dt").toString();
////
////        List<Map<String, Object>> result = new QueueItemDao(MyBatisConnectionFactoryWorkflow.getSqlSessionFactory()).selectByQueueItemId(hscID);
////        if (null != result && result.size() > 0) {
////            //Already in WorkQueue
////            return;
////        }
////
////        queueName = WhiteBoard.resolve(owner, queueName);
////        String stringMap = WhiteBoard.getInstance().getString(owner, queueName.replace(' ', '_'));
////        Properties queueParams = DataTableUtils.asProperties(stringMap);
////        WhiteBoard.register(owner, queueParams);
////
////        MyBatisShared myBatisShared = new MyBatisShared(scenario, driver());
////        String sqlFile = "src/main/resources/features/Regression Suite/UI Automation Suite/Archive/workflow/submit_a_case.sql";
////        myBatisShared.isExecutedInDatabase(sqlFile, "${wfdb_MyBatisConnectionFactory}");
////
////        WhiteBoard.getInstance().putString(owner, "hscID", hscID);
////        WhiteBoard.getInstance().putString(owner, "memberID", memberID + "");
////        WhiteBoard.getInstance().putString(owner, "memberBirthDate", memberBirthDate);
////        WhiteBoard.getInstance().putString(owner, "marker", WhiteBoard.resolve(owner, "${random5}"));
////
////        Retry retry = new Retry("^the authorization request " + hscID + " is sent to Work Queue " + queueName) {
////
////            @Override
////            protected void tryOnce() throws Exception {
////                serviceIsCalledWithRequestAndResponse("flow_process_start", "${dynamicAuthStepperFlow}", "process${marker}");
////                isExtractedFromWithQuery("pid", "${process${marker}}", "jsonpath $.processInstanceId");
////                serviceIsCalledWithRequestAndResponse("flow_process_signal", "${stepperContinue35}", "stepperContinue35Response${marker}");
////            }
////
////            @Override
////            protected boolean until() throws Exception {
////                String hscID = WhiteBoard.getInstance().getString(owner, "hscID");
////                List<Map<String, Object>> result = new QueueItemDao(MyBatisConnectionFactoryWorkflow.getSqlSessionFactory()).selectByQueueItemId(hscID);
////                if (null != result && result.size() > 0) {
////                    return true;
////                } else {
////                    scenarioLogger.warn("JBpm success but the authorization is not sent to WorkQueue.");
////                    return false;
////                }
////            }
////
////            @Override
////            protected long getSleepMillis() {
////                return 5 * 1000;
////            }
////
////        };
////        Assert.assertTrue(retry.execute());
//    }
//
//    /**
//     * Use this step to enter sample text in
//     * notes text area on utilization management page
//     *
//     * @param: None
//     */
//
//    @Then("^user should be able to type in new note textbox$")
//    public void userShouldBeAbleToTypeInTextBox() throws Throwable {
//        TestUtils.demoBreakPoint(scenario, driver(), "Text area filled with desired comment");
//        obj().CaseSummaryNotesSection.typeNotesArea();
//    }
//
//
//    /**
//     * Use this step to enter sample text in
//     * notes text area on utilization management page
//     *
//     * @param: None
//     */
//
//    @And("^user adds a new note with detail - \"([^\"]*)\"$")
//    public void userAddsAWithDetail(String noteComment) throws Throwable {
//        obj().CaseSummaryNotesSection.addDetailToNote(noteComment);
//        TestUtils.demoBreakPoint(scenario, driver(), "Text area filled with desired comment");
//    }
//
//    /**
//     * Use this step to cancel the note by clicking on
//     * cancel button in notes section on utilization management page
//     *
//     * @param: None
//     */
//
//    @Then("^user clicks on cancel button$")
//    public void userClicksOnCancel() throws Throwable {
//        TestUtils.demoBreakPoint(scenario, driver(), "Cancel button is clickable");
//        obj().CaseSummaryNotesSection.clickCancelButton();
//    }
//
//
//    /**
//     * Use this step to save the note by clicking on
//     * save button in notes section on utilization management page
//     *
//     * @param: None
//     */
//    @Then("^user saves the note$")
//    public void userSavesTheNote() throws Throwable {
//        TestUtils.demoBreakPoint(scenario, driver(), "User saves note");
//        obj().CaseSummaryNotesSection.clickSaveButton();
//    }
//
//
//    /**
//     * Use this step to check save button in notes section on utilization management page
//     * is visible and clickable
//     *
//     * @param: None
//     */
//    @And("^Save button is clickable$")
//    public void buttonIsClickable() throws Throwable {
//        TestUtils.demoBreakPoint(scenario, driver(), "Save button is clickable");
//        obj().CaseSummaryNotesSection.selectSaveButton();
//    }
//
//
//    /**
//     * Use this step to check cancel button in notes section on utilization management page
//     * is visible and clickable
//     *
//     * @param: None
//     */
//    @And("^Cancel button is clickable$")
//    public void buttonIsAlsoClickable() throws Throwable {
//        TestUtils.demoBreakPoint(scenario, driver(), "Cancel button is clickable");
//        obj().CaseSummaryNotesSection.selectCancelButton();
//    }
//
//
//    /**
//     * Use this ste to check success popup message is displayed for
//     * saving a note in notes section on utilization management page
//     *
//     * @param: None
//     */
//    @And("^success popup message is displayed$")
//    public void successPopupMessageIsDisplayed() throws Throwable {
//        TestUtils.demoBreakPoint(scenario, driver(), "Success popup displayed after note is saved");
//        obj().CaseSummaryNotesSection.successPopUpDisplayed();
//
//    }
//
//    /**
//     * checks if note panel is updated to show new notes
//     *
//     * @param: none
//     */
//    @And("^note panel history is updated to show new note$")
//    public void notePanelHistoryIsUpdatedToShowNewNote() throws Throwable {
//        TestUtils.demoBreakPoint(scenario, driver(), "Note side panel updated with new note");
//        obj().CaseSummaryNotesSection.clickOnExistingNote();
//        obj().CaseSummaryNotesSection.existingNoteVisible();
//    }
//
//    /**
//     * use this step to add AuthorName and dateTime to note
//     *
//     * @param authorName: Name of the author of the note
//     */
//    @And("^Author \"([^\"]*)\" and DateTime added to note$")
//    public void authorAndDateTimeAddedToNote(String authorName) throws Throwable {
//        TestUtils.demoBreakPoint(scenario, driver(), "Timestamp added to note");
//        authorName = WhiteBoard.resolve(owner, authorName);
//        obj().CaseSummaryNotesSection.authorAndDateTimetoNote(authorName);
//    }
//
//    /**
//     * Use this ste to check cancel popup is displayed for
//     * cancelling a note in notes section on utilization management page
//     *
//     * @param: None
//     */
//    @And("^cancel pop up is displayed$")
//    public void cancelPopUpIsDisplayed() throws Throwable {
//        TestUtils.demoBreakPoint(scenario, driver(), "Cancel popup displayed");
//        obj().CaseSummaryNotesSection.cancelPopUpDisplayed();
//    }
//
//    /**
//     * clicks on cancel button of cancel popup
//     *
//     * @param: none
//     */
//    @And("^user clicks on X button on top-right of pop up$")
//    public void userClicksOnXButtonOnTopRightOfPopUp() throws Throwable {
//        TestUtils.demoBreakPoint(scenario, driver(), "User clicks on X button in cancel popup");
//        obj().CaseSummaryNotesSection.clickXbuttonTopRightCancelPopUp();
//    }
//
//    @Then("^text in notesArea is still displayed$")
//    public void textInNotesAreaIsStillDisplayed() throws Throwable {
//        TestUtils.demoBreakPoint(scenario, driver(), "Text still displayed in text area and still editable");
//        obj().CaseSummaryNotesSection.textInNoteAreaStillDisplayed();
//    }
//
//    /**
//     * clicks on cancel button of cancel popup
//     *
//     * @param: none
//     */
//    @And("^user clicks on Cancel button of pop up$")
//    public void userClicksOnCancelButtonOfPopUp() throws Throwable {
//        TestUtils.demoBreakPoint(scenario, driver(), "User clicks on cancel button in cancel popup");
//        obj().CaseSummaryNotesSection.clickCancelbuttonCancelPopUp();
//    }
//
//    /**
//     * clicks on continue button of cancel popup
//     *
//     * @param: none
//     */
//    @And("^user clicks on Continue button of the pop up$")
//    public void userClicksOnContinueButtonOfThePopUp() throws Throwable {
//        TestUtils.demoBreakPoint(scenario, driver(), "User clicks on continue button in cancel popup");
//        obj().CaseSummaryNotesSection.clickContinuebuttonCancelPopUp();
//    }
//
//    //checks that there is no text in Notes Area
//    @Then("^text in notesArea is cleared$")
//    public void textInNotesAreaIsCleared() throws Throwable {
//        TestUtils.demoBreakPoint(scenario, driver(), "Note text area is empty");
//        obj().CaseSummaryNotesSection.textInNoteAreaIsEmpty();
//    }
//
//    //verify that notes area is no longer visible
//    @Then("^verify note area is no longer visible$")
//    public void getStateOfNoteArea() throws Throwable {
//        TestUtils.demoBreakPoint(scenario, driver(), "Note text area no longer in edit mode");
//        Assert.assertFalse(obj().CaseSummaryNotesSection.getStateOfNoteArea());
//    }
//
//    //checks that user is able to see the note
//    @Then("^user should be able to see the note$")
//    public void userShouldBeAbleToSeeTheNote() throws Throwable {
//        TestUtils.demoBreakPoint(scenario, driver(), "User can view note");
//        obj().CaseSummaryNotesSection.existingNoteVisible();
//    }
//
//    //checks that user is not able to delete note
//    @And("^user should not be able to delete note$")
//    public void userShouldNotBeAbleToDeleteNote() throws Throwable {
//        TestUtils.demoBreakPoint(scenario, driver(), "User cannot delete note");
//        obj().CaseSummaryNotesSection.userNotAbletoDeleteNote();
//    }
//
//    //checks that user is not able to edit note
//    @And("^user should not be able to edit note$")
//    public void userShouldNotBeAbleToEditNote() throws Throwable {
//        TestUtils.demoBreakPoint(scenario, driver(), "Note text area visible to edit note");
//        obj().CaseSummaryNotesSection.userNotAbletoEditNote();
//    }
//
//    //clicks on existing note
//    @And("^user clicks on Existing Note$")
//    public void userClicksOnExistingNote() throws Throwable {
//        TestUtils.demoBreakPoint(scenario, driver(), "User clicks on existing note");
//        obj().CaseSummaryNotesSection.clickOnExistingNote();
//    }
//
//    //checks if existing note is visible
//    @Then("^existing note should be visible$")
//    public void existingNoteShouldBeVisible() throws Throwable {
//        TestUtils.demoBreakPoint(scenario, driver(), "Existing note is displayed");
//        obj().CaseSummaryNotesSection.existingNoteVisible();
//    }
//
//    //clicks on New Note
//    @And("^user clicks on New Note$")
//    public void userClicksOnNewNote() throws Throwable {
//        TestUtils.demoBreakPoint(scenario, driver(), "Clicks +New Note");
//        obj().CaseSummaryNotesSection.userClicksOnNewNote();
//    }
//
//    //checks if noteArea is visible
//    @Then("^New Note Text area should be visible$")
//    public void newNoteTextAreaShouldBeVisible() throws Throwable {
//        TestUtils.demoBreakPoint(scenario, driver(), "New note text area should be displayed");
//        obj().CaseSummaryNotesSection.notesAreaVisible();
//    }
//
//    //Checks if existing note added by UM nurse is visible.
//    @And("^user should be able to view note with detail Added by UM nurse$")
//    public void userShouldBeAbleToViewNoteWithDetailAddedByUMNurse() throws Throwable {
//        TestUtils.demoBreakPoint(scenario, driver(), "Existing note visible");
//        obj().CaseSummaryNotesSection.clickOnExistingNote();
//        obj().CaseSummaryNotesSection.existingNoteVisible();
//    }
//
//    /**
//     * Temporary function - searches user member for work queue and clicks enter rather than clicking the filter button
//     *
//     * @param value
//     * @param locatorName
//     * @param pageName
//     * @throws Throwable
//     */
//    @When("^user searches \"([^\"]*)\" in \"([^\"]*)\" on \"([^\"]*)\"$")
//    public void searchesAssignedTo(String value, String locatorName, String pageName) throws Throwable {
//        By by = CommonPageObject.pageObjectUtils.getLocator(pageName, locatorName);
//        TestUtils.input(driver(), by, WhiteBoard.resolve(owner, value));
//        TestUtils.wait(2);
//        TestUtils.demoBreakPoint(scenario, driver(), "Search work queue by assigned to option");
//        obj().WorkQueuePage.userSearchForAssignedByForWorkQueue();
//        TestUtils.wait(2);
//    }
//
//
//    /**
//     * Checks the database for the notes table and verifies note saved correctly
//     *
//     * @param queryExpression -- this is the hscID
//     */
//    @And("^note should be stored in the database table named note \"([^\"]*)\" with text \"([^\"]*)\" and with user \"([^\"]*)\"$")
//    public void verifyNoteAddedToDB(String queryExpression, String noteText, String createUser) throws Throwable {
//        TestUtils.demoBreakPoint(scenario, driver(), "Note text and user timestamp verified against database");
//        createUser = WhiteBoard.resolve(owner, createUser);
//        queryExpression = WhiteBoard.resolve(owner, queryExpression);
//        log.warn("queryExpression=" + queryExpression);
//        List<Map<String, Object>> selectNoteTxtLobj = new NoteDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectNoteTxtLobj(queryExpression);
//        List<Object> list = new ArrayList<Object>();
//        for (Map<String, Object> i : selectNoteTxtLobj) {
//            list.addAll(i.values());
//        }
//        TestUtils.demoBreakPoint(scenario, driver(), "Getting username timestamp");
//        Assert.assertEquals(noteText, list.get(0));
//        Assert.assertEquals(createUser, list.get(1));
//    }
//
//    /**
//     * checks autopopulated fields provided in parameters
//     *
//     * @param renderedBy
//     * @param PM
//     * @param AM
//     * @param time
//     * @param date
//     */
//    @Then("^user verifies autopopulate logic for fields \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
//    public void userVerifiesAutoPopulate(String renderedBy, String date, String time, String AM, String PM, String userFullName, String userID) throws Throwable {
//        userFullName = WhiteBoard.resolve(owner, userFullName);
//        userID = WhiteBoard.resolve(owner, userID);
//        TestUtils.wait(1);
//        String renderbytext = driver().findElement(obj().CaseSummaryMakeDecisionSection.getDropdownElement(renderedBy)).getAttribute("value");
//        String dateText = driver().findElement(obj().CaseSummaryMakeDecisionSection.getDropdownElement(date)).getAttribute("value");
//        String timetext = driver().findElement(obj().CaseSummaryMakeDecisionSection.getDropdownElement(time)).getAttribute("value");
//        Assert.assertTrue(obj().CaseSummaryMakeDecisionSection.verifyEnteredBy(userFullName + " (" + userID + ")"));
//        Assert.assertFalse("renderbytext is empty", StringUtils.isEmpty(renderbytext));
//        Assert.assertEquals(userFullName, renderbytext);
//        Assert.assertEquals(userFullName + " (" + userID + ")", TestUtils.text(driver(), ViewAuthPage.decisionEnteredBy));
//        Assert.assertFalse("dateText is empty", StringUtils.isEmpty(dateText));
//        if (!obj().CaseSummaryMakeDecisionSection.dateTimeValidator(dateText, "mm-dd-yyyy")) {
//            TestUtils.click(driver(), ViewAuthPage.decisionForm);
//            Assert.assertTrue("Incorrect Date Format", TestUtils.isElementVisible(driver(), ViewAuthPage.decisionTimeErr));
//        }
//        Assert.assertFalse("Timetext is empty", StringUtils.isEmpty(timetext));
//        if (obj().CaseSummaryMakeDecisionSection.dateTimeValidator(timetext, "HH:mm")) {
//            TestUtils.click(driver(), By.xpath("//*[@id='decisionsForm']/form/table/tbody"));
//            Assert.assertTrue("Invalid Time Format", TestUtils.isElementVisible(driver(), ViewAuthPage.decisionDateErr));
//        }
//        Boolean radiobtnAM = driver().findElement(obj().CaseSummaryMakeDecisionSection.getDropdownElement(AM)).isSelected();
//        Boolean radiobtnPM = driver().findElement(obj().CaseSummaryMakeDecisionSection.getDropdownElement(PM)).isSelected();
//        if ((radiobtnAM || radiobtnPM) && renderbytext != "" && dateText != "" && timetext != "") {
//            assert (true);
//        } else {
//            assert (false);
//        }
//        TestUtils.demoBreakPoint(scenario, driver(), "Verifying autopopulate fields");
//    }
//
//
//    /**
//     * Fills out the following fields based on the parameters being passed in
//     *
//     * @param decisionOutcome
//     * @param decisionType
//     * @param decisionReason
//     * @param renderedBy
//     * @param comment
//     * @param amPM
//     * @param customRequestReason
//     * @param time
//     * @param date
//     */
//    @Then("^user makes and \"([^\"]*)\" a decision \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
//    public void userMakesDecision(String saveOrCancel, String decisionOutcome, String decisionType, String customRequestReason, String decisionReason, String renderedBy, String date, String time, String amPM, String resourceUsed, String resourceComment, String comment) throws Throwable {
//        TestUtils.select(driver(), obj().CaseSummaryMakeDecisionSection.getDropdownElement("Decision Outcome"), decisionOutcome);
//        TestUtils.select(driver(), obj().CaseSummaryMakeDecisionSection.getDropdownElement("Decision Subtype"), decisionType);
//        try {
//            TestUtils.select(driver(), obj().CaseSummaryMakeDecisionSection.getDropdownElement("Decision Reason"), decisionReason);
//        } catch (Exception e) {
//        }
//        if (obj().CaseSummaryMakeDecisionSection.checkDropdownexists("Custom Request Reason")) {
//            TestUtils.wait(1);
//            TestUtils.select(driver(), obj().CaseSummaryMakeDecisionSection.getDropdownElement("Custom Request Reason"), customRequestReason);
//        }
//        TestUtils.input(driver(), ViewAuthPage.decisionRenderedBy, renderedBy);
//        obj().CaseSummaryMakeDecisionSection.inputDate(date);
//        obj().CaseSummaryMakeDecisionSection.inputTime(time, amPM);
//        obj().CaseSummaryMakeDecisionSection.checkFutureTime(time, amPM);
//        obj().CaseSummaryMakeDecisionSection.enterResourcesUsed(resourceUsed);
//        TestUtils.click(driver(), ViewAuthPage.resourceCommentText);
//        TestUtils.input(driver(), ViewAuthPage.resourceCommentText, resourceComment);
//        TestUtils.click(driver(), ViewAuthPage.claimNote);
//        TestUtils.input(driver(), ViewAuthPage.claimNote, comment);
//        TestUtils.demoBreakPoint(scenario, driver(), "Make Decision");
//        obj().CaseSummaryMakeDecisionSection.saveOrCancelDecision(saveOrCancel);
//        TestUtils.demoBreakPoint(scenario, driver(), "Make Decision Completed");
//    }
//
//    /**
//     * Checks the status of the make decision button based on which User is currently logged in
//     *
//     * @param userLoggedIn
//     */
//
//    @And("^user wants to click make decision button \"([^\"]*)\"$")
//    public void getMakeDecisionButtonStatus(String userLoggedIn) throws Throwable {
//        switch (userLoggedIn) {
//            case "a bcbs internal operations user":
//                Assert.assertFalse(obj().CaseSummaryMakeDecisionSection.getMakeDecisionButtonStatus());
//                break;
//            default:
//                Assert.assertTrue(obj().CaseSummaryMakeDecisionSection.getMakeDecisionButtonStatus());
//        }
//    }
//
//
//    /**
//     * This runs a query on the database to verify the options were stored correctly based on value being passed from user
//     *
//     * @param queryExpression
//     * @param decisionOutcomeText
//     * @param decisionSubTypeText
//     * @param decisionReasonText
//     * @param renderedBy
//     * @param comment
//     */
//    @Then("^decision should be stored in the database table named hsc_srvc_decn under \"([^\"]*)\" with \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" by \"([^\"]*)\"$")
//    public void verifyDecisionAddedToDB(String queryExpression, String decisionOutcomeText, String decisionSubTypeText, String customReasonRequestText, String decisionReasonText, String renderedBy, String date, String time, String amPm, String expectedResourceUsed, String expectedResourceComment, String comment, String enteredBy) throws Throwable {
//        queryExpression = WhiteBoard.resolve(owner, queryExpression);
//        Integer numberOfServices = driver().findElements(By.xpath("//*[@id='servicesTableID']/tbody/tr")).size();
//        String decnSeqNbr = new MakeDecisionsDao(MyBatisConnectionFactory.getSqlSessionFactory()).getDecisionSequenceNumber(queryExpression);
//        List<Map<String, Object>> serviceDecisions = new MakeDecisionsDao(MyBatisConnectionFactory.getSqlSessionFactory()).getServiceDecisions(queryExpression, decnSeqNbr);
//        for (Integer iterateRows = 0; iterateRows < numberOfServices; iterateRows++) {
//            Assert.assertEquals(decisionOutcomeText, new MakeDecisionsDao(MyBatisConnectionFactory.getSqlSessionFactory()).getOutcomeDescription(serviceDecisions.get(iterateRows).get("decn_otcome_typ_id")));
//            Assert.assertEquals(decisionSubTypeText, new MakeDecisionsDao(MyBatisConnectionFactory.getSqlSessionFactory()).getSubTypeDescription(serviceDecisions.get(iterateRows).get("decn_sub_typ_id")));
//            Assert.assertEquals(decisionReasonText, new MakeDecisionsDao(MyBatisConnectionFactory.getSqlSessionFactory()).getReasonDescription(serviceDecisions.get(iterateRows).get("decn_rsn_typ_id")));
//            Assert.assertEquals(comment, serviceDecisions.get(iterateRows).get("clm_note_txt"));
//            Assert.assertEquals(renderedBy, serviceDecisions.get(iterateRows).get("decn_made_by_user_id"));
//            Assert.assertEquals(customReasonRequestText, new MakeDecisionsDao(MyBatisConnectionFactory.getSqlSessionFactory()).getDecisionCustomRequestReasonDescription(serviceDecisions.get(iterateRows).get("cstm_rgmn_rqst_rsn_typ_id")));
//            Assert.assertTrue(obj().CaseSummaryMakeDecisionSection.verifyExpectedResourcesUsed(expectedResourceUsed, queryExpression));
//            Assert.assertEquals(expectedResourceComment, serviceDecisions.get(iterateRows).get("decn_src_cmmt_txt"));
//            Assert.assertEquals(enteredBy, serviceDecisions.get(iterateRows).get("decn_entr_by_user_id"));
//        }
//    }
//
//
//    //Clicks on the Work Queue tab
//    @When("^user clicks Work Queue tab$")
//    public void clickWorkQueue() throws Throwable {
//        obj().CaseSummaryMakeDecisionSection.clickWorkQueueTab();
//    }
//
//    //Clicks on make decision button
//    @Then("^user clicks Make Decision button$")
//    public void clickMakeDecisionButton() throws Throwable {
//        TestUtils.wait(2);
//        obj().CaseSummaryMakeDecisionSection.acknowledgePopUp();
//        TestUtils.wait(2);
//        obj().CaseSummaryMakeDecisionSection.clickMakeDecisionButton();
//    }
//
//    /**
//     * Selects Decision Outcome and Decision Subtype based on values being passed in
//     *
//     * @param maps
//     */
//    @Given("^user adds decision outcome and decision subtype decisions$")
//    public void userAddsBelowDecisions(List<Map<String, String>> maps) throws Throwable {
//        maps = WhiteBoard.resolve(owner, maps);
//        for (Map<String, String> map : maps) {
//            TestUtils.wait(2);
//            TestUtils.select(driver(), obj().CaseSummaryMakeDecisionSection.getDropdownElement("Decision Outcome"), map.get("Decision Outcome"));
//            TestUtils.wait(2);
//            TestUtils.select(driver(), obj().CaseSummaryMakeDecisionSection.getDropdownElement("Decision Subtype"), map.get("Decision Subtype"));
//        }
//        TestUtils.wait(2);
//    }
//
//    /**
//     * checks if the validation message is displayed on mandatory fields
//     *
//     * @param elementsToValidate: these are the elements to be validated
//     */
//    @Given("^user verifies the validation message displayed below mandatory fields$")
//    public void userVerifiesValidationMessages(List<String> elementsToValidate) throws Throwable {
//        obj().CaseSummaryMakeDecisionSection.clickDecisionSaveButton();
//        TestUtils.wait(2);
//        TestUtils.demoBreakPoint(scenario, driver(), "Validating asterisk and required message for elements");
//        obj().CaseSummaryMakeDecisionSection.checkValidationMessages(elementsToValidate);
//    }
//
//    /**
//     * verify if the decision status field is updated on changing the decision
//     *
//     * @param decisionStatus: it is the previous value of the decisionStatuis
//     */
//    @Then("^user verifies updated decision status with \"([^\"]*)\"$")
//    public void userVerifiesUpdatedDecisionStatusWith(String decisionStatus) throws Throwable {
//        obj().CaseSummaryMakeDecisionSection.verifyUpdatedDecisionStatus(decisionStatus);
//    }
//
//    @Then("^user verifies expected Resources Used list$")
//    public void verifiyResourceUsedList(List<String> expectedResourceOptions) throws Throwable {
//        Assert.assertTrue("Resource(s) Used options do not match", obj().CaseSummaryMakeDecisionSection.compareResourceUserOptionList(expectedResourceOptions));
//    }
//
//    @Given("^workqueue decisions are reset for authorization request \"([^\"]*)\"$")
//    public void workqueueDecisionsAreResetForAuthorizationRequest(String hscId) throws Throwable {
//        hscId = WhiteBoard.resolve(owner, hscId);
//        resetWorkQueueDecisionHscIds(hscId);
//    }
//
//    private void resetWorkQueueDecisionHscIds(String in) {
//        String mbmSql = "";
//        mbmSql += "\r\ndelete from hsc_srvc_decn_src where hsc_id in (" + in + ");";
//        mbmSql += "\r\ndelete from hsc_srvc_decn where hsc_id in (" + in + ");";
//        MyBatisUtils.execute(MyBatisConnectionFactory.getSqlSessionFactory(), new StringReader(mbmSql), true, true);
//    }
//
//    @Given("^workqueue authorization is set to open for \"([^\"]*)\"$")
//    public void workqueueStatusAuthorizationIsSetToOpen(String hscId) throws Throwable {
//        hscId = WhiteBoard.resolve(owner, hscId);
//        setStatusForAuthorizationToOpen(hscId);
//    }
//
//    private void setStatusForAuthorizationToOpen(String in) {
//        String mbmSql = "";
//        mbmSql += "\r\nUPDATE hsc SET hsc_sts_typ_id = '1' WHERE hsc_id in (" + in + ");";
//        MyBatisUtils.execute(MyBatisConnectionFactory.getSqlSessionFactory(), new StringReader(mbmSql), true, true);
//    }
//
//    /**
//     * verify Service Fields in the medicalBenefitServicesTable
//     *
//     * @param queryExpression: {@Link atdd.common.QueryExpression}
//     */
//    @Then("^user verifies Service Requests for all rows in service table for \"([^\"]*)\"\\.$")
//    public void userVerifiesServiceRequestsForAllRowsInServiceTableFor(String queryExpression) throws Throwable {
//        queryExpression = WhiteBoard.resolve(owner, queryExpression);
//        log.warn("queryExpression=" + queryExpression);
//        Integer numberOfServices = driver().findElements(ViewAuthPage.medicalBenefitServicesTableRows).size();
//        if (!StringUtils.isEmpty(TestUtils.text(driver(), ViewAuthPage.medicalBenefitServicesTableDecisionStatus))) {
//            obj().CaseSummaryMakeDecisionSection.verifyServiceFields(queryExpression, numberOfServices);
//        } else {
//            clickMakeDecisionButton();
//            TestUtils.wait(2);
//            TestUtils.select(driver(), obj().CaseSummaryMakeDecisionSection.getDropdownElement("Decision Outcome"), "Denied/Not Covered");
//            TestUtils.select(driver(), obj().CaseSummaryMakeDecisionSection.getDropdownElement("Decision Subtype"), "Clinical");
//            if (obj().CaseSummaryMakeDecisionSection.checkDropdownexists("Custom Request Reason")) {
//                TestUtils.wait(1);
//                TestUtils.select(driver(), obj().CaseSummaryMakeDecisionSection.getDropdownElement("Custom Request Reason"), "Non-Formulary");
//            }
//            TestUtils.input(driver(), ViewAuthPage.decisionRenderedBy, "mbmauto1");
//            obj().CaseSummaryMakeDecisionSection.inputDate("Today");
//            obj().CaseSummaryMakeDecisionSection.inputTime("12:00", "AM");
//            obj().CaseSummaryMakeDecisionSection.enterResourcesUsed("Medicaid Approval;Medicaid Denial;Medicare Approval;Medicare Denial");
//            TestUtils.click(driver(), ViewAuthPage.resourceCommentText);
//            TestUtils.input(driver(), ViewAuthPage.resourceCommentText, " resourceComment");
//            TestUtils.click(driver(), ViewAuthPage.claimNote);
//            TestUtils.input(driver(), ViewAuthPage.claimNote, "ClaimType comment");
//            TestUtils.wait(1);
//            TestUtils.select(driver(), obj().CaseSummaryMakeDecisionSection.getDropdownElement("Decision Reason 2"), "D3 Deny, Other");
//            obj().CaseSummaryMakeDecisionSection.saveOrCancelDecision("Save");
//            obj().CaseSummaryMakeDecisionSection.verifyServiceFields(queryExpression, numberOfServices);
//        }
//    }
//
//
//    @And("^user clicks on Edit Assignment link on Assignments page$")
//    public void userClicksOnEditAssignmentLinkOnAssignmentsPage() throws Throwable {
//        obj().AddAssignmentPage.clickEditAssignmentLink();
//    }
//
//    @Then("^user clicks on check box on Work Queue page for row \"([^\"]*)\"$")
//    public void userClicksOnCheckBoxOnWorkQueuePageForRow(String row) throws Throwable {
//        obj().WorkQueuePage.ClicksOnCheckBoxOnWorkQueuePageForRow(row);
//    }
//
//    @Given("^user adds below assignment without saving$")
//    public void userAddsBelowAssignmentsWithoutSaving(List<Map<String, String>> maps) throws Throwable {
//        userAddsBelowAssignments(maps, false);
//    }
//
//    @Given("^authorization request \"([^\"]*)\" is \"([^\"]*)\" with \"([^\"]*)\" through View Auth page if \"([^\"]*)\"$")
//    public void authorizationRequestInQueueIsCanceledThroughViewAuthPageIf(String requestNumber, String op, String options, String ifExpression) throws Throwable {
//        if (WhiteBoard.evaluate(owner, ifExpression)) {
//            authorizationRequestInQueueIsCanceledWithReasonThroughViewAuthPage(requestNumber, op, options);
//        }
//    }
//
//    @Given("^authorization request \"([^\"]*)\" is \"([^\"]*)\" with \"([^\"]*)\" through View Auth page$")
//    public void authorizationRequestInQueueIsCanceledWithReasonThroughViewAuthPage(String requestNumber, String op, String options) throws Throwable {
//        Login.login(scenario, ExcelLib.completeProfile(owner, null));
//
//        requestNumber = WhiteBoard.resolve(owner, requestNumber);
//        AuthorizationRequest ar = new AuthorizationRequest(scenario, driver());
//        ar.searchSubmitted(DataTableUtils.asMap("Request Number=" + requestNumber));
//
//        TestUtils.click(driver(), PriorAuthorizationSearchSubmittedPage.viewAuthLink(requestNumber));
//        Assert.assertTrue(ViewAuthPage.waitForViewAuthPageLoaded(driver()));
//
//        options = WhiteBoard.resolve(owner, options);
//        Map<String, String> optionMap = DataTableUtils.asMap(options);
//        switch (op) {
//            case "canceled":
//                String reason = optionMap.get("Reason");
//                obj().ViewAuthPage.cancelAuthorizationRequest(reason); //For example: "Reason=Case Opened on Wrong Member"
//                break;
//            default:
//                throw new RuntimeException("TODO: other operations");
//        }
//
//    }
//
//    @Then("^user verifies View Auth page is having only the links \"([^\"]*)\"$")
//    public void userVerifiesViewAuthPageIsHavingOnlyTheLinks(String links) throws Throwable {
//        TestUtils.demoBreakPoint(scenario, driver(), "Verify links");
//        List<String> expectedLinks = new ArrayList<>();
//        if (!StringUtils.isEmpty(links)) {
//            expectedLinks = Arrays.asList(links.split("\\s*,\\s*"));
//        }
//        List<String> actualLinks = obj().ViewAuthPage.getLinks();
//
//        Assert.assertEquals(expectedLinks, actualLinks);
//    }
//
//    @Then("^user searches work queue with below entries$")
//    public void user_searches_work_queue_with_below_entries(List<Map<String, String>> maps) throws Throwable {
//        maps = WhiteBoard.resolve(owner, maps);
//        obj().WorkQueueMaintenancePage.clickClearButton();
//        SearchCriteria searchCriteria = new SearchCriteria(scenario, driver());
//        searchCriteria.setCriteria(maps.get(0), WorkQueueMaintenancePage.filterTableXpath);
//        obj().WorkQueueMaintenancePage.clickSearchButton();
//    }
//
//    @And("^user should be landing on View Auth page$")
//    public void userShouldBeLandingOnViewAuthPage() throws Throwable {
//        Assert.assertTrue(ViewAuthPage.waitForViewAuthPageLoaded(driver()));
//    }
//    //Ryan Code End
//
//    private void userAddsBelowAssignments(List<Map<String, String>> maps, boolean saving) throws Throwable {
//        if (!saving) {
//            Assert.assertTrue(1 == maps.size());
//        }
//        maps = WhiteBoard.resolve(owner, maps);
//        for (Map<String, String> map : maps) {
//            obj().AssignmentsPage.clickAddAssignment();
//            obj().AddAssignmentPage.selectAssignmentType(map);
//            obj().AddAssignmentPage.selectDescriptor(map);
//            obj().AddAssignmentPage.typeComments(map);
//            obj().AddAssignmentPage.selectPriority(map);
//            obj().AddAssignmentPage.typeDueDate(map);
//            obj().AddAssignmentPage.inputAssignedTo(map);
//
//            TestUtils.demoBreakPoint(scenario, driver(), "Add Assignment");
//
//            if (saving) {
//                Assert.assertTrue(obj().AddAssignmentPage.clickAddAssignment());
//
//                TestUtils.demoBreakPoint(scenario, driver(), "Add Assignment completed");
//            }
//        }
//    }
//
//    @Given("^User edit the work queue and validate the table$")
//    public void user_edit_the_work_queue_and_validate_the_table() throws Throwable {
//        new WorkQueueMaintenance(scenario, driver()).editWorkQueueAndValidateOnTable();
//    }
//
//    /*
//     * user navigates to work queue maintenance page
//     * and adds a work queue
//     * @param name, description, status
//     * */
//    @Given("^User add a work queue with following data on work queue maintenance \"([^\"]*)\", \"([^\"]*)\" and \"([^\"]*)\"$")
//    public void user_add_a_work_queue_with_following_data_on_work_queue_maintenance_and(String name, String description, String status) throws Throwable {
//        new WorkQueueMaintenance(scenario, driver()).addWorkQueue(name, description, status);
//    }
//
//    @Given("^User adds below work queues$")
//    public void user_adds_below_work_queues(List<Map<String, String>> maps) throws Throwable {
//        WorkQueueMaintenance workQueueMaintenance = new WorkQueueMaintenance(scenario, driver());
//        for (Map<String, String> map : maps) {
//            String name = WhiteBoard.resolve(owner, map.get("Name"));
//            String description = WhiteBoard.resolve(owner, map.get("Description"));
//            String status = WhiteBoard.resolve(owner, map.get("Status"));
//            workQueueMaintenance.addWorkQueue(name, description, status);
//        }
//    }
//
//    @Given("^User validates the added work queue$")
//    public void user_validates_the_added_work_queue(DataTable dataTable) throws Throwable {
//        List<Map<String, String>> list = dataTable.asMaps(String.class, String.class);
//        String name = list.get(0).get("Name");
//        String description = list.get(0).get("Description");
//        String status = list.get(0).get("Status");
//    }
//
//    @Then("^User validates table header with below labels$")
//    public void user_validates_table_header_with_below_labels(DataTable arg1) throws Throwable {
//        List<String> expectedLabelList = arg1.asList(String.class);
//        new WorkQueueMaintenance(scenario, driver()).validateWorkQueueTableHeader(expectedLabelList);
//    }
//
//    @And("^User validates the pagination for work queue with below data$")
//    public void user_validates_the_pagination_for_work_queue_with_below_data(DataTable arg1) throws Throwable {
//
//    }
//
//    @Given("^user edit work queue as below table$")
//    public void userEditWorkQueueAsBelowTable(List<Map<String, String>> maps) throws Throwable {
//        for (Map<String, String> map : maps) {
//            int row = Integer.parseInt(map.get("ROW_NUMBER"));
//            obj().WorkQueueMaintenancePage.clickEditIcon(row);
//            obj().AddWorkQueuePage.enterDetailsToAddWorkQueue(map.get("Name"), map.get("Description"), map.get("Status"));
//            obj().AddWorkQueuePage.clickSaveButton();
//        }
//    }
//
//    @Then("^user bulk assigns below authorization requests to \"([^\"]*)\"$")
//    public void userBulkAssignsBelowAuthorizationRequestsTo(String assignedTo, List<String> requestNumberList) throws Throwable {
//        for (String requestNumber : requestNumberList) {
//            requestNumber = WhiteBoard.resolve(owner, requestNumber);
//            obj().WorkQueuePage.selectByRequestNumber(requestNumber);
//        }
//        obj().WorkQueuePage.clickAssignSelectedButton();
//
//        assignedTo = WhiteBoard.resolve(owner, assignedTo);
//        if (assignedTo.equals("Me")) {
//            TestUtils.click(driver(), BulkAssignPopupPage.assignedToMeRadioButtonPopup);
//        } else if (assignedTo.startsWith("Another User:")) {
//            TestUtils.click(driver(), BulkAssignPopupPage.assignedToAnotherUserRadioButtonPopup);
//            TestUtils.input(driver(), By.xpath(BulkAssignPopupPage.assignedToAnotherUserTypeAheadXpath), assignedTo.split(":")[1].trim());
//        } else if (assignedTo.startsWith("Queue:")) {
//            TestUtils.click(driver(), BulkAssignPopupPage.assignedToQueueRadioButtonPopup);
//            TestUtils.input(driver(), By.xpath(BulkAssignPopupPage.assignedToQueueTypeAheadXpath), assignedTo.split(":")[1].trim());
//        }
//        TestUtils.click(driver(), BulkAssignPopupPage.assignButton);
//    }
//
//    @And("^user should be landing on Work Queue page$")
//    public void userShouldBeLandingOnWorkQueuePage() throws Throwable {
//        Assert.assertTrue(TestUtils.waitElementVisible(driver(), WorkQueuePage.WORK_QUEUE_ITEMS_TABLE_XPATH));
//    }
//
//    @And("^user navigates to the result page with Request Number \"([^\"]*)\" on Work Queue page$")
//    public void userNavigatesToTheResultPageWithRequestNumberOnWorkQueuePage(String requestNumber) throws Throwable {
//        requestNumber = WhiteBoard.resolve(owner, requestNumber);
//        Assert.assertTrue(obj().WorkQueuePage.navigateToPageWithRequestNumber(requestNumber));
//    }
//
//    @And("^user verifies the search result does not contain Request Number \"([^\"]*)\" on Work Queue page$")
//    public void useVerifiesTheSearchResultDoesNotContainRequestNumberOnWorkQueuePage(String requestNumber) throws Throwable {
//        requestNumber = WhiteBoard.resolve(owner, requestNumber);
//        Assert.assertFalse(obj().WorkQueuePage.navigateToPageWithRequestNumber(requestNumber));
//    }
//
//    @And("^Work Queue \"([^\"]*)\" is reset$")
//    public void workQueueIsReset(String stringMap) throws Throwable {
//        Map<String, String> map = DataTableUtils.asMap(stringMap);
//        map = WhiteBoard.resolve(owner, map);
//
//        String name = map.get("name");
//        String description = map.containsKey("description") ? map.get("description") : name;
//        String status = map.containsKey("status") ? map.get("status") : "Active";
//
//        workqueueItemsAreResetForQueue(name);
//
//        QueryShared myBatisShared = new QueryShared(scenario);
//        myBatisShared.isExecutedInDatabase(
//                "delete from work_queue where name = '" + name + "';",
//                "${wfdb_MyBatisConnectionFactory}");
//        String f = "INSERT INTO work_queue (work_queue_id, name, description, status) VALUES ((select max(a.work_queue_id) + 1 from work_queue a), '%s', '%s', '%s');";
//        myBatisShared.isExecutedInDatabase(
//                String.format(f, name, description, status),
//                "${wfdb_MyBatisConnectionFactory}");
//
//    }
//
//    @And("^user extracts Work Queue Manager Dashboard page as \"([^\"]*)\"$")
//    public void userExtractsWorkQueueManagerDashboardPageAs(String pvoName) throws Throwable {
//        WorkQueueManagerDashboardPage po = new WorkQueueManagerDashboardPage(driver());
//        po.setScenarioLogger(scenarioLogger);
//        PvoWorkQueueManagerDashboard result = po.collect();
//        StringBuilder healthyIssues = new StringBuilder();
//        result.appendHealthyIssues(healthyIssues);
//        String s = healthyIssues.toString().trim();
//        Assert.assertTrue(s, s.isEmpty());
//
//        String jsonString = QuickJson.writeValueAsString(result);
//        pvoName = WhiteBoard.resolve(owner, pvoName);
//        WhiteBoard.getInstance().putString(owner, pvoName, jsonString);
//    }
//
//    @When("^Work Queue Manager Dashboard difference \"([^\"]*)\" is calculated by \"([^\"]*)\" and \"([^\"]*)\"$")
//    public void workQueueManagerDashboardDifferenceIsCalculatedByAnd(String diffName, String after, String before) throws Throwable {
//        Class<PvoWorkQueueManagerDashboard> clazz = PvoWorkQueueManagerDashboard.class;
//        String jsonAfter = WhiteBoard.resolve(owner, after);
//        PvoWorkQueueManagerDashboard pvoAfter = (PvoWorkQueueManagerDashboard) QuickJson.readValue(jsonAfter, clazz);
//        String jsonBefore = WhiteBoard.resolve(owner, before);
//        PvoWorkQueueManagerDashboard pvoBefore = (PvoWorkQueueManagerDashboard) QuickJson.readValue(jsonBefore, clazz);
//
//        PvoWorkQueueManagerDashboardDiff diff = PvoWorkQueueManagerDashboardDiff.diff(pvoAfter, pvoBefore);
//        String diffJson = QuickJson.prettyJson(diff);
//        WhiteBoard.getInstance().putString(owner, WhiteBoard.resolve(owner, diffName), diffJson);
//        scenarioLogger.warn(diffName + "=\n" + diffJson);
//
//    }
//
//    @And("^user validates tile \"([^\"]*)\" is selected on Work Queue Manager Dashboard page$")
//    public void userValidatesTileIsSelectedOnWorkQueueManagerDashboardPage(String widget) throws Throwable {
//        String xpath = WorkQueueManagerDashboardPage.widgetXpath(widget);
//        String attrClass = driver().findElement(By.xpath(xpath)).getAttribute("class");
//        scenarioLogger.warn("class=" + attrClass);
//        Assert.assertTrue(attrClass.contains("selected"));
//    }
//
//    @Given("^user makes overall decision \"([^\"]*)\" on authorization \"([^\"]*)\"$")
//    public void userMakesOverallDecisionOnAuthorization(String option, String requestNumber) throws Throwable {
//        option = WhiteBoard.resolve(owner, option);
//        requestNumber = WhiteBoard.resolve(owner, requestNumber);
//        scenarioLogger.warn("option=" + option);
//        scenarioLogger.warn("requestNumber=" + requestNumber);
//
//        Map<String, String> map = ViewAuthPage.dataOfDecision(option);
//        Assert.assertNotNull(map);
//        HscSrvcDecnDao hscSrvcDecnDao = new HscSrvcDecnDao(MyBatisConnectionFactory.getSqlSessionFactory());
//        List<Map<String, Object>> hscSrvcDecnList = hscSrvcDecnDao.selectActiveOverallDecisionByRequestNumber(requestNumber);
//        if (null != hscSrvcDecnList && hscSrvcDecnList.size() > 0) {
//            String decn = null;
//            for (Map<String, Object> hscSrvcDecn : hscSrvcDecnList) {
//                Object decn_otcome_typ_id = hscSrvcDecn.get("decn_otcome_typ_id");
//                if (null == decn_otcome_typ_id) {
//                    break;
//                }
//                String s = decn_otcome_typ_id.toString();
//                if (null == decn) {
//                    decn = s;
//                } else {
//                    if (!decn.equals(s)) {
//                        decn = null;
//                        break;
//                    }
//                }
//            }
//            if ("1".equals(decn) && "Approved".equals(option)) {
//                return;
//            }
//            if ("2".equals(decn) && "Denied".equals(option)) {
//                return;
//            }
//        }
//
//        WebDriver d = driver();
//
//        //search
//        String hscID = hscSrvcDecnList.get(0).get("hsc_id").toString();
//
//        navigateToViewAuthPage(d, requestNumber, hscID, true);
//
//        //make decision
//        TestUtils.click(d, ViewAuthPage.tabServiceAndDecisions);
//        ViewAuthPage viewAuthPage = new ViewAuthPage(d);
//        Assert.assertTrue(viewAuthPage.clickMakeDecisions());
//        TestUtils.inputAllByLabels(d, map, null);
//        TestUtils.demoBreakPoint(scenario, d, "Input completed: " + map.toString());
//        Assert.assertTrue(viewAuthPage.clickSaveDecisions());
//        Assert.assertTrue(TestUtils.isElementVisible(driver(), ViewAuthPage.medicalBenefitServicesTableDecisionStatus));
//
//    }
//
//    private void navigateToViewAuthPage(WebDriver d, String requestNumber, String hscID, boolean urlManipulation) throws Throwable {
//        if (urlManipulation) {
//
//            navigateToViewAuthPagebyURLmanipulation(hscID);
//
//        } else {
//            AuthorizationRequest ar = new AuthorizationRequest(scenario, d);
//            Map<String, String> criteria = new HashMap<String, String>(1);
//            criteria.put("Request Number", requestNumber);
//            ar.searchSubmitted(criteria);
//            //view auth
//            By by = PriorAuthorizationSearchSubmittedPage.viewAuthLink(requestNumber);
//            TestUtils.click(d, by);
//        }
//
//        Assert.assertTrue(ViewAuthPage.waitForViewAuthPageLoaded(d));
//    }
//
//    private void navigateToViewAuthPagebyURLmanipulation(String hscID) throws Throwable {
//        Base64.Encoder encoder = Base64.getEncoder();
//        String encodedString = encoder.encodeToString(hscID.getBytes());
//        //view auth
//        String newUrl = "${testHost}/bcbs/sc/app/workQueue/utilizationManagement/" + encodedString;
//        newUrl = WhiteBoard.resolve(owner, newUrl);
//        driver().get(newUrl);
//    }
//    @And("^User validates the list of custom request reason in dropdown$")
//    public void userValidatesTheListOfCustomRequestReasonInDropdown() throws Throwable {
//        obj().CaseSummaryMakeDecisionSection.validateListofCustomRequestReason();
//    }
//
//    @And("^User save multiple Reasons for custom in Make decision section$")
//    public void userSaveMultipleReasonsForCustomInMakeDecisionSection() throws Throwable {
//        obj().CaseSummaryMakeDecisionSection.selectCustomReason("Other");
//        customRequestReasonInMakeDecision= obj().CaseSummaryMakeDecisionSection.getCustomReasonsSelected();
//        obj().CaseSummaryMakeDecisionSection.enterResourceDetails("resource details");
//        obj().CaseSummaryMakeDecisionSection.selectAllCriteriaResourceUsed();
//        obj().CaseSummaryMakeDecisionSection.clickDecisionSaveButton();
//        customRequestReasonsInHeader=obj().CaseSummaryMakeDecisionSection.getCustomReasonsInHeader();
//        Assert.assertEquals(customRequestReasonInMakeDecision,customRequestReasonsInHeader);
//    }
//
//    @And("^User selects all mandatory fields in Make Decision section$")
//    public void userSelectsAllMandatoryFieldsInMakeDecisionSection() throws Throwable {
//        obj().CaseSummaryMakeDecisionSection.selectDecisionOutcome("Approved/Covered");
//        obj().CaseSummaryMakeDecisionSection.selectDecisionType("Clinical");
//        obj().CaseSummaryMakeDecisionSection.selectDecisionReason("A1 Approve, Medically Appropriate");
//    }
//
//    @And("^User checks custom reasons displayed in Header are auto selected in Make decision section$")
//    public void userChecksCustomReasonsDisplayedInHeaderAreAutoSelectedInMakeDecisionSection() throws Throwable {
//        obj().CaseSummaryMakeDecisionSection.clickCustomReasonDropdown();
//        obj().CaseSummaryMakeDecisionSection.verifyCustomReasonAutoSelected("Cancer/Disease State Other");
//        obj().CaseSummaryMakeDecisionSection.verifyCustomReasonAutoSelected("No Regimen Match Found");
//        }
//
//    @And("^User clicks on Override Decision Button to validate CustomRequest reason is disabled$")
//    public void userClicksOnOverrideDecisionButtonToValidateCustomRequestReasonIsDisabled() throws Throwable {
//        obj().CaseSummaryMakeDecisionSection.clickOverrideDecisionButton();
//    }
//
//    @And("^User checks custom reasons displayed in Header are auto selected in Make decision section for SGP$")
//    public void userChecksCustomReasonsDisplayedInHeaderAreAutoSelectedInMakeDecisionSectionForSGP() throws Throwable {
//        obj().CaseSummaryMakeDecisionSection.clickCustomReasonDropdown();
//        obj().CaseSummaryMakeDecisionSection.verifyCustomReasonAutoSelected("Clinical Status Exception");
//        obj().CaseSummaryMakeDecisionSection.verifyCustomReasonAutoSelected("Site of Care Exception");
//    }
//}
