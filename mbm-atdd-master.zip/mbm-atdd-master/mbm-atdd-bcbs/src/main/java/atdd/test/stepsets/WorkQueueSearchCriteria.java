package atdd.test.stepsets;

import atdd.test.core.SearchCriteria;
import atdd.test.pageobjects.WorkQueuePage;
import atdd.utils.StringUtils;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.Map;

public class WorkQueueSearchCriteria extends SearchCriteria {
    public WorkQueueSearchCriteria(Scenario scenario, WebDriver webDriver) {
        super(scenario, webDriver);
    }

    public void setCriteria(Map<String, String> criteria, By clearButton) {
//DE290944        TestUtils.safeClick(driver(), clearButton);

        String assignedTo = criteria.remove("Assigned To");
        if (!StringUtils.isEmpty(assignedTo)) {
            if (assignedTo.startsWith("Me")) {
                Assert.assertTrue(TestUtils.click(driver(), WorkQueuePage.assignedToMeRadioButton));
            } else if (assignedTo.startsWith("Another user>")) {
                Assert.assertTrue(TestUtils.click(driver(), WorkQueuePage.assignedToAnotherUserRadioButton));
                Assert.assertTrue(TestUtils.input(driver(), WorkQueuePage.assignedToUserTypeAhead, assignedTo.split(">", 2)[1]));
            } else if (assignedTo.startsWith("Queue>")) {
                Assert.assertTrue(TestUtils.click(driver(), WorkQueuePage.assignedToQueueRadioButton));
                Assert.assertTrue(TestUtils.input(driver(), WorkQueuePage.assignedToQueueTypeAhead, assignedTo.split(">", 2)[1]));
            } else {
                Assert.fail("Unknown Assigned To option: " + assignedTo);
            }
        }

        if (criteria.size() > 0) {
            //TODO: remove version check
            AbstractLogin login = Login.getLastAccessedLogin(scenario());
            if (null == login || login.getAppVersion().contains("4.1.")) {
                for (String label : criteria.keySet()) {
                    String s = "//div[contains(@class, 'individualSearchFieldPair') and contains(./span, '" + label + "')]/*[2]";
                    Assert.assertTrue(TestUtils.input(driver(), By.xpath(s), criteria.get(label)));
                }
            } else
                Assert.assertTrue(TestUtils.inputAllByLabels(driver(), criteria, WorkQueuePage.workQueueSearchFormXpath));
        }
    }

//        String sor = criteria.get("SOR");
//        if (!StringUtils.isEmpty(sor)) {
//            TestUtils.input(driver(), WorkQueuePage.sorTkMultiSel, sor);
//        }
//
//        String reviewPriority = criteria.get("Review Priority");
//        if (!StringUtils.isEmpty(reviewPriority)) {
//            TestUtils.input(driver(), WorkQueuePage.reviewPrioritySelect, reviewPriority);
//        }
//
//        String assignmentDueDate = criteria.get("Assignment Due Date");
//        if (!StringUtils.isEmpty(assignmentDueDate)) {
//            TestUtils.input(driver(), WorkQueuePage.assignmentDueDateSelect, assignmentDueDate);
//        }
//
//        String dateOfService = criteria.get("Date of Service");
//        if (!StringUtils.isEmpty(dateOfService)) {
//            TestUtils.input(driver(), WorkQueuePage.dateOfServiceSelect, dateOfService);
//        }
//
//        String tatDueDate = criteria.get("TAT Due Date");
//        if (!StringUtils.isEmpty(tatDueDate)) {
//            TestUtils.input(driver(), WorkQueuePage.tatDueDateInput, tatDueDate);
//        }
//
//        String assignmentType = criteria.get("Assignment Type");
//        if (!StringUtils.isEmpty(assignmentType)) {
//            TestUtils.input(driver(), WorkQueuePage.assignmentTypeSelect, assignmentType);
//        }
}

