package atdd.test.stepsets.auth;

import atdd.common.ICondition;
import atdd.common.ImmediateAbortException;
import atdd.test.core.DrugQuestionnaireManager;
import atdd.test.core.PageWorkerBcbs;
import atdd.test.core.Qa;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DrugQuestionnairePageWorker extends PageWorkerBcbs {
    public DrugQuestionnairePageWorker(Scenario scenario, WebDriver webDriver, Map<String, String> pf) {
        super(scenario, webDriver, pf);
    }

    @Override
    public boolean accept() {
        TestUtils.waitForNotBusy(driver());
        return TestUtils.isElementVisible(driver(), "//div[contains(@class, 'oral-regimen-panel')]");
    }

    @Override
    public void work() throws ImmediateAbortException {
        List<WebElement> oralRegimenInnerWrappers = TestUtils.findElements(driver(), "//div[contains(@class, 'oral-regimen-inner-wrapper')]");
        for (WebElement oralRegimenInnerWrapper : oralRegimenInnerWrappers) {
            WebElement drugNameP = oralRegimenInnerWrapper.findElement(By.xpath(".//div[./strong='Drug Name']/p"));
            String drugName = drugNameP.getText().trim();
            WebElement strengthP = oralRegimenInnerWrapper.findElement(By.xpath(".//div[./strong='Strength']/p"));
            String strength = strengthP.getText().trim();
            Map<String, String> criteria = new HashMap<>(2);
            criteria.put("drugName", drugName);
            criteria.put("strength", strength);
            logger.warn(criteria);
            Qa qa = DrugQuestionnaireManager.getInstance().getQa(criteria);
            if (null == qa) {
                throw new ImmediateAbortException("No predefined Drug Questionnaire for " + drugName);
            } else {
                logger.warn("Qa's provided by: " + qa.getSource());
                if (null == qa.getQas() || 0 == qa.getQas().size()) {
                    throw new ImmediateAbortException("No predefined Drug Questionnaire found: " + qa.getSource());
                }
                //1. make sure expanded
                TestUtils.clickUntil(driver(), oralRegimenInnerWrapper.findElement(By.xpath(".//div[@ng-click]")), new ICondition() {
                    @Override
                    public boolean evaluate() throws Exception {
                        return oralRegimenInnerWrapper.findElement(By.xpath(".//div[@ng-click]")).getAttribute("class").contains("triangle-down");
                    }
                });
                //2. input answers with predefinedQuestionnaire
                //e.g. .//div[contains(@class, 'oral-regimen-question1') and contains(./p, 'Please provide the directions for use:')]/div/p[contains(@class,'choices')]
                for (String q : qa.getQas().keySet()) {
                    String a = qa.getQas().get(q);
                    List<WebElement> answerPs = oralRegimenInnerWrapper.findElements(
                            By.xpath(".//div[contains(@class, 'oral-regimen-question1') and contains(./p, \""
                                    + q + "\")]/div/p[contains(@class,'choices')]"));
                    if (1 == answerPs.size()) {
                        //non-radio
                        WebElement el = answerPs.get(0).findElement(By.xpath("./*"));
                        if (!TestUtils.input(driver(), el, a, false)) {
                            throw new ImmediateAbortException("Input fail: " + a + "/" + el);
                        }
                    } else {
                        //radio
                        for (WebElement answerP : answerPs) {
                            if (answerP.getText().contains(a)) {
                                TestUtils.click(driver(), answerP.findElement(By.xpath("./input[@type='radio']")));
                                break;
                            }
                        }
                    }
                }
                //3. Next or Close
                TestUtils.click(driver(), oralRegimenInnerWrapper.findElement(By.xpath("./input")));
            }
        }

    }

    @Override
    protected void handOff() {
        TestUtils.click(driver(), By.xpath("//input[@ng-click='regimenContinue(newAuthForm)']"));
    }

    @Override
    protected String getPageName() {
        return "DrugQuestionnairePage";
    }
}
