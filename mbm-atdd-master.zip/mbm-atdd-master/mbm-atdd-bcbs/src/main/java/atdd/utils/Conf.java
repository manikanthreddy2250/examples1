package atdd.utils;

public class Conf extends ConfBase {
    private static ConfBase instance = new Conf();

    private Conf() {
        super("mbm-atdd-bcbs", "config","common_config","bcbs_config","bcbs_data", "um_config");

        loadTunnelProperties(DATA);
    }

    public static ConfBase getInstance() {
        return instance;
    }
}
