package atdd.dao;

import atdd.dao.mbm.HscDao;
import atdd.dao.mbm.MyBatisConnectionFactory;
import atdd.dao.workflow.MyBatisConnectionFactoryWorkflow;
import atdd.dao.workflow.QueueItemDao;
import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.Before;
import org.junit.Test;

public class MyBatisConnectionFactoryTest {

    @Before
    public void before() {
        System.setProperty("envset", "bravo_bcbssc");
    }

    @Test
    public void getFactoriesTest() {
        try {
            SqlSessionFactory factory = MyBatisConnectionFactory.getSqlSessionFactory();
            HscDao hscDao = new HscDao(factory);
            System.out.println(hscDao.selectById(174139).size());
        } catch (Throwable e) {
            e.printStackTrace();
            //should not be blocking maven install
            //because db credentials are supplied by Jenkins parameters
        }
    }

    @Test
    public void getWorkQueueFactoriesTest() {
        try {
            SqlSessionFactory factory = MyBatisConnectionFactoryWorkflow.getSqlSessionFactory();
            QueueItemDao queueItemDao = new QueueItemDao(factory);
            System.out.println(queueItemDao.selectByQueueItemId("660002").size());
        } catch (Throwable e) {
            e.printStackTrace();
            //should not be blocking maven install
            //because db credentials are supplied by Jenkins parameters
        }
    }

}