package atdd.test.core;

import atdd.utils.Conf;
import atdd.utils.DataTableUtils;
import atdd.utils.ExcelLib;
import atdd.utils.MBM;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.LinkedHashMap;
import java.util.Map;

public class CsqaManagerBcbsTest {

    @Before
    public void before() {
        System.setProperty(Conf.ENVSET, "int_bcbssc");
    }

    @Test
    public void getInstanceTest() {
        System.out.println(CsqaManager.getInstance().getNames());
        System.out.println(CsqaManager.getInstance().getFeatures());
        System.out.println(CsqaManager.getInstance().getFeatureKeys());
    }

    @Test
    public void getQasTest() {
        ExcelLib lib = ExcelLib.instance(ExcelLib.LIB_AUTH_PROFILE);
        for (String authTitle : lib.getTitles()) {
            System.out.println("authTitle=" + authTitle);
            Map<String, String> qas = new LinkedHashMap<>(); //for logging
            qas.put(MBM.AUTH_TITLE, authTitle);

            Map<String, String> pf = ExcelLib.completeProfile(null, qas);//lib.getObjectByTitle(authTitle);
            String pfFeature = CsqaManager.getInstance().getFeature(pf);
            System.out.println("pfFeature=" + pfFeature);
            if (authTitle.equals("physical therapy approved profile") || authTitle.equals("occupational therapy approved profile")
                    || authTitle.equals("speech therapy approved profile")) {
                FomsQa qa = FomsQaManager.getInstance().getFomsQa(pf);
                System.out.println("source=" + (null == qa ? "UNKNOWN" : qa.getSource()));
                if (null == qa || null == qa.getMskqas() || 0 == qa.getMskqas().size() ||
                        null == qa.getBackindexqas() || 0 == qa.getBackindexqas().size()) {
                    if ("No".equalsIgnoreCase(pf.get(MBM.AUTH_HAS_CSQA))) {
                        System.out.println("No Qa's defined for profile: " + authTitle);
                        continue;
                    } else {
                        Assert.fail("No Qa's defined for profile: " + authTitle);
                    }
                }

                try {
                    qas.putAll(qa.getMskqas());
                    qas.putAll(qa.getBackindexqas());
                    String s = DataTableUtils.mapToDataTableString(qas);
                    System.out.println(s);
                } catch (Exception e) {
                    e.printStackTrace();
                    Assert.fail(e.getMessage());
                }
            }
            else {
                Qa qa = CsqaManager.getInstance().getQa(pf);
                System.out.println("source=" + (null == qa ? "UNKNOWN" : qa.getSource()));
                if (null == qa || null == qa.getQas() || 0 == qa.getQas().size()) {
                    if ("No".equalsIgnoreCase(pf.get(MBM.AUTH_HAS_CSQA))) {
                        System.out.println("No Qa's defined for profile: " + authTitle);
                        continue;
                    } else {
                        Assert.fail("No Qa's defined for profile: " + authTitle);
                    }
                }

                try {
                    qas.putAll(qa.getQas());
                    String s = DataTableUtils.mapToDataTableString(qas);
                    System.out.println(s);
                } catch (Exception e) {
                    e.printStackTrace();
                    Assert.fail(e.getMessage());
                }
            }
//       | authTitle | What is the histology? | What was the stage at initial diagnosis? | What is the treatment indication or disease status? | What is the MSI/MMR status? | What is the line of therapy? |
//       | default   | Adenocarcinoma         | Stage IVB                                | Castration-Resistant                                | Low/Proficient              | Initial                      |
        }
    }

    @Test
    public void getOneQasTest() {
        for (String authTitle : new String[]{"auth_chemo_new_treatment"}) {
            System.out.println("authTitle=" + authTitle);
            Map<String, String> qas = new LinkedHashMap<>(); //for logging
            qas.put(MBM.AUTH_TITLE, authTitle);

            Map<String, String> pf = ExcelLib.completeProfile(null, qas);//lib.getObjectByTitle(authTitle);
            String pfFeature = CsqaManager.getInstance().getFeature(pf);
            System.out.println("pfFeature=" + pfFeature);
            Qa qa = CsqaManager.getInstance().getQa(pf);
            System.out.println("source=" + (null == qa ? "UNKNOWN" : qa.getSource()));
            if (null == qa || null == qa.getQas() || 0 == qa.getQas().size()) {
                if ("No".equalsIgnoreCase(pf.get(MBM.AUTH_HAS_CSQA))) {
                    System.out.println("No Qa's defined for profile: " + authTitle);
                    continue;
                } else {
                    Assert.fail("No Qa's defined for profile: " + authTitle);
                }
            }
            try {
                qas.putAll(qa.getQas());
                String s = DataTableUtils.mapToDataTableString(qas);
                System.out.println(s);
            } catch (Exception e) {
                e.printStackTrace();
                Assert.fail(e.getMessage());
            }
//       | authTitle | What is the histology? | What was the stage at initial diagnosis? | What is the treatment indication or disease status? | What is the MSI/MMR status? | What is the line of therapy? |
//       | default   | Adenocarcinoma         | Stage IVB                                | Castration-Resistant                                | Low/Proficient              | Initial                      |
        }
    }
}