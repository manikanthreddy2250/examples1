package atdd.test.core;

import org.junit.Assert;
import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

public class DrugQuestionnaireManagerTest {

    @Test
    public void tykerbTest() {
        Map<String, String> criteria = new HashMap<>(2);
        criteria.put("drugName", "TYKERB TABS 250.0 MG");
        criteria.put("rgdrDrugStrength0", "250.00 MG");
        Map<String, String> qas = DrugQuestionnaireManager.getInstance().getQa(criteria).getQas();
        System.out.println(qas);
        Assert.assertTrue(null != qas && qas.size() > 0);
    }
}