package atdd.utils;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ExcelLibTest {

    @Test
    public void getUserByTitle() {
        printExcelLib(ExcelLib.LIB_USER);
    }

    @Test
    public void getMemberByTitle() {
        printExcelLib(ExcelLib.LIB_MEMB);
    }

    @Test
    public void getRequestingProviderByTitle() {
        printExcelLib(ExcelLib.LIB_RP);
    }

    @Test
    public void getServicingProviderByTitle() {
        printExcelLib(ExcelLib.LIB_SP);
    }

    @Test
    public void completeProfile() {
        ExcelLib lib = ExcelLib.instance(ExcelLib.LIB_AUTH_PROFILE);
        for (String title : lib.getTitles()) {
            List<Map<String, String>> maps = new ArrayList<>();
            maps.add(ExcelLib.completeProfile(null, lib.getObjectByTitle(title)));
            printMaps(maps);
        }
    }

    private void printExcelLib(String libType) {
        List<Map<String, String>> maps = new ArrayList<>();
        ExcelLib lib = ExcelLib.instance(libType);
        for (String title : lib.getTitles()) {
            maps.add(lib.getObjectByTitle(title));
        }
        printMaps(maps);
    }

    private void printMaps(List<Map<String, String>> maps) {
        System.out.println(DataTableUtils.mapsToDataTableString(maps));
    }

}