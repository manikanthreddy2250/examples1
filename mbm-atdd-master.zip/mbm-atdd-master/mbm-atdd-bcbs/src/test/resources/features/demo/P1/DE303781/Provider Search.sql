
select a.alternate_id, a.type, a.* from practitioner a where last_name = 'Provider Search';

select * from address where practitioner_id in (select a.practitioner_id from practitioner a where a.last_name = 'Provider Search');
select * from contact where practitioner_id in (select a.practitioner_id from practitioner a where a.last_name = 'Provider Search');
select * from ingestion_history where practitioner_id in (select a.practitioner_id from practitioner a where a.last_name = 'Provider Search');
select * from network where practitioner_id in (select a.practitioner_id from practitioner a where a.last_name = 'Provider Search');
select * from practitioner_identifier where practitioner_id in (select a.practitioner_id from practitioner a where a.last_name = 'Provider Search');
select * from practitioner_type where practitioner_id in (select a.practitioner_id from practitioner a where a.last_name = 'Provider Search');
select * from practitioner where last_name = 'Provider Search';

delete from address where practitioner_id in (select a.practitioner_id from practitioner a where a.last_name = 'Provider Search');
delete from contact where practitioner_id in (select a.practitioner_id from practitioner a where a.last_name = 'Provider Search');
delete from ingestion_history where practitioner_id in (select a.practitioner_id from practitioner a where a.last_name = 'Provider Search');
delete from network where practitioner_id in (select a.practitioner_id from practitioner a where a.last_name = 'Provider Search');
delete from practitioner_identifier where practitioner_id in (select a.practitioner_id from practitioner a where a.last_name = 'Provider Search');
delete from practitioner_type where practitioner_id in (select a.practitioner_id from practitioner a where a.last_name = 'Provider Search');
delete from practitioner where last_name = 'Provider Search';


INSERT INTO address (address_id, practitioner_id, name, address1, address2, address3, address_type_id, city, state, county, zip, creat_dttm, chg_dttm, version) VALUES (224182, 171146, 'newtoneinstein news1 co', '', '163 Bluffton AE ABC A', null, '2', 'BLUFFTON', 'SC', null, '294567334', '2020-02-21 10:35:31', '2020-02-21 10:35:31', 0);
INSERT INTO address (address_id, practitioner_id, name, address1, address2, address3, address_type_id, city, state, county, zip, creat_dttm, chg_dttm, version) VALUES (224183, 171146, null, '123 COMMERCIAL AB', '', null, '1', 'RINCON', 'GA', null, '234567123', '2020-02-21 10:35:31', '2020-02-21 10:35:31', 0);
INSERT INTO address (address_id, practitioner_id, name, address1, address2, address3, address_type_id, city, state, county, zip, creat_dttm, chg_dttm, version) VALUES (224184, 171147, 'newtoneinstein news1 co', '', '163 Bluffton AE ABC A', null, '2', 'BLUFFTON', 'SC', null, '294567334', '2020-02-21 10:35:31', '2020-02-21 10:35:31', 0);
INSERT INTO address (address_id, practitioner_id, name, address1, address2, address3, address_type_id, city, state, county, zip, creat_dttm, chg_dttm, version) VALUES (224185, 171147, null, '123 COMMERCIAL AB', '', null, '1', 'RINCON', 'GA', null, '234567123', '2020-02-21 10:35:31', '2020-02-21 10:35:31', 0);
INSERT INTO address (address_id, practitioner_id, name, address1, address2, address3, address_type_id, city, state, county, zip, creat_dttm, chg_dttm, version) VALUES (224186, 171148, 'newtoneinstein news1 co', '', '163 Bluffton AE ABC A', null, '2', 'BLUFFTON', 'SC', null, '294567334', '2020-02-21 10:35:31', '2020-02-21 10:35:31', 0);
INSERT INTO address (address_id, practitioner_id, name, address1, address2, address3, address_type_id, city, state, county, zip, creat_dttm, chg_dttm, version) VALUES (224187, 171148, null, '123 COMMERCIAL AB', '', null, '1', 'RINCON', 'GA', null, '234567123', '2020-02-21 10:35:31', '2020-02-21 10:35:31', 0);

INSERT INTO contact (contact_id, practitioner_id, contact_type_id, contact_value, creat_dttm, chg_dttm, version) VALUES (342289, 171146, '2', '5671329120', '2020-02-21 10:35:31', '2020-02-21 10:35:31', 0);
INSERT INTO contact (contact_id, practitioner_id, contact_type_id, contact_value, creat_dttm, chg_dttm, version) VALUES (342290, 171146, '1', '4561234567', '2020-02-21 10:35:31', '2020-02-21 10:35:31', 0);
INSERT INTO contact (contact_id, practitioner_id, contact_type_id, contact_value, creat_dttm, chg_dttm, version) VALUES (342291, 171147, '2', '5671329120', '2020-02-21 10:35:31', '2020-02-21 10:35:31', 0);
INSERT INTO contact (contact_id, practitioner_id, contact_type_id, contact_value, creat_dttm, chg_dttm, version) VALUES (342292, 171147, '1', '4561234567', '2020-02-21 10:35:31', '2020-02-21 10:35:31', 0);
INSERT INTO contact (contact_id, practitioner_id, contact_type_id, contact_value, creat_dttm, chg_dttm, version) VALUES (342293, 171148, '2', '5671329120', '2020-02-21 10:35:31', '2020-02-21 10:35:31', 0);
INSERT INTO contact (contact_id, practitioner_id, contact_type_id, contact_value, creat_dttm, chg_dttm, version) VALUES (342294, 171148, '1', '4561234567', '2020-02-21 10:35:31', '2020-02-21 10:35:31', 0);

INSERT INTO network (network_id, practitioner_id, network_code, network_status, start_date, end_date, creat_dttm, chg_dttm, version) VALUES (368808, 171146, '3', 1, '2010-07-02 00:00:00', '9901-01-01 00:00:00', '2020-02-21 10:35:31', '2020-02-21 10:35:31', 0);
INSERT INTO network (network_id, practitioner_id, network_code, network_status, start_date, end_date, creat_dttm, chg_dttm, version) VALUES (368809, 171147, '3', 1, '2010-07-02 00:00:00', '9901-01-01 00:00:00', '2020-02-21 10:35:31', '2020-02-21 10:35:31', 0);
INSERT INTO network (network_id, practitioner_id, network_code, network_status, start_date, end_date, creat_dttm, chg_dttm, version) VALUES (368810, 171148, '3', 1, '2010-07-02 00:00:00', '9901-01-01 00:00:00', '2020-02-21 10:35:31', '2020-02-21 10:35:31', 0);

INSERT INTO practitioner_identifier (practitioner_identifier_id, practitioner_id, practitioner_identifier_type_id, practitioner_identifier_value, creat_dttm, chg_dttm, version) VALUES (513427, 171146, '2', '239819001', '2020-02-21 10:35:31', '2020-02-21 10:35:31', 0);
INSERT INTO practitioner_identifier (practitioner_identifier_id, practitioner_id, practitioner_identifier_type_id, practitioner_identifier_value, creat_dttm, chg_dttm, version) VALUES (513428, 171146, '3', '2398190001', '2020-02-21 10:35:31', '2020-02-21 10:35:31', 0);
INSERT INTO practitioner_identifier (practitioner_identifier_id, practitioner_id, practitioner_identifier_type_id, practitioner_identifier_value, creat_dttm, chg_dttm, version) VALUES (513429, 171146, '4', '001234567', '2020-02-21 10:35:31', '2020-02-21 10:35:31', 0);
INSERT INTO practitioner_identifier (practitioner_identifier_id, practitioner_id, practitioner_identifier_type_id, practitioner_identifier_value, creat_dttm, chg_dttm, version) VALUES (513430, 171147, '2', '239819002', '2020-02-21 10:35:31', '2020-02-21 10:35:31', 0);
INSERT INTO practitioner_identifier (practitioner_identifier_id, practitioner_id, practitioner_identifier_type_id, practitioner_identifier_value, creat_dttm, chg_dttm, version) VALUES (513431, 171147, '3', '2398190002', '2020-02-21 10:35:31', '2020-02-21 10:35:31', 0);
INSERT INTO practitioner_identifier (practitioner_identifier_id, practitioner_id, practitioner_identifier_type_id, practitioner_identifier_value, creat_dttm, chg_dttm, version) VALUES (513432, 171147, '4', '001234567', '2020-02-21 10:35:31', '2020-02-21 10:35:31', 0);
INSERT INTO practitioner_identifier (practitioner_identifier_id, practitioner_id, practitioner_identifier_type_id, practitioner_identifier_value, creat_dttm, chg_dttm, version) VALUES (513433, 171148, '2', '239819003', '2020-02-21 10:35:31', '2020-02-21 10:35:31', 0);
INSERT INTO practitioner_identifier (practitioner_identifier_id, practitioner_id, practitioner_identifier_type_id, practitioner_identifier_value, creat_dttm, chg_dttm, version) VALUES (513434, 171148, '3', '2398190003', '2020-02-21 10:35:31', '2020-02-21 10:35:31', 0);
INSERT INTO practitioner_identifier (practitioner_identifier_id, practitioner_id, practitioner_identifier_type_id, practitioner_identifier_value, creat_dttm, chg_dttm, version) VALUES (513435, 171148, '4', '001234567', '2020-02-21 10:35:31', '2020-02-21 10:35:31', 0);

INSERT INTO practitioner_type (practitioner_type_id, practitioner_id, practitioner_type_value, description, group_id, creat_dttm, chg_dttm, version) VALUES (171143, 171146, '1', null, null, '2020-02-21 10:35:31', '2020-02-21 10:35:31', 0);
INSERT INTO practitioner_type (practitioner_type_id, practitioner_id, practitioner_type_value, description, group_id, creat_dttm, chg_dttm, version) VALUES (171144, 171147, '2', null, null, '2020-02-21 10:35:31', '2020-02-21 10:35:31', 0);
INSERT INTO practitioner_type (practitioner_type_id, practitioner_id, practitioner_type_value, description, group_id, creat_dttm, chg_dttm, version) VALUES (171145, 171148, '3', null, null, '2020-02-21 10:35:31', '2020-02-21 10:35:31', 0);

INSERT INTO practitioner (practitioner_id, first_name, last_name, middle_initial, suffix, title, business_name, eligibility_status, specialty_type_id, specialty_description, specialty, setting_type_id, creat_dttm, chg_dttm, version, alternate_id, type) VALUES (171146, 'Practitioner', 'Provider Search', null, null, null, 'AVANC FAMILY CHINKORACTIC', null, null, null, '35', '4', '2020-02-21 10:35:31', '2020-02-21 10:35:31', 0, '2398190001', '1');
INSERT INTO practitioner (practitioner_id, first_name, last_name, middle_initial, suffix, title, business_name, eligibility_status, specialty_type_id, specialty_description, specialty, setting_type_id, creat_dttm, chg_dttm, version, alternate_id, type) VALUES (171147, 'Group', 'Provider Search', null, null, null, 'AVANC FAMILY CHINKORACTIC', null, null, null, '35', '4', '2020-02-21 10:35:31', '2020-02-21 10:35:31', 0, '2398190002', '2');
INSERT INTO practitioner (practitioner_id, first_name, last_name, middle_initial, suffix, title, business_name, eligibility_status, specialty_type_id, specialty_description, specialty, setting_type_id, creat_dttm, chg_dttm, version, alternate_id, type) VALUES (171148, 'Affiliation', 'Provider Search', null, null, null, 'AVANC FAMILY CHINKORACTIC', null, null, null, '35', '4', '2020-02-21 10:35:31', '2020-02-21 10:35:31', 0, '2398190003', '3');
