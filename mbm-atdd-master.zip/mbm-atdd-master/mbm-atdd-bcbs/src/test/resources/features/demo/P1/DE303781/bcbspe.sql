select a.practitioner_id,a.first_name,a.last_name,a.business_name,a.alternate_id,a.type,c.practitioner_type_value,c.description,d.address1,d.address2,d.city from practitioner a
 inner join practitioner_identifier b on a.practitioner_id = b.practitioner_id 
 inner join practitioner_type c on a.practitioner_id = c.practitioner_id 
 inner join address d on a.practitioner_id = d.practitioner_id 
 where alternate_id in (1215121645)
 
 union
select a.practitioner_id,a.first_name,a.last_name,a.business_name,a.alternate_id,a.type,c.practitioner_type_value,c.description,d.address1,d.address2,d.city from practitioner a
 inner join practitioner_identifier b on a.practitioner_id = b.practitioner_id -- and b.practitioner_identifier_type_id = 3
 inner join practitioner_type c on a.practitioner_id = c.practitioner_id 
 inner join address d on a.practitioner_id = d.practitioner_id and d.address_type_id = 1
 where first_name = 'BRIAN' and last_name = 'WRIGHT';
 
select a.practitioner_id,a.first_name,a.last_name,a.business_name,a.alternate_id,a.type,c.practitioner_type_value,c.description,d.address1,d.address2,d.city from practitioner a
 inner join practitioner_identifier b on a.practitioner_id = b.practitioner_id -- and b.practitioner_identifier_type_id = 3
 inner join practitioner_type c on a.practitioner_id = c.practitioner_id 
 inner join address d on a.practitioner_id = d.practitioner_id and d.address_type_id = 1
 where first_name = 'BRIAN' and last_name = 'WRIGHT';

select a.practitioner_id,a.first_name,a.last_name,a.business_name,a.alternate_id,a.type,c.practitioner_type_value,c.description,d.address1,d.address2,d.city from practitioner a
 inner join practitioner_identifier b on a.practitioner_id = b.practitioner_id 
 inner join practitioner_type c on a.practitioner_id = c.practitioner_id 
 inner join address d on a.practitioner_id = d.practitioner_id 
 where alternate_id  like '303781%';
 
select a.practitioner_id,a.first_name,a.last_name,a.business_name,a.alternate_id,a.type,c.practitioner_type_value,c.description,d.address1,d.address2,d.city from practitioner a
 inner join practitioner_identifier b on a.practitioner_id = b.practitioner_id -- and b.practitioner_identifier_type_id = 3
 inner join practitioner_type c on a.practitioner_id = c.practitioner_id 
 inner join address d on a.practitioner_id = d.practitioner_id and d.address_type_id = 1
 where alternate_id like '303781%';

select count(*) from address;
select count(*) from contact;

select * from practitioner where alternate_id like '303781%';

select * from network where network_code=6;

select * from practitioner where practitioner_id=110372;

select a.creat_dttm, a.success, a.* from ingestion_history a order by a.creat_dttm desc limit 50;

select a.alternate_id, a.* from practitioner a where alternate_id like '303781%';

select * from address where practitioner_id in (select a.practitioner_id from practitioner a where a.alternate_id like '303781%');
select * from contact where practitioner_id in (select a.practitioner_id from practitioner a where a.alternate_id like '303781%');
select * from ingestion_history where practitioner_id in (select a.practitioner_id from practitioner a where a.alternate_id like '303781%');
select * from network where practitioner_id in (select a.practitioner_id from practitioner a where a.alternate_id like '303781%');
select * from practitioner_identifier where practitioner_id in (select a.practitioner_id from practitioner a where a.alternate_id like '303781%');
select * from practitioner_type where practitioner_id in (select a.practitioner_id from practitioner a where a.alternate_id like '303781%');
select * from practitioner where alternate_id like '303781%' order by type, alternate_id;

select * from address where practitioner_id = '171473';

select a.practitioner_id, a.alternate_id, c.description as "network", b.network_status as "status", a.type, a.first_name, a.last_name, a.business_name, d.address1, d.address2, d.city, d.state, d.zip
from practitioner a, network b, (select * from reference where name = 'networkType') c, address d
where a.alternate_id like '303781%'
and a.practitioner_id = b.practitioner_id
and a.practitioner_id = d.practitioner_id
and b.network_code = c.code
and a.alternate_id = 303781007
order by a.alternate_id, c.description, b.network_status, d.name
;
select a.practitioner_id, a.alternate_id, c.description as "network", b.network_status as "status", a.type, a.first_name, a.last_name, a.business_name
from practitioner a, network b, (select * from reference where name = 'networkType') c
where a.alternate_id like '303781%'
and a.practitioner_id = b.practitioner_id
and b.network_code = c.code
order by a.type, a.alternate_id, c.description, b.network_status
;

delete from address where practitioner_id in (select a.practitioner_id from practitioner a where a.alternate_id like '303781%');
delete from contact where practitioner_id in (select a.practitioner_id from practitioner a where a.alternate_id like '303781%');
delete from ingestion_history where practitioner_id in (select a.practitioner_id from practitioner a where a.alternate_id like '303781%');
delete from network where practitioner_id in (select a.practitioner_id from practitioner a where a.alternate_id like '303781%');
delete from practitioner_identifier where practitioner_id in (select a.practitioner_id from practitioner a where a.alternate_id like '303781%');
delete from practitioner_type where practitioner_id in (select a.practitioner_id from practitioner a where a.alternate_id like '303781%');
delete from practitioner where alternate_id like '303781%';


select a.alternate_id, a.type, a.* from practitioner a where alternate_id like '239819%';

select * from address where practitioner_id in (select a.practitioner_id from practitioner a where a.alternate_id like '239819%');
select * from contact where practitioner_id in (select a.practitioner_id from practitioner a where a.alternate_id like '239819%');
select * from ingestion_history where practitioner_id in (select a.practitioner_id from practitioner a where a.alternate_id like '239819%');
select * from network where practitioner_id in (select a.practitioner_id from practitioner a where a.alternate_id like '239819%');
select * from practitioner_identifier where practitioner_id in (select a.practitioner_id from practitioner a where a.alternate_id like '239819%');
select * from practitioner_type where practitioner_id in (select a.practitioner_id from practitioner a where a.alternate_id like '239819%');
select * from practitioner where alternate_id like '239819%';

select a.alternate_id, a.type, a.first_name, a.last_name, a.business_name, c.description as "network", b.network_status
from practitioner a, network b, (select * from reference where name = 'networkType') c
where a.alternate_id like '239819%';
and a.practitioner_id = b.practitioner_id
and b.network_code = c.code
order by a.alternate_id, a.type
;

delete from address where practitioner_id in (select a.practitioner_id from practitioner a where a.alternate_id like '239819%');
delete from contact where practitioner_id in (select a.practitioner_id from practitioner a where a.alternate_id like '239819%');
delete from ingestion_history where practitioner_id in (select a.practitioner_id from practitioner a where a.alternate_id like '239819%');
delete from network where practitioner_id in (select a.practitioner_id from practitioner a where a.alternate_id like '239819%');
delete from practitioner_identifier where practitioner_id in (select a.practitioner_id from practitioner a where a.alternate_id like '239819%');
delete from practitioner_type where practitioner_id in (select a.practitioner_id from practitioner a where a.alternate_id like '239819%');
delete from practitioner where alternate_id like '239819%';


select * from address where practitioner_id in (select a.practitioner_id from practitioner a where a.alternate_id='303781001');