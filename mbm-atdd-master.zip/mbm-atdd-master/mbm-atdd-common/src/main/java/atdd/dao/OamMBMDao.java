package atdd.dao;


import org.junit.Assert;

import java.sql.*;
import java.util.*;
import java.util.logging.Logger;

@Deprecated
public class OamMBMDao {

    private static OamMBMDao dao;
    private static Logger log = Logger.getLogger(OamMBMDao.class.getName());
    private Connection connect = null;

    private OamMBMDao() throws SQLException {

        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            log.info(e.getMessage());
            Assert.fail("Cannot find the driver class");
        }
        connect = DriverManager.getConnection("jdbc:mysql://dbsrt1260:3306/occc01", "sumalekh", "Uma<123a");

    }

    public static OamMBMDao getDao() throws SQLException {
        if (dao == null) {
            dao = new OamMBMDao();
        }
        return dao;
    }


    public void close() throws SQLException {
        connect.close();
    }

    private void execUpdate(PreparedStatement st) throws SQLException {
        st.executeUpdate();
    }

    private ResultSet execQuery(PreparedStatement st) throws SQLException {
        return st.executeQuery();
    }

    //adding generic method to get member info for code maintainability (avoid duplicate code)
    private Map<String, String> getMemberInfo(PreparedStatement query) throws SQLException {
        Map<String, String> memberInfo = new HashMap<String, String>();
        ResultSet rs = execQuery(query);//
        //its for future purpose select M.FST_NM,M.LST_NM, DATE_FORMAT(M.BTH_DT,'%m-%d-%Y') as DOB,ID.MBR_ID_TXT , C.POL_NBR from MBR M, MBR_ID ID, MBR_COV C where M.MBR_ID=ID.MBR_ID  and M.MBR_ID=C.MBR_ID and M.LST_NM is not null and
        // M.BTH_DT is not null and ID.MBR_ID_TXT is not null and C.POL_NBR is not null AND M.mbr_id in (select mbr_id from MBR_ID  where mbr_id_typ_id = '1' order by creat_dttm Desc) --.mbr_id_txt
        rs.next();
        ResultSetMetaData rsmd = rs.getMetaData();
        int cc = rsmd.getColumnCount();
        for (int i = 1; i <= cc; i++) {

            memberInfo.put(rsmd.getColumnName(i), rs.getString(i));

        }
        return memberInfo;
    }

    public Map<String, String> getColumnsAndDatatypes(String table) throws SQLException {
        ResultSet rs = null;
        PreparedStatement fetchData = null;
        HashMap columnAndDatatypes = null;
        try {
            fetchData = this.connect.prepareStatement("describe " + table);
//            fetchData.setString(1, table);
            columnAndDatatypes = new HashMap();
            rs = this.execQuery(fetchData);

            while (rs.next()) {
//                System.out.println("Value 1:" + rs.getString(1).trim().toUpperCase() + "------ Value 2:" + rs.getString(2).trim().toUpperCase());
                columnAndDatatypes.put(rs.getString(1).trim().toUpperCase(), rs.getString(2).trim().toUpperCase());
            }

        } catch (SQLException e1) {
            log.info(String.valueOf(e1.getStackTrace()));
        } finally {
            if (rs != null) {
                rs.close();
            }

            if (fetchData != null) {
                fetchData.close();
            }
        }
        return columnAndDatatypes;
    }

    public Map<String, String> getColumnsAndKeys(String table) throws SQLException {
        ResultSet rs = null;
        PreparedStatement fetchData = null;

        HashMap columnsAndKeys;
        try {
            fetchData = this.connect.prepareStatement("describe " + table);

//            fetchData = this.connect.prepareStatement("describe ?");
//            fetchData.setString(1, table);
            columnsAndKeys = new HashMap();
            rs = this.execQuery(fetchData);

            while (rs.next()) {
                columnsAndKeys.put(rs.getString(1).trim().toUpperCase(), rs.getString(4).trim().toUpperCase());
            }
        } finally {
            if (fetchData != null) {
                fetchData.close();
            }

            if (rs != null) {
                rs.close();
            }

        }

        return columnsAndKeys;
    }

    public Map<String, String> getColumnsAndNullable(String table) throws SQLException {
        ResultSet rs = null;
        PreparedStatement fetchData = null;

        Map<String, String> columnAndNullable = new HashMap();
        try {
            fetchData = this.connect.prepareStatement("describe " + table);
            rs = this.execQuery(fetchData);

            while (rs.next()) {
                columnAndNullable.put(rs.getString(1).trim().toUpperCase(), rs.getString(3).trim().toUpperCase());
            }
        } finally {
            if (rs != null) {
                rs.close();
            }

            if (fetchData != null) {
                fetchData.close();
            }

        }

        return columnAndNullable;
    }

    /**
     * Work Around method
     *
     * @param fstNM
     * @param lstNM
     * @param DOB
     * @return
     * @throws SQLException
     */
    public Map<String, String> getRequestingProvDetails(String fstNM, String lstNM, String DOB) throws SQLException {
        Map<String, String> provInfo = new HashMap<String, String>();
        PreparedStatement fetchData;
        String query = "select fst_nm as Provider_First_Name, lst_nm as Provider_Last_Name,prov_npi as Provider_NPI, fed_tax_id as Provider_TIN ,adr_ln_1_txt as Adr1, adr_ln_2_txt as Adr2 , cty_nm as City ,st_cd as State , zip_cd_txt as Zip , zip_sufx_cd_txt as Zip_cd\n" +
                " email_adr_txt as Prov_Email,sec_tel_nbr as Prov_Cell_Phn from hsc_prov where hsc_id = (select hsc_id from  hsc where mbr_id in (select mbr_id from mbr where fst_nm='" + fstNM + "' and lst_nm='" + lstNM + "'  order by creat_dttm Desc )order by creat_dttm Desc limit 1)";
        fetchData = this.connect.prepareStatement(query);
        ResultSet rs = execQuery(fetchData);
        rs.next();
        ResultSetMetaData rsmd = rs.getMetaData();
        int cc = rsmd.getColumnCount();
        for (int i = 1; i <= cc; i++) {
            System.out.println("Column name:" + rsmd.getColumnName(i) + "----------- Column value:" + rs.getString(i));
            provInfo.put(rsmd.getColumnName(i), rs.getString(i));
        }
        return provInfo;

    }

    public Map<String, String> getRequestingProvDetails(String hscID) throws SQLException {
        Map<String, String> provInfo = new HashMap<String, String>();
        PreparedStatement fetchData;
        String query = "select fst_nm as Provider_First_Name, lst_nm as Provider_Last_Name,prov_npi as Provider_NPI, fed_tax_id as Provider_TIN ,adr_ln_1_txt as Adr1, adr_ln_2_txt as Adr2 , cty_nm as City ,st_cd as State , zip_cd_txt as Zip , zip_sufx_cd_txt as Zip_cd\n" +
                " email_adr_txt as Prov_Email,sec_tel_nbr as Prov_Cell_Phn from hsc_prov where hsc_id ='" + hscID + "'";

        fetchData = this.connect.prepareStatement(query);
        ResultSet rs = execQuery(fetchData);
        rs.next();
        ResultSetMetaData rsmd = rs.getMetaData();
        int cc = rsmd.getColumnCount();
        for (int i = 1; i <= cc; i++) {
            System.out.println("Column name:" + rsmd.getColumnName(i) + "----------- Column value:" + rs.getString(i));
            provInfo.put(rsmd.getColumnName(i), rs.getString(i));

        }
        return provInfo;
    }

    public String getRequestingProvRoleType(String fstNM, String lstNM, String DOB) throws SQLException {
        String provInfo = null;
        PreparedStatement fetchData;
        String query = "select prov_role_typ_id  from HSC_PROV_ROLE where hsc_id = (select hsc_id from  hsc where mbr_id in (select mbr_id from mbr where fst_nm='" + fstNM + "' and lst_nm='" + lstNM + "'  order by creat_dttm Desc )order by creat_dttm Desc limit 1)";
        fetchData = this.connect.prepareStatement(query);
        ResultSet rs = execQuery(fetchData);
        rs.next();
        ResultSetMetaData rsmd = rs.getMetaData();
        int cc = rsmd.getColumnCount();
        for (int i = 1; i <= cc; i++) {
            System.out.println("Column name:" + rsmd.getColumnName(i) + "----------- Column value:" + rs.getString(i));
            provInfo = rs.getString(i);
        }
        return provInfo;
    }


    public Map<String, String> validateThedbColumns(String tableName) throws SQLException, ClassNotFoundException {
        String Query1 = null;
        Map<String, String> dataBaseColumns;
        if (tableName.equals("MBR")) {
            Query1 = " select mbr_id,fst_nm ,lst_nm,bth_dt,gdr_cd,rel_typ_id,chg_dttm  from " + tableName + " order by chg_dttm desc";

        } else if (tableName.equals("MBR_ADR")) {
            Query1 = "select mbr_id,adr_typ_id,adr_ln_1_txt,adr_ln_2_txt,cty_nm,st_cd,zip_cd_txt,chg_dttm from " + tableName + " order by chg_dttm desc";
        } else if (tableName.equals("HSC")) {
            Query1 = "select hsc_id,hsc_sts_typ_id,hsc_sts_rsn_typ_id,mbr_id,Srvc_setting_typ_id,chg_dttm from " + tableName + " order by chg_dttm desc";
        } else if (tableName.equals("HSC_PROV")) {
            Query1 = "select fst_nm,lst_nm,adr_ln_1_txt,adr_ln_2_txt,cty_nm,st_cd,zip_cd_txt,zip_sufx_cd_txt,prov_npi,fed_tax_id,chg_dttm from " + tableName + " order by chg_dttm desc";


        } else {
            Assert.fail("Table name not matched");
        }
        dataBaseColumns = returnMaplistSingleColumnValues(Query1);

        return dataBaseColumns;
    }

    public List<String> returnMultipleRowValue(String QUERY) throws SQLException {
        PreparedStatement query = connect.prepareStatement(QUERY);
        ResultSet rs = execQuery(query);
        List<String> value = new ArrayList();
        while (rs.next()) {
            value.add(rs.getString(1));
        }
        return value;
    }

    public void validatesColumnValuesWithDb(List<String> coulumnValues, String tableName) throws SQLException {
        String Query = "select " + " from " + tableName;
        List<String> QueryResult = returnMultipleRowValue(Query);
        for (int i = 0; i < QueryResult.size(); ++i) {
            String[] column = coulumnValues.get(i).split("\"");
            Assert.assertEquals(QueryResult.get(i), column[1]);
        }

    }

    public Map<String, String> returnMaplistSingleColumnValues(String sqlQuery) throws SQLException {
        ResultSet rs = null;
        int rc;
        int cc;
        Map<String, String> rowColumnList = new HashMap<String, String>();
        ResultSetMetaData rsmd;
        try {
            PreparedStatement query = connect.prepareStatement(sqlQuery);
            rs = execQuery(query);
            rs.last();
            rc = rs.getRow();
            rsmd = rs.getMetaData();
            cc = rsmd.getColumnCount();
            rs.beforeFirst();
            System.out.println("Row Count :" + rc);
            System.out.println("Column Count :" + cc);
            int rows = 0;
            for (int i = 1; i <= cc; i++) {
                rs.beforeFirst();
                while (rs.next()) {
                    rowColumnList.put(rsmd.getColumnLabel(i), rs.getString(i));
                }
            }
            Iterator iter = rowColumnList.entrySet().iterator();
            while (iter.hasNext()) {
                Map.Entry or = (Map.Entry) iter.next();
                System.out.println(or.getKey() + " : " + or.getValue());
            }

            System.out.println("Column Array Size " + rowColumnList.size());
        } catch (Exception e) {
            System.out.println("Query Returned no Records ! Check output console");
            log.info(String.valueOf(e.getStackTrace()));
        }
        return rowColumnList;
    }

    /**
     * This is a Work Around
     *
     * @param hsc
     * @return
     * @throws SQLException
     */
    public Map<String, String> getRequestingProviderforHscIdFromDb(String hsc) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement(" select * from HSC_prov where hsc_id='" + hsc + "'");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> gethscsrvcdetailsFromDb(String hsc) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement(" select * from HSC_SRVC_NON_FACL where hsc_id='" + hsc + "'");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public List<String> preferredregimenvalue() throws SQLException {
        List<String> preferredregimenvalue = new ArrayList<String>();
        ResultSet rs = null;
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("  select distinct rtv.treatmentRegimenName from regimentraversalview rtv, trt_rgmn_ver_proc trt where rtv.diseaseTraversalID=1 and rtv.treatmentGuidelinePrefRgmnInd=1 and rtv.treatmentRegimenVersionID=trt.trt_rgmn_ver_id");
        rs = this.execQuery(fetchMemberInfo);
        while (rs.next()) {
            preferredregimenvalue.add(rs.getString(1));
        }
        return preferredregimenvalue;

    }

    public List<String> nonpreferredregimenvalue() throws SQLException {
        List<String> preferredregimenvalue = new ArrayList<String>();
        ResultSet rs = null;
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("  select distinct rtv.treatmentRegimenName from regimentraversalview rtv, trt_rgmn_ver_proc trt where rtv.diseaseTraversalID=1 and rtv.treatmentGuidelinePrefRgmnInd=0 and rtv.treatmentRegimenVersionID=trt.trt_rgmn_ver_id");
        rs = this.execQuery(fetchMemberInfo);
        while (rs.next()) {
            preferredregimenvalue.add(rs.getString(1));
        }
        return preferredregimenvalue;

    }


    /**
     * This is a work around
     *
     * @param hsc
     * @return
     * @throws SQLException
     */
    public Map<String, String> getMemberInformationforHscIdFromDb(String hsc) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement(" select * from HSC_prov  where hsc_id='" + hsc + "'");
        return this.getMemberInfo(fetchMemberInfo);
    }

    /**
     * This is a Workaround
     *
     * @param lastName
     * @param dateOfBirth
     * @return
     * @throws SQLException
     */
    public Map<String, String> getHscIdFromDb(String lastName, String dateOfBirth) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        dateOfBirth = convertDateOfBirthToDB(dateOfBirth);
        fetchMemberInfo = this.connect.prepareStatement("select hsc_id from HSC where creat_user_id ='ADTST12725' and mbr_id in (select mbr_id from mbr where lst_nm='" + lastName + "' and bth_dt='" + dateOfBirth + "' order by creat_dttm desc ) order by creat_dttm desc limit 1");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> getHscId() throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("select hsc_id from HSC where creat_user_id ='ADTST12725' order by creat_dttm desc");
        return this.getMemberInfo(fetchMemberInfo);
    }

    private String convertDateOfBirthToDB(String dateOfBirth) {
        String resultDateOfBirth;
        String[] result = dateOfBirth.split("-");
        resultDateOfBirth = result[2] + "-" + result[0] + "-" + result[1];
        return resultDateOfBirth;
    }

    /**
     * This is a Work Around
     *
     * @param hsc
     * @return
     * @throws SQLException
     */
    public Map<String, String> getRequestDetailsforHscIdFromDb(String hsc, String hsc_atr_typ_id) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement(" select * from HSC_ATR where hsc_id='" + hsc + "'" + " and  hsc_atr_typ_id='" + hsc_atr_typ_id + "'");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> hscidfromDB(String hsc, String hsc_atr_typ_id) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement(" select * from HSC_ATR where hsc_id='" + hsc + "'" + " and  hsc_atr_typ_id='" + hsc_atr_typ_id + "'");
        return this.getMemberInfo(fetchMemberInfo);
    }


    /**
     * This is a Work Around
     *
     * @param hsc
     * @return
     * @throws SQLException
     */
    public Map<String, String> getServiceDetailsInitialDiagnosisDateforHscIdFromDb(String hsc) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement(" select hsc_atr_val from HSC_ATR where hsc_id='" + hsc + "'" + " and  hsc_atr_typ_id='3'");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> getServiceDetailsAnticipatedTreatmentStartDateforHscIdFromDb(String hsc) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement(" select * from HSC_SRVC_NON_FACL where hsc_id='" + hsc + "'");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> getServiceDetailsforHscIdFromDb(String hsc) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement(" select * from HSC_SRVC_NON_FACL where hsc_id='" + hsc + "'");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> getServiceDetailsICDCodeforHscIdFromDb(String hsc) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement(" select * from hsc_diag where hsc_id='" + hsc + "'");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> getClinicalDetailsPrimaryCancerforHscIdFromDb(String hsc) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement(" select * from ref where ref_nm='diseaseType' and ref_cd in (select  hsc_atr_val from hsc_atr where hsc_id='" + hsc + "' and hsc_atr_typ_id = '4')");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> getClinicalDetailsChemoDiseaseforHscIdFromDb(String hsc, String hsc_atr_typ_id) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement(" select * from hsc_atr where hsc_id='" + hsc + "' and hsc_atr_typ_id = '" + hsc_atr_typ_id + "'");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> getClinicalDetailsInitialOrChangeTreatmentforHscIdFromDb(String hsc, String hsc_atr_typ_id) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("select * from ref where ref_nm ='treatmentChangeStatus' and ref_cd in (select  hsc_atr_val from hsc_atr where hsc_id='" + hsc + "' and hsc_atr_typ_id = '" + hsc_atr_typ_id + "')");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> asmtResponse(String asmt) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("select * from asmt_rspn_cho where asmt_id= '" + asmt + "'");
        return this.getMemberInfo(fetchMemberInfo);
    }


}

