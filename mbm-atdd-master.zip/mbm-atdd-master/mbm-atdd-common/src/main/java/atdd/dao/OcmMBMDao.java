package atdd.dao;


import atdd.test.shared.BaseCucumber;
import atdd.test.shared.Globals;
import io.restassured.response.Response;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Assert;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;

import static io.restassured.RestAssured.get;

@Deprecated
public class OcmMBMDao {

    protected static List<String> appUrlAndDBInfo;
    private static OcmMBMDao dao;
    private static Logger log = Logger.getLogger(OcmMBMDao.class.getName());
    private static String dbUrl;
    private static String dbUser;
    private static String dbPass;
    private Connection connect = null;
    private String authHscId = null;
    private String columnValue;
    private String SRN = "";
    Globals gv;

    private OcmMBMDao() throws SQLException {
        gv = BaseCucumber.gv;

        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            log.error(e.getMessage());
            Assert.fail("Cannot find the driver class " + e.getMessage());
        }

        Properties pros = System.getProperties();
        pros.list(System.out);

        dbUrl = System.getenv("DatabaseURL");
        dbUser = System.getenv("DatabaseUser");
        dbPass = System.getenv("DatabasePass");

        String dbUrlConfig = BaseCucumber.Config.getProperty("jdbcLocal");
        String dbUserConfig = BaseCucumber.Config.getProperty("dbUser");
        String dbPassConfig = BaseCucumber.Config.getProperty("dbPass");

        String local = BaseCucumber.Config.getProperty("localTest").trim();
        boolean localTest = Boolean.parseBoolean(local);
        log.warn("Localtest flag is: " + localTest);

        if (dbPass == null) dbPass = "null";
        if (dbPassConfig == null) dbPassConfig = "null";

        log.warn("System data: " + dbUrl + ", " + dbUser + ", " + dbPass.length());
        log.warn("Config data: " + dbUrlConfig + ", " + dbUserConfig + ", " + dbPassConfig.length());

        //If nothing form Jenkins
        if (dbUrl == null || localTest) {
            log.warn("No System data. Taking DB URL from config.");
            dbUrl = dbUrlConfig;
        }
        if (dbUser == null || localTest) {
            log.warn("No System data. Taking DB User from config.");
            dbUser = dbUserConfig;
        }
        if (dbPass == null || localTest) {
            log.warn("No System data. Taking DB User Pass from config.");
            dbPass = dbPassConfig;
        }

        log.warn("Connect with: " + dbUrl + ", " + dbUser + ", " + dbPass.length());

        connect = DriverManager.getConnection(dbUrl, dbUser, dbPass);

    }

    public static OcmMBMDao getDao() throws SQLException {
        if (dao == null) {
            dao = new OcmMBMDao();
        }

        return dao;
    }

    public static String convertDateOfBirthToDB(String dateOfBirth) {
        String resultDateOfBirth;
        String[] result = dateOfBirth.split("-");
        resultDateOfBirth = result[2] + "-" + result[0] + "-" + result[1];
        return resultDateOfBirth;
    }

    public void close() throws SQLException {
        connect.close();
    }

    private void execUpdate(PreparedStatement st) throws SQLException {
        st.executeUpdate();
    }

    private ResultSet execQuery(PreparedStatement st) throws SQLException {
        return st.executeQuery();
    }

    public Map<String, String> getMapOfRecords(String query) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement(query);
        return this.getMemberInfo(fetchMemberInfo);
    }

    //adding generic method to get member info for code maintainability (avoid duplicate code)
    private Map<String, String> getMemberInfo(PreparedStatement query) throws SQLException {
        Map<String, String> memberInfo = new HashMap<String, String>();
        ResultSet rs = execQuery(query);//
        //its for future purpose select M.FST_NM,M.LST_NM, DATE_FORMAT(M.BTH_DT,'%m-%d-%Y') as DOB,ID.MBR_ID_TXT , C.POL_NBR from MBR M, MBR_ID ID, MBR_COV C where M.MBR_ID=ID.MBR_ID  and M.MBR_ID=C.MBR_ID and M.LST_NM is not null and
        // M.BTH_DT is not null and ID.MBR_ID_TXT is not null and C.POL_NBR is not null AND M.mbr_id in (select mbr_id from MBR_ID  where mbr_id_typ_id = '1' order by creat_dttm Desc) --.mbr_id_txt
        rs.next();
        ResultSetMetaData rsmd = rs.getMetaData();
        int cc = rsmd.getColumnCount();

        for (int i = 1; i <= cc; i++) {
            System.out.println("Column name:" + rsmd.getColumnName(i) + "------" + rs.getString(i));
            memberInfo.put(rsmd.getColumnName(i), rs.getString(i));

        }
        return memberInfo;
    }

    private List<String> getResultSetList(PreparedStatement query) throws SQLException {
        List<String> memberInfo = new ArrayList<String>();
        ResultSet rs = execQuery(query);//
        //its for future purpose select M.FST_NM,M.LST_NM, DATE_FORMAT(M.BTH_DT,'%m-%d-%Y') as DOB,ID.MBR_ID_TXT , C.POL_NBR from MBR M, MBR_ID ID, MBR_COV C where M.MBR_ID=ID.MBR_ID  and M.MBR_ID=C.MBR_ID and M.LST_NM is not null and
        // M.BTH_DT is not null and ID.MBR_ID_TXT is not null and C.POL_NBR is not null AND M.mbr_id in (select mbr_id from MBR_ID  where mbr_id_typ_id = '1' order by creat_dttm Desc) --.mbr_id_txt
        rs.next();
        ResultSetMetaData rsmd = rs.getMetaData();
        int cc = rsmd.getColumnCount();
        for (int i = 1; i <= cc; i++) {

            memberInfo.add(rs.getString(i));

        }
        return memberInfo;
    }

    private Map<String, ArrayList<String>> getMemberInfoMultipleRows(PreparedStatement query) throws SQLException {
        Map<String, ArrayList<String>> memberInfo = new HashMap<String, ArrayList<String>>();
        ResultSet rs = execQuery(query);
        ResultSetMetaData rsmd = null;
        int rc;
        int cc;

        try {
            rs.last();
            rc = rs.getRow();
            rsmd = rs.getMetaData();
            cc = rsmd.getColumnCount();
            rs.beforeFirst();
            System.out.println("Row Count :" + rc);
            System.out.println("Column Count :" + cc);
            int rows = 0;
            for (int i = 1; i <= cc; i++) {
                ArrayList<String> ColumnList = new ArrayList();
                rs.beforeFirst();
                while (rs.next()) {
                    //System.out.println("Column Type : "+ i +" --- "+ rs.getString(i));
                    //Column.put(rsmd.getColumnLabel(i),rs.getString(i));
                    ColumnList.add(rs.getString(i));
                }// While loop
                memberInfo.put(rsmd.getColumnLabel(i), ColumnList);
            }
            Iterator iter = memberInfo.entrySet().iterator();
            while (iter.hasNext()) {
                Map.Entry or = (Map.Entry) iter.next();
                System.out.println(or.getKey() + " : " + or.getValue());
            } // End of WHILE

            System.out.println("Column Array Size " + memberInfo.size());
        }// try
        catch (Exception e) {
            System.out.println("Query Returned no Records ! Check output console");
            e.printStackTrace();
        }
        return memberInfo;
    }


    public Map<String, String> getColumnsAndDatatypes(String table) throws SQLException {
        ResultSet rs = null;
        PreparedStatement fetchData = null;
        HashMap columnAndDatatypes = null;
        try {
            fetchData = this.connect.prepareStatement("describe " + table);
//            fetchData.setString(1, table);
            columnAndDatatypes = new HashMap();
            rs = this.execQuery(fetchData);

            while (rs.next()) {
//                System.out.println("Value 1:" + rs.getString(1).trim().toUpperCase() + "------ Value 2:" + rs.getString(2).trim().toUpperCase());
                columnAndDatatypes.put(rs.getString(1).trim().toUpperCase(), rs.getString(2).trim().toUpperCase());
            }

        } catch (SQLException e1) {
            log.info(String.valueOf(e1.getStackTrace()));
        } finally {
            if (rs != null) {
                rs.close();
            }

            if (fetchData != null) {
                fetchData.close();
            }
        }
        return columnAndDatatypes;
    }

    public Map<String, String> getColumnsAndKeys(String table) throws SQLException {
        ResultSet rs = null;
        PreparedStatement fetchData = null;

        HashMap columnsAndKeys;
        try {
            fetchData = this.connect.prepareStatement("describe " + table);

//            fetchData = this.connect.prepareStatement("describe ?");
//            fetchData.setString(1, table);
            columnsAndKeys = new HashMap();
            rs = this.execQuery(fetchData);

            while (rs.next()) {
                columnsAndKeys.put(rs.getString(1).trim().toUpperCase(), rs.getString(4).trim().toUpperCase());
            }
        } finally {
            if (fetchData != null) {
                fetchData.close();
            }

            if (rs != null) {
                rs.close();
            }

        }

        return columnsAndKeys;
    }

    public Map<String, String> getColumnsAndNullable(String table) throws SQLException {
        ResultSet rs = null;
        PreparedStatement fetchData = null;

        Map<String, String> columnAndNullable = new HashMap();
        try {
            fetchData = this.connect.prepareStatement("describe " + table);
            rs = this.execQuery(fetchData);

            while (rs.next()) {
                columnAndNullable.put(rs.getString(1).trim().toUpperCase(), rs.getString(3).trim().toUpperCase());
            }
        } finally {
            if (rs != null) {
                rs.close();
            }

            if (fetchData != null) {
                fetchData.close();
            }

        }

        return columnAndNullable;
    }

    public Map<String, String> getRequestingProvDetails(String fstNM, String lstNM, String DOB) throws SQLException {
        Map<String, String> provInfo = new HashMap<String, String>();
        PreparedStatement fetchData;
        String query = "select fst_nm as Provider_First_Name, lst_nm as Provider_Last_Name,prov_npi as Provider_NPI, fed_tax_id as Provider_TIN ,adr_ln_1_txt as Adr1, adr_ln_2_txt as Adr2 , cty_nm as City ,st_cd as State , zip_cd_txt as Zip , zip_sufx_cd_txt as Zip_cd\n" +
                " email_adr_txt as Prov_Email,sec_tel_nbr as Prov_Cell_Phn from hsc_prov where hsc_id = (select hsc_id from  hsc where mbr_id in (select mbr_id from mbr where fst_nm='" + fstNM + "' and lst_nm='" + lstNM + "'  order by creat_dttm Desc )order by creat_dttm Desc limit 1)";
        fetchData = this.connect.prepareStatement(query);
        ResultSet rs = execQuery(fetchData);
        rs.next();
        ResultSetMetaData rsmd = rs.getMetaData();
        int cc = rsmd.getColumnCount();
        for (int i = 1; i <= cc; i++) {
            System.out.println("Column name:" + rsmd.getColumnName(i) + "----------- Column value:" + rs.getString(i));
            provInfo.put(rsmd.getColumnName(i), rs.getString(i));
        }
        return provInfo;

    }

    public Map<String, String> getRequestingProvDetails(String hscID) throws SQLException {
        Map<String, String> provInfo = new HashMap<String, String>();
        PreparedStatement fetchData;
        String query = "select fst_nm as Provider_First_Name, lst_nm as Provider_Last_Name,prov_npi as Provider_NPI, fed_tax_id as Provider_TIN ,adr_ln_1_txt as Adr1, adr_ln_2_txt as Adr2 , cty_nm as City ,st_cd as State , zip_cd_txt as Zip , zip_sufx_cd_txt as Zip_cd\n" +
                " email_adr_txt as Prov_Email,sec_tel_nbr as Prov_Cell_Phn from hsc_prov where hsc_id ='" + hscID + "'";

        fetchData = this.connect.prepareStatement(query);
        ResultSet rs = execQuery(fetchData);
        rs.next();
        ResultSetMetaData rsmd = rs.getMetaData();
        int cc = rsmd.getColumnCount();
        for (int i = 1; i <= cc; i++) {
            System.out.println("Column name:" + rsmd.getColumnName(i) + "----------- Column value:" + rs.getString(i));
            provInfo.put(rsmd.getColumnName(i), rs.getString(i));
            System.out.println("Column name:" + rsmd.getColumnName(i) + "----------- Column value:" + rs.getString(i));
            provInfo.put(rsmd.getColumnName(i), rs.getString(i));

        }
        return provInfo;
    }

    public String getRequestingProvRoleType(String fstNM, String lstNM, String DOB) throws SQLException {
        String provInfo = null;
        PreparedStatement fetchData;
        String query = "select prov_role_typ_id  from HSC_PROV_ROLE where hsc_id = (select hsc_id from  hsc where mbr_id in (select mbr_id from mbr where fst_nm='" + fstNM + "' and lst_nm='" + lstNM + "'  order by creat_dttm Desc )order by creat_dttm Desc limit 1)";
        fetchData = this.connect.prepareStatement(query);
        ResultSet rs = execQuery(fetchData);
        rs.next();
        ResultSetMetaData rsmd = rs.getMetaData();
        int cc = rsmd.getColumnCount();
        for (int i = 1; i <= cc; i++) {
            System.out.println("Column name:" + rsmd.getColumnName(i) + "----------- Column value:" + rs.getString(i));
            provInfo = rs.getString(i);
        }
        return provInfo;
    }

    public Map<String, String> validateThedbColumns(String tableName) throws SQLException, ClassNotFoundException {
        String Query1 = null;
        Map<String, String> dataBaseColumns;
        if (tableName.equals("MBR")) {
            Query1 = " select mbr_id,fst_nm ,lst_nm,bth_dt,gdr_cd,rel_typ_id,chg_dttm  from " + tableName + " order by chg_dttm desc";

        } else if (tableName.equals("MBR_ADR")) {
            Query1 = "select mbr_id,adr_typ_id,adr_ln_1_txt,adr_ln_2_txt,cty_nm,st_cd,zip_cd_txt,chg_dttm from " + tableName + " order by chg_dttm desc";
        } else if (tableName.equals("HSC")) {
            Query1 = "select hsc_id,hsc_sts_typ_id,hsc_sts_rsn_typ_id,mbr_id,Srvc_setting_typ_id,chg_dttm from " + tableName + " order by chg_dttm desc";
        } else if (tableName.equals("HSC_PROV")) {
            Query1 = "select fst_nm,lst_nm,adr_ln_1_txt,adr_ln_2_txt,cty_nm,st_cd,zip_cd_txt,zip_sufx_cd_txt,prov_npi,fed_tax_id,chg_dttm from " + tableName + " order by chg_dttm desc";

        } else if (tableName.equals("HSC_CMPNT_STS")) {

            Query1 = "select hsc_cmpnt_sts_typ_id from " + tableName + " order by chg_dttm desc";

        } else {
            Assert.fail("Table name not matched");
        }
        dataBaseColumns = returnMaplistSingleColumnValues(Query1);

        return dataBaseColumns;
    }

    // Abhinav
    public String validateThedbforSingleColumns(String tableName, String column, String TIN) throws SQLException, ClassNotFoundException {
        String Query1 = null;
        Map<String, String> dataBaseColumns;

        if (tableName.equals("HSC_PROV")) {
            Query1 = "select " + column + " from " + tableName + " where fed_tax_id='" + TIN + "' order by chg_dttm desc";

        } else {
            Assert.fail("Table name not matched");
        }
        dataBaseColumns = returnMaplistSingleColumnValues(Query1);
        columnValue = returnMaplistSingleColumnValues(Query1).get(column);
        //    System.out.println(columnValue);
        return columnValue;
    }

    public List<String> returnMultipleRowValue(String QUERY) throws SQLException {
        PreparedStatement query = connect.prepareStatement(QUERY);
        ResultSet rs = execQuery(query);
        List<String> value = new ArrayList();
        while (rs.next()) {
            value.add(rs.getString(1));
        }
        return value;
    }

    public void validatesColumnValuesWithDb(List<String> coulumnValues, String tableName) throws SQLException {
        String Query = "select " + " from " + tableName;
        List<String> QueryResult = returnMultipleRowValue(Query);
        for (int i = 0; i < QueryResult.size(); ++i) {
            String[] column = coulumnValues.get(i).split("\"");
            Assert.assertEquals(QueryResult.get(i), column[1]);
        }

    }

    public Map<String, String> returnMaplistSingleColumnValues(String sqlQuery) throws SQLException {
        ResultSet rs = null;
        int rc;
        int cc;
        Map<String, String> rowColumnList = new HashMap<String, String>();
        ResultSetMetaData rsmd;
        try {
            PreparedStatement query = connect.prepareStatement(sqlQuery);
            rs = execQuery(query);
            rs.last();
            rc = rs.getRow();
            rsmd = rs.getMetaData();
            cc = rsmd.getColumnCount();
            rs.beforeFirst();
            System.out.println("Row Count :" + rc);
            System.out.println("Column Count :" + cc);
            int rows = 0;
            for (int i = 1; i <= cc; i++) {
                rs.beforeFirst();
                while (rs.next()) {
                    rowColumnList.put(rsmd.getColumnLabel(i), rs.getString(i));
                }
            }
            Iterator iter = rowColumnList.entrySet().iterator();
            while (iter.hasNext()) {
                Map.Entry or = (Map.Entry) iter.next();
                System.out.println(or.getKey() + " : " + or.getValue());
            }

            System.out.println("Column Array Size " + rowColumnList.size());
        } catch (Exception e) {
            System.out.println("Query Returned no Records ! Check output console");
            log.info(String.valueOf(e.getStackTrace()));
        }
        return rowColumnList;
    }

    public Map<String, String> getRequestingProviderforHscIdFromDb(String hsc) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement(" select * from HSC_prov where hsc_id='" + hsc + "'");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> gethscsrvcdetailsFromDb(String hsc) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement(" select * from HSC_SRVC_NON_FACL where hsc_id='" + hsc + "'");
        System.out.println("hsc id " + hsc);
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> hscdb(String hsc) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement(" select * from HSC where hsc_id='" + hsc + "'");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public List<String> preferredregimenvalue() throws SQLException {
        List<String> preferredregimenvalue = new ArrayList<String>();
        ResultSet rs = null;
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("  select distinct rtv.treatmentRegimenName from regimentraversalview rtv, trt_rgmn_ver_proc trt where rtv.diseaseTraversalID=1 and rtv.treatmentGuidelinePrefRgmnInd=1 and rtv.treatmentRegimenVersionID=trt.trt_rgmn_ver_id");
        rs = this.execQuery(fetchMemberInfo);
        while (rs.next()) {
            preferredregimenvalue.add(rs.getString(1));
        }
        return preferredregimenvalue;

    }

    public List<String> drugCodeRefValues() throws SQLException {
        List<String> drugCodeRefValue = new ArrayList<String>();
        ResultSet rs = null;
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement(" select ref_desc from ref where ref_nm = 'medicationAdminRouteType' and ref_cd in (44,01,03,04,16,48,26,50,46,25,49,02)");
        rs = this.execQuery(fetchMemberInfo);
        while (rs.next()) {
            drugCodeRefValue.add(rs.getString(1));
        }
        return drugCodeRefValue;

    }

    public List<String> nonpreferredregimenvalue() throws SQLException {
        List<String> preferredregimenvalue = new ArrayList<String>();
        ResultSet rs = null;
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("  select distinct rtv.treatmentRegimenName from regimentraversalview rtv, trt_rgmn_ver_proc trt where rtv.diseaseTraversalID=1 and rtv.treatmentGuidelinePrefRgmnInd=0 and rtv.treatmentRegimenVersionID=trt.trt_rgmn_ver_id");
        rs = this.execQuery(fetchMemberInfo);
        while (rs.next()) {
            preferredregimenvalue.add(rs.getString(1));
        }
        return preferredregimenvalue;

    }

    /**
     * This is a work around
     *
     * @param hsc
     * @return
     * @throws SQLException
     */
    public Map<String, String> getMemberInformationforHscIdFromDb(String hsc) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement(" select * from HSC_prov  where hsc_id='" + hsc + "'");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> getFollowUpContactHscIdFromDb(String hsc) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement(" select * from HSC_FLWUP_CNTC  where hsc_id='" + hsc + "'");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> getHscIdFromDb(String userName, String lastName, String dateOfBirth) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("select hsc.hsc_id, mbr.lst_nm, mbr.bth_dt\n" +
                "from HSC hsc\n" +
                "join mbr mbr\n" +
                "on hsc.mbr_id = mbr.mbr_id\n" +
                "where hsc.creat_user_id  ='" + userName + "' and mbr.lst_nm='" + lastName + "' and mbr.bth_dt='" + dateOfBirth + "'\n" +
                "order by mbr.creat_dttm desc\n" +
                "limit 1");
        return this.getMemberInfo(fetchMemberInfo);
    }





    public Map<String, String> getVendorCaseId(String caseId) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("select vend_cse_id from hsc where pri_srvc_ref_nbr = '" + caseId + "' or vend_cse_id = '" + caseId + "';");
        return this.getMemberInfo(fetchMemberInfo);
    }


    public List<String> getHscStatusFromDb(String HScId) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("SELECT\n" +
                "  a.hsc_id,\n" +
                "  a.creat_dttm,\n" +
                "  a.creat_user_id,\n" +
                "  a.chg_dttm,\n" +
                "  a.chg_user_id,\n" +
                "  a.hsc_sts_rsn_typ_id,\n" +
                "  a.hsc_sts_typ_id,\n" +
                "  b.ref_desc AS statusReasonType,\n" +
                "  c.ref_desc AS statusType\n" +
                "FROM hsc a\n" +
                "LEFT JOIN\n" +
                "(\n" +
                "  SELECT ref_desc, ref_cd, ref_nm\n" +
                "  FROM cust_ref\n" +
                "  WHERE ref_nm = 'hscStatusReasonType'\n" +
                ") b ON (a.hsc_sts_rsn_typ_id = b.ref_cd )\n" +
                "LEFT JOIN\n" +
                "(\n" +
                "  SELECT ref_desc, ref_cd, ref_nm\n" +
                "  FROM cust_ref\n" +
                "  WHERE ref_nm = 'hscStatusType'\n" +
                ") c ON (a.hsc_sts_typ_id = c.ref_cd)\n" +
                "WHERE hsc_id = '" + HScId + "'");
        return this.getResultSetList(fetchMemberInfo);
    }


    public List<String> getHscStartDateAndEndateFromDb(String HScId) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("Select hsnr.srvc_strt_dt,hsnr.srvc_end_dt  " +
                "From hsc_srvc_non_facl hsnr \n" +
                "join  hsc h\n" +
                "ON hsnr.hsc_id = h.hsc_id\n" +
                "\n" +
                "WHERE h.pri_srvc_ref_nbr = '" + HScId + "'  or h.hsc_id = '" + HScId + "'");
        return this.getResultSetList(fetchMemberInfo);
    }

    public Map<String, String> getHscIdForUSerFromDb(String lastName, String dateOfBirth, String userID) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        dateOfBirth = convertDateOfBirthToDB(dateOfBirth);
        fetchMemberInfo = this.connect.prepareStatement("select hsc_id from HSC where creat_user_id ='" + userID + "' and mbr_id in (select mbr_id from mbr where lst_nm='" + lastName + "' and bth_dt='" + dateOfBirth + "' order by creat_dttm desc ) order by creat_dttm desc limit 1");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> getHscId() throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("select hsc_id from HSC where creat_user_id ='ADTST12725' order by creat_dttm desc");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public String getRegimenDuration(String authorizationNumber) throws SQLException {
        String regimenDuration = null;
        PreparedStatement fetchData;
        String query = "select auth_dur_mo_cnt from TRT_RGMN_ver where trt_rgmn_id =(select req_trt_rgmn_ver_id from hsc where pri_srvc_ref_nbr = '" + authorizationNumber + "' order by creat_dttm desc ) order by creat_dttm desc limit 1";
        fetchData = this.connect.prepareStatement(query);
        ResultSet rs = execQuery(fetchData);
        rs.next();
        ResultSetMetaData rsmd = rs.getMetaData();
        int cc = rsmd.getColumnCount();
        for (int i = 1; i <= cc; i++) {
            System.out.println("Column name:" + rsmd.getColumnName(i) + "----------- Column value:" + rs.getString(i));
            regimenDuration = rs.getString(i);
        }
        return regimenDuration;
    }

    //Pavan method for mapping sheet
    public String getrequestLogtable() throws SQLException {
        String requestPayload = null;
        PreparedStatement fetchData;
        String query = "select ws_req_payload from SYS_WEB_SRVC_LOG where ws_typ_id = 'authSvc' and sys_ws_log_id = '28051' order by creat_dttm desc";

        fetchData = this.connect.prepareStatement(query);
        ResultSet rs = execQuery(fetchData);
        rs.next();
        ResultSetMetaData rsmd = rs.getMetaData();
        int cc = rsmd.getColumnCount();
        for (int i = 1; i <= cc; i++) {
            System.out.println("Column name:" + rsmd.getColumnName(i) + "----------- Column value:" + rs.getString(i));
            requestPayload = rs.getString(i);
        }
        return requestPayload;
    }

    public Map<String, String> getRequestDetailsforHscIdFromDb(String hsc, String hsc_atr_typ_id) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement(" select * from HSC_ATR where hsc_id='" + hsc + "'" + " and  hsc_atr_typ_id='" + hsc_atr_typ_id + "'");
        System.out.println("Query:" + "select * from HSC_ATR where hsc_id='" + hsc + "'" + " and  hsc_atr_typ_id='" + hsc_atr_typ_id + "'");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> hscidfromDB(String hsc, String hsc_atr_typ_id) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement(" select * from HSC_ATR where hsc_id='" + hsc + "'" + " and  hsc_atr_typ_id='" + hsc_atr_typ_id + "'");
        return this.getMemberInfo(fetchMemberInfo);
    }


    /**
     * This is a Work Around
     *
     * @param hsc
     * @return
     * @throws SQLException
     */
    public Map<String, String> getServiceDetailsInitialDiagnosisDateforHscIdFromDb(String hsc) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement(" select hsc_atr_val from HSC_ATR where hsc_id='" + hsc + "'" + " and  hsc_atr_typ_id='3'");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> getServiceDetailsAnticipatedTreatmentStartDateforHscIdFromDb(String hsc) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement(" select * from HSC_SRVC_NON_FACL where hsc_id='" + hsc + "'");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> getServiceDetailsforHscIdFromDb(String hsc) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement(" select * from HSC_SRVC_NON_FACL where hsc_id='" + hsc + "'");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> getServiceDetailsforHscIdFromDb1(String hsc, String serviceDescriptionText) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement(" select * from HSC_SRVC_DECN where hsc_id='" + hsc + "' and srvc_seq_nbr= '" + serviceDescriptionText + "'");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> getServiceDetailsforHscIdFromDb3(String hsc, String serviceDescription) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement(" select * from HSC_SRVC where hsc_id='" + hsc + "' and srvc_seq_nbr= '" + serviceDescription + "'");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> getServiceDetailsforHscIdFromDb2(String hsc, String serviceDescriptionText) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement(" select * from HSC_SRVC_NON_FACL where hsc_id='" + hsc + "' and srvc_seq_nbr= '" + serviceDescriptionText + "'");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> getHscProviderDetailsFromDb2(String hsc, String ProviderRoles) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement(" select * from HSC_PROV_ROLE where hsc_id='" + hsc + "' and prov_seq_nbr= '" + ProviderRoles + "'");
        return this.getMemberInfo(fetchMemberInfo);
    }


    public Map<String, String> getServiceDetailsPlaceOfServiceforHscIdFromDb(String hsc) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement(" select * from ref where ref_nm ='placeOfServiceCode' and ref_cd in (select hsc_atr_val from HSC_ATR where hsc_id='" + hsc + "'" + " and  hsc_atr_typ_id='16')");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> getServiceDetailsICDCodeforHscIdFromDb(String hsc) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement(" select * from hsc_diag where hsc_id='" + hsc + "'");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> getClinicalDetailsPrimaryCancerforHscIdFromDb(String hsc) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement(" select * from ref where ref_nm='diseaseType' and ref_cd in (select  hsc_atr_val from hsc_atr where hsc_id='" + hsc + "' and hsc_atr_typ_id = '4')");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> getClinicalDetailsChemoDiseaseforHscIdFromDb(String hsc, String hsc_atr_typ_id) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement(" select * from hsc_atr where hsc_id='" + hsc + "' and hsc_atr_typ_id = '" + hsc_atr_typ_id + "'");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> getClinicalDetailsInitialOrChangeTreatmentforHscIdFromDb(String hsc, String hsc_atr_typ_id) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("select * from ref where ref_nm ='treatmentChangeStatus' and ref_cd in (select  hsc_atr_val from hsc_atr where hsc_id='" + hsc + "' and hsc_atr_typ_id = '" + hsc_atr_typ_id + "')");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> Asmtocmdb(String hsc) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        System.out.println("hsc id is" + hsc);
        fetchMemberInfo = this.connect.prepareStatement("select * from HSC_asmt where creat_user_id='ADTST12725' order by creat_dttm desc");

        return this.getMemberInfo(fetchMemberInfo);
    }


    public Map<String, String> getServicingProviderDetailsforHscIdFromDb(String hsc) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("select * from hsc_prov  where hsc_id='" + hsc + "' and prov_seq_nbr in (select prov_seq_nbr from hsc_prov_role  where hsc_id='" + hsc + "'  and prov_role_typ_id='SJ')");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> getRegimenNameforHscIdFromDb(String hsc) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("select * from TRT_RGMN where trt_rgmn_id =(select req_trt_rgmn_ver_id from hsc where hsc_id='" + hsc + "'");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> hscdeatils(String authorizationNumber) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement(" select * from HSC where pri_srvc_ref_nbr = '" + authorizationNumber + "' ");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> mbrDetails(String mbr_id) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement(" select * from mbr where mbr_id = '" + mbr_id + "' ");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> hscMbrCovDetails(String hsc_id) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement(" select * from hsc_mbr_cov where hsc_id='" + hsc_id + "' ");
        return this.getMemberInfo(fetchMemberInfo);

    }

    public Map<String, String> mbrIDDetails(String mbr_id) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement(" select * from mbr_id where mbr_id = '" + mbr_id + "' ");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> refDetails(String ref_nm, String ref_cd) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement(" select * from REF where ref_nm = '" + ref_nm + "' and ref_cd = '" + ref_cd + "' ");
        return this.getMemberInfo(fetchMemberInfo);

    }


    public Map<String, String> getAllRegimensDisplayedforDiseaseTraversal(String diseaseTraversalID) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("select r.treatmentRegimenName from regimentraversalview r where r.diseaseTraversalID='" + diseaseTraversalID + "' and r.treatmentRegimenVersionID in (select trt_rgmn_ver_id from trt_rgmn_ver_proc   where proc_cd is not null )");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> getRiskAuthDetailsforRegimenandDiseaseTraversal(String diseaseTraversalID, String regimenName) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("select rf.ref_dspl,r.growFacFebNeutroRisk,r.supportiveCareAntiEmRiskDesc,r.authDurationMonthCount from regimentraversalview r , ref rf where r.diseaseTraversalID='" + diseaseTraversalID + "'  and r.treatmentRegimenName ='" + regimenName + "' and rf.ref_nm='growFacFebNeutroRisk' and rf.ref_cd = r.growFacFebNeutroRisk");
        return this.getMemberInfo(fetchMemberInfo);
    }


    public Map<String, ArrayList<String>> getRegimenDetailsforDiseaseTraversalIDFromDb(String diseaseTraversalID) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("select r.treatmentRegimenName , r.treatmentRegimenVersionID,growFacFebNeutroRisk,supportiveCareAntiEmRiskDesc,authDurationMonthCount from regimentraversalview r where r.diseaseTraversalID='" + diseaseTraversalID + "' and r.treatmentRegimenVersionID in (select trt_rgmn_ver_id from trt_rgmn_ver_proc where proc_cd is not null )");
        return this.getMemberInfoMultipleRows(fetchMemberInfo);
    }

    public Map<String, String> getFebrileNeutropeniaRiskFromDb(String growFacFebNeutroRisk) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("select ref_dspl from ref where ref_nm='growFacFebNeutroRisk' and ref_cd='" + growFacFebNeutroRisk + "'");
        return this.getMemberInfo(fetchMemberInfo);
    }


    public Map<String, ArrayList<String>> getDrugDosageForRegimenNameAndDiseaseTraversalIDFromDb(String regimenName, String diseaseTraversalID) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("Select proc_day_per_cyc_desc from trt_rgmn_ver_proc where trt_rgmn_ver_id in(select  treatmentRegimenVersionID from regimentraversalview where treatmentRegimenName='" + regimenName + "' )");
        fetchMemberInfo = this.connect.prepareStatement("Select proc_day_per_cyc_desc from trt_rgmn_ver_proc where trt_rgmn_ver_id in(select  treatmentRegimenVersionID from regimentraversalview where treatmentRegimenName='" + regimenName + "' and diseaseTraversalID='" + diseaseTraversalID + "' )");
        return this.getMemberInfoMultipleRows(fetchMemberInfo);
    }

    public Map<String, ArrayList<String>> getDrugNameForRegimenNameAndDiseaseTraversalIDFromDb(String regimenName) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("select full_desc from hcpcs where proc_cd in(Select proc_cd from trt_rgmn_ver_proc where trt_rgmn_ver_id in (select  treatmentRegimenVersionID from regimentraversalview where  treatmentRegimenName='" + regimenName + "' ))");
        return this.getMemberInfoMultipleRows(fetchMemberInfo);
    }

    public Map<String, ArrayList<String>> getDrugCodeForRegimenNameAndDiseaseTraversalIDFromDb(String regimenName, String diseaseTraversalID) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("Select proc_cd from trt_rgmn_ver_proc where trt_rgmn_ver_id in (select  treatmentRegimenVersionID from regimentraversalview where  treatmentRegimenName='" + regimenName + "' and diseaseTraversalID='" + diseaseTraversalID + "')");
        fetchMemberInfo = this.connect.prepareStatement("Select proc_cd from trt_rgmn_ver_proc where trt_rgmn_ver_id in (select  treatmentRegimenVersionID from regimentraversalview where  treatmentRegimenName='" + regimenName + "' )");
        return this.getMemberInfoMultipleRows(fetchMemberInfo);
    }

    public Map<String, ArrayList<String>> getDrugCodeForRegimenNameFromDb(String regimenName) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("Select proc_cd from trt_rgmn_ver_proc where trt_rgmn_ver_id in (select  treatmentRegimenVersionID from regimentraversalview where  treatmentRegimenName='" + regimenName + "' ) Order by proc_rnk asc");
        return this.getMemberInfoMultipleRows(fetchMemberInfo);
    }

    public Map<String, String> getDrugDetailsForRegimenFromDb(String regimenID) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("Select proc_cd, medcn_admin_rte_typ_id,proc_day_per_cyc_desc,proc_unit_desc from trt_rgmn_ver_proc where trt_rgmn_ver_id='" + regimenID + "'");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> getDrugRouteForRegimenFromDb(String drugRoute) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("select ref_dspl from ref where ref_nm = 'medicationAdminRouteType' and  ref_cd='" + drugRoute + "' ");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> getProcCodeDescriptionFromDb(String procCode) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("select shrt_desc from hcpcs where proc_cd='" + procCode + "'");
        return this.getMemberInfo(fetchMemberInfo);
    }

//    public Map<String, String> getRegimenEmeticRiskFromDb(String hsc) throws SQLException {
//        PreparedStatement fetchMemberInfo = null;
//        fetchMemberInfo = this.connect.prepareStatement("select * from HSC_SRVC_NON_FACL order by hsc_id desc");
//        return this.getMemberInfo(fetchMemberInfo);
//    }
//
//    public Map<String, String> getRegimenAuthorizationDurationFromDb(String hsc) throws SQLException {
//        PreparedStatement fetchMemberInfo = null;
//        fetchMemberInfo = this.connect.prepareStatement("select * from HSC_SRVC where creat_user_id = 'ADTST12234' order by hsc_id desc");
//        return this.getMemberInfo(fetchMemberInfo);
//    }

    public void executeQueryForDBWhenFilteredOnTwoFields(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6) throws SQLException, IOException, ParseException {
        // Specify Columns from DB to be validated start from 0 1 2

        String[] arrOfStr1 = arg1.split(" ");
        for (String a : arrOfStr1)
            System.out.println(a);
        int lengthD = arrOfStr1.length;
        System.out.println("DB  # " + lengthD);

        String[] arrOfStr2 = arg2.split(" ");
        for (String b : arrOfStr2)
            System.out.println(b);
        int lengthS = arrOfStr2.length;
        System.out.println("Sheet  # " + lengthS);
        System.out.println("Validation of DB to Sheet has started and is in progress ");

        File xlFile = new File(System.getProperty("user.dir") + "//src//main//resources//" + arg3);
        FileInputStream fi = new FileInputStream(xlFile);
        XSSFWorkbook workbook = new XSSFWorkbook(fi);

        XSSFSheet sheet = workbook.getSheet(arg4);

        XSSFRow row = sheet.getRow(2); // update 2 for

        int rowCountSheet = 0;

        //int rowCountSheet = sheet.getLastRowNum();
        for (Row rowcntr : sheet) {
            if (rowcntr.getCell(1) != null) {
                rowCountSheet++;
            } else {
                break;
            }

        }
        int colCountSheet = row.getLastCellNum();

        System.out.println("\n rowCountSheet\t" + (rowCountSheet - 3));
        System.out.println("colCountSheet\t" + colCountSheet);
        Boolean flag = true;

        for (int i = 1; i <= rowCountSheet - 3; i++) {

            for (int j = 0; j < lengthD; j++) {
                String Sheetvalue1 = "";
                row = sheet.getRow((short) (i + 2)); // add 2 for actual
                // sheet

                int j2 = Integer.parseInt(arrOfStr2[j]) - 1;

                XSSFCell Sheetvalue = row.getCell(j2);
                if (Sheetvalue.getCellType() == 0) {
                    Sheetvalue1 = Sheetvalue.toString();
                } else {
                    Sheetvalue1 = (Sheetvalue.getStringCellValue()).trim();

                }

                ResultSet rs = null;
                PreparedStatement statement = null;
                int j1 = Integer.parseInt(arrOfStr1[j]);

                // Execute Query
                String query = "select * from " + arg4 + " where " + arg5 + " = '" + row.getCell(1).getStringCellValue() + "'  and " + arg6 + "='" + row.getCell(3).getStringCellValue() + "'";
                //System.out.println(query);
                statement = this.connect.prepareStatement(query);
                rs = statement.executeQuery(query);
                String DBvalue = "";
                while (rs.next()) {
                    Object dbValue = rs.getObject(j1);
                    if (dbValue == null) {
                        DBvalue = "null";
                    } else if (dbValue instanceof Timestamp) {
                        SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
                        Date dbDate = rs.getDate(j1);
                        DBvalue = formatter.format(dbDate);
                        // DBvalue = TestUtilsMBM.sqlToUSDateFormat(dbDate);
                    } else {
                        DBvalue = rs.getString(j1);
                    }


                }
                if (DBvalue.equals(Sheetvalue1)) {
                    displayResult(i, Sheetvalue1, j2, query, DBvalue, true);

                } else {
                    displayResult(i, Sheetvalue1, j2, query, DBvalue, false);
                    flag = false;
                }
            }
        }
        if (flag.equals(false)) {
            Assert.fail();
        }
    }

    private void displayResult(int i, String sheetvalue1, int j2, String query, String DBvalue, boolean isPassed) {
        if (isPassed) {
            System.out.println("Sheet row" + (i + 3) + " \tCol" + (j2 + 1) + "\t Matched - Passed\t");
        } else {
            System.out.println("Sheet row" + (i + 3) + " \tCol" + (j2 + 1) + "\t Not Matched - Failed\t");
        }
        System.out.println(query);
        System.out.println("DB query Result Value: " + DBvalue);
        System.out.println("Given Sheet Value    : " + sheetvalue1 + "\n");
    }

    public void executeQueryForDBWhenFilteredOnFiveFields(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6, String arg7, String arg8, String arg9) throws SQLException, IOException, ParseException {
        // Specify Columns from DB to be validated start from 0 1 2

        String[] arrOfStr1 = arg1.split(" ");
        for (String a : arrOfStr1)
            System.out.println(a);
        int lengthD = arrOfStr1.length;
        System.out.println("DB  # " + lengthD);

        String[] arrOfStr2 = arg2.split(" ");
        for (String b : arrOfStr2)
            System.out.println(b);
        int lengthS = arrOfStr2.length;
        System.out.println("Sheet  # " + lengthS);
        System.out.println("Validation of DB to Sheet has started and is in progress ");

        File xlFile = new File(System.getProperty("user.dir") + "//src//main//resources//" + arg3);
        FileInputStream fi = new FileInputStream(xlFile);
        XSSFWorkbook workbook = new XSSFWorkbook(fi);

        XSSFSheet sheet = workbook.getSheet(arg4);

        XSSFRow row = sheet.getRow(2); // update 2 for

        int rowCountSheet = 0;

        //int rowCountSheet = sheet.getLastRowNum();
        for (Row rowcntr : sheet) {
            if (rowcntr.getCell(1) != null) {
                rowCountSheet++;
            } else {
                break;
            }

        }
        int colCountSheet = row.getLastCellNum();

        System.out.println("\n rowCountSheet\t" + (rowCountSheet - 3));
        System.out.println("colCountSheet\t" + colCountSheet);
        Boolean flag = true;

        for (int i = 1; i <= rowCountSheet - 3; i++) {

            for (int j = 0; j < lengthD; j++) {
                String Sheetvalue1 = "";
                row = sheet.getRow((short) (i + 2)); // add 2 for actual
                // sheet

                int j2 = Integer.parseInt(arrOfStr2[j]) - 1;

                XSSFCell Sheetvalue = row.getCell(j2);
                if (Sheetvalue.getCellType() == 0) {

                    Sheetvalue1 = Sheetvalue.toString();

                } else {
                    Sheetvalue1 = (Sheetvalue.getStringCellValue()).trim();

                }

                ResultSet rs = null;
                PreparedStatement statement = null;
                int j1 = Integer.parseInt(arrOfStr1[j]);

                // Execute Query
                String query = "select * from " + arg4 + " where " + arg5 + "= '" + row.getCell(1).getStringCellValue() + "' and " + arg6 + "='" + row.getCell(3).getStringCellValue() + "' and " + arg7 + "='" + row.getCell(4).getStringCellValue() + "' and " + arg8 + "='" + row.getCell(5).getStringCellValue() + "' and " + arg9 + "='" + row.getCell(6).getStringCellValue() + "'";
                //System.out.println(query);
                statement = this.connect.prepareStatement(query);
                rs = statement.executeQuery(query);
                String DBvalue = "";
                while (rs.next()) {
                    //DBvalue = rs.getString(j1);


                    Object dbValue = rs.getObject(j1);
                    if (dbValue == null) {
                        DBvalue = "null";
                    } else if (dbValue instanceof Timestamp) {
                        SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
                        Date dbDate = rs.getDate(j1);
                        DBvalue = formatter.format(dbDate);
                        // DBvalue = TestUtilsMBM.sqlToUSDateFormat(dbDate);
                    } else {
                        DBvalue = rs.getString(j1);
                    }


                }
                if (DBvalue.equals(Sheetvalue1)) {
                    displayResult(i, Sheetvalue1, j2, query, DBvalue, true);

                } else {
                    displayResult(i, Sheetvalue1, j2, query, DBvalue, false);
                    flag = false;
                }


            }

        }
        if (flag.equals(false)) {
            Assert.fail();
        }
    }

    public void executeQueryForDBAndSysSetTemp(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6, String arg7, String arg8) throws SQLException, IOException, ParseException {
        // Specify Columns from DB to be validated start from 0 1 2

        String[] arrOfStr1 = arg1.split(" ");
        for (String a : arrOfStr1)
            System.out.println(a);
        int lengthD = arrOfStr1.length;
        System.out.println("DB  # " + lengthD);

        String[] arrOfStr2 = arg2.split(" ");
        for (String b : arrOfStr2)
            System.out.println(b);
        int lengthS = arrOfStr2.length;
        System.out.println("Sheet  # " + lengthS);
        System.out.println("Validation of DB to Sheet has started and is in progress ");

        File xlFile = new File(System.getProperty("user.dir") + "//src//main//resources//" + arg3);
        FileInputStream fi = new FileInputStream(xlFile);
        XSSFWorkbook workbook = new XSSFWorkbook(fi);

        XSSFSheet sheet = workbook.getSheet(arg4);

        XSSFRow row = sheet.getRow(2); // update 2 for

        int rowCountSheet = 0;

        //int rowCountSheet = sheet.getLastRowNum();
        for (Row rowcntr : sheet) {
            if (rowcntr.getCell(1) != null) {
                rowCountSheet++;
            } else {
                break;
            }

        }
        int colCountSheet = row.getLastCellNum();

        System.out.println("\n rowCountSheet\t" + (rowCountSheet - 3));
        System.out.println("colCountSheet\t" + colCountSheet);
        Boolean flag = true;

        for (int i = 1; i <= rowCountSheet - 3; i++) {

            for (int j = 0; j < lengthD; j++) {
                String Sheetvalue1 = "";
                row = sheet.getRow((short) (i + 2)); // add 2 for actual
                // sheet

                int j2 = Integer.parseInt(arrOfStr2[j]) - 1;

                XSSFCell Sheetvalue = row.getCell(j2);
                if (Sheetvalue.getCellType() == 0) {

                    Sheetvalue1 = Sheetvalue.toString();

                } else {
                    Sheetvalue1 = (Sheetvalue.getStringCellValue()).trim();

                }

                ResultSet rs = null;
                PreparedStatement statement = null;
                int j1 = Integer.parseInt(arrOfStr1[j]);

                // Execute Query
                String query = "select * from " + arg4 + " where " + arg5 + "= '" + row.getCell(1).getStringCellValue() + "' and " + arg6 + "='" + row.getCell(2).getStringCellValue() + "' and " + arg7 + "='" + row.getCell(3).getStringCellValue() + "' and " + arg8 + "='" + row.getCell(4).getStringCellValue() + "'";
                //System.out.println(query);
                statement = this.connect.prepareStatement(query);
                rs = statement.executeQuery(query);
                String DBvalue = "";
                while (rs.next()) {
                    //DBvalue = rs.getString(j1);


                    Object dbValue = rs.getObject(j1);
                    if (dbValue == null) {
                        DBvalue = "null";
                    } else if (dbValue instanceof Timestamp) {
                        SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
                        Date dbDate = rs.getDate(j1);
                        DBvalue = formatter.format(dbDate);
                        // DBvalue = TestUtilsMBM.sqlToUSDateFormat(dbDate);
                    } else {
                        DBvalue = rs.getString(j1);
                    }


                }
                if (DBvalue.equals(Sheetvalue1)) {
                    displayResult(i, Sheetvalue1, j2, query, DBvalue, true);

                } else {
                    displayResult(i, Sheetvalue1, j2, query, DBvalue, false);
                    flag = false;
                }


            }

        }
        if (flag.equals(false)) {
            Assert.fail();
        }
    }


    public Map<String, String> getRegimenEmeticRiskFromDb(String hsc) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("select * from HSC_SRVC_NON_FACL order by hsc_id desc");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> getRegimenAuthorizationDurationFromDb(String hsc) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("select * from HSC_SRVC_NON_FACL order by hsc_id desc");
        return this.getMemberInfo(fetchMemberInfo);
    }


    public Map<String, String> getHSCATRFromDb(String hsc) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("select * from HSC_ATR where hsc_atr_typ_id = '20'" + "and chg_user_id = 'nreddy43'  order by hsc_id desc");
        return this.getMemberInfo(fetchMemberInfo);
    }


    public String performAuthorisationNumberSearchTakingHsc_idFromDb() throws Throwable {
        PreparedStatement fetchData = null;
        String name = BaseCucumber.Config.getProperty("userName");
        System.out.println("username" + name);
        String query = "select hsc_id from hsc_asmt where creat_user_id='ADTST12725' order by creat_dttm desc";
        System.out.println(query);
        fetchData = this.connect.prepareStatement(query);
        ResultSet rs = execQuery(fetchData);
        rs.next();
        ResultSetMetaData rsmd = rs.getMetaData();
        int cc = rsmd.getColumnCount();
        for (int i = 1; i <= cc; i++) {
            System.out.println("Column name:" + rsmd.getColumnName(i) + "----------- Column value:" + rs.getString(i));
            authHscId = rs.getString(i);
            System.out.println("info" + i + authHscId);
            System.out.println(i + rs.getString(i) + "/n");
        }
        return authHscId;

    }

    public Map<String, String> getContactDetailsforHscIdFromDb(String hsc) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("select * from hsc_flwup_cntc  where hsc_id='" + hsc + "'");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> getRegimendrugnameFromDb(String hsc) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("select * from HSC_SRVC_NON_FACL where hsc_id='" + hsc + "'");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> getRegimenJustificationFromDb(String hsc) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("select * from HSC where hsc_id='" + hsc + "'");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> getHSCFromDb() throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("select * from HSC where creat_user_id = 'ADTST12725' order by hsc_id desc");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> getHSC_SRVCFromDb() throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("select * from HSC_SRVC where creat_user_id = 'ADTST12234' order by hsc_id desc");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> getHSC_SRVC_NON_FACLFromDb() throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("select * from HSC_SRVC_NON_FACL order by hsc_id desc");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> getnewProcCode(String new_proc_id) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("select * from NEW_PROC order by new_proc_id desc");
        return this.getMemberInfo(fetchMemberInfo);
    }

//    public Map<String, String> refNameStepperStatusFromDb(String stepperstatus) throws SQLException {
//        PreparedStatement fetchMemberInfo = null;
//        fetchMemberInfo = this.connect.prepareStatement("select * from ref where ref_nm='" + stepperstatus + "'");
//        return this.getMemberInfo(fetchMemberInfo);
//    }

    public List<String> refNameStepperStatusFromDbValues(String stepperstatus) throws SQLException {


        List<String> stepperStatusValue = new ArrayList<String>();
        ResultSet rs = null;
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement(" select ref_desc from ref where ref_nm='" + stepperstatus + "'");
        rs = this.execQuery(fetchMemberInfo);
        while (rs.next()) {
            stepperStatusValue.add(rs.getString(1));
        }
        return stepperStatusValue;


    }

    public Map<String, String> refNameStepperStatusFromDb(String stepperstatus) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("select * from ref where ref_nm='" + stepperstatus + "'");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public List<String> refNameStepperLocationFromDbValues(String stepperLocation) throws SQLException {


        List<String> stepperLocationValue = new ArrayList<String>();
        ResultSet rs = null;
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement(" select ref_desc from ref where ref_nm='" + stepperLocation + "'");
        rs = this.execQuery(fetchMemberInfo);
        while (rs.next()) {
            stepperLocationValue.add(rs.getString(1));
        }
        return stepperLocationValue;


    }

    public Map<String, String> refNameStepperLocationFromDb(String stepperLocation) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("select * from ref where ref_nm='" + stepperLocation + "'");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> getHscServiceDecisionDb(String hsc) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("select * from HSC_SRVC_DECN  order by hsc_id desc");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> getHscDb(String hsc) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("select * from HSC  order by hsc_id desc");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public List<Map<String, String>> getRecordsList(String queryString) throws SQLException {
        ResultSet rs = null;
        List<Map<String, String>> resultList = new ArrayList<Map<String, String>>();
        PreparedStatement query = null;
        try {
            query = connect.prepareStatement(queryString);
            rs = execQuery(query);
            while (rs.next()) {
                Map<String, String> result = new HashMap<String, String>();
                ResultSetMetaData rsmd = rs.getMetaData();
                int cc = rsmd.getColumnCount();
                for (int i = 1; i <= cc; i++) {
                    result.put(rsmd.getColumnName(i), rs.getString(i));
                }
                resultList.add(result);
            }
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (query != null) {
                query.close();
            }
        }
        return resultList;
    }

    public Map<String, String> getValidatestheStepperStatusSavedInTheTables(String hsc, String steppercomponent) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        System.out.println("Query :" + "Select * from HSC_CMPNT_STS where hsc_id='" + hsc + "' and hsc_cmpnt_typ_id='" + steppercomponent + "'  order by hsc_id desc");
        fetchMemberInfo = this.connect.prepareStatement("Select * from HSC_CMPNT_STS where hsc_id='" + hsc + "' and hsc_cmpnt_typ_id='" + steppercomponent + "'  order by hsc_id desc");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> getstepperLocation(String stepperLocation) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        System.out.println("Query :" + "select * from ref where ref_nm = 'stepperLocation' and ref_desc='" + stepperLocation + "'");
        fetchMemberInfo = this.connect.prepareStatement("select * from ref where ref_nm = 'stepperLocation' and ref_desc='" + stepperLocation + "'");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> getstepperStatus(String stepperstatus) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        System.out.println("Query :" + "select * from ref where ref_nm = 'stepperStatus' and ref_desc='" + stepperstatus + "'");
        fetchMemberInfo = this.connect.prepareStatement("select * from ref where ref_nm = 'stepperStatus' and ref_desc='" + stepperstatus + "'");
        return this.getMemberInfo(fetchMemberInfo);
    }


    public Map<String, String> getHscStatusID(String query) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement(query);
        return this.getMemberInfo(fetchMemberInfo);
    }


    public Map<String, String> getHscIdDb(String lastName, String dateOfBirth) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        dateOfBirth = convertDateOfBirthToDB(dateOfBirth);
        fetchMemberInfo = this.connect.prepareStatement("select * from HSC where creat_user_id ='ADTST12725' and mbr_id in (select mbr_id from mbr where lst_nm='" + lastName + "' and bth_dt='" + dateOfBirth + "' order by creat_dttm desc ) order by creat_dttm desc limit 1");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> getHscIdForSRN(String hscid) throws SQLException {
        PreparedStatement fetchMemberInfo = this.connect.prepareStatement("select hsc_id from HSC where hsc_id ='" + hscid + "'");
        //System.out.println("Query:" + "select hsc_id from hsr.HSC where pri_srvc_ref_nbr ='"+servrefnumber+"'");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> verifyHscTable(String memberId) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("select * from hsc  where mbr_id='" + memberId + "' order by creat_dttm desc");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> verifyMbrCovTableForBlockingRules(String mbrId) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("select mbr_id, ONC_MED_NECESSITY_TYP_ID,CORE_MED_NECESSITY_TYP_ID ,SHR_ARNG_ID,OBLIG_ID,LGCY_BEN_PLN_ID,FUND_ARNG_ID,prdct_catgy_cd,RPT_CD from mbr_cov where mbr_id='" + mbrId + "'");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> verifyHscMbrCovTableForBlockingRules(String mbrId) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("select hsc_id, ONC_MED_NECESSITY_TYP_ID,CORE_MED_NECESSITY_TYP_ID ,SHR_ARNG_ID,OBLIG_ID,LGCY_BEN_PLN_ID,FUND_ARNG_ID,prdct_catgy_cd,RPT_CD from hsc_mbr_cov where hsc_id=(select hsc_id from hsc where creat_user_id='vsujitha' and mbr_id='" + mbrId + "' order by creat_dttm desc limit 1)");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> verifyMbrTable(String mbrId) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("select * from mbr where mbr_id='" + mbrId + "'");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> verifyMbrCovTable(String mbrId) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("select * from mbr_cov where mbr_id='" + mbrId + "'");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> verifyHscMbrCovTableWithHscId(String hscId) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("select * from hsc_mbr_cov where hsc_id='" + hscId + "'");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> verifyHscTableWithHscId(String hscId) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("select * from hsc where hsc_id='" + hscId + "'");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, ArrayList<String>> verifyMbrIdTable(String mbrId) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("select * from mbr_id where mbr_id='" + mbrId + "'");
        return this.getMemberInfoMultipleRows(fetchMemberInfo);
    }

    public Map<String, String> verifyHscTableWithSrn(String srn) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("select * from hsc where pri_srvc_ref_nbr='" + srn + "'");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> verifyHscMbrCovTableWithSrn(String srn) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("select * from hsc_mbr_cov where hsc_id in ( select hsc_id from hsc where pri_srvc_ref_nbr='" + srn + "')");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> verifyMbrAdrTable(String mbrId) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("select * from mbr_adr where mbr_id='" + mbrId + "'");
        return this.getMemberInfo(fetchMemberInfo);
    }

    public Map<String, String> verifyMbrTdrTable(String mbrId) throws SQLException {
        PreparedStatement fetchMemberInfo = null;
        fetchMemberInfo = this.connect.prepareStatement("select * from mbr_tel where mbr_id='" + mbrId + "'");
        return this.getMemberInfo(fetchMemberInfo);
    }

    // Cfisher5: Want to eventually return hashmap to use this in multiple tests
    //Available = 1, Uploading = 2, Deleted = 3, Failed to upload = 4,
    // Infected = 5, Not Supported = 6, Limit Exceeded = 7
    public String getValidAttachmentId() throws SQLException {
        String attachmentId = "";
        PreparedStatement fetchAttachments = null;
        String query =
                "SELECT MAX(a.fds_attch_id) FROM hsc_doc_req_attch a " +
                        "JOIN hsc_doc_req d ON a.hsc_doc_req_id = d.hsc_doc_req_id " +
                        "WHERE d.doc_req_sts_typ_id = '1' " +
                        "AND fds_attch_id NOT IN (" +
                        "SELECT DISTINCT orig_fl_fds_attch_id FROM hsc_doc_req_attch " +
                        "WHERE orig_fl_fds_attch_id IS NOT NULL" +
                        ") order by a.creat_dttm desc;";
        fetchAttachments = this.connect.prepareStatement(query);
        System.out.println();
        System.out.println("Get valid attachments query: " + fetchAttachments);
        ResultSet rs = execQuery(fetchAttachments);
        rs.next();
        attachmentId = rs.getString(1);
        System.out.println();
        System.out.println("Using attachment id: " + attachmentId);
        rs.close();
        return attachmentId;

    }

    public ArrayList<String> getAttachmentNamesForSRN(String SRN) throws SQLException {
        ArrayList<String> filenames = new ArrayList<String>();
        PreparedStatement fetchAttachmentNames;
        String query =
                "SELECT a.fl_nm " +
                        "FROM   hsc_doc_req_attch a " +
                        "       JOIN hsc_doc_req d " +
                        "         ON a.hsc_doc_req_id = d.hsc_doc_req_id " +
                        "       JOIN hsc h " +
                        "         ON h.hsc_id = d.hsc_id " +
                        "WHERE  d.doc_req_sts_typ_id = '1' " +
                        "       AND h.pri_srvc_ref_nbr = '" + SRN + "' " +
                        "       AND h.hsc_sts_typ_id != '5' " +
                        "       AND h.pri_srvc_ref_nbr IS NOT NULL " +
                        "       AND fds_attch_id NOT IN (SELECT DISTINCT orig_fl_fds_attch_id " +
                        "                                FROM   hsc_doc_req_attch " +
                        "                                WHERE  orig_fl_fds_attch_id IS NOT NULL);";
        fetchAttachmentNames = this.connect.prepareStatement(query);
        System.out.println();
        //System.out.println("Get valid attachment names query: " + fetchAttachmentNames);
        ResultSet rs = execQuery(fetchAttachmentNames);
        while (rs.next()) {
            filenames.add(rs.getString(1));
        }
        rs.close();
        // System.out.println();
        System.out.println("Attachment names from database: " + filenames);
        return filenames;

    }

    public int getFdsAttachment(String fdsAttachmentId) {
        Response response = get("http://document-manager-ocm-spcl-care-test.ocp-ctc-core-nonprod.optum.com/" +
                "clinical/v1.0/documentManager/fds/attachment/" +
                fdsAttachmentId);
        System.out.println();
        System.out.println("Using attachment id: " + fdsAttachmentId);
        System.out.println("RESPONSE from get attachment microservice: " + response.getStatusCode());
        return response.getStatusCode();
    }

    public String getAuthThatHasAttachs() throws SQLException {
        PreparedStatement fetchHscId = null;
        String query =
                "SELECT h.pri_srvc_ref_nbr " +
                        "FROM   hsc_doc_req_attch a " +
                        "       JOIN hsc_doc_req d " +
                        "         ON a.hsc_doc_req_id = d.hsc_doc_req_id " +
                        "       JOIN hsc h " +
                        "         ON h.hsc_id = d.hsc_id " +
                        "WHERE  d.doc_req_sts_typ_id = '1' " +
                        "       AND h.hsc_sts_typ_id != '5' " +
                        "       AND h.pri_srvc_ref_nbr IS NOT NULL " +
                        "       AND fds_attch_id NOT IN (SELECT DISTINCT orig_fl_fds_attch_id " +
                        "                                FROM   hsc_doc_req_attch " +
                        "                                WHERE  orig_fl_fds_attch_id IS NOT NULL);";
        fetchHscId = this.connect.prepareStatement(query);
        System.out.println();
        //System.out.println("Get hscId with valid attachment(s) query: " + query);
        ResultSet rs = execQuery(fetchHscId);
        rs.next();
        SRN = rs.getString(1);
        //System.out.println("Using SRN: " + SRN);
        System.out.println();
        rs.close();
        return SRN;
    }

    /**
     * Query DB for the total records that should return when searching for submitted or draft authorizations
     *
     * @param authType return numberOfRows
     */
    public int getTotalRecordsOnPriorAuthSearch(String authType) {
        int numberOfRows = 0;
        String query = "";
        PreparedStatement TotalSearchRecords = null;

        switch (authType) {
            case "Submitted":
                query = "Select count(*) as total " +
                        "from hsc where hsc_sts_typ_id not in (5,9) and hsc_id in " +
                        "(Select a.hsc_id FROM hsc_prov a " +
                        "JOIN hsc_prov_role b ON a.hsc_id = b.hsc_id " +
                        "AND a.prov_seq_nbr = b.prov_seq_nbr AND (b.prov_role_typ_id = 'RF' OR b.prov_role_typ_id = 'SJ') AND a.fed_tax_id = '" + gv.getpaanTIN() + "')";
                break;
            case "Draft":
                query = "Select COUNT(IF(hsc_sts_typ_id ='5' ,1, NULL)) 'Draft' " +
                        "from hsc where hsc_sts_typ_id in (5) and hsc_id in " +
                        "(Select a.hsc_id FROM hsc_prov a JOIN hsc_prov_role b ON a.hsc_id = b.hsc_id " +
                        "AND a.prov_seq_nbr = b.prov_seq_nbr AND b.prov_role_typ_id = 'RF' AND a.fed_tax_id = '" + gv.getpaanTIN() + "')";
                break;
        }

        try {
            TotalSearchRecords = this.connect.prepareStatement(query);
            ResultSet rs = execQuery(TotalSearchRecords);

            while (rs.next()) {
                numberOfRows = rs.getInt(1);
                System.out.println("numberOfRows= " + numberOfRows);
            }
            rs.close();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return numberOfRows;
    }

    /**
     *
     * @param cancertype
     * @param variabletype
     * @param variabletype1
     * @return
     */
    public int validateCountOfrecords(String cancertype, String variabletype, String variablevalue, String variabletype1, String variablevalue1) {
        int numberOfRows=0;
        String Query = "Select count(*) from " +
                "( Select d.dses_trvrs_id from dses_trvrs d JOIN dses_trvrs_clin_var cv ON cv.dses_trvrs_id = d.dses_trvrs_id JOIN ref r ON cv.dses_typ_id = r.ref_cd AND " +
                "ref_nm='diseaseType' AND ref_desc like '%"+cancertype+"%' " +
                "WHERE dses_trvrs_desc LIKE '%"+variabletype+" - "+variablevalue+"%' and dses_trvrs_desc LIKE '%"+variabletype1+" - "+variablevalue1+"%' GROUP BY d.dses_trvrs_id)a";

        System.out.println(Query);
        try {
            PreparedStatement count = this.connect.prepareStatement(Query);
            ResultSet rs = execQuery(count);
            while (rs.next()) {
                numberOfRows = rs.getInt(1);
                System.out.println("numberOfRows= " + numberOfRows);
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return numberOfRows;

    }


    public String getMember() {
        return null;
    }
}

