package atdd.dao.icue;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.List;
import java.util.Map;

public class HscDaoIcue {

    private SqlSessionFactory sqlSessionFactory = null;

    public HscDaoIcue(SqlSessionFactory sqlSessionFactory) {
        this.sqlSessionFactory = sqlSessionFactory;
    }

    /**
     * Return the member by auth number in iCue db
     *
     * @param authNumber
     * @return
     */
    public List<Map<String, Object>> selectByIcueAuthNumber(String authNumber) {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("Hsc.selectByIcueAuthNumber", authNumber);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * The member is resetting in ICUE DB
     *
     * @param subscriberId
     * @return
     */
    public int resetMemberIcue(String subscriberId) {
        if (!subscriberId.startsWith("00")) {
            subscriberId = "00" + subscriberId;
        }

        int rows = 0;
        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            rows = sqlSession.update("Hsc.resetMemberIcue", subscriberId);
            sqlSession.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return rows;
    }

}

