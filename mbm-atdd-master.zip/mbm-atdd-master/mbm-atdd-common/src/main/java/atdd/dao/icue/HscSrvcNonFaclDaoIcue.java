package atdd.dao.icue;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.List;
import java.util.Map;

public class HscSrvcNonFaclDaoIcue {

    private SqlSessionFactory sqlSessionFactory = null;

    public HscSrvcNonFaclDaoIcue(SqlSessionFactory sqlSessionFactory) {
        this.sqlSessionFactory = sqlSessionFactory;
    }

    public List<Map<String, Object>> selectByIcueAuthNumber(String authNumber) {
        List<Map<String, Object>> list = null;
        SqlSession sqlSession = this.sqlSessionFactory.openSession();
        try {
            list = sqlSession.selectList("HscSrvcNonFacl.selectByIcueAuthNumber", authNumber);
        } finally {
            sqlSession.close();
        }

        return list;
    }

}
