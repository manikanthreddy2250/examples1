package atdd.dao.icue;

import atdd.utils.Conf;
import atdd.utils.MyBatisUtils;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.Properties;

public class MyBatisConnectionFactoryICUE {

    private static SqlSessionFactory sqlSessionFactory = null;
    private static Properties lastProperties = null;

    public static synchronized SqlSessionFactory getSqlSessionFactory() {
        MyBatisUtils.FactoryContainer container = new MyBatisUtils.FactoryContainer();
        container.sqlSessionFactory = sqlSessionFactory;
        container.properties = lastProperties;

        if (MyBatisUtils.getSqlSessionFactory(container, "src/main/resources/mybatis/icue/config.xml",
                "icueDriver", "icueJdbc", "icueDatabaseUser", "icueDatabasePass",
                "msidUser", "msidDbPass")) {
            sqlSessionFactory = container.sqlSessionFactory;
            lastProperties = container.properties;
            return container.sqlSessionFactory;
        } else {
            throw new RuntimeException("Unable to connect to database \"icueJdbc\": " + Conf.getInstance().getProperty("icueJdbc"));
        }
    }

}
