package atdd.dao.mbm;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.List;
import java.util.Map;

public class CmnctTransDao {

    private SqlSessionFactory sqlSessionFactory = null;

    public CmnctTransDao(SqlSessionFactory sqlSessionFactory) {
        this.sqlSessionFactory = sqlSessionFactory;
    }

    public List<Map<String, Object>> selectByHscId(long hscId) {
        List<Map<String, Object>> list = null;
        SqlSession sqlSession = this.sqlSessionFactory.openSession();
        try {
            list = sqlSession.selectList("CmnctTrans.selectByHscId", hscId);
        } finally {
            sqlSession.close();
        }

        return list;
    }

}
