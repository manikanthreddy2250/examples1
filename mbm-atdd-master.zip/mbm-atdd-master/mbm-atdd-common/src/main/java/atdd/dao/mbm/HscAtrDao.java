package atdd.dao.mbm;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class HscAtrDao {

    private SqlSessionFactory sqlSessionFactory = null;

    public HscAtrDao(SqlSessionFactory sqlSessionFactory) {
        this.sqlSessionFactory = sqlSessionFactory;
    }

    public static Map<String, String> asMap(List<Map<String, Object>> hscAtrs) {
        Map<String, String> result = new LinkedHashMap<>(hscAtrs.size());
        for (Map<String, Object> row : hscAtrs) {
            result.put(row.get("ref_cd").toString() + "-" + row.get("ref_desc").toString(), row.get("hsc_atr_val").toString());
        }
        return result;
    }

    public List<Map<String, Object>> selectById(long hscId) {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("HscAtr.selectById", hscId);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

}
