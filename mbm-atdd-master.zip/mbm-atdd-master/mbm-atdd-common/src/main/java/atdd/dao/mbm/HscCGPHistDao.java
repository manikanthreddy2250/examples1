package atdd.dao.mbm;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HscCGPHistDao {
    private SqlSessionFactory sqlSessionFactory = null;

    public HscCGPHistDao(SqlSessionFactory sqlSessionFactory) {
        this.sqlSessionFactory = sqlSessionFactory;
    }


    public String getclinicalInfoByHscID(String hscID) {
        String result;
        SqlSession sqlSession = this.sqlSessionFactory.openSession();
        try {
            result = sqlSession.selectOne("HscCGPHist.selectClinicalInfoByHscId", hscID);
        } finally {
            sqlSession.close();
        }

        return result;

    }
}
