package atdd.dao.mbm;


import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class HscCustomReasonsDao
{
    private SqlSessionFactory sqlSessionFactory = null;

    public HscCustomReasonsDao(SqlSessionFactory sqlSessionFactory) {
        this.sqlSessionFactory = sqlSessionFactory;
    }

    public List<Map<String, Object>> selectHscCustomReasonById(long hscId) {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("HscCustomReason.selectHscCustomReasonById", hscId);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    public static List<String> asList(List<Map<String, Object>> hscCustomReasons) {
        Map<String, String> result = new LinkedHashMap<>(hscCustomReasons.size());
        List<String> cstmReasons = new ArrayList<>();

        for (Map<String, Object> row : hscCustomReasons) {
            //result.put(row.get("ref_cd").toString() + "-" + row.get("ref_desc").toString(), row.get("hsc_id").toString());
            cstmReasons.add(row.get("ref_desc").toString());
        }
        return cstmReasons;
    }

}

