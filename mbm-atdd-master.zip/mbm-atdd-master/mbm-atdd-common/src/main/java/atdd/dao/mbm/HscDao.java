package atdd.dao.mbm;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.Assert;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class HscDao {

    private SqlSessionFactory sqlSessionFactory = null;

    public HscDao(SqlSessionFactory sqlSessionFactory) {
        this.sqlSessionFactory = sqlSessionFactory;
    }

    public static long getHscIdByAuthNumber(String authNumber) {
        SqlSessionFactory factory = MyBatisConnectionFactory.getSqlSessionFactory();

        HscDao hscDao = new HscDao(factory);
        List<Map<String, Object>> hscs = hscDao.selectByAuthNumber(authNumber);
        Assert.assertEquals(1, hscs.size());
        Map<String, String> hsc = new LinkedHashMap<>(hscs.get(0).size());
        long hsc_id = (Long) hscs.get(0).get("hsc_id");
        return hsc_id;
    }

    public List<Map<String, Object>> selectById(long hscId) {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("Hsc.selectById", hscId);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Map<String, Object>> selectByAuthNumber(String authNumber) {
        List<Map<String, Object>> list = null;
        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("Hsc.selectByAuthNumber", authNumber);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    public List<Map<String, Object>> selectClonedEntityByPriTelNbr(String priTelNbr, String authNumber) {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            Map<String, Object> params = new HashMap<String, Object>(2);
            params.put("priTelNbr", priTelNbr);
            params.put("authNumber", authNumber);
            list = sqlSession.selectList("Hsc.selectClonedEntityByPriTelNbr", params);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    /**
     * The member is reseting in DB
     *
     * @param subscriberId
     * @return
     */
    public int resetMember(String subscriberId,String owner) {
        if (!subscriberId.startsWith("00") && owner.contains("uhc")) {
            subscriberId = "00" + subscriberId;
        }
        int rows = 0;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            rows = sqlSession.update("Hsc.resetMember", subscriberId);
            sqlSession.commit();
        } catch (Exception e) {
            Assert.fail("Member reset failed: " + subscriberId);
        }

        return rows;
    }

    /**
     * The authorization request is reseting in DB for passing authNumber from ff
     *
     * @param authNumber
     * @return
     */
    public int resetAuth(String authNumber) {
        int rows = 0;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            rows = sqlSession.update("Hsc.resetAuth", authNumber);
            sqlSession.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return rows;
    }

    public List<Map<String, Object>> verifyTop10Drafts(String user) {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("Hsc.selectTop10Drafts", user);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;

    }

    public List<Map<String, Object>> getTop10SubmittedAuthorizationsThatTheyMostRecentlyTouchedByProvider(String user) {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("Hsc.selectTop10SubmittedByProvider", user);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Map<String, Object>> getTop10SubmittedAuthorizationsThatTheyMostRecentlyTouchedByOps(String user) {
        List<Map<String, Object>> list = null;
        SqlSession sqlSession = this.sqlSessionFactory.openSession();
        try {
            list = sqlSession.selectList("Hsc.selectTop10SubmittedByOps", user);
        } finally {
            sqlSession.close();
        }
        return list;
    }

    /**
     * getting top 10 ActivityTracking values
     *
     * @return
     */
    public List<Map<String, Object>> selectTop10ActivityTracking() {
        List<Map<String, Object>> list = null;
        SqlSession sqlSession = this.sqlSessionFactory.openSession();
        try {
            list = sqlSession.selectList("Hsc.selectTop10ActivityTracking");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;

    }

    public List<Map<String, Object>> getHscIdFromDb(String userName, String lastName, String dateOfBirth) {
        List<Map<String, Object>> list = null;
        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            Map<String, Object> params = new HashMap<String, Object>(3);
            params.put("userName", userName);
            params.put("lastName", lastName);
            params.put("dateOfBirth", dateOfBirth);
            list = sqlSession.selectList("Hsc.selectHSCId", params);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Map<String, Object>> selectServiceLinesWithPayerFilter(String regimen, String cancerType, String payer) {
        List<Map<String, Object>> list = null;
        SqlSession sqlSession = this.sqlSessionFactory.openSession();
        try {
            Map<String, Object> params = new HashMap<String, Object>(3);
            params.put("cancerType", cancerType);
            params.put("regimen", regimen);
            params.put("payer", payer);
            list = sqlSession.selectList("Hsc.selectServiceLinesWithPayerFilter", params);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;

    }

    public List<Map<String, Object>> selectSupportive(String cancerType, String payer) {
        List<Map<String, Object>> list = null;
        SqlSession sqlSession = this.sqlSessionFactory.openSession();
        try {
            Map<String, Object> params = new HashMap<String, Object>(2);
            params.put("cancerType", cancerType);
            params.put("payer", payer);
            list = sqlSession.selectList("Hsc.selectSupportive", params);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;

    }

    public List<Map<String, Object>> selectServiceLinesWithoutPayerFilter(String regimen, String cancerType) {
        List<Map<String, Object>> list = null;
        SqlSession sqlSession = this.sqlSessionFactory.openSession();
        try {
            Map<String, Object> params = new HashMap<String, Object>(2);
            params.put("cancerType", cancerType);
            params.put("regimen", regimen);
            list = sqlSession.selectList("Hsc.selectServiceLinesByRegimenWithoutPayerFilter", params);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Map<String, Object>> selectBycriteriae(String criteria) {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("Hsc.selectrecords", criteria);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Map<String, Object>> selectBycriteriaeDrafts(String criteria) {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("Hsc.selectrecordsDrafts", criteria);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Map<String, Object>> selectBycriteriaeDraftsProvider(String criteria) {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("Hsc.selectrecordsDraftsProvider", criteria);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Map<String, Object>> selectByMemberLastName(String Lastname) {
        List<Map<String, Object>> list = null;
        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("Hsc.selectrecordsLastName", Lastname);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Map<String, Object>> selectBycriteriaeSubmittedrovider(String criteria) {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("Hsc.selectrecordsSubmittedProvider", criteria);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }


    public List<Map<String, Object>> selectByRequestNumber(String RequestNumber) {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("Hsc.selectrecordsRequestNumber", RequestNumber);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Map<String, Object>> selectBySubscriberId(String subid) {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("Hsc.selectrecordsSubscriberId", subid);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Map<String, Object>> selectByPhysicianName(String PhysicianName) {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("Hsc.selectrecordsPhysicianName", PhysicianName);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Map<String, Object>> selectByMemberLastNameProvider(String Lastname) {
        List<Map<String, Object>> list = null;
        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("Hsc.selectrecordsLastNameProvider", Lastname);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }


    public List<Map<String, Object>> selectByRequestNumberProvider(String RequestNumber) {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("Hsc.selectrecordsRequestNumberProvider", RequestNumber);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Map<String, Object>> selectBySubscriberIdProvider(String subid) {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("Hsc.selectrecordsSubscriberIdProvider", subid);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Map<String, Object>> selectByPhysicianNameProvider(String PhysicianName) {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("Hsc.selectrecordsPhysicianNameProvider", PhysicianName);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Map<String, Object>> selectByPhysicianTIN(String PhysicianTin) {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("Hsc.selectrecordsPhysicianTin", PhysicianTin);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }


    public List<Map<String, Object>> selectByPriority() {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("Hsc.selectrecordsPriority");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Map<String, Object>> selectByMemberLastNameDrafts(String Lastname) {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("Hsc.selectLastNameDrafts", Lastname);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Map<String, Object>> selectByDraftIDDrafts(String DraftID) {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("Hsc.selectDraftIDDrafts", DraftID);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Map<String, Object>> selectBySubscriberIdDrafts(String SubscriberId) {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("Hsc.selectSubscriberIdDrafts", SubscriberId);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Map<String, Object>> selectByPhysicianNameDrafts(String PhysicianName) {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("Hsc.selectPhysicianNameDrafts", PhysicianName);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Map<String, Object>> selectByPhysicianTINDrafts(String PhysicianTIN) {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("Hsc.selectPhysicianTinDrafts", PhysicianTIN);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Map<String, Object>> selectByPriorityDrafts() {

        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("Hsc.selectrecordsPriorityDrafts");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;


    }

    public List<Map<String, Object>> selectByMemberLastNameDraftsProvider(String Lastname) {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("Hsc.selectLastNameDraftsProvider", Lastname);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Map<String, Object>> selectByDraftIDProviderDrafts(String DraftID) {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("Hsc.selectDraftIDDraftsProvider", DraftID);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Map<String, Object>> selectBySubscriberIdProviderDrafts(String SubscriberId) {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("Hsc.selectSubscriberIdDraftsProvider", SubscriberId);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Map<String, Object>> selectByCreatorNameDrafts(String creatorFirstname) {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("Hsc.selectcreatorFirstnameDrafts", creatorFirstname);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Map<String, Object>> selectByCreatorLastNameDrafts(String creatorLastname) {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("Hsc.selectcreatorLastnameDrafts", creatorLastname);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Map<String, Object>> verifyActivityTrackingHistoryvalues() {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("Hsc.selectActivityTrackingHistory");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Map<String, Object>> verifyActivityTrackingHistoryvaluesforuser(String user) {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("Hsc.selectActivityTrackingHistoryforuser", user);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
    public List<Map<String, Object>> selectOnPathwaysCount(String tin, String startDate, String endDate) {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            Map<String, Object> params = new HashMap<String, Object>(3);
            params.put("tin", tin);
            params.put("startDate", startDate);
            params.put("endDate", endDate);
            list = sqlSession.selectList("Hsc.selectOnPathwayCount", params);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
    public int resetProvider(String providerTin) {
        int rows = 0;
        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            rows = sqlSession.update("Hsc.resetProvider", providerTin);
            sqlSession.commit();
        } catch (Exception e) {
            Assert.fail("Provider reset failed: " + providerTin);
        }
        return rows;

    }

    public void insertRewardsEligible() {
        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            sqlSession.insert("Hsc.insertRewardsEligible");
            sqlSession.commit();
        } catch (Exception e) {
            Assert.fail("insertion failed: " );
        }
    }

    public void deleteRewardsEligible() {
        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            sqlSession.delete("Hsc.deleteRewardsEligible");
            sqlSession.commit();
        } catch (Exception e) {
            Assert.fail("insertion failed: " );
        }
    }

    public List<Map<String, String>> selectOnPathwaysPerformanceCount(String providerTin, String startDate, String endDate) {
        List<Map<String, String>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            Map<String, Object> params = new HashMap<String, Object>(3);
            params.put("tin", providerTin);
            params.put("startDate", startDate);
            params.put("endDate", endDate);
            list = sqlSession.selectList("Hsc.selectOnPathwayPerformanceCount", params);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Map<String, String>> selectOnPathwaysPerformanceForAllProvidersCount(String startDate, String endDate) {
        List<Map<String, String>> list = null;
        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            Map<String, Object> params = new HashMap<String, Object>(3);
            params.put("startDate", startDate);
            params.put("endDate", endDate);
            list = sqlSession.selectList("Hsc.selectOnPathwayPerformanceForAllProvidersCount", params);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;

    }

    public void updateLOB(String lob, String hscid) {
        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            Map<String, Object> params = new HashMap<String, Object>(2);
            params.put("lob", lob);
            params.put("hscid", hscid);
            sqlSession.update("Hsc.updateLOB", params);
            sqlSession.commit();
        } catch (Exception e) {
            Assert.fail("insertion failed: " );
        }

    }
    public List<Map<String, Object>> getPQ(long hscId) {
        List<Map<String, Object>> list = null;
        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("Hsc.getPQ", hscId);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Map<String, Object>> selectBy14DaysOldDraftId(String draftId, String customer, String authType) {
        List<Map<String, Object>> list = null;
        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            Map<String, Object> params = new HashMap<String, Object>(2);
            params.put("draftId", draftId);
            params.put("customer", customer);
            params.put("authType", authType);
            list = sqlSession.selectList("Hsc.select_14DaysOldDraftId", params);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;

    }

    public List<Map<String, Object>> selectByTodaysDraftId(String draftId, String customer, String authType) {
        List<Map<String, Object>> list = null;
        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            Map<String, Object> params = new HashMap<String, Object>(2);
            params.put("draftId", draftId);
            params.put("customer", customer);
            params.put("authType", authType);
            list = sqlSession.selectList("Hsc.select_today'sDraftId", params);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;

    }

    public String selectTherapyAuthWithReasonByStatus(String authOverallStatus) {
        List<Map<String, Object>> list = null;
        String requestNumber = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("Hsc.selectTherapyAuthWithReasonsByStatus", authOverallStatus);

            Map<String, String>  firstHSC = new LinkedHashMap<>(list.get(0).size());
            requestNumber = list.get(0).get("RequestNumber").toString();
            return requestNumber;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return requestNumber;
    }


    public List<Map<String, Object>> selectAuthNumberFrom(String customer, String authtype, String subID, String CancerType) {
        List<Map<String, Object>> result = null;
        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            Map<String, Object> params = new HashMap<String, Object>(2);

            params.put("customer", customer);
            params.put("cancer", CancerType);
            params.put("authtype", authtype);
            params.put("subid", subID);
            result = sqlSession.selectList("Hsc.selectAuthorizationNumberFromDb", params);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    public List<Map<String, Object>> selectAuthNumberForSupportive(String customer, String authtype, String subID, String cancer, String supportiveType) {
        List<Map<String, Object>> result = null;
        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            Map<String, Object> params = new HashMap<String, Object>(2);

            params.put("customer", customer);
            params.put("authtype", authtype);
            params.put("subid", subID);
            params.put("cancer",cancer);
            params.put("supptype",supportiveType);
            result = sqlSession.selectList("Hsc.selectAuthorizationNumberFromDbForsupportive", params);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

}

