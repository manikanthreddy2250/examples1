package atdd.dao.mbm;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.List;
import java.util.Map;

public class HscFlwupCntcDao {

    private SqlSessionFactory sqlSessionFactory = null;

    public HscFlwupCntcDao(SqlSessionFactory sqlSessionFactory) {
        this.sqlSessionFactory = sqlSessionFactory;
    }

    public List<Map<String, Object>> selectByHscId(long hscId) {
        List<Map<String, Object>> list = null;
        SqlSession sqlSession = this.sqlSessionFactory.openSession();
        try {
            list = sqlSession.selectList("HscFlwupCntc.selectByHscId", hscId);
        } finally {
            sqlSession.close();
        }

        return list;
    }

}
