package atdd.dao.mbm;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class HscMsrDao {
    private SqlSessionFactory sqlSessionFactory = null;

    public HscMsrDao(SqlSessionFactory sqlSessionFactory) {
        this.sqlSessionFactory = sqlSessionFactory;
    }

    public static Map<String, String> asMap(List<Map<String, Object>> hscMsr) {
        Map<String, String> result = new LinkedHashMap<>(hscMsr.size());
        for (Map<String, Object> row : hscMsr) {
            result.put(row.get("ref_desc").toString(), row.get("msr_val_desc").toString());
        }
        return result;
    }

    public List<Map<String, Object>> selectByHscId(long hscId) {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("HscMsr.selectByHscId", hscId);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

}