package atdd.dao.mbm;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class HscPhQuestDao {
    private SqlSessionFactory sqlSessionFactory = null;

    public HscPhQuestDao(SqlSessionFactory sqlSessionFactory) {
        this.sqlSessionFactory = sqlSessionFactory;
    }



    public List<Map<String, Object>> getPQ(long hscId) {
        List<Map<String, Object>> list = null;
        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("HscPhQuest.getPQ", hscId);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}