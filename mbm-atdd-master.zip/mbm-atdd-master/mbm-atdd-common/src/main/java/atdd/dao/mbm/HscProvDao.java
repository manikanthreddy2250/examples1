package atdd.dao.mbm;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HscProvDao {

    private SqlSessionFactory sqlSessionFactory = null;

    public static boolean matches(Map<String,Object> left, Map<String,Object> right, String[] ex) {
        left = new HashMap<String, Object>(left);
        right = new HashMap<String, Object>(right);
        if (null != ex && ex.length > 0) {
            for (String ex1 : ex) {
                left.remove(ex);
                right.remove(ex);
            }
        }
         if (left.get("hsc_id") != null ? !left.get("hsc_id").equals(right.get("hsc_id")) : right.get("hsc_id") != null) return false;
        if (left.get("prov_seq_nbr") != null ? !left.get("prov_seq_nbr").equals(right.get("prov_seq_nbr")) : right.get("prov_seq_nbr") != null) return false;
        if (left.get("creat_dttm") != null ? !left.get("creat_dttm").equals(right.get("creat_dttm")) : right.get("creat_dttm") != null) return false;
        if (left.get("creat_user_id") != null ? !left.get("creat_user_id").equals(right.get("creat_user_id")) : right.get("creat_user_id") != null) return false;
        if (left.get("chg_dttm") != null ? !left.get("chg_dttm").equals(right.get("chg_dttm")) : right.get("chg_dttm") != null) return false;
        if (left.get("chg_user_id") != null ? !left.get("chg_user_id").equals(right.get("chg_user_id")) : right.get("chg_user_id") != null) return false;
        if (left.get("updt_ver_nbr") != null ? !left.get("updt_ver_nbr").equals(right.get("updt_ver_nbr")) : right.get("updt_ver_nbr") != null) return false;
        if (left.get("prov_clin_id") != null ? !left.get("prov_clin_id").equals(right.get("prov_clin_id")) : right.get("prov_clin_id") != null) return false;
        if (left.get("bus_nm") != null ? !left.get("bus_nm").equals(right.get("bus_nm")) : right.get("bus_nm") != null) return false;
        if (left.get("fst_nm") != null ? !left.get("fst_nm").equals(right.get("fst_nm")) : right.get("fst_nm") != null) return false;
        if (left.get("lst_nm") != null ? !left.get("lst_nm").equals(right.get("lst_nm")) : right.get("lst_nm") != null) return false;
        if (left.get("midl_nm") != null ? !left.get("midl_nm").equals(right.get("midl_nm")) : right.get("midl_nm") != null) return false;
        if (left.get("sufx_nm") != null ? !left.get("sufx_nm").equals(right.get("sufx_nm")) : right.get("sufx_nm") != null) return false;
        if (left.get("spcl_typ_id") != null ? !left.get("spcl_typ_id").equals(right.get("spcl_typ_id")) : right.get("spcl_typ_id") != null) return false;
        if (left.get("ntwk_sts_typ_id") != null ? !left.get("ntwk_sts_typ_id").equals(right.get("ntwk_sts_typ_id")) : right.get("ntwk_sts_typ_id") != null) return false;
        if (left.get("adr_ln1_txt") != null ? !left.get("adr_ln1_txt").equals(right.get("adr_ln1_txt")) : right.get("adr_ln1_txt") != null) return false;
        if (left.get("adr_ln2_txt") != null ? !left.get("adr_ln2_txt").equals(right.get("adr_ln2_txt")) : right.get("adr_ln2_txt") != null) return false;
        if (left.get("cty_nm") != null ? !left.get("cty_nm").equals(right.get("cty_nm")) : right.get("cty_nm") != null) return false;
        if (left.get("cnty_nm") != null ? !left.get("cnty_nm").equals(right.get("cnty_nm")) : right.get("cnty_nm") != null) return false;
        if (left.get("st_cd") != null ? !left.get("st_cd").equals(right.get("st_cd")) : right.get("st_cd") != null) return false;
        if (left.get("zip_cd_txt") != null ? !left.get("zip_cd_txt").equals(right.get("zip_cd_txt")) : right.get("zip_cd_txt") != null) return false;
        if (left.get("zip_sufx_cd_txt") != null ? !left.get("zip_sufx_cd_txt").equals(right.get("zip_sufx_cd_txt")) : right.get("zip_sufx_cd_txt") != null) return false;
        if (left.get("prov_npi") != null ? !left.get("prov_npi").equals(right.get("prov_npi")) : right.get("prov_npi") != null) return false;
        if (left.get("prov_grp_nbr") != null ? !left.get("prov_grp_nbr").equals(right.get("prov_grp_nbr")) : right.get("prov_grp_nbr") != null) return false;
        if (left.get("pri_tel_nbr") != null ? !left.get("pri_tel_nbr").equals(right.get("pri_tel_nbr")) : right.get("pri_tel_nbr") != null) return false;
        if (left.get("sec_tel_nbr") != null ? !left.get("sec_tel_nbr").equals(right.get("sec_tel_nbr")) : right.get("sec_tel_nbr") != null) return false;
        if (left.get("fax_nbr") != null ? !left.get("fax_nbr").equals(right.get("fax_nbr")) : right.get("fax_nbr") != null) return false;
        if (left.get("fed_tax_id") != null ? !left.get("fed_tax_id").equals(right.get("fed_tax_id")) : right.get("fed_tax_id") != null) return false;
        if (left.get("email_adr_txt") != null ? !left.get("email_adr_txt").equals(right.get("email_adr_txt")) : right.get("email_adr_txt") != null) return false;
        if (left.get("ndb_adr_seq_nbr") != null ? !left.get("ndb_adr_seq_nbr").equals(right.get("ndb_adr_seq_nbr")) : right.get("ndb_adr_seq_nbr") != null) return false;
        if (left.get("ndb_mpin") != null ? !left.get("ndb_mpin").equals(right.get("ndb_mpin")) : right.get("ndb_mpin") != null) return false;
        if (left.get("pri_tel_ext_nbr") != null ? !left.get("pri_tel_ext_nbr").equals(right.get("pri_tel_ext_nbr")) : right.get("pri_tel_ext_nbr") != null) return false;
        return left.get("fax_ext_nbr") != null ? left.get("fax_ext_nbr").equals(right.get("fax_ext_nbr")) : right.get("fax_ext_nbr") == null;
    }
    
    public HscProvDao(SqlSessionFactory sqlSessionFactory) {
        this.sqlSessionFactory = sqlSessionFactory;
    }

    public List<Map<String, Object>> selectRequestingProviderByHscId(long hscId) {
        List<Map<String, Object>> list = null;
        SqlSession sqlSession = this.sqlSessionFactory.openSession();
        try {
            list = sqlSession.selectList("HscProv.selectRequestingProviderByHscId", hscId);
        } finally {
            sqlSession.close();
        }

        return list;
    }

    public List<Map<String, Object>> selectServicingProviderByHscId(long hscId) {
        List<Map<String, Object>> list = null;
        SqlSession sqlSession = this.sqlSessionFactory.openSession();
        try {
            list = sqlSession.selectList("HscProv.selectServicingProviderByHscId", hscId);
        } finally {
            sqlSession.close();
        }

        return list;
    }

}
