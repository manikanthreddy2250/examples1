package atdd.dao.mbm;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HscProvRoleDao {

    private SqlSessionFactory sqlSessionFactory = null;

    public static boolean matches(Map<String, Object> left, Map<String, Object> right, String[] ex) {
        left = new HashMap<String, Object>(left);
        right = new HashMap<String, Object>(right);
        if (null != ex && ex.length > 0) {
            for (String ex1 : ex) {
                left.remove(ex);
                right.remove(ex);
            }
        }
        if (left.get("hsc_id") != null ? !left.get("hsc_id").equals(right.get("hsc_id")) : right.get("hsc_id") != null)
            return false;
        if (left.get("prov_seq_nbr") != null ? !left.get("prov_seq_nbr").equals(right.get("prov_seq_nbr")) : right.get("prov_seq_nbr") != null)
            return false;
        if (left.get("prov_role_typ_id") != null ? !left.get("prov_role_typ_id").equals(right.get("prov_role_typ_id")) : right.get("prov_role_typ_id") != null)
            return false;
        if (left.get("creat_dttm") != null ? !left.get("creat_dttm").equals(right.get("creat_dttm")) : right.get("creat_dttm") != null)
            return false;
        if (left.get("creat_user_id") != null ? !left.get("creat_user_id").equals(right.get("creat_user_id")) : right.get("creat_user_id") != null)
            return false;
        if (left.get("chg_dttm") != null ? !left.get("chg_dttm").equals(right.get("chg_dttm")) : right.get("chg_dttm") != null)
            return false;
        if (left.get("chg_user_id") != null ? !left.get("chg_user_id").equals(right.get("chg_user_id")) : right.get("chg_user_id") != null)
            return false;
        return left.get("updt_ver_nbr") != null ? left.get("updt_ver_nbr").equals(right.get("updt_ver_nbr")) : right.get("updt_ver_nbr") == null;
    }

    public HscProvRoleDao(SqlSessionFactory sqlSessionFactory) {
        this.sqlSessionFactory = sqlSessionFactory;
    }

    public List<Map<String, Object>> selectRequestingProviderByHscId(long hscId) {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("HscProvRole.selectRequestingProviderByHscId", hscId);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    public List<Map<String, Object>> selectServicingProviderByHscId(long hscId) {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("HscProvRole.selectServicingProviderByHscId", hscId);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    public List<Map<String,Object>> selectById(long hscId) {
        List<Map<String, Object>> list = null;
        SqlSession sqlSession = this.sqlSessionFactory.openSession();
        try {
            list = sqlSession.selectList("HscProvRole.selectById", hscId);
        } finally {
            sqlSession.close();
        }

        return list;
    }

}
