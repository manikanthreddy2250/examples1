package atdd.dao.mbm;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.Assert;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HscSrvcDecnDao {

    private final SqlSessionFactory sqlSessionFactory;

    public HscSrvcDecnDao(SqlSessionFactory sqlSessionFactory) {
        this.sqlSessionFactory = sqlSessionFactory;
    }

    public List<Map<String, Object>> selectActiveOverallDecisionByRequestNumber(String srn) {
        List<Map<String, Object>> list = null;
        SqlSession sqlSession = this.sqlSessionFactory.openSession();
        try {
            list = sqlSession.selectList("HscSrvcDecn.selectActiveOverallDecisionByRequestNumber", srn);
        } finally {
            try {
                sqlSession.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return list;
    }

    public void updateDecisionRenderDate(String previousMonth, String hscid) {
        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            Map<String, Object> params = new HashMap<String, Object>(2);
            params.put("previousMonth", previousMonth);
            params.put("hscid", hscid);
            sqlSession.update("HscSrvcDecn.updateDecisionRenderDate", params);
            sqlSession.commit();
        } catch (Exception e) {
            Assert.fail("insertion failed: " );
        }

    }
}
