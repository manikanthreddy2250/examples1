package atdd.dao.mbm;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.List;
import java.util.Map;

public class HscSrvcNonFaclDao {

    private SqlSessionFactory sqlSessionFactory = null;

    public HscSrvcNonFaclDao(SqlSessionFactory sqlSessionFactory) {
        this.sqlSessionFactory = sqlSessionFactory;
    }

    public List<Map<String, Object>> selectByAuthNumber(String authNumber) {
        List<Map<String, Object>> list = null;
        SqlSession sqlSession = this.sqlSessionFactory.openSession();
        try {
            list = sqlSession.selectList("HscSrvcNonFacl.selectByAuthNumber", authNumber);
        } finally {
            sqlSession.close();
        }

        return list;
    }

    public List<Map<String, Object>> selectById(long hscId) {
        List<Map<String, Object>> list = null;
        SqlSession sqlSession = this.sqlSessionFactory.openSession();
        try {
            list = sqlSession.selectList("HscSrvcNonFacl.selectById", hscId);
        } finally {
            sqlSession.close();
        }

        return list;
    }

}
