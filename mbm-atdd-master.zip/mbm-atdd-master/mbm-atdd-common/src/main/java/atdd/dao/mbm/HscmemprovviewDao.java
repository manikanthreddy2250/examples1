package atdd.dao.mbm;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HscmemprovviewDao {
    private SqlSessionFactory sqlSessionFactory = null;

    public HscmemprovviewDao(SqlSessionFactory sqlSessionFactory) {
        this.sqlSessionFactory = sqlSessionFactory;
    }

    public List<Map<String, Object>> selectByMarker(String marker) {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("Hscmemprovview.selectByMarker", marker);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Map<String, Object>> selectByMarkerAndOverallStatus(String marker, String overallStatus) {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            Map<String, String> map = new HashMap<>(2);
            map.put("marker", marker);
            map.put("hscOverallStatusDesc", overallStatus);
            list = sqlSession.selectList("Hscmemprovview.selectByMarkerAndHscOverallStatusDesc", map);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Map<String, Object>> selectByHscId(long hscId) {
        List<Map<String, Object>> list = null;
        SqlSession sqlSession = this.sqlSessionFactory.openSession();
        try {
            list = sqlSession.selectList("Hscmemprovview.selectByHscId", hscId);
        } finally {
            sqlSession.close();
        }

        return list;
    }
}
