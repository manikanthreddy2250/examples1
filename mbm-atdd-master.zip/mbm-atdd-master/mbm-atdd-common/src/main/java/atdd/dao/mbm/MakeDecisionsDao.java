package atdd.dao.mbm;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MakeDecisionsDao {

    private SqlSessionFactory sqlSessionFactory = null;

    public MakeDecisionsDao(SqlSessionFactory sqlSessionFactory) {
        this.sqlSessionFactory = sqlSessionFactory;
    }

    public String getOutcomeDescription(Object outcomeValue) {
        String result;
        SqlSession sqlSession = this.sqlSessionFactory.openSession();
        try {
            result = sqlSession.selectOne("MakeDecisions.decisionOutcomeRefDescription", outcomeValue);
        } finally {
            sqlSession.close();
        }

        return result;
    }

    public String getSubTypeDescription(Object subTypeValue) {
        String result;
        SqlSession sqlSession = this.sqlSessionFactory.openSession();
        try {
            result = sqlSession.selectOne("MakeDecisions.decisionSubTypeRefDescription", subTypeValue);
        } finally {
            sqlSession.close();
        }

        return result;
    }

    public String getReasonDescription(Object reasonValue) {
        String result;
        SqlSession sqlSession = this.sqlSessionFactory.openSession();
        try {
            result = sqlSession.selectOne("MakeDecisions.decisionReasonRefDescription", reasonValue);
        } finally {
            sqlSession.close();
        }

        return result;
    }

    public String getDecisionCustomRequestReasonDescription(Object subTypeValue) {
        String result;
        SqlSession sqlSession = this.sqlSessionFactory.openSession();
        try {
            result = sqlSession.selectOne("MakeDecisions.decisionCustomRequestReasonDescription", subTypeValue);
        } finally {
            sqlSession.close();
        }

        return result;
    }

    public String getDecisionSequenceNumber(Object queryExpressions) {
        String result;
        SqlSession sqlSession = this.sqlSessionFactory.openSession();
        try {
            result = sqlSession.selectOne("MakeDecisions.getDecisionSequenceNumber", queryExpressions);
        } finally {
            sqlSession.close();
        }
        return result;
    }

    public String getDecisionResourceTypeBasedOnSrcSeqNumber(String queryExpressions, String srcSeq, String decnSeq) {
        String result;
        SqlSession sqlSession = this.sqlSessionFactory.openSession();
        Map<String, Object> parms = new HashMap<String, Object>();
        parms.put("hscid", queryExpressions);
        parms.put("srcSeq", srcSeq);
        parms.put("decnSeq", decnSeq);

        try {
            result = sqlSession.selectOne("MakeDecisions.getDecisionResourceTypeBasedOnSrcSeqNumber", parms);
        } finally {
            sqlSession.close();
        }
        return result;
    }

    public String getresourceDescription(Object queryExpressions) {
        String result;
        SqlSession sqlSession = this.sqlSessionFactory.openSession();
        try {
            result = sqlSession.selectOne("MakeDecisions.resourceDescription", queryExpressions);
        } finally {
            sqlSession.close();
        }
        return result;
    }

    public List<Map<String, Object>> getServiceDecisions(String queryExpressions, String decnSeq) {
        List<Map<String, Object>> result;
        SqlSession sqlSession = this.sqlSessionFactory.openSession();
        Map<String, Object> parms = new HashMap<String, Object>();
        parms.put("hscid", queryExpressions);
        parms.put("decnSeq", decnSeq);

        try {
            result = sqlSession.selectList("MakeDecisions.getServiceDecision", parms);
        } finally {
            sqlSession.close();
        }
        return result;
    }

}
