package atdd.dao.mbm;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.log4j.Logger;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MbrDao {

    Logger log = Logger.getLogger(MbrDao.class);

    private SqlSessionFactory sqlSessionFactory = null;

    public MbrDao(SqlSessionFactory sqlSessionFactory) {
        this.sqlSessionFactory = sqlSessionFactory;
    }

    public List<Map<String, Object>> selectByMemberId(long mbrId) {
        List<Map<String, Object>> list = null;
        SqlSession sqlSession = this.sqlSessionFactory.openSession();
        try {
            list = sqlSession.selectList("Mbr.selectByMemberId", mbrId);
        } finally {
            sqlSession.close();
        }

        return list;
    }

    public List<Map<String, Object>> selectByAuthNumber(String authNumber) {
        List<Map<String, Object>> list = null;
        SqlSession sqlSession = this.sqlSessionFactory.openSession();
        try {
            list = sqlSession.selectList("Mbr.selectByAuthNumber", authNumber);
        } finally {
            sqlSession.close();
        }

        return list;
    }

    public List<Map<String, Object>> selectByHscId(long hscId) {
        List<Map<String, Object>> list = null;
        SqlSession sqlSession = this.sqlSessionFactory.openSession();
        try {
            list = sqlSession.selectList("Mbr.selectByHscId", hscId);
        } finally {
            sqlSession.close();
        }

        return list;
    }

    public List<Map<String, Object>> selectBySubscriberId(String subscriberId) {
        List<Map<String, Object>> list = null;
        SqlSession sqlSession = this.sqlSessionFactory.openSession();
        try {
            list = sqlSession.selectList("Mbr.selectBySubscriberId", subscriberId);
            if (0 == list.size()) {
                list = sqlSession.selectList("Mbr.selectBySubscriberId", "00" + subscriberId);
            }
        } finally {
            sqlSession.close();
        }

        return list;
    }

    public Map<String, Object> reserveNextAvailableEAIMemberForDupTermCheck(int inMinutes) {
        log.debug("inMinutes=" + inMinutes);
        List<Map<String, Object>> list = null;
        SqlSession sqlSession = this.sqlSessionFactory.openSession();
        try {
            list = sqlSession.selectList("Mbr.selectNextAvailableEAIMemberForDupTermCheck");
            log.debug("list=" + list);
            if (null != list && 1 == list.size()) {
                long mbrId = (long) list.get(0).get("mbr_id");
                int updtVerNbr = (int) list.get(0).get("updt_ver_nbr");
                Map<String, Object> params = new HashMap<String, Object>(2);
                params.put("mbrId", mbrId);
                params.put("inMinutes", inMinutes);
                params.put("updtVerNbr", updtVerNbr);
                int rows = sqlSession.update("Mbr.reserveMember", params);
                if (1 == rows) {
                    return list.get(0);
                } else {
                    return null;
                }
            } else {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            sqlSession.commit();
            sqlSession.close();
        }
    }

    public int releaseMemberByMemberId(long mbrId) {
        SqlSession sqlSession = this.sqlSessionFactory.openSession();
        try {
            int rows = sqlSession.update("Mbr.releaseMemberByMemberId", mbrId);
            sqlSession.commit();
            return rows;
        } finally {
            sqlSession.close();
        }
    }

    public int releaseMemberBySubscriberId(String subscriberId) {

        SqlSession sqlSession = this.sqlSessionFactory.openSession();

        try {
            log.warn("Releasing member " + subscriberId);

            int rows = sqlSession.update("Mbr.releaseMemberBySubscriberId", subscriberId);
            if (0 == rows) {
                rows = sqlSession.update("Mbr.releaseMemberBySubscriberId", "00" + subscriberId);
            }
            sqlSession.commit();
            log.warn("Updated rows: " + rows);
            return rows;
        } finally {
            sqlSession.close();
        }
    }
    public List<Map<String,Object>> getMemberInformationDetails(String subid) {
        List<Map<String, Object>> list = null;
        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("Mbr.selectMemberInformationDetails",subid);
            if (0 == list.size()) {
                list = sqlSession.selectList("Mbr.selectMemberInformationDetails", "00" + subid);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Map<String, Object>> getHeaderData(long subid, long hsc) {
        List<Map<String, Object>> list = null;
        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            Map<String, Object> params = new HashMap<String, Object>(2);
            params.put("subid", subid);
            params.put("hsc", hsc);
            list = sqlSession.selectList("Mbr.selectFundingArrangmentAndMarketTypeBySubscriberId", params);
            if (0 == list.size()) {
                list = sqlSession.selectList("Mbr.selectFundingArrangmentAndMarketTypeBySubscriberId", "00" + params);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;

    }

}
