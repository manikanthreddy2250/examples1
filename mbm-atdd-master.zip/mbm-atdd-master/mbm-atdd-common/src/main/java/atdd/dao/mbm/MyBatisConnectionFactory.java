package atdd.dao.mbm;

import atdd.utils.Conf;
import atdd.utils.MyBatisUtils;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.log4j.Logger;

import java.util.Properties;

public class MyBatisConnectionFactory {

    public static final Logger log = Logger.getLogger(MyBatisConnectionFactory.class.getName());

    private static SqlSessionFactory sqlSessionFactory = null;
    private static Properties lastProperties = null;

    public static synchronized SqlSessionFactory getSqlSessionFactory() {
        MyBatisUtils.FactoryContainer container = new MyBatisUtils.FactoryContainer();
        container.sqlSessionFactory = sqlSessionFactory;
        container.properties = lastProperties;

        if (MyBatisUtils.getSqlSessionFactory(container, "src/main/resources/mybatis/mbm/config.xml",
                "mbmdbDriver", "mbmdbJdbc", "DatabaseUser", "DatabasePass",
                "msidUser", "msidDbPass")) {
            sqlSessionFactory = container.sqlSessionFactory;
            lastProperties = container.properties;
            return container.sqlSessionFactory;
        } else {
            throw new RuntimeException("Unable to connect to database \"mbmdbJdbc\": " + Conf.getInstance().getProperty("mbmdbJdbc"));
        }
    }

}
