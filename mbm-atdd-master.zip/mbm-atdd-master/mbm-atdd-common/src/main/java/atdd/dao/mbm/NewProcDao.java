package atdd.dao.mbm;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.List;
import java.util.Map;

public class NewProcDao {

    private SqlSessionFactory sqlSessionFactory = null;

    public NewProcDao(SqlSessionFactory sqlSessionFactory) {
        this.sqlSessionFactory = sqlSessionFactory;
    }

    public List<Map<String, Object>> selectByBrandName() {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()){
            list = sqlSession.selectList("NewProc.selectByBrandName");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

}
