package atdd.dao.mbm;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.List;
import java.util.Map;

public class NoteDao {

    private SqlSessionFactory sqlSessionFactory = null;

    public NoteDao(SqlSessionFactory sqlSessionFactory) {
        this.sqlSessionFactory = sqlSessionFactory;
    }

    public List<Map<String, Object>> selectNoteTxtLobj(String queryExpressions) {
        List<Map<String, Object>> list = null;
        SqlSession sqlSession = this.sqlSessionFactory.openSession();
        try {
            list = sqlSession.selectList("Note.selectNoteTxtLobjandUser", queryExpressions);
        } finally {
            sqlSession.close();
        }

        return list;
    }

}
