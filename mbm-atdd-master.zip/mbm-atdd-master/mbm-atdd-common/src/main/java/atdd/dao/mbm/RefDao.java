package atdd.dao.mbm;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RefDao {

    private SqlSessionFactory sqlSessionFactory = null;

    public RefDao(SqlSessionFactory sqlSessionFactory) {
        this.sqlSessionFactory = sqlSessionFactory;
    }

    public List<Map<String, Object>> refNameDescription(String name) {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()){
            list = sqlSession.selectList("RefTbl.refNameDescription",name);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<String> refNameDescriptionByCode(String name, String code){
        List<String> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()){
            Map<String, Object> params = new HashMap<String, Object>(2);
            params.put("name", name);
            params.put("code", code);
            list = sqlSession.selectList("RefTbl.refNameDescriptionByCode",params);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
