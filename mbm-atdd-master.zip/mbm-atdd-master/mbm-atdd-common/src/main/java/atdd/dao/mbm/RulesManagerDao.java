package atdd.dao.mbm;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RulesManagerDao {
    private SqlSessionFactory sqlSessionFactory = null;

    public RulesManagerDao(SqlSessionFactory sqlSessionFactory) {
        this.sqlSessionFactory = sqlSessionFactory;
    }

    public List<Map<String, Object>> getMemberExceptionsByVersion(String subscriberID,String lastName,String firstName) {
        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            Map<String, Object> params = new HashMap<String, Object>(2);
            params.put("subscriberID", subscriberID);
            params.put("lastName", lastName);
            params.put("firstName", firstName);
            return sqlSession.selectList("rulesManager.selectByVersion", params);
        } catch (Exception e) {
            return null;
        }

    }

    public List<Map<String, Object>> getProviderExceptionsByVersion(String tin) {
        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            Map<String, Object> params = new HashMap<String, Object>(2);
            params.put("tin", tin);
            return sqlSession.selectList("rulesManager.selectByVersionProvider", params);
        } catch (Exception e) {
            return null;
        }
    }
}
