package atdd.dao.mbm;

import atdd.utils.MyBatisUtils;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.Assert;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UserTblDao {

    private SqlSessionFactory sqlSessionFactory = null;

    public UserTblDao(SqlSessionFactory sqlSessionFactory) {
        this.sqlSessionFactory = sqlSessionFactory;
    }

    public List<Map<String, Object>> selectByUserId(String userId) {
        List<Map<String, Object>> list = null;

        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            list = sqlSession.selectList("UserTbl.selectByUserId", userId);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * Update user role by userId.
     *
     * @param userId
     * @param role
     * @return
     */
    public int updateRoleByUserId(String userId, String role) {
        int rows = 0;
        Map<String, Object> params = new HashMap<String, Object>(3);
        params.put("userId", userId);
        params.put("role", role);
        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            List<Map<String, Object>> roleList = sqlSession.selectList("UserTbl.selectDistinctRoles");
            if (MyBatisUtils.firstIndexOf(roleList, role, "user_grp_id") < 0) {
                throw new RuntimeException("Invalid role: " + role);
            }
            rows = sqlSession.update("UserTbl.updateRoleByUserId", params);
            if (1 != rows) {
                sqlSession.rollback();
                throw new RuntimeException("Exactly one row should be updated. But actually " + rows + " rows are updated.");
            }
            sqlSession.commit();
        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("Update failed: " + params);
        }

        return rows;
    }

}
