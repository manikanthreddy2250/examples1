package atdd.dao.mbm;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.List;
import java.util.Map;

public class WorkqueueviewDao {

    private SqlSessionFactory sqlSessionFactory = null;

    public WorkqueueviewDao(SqlSessionFactory sqlSessionFactory) {
        this.sqlSessionFactory = sqlSessionFactory;
    }

    public List<Map<String, Object>> selectByMemberName(String memberName) {
        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            return sqlSession.selectList("Workqueueview.selectByMemberName", memberName);
        } catch (Exception e) {
            return null;
        }
    }

    public List<Map<String, Object>> selectStarByHscId(long hsc_id) {
        try (SqlSession sqlSession = this.sqlSessionFactory.openSession()) {
            return sqlSession.selectList("Workqueueview.selectStarByHscId", hsc_id);
        } catch (Exception e) {
            return null;
        }
    }
}
