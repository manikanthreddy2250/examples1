package atdd.test.core;

import atdd.utils.Conf;

public class CsqaManager extends QaManager {
    protected CsqaManager(String csqaRootFolder) {
        super(csqaRootFolder);
    }

    public synchronized static CsqaManager getInstance() {
        if (null == instance) {
            String[] dirs = Conf.getInstance().getPropertyDeep("csqa_root_folder").split(",");
            instance = new CsqaManager(dirs[0]);
            if (dirs.length > 1) {
                for (int i = 1; i < dirs.length; i++) {
                    instance.merge(new CsqaManager(dirs[i]));
                }
            }
        }
        return instance;
    }

    public static void reset() {
        instance = null;
    }

    private static CsqaManager instance;
}
