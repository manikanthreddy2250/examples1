package atdd.test.core;

import java.util.Map;

public final class FomsQa {

    private String name;
    private Map<String, String> criteria;
    private Map<String, String> mskqas;
    private Map<String, String> backindexqas;
    private Map<String, String> neckindexqas;
    private Map<String, String> dashqas;
    private Map<String, String> lefsqas;
    private Map<String, String> otherqas;

    private String source;

    public FomsQa() {
    }

    public FomsQa(String name, Map<String, String> criteria, Map<String, String> mskqas,
                  Map<String, String> backindexqas) {
        this.name = name;
        this.criteria = criteria;
        this.mskqas = mskqas;
        this.backindexqas = backindexqas;

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Map<String, String> getCriteria() {
        return criteria;
    }

    public void setCriteria(Map<String, String> criteria) {
        this.criteria = criteria;
    }

    public Map<String, String> getMskqas() {
        return mskqas;
    }

    public void setMskqas(Map<String, String> mskqas) {
        this.mskqas = mskqas;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public Map<String, String> getBackindexqas() {
        return backindexqas;
    }

    public void setBackindexqas(Map<String, String> backindexqas) {
        this.backindexqas = backindexqas;
    }

    public Map<String, String> getNeckindexqas() {
        return neckindexqas;
    }

    public void setNeckindexqas(Map<String, String> neckindexqas) {
        this.neckindexqas = neckindexqas;
    }

    public Map<String, String> getDashqas() {
        return dashqas;
    }

    public void setDashqas(Map<String, String> dashqas) {
        this.dashqas = dashqas;
    }

    public Map<String, String> getLefsqas() {
        return lefsqas;
    }

    public void setLefsqas(Map<String, String> lefsqas) {
        this.lefsqas = lefsqas;
    }
    public Map<String, String> getOtherqas() {
        return otherqas;
    }

    public void setOtherqas(Map<String, String> otherqas) {
        this.otherqas = otherqas;
    }

}
