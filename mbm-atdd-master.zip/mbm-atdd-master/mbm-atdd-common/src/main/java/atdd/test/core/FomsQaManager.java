package atdd.test.core;

import atdd.utils.Conf;
import atdd.utils.QuickJson;
import atdd.utils.StringUtils;
import atdd.utils.TestUtils;
import org.apache.commons.io.FileUtils;
import org.junit.Assert;

import java.io.File;
import java.util.*;

public class FomsQaManager {

    private Map<String, FomsQa> qas = new LinkedHashMap<>();

    private Map<String, FomsQa> qaByFeature = new LinkedHashMap<>();

    private List<String> featureKeys = new LinkedList<>();

    public synchronized static FomsQaManager getInstance() {
        if (null == instance) {
            String[] dirs = Conf.getInstance().getPropertyDeep("foms_root_folder").split(",");
            instance = new FomsQaManager(dirs[0]);
            if (dirs.length > 1) {
                for (int i = 1; i < dirs.length; i++) {
                    instance.merge(new FomsQaManager(dirs[i]));
                }
            }
        }
        return instance;
    }

    public static void reset() {
        instance = null;
    }

    private static FomsQaManager instance;

    protected FomsQaManager(String qaRootFolder) {
        File rootFolder = TestUtils.projectFile(qaRootFolder);
        Assert.assertTrue(rootFolder.isDirectory());

        Set<String> criteriaKeys = new LinkedHashSet<>();
        for (File file : FileUtils.listFiles(rootFolder, new String[]{"json"}, true)) {
            FomsQa qa = (FomsQa) QuickJson.readValue(file, FomsQa.class);
            Assert.assertNotNull(qa);
            Assert.assertNull("Duplicated qa name: " + qa.getName(), qas.put(qa.getName(), qa));
            qa.setSource(file.getAbsolutePath());
            criteriaKeys.addAll(qa.getCriteria().keySet());
        }
        featureKeys.addAll(criteriaKeys);
        calculateQaByFeature();
    }


    public FomsQa getFomsQa(Map<String, String> pf) {
        String feature = getFeature(pf);
        return qaByFeature.get(feature);
    }

    public String getFeature(Map<String, String> pf) {
        String feature = "";
        for (String key : featureKeys) {
            String value = pf.get(key);
            if (!StringUtils.isEmpty(value)) {
                feature += key + "=" + value + ", ";
            }
        }
        feature = feature.substring(0, feature.length() - 2);
        return feature;
    }

    private void calculateQaByFeature() {
        qaByFeature.clear();
        for (FomsQa qa : qas.values()) {
            String feature = getFeature(qa.getCriteria());
            FomsQa dupQa = qaByFeature.put(feature, qa);
            if (null != dupQa) {
                Assert.fail("Duplicated feature [" + feature + "] with " + qa.getName() + " and " + dupQa.getName());
            }
        }
    }

    public Set<String> getNames() {
        return this.qas.keySet();
    }

    public Set<String> getFeatures() {
        return this.qaByFeature.keySet();
    }

    public List<String> getFeatureKeys() {
        return new ArrayList<>(featureKeys);
    }

    protected void merge(FomsQaManager anotherQaManager) {
        this.qas.putAll(anotherQaManager.qas);

        Set<String> allKeys = new LinkedHashSet<>();
        allKeys.addAll(this.featureKeys);
        allKeys.addAll(anotherQaManager.featureKeys);
        this.featureKeys.clear();
        this.featureKeys.addAll(allKeys);

        calculateQaByFeature();
    }
}
