package atdd.test.core;


import atdd.common.ImmediateAbortException;
import atdd.utils.*;
import cucumber.api.Scenario;
import org.openqa.selenium.WebDriver;

import java.util.LinkedHashMap;
import java.util.Map;

public abstract class PageWorkerBase extends AbstractStepSet {

    protected final Map<String, String> pf;

    protected Map<String, Map<String, String>> outcome = new LinkedHashMap<>();

    public PageWorkerBase(Scenario scenario, WebDriver webDriver, Map<String, String> pf) {
        super(scenario, webDriver);
        this.pf = pf;
    }

    public Map<String, Map<String, String>> getOutcome() {
        return this.outcome;
    }

    public abstract boolean accept();

    public abstract void work() throws ImmediateAbortException;

    protected abstract void handOff();

    protected abstract String getPageName();

    public String getShortPageName() {
        return TestUtils.shortName(this.getPageName());
    }

    protected void tryStopAtPageBegin() throws StopAtPageBeginException {
        if (Conf.getInstance().isDemo()) {
            TestUtils.demoBreakPoint(scenario(), driver(), "Landing on page: " + TestUtils.shortName(this.getPageName()));
            WhiteBoard.getInstance().putMap(getOwner(), getShortPageName(), collectStatus());
        }
        if (pf.containsKey(ExcelLib.STOP_AT_PAGE_BEGIN) && getPageName().contains(pf.get(ExcelLib.STOP_AT_PAGE_BEGIN))) {
            throw new StopAtPageBeginException(getPageName());
        }
    }

    protected void tryStopAtPage() throws StopAtPageException {
        if (Conf.getInstance().isDemo()) {
            TestUtils.demoBreakPoint(scenario(), driver(), "Page completed: " + TestUtils.shortName(this.getPageName()));
        }
        if (pf.containsKey(ExcelLib.STOP_AT_PAGE) && getPageName().contains(pf.get(ExcelLib.STOP_AT_PAGE))) {
            throw new StopAtPageException(getPageName());
        }
    }

    protected Map<String, String> collectStatus() {
        Map<String, String> status = new LinkedHashMap<>();
        status.put("timestamp", ZonedDateUtils.timestamp());
        try {
            long hscID = TestUtils.getHscIdFromURL(driver().getCurrentUrl());
            status.put("hscID", hscID + "");
        } catch (Exception e) {
            // do nothing
        }
        return status;
    }

}
