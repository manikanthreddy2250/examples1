package atdd.test.core;


import atdd.test.pageobjects.CommonPageObject;
import atdd.test.stepsets.AuthorizationRequest;
import atdd.utils.ExcelLib;
import atdd.utils.MBM;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.openqa.selenium.WebDriver;

import java.util.Map;

public abstract class PageWorkerCommon extends PageWorkerBase {

    private final CommonPageObject obj;

    public PageWorkerCommon(Scenario scenario, WebDriver webDriver, Map<String, String> pf) {
        super(scenario, webDriver, pf);
        this.obj = new CommonPageObject(scenario, webDriver);
    }

    protected CommonPageObject obj() {
        TestUtils.immediateAbortCheck(scenario());
        return obj;
    }




}
