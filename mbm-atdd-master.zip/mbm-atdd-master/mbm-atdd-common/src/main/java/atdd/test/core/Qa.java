package atdd.test.core;

import java.util.Map;

public final class Qa {

    private String name;
    private Map<String, String> criteria;
    private Map<String, String> qas;
    private String source;

    public Qa() {
    }

    public Qa(String name, Map<String, String> criteria, Map<String, String> qas) {
        this.name = name;
        this.criteria = criteria;
        this.qas = qas;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Map<String, String> getCriteria() {
        return criteria;
    }

    public void setCriteria(Map<String, String> criteria) {
        this.criteria = criteria;
    }

    public Map<String, String> getQas() {
        return qas;
    }

    public void setQas(Map<String, String> qas) {
        this.qas = qas;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }
}
