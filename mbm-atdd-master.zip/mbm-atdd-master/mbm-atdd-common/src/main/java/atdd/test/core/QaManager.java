package atdd.test.core;

import atdd.utils.QuickJson;
import atdd.utils.StringUtils;
import atdd.utils.TestUtils;
import org.apache.commons.io.FileUtils;
import org.junit.Assert;

import java.io.File;
import java.util.*;

public class QaManager {

    private Map<String, Qa> qas = new LinkedHashMap<>();

    private Map<String, Qa> qaByFeature = new LinkedHashMap<>();

    private List<String> featureKeys = new LinkedList<>();

    protected QaManager(String qaRootFolder) {
        File rootFolder = TestUtils.projectFile(qaRootFolder);
        Assert.assertTrue(rootFolder.isDirectory());

        Set<String> criteriaKeys = new LinkedHashSet<>();
        for (File file : FileUtils.listFiles(rootFolder, new String[]{"json"}, true)) {
            Qa qa = (Qa) QuickJson.readValue(file, Qa.class);
            Assert.assertNotNull(qa);
            Assert.assertNull("Duplicated qa name: " + qa.getName(), qas.put(qa.getName(), qa));
            qa.setSource(file.getAbsolutePath());
            criteriaKeys.addAll(qa.getCriteria().keySet());
        }
        featureKeys.addAll(criteriaKeys);
        calculateQaByFeature();
    }

//    public Map<String, String> getQas(Map<String, String> pf) {
//        String feature = getFeature(pf);
//        Qa qa = qaByFeature.get(feature);
//        return null == qa ? null : qa.getQas();
//    }

    public Qa getQa(Map<String, String> pf) {
        String feature = getFeature(pf);
        return qaByFeature.get(feature);
    }

    public String getFeature(Map<String, String> pf) {
        String feature = "";
        for (String key : featureKeys) {
            String value = pf.get(key);
            if (!StringUtils.isEmpty(value)) {
                feature += key + "=" + value + ", ";
            }
        }
        feature = feature.substring(0, feature.length() - 2);
        return feature;
    }

    private void calculateQaByFeature() {
        qaByFeature.clear();
        for (Qa qa : qas.values()) {
            String feature = getFeature(qa.getCriteria());
            Qa dupQa = qaByFeature.put(feature, qa);
            if (null != dupQa) {
                Assert.fail("Duplicated feature [" + feature + "] with " + qa.getName() + " and " + dupQa.getName());
            }
        }
    }

    public Set<String> getNames() {
        return this.qas.keySet();
    }

    public Set<String> getFeatures() {
        return this.qaByFeature.keySet();
    }

    public List<String> getFeatureKeys() {
        return new ArrayList<>(featureKeys);
    }

    protected void merge(QaManager anotherQaManager) {
        this.qas.putAll(anotherQaManager.qas);

        Set<String> allKeys = new LinkedHashSet<>();
        allKeys.addAll(this.featureKeys);
        allKeys.addAll(anotherQaManager.featureKeys);
        this.featureKeys.clear();
        this.featureKeys.addAll(allKeys);

        calculateQaByFeature();
    }
}
