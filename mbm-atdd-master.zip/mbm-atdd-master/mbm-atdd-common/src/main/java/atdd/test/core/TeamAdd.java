package atdd.test.core;

import atdd.common.ImmediateAbortException;
import atdd.test.pageobjects.NavigationPage;
import atdd.test.pageobjects.PageObject;
import atdd.test.stepsets.LostBrowserException;
import atdd.utils.ExcelLib;
import atdd.utils.MBM;
import atdd.utils.StringUtils;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;

import java.util.Map;
import java.util.Queue;

public abstract class TeamAdd extends TeamBase {

    public TeamAdd(Scenario scenario, Map<String, String> pf) throws ImmediateAbortException, LostBrowserException {
        super(scenario, pf);
    }

    protected PageObject obj() {
        return new PageObject(scenario(), driver());
    }

    @Override
    protected final Queue<PageWorkerBase> buildTeam(Map<String, String> pf) {
        Queue<PageWorkerBase> team = buildMyTeam(pf);
        adjustTeam(team, pf);
        return team;
    }

    protected abstract Queue<PageWorkerBase> buildMyTeam(Map<String, String> pf);

    @Override
    public void kickOff() {

        if (StringUtils.isEmpty(pf.get(ExcelLib.CONTINUE_FROM_PAGE))) {
            String payer = pf.get(MBM.PAYER);
            if (TestUtils.isElementVisible(driver(),NavigationPage.customerLockToolTip)){
                //assume that you will need to navigate home in case of failure if customer is locked
                obj().NavigationPage.navigatesToMenuItem("Home>Authorization>Add New");
            } else{
                obj().NavigationPage.navigateToCustomer(payer);
                obj().NavigationPage.navigatesToMenuItem("Home>Authorization>Add New");
            }
        }

    }

    private void adjustTeam(Queue<PageWorkerBase> team, Map<String, String> pf) {
        String authType = pf.get(MBM.AUTH_AUTHORIZATION_TYPE);
        String payer = pf.get(MBM.PAYER);
        if (ExcelLib.AUTH_TYPE_SPECIALTY_PHARMA.equals(authType)) {
            //TBD
        } else {
            String membType = pf.get(MBM.MEMB_TYPE);
            if (!ExcelLib.MEMB_TYPE_C_AND_S.equals(membType) && !ExcelLib.MEMB_TYPE_BCBS.equals(membType) && !ExcelLib.AUTH_TYPE_RADONC.equals(authType)) {
                if(!payer.equals(("Peoples Health Network")))
                removePageWorker(team, "ServicingProvider");
            }
        }
    }


    private static void removePageWorker(Queue<PageWorkerBase> team, String pageName) {
        PageWorkerBase theWorker = null;
        for (PageWorkerBase worker : team) {
            if (worker.getPageName().contains(pageName)) {
                theWorker = worker;
                break;
            }
        }
        if (null != theWorker) {
            team.remove(theWorker);
        }
    }

}
