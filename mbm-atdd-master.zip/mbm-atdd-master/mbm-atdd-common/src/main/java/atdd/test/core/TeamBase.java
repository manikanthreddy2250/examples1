package atdd.test.core;

import atdd.common.ICondition;
import atdd.common.ImmediateAbortException;
import atdd.common.Retry;
import atdd.test.stepsets.Login;
import atdd.test.stepsets.LostBrowserException;
import atdd.utils.*;
import cucumber.api.Scenario;
import org.apache.log4j.Logger;
import org.junit.Assert;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Queue;

public abstract class TeamBase extends AbstractStepSet {
    private static final Logger log = Logger.getLogger(TeamBase.class.getName());

    protected final Map<String, String> pf;

    protected Map<String, Map<String, String>> outcome = new LinkedHashMap<>();

    private long teamworkTimeoutInMillis = Integer.parseInt(Conf.getInstance().getProperty("teamworkTimeoutInMinutes")) * 60 * 1000;

    public TeamBase(Scenario scenario, Map<String, String> pf) throws ImmediateAbortException, LostBrowserException {
        super(scenario, Login.login(scenario, pf));
        this.pf = pf;
    }

    protected abstract Queue<PageWorkerBase> buildTeam(Map<String, String> pf);

    protected abstract void kickOff();

    public Map<String, Map<String, String>> getOutcome() {
        return this.outcome;
    }

    public final boolean teamwork() {
        return teamwork(teamworkTimeoutInMillis);
    }

    public final boolean teamwork(long teamworkTimeoutInMillis) {

        boolean success = new Retry("teamwork>" + TestUtils.shortName(this.getClass()), teamworkTimeoutInMillis, 0, 0) {

            @Override
            protected void tryOnce() throws Exception {
                try {
                    LinkedHashMap<String, String> pfWorking = new LinkedHashMap<>(pf);
                    setDriver(Login.login(scenario(), pfWorking));
                    Queue<PageWorkerBase> team = buildTeam(pfWorking);
                    stopAtNextPageBegin(pfWorking, team);

                    String continueFromPage = pfWorking.get(ExcelLib.CONTINUE_FROM_PAGE);
                    if (!StringUtils.isEmpty(continueFromPage)) {
                        while (null != team.peek() && !team.peek().getPageName().contains(continueFromPage)) {
                            team.poll();
                        }
                    }

                    Assert.assertTrue("No workers.", !team.isEmpty());

                    outcome.clear();
                    teamworkInQueue(team);
                } catch (ImmediateAbortException e) {
                    throw e;
                } catch (StopAtPageBeginException e) {
                    scenarioLogger.warn("Stop at page begin: " + e.getMessage());
                } catch (StopAtPageException e) {
                    scenarioLogger.warn("Stop at page: " + e.getMessage());
                }
             }

            @Override
            protected void weakRecover(Exception e) throws Exception {
                String continueFromPage = pf.get(ExcelLib.CONTINUE_FROM_PAGE);
                if (!StringUtils.isEmpty(continueFromPage)) {
                    throw new ImmediateAbortException("Unable to retry with " + ExcelLib.CONTINUE_FROM_PAGE + "=" + continueFromPage);
                }
            }

        }.execute();

        String note = (success ? "Success: " : "Timeout: ") + pf.get(MBM.AUTH_TITLE);
        TestUtils.demoBreakPoint(scenario(), this.driver(), note);

        return success;

    }

    private static void stopAtNextPageBegin(LinkedHashMap<String, String> pf, Queue<PageWorkerBase> team) {
        String stopAtNextPageBegin = pf.get(ExcelLib.STOP_AT_NEXT_PAGE_BEGIN);
        if (!StringUtils.isEmpty(stopAtNextPageBegin)) {
            String nextPage = null;
            for (PageWorkerBase worker : team) {
                if (null != nextPage) {
                    nextPage = worker.getPageName();
                    break;
                }
                if (stopAtNextPageBegin.equals(worker.getPageName()) || stopAtNextPageBegin.equals(worker.getShortPageName())) {
                    nextPage = "";
                }
            }
            if (!StringUtils.isEmpty(nextPage)) {
                pf.put(ExcelLib.STOP_AT_PAGE_BEGIN, nextPage);
            }
        }
    }

    private void teamworkInQueue(Queue<PageWorkerBase> workersInQueue)
            throws StopAtPageBeginException, StopAtPageException {

        boolean kickoffSuccess = new Retry("teamworkInQueue.kickoff>" + TestUtils.shortName(this.getClass())) {
            @Override
            protected void tryOnce() throws Exception {
                try {
                    kickOff();
                } catch (ImmediateAbortException e) {
                    throw e;
                } catch (Exception e) {
                    MbmUtils.immediateRecover(driver());
                    kickOff();
                }
            }

            @Override
            protected boolean until() throws Exception {
                if (new RetryAccept(workersInQueue).execute()) return true;
                else return false;
            }
        }.execute();

        if (kickoffSuccess) {
            scenarioLogger.warn("Kickoff success.");
        } else {
            scenarioLogger.error("Kickoff fail.");
            throw new RuntimeException("Unable to kickOff");
        }

        while (null != workersInQueue.peek()) {
            PageWorkerBase worker = workersInQueue.poll();

            worker.tryStopAtPageBegin();

            boolean workSuccess = new Retry("teamworkInQueue.work>" + TestUtils.shortName(this.getClass()) + ">" + worker.getShortPageName()) {
                @Override
                protected void tryOnce() throws Exception {
                    try {
                        worker.work();
                    } catch (ImmediateAbortException e) {
                        throw e;
                    } catch (Exception e) {
                        MbmUtils.immediateRecover(driver());
                        worker.work();
                    }
                }
            }.execute();

            if (workSuccess) {
                scenarioLogger.warn("Work success: " + worker.toString());
            } else {
                scenarioLogger.error("Work fail:" + worker.toString());
                throw new RuntimeException("Unable to work: " + worker.toString());
            }

            Map<String, Map<String, String>> workerOutCome = worker.getOutcome();
            if (null != workerOutCome) {
                outcome.putAll(workerOutCome);
            }

            worker.tryStopAtPage();

            boolean handOffSuccess = new Retry("teamworkInQueue.handOff>" + TestUtils.shortName(this.getClass()) + ">" + worker.getShortPageName()) {

                @Override
                protected void tryOnce() throws Exception {
                    try {
                        worker.handOff();
                    } catch (ImmediateAbortException e) {
                        throw e;
                    } catch (Exception e) {
                        MbmUtils.immediateRecover(driver());
                        try {
                            worker.handOff();
                        } catch (Exception e1) {
                            // do nothing in case next worker can accept already
                        }
                    }
                }

                @Override
                protected boolean until() throws Exception {
                    return new RetryAccept(workersInQueue).execute();
                }

                @Override
                protected long getSleepMillis() {
                    return 5 * 1000;
                }
            }.execute();

            if (handOffSuccess) {
                scenarioLogger.warn("Hand off and nextWorkerAccept success: " + worker.toString());
            } else {
                scenarioLogger.error("Hand off or nextWorkerAccept fail:" + worker.toString());
                throw new RuntimeException("Unable to hand off or nextWorkerAccept: " + worker.toString());
            }

        }

        boolean endSuccess = new Retry("teamworkInQueue.end>" + TestUtils.shortName(this.getClass())) {
            @Override
            protected void tryOnce() throws Exception {
                try {
                    end();
                } catch (ImmediateAbortException e) {
                    throw e;
                } catch (Exception e) {
                    MbmUtils.immediateRecover(driver());
                    end();
                }
            }
        }.execute();

        if (endSuccess) {
            scenarioLogger.warn("End success.");
        } else {
            scenarioLogger.error("End fail.");
            throw new RuntimeException("Unable to end");
        }

    }

    protected void end() {
        // do nothing by default
    }

    private boolean nextWorkerAccept(Queue<PageWorkerBase> workersInQueue) {
        PageWorkerBase nextPageWorker = workersInQueue.peek();
        if (null == nextPageWorker) {
            return true;
        } else {
            return TestUtils.waitUntil("nextWorkerAccept", 5, new ICondition() {
                @Override
                public boolean evaluate() throws Exception {
                    return nextPageWorker.accept();
                }
            });
        }
    }

    private class RetryAccept extends Retry {

        private final Queue<PageWorkerBase> workersInQueue;
        private boolean accepted = false;

        public RetryAccept(Queue<PageWorkerBase> workersInQueue) {
            super("Retry accept.");
            this.workersInQueue = workersInQueue;
        }

        @Override
        protected void tryOnce() throws Exception {
            try {
                accepted = nextWorkerAccept(workersInQueue);
                if (!accepted) {
                    MbmUtils.immediateRecover(driver());
                    accepted = nextWorkerAccept(workersInQueue);
                }
            } catch (Exception e) {
                MbmUtils.immediateRecover(driver());
                try {
                    accepted = nextWorkerAccept(workersInQueue);
                } catch (Exception e1) {
                    accepted = false;
                }
            }
        }

        @Override
        protected boolean until() throws Exception {
            return accepted;
        }
    }

}
