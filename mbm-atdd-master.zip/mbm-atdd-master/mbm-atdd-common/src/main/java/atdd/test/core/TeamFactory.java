package atdd.test.core;

import atdd.common.ImmediateAbortException;
import atdd.test.stepsets.LostBrowserException;
import cucumber.api.Scenario;

import java.lang.reflect.Constructor;
import java.util.Map;

public class TeamFactory {

    public static TeamBase getTeam(Scenario scenario, Map<String, String> pf) throws ImmediateAbortException, LostBrowserException {
        try {
            String teamClassName = pf.get("team");
            Class teamClass = Class.forName(teamClassName);

            Class<?>[] paramTypes = new Class<?>[]{Scenario.class, Map.class};
            Constructor<?> constructor = teamClass.getDeclaredConstructor(paramTypes);

            Object[] params = new Object[]{scenario, pf};
            return (TeamBase) constructor.newInstance(params);
        } catch (Exception e) {
            throw new ImmediateAbortException(e.getMessage());
        }
    }

}
