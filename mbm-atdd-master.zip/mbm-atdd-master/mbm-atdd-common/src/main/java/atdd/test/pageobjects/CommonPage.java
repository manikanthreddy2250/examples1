package atdd.test.pageobjects;

import atdd.common.ICondition;
import atdd.common.WaitUntil;
import atdd.utils.SizzleSelector;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.apache.commons.io.FileUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.log4j.Logger;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.html5.LocalStorage;
import org.openqa.selenium.html5.WebStorage;
import org.openqa.selenium.remote.RemoteExecuteMethod;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.html5.RemoteWebStorage;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import static org.openqa.selenium.By.cssSelector;

public class CommonPage {

    public static final String F_ERRMSG_XPATH = "//span/span[. = '%s']";

    private Logger log;
    private WebDriver driver;
    private Scenario scenario;
    private String owner;

    public static final By loadingBox = By.xpath("//div[contains(@id,'busyIndicatorBox')]");
    public static final By globalMessagesDescription = By.id("globalMessages-description");
    public static final By globalMessageXButton = By.xpath("//button[@ng-click='closeMessage()']");
    public static final By optumLogoBcbsEnv = By.xpath("//img[contains(@src,'logo') and @alt = 'Blue Cross Blue Shield Medical Benefit Management']");
    public static final By optumLogoUhcEnv = By.xpath("//img[@ng-src='images/optum_logo.svg' and @alt='United HealthCare Medical Benefit Management']");
    public static final By uhcProviderLogo = By.xpath("//img[@ng-src='images/logo.svg' and @alt='United HealthCare Medical Benefit Management']");
    public static final By headerColor = By.id("globalNavigationMenu");
    public static final By termsAndconditions = By.xpath("//div[@class='terms-contents ng-scope']");
    public static final By privacyPolicyContent = By.xpath("//div[@id='privacyPolicyPanelIdContent']");
    public static final By loginpagePrivacyPolicy = By.xpath("//div[@class='privacy-content ng-scope']");
    public static final By termsAndconditionsHome = By.xpath("//div[@id='termsOfUsePanelIdContent']");
    public static final By requiredFieldValidationMessage = By.id("//*[text()='Review the form and correct the highlighted fields']");
    public static final By continueButton = cssSelector("[id='regimensPanelIdContent'] [class='continue-button ng-scope tk-btn']");
    public static final By deliveryTypeDropdown = By.xpath("//select[contains (@id, 'letterData-deliveryType')]");
    public static final By letterTypeDropdown = By.xpath("//select[contains (@id, 'letterData-letterType')]");
    public static final By hoursLetterSent = By.xpath("//input[contains (@id, 'hours')]");
    public static final By mimnutesLetterSent = By.xpath("//input[contains (@id, 'minutes')]");
    public static final By selectAllCheckBox = By.name("All Checked");

    public static final By closeAuthorizationRequestLink = By.xpath("//a[contains(text(),'Close Authorization Request')]");
    public static final By closeReasonSelect = By.xpath("//form[@name='closeAuthForm']//select[@ref-nm='hscStatusReasonType']");
    public static final By closeRequestButton = By.xpath("//form[@name='closeAuthForm']//input[@value='Notification requirements met']");
    public static final By downloadPDF = By.xpath("//a[@id='pdf-download']");
    public static final By refreshButton = By.xpath("//input[@value='Refresh']");
    public static final By faxNumber = By.xpath("//input[contains (@id, 'faxNumberInput')]");
    public static final By phoneNumber = By.xpath("//input[contains (@id, 'phone')]");
    public static final By faxType = By.xpath("//select[contains (@ng-model, 'selectedFaxType')]");
    public static final By sendFaxButton = By.xpath("//input[@value='Send Fax']");
    public static final By letterViewable = By.id("//span[text()='Viewable']");
    public static final By saveFaxButton = By.xpath("//input[@ng-click='sendFax(false)']");
    public static final By contactName = By.xpath("//input[contains (@id, 'memberDemo-assignedToName-0')]");
    public static final By question = By.xpath("//label[text()='Is the request for initial infusion or re-initiation of therapy after more than 6 months?']");

    public static By continueButtonPreferred = By.xpath("//input[@ng-click='preferredDrugPopupModel.preferredDrugContinue();']");

    public static final By createLetterBtn = By.xpath("//input[@type='button' and  @value='Create Letter']");
    public static final By letterHistoryLink= By.xpath("//a[@ng-click='showLetterHistory()']");
    public static final By downloadPdfLinkXpath = By.xpath("//a[@id='pdf-download']");
    public static final By pdfPreviewIEXpath = By.xpath("//iframe[@id='letterPdfViewIframe' and @ng-if='isIE == true']");
    public static final By pdfPreviewChromeXpath=By.xpath("//object[@ng-if='isIE == false' and @id='letterPdfView']");
    public static final By viewIconXpath = By.xpath("//tr[@ng-if='letterHistory.records.length != 0'][1]//following-sibling::span[@ng-click='letterPreview(record, $event)']");

    public static final By isChangeCredPopup = By.xpath("//*[@id='credentialValidationPopupModelID']");
    private static final String COOKIE_KEY = "cookie";

    public static final By authStatusMesasge = By.xpath("//p[@class='approvedDescriptionDiv ng-scope']");
    public static By continueButtonAuthorization = By.xpath("//input[@ng-click='authNotificationContinue()']");
 //   public static By okayButtonFractionExceeded = By.xpath("//input[@ng-click='hypoFractionPolicyPopupModel.closePopup();saveHscAdditionalServices()']");
    public static By okayButtonFractionExceeded = By.xpath("//input[contains (@ng-click, 'saveHscAdditionalServices()')]");


    public CommonPage(WebDriver webDriver) {
        this.driver = webDriver;
        log = Logger.getLogger(this.getClass().getName());
    }

    /**
     * Opens a new tab and switches to it.
     */
    public void opensNewTab() {
        driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL + "t");
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(0));
    }

    /**
     * Waiting for Loading popup
     */
    public void waitForNOTBusyIndicator() {
        log.warn("Waiting for NOT busy indicator...");
        try {
            TestUtils.waitForNotBusy(driver);
        } catch (Exception e) {
            // do nothing
        }
    }

    /**
     * Waiting for seconds in param
     *
     * @param sec
     */
    public void waitForSec(int sec) {
        TestUtils.wait(sec);
    }

    /**
     * Getting item value from the browser local storage
     *
     * @param item
     * @return String
     */
    public String util_GetItemFromLocalStorage(String item) {
        String itemLocalStorage = TestUtils.getItemFromLocalStorage(driver, item);
        log.warn("Local Storage Value: " + itemLocalStorage);
        return itemLocalStorage;
    }

    /**
     * Checking that URL request returns expected code
     *
     * @param URL
     * @param resp
     */
    public void verifyURLStatus(String URL, int resp) {
        log.warn("Checking that URL " + URL + " request returns expected code " + resp);
        HttpClient client = HttpClientBuilder.create().build();
        HttpGet request = new HttpGet(URL);
        try {
            HttpResponse response = client.execute(request);
            int respCode = response.getStatusLine().getStatusCode();

            Assert.assertTrue("Responce: " + respCode + " Expected: " + resp, resp == respCode);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * Check that element with Text has Required mark
     *
     * @param txt
     */
    public void checkRequiredElementByText(String txt) {

        TestUtils.wait(3);
        String xpath = "//*[contains(text(),'" + txt + "')]/span[@title='Required']";
        boolean present = false;

        //Checking
        if (TestUtils.isElementVisible(driver, xpath)) {
            present = true;
        }

        Assert.assertTrue("Element with text " + txt + " is NOT visible. ", present);
    }

    /**
     * Maximize browser window
     *
     * @return
     */
    public CommonPage maximizeBrowser() {
        Capabilities caps = ((RemoteWebDriver) driver).getCapabilities();
        String browserName = caps.getBrowserName();

        if (driver instanceof FirefoxDriver || browserName.equals("firefox") || browserName.equals("internet explorer"))
            driver.manage().window().maximize();
        else if (driver instanceof ChromeDriver || browserName.equals("chrome")) {
            // Toolkit doesn't work on Saucelabs because it started on Jenkins server.
            //   Toolkit toolkit = Toolkit.getDefaultToolkit();
            //   int Width = (int) toolkit.getScreenSize().getWidth();
            //   int Height = (int) toolkit.getScreenSize().getHeight();
            //   log.warn("Screen size: " + Width + "*" + Height);
            driver.manage().window().setPosition(new Point(0, 0));
            driver.manage().window().setSize(new Dimension(1600, 1200));
        } else
            log.error("Can't recognize browser to maximize");

        return this;
    }


    /**
     * Checking that current URL contains expected part
     *
     * @param urlPart
     */
    public void checkCurrentURL(String urlPart) {
        String currUrl = driver.getCurrentUrl();

        Assert.assertTrue("URL does not contains" + urlPart + ". Currect URL is: " + currUrl,
                currUrl.contains(urlPart));
    }

    /**
     * Checking page Title
     *
     * @param titleName
     */
    public void checkPageTitle(String titleName) {
        TestUtils.wait(4);
        String titletext = driver.getTitle();
        log.warn("Checking page title. Title is: " + titletext);
        Assert.assertTrue("Title is not " + titleName + ". Currect title is: " + titletext,
                titletext.equals(titleName));
    }

    /**
     * Check that Element by this Xpath is visible
     *
     * @param by
     */
    public void checkElementByXpath(By by) {
        TestUtils.wait(3);

        boolean present = false;

        //Checking
        if (TestUtils.isElementVisible(driver, by)) {
            present = true;
        }

        Assert.assertTrue("Element " + by + " is NOT visible. ", present);
    }

    /**
     * Check that Element with expected text is present
     *
     * @param txt
     */
    public void checkElementByText(String txt) {
        log.warn("Checking element by " + txt + " text");
        TestUtils.wait(2);
        By elementTxt = By.xpath("//*[contains(text(),\"" + txt + "\")]");

        boolean present = false;

        //Checking
        if (TestUtils.isElementVisible(driver, elementTxt)) {
            TestUtils.onMouseHover(driver, elementTxt);
            present = true;
        }

        Assert.assertTrue("Element with text " + txt + " is NOT visible. ", present);

    }

    /**
     * Check that Element with expected text is present
     *
     * @param txt
     */
    public void checkNotElementByText(String txt) {
        log.warn("Checking that element by " + txt + " text is not present");
        TestUtils.wait(3);
        By elementTxt = By.xpath("//*[contains(text(),'" + txt + "')]");

        boolean present = false;

        //Checking
        if (TestUtils.isElementVisible(driver, elementTxt)) {
            present = true;
        }

        Assert.assertFalse("Element with text " + txt + " is visible. ", present);

    }

    /**
     * return window counts
     *
     * @return
     */
    public int countWindows() {
        Set<String> winHandle = driver.getWindowHandles();

        int winNum = winHandle.size();

        return winNum;
    }

    /**
     * Counting windows and jumping by number
     *
     * @param windowNumber
     */
    public void switchWindowTo(int windowNumber) {
        int tmp = 1;

        // Switch to new window opened
        for (String winHandle : driver.getWindowHandles()) {
            driver.switchTo().window(winHandle);
            String windowName = driver.getTitle();

            if (windowNumber == tmp) break;
            tmp++;
            log.warn("Window Name: " + windowName);
        }
    }

    /**
     * Getting window names and switching by name
     *
     * @param windowTitle
     */
    public void switchWindowTo(String windowTitle) {
        boolean found = false;
        for (String winHandle : driver.getWindowHandles()) {
            driver.switchTo().window(winHandle);
            String windowName = driver.getTitle();

            log.warn("Switch to Window Name: " + windowName);

            if (windowName.trim().equals(windowTitle)) {
                log.warn("Window found: " + windowName);
                found = true;
                break;
            }
        }
        Assert.assertTrue("Window " + windowTitle + " is not found!", found);
    }

    /**
     * If alert is present, click accept
     */
    public void acceptAlert() {
        TestUtils.wait(2);
        Alert alert = driver.switchTo().alert();
        String alertText = alert.getText();
        log.warn("Alert data: " + alertText);
        alert.accept();
        driver.switchTo().defaultContent();
    }

    /**
     * User clicks A hyperlink
     *
     * @param hyperLinkName
     */
    public void clickOnHyperlink(String hyperLinkName) {
        By hyperlink = By.xpath("//a[contains(text(),'" + hyperLinkName + "')]");
        TestUtils.waitElementVisible(driver, hyperlink);
        TestUtils.wait(3);
        driver.findElement(hyperlink).click();
    }

    /**
     * User clicks A button
     *
     * @param buttonText
     */
    public void userClicksAButton(String buttonText) {
        List<WebElement> elements = SizzleSelector.findElementsByCss(driver, "input[value='" + buttonText + "'], button[value='" + buttonText + "'], button span.oui-a11y-hidden:contains(" + buttonText + ")");
        Iterator var3 = elements.iterator();
        TestUtils.wait(1);

        while (true) {
            WebElement element;
            do {
                if (!var3.hasNext()) {
                    return;
                }

                element = (WebElement) var3.next();
                TestUtils.wait(1);
            }
            while (!buttonText.equals(element.getText()) && (!buttonText.equals(element.getAttribute("value")) || !element.isDisplayed()));

            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
            TestUtils.wait(1);
        }
    }

    /**
     * Verfyies success msg
     */
    public void successMsgDisplay() {
        TestUtils.wait(3);
        String warningMsg = "Success";
        String css = "span[id*='lobalMessages'] span";
        Assert.assertEquals(warningMsg, TestUtils.waitUntilTextIsDisplay(driver, By.cssSelector(css), warningMsg));
    }

    /**
     * verifies header text
     *
     * @param expectedHeader
     */
    public boolean verifyHeader(String expectedHeader) {
        TestUtils.wait(3);
        String headerXpath = "(//h1|//h2|//h3|//h4|//strong)[contains(.,'" + expectedHeader + "')]";
        List<WebElement> els = TestUtils.findElements(driver, headerXpath);
        return 1 == els.size();
    }

    /**
     * wait header text
     *
     * @param expectedHeader
     */
    public boolean waitHeader(String expectedHeader, long timeoutInSeconds) {
        return new WaitUntil("waitHeader: " + expectedHeader,
                timeoutInSeconds * 1000, 1000, 1000,
                new ICondition() {
                    @Override
                    public boolean evaluate() throws Exception {
                        return verifyHeader(expectedHeader);
                    }
                }).execute();
    }


    /**
     * Try to not use this!!! Use waitelement
     */
    public void WaitsForFewSeconds() throws InterruptedException {
        Thread.sleep(5000);
    }

    /**
     * globalMessages-description
     */
    public String getGlobalMessagesDescription() {
        TestUtils.waitElementVisible(driver, globalMessagesDescription);
        return this.driver.findElement(globalMessagesDescription).getText();
    }

    /**
     * Is Error message visible
     *
     * @param errmsg
     * @return
     */
    public boolean isErrorMessageVisible(String errmsg) {
        try {
            String xpath = String.format(F_ERRMSG_XPATH, errmsg);
            Wait wait = new WebDriverWait(this.driver, 5000);
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
            log.warn("[" + errmsg + "] is visible");
            return true;
        } catch (Exception e) {
            log.warn("[" + errmsg + "] is NOT visible");
            return false;
        }

    }

    public void verifyBcbslogo() {
        Assert.assertTrue(TestUtils.isElementVisible(this.driver, optumLogoBcbsEnv));
        Assert.assertEquals("optum header background color does not match", "#63666a",
                Color.fromString(this.driver.findElement(headerColor).getCssValue("background-color")).asHex());
    }

    /**
     * verifies the privacy policy
     */

    public void verifyContentOfPrivacyPolicy() throws Exception {


        TestUtils.waitElementVisible(driver, privacyPolicyContent);
        String uiText = driver.findElement(privacyPolicyContent).getText();
        File filePath = TestUtils.projectFile("mbm-atdd-cgp-bcbs", "/src/main/resources/samplefilesforupload/privacy policy.txt");
        boolean condition;
        condition = compareText(uiText, filePath);
        Assert.assertTrue("privacy policy dont match", condition);

    }

    /**
     * verifies the privacy policy  on login page
     */
    public void verifyContentOfPrivacyPolicyOnLogin() throws IOException {
        log.warn("verifying the privacy policy");
        TestUtils.waitElementVisible(driver, loginpagePrivacyPolicy);
        String uiText = driver.findElement(loginpagePrivacyPolicy).getText();
        File filePath = TestUtils.projectFile("mbm-atdd-cgp-bcbs", "/src/main/resources/samplefilesforupload/privacy policy.txt");
        boolean condition;
        condition = compareText(uiText, filePath);
        Assert.assertTrue("privacy policy dont match", condition);
    }

    /**
     * verifies the terms and conditions on login page
     */
    public void verifyContentOfTermsAndConditionsOnLogin() throws IOException {

        TestUtils.waitElementVisible(driver, termsAndconditions);
        String uiText = driver.findElement(termsAndconditions).getText();
        File filePath = TestUtils.projectFile("mbm-atdd-cgp-bcbs", "/src/main/resources/samplefilesforupload/terms and conditions.txt");
        boolean condition;
        condition = compareText(uiText, filePath);
        Assert.assertTrue("terms and conditions dont match", condition);
    }

    /**
     * compare uitext with file content
     */
    private boolean compareText(String uiText, File filePath) throws IOException {
        String fileName = filePath.getPath();
        String expectedMessage = FileUtils.readFileToString(new File(fileName));
        expectedMessage = expectedMessage.replaceAll("[^\\p{Graph}]", "");
        uiText = uiText.contains("\n\n") ? uiText.replace("\n\n", "") : uiText;
        uiText = uiText.replaceAll("[^\\p{Graph}]", "");
        uiText = uiText.contains("\"") ? uiText.replace("\"", "") : uiText;
        expectedMessage = expectedMessage.contains("\"") ? expectedMessage.replace("\"", "") : expectedMessage;
        return uiText.equalsIgnoreCase(expectedMessage);
    }

    /**
     * verifies the terms and conditions
     */
    public void verifyContentOfTermsAndConditions() throws IOException {

        TestUtils.waitElementVisible(driver, termsAndconditionsHome);
        String uiText = driver.findElement(termsAndconditionsHome).getText();
        File filePath = TestUtils.projectFile("mbm-atdd-cgp-bcbs", "/src/main/resources/samplefilesforupload/terms and conditions.txt");
        boolean condition;
        condition = compareText(uiText, filePath);
        Assert.assertTrue("terms and conditions dont match", condition);
    }

    public void dismissGlobalMessage() {
        TestUtils.click(driver, globalMessageXButton);
    }

    /**
     * verifies payer dropdown values
     */
    public void verifyPayerDropdownValues(String tab, List<String> expectedLabelvalues) {
        By payerLabel = By.xpath("//div[@id='" + tab + "Panel']//td[contains(text(),'Payer')]");
        log.warn("Verifies Payer dropdown is displayed on Prior Auth search page");
        Assert.assertTrue("Payer dropdown is not displayed on Prior Auth search page", driver.findElement(payerLabel).isDisplayed());
        By payerDropdown = By.xpath("//div[@id='" + tab + "Panel']//select[@ng-model='selectPayer.payers']");
        TestUtils.click(driver, payerDropdown);
        Select payerValues = new Select(driver.findElement(payerDropdown));
        List<WebElement> payer = payerValues.getOptions();
        for (int i = 0; i < expectedLabelvalues.size(); i++) {
            log.warn(payer.get(i).getText());
            Assert.assertTrue("Dropdown value is missing " + expectedLabelvalues.get(i), payer.get(i).getText().contains(expectedLabelvalues.get(i)));
        }
    }



    /**
     * verifies payer dropdown is not present
     */
    public void verifyPayerDropdownIsnotPresent(String tab) {
        By payerLabel = By.xpath("//div[@id='" + tab + "Panel']//td[contains(text(),'Payer')]");
        log.warn("Verifies Payer dropdown is not displayed on Prior Auth search page");
        Assert.assertFalse("Payer dropdown is displayed on the Prior auth search page", TestUtils.isElementPresent(driver, payerLabel));

    }

    public void clickElementByText(String txt) {
        log.warn("Checking element by " + txt + " text");
        TestUtils.wait(2);
        By elementTxt = By.xpath("//button[contains(text(),\"" + txt + "\")]");
        TestUtils.click(driver, elementTxt);

    }

    /*
 This method is to expand first row in  Activities table
  */
    public void expandFirstRowInActivities() {

        List<WebElement> tableRows = driver.findElements(By.xpath("//table[@id = 'viewActivityTrackingWorkQueueID']/tbody/tr"));
        int numberOfRows = tableRows.size();
        List<String> expectedValue = new ArrayList<>();

        for (int i = 1; i <= numberOfRows; i++) {
            System.out.println("//table[@id = 'viewActivityTrackingWorkQueueID']/tbody/tr[" + i + "]/td");
            List<WebElement> tableColumn = driver.findElements(By.xpath("//table[@id = 'viewActivityTrackingWorkQueueID']/tbody/tr[" + i + "]/td/span"));

            int numberOfColumns = tableColumn.size();
            //driver.findElement(By.xpath("//table[@id='viewActivityTrackingWorkQueueID']/tbody/tr["+i+"]/td["+0+"]")).click();
            tableColumn.get(0).click();
            break;
        }

    }

    /**
     * verifies message on contact us page
     */
    public void verifyMessageOnContactUsPage(String actual) {
        By message = By.xpath("//div[@ng-bind-html='contactUsText']");
        TestUtils.waitElementVisible(driver, message);

        Assert.assertTrue("message is not same", driver.findElement(message).getText().contains(actual));
    }

    public String cookieForWhiteboard() {
        Set<Cookie> cookies = driver.manage().getCookies();
        String stringCookie = "";
        for (Cookie cookie : cookies) {
            stringCookie += cookie.toString() + "; ";
        }
        return stringCookie;

    }

    public void setBrowserCookie(String stringCookie) {
//        WhiteBoard.getInstance().putString(getOwner(), COOKIE_KEY, stringCookie);
        modifyFile("/Users/rcraven3/mbm-atdd/mbm-atdd-common/src/main/resources/apiTemplates/archive/mbmFlow/headerFlow.txt", "textToReplace", stringCookie);
    }

    public void resetBrowserHeaderFile(String stringCookie) {
//        WhiteBoard.getInstance().putString(getOwner(), COOKIE_KEY, stringCookie);
        modifyFile("/Users/rcraven3/mbm-atdd/mbm-atdd-common/src/main/resources/apiTemplates/archive/mbmFlow/headerFlow.txt", "textToReplace", "textToReplace");
    }

    public String getOwner() {
        TestUtils.immediateAbortCheck(scenario);
        return this.owner;
    }

    static void modifyFile(String filePath, String oldString, String newString) {
        File fileToBeModified = new File(filePath);
        String oldContent = "";
        BufferedReader reader = null;
        FileWriter writer = null;
        try {
            reader = new BufferedReader(new FileReader(fileToBeModified));
            //Reading all the lines of input text file into oldContent
            String line = reader.readLine();
            while (line != null) {
                oldContent = oldContent + line + System.lineSeparator();
                line = reader.readLine();
            }
            //Replacing oldString with newString in the oldContent
            String newContent = oldContent.replaceAll(oldString, newString);
            //Rewriting the input text file with newContent
            writer = new FileWriter(fileToBeModified);
            writer.write(newContent);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                //Closing the resources
                reader.close();
                writer.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void newLineInTextFile(String filePath, String newText) {
        Writer output;
        try {
            output = new BufferedWriter(new FileWriter(filePath));
            output.append(newText);
            output.close();
        }catch (Exception e) {}
    }

    public void userClicksContinueButton(){

        TestUtils.click(driver, continueButton);

    }

    public void verifyPopUpMessageOral(String expectedHeader) {

        List<WebElement>  elements = driver.findElements(By.xpath("//*[contains(text(), 'Pharmacy Benefits Notification')]"));

        log.info("Checking popup header. Header is: "  + elements.get(0).getText());
        Assert.assertTrue("Header is not matching with " + expectedHeader + ". Currect header is: " + expectedHeader,
                (elements.size() > 0));
    }


    public void userInputsInDeliveryTypeField(String deliveryType) {

        log.warn("Select Delivery Type On the Delivery dropdown " + deliveryType);
        TestUtils.waitElement(driver, deliveryTypeDropdown);
        TestUtils.selectByVisibleText(driver, deliveryTypeDropdown, deliveryType);

    }

    public void userInputsInLetterTypeField(String letterType) {

        log.warn("Select Letter Type On the Letter dropdown " + letterType);
        TestUtils.waitElement(driver, letterTypeDropdown);
        TestUtils.selectByVisibleText(driver, letterTypeDropdown, letterType);

    }

    public void userInputsInHoursLetterSent(String hours) {

        log.warn("Hourse entered in Send Letter " + hours);
        //TestUtils.waitElement(driver, letterTypeDropdown);
        driver.findElement(hoursLetterSent).sendKeys(hours);

    }

    public void userInputsInminutesLetterSent(String minmutes) {

        log.warn("Minmutes entered in Send Letter " + minmutes);
        driver.findElement(mimnutesLetterSent).sendKeys(minmutes);

    }

    public void closeAuthorizationRequest(String reason) {
        TestUtils.click(driver, closeAuthorizationRequestLink);
        TestUtils.input(driver, closeReasonSelect, reason);
        userClicksAButton("Close Authorization Request");
        TestUtils.wait(2);
    }


    public void userClicksDownloadPDFButton() {

        TestUtils.click(driver, downloadPDF);


        File file = new File("/Users/sdevi20/Downloads/download.pdf");
        try {
            PDDocument document = PDDocument.load(file);
            PDFTextStripper pdfStripper = new PDFTextStripper();
            String text = pdfStripper.getText(document);
            Assert.assertTrue(text.contains("NOTICE OF APPROVAL"));
            document.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            TestUtils.wait(2);
            file.delete();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void userClicksRefreshutton() {
        TestUtils.click(driver, refreshButton);
        TestUtils.wait(2);
    }


    /**
     * verifies header text
     *
     * @param expected
     */
    public boolean verifyRefresh(String expected) {
        List<WebElement> els = TestUtils.findElements(driver, refreshButton);
        return 1 == els.size();
    }

    /**
     * wait header text
     *
     * @param expected
     */
    public boolean waitForRefresh(String expected, long timeoutInSeconds) {

        long t1 = System.currentTimeMillis() + (timeoutInSeconds * 1000);
        while (System.currentTimeMillis() < t1) {
            try {
                Wait wait = new WebDriverWait(driver, timeoutInSeconds);
                wait.until(ExpectedConditions.visibilityOfElementLocated(letterViewable));
                log.warn("waitElementVisible: true");
                return true;
            } catch (Exception e) {
                //do nothing
            }
        }
        log.warn("waitElementVisible: false");
        return false;

    }


    public void userInputsFaxNumber(String faxNumberInput) {

        log.warn("Enter Fax Number " + faxNumberInput);
        driver.findElement(faxNumber).sendKeys(faxNumberInput);

    }


    public void userInputsPhoneNumber(String phoneNumberInput) {

        log.warn("Enter Phone Number " + phoneNumberInput);
        driver.findElement(phoneNumber).sendKeys(phoneNumberInput);

    }

    public void userInputsName(String name) {

        log.warn("Enter Name " + name);
        driver.findElement(contactName).sendKeys(name);

    }

    public void userInputsFaxType(String faxTypeInput) {

        log.warn("Enter Fax Type " + faxTypeInput);
        TestUtils.waitElement(driver, faxType);
        TestUtils.selectByVisibleText(driver, faxType, faxTypeInput);

    }

    public void userClicksSendFaxButton() {

        log.warn("User Clicks Send Fax Button ");
        TestUtils.click(driver, sendFaxButton);
        TestUtils.wait(2);

    }



    public void userClicksSaveFaxButton() {

        log.warn("User Clicks Save Fax Button ");
        TestUtils.wait(2);
        TestUtils.click(driver, saveFaxButton);

    }


    public void validateTATPage() {
        log.warn("User Validates TAT Page ");
        String  ele = TestUtils.findElements(driver,"//table[@class = 'tatTable']/tbody/tr[3]/td[7]").get(0).getText();
        Assert.assertFalse(ele.isEmpty());
//        Assert.assertTrue(ele.startsWith(TestUtils.getTomorrowDateMMddyyyy()));
    }



    public void userValidatedQuestionOnAuthpage() {
        log.warn("User Validates quesion on Authorization Type Page ");
        String  ele = TestUtils.findElements(driver,question).get(0).getText();
        Assert.assertFalse(ele.isEmpty());
    }

    public void userClicksContinueButtonPreferredPopUp(){

        TestUtils.click(driver, continueButtonPreferred);

    }

    public void userClicksContinueButtonAuthorizationPopUp(){

        TestUtils.click(driver, continueButtonAuthorization);

    }

    public void userClicksOkayButtonPopUp(){

        TestUtils.click(driver, okayButtonFractionExceeded);

    }


    public void refreshesCacheFromSystemSettings() {
        NavigationPage np = new NavigationPage(driver);
        By element = By.xpath("//ul[@id='globalNavigationMenu']//span[text()='System Settings']");
        TestUtils.click(driver, element);
        TestUtils.wait(2);
        np.clickOptionFromTopNavMenu("Refresh Cache");
        TestUtils.wait(3);
        TestUtils.click(driver, selectAllCheckBox);
        TestUtils.wait(2);
        TestUtils.click(driver, refreshButton);

    }

    public void selectTypeInCommunication(String communicationType) {
        String id="";
        communicationType=communicationType.toUpperCase();
        switch (communicationType) {
            case "FAX":
                id = "communicationTypeFaxRadio";
                break;
            case "LETTER":
                id = "communicationTypeLetterRadio";
                break;
        }
        String option = "//input[@id='"+id+"']" ;
        WebElement optionXpath = driver.findElement(By.xpath(option));
        TestUtils.wait(2);
        TestUtils.click(driver,optionXpath);
    }
    public void selectOptionInSendLetterTo(String option){

        String text="";
        option=option.toUpperCase();
        switch (option) {
            case "SERVICING PROVIDER":
                text = "Servicing Provider";
                break;
            case "REQUESTING PROVIDER":
                text = "Requesting Provider";
                break;
            case "MEMBER":
                text = "Member";
                break;
        }
        String type = "//span[text()='"+text+"']//..//preceding-sibling::td//input[@type='radio']" ;
        WebElement optionXpath = driver.findElement(By.xpath(type));
        TestUtils.wait(2);
        TestUtils.click(driver,optionXpath);

    }

    public void clickLetterHistory(){
        log.warn("Click on Letter history link");
        TestUtils.wait(5);
        TestUtils.click(driver,letterHistoryLink);
        TestUtils.wait(5);

    }
    public void clickCreateLetterBtn(){
        log.warn("Click on create letter button");
        TestUtils.wait(2);
        TestUtils.click(driver,createLetterBtn);
        TestUtils.wait(8);
    }

    public void letterHistoryRecordsDisplayed(String option1, String option2,String option3){
        if(!(TestUtils.isElementVisible(driver,viewIconXpath))) {
            selectOptionInSendLetterTo(option1);
            userInputsInDeliveryTypeField(option2);
            userInputsInLetterTypeField(option3);
            clickCreateLetterBtn();
            TestUtils.click(driver,refreshButton);
            Assert.assertTrue(TestUtils.isElementVisible(driver,viewIconXpath));

        }
        else {

            Assert.assertTrue(TestUtils.isElementVisible(driver,viewIconXpath));
        }

    }

    public void clickLetterHistoryPDFView(){

        TestUtils.onMouseHover(driver, viewIconXpath);
        TestUtils.wait(5);
        TestUtils.safeClick(driver, viewIconXpath);
        TestUtils.wait(5);

    }

    public void verifyPdfPreviewinLetter(){
        log.warn("Verifying whether Download PDF link and PDF Preview is displayed ");
        TestUtils.wait(3);
        Assert.assertTrue(TestUtils.isElementVisible(driver,downloadPdfLinkXpath));
        if(TestUtils.isElementVisible(driver,pdfPreviewIEXpath)){
            log.warn("Verifying pdf review in IE Browser");
            Assert.assertTrue(TestUtils.isElementVisible(driver,pdfPreviewIEXpath));
        }
        else {
            log.warn("Verifying pdf review in Chrome Browser");
            Assert.assertTrue(TestUtils.isElementVisible(driver,pdfPreviewChromeXpath));
        }
    }

    public void changevalueFromLocalStorage(String variable, String value) {
        if (!(driver instanceof WebStorage)) {
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript(String.format(
                    "window.localStorage.setItem('%s','%s');", variable, value));
            System.out.println(js.executeScript(String.format(
                    "return window.localStorage.key('%s');", variable)));
        } else {
            RemoteExecuteMethod executeMethod = new RemoteExecuteMethod((RemoteWebDriver) driver);
            RemoteWebStorage webStorage = new RemoteWebStorage(executeMethod);
            LocalStorage storage = webStorage.getLocalStorage();
            storage.setItem(variable, value);
        }
/*
        IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
        js.ExecuteScript("localStorage.setItem('key','value');");*/

    }

    public void verifyCredentialsChangeDetectedPopup() {
        log.warn("verifing changeCredentials popup");
        Assert.assertTrue("Credentials change is not present",TestUtils.isElementVisible(driver,isChangeCredPopup));

    }

    public void verifyUserIsLoggedOut() {
        log.warn("verifying user is logged out");
        String title = driver.getTitle();
    }

    public void clickonFaxHyperlink() {
        log.warn("clicking the fax hsitory hyperlink");
        TestUtils.click(driver,By.xpath("//a[@ng-click='checkFaxDetailsClicked()']"));
    }

    public void clickOnOK() {
        log.warn("clicking ok on pharmabenefits popup");
        TestUtils.click(driver,By.xpath("//input[@ng-click='mixedRegimenNoPharmacyBenefitPopupModel.closePopup(); continueFromOralCheck(newAuthForm);']"));
    }



    /* User verifies the auth status message in Request Status Page*/
    public void userVerifiesTheStatusVerbiageInRequestStatusPage(String message) {
        log.warn("User verifies the auth status message in Request Status Page ");
        TestUtils.waitElement(driver, authStatusMesasge);
        Assert.assertTrue("status message is not matching",driver.findElement(authStatusMesasge).getText().contains(message));
    }

    public void verifyAuthStatusLabel(String expectedStatus) {
        log.warn("user verifies status labels");

        By requestStatusMessage = By.xpath("//td[@class='labelColumn'][contains(.,'" + expectedStatus + "')]");
        TestUtils.scrollToElement(driver, requestStatusMessage);
        TestUtils.waitElement(driver, requestStatusMessage);
        TestUtils.demoBreakPoint(scenario, driver, "Request Status Page");
        String actualRequestStatusMessage = driver.findElement(requestStatusMessage).getText();
        log.warn("verifying Authorization Request Status");
        Assert.assertTrue("authorization request status is not matching with actual authorization request status",
                expectedStatus.equals(actualRequestStatusMessage));
    }

    public void clickOnAddDrug() {
        log.warn("click on add drug hyperlink");
        TestUtils.click(driver,By.xpath("//a[contains(text(),'Add Drug')]"));
    }


    public void selectAuthTypeOnCLonePopup(String authType) {
        log.warn("enter authtype on clone popup");
        By authType_clonePopup=By.xpath("//select[@ng-model='cloneAuthPopupModel.authorizationType']");
        TestUtils.waitElementVisible(driver,authType_clonePopup);

        TestUtils.selectByVisibleText(driver.findElement(authType_clonePopup),authType);
    }

    public void verifyLink(String arg0) {
        By element =By.partialLinkText(arg0);
        TestUtils.waitElementVisible(driver,element);
        Assert.assertTrue(TestUtils.isElementVisible(driver, element));
    }
    public void userClicksOntext(String text)
    {
        TestUtils.wait(5);
        TestUtils.waitElementVisible(driver,By.xpath("//span[text()='"+text+"']"));
        TestUtils.click(driver,By.xpath("//span[text()='"+text+"']"));
    }



}



