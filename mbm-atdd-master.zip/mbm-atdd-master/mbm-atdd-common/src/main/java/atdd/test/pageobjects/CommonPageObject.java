package atdd.test.pageobjects;

import atdd.test.pageobjects.activityTracking.ActivityTrackingHistoryPage;
import atdd.test.pageobjects.activityTracking.NewActivityPage;
import atdd.test.pageobjects.authorization.*;
import atdd.test.pageobjects.authorization.physicalHealth.*;
import atdd.test.pageobjects.dashboard.Dashboard;
import atdd.test.pageobjects.drugExceptions.DrugExceptionsPage;
import atdd.test.pageobjects.drugManager.DrugManagerPage;
import atdd.test.pageobjects.drugPolicyMaintenance.CreateNewDrugPolicyPage;
import atdd.test.pageobjects.drugPolicyMaintenance.DrugPolicyMaintenancePage;
import atdd.test.pageobjects.icue.*;
import atdd.test.pageobjects.newlyApprovedDrugs.AddNewDrugPage;
import atdd.test.pageobjects.newlyApprovedDrugs.NewlyApprovedDrugsPage;
import atdd.test.pageobjects.pathwaysDashboard.PathwaysDashboardPage;
import atdd.test.pageobjects.pathwaysDashboard.PathwaysReviewResultsPage;
import atdd.test.pageobjects.priorAuthSearch.PriorAuthorizationSearchDraftPage;
import atdd.test.pageobjects.priorAuthSearch.PriorAuthorizationSearchHistoryPage;
import atdd.test.pageobjects.priorAuthSearch.PriorAuthorizationSearchSubmittedPage;
import atdd.test.pageobjects.regimenMaintenance.RegimenMaintenancePage;
import atdd.test.pageobjects.supportiveMaintenance.AddSupportiveDrugsModalPage;
import atdd.test.pageobjects.supportiveMaintenance.SupportiveDrugsPage;
import atdd.test.pageobjects.traversalMaintenance.*;
import atdd.test.pageobjects.utilizationManagement.*;
import atdd.utils.InvalidLocatorException;
import atdd.utils.PageObjectUtils;
import cucumber.api.Scenario;
import org.openqa.selenium.WebDriver;


public class CommonPageObject extends PageObject {

    public BulkChangeVariableValueModalPage BulkChangeVariableValueModalPage = new BulkChangeVariableValueModalPage(webDriver);
    public ClonePopupPage clonePopupPage = new ClonePopupPage(webDriver);
    public CloneRequestPage CloneRequestPage = new CloneRequestPage(webDriver);
    public ClinicalStatusPage ClinicalStatusPage = new ClinicalStatusPage(webDriver);
    public RequestSummaryPage RequestSummaryPage = new RequestSummaryPage(webDriver);
    public RequestingProviderPage RequestingProviderPage = new RequestingProviderPage(webDriver);
    public RequestDetailsPage RequestDetailsPage = new RequestDetailsPage(webDriver);
    public CommonPage CommonPage = new CommonPage(webDriver);
    public Dashboard Dashboard = new Dashboard(webDriver);
    public RegimensPage RegimensPage = new RegimensPage(webDriver);
    public MemberSearchPage MemberSearchPage = new MemberSearchPage(webDriver);
    public MemberInformationPage MemberInformationPage = new MemberInformationPage(webDriver);
    public NavigationPage NavigationPage = new NavigationPage(webDriver);
    public RequestingProviderSearchModalPage RequestingProviderSearchModalPage = new RequestingProviderSearchModalPage(webDriver);
    public ServicingProviderPage ServicingProviderPage = new ServicingProviderPage(webDriver);
    public RequestStatusPage RequestStatusPage = new RequestStatusPage(webDriver);
    public PriorAuthorizationSearchSubmittedPage PriorAuthorizationSearchSubmittedPage = new PriorAuthorizationSearchSubmittedPage(webDriver);
    public PriorAuthorizationSearchDraftPage PriorAuthorizationSearchDraftPage = new PriorAuthorizationSearchDraftPage(webDriver);
    public PriorAuthorizationSearchHistoryPage PriorAuthorizationSearchHistoryPage = new PriorAuthorizationSearchHistoryPage(webDriver);
    public TraversalMaintenancePage TraversalMaintenancePage = new TraversalMaintenancePage(webDriver);
    public ImportNewTraversalsPage ImportNewTraversalsPage = new ImportNewTraversalsPage(webDriver);
    public EditTraversalModalPage EditTraversalModalPage = new EditTraversalModalPage(webDriver);
    public SupportiveDrugsPage SupportiveDrugsPage = new SupportiveDrugsPage(webDriver);
    public AddSupportiveDrugsModalPage AddSupportiveDrugsModalPage = new AddSupportiveDrugsModalPage(webDriver);
    public NewActivityPage NewActivityPage = new NewActivityPage(webDriver);
    public BulkEditAuthorizationDurationModalPage BulkEditAuthorizationDurationModalPage = new BulkEditAuthorizationDurationModalPage(webDriver);
    public AuthorizationTypePage AuthorizationTypePage = new AuthorizationTypePage(webDriver);
    public BulkDeleteModalPage BulkDeleteModalPage = new BulkDeleteModalPage(webDriver);
    public BulkChangeVariableTypeModalPage BulkChangeVariableTypeModalPage = new BulkChangeVariableTypeModalPage(webDriver);
    public DupTermPopupPage DupTermPopupPage = new DupTermPopupPage(webDriver);
    public EditAuthorizationPage EditAuthorizationPage = new EditAuthorizationPage(webDriver);
    public NewlyApprovedDrugsPage NewlyApprovedDrugsPage = new NewlyApprovedDrugsPage(webDriver);
    public DrugExceptionsPage DrugExceptionsPage = new DrugExceptionsPage(webDriver);
    public AddNewDrugPage AddNewDrugPage = new AddNewDrugPage(webDriver);
    public UserSecuritySettingsPage UserSecuritySettingsPage = new UserSecuritySettingsPage(webDriver);
    public ActivityTrackingHistoryPage ActivityTrackingHistoryPage = new ActivityTrackingHistoryPage(webDriver);
    public Icue Icue = new Icue(webDriver);
    public IcueIntakeShortForm IcueIntakeShortForm = new IcueIntakeShortForm(webDriver);
    public IcueInitiateHSCIntake IcueInitiateHSCIntake = new IcueInitiateHSCIntake(webDriver);
    public IcueServiceDecision IcueServiceDecision = new IcueServiceDecision(webDriver);
    public IcueNotification IcueNotification = new IcueNotification(webDriver);
    public IcueContAndAct IcueContAndAct = new IcueContAndAct(webDriver);
    public IcueIntakeLongForm IcueIntakeLongForm = new IcueIntakeLongForm(webDriver);
    public IcueService IcueService = new IcueService(webDriver);
    public PathwaysDashboardPage PathwaysDashboardPage = new PathwaysDashboardPage(webDriver);
    public PathwaysReviewResultsPage PathwaysReviewResultsPage = new PathwaysReviewResultsPage(webDriver);
    public RegimenMaintenancePage RegimenMaintenancePage = new RegimenMaintenancePage(webDriver);
    public DrugManagerPage DrugManagerPage = new DrugManagerPage(webDriver);
    public CreateNewDrugPolicyPage CreateNewDrugPolicyPage = new CreateNewDrugPolicyPage(webDriver);
    public DrugPolicyMaintenancePage DrugPolicyMaintenancePage = new DrugPolicyMaintenancePage(webDriver);
    public WorkQueueMaintenancePage WorkQueueMaintenancePage = new WorkQueueMaintenancePage(webDriver);
    public AddWorkQueuePage AddWorkQueuePage = new AddWorkQueuePage(webDriver);
    public WorkQueuePage WorkQueuePage = new WorkQueuePage(webDriver);
    public LettersSection LettersSection = new LettersSection(webDriver);
    public AssignmentsPage AssignmentsPage = new AssignmentsPage(webDriver);
    public AddAssignmentPage AddAssignmentPage = new AddAssignmentPage(webDriver);
    public CaseSummaryNotesSection CaseSummaryNotesSection = new CaseSummaryNotesSection(webDriver);
    public ViewAuthPage ViewAuthPage = new ViewAuthPage(webDriver);
    public CaseSummaryMakeDecisionsSection CaseSummaryMakeDecisionSection = new CaseSummaryMakeDecisionsSection(webDriver);
    public FeatureFlagSettingsPage FeatureFlagSettingsPage = new FeatureFlagSettingsPage(webDriver);
    public FOMsPage FOMsPage = new FOMsPage(webDriver);
    public RequestDetailsPagePH RequestDetailsPagePH = new RequestDetailsPagePH(webDriver);
    public PatientQuestionsPage PatientQuestionsPage = new PatientQuestionsPage(webDriver);
    public RequestSummaryPagePH RequestSummaryPagePH = new RequestSummaryPagePH(webDriver);
    public RequestStatusPagePH RequestStatusPagePH = new RequestStatusPagePH(webDriver);
    public TechniquePage TechniquePage = new TechniquePage(webDriver);
    public AdditionalServicesPage AdditionalServicesPage = new AdditionalServicesPage(webDriver);
    public FaxSection FaxSection = new FaxSection(webDriver);

    public UMPagePH UMPagePH = new UMPagePH(webDriver);

    public CommonPageObject(Scenario scenario, WebDriver webDriver) {
        super(scenario, webDriver);
    }

    public static PageObjectUtils pageObjectUtils = new PageObjectUtils(CommonPageObject.class.getPackage().getName());

    public static void main(String[] args) throws InvalidLocatorException {
        System.out.println(pageObjectUtils.getLocator("AddAssignmentPage.cancelButton"));
        System.out.println(pageObjectUtils.getLocator("authorization.ServicingProviderPage.selectALimitedSupplierDropdownXpath"));
    }
}
