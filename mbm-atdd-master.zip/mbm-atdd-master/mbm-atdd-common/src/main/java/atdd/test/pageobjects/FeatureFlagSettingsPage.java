package atdd.test.pageobjects;

import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class FeatureFlagSettingsPage {



    public static By featureName = By.xpath("//input[@ng-model='featureFlagTable.tableFilters.featureName']");
    public static By editfeatureFlagPopUp = By.xpath("//h2[text()='Edit Feature Flag']");
    public static By enabledFeatureFlagCheckbox = By.xpath("//input[@type='checkbox' and @ng-model=\"record.featureEnabled\"]");
    public static By saveButton = By.xpath("//input[@type='button' and @ng-click='featureFlagTable.editPopup.saveRecords([record], $event, featureFlagTable.editPopupForm)']");
    public static By refreshCachesButton = By.xpath("//input[@ng-click='saveCacheRefreshVO(cacheForm)']");

    private static Logger log = Logger.getLogger(FeatureFlagSettingsPage.class);
    private WebDriver driver;

    /*Page Constructor*/
    public FeatureFlagSettingsPage(WebDriver driver) {
        this.driver = driver;
    }

    /**
     *
     * @param featureFlagName
     */
    public void  enterFeatureFlagNameandSetFlag(String featureFlagName,String flagStatus) {
        log.warn("Enter the Feature Flag Key :");
        TestUtils.input(driver,featureName,featureFlagName);
        TestUtils.wait( 6);
        TestUtils.click(driver,By.xpath("//table[@id='featureFlagTableID']//tr[not(contains(@class,'tk-dtbl-header-row'))]//td//a[text()='"+featureFlagName+"']/ancestor::td/preceding-sibling::td//span"));
        TestUtils.waitElementVisible(driver,editfeatureFlagPopUp);


         if(flagStatus.equalsIgnoreCase("true")) {

             if(!driver.findElement(enabledFeatureFlagCheckbox).isSelected()){
                 log.warn("Feature flag is set enabled:");
                 TestUtils.click(driver,enabledFeatureFlagCheckbox);
             }
         }
         else {

             if(driver.findElement(enabledFeatureFlagCheckbox).isSelected()){
                 log.warn("Feature flag is set disabled:");
                 TestUtils.click(driver,enabledFeatureFlagCheckbox);
             }

         }

        ((JavascriptExecutor)driver).executeScript("arguments[0]. click();",driver.findElement(saveButton));
    }

    /**
     *
     * @param cachesName
     */
  public void refreshCaches(String cachesName) {

        log.warn("Refresh caches : "+cachesName);
        By checkboxCaches = By.xpath("//form[@name='cacheForm']//td[text()='"+cachesName+"']/preceding-sibling::td/input");
        TestUtils.waitElementVisible(driver,checkboxCaches);
         TestUtils.click(driver,checkboxCaches);
         TestUtils.click(driver,refreshCachesButton);
    }
























}
