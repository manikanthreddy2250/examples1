package atdd.test.pageobjects;


import atdd.common.ICondition;
import atdd.common.Retry;
import atdd.common.WaitUntil;
import atdd.test.pageobjects.priorAuthSearch.PriorAuthorizationSearchPage;
import atdd.test.shared.BaseCucumber;
import atdd.utils.MbmUtils;
import atdd.utils.StringUtils;
import atdd.utils.TestUtils;
import atdd.utils.WhiteBoard;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.List;


public class NavigationPage {

    Logger log;
    private WebDriver driver;
    private TestUtils utils;

    @Deprecated
    private By submitted_searchPage = PriorAuthorizationSearchPage.submittedTab;
    @Deprecated
    private By drafts_searchPage = PriorAuthorizationSearchPage.draftsTab;
    @Deprecated
    private By history_searchPage = PriorAuthorizationSearchPage.historyTab;

    @Deprecated
    private By ConvAuth_searchPage = PriorAuthorizationSearchPage.convertedAuthorizationsTab;


    public static By closeAnalytics = By.xpath("//img[contains(@src,'svg-close-btn-black')]");
    public static By globalMessage = By.xpath("//*[@id='globalMessages-description']/span");
    private By systemUnavaliableMessage = By.xpath("//h2");
    public static By expiredMemberCoverageMessage = By.xpath("//*[@id='continueInternalOperationsAuthorizationMessageDiv']/p");
    public By converted_searchPage = By.xpath("//li[contains(@class,'tk-tpnl')]/span[text()='Converted Authorizations']");
    public static By selfadminexceptionMessage = By.xpath("//*[@id='selfAdministeredDrugPopupID']/div[2]/div/form/div/div[1]/div[1]/div/p");
    public static By customerSelectionHeader = By.id("customer-selection-header");
    public static By customerSelectionMenu = By.id("customer-selection-menu");
    public static By customerSelectionFilter = By.id("customer-selection-filter");
    public static By customerSelection = By.xpath("(//*[contains(@ng-click,'selectCustomer(customer)')])");
    public static By customerLockToolTip = By.xpath("//*[@ng-if=\"showCustomerSwitchTooltip\"]");


    public NavigationPage(WebDriver webDriver) {
        this.driver = webDriver;
        utils = BaseCucumber.utils;
        log = Logger.getLogger(this.getClass().getName());
    }

    /**
     * Closing Alanytics popup if it present.
     */
    public void closeAnalytics() {
        log.warn("Closing Analytics window if it present");
        TestUtils.wait(5);
        boolean present = TestUtils.isElementPresent(driver, closeAnalytics);
        if (present) {
            TestUtils.highlightElement(driver, closeAnalytics);
            driver.findElement(closeAnalytics).click();
            log.warn("Closed.");
        } else {
            log.warn("Not present.");
        }
    }


    /**
     * Click on Draft tab On the search page
     */
    public void selectDraftTab_Search() {
        log.warn("Click on Draft tab On the search page");
        TestUtils.waitElement(driver, drafts_searchPage);
        TestUtils.highlightElement(driver, drafts_searchPage);
        driver.findElement(drafts_searchPage).click();
        TestUtils.wait(2);
    }

    /**
     * Click on Submitted tab On the search page
     */
    public void selectSubmittedTab_Search() {
        log.warn("Click on Submitted tab On the search page");
        TestUtils.waitElement(driver, submitted_searchPage);
        TestUtils.highlightElement(driver, submitted_searchPage);
        this.driver.findElement(submitted_searchPage).click();
        TestUtils.wait(2);
    }

    /**
     * Click on History tab On the search page
     */
    public void selectHistoryTab_Search() {
        log.warn("Click on History tab On the search page");
        TestUtils.waitElement(driver, history_searchPage);
        TestUtils.highlightElement(driver, history_searchPage);
        this.driver.findElement(history_searchPage).click();
        TestUtils.wait(2);
    }

    public void selectConvertedAuthorizationsTab_Search() {
        log.warn("Click on Converted Authorizations tab On the search page");
        TestUtils.waitElement(driver, converted_searchPage);
        TestUtils.highlightElement(driver, converted_searchPage);
        this.driver.findElement(converted_searchPage).click();
        TestUtils.wait(2);
    }

    /**
     * Expand or click on Primary nav menu
     *
     * @param option
     * @return NavigationPage
     */
    public NavigationPage expandClickPrimaryNav(String option) {
        log.warn("Expand or click on " + option + " Primary nav menu");
        TestUtils.wait(5);
        By element = By.xpath("//a[contains(@class, 'ng-scope')]//span[text()='" + option + "']");
        TestUtils.waitElementClickable(driver, element);
        TestUtils.highlightElement(driver, element);
        TestUtils.click(driver, element);
        TestUtils.wait(2);
        return this;
    }

    /**
     * Clicking on Autorization drop-down
     *
     * @param option
     * @return NavigationPage
     */
    public NavigationPage clickOptionFromPrimaryNavMenu(String option) {
        log.warn("Selecting " + option + " option from Primary nav menu drop-down");

        By element = By.xpath("//*[@model='item.dropDown']//span[text()='" + option + "']");

        retryClickingMenuItem(element);
        return this;
    }

    private void retryClickingMenuItem(By element) {
        if (!new Retry("retry clicking Menu Item: " + element) {
            @Override
            protected void tryOnce() throws Exception {
                TestUtils.click(driver, element);
            }

            @Override
            protected void weakRecover(Exception e) throws Exception {
                MbmUtils.immediateRecover(driver);
            }
        }.execute()) {
            throw new RuntimeException("Timeout trying to click " + element.toString());
        }
    }

    /**
     * Clicking on nav drop-down. Have to set navigation drop-down name
     *
     * @param navOption option
     * @return NavigationPage
     */
    public NavigationPage clickNavOptionByDropDownOption(String navOption, String option) {
        log.warn("Clicking on " + navOption + " navigation drop-down " + option + " option");

        By dropDown = By.xpath("//ul[contains(@class, 'pnav-submenu-open')]//span[text()='" + navOption + "']/../.." +
                "/*[@model='item.dropDown']//span[text()='" + option + "']");

        TestUtils.waitElement(driver, dropDown);
        TestUtils.highlightElement(driver, dropDown);
        driver.findElement(dropDown).click();

        TestUtils.wait(2);
        return this;
    }

    public boolean waitMainMenu(String mainMenu) {
        return new WaitUntil("wait main menu: " + mainMenu,
                15 * 1000, 1000, 1000,
                new ICondition() {
                    @Override
                    public boolean evaluate() throws Exception {
                        return TestUtils.isElementVisible(driver, menu(mainMenu, null));
                    }
                }).execute();
    }

    /**
     * Selecting option from Primary nav menu drop-down
     *
     * @param option
     * @return
     */
    public NavigationPage clickOptionFromTopNavMenu(String option) {
        log.warn("Selecting " + option + " option from Primary nav menu drop-down");

        By dropDown = menu(option, null);
        retryClickingMenuItem(dropDown);

        return this;
    }

    /*
     * This method returns list of submenu items displayed under a particular main menu
     * @param mainMenu
     * @return list of actual sub menu
     * */
    public List<String> getsubMenuValue(String mainMenu) {
        List<String> result = new ArrayList<>();
        String xpath = "//span[text()='" + mainMenu + "']/ancestor::li//ul/li";
        if (TestUtils.countElementsByXpath(driver, xpath) > 0) {
            List<WebElement> liElements = driver.findElements(By.xpath(xpath));
            for (WebElement li : liElements) {
                result.add(li.getText());
            }
        }
        return result;
    }

    public void navigatesToMenuItem(String trace) {
        trace = WhiteBoard.resolve(WhiteBoard.OWNER_GLOBAL, trace);
        String[] items = trace.split(">");

        if (items.length > 1) {
            TestUtils.safeClick(driver, menu(items[0], null));
            for (int i = 1; i < items.length; i++) {
                final By parentMenu = menu(items[i - 1], i - 2 < 0 ? null : items[i - 2]);
                final String item = items[i];
                final String parentItem = items[i - 1];
                boolean success = TestUtils.clickUntil(driver, parentMenu, new ICondition() {
                    @Override
                    public boolean evaluate() throws Exception {
                        return null != menu(item, parentItem);
                    }
                });
                Assert.assertTrue("Invalid menu item: " + item + " with parent menu item: " + parentMenu, success);
            }
            TestUtils.click(driver, menu(items[items.length - 1], items[items.length - 2]));
        } else {
            TestUtils.click(driver, menu(items[0], null));
        }
    }

    private By menu(String item, String parentItem) {
        if (StringUtils.isEmpty(parentItem)) {
            return By.xpath("//a[contains(@class, 'ng-scope')]//span[text()='" + item + "']");
        }
        item = item.trim();
        parentItem = null == parentItem ? null : parentItem.trim();
        String itemXpath = "//a[contains(@class, 'ng-scope')]//span[text()='" + item + "']";
        if (!TestUtils.isElementVisible(driver, itemXpath)) {
            if (StringUtils.isEmpty(parentItem)) {
                return null;
            } else {
                itemXpath = "//span[text()='" + parentItem + "']/ancestor::li//ul/li//a[contains(@class, 'ng-scope')]//span[text()='" + item + "']";
                if (!TestUtils.isElementVisible(driver, itemXpath)) {
                    return null;
                }
            }
        }
        return By.xpath(itemXpath);
    }

    /**
     * Return text inside global message popup
     *
     * @return
     */
    public String getGlobalMessage() {
        return this.driver.findElement(globalMessage).getText();
    }

    public String getExpiredMemberCoverage() {
        return this.driver.findElement(expiredMemberCoverageMessage).getText();
    }

    public void verifySystemUnvailablePopUp(String message) {
        log.warn("verifying System Unvailable PopUp header");
        Assert.assertEquals(driver.findElement(systemUnavaliableMessage).getText(), message);

    }

    public void navigateToUHCHomePage() {
        String url = driver.getCurrentUrl();
        String newUrl = url.replace("bcbs/sc", "ocm");
        driver.get(newUrl);
    }

    public void navigateToBCBSHomePage() {
        String url = driver.getCurrentUrl();
        String newUrl = url.replace("ocm", "bcbs/sc");
        driver.get(newUrl);
    }

    /**
     * verifing the  third tab as converted authorizations for bcbs
     */

    public void userVerifiesTheConvertedAuthTab() {
        log.warn("verifying the third tabs as converted authorizations");
        Assert.assertTrue("third tba is not converted auths", TestUtils.isElementVisible(driver, converted_searchPage));
    }

    public void clickOnException(String exception) {

        try {
            By button_xpath = By.xpath("//a[contains(text(),'" + exception + "')]");
            TestUtils.waitElementVisible(driver, button_xpath);
            log.warn("clicking on the exception link");
            TestUtils.click(driver, button_xpath);
        } catch (Exception e) {
            By button_xpath = By.xpath("(//a[contains(text(),'" + exception + "')])[2]");
            TestUtils.waitElementVisible(driver, button_xpath);
            log.warn("clicking on the exception link");
            TestUtils.click(driver, button_xpath);
        }
    }

    public String getSelfadminException() {
        return this.driver.findElement(selfadminexceptionMessage).getText();
    }

    /**
     * Navigate to customer via customer selection on menu bar
     * waitElement - wait until retries until cusomter selection menu is loaded after click of header - may vary by customer
     *
     * @param customer
     */
    public void navigateToCustomer(String customer) {
        Assert.assertTrue("Customer navigation menu is not present", TestUtils.isElementVisible(driver, customerSelectionHeader));
        TestUtils.click(driver, customerSelectionHeader);
        TestUtils.waitElement(driver, customerSelectionMenu);
        TestUtils.input(driver, customerSelectionFilter, customer);
        TestUtils.click(driver, customerSelection);
    }

    public void userVerifiesHeaderOnpopUp(String message)
    {
        TestUtils.wait(10);
        TestUtils.isElementVisible(driver, By.xpath("//h2[contains(text(),'"+message+"')]"));

    }

}
