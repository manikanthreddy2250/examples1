package atdd.test.pageobjects;

import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.openqa.selenium.WebDriver;

public class PageObject {

    protected final WebDriver webDriver;
    public NavigationPage NavigationPage;

    public PageObject(Scenario scenario, WebDriver webDriver) {
        TestUtils.immediateAbortCheck(scenario);
        this.webDriver = webDriver;
        this.NavigationPage = new NavigationPage(webDriver);
    }

}
