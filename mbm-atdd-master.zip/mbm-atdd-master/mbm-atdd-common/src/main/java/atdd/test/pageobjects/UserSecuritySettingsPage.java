package atdd.test.pageobjects;

import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class UserSecuritySettingsPage {

    public static final String filterFormXpath = "//form[@name='userTableFormtableFilters']";

    public static By userIdInputBox = By.xpath(filterFormXpath+"//input[@name='User ID']");
    public static By lastNameInputBox = By.xpath(filterFormXpath+"//input[@name='Last Name']");
    public static By filterButton = By.xpath(filterFormXpath+"//input[@value='Filter']");
    public static final By userRoleDropdown = By.xpath("//select[@ng-model='record.userGroupID']");
    public static final By userCredentialsDropdown = By.xpath("//select[@ng-model='record.clinicalCredentialsType']");

    public static By editIcon(String userId) {
        return By.xpath("//table[@id='userTableID']//tr[./td/a='" + userId + "']/td[1]/span");
    }

    private static Logger log = Logger.getLogger(UserSecuritySettingsPage.class);
    private WebDriver driver;

    /*Page Constructor*/
    public UserSecuritySettingsPage(WebDriver driver) {
        this.driver = driver;
    }

    public void enterDataOnUserSecurityPage(List<Map<String, String>> maps) {
        for (Map<String, String> map : maps) {
            for (String locatorName : map.keySet()) {
                if (locatorName.contains("User ID") || locatorName.contains("Last Name")) {
                    By inputValue = By.xpath("//input[@name='" + locatorName + "'][1]");
                    driver.findElement(inputValue).sendKeys(map.get(locatorName));
                } else {
                    By inputValue = By.xpath("//input[@name='" + locatorName + "']");
                    driver.findElement(inputValue).sendKeys(map.get(locatorName).replaceAll("-", ""));
                }
            }

        }
    }

    public void enterinfoOnSecurityPage(String value, String label) {
        TestUtils.wait(2);
        By userLabels = By.xpath("//input[@id='record-" + label + "-0']");//input[@id='record-userID-0']
        driver.findElement(userLabels).sendKeys(value);
    }

    public void selectDropdownValue(String dropdownValue) {

        TestUtils.select(driver, userRoleDropdown, dropdownValue);
    }

    public void selectUserCeredentialsDropdownValue(String dropdownValue) {

        TestUtils.select(driver, userCredentialsDropdown, dropdownValue);
    }


    public void verifyDropdownList(List<List<String>> data) {

        List<String> actualOptions = TestUtils.getDropdownListOptions(driver, userCredentialsDropdown);
        System.out.println(actualOptions);
        int rows = data.size();
        int cols = data.get(0).size();
        for (int col = 0; col < cols; col++) {
            List<String> expectedOptions = new ArrayList<>(rows);
            for (int row = 0; row < rows; row++) {
                String option = data.get(row).get(col);
                expectedOptions.add(option);

            }

            System.out.println(expectedOptions);
            Assert.assertEquals("options are not equal", actualOptions, expectedOptions);
        }

    }

}
