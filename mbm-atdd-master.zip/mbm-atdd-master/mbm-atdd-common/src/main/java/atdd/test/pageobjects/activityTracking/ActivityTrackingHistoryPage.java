package atdd.test.pageobjects.activityTracking;

import atdd.test.core.ISearchable;
import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.util.List;


public class ActivityTrackingHistoryPage implements ISearchable  {


    public String activityTrackingHistory_XPATH="//table[@id='activityTrackingHistoryOperationID']";

    public final static String filterTableXpath = "//form[@name='activityTrackingHistoryOperationFormtableFilters']/table";
    public final static String resultTableXpath = "//table[@id='activityTrackingHistoryOperationID']";
    public final static String searchButtonXpath = "//input[@value='Search']";
    public final static String clearButtonXpath = "//input[@value='Clear']";
    public final static By payerLabel = By.xpath("//td[contains(text(),'Payer')]");
    public final static   By payerDropdown = By.xpath("//select[@ng-model='selectPayer.payers']");

    private static Logger log = Logger.getLogger(ActivityTrackingHistoryPage.class);
    private WebDriver driver;

    /*Page Constructor*/
    public ActivityTrackingHistoryPage(WebDriver driver) {
        this.driver = driver;
    }


    @Override
    public String getFilterTableXpath() {
        return filterTableXpath;
    }

    @Override
    public String getResultTableXpath() {
        return resultTableXpath;
    }

    @Override
    public By getSearchButtonLocator() {
        return By.xpath(searchButtonXpath);
    }

    @Override
    public By getClearButtonLocator() {
        return By.xpath(clearButtonXpath);
    }

    @Override
    public boolean hasPagination() {
        return true;
    }

    public void verifyDropdownOptionsInActivityTrackingHistory(List<String> labelValues) {
        log.warn("Verifies Payer dropdown is displayed on activitytracking page");
        Assert.assertTrue("Payer dropdown is not displayed on activitytracking page", driver.findElement(payerLabel).isDisplayed());

        TestUtils.click(driver, payerDropdown);
        Select payerValues = new Select(driver.findElement(payerDropdown));
        List<WebElement> payer = payerValues.getOptions();
        for (int i = 0; i < labelValues.size(); i++) {
            log.warn(payer.get(i).getText());
            Assert.assertTrue("Dropdown value is missing " + labelValues.get(i), payer.get(i).getText().contains(labelValues.get(i)));
        }
    }

    public void verifyLabelPresentOnInActivityTrackingHistory(List<String> labelValues) {
        for (int i = 0; i < labelValues.size(); i++) {
            By searchLabel = By.xpath("//td[contains(text(),'" + labelValues.get(i) + "')]");
            Assert.assertTrue("Label value is missing " + labelValues.get(i), driver.findElement(searchLabel).isDisplayed());
        }
    }

    public void verifyDefaultSelectedPayerName(String payerName) {

        Assert.assertTrue("Payer is not selected as given ",TestUtils.simpleContent(driver.findElement(payerDropdown)).equalsIgnoreCase(payerName));
    }

    public void validateActivityInHistory(String activityType) {
        By activityTypeXpath = By.xpath("//tr[@ng-repeat-start='record in activityTrackingHistoryOperation.records'][1]//td[5]//span[text()='"+activityType+"']");
        TestUtils.wait(3);
        Assert.assertTrue(TestUtils.isElementVisible(driver, activityTypeXpath));
    }

    public void clickSearchButtonInHistory(){
        By searchXpath = By.xpath("//input[@value='Search']");
        Assert.assertTrue(TestUtils.isElementVisible(driver, searchXpath));
        TestUtils.click(driver,searchXpath);
        TestUtils.wait(2);
    }

    public void selectActivityType(String activityType){
        By activityTypeDropdownXpath = By.xpath("//select[@ref-nm='activityType']");
        Assert.assertTrue(TestUtils.isElementVisible(driver,activityTypeDropdownXpath));
        TestUtils.click(driver,activityTypeDropdownXpath);
        TestUtils.wait(3);
        By activityTypeXpath =By.xpath("//select[@ref-nm='activityType']//option[text()='"+activityType+"']");
        TestUtils.click(driver,activityTypeXpath);
        TestUtils.wait(3);
    }
}



