package atdd.test.pageobjects.activityTracking;

import atdd.test.shared.BaseCucumber;
import atdd.utils.TestUtils;
import cucumber.api.DataTable;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;


public class NewActivityPage {

    Logger log;
    private WebDriver driver;
    private TestUtils utils;

    //Locators
    public final static By activityType = By.xpath("//select[contains(@id,'activityType')]");
    public final static By resolutionReason = By.xpath("//select[contains(@id,'activityResolutionReasonType')]");
    public final static By date = By.xpath("//input[contains(@id,'activityDate')]");
    public final static By time = By.xpath("//input[contains(@id,'activityTime-time')]");
    public final static By callContactName = By.xpath("//input[contains(@id,'actCallContactName')]");
    public final static By role = By.xpath("//select[contains(@id,'contactRoleType')]");
    public final static By communicationType = By.xpath("//select[contains(@id,'communicationType')]");
    public final static By saveBtn = By.xpath("//input[contains(@ng-click, 'saveActivity')]");
    public final static By dateTimeNewActicity = By.xpath("//*[@id='activityTrackingHistoryOperationID']/tbody/tr[1]/td[6]/span");
    public final static By activityTypeNewActicity = By.xpath("//*[@id='activityTrackingHistoryOperationID']/tbody/tr[1]/td[4]/span");
    public final static By resolutionReasontxt = By.xpath("//*[@id='activityTrackingHistoryOperationID']/tbody/tr[1]/td[5]/span");
    public final static By userIDNewActicity = By.xpath("//*[@id='activityTrackingHistoryOperationID']/tbody/tr[1]/td[2]/span");
    public final static By callContactNametxtNewActicity = By.xpath("//*[@id='activityTrackingHistoryOperationID']/tbody/tr[1]/td[8]/span");
    public final static By CommunicationTypetxtNewActicity = By.xpath("//*[@id='activityTrackingHistoryOperationID']/tbody/tr[1]/td[9]/span");
    public final static By collapseRowNewActicity = By.xpath("//*[@id='activityTrackingHistoryOperationID']/tbody/tr[1]/td[1]/span");
    public final static By roletxtNewActicity = By.xpath("//*[contains(@id,activityTrackingDrawer)]//td[3]/span[text()='Internal']");
    public final static By dateTimeHome = By.xpath("//*[@id='viewActivityTrackingOperationID']/tbody/tr[1]/td[2]/span");
    public final static By activityTypetxtHome = By.xpath("//*[@id='viewActivityTrackingOperationID']/tbody/tr[1]/td[3]/span");
    public final static By resolutionReasontxtHome = By.xpath("//*[@id='viewActivityTrackingOperationID']/tbody/tr[1]/td[4]/span");
    public final static By userIDActicityHome = By.xpath("//*[@id='viewActivityTrackingOperationID']/tbody/tr[1]/td[5]/span");
    public final static By callContactNametxtHome = By.xpath("//*[@id='viewActivityTrackingOperationID']/tbody/tr[1]/td[8]");
    public final static By CommunicationTypetxtHome = By.xpath("//*[@id='viewActivityTrackingOperationID']/tbody/tr[1]/td[9]/span");
    public final static By collapseRowNewActicityHome = By.xpath("//*[@id='viewActivityTrackingOperationID']/tbody/tr[1]/td[1]/span");
    public final static By roletxtHome = By.xpath("//*[contains(@id,'activityTrackingDrawer')]/td[4]/div/span[text()='Internal']");
    public final static By memberId = By.xpath("//input[@id='actNewMemberID']");
    public final static By draftID = By.xpath("//input[@id='actAuthIDDraftID']");
    public final static By callBackNumber = By.xpath("//input[@id='actNewCallBackNumber']");
    public final static By physicianName = By.xpath("//input[@id='actPhysicianOffFacilityName']");
    public final static By comments = By.xpath("//textarea[@id='noteDetails']");
    public final static By saveActivity = By.xpath("//input[contains(@ng-click, 'saveAddActivity')]");


    //Locators

    public NewActivityPage(WebDriver webDriver) {
        this.driver = webDriver;
        utils = BaseCucumber.utils;
        log = Logger.getLogger(this.getClass().getName());
    }

    /**
     * Clicking Save button
     *
     * @return
     */
    public NewActivityPage clickSaveBtn() {
        log.warn("Clicking Save button");
        TestUtils.waitElement(driver, saveActivity);
        TestUtils.highlightElement(driver, saveActivity);
        TestUtils.click(driver, saveActivity);
        return this;
    }


    /**
     * Clicking Save button
     *
     * @return
     */
    public NewActivityPage clickSaveActivity() {
        log.warn("Clicking Save button");
        TestUtils.waitElement(driver, saveBtn);
        TestUtils.highlightElement(driver, saveBtn);
        driver.findElement(saveBtn).click();
        return this;
    }

    /**
     * Entering Call Contact Name
     *
     * @param txt
     * @return
     */
    public NewActivityPage enterCallContactName(String txt) {
        log.warn("Entering Call Contact Name " + txt);
        TestUtils.waitElement(driver, callContactName);
        TestUtils.highlightElement(driver, callContactName);
        driver.findElement(callContactName).sendKeys(txt);
        return this;
    }

    /**
     * Entering Date
     *
     * @param txt
     * @return
     */
    public NewActivityPage enterDate(String txt) {
        log.warn("Entering Date " + txt);
        TestUtils.waitElement(driver, date);
        TestUtils.highlightElement(driver, date);
        driver.findElement(date).clear();
        driver.findElement(date).sendKeys(txt);
        return this;
    }

    /**
     * Entering time
     *
     * @param txt
     * @return
     */
    public NewActivityPage enterTime(String txt) {
        log.warn("Entering Time " + txt);
        TestUtils.waitElement(driver, time);
        TestUtils.highlightElement(driver, time);
        driver.findElement(time).sendKeys(txt);
        return this;
    }

    /**
     * Selecting Activity type
     *
     * @param option
     * @return
     */
    public NewActivityPage selectActivityType(String option) {
        log.warn("Selecting Activity Type " + option);
        TestUtils.waitElement(driver, activityType);
        TestUtils.highlightElement(driver, activityType);
        TestUtils.selectByVisibleText(driver, activityType, option);
        return this;
    }

    /**
     * Select Resolution Reson
     *
     * @param option
     * @return
     */
    public void selectResolutionReason(String option) {
        log.warn("Selecting Resolution Reason " + option);
        TestUtils.wait(3);
        TestUtils.select(driver, resolutionReason, option);
    }

    /**
     * Selecting Role
     *
     * @param option
     * @return
     */
    public NewActivityPage selectRole(String option) {
        log.warn("Selecting Role " + option);
        TestUtils.waitElement(driver, role);
        TestUtils.highlightElement(driver, role);
        TestUtils.selectByVisibleText(driver, role, option);
        return this;
    }

    /**
     * Select Communication Type
     *
     * @param option
     * @return
     */
    public NewActivityPage selectCommunicationType(String option) {
        log.warn("Selecting Communication Type " + option);
        TestUtils.waitElement(driver, communicationType);
        TestUtils.highlightElement(driver, communicationType);
        TestUtils.selectByVisibleText(driver, communicationType, option);
        return this;
    }

    /**
     * Verifies option is present under Resolution_Reason_dropDown dropdown
     *
     * @param txt
     */
    public void userVerifiesTheContentsOfDropdown(String txt) {
        By activityResolutionReason = By.xpath("//select[contains(@id,'activityVO-activityResolutionReasonType')]/option");
        List<WebElement> options = driver.findElements(activityResolutionReason);
        boolean isMatched = false;
        for (WebElement option : options) {
            if (option.getText().equals(txt)) {
                isMatched = true;
                TestUtils.wait(2);
                break;
            }
        }
        Assert.assertTrue(" Activity Resolution Reason is not matched with dropw down values", isMatched);

    }

    /**
     * Entering Authorization ID/Draft ID
     */
    public void enterAuthorizationID(String id) {
        log.warn("Enter Authorization ID/Draft ID");
        TestUtils.input(driver, draftID, id);
    }

    /**
     * Entering memberID
     */
    public void enterMemberID(String memberId) {
        log.warn("Enter memberID");
        TestUtils.input(driver, NewActivityPage.memberId, memberId);
    }

    /**
     * Entering Call back number
     */
    public void enterCallBackNumber(String number) {
        log.warn("EnterCall back number");
        TestUtils.input(driver, callBackNumber, number);
    }

    /**
     * Entering entering Physician/Office/Facility Name
     */
    public void enterPhysician(String name) {
        log.warn("Enter Physician/Office/Facility Name");
        TestUtils.input(driver, physicianName, name);
    }

    /**
     * Entering entering comments
     */
    public void enterComment(String comment) {
        log.warn("Enter comments");
        TestUtils.input(driver, comments, comment);
    }

    /**
     * validation Of new activityTracking Widget
     *
     * @param arg1
     */
    public void validationOfNewActivityTrackingWidget(DataTable arg1) {
        List<Map<String, String>> maps = arg1.asMaps(String.class, String.class);

        String expDateTime = maps.get(0).get("Date / Time").trim();
        log.warn("userShouldVerifyThatValueDateTimeIsOntheNewActivityWidget" + expDateTime);
        WebElement txtDateTime = driver.findElement(dateTimeNewActicity);
        TestUtils.waitElement(driver, txtDateTime);
        String actexpDateTime = txtDateTime.getText().trim();
        Assert.assertTrue("DateTime not saved correctly.", expDateTime.equals(actexpDateTime));
        TestUtils.highlightElement(driver, txtDateTime);

        String ExpActivityType = maps.get(0).get("Activity Type").trim();
        log.warn("userShouldVerifyThatValueActivityTypeNewActivityWidget" + ExpActivityType);
        WebElement txtactivityType = driver.findElement(activityTypeNewActicity);
        TestUtils.waitElement(driver, txtactivityType);
        String ActActivityType = txtactivityType.getText();
        Assert.assertTrue("ActivityType not saved correctly.", ExpActivityType.equals(ActActivityType));
        TestUtils.highlightElement(driver, txtactivityType);

        String expResolutionReason = maps.get(0).get("Resolution Reason");
        log.warn("userShouldVerifyThatValueResolution_ReasonIsOntheNewActivityWidget" + expResolutionReason);
        WebElement ResolutionReason = driver.findElement(resolutionReasontxt);
        TestUtils.waitElement(driver, ResolutionReason);
        String actResolutionReason = ResolutionReason.getText();
        Assert.assertTrue("Role not saved correctly.", expResolutionReason.equals(actResolutionReason));
        TestUtils.highlightElement(driver, ResolutionReason);

        String ExpUserID = maps.get(0).get("User ID").trim();
        log.warn("userShouldVerifyThatValueDateTimeIsOntheNewActivityWidget" + ExpUserID);
        WebElement UserID = driver.findElement(userIDNewActicity);
        TestUtils.waitElement(driver, UserID);
        String actUserID = UserID.getText().trim();
        Assert.assertTrue("UserID not saved correctly.", ExpUserID.equals(actUserID));
        TestUtils.highlightElement(driver, UserID);

        String ExpCallContactName = maps.get(0).get("Call Contact Name").trim();
        log.warn("userShouldVerifyThatValueCallContactNameIsOntheNewActivityWidget" + ExpCallContactName);
        WebElement CallContactName = driver.findElement(callContactNametxtNewActicity);
        TestUtils.waitElement(driver, CallContactName);
        String ActCallContactName = CallContactName.getText().trim();
        Assert.assertTrue("CallContactName not saved correctly.", ExpCallContactName.equals(ActCallContactName));
        TestUtils.highlightElement(driver, CallContactName);

        String ExpCommunicationType = maps.get(0).get("Communication Type").trim();
        log.warn("userShouldVerifyThatValueCommunication Type IsOntheNewActivityWidget" + ExpCommunicationType);
        WebElement CommunicationType = driver.findElement(CommunicationTypetxtNewActicity);
        TestUtils.waitElement(driver, CommunicationType);
        String ActCommunicationType = CommunicationType.getText().trim();
        Assert.assertTrue("CommunicationType not saved correctly.", ExpCommunicationType.equals(ActCommunicationType));
        TestUtils.highlightElement(driver, CommunicationType);

        String ExpRole = maps.get(0).get("Role").trim();
        log.warn("userShouldVerifyThatValueRoleIsOntheNewActivityWidget" + ExpRole);
        driver.findElement(collapseRowNewActicity).click();
        WebElement Role = driver.findElement(roletxtNewActicity);
        TestUtils.waitElement(driver, Role);
        String ActRole = Role.getText().trim();
        Assert.assertTrue("Role not saved correctly.", ExpRole.equals(ActRole));
        TestUtils.wait(1);
        TestUtils.highlightElement(driver, Role);
    }

    /**
     * validation Of new activityTracking Widget in home page
     *
     * @param arg1
     */
    public void validationOfActivityTrackingWidgetInHomePage(DataTable arg1) {
        List<Map<String, String>> maps = arg1.asMaps(String.class, String.class);

        String expDateTime = maps.get(0).get("Date / Time").trim();
        log.warn("userShouldVerifyThatValueDateTimeIsOntheActivityTrackingWidget" + expDateTime);
        WebElement DateTime = driver.findElement(dateTimeHome);
        TestUtils.waitElement(driver, DateTime);
        String actexpDateTime = DateTime.getText().trim();
        Assert.assertTrue("DateTime not saved correctly.", expDateTime.equals(actexpDateTime));
        TestUtils.highlightElement(driver, DateTime);

        String ExpActivityType = maps.get(0).get("Activity Type").trim();
        log.warn("userShouldVerifyThatValueActivityTypeNewActivityWidget" + ExpActivityType);
        WebElement ActivityType = driver.findElement(activityTypetxtHome);
        TestUtils.waitElement(driver, ActivityType);
        String ActActivityType = ActivityType.getText();
        Assert.assertTrue("ActivityType not saved correctly.", ExpActivityType.equals(ActActivityType));
        TestUtils.highlightElement(driver, ActivityType);

        String expResolutionReason = maps.get(0).get("Resolution Reason");
        log.warn("userShouldVerifyThatValueResolution_ReasonIsOntheNewActivityWidget" + expResolutionReason);
        WebElement ResolutionReason = driver.findElement(resolutionReasontxtHome);
        TestUtils.waitElement(driver, ResolutionReason);
        String actResolutionReason = ResolutionReason.getText();
        Assert.assertTrue("Role not saved correctly.", expResolutionReason.equals(actResolutionReason));
        TestUtils.highlightElement(driver, ResolutionReason);

        String ExpUserID = maps.get(0).get("User ID").trim();
        log.warn("userShouldVerifyThatValueDateTimeIsOntheNewActivityWidget" + ExpUserID);
        WebElement UserID = driver.findElement(userIDActicityHome);
        TestUtils.waitElement(driver, UserID);
        String actUserID = UserID.getText().trim();
        Assert.assertTrue("UserID not saved correctly.", ExpUserID.equals(actUserID));
        TestUtils.highlightElement(driver, UserID);

        String ExpCallContactName = maps.get(0).get("Call Contact Name").trim();
        log.warn("userShouldVerifyThatValueCallContactNameIsOntheNewActivityWidget" + ExpCallContactName);
        WebElement CallContactName = driver.findElement(callContactNametxtHome);
        TestUtils.waitElement(driver, CallContactName);
        String ActCallContactName = CallContactName.getText().trim();
        Assert.assertTrue("CallContactName not saved correctly.", ExpCallContactName.equals(ActCallContactName));
        TestUtils.highlightElement(driver, CallContactName);

        String ExpCommunicationType = maps.get(0).get("Communication Type").trim();
        log.warn("userShouldVerifyThatValueCommunication Type IsOntheNewActivityWidget" + ExpCommunicationType);
        WebElement CommunicationType = driver.findElement(CommunicationTypetxtHome);
        TestUtils.waitElement(driver, CommunicationType);
        String ActCommunicationType = CommunicationType.getText().trim();
        Assert.assertTrue("CommunicationType not saved correctly.", ExpCommunicationType.equals(ActCommunicationType));
        TestUtils.highlightElement(driver, CommunicationType);

        String ExpRole = maps.get(0).get("Role").trim();
        log.warn("userShouldVerifyThatValueRoleIsOntheNewActivityWidget" + ExpRole);
        driver.findElement(collapseRowNewActicityHome).click();
        WebElement Role = driver.findElement(roletxtHome);
        TestUtils.waitElement(driver, Role);
        String ActRole = Role.getText().trim();
        Assert.assertTrue("Role not saved correctly.", ExpRole.equals(ActRole));
        TestUtils.wait(1);
        TestUtils.highlightElement(driver, Role);
    }

    /**
     * add new activity
     *
     * @param maps
     */
    public void add(List<Map<String, String>> maps) {
        for (Map<String, String> map : maps) {
            selectActivityType(map.get("Activity Type"));
            selectResolutionReason(map.get("Resolution Reason"));
            enterDate(map.get("Date"));
            enterTime(map.get("Time"));
            if (map.containsKey("Call Contact Name")) {
                enterCallContactName(map.get("Call Contact Name"));
            }
            selectRole(map.get("Role"));
            selectCommunicationType(map.get("Communication Type"));
            if (map.containsKey("Authorization ID/Draft ID")) {
                enterAuthorizationID(map.get("Authorization ID/Draft ID"));
            }
            if (map.containsKey("Member ID")) {
                enterMemberID(map.get("Member ID"));
            }
            if (map.containsKey("Call Back Number")) {
                enterCallBackNumber(map.get("Call Back Number"));
            }
            if (map.containsKey("Physician/Office/Facility Name")) {
                enterPhysician(map.get("Physician/Office/Facility Name"));
            }
            if (map.containsKey("Comments")) {
                enterComment(map.get("Comments"));
            }
            clickSaveBtn();
        }

    }


    /**
     * add new activity
     *
     * @param maps
     */
    public void addActivity(List<Map<String, String>> maps) {
        for (Map<String, String> map : maps) {
            selectActivityType(map.get("Activity Type"));
            selectResolutionReason(map.get("Resolution Reason"));
            enterDate(map.get("Date"));
            enterTime(map.get("Time"));
            if (map.containsKey("Call Contact Name")) {
                enterCallContactName(map.get("Call Contact Name"));
            }
            selectRole(map.get("Role"));
            selectCommunicationType(map.get("Communication Type"));
            if (map.containsKey("Authorization ID/Draft ID")) {
                enterAuthorizationID(map.get("Authorization ID/Draft ID"));
            }
            if (map.containsKey("Member ID")) {
                enterMemberID(map.get("Member ID"));
            }
            if (map.containsKey("Call Back Number")) {
                enterCallBackNumber(map.get("Call Back Number"));
            }
            if (map.containsKey("Physician/Office/Facility Name")) {
                enterPhysician(map.get("Physician/Office/Facility Name"));
            }
            if (map.containsKey("Comments")) {
                enterComment(map.get("Comments"));
            }
            clickSaveBtn();
            TestUtils.wait(2);
            TestUtils.waitElementNotVisible(driver,"//input[contains(@ng-click, 'saveAddActivity(addActivityForm)')]");
        }

    }

    public void validateResolutionReasonValues(){
        List<String> expectedResolutionValues = new ArrayList<String>();
        Collections.addAll(expectedResolutionValues,"Call Attempt", "Call Contact", "Fax Sent", "Transfer to VM","Warm Transfer");
        List<String>  actualResolutionValues = new ArrayList<String>();
        By resolutionDropdwnXpath=By.xpath("//select[@ref-nm='activityResolutionReasonType']");
        TestUtils.click(driver,resolutionDropdwnXpath);
        TestUtils.wait(3);
        List<WebElement> resolutionReasonValues = driver.findElements(By.xpath("//option[@ng-repeat='option in activityResolutionReasonTypeLIST']"));
        resolutionReasonValues.forEach(i-> actualResolutionValues.add(i.getText().trim()));
        log.warn(actualResolutionValues);
        log.warn(expectedResolutionValues);
        Assert.assertEquals("All Resolution values are displayed", expectedResolutionValues,actualResolutionValues);
    }

}



