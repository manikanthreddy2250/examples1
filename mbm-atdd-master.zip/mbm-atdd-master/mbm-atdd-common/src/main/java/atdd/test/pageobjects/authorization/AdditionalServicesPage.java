package atdd.test.pageobjects.authorization;

import atdd.common.ICondition;
import atdd.common.WaitUntil;
import atdd.test.shared.BaseCucumber;
import atdd.test.shared.Globals;
import atdd.utils.MBM;
import atdd.utils.StringUtils;
import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.jetbrains.annotations.NotNull;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.util.List;
import java.util.Map;

import static org.openqa.selenium.By.cssSelector;
import static org.openqa.selenium.By.xpath;

public class AdditionalServicesPage {

    Logger log;
    private WebDriver driver;
    private TestUtils utils;
    Globals gv;

    //Locators--------
    public static final By numberOfFractionForExternalBeamTextBox = xpath("//div[contains(@class, 'question-wrapper') and contains(., 'number of fractions requested')]//input");
    public static final By requestedIGRTCodeSel = xpath("//select[contains(@id,'ocmAssessmentConductor-responses-0')]");
    public static final By requestedIGRTUnitsTextBox = xpath("//div[contains(@class, 'question-wrapper') and contains(., 'number of IGRT units requested:')]//input");
    public static final By requestedFrequencySel = xpath("//div[contains(@class, 'question-wrapper') and contains(.,'frequency requested for 77331')]//select");
    //public static final By clinicalJustFor77331TextBox = xpath("//div[contains(@class, 'question-wrapper') and contains(.,'clinical justification for the request of 77331')]//input");
    public static final By clinicalJustFor77331TextBox = xpath("//div[contains(@class, 'question-wrapper') and contains(.,'clinical justification for the selection of \"Greater than 6\" for the request of 77331')]//input");


    public static final By clinicalJustFor77399TextBox = xpath("//div[contains(@class, 'question-wrapper') and contains(.,'clinical justification for the request of 77399')]//input");
    public static final By otherClinicalJustFor77470TextBox = xpath("//div[contains(@class, 'question-wrapper') and contains(.,'clinical justification for the request of 77470')]//input");
    public static final By otherClinicalJustFor77370TextBox = xpath("//div[contains(@class, 'question-wrapper') and contains(.,'for the request of 77370') and contains(.,'clinical justification')]//input");
    public static final By spacerUsedSel = xpath("//select[contains(@id,'ocmAssessmentConductor-responses-0')]");
    public static final By continueButton = xpath("(//*[contains(@ng-click,'Continue')] | //*[contains(@ng-click,'continue')])[1]");
    public static By saveDraftButton = By.xpath("//input[@value = 'Save Draft']");
    //Locators--------


    public AdditionalServicesPage(WebDriver webDriver) {
        this.driver = webDriver;
        utils = BaseCucumber.utils;
        log = Logger.getLogger(this.getClass().getName());
        gv = BaseCucumber.gv;
    }

    /**
     * Entering number of Fractions for External Beam Technique
     *
     * @param fractions
     */
    public void enterNumberOfFractionForExternalBeamTechnique(String fractions) {
        log.warn("Entering Number of fractions ");
        TestUtils.input(driver, numberOfFractionForExternalBeamTextBox, fractions);
    }

    /**
     * Select Drop down for Requested IGRT codes
     *
     * @param IGRTCode
     */
    public void selectDropDownRequestedIGRTCode(String IGRTCode) {
        log.warn("Select " + IGRTCode + " value from Drop-down");
        TestUtils.waitElement(driver, requestedIGRTCodeSel);
        TestUtils.onMouseHover(driver, requestedIGRTCodeSel);
        TestUtils.highlightElement(driver, requestedIGRTCodeSel);
        TestUtils.selectByVisibleText(driver.findElement(requestedIGRTCodeSel), IGRTCode);

    }

    /**
     * Entering number of IGRT units
     *
     * @param units
     */
    public void enterNumberOfIGRTUnits(String units) {
        log.warn("Entering Number of IGRT Units ");
        TestUtils.input(driver, requestedIGRTUnitsTextBox, units);
    }


    /**
     * Select all comma separated special codes
     * @param codestobeselected multiple drugs comma separated
     */
    public void selectSpecialCodes(String codestobeselected) {
        log.warn("Selecting special codes");
        String[] codeList = codestobeselected.split(",");
        for(String code : codeList){
            By specialCodeChkBox = By.xpath("//span[contains(@ng-class,' question.responseRequiredIndicator && ocmAssessmentConductor')]//span[contains(text(),'"+code+"')]/parent::*//input");
            TestUtils.waitElement(driver, specialCodeChkBox);
            TestUtils.onMouseHover(driver, specialCodeChkBox);
            TestUtils.highlightElement(driver, specialCodeChkBox);
            TestUtils.click(driver, specialCodeChkBox);
        }
    }

    // Methods

    /**
     * Select all comma separated medical record documentation for Special code 77470 e.g (1,2,3,4,5)
     * @param recordTobeSelectedFor77470 multiple drugs comma separated
     */
    public void selectmedicalRecordDocumentation77470(String recordTobeSelectedFor77470) {
        log.warn("Selecting special codes");
        String[] codeList = recordTobeSelectedFor77470.split(",");
        for(String code : codeList){
            By medicalRecordfor77470 = By.xpath("//div[contains(@class, 'question-wrapper') and contains(.,'below criteria for the request of 77470')]//div["+code+"]//input");
            TestUtils.waitElement(driver, medicalRecordfor77470);
            TestUtils.onMouseHover(driver, medicalRecordfor77470);
            TestUtils.highlightElement(driver, medicalRecordfor77470);
            TestUtils.click(driver, medicalRecordfor77470);
        }
    }


    /**
     * Select all comma separated medical record documentation for Special code 77370 e.g (1,2,3,4,5)
     * @param recordTobeSelectedFor77370 multiple drugs comma separated
     */
    public void selectmedicalRecordDocumentation77370(String recordTobeSelectedFor77370) {
        log.warn("Selecting special codes");
        String[] codeList = recordTobeSelectedFor77370.split(",");
        for(String code : codeList){
            By medicalRecordfor77370 = By.xpath("//div[contains(@class, 'question-wrapper') and contains(.,'below criteria for the request of 77370')]//div["+code+"]//input");
            TestUtils.waitElement(driver, medicalRecordfor77370);
            TestUtils.onMouseHover(driver, medicalRecordfor77370);
            TestUtils.highlightElement(driver, medicalRecordfor77370);
            TestUtils.click(driver, medicalRecordfor77370);
        }
    }

    /**
     * Select frequency requested for 77331
     *
     * @param frequency
     */
    public void selectFrequencyFor77331(String frequency) {
        log.warn("Select " + frequency + " value from Drop-down");
        TestUtils.waitElement(driver, requestedFrequencySel);
        TestUtils.onMouseHover(driver, requestedFrequencySel);
        TestUtils.highlightElement(driver, requestedFrequencySel);
        TestUtils.selectByVisibleText(driver.findElement(requestedFrequencySel), frequency);

    }

    /**
     * Entering Clinical Justification for Greater then 6 frequency for 77331
     *
     * @param clinincalJustFor77331
     */
    public void enterclinicalJustificationFor77331(String clinincalJustFor77331) {
        log.warn("Entering clinical Justification for Greater then 6 frequency for 77331");
        TestUtils.input(driver, clinicalJustFor77331TextBox, clinincalJustFor77331);
    }

    /**
     * Entering Clinical Justification for for 77399
     *
     * @param clinincalJustFor77399
     */
    public void enterclinicalJustificationFor77399(String clinincalJustFor77399) {
        log.warn("Entering clinical Justification for Greater then 6 frequency for 77399");
        TestUtils.input(driver, clinicalJustFor77399TextBox, clinincalJustFor77399);
    }

    /**
     * Entering Clinical Justification for for 77470
     *
     * @param otherclinincalJustFor77470
     */
    public void enterOtherclinicalJustificationFor77470(String otherclinincalJustFor77470) {
        log.warn("Entering Other clinical Justification for 77470");
        TestUtils.input(driver, otherClinicalJustFor77470TextBox, otherclinincalJustFor77470);
    }

    /**
     * Entering Clinical Justification for for 77370
     *
     * @param otherclinincalJustFor77370
     */
    public void enterOtherclinicalJustificationFor77370(String otherclinincalJustFor77370) {
        log.warn("Entering Other clinical Justification for 77370");
        TestUtils.input(driver, otherClinicalJustFor77370TextBox, otherclinincalJustFor77370);
    }

    /**
     * Select spacer used for 55874
     *
     * @param spacer
     */
    public void selectSpacerUsed(String spacer) {
        log.warn("Select " + spacer + " value from Drop-down");
        TestUtils.waitElement(driver, spacerUsedSel);
        TestUtils.onMouseHover(driver, spacerUsedSel);
        TestUtils.highlightElement(driver, spacerUsedSel);
        TestUtils.selectByVisibleText(driver.findElement(spacerUsedSel), spacer);

    }

    /**
     * Entering Additional services details for clone
     */

    public void enterAdditionalServicesForClone(Map<String, String> pf) throws Throwable {
        enterNumberOfFractionForExternalBeamTechnique(pf.get(MBM.AS_NUMBER_OF_FRACTION_EXTERNAL_BEAM));
        selectDropDownRequestedIGRTCode(pf.get(MBM.AS_IGRT_CODE));
        enterNumberOfIGRTUnits(pf.get(MBM.AS_IGRT_UNITS));
        selectSpecialCodes("77470");
        selectmedicalRecordDocumentation77470("2");
        clickContinueButton();
    }

    /**
     * Entering Additional services details for clone with No techinque
     */
    public void enterAdditionalServicesForNoTechnique(Map<String, String> pf) throws Throwable {
        selectDropDownRequestedIGRTCode(pf.get(MBM.AS_IGRT_CODE));
        enterNumberOfIGRTUnits(pf.get(MBM.AS_IGRT_UNITS));
        selectSpecialCodes("77470");
        clickContinueButton();
    }


    /**
     * Clicking on continue button on Additional Services Page
     *
     * @return Additional ServicePage
     */
    public void clickContinueButton() {
        TestUtils.safeClick(driver, continueButton);
    }
    public void clickSaveAsDraftButton() {
        TestUtils.safeClick(driver, saveDraftButton);
    }
  }





