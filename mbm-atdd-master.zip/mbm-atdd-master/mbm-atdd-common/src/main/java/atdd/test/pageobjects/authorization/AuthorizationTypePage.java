package atdd.test.pageobjects.authorization;

import atdd.test.shared.BaseCucumber;
import atdd.utils.Conf;
import atdd.utils.DateUtils;
import atdd.utils.MBM;
import atdd.utils.TestUtils;
import cucumber.api.DataTable;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.util.Arrays;
import java.util.List;

import static org.openqa.selenium.By.xpath;

public class AuthorizationTypePage {

    private WebDriver driver;
    private TestUtils utils;
    Logger log;

    public static final String POSInfoTextMessage = "For members over 18 years old, your authorization request will pend if the selected drug is on the Site of Care list because the medication CANNOT be administered by an Outpatient Place of Service.";
    public static final String SOCDrugPopupTitle = "Site of Care Drug Selected";

    //locators
    public static By authorizationType = By.xpath("//select[@id='authorizationType-hscAttributeValue-0']");
    public static By selectAuthTypeSection = By.xpath("//*[@id='authorizationTypePanelId']/div[@class = 'tk-panl-content-wrapper']");
    public static By selectAuthTypeSectionTitle = By.xpath("//*[@id='authorizationTypeHeader']");
    public static By authTypeDropdownLabel = By.xpath("//*[@id='authorizationTypeLabel']/label");
    public static By authTypeDropdown = By.xpath("//select[contains (@id, 'authorizationType-hscAttributeValue')]");
    public static By authInfoIcon = By.xpath("//span[@ng-click='openAuthorizationTypesPopup()']");
    public static By authTypesInfoPopup = By.xpath("//*[@id='authorizationTypesPopupModelID']//div[@class='tk-lbox-content-wrapper']");
    public static By authTypesInfoPopupTitle = By.xpath("//*[contains(@ng-focus,'authorizationTypesPopupModel.setFocus')]/h2");
    public static By closeBtnOnAuthTypeInfoPopup = By.xpath("//button[@ng-click='authorizationTypesPopupModel.closePopup()']");
    public static By authorizationTypeDropdownList = By.xpath("//select[contains(@id, 'authorizationType-hscAttributeValue')]");
    public static By continueButton = By.xpath("//input[@ng-click='continueAuthorization(authTypeForm)']");
    public static By specialtyPharmaDrugClass = By.xpath("//input[@ng-model='specialtyProcedure.drugClass']");
    public static By specialtyPharmaDrugCode = By.xpath("//*[@data-id='CreateAuth.AuthType.DrugCode—-dropdownMenu']");
    public static By specialtyPharmaDrugCodeinput = By.xpath("//*[@id='inputLabel-labelFilter-0']");
    public static By specialtyPharmaDrugCodeselect = By.xpath("//*[@id='memberDetailsProcedureCodePreferred']/div[2]/form/div[2]/div/div/label/span[2]");
    public static By specialtyPharmaDrugCodeselectabove = By.xpath("//*[@id='memberDetailsProcedureCodePreferred']/div[2]/form/div[2]/div/div/label/span");
    public static By backButton = By.xpath("//input[@id='toggleMemConfBackBtn']");
    public static By expiredMemberBlockingContinue = By.cssSelector("#continueInternalOperationsAuthorizationPopupID  input:nth-child(1)");
    public static By SelfadministeredDropdownLabel = By.xpath("//*[@id='selfAdministered']/label");
    public static By SelfadministeredDropdown = By.xpath("//select[contains (@id, 'sharedSAD-selfAdministeredRequired-userChoice-0')]");
    public static final By ReturntoDashboardbtn = By.xpath("//input[@value='Return to Dashboard']");
    //used in feature file as reference - actual value pulled from request details
    public static final By placeofServiceTypeSel = xpath("//select[contains(@id,'placeOfServiceCode-hscAttributeValue')]");

    public static final By initialInfusionMember = xpath("//select[contains(@id,'initialInfusionAnswer-hscAttributeValue-0')]");

    public static By buyandbillDropDown = By.xpath("//*[@id=\"sharedBAB-buyAndBillRequired-userChoice-0\"]");
    public static By warningOkay = By.xpath("//*[@id=\"buyAndBillOkayBtn\"]");
    public static By warningCancel = By.xpath("//*[@id=\"buyAndBillBackBtn\"]");
    public static By existingPharmacyAuthPopUPContinue = By.xpath("//*[@ng-click=\"existingClaimPriorAuthPopupModel.existingClaimPriorAuthContinue();\"]");
    public static By verifyExistingPharmacyAuthPopUP = By .xpath("//h2[text()=\"Existing Pharmacy Authorization/Claim\"]");

    public static By placeOfServiceInfoIcon = By.xpath("//span[@aria-label='Place of Service tooltip']");
    public static By placeOfServiceIconText = By.xpath("//span[@aria-label='Place of Service tooltip']/descendant::span[2]");

    // POS - Outpatient Facility - Site Of Drug Drug Pop-up.
    public static By placeOfServiceSOCDrugInfoPopup = By.xpath("//div[@id='outPatientWarningPopupModelDiv']");
    public static By placeOfServiceSOCDrugPopupTitle = By.xpath("//*[contains(@ng-focus,'outPatientWarningPopupModel')]/h2");
    public static By closeBtnOnPlaceOfServiceSOCDrugPopup = By.xpath("//button[@ng-click='outPatientWarningPopupModel.closePopup()']");
    public static By dob= By.xpath("//label[contains(.,'Date of Birth')]/following::td[1]");

    public AuthorizationTypePage(WebDriver webDriver) {
        this.driver = webDriver;
        utils = BaseCucumber.utils;
        log = Logger.getLogger(this.getClass().getName());
    }

    /**
     * Select option from Authorization Type drop-down
     *
     * @param type
     */
    public void selectAuthorizationType(String type) {
        log.warn("Selecting authorization Type: " + type);
        TestUtils.highlightElement(driver, authorizationType);
        new Select(this.driver.findElement(authorizationTypeDropdownList)).selectByVisibleText(type);
    }

    public void clickContinueButton() {
        this.driver.findElement(continueButton).click();
    }


    /**
     * Verifies Select Auth Type Section is displayed on Member information page
     */
    public void VerifySelectAuthSectionsDisplayed() {
        log.warn("Verifies Select Auth Type Section is displayed on Member information page");
        TestUtils.wait(3);
        Assert.assertTrue("Select Authorization Type pop up is not displayed", driver.findElement(selectAuthTypeSection).isDisplayed());
        Assert.assertTrue("Select Authorization Type title doesn't exist on Authorization Type Section",
                driver.findElement(selectAuthTypeSectionTitle).getText().contains("Authorization Type"));
    }

    /**
     * Verifies Auth Type Dropdown is present on Select Auth Type section
     */
    public void verifyAuthTpeDropdownOnSelectAuthSection() {
        log.warn("Verifies Auth Type dropdown is displayed on Select Auth Type Section");
        Assert.assertTrue("Auth Type dropdown is not displayed on Select Auth Type pop up window", driver.findElement(authTypeDropdown).isDisplayed());
        Assert.assertTrue("Authorization Type, required label is not present",
                driver.findElement(authTypeDropdownLabel).getText().contains("Authorization Type"));
    }


    /**
     * Verifies Auth Type Dropdown options on Select Auth Type section using datatable
     *
     * @param dropDownValues
     */
    public void validateAuthTypeDropdownOptions(DataTable dropDownValues) {
        log.warn("Verifies Auth Type Dropdown options on Select Auth Type section");
        List<List<String>> data = dropDownValues.raw();
        TestUtils.waitElement(driver, authTypeDropdown);
        driver.findElement(authTypeDropdown).click();

        for (int i = 0; i < data.size(); i++) {
            log.warn("Verifying value " + data.get(i).get(0) + " from Drop down values");
            By authTypeDropdownValue = xpath("//select[contains(@ng-model,'authorizationType.hscAttributeValue')]/option[contains(text(),'" + data.get(i).get(0) + "')]");

            Assert.assertTrue("Select option: " + data.get(i).get(0) + " doesn't exist",
                    driver.findElement(authTypeDropdownValue).isDisplayed());
            Assert.assertTrue("Select option: " + data.get(i).get(0) + " text doesn't match",
                    driver.findElement(authTypeDropdownValue).getText().contains(data.get(i).get(0)));
        }

    }

    /**
     * Selecting auth type option from Auth Dropdown
     *
     * @param type
     */
    public void selectAuthType(String type) {
        log.warn("Select auth Type On the auth dropdown " + type);
        TestUtils.waitElement(driver, authTypeDropdown);
        TestUtils.selectByVisibleText(driver, authTypeDropdown, type);
    }

    /**
     * Clicking on info icon on MemberInformationPage
     */
    public void userClicksOnAuthInfoIcon() {
        log.warn("Clicking on Auth Info Icon");
        TestUtils.wait(3);
        TestUtils.click(driver, authInfoIcon);
    }

    /**
     * Clicking on Tooltip icon on PlaceOfService.
     */
    public void userValidatesPOSToolTipText() {
        String hoverText = new String();
        log.warn("Clicking on POS Tooltip and compare the message.");
        TestUtils.wait(1);
        TestUtils.onMouseHover(driver, placeOfServiceInfoIcon);
        TestUtils.wait(2);
        hoverText = driver.findElement(placeOfServiceIconText).getText();
        TestUtils.wait(1);

        Assert.assertEquals(POSInfoTextMessage,hoverText.replace("\n"," "));
    }

    /**
     * Verifying place of service SOC Drug popup is displayed and its title on MemberInformationPage
     *
     * @param title
     */
    public void verifiesPlaceOfServiceSOCDrugPopupIsDisplayed(String title) {
        log.warn("Verifying place of service SOC Drug popup is displayed on MemberInformationPage and title as " + title);
        TestUtils.waitElement(driver, placeOfServiceSOCDrugInfoPopup);
        Assert.assertTrue("place of service SOC Drug popup window is not displayed", driver.findElement(placeOfServiceSOCDrugInfoPopup).isDisplayed());
        TestUtils.waitElement(driver, placeOfServiceSOCDrugPopupTitle );
        Assert.assertEquals("Popup title doesn't have title as " + title, title, driver.findElement(placeOfServiceSOCDrugPopupTitle).getText());
    }

    /**
     * Clicking X button on place of service SOC Drug Popup on MemberInformationPage
     */
    public void userClicksOnXBtnOnPlaceOfServiceSOCDrugPopup() {
        log.warn("Clicking X button on place of service - SOC Drug popup");
        TestUtils.waitElement(driver, closeBtnOnPlaceOfServiceSOCDrugPopup);
        driver.findElement(closeBtnOnPlaceOfServiceSOCDrugPopup).click();
    }

    /**
     * Verifying place of service SOC Drug is cosed on MemberInformationPage
     */
    public void verifiesPlaceOfServiceSOCDrugPopupIsClosed() {
        log.warn("Verifying place of service SOC Drug pop up is closed on MemberInformationPage");
        TestUtils.wait(2);
        Assert.assertFalse("Place of service SOC Drug popup window is not closed", driver.findElement(placeOfServiceSOCDrugInfoPopup).isDisplayed());
    }

    /**
     * Verifying Auth type info popup is displayed and its title on MemberInformationPage
     *
     * @param title
     */
    public void verifiesAuthTypePopupIsDisplayed(String title) {
        log.warn("Verifying Auth type info popup is displayed on MemberInformationPage and title as " + title);
        TestUtils.waitElement(driver, authTypesInfoPopup);
        TestUtils.highlightElement(driver, authTypesInfoPopup);
        Assert.assertTrue("Authorization Types popup window is not displayed", driver.findElement(authTypesInfoPopup).isDisplayed());
        TestUtils.highlightElement(driver, authTypesInfoPopupTitle);
        Assert.assertEquals("Popup title doesn't have title as " + title, title, driver.findElement(authTypesInfoPopupTitle).getText());
    }

    /**
     * Clicking X button on Auth Type Popup on MemberInformationPage
     */
    public void userClicksOnXBtnOnAuthTypePopup() {
        log.warn("Clicking X button on Auth Type Popup");
        TestUtils.waitElement(driver, closeBtnOnAuthTypeInfoPopup);
        TestUtils.highlightElement(driver, closeBtnOnAuthTypeInfoPopup);
        driver.findElement(closeBtnOnAuthTypeInfoPopup).click();
    }

    /**
     * Verifying Auth type info popup is cosed on MemberInformationPage
     */
    public void verifiesAuthTypePopupIsClosed() {
        log.warn("Verifying Auth type info popup is closed on MemberInformationPage");
        TestUtils.wait(2);
        TestUtils.highlightElement(driver, authTypesInfoPopup);
        Assert.assertFalse("Authorization Types popup window is not closed", driver.findElement(authTypesInfoPopup).isDisplayed());
    }

    /**
     * Verifying Auth type info popup Content MemberInformationPage
     *
     * @param content
     */
    public void verifyContentOfAuthTypesPopup(DataTable content) {
        log.warn("Verifying Auth type info popup Content" + content);
        List<List<String>> data = content.raw();

        for (int i = 0; i < data.size(); i++) {
            log.warn("Verifying value " + data.get(i).get(0) + " from Drop down values");
            By authTypeContent = xpath("//*[@id='authorizationList']//*[contains(text(),'" + data.get(i).get(0) + "')]");

            Assert.assertTrue("Content: " + data.get(i).get(0) + " doesn't exist",
                    driver.findElement(authTypeContent).isDisplayed());
            Assert.assertTrue("Content: " + data.get(i).get(0) + " text doesn't match",
                    driver.findElement(authTypeContent).getText().contains(data.get(i).get(0)));
        }

    }

    /*
     * This method verifies the default value for authorization type dropdown
     * @param expectedDefaultValue
     * */
    public void verifyAuthorizationTypeDropDownDefaultValue(String expectedDefaultValue) {
        Select sel = new Select(driver.findElement(authorizationTypeDropdownList));
        Assert.assertTrue(expectedDefaultValue + " is not the default value for authorization type ",
                sel.getFirstSelectedOption().getText().equals(expectedDefaultValue));
    }

    /**
     * Selecting Drug class on RequestDetailsPage
     *
     * @param drugClass
     */
    public void selectSpecialtyPharmaDrugClass(String drugClass) {
        TestUtils.input(driver, specialtyPharmaDrugClass, drugClass);
        TestUtils.wait(2);
        TestUtils.click(driver, By.xpath("//a[@title=\"" + drugClass + "\"]"));
    }

    /**
     * User enters sepcialty pharma drug code
     *
     * @param drugCode
     */
    public void enterSepcialtyPharmaDrugCode(String drugCode) {
            //preferred specialty drodown
        if(Conf.getInstance().getProperty("envset").contains("uhc")){
            TestUtils.click(driver, (By.xpath("//button[@data-id='CreateAuth.AuthType.DrugCode—-dropdownMenu']")));
            TestUtils.wait(2);
            TestUtils.input(driver, (By.xpath("//input[@ng-model='inputLabel.labelFilter']")), drugCode);
            TestUtils.wait(2);
            TestUtils.click(driver, By.xpath("//*[contains(text(),'"+drugCode+"')]//parent::span"));
        }else if (Conf.getInstance().getProperty("envset").contains("bcbssc")){
            TestUtils.click(driver, specialtyPharmaDrugCode);
            TestUtils.wait(2);
            TestUtils.input(driver, specialtyPharmaDrugCodeinput, drugCode);
            TestUtils.wait(2);
            try {
                TestUtils.click(driver, specialtyPharmaDrugCodeselect);
            } catch (Exception e) {
                TestUtils.click(driver, specialtyPharmaDrugCodeselectabove);
            }
        } else {
            //nonpreffered specialty dropdown
            TestUtils.input(driver, specialtyPharmaDrugCode, drugCode);
        }
    }

    /**
     * Selecting place of service on AuthorizationType Page
     *
     * @param service
     */
    public void selectDropDownValueInplaceofServiceTypeSel(String service) {
        log.warn("Selecting service ");
        TestUtils.input(driver, placeofServiceTypeSel, service);

    }

    /**
     * Selecting place of service on AuthorizationType Page
     *
     * @param service
     */
    public void selectDropDownValueInplaceofServiceTypeSelForProvider(String service) {
        log.warn("Selecting service ");
        TestUtils.input(driver, placeofServiceTypeSel, service);

        // When profile value for POS different, no need to perform below pop-up checks
        if (service.contains("Outpatient Facility") && DateUtils.getAge(driver.findElement(dob).getText()) > 18)
        {
            verifySOCDrugPopupForOutpatientFacility();
        }
        else if(service.contains("Outpatient Facility") && DateUtils.getAge(driver.findElement(dob).getText()) <= 18)
        {
            verifiesPlaceOfServiceSOCDrugPopupIsClosed();
        }

    }

    /**
     *  Place of Service -  Outpatient Facility --- Site of Care Drug Popup
     */
    public void verifySOCDrugPopupForOutpatientFacility()
    {
            // there will be a pop-up.
            verifiesPlaceOfServiceSOCDrugPopupIsDisplayed(SOCDrugPopupTitle);
            // verify content of pop-up.
            userClicksOnXBtnOnPlaceOfServiceSOCDrugPopup();
            // click Okay button and pop-up should close.
            verifiesPlaceOfServiceSOCDrugPopupIsClosed();
    }

    public void clickBackButton() {
        TestUtils.safeClick(driver, backButton);
    }

    public void clickContinueButtonExpiredMemberBlockingPopu() {
        TestUtils.safeClick(driver, expiredMemberBlockingContinue);
    }

    /**
     * Selecting service on AuthorizationType Page
     *
     * @param value
     */
    public void selectInitialInfusionMember(String value) {
        log.warn("Selecting Value ");
        TestUtils.input(driver, initialInfusionMember, value);
    }

    /**
     * User enters specialty drug code
     *
     * @param drugCode
     */
    public void enterSpecialtyDrugCode(String drugCode) {
        String drugName = "Ilaris";


        if (drugCode.equals("")) {
            drugName = "Ilaris";
        }

        By globalMessageXButton = By.xpath("//button[contains(text(), 'Select')]");

        TestUtils.findElements(driver, globalMessageXButton).get(0).click();
        By saveFaxButton = By.xpath("//input[contains (@id, 'inputLabel-labelFilter-0')]");
        TestUtils.input(driver, saveFaxButton, drugCode);
        String specialityDrugCodeText = ".//div[contains (@class, 'tk-chckbox-layer tk-multi-show')]";
        String specialityDrugCodeTextSelect = "..//span[contains (text(), '" + drugName + "')]";

        By specialityDrugCodeXpath = By.xpath(specialityDrugCodeText);
        By specialityDrugCode = By.xpath(specialityDrugCodeTextSelect);

        TestUtils.findElements(driver, specialityDrugCodeXpath).get(0).findElements(specialityDrugCode).get(0).click();

    }

    public void selectYesfromBuyandBill() {

        Select buyandbillYes = new Select(driver.findElement(buyandbillDropDown));
        buyandbillYes.selectByVisibleText("Yes");
    }

    public void selectNofromBuyandBill() {

        Select buyandbillNo = new Select(driver.findElement(buyandbillDropDown));
        buyandbillNo.selectByVisibleText("No");
    }

    public void enterBuyAndBillDrugCode(String drugCode) {

        By globalMessageXButton = By.xpath("//button[contains(text(), 'Select')]");

        TestUtils.findElements(driver, globalMessageXButton).get(0).click();
        By saveFaxButton = By.xpath("//input[contains (@id, 'inputLabel-labelFilter-0')]");
        TestUtils.input(driver, saveFaxButton, drugCode);
        String specialityDrugCodeText = ".//div[contains (@class, 'tk-chckbox-layer tk-multi-show')]";
        String specialityDrugCodeTextSelect = "..//span[contains (., '" + drugCode + "')]";

        By specialityDrugCodeXpath = By.xpath(specialityDrugCodeText);
        By specialityDrugCode = By.xpath(specialityDrugCodeTextSelect);
        //WebElement element = TestUtils.findElements(driver, specialityDrugCodeXpath).get(0);
        TestUtils.findElements(driver, specialityDrugCodeXpath).get(0).findElements(specialityDrugCode).get(0).click();

    }

    public void clickOkay() {
        driver.findElement(warningOkay).click();
    }

    public void clickCancel() {
        driver.findElement(warningCancel).click();
    }


    public void validatingDisplayOfPreferredAndNonPreferredBreakoutInUI(String drugClass, String testFlag) {
        selectSpecialtyPharmaDrugClass(drugClass);
        TestUtils.wait(2);

        if (testFlag.contains("preferred")) {
            Assert.assertTrue("SGP Preferred Products catagory not available for user selection", compareTwoLists());
        } else {
            Assert.assertTrue("SGP Preferred Products catagory not available for user selection", !compareTwoLists());

        }


    }

    private boolean compareTwoLists() {
        driver.findElement(By.xpath("//button[@data-id='CreateAuth.AuthType.DrugCode—-dropdownMenu']")).click();
        List<String> optionsList = Arrays.asList("Preferred Products", "Other");
        List<WebElement> dropdownList = driver.findElements(xpath("//input[@name='Label Filter']//following::label/span[@class='tk-multi-label ng-binding disabled']"));

        boolean found = false;
        for (String op : optionsList) {
            for (WebElement el : dropdownList) {
                found = el.getText().contains(op);
                log.warn(el.getText());
                if (found)
                    break;


            }
            if (!found)
                break;

        }
        driver.findElement(By.xpath("//button[@data-id='CreateAuth.AuthType.DrugCode—-dropdownMenu']")).click();
        return found;
    }

    public void verifySelfAdministeredDropdown() {
        log.warn("Verifies Self Administered dropdown is displayed on Selection of Drug code");
        Assert.assertTrue("Self-administered dropdown is not displayed on Selection of Drug code", driver.findElement(SelfadministeredDropdown).isDisplayed());
        Assert.assertTrue("Self-administered, required label is not present",
                driver.findElement(SelfadministeredDropdownLabel).getText().contains("Self-administered"));
    }

    public void selectsgpType(String selfadminvalue) {
        log.warn("Select self administered value " + selfadminvalue);
        TestUtils.waitElementVisible(driver,SelfadministeredDropdown);
        TestUtils.input(driver, SelfadministeredDropdown, selfadminvalue);
    }

    public void ClickReturntoDashboard() {
        log.warn("Click Return to Dashboard Button");
        //TestUtils.safeClick(driver, ReturntoDashboardbtn);
        TestUtils.waitElement(driver, ReturntoDashboardbtn);
        TestUtils.onMouseHover(driver, ReturntoDashboardbtn);
        driver.findElement(ReturntoDashboardbtn).click();

    }

    // Existing pharmacy page on
    public void VerifyExistingPharmacyPopUP() {
        log.warn("Existing Pharmacy specialty Authentication popup is displaying");
        utils.waitElement(driver, verifyExistingPharmacyAuthPopUP);
        utils.onMouseHover(driver, verifyExistingPharmacyAuthPopUP);
        Assert.assertTrue("Existing Pharmacy specialty Authentication popup is not displaying", driver.findElement(verifyExistingPharmacyAuthPopUP).isDisplayed());

    }


    // Existing pharmacy page on
    public void ClickExistingPharmacyPopUPContinue() {
        log.warn("Verified Existing Pharmacy Authentication Popup");
        //TestUtils.safeClick(driver, ReturntoDashboardbtn);
        utils.waitElement(driver, verifyExistingPharmacyAuthPopUP);
        utils.onMouseHover(driver, verifyExistingPharmacyAuthPopUP);
        driver.findElement(existingPharmacyAuthPopUPContinue).click();

    }


    /**
     * verifying authorization type is ""
     *
     * @param blank
     */
    public void VerifyAuthTypeIsBlank(String blank) {
        Select type = new Select(driver.findElement(authTypeDropdown));
        String defaultItem = type.getFirstSelectedOption().getText();
        Assert.assertEquals(blank, defaultItem);


    }

    public void clickContinueButtonOnDrugException() {
        try{
            TestUtils.isElementPresent(driver,By.xpath("//input[@ng-click='drugExceptionPopupModel.drugExceptionsContinue();']"));
            TestUtils.click(driver,By.xpath("//input[@ng-click='drugExceptionPopupModel.drugExceptionsContinue();']"));
        }
        catch (Exception e)
        {
            log.warn("no drug Exception popup present");
        }
    }
}



