package atdd.test.pageobjects.authorization;


import atdd.dao.mbm.*;
import atdd.test.shared.*;
import atdd.utils.*;
import cucumber.api.*;
import org.apache.log4j.*;
import org.junit.*;
import org.openqa.selenium.*;

import java.util.*;

import static org.openqa.selenium.By.*;

public class ClinicalStatusPage {

    private final static Logger log = Logger.getLogger(ClinicalStatusPage.class);
    private WebDriver driver;
    private TestUtils utils;

    //Locators
    public static By continueButton = xpath("//input[@ng-click='continueAction(newAuthForm)']");
    public static By showAnswersLink = xpath("//a[.='Show Answers']");
    public static By selectImmunotherapy = xpath("(//select[contains(@id, 'ocmAssessmentConductor')])[7]");
    public static By diagnosisDropdownList = xpath("//select[@ng-model='ocmAssessmentConductor.responses[question.questionID]']");
    public static By Doesmedicalrecorddocumentationstatethemember=xpath("//span[contains(text(),'Does medical record documentation state the member')]");
    public static By InitialInfusion=By.xpath("//span[contains(text(),'Is the request for initial infusion or re-initiation of therapy after more than 6 months?')]");
  //public static By InitialInfusion = By.xpath("//label[text()='Is the request for initial infusion or re-initiation of therapy after more than 6 months?']");
    public static By isElapsreDropdown = By.xpath("(//select[@ng-model='ocmAssessmentConductor.responses[question.questionID]'])[2]");

    public ClinicalStatusPage(WebDriver webDriver) {
        this.driver = webDriver;
        utils = BaseCucumber.utils;
    }

//Methods

    /**
     * Clicking on continue button on ClinicalStatusPage
     */
    public void clickContinueButton() {
        log.warn("Clicking on continue button on ClinicalStatusPage\n");
        TestUtils.click(driver, continueButton);
    }

    /**
     * Selecting clinicalStatusDropDownValue clinicalStatusDropDownLabel on ClinicalStatusPage
     *
     * @param value clinicalStatusDropDownLabel
     */
    public void chooseClinicalStatus(String value, String label) {
        log.warn("Selecting " + value + " from " + label + " on ClinicalStatusPage");
        By by = xpath("//*[contains(text(),'" + label + "')]/ancestor::div[contains(@id,'question-wrapper')]//select");
        if (TestUtils.isElementVisible(driver, by)) {
            TestUtils.select(driver, by, value);
        } else {
            by = xpath("//label[contains(., '" + label + "')]/../..//span[.='" + value + "']/../input[@type='radio']|//span[contains(text(),'" + label + "')]/../../..//span[.='" + value + "']/../input[@type='radio']");
            TestUtils.click(driver, by);
        }
    }

    /**
     * Selecting radio button on ClinicalStatusPage
     *
     * @param radio
     */
    public void selectRadioButton(String radio) {
        log.warn("selecting radio button on ClinicalStatusPage\n");
        driver.findElement(By.xpath("//span[text()='" + radio + "']//preceding-sibling::input[@type='radio']")).click();
    }

    /**
     * Checks Histology Drop down values on RequestDetailsPage Page
     */
    public void verifySelectFieldElements(String arg1, DataTable arg2) {
        log.warn("Verifying " + arg1 + " Drop down values on ClinicalStatusPage");
        List<List<String>> data = arg2.raw();
        By QuestionSelect = xpath("//label[contains(text(),'" + arg1 + "')]/../..//select|//span[contains(text(),'" + arg1 + "')]/../../..//select");
        TestUtils.waitElement(driver, QuestionSelect);
        driver.findElement(QuestionSelect).click();

        for (int i = 0; i < data.size(); i++) {
            log.warn("Verifying value " + data.get(i).get(0) + " from Drop down values");
            By clinicalStatusDropDownValue = xpath("//label[contains(text(),'" + arg1 + "')]/../..//select//option[text()='" + data.get(i).get(0) + "']|" +
                    "//span[contains(text(),'" + arg1 + "')]/../../..//select//option[text()='" + data.get(i).get(0) + "']");
            TestUtils.waitElement(driver, clinicalStatusDropDownValue);
            Assert.assertTrue("Select option: " + data.get(i).get(0) + " doesn't exist",
                    driver.findElement(clinicalStatusDropDownValue).isDisplayed());
            Assert.assertTrue("Select option: " + data.get(i).get(0) + " text doesn't match",
                    driver.findElement(clinicalStatusDropDownValue).getText().contains(data.get(i).get(0)));
        }
    }

    /**
     * selecting SomatostationRecept or metastatic question
     *
     * @param dropdownvalue
     */
    public void selectSomatostationReceptorMetastaticQuestion(String dropdownvalue) {
        By somatostationReceptorMetastatic = By.xpath("//span[contains(text(),'I attest that:')]/ancestor::span[contains(@class,'question')]/following::span[1]//select");
        TestUtils.waitElement(driver, somatostationReceptorMetastatic);
        TestUtils.highlightElement(driver, somatostationReceptorMetastatic);
        TestUtils.wait(2);
        TestUtils.selectByVisibleText(driver.findElement(somatostationReceptorMetastatic), dropdownvalue);
    }

    /**
     * Selecting option from Immunotherapy dropdown
     *
     * @param immunotherapy
     */
    public void selectImmunotherapyOption(String immunotherapy) {
        log.warn("Selecting option from Immunotherapy dropdown");
        TestUtils.wait(2);
        TestUtils.highlightElement(driver, selectImmunotherapy);
        TestUtils.selectByVisibleText(driver.findElement(selectImmunotherapy), immunotherapy);
    }

    /**
     * Selecting option from Select Diagnosis dropdown
     *
     * @param diagnosis
     */
    public void selectDiagnosis(String diagnosis) {
        log.warn("Selecting option from Select Diagnosis dropdown");
        TestUtils.select(driver, diagnosisDropdownList, diagnosis);
    }


    public boolean inputAnswer(String a, String q) {
        String answerDropdownXpath = "//div[contains(@class, 'question-wrapper') and contains(., '" + q + "')]/span[2]/*";
        String answerInputXpath = "//div[contains(@class, 'question-wrapper') and contains(., '" + q + "')]//input[@type='text']";
TestUtils.waitElementVisible(driver,By.xpath(answerDropdownXpath));
        if (TestUtils.isElementVisible(driver, By.xpath(answerDropdownXpath))) {
            return TestUtils.input(driver, By.xpath(answerDropdownXpath), a);
        } else if (TestUtils.isElementVisible(driver, By.xpath(answerInputXpath))) {
            return TestUtils.input(driver, By.xpath(answerInputXpath), a);
        } else {
            String answerRadioButtonXpath = "//div[contains(@class, 'question-wrapper') and contains(., '" + q + "')]/span[2]//span[.='" + a + "']/../input[@type='radio']";
            return TestUtils.click(driver, By.xpath(answerRadioButtonXpath));
        }
    }

    /**
     * Verifiying Header
     */
    public void verifyHiddenQuestion() {
        log.warn("Verifying header 'Does medical record documentation state the member' not visible on clinical status page");
        boolean displayed = driver.findElement(Doesmedicalrecorddocumentationstatethemember).isDisplayed();
        Assert.assertFalse("Header not visible 'available growth factors for auto approval on request details page'", displayed);
        TestUtils.wait(3);

    }

    public void verifyInitialInfusionQuestion() {
        log.warn("Verifying header 'Initial Infusion' visible on clinical status page");
        boolean displayed = driver.findElement(InitialInfusion).isDisplayed();
        Assert.assertTrue("Header not visible 'Is the request for initial infusion or re-initiation of therapy after more than 6 months?'", displayed);
        TestUtils.wait(3);

    }

    /**
     *
     * @param diagnosis
     */
    public void selectElapsreDropdown(String diagnosis) {
        log.warn("Selecting option from Select Elapsre dropdown");
        TestUtils.select(driver, isElapsreDropdown, diagnosis);
    }


    public void validateClinicalAssessmentInfoFromDB(String hscId, String expectedInfo) {
        String clinicalDetails = new HscCGPHistDao(MyBatisConnectionFactory.getSqlSessionFactory())
                .getclinicalInfoByHscID(hscId);
        if("null".equalsIgnoreCase(expectedInfo))
            Assert.assertEquals("clinical Q&A is not mactching",null,clinicalDetails);
        else
            Assert.assertEquals("clinical Q&A is not mactching",expectedInfo.trim(),clinicalDetails.trim());
        System.out.println("Clinical DB INfo"+clinicalDetails);
    }
}




