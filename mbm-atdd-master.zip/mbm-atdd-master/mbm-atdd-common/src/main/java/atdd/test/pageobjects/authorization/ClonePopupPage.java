package atdd.test.pageobjects.authorization;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ClonePopupPage {

    public static final String THIS_REQUEST_HAS_BEEN_CLONED_SUCCESSFULLY = "This Request has been cloned successfully.";

    public static By titleText = By.xpath("//div[@ng-focus=\"cloneAuthPopupModel.setFocus('start')\"]/h2");
    public static By xOutButton = By.xpath("//button[@ng-click='cloneAuthPopupModel.closePopup()']");
    public static By requiredLegend = By.xpath("//div[@id='cloneAuthContent']/div");
    public static By authorizationTypeLabel = By.xpath("//span[@id='authorizationTypeLabel' and contains(., 'Authorization Type')]");
    public static By authorizationDropdown = By.xpath("//select[@ng-model='cloneAuthPopupModel.authorizationType']");
    public static By authorizationDropdownOptionSelect = By.xpath("//select[@ng-model='cloneAuthPopupModel.authorizationType' and contains(@class, 'ng-invalid')]");
    public static By cancerTypeLabel = By.id("cancerTypeLabel");
    public static By cancerTypeInput = By.xpath("//input[@ng-model='cloneAuthDetails.hscAttributeValue']");
    public static By cloneCancel = By.id("cloneCancel");
    public static By cloneContinue = By.xpath("//*[@id='cloneContinue']");
    public static By message = By.id("globalMessages-description");
    public static By thisRequestHasBeenClonedSuccessfully = By.xpath("//*[.='" + THIS_REQUEST_HAS_BEEN_CLONED_SUCCESSFULLY + "']");
    public static By specialtyPharmaDrugClass = By.xpath("//select[@ng-model='cloneAuthDetails.drugClass']");
    public static By specialtyPharmaDrugCode = By.xpath("//label[(text()='Drug Code')]/following::td//input[@ng-model='cloneAuthDetails.procedureCode']");

    public static By getCancerTypeAutoCompleteOptionLocator(String cancerType) {
        return By.xpath("//a[contains(@title,'" + cancerType + "')]");
    }

    public ClonePopupPage(WebDriver webDriver) {

    }
}