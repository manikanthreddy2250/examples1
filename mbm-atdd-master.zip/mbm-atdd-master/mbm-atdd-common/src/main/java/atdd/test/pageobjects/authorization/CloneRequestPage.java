package atdd.test.pageobjects.authorization;


import atdd.test.shared.BaseCucumber;
import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import java.util.Arrays;
import java.util.List;

import static org.openqa.selenium.By.xpath;

public class CloneRequestPage {
    Logger log;
    private WebDriver driver;
    private TestUtils utils;
    private By clone_icon = By.xpath("//span[@title='Clone Request']");

    public CloneRequestPage(WebDriver webDriver) {
        this.driver = webDriver;
        utils = BaseCucumber.utils;
        log = Logger.getLogger(this.getClass().getName());
    }

    /**
     * Verifying that clone icon is present
     */

    public void user_Verifies_That_Clone_Icon_is_Present() {

        TestUtils.wait(5);
        String[] hexValue;
        String color = driver.findElement(clone_icon).getCssValue("color");

        if (color.startsWith("rgba")) {
            hexValue = color.replace("rgba(", "").replace(")", "").split(",");
        } else {
            hexValue = color.replace("rgb(", "").replace(")", "").split(",");
        }
        int hexValue1 = Integer.parseInt(hexValue[0]);
        hexValue[1] = hexValue[1].trim();
        int hexValue2 = Integer.parseInt(hexValue[1]);
        hexValue[2] = hexValue[2].trim();
        int hexValue3 = Integer.parseInt(hexValue[2]);

        String actualColor = String.format("#%02x%02x%02x", hexValue1, hexValue2, hexValue3);
        Assert.assertTrue("clone color is not #C25608", actualColor.equals("#c25608"));
        TestUtils.highlightElement(driver, clone_icon);
        Assert.assertTrue("clone icon is not present under action tab", TestUtils.isElementPresent(driver, clone_icon));

        Assert.assertEquals("Clone request is not present on hover", "Clone Request", driver.findElement(clone_icon).getAttribute("title"));
        log.warn("clone icon is present and color code is #C25608");
    }

    /**
     * Clicking the clone icon
     */

    public void clickCloneOption() {

        TestUtils.wait(5);
        TestUtils.waitElementVisible(driver,clone_icon);
        TestUtils.highlightElement(driver, clone_icon);
        driver.findElement(clone_icon).click();
        log.warn("successfully clicked on clone");
    }

    /**
     * clicking the cancel button on clone popup
     */
    public void user_click_The_x_Button_On_Popup() {
        By Cancel_button = By.xpath("//button[@ng-click='cloneAuthPopupModel.closePopup()']");
        //  By Cancel_button = By.xpath(".//*[@id='cloneAuthPopupModelID']/div[2]/div/div[1]/div[2]/button");


        driver.findElement(Cancel_button).click();

    }

    /**
     * selecting the auth type from dropdown  on clone popup
     */
    public void selectAuthType(String selectAuthType) {
        By dropdown_authType = By.xpath("//select[@id='cloneAuthPopupModel-authorizationType-0']");
        TestUtils.wait(5);
        TestUtils.selectByVisibleText(driver.findElement(dropdown_authType), selectAuthType);
        TestUtils.highlightElement(driver, dropdown_authType);
        log.warn("user selected supportive drugs from selectAuthType dropdown");
    }

    /**
     * clicking  the continue button on clone popup
     */

    public void clickContinueOnCloneRequestPage(String message) throws InterruptedException {
        By continue_On_Clone_Request = By.xpath("//input[@ng-click='cloneAuthorization(cloneAuthPopupModelForm)']");
        TestUtils.highlightElement(driver, continue_On_Clone_Request);
        driver.findElement(continue_On_Clone_Request).click();
        log.warn("user clicked on continue on clone request page");
        By elementTxt = By.xpath("//*[contains(text(),'" + message + "')]");


        boolean present = false;

        //Checking
        if (TestUtils.isElementPresent(driver, elementTxt)) {
            TestUtils.highlightElement(driver, elementTxt);
            present = true;
        }

        Assert.assertTrue("Element with text " + message + " is NOT visible. ", present);

    }

    /**
     * entering the cancer field  on clone popup
     */
    public void user_Enters_Cancer_Field_In_Clone_Request_Page(String cancerType) {
        By textbox_cancerType = By.xpath("//input[@ng-model='primaryCancer.hscAttributeValue']");
        TestUtils.highlightElement(driver, textbox_cancerType);
        driver.findElement(textbox_cancerType).clear();
        driver.findElement(textbox_cancerType).sendKeys(cancerType);
        log.warn("user selected" + cancerType + "from selectAuthType dropdown");
    }

    /**
     * verifing title of on clone popup
     *
     */

    /**
     * verifing title of on clone icon is under action tab in priorAuthSearch
     */
    public void user_Verifies_That_Clone_Icon_Is_Under_Action_Tab_In_Prior_Auth_Search() {
        TestUtils.wait(5);
        String[] hexValue;
        String color = driver.findElement(clone_icon).getCssValue("color");


        if (color.startsWith("rgba")) {
            hexValue = color.replace("rgba(", "").replace(")", "").split(",");
        } else {
            hexValue = color.replace("rgb(", "").replace(")", "").split(",");
        }
        int hexValue1 = Integer.parseInt(hexValue[0]);
        hexValue[1] = hexValue[1].trim();
        int hexValue2 = Integer.parseInt(hexValue[1]);
        hexValue[2] = hexValue[2].trim();
        int hexValue3 = Integer.parseInt(hexValue[2]);

        String actualColor = String.format("#%02x%02x%02x", hexValue1, hexValue2, hexValue3);

        Assert.assertTrue("clone color is not #C25608", actualColor.equals("#c25608"));
        log.warn("color code is #c25608");
    }

    /**
     * verifing required label of on clone popup
     */
    public void user_Verifies_Is_Present_Under_The_Title_Of_Clone_Popup(String text) {
        By popup_content = By.xpath("//label[contains(text(),'" + text + "')]");
        Assert.assertTrue(text + "is not present under the title", TestUtils.isElementPresent(driver, popup_content));
    }

    /**
     * verifing the contents of dropdown on clone popup
     */
    public void user_Verifies_The_Contents_Of_Dropdown() {
        By required = By.xpath("//label[contains(text(),'Authorization Type')]/span[@title='Required']");
        TestUtils.wait(3);
        Assert.assertTrue("authorization type is not required", TestUtils.isElementPresent(driver, required));
        log.warn("Authorization field is mandatory field");
        By dropdown_authorizationType = By.xpath("//select[@ref-nm='authorizationType']");
        Select select = new Select(driver.findElement(dropdown_authorizationType));
        Assert.assertTrue("default value is not select", select.getFirstSelectedOption().getText().equals("Select"));
        List<String> contents = Arrays.asList("Select", "Cancer Supportive Drug Only", "Injectable Chemotherapy");
        TestUtils.validateDropDownOptions(contents, select.getOptions());
    }

    /**
     * Verifies that clone Icon is not Present
     */
    public void user_Verifies_That_Clone_Icon_is_not_Present() {
        By clone_icon_not_present = By.xpath("//tbody/tr[1]/td[1]/div[@class='ng-scope cloneButton-noClone']");
        log.warn("checking for clone icon");
        Assert.assertFalse("clone is  present under the title", TestUtils.isElementPresent(driver, clone_icon_not_present));
        log.warn("clone icon is not present");
    }

    /**
     * selecting the auth type from dropdown  on clone popup
     */
    public void selectInitialInfusion(String selectValue) {
        By initialInfusionMember = xpath("//select[contains(@id,'initialInfusionAnswer-hscAttributeValue-0')]");
        TestUtils.wait(5);
        TestUtils.selectByVisibleText(driver.findElement(initialInfusionMember), selectValue);
        TestUtils.highlightElement(driver, initialInfusionMember);
        log.warn("user answers initial infusion in clone modal");
    }

    /**
     * clicking the cancel button on clone popup
     */
    public void user_click_The_continue_Button_On_Popup() {

        By Continue_button = xpath("//input[@ng-click='existingAuthorizationData.onClonePopupOK(cloneAuthPopupModelForm)']");

        driver.findElement(Continue_button).click();

    }

    /**
     * selecting the option from Buy and Bill dropdown  on clone popup
     */
    public void selectBuyAndBill(String selectValue) {
        By buyAndBill = xpath("//select[contains(@ng-model,'sharedBAB.buyAndBillRequired.userChoice')]");
        TestUtils.wait(5);
        TestUtils.selectByVisibleText(driver.findElement(buyAndBill), selectValue);
        TestUtils.highlightElement(driver, buyAndBill);
        log.warn("user answers buy and bill in clone modal");
    }


    public void selectPlaceOfService(String placeOfservice) {
        By placeOfserviceSel = xpath("//select[contains(@ng-model,'cloneAuthDetails.placeOfServiceCode')]");
        log.warn("Entering place of service");
        TestUtils.waitElement(driver, placeOfserviceSel);
        Select dr = new Select(driver.findElement(placeOfserviceSel));
        dr.selectByVisibleText(placeOfservice);
    }

    public void EnterCancerType(String cancer) {
        By Cancer = By.xpath("//input[@ng-model='cloneAuthDetails.hscAttributeValue']");
        log.warn("entering cancer type");
        TestUtils.input(driver, Cancer, cancer);
        By value = By.xpath("(//a[contains(@title,'" + cancer + "')])[1]");
        TestUtils.wait(2);
        TestUtils.click(driver, value);
    }

    public void selectPlaceOfServiceForSpecialtyPharmacy(String placeOfservice) {
        By placeOfserviceSel = xpath("//select[contains(@ng-model,'cloneAuthPopupModel.placeOfServiceCodeBCBSSGPSelect')]");
        log.warn("Entering place of service");
        TestUtils.waitElement(driver, placeOfserviceSel);
        Select dr = new Select(driver.findElement(placeOfserviceSel));
        dr.selectByVisibleText(placeOfservice);
    }

    /**
     * clicking the Continue button on clone auth and Submit the auth.
     * All the information prepopulated as part of clone process, nothing to enter any information.
     */
    public void ContinueCloneAuthStepperAndSubmit()
    {
        By continueButton = By.xpath("//input[contains(@class, 'continue-button')]");
        By submitButton = By.xpath("//input[@ng-click='continueAction(newAuthForm)']");;
        TestUtils.wait(5);
        for (int i = 0; i< 5; i++)
        {
            log.warn("Clicking Continue Button");
            TestUtils.waitElement(driver, continueButton);
            TestUtils.onMouseHover(driver, continueButton);
            TestUtils.wait(5);
            TestUtils.highlightElement(driver, continueButton);
            driver.findElement(continueButton).click();
            TestUtils.wait(10);
        }

        TestUtils.highlightElement(driver, submitButton);
        driver.findElement(submitButton).click();
        TestUtils.wait(10);
    }
}
