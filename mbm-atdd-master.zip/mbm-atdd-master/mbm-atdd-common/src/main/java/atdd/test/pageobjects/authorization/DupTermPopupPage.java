package atdd.test.pageobjects.authorization;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class DupTermPopupPage {

    public static final By okButton = By.xpath("//form[@name='existingAuthorizationPopupModelForm']//input[@value='OK']");
    public static final String continueButtonXpath = "//form[@name='existingAuthorizationPopupModelForm']//input[@value='Continue']";
    public static final By continueButton = By.xpath(continueButtonXpath);
    public static final By existingAuthMessageDiv = By.id("existingAuthMessageDiv");

    private final WebDriver webDriver;

    public DupTermPopupPage(WebDriver webDriver) {
        this.webDriver = webDriver;
    }

    public void clickOK() {
        this.webDriver.findElement(okButton).click();
    }

    public void clickContinue() {
        this.webDriver.findElement(continueButton).click();
    }

    public String getMessage() {
        return this.webDriver.findElement(existingAuthMessageDiv).getText();
    }
}
