package atdd.test.pageobjects.authorization;

import atdd.utils.StringUtils;
import atdd.utils.TestUtils;
import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import static atdd.test.pageobjects.authorization.RegimensPage.fileUploadStatus;

public class EditAuthorizationPage {

    public static By backdatingStartDateCheckBox = By.id("backdatingStartDate");
    public static By authorizationStartDateInputBackdate = By.xpath("//input[@ng-model='authStartDate.date']");
    public static By authorizationStartDateInput = By.xpath("//input[@ng-model='authorizationStartDate.hscAttributeValue']");

    public static By confirmButton = By.xpath("//input[@value='Confirm']");
    public static By backdToDashboardButton = By.xpath("//input[@value='Back to Dashboard']");

    private final WebDriver driver;
    private By backdateAuthJustification = By.xpath("//select[@ref-nm='backdateAuthJustification']");
    public EditAuthorizationPage(WebDriver driver) {
        this.driver = driver;
    }

    public void enterAuthorizationStartDate(String backdate) {
        TestUtils.input(driver, authorizationStartDateInput, backdate);
    }

    public void clickConfirmButton() {
        TestUtils.click(driver, confirmButton);
        TestUtils.wait(15);
        TestUtils.waitForNotBusy(driver);
        TestUtils.waitElementVisible(driver,By.xpath("//span[contains(text(),'Request Status')]"));
        Assert.assertTrue("the header is not matched",TestUtils.isElementPresent(driver,By.xpath("//span[contains(text(),'Request Status')]")));
    }

    public void clickBackdatingStartDateCheckBox() {
        TestUtils.wait(2);
        TestUtils.waitElementVisible(driver,backdatingStartDateCheckBox);
       if(!driver.findElement(backdatingStartDateCheckBox).isSelected())
        TestUtils.click(driver, backdatingStartDateCheckBox);
    }

    public void clickBackdToDashboardButton() {
        TestUtils.click(driver, backdToDashboardButton);
        TestUtils.tryAccecpt(driver);
    }

    public void selectJustificationForBackdatingOfStartDate(String option) {
        TestUtils.select(driver, backdateAuthJustification, option);
    }

    /**
     * add documentaion on backdating screen
     * @param fileName
     */
    public void clickAddDocumentationOnBackDatingScreen(String fileName) {
        if (StringUtils.isEmpty(fileName)) {
            Assert.fail("file not available");
        } else {
            TestUtils.waitElementVisible(driver,fileUploadStatus);
            TestUtils.uploadFile(driver, "btnFileSelectorAlias", fileName, fileUploadStatus);
        }
    }

    /**
     * enter auth date on the edit auth screeen
     * @param date
     */
    public void enterAuthorizationStartDateOnBackdatingScreen(String date) {
        TestUtils.input(driver, authorizationStartDateInputBackdate, date);

    }

}
