package atdd.test.pageobjects.authorization;


import atdd.test.shared.BaseCucumber;
import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * Created by pvavilal on 12/3/18.
 */
public class MemberInformationPage {
    private WebDriver driver;
    private TestUtils utils;
    Logger log;

    //Locators
    private By createBtn = By.xpath("//input[contains(@ng-click,'continueAuthorization')]");
    private By memberInformationSection = By.xpath("//div[@id='memberInformationPanelIdContent']");
    private By riBlockPopupMessage = By.xpath("(//span[@id='globalMessages-description'])/span");
    private By riBlockPopup = By.xpath("//*[@id='globalMessages']/div");

    public MemberInformationPage(WebDriver webDriver) {
        this.driver = webDriver;
        utils = BaseCucumber.utils;
        log = Logger.getLogger(this.getClass().getName());
    }

    //Methods

    /**
     * Clicking on continue button on MemberInformationPage
     *
     */
    public void clickContinueButton() {
        log.warn("Click Continue Button");
        TestUtils.waitElement(driver, createBtn);
        TestUtils.onMouseHover(driver, createBtn);
        driver.findElement(createBtn).click();
    }

    public void verifyMemberInformationDisplayed(){

        log.warn("verifying member Information page is displayed");
        TestUtils.wait(10);
        Assert.assertTrue(TestUtils.isElementVisible(driver, memberInformationSection));
    }

    public void verifyRIBlockingPopupDisplayed() {
        log.warn("verifying RI Blocking popup is displayed");
        TestUtils.wait(2);
        String expectedMessage = "In order to request a prior authorization for this member, please call 1-888-397-8129";
        Assert.assertTrue(TestUtils.isElementVisible(driver, riBlockPopup));
        Assert.assertEquals("message is not matching",expectedMessage,driver.findElement(riBlockPopupMessage).getText());

    }
}
