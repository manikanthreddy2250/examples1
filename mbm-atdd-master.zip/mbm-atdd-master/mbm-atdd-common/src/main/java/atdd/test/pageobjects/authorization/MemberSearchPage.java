package atdd.test.pageobjects.authorization;


import atdd.test.shared.BaseCucumber;
import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.openqa.selenium.By.cssSelector;

/**
 * Authorization -> Add New
 */
public class MemberSearchPage {

    private WebDriver driver;
    private TestUtils utils;
    Logger log;

    //Locators
    public static final By lastName = By.xpath("//input[contains(@id,'LastName')]");
    public static final By firstName = By.xpath("//input[contains(@id,'FirstName')]");
    public static final By searchButton = By.xpath("//input[contains(@ng-click, 'memberSearch')]");
    public static final By dateofBirth = By.xpath("//input[@name='Birth Date']");
    public static final By subscriberID = By.xpath("//input[@id='memberSearchFormSUBID' or @id='memberSearchFormSubscriberID']");//("//input[@id='memberSearchTable-tableFilters-subscriberID-0']");
    public static final By continueBtn = By.xpath("//input[@ng-click='continueAuthorization()']");
    public static final By authorizationTypeSel = By.xpath("//select[contains(@id,'authorizationType-hscAttributeValue')]");
    public static final By memberSearch = cssSelector("div[custom-include*='memberSearch']");
    public static final By detailsIcon = By.xpath(" //span[@title='Details']");
    public static final By lastNameRadioButton = By.xpath("//input[@id='memberSearchTypeLNameRadio']");
    public static final By allMembersRadioButton = By.xpath("//input[@id='memberSearchAllRadio']");
    public static final String payersSelectXpath = "//select[@ref-nm='payers']";
    public static final By payersSelect = By.xpath(payersSelectXpath);
    private By memberData = By.xpath("//table[@id='memberSearchTableID']//tr[@class='ocmTableRow ng-scope'][1]//span[@ng-click='memberSearchTable.selectRecord(record)']");
    //Locators

    public MemberSearchPage(WebDriver webDriver) {
        this.driver = webDriver;
        utils = BaseCucumber.utils;
        log = Logger.getLogger(this.getClass().getName());
    }

    /**
     * Entering Date of birth on the Member search page
     *
     * @param dob
     * @return
     */
    public MemberSearchPage enterDOB(String dob) {
        log.warn("Entering Date of birth " + dob + " on the Member search page");
        TestUtils.input(driver, dateofBirth, dob);
        return this;
    }

    /**
     * Entering Subscriber ID on the Member search page
     *
     * @param subID
     */
    public MemberSearchPage enterSubscriberID(String subID) {
        log.warn("Entering Subscriber ID " + subID + " on the Member search page");
        TestUtils.input(driver, subscriberID, subID);
        return this;
    }

    /**
     * Entering Last Name on the Member search page
     *
     * @param name
     */
    public MemberSearchPage enterLastName(String name) {
        log.warn("Entering Last Name " + name + " on the Member search page");
        TestUtils.input(driver, lastName, name);
        return this;
    }

    /**
     * Clicking Search button on the Member search page
     */
    public MemberSearchPage clickSearchButton() {
        log.warn("Clicking Search button on the Member search page");
        TestUtils.click(driver, searchButton);
        return this;
    }

    /**
     * Clicking Search button on the Member search page
     */
    public MemberSearchPage clickContinueButton() {
        log.warn("Clicking Continue button on the Member search page");
        TestUtils.click(driver, continueBtn);
        return this;
    }

    /**
     * Selecting authorizarion type
     *
     * @param authorizationType
     */
    public void selectDropDownValueInAuthorizationType(String authorizationType) {
        log.warn("Selecting authorizarion type");
        utils.wait(3);
        TestUtils.select(driver, authorizationTypeSel, authorizationType);
    }

    public void verifyvaluesfromDb(String subscriberid, List<Map<String, Object>> mbr, List<Map<String, Object>> dbaddr, List<Map<String, Object>> dbdates) {

        By fullname = By.xpath("//label[contains(text(),'Full Name')]//ancestor::td//following::td[1]");
        String fullName = driver.findElement(fullname).getText();
        String names[] = fullName.split(" ");
        By subid = By.xpath("//label[contains(text(),'Subscriber ID')]//ancestor::td//following::td[1]");
        By gender = By.xpath("//label[contains(text(),'Gender')]//ancestor::td//following::td[1]");
        By address = By.xpath("//label[contains(text(),'Address')]//ancestor::td//following::td[1]");
        By groupid = By.xpath("//label[contains(text(),'Group ID')]//ancestor::td//following::td[1]");
        Assert.assertEquals("firstname doesnot match", names[0], mbr.get(0).get("first_name").toString());
        Assert.assertEquals("lastname doesnot match", names[1], mbr.get(0).get("last_name").toString());
        Assert.assertEquals("subscriderID doesnot match", driver.findElement(subid).getText(), mbr.get(0).get("memberid").toString());
        if (driver.findElement(gender).getText().equals("Male")) {
            Assert.assertEquals("gender doesnot match", "8", mbr.get(0).get("gender").toString());
        } else {
            Assert.assertEquals("gender doesnot match", "9", mbr.get(0).get("gender").toString());
        }
        Assert.assertEquals("groupid doesnot match", driver.findElement(groupid).getText(), dbdates.get(0).get("groupid"));
        Assert.assertTrue("address doesnot match", driver.findElement(address).getText().contains(dbaddr.get(0).get("address1").toString()));
    }


    public void verifySearchMessage(String message) {
        log.warn("verfying search message is displayed");
        TestUtils.wait(2);
        By txtMessagge = By.xpath("//td[contains(text(), '" + message + "')]");
        Assert.assertTrue(TestUtils.isElementVisible(driver, txtMessagge));

    }

    public void verifyMemberSearchPageIsDisplayed() {
        log.warn("verifying member search page is dispalyed");
        Assert.assertTrue(TestUtils.isElementVisible(driver, memberSearch));

    }

    public void clickDetailsIcon() {
        log.warn("clicking details Icon");
        TestUtils.safeClick(driver, detailsIcon);
    }

    public void clickLastNameRadioButton() {
        log.warn("clicking Last Name Radio Button");
        TestUtils.safeClick(driver, lastNameRadioButton);
    }

    public void clickAllMembersRadioButton() {
        log.warn("clicking Last Name Radio Button");
        TestUtils.safeClick(driver, allMembersRadioButton);
    }

    public void selectPayer(String payer) {
        if (TestUtils.isElementVisible(driver, payersSelectXpath)) {
            TestUtils.input(driver, payersSelect, payer);
        }
    }

    public void enterFirstName(String s) {
        TestUtils.input(driver, firstName, s);
    }

    public void verifyRestrictedMessageInMemberSearch(){
        String xpath = "//td[@ng-if='record.memberMasked == true']//span[@class='maskedRowText']";
        List<WebElement> messages = driver.findElements( By.xpath(xpath));
        List<String> restrictedMessageDisplayed = new ArrayList<String>();
        System.out.println(" Verifying Restricted Policies Message:");
        messages.forEach(i -> restrictedMessageDisplayed.add(i.getText().trim()));
        System.out.println(restrictedMessageDisplayed);
        Assert.assertTrue(restrictedMessageDisplayed.contains("This entry cannot be viewed due to insufficient security privileges."));
    }
    public void selectMemberData()
    {
        log.warn("Select Member data");
        TestUtils.wait(7);
        if(!(TestUtils.isElementVisible(driver,authorizationTypeSel))){
            TestUtils.click(driver, memberData);
            TestUtils.wait(5);
        }
        else {
            log.warn("Member Information page is displayed");
        }
    }
}
