package atdd.test.pageobjects.authorization;


import atdd.common.ICondition;
import atdd.common.Retry;
import atdd.common.WaitUntil;
import atdd.test.shared.BaseCucumber;
import atdd.utils.StringUtils;
import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

import static org.openqa.selenium.By.xpath;


public class RegimensPage {

    Logger log;
    private WebDriver driver;
    private TestUtils utils;

    //Locators--------
    //public static By autoApprovedregimen = xpath("(//*[@class='selection-wrapper']//span)[1]");
    public static By autoApprovedregimen = xpath("(//*[@class='selection-wrapper']//span)[1]");
    // public static By continueButton = cssSelector("[id='regimensPanelIdContent'] [class='continue-button ng-scope tk-btn']");
    public static By continueButton = By.xpath("//*[@id='regimensPanelIdContent'] //input[@class='continue-button ng-scope tk-btn'] | //*[@id='customRegimenPanelIdContent'] //input[@value='Continue']");
    public static By header = xpath("//span[contains(text(),'Regimens')]");
    public static By createCustomRegimenLink = By.xpath("//a[contains(text(),'Create Custom Regimen')]");
    public static By createCustomRequestLink = By.xpath("//a[contains(text(),'Create Custom Request')]");
    public static By drugNameTextBox = By.xpath("//input[contains(@id,'hscServiceVO-procedureCode')]");
    public static By drugNameSelect = By.xpath("//select[@ng-model='drug.selectedNdcCode']|//select[@ng-model='hscServiceVO.selectedNdcCode']");
    public static By drugCodeTextBox = By.xpath("//input[@name='Procedure Code']");
    public static By procedureCodeTypeahead = By.xpath("//*[(name()='ocm:typeahead' or name()='ocm-typeahead') and @ng-model='hscServiceVO.procedureCode']");
    public static By drugrouteregimen = By.xpath("//select[@ref-nm='medicationAdminRouteType']");
    public static By dosageTextBox = By.cssSelector("input[ng-model*='hscServiceVO.hscServiceNonFacilityVO.procUnitDesc']");
    public static By daysofAdministrationTextBox = By.cssSelector("input[ng-model*='hscServiceVO.hscServiceNonFacilityVO.procDayPerCycleDesc']");
    public static By lengthofCyclesTextBox = By.cssSelector("input[ng-model*='hscServiceVO.hscServiceNonFacilityVO.lengthOfCycleDesc']");
    public static By addButton = By.cssSelector("[name='regimenDrugsTable.editPopupForm'] input[value='Add']");
    public static By okButton = By.xpath("//input[(@ng-click='supportiveCareDrugPopupModel.closePopup()')]");
    public static By regimenJustificationTextBox = By.xpath("//textarea[@id='customRegimenDO-customTreatmentRegimenDesc-0']");
    //public static By customContinueButton = By.cssSelector("[id='customRegimenPanelIdContent'] input[value='Continue']");
    public static By customContinueButton = By.xpath("//*[@id='regimensPanelIdContent'] //input[@class='continue-button ng-scope tk-btn'] | //input[@ng-click='customRegimenContinue(newAuthForm)'] | //*[@id='customRegimenPanelIdContent'] //input[@value='Continue']");
    public static By operationsUrgentRequestCheckbox = By.xpath("//input[@id='operationsUrgentCheckbox' or @id='providerUrgentCheckbox']");
    public static By urgentRequestCheckbox = By.xpath("//input[@ng-model='urgentRequest.hscAttributeValue']");
    public static By urgentRequestOutcome = By.xpath("//select[contains(@id, 'urgentRequestOutcome-hscAttributeValue')]");
    public static By drugCodeValue = By.xpath("//label[text()='Drug Code']/ancestor::td[1]/following-sibling::td//span");
    public static By drugNameValue = By.xpath("//div[@ng-if='UNCLASSIFIED_DRUG_LIST.indexOf(hscServiceVO.procedureCode) === -1']/span[@class='ng-binding']");
    public static By drugrouteValue = By.xpath("//div[@ng-if='isRadioPharma']/span[@class='ng-binding ng-scope']");
    public static By dosageTextValue = By.xpath("//label[text()='Dosage']/ancestor::td[1]/following-sibling::td//span");
    public static By daysofAdministrationValue = By.xpath("//label[contains(text(),'Day(s) of Cycle to')]/ancestor::td[1]/following-sibling::td//span");
    public static By lengthofCyclesValue = By.xpath("//label[contains(text(),'Length of Cycles ')]/ancestor::td[1]/following-sibling::td//span");
    public static By drugNameDropdownListForSupportiveRequest = By.id("drugName");
    public static By specialtyPharmaDosageNumberField = By.xpath(".//label[contains(.,'Dosage')]/following::td//*[contains(@type,'number')]");
    public static By specialtyPharmaDosageDropDown = By.xpath(".//label[contains(.,'Dosage')]/following::td//select[contains(@ref-nm,'drugUnitOfMeasureType')]");
    public static By specialtyPharmaDosageFrequencyOfAdministration = By.xpath(".//label[contains(.,'Frequency of ')]/following::td//select[contains(@ref-nm,'specialtyProcFreqType')]");
    public static By specialtyPharmaAddDrugAddButton = By.xpath("//*[@value='Add']");
    public static By drugName = By.xpath("//label[text()='Drug Name']/ancestor::td[1]/following-sibling::td/span");
    public static By regimenSelectErrorMsg = By.xpath("//*[@id='globalMessages']/div[@class='oui-pmsg ng-scope oui-pmsg-error']");
    public static By regimenSelectErrMsgDesc = By.xpath("//*[@id='globalMessages-description']");
    public static By addRadioDrugMsg = By.xpath("//td[contains(@ng-bind-html,'regimenDrugsTable.noRecordsMessage')]");
    public static By okBtnOnSupportiveCareDrugPopup = By.xpath("//input[@ng-click='supportiveCareDrugPopupModel.closePopup()']");
    public static By oralDrugIncludeRegimenPopupModelForm = By.name("oralDrugIncludeRegimenPopupModelForm");
    public static By oralDrugIncludeRegimenPopupModelFormOKButton = By.xpath("//form[@name='oralDrugIncludeRegimenPopupModelForm']//input[@value='OK']");
    public static By chemoRegimenQuestion = By.xpath("//form[@name='neulastaScheduleWarningPopupModelForm']//input[@value='Yes']");
    public static By addDrugLink = By.xpath("//a[contains(text(),'Add Drug')]");
    public static By addTechniqueLink = By.xpath("//a[contains(text(),'Add Technique and/or Service')]");
    public static By addDrugLinkForSupportive = By.xpath("//a[contains(text(),'Add Supportive Drug')]");
    public static By cancelLink = By.xpath("//form[@name='regimenDrugsTable.editPopupForm']//input[@value='Cancel']");
    public static By tehniquecancelLink = By.xpath("//form[@name='techniqueServiceTable.editPopupForm']//input[@value='Cancel']");
    public static By techniquecodetype = By.xpath("//select[@ref-nm='procCodeType']");
    public static By fractionunits = By.cssSelector("input[ng-model*='hscServiceVO.hscServiceNonFacilityVO.totalDosageCount']");
    public static By radioPharmaDrugNotificationHeader = By.xpath("//*[contains(text(), 'Radiopharmaceutical Drug Notification')]");
    public static By radioPharmaDrugNotificationPopupMessage = By.xpath("//*[@id='radiopharmaMessageDiv']/p");
    public static By radioPharmaDrugNotificationPopupCancelButton = By.xpath("//*[@id='radiopharmaMessageDiv']/following-sibling::div/input[2]");
    public static By radioPharmaDrugNotificationPopupContinueButton = By.xpath("//*[@id='radiopharmaDrugNotificationPopupModelID']//input[1]");
    public static By popupContinueButton = By.xpath("//*[@custom-include='ocmRegimensView.showNonPreferredSupportivesPopupModel.customPopupTemplate']//input[@value='Continue']");
    public static By choicefromAvailableGrowthFactorsforAutoApproval = xpath("//*[text()='1']/../following-sibling::span//*[@role='radio']");
    public static By otherOptionsRequiringClinicalReview = xpath("//h2[text()='Other Options (Requiring Clinical Review)']/../div//span[text()='1']/../following-sibling::span/span");
    public static By continueFromSupportiveReviewRequiredPopup = xpath("//*[@ng-click='loadSelectedNonPreferredSupportiveInCustom();preferredRegimenWarningPopupModel.closePopup();']");
    public static By drugExceptionNotificationMessage = By.xpath("//*[@id='customDrugExceptionMessageDiv']/p");
    public static final String regimenDropDownButton = "//span[@class='ocm-action tk-panl-helper cux-icon-caret_right']";
    public static final String serviceLines = "//table[@role= 'presentation'][@class = 'second']";
    public static final String customDrugExceptionPopupModelFormContinueButtonXpath = "//form[@name='customDrugExceptionPopupModelForm']//input";

    public static By antemeticDrugRadioButton = xpath("//input[@ng-model='ocmRegimensView.highRiskModel.shouldShowSupportiveAntiEmeticDrugs'][@ng-value='false']");
    public static By growthDrugRadioButton = xpath("//input[@ng-model='ocmRegimensView.highRiskModel.shouldShowSupportiveGrowthFactorDrugs'][@ng-value='true']");

    public static By OnPathwayIcon = By.xpath("//span[contains(text(), '1')]/../span[contains(@class, 'on-pathway')]");
    public static By drugList = By.xpath("//div[@class='ocm-regimens-view-wrapper ng-scope']/div");
    public static By expandRegimen = xpath("//span[@class='ocm-action tk-panl-helper cux-icon-caret_right']");
    public static By pharmacyBenefitsNotificationMixedRegimen=By.xpath ("(//h2[text()='Pharmacy Benefits Notification'])[1]");
    public static By pharmacyBenefitsNotificationOk = By.xpath("//*[@id='mixedRegimenMessageDiv']/following-sibling::div/input[@value= 'OK']");
    public static By pharmacyBenefitNotification=By.xpath ("(//h2[text()='Pharmacy Benefits Notification'])[1]");
    public static By pharmacyBenefitNotificationClose = By.xpath("//*[@id='oralIncludeMessageDiv']/following-sibling::div/input");

    public static final String mixedRegimenNoPharmacyBenefitPopupModelFormXpath = "//form[@name='mixedRegimenNoPharmacyBenefitPopupModelForm']";
    public static final String mixedRegimenNoPharmacyBenefitPopupModelFormOkButtonXpath = mixedRegimenNoPharmacyBenefitPopupModelFormXpath + "//input[@value='OK']";
    public static final String mixedRegimenNoPharmacyBenefitPopupModelFormCancelButtonXpath = mixedRegimenNoPharmacyBenefitPopupModelFormXpath + "//input[@value='Cancel']";
    public static final String selectedRegimenNotPartofPathwayProgramXpathexpr = "//*[@id='offPathwayRegimenReason-hscAttributeValue-0']";
    public static final String offPathwayRegimenReasonPopupModelFormContinueXpath = "//form[@name='offPathwayRegimenReasonPopupModelForm']"+"//input[@value='Continue']";
    public static final String offPathwayRegimenReasonPopupModelFormXpath = "//form[@name='offPathwayRegimenReasonPopupModelForm']";
    public static final String offPathwayRegimenReasonPopupModelFormCancelXpath = "//form[@name='offPathwayRegimenReasonPopupModelForm']"+"//input[@value='Cancel']";
    public static final String customEpaFinalizePopupModelFormXpath = "//form[@name='customEpaFinalizePopupModelForm']";
    public static final String customEpaFinalizePopupModelFormFinalizeButtonXpath = customEpaFinalizePopupModelFormXpath + "//input[@value='Finalize']";
    public static final String customEpaFinalizePopupModelFormCancelButtonXpath = customEpaFinalizePopupModelFormXpath + "//input[@value='Cancel']";

    public static By errorMessageRegimenReasonPopup = By.xpath("//span[contains(@id,'popupGlobalMessages')]/span");

    public static By continueOnSelectedRegimenNotPartOfPathwayProgram = By.xpath("//*[@id='offPathwayRegimenReasonPopupModelID']/div[2]/div/form/div/div[2]/input[1]");
    public static final By reasonforchoosingregimen = By.xpath("//*[@id='offPathwayRegimenReason-hscAttributeValue-0']");

    public static By expandAll = By.xpath("//a[contains(text(),'Expand All')]");
    public static By drugDosagePopup = By.xpath("//h2[text()='Recommended Dosage']");
    public static final String drugDosagePopupFormXpath = "//form[@name='drugDosageRoundingPopupModelForm']";
    public static By acceptDrugDosagePopupFormXpath = By.xpath("//*[@id='acceptRounding']");
    public static By rejectDrugDosagePopupFormXpath = By.xpath("//*[@id='notAcceptRounding']");
    public static final By customRegimenRoundedDosagePopup = By.xpath("//div[@id='drug-dosage-rounding-warning']");
    public static final String confirmRoundedDosage = drugDosagePopupFormXpath + "//input[@value='Confirm']";
    public static final String cancelRoundedDosage = drugDosagePopupFormXpath + "//input[@value='Cancel']";
    public static By clickContinueButtonOtherOption = By.xpath("//input[@ng-click='ocmRegimensView.showNonPreferredSupportivesPopupModel.closePopup(); ocmRegimensView.showNonPreferredSupportivesFromPopup();']");
    public static By PharmabenefitsNotificationPopupCloseButton = By.xpath("//input[@ng-click='oralDrugNoPharmacyBenefitPopupModel.closePopup();']");

    public static By fileUploadStatus = By.xpath("//*[@ng-if='fileBundle.length']//span[text()='Uploaded']");
    public static final By priorityreviewmessage = By.xpath("//form[@name='urgentRequestProviderPopupModelForm']//div[@class='ng-scope']");
    public static final By priorityreviewokbutton = By.xpath("//form[@name='urgentRequestProviderPopupModelForm']//input[@value='OK']");

    public static By saveDraftButton = By.xpath("//input[@value = 'Save Draft']");
    public static By supportDrugDropDown = By.xpath("//select[@ng-model='ocmRegimensView.highRiskRegimenPopupModel.showSupportiveDrugs']");
    public static By  imageguidedRadiationTherapyCheckbox = By.xpath("//input[@type='checkbox'][@id='Q45377-1']");
    public static By  numberIGRTText = By.xpath("//input[@type='text'][@id='Q45380-0']");
    public static By  specialCodesCheckbox = By.xpath("//input[@type='checkbox'][@id='Q45378-1']");


    //Locators--------


    public RegimensPage(WebDriver webDriver) {
        this.driver = webDriver;
        utils = BaseCucumber.utils;
        log = Logger.getLogger(this.getClass().getName());
    }
;
    //Methods

    /**
     * Select Urgent Request check box
     */
    public void selectUrgentRequestCheckbox() {
        TestUtils.wait(2);
        if (!driver.findElement(operationsUrgentRequestCheckbox).isSelected())
            TestUtils.click(driver, operationsUrgentRequestCheckbox);

    }

    /**
     * Selecting regimen on RegimensPage
     *
     * @return RegimensPage
     */
    public void selectRegimen() {
        TestUtils.wait(2);
        TestUtils.click(driver, autoApprovedregimen);
    }

    /**
     * Selecting regimen by index on RegimensPage
     *
     * @param rgIndex
     */
    public void selectRegimen(int rgIndex) {
        TestUtils.wait(2);
        TestUtils.click(driver, By.xpath("(//*[@class='selection-wrapper']//span)[" + rgIndex + "]"));
    }

    /**
     * Selecting regimen by label on RegimensPage
     *
     * @param rgLabel
     */
    public void selectRegimen(String rgLabel) {
         TestUtils.wait(3);
        By regimenByText = xpath("//span[text()='" + rgLabel + "']/../span[contains(@class, 'selection-wrapper')]");
        TestUtils.waitElementVisible(driver, regimenByText);
        TestUtils.click(driver, regimenByText);
    }

    /**
     * Clicking on continue button on RegimensPage
     */
    public void clickContinueButton() {
        TestUtils.wait(2);
        TestUtils.click(driver, continueButton);
        TestUtils.wait(2);
    }

    /**
     * Clicking on Supportive Review Required Popup continue button on RegimensPage
     */
    public void continueFromSupportiveReviewRequiredPopup() {
        TestUtils.click(driver, continueFromSupportiveReviewRequiredPopup);
    }

    /**
     * Verifying the Header Text on RegimensPage
     *
     * @param expectedHeader
     */
    public void verifyHeaderText(String expectedHeader) {
        String actualHeader = TestUtils.text(driver, header);
        log.info("Checking page header. Header is: " + actualHeader);
        Assert.assertTrue("Header is not matching with " + expectedHeader + ". Currect header is: " + actualHeader,
                expectedHeader.equals(actualHeader));

    }


    /**
     * Clicking Show Other Options Requiring Clinical Review hyperlink
     */
    public void showOtherOptionsRequiringClinicalReviewhyperlink() {
        log.warn("Clicking Show Other Options Requiring Clinical Review hyperlink");
        By showOtherOptions = By.xpath("//a[text()='Show Other Options (Requiring Clinical Review)']");
        TestUtils.waitElementVisible(driver, showOtherOptions);
        TestUtils.click(driver, showOtherOptions);


    }

    /**
     * Verifying the popup header RegimensPage
     *
     * @param expectedHeader
     */
    public void verifypopup(String expectedHeader) {
        String actualPopupHeader = TestUtils.text(driver, By.xpath("//*[@id='ocmRegimensView-showNonPreferredSupportivesPopupModelID']//*[text()='Other Options (Not Auto-Approvable)']"));
        log.info("Checking popup header. Header is: " + actualPopupHeader);
        Assert.assertTrue("Header is not matching with " + expectedHeader + ". Currect header is: " + expectedHeader,
                expectedHeader.equals(actualPopupHeader.trim()));
        TestUtils.wait(3);

    }

    /**
     * Clicking on continue button on Regimens popup
     */
    public void clickContinueButtononPopup() {
        TestUtils.click(driver, popupContinueButton);
    }

    /**
     * Verifying the popup header RegimensPage
     *
     * @param expectedHeader
     */
    public void verifypopupMessageOtherOptionsRequiringClinicalReview(String expectedHeader) {
        String actualPopupMessage = TestUtils.text(driver, By.xpath("//div[@id='showNonPreferredSupportivesPopupTextDiv']//p"));
        log.info("Checking popup header. Header is: " + actualPopupMessage);
        Assert.assertTrue("Header is not matching with " + expectedHeader + ". Currect header is: " + expectedHeader,
                expectedHeader.equals(actualPopupMessage.trim()));
        TestUtils.wait(3);

    }

    /**
     * Clicking Hide Other Options Requiring Clinical Review hyperlink
     */
    public void hideOtherOptionsRequiringClinicalReviewhyperlink() {
        log.warn("Clicking Hide Other Options Requiring Clinical Review hyperlink");
        TestUtils.wait(3);
        TestUtils.click(driver, By.xpath("//a[text()='Hide Other Options (Requiring Clinical Review)']"));
        TestUtils.wait(3);


    }

    /**
     * selecting first choice for available growth factors for auto approval on regimens page
     */
    public void selectingFirstChoiceforAvailableGrowthFactorsforAutoApproval() {
        log.warn("selecting first choice for available growth factors for auto approval on regimens page");
        TestUtils.wait(2);
        TestUtils.click(driver, choicefromAvailableGrowthFactorsforAutoApproval);
    }

    /**
     * selecting first choice for available growth factors for auto approval on regimens page
     */
    public void otherOptionRequiringClinicalReview() {
        log.warn("selecting first choice for available growth factors for auto approval on regimens page");
        TestUtils.wait(2);
        TestUtils.click(driver, otherOptionsRequiringClinicalReview);
        TestUtils.wait(3);

    }

    /**
     * selecting selectingDrugChoice regimens page
     */
    public void selectingDrugChoice(String drugChoice) {
        log.warn("selecting choice for available growth factors for auto approval on regimens page");
        TestUtils.wait(2);
        By selectingDrugChoice = xpath("//*[contains(text(),'" + drugChoice + "')]/..//*[@role='radio']");
        TestUtils.click(driver, selectingDrugChoice);
        TestUtils.wait(3);

    }

    /**
     * Verifying the popup header RegimensPage
     *
     * @param expectedHeader
     */
    public void verifySupportiveDrugReviewRequiredpopupMessage(String expectedHeader) {
        String actualPopupMessage = driver.findElement(By.xpath("//*[@id='showNonPreferredSupportivesPopupTextDiv']")).getAttribute("innerHTML");
        actualPopupMessage = actualPopupMessage.replace("<p class=\"ng-binding\">", "");
        actualPopupMessage = actualPopupMessage.replace("<p id=\"continuePopupText\">", "");
        actualPopupMessage = actualPopupMessage.replace("\n", "");
        actualPopupMessage = actualPopupMessage.replace("</p>", "");
        String finalActualPopupMessage = actualPopupMessage.trim();
        String finalExpectedPopupMessage = expectedHeader.trim();
        log.info("Checking popup message. Message is: " + actualPopupMessage);
        Assert.assertTrue("", finalExpectedPopupMessage.equals(finalActualPopupMessage));

    }

    /**
     * Verifying the popup header RegimensPage
     *
     * @param expectedHeader
     * @return RegimensPage
     */
    public void verifypopupSupportiveDrugReviewRequired(String expectedHeader) {
        String actualPopupHeader = TestUtils.text(driver, By.xpath("//*[text()='Supportive Drug Review Required']"));
        log.info("Checking popup header. Header is: " + actualPopupHeader);
        Assert.assertTrue("Header is not matching with " + expectedHeader + ". Currect header is: " + expectedHeader,
                expectedHeader.equals(actualPopupHeader.trim()));

    }


    /**
     * Clicking on CustomRegimenLink on RegimensPage
     */

    public void clickCustomRegimenLink() {
        TestUtils.click(driver, createCustomRegimenLink);
        TestUtils.wait(1);
    }

    /**
     * Entering drugname on RegimensPage
     *
     * @param drugName
     */

    public void enterTextIndrugNameTextBox(String drugName) {
        TestUtils.input(driver, drugNameTextBox, drugName);
        By drugNameDropDown = By.xpath("//a[contains(@title,'" + drugName + "')]");
        TestUtils.wait(1);
        TestUtils.click(driver, drugNameDropDown);

    }

    /**
     * Entering drug route on RegimensPage
     *
     * @param drugroute
     */
    public void selectdrugrouteinregimen(String drugroute) {
        TestUtils.select(driver, drugrouteregimen, drugroute);
    }

    public void selectTechniqueCodeType(String codetype) {
        TestUtils.select(driver, techniquecodetype, codetype);
    }

    /**
     * Entering Units on CustomRequestPage
     *
     * @param units
     */
    public void enterTextInUnitsTextBox(String units) {
        TestUtils.input(driver, fractionunits, units);
    }

    /**
     * Entering dosage on RegimensPage
     *
     * @param dosage
     */
    public void enterTextInDosageTextBox(String dosage) {
        TestUtils.input(driver, dosageTextBox, dosage);
    }

    /**
     * Entering daysofAdministration on RegimensPage
     *
     * @param daysofAdministration
     */
    public void enterTextInDaysofAdministrationTextBox(String daysofAdministration) {
        TestUtils.input(driver, daysofAdministrationTextBox, daysofAdministration);
    }

    /**
     * Entering lengthofCycles on RegimensPage
     *
     * @param lengthofCycles
     */
    public void enterTextInLengthofCyclesTextBox(String lengthofCycles) {
        TestUtils.input(driver, lengthofCyclesTextBox, lengthofCycles);
    }

    /**
     * Clicking on Add button on Custom Regimen Page
     */
    public void clickAddButton() {
        boolean success = TestUtils.clickUntil(driver, addButton, new ICondition() {
            @Override
            public boolean evaluate() throws Exception {
                return !TestUtils.isElementVisible(driver, addButton);
            }
        });
        if (!success) {
            clickCancelLink();
            throw new RuntimeException("Unable to add drug.");
        }
    }

    /**
     * Clicking on Ok button on Supportive Care Drug
     */
    public void clickOkButtonOnSupportiveCareDrug() {
        TestUtils.click(driver, okButton);
    }

    /**
     * Entering regimenJustification on RegimensPage
     *
     * @param regimenJustification
     */
    public void enterRegimenJustification(String regimenJustification) {
        TestUtils.wait(3);
        if (!StringUtils.isEmpty(regimenJustification)) {
            regimenJustification = StringUtils.readOrReturn(regimenJustification);
            TestUtils.wait(3);
            TestUtils.input(driver, regimenJustificationTextBox, regimenJustification);
        }
    }

    /**
     * Clicking on Continue button on CustomRegimen
     */
    public void clickContinueButtonInCustomRegimenPage() {

        log.warn("Clicking Continue Button in custom regimen ");
        TestUtils.waitElement(driver, customContinueButton);
        TestUtils.onMouseHover(driver, customContinueButton);
        TestUtils.wait(5);
        TestUtils.highlightElement(driver, customContinueButton);
        driver.findElement(customContinueButton).click();
        TestUtils.wait(10);
    }

    /**
     * Selecting a value from Urgent Request outcome dropdown on CustomRegimen
     */
    public void selectsValueFromUrgentRequestOutcomeDropdown(String urgentRequestOutcomeValue) {
        TestUtils.select(driver, urgentRequestOutcome, urgentRequestOutcomeValue);
    }

    /**
     * Verifying drug name on Add Drug window
     *
     * @param drugName
     */
    public void verifiesTextIndrugNameTextBox(String drugName) {
        log.warn("Verifying text in drug name ");
        Assert.assertEquals("Populated drug name is incorrect", drugName, TestUtils.text(driver, drugNameValue)
        );
    }

    /**
     * Verifying drug code on Add Drug window
     *
     * @param drugCode
     */
    public void verifiesTextIndrugCodeTextBox(String drugCode) {
        log.warn("Verifying drug code on Add Drug window");
        Assert.assertEquals("Populated drug code is incorrect", drugCode, TestUtils.text(driver, drugCodeValue)
        );

    }

    /**
     * Verifying drug Route on Add Drug window
     *
     * @param drugroute
     */
    public void verifiesdrugrouteinregimen(String drugroute) {
        log.warn("Verifying drugRoute on Add Drug window");
        Assert.assertEquals("Populated drug route is incorrect", drugroute, TestUtils.text(driver, drugrouteValue));
    }

    /**
     * Verifying dosage on Add Drug window
     *
     * @param dosage
     */
    public void verifiesTextInDosageTextBox(String dosage) {
        log.warn("Verifying dosage on Add Drug window");
        Assert.assertEquals("Populated dosage is incorrect", dosage, TestUtils.text(driver, dosageTextValue));
    }

    /**
     * Verifying daysofAdministration on Add Drug window
     *
     * @param daysofAdministration
     */
    public void verifiesTextInDaysofAdministrationTextBox(String daysofAdministration) {
        log.warn("Verifying daysofAdministration on Add Drug window");
        Assert.assertEquals("Populated daysofAdministration is incorrect", daysofAdministration, TestUtils.text(driver, daysofAdministrationValue));
    }

    /**
     * Verifying lengthofCycles on Add Drug window
     *
     * @param lengthofCycles
     */
    public void verifiesTextInLengthofCyclesTextBox(String lengthofCycles) {
        log.warn("Verifying lengthofCycles on Add Drug window");
        Assert.assertEquals("Populated lengthofCyclesTextBox is incorrect", lengthofCycles, TestUtils.text(driver, lengthofCyclesValue));

    }

    /**
     * Verifying Drug Name on Add Drug window
     *
     * @param expectedDrugName
     */
    public void verifyDrugName(String expectedDrugName) {
        log.warn("verifying Drug Name on Add Drug window ");
        String actualChangingTreatment = TestUtils.text(driver, drugName);
        Assert.assertTrue("Drug Name does not match with given drug .", actualChangingTreatment.equals(expectedDrugName));

    }

    /**
     * Verifying Regimen popup error message pop up is displayed and verifies its text on Medical Request Page
     */
    public void verifiesRegimensErrorMessage(String reason) {
        log.warn("Verifying Regimen popup error message pop up is displayed and verifies its text");
        String clinDocErrMsg = "Valid Clinical Documentation must be attached to continue.";
        String chemoClinDocErrMsg = "Valid Clinical Documentation must be attached to continue. If you selected an NCCN recommended regimen on the prior screen, include \"NCCN recommended\" in the Regimen Justification box.";
        String enterReasonErrMsg = "Either a Request Justification must be entered or valid Clinical Documentation attached to continue.";
        String addDrugMsg = "Please add a radiopharmaceutical drug before continuing.";
        String azedraErrMsg = "For Azedra, please include both dosimetric and therapeutic dosages within this request.";

        if (reason.equals("no")){
            Assert.assertFalse("Regimen error popup message is displayed", TestUtils.isElementVisible(driver, regimenSelectErrorMsg));
        }else {
            Assert.assertTrue("Regimen error popup message is not displayed", TestUtils.isElementVisible(driver, regimenSelectErrorMsg));
            if (reason.equals("clinDocErrMsg"))
                Assert.assertEquals("Regimen error message is incorrect", clinDocErrMsg, TestUtils.text(driver, regimenSelectErrMsgDesc)
                );
            if (reason.equals("chemoClinDocErrMsg"))
                Assert.assertEquals("Regimen error message is incorrect", chemoClinDocErrMsg, TestUtils.text(driver, regimenSelectErrMsgDesc)
                );
            else if (reason.equals("enterReasonErrMsg"))
                Assert.assertEquals("Regimen error message is incorrect", enterReasonErrMsg, TestUtils.text(driver, regimenSelectErrMsgDesc)
                );
            else if (reason.equals("enterDrugErrMsg"))
                Assert.assertEquals("Add drug error message is incorrect", addDrugMsg, TestUtils.text(driver, regimenSelectErrMsgDesc)
                );
            else if (reason.equals("azedraErrMsg"))
                Assert.assertEquals("azedra error message is incorrect", azedraErrMsg, TestUtils.text(driver, regimenSelectErrMsgDesc)
                );
        }
    }

    /**
     * Verifying add drugs message is displayed When no drug is added on Medical Request Page
     */
    public void verifiesAddRadioPharmaDrugsMessage() {
        log.warn("Verifying add drugs message is displayed When no drug is added");
        Assert.assertTrue("Add drug message is not displayed", TestUtils.isElementVisible(driver, addRadioDrugMsg));
        Assert.assertEquals("Add drug message is incorrect", "Please add a radiopharmaceutical drug(s)", TestUtils.text(driver, addRadioDrugMsg)
        );

    }

    /**
     * Clicking on ok button on supportive care drug popup on Medical Request Page
     */
    public void clickOkButtonOnSupprtiveCareDrug() {
        log.warn("Clicking on ok button on supportive care drug popup");
        TestUtils.click(driver, okBtnOnSupportiveCareDrugPopup);
    }

    public boolean isPopupOralDrug() {
        log.warn("Checking oral drug popup window");
        List<WebElement> els = driver.findElements(oralDrugIncludeRegimenPopupModelForm);
        return els.size() > 0 && els.get(0).isDisplayed();
    }

    /**
     * Clicking on oral drug OK button
     */
    public void clickOralDrugOK() {
        log.warn("Clicking oral drug OK button");
        TestUtils.wait(4);
        TestUtils.click(driver, oralDrugIncludeRegimenPopupModelFormOKButton);
        TestUtils.wait(2);
    }

    /**
     * Clicking on oral drug OK button
     */
    public void clickChemoRegimenQuestionYes() {
        log.warn("Click Chemo Regimen Question Yes");
        TestUtils.wait(3);
        TestUtils.click(driver, chemoRegimenQuestion);
        TestUtils.wait(2);
    }

    /**
     * Clicking on Add Drug Link on Custom Regimen page for chemo authorization
     */
    public void clickAddDrugLink() {
        log.warn("Clicking add drug link");
        TestUtils.wait(2);
        if (!driver.findElement(By.xpath("//*[@id='regimenDrugsTable-editPopupID']//div[@class='tk-lbox-content-wrapper']")).isDisplayed()) {
            TestUtils.click(driver, addDrugLink);
        } else {
            log.warn("Add Pop up Modal was populated as expected for supportive flow");
        }
    }

    /**
     * Clicking on Add Drug Link on Custom Regimen page for supportive authorization
     */
    public void clickAddDrugLinkForSupportive() {
        log.warn("Clicking add supportive drug link");
        TestUtils.wait(3);
        if (!driver.findElement(By.xpath("//*[@id='regimenDrugsTable-editPopupID']//div[@class='tk-lbox-content-wrapper']")).isDisplayed()) {
            TestUtils.click(driver, addDrugLinkForSupportive);
        } else {
            log.warn("Add Pop up Modal was populated as expected for supportive flow");
        }
    }

    /**
     * Enter Drug Code into add drug text box
     */
    public void enterTextInDrugCodeTextBox(String drugCode) {
        TestUtils.input(driver, procedureCodeTypeahead, drugCode);
    }

    /**
     * click Urgent Request
     */
    public void clickUrgentRequestCheckbox() {
        log.warn("Clicking Urgent Request Checkbox");
        TestUtils.click(driver, urgentRequestCheckbox);
    }

    /**
     * select urgent outcome
     */
    public void selectUrgentOutcome(String urgentOutcome) {
        log.warn("Entering Urgent Request Outcome");
        Assert.assertTrue(new WaitUntil("", new ICondition() {
            @Override
            public boolean evaluate() throws Exception {
                return TestUtils.input(driver, urgentRequestOutcome, urgentOutcome);
            }
        }).execute());
    }

    /**
     * select drug name for supportive request
     */
    public void selectDrugNameForSupportiveRequest(String drugName) {
        log.warn("Select drug name for supportive request");
        TestUtils.select(this.driver, drugNameDropdownListForSupportiveRequest, drugName);
    }

    /**
     * select cancel link in add drug modal
     */
    public void clickCancelLink() {
        log.warn("Click Cancel Link");
        TestUtils.click(this.driver, cancelLink);
    }

    /**
     * Verifying Dosage value is empty in add drug modal
     */
    public void verifyTextInDosageTextBox() {
        log.warn("Verifying Dosage value is empty");
        Assert.assertEquals("Dosage value is not empty", "", TestUtils.text(driver, dosageTextBox));
    }

    /**
     * Verifying DaysofAdministration value is empty in add drug modal
     */
    public void verifyTextInDaysofAdministrationTextBox() {
        log.warn("Verifying DaysofAdministration value is empty");
        Assert.assertEquals("DaysofAdministration value is not empty", "", TestUtils.text(driver, daysofAdministrationTextBox));
    }

    /**
     * Verifying LengthofCycles value is empty in add drug modal
     */
    public void verifyTextInLengthofCyclesTextBox() {
        log.warn("Verifying LengthofCycles value is empty");
        Assert.assertEquals("LengthofCycles value is not empty", "", TestUtils.text(driver, lengthofCyclesTextBox));
    }

    /*
     * Verifying radio pharma notifcation message in pop up
     *@param popupMessage
     * */
    public void valdiateRadioPharmaDrugNotificationPopup(String popupMessage) {
        log.warn("Checking radio pharma drug notification popup window");
        Assert.assertTrue("RadioPharma Drug Notification Pop Header not displayed", TestUtils.isElementVisible(driver, radioPharmaDrugNotificationHeader));
        Assert.assertEquals("RadioPharma Drug notification message doesn't displayey", popupMessage, TestUtils.text(driver, radioPharmaDrugNotificationPopupMessage));
    }

    /*
     * Clicks on cancel button on rodio pharam notification pop up
     * */

    public void clickCancelButtonOnRadioPharmaNotificationDrugPopUp() {
        TestUtils.click(driver, radioPharmaDrugNotificationPopupCancelButton);
    }

    /*
     * Clicks on continue button on rodio pharam notification pop up
     * */

    public void clickContinueButtonOnRadioPharmaNotificationDrugPopUp() {
        TestUtils.click(driver, radioPharmaDrugNotificationPopupContinueButton);
    }

    /**
     * Selecting a value from Dosage unit dropdown on CustomRegimen
     */
    public void selectsValueFromDosageUnitDropdown(String unit) {
        TestUtils.select(driver, specialtyPharmaDosageDropDown, unit);
    }

    /**
     * Selecting a value from frequency of administration dropdown on CustomRegimen
     */
    public void selectsValueFromFrequencyOfAdministration(String frequencyOfAdministration) {
        TestUtils.select(driver, specialtyPharmaDosageFrequencyOfAdministration, frequencyOfAdministration);
    }

    /**
     * Clicking on Add button on Custom Regimen Page
     */
    public void specialtyPharmaclickAddButton() {
        TestUtils.click(driver, specialtyPharmaAddDrugAddButton);
        TestUtils.wait(2);
    }

    /**
     * Clicking on Add drug link Regimen Page
     */
    public void specialtyPharmaAddDrugLink() {
        TestUtils.click(driver, addDrugLink);
        TestUtils.wait(2);
    }

    /**
     * Add Clinical Documentation
     *
     * @param fileName
     * @return
     */
    public boolean addClinicalDocumentation(String fileName) {
        log.warn("addClinicalDocumentation will upload file with name " + fileName);
        if (StringUtils.isEmpty(fileName)) {
            return true;
        } else {
            return TestUtils.uploadFile(driver, "btnFileSelectorAlias", fileName, fileUploadStatus);


        }

    }


    /**
     * Entering drug dosage on add drug popup
     */
    public void enteringDrugDosage(String drugDose) {
        TestUtils.input(driver, specialtyPharmaDosageNumberField, drugDose);

    }

    /**
     * Verifying supportive drug pop up
     */
    public void verifySupportiveDrugPopUp() {
        log.warn("Verifying header text of supportive drug pop up");
        By popupheader = By.xpath("//h2[text()='Supportive Drug']");
        TestUtils.waitElementVisible(driver, popupheader);
        Assert.assertTrue("Header Text is incorrect", TestUtils.text(driver, popupheader).equalsIgnoreCase("Supportive Drug"));
    }

    /**
     * User Select option and click continue on supportive drug pop up
     */
    public void selectOptionAndClickContinueButton(String value) {
        log.warn("Select Dropdown and click continue");
        By popupdropdown = By.xpath("//div[@id='highRiskContent']//child::td/select");
        TestUtils.select(driver, popupdropdown, value);
        By continuebutton = By.xpath("//input[@ng-click='addHighRiskSupportiveDrug()']");
        TestUtils.click(driver, continuebutton);
    }

    /**
     * Selecting regimen on RegimensPage
     *
     * @return RegimensPage
     */
    public void selectAutoapprovedRegimen(String number) {
        TestUtils.wait(2);
        int result = Integer.parseInt(number);
        System.out.println(result);
        By autoApprovedregimen1 = xpath("(//*[@class='selection-wrapper']//span)[" + result + "]");
        TestUtils.click(driver, autoApprovedregimen1);
        TestUtils.highlightElement(driver, autoApprovedregimen1);
    }
      /*
     Verify the transparency Metrics is not visible for Breast Cancer on Regimen Page
     */

    public void transparencyMetricsNotVisible() {
        log.warn("Checking that Transparency Metrics is not present on Regimen Page");
        TestUtils.wait(3);

        List<WebElement> els = driver.findElements(drugList);
        for (int i = 4; i < els.size(); i++) {
            By elementTxt = By.xpath("//div[@class='ocm-regimens-view-wrapper ng-scope']/div[" + i + "]/div[1]//span[contains(@class, 'metrics')]");

            boolean present = false;

            //Checking
            if (TestUtils.isElementPresent(driver, elementTxt)) {
                TestUtils.highlightElement(driver, elementTxt);
                present = true;
            }

            Assert.assertFalse("Transparency metrics is visible for Breast Cancer. ", present);
        }
    }


    /**
     * Verifying the popup text for Off-Pathway Regimen
     */
    public void verifyOffPathwayRegimenpopupText(String arg1) {

        String actualPopupMessage = driver.findElement(By.cssSelector("div[id='offPathwayRegimenWarningPopupTextDiv']")).getText();
        System.out.println(actualPopupMessage);
        actualPopupMessage = actualPopupMessage.replace("\n", "");
        actualPopupMessage = actualPopupMessage.replace("&nbsp;", "");

        String finalActualPopupMessage = actualPopupMessage.trim();
        String text = "The regimen you have selected is NCCN recommended for your patient’s disease and stage; however, it is not a UHC Cancer Therapy Pathway regimen.  UHC Cancer Therapy Pathways include regimen(s) selected based on their efficacy, toxicity and cost.To learn more about the regimens included in the UHC Cancer Therapy Pathway program, visit uhcprovider.com.  If your patient is on a UnitedHealthcare Commercial plan, you may be eligible for rewards when selecting a UHC Cancer Therapy Pathway.Would you like to continue using this option?";
        text = text.replace("\n", " ");
        String finalExpectedPopupMessage = text.trim();
        log.info("Checking popup message. Message is: " + actualPopupMessage);
        Assert.assertTrue("", finalExpectedPopupMessage.equalsIgnoreCase(finalActualPopupMessage));
        String Opr = "//h2[contains(text(),'" + arg1 + "')]";
        Assert.assertEquals(driver.findElement(By.xpath(Opr)).getText(), "Off-Pathway Regimen");

    }


    /**
     * Verifying the popup text for Off-Pathway Regimen
     */
    public void verifyRegimenpopupdropdown() {

        String actualPopupMessage = driver.findElement(By.xpath("//form[@name='offPathwayReasonForm']/div[1]")).getText();
        System.out.println(actualPopupMessage);
        actualPopupMessage = actualPopupMessage.replace("\n", "");
        actualPopupMessage = actualPopupMessage.replace("&nbsp;", "");

        String finalActualPopupMessage = actualPopupMessage.trim();
        // New message
        String text = "The regimen you have selected is not part of the Cancer Therapy Pathway Program. In order to proceed, please provide the following information:";
        //Old Message
//        String text = "The regimen you have selected is not part of the UHC Cancer Therapy Pathway Program. Would you like to continue using this option?If you are asked for a Regimen Justification, enter \"NCCN recommended\" in the box provided prior to clicking submit.";
        text = text.replace("\n", " ");
        String finalExpectedPopupMessage = text.trim();
        log.warn("Checking popup message. Message is: " + finalActualPopupMessage);
        log.warn("Checking popup message. Message is: " + finalExpectedPopupMessage);
        Assert.assertTrue("the text donot match", finalExpectedPopupMessage.equalsIgnoreCase(finalActualPopupMessage));
    }


    /**
     * verifying On-Pathway Icon on the Regimen Page
     */
    public void verifyOnPathwayIcon() {
        log.warn("Verifying On-Pathway icon on the Regimen Page");
        TestUtils.waitElementVisible(driver, OnPathwayIcon);
        Assert.assertTrue("on-pathway Icon doesn't exist on Regimen", TestUtils.isElementVisible(driver, OnPathwayIcon));

    }

    /**
     * Entering regimenJustification on RegimensPage
     *
     * @param regimenJustification
     */
    public void sendingRegimenJustification(String regimenJustification) {
        TestUtils.wait(5);
        TestUtils.waitElementVisible(driver,regimenJustificationTextBox,5);
        driver.findElement(regimenJustificationTextBox).sendKeys(regimenJustification);
    }

    /**
     * User should verify that following Available Growth Factors for Auto-Approval values are visible in the regimensPanel in Regimens page
     *
     * @param drugName
     */
    public void isDrugPopulatedOnAvailableGrowthFactorsforAutoApprovalTable(List drugName) {
        log.warn("checking  preferred Drug Populated On Available Growth Factors for AutoApproval Table");
        TestUtils.wait(2);
        List<WebElement> els = driver.findElements(By.xpath("//*[@role='radiogroup']/div[@class='regimen-wrapper html2pdf__page-break_auto ng-scope operations-view']"));
        for (int i = 0; i < els.size(); i++) {
            String actual = els.get(i).getText().replaceAll("^\\d", "").trim();
            String expected = drugName.get(i).toString().trim().replaceAll("^\\d", "");
            if (els.size() > 0 && actual.equals(expected.trim())) {
                Assert.assertTrue("preferred Drug not Populated On Available Growth Factors for AutoApproval Table for the LOB", true);
            } else Assert.fail();

        }
    }

    /**
     * User should verify that in the Other Options (Requiring Clinical Review) table folowing drugs are visible in the regimensPanel in Regimens page
     *
     * @param drugName
     */

    public void isDrugPopulatedOnOtherOptionRequiringClinicalReviewTable(List drugName) {
        log.warn("checking preferred Drug Populated On Other Options Table");
        TestUtils.wait(2);
        List<WebElement> els = driver.findElements(By.xpath("//*[@role='radiogroup']//*[@ng-if='ocmRegimensView.regimensList.length && ocmRegimensView.supportiveCare && ocmRegimensView.showNonPreferredSupportives']"));
        for (int i = 0; i < els.size(); i++) {
            for (int j = 0; j < drugName.size(); j++) {
                String actual = els.get(i).getText().replaceAll("^\\d", "").trim();
                String expected = drugName.get(i).toString().trim().replaceAll("^\\d", "");
                if (els.size() > 0 && actual.trim().equals(expected.trim())) {
                    Assert.assertTrue("Preferred Drug not Populated On Other Options (Requiring Clinical Review) Table", true);
                    break;
                } else Assert.fail("Preferred Drug not Populated On Other Options (Requiring Clinical Review) Table");
            }


        }
    }

    /**
     * User should verify that following Available Growth Factors for Auto-Approval values are not visible in the regimensPanel in Regimens page
     *
     * @param drugName
     */
    public void isDrugNotPopulatedOnAvailableGrowthFactorsforAutoApprovalTable(List drugName) {
        log.warn("checking  preferred Drug Populated On Available Growth Factors for AutoApproval Table");
        TestUtils.wait(2);
        List<WebElement> els = driver.findElements(By.xpath("//*[@role='radiogroup']/div[@class='regimen-wrapper html2pdf__page-break_auto ng-scope operations-view']"));
        for (int i = 0; i < els.size(); i++) {
            String actual = els.get(i).getText().replaceAll("^\\d", "").trim();
            String expected = drugName.get(0).toString().trim().replaceAll("^\\d", "");
            if (els.size() > 0 && actual.equals(expected.trim())) {
                Assert.assertTrue("preferred Drug is Populated On Available Growth Factors for AutoApproval Table for the LOB", false);
            } else Assert.assertTrue(expected + "drug Not Visible on preferred drug table", true);

        }
    }

    /**
     * User should verify that in the Other Options (Requiring Clinical Review) table folowing drug not visible in the regimensPanel in Regimens page
     *
     * @param drugName
     */
    public void isNotDrugPopulatedOnOtherOptionRequiringClinicalReviewTable(List drugName) {
        log.warn("checking preferred Drug Populated On Other Options Table");
        TestUtils.wait(2);
        List<WebElement> els = driver.findElements(By.xpath("//*[@role='radiogroup']//*[@ng-if='ocmRegimensView.regimensList.length && ocmRegimensView.supportiveCare && ocmRegimensView.showNonPreferredSupportives']"));
        for (int i = 0; i < els.size(); i++) {
            for (int j = 0; j < drugName.size(); j++) {
                if (els.size() > 0 && els.get(i).getText().equals(drugName.get(0))) {
                    Assert.assertTrue("Preferred Drug not Populated On Other Options (Requiring Clinical Review) Table", false);
                } else continue;
            }


        }
    }


    public void verifyEPAPopUpMessage(String expectedHeader) {

        String actualPopupHeader = TestUtils.text(driver, By.xpath("//*[text()='EPA Notification']"));
        log.info("Checking popup header. Header is: " + actualPopupHeader);
        Assert.assertTrue("Header is not matching with " + expectedHeader + ". Currect header is: " + expectedHeader,
                expectedHeader.equals(actualPopupHeader.trim()));

    }

    public void verifyPopUpMessageUHC(String expectedHeader) {

        String actualPopupHeader = TestUtils.text(driver, By.xpath("//*[text()='Oral Chemotherapy Drug Notification']"));
        log.info("Checking popup header. Header is: " + actualPopupHeader);
        Assert.assertTrue("Header is not matching with " + expectedHeader + ". Currect header is: " + expectedHeader,
                expectedHeader.equals(actualPopupHeader.trim()));

    }


    /**
     * Expanding Drug in Regimen Page
     */
    public void regimenDrugExpand() {
        TestUtils.click(driver, expandRegimen);
        TestUtils.wait(2);
    }

    public String drugExceptionMessage() {
        return this.driver.findElement(drugExceptionNotificationMessage).getText();
    }

    public boolean selectDrugName(String drugName) {
        WaitUntil waitDrugNameSelect = new WaitUntil("Wait for " + drugNameSelect, 3 * 1000, 1000, 1000, new ICondition() {
            @Override
            public boolean evaluate() throws Exception {
                return TestUtils.isElementVisible(driver, drugNameSelect);
            }
        });
        if (waitDrugNameSelect.execute()) {
            Retry retrySelectDrugName = new Retry("Retry select drug name: " + drugName, 10 * 1000, 1000, 1000) {
                @Override
                protected void tryOnce() throws Exception {
                    TestUtils.input(driver, drugNameSelect, drugName);
                }
            };
            return retrySelectDrugName.execute();
        } else {
            return false;
        }
    }

    /**
     * Verifying the error message when Reason for choosing this regimen drop down is not selected
     */

    public void verifyErrorMessagewhenReasonNotSelected(String expectedError) {
        TestUtils.wait(4);
        log.warn("Verifying \"Review the form and correct the highlighted fields\" error displayed when Reason for choosing this regimen drop down is not selected");
        TestUtils.waitElement(driver, errorMessageRegimenReasonPopup);
        TestUtils.highlightElement(driver, errorMessageRegimenReasonPopup);
//        String expectedError = "Review the form and correct the highlighted fields";
        String actualError=this.driver.findElement(errorMessageRegimenReasonPopup).getText();
        Assert.assertEquals("Duplicate type, please update your variable Type value",expectedError,actualError);
    }


    /**
     * Clicking Continue on
     *
     */
    public void ContinueRegimenReasonPopUp() {
TestUtils.waitElementVisible(driver,continueOnSelectedRegimenNotPartOfPathwayProgram);
TestUtils.click(driver, continueOnSelectedRegimenNotPartOfPathwayProgram);
    }

    /**
     * Fill reason for choosing this regimen
     *
     */
    public void fillreasonforchoosingthisregimendropdown(String regimenreason) {
        TestUtils.wait(3);
        TestUtils.select(driver, reasonforchoosingregimen, regimenreason);
    }

    public void OkPharmacyBenefitNotification() {
        TestUtils.wait(3);
        TestUtils.click(driver, pharmacyBenefitsNotificationOk);
    }
    public void closePharmacyBenefitNotification() {
        TestUtils.wait(3);
        TestUtils.click(driver, pharmacyBenefitNotificationClose);
    }

    /**
     * Click on Expand All link on Regimens Page to open all the regimens
     */
    public void regimensExpandAll() {
        log.warn("Clicks on Expand All on Regimens page");
        TestUtils.waitElement(driver, expandAll);
        TestUtils.highlightElement(driver, expandAll);
        driver.findElement(expandAll).click();
    }

    public void verifyDrugExceptionNotification(){

        String expectedMessage = "This regimen contains a drug that cannot be auto-approved. Selecting Continue will allow you to complete your request using a custom regimen.";
        By popupXpath = By.xpath("//h2[text()='Drug Exception Notification']");
        By popupMessageXpath=By.xpath("//*[@id='drugExceptionMessageDiv']/p");
        String actualMessage =TestUtils.text(driver,popupMessageXpath);
        Assert.assertTrue(TestUtils.isElementVisible(driver,popupXpath));
        Assert.assertEquals("Message displayed correctly",expectedMessage,actualMessage);
    }

    public void clickDrugExceptionContinueButton(){
        By continueBtnXpath = By.xpath("//div[@id='drugExceptionMessageDiv']//following-sibling::div//input[@value='Continue']");
        TestUtils.isElementVisible(driver,continueBtnXpath);
        TestUtils.wait(3);
        TestUtils.click(driver,continueBtnXpath);
    }


    /**
     * Verifying Rounded Dosage pop up
     */
    public void verifyRoundedDosagePopUp() {
        log.warn("Verifying header text of Rounded Dosage pop up");
        By popupheader = By.xpath("//h2[text()='Recommended Dosage']");
        TestUtils.waitElementVisible(driver, popupheader);
        Assert.assertTrue("Header Text is incorrect", TestUtils.text(driver, popupheader).equalsIgnoreCase("Recommended Dosage"));
    }
    /*
     * Clicks on accept radio button on rounded dosage pop up
     * */
    public void acceptRoundedDosage() {
        By popupheader = By.xpath("//h2[text()='Recommended Dosage']");
        TestUtils.waitElementVisible(driver, popupheader);
        TestUtils.click(driver, acceptDrugDosagePopupFormXpath);

    }
    /*
     * Clicks on reject radio button on rounded dosage pop up
     * */
    public void rejectRoundedDosage() {
        By popupheader = By.xpath("//h2[text()='Recommended Dosage']");
        TestUtils.waitElementVisible(driver, popupheader);
        TestUtils.click(driver, rejectDrugDosagePopupFormXpath);
    }

    /*
     * Clicks on confirm button on rounded dosage pop up
     * */

    public void clickConfirmButtonOnRoundedDosagePopUp() {
        By popupheader = By.xpath("//h2[text()='Recommended Dosage']");
        TestUtils.waitElementVisible(driver, popupheader);
        By confirmButton = By.xpath(RegimensPage.confirmRoundedDosage);
        TestUtils.click(driver, confirmButton);
        TestUtils.wait(3);
    }
    /**
     * Clicking on continue button on RegimensPage
     */
    public void clickContinueButtonOtherOption() {
        TestUtils.wait(2);
        TestUtils.click(driver, clickContinueButtonOtherOption);
        TestUtils.wait(2);
    }
    /*
     * Clicks on close button on pharmacy notification pop up
     * */

    public void clickCloseButtonOnPharmaNotificationPopUp() {
        TestUtils.wait(3);
        TestUtils.click(driver, PharmabenefitsNotificationPopupCloseButton);
        TestUtils.wait(3);
    }

    public void clickYesOnRecommendedDosageScreen() {
        By RecommendedDosageScreenYes = By.xpath("//input[@data-id='CreateAuth.Regimens.DosageAction.AcceptDosage--radioButton']");
        By ConfirmButton = By.xpath("//input[@data-id='CreateAuth.Regimens.DosagePopup--ConfirmButton']");
        TestUtils.waitElementVisible(driver, RecommendedDosageScreenYes);
        TestUtils.click(driver, RecommendedDosageScreenYes);
        TestUtils.click(driver, ConfirmButton);
    }

    /**
     * Validating ProviderPriorityReviewRequest Next Steps and click OK
     *
     * @param expecMessage
     */
    public void PriorityReviewNextStep(String expecMessage) {
        TestUtils.wait(2);
        TestUtils.highlightElement(driver, priorityreviewmessage);
        TestUtils.click(driver,priorityreviewokbutton);
    }
    public void clickOnSaveAsDraftButton() {
        TestUtils.click(driver, saveDraftButton);
    }

    public void userSelectsTheAntimaticAndGrowthDrugRadiobttn()
    {
        TestUtils.wait(2);
        TestUtils.click(driver,antemeticDrugRadioButton);
        TestUtils.wait(2);
        TestUtils.click(driver,growthDrugRadioButton);
    }
    public void userSelectsFromThedropdown(String dropdown)
    {
        TestUtils.wait(3);
        TestUtils.isElementPresent(driver,supportDrugDropDown);
        TestUtils.selectByVisibleText(driver,supportDrugDropDown,dropdown);
    }
    public void userSelectsTheCheckboxesOnTheAdditionalServicepage()
    {
        TestUtils.wait(3);
        TestUtils.isElementPresent(driver,imageguidedRadiationTherapyCheckbox);
        TestUtils.click(driver,imageguidedRadiationTherapyCheckbox);
        TestUtils.wait(3);
        TestUtils.input(driver,numberIGRTText,"12");
        TestUtils.wait(3);
        TestUtils.click(driver,specialCodesCheckbox);
    }


}