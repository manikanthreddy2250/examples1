package atdd.test.pageobjects.authorization;

import atdd.common.ICondition;
import atdd.common.WaitUntil;
import atdd.test.shared.BaseCucumber;
import atdd.test.shared.Globals;
import atdd.utils.ExcelLib;
import atdd.utils.MBM;
import atdd.utils.StringUtils;
import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.jetbrains.annotations.NotNull;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.util.List;
import java.util.Map;

import static org.openqa.selenium.By.cssSelector;
import static org.openqa.selenium.By.xpath;

public class RequestDetailsPage {

    Logger log;
    private WebDriver driver;
    private TestUtils utils;
    Globals gv;

    //Locators--------
    public static final By heightOfThePatientTextBox = cssSelector("input[ng-model*='hscMeasurementHeight.measurementValueDescription']");
    public static final By weightOfThePatientTextBox = cssSelector("input[ng-model*='hscMeasurementWeight.measurementValueDescription']");
    public static final By patientContactNumberTextBox = cssSelector("input[ng-model*='patientContactNumber']");
    public static final By initialDiagnosisDateTextBox = cssSelector("input[ng-model*='initialDiagnosisDate']");
    public static final By placeofServiceTypeSel = xpath("//select[contains(@id,'placeOfServiceCode-hscAttributeValue')]");
    public static final By placeOfSerDisabled = xpath("//span[@id='requestDetailsPlaOfSerTypeDisabled']");
    public static final By anticipatedTreatmentTextBox = By.xpath("//input[@ng-model='dmeInitialTreatmentDate.hscAttributeValue']|//input[@ng-model='treatmentStartDate.hscAttributeValue']");
    public static final By iCDCode = cssSelector("table[class='panelTable'] input[ng-model*='diagnosisCode']");
    //    public static final By primaryIcd10Code = xpath("//ocm-typeahead[@ng-model='primaryDiagnosis.diagnosisCode']");
    //    public static final By primaryIcd10Code = xpath("//ocm-typeahead[@ng-model='primaryDiagnosis.diagnosisCode']/input");
    public static final By primaryIcd10Code = xpath("//*[@ng-model='primaryDiagnosis.diagnosisCode']/input");
    public static final By primaryCancerDrorpDownList = cssSelector("li[id*='option']>a");
    public static final By primaryCancer = cssSelector("input[ng-model*='primaryCancer']");
    public static final By supportiveCareRequestTypeSel = xpath("//select[contains(@id, 'supportiveCare-hscAttributeValue')]");
    public static final By chemotherapyTrialCancerTypeSel = xpath("//select[contains(@id,'chemoTrialCancer-hscAttributeValue')]");
    public static final By patientdistantmetatasticdisease = xpath("//select[contains(@id,'radOncMetastaticDisease-hscAttributeValue-0')]");
    public static final By primaryorsecondarymetatasticsite = xpath("//select[contains(@id,'radOncTreatmentSite-hscAttributeValue-0')]");
    public static final By changeprimarydiagnoselectionokaybutton = xpath("//form[@name='radOncTreatmentSitePopupModelForm']//input[@value='Okay']");
    public static final By changeprimarydiagnoselectionmessage = xpath("//form[@name='radOncTreatmentSitePopupModelForm']//div[@id='treatmentSiteMessageDiv']");
    public static final By clinicaltrialokaybutton = xpath("//form[@name='chemotherapyClinicalTrialPopupModelForm']//input[@value='OK']");
    public static final By clinicaltrialmessage = xpath("//form[@name='chemotherapyClinicalTrialPopupModelForm']//div[@id='clinicalTrialMessageDiv']");
    public static final By diseaseStatusTypeSel = xpath("//select[contains(@id,'diseaseProgressed-hscAttributeValue')]");
    public static final By changingTreatmentTypeSel = xpath("//select[contains(@id,'initialOrChangeTreatment-hscAttributeValue')]|//select[@ng-model='newOrContinuingTreatment.hscAttributeValue']");
    public static final By continueButton = xpath("(//*[contains(@ng-click,'Continue')] | //*[contains(@ng-click,'continue')])[1]");
    public static final By initialDateofProgression = xpath("//*[contains(@id,'dateOfProgression-hscAttributeValue')]");
    public static final By performanceScaleDropDwn = By.xpath("//select[contains(@id,'performanceScale-hscAttributeValue')]");
    public static final By performanceStatusDropDwn = By.xpath("//select[contains(@id,'performanceStatus-hscAttributeValue')]");
    public static final By anticipatedTreatmentLabel = By.xpath("//label[contains(text(), 'Anticipated Treatment Start Date')]");
    public static final By otherDecription = By.xpath("//*[@id='requestDetailsOtherDescription']");
    public static final By currentMedicine = By.xpath("//select[contains(@id,'radioPharmaLeuprolideAcetate-hscAttributeValue') or contains(@id,'radioPharmaOctreotide-hscAttributeValue')]");
    public static final By radiopharmaceuticalRequest = By.xpath("//select[contains(@id,'radioPharmaRequest-hscAttributeValue')]");
    public static final By drugCategorySelect = By.xpath("//select[@ng-model='supportiveType.hscAttributeValue']");
    public static final By drugTypeSel = By.xpath("//select[@ng-model='supportiveType.hscAttributeValue']");
    public static final By drugTypeDosage = By.xpath("//select[@ng-model='supportiveCareProcedureID.hscAttributeValue']");
    public static final By lineOfTherapySel = By.xpath("//select[contains(@id,'firstLineOfTherapy-hscAttributeValue')]");
    public static final By heightRequiredFlag = By.xpath("//*[contains(@id,'requestDetailsPatHeight')]//*[@title='Required']");
    public static final By clinicalTrialName = By.xpath("textarea[@ng-model*='clinicalTrialName.hscAttributeValue']");
    public static final By clinicalTrialPhase = By.xpath("textarea[@ng-model*='clinicalTrialPhase.hscAttributeValue']");
    public static final By ContinuationofTreatment = By.xpath("//*[@id='newOrContinuingTreatment-hscAttributeValue-0']/option[text()='Continuation of Treatment']");
    public static final By changingTreatmentType = xpath("//select[contains(@id,'initialOrChangeTreatment-hscAttributeValue')]|//select[@ng-model='newOrContinuingTreatment.hscAttributeValue']");
    public static final By takingLeuprolideAcetate = xpath("//*[contains(@id,'radioPharmaLeuprolideAcetate-hscAttributeValue')]");
    public static final By showOtherOptionsLink = xpath("//a[text()='Show Other Options (Requiring Clinical Review)']");
    public static final By availableGrowthFactorsforAutoApproval = xpath("//*[text()='Available Growth Factors for Auto-Approval']");
    public static final By OtherOptionsRequiringClinicalReview = xpath("//div[@id='ocmRegimensView-showNonPreferredSupportivesPopupModelID']//h2[text()='Other Options (Requiring Clinical Review)']");
    public static final By RegimensGrowthFactors = xpath("//*[text()='Regimens (Growth Factors)']");
    public static final By SecondaryCancerList = xpath("//span[@class='subcancer-text ng-scope']");

    // Radio Pharma Locators

    public static final By cancelClinicalSel = By.xpath("//*[contains(@id,'chemoTrialCancer-hscAttributeValue')]");
    public static final By diseaseProgressedOrRelapsedSel = By.xpath("//*[contains(@id,'diseaseProgressed-hscAttributeValue')]");
    public static final By octreotideSel = By.xpath("//select[contains(@id,'radioPharmaOctreotide-hscAttributeValue')]");
    public static final By leuprolideAcetateSel = By.xpath("//select[contains(@id,'radioPharmaLeuprolideAcetate-hscAttributeValue')]");
    public static final By drugExceptionPopUp = By.xpath("//*[@id='customDrugExceptionPopupModelID']//div[@class='tk-lbox-content-wrapper']");
    public static final By drugExceptionPopUpTitle = By.xpath("//*[contains(@ng-focus,'customDrugExceptionPopupModel.setFocus')]/h2");
    public static final By drugExceptionMessageText = By.xpath("//*[@id='customDrugExceptionMessageDiv']//p");
    public static final By requestDetailsBackdatingStartDateCheckBox = By.id("requestDetailsBackdatingStartDate");
    public static final By requestDetailsBackdatingStartDateTextBox = By.xpath("//input[@ng-model='authorizationStartDate.hscAttributeValue']");
    public static final By requestDetailsBackdatingStartDateJustificationDropdownList = By.xpath("//select[@ng-model='backdateAuthJustification.hscAttributeValue']");
    public static final By closeButtonOnDrugExceptionModal = By.xpath("//form[@name='customDrugExceptionPopupModelForm']//input[@value='Close']");
    public static final By XButtonOnDrugExceptionModal = cssSelector("[id='customDrugExceptionPopupModelID'] [class='cux-icon-close']");
    public static final By backButton = By.xpath("//input[@value='Back']");

    //Specialty Pharma Locators
//    public static By additionalIcd10Code = xpath("//label[contains(text(), 'Additional')]//..//..//following-sibling::td//input");
    public static final By icd10CodeTypeahead = By.xpath("//*[(name()='ocm:typeahead' or name()='ocm-typeahead') and @id='requestDetailsICD10Code']");
    public static final By addCode = By.xpath("//*[text()='Add Code']");
    //    public static final By specialtyPharmaDiagnosis = By.xpath("//*[text()='Disease State']/ancestor::td[1]/following-sibling::td//input");
    public static final By addDosage = By.xpath("//span[text()='Drug Dosage']/following-sibling::span//*[text()='Add Dosage']");
    public static final By doseInput = By.xpath("//label[(text()='Dose')]/following::td//input[contains(@name,'Procedure Unit Count')]");
    public static final By doseUnitSelect = By.xpath("//select[@ref-nm='procedureUnitOfMeasureType']");
    public static final By frequencyOfAdministrationDropDown = By.xpath("//label[contains(text(),'Every')]/following::select[contains(@ref-nm,'specialtyProcFreqType')]");
    public static final By numberOfDosesInput = By.xpath("//label[contains(text(),'Number')]/following::input[@name='Unit Per Frequency Count']");
    public static final By specialtyPharmaAddDosageButton = By.xpath("//*[@value='Add']");
    public static final By everyInput = By.xpath("//input[@name='Frequency Of Dosage']");
    public static final By everyUnitSelect = By.xpath("//select[@ng-model='hscServiceVO.hscServiceNonFacilityVO.procedureFrequencyType']");
    public static final By totalNumberofDoses = By.xpath(".//label[contains(text(),'Total Number')]/following::input[@name='Total Dosage Count']");
    public static final String doseConfirmationPopupContinueButtonXpath = "//div[@id='specialtyDrugDosageWarningTextDiv']/following-sibling::div/input[@value='Continue']";
    public static final By doseConfirmationPopupContinueButton = By.xpath(doseConfirmationPopupContinueButtonXpath);
    public static final By rdcdSpecialtyDiseaseState = By.xpath("//*[(name()='ocm:typeahead' or name()='ocm-typeahead') and @ng-model='hscSpecialtyProcedureVO.diseaseState']|//*[(name()='ocm:typeahead' or name()='ocm-typeahead') and @ng-model='diagnosisAttr.hscAttributeValue']");

    public static final By numberOfJointsInput = By.xpath("//input[@name='Number Of Joints']");
    public static final String LABEL_WHAT_IS_THE_DOSAGE = "What is the Dosage?";

    public static final By rdcdSpeciatyDiseaseStatebcbs=By.xpath("//input[@ng-model='hscSpecialtyProcedureVO.diseaseState']");

    // Cancer Supportive Drugs locators
    public static final By drugNameMenu = By.xpath("//*[@id=\"requestDetailsProcedureCodePreferred\"]/div[1]/div/button");
    public static final By drugNameInput = By.xpath("//*[@id=\"inputLabel-labelFilter-0\"]");

    //Locators--------

    public RequestDetailsPage(WebDriver webDriver) {
        this.driver = webDriver;
        utils = BaseCucumber.utils;
        log = Logger.getLogger(this.getClass().getName());
        gv = BaseCucumber.gv;
    }

    // Methods

    /**
     * Select a given supportive drug name. Currently only being used by White Blood Cell Growth Factors Supportive
     * flows.
     * @param drugName The drug name to select
     */
    public void selectSupportiveDrug(String drugName) {
        TestUtils.click(driver, drugNameMenu);
        TestUtils.wait(2);
        TestUtils.input(driver, drugNameInput, drugName);
        TestUtils.wait(2);
        TestUtils.click(driver, By.xpath("//*[contains(text(),'" + drugName + "')]//parent::span"));
    }

    /**
     * Inputs a required justification for choosing a non-preferred cancer supportive drug.
     *
     * @param justification The value of the justification string
     */
    public void inputCustomSupportiveDrugJustification(String justification) {

        By nonPreferredDrugJustificationInput = By.xpath("//*[@id='regimenJustification']");
        By deterrencePopupContinueBtn = By.xpath("//*[@ng-click='preferredDrugPopupModel.preferredDrugContinue();']");

        if (TestUtils.isElementVisible(driver, nonPreferredDrugJustificationInput)) {
            TestUtils.input(driver, nonPreferredDrugJustificationInput, justification);
            TestUtils.wait(2);
            TestUtils.click(driver, deterrencePopupContinueBtn);
        }

    }

    /**
     * Select Performance Status value from drop-down
     *
     * @param status
     */
    public void selectDropDownPerformanceStatus(String status) {
        log.warn("Select " + status + " value from Performance Status Drop-down");
        TestUtils.waitElement(driver, performanceStatusDropDwn);

        boolean success = new WaitUntil("Wait for Performance Status got populated", new ICondition() {
            @Override
            public boolean evaluate() throws Exception {
                Select select = new Select(driver.findElement(performanceStatusDropDwn));
                select.getOptions();
                return select.getOptions().size() > 2;
            }
        }).execute();
        if (!success) {
            throw new RuntimeException("There is no option in dropdown list: Performance Status");
        }

        TestUtils.onMouseHover(driver, performanceStatusDropDwn);
        TestUtils.highlightElement(driver, performanceStatusDropDwn);
        TestUtils.selectByVisibleText(driver.findElement(performanceStatusDropDwn), status);

    }

    /**
     * Select value from Performance Scale Drop-down
     *
     * @param scale
     */
    public void selectDropDownPerformanceScale(String scale) {
        log.warn("Select " + scale + " value from Performance Scale Drop-down");
        TestUtils.waitElement(driver, performanceScaleDropDwn);
        TestUtils.onMouseHover(driver, performanceScaleDropDwn);
        TestUtils.highlightElement(driver, performanceScaleDropDwn);
        TestUtils.selectByVisibleText(driver.findElement(performanceScaleDropDwn), scale);

    }

    /**
     * Entering height on RequestDetailsPage
     *
     * @param height
     */
    public void enterTextInHeightOfThePatient(String height) {
        log.warn("Entering height ");
        TestUtils.input(driver, heightOfThePatientTextBox, height);
    }

    /**
     * Entering weight on RequestDetailsPage
     *
     * @param weight
     */
    public void enterTextInWeightOfThePatient(String weight) {
        log.warn("Entering weight ");
        TestUtils.input(driver, weightOfThePatientTextBox, weight);
    }

    /**
     * Entering phone number on RequestDetailsPage
     *
     * @param phone
     */
    public void enterTextInPatientContactNumber(String phone) {
        log.warn("Entering phone number ");
        TestUtils.inputBasedOnLabelName(driver, phone, "Patient Contact Number");
    }

    /**
     * Entering initialDiagnosisDate on RequestDetailsPage
     *
     * @param initialDiagnosisDate
     */
    public void enterTextInInitialDiagnosisDate(String initialDiagnosisDate) {
        log.warn("Entering initialDiagnosisDate ");
        TestUtils.input(driver, initialDiagnosisDateTextBox, initialDiagnosisDate);
    }

    /**
     * Selecting service on RequestDetailsPage
     *
     * @param service
     */
    public void selectDropDownValueInplaceofServiceTypeSel(String service) {
        log.warn("Selecting service ");
        TestUtils.input(driver, placeofServiceTypeSel, service);

        String buyAndBillPopupModelFormXpath = "//form[@name='buyAndBillPopupModelForm']";
        if (TestUtils.isElementVisible(driver, buyAndBillPopupModelFormXpath)) {
            String yesButtonXpath = buyAndBillPopupModelFormXpath + "//input[@value='Yes']";
            TestUtils.clickUntil(driver, By.xpath(yesButtonXpath), new ICondition() {
                @Override
                public boolean evaluate() throws Exception {
                    return !TestUtils.isElementVisible(driver, buyAndBillPopupModelFormXpath);
                }
            });
        }
    }

    /**
     * Validate if POS field is readonly
     */
    public void validatPOSReadOnlyField(){
        log.warn(" POS should be read only field");
        Assert.assertTrue(TestUtils.isElementPresent(driver,placeOfSerDisabled));
    }

    /**
     * Entering treatmentStartDate on RequestDetailsPage
     *
     * @param treatmentStartDate
     */
    public void enterTextInAnticipatedTreatmentTextBox(String treatmentStartDate) {
        log.warn("Entering " + treatmentStartDate + " treatment start date");
        TestUtils.highlightElement(driver, anticipatedTreatmentTextBox);
        driver.findElement(anticipatedTreatmentTextBox).clear();
        driver.findElement(anticipatedTreatmentTextBox).sendKeys(treatmentStartDate);
    }


    /**
     * Entering iCD10CodeText on RequestDetailsPage
     *
     * @param iCD10CodeText
     */
    public void enterTextinIcdCode(String iCD10CodeText) {
        selectingICDcode(iCD10CodeText);
    }

    /**
     * Entering primaryCancerText on RequestDetailsPage
     *
     * @param primaryCancerText
     */
    public void enterTextinprimaryCancer(String primaryCancerText) {
        log.warn("Entering primaryCancerText");
        driver.findElement(primaryCancer).clear();
        TestUtils.wait(2);
        TestUtils.input(driver, primaryCancer, primaryCancerText);
        By primaryCancerDropDown = By.xpath("  //a[contains(@title,'" + primaryCancerText + "')]");
        TestUtils.wait(2);
        TestUtils.click(driver, primaryCancerDropDown);
    }

    /**
     * Selecting supportiveCareRequest on RequestDetailsPage
     *
     * @param supportiveCareRequest
     */
    public void selectDropDownValueInSupportiveCareRequest(String supportiveCareRequest) {
        log.warn("Selecting supportiveCareRequest");
        TestUtils.highlightElement(driver, supportiveCareRequestTypeSel);
        TestUtils.selectByVisibleText(driver.findElement(supportiveCareRequestTypeSel), supportiveCareRequest);

    }

    /**
     * Selecting chemotherapyTrialCancer on RequestDetailsPage
     *
     * @param chemotherapyTrialCancer
     */
    public void selectDropDownValueInChemotherapyTrialCancerTypeSel(String chemotherapyTrialCancer) {
        TestUtils.waitElementVisible(driver,chemotherapyTrialCancerTypeSel);
        log.warn("Selecting chemotherapyTrialCancer");
        TestUtils.wait(2);
        TestUtils.highlightElement(driver, chemotherapyTrialCancerTypeSel);
        TestUtils.selectByVisibleText(driver.findElement(chemotherapyTrialCancerTypeSel), chemotherapyTrialCancer);
    }

    /**
     * Selecting chemotherapyTrialCancer on RequestDetailsPage
     *
     * @param distantMetatasticDisease
     */
    public void selectDropDownValueForDistantMetatasticDisease(String distantMetatasticDisease) {
        log.warn("Selecting distant metatastic disease");
        TestUtils.wait(2);
        TestUtils.highlightElement(driver, patientdistantmetatasticdisease);
        TestUtils.selectByVisibleText(driver.findElement(patientdistantmetatasticdisease), distantMetatasticDisease);
    }

    /**
     * Selecting chemotherapyTrialCancer on RequestDetailsPage
     *
     * @param primaryOrSecondarySite
     */
    public void selectDropDownValueForPrimarySecondaryMetatasticSite(String primaryOrSecondarySite) {
        log.warn("Selecting chemotherapyTrialCancer");
        TestUtils.wait(2);
        TestUtils.highlightElement(driver, primaryorsecondarymetatasticsite);
        TestUtils.selectByVisibleText(driver.findElement(primaryorsecondarymetatasticsite), primaryOrSecondarySite);
    }
    /**
     * Validating ChangePrimarydiagnosisMessage on RequestDetailsPage and click OK
     *
     * @param expecMessage
     */
    public void changePrimaryDiagnoseMessage(String expecMessage) {
        log.warn("Verifying Change Primary diagnosis Message message");
        TestUtils.wait(2);
        TestUtils.highlightElement(driver, changeprimarydiagnoselectionmessage);
        String messageText = driver.findElement(changeprimarydiagnoselectionmessage).getText();
        Assert.assertTrue("MessageText Does not match ", expecMessage.equals(messageText));
        TestUtils.click(driver,changeprimarydiagnoselectionokaybutton);
    }

    /**
     * Validating Clinical Trial Message and Update value to No
     *
     * @param expecMessage
     */
    public void validateAndChangeClinicalTrialValue(String expecMessage) {
        log.warn("Verifying Clinical Trial Message");
        TestUtils.wait(2);
        TestUtils.highlightElement(driver, clinicaltrialmessage);
        String messageText = driver.findElement(clinicaltrialmessage).getText();
        Assert.assertTrue("MessageText Does not match ", expecMessage.equals(messageText));
        TestUtils.click(driver,clinicaltrialokaybutton);
        TestUtils.selectByVisibleText(driver.findElement(chemotherapyTrialCancerTypeSel), "No");
    }
    /**
     * Selecting diseaseProgressed on RequestDetailsPage
     *
     * @param diseaseProgressed
     */
    public void selectDropDownValueInDiseaseProgressedTypeSel(String diseaseProgressed) {
        TestUtils.waitElementVisible(driver, diseaseStatusTypeSel);
        log.warn("Selecting diseaseProgressed");
        TestUtils.highlightElement(driver, diseaseStatusTypeSel);
        TestUtils.selectByVisibleText(driver.findElement(diseaseStatusTypeSel), diseaseProgressed);
    }

    /**
     * Selecting changingTreatment on RequestDetailsPage
     *
     * @param changingTreatment
     */
    public void selectDropDownValueInChangingTreatmentTypeSel(String changingTreatment) {
        log.warn("Selecting changingTreatment");
        TestUtils.wait(2);

        String readonlySpanXpath = "//label[text()='New to Therapy or Continuation Therapy']/../../following-sibling::td/span";

        int c = TestUtils.countElementsByXpath(driver, readonlySpanXpath);
        if (0 == c) {
            TestUtils.select(driver, changingTreatmentType, changingTreatment);
        } else if (1 == c) {
            Assert.assertEquals(changingTreatment, TestUtils.text(driver, By.xpath(readonlySpanXpath)));
        } else {
            Assert.fail(c + " elements found by xpath: " + readonlySpanXpath);
        }
    }

    /**
     * Selecting changingTreatment justification on RequestDetailsPage
     *
     * @param justificationReason
     */
    public void changeTreatmentJustificationSelection(String justificationReason) {
        By changeTreatmentJustification = By.xpath(" //label[contains(text(),'" + justificationReason + "')]/../input");
        driver.findElement(changeTreatmentJustification).click();
    }

    /**
     * Clicking on continue button on RequestDetailsPage
     *
     * @return RequestDetailsPage
     */
    public void clickContinueButton() {
        TestUtils.safeClick(driver, continueButton);
    }

    public void clickDoseConfirmationPopupContinueButton() {
        if (TestUtils.waitElementVisible(driver, doseConfirmationPopupContinueButtonXpath, 3)) {
            TestUtils.safeClick(driver, doseConfirmationPopupContinueButton);
        }
    }


    /**
     * Entering initialDateofProgressionText on RequestDetailsPage
     *
     * @param initialDateofProgressionText
     */
    public void enterTextInInitialDateofProgression(String initialDateofProgressionText) {
        log.warn("Entering initialDateofProgressionText");
        TestUtils.highlightElement(driver, initialDateofProgression);
        driver.findElement(initialDateofProgression).sendKeys(initialDateofProgressionText);
    }

    public void enterOtherDecription(String description) {
        log.warn("Entering other Description ");
        TestUtils.highlightElement(driver, otherDecription);
        driver.findElement(otherDecription).sendKeys(description);
    }

    /**
     * Entering Current Medicine on RequestDetailsPage
     *
     * @param isMedicineTaken
     */
    public void selectDropDownValueInCurrentMedicineTypeSel(String isMedicineTaken) {
        log.warn("Entering is Medicine Taken currently");
        TestUtils.waitElement(driver, currentMedicine);
        Select dr = new Select(driver.findElement(currentMedicine));
        dr.selectByVisibleText(isMedicineTaken);
    }

    /**
     * Entering Radiopharmaceutical Req on RequestDetailsPage
     *
     * @param radiopharmaceuticalReq
     */
    public void selectDropDownValueInRadiopharmaceuticalRequestTypeSel(String radiopharmaceuticalReq) {
        log.warn("Entering Radiopharmaceutical Request");
        TestUtils.waitElement(driver, radiopharmaceuticalRequest);
        Select dr = new Select(driver.findElement(radiopharmaceuticalRequest));
        dr.selectByVisibleText(radiopharmaceuticalReq);
    }

    /**
     * validating height min and max values
     *
     * @param height
     */
    public void validateBoundaryValueForHeight(String height) {
        log.warn("Validating boundary values for height component ");
        TestUtils.highlightElement(driver, heightOfThePatientTextBox);

        Integer patientHeight = height.isEmpty() ? null : (int) Double.parseDouble(height);

        if (patientHeight == null || patientHeight >= 0 && patientHeight <= 120.9) {
            driver.findElement(heightOfThePatientTextBox).clear();
            driver.findElement(heightOfThePatientTextBox).sendKeys(height);
            driver.findElement(weightOfThePatientTextBox).click();
            Assert.assertFalse("Error Message should not be displayed ", TestUtils.isElementPresent(driver, By.xpath("//*[text()='Value cannot be greater than 120.9']")));
        } else {
            driver.findElement(heightOfThePatientTextBox).clear();
            driver.findElement(heightOfThePatientTextBox).sendKeys(height);
            driver.findElement(weightOfThePatientTextBox).click();
            Assert.assertTrue("Error Message not displayed ", TestUtils.isElementPresent(driver, By.xpath("//*[text()='Value cannot be greater than 120.9']")));
        }
    }

    /**
     * Selecting cancel clinical trial value from clinical trial drop down
     *
     * @param cancelClinicalTrial
     */
    public void selectDropDownValueInCacnerClinicalTrial(String cancelClinicalTrial) {
        log.warn("Selecting cancel clinical trial value");
        TestUtils.wait(2);
        TestUtils.highlightElement(driver, cancelClinicalSel);
        TestUtils.selectByVisibleText(driver.findElement(cancelClinicalSel), cancelClinicalTrial);
    }

    /**
     * User Selecting disease progressed ot elapsed from drop down
     *
     * @param diseaseProgressedOrRelapsed
     */
    public void selectDropDownValueIndiseaseProgressedOrRelapsed(String diseaseProgressedOrRelapsed) {
        log.warn("Selecting disease progressed ot elapsed");
        TestUtils.wait(2);
        TestUtils.highlightElement(driver, diseaseProgressedOrRelapsedSel);
        TestUtils.selectByVisibleText(driver.findElement(diseaseProgressedOrRelapsedSel), diseaseProgressedOrRelapsed);
    }

    /**
     * Select Octreotide as additional drug in radiopharma
     *
     * @param drug
     */
    public void selectDropDownValueInOctreotide(String drug) {
        log.warn("Selecting octreotide");
        TestUtils.wait(5);
        TestUtils.highlightElement(driver, octreotideSel);
        TestUtils.selectByVisibleText(driver.findElement(octreotideSel), drug);
    }


    /**
     * Select LeuprolideAcetate as additional drug in radiopharma
     *
     * @param drug
     */
    public void selectDropDownValueInLeuprolideAcetateSel(String drug) {
        log.warn("Selecting Leuprolide Acetate");
        TestUtils.wait(2);
        TestUtils.highlightElement(driver, leuprolideAcetateSel);
        TestUtils.selectByVisibleText(driver.findElement(leuprolideAcetateSel), drug);
    }


    /**
     * Check that element with Text has Required mark
     *
     * @param txt
     */
    public void checkRequiredElementByText(String txt) {
        log.warn("verifying required mark is present .");
        Assert.assertTrue("Element with text " + txt + " is NOT visible. ", TestUtils.isElementPresent(driver, By.xpath("(//*[contains(text(),'" + txt + "')]/span[@title='Required'])")));
        TestUtils.highlightElement(driver, By.xpath("(//*[contains(text(),'" + txt + "')]/span[@title='Required'])"));
    }

    /**
     * Selecting Drug Category on RequestDetailsPage
     *
     * @param drugCategory
     */
    public void selectDropdownDrugCategory(String drugCategory) {
        TestUtils.input(driver, drugCategorySelect, drugCategory);
    }

    /**
     * Selecting Drug Type on RequestDetailsPage
     *
     * @param drugType
     */
    public void selectDropdownDrugType(String drugType) {
//        TestUtils.input(driver, drugTypeSel, drugType);
        TestUtils.select(driver, drugTypeSel, drugType);

    }

    /**
     * Selecting Drug Dosage on RequestDetailsPage
     */
    public void selectDropdownDosage(String dosage) {
        TestUtils.inputBasedOnLabelName(driver, dosage, LABEL_WHAT_IS_THE_DOSAGE);
    }

    /**
     * Selecting Line of therapy on RequestDetailsPage
     *
     * @param lineOfTherapy
     */
    public void selectDropDownLineOfTherapy(String lineOfTherapy) {
        log.warn("Selecting line of therapy for supportive Drug");
        TestUtils.wait(2);
        TestUtils.highlightElement(driver, lineOfTherapySel);
        TestUtils.selectByVisibleText(driver.findElement(lineOfTherapySel), lineOfTherapy);
    }

    /**
     * verifying Text/Error message on RequestDetailsPage
     *
     * @param errormessage
     * @throws Exception
     */
    public void verifyTextOnRequestDetailsPage(String errormessage) throws Exception {
        log.warn("verifying Text/Error message '" + errormessage + "' is displayed");
        TestUtils.wait(2);
        By message = By.xpath("//*[contains(text(),'" + errormessage + "')]");
        TestUtils.waitElement(driver, message, 15);
        TestUtils.highlightElement(driver, message);
        Assert.assertTrue("Text/Error Message " + errormessage + " not displayed ", TestUtils.isElementPresent(driver, message));
    }

    /**
     * Verifying height element is not required
     */
    public void checkHeightWithRequiredMark() {
        log.warn("Checking height element is not required");
        TestUtils.wait(3);
        boolean present = TestUtils.isElementPresent(driver, heightRequiredFlag);

        Assert.assertFalse("Element required icon is present ", present);

    }

    public void enterTextInBackDatingTextBox(String backdatingStartDate, String justification) {
        log.warn("Entering backdating start date");
        if (StringUtils.isEmpty(backdatingStartDate)) {
            return;
        }
        String checked = this.driver.findElement(requestDetailsBackdatingStartDateCheckBox).getAttribute("checked");
        while (!"true".equals(checked)) {
            try {
                TestUtils.click(driver, requestDetailsBackdatingStartDateCheckBox);
                TestUtils.wait(1);
            } catch (Exception e) {
                // do nothing
            } finally {
                checked = this.driver.findElement(requestDetailsBackdatingStartDateCheckBox).getAttribute("checked");
            }
        }
        TestUtils.wait(1);
        TestUtils.input(driver, requestDetailsBackdatingStartDateTextBox, backdatingStartDate);
        TestUtils.wait(1);
        TestUtils.select(driver, requestDetailsBackdatingStartDateJustificationDropdownList, justification);
    }

    public void verifytheClinicalTrialFields(String ClinicalTrial) {
        log.warn("Verifies Clinical Trials Fields is not displayed on Selection ChemoThreapy Clinical Trials as Yes");
        By ClinicalTrialsField = By.xpath("  //label[contains(text(),'" + ClinicalTrial + "')]");
        boolean present = TestUtils.isElementPresent(driver, ClinicalTrialsField);

        Assert.assertFalse("Element required icon is present ", present);

    }

    /**
     * User enters clinical trial name field in Request Details Page
     *
     * @param TrialName
     */
    public void enterTextInClinicalTrialName(String TrialName) {
        log.warn("Entering Clinical Trial Name");
        TestUtils.highlightElement(driver, clinicalTrialName);
        driver.findElement(clinicalTrialName).sendKeys(TrialName);
        gv.setClinicalTrialName(TrialName);
    }

    /**
     * User enters clinical trial phase field in Request Details Page
     *
     * @param TrialPhase
     */
    public void enterTextInClinicalTrialPhase(String TrialPhase) {
        log.warn("Entering Clinical Trial Phase");
        TestUtils.highlightElement(driver, clinicalTrialPhase);
        driver.findElement(clinicalTrialPhase).sendKeys(TrialPhase);
        gv.setClinicalTrialPhase(TrialPhase);

    }


    /**
     * Verifying Radio pharma drug from Radiopharmaceutical dropdown on RequestDetailsPage
     *
     * @param radiopharmaceuticalReq
     */
    public void verifyDropDownValueInRadiopharmaceuticalRequestTypeSel(String radiopharmaceuticalReq) {
        log.warn("Verifying Radiopharmaceutical option");
        boolean isExist = false;
        TestUtils.waitElement(driver, radiopharmaceuticalRequest);
        Select dr = new Select(driver.findElement(radiopharmaceuticalRequest));
        List<WebElement> allOptions = dr.getOptions();
        for (WebElement we : allOptions) {
            if (we.getText().equals(radiopharmaceuticalReq)) {
                isExist = true;
                break;
            }
        }
        Assert.assertTrue(radiopharmaceuticalReq + "option is not present in Radiopharma dropdown", isExist);
    }

    /**
     * Verifiying Drug exception popup header on RequestDetailsPage
     */
    public void verifyDrugExceptionPopUpHeader() {
        log.warn("Verifying popup is displayed on Drug Exception Notification");
        TestUtils.waitElement(driver, drugExceptionPopUp);
        TestUtils.highlightElement(driver, drugExceptionPopUp);
        Assert.assertTrue("Drug Exception Notification popup window is not displayed", TestUtils.isElementPresent(driver, drugExceptionPopUp));
        TestUtils.highlightElement(driver, drugExceptionPopUpTitle);
        Assert.assertTrue("Popup title doesn't have title as Drug Exception Notification", TestUtils.isElementPresent(driver, drugExceptionPopUpTitle));
    }

    /**
     * Verifiying Drug exception Message on RequestDetailsPage
     *
     * @param message
     */
    public void verifyDrugExceptionPopUpMessage(String message) {
        log.warn("Verifying Drug exception message Drug Exception Notification");
        TestUtils.highlightElement(driver, drugExceptionMessageText);
        String messageText = driver.findElement(drugExceptionMessageText).getText();
        Assert.assertTrue("drugExceptionMessageText Does not match ", message.equals(messageText));
    }

    /**
     * Verifiying Close Button on Drug Exception Modal
     */
    public void verifyCloseButtonOnDrugExceptionModalPage() {
        log.warn("Verifying close button on  Drug Exception Notification");
        TestUtils.highlightElement(driver, closeButtonOnDrugExceptionModal);
        Assert.assertTrue("Close Button is present on Drug Exception Notification", TestUtils.isElementPresent(driver, closeButtonOnDrugExceptionModal));

    }

    /**
     * Verifiying X Action Button on Drug Exception Modal
     */
    public void verifyXActionButton() {
        log.warn("Verifying X action Button on Drug Exception Notification");
        TestUtils.highlightElement(driver, XButtonOnDrugExceptionModal);
        Assert.assertTrue("X action button Drug Exception Notification", TestUtils.isElementPresent(driver, XButtonOnDrugExceptionModal));

    }

//    public void selectingPrimaryOrAdditionalICDcode(String iCD10CodeText, By by) {
//        TestUtils.input(driver, by, iCD10CodeText);
//        By icdDropDown = By.xpath("//a[contains(@title,'" + iCD10CodeText + "')]");
//        TestUtils.click(driver, icdDropDown);
//    }

    public void selectingICDcode(String iCD10CodeText) {
        TestUtils.input(driver, icd10CodeTypeahead, iCD10CodeText);
    }

    //Specialty Pharma methods

    /**
     * Entering Primary iCD10CodeText on RequestDetailsPage
     *
     * @param iCD10CodeText
     */
    public void enterPrimaryIcdCodeAndClickAddCode(String iCD10CodeText) {
        TestUtils.input(driver, primaryIcd10Code, iCD10CodeText);
        TestUtils.wait(6);
        TestUtils.click(driver, By.xpath("//*[contains(@id,'typeahead')]/a/strong"));
        TestUtils.wait(4);
    }

    /**
     * Selecting Diagnosis on RequestDetailsPage
     *
     * @param diagnosis
     */
    public void selectSpecialtyDiagnosis(String diagnosis) {
        enterTextInDiseaseState(diagnosis);
    }

    /**
     * Clicking on continue button on RequestDetailsPage
     */
    public void specialtyPharmaclickContinueButton() {
        TestUtils.wait(2);
        TestUtils.safeClick(driver, continueButton);
        TestUtils.wait(2);

    }

    /**
     * Clicking on Add Dosage link on RequestDetailsPage
     */
    public void clickingAddDosage() {
        TestUtils.safeClick(driver, addDosage);
        TestUtils.wait(2);

    }

    /**
     * Entering drug dosage on add Dosage popup
     */
    public void enteringDrugDosage(String drugDose,String unit) {
        TestUtils.input(driver, doseInput, drugDose);
      //Add
        TestUtils.wait(2);
        TestUtils.select(driver, doseUnitSelect, unit);

    }


    /**
     * Selecting a value from frequency of administration dropdown
     */
    public void selectsValueFromFrequencyOfAdministration(String frequencyOfAdministration) {
        TestUtils.select(driver, frequencyOfAdministrationDropDown, frequencyOfAdministration);
    }

    /**
     * Input frequecy
     */
    public void inputFrequecy(String unit) {
        TestUtils.input(driver, everyInput, unit);
    }

    /**
     * Input total number of doses
     */
    public void inputTotoalNumberofDoses(String unit) {
        TestUtils.input(driver, totalNumberofDoses, unit);
    }

    /**
     * Entering drug dosage on add Doses
     */
    public void enteringNumberofDoses(String drugDose) {
        TestUtils.wait(2);
        TestUtils.input(driver, numberOfDosesInput, drugDose);

    }

    /**
     * Clicking on Add button
     */
    public void specialtyPharmaclickAddButton() {
        TestUtils.click(driver, specialtyPharmaAddDosageButton);
        TestUtils.wait(2);
    }

    /**
     * Verifying cloned values displayed on Request details page for specialty pharma flow
     */
    public void verifyCloning(String cloneType, Map<String, String> pf) {
        Select dropdown;
        WebElement option;
        String text;
        log.warn("Verifying cloned values displayed on Request details page");
        switch (cloneType) {

            case "specialtypharmaSameClass":
                Assert.assertEquals("", true, driver.findElement(By.xpath("//label[text()='Height of the Patient']/../../following-sibling::td/input")).getAttribute("value").equals(pf.get(MBM.RDPD_HEIGHT_OF_THE_PATIENT)));
                Assert.assertEquals("", true, driver.findElement(By.xpath("//label[text()='Weight of the Patient']/../../following-sibling::td/input")).getAttribute("value").equals(pf.get(MBM.RDPD_WEIGHT_OF_THE_PATIENT)));
                Assert.assertEquals("", true, driver.findElement(By.xpath("//label[text()='Patient Contact Number']/../../following-sibling::td/input")).getAttribute("value").equals(pf.get(MBM.RDPD_PATIENT_CONTACT_NUMBER)));
                Assert.assertEquals("", true, driver.findElement(By.xpath("//label[text()='Initial Diagnosis Date']/../../following-sibling::td//input")).getAttribute("value").equals(pf.get(MBM.RDSD_INITIAL_DIAGNOSIS_DATE)));
                Assert.assertEquals("", true, driver.findElement(By.xpath("//label[text()='Primary ICD-10 Code']/../../following-sibling::td//input")).getAttribute("value").equals(pf.get(MBM.RDSD_ICD_10_CODE)));
                Assert.assertEquals("", true, driver.findElement(By.xpath("//label[text()='New to Therapy or Continuation Therapy']/../../following-sibling::td/span")).getText().equals("Continuation Therapy"));
                dropdown = new Select(driver.findElement(By.xpath("//label[text()='Place of Service']/../../following-sibling::td//select")));
                option = dropdown.getFirstSelectedOption();
                text = option.getText();
                Assert.assertEquals("", true, text.equals(pf.get(MBM.RDSD_PLACE_OF_SERVICE)));
                Assert.assertEquals("", true, driver.findElement(By.xpath("//label[text()='Specialty Pharmacy Drug Class']/../../following-sibling::td/span")).getText().equals(pf.get("Clone To Class")));
                Assert.assertEquals("", true, driver.findElement(By.xpath("//label[text()='Drug Code']/../../following-sibling::td/span")).getText().equals(pf.get("drugCode")));
                break;
            case "specialtypharmaDifferentClass":
                Assert.assertEquals("", true, driver.findElement(By.xpath("//label[text()='Height of the Patient']/../../following-sibling::td/input")).getAttribute("value").equals(pf.get(MBM.RDPD_HEIGHT_OF_THE_PATIENT)));
                Assert.assertEquals("", true, driver.findElement(By.xpath("//label[text()='Weight of the Patient']/../../following-sibling::td/input")).getAttribute("value").equals(pf.get(MBM.RDPD_WEIGHT_OF_THE_PATIENT)));
                Assert.assertEquals("", true, driver.findElement(By.xpath("//label[text()='Patient Contact Number']/../../following-sibling::td/input")).getAttribute("value").equals(pf.get(MBM.RDPD_PATIENT_CONTACT_NUMBER)));
                Assert.assertEquals("", true, driver.findElement(By.xpath("//label[text()='Initial Diagnosis Date']/../../following-sibling::td//input")).getAttribute("value").equals(""));
                Assert.assertEquals("", true, driver.findElement(By.xpath("//label[text()='Primary ICD-10 Code']/../../following-sibling::td//input")).getAttribute("value").equals(""));
                dropdown = new Select(driver.findElement(By.xpath("//label[text()='New to Therapy or Continuation Therapy']/../../following-sibling::td//select")));
                option = dropdown.getFirstSelectedOption();
                text = option.getText();
                Assert.assertEquals("", true, text.equals(""));
                dropdown = new Select(driver.findElement(By.xpath("//label[text()='Place of Service']/../../following-sibling::td//select")));
                option = dropdown.getFirstSelectedOption();
                text = option.getText();
                Assert.assertEquals("", true, text.equals(""));
                Assert.assertEquals("", true, driver.findElement(By.xpath("//label[text()='Specialty Pharmacy Drug Class']/../../following-sibling::td/span")).getText().equals(pf.get("Clone To Class")));
                Assert.assertEquals("", true, driver.findElement(By.xpath("//label[text()='Drug Code']/../../following-sibling::td/span")).getText().equals(pf.get("drugCode")));
                break;
        }
    }

    /**
     * Verifiying show other Options Link
     */
    public void verifyshowOtherOptionsLink() {
        log.warn("Verifying show other Options Link  on request details page");
        TestUtils.highlightElement(driver, showOtherOptionsLink);
        Assert.assertTrue("Show other Options Link  is present on request details page",
                TestUtils.isElementVisible(driver, showOtherOptionsLink));

    }

    /**
     * Verifiying Header
     */
    public void verifyHeader() {
        log.warn("Verifying header available growth factors for auto approval on request details page");
        TestUtils.highlightElement(driver, availableGrowthFactorsforAutoApproval);
        Assert.assertTrue("Header not visible 'available growth factors for auto approval on request details page'", TestUtils.isElementVisible(driver, availableGrowthFactorsforAutoApproval));

    }

    /**
     * Verifiying Header
     */
    public void verifyHiddenHeader() {
        log.warn("Verifying header 'Other Options (Requiring Clinical Review)' not visible on request details page");
        boolean displayed = driver.findElement(OtherOptionsRequiringClinicalReview).isDisplayed();
        Assert.assertFalse("Header not visible 'available growth factors for auto approval on request details page'", displayed);
        TestUtils.wait(3);

    }

    /**
     * Verifiying Header
     */
    public void verifyHeaderforMS() {
        log.warn("Verifying header available growth factors for auto approval on request details page");
        TestUtils.highlightElement(driver, RegimensGrowthFactors);
        Assert.assertTrue("Header not visible 'available growth factors for auto approval on request details page'", TestUtils.isElementVisible(driver, RegimensGrowthFactors));
        TestUtils.wait(2);
    }

    public void clickBackButton() {
        TestUtils.onMouseHover(driver, backButton);
        TestUtils.click(driver, backButton);
    }

    public void addAdditionalIcd10Code(String value) {
        if (!StringUtils.isEmpty(value)) {
            TestUtils.input(driver, icd10CodeTypeahead, value);
            TestUtils.click(driver, addCode);
        }
    }

    /**
     * Adding If condition in below method  for Regular flow passing "RegularDoses" for RGDR_NUMBER_OF_DOSES_0
     * to skip the Add Dosage
     */

    public void addSpecialtyDosage(Map<String, String> pf) {
        int index = 0;

        if (pf.get(indexedKey(MBM.RGDR_NUMBER_OF_DOSES_0, index)).equalsIgnoreCase("RegularDoses")) {

            while (pf.containsKey(indexedKey(MBM.RGDR_NUMBER_OF_DOSES_0, index))) {
                String rgdrNumberofDoses = pf.get(indexedKey(MBM.RGDR_NUMBER_OF_DOSES_0, index));

                Assert.assertTrue("Missing required Drug Dosage information.",
                        !StringUtils.isEmpty(rgdrNumberofDoses)
                );

                index++;
            }

        } else {

            while (pf.containsKey(indexedKey(MBM.RGDR_NUMBER_OF_DOSES_0, index))) {
                String rgdrNumberofJoints = pf.get(indexedKey(MBM.RGDR_NUMBER_OF_JOINTS_0, index));
                String rgdrNumberofDoses = pf.get(indexedKey(MBM.RGDR_NUMBER_OF_DOSES_0, index));
                String rgdrDose = pf.get(indexedKey(MBM.RGDR_DOSE_0, index));
                String rgdrFrequencyofAdministration = pf.get(indexedKey(MBM.RGDR_FREQUENCY_OF_ADMINISTRATION_0, index));
                String rgdrTotalNumberofDoses = pf.get(indexedKey(MBM.RGDR_TOTAL_NUMBER_OF_DOSES_0, index));

                Assert.assertTrue("Missing required Drug Dosage information.",
                        !StringUtils.isEmpty(rgdrNumberofDoses) &&
                                !StringUtils.isEmpty(rgdrDose) &&
                                !StringUtils.isEmpty(rgdrFrequencyofAdministration) &&
                                !StringUtils.isEmpty(rgdrTotalNumberofDoses)
                );

                clickingAddDosage();

                inputNumberofJoints(rgdrNumberofJoints);
                inputNumberOfDoses(rgdrNumberofDoses);
                inputDose(rgdrDose);
                inputFrequencyofAdministration(rgdrFrequencyofAdministration);
                inputTotoalNumberofDoses(rgdrTotalNumberofDoses);

                specialtyPharmaclickAddButton();

                index++;
            }
        }
    }

    @NotNull
    private String indexedKey(String key0, int index) {
        return key0.substring(0, key0.length() - 1) + index;
    }

    private void inputNumberofJoints(String rgdrNumberofJoints) {
        if (TestUtils.isElementVisible(driver, numberOfJointsInput)) {
            Assert.assertTrue(!StringUtils.isEmpty(rgdrNumberofJoints));
            TestUtils.input(driver, numberOfJointsInput, rgdrNumberofJoints);
        }
    }

    private void inputFrequencyofAdministration(String rgdrFrequencyofAdministration) {
        String[] p = rgdrFrequencyofAdministration.split("\\s+", 3);
        TestUtils.input(driver, everyInput, p[1]);
        TestUtils.input(driver, everyUnitSelect, p[2]);
    }

    private void inputDose(String rgdrDose) {
        String[] p = rgdrDose.split("\\s+", 2);
        TestUtils.input(driver, doseInput, p[0]);
        TestUtils.input(driver, doseUnitSelect, p[1]);
    }

    private void inputNumberOfDoses(String rgdrNumberofDoses) {
        TestUtils.input(driver, numberOfDosesInput, rgdrNumberofDoses);
    }

    public void enterTextInDiseaseState(String s) {
        if (!StringUtils.isEmpty(s)) {
                TestUtils.input(driver, rdcdSpecialtyDiseaseState, s);
        }

    }


    //Add

    public static final By backdateAuthJustification = By.xpath("//select[@ref-nm='backdateAuthJustification']");

    public void selectJustificationForBackdatingOfStartDating(String option) {

        TestUtils.select(driver, backdateAuthJustification, option);
    }

    //Select Therapy
    public void selectTherapyOnRequestDetailsPage(String therapy) {
        TestUtils.select(driver, changingTreatmentTypeSel, therapy);

    }


    public void enterClincalDetailsForClone(Map<String, String> pf, String to) {
        switch (to) {
            case "Chemo":
                try {
                    selectDropDownValueInChemotherapyTrialCancerTypeSel(pf.get(MBM.RDCD_CHEMOTHERAPY_CLINICAL_TRIAL));
                }
                catch(Exception e){

                }
                String treatment = pf.get(MBM.RDCD_INITIAL_OR_CHANGING_TREATMENT);
                selectDropDownValueInDiseaseProgressedTypeSel("No");
                selectDropDownValueInChangingTreatmentTypeSel(treatment);

                String[] justifications = ExcelLib.splitJustifications(pf.get(MBM.RDCD_CHANGING_TREATMENT_JUSTIFICATION));
                TestUtils.wait(2);
                for (String justification : justifications) {
                    changeTreatmentJustificationSelection(justification);
                }
                break;
            case "Supportive":
                String drugCategory = pf.get(MBM.RDCD_WHAT_IS_THE_DRUG_CATEGORY);
                selectDropdownDrugCategory(drugCategory);

                // Input and select the drug name
                if (pf.containsKey(MBM.RDCD_SUPPORTIVE_DRUG_NAME)) {
                    selectSupportiveDrug(pf.get(MBM.RDCD_SUPPORTIVE_DRUG_NAME));
                }

                // Input the selected drug dosage
                if (pf.containsKey(MBM.RDCD_WHAT_IS_THE_DOSAGE)) {
                    selectDropdownDosage(pf.get(MBM.RDCD_WHAT_IS_THE_DOSAGE));
                }

                // Input the custom regimen justification
                if (pf.containsKey(MBM.RG_TYPE) && pf.get(MBM.RG_TYPE).equals("Custom")) {
                    clickContinueButton();
                    Assert.assertTrue(pf.containsKey(MBM.RGID_REGIMEN_JUSTIFICATION_0));
                    inputCustomSupportiveDrugJustification(pf.get(MBM.RGID_REGIMEN_JUSTIFICATION_0));
                }

            case "Radonc":
                try {
                    enterTextInPatientContactNumber(pf.get(MBM.RDPD_PATIENT_CONTACT_NUMBER));
                    enterTextInInitialDiagnosisDate(pf.get(MBM.RDSD_INITIAL_DIAGNOSIS_DATE));
                    enterPrimaryIcdCodeAndClickAddCode(pf.get(MBM.RDSD_ICD_10_CODE));
                    selectDropDownValueForDistantMetatasticDisease("No");
                    selectDropDownValueInCacnerClinicalTrial("No");
                    selectDropDownValueInplaceofServiceTypeSel("Outpatient Facility");
                                    }
                catch(Exception e){

                }

        }

    }

}





