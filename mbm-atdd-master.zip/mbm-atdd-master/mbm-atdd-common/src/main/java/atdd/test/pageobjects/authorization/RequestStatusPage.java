package atdd.test.pageobjects.authorization;


import atdd.common.ScenarioLogger;
import atdd.test.shared.BaseCucumber;
import atdd.test.shared.Globals;
import atdd.utils.DateUtils;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.Date;

import static atdd.utils.TestUtils.text;

/**
 * Created by pvavilal on 12/10/18.
 */
public class RequestStatusPage {

    Logger log;
    private WebDriver driver;
    private TestUtils utils;
    private Globals glb;
    private Scenario scenario;
    private ScenarioLogger scenarioLogger = null;

    //Locators--------
    public static By urgentRequestText = By.xpath("//label[text()='Is it an Urgent Request?']/ancestor::td[1]/following-sibling::td/span");
    public static By urgentRequestOutcomeText = By.xpath("//label[text()='Urgent Request Outcome']/ancestor::td[1]/following-sibling::td/span");
    public static By serviceDetialsAnticipatedTreatmentStartDateDataField = By.xpath("//label[text()='Anticipated Treatment Start Date']/ancestor::td[1]/following-sibling::td/span");
    public static By authorizationNumber = By.xpath("//td[@class='approvedDetails']//td[contains(.,'Request Number') or contains(.,'Authorization Number')]/following-sibling::td[1]");
    public static By authorizationStatus = By.xpath("//td[@class='approvedDetails']//td[contains(.,'Request Status') or contains(.,'Authorization Status')]/following-sibling::td[1]");
    public static By authorizationStartDate = By.xpath("//td[@class='approvedDetails']//td[contains(.,'Request Start Date') or contains(.,'Authorization Start Date')]/following-sibling::td[1]");
    public static By authorizationEndDate = By.xpath("//td[@class='approvedDetails']//td[contains(.,'Request End Date') or contains(.,'Authorization End Date')]/following-sibling::td[1]");
    public static By otherDescriptionText = By.xpath("//label[text()='Other Description']/ancestor::td[1]/following-sibling::td");
    public static By primaryCancer = By.xpath("//table[@id='clinicalDetailsSection']//td[contains(.,'Primary Cancer')]/following-sibling::td[1]");
    public static By authorizationDuration = By.xpath("//div[@class='tk-panl-content']//td[contains(., 'months')]");
    public static By regimenHeader = By.xpath("//*[@id='customRegimenHeaderWrapper']/div[@class='regimen-header']/span");
    public static By regimenTitleHeader = By.xpath("//div[@class='regimen-title regimen-header ng-scope']/span");
    public static By requestJustificationLabel = By.xpath("//td[@ng-if='isRadioPharma']/span/label");
    public static By clinicalDetailsPrimaryCancerField = By.xpath("//label[text()='Primary Cancer']/ancestor::td[1]/following-sibling::td");
    public static By clinicalDetailsSupportiveCareField = By.xpath("//label[text()='Supportive Care Only Request']/ancestor::td[1]/following-sibling::td");
    public static By clinicalDetailsChemotherapyClinicalTrialField = By.xpath("//label[text()='Chemotherapy Clinical Trial']/ancestor::td[1]/following-sibling::td/span");

    public static By clinicalDetailsDiseaseStatusField = By.xpath("//label[text()='Has Disease Progressed or Relapsed?']/ancestor::td[1]/following-sibling::td/span");
    public static By clinicalDetailsInitialDateOfProgressionField = By.xpath("//label[text()='Initial Date of Progression']/ancestor::td[1]/following-sibling::td/span");
    public static By clinicalDetailsChangingTreatmentField = By.xpath("//label[text()='Initial or Changing Treatment?']/ancestor::td[1]/following-sibling::td");
    public static By clinicalDetailsDrugType = By.xpath("//label[text()='What is the Drug Type?']/ancestor::td[1]/following-sibling::td");
    public static By clinicalDetailsIsTheFirstLineOfTherapy = By.xpath("//label[text()='Is the 1st line of therapy being given?']/ancestor::td[1]/following-sibling::td/span");
    public static By radioPharmDrug = By.xpath(" //div[@id='customRegimenHeaderWrapper']/div[@class='regimen-header']//span|//div[@id='supportiveDrugSection']/table[@class='wrapper-table detail']//span");
    public static By radioPharmHeader = By.xpath("//*[@id='supportiveDrugSection']//*[@class='subsection-header']/span | //*[@id='regimenSection']//*[@class='subsection-header']/span");
    public static By TrialName = By.xpath("//table[@id='clinicalDetailsSection']/tbody/td[6]/td[2]/span");
    public static By TrialPhase = By.xpath("//table[@id='clinicalDetailsSection']/tbody/td[7]/td[2]/span");

    public static By regimenreasonLabel = By.xpath("//td[text()='Reason for choosing this regimen']/../td[2]");

    //Locators--------

    public RequestStatusPage(WebDriver webDriver) {
        this.driver = webDriver;
        utils = BaseCucumber.utils;
        log = Logger.getLogger(this.getClass().getName());
        this.glb = BaseCucumber.gv;
    }


//Methods

    /**
     * Verifying AuthorizationRequestStatus on RequestStatusPage
     *
     * @param expetedRequestStatusMessage
     */
    public void verifyAuthorizationRequestStatus(String expetedRequestStatusMessage) {
        By requestStatusMessage = By.xpath("//span[contains(text(),'" + expetedRequestStatusMessage + "')]");
        TestUtils.scrollToElement(driver, requestStatusMessage);
        TestUtils.waitElement(driver, requestStatusMessage);
        TestUtils.demoBreakPoint(scenario, driver, "Request Status Page");
        String actualRequestStatusMessage = driver.findElement(requestStatusMessage).getText();
        log.warn("verifying Authorization Request Status");
        Assert.assertTrue("authorization request status is not matching with actual authorization request status",
                expetedRequestStatusMessage.equals(actualRequestStatusMessage));
    }

    /**
     * verifying Anticipated Treatment Start Date on RequestStatusPage
     */
    public void verifyAnticipatedTreatmentStartDate() {
        log.warn("verifying Anticipated Treatment Start Date in request status page");
        String actualAnticipatedTreatmentStartDate = driver.findElement(serviceDetialsAnticipatedTreatmentStartDateDataField).getText();
        Assert.assertTrue("AnticipatedTreatmentStartDate does not match with given date.",
                actualAnticipatedTreatmentStartDate.equals(DateUtils.mmDdYyyy()));
    }

    /**
     * verifying Is It An UrgentRequest label and Text on RequestStatusPage
     *
     * @param expectedUrgentRequestValue
     */
    public void verifyIsItAnUrgentRequest(String expectedUrgentRequestValue) {
        log.warn("verifying Urgent Request in request status page");
        TestUtils.highlightElement(driver, urgentRequestText);
        String actualUrgentRequestValue = driver.findElement(urgentRequestText).getText();
        Assert.assertTrue("Urgent Request Value does not match with given value.",
                actualUrgentRequestValue.equals(expectedUrgentRequestValue));
    }

    /**
     * verifying Is It An UrgentRequestOutcome label and Text on RequestStatusPage
     *
     * @param expectedUrgentRequestOutcomeValue
     */
    public void verifyIsItAnUrgentRequestOutcome(String expectedUrgentRequestOutcomeValue) {
        log.warn("verifying Urgent Request OutCome in request status page");
        TestUtils.highlightElement(driver, urgentRequestOutcomeText);
        String actualUrgentRequestOutcomeValue = driver.findElement(urgentRequestOutcomeText).getText();
        Assert.assertTrue("Urgent Request Outcome Value does not match with given value.",
                actualUrgentRequestOutcomeValue.equals(expectedUrgentRequestOutcomeValue));
    }

    /**
     * Store Request Number on RequestStatusPage
     */
    public void storeAuthNumber() {
        log.warn("Storing Authorization Number on Request Status Page");
        TestUtils.wait(3);
        glb.setRequestNumber(getAuthNumber());
        log.warn("Authorization Number is " + glb.getRequestNumber());
    }

    /**
     * Get Authorization Number on Request Status Page
     *
     * @return
     */
    public String getAuthNumber() {
        log.warn("Get Authorization Number on Request Status Page");
        TestUtils.wait(3);
        return driver.findElement(authorizationNumber).getText();

    }

    /**
     * Verifying End Date is not present on RequestStatusPage
     */
    public void verifyEndDateHidden() {
        log.warn("Verifying End date is not present");
        Assert.assertFalse("End date is displayed", driver.getPageSource().contains("end date"));
    }

    /**
     * Verifying Other decription text in request summary page
     *
     * @param expectedDescription
     */
    public void verifyOtherDecription(String expectedDescription) {
        log.warn("verifying Other Decription text in request summary page");
        TestUtils.highlightElement(driver, otherDescriptionText);
        String actualAnticipatedTreatmentStartDate = driver.findElement(otherDescriptionText).getText();
        Assert.assertTrue("AnticipatedTreatmentStartDate does not match with given date.",
                actualAnticipatedTreatmentStartDate.equals(expectedDescription));
    }

    /**
     * @return String: the displayed Authorization Number
     */
    public String getAuthorizationNumber() {
        log.warn("the displayed Authorization Number");
        TestUtils.waitElementVisible(driver, authorizationNumber);
        return driver.findElement(authorizationNumber).getText();
    }

    /**
     * @return String: the displayed Primary Cancer
     */
    public String getCancerType() {
        log.warn("the displayed Primary Cancer");
        return driver.findElement(primaryCancer).getText();
    }

    /**
     * @return String: the displayed Regimen Duration
     */
    public String getAuthorizationDuration() {
        log.warn("the displayed Regimen Duration");
        String text = driver.findElement(authorizationDuration).getText();
        return text.split("\\s+", 2)[0];
    }

    /**
     * @return String: the Calculated Duration: number of months between Start Date and End Date
     */
    public String getCalculatedAuthorizationDuration() {
        log.warn("the Calculated Duration: number of months between Start Date and End Date");
        try {
            TestUtils.waitElementVisible(driver, authorizationStartDate);
            TestUtils.waitElementVisible(driver, authorizationEndDate);

            String sStart = text(driver, authorizationStartDate);
            String sEnd = text(driver, authorizationEndDate);
            ;
            Date dStart = DateUtils.mmDdYyyy(sStart);
            Date dEnd = DateUtils.mmDdYyyy(sEnd);
            int monthsBetween = DateUtils.monthsBetween(dStart, dEnd);
            return "" + monthsBetween;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * verifying Medical Review Request on RequestStatusPage
     *
     * @param medicalReviewReq
     */
    public void verifyMedicalReviewRequest(String medicalReviewReq) {
        log.warn("verifying " + medicalReviewReq + "  Description Text on RequestStatusPage");
        TestUtils.highlightElement(driver, regimenHeader);
        Assert.assertEquals("Regimen header is incorrect", medicalReviewReq, driver.findElement(regimenHeader).getText());
        Assert.assertEquals("Regimen Title header is incorrect", medicalReviewReq, driver.findElement(regimenTitleHeader).getText());
    }

    /**
     * verifying request justification on RequestStatusPage
     *
     * @param requestJustification
     */
    public void verifyRequestJustification(String requestJustification) {
        log.warn("verifying " + requestJustification + "  on RequestStatusPage");
        TestUtils.highlightElement(driver, requestJustificationLabel);
        Assert.assertEquals(requestJustification + " header is incorrect", requestJustification, driver.findElement(requestJustificationLabel).getText().trim());
    }

    /**
     * verifying PrimaryCancer on RequestStatusPage
     *
     * @param expectedPrimaryCancer
     */
    public void verifyPrimaryCancer(String expectedPrimaryCancer) {
        log.warn("verifying " + expectedPrimaryCancer + "  in request summary page");
        String actualPrimaryCancer = driver.findElement(clinicalDetailsPrimaryCancerField).getText();
        Assert.assertTrue(expectedPrimaryCancer + " does not match with given cancer .",
                actualPrimaryCancer.equals(expectedPrimaryCancer));
    }

    /**
     * verifying Supportive Care on RequestStatusPage
     *
     * @param expectedSupportiveCare
     */
    public void verifySupportiveCare(String expectedSupportiveCare) {
        log.warn("verifying " + expectedSupportiveCare + "  in request summary page");
        TestUtils.highlightElement(driver, clinicalDetailsSupportiveCareField);
        String actualSupportiveCare = driver.findElement(clinicalDetailsSupportiveCareField).getText();
        Assert.assertTrue(expectedSupportiveCare + " does not match.",
                actualSupportiveCare.equals(expectedSupportiveCare));
    }

    /**
     * verifying Chemotherapy Clinical Trial on RequestStatusPage
     *
     * @param expectedChemotherapyClinicalTrial
     */
    public void verifyChemotherapyClinicalTrial(String expectedChemotherapyClinicalTrial) {
        log.warn("verifying " + expectedChemotherapyClinicalTrial + "  Clinical Trial in request summary page");
        String actualChemotherapyClinicalTrial = driver.findElement(clinicalDetailsChemotherapyClinicalTrialField).getText();
        Assert.assertTrue(expectedChemotherapyClinicalTrial + " Clinical Triarl does not match with given ClinicalTrial .",
                actualChemotherapyClinicalTrial.equals(expectedChemotherapyClinicalTrial));
    }

    /**
     * verifying Disease Status on RequestStatusPage
     *
     * @param expectedDiseaseStatus
     */
    public void verifyDiseaseStatus(String expectedDiseaseStatus) {
        log.warn("verifying " + expectedDiseaseStatus + "  in request summary page");
        String actualDiseaseStatus = driver.findElement(clinicalDetailsDiseaseStatusField).getText();
        Assert.assertTrue(expectedDiseaseStatus + " Status does not match with given Status .",
                actualDiseaseStatus.equals(expectedDiseaseStatus));
    }

    /**
     * verifying Initial Date Of Progression on RequestStatusPage
     *
     * @param expectedInitialDateOfProgression
     */
    public void verifyInitialDateOfProgression(String expectedInitialDateOfProgression) {
        log.warn("verifying " + expectedInitialDateOfProgression + "  Of Progression in request summary page");
        String actualInitialDateOfProgression = driver.findElement(clinicalDetailsInitialDateOfProgressionField).getText();
        Assert.assertTrue(expectedInitialDateOfProgression + "  does not match with given Date Of Progression .",
                actualInitialDateOfProgression.equals(expectedInitialDateOfProgression));
    }

    /**
     * verifying expected Changing Treatment on RequestStatusPage
     *
     * @param expectedChangingTreatment
     */
    public void verifyChangingTreatment(String expectedChangingTreatment) {
        log.warn("verifying " + expectedChangingTreatment + " in request summary page");
        String actualChangingTreatment = driver.findElement(clinicalDetailsChangingTreatmentField).getText();
        Assert.assertTrue(expectedChangingTreatment + " does not match with given Treatment .",
                actualChangingTreatment.equals(expectedChangingTreatment));
    }

    /**
     * verifying expected Changing Treatment Justification on RequestStatusPage
     *
     * @param expectedChangingTreatmentJustification
     */
    public void verifyChangingTreatmentJustification(String expectedChangingTreatmentJustification) {
        log.warn("verifying " + expectedChangingTreatmentJustification + " in request summary page");
        Assert.assertTrue(expectedChangingTreatmentJustification + " does not match with given Justification .",
                TestUtils.isElementPresent(driver, By.xpath("//label[text()='Changing Treatment Justification']/ancestor::td[1]/following-sibling::td/div/span[text() = '" + expectedChangingTreatmentJustification + "']")));
        TestUtils.highlightElement(driver, By.xpath("//label[text()='Changing Treatment Justification']/ancestor::td[1]/following-sibling::td/div/span[text() = '" + expectedChangingTreatmentJustification + "']"));
    }

    /**
     * verifying label on RequestStatusPage
     *
     * @param label
     */
    public void verifyLabel(String label) {
        log.warn("verifying " + label + " in request summary page");
        Assert.assertTrue(label + "not visible in request status page",
                TestUtils.isElementPresent(driver, By.xpath("//label[contains(text(),'" + label + "')]")));
        TestUtils.highlightElement(driver, By.xpath("//label[contains(text(),'" + label + "')]"));

    }

    /**
     * verifying expected Drug Type on RequestStatusPage
     *
     * @param expectedDrugType
     */
    public void verifyDrugType(String expectedDrugType) {
        log.warn("verifying Drug Type in request summary page");
        String actualChangingTreatment = driver.findElement(clinicalDetailsDrugType).getText();
        Assert.assertTrue("Drug Type does not match with given Treatment .", actualChangingTreatment.equals(expectedDrugType));
        TestUtils.highlightElement(driver, clinicalDetailsDrugType);
    }

    /**
     * verifying expected IsTheFirstLineOfTherapy on RequestStatusPage
     *
     * @param expectedLineOfTherapy
     */
    public void verifyIsTheFirstLineOfTherapy(String expectedLineOfTherapy) {
        log.warn("verifying Changing Treatment in request summary page");
        TestUtils.highlightElement(driver, clinicalDetailsIsTheFirstLineOfTherapy);
        String actualChangingTreatment = driver.findElement(clinicalDetailsIsTheFirstLineOfTherapy).getText();
        Assert.assertTrue("Line Of Therapy does not match with given Treatment .", actualChangingTreatment.equals(expectedLineOfTherapy));

    }

    /**
     * verifying Radiopharmaceutical Drug on RequestStatusPage
     *
     * @param drug
     */
    public void verifyRadiopharmaceuticalDrug(String drug) {
        log.warn("verifying Radiopharmaceutical Drug in request summary page");
        TestUtils.highlightElement(driver, By.xpath("//*[@class='panelTable ng-scope']//span[contains(text(),'" + drug + "')]"));
        Assert.assertTrue("Radiopharmaceutical Drug does not match.", TestUtils.isElementPresent(driver, By.xpath("//*[@class='panelTable ng-scope']//span[contains(text(),'" + drug + "')]")));

    }

    /**
     * verifying Therapeutic Radiopharmaceutical Under Clinical Status on RequestStatusPage
     *
     * @param header
     */
    public void verifyTherapeuticRadiopharmaceuticalUnderClinicalStatus(String header) {
        log.warn("verifying Radiopharmaceutical Header in request summary page");
        String actualChangingTreatment = driver.findElement(radioPharmHeader).getText();
        Assert.assertTrue("Radiopharmaceutical Header Drug does not match.", actualChangingTreatment.contains(header));
        TestUtils.highlightElement(driver, radioPharmHeader);
    }

    /**
     * verifying Radiopharmaceutical Drug Name Under Therapeutic Radiopharmaceuticals on RequestStatusPage
     *
     * @param drug
     */
    public void verifyRadiopharmaceuticalDrugNameUnderTherapeuticRadiopharmaceutical(String drug) {
        log.warn("verifying Radiopharmaceutical Drug Under Therapeutic Radiopharmaceutical in request summary page");
        String actualChangingTreatment = driver.findElement(radioPharmDrug).getText();
        Assert.assertTrue("Radiopharmaceutical Drug does not match.", actualChangingTreatment.equals(drug));
        TestUtils.highlightElement(driver, radioPharmDrug);
    }

    /**
     * Verifying Clinical Trial Name and Phase values in Confirmation Page
     *
     * @param expectedClinicalTrialName
     * @param expectedClinicalTrialPhase
     */
    public void verifyClinicalTrialNameandPhase(String expectedClinicalTrialName, String expectedClinicalTrialPhase) {
        log.warn("verifying Clinical Trial Name and Phase values in Confirmation Page");
        String actualTrialName = driver.findElement(TrialName).getText();
        String actualTrialPhase = driver.findElement(TrialPhase).getText();
        Assert.assertTrue("Clinical Trial Name doesn't match with one in Request Details screen.",
                actualTrialName.equals(expectedClinicalTrialName));
        Assert.assertTrue("Clinical Trial Phase doesn't match with one in Request Details screen.",
                actualTrialPhase.equals(expectedClinicalTrialPhase));

    }

    /**
     * User verifies as per given table
     *
     * @param expected
     * @param actualFromUI
     * @param label
     */
    public void verifyAsperTable(String expected, String actualFromUI, String label) {
        log.warn("verifying" + label + " value in UI");
        Assert.assertTrue(label + "expected value doesn't match with UI",
                expected.equals(actualFromUI));
    }


    /**
     * verifying regimen reason on RequestSummaryPage
     *
     * @param regimenreason
     */
    public void verifyRegimenreason(String regimenreason) {
        log.warn("verifying regimen reason on Request Status Page");

        String actualRegimenReason = driver.findElement(regimenreasonLabel).getText();
        Assert.assertTrue("Regimen Reason for choosing other than pathway regimen is not passed to Request Status Page",
                actualRegimenReason.equals(regimenreason));
    }

}