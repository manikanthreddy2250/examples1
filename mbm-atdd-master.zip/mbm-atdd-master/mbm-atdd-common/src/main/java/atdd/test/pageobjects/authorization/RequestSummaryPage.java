package atdd.test.pageobjects.authorization;


import atdd.test.shared.BaseCucumber;
import atdd.utils.DateUtils;
import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import java.util.*;

import static org.openqa.selenium.By.cssSelector;


public class RequestSummaryPage {

    Logger log;
    private WebDriver driver;
    private TestUtils utils;

    //Locators--------
    public static By submitButton = cssSelector("[id='requestSummaryPanelId'] input[value='Submit']");
    public static By serviceDetialsAnticipatedTreatmentStartDateDataField = By.xpath("//label[text()='Anticipated Treatment Start Date']/ancestor::td[1]/following-sibling::td/span");
    public static By urgentRequestText = By.xpath("//label[text()='Is it an Urgent Request?']/ancestor::td[1]/following-sibling::td/span");
    public static By urgentRequestOutcomeText = By.xpath("//label[text()='Urgent Request Outcome']/ancestor::td[1]/following-sibling::td/span");
    public static By otherDescriptionText = By.xpath("//label[text()='Other Description']/ancestor::td[1]/following-sibling::td");
    public static By regimenHeader = By.xpath("//*[@id='customRegimenHeaderWrapper']/div[@class='regimen-header']/span");
    public static By requestJustificationLabel = By.xpath("//td[@ng-if='isRadioPharma']/span/label");
    public static By clinicalDetailsPrimaryCancerField = By.xpath("//label[text()='Primary Cancer']/ancestor::td[1]/following-sibling::td");
    public static By clinicalDetailsSupportiveCareField = By.xpath("//label[text()='Supportive Care Only Request']/ancestor::td[1]/following-sibling::td");
    public static By clinicalDetailsChemotherapyClinicalTrialField = By.xpath("//label[text()='Chemotherapy Clinical Trial']/ancestor::td[1]/following-sibling::td/span");
    public static By clinicalDetailsDiseaseStatusField = By.xpath("//label[text()='Has Disease Progressed or Relapsed?']/ancestor::td[1]/following-sibling::td/span");
    public static By clinicalDetailsInitialDateOfProgressionField = By.xpath("//label[text()='Initial Date of Progression']/ancestor::td[1]/following-sibling::td/span");
    public static By clinicalDetailsChangingTreatmentField = By.xpath("//label[text()='Initial or Changing Treatment?']/ancestor::td[1]/following-sibling::td");
    public static By clinicalDetailsDrugType = By.xpath("//label[text()='What is the Drug Type?']/ancestor::td[1]/following-sibling::td");
    public static By clinicalDetailsIsTheFirstLineOfTherapy = By.xpath("//label[text()='Is the 1st line of therapy being given?']/ancestor::td[1]/following-sibling::td/span");
    public static By radioPharmDrug = By.xpath(" //div[@id='customRegimenHeaderWrapper']/div[@class='regimen-header']//span|//div[@id='supportiveDrugSection']/table[@class='wrapper-table detail']//span");
    public static By radioPharmHeader = By.xpath("//*[@id='supportiveDrugSection']//*[@class='subsection-header']/span | //*[@id='regimenSection']//*[@class='subsection-header']/span");
    public static By heightRequestSummary = By.xpath("//label[text()='Height of the Patient']/ancestor::td[1]/following-sibling::td/div");
    public static By TrialName = By.xpath("//table[@id='clinicalDetailsSection']/tbody/td[6]/td[2]/span");
    public static By TrialPhase = By.xpath("//table[@id='clinicalDetailsSection']/tbody/td[7]/td[2]/span");
    public static By servicingProvider = By.xpath("//*[text()='Servicing Provider/Pharmacy']");

    public static By regimenreasonLabel = By.xpath("//td[text()='Reason for choosing this regimen']/../td[2]");
    public static By dosageBillingUnits = By.xpath("//*[@id='regimenSection']//*[@class='drugDosageGrid']/span");
    public static By roundedDosageValue =  By.xpath("//*[text()='roundedDosageValue/regimenSection']");
    public static By CFMSEditDetails =  By.xpath("//span[contains(text(),'Current Functional Measure Scores')]/following-sibling::span");
    public static By autoApprovedosageBillingGrid = By.xpath("//th[@ng-if='roundingInd'][contains(text(),'Auto-Approvable Dosage and Billing Units')]");
    public static By autoApprovedosageUnits = By.xpath("//table[@class='drugDosageGrid']//tr[1]/td[7]");

    //Locators--------

    public RequestSummaryPage(WebDriver webDriver) {
        this.driver = webDriver;
        utils = BaseCucumber.utils;
        log = Logger.getLogger(this.getClass().getName());
    }


    //Methods

    /**
     * Clicking Edit Details Button on Current Functional Measure Scores section in RequestSummaryPage
     */
    public void clickCFMSEditDetails() {
        TestUtils.wait(2);
        log.warn("Click CFMS Edit Details\n");
        TestUtils.waitElementVisible(driver, CFMSEditDetails);
        TestUtils.safeClick(driver, CFMSEditDetails);
    }
    /**
     * Clicking Submit BUtton on RequestSummaryPage
     */
    public void clickSubmitButton() {
        TestUtils.wait(2);
        log.warn("Click Submit Button\n");
        //  TestUtils.wait(5);
        TestUtils.waitElementVisible(driver, submitButton);
        TestUtils.safeClick(driver, submitButton);
        TestUtils.wait(2);
    }

    /**
     * verifying Anticipated Treatment Start Date on RequestSummaryPage
     */
    public void verifyAnticipatedTreatmentStartDate() {
        log.warn("verifying Anticipated Treatment Start Date in request summary page");
        String actualAnticipatedTreatmentStartDate = driver.findElement(serviceDetialsAnticipatedTreatmentStartDateDataField).getText();
        TestUtils.wait(2);
        Assert.assertTrue("AnticipatedTreatmentStartDate does not match with given date.",
                actualAnticipatedTreatmentStartDate.equals(DateUtils.mmDdYyyy()));
    }

    /**
     * verifying Is It An UrgentRequest Text on RequestSummaryPage
     *
     * @param expectedUrgentRequestValue
     */
    public void verifyIsItAnUrgentRequest(String expectedUrgentRequestValue) {
        log.warn("verifying Urgent Requestin request summary page");
        TestUtils.highlightElement(driver, urgentRequestText);
        String actualUrgentRequestValue = driver.findElement(urgentRequestText).getText();
        Assert.assertTrue("Urgent Request Value does not match with given value.",
                actualUrgentRequestValue.equals(expectedUrgentRequestValue));
    }

    /**
     * verifying Is It An UrgentRequestOutcome Text on RequestSummaryPage
     *
     * @param expectedUrgentRequestOutcomeValue
     */
    public void verifyIsItAnUrgentRequestOutcome(String expectedUrgentRequestOutcomeValue) {
        log.warn("verifying Urgent Request OutCome in request summary page");
        TestUtils.highlightElement(driver, urgentRequestOutcomeText);

        String actualUrgentRequestOutcomeValue = driver.findElement(urgentRequestOutcomeText).getText();
        Assert.assertTrue("Urgent Request Outcome Value does not match with given value.",
                actualUrgentRequestOutcomeValue.equals(expectedUrgentRequestOutcomeValue));
    }

    /**
     * verifying Other Description Text on RequestSummaryPage
     *
     * @param expectedDescription
     */
    public void verifyOtherDecription(String expectedDescription) {
        log.warn("verifying Other Decription text in request summary page");
        TestUtils.highlightElement(driver, otherDescriptionText);
        String actualAnticipatedTreatmentStartDate = driver.findElement(otherDescriptionText).getText();
        Assert.assertTrue("AnticipatedTreatmentStartDate does not match with given date.",
                actualAnticipatedTreatmentStartDate.equals(expectedDescription));
    }

    /**
     * verifying request justification on RequestSummaryPage
     *
     * @param requestJustification
     */
    public void verifyRequestJustification(String requestJustification) {
        log.warn("verifying request justification on RequestSummaryPage");
        TestUtils.highlightElement(driver, requestJustificationLabel);
        Assert.assertEquals("Regimen header is incorrect", requestJustification, driver.findElement(requestJustificationLabel).getText().trim());
    }

    /**
     * verifying regimen reason on RequestSummaryPage
     *
     * @param regimenreason
     */
    public void verifyRegimenreason(String regimenreason) {
        TestUtils.wait(5);
        log.warn("verifying regimen reason on Request Summary Page");

        String actualRegimenReason = driver.findElement(regimenreasonLabel).getText();
        Assert.assertTrue("Regimen Reason for choosing other than pathway regimen is not passed to Request Summary Page",
                actualRegimenReason.equals(regimenreason));
    }

    /**
     * Check that element with Text
     *
     * @param txt
     */
    public void checkRequiredElementByText(String txt) {
        log.warn("verifying required mark is present .");
        By elementTxt = By.xpath("(//*[contains(text(),'" + txt + "')])[2]");
        Assert.assertTrue("Element with text " + txt + " is NOT visible. ", TestUtils.isElementPresent(driver, elementTxt));
        TestUtils.highlightElement(driver, elementTxt);
    }


    /**
     * verifying PrimaryCancer on RequestSummaryPage
     *
     * @param expectedPrimaryCancer
     */
    public void verifyPrimaryCancer(String expectedPrimaryCancer) {
        log.warn("verifying PrimaryCancer in request summary page");
        String actualPrimaryCancer = driver.findElement(clinicalDetailsPrimaryCancerField).getText();
        Assert.assertTrue("PrimaryCancer does not match with given cancer .",
                actualPrimaryCancer.equals(expectedPrimaryCancer));
    }

    /**
     * verifying Supportive Care on RequestSummaryPage
     *
     * @param expectedSupportiveCare
     */
    public void verifySupportiveCare(String expectedSupportiveCare) {
        log.warn("verifying SupportiveCare in request summary page");
        String actualSupportiveCare = driver.findElement(clinicalDetailsSupportiveCareField).getText();
        Assert.assertTrue("SupportiveCare does not match.",
                actualSupportiveCare.equals(expectedSupportiveCare));
    }

    /**
     * verifying Chemotherapy Clinical Trial on RequestSummaryPage
     *
     * @param expectedChemotherapyClinicalTrial
     */
    public void verifyChemotherapyClinicalTrial(String expectedChemotherapyClinicalTrial) {
        log.warn("verifying Chemotherapy Clinical Trial in request summary page");
        String actualChemotherapyClinicalTrial = driver.findElement(clinicalDetailsChemotherapyClinicalTrialField).getText();
        Assert.assertTrue("Chemotherapy Clinical Triarl does not match with given ClinicalTrial .",
                actualChemotherapyClinicalTrial.equals(expectedChemotherapyClinicalTrial));
    }

    /**
     * verifying Disease Status on RequestSummaryPage
     *
     * @param expectedDiseaseStatus
     */
    public void verifyDiseaseStatus(String expectedDiseaseStatus) {
        log.warn("verifying Disease Status in request summary page");
        String actualDiseaseStatus = driver.findElement(clinicalDetailsDiseaseStatusField).getText();
        Assert.assertTrue("Disease Status does not match with given Status .",
                actualDiseaseStatus.equals(expectedDiseaseStatus));
    }

    /**
     * verifying Initial Date Of Progression on RequestSummaryPage
     *
     * @param expectedInitialDateOfProgression
     */
    public void verifyInitialDateOfProgression(String expectedInitialDateOfProgression) {
        log.warn("verifying Initial Date Of Progression in request summary page");
        String actualInitialDateOfProgression = driver.findElement(clinicalDetailsInitialDateOfProgressionField).getText();
        Assert.assertTrue("InitialDateOfProgression does not match with given Date Of Progression .",
                actualInitialDateOfProgression.equals(expectedInitialDateOfProgression));
    }

    /**
     * verifying expected Changing Treatment on RequestSummaryPage
     *
     * @param expectedChangingTreatment
     */
    public void verifyChangingTreatment(String expectedChangingTreatment) {
        log.warn("verifying Changing Treatment in request summary page");
        String actualChangingTreatment = driver.findElement(clinicalDetailsChangingTreatmentField).getText();
        Assert.assertTrue("Changing Treatment does not match with given Treatment .",
                actualChangingTreatment.equals(expectedChangingTreatment));
    }

    /**
     * verifying expected Changing Treatment Justification on RequestSummaryPage
     *
     * @param expectedChangingTreatmentJustification
     */
    public void verifyChangingTreatmentJustification(String expectedChangingTreatmentJustification) {
        log.warn("verifying PrimaryCancer in request summary page");
        Assert.assertTrue("PrimaryCancer does not match with given cancer .",
                TestUtils.isElementPresent(driver, By.xpath("//label[text()='Changing Treatment Justification']/ancestor::td[1]/following-sibling::td/div/span[text() = '" + expectedChangingTreatmentJustification + "']")));
        TestUtils.highlightElement(driver, By.xpath("//label[text()='Changing Treatment Justification']/ancestor::td[1]/following-sibling::td/div/span[text() = '" + expectedChangingTreatmentJustification + "']"));
    }

    /**
     * verifying label on RequestSummaryPage
     *
     * @param label
     */
    public void verifyLabel(String label) {
        log.warn("verifying " + label + " in request summary page");
        Assert.assertTrue(label + "not visible in request status page",
                TestUtils.isElementPresent(driver, By.xpath("//label[contains(text(),'" + label + "')]")));
        TestUtils.highlightElement(driver, By.xpath("//label[contains(text(),'" + label + "')]"));

    }

    /**
     * verifying expected Drug Type on RequestSummaryPage
     *
     * @param expectedDrugType
     */
    public void verifyDrugType(String expectedDrugType) {
        log.warn("verifying Drug Type in request summary page");
        String actualChangingTreatment = driver.findElement(clinicalDetailsDrugType).getText();
        Assert.assertTrue("Drug Type does not match with given Treatment .", actualChangingTreatment.equals(expectedDrugType));
        TestUtils.highlightElement(driver, clinicalDetailsDrugType);
    }

    /**
     * verifying expected IsTheFirstLineOfTherapy on RequestSummaryPage
     *
     * @param expectedLineOfTherapy
     */
    public void verifyIsTheFirstLineOfTherapy(String expectedLineOfTherapy) {
        log.warn("verifying Changing Treatment in request summary page");
        String actualChangingTreatment = driver.findElement(clinicalDetailsIsTheFirstLineOfTherapy).getText();
        Assert.assertTrue("Line Of Therapy does not match with given Treatment .", actualChangingTreatment.equals(expectedLineOfTherapy));
        TestUtils.highlightElement(driver, clinicalDetailsIsTheFirstLineOfTherapy);
    }

    /**
     * verifying Therapeutic Radiopharmaceutical Under Clinical Status on RequestSummaryPage
     *
     * @param header
     */
    public void verifyTherapeuticRadiopharmaceuticalUnderClinicalStatus(String header) {
        log.warn("verifying Radiopharmaceutical Header in request summary page");
        String actualChangingTreatment = driver.findElement(radioPharmHeader).getText();
        Assert.assertTrue("Radiopharmaceutical Header Drug does not match.", actualChangingTreatment.contains(header));
        TestUtils.highlightElement(driver, radioPharmHeader);
    }

    /**
     * verifying Radiopharmaceutical Drug Name Under Therapeutic Radiopharmaceuticals on RequestSummaryPage
     *
     * @param drug
     */
    public void verifyRadiopharmaceuticalDrugNameUnderTherapeuticRadiopharmaceutical(String drug) {
        log.warn("verifying Radiopharmaceutical Drug Under Therapeutic Radiopharmaceutical in request summary page");
        String actualChangingTreatment = driver.findElement(radioPharmDrug).getText();
        Assert.assertTrue("Radiopharmaceutical Drug does not match.", actualChangingTreatment.equals(drug));
        TestUtils.highlightElement(driver, radioPharmDrug);
    }

    /**
     * verifying Height Under Therapeutic Radiopharmaceuticals on RequestSummaryPage
     *
     * @param height
     */
    public void verifyHeightOnRequestSummary(String height) {
        log.warn("verifying height in the request summary page");
        String actualHeight = driver.findElement(heightRequestSummary).getText();
        String expectedHeight = height + " in";
        Assert.assertEquals(expectedHeight, actualHeight);
        TestUtils.highlightElement(driver, heightRequestSummary);
    }

    /**
     * verifying clinical trial name on Request details Page
     *
     * @param ClinicalTrialName
     */
    public void verifytheClinicalTrialName(String ClinicalTrialName) {
        log.warn("verifying Clinical Trial Name in request summary page");
        String ClinicalTrial = driver.findElement(TrialName).getText();
        Assert.assertTrue("Clinical Trial Name doesnt match with one in Request Details Page",
                ClinicalTrialName.equals(ClinicalTrial));
    }

    /**
     * verifying clinical trial phase on Request details Page
     *
     * @param ClinicalTrialPhase
     */
    public void verifytheClinicalTrialPhase(String ClinicalTrialPhase) {
        log.warn("verifying Clinical Trial Phase in request summary page");
        String ClinicalPhase = driver.findElement(TrialPhase).getText();
        Assert.assertTrue("Clinical Trial Phase doesnt match with one in Request Details Page",
                ClinicalPhase.equals(ClinicalTrialPhase));
    }

    /**
     * verifying clinical trial phase on Request details Page
     *
     * @param header
     */
    public void verifytheServicingProviderPharmacyHeader(String header) {
        log.warn("verifying Servicing Provider/Pharmacy Header in request summary page");
        TestUtils.waitElementVisible(driver, servicingProvider);
        String servicingProviderOrPharmmacy = TestUtils.text(driver, servicingProvider);
        Assert.assertTrue("Doesnt match provider pharmacy header with one in Request Details Page", servicingProviderOrPharmmacy.equals(header));
    }


    /**
     * verifying Dosage & Billing Units label on RequestSummaryPage
     *
     *
     */
    public void verifyDosage_BillableUnits(){

        log.warn("Verifying Dosage & Billing Units on Request Summary Page");
        TestUtils.waitElementVisible(driver, dosageBillingUnits);
        Assert.assertTrue("Dosage & Billing Units doesn't exist on Request Summary Page", TestUtils.isElementVisible(driver, dosageBillingUnits));

    }


    /**
     * verifying Dosage & Billing Units label on RequestStatusPage
     *
     *
     */
    public void verifyAutoApprovalDosage(String dosage) {

        log.warn("Verifying Dosage & Billing Units on Request Status Page");
        TestUtils.waitElementVisible(driver, autoApprovedosageBillingGrid);
        int i = 1;
        Boolean flag=false;
      //  By autoApprovedosageUnits = By.xpath("//table[@class='drugDosageGrid']//tr[" + i + "]/td[7]");
        //Assert.assertTrue("Auto-Approvable Dosage and Billing Units Grid doesn't exist on Request Status Page", TestUtils.isElementVisible(driver, autoApprovedosageBillingGrid));
        List<WebElement> elements = driver.findElements(By.xpath("//*[@class='request-summary-regimen-view-wrapper']//table[2]//tbody//tr"));
        TestUtils.waitElementVisible(driver,autoApprovedosageUnits);
        for (int j = 1; j <= elements.size(); j++) {
          String dosagevalue = driver.findElement(By.xpath("//table[@class='drugDosageGrid']//tr["+j+"]/td[7]")).getText();
            if (dosagevalue.equals(dosage)) {
                flag=true;
                System.out.println("Dosage value given and Dosage value on the Request Status page match");
                break;
            }
            else
            {
                flag=false;
            }

        }
        if(flag==false)
        {
            Assert.fail("Dosage did not match on the Request Status page");
        }
    }
}
