package atdd.test.pageobjects.authorization;


import atdd.test.shared.BaseCucumber;
import atdd.test.shared.Globals;
import atdd.utils.MBM;
import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.Map;


public class RequestingProviderPage {

    Logger log;
    private WebDriver driver;
    private TestUtils utils;
    private String owner;

    //Locators--------
    public static By provPhoneNbrTextBox = By.xpath("//input[@id='requestingProviderPhoneNumber']");
    public static By provFaxNbrTextBox = By.xpath("//input[@id='requestingProviderFaxNumber']");
    public static By contactPhoneNbrTextBox = By.xpath("//input[@id='followupContactPhoneNumber']");
    public static By contactFaxNbrTextBox = By.xpath("//input[@id='followupContactFaxNumber']");
    public static By continueButton = By.xpath("//input[contains(@class, 'continue-button ')]");
    public static By selectaRequestingProvider = By.xpath("(//*[@id='select-a-requesting-provider-btn'] | //a[contains(.,'Change provider')])[1]");
    public static By selectaRequestingProviderBtn = By.xpath("//input[@id='select-a-requesting-provider-btn']");
    public static By addServicingProvider = By.xpath("//input[@value='Add Servicing Provider']");
    //By.cssSelector("[id='requestingProviderPanelIdContent'] input[value='Select a Requesting Provider']");
    public static By saveDraftBtn = By.xpath("//input[contains(@ng-click,'saveDraft')]");
    public static By contactNameTextBox = By.cssSelector("input[ng-model*='contactName']");
    public static By requestingProvider = By.xpath("//*[@id='requestingProviderPanelId']/div[1]/h2/span");
    public static By firstName = By.xpath("//label[contains(text(),'Provider First Name')]/following::td[1]");
    public static By LastName = By.xpath("//label[contains(text(),'Provider Last Name')]/following::td[1]");
    public static By communicationTypeReqdField = By.xpath("//*[@id='requestReceivedBy']");
    public static By providerPointOfContactHeader = By.xpath("//span[@class='inner-table-header ng-binding ng-scope']/h3");
    public static By memberHeaderExpansionIcon = By.xpath("//*[@id='memberHeaderIcon']");
    public static By expandedMemberHeader = By.xpath("//*[@class='memberHeader mh-expanded ng-scope']");
    public static By blockerOverridePopup = By.xpath("//*[@id='globalMessages-description']/span");
    public static By overrideReason = By.xpath("//select[contains(@id,'sharedBOParams-blockerOverrideVO-overrideReasonCode')]");
    public static By overrideContinueButton = By.xpath("//*[@id='blockerOverrideOkayButton']");
    public static By  errorOverridePopup = By.xpath("//*[@id='blockerOverridePopupModelID']//h2"); //By.xpath("//*[@id='requestingProviderPanelIdContent']//input[@ng-disabled ='continueButtonClicked']");
    public static By  notifyPopup = By.xpath("//*[@id='authProviderNotificationPopupModelID']//h2");
    public static By  notifyContinueButton = By.xpath("//*[@ng-click='authNotificationContinue()']");


    Globals gv = BaseCucumber.gv;
    //Locators--------

    public RequestingProviderPage(WebDriver webDriver) {
        driver = webDriver;
        utils = BaseCucumber.utils;
        log = Logger.getLogger(this.getClass().getName());
    }
    //Methods

    /**
     * Clicking Continue Button on RequestingProviderPage
     */
    public void clickSaveDraftButton() {
        log.warn("Clicking Save Draft Button");
        TestUtils.waitElement(driver, saveDraftBtn);
        TestUtils.onMouseHover(driver, saveDraftBtn);
        TestUtils.wait(5);
        TestUtils.highlightElement(driver, saveDraftBtn);
        driver.findElement(saveDraftBtn).click();
        TestUtils.wait(1);
    }

    /**
     * Entering reqProviderPhoneNumberD on RequestingProviderPage
     *
     * @param reqProviderPhoneNumber
     */
    public void enterTextInProvPhoneNbrTextBox(String reqProviderPhoneNumber) {
        log.warn("Entering reqProviderPhoneNumber");
        TestUtils.highlightElement(driver, provPhoneNbrTextBox);
        driver.findElement(provPhoneNbrTextBox).clear();
        driver.findElement(provPhoneNbrTextBox).sendKeys(reqProviderPhoneNumber);
    }

    /**
     * Entering reqProviderFaxNumber on RequestingProviderPage
     *
     * @param reqProviderFaxNumber
     */
    public void enterTextInProvFaxNbrTextBox(String reqProviderFaxNumber) {
        log.warn("Entering reqProviderFaxNumber");
        TestUtils.highlightElement(driver, provFaxNbrTextBox);
        driver.findElement(provFaxNbrTextBox).clear();
        driver.findElement(provFaxNbrTextBox).sendKeys(reqProviderFaxNumber);
    }

    /**
     * Entering contactPersonPhoneNumber on RequestingProviderPage
     *
     * @param contactPersonPhoneNumber
     */
    public void enterTextInContactPhoneNumberTextBox(String contactPersonPhoneNumber) {
        log.warn("Entering contactPersonPhoneNumber");
        TestUtils.waitElement(driver, contactPhoneNbrTextBox);
        driver.findElement(contactPhoneNbrTextBox).clear();
        driver.findElement(contactPhoneNbrTextBox).sendKeys(contactPersonPhoneNumber);
    }

    /**
     * Entering contactPersonfaxNumber on RequestingProviderPage
     *
     * @param contactPersonfaxNumber
     */
    public void enterTextInContactFaxNumberTextBox(String contactPersonfaxNumber) {
        log.warn("Entering contactPersonfaxNumber");
        TestUtils.waitElement(driver, contactFaxNbrTextBox);
        driver.findElement(contactFaxNbrTextBox).clear();
        driver.findElement(contactFaxNbrTextBox).sendKeys(contactPersonfaxNumber);
    }

    /**
     * Clicking Continue Button on RequestingProviderPage
     */
    public void clickContinueButton() {
        log.warn("Clicking Continue Button");
        TestUtils.waitElement(driver, continueButton);
        TestUtils.onMouseHover(driver, continueButton);
        TestUtils.wait(5);
        TestUtils.highlightElement(driver, continueButton);
        driver.findElement(continueButton).click();
        TestUtils.wait(5);
    }

    /**
     * Clicking Select a Requesting Provider on RequestingProviderPage
     */
    public void clickSelectaRequestingProvider() {
        log.warn("Clicking Select a Requesting Provider");
        TestUtils.wait(2);
        TestUtils.waitElementVisible(driver, selectaRequestingProvider);
        TestUtils.click(driver, selectaRequestingProvider);
    }

    /**
     * Entering contactName on RequestingProviderPage
     *
     * @param contactName
     */
    public void enterTextInContactNameTextBox(String contactName) {
        log.warn("Entering contactName");
        TestUtils.highlightElement(driver, contactNameTextBox);
        driver.findElement(contactNameTextBox).clear();
        driver.findElement(contactNameTextBox).sendKeys(contactName);
    }

    /**
     * verifying fields are editable
     */
    public void verifyFieldsAreEditable() {
        Assert.assertTrue("providerphonenumber is not editable", driver.findElement(provPhoneNbrTextBox).isEnabled());
        Assert.assertTrue("providerfaxnumber is not editable", driver.findElement(provFaxNbrTextBox).isEnabled());
        Assert.assertTrue("contactphonenumber is not editable", driver.findElement(contactPhoneNbrTextBox).isEnabled());
        Assert.assertTrue("contactfaxnumber is not editable", driver.findElement(contactFaxNbrTextBox).isEnabled());
        Assert.assertTrue("contact name is not editable", driver.findElement(contactNameTextBox).isEnabled());
    }

    /**
     * User verifies the data on the requesting provider details  as same as the previous authorization
     *
     * @param Tin
     */
    public void verifyDataofRequestingProviderPage(String Tin) {
        String prevTin = gv.getReqProviderTIN();
        Assert.assertEquals("tin is not as previous tin", Tin, prevTin);

    }

    /**
     * Selects fax or phone option in requesting provider page
     *
     * @param opt
     */
    public void selectRequestReceivedBy(String opt) {
        if (null == opt || "-".equals(opt.trim()) || opt.trim().isEmpty() || "empty".equalsIgnoreCase(opt.trim())) {
            return;
        }
        this.driver.findElement(By.xpath("//input[@name='Channel Source Type' and ..='" + opt + "']")).click();
    }

    public void verifyTheValuesOnRequestingProvider(Map<String, String> pf) {
        Assert.assertTrue("First name is not matched", driver.findElement(firstName).getText().equalsIgnoreCase(pf.get(MBM.RPPD_PROVIDER_FIRST_NAME)));
        Assert.assertTrue("Last name is not matched", driver.findElement(LastName).getText().equalsIgnoreCase(pf.get(MBM.RPPD_PROVIDER_LAST_NAME)));
    }

    public void verifyFaxNumberIsNotRequired() {
        String faxnbrrqd = driver.findElement(contactFaxNbrTextBox).getAttribute("required");
        Assert.assertTrue("verify fax number is not required for PH Therapy", faxnbrrqd == null);
    }

    public void verifyChangeProviderIsVisible(Map<String, String> pf) {
        if (pf.get(MBM.USER_TITLE).contains("PAAN")) {
            List<WebElement> listOfElements = driver.findElements(selectaRequestingProvider);
            Assert.assertFalse(listOfElements.size() > 0);
        } else {
            Assert.assertTrue("Verify that change provider button is displayed", driver.findElement(selectaRequestingProvider).isDisplayed());
        }
    }

    public void verifyCommunicationTypeIsNotRequired() {
        List<WebElement> listOfElements = driver.findElements(communicationTypeReqdField);
        Assert.assertFalse(listOfElements.size() > 0);

    }

    public void verifyTextOfPointOfContactHeader(String title) {
        String onpage = driver.findElement(providerPointOfContactHeader).getText();
        Assert.assertEquals(title, onpage);
    }


    /**
     * Clicks onto memberheaderexpansion if the provider is interal ops or admin
     * If in a paan connection, member header expansion does not exist.
     *
     * @param pf
     */
    public void clickOnMemberHeaderExpansion(Map<String, String> pf) {
        log.warn("Expanding Member Header");
        driver.findElement(memberHeaderExpansionIcon).click();
    }


    /**
     * Verifying that member header is not expanded
     */
    public void verifyHeaderIsNotAvailable() {
        List<WebElement> expandedHeader = driver.findElements(expandedMemberHeader);
        Assert.assertFalse("Verifying that member header is not expanded", expandedHeader.size() > 0);
    }

    public void verifyFaxNumberIsRequired() {
        String faxnbrrqd = driver.findElement(contactFaxNbrTextBox).getAttribute("required");
        Assert.assertTrue("verify fax number is not required for PH Therapy", faxnbrrqd.equals("true"));
    }

    public void verifyCommunicationTypeIsDisplayed() {
        List<WebElement> listOfElements = driver.findElements(communicationTypeReqdField);
        Assert.assertTrue(listOfElements.size() > 0);
    }

    public void verifySubInsuranceTypeInHeaderSection() {
        log.warn("verifying Sub Insurance type value  Header in Requesting provider page");
        By subInsuranceTypeXpath = By.xpath("//span[text()='Ins. Sub-Type']//following-sibling ::span[text()='Premium Commercial']");
        Assert.assertTrue(TestUtils.isElementVisible(driver, subInsuranceTypeXpath));
    }

    public void verifyBlockerOverridePopup(Map<String, String> pf) {
        log.warn("Verify Blocker override popup in Requesting provider page");
        if(pf.get(MBM.USER_TITLE).contains("admin")|| pf.get(MBM.USER_TITLE).contains("an operations manager")) {
            TestUtils.waitElementVisible(driver,  errorOverridePopup);
            Assert.assertTrue("Blocker override popup is not displayed", driver.findElement(errorOverridePopup).getText().contains("Blocked Authorization Override"));
        }
        else {
       TestUtils.waitElementVisible(driver, blockerOverridePopup);
            Assert.assertTrue("Blocker override popup is not displayed", driver.findElement(blockerOverridePopup).isDisplayed());
        }
    }

    public void selectBlockeroverrideOption(String reason) {
        log.warn("Selecting Provider Faxed Auth override reason");
        TestUtils.highlightElement(driver, overrideReason);
        TestUtils.waitElement(driver, overrideReason);
        TestUtils.wait(3);
        TestUtils.selectByVisibleText(driver.findElement(overrideReason), reason);
    }

    public void clickOverrideContinueButton()
    {
        log.warn("Clicking on continue button");
        Assert.assertTrue(TestUtils.click(driver, overrideContinueButton));
    }

    public void verifyNotifyPopup()
    {
        log.warn("Checking Notify Popup ");
        TestUtils.waitElementVisible(driver, notifyPopup);
        Assert.assertTrue("Notify popup is not displayed", driver.findElement(notifyPopup).getText().contains("Authorization Not Required"));
        log.warn("Clicking on continue button");
        Assert.assertTrue(TestUtils.click(driver, notifyContinueButton));
    }


    public void verifyRequestingProviderPageisDisplayed() {
        log.warn("Verifying Requesting Provider Page is Displayed");
        Assert.assertTrue(TestUtils.isElementVisible(driver, selectaRequestingProviderBtn));
    }
}

