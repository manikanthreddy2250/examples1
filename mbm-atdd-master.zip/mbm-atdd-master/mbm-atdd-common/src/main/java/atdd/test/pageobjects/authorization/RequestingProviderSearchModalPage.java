package atdd.test.pageobjects.authorization;


import atdd.common.ICondition;
import atdd.test.shared.BaseCucumber;
import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import static org.openqa.selenium.By.cssSelector;

/**
 * Created by pvavilal on 12/5/18.
 */
public class RequestingProviderSearchModalPage {
    private WebDriver driver;
    private TestUtils utils;
    Logger log;

    //Locators--------
    public static By providerPhyscianTab = By.xpath("//tabs//span[text()='Physician']");
    public static By physicianLastName = By.cssSelector("input[ng-model='providerSearchTable.tableFilters.lastName']");
    public static By physicianFirstName = By.cssSelector("input[ng-model='providerSearchTable.tableFilters.firstName']");
    public static By physicianState = By.cssSelector("select[ng-model='providerSearchTable.tableFilters.statePhysician']");
    public static By physicianZip = By.cssSelector("input[id='physicianSearchZIPText']");
    public static By physicianTinNumberTextBox = By.cssSelector("input[ng-model='providerSearchTable.tableFilters.npi']");
    public static By taxID = By.xpath("//input[@id='physicianSearchTINText']");
    public static By searchButton = cssSelector("input[value='Search']");
    public static By firstPhysicianSearchResult = By.xpath("(//input[@name='changeButton'])[1]");
    public static By changeButton = cssSelector("input[value='Change']");
    public static By cancelButton = By.xpath("//input[@id='providerSearchCancelBtn']");
    public static By tinRadioBtn = By.xpath("//input[@id='physicianSearchTypeTINRadio']");
    public static By providerFacilityTab = By.xpath("//tabs//span[text()='Facility']");
    public static By facilityName = By.xpath("//input[@id='facilitySearchNameText']");
    public static By facilityZip = By.xpath("//input[@id='facilitySearchZIPText']");
    public static By facilityState = By.cssSelector("select[ng-model='providerFacilitySearchTable.tableFilters.stateFacility']");
    public static By facilityTaxID = By.xpath("//input[@id='facilitySearchTINText'] |//input[@id='bcbsFacilitySearchTINText']");
    public static By facilityNPI = By.xpath("//input[@id='bcbsFacilitySearchNPIText']");
    public static By firstFacilitySearchResult = By.xpath("//table[@id='providerFacilitySearchTableID']/tbody/tr[1]/td[1]/span/input");
    public static By facilityTinRadioBtn = By.xpath("//input[@id='facilitySearchTypeTINRadio']");
    public static By clearButton = By.xpath("//input[@value='Clear']");
    public static By providerSearchTable = By.xpath("//*[@id='providerSearchTableID']/tfoot");
    public static By contactUsLink = By.xpath("//*[@id='providerSearchTableID']/tfoot/tr/td/a");
public static By npiRegistrySearchButton=By.xpath("//input[@value='NPI National Registry Search']");
    //Locators--------

    public RequestingProviderSearchModalPage(WebDriver webDriver) {
        driver = webDriver;
        utils = BaseCucumber.utils;
        log = Logger.getLogger(this.getClass().getName());
    }

    //Methods

    /**
     * Select TIN and/or NPI radio button on the Provider Search page
     */
    public void selectTINRadioBtn_ChangeProvModal() {
        log.warn("Selecting TIN and/or NPI radio button");
        TestUtils.click(driver, tinRadioBtn);
    }

    /**
     * Select TIN and/or NPI radio button on the Provider Facility Search page
     */
    public void selectTINRadioBtn_FacilitySearchpage() {
        log.warn("Selecting TIN and/or NPI radio button");
        TestUtils.click(driver, facilityTinRadioBtn);
    }

    /**
     * Verifying Provider Physcian Tab On Popup on RequestingProviderSearchModalPage
     *
     * @param Provider
     */
    public void verifyProviderPhyscianTabOnPopup(String Provider) {
        log.warn("Verifying Provider Physcian Tab On Popup ");
        Assert.assertTrue("The Default tab is not Physician",
                driver.findElement(providerPhyscianTab).getText().equalsIgnoreCase(Provider)
                        && driver.findElement(physicianLastName).isDisplayed());
    }

    /**
     * Entering npiNumber on RequestingProviderSearchModalPage
     *
     * @param npiNumber
     */
    public void enterNpiNumberInPhysicianTab(String npiNumber) {
        log.warn("enter the npi number: " + npiNumber);
        TestUtils.input(driver, physicianTinNumberTextBox, npiNumber);
    }


    /**
     * Entering TIN Number on RequestingProviderSearchModalPage
     */
    public void userEntersTINPhys(String tin) {
        log.warn("Enter the TIN: " + tin);
        TestUtils.input(driver, taxID, tin);
    }

    /**
     * Clicking Search Button on RequestingProviderSearchModalPage
     */
    public void clickSearchButton() {
        log.warn("Click Search button on the Provider search modal");
        TestUtils.click(driver, searchButton);
    }

    /**
     * Selecting first Physician search result
     */
    public void selectFirstPhysicianSearchResult() {
        log.warn("Select first record from the Physician npi results grid");
        TestUtils.wait(3);
        TestUtils.click(driver, firstPhysicianSearchResult);
    }

    /**
     * Clicking Change Button on RequestingProviderSearchModalPage
     */
    public void clickChangeButton() {
        log.warn("Click Change button");
        TestUtils.clickUntil(driver, changeButton, new ICondition() {
            @Override
            public boolean evaluate() throws Exception {
                return !TestUtils.isElementVisible(driver, changeButton);
            }
        });
    }

    /**
     * Clicking facility Tab on RequestingProviderSearchModalPage
     */
    public void clickFacilityTab() {
        log.warn("Click Facility tab");
        TestUtils.click(driver, providerFacilityTab);
    }

    /**
     * Entering TIN Number on RequestingProviderSearchModalPage
     */
    public void userEntersTINFacility(String tin) {
        log.warn("Enter the TIN: " + tin);
        TestUtils.input(driver, facilityTaxID, tin);
    }

    /**
     * Entering NPI Number on RequestingProviderSearchModalPage
     */
    public void userEntersNPIFacility(String npi) {
        if (TestUtils.isElementVisible(driver, facilityNPI)) {
            log.warn("Enter the NPI: " + npi);
            TestUtils.input(driver, facilityNPI, npi);
        }
    }


    /**
     * Selecting the first Facility searh result
     */
    public void selectFirstFacilitySearchResult() {
        log.warn("Select first record from the Physician npi results grid");
        TestUtils.click(driver, firstFacilitySearchResult);
    }

    /**
     * Select TIN  radio button on the facility provider Search page
     */
    public void selectTINRadioBtn_ChangefacilityProvModal() {
        log.warn("Selecting TIN and/or NPI radio button");
        TestUtils.wait(3);
        TestUtils.click(driver, facilityTinRadioBtn);
    }

    public void enterLastName(String lastName) {
        log.warn("entering last name");
        driver.findElement(physicianLastName).sendKeys(lastName);
    }

    public void selectState(String state) {
        log.warn("selecting state");
        TestUtils.wait(2);
        TestUtils.select(driver, physicianState, state);
    }

    public void enterFirstName(String firstName) {
        log.warn("entering first name");
        TestUtils.input(driver, physicianFirstName, firstName);

    }

    public void enterPhysicianZip(String zip) {
        log.warn("entering Zip code");
        TestUtils.input(driver, physicianZip, zip);
    }

    public void enterFacilityName(String name) {
        log.warn("entering facility Name ");
        TestUtils.input(driver, facilityName, name);
    }

    public void enterFacilityState(String state) {
        log.warn("entering Zip code");
        TestUtils.select(driver, facilityState, state);
    }

    public void enterFacilityZip(String zip) {
        log.warn("entering Zip code");
        TestUtils.input(driver, facilityZip, zip);
    }

    /**
     * Clicking physcian Tab on RequestingProviderSearchModalPage
     */
    public void clickPhysicianTab() {
        log.warn("Click Physician tab");
        TestUtils.safeClick(driver, providerPhyscianTab);
    }

    /**
     * validating labels onn RequestingProviderSearchModalPage search results table
     */
    public void validateLabelInTable(String label) {
        log.warn("verifing the " + label + "requesting provider search table");
        By searchLabel = By.xpath("//span[contains(text(),'" + label + "')]");
        Assert.assertTrue("label" + label + "is not present", driver.findElement(searchLabel).isDisplayed());
    }


    /**
     * Clicking clear button on RequestingProviderSearchModalPage
     */

    public void clickClearButton() {
        log.warn("clearing the text");
        TestUtils.click(driver, clearButton);
    }

    /**
     * Clicking provider name payer column on RequestingProviderSearchModalPage
     */

    public void validateProviderName(String payer) {
        log.warn("verifying the payer name as" + payer);
        By PayerName = By.xpath("//span[contains(text(),'" + payer + "')]");
        TestUtils.waitElementVisible(driver, PayerName);
        Assert.assertTrue("Payer name is not " + payer, driver.findElement(PayerName).isDisplayed());
    }

    /**
     * verifying No NPI search filed
     */
    public void verifyNoNPISearchField() {
        log.warn("verifying NPI search field is not present");
        Assert.assertFalse("label is not present", TestUtils.isElementVisible(driver, By.xpath("//*[@id='physicianSearchNPITextLabel']")));
    }

    public void clickCancelButton() {
        TestUtils.clickUntil(driver, cancelButton, new ICondition() {
            @Override
            public boolean evaluate() throws Exception {
                return !TestUtils.isElementVisible(driver, cancelButton);
            }
        });

    }


    public boolean verifySearchModalProviderNotFoundMessage(String message) {

        String expectedMessage = message;
        String actualMessage = this.driver.findElement(providerSearchTable).getText();
        //verify Href
        return expectedMessage.equals(actualMessage);

    }

    public void clickOnContactUs() {
        Assert.assertEquals("https://mbmnow-int.optum.com/ocm/app/contactUs", driver.findElement(contactUsLink).getAttribute("href"));
        TestUtils.click(driver, contactUsLink);
    }


    public void clickNpiRegistrySearchButton() {
        TestUtils.click(driver,npiRegistrySearchButton);

    }
}
