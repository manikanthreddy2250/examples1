package atdd.test.pageobjects.authorization;

import atdd.common.ICondition;
import atdd.test.shared.BaseCucumber;
import atdd.utils.MBM;
import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.Map;

import static org.openqa.selenium.By.cssSelector;

/**
 * Created by pvavilal on 12/5/18.
 */
public class ServicingProviderPage {

    private WebDriver driver;
    private TestUtils utils;
    Logger log;
    public static final String OONCheckMessage = "This provider is out-of-network for this member's benefit. Please contact the number on the back of the member's card for assistance in locating an in-network provider.";
    public static final String NNOONCheckMessage = "Please contact 1-855-895-1682 for assistance in locating an in-network provider.";

    //Locators--------
    public static By yesButton = By.xpath("//input[@ng-click='transferRequestingProvider()']");
    public static By continueButton = cssSelector("[id='servicingProviderPanelId'] input[value='Continue']");
    public static By addServicingProvider = By.xpath("//input[contains(@ng-click, 'addServicingProvider')]");
    public static By addServicingProviderOrPharmacy = By.xpath("//input[@value='Add Servicing Provider/Pharmacy']");
    public static By tinRadioBtn = By.xpath("//input[@id='facilitySearchTypeTINRadio']");
    public static By facilitySearchTIN = By.xpath("//input[@id='facilitySearchTINText']");
    public static By OONMessage = By.xpath("//span[@id='globalMessages-description']");
    public static By providerTIN = By.xpath("//label[text()='Provider TIN']");
    public static By providerRiBlockPopup = By.xpath("(//span[@id='globalMessages-description'])/span");
    public static By providerRiBlockPopupOnSPS = By.xpath("//span[contains(@id, 'popupGlobalMessages')]/span");

    //New Grid for Specialty Pharma
    public static By newDrugSupplierGrid = By.xpath("//div[@class='panel-message ng-binding']/following::div[@class='table']");
    public static By sameAsTheRequestingProviderRadioButton = By.id("vm-selection-0");
    public static By searchOtherProviderRadioButton = By.id("vm-selection-1");
    public static By selectPreferredSupplierRadioButton = By.id("vm-selection-2");
    public static By selectPreferredSupplierDropdown = By.xpath("//select[contains(@id,'CreateAuth.MsoServicingProvider.')]");
    public static By  errorOverridePopup = By.xpath("//*[@id='blockerOverridePopupModelID']//h2"); //By.xpath("//*[@id='requestingProviderPanelIdContent']//input[@ng-disabled ='continueButtonClicked']");
    public static By blockerOverridePopup = By.xpath("//*[@id='globalMessages-description']/span");


    public static By backButton = By.xpath("//input[@value='Back']");

    //Override Blocker Popup
    public static By overrideReasonDropdown = By.xpath("//*[@id=\"sharedBOParams-blockerOverrideVO-overrideReasonCode-0\"]");
    public static By overrideReason = By.xpath("//*[@id=\"ovrdDescId\"]");
    public static By overrideContinue = By.xpath("//*[@id=\"blockerOverrideOkayButton\"]");
    public static By overrideCancel = By.xpath("//*[@id=\"blockerOverrideBackButton\"]");

    // for Servicing Provider/Pharmacy page
    public static final String selectALimitedSupplierDropdownXpath = "//uitk-select[@ng-model='selectedSupplier']";
    //Locators--------

    public ServicingProviderPage(WebDriver webDriver) {
        driver = webDriver;
        utils = BaseCucumber.utils;
        log = Logger.getLogger(this.getClass().getName());
    }

    //Methods

    public void clickAddServicingProvider() {
        log.warn("Clicking Add Servicing Provider Button");
        TestUtils.clickUntil(driver, addServicingProvider, new ICondition() {
            @Override
            public boolean evaluate() throws Exception {
                return TestUtils.isElementVisible(driver, RequestingProviderSearchModalPage.searchButton);
            }
        });
    }

    /**
     * Clicking yes Button on ServicingProviderPage
     */
    public void clickYesButton() {
        log.warn("Clicking Yes Button");
        TestUtils.waitElement(driver, yesButton);
        driver.findElement(yesButton).click();
        TestUtils.wait(2);
    }

    /**
     * Clicking "Same as the requesting provider" Radio Button on ServicingProviderPage
     */
    public void clickSameAsTheRequestingProviderRadioButton() {
        log.warn("Clicking Same as the requesting provider Radio Button");
        TestUtils.waitElement(driver, sameAsTheRequestingProviderRadioButton);
        driver.findElement(sameAsTheRequestingProviderRadioButton).click();
        TestUtils.wait(2);
    }

    /**
     * Clicking "Search other provider/pharmacy" Radio Button on ServicingProviderPage
     */
    public void clickSearchOtherProviderRadioButton() {
        log.warn("Clicking Search other provider/pharmacy Radio Button");
        TestUtils.waitElement(driver, searchOtherProviderRadioButton);
        driver.findElement(searchOtherProviderRadioButton).click();
        TestUtils.wait(2);
    }

    /**
     * Clicking "Select a specialty pharmacy" Radio Button on ServicingProviderPage
     */
    public void clickSelectPreferredSupplierRadioButton() {
        log.warn("Clicking Select a specialty pharmacy Radio Button");
        TestUtils.waitElement(driver, selectPreferredSupplierRadioButton);
        driver.findElement(selectPreferredSupplierRadioButton).click();
        TestUtils.wait(2);
    }

    /**
     * Select first option from the Preferred Supplier Dropdown
     */
    public void selectPreferredSupplierFromDropdown() {
        log.warn("Select Preferred Supplier From Dropdown");
        TestUtils.select(driver, selectPreferredSupplierDropdown , 1);
        TestUtils.wait(2);
    }

    /**
     * Clicking Continue Button on ServicingProviderPage
     */
    public void clicKContinueButton() {
        log.warn("Clicking Continue Button");
        TestUtils.waitElement(driver, continueButton);
        TestUtils.onMouseHover(driver, continueButton);
        TestUtils.wait(2);
        TestUtils.safeClick(driver, continueButton);
    }

    /**
     * Verfying Add Servicing ProviderOrPharmacy Button visible on the page
     */
    public void verifyAddServicingProviderOrPharmacyButton() {
        log.warn("verfying Add Servicing Provider/Pharmacy Button is present in the page Servicing Provider page ");
        TestUtils.wait(3);
        Assert.assertTrue("Add Servicing Provider/Pharmacy Button is not present in the page", TestUtils.isElementPresent(driver, addServicingProviderOrPharmacy));
        TestUtils.highlightElement(driver, addServicingProviderOrPharmacy);

    }

    /**
     * Verfying Add Servicing ProviderOrPharmacy Button not visible on the page
     */
    public void verifyAddServicingProviderOrPharmacyButtonNotVisibleOnthePage() {
        log.warn("verfying Add Servicing Provider/Pharmacy Button is present in the page Servicing Provider page ");
        Assert.assertFalse("Add Servicing Provider/Pharmacy Button is  present in the page", TestUtils.isElementPresent(driver, addServicingProviderOrPharmacy));

    }

    /**
     * Select TIN  radio button on the servicing Provider Search page
     */
    public void selectTINRadioBtn_ChangeProvModal() {
        log.warn("Selecting TIN and/or NPI radio button");
        TestUtils.highlightElement(driver, tinRadioBtn);
        driver.findElement(tinRadioBtn).click();
    }


    /**
     * Entering TIN Number on Servicing Provider Search Modal Page
     */
    public void userEntersTINPhys(String tin) {
        log.warn("Enter the TIN: " + tin);
        TestUtils.wait(1);
        TestUtils.input(driver, facilitySearchTIN, tin);
        TestUtils.wait(1);
    }

    /**
     * clicking back on  Servicing Provider Search Modal Page
     */
    public void clickBackButton() {
        log.warn("Clicking Back Button");
        TestUtils.waitElement(driver, backButton);
        TestUtils.onMouseHover(driver, backButton);
        TestUtils.wait(2);
        TestUtils.safeClick(driver, backButton);
    }

    /**
     * verifying out of network check pop up message.
     */
    public void verifyOONCheckPopUpMessage() {
        log.warn("Verifying out of network pop up message");
        String expectedMessage = String.format(OONCheckMessage);
        String actualMessage = TestUtils.text(driver, OONMessage);
        Assert.assertEquals("out of network pop up message is incorrect", expectedMessage, actualMessage);

    }

    public void verifyNNOONCheckPopUpMessage() {
        log.warn("Verifying out of network pop up message");
        String expectedMessage = String.format(NNOONCheckMessage);
        String actualMessage = TestUtils.text(driver, OONMessage);
        Assert.assertEquals("out of network pop up message is incorrect", expectedMessage, actualMessage);

    }

    public void SPverifyBlockerOverridePopup(Map<String, String> pf) {
        log.warn("Verify Blocker override popup in Servicing provider page");
        if(pf.get(MBM.USER_TITLE).contains("admin")|| pf.get(MBM.USER_TITLE).contains("operations manager")) {
            TestUtils.waitElementVisible(driver,  errorOverridePopup);
            Assert.assertTrue("Blocker override popup is not displayed", driver.findElement(errorOverridePopup).getText().contains("Blocked Authorization Override"));
        }
        else {
            TestUtils.waitElementVisible(driver, blockerOverridePopup);
            Assert.assertTrue("Blocker override popup is not displayed", driver.findElement(blockerOverridePopup).isDisplayed());
        }
    }

    public void SPselectBlockeroverrideOption(String reason) {
        log.warn("Selecting Provider Faxed Auth override reason");
        TestUtils.highlightElement(driver, overrideReasonDropdown);
        TestUtils.waitElement(driver, overrideReasonDropdown);
        TestUtils.wait(3);
        TestUtils.selectByVisibleText(driver.findElement(overrideReasonDropdown), reason);
    }

    public void SPselectBlockeroverrideJustification(String justification) {
        log.warn("Selecting Provider Faxed Auth override reason");
        TestUtils.highlightElement(driver, overrideReason);
        TestUtils.waitElement(driver, overrideReason);
        TestUtils.wait(3);
        TestUtils.input(driver, By.xpath("//*[@id=\"ovrdDescId\"]"), justification);
    }

    public void SPclickOverrideContinueButton()
    {
        log.warn("Clicking on continue button");
        Assert.assertTrue(TestUtils.click(driver, overrideContinue));
    }

    public void selectALimitedSupplier(String facilityName) {
        TestUtils.input(driver, By.xpath(selectALimitedSupplierDropdownXpath), facilityName);
    }

    public void verifyDefaultProviderData(){

        log.warn("verifying Default data not populated in Servicing provider page");
        Assert.assertFalse("verifying Default data in Servicing provider page", TestUtils.isElementPresent(driver, providerTIN));
    }

    /***
     *
     * @param overrideOption
     * Method to select the required option from Override Rules dropdown, provide justification and Continue
     */

    public void selectOverRideReason(String overrideOption) {

        By overrideReasonDropdown = By.xpath("//*[@id=\"sharedBOParams-blockerOverrideVO-overrideReasonCode-0\"]");
        log.warn("Selecting Override Reason");
        utils.waitElement(driver, overrideReasonDropdown);
        org.openqa.selenium.support.ui.Select override = new org.openqa.selenium.support.ui.Select(driver.findElement(overrideReasonDropdown));
        override.selectByVisibleText(overrideOption);

        driver.findElement(overrideReason).sendKeys("Simple Description to Override.");
//        driver.findElement(overrideContinue).click();
    }

    /***
     * Click continue button from Override Reason popup blocker
     */

    public void continueOverridePopup() {
        driver.findElement(overrideContinue).click();
    }

    /***
     * Click continue button from Override Reason popup blocker
     */

    public void cancelOverridePopup() {
        driver.findElement(overrideCancel).click();
    }

    /***
     *
     * @throws InterruptedException
     * valdiating the dropdown items from override dropdown box
     */

    public void verifyOverRideReasonValues() throws InterruptedException {
        driver.findElement(overrideReasonDropdown).click();
        String expectedDropdownValues = driver.findElement(overrideReasonDropdown).getText();
        String actualDropdownValues = driver.findElement(overrideReasonDropdown).getText();
        Assert.assertEquals(expectedDropdownValues, actualDropdownValues);
    }

    /***
     * verifying Overridden Rules section from Utilization Management page
     */

    public void overriddenBlockingRulesTableUM() {

        By OverriddenBlockingDetails = By.xpath("//*[@id=\"overrideBlockingDetailsId\"]/div[2]");
        Assert.assertEquals("Blocker Table is present in UM page", true, utils.isElementPresent(driver, OverriddenBlockingDetails));
    }

    /***
     * verifying Overridden Rules section from Request Summary page
     */

    public void overriddenBlockingRulesTableReqSummary() {
        By OverriddenBlockingDetailsReqSummary = By.xpath("//*[@id=\"requestSummaryPanelIdContent\"]/div/div[8]");
        Assert.assertEquals("Blocker Table is present in Request Summary Page", true, utils.isElementPresent(driver, OverriddenBlockingDetailsReqSummary));
    }

    /***
     * verifying Overridden Rules section from Request Status page
     */

    public void overriddenBlockingRulesTableReqStatus() {
        By OverriddenBlockingDetailsReqStatus = By.xpath("//*[@id=\"authorizationConfirmationPanelIdContent\"]/div/div[2]/div[3]/div[8]");
        Assert.assertEquals("Blocker Table is present in Request Status Page", true, utils.isElementPresent(driver, OverriddenBlockingDetailsReqStatus));
    }

    /***
     * verifying warning message when not select override reason
     */

    public void warningMessageOverrideReason() {
        By warningOverride = By.id("sharedBOParams-blockerOverrideVO-overrideReasonCode_errVHAqXDahBcfTrPwLwFEpGBT");
        Assert.assertEquals("This field is required warning message is displayed", false, utils.isElementPresent(driver, warningOverride));
    }

    public void verifyProviderRIBlockingPopupDisplayed() {
        log.warn("verifying RI Blocking popup is displayed on Servicing Provider Page");
        TestUtils.wait(2);
        String expectedMessage = "In order to request a prior authorization for this member, please call 1-888-397-8129";
        Assert.assertEquals("message is not matching",expectedMessage,driver.findElement(providerRiBlockPopup).getText());
    }

    public void verifyProviderRIBlockingOnSPSPopupDisplayed() {
        log.warn("verifying RI Blocking popup is displayed on Servicing Provider Search Pop Up");
        TestUtils.wait(2);
        String expectedMessage = "In order to request a prior authorization for this member, please call 1-888-397-8129";
        Assert.assertEquals("message is not matching",expectedMessage,driver.findElement(providerRiBlockPopupOnSPS).getText());

    }
}
