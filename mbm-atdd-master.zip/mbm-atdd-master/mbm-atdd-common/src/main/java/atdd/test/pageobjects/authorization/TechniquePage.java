package atdd.test.pageobjects.authorization;


import atdd.test.shared.BaseCucumber;
import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import static org.openqa.selenium.By.xpath;


public class TechniquePage {

    public static By continueButtonTechnique = By.xpath("//*[@id='techniquePanelIdContent'] //input[@class='continue-button ng-scope tk-btn'] | //*[@id='techniquePanelIdContent'] //input[@value='Continue']");
 //   public static By cptCodeTechnique = By.xpath("//select[@name='cptCodes-0']");
 public static By cptCodeTechnique = By.xpath("//button[contains(text(),'None Selected')]");


    public static By techniqueRadioButton = By.xpath("(//*[@class='selection-wrapper']//span)");
    public static By header = xpath("//span[contains(text(),'Technique')]");
    public static By saveDraftuttonTechnique = By.xpath("//*[@id='techniquePanelIdContent'] //input[@class='Save Draft-button ng-scope tk-btn'] | //*[@id='techniquePanelIdContent'] //input[@value='Save Draft']");

    //Locators--------

    Logger log;
    private WebDriver driver;
    private TestUtils utils;


    //Locators--------


    public TechniquePage(WebDriver webDriver) {
        this.driver = webDriver;
        utils = BaseCucumber.utils;
        log = Logger.getLogger(this.getClass().getName());
    }

    //Methods


    /**
     * Clicking on continue button on TechniquePage
     * Created - amadduku
     */
    public void clickContinueButtonTechnique() {
        TestUtils.wait(2);
        TestUtils.click(driver, continueButtonTechnique);
        TestUtils.wait(2);
    }

    public void selectCptcodeTechnique(String cptcode) {
        log.warn("Select " + cptcode + " value from CPT/HCPCS  Drop-down");
        TestUtils.wait(5);
        TestUtils.waitElement(driver, cptCodeTechnique);
        TestUtils.onMouseHover(driver, cptCodeTechnique);
        TestUtils.highlightElement(driver, cptCodeTechnique);
        driver.findElement(By.xpath("//button[contains(text(),'None Selected')]//following-sibling::span/span")).click();
        String xpath = "//span[contains(text(),'"+cptcode.trim() +"')]";
        driver.findElement(By.xpath(xpath)).click();

        //TestUtils.selectByVisibleText(driver.findElement(cptCodeTechnique), cptcode);

    }

    public void selectTechniqueRadioButton(String techniquename) {
        TestUtils.wait(3);
        By techniqueByText = xpath("//span[text()='" + techniquename + "']/../span[contains(@class, 'selection-wrapper')]");
        TestUtils.waitElementVisible(driver, techniqueByText);
        TestUtils.click(driver, techniqueByText);
    }

    public void clickSaveDraftButtonTechnique() {
        TestUtils.wait(2);
        TestUtils.click(driver, saveDraftuttonTechnique);
        TestUtils.wait(2);
    }

    public void verifyHeaderText(String expectedHeader) {
        String actualHeader = TestUtils.text(driver, header);
        log.info("Checking page header. Header is: " + actualHeader);
        Assert.assertTrue("Header is not matching with " + expectedHeader + ". Currect header is: " + actualHeader,
                expectedHeader.equals(actualHeader));

    }

}