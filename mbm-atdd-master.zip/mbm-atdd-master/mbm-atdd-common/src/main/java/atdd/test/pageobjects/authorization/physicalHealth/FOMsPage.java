package atdd.test.pageobjects.authorization.physicalHealth;

import atdd.test.shared.BaseCucumber;
import atdd.utils.MBM;
import atdd.utils.TestUtils;
import cucumber.api.java.en.And;
import org.apache.log4j.Logger;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.junit.Assert;
import cucumber.api.DataTable;
import java.util.List;
import java.util.Map;

import atdd.test.core.FomsQa;
import atdd.test.core.FomsQaManager;
import atdd.test.stepsets.auth.PhysicalHealth.FOMsPageWorker;
import static org.openqa.selenium.By.xpath;

public class FOMsPage {
    private WebDriver driver;
    private TestUtils utils;
    Logger log;

    //Locators-----
    public static By backButton = xpath("//input[@value='Back']");
    public static By mSKAccordion = xpath("//strong[contains(text(),'MSK SBST(STart Back Screening Tool)')]//../..//div[contains(@id,'accordionFOM')]");
    public static By backIndexAccordion = xpath("//strong[contains(text(),'Back Index')]//../..//div[contains(@id,'accordionFOM')]");
    public static By patientAbility = xpath("//select[contains(@id,'ocmAssessmentConductor-responses')]");
    public static By ContinueButton = xpath("//input[contains(@class,'continue-button')]");
    public static By saveAssessment = xpath("//input[contains(@id,'saveAssessmentBtn')]");
    public static By assesementXpath = xpath("//select[contains(@class,'assessment-select')]");
    public static By expandSBSTAccordion = xpath("//*[@id='accordionFOM']");
    public static By SBSTchoicesdropdown = xpath("//*[@id='ocmAssessmentConductor-responses-0']");
    public static By supplementaryAssessmentDropdown = xpath("//*[@id='fomsType']");
    public static By removeAssessmentButton = xpath("//*[@class='remove-assessment ng-scope']/a");
    public static By MSKEnterScore = xpath("//select[contains (@id, 'ocmAssessmentConductor-responses-1')]");
    public static By OptionalFormManualScore = xpath("//input[contains(@type,'number') and contains(@class,'ng-pristine')]");
    public static By BackAccordion = xpath("//strong[contains(text(),'Back Index')]//../..//div[contains(@id,'accordionFOM')]");
    public static By NeckAccordion = xpath("//strong[contains(text(),'Neck Index')]//../..//div[contains(@id,'accordionFOM')]");
    public static By DashAccordion = xpath("//strong[contains(text(),'DASH')]//../..//div[contains(@id,'accordionFOM')]");
    public static By LEFSAccordion = xpath("//strong[contains(text(),'LEFS')]//../..//div[contains(@id,'accordionFOM')]");
    public static By OtherAccordion = xpath("//strong[contains(text(),'Other')]//../..//div[contains(@id,'accordionFOM')]");
    public static By AddAssessment = xpath("//select[contains(@class,'assessment-select')]");
    public static By sucessPopup = By.id("globalMessages-description");
    public static By SelectExistingForm = xpath("//select[contains(@class,'tk-sngl-dpwn question-option ng-pristine')]");
    public static By InCompeleteInProgress = xpath("//p[contains(@class,'assessment-status') and (contains(text(),'Incomplete') or contains(text(),'In-Progress'))]");
    public static By OtherFormName = xpath("//div[contains(@class,'text-question-response')]/input[contains(@type,'text')]");
    public static By OtherManualScoreEntry = xpath("//input[contains(@type,'number') and contains(@class,'ng-pristine')]");
    public static By sbstRequiredlabel = xpath("//span[contains(@class,'inner-table-header') and contains(text(),'This form is now required for all authorizations')]");
    public static By TwoformsRequiredError = xpath("//div[contains(@class,'oui-pmsg-error-body')]/span[2]/span");
    public static By MSKScore = xpath("//strong[contains(text(),'MSK SBST(STart Back Screening Tool)')]//../..//div[contains(@id,'accordionFOM')]/following::span[2]");
    public static By BackIndexScore = xpath("//strong[contains(text(),'Back Index')]//../..//div[contains(@id,'accordionFOM')]/following::span[2]");
    public static By NeckIndexScore = xpath("//strong[contains(text(),'Neck Index')]//../..//div[contains(@id,'accordionFOM')]/following::span[2]");
    public static By DashScore = xpath("//strong[contains(text(),'DASH')]//../..//div[contains(@id,'accordionFOM')]/following::span[2]");
    public static By LefsScore = xpath("//strong[contains(text(),'LEFS')]//../..//div[contains(@id,'accordionFOM')]/following::span[2]");
    public static By OtherScore = xpath("//strong[contains(text(),'Other')]//../..//div[contains(@id,'accordionFOM')]/following::span[2]");
    public static By SbstCloseAccordian = xpath("//strong[contains(text(),'MSK SBST')]/../..//div[contains(@ class,'rowCol triangle-right')]");
    public static By BackCloseAccordian = xpath("//strong[contains(text(),'Back Index')]/../..//div[contains(@ class,'rowCol triangle-right')]");
    public static By NeckCloseAccordian = xpath("//strong[contains(text(),'Neck Index')]/../..//div[contains(@ class,'rowCol triangle-right')]");
    public static By DashCloseAccordian = xpath("//strong[contains(text(),'DASH')]/../..//div[contains(@ class,'rowCol triangle-right')]");
    public static By LefsCloseAccordian = xpath("//strong[contains(text(),'LEFS')]/../..//div[contains(@ class,'rowCol triangle-right')]");
    public static By OtherCloseAccordian = xpath("//strong[contains(text(),'Other')]/../..//div[contains(@ class,'rowCol triangle-right')]");
    public FOMsPage(WebDriver webDriver) {
        this.driver = webDriver;
        utils = BaseCucumber.utils;
        log = Logger.getLogger(this.getClass().getName());
    }

    /**
     * Clicks Back Button
     */
    public void clickBackButton() {
        TestUtils.safeClick(driver, backButton);
    }

    /**
     * Clicks Continue Button
     */
    public void clickContinueButton() {
        TestUtils.safeClick(driver, ContinueButton);
    }

    /**
     * Clicks Save Button
     */
    public void clickSaveAssessment() {
        TestUtils.safeClick(driver, saveAssessment);
    }


    /**
     * Selecting Foms on Functional Outcome Measures page
     *
     * @param value
     * @param label
     */
    public void chooseFoMs(String value, String label) {
        log.warn("Selecting " + value + " from " + label + " on FoMsPage");
        By by = xpath("//*[contains(text(),'" + label + "')]/ancestor::div[contains(@id,'question-wrapper')]//select");
        TestUtils.isElementVisible(driver, by);
        TestUtils.select(driver, by, value);
    }

    /**
     * Inputs the answers for all assessments including Start Assessment, Manual Entry or Skip the assessment that are passed through Json profiles
     * Note: For Start Assessment option, Save should be passed through Json. For Manual Entry & Skip, Save is handled in the method
     */
    public boolean inputAnswer(String a, String q) {
        List<WebElement> lst = driver.findElements(By.xpath("//div[contains(@class, 'triangle-right')]"));
        if ((q.equals("Patient Ability to complete form?"))|| (q.equals("Patient ability to complete the form?"))|| (q.equals("Patient ability to complete the assessment?"))) {
            TestUtils.click(driver, lst.get(lst.size() - 1));
            TestUtils.waitElement(driver, patientAbility);
            Select PatientAbilitydrop = new Select(driver.findElement(patientAbility));
            PatientAbilitydrop.selectByVisibleText(a);
                    if(a.equals("Skip - Not able to complete")){
                        TestUtils.click(driver, saveAssessment);
                    } return true;
        } else if(q.equals("Enter the score") && (TestUtils.isElementVisible(driver, OptionalFormManualScore))) {
            WebElement OptionalFormEnterScore = driver.findElement(OptionalFormManualScore);
            OptionalFormEnterScore.clear();
            OptionalFormEnterScore.sendKeys(a);
            TestUtils.click(driver, saveAssessment);
        } else if (q.equals("Enter the score") && (TestUtils.isElementVisible(driver, MSKEnterScore))) {
            Select SbstManualScore = new Select(driver.findElement(MSKEnterScore));
            SbstManualScore.selectByVisibleText(a);
            TestUtils.click(driver, saveAssessment);
        }else if (q.equals("Other Form Name")) {
            Select OtherManualScoreVal = new Select(driver.findElement(OtherFormName));
            OtherManualScoreVal.selectByVisibleText(a);
        }else if (q.equals("Select existing form")) {
            TestUtils.click(driver, lst.get(lst.size() - 1));
            TestUtils.waitElement(driver, SelectExistingForm);
            Select SelectExistingFormVal = new Select(driver.findElement(SelectExistingForm));
            SelectExistingFormVal.selectByVisibleText(a);
        } else if (q.equals("Enter score")&& (TestUtils.isElementVisible(driver, OptionalFormManualScore))) {
            WebElement OtherManualScoreVal = driver.findElement(OptionalFormManualScore);
            OtherManualScoreVal.clear();
            OtherManualScoreVal.sendKeys(a);
            TestUtils.click(driver, saveAssessment);
        }else if (q.equals("Save Assessment")){
            TestUtils.click(driver, saveAssessment);
        } else {
            String answerRadioButtonXpath = "//div[contains(@class, 'question-wrapper') and contains(., '" + q + "')]/span[2]//span[.='" + a + "']/../input[@type='radio']";
            String answerInputXpath = "//div[contains(@class, 'question-wrapper') and contains(., '" + q + "')]/span[2]/*";
            if (TestUtils.isElementVisible(driver, answerRadioButtonXpath)) {
                TestUtils.click(driver, By.xpath(answerRadioButtonXpath));
            } else if(TestUtils.isElementVisible(driver, answerInputXpath)){
                TestUtils.input(driver, By.xpath(answerInputXpath), a);
            }
        }return true;
    }

    /**
     * Selects the assessment
     * @param assesement
     */
    public void selectAssessment(String assesement) {
        TestUtils.input(driver, assesementXpath, assesement);
    }

    public void expandandskipSBSTAssessment() {
        //open the accordian
        driver.findElement(expandSBSTAccordion).click();
        //Get the list of options and click skip
        TestUtils.wait(3);
        Select assessmentChoices = new Select(driver.findElement(SBSTchoicesdropdown));
        assessmentChoices.selectByVisibleText("Skip - Not able to complete");
        //Save assessment
        TestUtils.wait(2);
        driver.findElement(saveAssessment).click();
    }

    public void addASupplementaryAssessment() {
        TestUtils.wait(2);
        Select supplementary = new Select(driver.findElement(supplementaryAssessmentDropdown));
        supplementary.selectByVisibleText("Back Index");
    }

    /**
     * Remove Optional Assessment by clicking on Remove Assessment link
     */
    public void RemoveAssessment() {
        //Assert.assertTrue("Verify remove Assessment button is not displayed", driver.findElement(removeAssessmentButton).isDisplayed());
        TestUtils.waitElement(driver, removeAssessmentButton);
        driver.findElement(removeAssessmentButton).click();
    }

    public void verifybackAssessmentDisplays() {
        Assert.assertTrue("Verify that the back index is expandable", driver.findElement(backIndexAccordion).isDisplayed());
    }

    /**
     * Verifies Two Forms Required Error message is displayed as expected
     * @param expectedError
     */
    public void VerifyErrorMessageIsDisplayed(String expectedError) {
        TestUtils.click(driver, ContinueButton);
        String actualError = driver.findElement(TwoformsRequiredError).getText();
        Assert.assertEquals("Error Message does not match", expectedError, actualError);
    }

    /**
     *  complete's the SBST Assessment by Skipping it
     */
    public void skipSBSTAssessment() {
        TestUtils.click(driver, mSKAccordion);
        log.warn("Skip SBST Assessment");
        TestUtils.waitElement(driver, patientAbility);
        Select PatientAbilitydrop = new Select(driver.findElement(patientAbility));
        PatientAbilitydrop.selectByVisibleText("Skip - Not able to complete");
        TestUtils.click(driver, saveAssessment);
    }

    /**
     *  Selects the Other Assessment from the dropdown
     */
    public void selectsOtherOtherassessment() {
        TestUtils.waitElement(driver, AddAssessment);
        Select AddAssessmentdrop = new Select(driver.findElement(AddAssessment));
        AddAssessmentdrop.selectByVisibleText("Other");
        TestUtils.waitElement(driver, OtherAccordion);
        TestUtils.click(driver, OtherAccordion);
        TestUtils.waitElement(driver, SelectExistingForm);
        Select SelectExistingFormVal = new Select(driver.findElement(SelectExistingForm));
        SelectExistingFormVal.selectByVisibleText("Other");
    }

    /**
     *  Verify the expected fields are displayed for Other:Other assessment
     */
    public void OtherassessmentFields() {
        TestUtils.isElementVisible(driver, OtherFormName);
        log.warn("Other Form Name field is displayed");
        TestUtils.isElementVisible(driver, OtherManualScoreEntry);
        log.warn("Enter Score field is displayed on Other Assessment");
    }

    /**
     *  Verifies the Required label is displayed for SBST Form and SBST form can not be removed
     */
    public void RequiredSbstFormAndNotRemoved() {
        TestUtils.waitElement(driver, mSKAccordion);
        Assert.assertTrue("Required label NOT displayed", TestUtils.isElementVisible(driver, sbstRequiredlabel));
        log.warn("This form is now required for all authorizations is displayed");
        Assert.assertFalse("Remove Assessment is displayed", TestUtils.isElementVisible(driver, removeAssessmentButton));
        log.warn("Remove Assessment is not displayed");
    }

    /**
     *  Completes SBST form with Manual ENtry as Medium Risk
     */
    public void SBSTManulEntry() {
        TestUtils.click(driver, mSKAccordion);
        log.warn("Manual Entry");
        TestUtils.waitElement(driver, patientAbility);
        Select PatientAbilitydrop = new Select(driver.findElement(patientAbility));
        PatientAbilitydrop.selectByVisibleText("Manual Entry");
        TestUtils.waitElement(driver, MSKEnterScore);
        Select SbstManualScore = new Select(driver.findElement(MSKEnterScore));
        SbstManualScore.selectByVisibleText("Medium Risk");
        TestUtils.click(driver, saveAssessment);
    }

    /**
     *  Enters Manual Score for Optional Forms except for Other Optional form
     *  @param OptionalManualScore
     */
    public void EnterManualScoreInOptionalForms(String OptionalManualScore) {
        TestUtils.waitElement(driver, patientAbility);
        Select PatientAbilitydrop = new Select(driver.findElement(patientAbility));
        PatientAbilitydrop.selectByVisibleText("Manual Entry");
        TestUtils.waitElement(driver, OptionalFormManualScore);
        WebElement OptionalFormEnterScore = driver.findElement(OptionalFormManualScore);
        OptionalFormEnterScore.clear();
        OptionalFormEnterScore.sendKeys(OptionalManualScore);
    }

    /**
     *  Enters Manual Score for Other Optional forms
     *  @param OtherScore
     */
    public void EnterManualScoreInOtherForms(String OtherScore) {
        TestUtils.waitElement(driver, OtherManualScoreEntry);
        WebElement OtherFormEnterScore = driver.findElement(OtherManualScoreEntry);
        OtherFormEnterScore.clear();
        OtherFormEnterScore.sendKeys(OtherScore);
    }

    /**
     *  Adds Optional Assessments
     *  @param FormName
     */
    public void AddOptionalAssesment(String FormName) {
        TestUtils.waitElement(driver, AddAssessment);
        Select AddAssessmentdrop = new Select(driver.findElement(AddAssessment));
        AddAssessmentdrop.selectByVisibleText(FormName);
        if (FormName.equals("Back Index")) {
            TestUtils.waitElement(driver, BackAccordion);
            TestUtils.click(driver, BackAccordion);
        } else if (FormName.equals("Neck Index")) {
            TestUtils.waitElement(driver, NeckAccordion);
            TestUtils.click(driver, NeckAccordion);
        } else if (FormName.equals("DASH")) {
            TestUtils.waitElement(driver, DashAccordion);
            TestUtils.click(driver, DashAccordion);
        } else if (FormName.equals("LEFS")) {
            TestUtils.waitElement(driver, LEFSAccordion);
            TestUtils.click(driver, LEFSAccordion);
        } else if (FormName.equals("Other")) {
            TestUtils.waitElement(driver, OtherAccordion);
            TestUtils.click(driver, OtherAccordion);
        }
    }

    /**
     *  Hides previously added Assessments in Add an Assessment dropdown list
     *
     */
    public void HidePreviouslyAddedAssessments() {
        TestUtils.waitElement(driver, AddAssessment);
        Select AddAssessmentdrop = new Select(driver.findElement(AddAssessment));
        List <WebElement> AddAssessmentdroplist = AddAssessmentdrop.getOptions();
        if(TestUtils.isElementVisible(driver, backIndexAccordion)){
            Assert.assertFalse("Back Index Assessment is available",AddAssessmentdroplist.contains("Back Index"));
            log.warn("Back Index Assessment is not available");
        }else if(TestUtils.isElementVisible(driver, NeckAccordion)) {
            Assert.assertFalse("Neck Index Assessment is available",AddAssessmentdroplist.contains("Neck Index"));
            log.warn("Neck Index Assessment is not available");
        }else if(TestUtils.isElementVisible(driver, DashAccordion)) {
            Assert.assertFalse("DASH Assessment is available",AddAssessmentdroplist.contains("DASH"));
            log.warn("DASH Assessment is not available");
        }else if(TestUtils.isElementVisible(driver, LEFSAccordion)) {
            Assert.assertFalse("LEFS Assessment is available",AddAssessmentdroplist.contains("LEFS"));
            log.warn("LEFS Assessment is not available");
        }else if(TestUtils.isElementVisible(driver, OtherAccordion)) {
            Assert.assertFalse("Other Assessment is available",AddAssessmentdroplist.contains("Other"));
            log.warn("Other Assessment is not available");
        }
    }

    /**
     *  Expands/Opens the Accordian by clicking on the accordian right arrow
     *  @param FormName
     */
    public void OpenAccordian(String FormName) {
        if (FormName.equals("SBST")) {
            TestUtils.waitElement(driver, mSKAccordion);
            TestUtils.click(driver, mSKAccordion);
        }else if (FormName.equals("Back Index")) {
            TestUtils.waitElement(driver, BackAccordion);
            TestUtils.click(driver, BackAccordion);
        } else if (FormName.equals("Neck Index")) {
            TestUtils.waitElement(driver, NeckAccordion);
            TestUtils.click(driver, NeckAccordion);
        } else if (FormName.equals("DASH")) {
            TestUtils.waitElement(driver, DashAccordion);
            TestUtils.click(driver, DashAccordion);
        } else if (FormName.equals("LEFS")) {
            TestUtils.waitElement(driver, LEFSAccordion);
            TestUtils.click(driver, LEFSAccordion);
        } else if (FormName.equals("Other")) {
            TestUtils.waitElement(driver, OtherAccordion);
            TestUtils.click(driver, OtherAccordion);
        }
    }

    /**
     *  Validates the values in the Patient ability to complete the form dropdown list
     *  @param dropDownValues
     */
    public void ValidatePatientAbilityToCompleteFormDropdownOptions(DataTable dropDownValues) {
        //TestUtils.click(driver, mSKAccordion);
        log.warn("Verifies Patient Ability To Complete Form Dropdown options on Foms Page");
        List<List<String>> data = dropDownValues.raw();
        TestUtils.waitElement(driver, patientAbility);
        driver.findElement(patientAbility).click();
        for (int i = 0; i < data.size(); i++) {
            log.warn("Verifying value " + data.get(i).get(0) + " from Drop down values");
            By patientAbilityDropdownValue = xpath("//select[contains(@id,'ocmAssessmentConductor-responses-0')]/option[contains(text(),'" + data.get(i).get(0) + "')]");
            Assert.assertTrue("Select option: " + data.get(i).get(0) + " doesn't exist",
                    driver.findElement(patientAbilityDropdownValue).isDisplayed());
            Assert.assertTrue("Select option: " + data.get(i).get(0) + " text doesn't match",
                    driver.findElement(patientAbilityDropdownValue).getText().contains(data.get(i).get(0)));
        }
        TestUtils.click(driver, mSKAccordion);
    }

    /**
     *  Validates the values in Enter The Score dropdown list on SBST form
     *  @param dropDownValues
     */
    public void ValidateSBSTFormEnterTheScoreDropdownOptions(DataTable dropDownValues) {
        TestUtils.click(driver, mSKAccordion);
        log.warn("Verifies SBST Form Enter The Score Dropdown options on Foms Page");
        List<List<String>> data = dropDownValues.raw();
        TestUtils.waitElement(driver, patientAbility);
        Select PatientAbilitydrop = new Select(driver.findElement(patientAbility));
        PatientAbilitydrop.selectByVisibleText("Manual Entry");
        TestUtils.waitElement(driver, MSKEnterScore);
        driver.findElement(MSKEnterScore).click();
        for (int i = 0; i < data.size(); i++) {
            log.warn("Verifying value " + data.get(i).get(0) + " from Drop down values");
            By patientAbilityDropdownValue = xpath("//select[contains(@id,'ocmAssessmentConductor-responses-1')]/option[contains(text(),'" + data.get(i).get(0) + "')]");
            Assert.assertTrue("Select option: " + data.get(i).get(0) + " doesn't exist",
                    driver.findElement(patientAbilityDropdownValue).isDisplayed());
            Assert.assertTrue("Select option: " + data.get(i).get(0) + " text doesn't match",
                    driver.findElement(patientAbilityDropdownValue).getText().contains(data.get(i).get(0)));
        }
    }

    /**
     *  Validates the values in Add an Assessment dropdown list
     *  @param dropDownValues
     */
    public void ValidateAddanAssessmentDropdownOptions(DataTable dropDownValues) {
        TestUtils.click(driver, mSKAccordion);
        log.warn("Verifies Add an Assessment Dropdown options on Foms Page");
        List<List<String>> data = dropDownValues.raw();
        TestUtils.waitElement(driver, patientAbility);
        Select PatientAbilitydrop = new Select(driver.findElement(patientAbility));
        PatientAbilitydrop.selectByVisibleText("Skip - Not able to complete");
        TestUtils.click(driver, saveAssessment);
        TestUtils.waitElement(driver, AddAssessment);
        driver.findElement(AddAssessment).click();
        for (int i = 0; i < data.size(); i++) {
            log.warn("Verifying value " + data.get(i).get(0) + " from Drop down values");
            By AddAssessmentDropdownValue = xpath("//select[contains(@class,'assessment-select')]/option[contains(text(),'" + data.get(i).get(0) + "')]");
            Assert.assertTrue("Select option: " + data.get(i).get(0) + " doesn't exist",
                    driver.findElement(AddAssessmentDropdownValue).isDisplayed());
            Assert.assertTrue("Select option: " + data.get(i).get(0) + " text doesn't match",
                    driver.findElement(AddAssessmentDropdownValue).getText().contains(data.get(i).get(0)));
        }
    }

    /**
     *  Verify the SBST assessment questions, when Start Assessment option is selected
     *  @param sbstQ
     */
    public void ValidateSBSTFormStartAssessmentQuestions(DataTable sbstQ) {
        TestUtils.click(driver, mSKAccordion);
        log.warn("Verifies SBST Form Start Assessment Questions");
        List<List<String>> data = sbstQ.raw();
        TestUtils.waitElement(driver, patientAbility);
        Select PatientAbilitydrop = new Select(driver.findElement(patientAbility));
        PatientAbilitydrop.selectByVisibleText("Start Assessment");
        for (int i = 0; i < data.size(); i++) {
            log.warn("Verifying Start Assessment Question:" + data.get(i).get(0));
            List<WebElement> sbstAssessmentQ = driver.findElements(By.xpath("//span[contains(@class,'prompt-text')]"));
            if (null != sbstAssessmentQ && sbstAssessmentQ.size() > 1) {
                By sbstQValue = xpath("//span[contains(@class,'prompt-text') and contains(text(),\"" + data.get(i).get(0) + "\")]");
                Assert.assertTrue("Assessment Question:" + data.get(i).get(0) + " doesn't exist",
                        driver.findElement(sbstQValue).isDisplayed());
                Assert.assertTrue("Assessment Question: " + data.get(i).get(0) + " text doesn't match",
                        driver.findElement(sbstQValue).getText().contains(data.get(i).get(0)));
            }
        }
    }


    /**
     *  Verify the Back Index assessment questions, when Start Assessment option is selected
     *  @param backQ
     */
    public void ValidateBACKIndexStartAssessmentQuestions(DataTable backQ) {
        skipSBSTAssessment();
        TestUtils.waitElement(driver, AddAssessment);
        Select AddAssessmentdrop = new Select(driver.findElement(AddAssessment));
        AddAssessmentdrop.selectByVisibleText("Back Index");
        TestUtils.waitElement(driver, BackAccordion);
        TestUtils.click(driver, BackAccordion);
        log.warn("Verifies BACK Index Start Assessment Questions");
        List<List<String>> data = backQ.raw();
        TestUtils.waitElement(driver, patientAbility);
        Select PatientAbilitydrop = new Select(driver.findElement(patientAbility));
        PatientAbilitydrop.selectByVisibleText("Start Assessment");
        for (int i = 0; i < data.size(); i++) {
            log.warn("Verifying Start Assessment Question: " + data.get(i).get(0));
            List<WebElement> backAssessmentQ = driver.findElements(By.xpath("//span[contains(@class,'prompt-text')]"));
            if (null != backAssessmentQ && backAssessmentQ.size() > 1) {
                By sbstQValue = xpath("//span[contains(@class,'prompt-text') and contains(text(),\"" + data.get(i).get(0) + "\")]");
                Assert.assertTrue("Assessment Question:" + data.get(i).get(0) + " doesn't exist",
                        driver.findElement(sbstQValue).isDisplayed());
                Assert.assertTrue("Assessment Question:" + data.get(i).get(0) + " text doesn't match",
                        driver.findElement(sbstQValue).getText().contains(data.get(i).get(0)));
            }
        }
    }

    /**
     *  Verify the Neck Index assessment questions, when Start Assessment option is selected
     *  @param neckQ
     */
    public void ValidateNeckIndexStartAssessmentQuestions(DataTable neckQ) {
        skipSBSTAssessment();
        TestUtils.waitElement(driver, AddAssessment);
        Select AddAssessmentdrop = new Select(driver.findElement(AddAssessment));
        AddAssessmentdrop.selectByVisibleText("Neck Index");
        TestUtils.waitElement(driver, NeckAccordion);
        TestUtils.click(driver, NeckAccordion);
        log.warn("Verifies NECK Index Start Assessment Questions");
        List<List<String>> data = neckQ.raw();
        TestUtils.waitElement(driver, patientAbility);
        Select PatientAbilitydrop = new Select(driver.findElement(patientAbility));
        PatientAbilitydrop.selectByVisibleText("Start Assessment");
        for (int i = 0; i < data.size(); i++) {
            log.warn("Verifying Start Assessment Question: " + data.get(i).get(0));
            List<WebElement> backAssessmentQ = driver.findElements(By.xpath("//span[contains(@class,'prompt-text')]"));
            if (null != backAssessmentQ && backAssessmentQ.size() > 1) {
                By sbstQValue = xpath("//span[contains(@class,'prompt-text') and contains(text(),\"" + data.get(i).get(0) + "\")]");
                Assert.assertTrue("Assessment Question: " + data.get(i).get(0) + " doesn't exist",
                        driver.findElement(sbstQValue).isDisplayed());
                Assert.assertTrue("Assessment Question: " + data.get(i).get(0) + " text doesn't match",
                        driver.findElement(sbstQValue).getText().contains(data.get(i).get(0)));
            }
        }
    }

    /**
     *  Verify the Dash assessment questions, when Start Assessment option is selected
     *  @param dashQ
     */
    public void ValidateDashStartAssessmentQuestions(DataTable dashQ) {
        skipSBSTAssessment();
        TestUtils.waitElement(driver, AddAssessment);
        Select AddAssessmentdrop = new Select(driver.findElement(AddAssessment));
        AddAssessmentdrop.selectByVisibleText("DASH");
        TestUtils.waitElement(driver, DashAccordion);
        TestUtils.click(driver, DashAccordion);
        log.warn("Verifies DASH Start Assessment Questions");
        List<List<String>> data = dashQ.raw();
        TestUtils.waitElement(driver, patientAbility);
        Select PatientAbilitydrop = new Select(driver.findElement(patientAbility));
        PatientAbilitydrop.selectByVisibleText("Start Assessment");
        for (int i = 0; i < data.size(); i++) {
            log.warn("Verifying Start Assessment Question:  " + data.get(i).get(0));
            List<WebElement> backAssessmentQ = driver.findElements(By.xpath("//span[contains(@class,'prompt-text')]"));
            if (null != backAssessmentQ && backAssessmentQ.size() > 1) {
                By sbstQValue = xpath("//span[contains(@class,'prompt-text') and contains(text(),\"" + data.get(i).get(0) + "\")]");
                Assert.assertTrue("Assessment Question: " + data.get(i).get(0) + " doesn't exist",
                        driver.findElement(sbstQValue).isDisplayed());
                Assert.assertTrue("Assessment Question: " + data.get(i).get(0) + " text doesn't match",
                        driver.findElement(sbstQValue).getText().contains(data.get(i).get(0)));
            }
        }
    }

    /**
     *  Verify the LEFS assessment questions, when Start Assessment option is selected
     *  @param lefsQ
     */
    public void ValidateLEFSStartAssessmentQuestions(DataTable lefsQ) {
        skipSBSTAssessment();
        TestUtils.waitElement(driver, AddAssessment);
        Select AddAssessmentdrop = new Select(driver.findElement(AddAssessment));
        AddAssessmentdrop.selectByVisibleText("LEFS");
        TestUtils.waitElement(driver, LEFSAccordion);
        TestUtils.click(driver, LEFSAccordion);
        log.warn("Verifies LEFS Start Assessment Questions");
        List<List<String>> data = lefsQ.raw();
        TestUtils.waitElement(driver, patientAbility);
        Select PatientAbilitydrop = new Select(driver.findElement(patientAbility));
        PatientAbilitydrop.selectByVisibleText("Start Assessment");
        for (int i = 0; i < data.size(); i++) {
            log.warn("Verifying Start Assessment Question:  " + data.get(i).get(0));
            List<WebElement> backAssessmentQ = driver.findElements(By.xpath("//span[contains(@class,'prompt-text')]"));
            if (null != backAssessmentQ && backAssessmentQ.size() > 1) {
                By sbstQValue = xpath("//span[contains(@class,'prompt-text') and contains(text(),\"" + data.get(i).get(0) + "\")]");
                Assert.assertTrue("Assessment Question: " + data.get(i).get(0) + " doesn't exist",
                        driver.findElement(sbstQValue).isDisplayed());
                Assert.assertTrue("Assessment Question: " + data.get(i).get(0) + " text doesn't match",
                        driver.findElement(sbstQValue).getText().contains(data.get(i).get(0)));
            }
        }
    }

    /**
     *  Verify the Score is displayed for all completed assessments
     */
    public void ValidateScoreOnTile() {
        log.warn("Validating Score is displayed on Tile");
        List<WebElement> CompletedStatus = driver.findElements(By.xpath("//p[contains(@ class,'assessment-status') and contains(text(),'Completed')]"));
        for (int i = 0; i < CompletedStatus.size(); i++) {
            if  (TestUtils.isElementVisible(driver, MSKScore)) {
                Assert.assertTrue("Score is not displayed", driver.findElement(MSKScore).isDisplayed());
            } else if  (TestUtils.isElementVisible(driver, BackIndexScore)) {
                Assert.assertTrue("Score is not displayed", driver.findElement(BackIndexScore).isDisplayed());
            }else if  (TestUtils.isElementVisible(driver, NeckIndexScore)) {
                Assert.assertTrue("Score is not displayed", driver.findElement(NeckIndexScore).isDisplayed());
            }else if  (TestUtils.isElementVisible(driver, DashScore)) {
                Assert.assertTrue("Score is not displayed", driver.findElement(DashScore).isDisplayed());
            }else if  (TestUtils.isElementVisible(driver, LefsScore)) {
                Assert.assertTrue("Score is not displayed", driver.findElement(LefsScore).isDisplayed());
            }else if  (TestUtils.isElementVisible(driver, OtherScore)) {
                Assert.assertTrue("Score is not displayed", driver.findElement(OtherScore).isDisplayed());
            }
        }
    }

    /**
     *  Verify the completed assessments Score is as expected
     *  @param assessment
     *  @param expectedScore
     */
    public void GetScoreOnTile(String assessment, String expectedScore) {
        log.warn("Validating Score is displayed on Tile");
        List<WebElement> CompletedStatus = driver.findElements(By.xpath("//p[contains(@ class,'assessment-status') and contains(text(),'Completed')]"));
        //TestUtils.waitElementVisible(driver, Score);
        for (int i = 0; i < CompletedStatus.size(); i++) {
            if ((assessment.equals("MSKScore")) && (TestUtils.isElementVisible(driver, MSKScore))) {
                String ActualScore = driver.findElement(MSKScore).getText();
                Assert.assertEquals("Score does not match", expectedScore, ActualScore);
            } else if((assessment.equals("BackIndexScore")) && (TestUtils.isElementVisible(driver, BackIndexScore))) {
                String ActualScore = driver.findElement(BackIndexScore).getText();
                Assert.assertEquals("Score does not match", expectedScore, ActualScore);
            }else if((assessment.equals("NeckIndexScore")) && (TestUtils.isElementVisible(driver, NeckIndexScore))) {
                String ActualScore = driver.findElement(NeckIndexScore).getText();
                Assert.assertEquals("Score does not match", expectedScore, ActualScore);
            }else if((assessment.equals("DashScore")) && (TestUtils.isElementVisible(driver, DashScore))) {
                String ActualScore = driver.findElement(DashScore).getText();
                Assert.assertEquals("Score does not match", expectedScore, ActualScore);
            }else if((assessment.equals("LefsScore")) && (TestUtils.isElementVisible(driver, LefsScore))) {
                String ActualScore = driver.findElement(LefsScore).getText();
                Assert.assertEquals("Score does not match", expectedScore, ActualScore);
            }else if((assessment.equals("OtherScore")) && (TestUtils.isElementVisible(driver, OtherScore))) {
                String ActualScore = driver.findElement(OtherScore).getText();
                Assert.assertEquals("Score does not match", expectedScore, ActualScore);
            }
        }
    }

    /**
     *  Verify Add an Assessment dropdown is not displayed when assessment status is InCompelete or InProgress
     */
    public void ValidateAddanAssessmentHidden() {
        TestUtils.waitElement(driver, mSKAccordion);
        log.warn("Verifying Add an Assessment Dropdown is Hidden");
        if (driver.findElement(InCompeleteInProgress).isDisplayed()) {
            Assert.assertFalse(TestUtils.isElementVisible(driver, AddAssessment));
            log.warn("Add an Assessment Dropdown is not displayed");
        } else {
            log.warn("Add an Assessment Dropdown is displayed");
        }
    }

    /**
     *  Verify Remove Assessment button is displayed when assessment status is InCompelete or InProgress
     */
    public void ValidateRemoveAssessmentisDisplayedforIncompleteStatus() {
        log.warn("Verifying... Remove Assessment is Displayed");
        if (driver.findElement(InCompeleteInProgress).isDisplayed()) {
            Assert.assertTrue("Remove Assessment NOT Displayed", TestUtils.isElementVisible(driver, removeAssessmentButton));
            log.warn("Remove Assessment is displayed");
        }
    }

    /**
     *  Verify Add an Assessment dropdown is displayed
     */
    public void ValidateAddanAssessmentIsDisplayed() {
        Assert.assertTrue("Add an Assessment Dropdown is not displayed", TestUtils.isElementVisible(driver, AddAssessment));
        log.warn("Add an Assessment Dropdown is displayed");
    }

    /**
     *  Verify only one accordion can be opened
     */
    public void OnlyOneAccordianIsOpen() {
        List<WebElement> OpenAccordians =  driver.findElements(By.xpath("//div[contains(@ class,'rowCol triangle-down')]"));
        if (OpenAccordians.size()==1){
            Assert.assertTrue(TestUtils.isElementVisible(driver,xpath("//div[contains(@ class,'rowCol triangle-down')]")));
        }else if (OpenAccordians.size()>1) {
            log.warn("More than one Accordian is open");
        }
    }

    /**
     *  Verify Success popup message is displayed
     */
    public void successPopUpDisplayed() {
        TestUtils.isElementVisible(driver, sucessPopup);
        TestUtils.wait(2);
        log.warn("Success message is displayed");
    }

    /**
     *  Verify Accordion is closed or collapses
     *  @param FormName
     */
    public void verifyAccordionClosed(String FormName) {

        if (FormName.equals("SBST")) {
            TestUtils.waitElement(driver, SbstCloseAccordian);
            Assert.assertTrue("SBST Accordian is not closed",TestUtils.isElementVisible(driver,SbstCloseAccordian));
        }else if (FormName.equals("Back Index")) {
            TestUtils.waitElement(driver, BackCloseAccordian);
            Assert.assertTrue("Back Index Accordian is not closed",TestUtils.isElementVisible(driver,BackCloseAccordian));
        } else if (FormName.equals("Neck Index")) {
            TestUtils.waitElement(driver, NeckCloseAccordian);
            Assert.assertTrue("Neck Index Accordian is not closed",TestUtils.isElementVisible(driver,NeckCloseAccordian));
        } else if (FormName.equals("DASH")) {
            TestUtils.waitElement(driver, DashCloseAccordian);
            Assert.assertTrue("DASH Accordian is not closed",TestUtils.isElementVisible(driver,DashCloseAccordian));
        } else if (FormName.equals("LEFS")) {
            TestUtils.waitElement(driver, LefsCloseAccordian);
            Assert.assertTrue("LEFS Accordian is not closed",TestUtils.isElementVisible(driver,LefsCloseAccordian));
        } else if (FormName.equals("Other")) {
            TestUtils.waitElement(driver, OtherCloseAccordian);
            Assert.assertTrue("Other Accordian is not closed",TestUtils.isElementVisible(driver,OtherCloseAccordian));
        }

    }

    /**
     *  Verifies that same assessment can be edited multiple times
     */
    public void EditAssessmentsMultipleTimes() {
        skipSBSTAssessment();
        SBSTManulEntry();
        skipSBSTAssessment();
    }

    /**
     *  Verifies Select existing form dropdown values as expected
     *  @param dropDownValues
     */
    public void ValidateSelectExistingFormDropdownOptions(DataTable dropDownValues) {
        skipSBSTAssessment();
        TestUtils.waitElement(driver, AddAssessment);
        Select AddAssessmentdrop = new Select(driver.findElement(AddAssessment));
        AddAssessmentdrop.selectByVisibleText("Other");
        TestUtils.waitElement(driver, OtherAccordion);
        TestUtils.click(driver, OtherAccordion);
        log.warn("Verifies Select Existing Form Dropdown options on Other Assessment");
        TestUtils.waitElement(driver, SelectExistingForm);
        TestUtils.click(driver, SelectExistingForm);
        List<List<String>> data = dropDownValues.raw();
        for (int i = 0; i < data.size(); i++) {
            log.warn("Verifying value " + data.get(i).get(0) + " from Drop down values");
            By patientAbilityDropdownValue = xpath("//select[contains(@class,'tk-sngl-dpwn question-option ng-pristine')]/option[contains(text(),'" + data.get(i).get(0) + "')]");
            Assert.assertTrue("Select option: " + data.get(i).get(0) + " doesn't exist",
                    driver.findElement(patientAbilityDropdownValue).isDisplayed());
            Assert.assertTrue("Select option: " + data.get(i).get(0) + " text doesn't match",
                    driver.findElement(patientAbilityDropdownValue).getText().contains(data.get(i).get(0)));
        }
    }

    /**
     *  Adds Other:Other assessments from the select existing form dropdown list
     *  @param ExistingForm
     */
    public void AddsOtherAssessmentFromDropdownList(String ExistingForm) {
        TestUtils.waitElement(driver, SelectExistingForm);
        Select SelectExistingFormdrop = new Select(driver.findElement(SelectExistingForm));
        SelectExistingFormdrop.selectByVisibleText(ExistingForm);
    }

    /**
     *  Clears the selected dropdown value from Select existing form dropdown
     */
    public void ClearSelectExistingFormDropdownValue() {
        TestUtils.waitElement(driver, SelectExistingForm);
        driver.findElement(SelectExistingForm).clear();
    }


}

