package atdd.test.pageobjects.authorization.physicalHealth;

import atdd.common.MapsComparer;
import atdd.test.shared.BaseCucumber;
import atdd.utils.DateUtils;
import atdd.utils.ExcelLib;
import atdd.utils.MBM;
import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.List;
import java.util.Map;

import static org.openqa.selenium.By.cssSelector;
import static org.openqa.selenium.By.xpath;

public class PatientQuestionsPage {

    private WebDriver driver;
    private TestUtils utils;
    Logger log;

    //Locators-----
    public static final By patientQuestionnaireCheckbox = xpath("//*[@id='patientNotAbleToCompleteCheckBox']");
    public static final By dateSymtompsBegan = xpath("//*[contains(@id,'questionnaireBody-symptomStartDate-0')]");
    public static final By brieflyDescribeYourSymptoms  = xpath("//*[contains(@id,'describeSymptomsTextarea')]");
    public static final By howDidYourSymptomsStart = xpath("//*[contains(@id,'symptomStartTextarea')]");
    public static final By painIn24Hours = xpath("//*[@id='pain24Hours1']");
    public static final By painInLastWeek = xpath("//*[@id='painLastWeek2']");
    public static final By howOftenDoYouFeelYourSymptoms = xpath("//select[contains(@id,'questionnaireBody-symptomFrequency')]");
    public static final By howOftenDoYouFeelYourSymptomsSelectedOption = xpath("//select[contains(@id,'questionnaireBody-symptomFrequency')]/option[@ng-selected='true']");
    public static final By howMuchHaveYourSymptoms = xpath("//select[contains(@id,'questionnaireBody-symptomDayToDayActivity')]");
    public static final By howMuchHaveYourSymptomsSelectedOption = xpath("//select[contains(@id,'questionnaireBody-symptomDayToDayActivity')]/option[@ng-selected='true']");
    public static final By howIsYourConditionChanging = xpath("//select[contains(@id,'questionnaireBody-conditionProgress')]");
    public static final By howIsYourConditionChangingSelectedOption = xpath("//select[contains(@id,'questionnaireBody-conditionProgress')]/option[@ng-selected='true']");
    public static final By overallHealthRightNowIs = xpath("//select[contains(@id,'questionnaireBody-overallHealth')]");
    public static final By overallHealthRightNowIsSelectedOption = xpath("//select[contains(@id,'questionnaireBody-overallHealth')]/option[@ng-selected='true']");
    public static final By datePatientCompletedQuestions  = xpath("//input[contains(@id,'questionnaireBody-completionDate')]");
    public static By backButton = By.xpath("//uitk-panel[@model='patientHealthQuestionsPanel']/descendant::input[@Value='Back']");
    public static By saveDraftButton = By.xpath("//input[@value='Save Draft']");
    public static final By pqContinueButton = xpath("(//*[contains(@ng-click,'continue')])[1]");
    public static final By dob = By.xpath("(//span[contains(text(),'DOB')]/following-sibling::span)[1]");
    public static final By allFieldsRequired = cssSelector("div[class='required-wrapper ng-binding ng-scope']");
    private static String isChecked;
    public PatientQuestionsPage(WebDriver webDriver) {
        this.driver = webDriver;
        utils = BaseCucumber.utils;
        log = Logger.getLogger(this.getClass().getName());
    }

    //Methods-----



    /**
     * Click Patient is medically incapable of completing questionnaire on Patient Questions Page
     */
    public void clickCompletingQuestionnaireCheckbox() {
        log.warn("Entering Patient is medically incapable of completing questionnaire");
        TestUtils.highlightElement(driver, patientQuestionnaireCheckbox);
        TestUtils.click(driver, patientQuestionnaireCheckbox);
    }

    /**
     * Entering in DateSymtompsBegan on Patient Questions Page
     *
     * @param date
     */
    public void enterDateSymtompsBegan(String date) {
        log.warn("Entering initialDateofProgressionText");
        TestUtils.highlightElement(driver, dateSymtompsBegan);
        TestUtils.input(driver, dateSymtompsBegan, date);
    }

    /**
     * Entering Briefly describe your symptoms on Patient Questions Page
     *
     * @param notes -- Variable that holds the notes  user wishes to add
     */
    public void enterBrieflyDescribeYourSymptoms(String notes) {
        log.warn("Entering Briefly describe your symptoms");
        TestUtils.highlightElement(driver, brieflyDescribeYourSymptoms);
        driver.findElement(brieflyDescribeYourSymptoms).clear();
        TestUtils.input(driver, brieflyDescribeYourSymptoms, notes);
    }

    /**
     * Entering How did your symptoms start? on Patient Questions Page
     *
     * @param notes -- Variable that holds the notes  user wishes to add
     */
    public void enterHowDidYourSymptomsStart(String notes) {
        log.warn("Entering Briefly describe your symptoms");
        TestUtils.highlightElement(driver, howDidYourSymptomsStart);
        driver.findElement(howDidYourSymptomsStart).clear();
        TestUtils.input(driver, howDidYourSymptomsStart, notes);
    }

    /**
     * Click Pain in last 24 hours on Patient Questions Page
     */
    public void clickPainInLast24Hours(String scale) {
        log.warn("Entering Patient is medically incapable of completing questionnaire");
        TestUtils.click(driver, By.xpath("(//*[@class='tableSecondColumn ng-scope']/label/span[contains(text(),'" + scale + "')])[1]"));
    }

    /**
     * Click Pain in last week (1-7 days) on Patient Questions Page
     */
    public void clickPainInLastWeek(String scale) {
        log.warn("Entering Patient is medically incapable of completing questionnaire");
        TestUtils.click(driver, By.xpath("(//*[@class='tableSecondColumn ng-scope']/label/span[contains(text(),'" + scale + "')])[2]"));
    }

    /**
     * Selecting How often do you feel your symptoms? on Patient Questions Page
     *
     * @param symptoms
     */
    public void selectDropDownValueInHowOftenDoYouFeelYourSymptoms(String symptoms) {
        log.warn("Selecting How often do you feel your symptoms?");
        TestUtils.highlightElement(driver, howOftenDoYouFeelYourSymptoms);
        TestUtils.selectByVisibleText(driver.findElement(howOftenDoYouFeelYourSymptoms), symptoms);
    }

    /**
     * Selecting How much have your symptoms interfered with your daily activities? on Patient Questions Page
     *
     * @param symptoms
     */
    public void selectDropDownValueInHowMuchHaveYourSymptomsInterferedWithYourDailyActivities(String symptoms) {
        log.warn("Selecting How much have your symptoms interfered with your daily activities?");
        TestUtils.highlightElement(driver, howMuchHaveYourSymptoms);
        TestUtils.selectByVisibleText(driver.findElement(howMuchHaveYourSymptoms), symptoms);
    }

    /**
     * Selecting How is your condition changing, since care at this facility? on Patient Questions Page
     *
     * @param condition
     */
    public void selectDropDownValueInHowIsYourConditionChanging(String condition) {
        log.warn("Selecting How is your condition changing, since care at this facility?");
        TestUtils.highlightElement(driver, howIsYourConditionChanging);
        TestUtils.selectByVisibleText(driver.findElement(howIsYourConditionChanging), condition);
    }

    /**
     * Selecting In general, would you say your overall health right now is... on Patient Questions Page
     *
     * @param health
     */
    public void selectDropDownValueInOverallHealthRightNow(String health) {
        log.warn("Selecting How is your condition changing, since care at this facility?");
        TestUtils.highlightElement(driver, overallHealthRightNowIs);
        TestUtils.selectByVisibleText(driver.findElement(overallHealthRightNowIs), health);
    }
    /**
     * Entering dateReceived on Patient Questions Page
     *
     * @param date
     */
    public void enterdatePatientCompletedQuestions(String date) {
        log.warn("Entering "+ date+ "received");
        TestUtils.highlightElement(driver, datePatientCompletedQuestions);
        driver.findElement(datePatientCompletedQuestions).clear();
        driver.findElement(datePatientCompletedQuestions).sendKeys(date);
    }

    /**
     * Clicking on continue button on Patient Questions Page
     *
     * @return RequestDetailsPage
     */
    public void clickContinueButton() {
        TestUtils.safeClick(driver, pqContinueButton);
    }

    public void verifyQuestionarieCheckbox(int age,  Map<String, String>pf) {
        String dateOfBirth;
        if(((pf.get(MBM.USER_TITLE).contains("PAAN")))){
             dateOfBirth = TestUtils.text(driver,By.xpath("(//span[contains(text(),'DOB')]/following-sibling::span)[2]"));
        }else {
            dateOfBirth = TestUtils.text(driver,dob);
        }
         isChecked= TestUtils.isChecked(driver, patientQuestionnaireCheckbox)?"1" :"0";
        if(age >= DateUtils.getAge(dateOfBirth)) {
            Assert.assertTrue(TestUtils.isChecked(driver, patientQuestionnaireCheckbox));
        }
        else{
            Assert.assertFalse(TestUtils.isChecked(driver, patientQuestionnaireCheckbox));
        }

    }

    public void verifyAllFieldsRequiredHidden() {
        Assert.assertFalse(TestUtils.isElementVisible(driver, allFieldsRequired));

    }
    public void verifyAllFieldsRequiredVisible() {
        Assert.assertTrue(TestUtils.isElementVisible(driver, allFieldsRequired));
    }

    public void verifiesAgainstDb(List<Map<String, Object>> list, Map<String, String> pf) {
        for (Map<String, Object> lst : list) {
            Assert.assertEquals(lst.get("symp_strt_dt").toString(), pf.get(MBM.PQ_DATE_SYMPTOMS_BEGAN));
            Assert.assertEquals(lst.get("symp_desc").toString(), pf.get(MBM.PQ_BRIEFLY_DESCRIBE_YOUR_SYMPTOMS));
            Assert.assertEquals(lst.get("symp_strt_desc").toString(), pf.get(MBM.PQ_HOW_DID_YOUR_SYMPTOMS_START));
            Assert.assertEquals(lst.get("pain_last_day").toString(), pf.get(MBM.PQ_PAIN_IN_LAST_24_HOURS));
            Assert.assertEquals(lst.get("pain_last_week").toString(), pf.get(MBM.PQ_PAIN_IN_LAST_WEEK_1_7_DAYS));
            Assert.assertEquals(lst.get("comp_dt").toString(), pf.get(MBM.PQ_DATE_PATIENT_COMPLETED_QUESTIONS));
            Assert.assertEquals(lst.get("cmplt_psbl_ind").toString(), isChecked);
            Assert.assertEquals(lst.get("symptomsHowOftenPHQ").toString(), pf.get(MBM.PQ_HOW_OFTEN_DO_YOU_FEEL_YOUR_SYMPTOMS));
            Assert.assertEquals(lst.get("symptomsInterfereActivitiesPHQ").toString(), pf.get(MBM.PQ_HOW_MUCH_HAVE_YOUR_SYMPTOMS_INTERFERED_WITH_YOUR_DAILY_ACTIVITIES));
            Assert.assertEquals(lst.get("overallHealthPHQ").toString(), pf.get(MBM.PQ_IN_GENERAL_WOULD_YOU_SAY_YOUR_OVERALL_HEALTH_RIGHT_NOW_IS));
            Assert.assertEquals(lst.get("conditionChangingPHQ").toString(), pf.get(MBM.PQ_HOW_IS_YOUR_CONDITION_CHANGING_SINCE_CARE_AT_THIS_FACILITY));
        }
    }


    public void clickSaveDraft() {
        TestUtils.safeClick(driver, saveDraftButton);
    }

    public void clickBackButton() {
        TestUtils.safeClick(driver, backButton);
    }

    public void verifiesAllFieldsAreSameAsExisting(Map<String, String>  pf) {
        Assert.assertEquals(TestUtils.text(driver, howOftenDoYouFeelYourSymptomsSelectedOption),  pf.get(MBM.PQ_HOW_OFTEN_DO_YOU_FEEL_YOUR_SYMPTOMS));
        Assert.assertEquals(TestUtils.text(driver, howMuchHaveYourSymptomsSelectedOption),  pf.get(MBM.PQ_HOW_MUCH_HAVE_YOUR_SYMPTOMS_INTERFERED_WITH_YOUR_DAILY_ACTIVITIES));
        Assert.assertEquals(TestUtils.text(driver, howIsYourConditionChangingSelectedOption),  pf.get(MBM.PQ_HOW_IS_YOUR_CONDITION_CHANGING_SINCE_CARE_AT_THIS_FACILITY));
        Assert.assertEquals(TestUtils.text(driver, overallHealthRightNowIsSelectedOption),  pf.get(MBM.PQ_IN_GENERAL_WOULD_YOU_SAY_YOUR_OVERALL_HEALTH_RIGHT_NOW_IS));
    }
}
