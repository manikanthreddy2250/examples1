package atdd.test.pageobjects.authorization.physicalHealth;

import atdd.dao.mbm.HscAtrDao;
import atdd.dao.mbm.MyBatisConnectionFactory;
import atdd.dao.mbm.RefDao;
import atdd.test.core.TeamBase;
import atdd.test.core.TeamFactory;
import atdd.test.pageobjects.CommonPage;
import atdd.test.shared.BaseCucumber;
import atdd.utils.DateUtils;
import atdd.utils.StringUtils;
import atdd.utils.TestUtils;
import atdd.utils.WhiteBoard;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.lang.reflect.Field;
import java.security.Key;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

import static org.openqa.selenium.By.cssSelector;
import static org.openqa.selenium.By.xpath;

public class RequestDetailsPagePH {

    private WebDriver driver;
    private TestUtils utils;
    Logger log;
    private String owner;
    public static String imageNumber = "";
    SimpleDateFormat to = new SimpleDateFormat("MM-dd-yyyy");
    SimpleDateFormat from = new SimpleDateFormat("yyyy-MM-dd");

    //Locators-----
    public static final By DateReceived = By.cssSelector("input[ng-model*='dateReceived.hscAttributeValue']");
    public static final By ImageNumber = By.cssSelector("input[id='requestDetailsImageNumber']");
    public static final By PrimaryProviderCredential = By.xpath("//select[contains(@ng-model,'primaryProviderCredential.hscAttributeValue')]");
    public static final By SecondaryProviderCredential = By.xpath("//select[contains(@ng-model,'secondaryProviderCredential.hscAttributeValue')]");
    public static final By NumberOfVisits = By.xpath("//input[contains(@id,'requestDetailsPast90Days')]");
    public static final By DateOfInitialEvaluation = By.xpath("//input[contains(@id,'initialEvaluationCondition-hscAttributeValue-0')]");
    public static final By PatientType = By.xpath("//select[contains(@ng-model,'patientType.hscAttributeValue')]");
    public static final By NatureOfCondition = By.xpath("//select[contains(@ng-model,'natureOfCondition.hscAttributeValue')]");
    public static final By PrimaryCauseOfCurrentEpisode = By.xpath("//select[contains(@ng-model,'primaryCauseOfCurrentEpisode.hscAttributeValue')]");
    public static final By SecondaryCauseOfCurrentEpisode = xpath("//select[contains(@ng-model,'secondaryCauseOfCurrentEpisode.hscAttributeValue')]");
    public static final By SurgeryDate = By.cssSelector("input[ng-model*='surgeryDate.hscAttributeValue']");
    public static final By secondarySurgeryDate = By.xpath("//*[@id='secondarySurgeryDate-hscAttributeValue-0']");
    public static final By secondaryTypeOfSurgery = By.xpath("//*[@id= 'secondaryTypeOfSurgery-hscAttributeValue-0']");
    public static final By secondaryOther = By.xpath("//*[@id='requestDetailsSecSurgeryTypeOther']");
    public static final By TypeOfSurgery = By.xpath("//select[contains(@ng-model,'typeOfSurgery.hscAttributeValue')]");
    public static final By NatureOfTreatment = By.xpath("//select[contains(@ng-model,'natureOfTreatment.hscAttributeValue')]");
    public static final By DateYouWantThisSubmissionToBegin = By.xpath("//input[@name='submissionStartDateMSk']");
    public static final By PlaceOfService = By.xpath("//select[contains(@ng-model,'mskHscPlaceOfService.hscAttributeValue')]");
    public static final By ReasonForLateSubmission = By.xpath("//select[contains(@ng-model,'lateSubmissionReason.hscAttributeValue')]");
    public static final By LateSubmissionNoteIncluded = By.xpath("//select[contains(@ng-model,'lateSubmissionNoteIncluded.hscAttributeValue')]");
    public static final By AdminDenialReview = By.id("adminDenialReviewFlagCheckBox");
    public static final By AdminDenialReviewComment = By.id("adminDenialReviewCommentTextarea");
    public static final By iCDCode = cssSelector("table[class='panelTable'] input[ng-model*='diagnosisCode']");
    public static final By PrimaryDiagnosisCode = xpath("//input[@ng-model='primaryDiagnosis.diagnosisCode']");
    public static final By AdditionalDiagnosisCode = xpath("//input[@ng-model='hscDiagnosisVO.diagnosisCode']");
    public static final By ReasonForLateSubmissionText = By.xpath("//label[contains(text(),'Reason For Late Submission')]");
    public static final By timelyFilingReason = By.xpath("//select[contains(@ng-model,'timelyFilingReason.hscAttributeValue')]");
    public static final By errorPopUpForDuplProviderCredentials = By.xpath("//span[contains(text(),'You entered a duplicate Provider Credential.')]");
    public static final By popUpForPrimAndAdditionalDiagCode = By.xpath("//span[contains(text(),'You entered duplicate Diagnosis Code.')]");
    public static final By continueButton = xpath("//*[contains(@ng-click,'requestDetailContinue(newAuthForm)')]");
    public static final By addDiagCode = By.xpath("//li[contains(@id,'typeahead')][1]/a");
    public static final By addCodeLink = By.xpath("//a[contains(text(),'Add Code')]");
    public static final By allLabels1 = By.xpath("//table//label");
    private String labels = "//table//label[contains(text(),'{fieldName}')]";
    private static By saveDraftBtn = By.xpath("//input[contains(@ng-click,'saveDraft')]");
    public static final By imageNumberFieldValidationMessage = By.cssSelector("div[class='imageError']");
    public static final By dateReceivedValidationMessage = By.xpath("//div[starts-with(@id,'dateReceived-hscAttributeValue_err')]");
    public static final By getDateYouWantThisTreatmentToBeginMessage = By.xpath("//div[starts-with(@id,'treatmentStartDateMsk-hscAttributeValue_err')]");
    public static final By surgeryDateFieldValMessage = By.xpath("//div[starts-with(@id,'surgeryDate-hscAttributeValue_err')]");
    public static final By getErrorPopUpForDuplication = By.xpath("");
    public static final By getICdCodePopup = By.xpath("//span[contains(text(),'You entered duplicate Diagnosis Code.')]");
    public static final By getImageNumberPopUp = By.xpath("//span[contains(text(),'Duplicate Image Number already exists on request')]");
    public static final By surgeryOtherTextField = By.id("requestDetailsSurgeryTypeOther");
    public static final By clickAnywhereInWebPage = By.xpath("//span[contains(text(),'Service Details')]");
    public static final By dateOfInitialEvalErrorMsg = By.xpath("//div[starts-with(@id,'initialEvaluationCondition-hscAttributeValue_err')]");
    public static final By numberOfVisitsErrorMessage = By.xpath("//div[contains(@ng-show, 'checkVisitsFlag')]");
    public static final By scheduledvisits  = By.xpath("//*[@id='requestDetailsVisits']");
    public static final By scheduledFrequency = By.xpath("//*[@id='scheduledFrequencyOfVisits-hscAttributeValue-0']");
    public static final By timelyFilingLateReason = By.xpath("//*[@id='providerLateSubmission-hscAttributeValue-0']");
    final List<String> surgeryFields = Arrays.asList("Surgery Date", "Type of Surgery", "Other");
    final List<String> patientTypeFields =  Arrays.asList("Date of Initial Evaluation for Condition", "Number of Visits Within Past 90 Days", "Scheduled Frequency of Visits");

    //Locators Dupe Check Pop up-----
    public static final By DupeCheckPopUPText = By.xpath("//*[contains(@id,'authDupeCheckPopupDiv')]/p");
    public static final By DupeCheckPopUPContinue = By.xpath("//*[contains(@id,'authDupeCheckPopupDiv')]/following::input[contains(@value,'Continue')][1]");
    public static final By DupeCheckPopUPCancel = By.xpath("//*[contains(@id,'authDupeCheckPopupDiv')]/following::input[contains(@value,'Cancel')]");
    private final String popupText = "A duplicate authorization {authNumber} has already been submitted and is pending or processed. You can review the submitted authorization on the Home Page. If you continue with this authorization, it may be denied upon processing.";

    public RequestDetailsPagePH(WebDriver webDriver) {
        this.driver = webDriver;
        utils = BaseCucumber.utils;
        log = Logger.getLogger(this.getClass().getName());
    }

    //Methods-----

    /**
     * Entering dateReceived on RequestDetailsPage
     *
     * @param date
     */
    public void enterDateReceived(String date) {
        log.warn("Entering " + date + "received");
        TestUtils.highlightElement(driver, DateReceived);
        driver.findElement(DateReceived).clear();
        TestUtils.input(driver, DateReceived, date);
    }

    /**
     * Entering dateReceived on RequestDetailsPage
     *
     * @return Boolean
     */
    public Boolean requestDetailsPHPageIsDisplayed() {
        return TestUtils.isElementPresent(driver, ImageNumber);
    }

    /**
     * Entering imageNumbers on RequestDetailsPage
     */
    public void enterImageNumber(String number, Map<String, String> pf) {
        log.warn("Entering numbers ");
        if (number.isEmpty()) {
            number = StringUtils.randomDigits(13);
        }
        TestUtils.input(driver, ImageNumber, number);
        imageNumber = number;
        pf.replace("rdptImageNumber", number);
    }

    /**
     * Select Late Submission Note
     */
    public void lateSubmissionNote(String note) {
        log.warn("Selecting Late Submission Note");
        TestUtils.select(driver,LateSubmissionNoteIncluded,note);
    }

    /**
     * Entering imageNumbers on RequestDetailsPage
     */
    public String enterPastDateReceived(int days) {
        log.warn("Entering numbers ");
        return TestUtils.getDaysLaterFromToday(Integer.toString(days));
    }


    /**
     * Clicking on continue button on RequestDetailsPage
     *
     * @return RequestDetailsPage
     */
    public void clickContinueButton() {
        TestUtils.safeClick(driver,continueButton );
    }


    /**
     * Entering providerCredential on RequestDetailsPage
     *
     * @param providerCredential
     */
    public void selectDropDownValueInPrimaryProviderCredential(String providerCredential) {

        log.warn("Selecting " + PrimaryProviderCredential + " type Of Credential");
        TestUtils.highlightElement(driver, PrimaryProviderCredential);
        TestUtils.selectByVisibleText(driver.findElement(PrimaryProviderCredential), providerCredential);
    }

    /**
     * Entering secondaryProviderCredential on RequestDetailsPage
     *
     * @param secondaryProviderCred
     */
    public void selectDropDownValueInSecondaryProviderCredentil(String secondaryProviderCred) {
        log.warn("Selecting " + SecondaryProviderCredential + " type Of Credential");
        TestUtils.highlightElement(driver, SecondaryProviderCredential);
        TestUtils.selectByVisibleText(driver.findElement(SecondaryProviderCredential), secondaryProviderCred);
    }
    /**
     * Click Continue on Dupe Check on RequestDetailsPage
     *
     */
    public void clickContinueOnDupeCheckPopUp() {
        log.warn("Click continue on Dupe Check Pop Up");
        TestUtils.highlightElement(driver, DupeCheckPopUPContinue);

        TestUtils.click(driver, DupeCheckPopUPContinue);
    }

    /**
     * Click Continue on Dupe Check on RequestDetailsPage
     *
     */
    public void validateDupeCheckPopUPText(){
        log.warn("Click continue on Dupe Check Pop Up");
        TestUtils.highlightElement(driver, DupeCheckPopUPText);
        Assert.assertEquals("Pop up text did not match",popupText.replace("{authNumber}",RequestStatusPagePH.authNumber),TestUtils.text(driver,DupeCheckPopUPText));
    }

    /**
     * Click Continue on Dupe Check on RequestDetailsPage
     *
     */
    public boolean validateICDPopUPText(String actual){
        log.warn("Click continue on Dupe Check Pop Up");
        TestUtils.highlightElement(driver,  getICdCodePopup);
       return  TestUtils.text(driver,getICdCodePopup).contains(actual);
    }


    /**
     * Click Continue on Dupe Check on RequestDetailsPage
     *
     */
    public void continueEvenIfItsDuplicate(){
        TestUtils.wait(3);
        if(TestUtils.isElementPresent(driver,DupeCheckPopUPText)){
            clickContinueOnDupeCheckPopUp();
            //clickContinueButton();
        }
    }

    /**
     * Entering providerCredential on RequestDetailsPage
     *
     * @param pType
     */
    public void selectDropDownValueInPatientType(String pType) {

        log.warn("Selecting pType");
        TestUtils.highlightElement(driver, PatientType);
        TestUtils.selectByVisibleText(driver.findElement(PatientType), pType);
    }

    /**
     * Select PatientType other than on RequestDetailsPage
     *
     * @param pType
     */
    public void selecPatientTypedDropDown(String pType) {

        log.warn("Selecting pType");
        TestUtils.highlightElement(driver, PatientType);
        List<String> options = TestUtils.getDropdownListOptions(driver, PatientType);
        TestUtils.selectByVisibleText(driver, PatientType, options.stream().filter(x -> !x.equals(pType)).collect(Collectors.toList()).get(1));
    }

    /*
     * Selecting natureOfCondition on RequestDetailsPage
     *
     * @param natCondition
     */
    public void selectDropDownValueInNatureOfCondition(String natCondition) {

        log.warn("Selecting Nature Of Condition");
        TestUtils.highlightElement(driver, NatureOfCondition);
        TestUtils.selectByVisibleText(driver.findElement(NatureOfCondition), natCondition);
    }

    /**
     * Selecting primaryCauseOfCurrentEpisode on RequestDetailsPage
     *
     * @param primaryCause
     */
    public void selectDropDownValueInPrimaryCauseOfCurrentEpisode(String primaryCause) {

        log.warn("Selecting Primary Cause Of Current Episode ");
        TestUtils.highlightElement(driver, PrimaryCauseOfCurrentEpisode);
        TestUtils.selectByVisibleText(driver.findElement(PrimaryCauseOfCurrentEpisode), primaryCause);
    }


    /**
     * Selecting secondaryCauseOfCurrentEpisode on RequestDetailsPage
     *
     * @param secondaryCause
     */
    public void selectDropDownValueInSecondaryCauseOfCurrentEpisode(String secondaryCause) {

        log.warn("Selecting Secondary Cause Of Current Episode ");
        TestUtils.highlightElement(driver, SecondaryCauseOfCurrentEpisode);
        TestUtils.selectByVisibleText(driver.findElement(SecondaryCauseOfCurrentEpisode), secondaryCause);
    }

    /**
     * Selecting natureTreatment on RequestDetailsPage
     *
     * @param natureTreatment
     */
    public void selectDropDownValueInNatureTreatment(String natureTreatment) {

        log.warn("Selecting Nature Of Treatment");
        TestUtils.highlightElement(driver, NatureOfTreatment);
        TestUtils.selectByVisibleText(driver.findElement(NatureOfTreatment), natureTreatment);
    }

    /**
     * Selecting surgeryDate on RequestDetailsPage
     *
     * @param surgeryD
     */
    public void enteringSurgeryDate(String surgeryD) {
        log.warn("Entering " + surgeryD + "date");
        TestUtils.highlightElement(driver, SurgeryDate);
        //driver.findElement(SurgeryDate).clear();
        TestUtils.input(driver, SurgeryDate, surgeryD);
    }

    /**
     * Selecting surgeryDate on RequestDetailsPage
     *
     * @param surgeryD
     */
    public void enteringSecondarySurgeryDate(String surgeryD) {
        log.warn("Entering " + surgeryD + "date");
        TestUtils.highlightElement(driver,  secondarySurgeryDate);
        //driver.findElement(SurgeryDate).clear();
        TestUtils.input(driver, secondarySurgeryDate, surgeryD);

    }

    /**
     * Selecting surgeryDate on TypeOfSurgery
     *
     * @param TypeOfS
     */
    public void selectDropDownValueInSecondaryTypeOfSurgery(String TypeOfS) {
        log.warn("Selecting " + TypeOfS + " type Of Surgery");
        TestUtils.highlightElement(driver,  secondaryTypeOfSurgery);
        TestUtils.wait(2);
        TestUtils.selectByVisibleText(driver.findElement( secondaryTypeOfSurgery), TypeOfS);
    }
    /**
     * Selecting surgeryDate on TypeOfSurgery
     *
     * @param TypeOfS
     */
    public void selectDropDownValueInTypeOfSurgery(String TypeOfS) {
        log.warn("Selecting " + TypeOfS + " type Of Surgery");
        TestUtils.highlightElement(driver, TypeOfSurgery);
        TestUtils.wait(2);
        TestUtils.selectByVisibleText(driver.findElement(TypeOfSurgery), TypeOfS);
    }

    public void enterSecondaryOtherSurgeryType(String type){
        log.warn("Entering " + type + "as Other Surgery");
        TestUtils.highlightElement(driver,  secondaryOther);
        driver.findElement(secondaryOther).clear();
        TestUtils.input(driver, secondaryOther, type);
    }

    /**
     * Entering dateYouWantTheTreatmentToStart on RequestDetailsPage
     *
     * @param TreatmentToStart
     */
    public void enterTextInDateYouWantTheTreatmentToStart(String TreatmentToStart) {
        if(TreatmentToStart.isEmpty()){
            enterLaterDaysFromToday(Integer.toString(new Random().nextInt(150-70) + 70));
        }else {
            log.warn("Entering " + TreatmentToStart + "date");
            TestUtils.highlightElement(driver, DateYouWantThisSubmissionToBegin);
            driver.findElement(DateYouWantThisSubmissionToBegin).clear();
            TestUtils.input(driver, DateYouWantThisSubmissionToBegin, TreatmentToStart);
        }

    }

    public void enterOtherSurgeryType(String type){
        log.warn("Entering " + type + "as Other Surgery");
        TestUtils.highlightElement(driver, surgeryOtherTextField);
        driver.findElement(surgeryOtherTextField).clear();
        TestUtils.input(driver, surgeryOtherTextField, type);
    }

    /**
     * Selecting placeofServicePT on TypeOfSurgery
     *
     * @param placeofService
     */
    public void selectDropDownValueInPlaceofServicePT(String placeofService) {
        log.warn("Selecting " + placeofService + " Place of Service");
        TestUtils.highlightElement(driver, PlaceOfService);
        TestUtils.selectByVisibleText(driver.findElement(PlaceOfService), placeofService);
    }

    /**
     * Selecting reasonForLateSubmission on TypeOfSurgery
     *
     * @param reasonLateSubmission
     */
    public void selectDropDownValueInReasonForLateSubmission(String reasonLateSubmission) {
        log.warn("Selecting "+reasonLateSubmission+" reason for late submission");
        TestUtils.highlightElement(driver, ReasonForLateSubmission);
        TestUtils.selectByVisibleText(driver.findElement(ReasonForLateSubmission), reasonLateSubmission);
    }

    /**
     * Selecting late submission note
     *
     * @param note
     */
    public void selectDropDownValueLateSubmissionNoteIncluded(String note) {
        log.warn("Selecting "+note+" reason for late submission note");
        TestUtils.highlightElement(driver, LateSubmissionNoteIncluded);
        TestUtils.selectByVisibleText(driver.findElement(LateSubmissionNoteIncluded), note);
    }

    /**
     * Select check box Admin Denial Review
     *
     * @param status
     */
    public void selectCheckBoxForAdminDenialReview(String status) {
        log.warn("Selecting "+status+" for Admin Denial Review");
        TestUtils.highlightElement(driver, AdminDenialReview);
        if(!TestUtils.isChecked(driver,AdminDenialReview) && status.equalsIgnoreCase("yes"))
            TestUtils.click(driver,AdminDenialReview);
    }

    public void enterAdminDenialReviewComment(String value){
        log.warn("Enter "+value+" for Admin Denial Review");
        TestUtils.highlightElement(driver, AdminDenialReviewComment);
        TestUtils.input(driver,AdminDenialReviewComment,value);
    }

    /**
     * Selecting reasonForLateSubmission
     *
     * @param reasonTimelyFiling
     */
    public void selectDropDownValueInTimelyFilingReason(String reasonTimelyFiling) {
        log.warn("Selecting "+reasonTimelyFiling+" for reason for late submission");
        TestUtils.highlightElement(driver,  timelyFilingReason);
        TestUtils.selectByVisibleText(driver.findElement(timelyFilingReason),  reasonTimelyFiling );
    }

    /**
     * Selecting reasonForLateSubmission
     *
     * @param reasonTimelyFilingLate
     */
    public void selectDropDownValueInTimelyFilingLateReason(String reasonTimelyFilingLate) {
        log.warn("Selecting "+reasonTimelyFilingLate+" for reason for late submission");
        TestUtils.highlightElement(driver,   timelyFilingLateReason);
        TestUtils.selectByVisibleText(driver.findElement(timelyFilingLateReason),  reasonTimelyFilingLate );
    }


    public void validateIcdCodeAndGetText(List<String> l) {

        log.warn("Verifying icd10 code");

        for (int i = 0; i < l.size(); i++) {
            TestUtils.input(driver, iCDCode, l.get(i));
            By icdDropDown = By.xpath("//a[contains(@title,'" + l.get(i) + "')]");
            String ICDText = TestUtils.text(driver, icdDropDown);
            Assert.assertTrue("X action button Drug Exception Notification", ICDText.equals(l.get(i)));

        }

    }

    public String getValueFromProfile(String field1, Map<String, String> pf) {
        String expectedValue = "";
        if (field1.equalsIgnoreCase("Image Number"))
            expectedValue = imageNumber;
        else if (field1.equalsIgnoreCase("Authorization Type"))
            expectedValue = pf.get("authAuthorizationType");
        else
            expectedValue = WhiteBoard.resolve(owner, pf.get(("rdpt" + field1).replaceAll(" ", "")));
        return expectedValue;
    }

    public String getValueFromUI(String field1, By webElement) {
        String actualValue = "";
        List<String> nonDropDown = new ArrayList<>();
        String[] nonDropDownFields = {"Date Received", "Date You Want This Submission To Begin", "Primary Diagnosis Code", "Image Number"};
        Collections.addAll(nonDropDown, nonDropDownFields);
        if (nonDropDown.contains(field1)) {
            actualValue = driver.findElement(webElement).getAttribute("value");
            if (field1.equalsIgnoreCase("Primary Diagnosis Code"))
                actualValue = actualValue.substring(0, 6);
        } else
            actualValue = TestUtils.getSelectedValueFromDropdown(driver, webElement);
        return actualValue;
    }


    /**
     * Entering Primary iCD10CodeText on RequestDetailsPage
     *
     * @param iCD10CodeText
     */
    public void enterPrimaryIcdCodeAndClickAddCode(String iCD10CodeText) {

        TestUtils.input(driver, PrimaryDiagnosisCode, iCD10CodeText);
        TestUtils.wait(2);
        TestUtils.click(driver, By.xpath("//*[contains(@id,'typeahead')]/a/strong"));
        TestUtils.wait(2);
    }

    /**
     * Entering Initial on RequestDetailsPage
     *
     * @param intialEvaluation
     */
    public void enterDateOfInitialEvaluation(String intialEvaluation) {
        log.warn("Entering " + intialEvaluation + "received");
        TestUtils.highlightElement(driver, DateOfInitialEvaluation);
        TestUtils.input(driver, DateOfInitialEvaluation, intialEvaluation);
    }

    /**
     * Entering    number of visits on RequestDetailsPage
     *
     * @param days
     */
    public void enterNumberOfVisits90Days(String days) {
        log.warn("Entering " + days + "received");
        TestUtils.highlightElement(driver, NumberOfVisits);
        TestUtils.input(driver, NumberOfVisits, days);
    }

    /**
     * Entering number of visits on RequestDetailsPage
     *
     * @param days
     */
    public void enterScheduledNumberOfVisits(String days) {
        log.warn("Entering " + days + "into Scheduled number of Visits");
        TestUtils.highlightElement(driver,  scheduledvisits);
        TestUtils.input(driver,  scheduledvisits, days);
        TestUtils.selectByVisibleText(driver.findElement(scheduledFrequency), "Monthly");
    }

    /**
     * Entering Primary iCD10CodeText on RequestDetailsPage
     *
     * @param additionalDiagCode
     */
    public void enterAdditionalDiagCodeAndClickAddCode(String additionalDiagCode) {

            TestUtils.input(driver, AdditionalDiagnosisCode, additionalDiagCode);
            TestUtils.waitElementVisible(driver, addDiagCode);
            TestUtils.wait(6);
            TestUtils.click(driver, addDiagCode);
            TestUtils.wait(4);
            TestUtils.click(driver, addCodeLink);

    }

    /**
     * Entering additional ICD codes iCD10CodeText on RequestDetailsPage
     *
     * @param  num
     */
    public void enterNineAdditionalDiagcodes(int num)
    {
        int MAX_SIZE = 19;

        List<String> randoms = new ArrayList<String>();

        int currentSize = driver.findElements(By.xpath("//*[@id='serviceDetailsTherapySection']//tr")).size();

        while(currentSize<= MAX_SIZE)
        {
            int count =  driver.findElements(By.xpath("//*[@id='serviceDetailsTherapySection']//tr")).size();
            String digit = StringUtils.randomDigits(3);
            if(!randoms.stream().anyMatch(x -> x.contains(digit))) {
                TestUtils.input(driver, AdditionalDiagnosisCode, digit);
                TestUtils.wait(2);
                if (TestUtils.isElementPresent(driver, addDiagCode) && TestUtils.isClickable(driver, addDiagCode)) {

                    TestUtils.click(driver, driver.findElement(addDiagCode));
                    TestUtils.wait(4);
                    TestUtils.click(driver, driver.findElement(addCodeLink));
                        if( driver.findElements(By.xpath("//*[@id='serviceDetailsTherapySection']//tr")).size() == count) {
                        TestUtils.click(driver, driver.findElement(addCodeLink));
                        }
                    TestUtils.wait(4);
                    randoms.add(digit);

                }

            }
            currentSize++;

        }
    }


    public void enterAdditionalDiagcodes(int num){

    }


    /**
     * Entering iCD10CodeText on RequestDetailsPage
     *
     * @param iCD10CodeText
     */
    public void enterTextinIcdCode(String iCD10CodeText) {
        selectingICDcode(iCD10CodeText);
    }

    public void selectingICDcode(String iCD10CodeText) {
        TestUtils.input(driver, iCDCode, iCD10CodeText);
    }

    /**
     * Entering LaterDate on RequestDetailsPage
     *
     * @param date
     */
    public void enterLaterDaysFromToday(String date) {
        log.warn("Entering " + date + "received");
        TestUtils.highlightElement(driver, DateYouWantThisSubmissionToBegin);
        driver.findElement(DateYouWantThisSubmissionToBegin).clear();
        driver.findElement(DateYouWantThisSubmissionToBegin).sendKeys(TestUtils.getDaysLaterFromToday(date));
        driver.findElement(DateYouWantThisSubmissionToBegin).sendKeys(Keys.TAB);
    }

    /**
     * Entering allLabels on RequestDetailsPage
     *
     * @param allLabels
     */
    public void validateAllVisibleLabels(ArrayList<String> allLabels) {
        log.warn("Checking all existing fields on Request Details Page");
        for (String label : allLabels) {
            Assert.assertTrue(TestUtils.isLabelPresent(driver, label));
        }
    }


    /**
     * Clicking Continue Button on RequestingDetailsPage
     */
    public void clickSaveDraftButton() {
        log.warn("Clicking Save Draft Button");
        TestUtils.waitElement(driver, saveDraftBtn);
        TestUtils.onMouseHover(driver, saveDraftBtn);
        TestUtils.wait(5);
        TestUtils.highlightElement(driver, saveDraftBtn);
        driver.findElement(saveDraftBtn).click();
        TestUtils.wait(1);
    }

    public void validateAllEnteredValues(ArrayList<String> allFields, Map<String, String> pf) {
        log.warn("Checking all entered values on Request Details Page");
        Field[] fields = RequestDetailsPagePH.class.getDeclaredFields();
        for (String field1 : allFields) {
            By webElement = getWebElementOfAField(fields, field1);
            Assert.assertTrue(getValueFromUI(field1, webElement).equals(getValueFromProfile(field1, pf)));
        }
    }

    public By getWebElementOfAField(Field[] fields, String field1) {
        By webElement = null;
        try {
            for (Field field : fields) {
                if (field.getType() == By.class) {
                    field.setAccessible(true);
                    if (field.getName().equals(field1.replaceAll(" ", ""))) {
                        webElement = (By) field.get(RequestDetailsPagePH.class);
                        break;
                    }
                }
            }
        } catch (Exception ex) {
        }
        return webElement;
    }


    public void validateHSCAtrData(ArrayList<String> allFields, Map<String, String> pf) {
        long hscID = TestUtils.getHscIdFromURL(driver.getCurrentUrl());
        List<Map<String, Object>> list = new HscAtrDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectById(hscID);
        allFields.add("Authorization Type");
        for (String field1 : allFields) {
            String enteredValue = getValueFromProfile(field1, pf);
            String dbValue = "";
            if (field1.equalsIgnoreCase("Date You Want This Submission To Begin"))
                field1 = "TreatmentStartDate";
            for (Map<String, Object> value : list) {
                if (field1.replaceAll(" ", "").toLowerCase().contains
                        (value.get("ref_desc").toString().replaceAll(" ", "").replaceAll("MSK", "").toLowerCase())) {
                    String name = getNameOfAttribute(field1);
                    List<String> dbValues = new RefDao(MyBatisConnectionFactory.getSqlSessionFactory())
                            .refNameDescriptionByCode(name, value.get("hsc_atr_val").toString());
                    if (dbValues.size() == 0)
                        dbValue = value.get("hsc_atr_val").toString();
                    else
                        dbValue = dbValues.get(0);
                    break;
                }
            }
            if (field1.equalsIgnoreCase("Date Received") || field1.equalsIgnoreCase("TreatmentStartDate")) {
                try {
                    dbValue = to.format(from.parse(dbValue));
                } catch (Exception ex) {
                }
            }
            Assert.assertEquals(enteredValue, dbValue);
        }
    }

    public String getNameOfAttribute(String field) {
        String name = "";
        switch (field) {
            case "Primary Provider Credential":
                name = "primaryProviderCredential";
                break;
            case "Secondary Provider Credential":
                name = "secondaryProviderCredential";
                break;
            case "Primary Cause Of Current Episode":
                name = "primaryCauseOfCurrentEpisode";
                break;
            case "Secondary Cause Of Current Episode":
                name = "secondaryCauseOfCurrentEpisode";
                break;
            case "Place Of Service":
                name = "mskHscPlaceOfService";
                break;
            case "Nature Of Treatment":
                name = "natureOfTreatment";
                break;
            case "Nature Of Condition":
                name = "natureOfCondition";
                break;
            case "Patient Type":
                name = "patientType";
                break;
            case "Authorization Type":
                name = "authorizationType";
                break;
            default:
                name = "";
                break;
        }
        return name;
    }


    /**
     * validate specific field label on RequestDetailsPage
     *
     * @param label
     */
    public void validateVisibleLabel(String label) {
        log.warn("Checking " + label + " field on Request Details Page");
        TestUtils.click(driver, clickAnywhereInWebPage);
        By element = By.xpath(labels.replace("{fieldName}", label));
        TestUtils.waitElementVisible(driver,  element);
        TestUtils.scrollToElement(driver, element);
        Assert.assertTrue("Could not find " +label, TestUtils.isElementPresent(driver,  element));
    }


    public void verifyConditionalFields(String fieldName) {
        if (fieldName.contains("Surgery")) {
            for (String field : surgeryFields)
                validateVisibleLabel(field);
        } else
            for (String field : patientTypeFields)
                validateVisibleLabel(field);
    }

    public void verifySecondaryConditionalFields(){
        Assert.assertTrue("Could not find secondary surgery date", TestUtils.isElementPresent(driver, secondarySurgeryDate));
        Assert.assertTrue("Could not find secondary Type of Surgery",TestUtils.isElementPresent(driver, secondaryTypeOfSurgery));
        Assert.assertTrue("Could not find secondary Other ",TestUtils.isElementPresent(driver, secondaryOther));
    }
    }


