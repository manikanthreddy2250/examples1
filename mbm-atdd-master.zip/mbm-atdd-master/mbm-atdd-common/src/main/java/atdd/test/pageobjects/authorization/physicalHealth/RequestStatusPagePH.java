package atdd.test.pageobjects.authorization.physicalHealth;

import atdd.common.ScenarioLogger;
import atdd.dao.mbm.HscSrvcNonFaclDao;
import atdd.dao.mbm.MyBatisConnectionFactory;
import atdd.test.shared.BaseCucumber;
import atdd.test.shared.Globals;
import atdd.utils.DateUtils;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.Date;
import java.util.List;
import java.util.Map;

import static atdd.utils.TestUtils.text;

/**
 * Created by Yashwanth on 08/17/2020.
 */
public class RequestStatusPagePH {

    Logger log;
    private WebDriver driver;
    private TestUtils utils;
    private Globals glb;
    private final String approvedMessage = "";
    private final String deniedMessage = "";
    public static String authNumber = "";

    //Locators--------
    public static By authorizationNumber = By.xpath("//td[@class='approvedDetails']//td[contains(.,'Request Number') or contains(.,'Authorization Number')]/following-sibling::td[1]/span");
    public static By authorizationStatus = By.xpath("//td[@class='approvedDetails']//td[contains(.,'Request Status') or contains(.,'Authorization Status')]/following-sibling::td[1]/span");
    public static By authorizationStartDate = By.xpath("//td[@class='approvedDetails']//td[contains(.,'Request Start Date') or contains(.,'Authorization Start Date')]/following-sibling::td[1]");
    public static By authorizationEndDate = By.xpath("//td[@class='approvedDetails']//td[contains(.,'Request End Date') or contains(.,'Authorization End Date')]/following-sibling::td[1]");
    public static By authorizationType = By.xpath("//*[contains(@class,'ng-binding title')]");
    public static By approvedAuthText = By.xpath("//*[contains(@ng-if,'isApprovedStatus||finalConfirm.isComplete') and starts-with(.,'This is')]");
    public static By totalNumOfVisits  = By.xpath("//label[contains(.,'Total number of Visits')]/following::span[contains(@class,'ng-Scope ng-binding ng-scope')]");


    //Locators--------

    public RequestStatusPagePH(WebDriver webDriver) {
        this.driver = webDriver;
        utils = BaseCucumber.utils;
        log = Logger.getLogger(this.getClass().getName());
        this.glb = BaseCucumber.gv;
    }

    //Methods
    /**
     * Verifying AuthorizationRequestStatus on RequestStatusPage
     * @param expectedRequestStatusMessage
     */
    public void verifyAuthorizationRequestStatus(String expectedRequestStatusMessage) {
       // TestUtils.scrollToElement(driver, authorizationStatus);
        //TestUtils.waitElement(driver, authorizationStatus);
       // String actualRequestStatusMessage = driver.findElement(authorizationStatus).getText();
        log.warn("verifying Authorization Request Status");
        Assert.assertTrue("authorization request status is not matching with actual authorization request status",
                TestUtils.waitElementVisible(driver, "//td[@class='approvedDetails']//span[contains(., '"+expectedRequestStatusMessage+"')]"));
    }

    /**
     * verifying Authorization Start Date on RequestStatusPage
     */
    public void verifyTAuthorizationStartDate() {
        log.warn("verifying Authorization Start Date in request status page");
        String actualAuthorizationStartDate = driver.findElement(authorizationStartDate).getText();
        Long hscID = TestUtils.getHscIdFromURL(driver.getCurrentUrl());
        List<Map<String,Object>> values = new HscSrvcNonFaclDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectById(hscID);
        Assert.assertTrue("Authorization Start Date does not match with given date.",
                actualAuthorizationStartDate.equals(values.get(0).get("srvc_strt_dt").toString()));
    }

    /**
     * verifying Authorization Type on RequestStatusPage
     * @param authType
     */
    public void verifyAuthorizationType(String authType) {
        log.warn("verifying Authorization Type in request status page");
        String actualAuthorizationType = driver.findElement(authorizationType).getText();
        Assert.assertTrue("Authorization Type does not match.",
                actualAuthorizationType.equals(authType));
    }


    /**
     * verifying Authorization Number on RequestStatusPage
     */
    public void verifyAuthorizationNumber() {
        log.warn("verifying Authorization Number in request status page");
        String actualAuthorizationType = getAuthNumber();
        String hscID = Long.toString(TestUtils.getHscIdFromURL(driver.getCurrentUrl()));
        Assert.assertTrue("Authorization Number does not match with HSC ID.",
                actualAuthorizationType.contains(hscID));
    }


    /**
     * verifying Authorization End Date on RequestStatusPage
     */
    public void verifyTAuthorizationEndDate() {
        log.warn("verifying Authorization End Date in request status page");
        String actualAuthorizationEndDate = driver.findElement(authorizationEndDate).getText();
        Long hscID = TestUtils.getHscIdFromURL(driver.getCurrentUrl());
        List<Map<String,Object>> values = new HscSrvcNonFaclDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectById(hscID);
        Assert.assertTrue("Authorization Start Date does not match with given date.",
                actualAuthorizationEndDate.equals(values.get(0).get("srvc_end_dt").toString()));
    }

    /**
     * verifying Authorization Message on RequestStatusPage
     * @param status
     */
    public void verifyAuthorizationMessage(String status) {
        log.warn("verifying Authorization Message in request status page");
        String actualAuthorizationText = driver.findElement(approvedAuthText).getText();
        String expectedAuthorizationText = "";
        if(status.equalsIgnoreCase("Approved"))
            expectedAuthorizationText = approvedMessage;
        else if(status.equalsIgnoreCase("Criteria Not Met"))
            expectedAuthorizationText = deniedMessage;
        Assert.assertEquals(status +" message does not match expected text",expectedAuthorizationText,actualAuthorizationText);
    }

    /**
     * verifying Visit Count on RequestStatusPage
     */
    public void verifyNumberOfVisits(){
        log.warn("verifying Authorization Message in request status page");
        long hscID = TestUtils.getHscIdFromURL(driver.getCurrentUrl());
        String actualVisitCount= driver.findElement(totalNumOfVisits).getText();
        String expectedVisitCount = new HscSrvcNonFaclDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectById(hscID).get(0).get("proc_unit_cnt").toString().substring(0,0);
        Assert.assertEquals("Visit Count does not match with DB",actualVisitCount,expectedVisitCount);
    }

    /**
     * Store Request Number on RequestStatusPage
     */
    public void storeAuthNumber() {
        log.warn("Storing Authorization Number on Request Status Page");
        TestUtils.wait(10);
        authNumber = getAuthNumber();
        log.warn("Authorization Number is " + authNumber);
    }

    /**
     * Get Authorization Number on Request Status Page
     *
     * @return
     */
    public String getAuthNumber() {
        log.warn("Get Authorization Number on Request Status Page");
        TestUtils.wait(10);
        TestUtils.waitElementVisible(driver, authorizationNumber);
        return driver.findElement(authorizationNumber).getText();

    }

    /**
     * Verifying End Date is not present on RequestStatusPage
     */
    public void verifyEndDateHidden() {
        log.warn("Verifying End date is not present");
        Assert.assertFalse("End date is displayed", driver.getPageSource().contains("end date"));
    }

    /**
     * Verifying End Date is not present on RequestStatusPage
     */
    public void verifyStartDateHidden() {
        log.warn("Verifying End date is not present");
        Assert.assertFalse("Start date is displayed", driver.getPageSource().contains("start date"));
    }

    /**
     * Verifying Visit Count is not present on RequestStatusPage
     */
    public void verifyNumberOfVisitsHidden() {
        log.warn("Verifying End date is not present");
        Assert.assertFalse("Visit Count is displayed", driver.getPageSource().contains("Number of Visits"));
    }

    /**
     * @return String: the displayed Authorization Number
     */
    public String getAuthorizationNumber() {
        log.warn("the displayed Authorization Number");
        TestUtils.waitElementVisible(driver, authorizationNumber);
        return driver.findElement(authorizationNumber).getText();
    }

    /**
     * @return String: the Calculated Duration: number of weeks between Start Date and End Date
     */
    public String getCalculatedAuthorizationDuration() {
        log.warn("the Calculated Duration: number of weeks between Start Date and End Date");
        try {
            TestUtils.waitElementVisible(driver, authorizationEndDate);
            TestUtils.waitElementVisible(driver, authorizationStartDate);
            String sStart = text(driver, authorizationStartDate);
            String sEnd = text(driver, authorizationEndDate);;
            Date dStart = DateUtils.mmDdYyyy(sStart);
            Date dEnd = DateUtils.mmDdYyyy(sEnd);
            int weeksBetween = DateUtils.weeksBetween(dStart, dEnd);
            return "" + weeksBetween;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * @return String: the displayed Total Number of Visits
     */
    public String getNumberVisits() {
        log.warn("the displayed Total Number of Visits");
        TestUtils.waitElementVisible(driver, totalNumOfVisits);
        return driver.findElement(totalNumOfVisits).getText();
    }


    //Methods
}

