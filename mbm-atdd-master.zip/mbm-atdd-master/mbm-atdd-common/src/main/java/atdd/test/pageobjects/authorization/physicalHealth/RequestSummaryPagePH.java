package atdd.test.pageobjects.authorization.physicalHealth;

import atdd.test.shared.BaseCucumber;
import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import static org.openqa.selenium.By.cssSelector;

public class RequestSummaryPagePH {
    private WebDriver driver;
    private TestUtils utils;
    Logger log;

    //Locators-----
    public static final By submitButton = cssSelector("[id='requestSummaryPanelId'] input[value='Submit']");


    public RequestSummaryPagePH(WebDriver webDriver) {
        this.driver = webDriver;
        utils = BaseCucumber.utils;
        log = Logger.getLogger(this.getClass().getName());
    }


    //Methods------
    /**
     * Clicking on submit button on Request Summary Page
     */
    public void clickSubmitButton() {
        log.warn("Clicking on submit button on Request Summary Page\n");
        TestUtils.waitElement(driver, submitButton);
        TestUtils.isElementPresent(driver, submitButton);
        TestUtils.click(driver, submitButton);

    }

}
