package atdd.test.pageobjects.authorization.physicalHealth;

import atdd.test.shared.BaseCucumber;
import atdd.test.shared.Globals;
import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import static org.openqa.selenium.By.xpath;

/**
 * Created by Vinay Kumar on 01/17/2020.
 */
public class UMPagePH {

    Logger log;
    private WebDriver driver;
    private TestUtils utils;
    private Globals glb;

    public static By floatingButtonPlusSign = xpath("//button[contains(@ng-click,'setAddMenu')]");
    public static By denialFloatingButton = xpath("//button[contains(@data-id,'WorkQueue.ReviewCase.Add--denialButton')]");
    public static By approveFloatingButton = xpath("//button[contains(@data-id,'WorkQueue.ReviewCase.Add--approvalButton')]");
    public static By notesFloatingButton = xpath("//button[contains(@data-id,'WorkQueue.ReviewCase.FloatingNotes--openNotesButton')]");
    public static By activityFloatingButton = xpath("//button[contains(@ng-click,'setShowAddActivity')]");

    public static By categoryDD = By.xpath("//select[contains(@ng-model,'hscServiceDecisionVO.decnClinicalRespCatgryId')]");
    public static By responseDD = By.xpath("//select[contains(@ng-model,'responsesChoices')]");
    public static By submitButton = By.xpath("//input[contains(@data-id,'WorkQueue.ReviewCase.Add.ApprovalOrDenial--submitButton')]");
    public static By addResponseLink = By.xpath("//a[@ng-if='showAddResponseButton']");

    public static By noteTextArea = xpath("//textarea[@id='notesArea']");
    public static By noteFromFloatingButtonTextArea = xpath("//textarea[@id='notesAddArea']");
    public static By noteSaveButton = xpath("//input[@id='notesSaveButton']");
    public static By noteFromFloatingButtonSaveButton = xpath("//input[@id='addSaveButton']");
    public static String viewNotesXpath= "//div[contains(@ng-click,'viewNote')]";

    public static By editProviderButton = xpath("//a[contains(@ng-click,'enableEdit')]");
    public static By providerPhoneNumberTxt = xpath("//input[contains(@id,'editProvider-editRequestingVO-primaryPhone') and @type ='tel']");
    public static By providerDetailSaveButton   = xpath("//input[contains(@ng-click, 'providerDetailsSave')]");
    public static By providerPhoneLabel = xpath("//form[@name='requestingForm']//tr[td[span[label[text()='Phone Number']]]]/td[2]");

    public static By addAssignmentLink = xpath("//a[text()='Add Assignment']");

    public UMPagePH(WebDriver webDriver) {
        this.driver = webDriver;
        utils = BaseCucumber.utils;
        log = Logger.getLogger(this.getClass().getName());
        this.glb = BaseCucumber.gv;
    }

    public void verifyUMTabName(String expectedTabName) {
       log.warn("verifying UM Tabs");
        TestUtils.waitForAngularRequestsToFinish(driver);
        TestUtils.waitElementVisible(driver, "//button[contains(@ng-repeat,'tabpanels') and text()='"+expectedTabName+"']");
    }

    public void clickOnUMTabName(String expectedTabName) {
        TestUtils.wait(1);
        TestUtils.waitForAngularRequestsToFinish(driver);
        verifyUMTabName(expectedTabName);
        By tabLabelXpath = xpath("//button[contains(@ng-repeat,'tabpanels') and text()='"+expectedTabName+"']");
        TestUtils.click(driver, tabLabelXpath);
        TestUtils.wait(1);
        By tabHeaderXpath = xpath("//span[contains(@ng-if,'panel.title') and contains(text(),'"+expectedTabName+"')]");
        TestUtils.click(driver, tabHeaderXpath);
    }


    public void userTakesDenialDecision(String category, String response) {
        TestUtils.wait(20);
        driver.manage().window().maximize();

        TestUtils.waitElementVisible(driver, floatingButtonPlusSign);
        TestUtils.click(driver, floatingButtonPlusSign);

        TestUtils.waitElementVisible(driver, denialFloatingButton);
        TestUtils.click(driver, denialFloatingButton);

        TestUtils.waitElementVisible(driver, categoryDD);
        TestUtils.select(driver, categoryDD, category);

        TestUtils.waitElementVisible(driver, responseDD);
        TestUtils.select(driver, responseDD, response);

        TestUtils.waitElementVisible(driver, submitButton);
        TestUtils.click(driver, submitButton);
        TestUtils.wait(20);
    }

    public void userTakesApprovedDecision(String response) {
        TestUtils.wait(20);
        driver.manage().window().maximize();

        TestUtils.waitElementVisible(driver, floatingButtonPlusSign);
        TestUtils.click(driver, floatingButtonPlusSign);

        TestUtils.waitElementVisible(driver, approveFloatingButton);
        TestUtils.click(driver, approveFloatingButton);

        TestUtils.waitElementVisible(driver, addResponseLink);
        TestUtils.click(driver, addResponseLink);

        TestUtils.waitElementVisible(driver, responseDD);
        TestUtils.select(driver, responseDD, response);

        TestUtils.waitElementVisible(driver, submitButton);
        TestUtils.click(driver, submitButton);
        TestUtils.wait(20);
    }


    public void userValidateDenialDecision(String category, String response) {
        validateUMFieldValue("Category", category);
        validateUMFieldValue("Responses", response);
    }


    public void userValidateApprovalDecision(String response) {
        validateUMFieldValue("Responses", response);
    }

    public void validateUMFieldValue(String fieldName, String value) {
        By responseLabel   = By.xpath("//tr[td[span[label[text()='"+fieldName+"']]]]/td[2][contains(.,'"+value+"')]");
        TestUtils.waitElementVisible(driver, responseLabel);
    }

    public void userEnterRandomNotesAndValidateTheSame() {
        driver.findElement(noteTextArea).sendKeys("Notes Testing From note section");
        TestUtils.click(driver, noteSaveButton);
        TestUtils.wait(5);
        Assert.assertEquals(1, TestUtils.countElementsByXpath(driver, viewNotesXpath));


        TestUtils.waitElementVisible(driver, floatingButtonPlusSign);
        TestUtils.click(driver, floatingButtonPlusSign);

        TestUtils.wait(5);
        TestUtils.waitElementVisible(driver, notesFloatingButton);
        TestUtils.click(driver, notesFloatingButton);

        driver.findElement(noteFromFloatingButtonTextArea).sendKeys("Note Testing from Floating button");
        TestUtils.click(driver, noteFromFloatingButtonSaveButton);
        TestUtils.wait(5);
        Assert.assertEquals(2, TestUtils.countElementsByXpath(driver, viewNotesXpath));
    }

    public void userEditProviderDetailsAndValidateTheSame() {

        TestUtils.click(driver, editProviderButton);
        TestUtils.wait(3);
        driver.findElement(providerPhoneNumberTxt).sendKeys("111-111-1112");
        TestUtils.click(driver, providerDetailSaveButton);

        TestUtils.wait(5);
        TestUtils.waitElementVisible(driver, providerPhoneLabel);
        //validateUMFieldValue("Phone Number","111-111-1112");
    }

    public void userAddAssignmentAndValidateTheSame() {

        TestUtils.click(driver, addAssignmentLink);
        TestUtils.wait(3);
        driver.findElement(providerPhoneNumberTxt).sendKeys("111-111-1112");
        TestUtils.click(driver, providerDetailSaveButton);

        TestUtils.wait(5);
        TestUtils.waitElementVisible(driver, providerPhoneLabel);
        //validateUMFieldValue("Phone Number","111-111-1112");
    }




}

