package atdd.test.pageobjects.dashboard;

import atdd.test.shared.BaseCucumber;
import atdd.test.shared.Globals;
import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.Map;

public class Dashboard {

    Globals gv = BaseCucumber.gv;
    Logger log;
    private WebDriver driver;
    private TestUtils utils;
    private String owner;

    //Locators
    private By priorAuthNewReqLink = By.xpath("//h2[text()='Draft Prior Authorization Requests']/parent::div/span/a[text()='Create New Request']");
    private By draftsNewReqLink = By.xpath("//h2[text()='Submitted Prior Authorization Requests']/parent::div/span/a[text()='Create New Request']");
    private By staticContentXpath = By.cssSelector("[id='content-wrapper'] [class='helperTool']");
    public static By switchPayer = By.cssSelector("[id='content-wrapper'] [class='ng-binding ng-scope']");
    public static By switchBCBSPayerButton = By.xpath("//button[contains(text(), 'Swap to The other unnamed payer')]");
    public static By switchUHCPayerButton = By.xpath("//button[contains(text(), 'Swap to The Payer BCBSSC')]");
    public static final String activityTrackingWidget_XPATH = "//table[@id='viewActivityTrackingOperationID']";
    public static By openAuthIcon = By.xpath("(//span[@title='Open Authorization'])[1]");

//Optum Care Customer selection

    public static By cusselectionTypeDropDown = By.xpath("//div[@id='customer-selection-header']/span");
    public static By switchUHCCustomer = By.xpath("//div[@id='customer-selection-list']/div[3]/div[2]");
    public static By switchBCBSCustomer = By.xpath("//div[@id='customer-selection-list']/div[1]/div[2]");
    public static By switchOnArizonaCustomer = By.xpath("//div[@id='customer-selection-list']/div[2]/div[2]");
    public static By switchSouthwestMedicalCustomer = By.xpath("//div[@id='customer-selection-list']/div[2]/div[4]");
    public static By switchBCBSCustomerName = By.xpath("(//div[contains(text(), 'BlueCross BlueShield of')])[1]");
    public static By switchUHCCustomerName = By.xpath("(//div[contains(text(), 'UnitedHealthcare')])[1]");
    public static By switchArizonaCustomerName = By.xpath("(//div[contains(text(), 'OptumCare Network - Arizona')])[1]");
    public static By switchSouthwestMedicalCustomerName = By.xpath("(//div[contains(text(), 'Southwest Medical')])[1]");


    public Dashboard(WebDriver webDriver) {
        this.driver = webDriver;
        utils = BaseCucumber.utils;
        log = Logger.getLogger(this.getClass().getName());
    }

    //Methods


    /**
     * Verifying the status of auth on Dashboard as Completed
     */
    public void check_Status_SearchSubmitted() {
        log.warn("Checking status of authorization as Completed");
        String reqNumber = gv.getRequestNumber();
        Assert.assertEquals("Status is not completed", driver.findElement(By.xpath("//span[text()='" + reqNumber + "']/parent::td/following-sibling::td[3]")).getText(), "Completed");

    }

    /**
     * Verifying that End Date is blank on Dashboard page
     */
    public void check_EndDate_SearchSubmitted() {
        log.warn("Checking status of authorization");
        String reqNumber = gv.getRequestNumber();
        Assert.assertEquals("End Date is not blank for the auth", driver.findElement(By.xpath("//span[text()='" + reqNumber + "']/parent::td/following-sibling::td[5]")).getText(), "-");

    }

    /**
     * Click on create New Request link on prior auth section on Dashboard page
     */
    public void createNewAuthFromPriorAuthReqWidget() {
        log.warn("Clicks on create New Request link on prior auth section on CreateAuthorization page ");
        TestUtils.waitElement(driver, priorAuthNewReqLink);
        TestUtils.highlightElement(driver, priorAuthNewReqLink);
        driver.findElement(priorAuthNewReqLink).click();
    }

    /**
     * Click on create New Request link on Drafts auth section on Dashboard page
     */
    public void createNewAuthFromDraftsWidget() {
        log.warn("Clicks on create New Request link on Drafts auth section on CreateAuthorization page");
        TestUtils.waitElement(driver, draftsNewReqLink);
        TestUtils.highlightElement(driver, draftsNewReqLink);
        driver.findElement(draftsNewReqLink).click();
    }

    /*verifying the Header content on Dashboard page
     * @param staticContent
     */
    public void verifyStaticContent(String staticContent) throws InterruptedException {
        TestUtils.highlightElement(driver, staticContentXpath);
        String staticContentText = driver.findElement(staticContentXpath).getText();
        staticContentText = staticContentText.replace("\n", "").replace("\r", "");
        Assert.assertTrue("Static Content Does not match ", staticContent.equals(staticContentText));
    }

    public By getCloneIconLocator(String authNumber) {
        return By.xpath("//table[@id='viewAuthorizationTableID']//td[contains(.,'" + authNumber + "')]/preceding-sibling::td[1]//span[@title='Clone Request']");
    }

    /**
     * Verify Clone Icon is not present on Dashboard
     */
    public void verifyCloneIconLocatorNoPresent() {
        log.warn("Verify Clone Icon is not present on the dashboard");
        By cloneIcon = By.xpath("//table[@id='viewAuthorizationTableID']//td[contains(.,'" + gv.getRequestNumber() + "')]/preceding-sibling::td[1]//span[@title='Clone Request']");
        Assert.assertFalse("Clone Icon is present", (TestUtils.isElementPresent(driver, cloneIcon)));
    }

    /**
     * Verify and click document Icon on Dashboard
     */
    public void verifyAndClickDocumentIconOnDeshboard(String RequestNumber) {
        log.warn("Verify and click document Icon on Dashboard");
        By documentIcon = By.xpath("//table[@id='viewAuthorizationTableID']//td[contains(.,'" + RequestNumber + "')]/preceding-sibling::td[1]//span[contains(@class,'cux-icon-document')]");
        Assert.assertFalse("Clone Icon is present", (TestUtils.isElementPresent(driver, documentIcon)));
        TestUtils.click(driver, documentIcon);
    }

    public void verifyTop10SubmittedAuthorizations(List<Map<String, Object>> hsc) {
        By RequestNumbersGridXpath = By.xpath("//*[@id='viewAuthorizationTableID']/tbody/tr/td[2]");
        List<WebElement> RequestNumbersUIXpath = driver.findElements(RequestNumbersGridXpath);
        if (RequestNumbersUIXpath.size() == hsc.size()) {
            for (int i = 0; i < RequestNumbersUIXpath.size(); i++) {
                log.warn(hsc.get(i).get("RequestNumber") + "" + RequestNumbersUIXpath.get(i).getText());
                Assert.assertTrue("Db and UI Values Does not match", (hsc.get(i).get("RequestNumber").toString()).equals(RequestNumbersUIXpath.get(i).getText()));
            }
        } else {
            Assert.fail("Number of records in for RequestNumbers Database do not match with Application UI ");
        }

    }

    /*This method validates the sequence of widgets on the Dahboard
     * @param
     * userType - Type of user you logged in with
     * firstWidget/secondWidget/thirdWidget - Widgets on the Dashboard page
     * */
    public void verifyWidgetSequence(String userType, String firstWidget, String secondWidget, String thirdWidget) {
        List<WebElement> widgetElements = driver.findElements(By.xpath("//div[@class='header-block']/h2"));
        if (userType.equals("internalOperationsUser")
                || userType.equals("operationsManager")) {
            Assert.assertTrue("", widgetElements.get(0).getText().equals(firstWidget));
            Assert.assertTrue("", widgetElements.get(1).getText().equals(secondWidget));
            Assert.assertTrue("", widgetElements.get(2).getText().equals(thirdWidget));
        } else if (userType.equalsIgnoreCase("Provider Users")) {
            Assert.assertTrue("", widgetElements.get(0).getText().equals(firstWidget));
            Assert.assertTrue("", widgetElements.get(1).getText().equals(secondWidget));
        }
    }

    public void verifyDrafts(List<Map<String, Object>> hsc) {
        By DraftsGridXpath = By.xpath("//div[@id='draftAuthorizationTableID-container']//tbody[@class='ng-scope']//tr//td[2]");
        List<WebElement> RequestNumbersUIXpath = driver.findElements(DraftsGridXpath);
        log.warn(RequestNumbersUIXpath);
        if (RequestNumbersUIXpath.size() == hsc.size()) {
            for (int i = 0; i < RequestNumbersUIXpath.size(); i++) {
                log.warn(hsc.get(i).get("hsc_id") + "" + RequestNumbersUIXpath.get(i).getText());
                Assert.assertTrue("Db and UI Values Does not match", (hsc.get(i).get("hsc_id").toString()).equals(RequestNumbersUIXpath.get(i).getText()));
            }
        } else {
            Assert.fail("Number of records in for RequestNumbers Database do not match with Application UI ");
        }


    }

    public void verifySubmittedByProvider(List<Map<String, Object>> hsc) {
        By submittedGridXpath = By.xpath("//*[@id='viewAuthorizationTableID']/tbody/tr/td[2]");
        By submittedStatusXpath = By.xpath("//*[@id='viewAuthorizationTableID']/tbody/tr/td[5]");
        List<WebElement> RequestNumbersUIXpath = driver.findElements(submittedGridXpath);
        List<WebElement> submittedStatus = driver.findElements(submittedStatusXpath);
        log.warn(RequestNumbersUIXpath);
        if (RequestNumbersUIXpath.size() == hsc.size()) {
            for (int i = 0; i < RequestNumbersUIXpath.size(); i++) {
                log.warn(hsc.get(i).get("hsc_id") + "" + RequestNumbersUIXpath.get(i).getText());
                Assert.assertEquals("Db and UI Values Does not match", hsc.get(i).get("request number").toString(), RequestNumbersUIXpath.get(i).getText());
                Assert.assertEquals("Db and UI Values Does not match", hsc.get(i).get("newhscstatus").toString(), (submittedStatus.get(i).getText()));
            }
        } else {
            Assert.fail("Number of records in for RequestNumbers Database do not match with Application UI ");
        }


    }

    public void clickSwitchPayers() {
        log.warn("Clicking between payer");
        TestUtils.click(driver, switchPayer);
    }

    public void clickSwitchForUhc() throws InterruptedException {
        log.warn("Clicking between payer");
        Thread.sleep(5000);
        TestUtils.click(driver, cusselectionTypeDropDown);
        Thread.sleep(5000);
        TestUtils.click(driver, switchUHCCustomer);
    }

    public void clickSwitchForBcbs() throws InterruptedException {
        log.warn("Clicking between payer");
        TestUtils.click(driver, cusselectionTypeDropDown);
        TestUtils.click(driver, switchUHCCustomer);
        TestUtils.click(driver, cusselectionTypeDropDown);
        TestUtils.click(driver, switchBCBSCustomer);
        TestUtils.isElementVisible(driver, cusselectionTypeDropDown);
    }

    public void clickSwitchBcbsToArizona() throws InterruptedException {
        log.warn("Clicking between payer");
        TestUtils.click(driver, cusselectionTypeDropDown);
        TestUtils.click(driver, switchBCBSCustomer);
        TestUtils.click(driver, cusselectionTypeDropDown);
        TestUtils.click(driver, switchOnArizonaCustomer);
    }


    public void clickSwitchArizonaToBcbs() throws InterruptedException {
        log.warn("Clicking between payer");
        TestUtils.click(driver, cusselectionTypeDropDown);
        TestUtils.click(driver, switchOnArizonaCustomer);
        TestUtils.click(driver, cusselectionTypeDropDown);
        TestUtils.click(driver, switchBCBSCustomer);
    }

    public void clickSwitchUHCToSouthwestMedical() throws InterruptedException {
        log.warn("Clicking between payer");
        TestUtils.click(driver, cusselectionTypeDropDown);
        TestUtils.click(driver, switchUHCCustomer);
        TestUtils.click(driver, cusselectionTypeDropDown);
        TestUtils.click(driver, switchSouthwestMedicalCustomer);
    }

    public void clickSwitchBcbsToSouthwestMedical() throws InterruptedException {
        log.warn("Clicking between payer");
        TestUtils.click(driver, cusselectionTypeDropDown);
        TestUtils.click(driver, switchBCBSCustomer);
        TestUtils.click(driver, cusselectionTypeDropDown);
        TestUtils.click(driver, switchSouthwestMedicalCustomer);
    }


    public void clickSwitchSouthwestMedicalToBcbs() throws InterruptedException {
        log.warn("Clicking between payer");
        TestUtils.click(driver, cusselectionTypeDropDown);
        TestUtils.click(driver, switchSouthwestMedicalCustomer);
        TestUtils.click(driver, cusselectionTypeDropDown);
        TestUtils.click(driver, switchBCBSCustomer);
    }

    public void clickSwitchSouthwestMedicalToUHC() throws InterruptedException {
        log.warn("Clicking between payer");
        TestUtils.click(driver, cusselectionTypeDropDown);
        TestUtils.click(driver, switchSouthwestMedicalCustomer);
        TestUtils.click(driver, cusselectionTypeDropDown);
        TestUtils.click(driver, switchUHCCustomer);
    }

    public void clickSwitchForArizona() {
        log.warn("Clicking between payer");
        TestUtils.click(driver, cusselectionTypeDropDown);
        TestUtils.highlightElement(driver, cusselectionTypeDropDown);
        TestUtils.waitElement(driver, switchUHCCustomer);
        TestUtils.click(driver, switchUHCCustomer);
        TestUtils.wait(5);
        TestUtils.click(driver, cusselectionTypeDropDown);
        TestUtils.highlightElement(driver, switchOnArizonaCustomer);
        TestUtils.waitElement(driver, switchOnArizonaCustomer);
        TestUtils.click(driver, switchOnArizonaCustomer);
    }

    public void clickOncustomerDropDown() {
        log.warn("Clicking between payer");
        TestUtils.click(driver, cusselectionTypeDropDown);
    }

    public void verifyUserRedirectedToBCBSHompage() {
        Assert.assertFalse(TestUtils.isElementVisible(driver, switchBCBSPayerButton));
    }

    public void verifyUserRedirectedToBCBSHompageforOPtumcare() throws InterruptedException {
        Assert.assertTrue(TestUtils.isElementVisible(driver, switchBCBSCustomerName));
    }

    public void verifyUserRedirectedToArizonaHompageforOPtumcare() throws InterruptedException {
        Assert.assertTrue(TestUtils.isElementVisible(driver, switchArizonaCustomerName));
    }

    public void verifyUserRedirectedToSouthwestMedicalHompageforOPtumcare() throws InterruptedException {
        Assert.assertTrue(TestUtils.isElementVisible(driver, switchSouthwestMedicalCustomerName));
    }

    public void verifyUserRedirectedToUHCHompage() {
        TestUtils.waitElementVisible(driver, switchUHCPayerButton);
        Assert.assertFalse(TestUtils.isElementVisible(driver, switchUHCPayerButton));
    }

    public void verifyUserRedirectedToUHCHompageforOPtumcare() throws InterruptedException {
        Thread.sleep(3000);
        Assert.assertTrue(TestUtils.isElementVisible(driver, switchUHCCustomerName));
    }

    public void verifyUserShouldNotAnySeeSwitchPayersButton() {
        Assert.assertFalse(TestUtils.isElementVisible(driver, switchUHCPayerButton));
        Assert.assertFalse(TestUtils.isElementVisible(driver, switchBCBSPayerButton));
    }

    public void verifyRestrictedMessageDisplayed(String widgetType) {
        String expectedRestrictedMessage = "This entry cannot be viewed due to insufficient security privileges.";
        String id = "";
        widgetType = widgetType.toUpperCase();
        switch (widgetType) {
            case "DRAFT": {
                id = "draftAuthorizationTableID-container";
                break;
            }
            case "SUBMITTED AUTHORIZATION": {
                id = "viewAuthorizationTableID-container";
                break;
            }
            case "ACTIVITY": {
                id = "viewActivityTrackingOperationID-container";
                break;
            }
        }
        By restrictedMessageXpath = By.xpath("//div[@id ='" + id + "']//tr[@class='ocmTableRow ng-scope'][1]//span[@class='maskedRowText']");
        TestUtils.wait(5);
        if (TestUtils.isElementPresent(driver, restrictedMessageXpath)) {
            log.warn(" Verifying Restricted policy message displayed");
            String restrictedMessage = TestUtils.text(driver, restrictedMessageXpath);

            Assert.assertEquals("Restricted Policy Message displayed correctly", expectedRestrictedMessage, restrictedMessage);
        }
    }

    public void verifyRestrictedMessageNotDisplayed(String widgetType) {
        String id = "";
        widgetType = widgetType.toUpperCase();
        switch (widgetType) {
            case "DRAFT": {
                id = "draftAuthorizationTableID-container";
                break;
            }
            case "SUBMITTED AUTHORIZATION": {
                id = "viewAuthorizationTableID-container";
                break;
            }
            case "ACTIVITY": {
                id = "viewActivityTrackingOperationID-container";
                break;
            }
        }
        By restrictedMessageXpath = By.xpath("//div[@id ='" + id + "']//tr[@class='ocmTableRow ng-scope'][1]//span[@class='maskedRowText']");
        TestUtils.wait(5);
        if (!(TestUtils.isElementPresent(driver, restrictedMessageXpath))) {
            log.warn("Verifying whether all records displayed ");
            TestUtils.wait(5);
            Assert.assertFalse("All records are displayed with restricted policy message", TestUtils.isElementVisible(driver, restrictedMessageXpath));
        }
    }

    public void clickGlobalNavigationMenu(String navigationMenu, String SubMenu) {

        log.warn("Click on the Navigation Menu : " + navigationMenu);
        TestUtils.wait(3);
        driver.findElement(By.xpath("//ul[@id='globalNavigationMenu']//li//span[text()='" + navigationMenu + "']/ancestor::a")).click();

        log.warn("Click on the Sub Menu : " + SubMenu);
        TestUtils.wait(1);
        driver.findElement(By.xpath("//ul[contains(@uitk-slide-show,'menuVisible') and @role='group']//li//span[text()='" + SubMenu + "']/ancestor::a")).click();
    }

    public void validateActivityType(String activityType) {
        By activityTypeXpath = By.xpath("//div[@id ='viewActivityTrackingOperationID-container']//tr[@class='ocmTableRow ng-scope'][1]//td[4]//span[text()='"+activityType+"']");
        TestUtils.wait(3);
        Assert.assertTrue(TestUtils.isElementVisible(driver, activityTypeXpath));
    }

    /**
     * Verify the Cloumn name is displayed in Submitted table
     */
    public void validateColumnInDraftTable(String columnName) {
        By columnNameXpath = By.xpath("//div[@id ='draftAuthorizationTableID-container']//tr[@class='tk-dtbl-header-row']//span[text()='" + columnName + "']");
        TestUtils.wait(3);
        Assert.assertTrue(TestUtils.isElementVisible(driver, columnNameXpath));
    }

    /**
     * Verify the Cloumn name is displayed in Submitted table
     */
    public void validateColumnInSubmittedTable(String columnName) {
        By columnNameXpath = By.xpath("//div[@id ='viewAuthorizationTableID-container']//tr[@class='tk-dtbl-header-row']//span[text()='" + columnName + "']");
        TestUtils.wait(3);
        Assert.assertTrue(TestUtils.isElementVisible(driver, columnNameXpath));
    }

    /**
     * Verify the value of the Request type column is displayed in draft table
     */
    public void validateRequestTypeValueInDraftTable(String requestType) {
        By requestTypeXpath = By.xpath("//div[@id ='draftAuthorizationTableID-container']//tr[@class='ocmTableRow ng-scope'][1]//span[text()='" + requestType + "']");
        for(int i=0;i<=100;i++){
            if(!driver.findElement(requestTypeXpath).isDisplayed()){
               TestUtils.refreshPage(driver);
            }else{
                Assert.assertTrue(TestUtils.isElementVisible(driver, requestTypeXpath));
                break;
            }
        }
    }
    /**
     * Validate the value of the Request type column is displayed in Submitted table
     */
    public void validateRequestTypeValueInSubmittedTable(String requestType) {
        By requestTypeXpath = By.xpath("//div[@id ='viewAuthorizationTableID-container']//tr[@class='ocmTableRow ng-scope'][1]//span[text()='" + requestType + "']");
        TestUtils.wait(3);
        Assert.assertTrue(TestUtils.isElementVisible(driver, requestTypeXpath));
    }

    public void clickEditOpenAuthIcon() {
    log.warn("Click on Edit Draft Icon");
    TestUtils.click(driver, openAuthIcon);
    }
}



