package atdd.test.pageobjects.directsso;

import atdd.utils.StringUtils;
import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.ArrayList;


public class SignInClinicalManager {
    private static final Logger log = Logger.getLogger(SignInClinicalManager.class.getName());

    private WebDriver driver;


    public SignInClinicalManager(WebDriver driver) {
        this.driver = driver;
    }

    //Locators---------------
    public static final By username = By.xpath("//input[@id='usernameId']");
    public static final By pass = By.xpath("//input[@id='pwd']");
    public static final By sighInBtn = By.xpath("//input[@type='submit']");
    public static final By versionSpan = By.xpath("//span[@id='appVersion']/..");
    //Locators--------------


    /**
     * Click Sign In on the Login Page
     *
     * @return
     */
    public SignInClinicalManager clickSignInLoginPage() {
        log.warn("Clicking Sign In on the Login Page.");
        TestUtils.click(driver, sighInBtn);
        return this;
    }

    /**
     * Enter text in to Username field
     *
     * @param userId
     * @return
     */
    public SignInClinicalManager enterUserId(String userId) {
        log.warn("Entering " + userId + " text in to Username field.");
        TestUtils.input(driver, username, userId);
        return this;
    }

    /**
     * Enter text in to User Pass field
     *
     * @param userPass
     * @return
     */
    public SignInClinicalManager enterUserPass(String userPass) {
        log.warn("Entering password text in to Pass field.");
        TestUtils.input(driver, pass, userPass, true);
        return this;
    }

    public void verifyErrorMessage(String message) {
        By errorMessage = By.xpath("//div[@id='ServerError']//span[contains(text(), '" + message + "')]");
        Assert.assertTrue(TestUtils.isElementVisible(driver, errorMessage));
    }

    public String getVersion() {
        String handler = driver.getWindowHandle();
        try {
            ArrayList<String> handlers = new ArrayList<String>(driver.getWindowHandles());
            for (String h : handlers) {
                driver.switchTo().window(h);
                String version = getVersion1();
                if (!StringUtils.isEmpty(version)) {
                    return version;
                }
            }
            return null;
        } catch (Exception e) {
            log.error("Unable to read version by: " + versionSpan);
            return null;
        } finally {
            driver.switchTo().window(handler);
        }
    }

    private String getVersion1() {
        try {
            if (TestUtils.isElementVisible(driver, versionSpan)) {
                return TestUtils.text(driver, versionSpan);
            } else {
                return null;
            }
        } catch (Exception e) {
            return null;
        }
    }

}