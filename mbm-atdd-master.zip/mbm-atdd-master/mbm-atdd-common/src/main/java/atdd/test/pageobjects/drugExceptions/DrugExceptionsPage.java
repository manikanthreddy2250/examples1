package atdd.test.pageobjects.drugExceptions;

import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import static org.openqa.selenium.By.cssSelector;


public class DrugExceptionsPage {

    public static By authTypesearchCriteria = By.xpath("//select[contains(@id,'drugTable-tableFilters-authorizationType')]");
    public static By payersearchCriteria = cssSelector("select[ng-model*='drugTable.tableFilters.customTreatmentApprovalType']");
    public static By drugCodesearchCriteria = By.xpath("//input[contains(@id,'drugTable-tableFilters-procedureCode')]");
    public static By searchButton = cssSelector("input[ng-click*='drugTable.applyTableFiltersOnClick(drugTableFormtableFilters)'][value='Search']");
    public static By addDrugException = By.xpath("//a[contains(text(),'Add Drug Exception')]");
    public static By route = By.xpath("//select[contains(@id,'record-medicationAdminRouteType')]");
    public static By payer = By.xpath("//select[contains(@id,'record-customerID')]");
    public static By authType = By.xpath("//select[contains(@id,'record-authorizationType')]");
    public static By message = By.xpath("//textarea[@id ='messageText']");
    public static By drugCode = By.xpath("//input[contains(@id,'record-procedureCode')]");
    public static By saveButton = By.xpath("//input[@class = 'open ng-scope tk-btn']");
    public static By effectiveStartDate = By.xpath("//input[contains(@id,'drugTable-tableFilters-startDate')]");
    public static By sortButton = By.xpath("//span[@id ='drugTable-Payer-sortButton']");
    public static By includedStates = By.xpath("//span[@ng-model='record.includedStates']//*[contains(@id,'btn')]");
    public static By includedStatesAll = By.xpath("(//*[@class='tk-multi-line ng-scope']//button[@type='button'][contains(@ng-class,'enableAllBtn')])[1]");
    public static By includeLob = By.xpath("//span[@ng-model='record.includedLoBs']//*[contains(@id,'btn')]//following-sibling::span");
    public static By includeLobAll = By.xpath("(//*[@class='tk-multi-line ng-scope']//button[@type='button'][contains(@ng-class,'enableAllBtn')])[2]");
    public static By regimneStandard = By.xpath("//input[@id='regimenTypeStandard']");
    public static By regimneCustom = By.xpath("//input[@id='regimenTypeCustom']");
    public static By deleteYesButton = By.xpath("//input[@id='deleteDrugConfYesBtn']");
    public static By authorizationType = By.xpath("//select[@ng-model='record.authorizationType']");


    private Scenario scenario;
    private WebDriver driver;
    private static Logger log = Logger.getLogger(DrugExceptionsPage.class);

    public DrugExceptionsPage(WebDriver driver) {
        this.driver = driver;
    }


 /*
    Verify the label names on result Grid
     */

    public void validateLabelValues(List<String> labelValues) {
        TestUtils.demoBreakPoint(scenario, driver, "Labels");
        for (int i = 0; i < labelValues.size(); i++) {
            String labelName = driver.findElement(By.xpath("//td[contains(text(), '" + labelValues.get(i) + "')]")).getText().trim();
            Boolean value = labelName.equalsIgnoreCase(labelValues.get(i));
            Assert.assertTrue("Search Field Label values is not correct", value);

        }


    }

    /*
    Verify the default selected value for Auth Type
     */
    public void validateDefaultValuesForAuthType() {
        Select sel = new Select(driver.findElement(authTypesearchCriteria));
        String Selected = sel.getFirstSelectedOption().getText();
        Assert.assertEquals("Select", Selected);

    }

     /*
       Verify the default selected value for Payer
        */

    public void validateDefaultValuesForPayer() {
        Select sel = new Select(driver.findElement(payersearchCriteria));
        String Selected = sel.getFirstSelectedOption().getText();
        Assert.assertEquals("Select", Selected);

    }

    /*
    Validate the order of Columns in the table
     */
    public void validateTableHeader(List<String> expectedHeader) {
        TestUtils.demoBreakPoint(scenario, driver, "Header");
        List<WebElement> headerElements = driver.findElements(By.xpath("//table[@id='drugTableID']/thead/tr/td"));
        for (int i = 0; i < expectedHeader.size(); i++) {
            Boolean value = headerElements.get(i).getText().contains(expectedHeader.get(i));
            Assert.assertTrue("expected and actual doesn't match at index " + i, value);
        }
    }

    /*
   This method is to enter the Drug Code in Drug Exceptions Screen Search Criteria
   */
    public void enterDrugCodeOnDrugExceptionsSearchCriteria(String DrugCode) {
        log.warn("Enter the Brand Name in Search Criteria of Drug Exceptions Screen");
        TestUtils.input(driver, drugCodesearchCriteria, DrugCode);
        TestUtils.demoBreakPoint(scenario, driver, "Enter Drug Code in Search Criteria");

    }

    /*
    This method is to select Authorization Type in in Drug Exceptions Screen, Search Criteria section
    */
    public void selectAuthTypeOnDrugExceptionSearchCriteria(String authType) {
        log.warn("select the Auth Type in Search Criteria of Drug Exceptions Screen");
        TestUtils.select(driver, authTypesearchCriteria, authType);
    }

    /*
     This method is to select Authorization Type on Drug Exception Screen
    */
    public void selectAuthTypeOnDrugException(String authType) {
        log.warn("select the Auth Type in Search Criteria of Drug Exceptions Screen");
        TestUtils.select(driver, authorizationType, authType);
    }

    /*
    This method is to select Payer in Drug Exceptions Screen Search Criteria section
    */
    public void selectpayerOnDrugExceptionsSearchCriteria(String payer) {
        log.warn("select the payer in Search Criteria of Newly Approved Drug Screen");
        TestUtils.select(driver, payersearchCriteria, payer);
    }

    /*
    This method to Enter the Effective Start Date in Drug Exception Search Criteria field
     */
    public void enterEffectiveStartDateOnDrugExceptionsSearchCriteria(String startDate) {
        log.warn("Enter Effective Start date on the Drug Exception Screen");
        TestUtils.demoBreakPoint(scenario, driver, "Enter Effective Start Date in Search Criteria");
        TestUtils.input(driver, effectiveStartDate, startDate);
    }

    /**
     * Clicking search Button on Traversal Maintenance Page
     */
    public void clickSearchButton() {
        log.warn("Click Search on Drug Exceptions Screen");
        TestUtils.click(driver, searchButton);

    }

    /*
   This method is to verify Records founds in search Result Grid
    */
    public void VerifyRecordsDisplayedCorrectly(Map<String, String> map) {
        TestUtils.wait(5);
        List<WebElement> els = driver.findElements(By.xpath("//table[@id='drugTableID']//tr"));
        System.out.println(els.size());
        List<String> actualValue = new ArrayList<String>();
        for (int i = 1; i < els.size(); i++) {
            List<WebElement> tableColumn = driver.findElements(By.xpath("//table[@id='drugTableID']//tbody/tr[" + i + "]/td"));
            for (int j = 1; j <= tableColumn.size(); j++) {

                actualValue.add(driver.findElement(By.xpath("//table[@id='drugTableID']//tbody/tr[" + i + "]/td[" + j + "]")).getText());

            }
            Assert.assertTrue("DrugCode doesn't match the added value", actualValue.get(1).equalsIgnoreCase(map.get("Drug Code")));
            Assert.assertTrue("Authorization Type doesn't match the added value", actualValue.get(4).equalsIgnoreCase(map.get("Authorization Type")));
            Assert.assertTrue("Payer doesn't match the added value", actualValue.get(5).equalsIgnoreCase(map.get("Payer")));
        }
    }

    /*
    This method is to verify the Sorting order
     */
    public void userVerifiesSortingOrder() {
        List<WebElement> els = driver.findElements(By.xpath("//table[@id='drugTableID']//tr"));
        System.out.println(els.size());
        ArrayList<String> actualValue = new ArrayList<String>();
        for (int i = 1; i < els.size(); i++) {
            actualValue.add(driver.findElement(By.xpath("//table[@id='drugTableID']//tbody/tr[" + i + "]/td[6]")).getText());
        }
        Collections.sort(actualValue);
        System.out.println(actualValue);
        TestUtils.click(driver, sortButton);
        TestUtils.click(driver, sortButton);
        TestUtils.wait(5);
        ArrayList<String> actualValue1 = new ArrayList<String>();
        for (int i = 1; i < els.size(); i++) {
            actualValue1.add(driver.findElement(By.xpath("//table[@id='drugTableID']//tbody/tr[" + i + "]/td[6]")).getText());
        }
        System.out.println(actualValue1);
        Assert.assertEquals(actualValue, actualValue1);

    }

    /*This method clicks on +Add New Drug*/
    public void clickOnAddDrugExceptionLink() {
        log.warn("Clicking on add Drug Exception");
        TestUtils.click(driver, addDrugException);
    }

    /*
         This method is to verify the position of Authorization Type and Payer on Add Drug Exception pop-up
          */
    public void verifyFieldsOnAddDrugExceptionPopUp(List<String> label) {
        String auth = label.get(0);
        String payer = label.get(1);
        Boolean authTypeDropDown = driver.findElement(By.xpath("//label[contains(text(), '" + auth + "')]")).isDisplayed();
        Assert.assertTrue("Authorization Type dropdown in Add Drug Exception Pop up not displayed", authTypeDropDown);
        Boolean payerDropDown = driver.findElement(By.xpath("//label[contains(text(), '" + payer + "')]")).isDisplayed();
        Assert.assertTrue("Payer Type dropdown in Add Drug Exception Pop up not displayed", payerDropDown);
    }


    public void selectDrugRouteOnAddDrugExceptionPopUp(String drugroute) {
        log.warn("Enter the Drug Route on the Add Drug Exception Pop-up modal");
        TestUtils.select(driver, route, drugroute);
    }

    public void selectPayerOnAddDrugExceptionPopUp(String payer) {
        log.warn("Enter the Payer on the Add Drug Exception Pop-up modal");
        TestUtils.select(driver, DrugExceptionsPage.payer, payer);
    }

    public void selectAuthTypeOnAddDrugExceptionPopUp(String authtype) {
        log.warn("Enter the Auth Type on the Add Drug Exception Pop-up modal");
        TestUtils.select(driver, authType, authtype);
    }

    public void enterMessageOnAddDrugExceptionPopUp(String Message) {
        log.warn("Enter Message on the Add Drug Exception Pop-up modal");
        TestUtils.input(driver, message, Message);
    }

    public void enterDrugCodeOnAddDrugExceptionPopUp(String drugcode) {
        log.warn("Enter drug code on the Add Drug Exception Pop-up modal");
        TestUtils.input(driver, drugCode, drugcode);
        TestUtils.wait(3);
        driver.findElement(By.xpath("//strong[contains(text(),'" + drugcode + "')]")).click();
    }

    public void clickSaveButton() {
        log.warn("Click save on the Add Drug Exception Pop-up modal");
        TestUtils.click(driver, saveButton);
    }


    public void selectState() {
        log.warn("Select all State on the Add Drug Exception Pop-up modal");
        TestUtils.click(driver, includedStates);
        TestUtils.click(driver, includedStatesAll);


    }

    public void selectLob() {
        log.warn("Select all LOB on the Add Drug Exception Pop-up modal");
        TestUtils.click(driver, includeLob);
        TestUtils.click(driver, includeLobAll);
        TestUtils.click(driver, By.xpath("//h2[text()='Add Drug Exception']"));
    }

    public void clickRegimenStandard() {
        log.warn("Click standard radio button on the Add Drug Exception Pop-up modal");
        TestUtils.wait(3);
        TestUtils.click(driver, regimneStandard);
    }

    public void clickRegimenCustom() {
        log.warn("click custom radio button on the Add Drug Exception Pop-up modal");
        TestUtils.wait(3);
        TestUtils.click(driver, regimneCustom);
    }

    public boolean hasResult() {
        TestUtils.wait(2);
        List<WebElement> els = driver.findElements(By.xpath("//table[@id='drugTableID']//tr"));
        return els.size() != 2 || !els.get(1).getText().equals("No records to display.");
    }

    /**
     * Remove FirstResult from
     */
    public void removeFirstResult() {
        driver.findElements(By.xpath("//table[@id='drugTableID']//span[@title='Delete Record']")).get(0).click();
        TestUtils.demoBreakPoint(null, driver, "removing the Drug");
        driver.findElement(By.xpath("//form[@name='deleteConfirmPopupForm']//input[@value='Yes']")).click();
        TestUtils.wait(1);
    }

}
