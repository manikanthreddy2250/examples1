package atdd.test.pageobjects.drugManager;

import atdd.common.Retry;
import atdd.test.shared.BaseCucumber;
import atdd.test.shared.Globals;
import atdd.utils.TestUtils;
import atdd.utils.WhiteBoard;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import java.text.ParseException;
import java.util.List;

public class DrugManagerPage {
    private WebDriver driver;
    private TestUtils utils;

    Logger log;
    Globals gv;

    private By authType = By.xpath("//select[contains(@ref-nm,'authorizationType')]");
    private By drugCode = By.xpath("//input[@name='Procedure Code']");
    private By brandName = By.xpath("//input[@name='Drug Name']");
    private By payer = By.xpath("//select[contains(@ref-nm,'customTreatmentApprovalType')]");
    private By startDate = By.xpath("//input[contains(@id,'tableFilters-startDate')]");
    private By endDate = By.xpath("//input[contains(@id,'tableFilters-endDate')]");
    private By status = By.xpath("//select[contains(@ref-nm,'versionStatusType')]");
    private By searchButton = By.xpath("//input[@value='Search']");
    private By clearButton = By.xpath("//input[@value='Clear']");
    private By resultMsgWithoutSearch = By.xpath("//tr[@class='ocmTableRow']/td");
    private By addDrugLink = By.xpath("//span[contains(@class,'tableActions')]/a");
    private By saveButton = By.xpath("//input[@value='Save']");
    private By cancelButton = By.xpath("//input[@value='Save']/following::input");
    private By startDateOnAddDrugPopup = By.xpath("//label[contains(text(),'Start Date')]/following::input[contains(@id,'record-startDate')]");
    private By endDateOnAddDrugPopup = By.xpath("//label[contains(text(),'End Date')]/following::input[contains(@id,'record-endDate')]");
    private By drugCodeOnAddDrugPopup = By.xpath("//label[contains(text(),'Drug Code')]/following::input[contains(@id,'procedureCode')]");
    private By drugNameOnEditDrugPopup = By.xpath("//label[contains(text(),'Drug Name')]/following::input[@name='Procedure Brand Name']");
    private By genericNameOnEditDrugPopup = By.xpath("//label[contains(text(),'Generic Name')]/following::input[@name='Procedure Generic Name']");
    private By checkboxResultGrid = By.xpath("//tr[@class='tk-dtbl-header-row']/following::tr[1]/td[1]/input");
    private By archiveIconResultGrid = By.xpath("//tr[@class='tk-dtbl-header-row']/following::tr[1]/td[2]/span[@title='Archive Drug']");
    private By cloneIconResultGrid = By.xpath("//tr[@class='tk-dtbl-header-row']/following::tr[1]/td[2]/span[@title='Clone Drug']");
    private By restoreIconResultGrid = By.xpath("//tr[@class='tk-dtbl-header-row']/following::tr[1]/td[2]/span[@title='Restore Drug']");
    private By editIconResultGrid = By.xpath("//tr[@class='tk-dtbl-header-row']/following::tr[1]/td[2]/span[@title='Edit Drug']");
    private By deleteIconResultGrid = By.xpath("//tr[@class='tk-dtbl-header-row']/following::tr[1]/td[2]/span[@title='Delete Drug']");
    private By drugCodeResultGrid = By.xpath("//tr[@class='tk-dtbl-header-row']/following::tr[1]/td[3]/span");
    private By brandNameResultGrid = By.xpath("//tr[@class='tk-dtbl-header-row']/following::tr[1]/td[4]/span");
    private By genericNameResultGrid = By.xpath("//tr[@class='tk-dtbl-header-row']/following::tr[1]/td[5]/span");
    private By benefitResultGrid = By.xpath("//tr[@class='tk-dtbl-header-row']/following::tr[1]/td[6]/span");
    private By drugRouteResultGrid = By.xpath("//tr[@class='tk-dtbl-header-row']/following::tr[1]/td[7]/span");
    private By dosageResultGrid = By.xpath("//tr[@class='tk-dtbl-header-row']/following::tr[1]/td[8]/span");
    private By drugClassResultGrid = By.xpath("//tr[@class='tk-dtbl-header-row']/following::tr[1]/td[9]/span");
    private By payerResultGrid = By.xpath("//tr[@class='tk-dtbl-header-row']/following::tr[1]/td[10]/span");
    private By startDateResultGrid = By.xpath("//tr[@class='tk-dtbl-header-row']/following::tr[1]/td[11]/span");
    private By endDateResultGrid = By.xpath("//tr[@class='tk-dtbl-header-row']/following::tr[1]/td[12]/span");
    private By statusResultGrid = By.xpath("//tr[@class='tk-dtbl-header-row']/following::tr[1]/td[13]/span");
    private By closeIconX = By.xpath("//button[contains(@ng-click,'drugManagerTable.editPopup.close')]/span[1]");
    private By dupeCheckErrorMessage = By.xpath("//*[contains(@id,'popupGlobalMessages')]/span");

    public DrugManagerPage(WebDriver webDriver) {
        this.driver = webDriver;
        utils = BaseCucumber.utils;
        log = Logger.getLogger(this.getClass().getName());
        gv = BaseCucumber.gv;
    }


    //Methods

    public void validateSearchClearButtons() {
        log.warn("Verifying search Buttons");
        Assert.assertTrue("Search button doesn't exists", TestUtils.isElementPresent(driver, searchButton));
        Assert.assertTrue("Clear button doesn't exists", TestUtils.isElementPresent(driver, clearButton));
    }

    public void validateDefaultSearchResults() {
        log.warn("Validating search results");
        Assert.assertEquals("Got wrong message for search with no results", "Please Provide Search Criteria.", driver.findElement(resultMsgWithoutSearch).getText());
    }

    public void checkElementsByText(List<List<String>> txt) {
        log.warn("Checking elements by text");
        TestUtils.wait(8);
        for (int i = 0; i < txt.size(); i++) {
            log.warn("Element = " + txt.get(i).get(0));
            By elementTxt = By.xpath("//div[contains(text(),'" + txt.get(i).get(0) + "')]");
            Assert.assertTrue("Element with text " + txt.get(i).get(0) + " is NOT visible. ", TestUtils.isElementVisible(driver, elementTxt));
        }
    }

    public void checkRequiredElementsByText(List<List<String>> txt) {
        log.warn("Checking required elements by text");
        TestUtils.wait(8);
        for (int i = 0; i < txt.size(); i++) {
            By elementTxt = By.xpath("//label[contains(text(),'" + txt.get(i).get(0) + "')]/ancestor::span[@required='required']");
            Assert.assertTrue("Element with text " + txt.get(i).get(0) + " is NOT required. ", TestUtils.isElementVisible(driver, elementTxt));
        }
    }

    public void checkAuthTypeAsRequiredElement() {
        log.warn("Checking Auth Type dropdown as required element on Drug Manager Page");
        By elementTxt = By.xpath("//span[contains(text(),'required.')]/../div[contains(text(),'Auth Type')]");
        TestUtils.waitElementVisible(driver,elementTxt);
        Assert.assertTrue("Element with text Auth Type is NOT required. ", TestUtils.isElementVisible(driver, elementTxt));
    }

    public void checkCloseIconOnPopUpWindow() {
        log.warn("Checking close X icon on Pop Up Window");
        Assert.assertTrue("close X icon is NOT visible. ", TestUtils.isElementVisible(driver, closeIconX));
    }

    public void checkPopupElementsByText(List<List<String>> txt) {
        log.warn("Checking elements by text");
        TestUtils.wait(2);
        for (int i = 0; i < txt.size(); i++) {
            By elementTxt = By.xpath("//label[contains(text(),'" + txt.get(i).get(0) + "')]");
            Assert.assertTrue("Element with text " + txt.get(i).get(0) + " is NOT visible. ", TestUtils.isElementVisible(driver, elementTxt));
        }
    }

    public void checkPopupHeaderByText(String arg0) {
        log.warn("Verifying Add Drug Pop Up Header");
        By popupHeader = By.xpath("//h2[contains(text(),'" + arg0 + "')]");
        Assert.assertTrue("Add Drug Pop Up Header doesn't exists", TestUtils.isElementPresent(driver, popupHeader));
    }

    public void checkPopupHeaderNotVisibleByText(String arg0) {
        log.warn("Verifying Add Drug Pop Up Header");
        TestUtils.wait(4);
        By popupHeader = By.xpath("//h2[contains(text(),'" + arg0 + "')]");
        Assert.assertTrue("Add Drug Pop Up Header does exists", !TestUtils.isElementVisible(driver, popupHeader));
    }

    public void validateSaveCancelButtons() {
        log.warn("Verifying search Buttons");
        Assert.assertTrue("Save button doesn't exists", TestUtils.isElementPresent(driver, saveButton));
        Assert.assertTrue("Cancel button doesn't exists", TestUtils.isElementPresent(driver, cancelButton));
    }

    public void selectAuthTypeOnAddDrugPopup(String authValue) {
        log.warn("Selecting Auth Type on Add Drug Popup");
        By payerDropdown = By.xpath("//label[contains(text(),'Authorization Type')]/following::select[1]");
        TestUtils.select(new Select(driver.findElement(payerDropdown)), authValue);
    }

    public void selectBenefitsOnAddDrugPopup(String value) {
        log.warn("Selecting Benefits on Add Drug Popup");
        By benefitsMultiSelect = By.xpath("//label[contains(text(),'Benefits')]/following::button[1]");
        TestUtils.click(driver, benefitsMultiSelect);
        TestUtils.wait(2);
        By benefitsType = By.xpath("//span[contains(@class,'tk-multi-tick')]/following::span[text()='" + value + "']");
        TestUtils.click(driver, benefitsType);
        TestUtils.wait(2);
        TestUtils.click(driver, benefitsMultiSelect);
    }

    public void selectPayerOnAddDrugPopup(String value) {
        log.warn("Selecting Payer on Add Drug Popup");
        By payerMultiSelect = By.xpath("//label[contains(text(),'Payer')]/following::button[1]");
        TestUtils.click(driver, payerMultiSelect);
        TestUtils.wait(2);
        By payerType = By.xpath("//span[contains(@class,'tk-multi-tick')]/following::span[text()='" + value + "']");
        TestUtils.click(driver, payerType);
        TestUtils.wait(2);
        TestUtils.click(driver, payerMultiSelect);
    }

    public void enterStartDateOnAddDrugPopup(String startDate, String owner) {
        log.warn("Input Start Date on Add Drug Popup");
        driver.findElement(startDateOnAddDrugPopup).clear();
        startDate = WhiteBoard.resolve(owner, startDate);
        TestUtils.input(driver, startDateOnAddDrugPopup, startDate);


    }

    public void enterStartDateOnAddDrugPopup(String actualStartDate, String newStartDate, String todaysDate, String owner) throws ParseException {
        log.warn("Input Start Date on Add Drug Popup");

        todaysDate = WhiteBoard.resolve(owner, todaysDate);
        int t = TestUtils.compareTwoDatesTest(todaysDate, actualStartDate);

        if (t < 0) {
            driver.findElement(startDateOnAddDrugPopup).clear();
            TestUtils.input(driver, startDateOnAddDrugPopup, newStartDate);
        } else {
            //Do nothing
        }


    }

    public void selectEndDateOnAddDrugPopup(String endDate, String owner) {
        log.warn("Input End Date on Add Drug Popup");
        driver.findElement(endDateOnAddDrugPopup).clear();
        endDate = WhiteBoard.resolve(owner, endDate);

        TestUtils.input(driver, endDateOnAddDrugPopup, endDate);
    }

    public void selectBasedOnLabel(String label, String payerValue) {
        log.warn("Selecting " + label + " on Add Drug Popup");
        By payerDropdown = By.xpath("//label[contains(text(),'" + label + "')]/following::select[1]");
        TestUtils.select(new Select(driver.findElement(payerDropdown)), payerValue);
    }

    public void inputTypeAheadAddDrugPopup(String label, String value) {
        log.warn("Input " + label + "on Add Drug Popup");

        By drugCodeOptionText = By.xpath("//li[contains(@role,'option')]/a/strong[contains(text(),'" + value + "')]");

        if (!new Retry("") {

            @Override
            protected void tryOnce() throws Exception {
                drugCodeOnAddDrugPopup = By.xpath("//*[@class='panelTable ng-scope']//tr//label[text()='" + label + "']/../../following::td[1]//input");
                TestUtils.input(driver, drugCodeOnAddDrugPopup, value);
                TestUtils.wait(3);
            }

            @Override
            protected boolean until() throws Exception {
                return TestUtils.isElementVisible(driver, drugCodeOptionText);
            }
        }.execute()) {
            throw new RuntimeException("Failed: Add" + label + " Drug code");
        }
        TestUtils.waitElementClickable(driver, drugCodeOptionText);
        TestUtils.click(driver, drugCodeOptionText);


    }

    public void selectDrugRouteOnAddDrugPopup(String value) {
        log.warn("Selecting Drug Route on Add Drug Popup");
        By payerDropdown = By.xpath("//label[contains(text(),'Drug Route')]/following::select[1]");
        TestUtils.select(new Select(driver.findElement(payerDropdown)), value);
    }

    //Drug Manager Page
    public void selectAuthTypeOnDrugManagerPage(String authValue) {
        log.warn("Selecting Auth Type on Drug Manager Page");
        TestUtils.select(new Select(driver.findElement(authType)), authValue);
    }

    public void inputDrugCodeOnDrugManagerPage(String value) {
        log.warn("Input Drug Code on Drug Manager Page");
        TestUtils.input(driver, drugCode, value);
    }

    public void inputBrandOrGenericNameOnDrugManagerPage(String value) {
        log.warn("Input Drug Code on Drug Manager Page");
        TestUtils.input(driver, brandName, value);

    }

    public void selectPayerOnDrugManagerPage(String authValue) {
        log.warn("Selecting Payer on Drug Manager Page");
        TestUtils.select(new Select(driver.findElement(payer)), authValue);
    }

    public void enterStartDateOnDrugManagerPage(String owner, String value) {
        log.warn("Input Start Date on Drug Manager Page");
        String sDate = WhiteBoard.resolve(owner, value);
        driver.findElement(startDate).clear();
        TestUtils.input(driver, startDate, sDate);
    }

    public void selectEndDateOnDrugManagerPage(String owner, String value) {
        log.warn("Input End Date on Drug Manager Page");
        String eDate = WhiteBoard.resolve(owner, value);
        driver.findElement(endDate).clear();
        TestUtils.input(driver, endDate, eDate);
    }

    public void selectStatusOnDrugManagerPage(String authValue) {
        log.warn("Selecting Status on Drug Manager Page");
        TestUtils.wait(2);
        TestUtils.select(new Select(driver.findElement(status)), authValue);
    }

    public void checkSearchValuesAreClearedOnDrugManagerPage() {
        log.warn("Search values are cleared on Drug Manager Page");
        Assert.assertEquals("Auth Type Value is not cleared", "Select", TestUtils.getSelectedValueFromDropdown(driver, authType));
        Assert.assertEquals("Drug Code Value is not cleared", "", TestUtils.text(driver, drugCode));
        Assert.assertEquals("Brand Name Value is not cleared", "", TestUtils.text(driver, brandName));
        Assert.assertEquals("Payer Value is not cleared", "Select", TestUtils.getSelectedValueFromDropdown(driver, payer));
        Assert.assertEquals("Start Date Value is not cleared", "", TestUtils.text(driver, startDate));
        Assert.assertEquals("End Date Value is not cleared", "", TestUtils.text(driver, endDate));
        Assert.assertEquals("Status Value is not cleared", "Deployed", TestUtils.getSelectedValueFromDropdown(driver, status));
    }


    public void verifySearchResultOnDrugManagerPage(String drugCode, String name, String payer, String status) {
        log.warn("Verify Search values in Result Grid on Drug Manager Page");
        TestUtils.wait(3);
        try {
            Assert.assertTrue("Drug Code Value is not found in result", TestUtils.text(driver, drugCodeResultGrid).equalsIgnoreCase(drugCode));
            Assert.assertTrue("Generic Name Value is not found in result", TestUtils.text(driver, genericNameResultGrid).equalsIgnoreCase(name));
            Assert.assertTrue("Payer Value is not found in result", TestUtils.text(driver, payerResultGrid).equalsIgnoreCase(payer));
            Assert.assertTrue("Status Value is not found in result", TestUtils.text(driver, statusResultGrid).equalsIgnoreCase(status));
        } catch (Exception e) {
            Assert.assertTrue("No records to display.", TestUtils.isElementVisible(driver, By.xpath("//*[@id='drugManagerTableID']//tfoot/tr/td")));
            Assert.fail("No records to display.");
        }
    }

    public void clickEditIconInSearchResult() {
        log.warn("Click Edit Icon in Search Result");
        TestUtils.waitElementClickable(driver, editIconResultGrid);
        TestUtils.click(driver, editIconResultGrid);
    }

    public void clickCloneIconInSearchResult() {
        log.warn("Click Clone Icon in Search Result");
        TestUtils.waitElementClickable(driver, cloneIconResultGrid);
        TestUtils.click(driver, cloneIconResultGrid);
    }


    public void verifyResultGridFirstRowAfterSearchActionDeployed() {
        log.warn("Verify Result Grid after Search Action for Deployed Status");
        Assert.assertTrue("Check Box doesn't exists", TestUtils.isElementPresent(driver, checkboxResultGrid));

        Assert.assertTrue("Drug Code doesn't exists", TestUtils.isElementPresent(driver, drugCodeResultGrid));
        Assert.assertTrue("Brand Name doesn't exists", TestUtils.isElementPresent(driver, brandNameResultGrid));
        Assert.assertTrue("Generic Name doesn't exists", TestUtils.isElementPresent(driver, genericNameResultGrid));
        Assert.assertTrue("Benefit doesn't exists", TestUtils.isElementPresent(driver, benefitResultGrid));
        Assert.assertTrue("Drug Route doesn't exists", TestUtils.isElementPresent(driver, drugRouteResultGrid));
        Assert.assertTrue("Payer doesn't exists", TestUtils.isElementPresent(driver, payerResultGrid));
        Assert.assertTrue("Start Date doesn't exists", TestUtils.isElementPresent(driver, startDateResultGrid));
        Assert.assertTrue("End Date doesn't exists", TestUtils.isElementPresent(driver, endDateResultGrid));
        Assert.assertTrue("Status doesn't exists", TestUtils.isElementPresent(driver, statusResultGrid));
    }

    public void verifyResultGridFirstRowAfterSearchAction() {
        log.warn("Verify Result Grid after Search Action");
        TestUtils.wait(3);
        TestUtils.waitElementVisible(driver, checkboxResultGrid);
        Assert.assertTrue("Check Box doesn't exists", TestUtils.isElementPresent(driver, checkboxResultGrid));
        String statusText = TestUtils.text(driver, statusResultGrid);
        if (statusText.equalsIgnoreCase("Draft")) {
            Assert.assertTrue("Edit Icon doesn't exists", TestUtils.isElementPresent(driver, editIconResultGrid));
            Assert.assertTrue("Delete Icon doesn't exists", TestUtils.isElementPresent(driver, deleteIconResultGrid));
        } else if (statusText.equalsIgnoreCase("Deployed")) {
            Assert.assertTrue("Archive Icon does exists", !TestUtils.isElementPresent(driver, archiveIconResultGrid));
            Assert.assertTrue("Clone Icon doesn't exists", TestUtils.isElementPresent(driver, cloneIconResultGrid));
        } else {
            Assert.assertTrue("Restore Icon doesn't exists", TestUtils.isElementPresent(driver, restoreIconResultGrid));
        }
        Assert.assertTrue("Drug Code doesn't exists", TestUtils.isElementPresent(driver, drugCodeResultGrid));
        Assert.assertTrue("Brand Name doesn't exists", TestUtils.isElementPresent(driver, brandNameResultGrid));
        Assert.assertTrue("Generic Name doesn't exists", TestUtils.isElementPresent(driver, genericNameResultGrid));
        String authTypeText = TestUtils.text(driver, authType);
        if (authTypeText.equalsIgnoreCase("Outpatient Chemo")) {
            Assert.assertTrue("Benefit doesn't exists", TestUtils.isElementPresent(driver, benefitResultGrid));
            Assert.assertTrue("Drug Route doesn't exists", TestUtils.isElementPresent(driver, drugRouteResultGrid));
        } else if (authTypeText.equalsIgnoreCase("Specialty Pharmacy")) {
            Assert.assertTrue("Dosage doesn't exists", TestUtils.isElementPresent(driver, dosageResultGrid));
            Assert.assertTrue("Drug Class doesn't exists", TestUtils.isElementPresent(driver, drugClassResultGrid));
        }
        Assert.assertTrue("Payer doesn't exists", TestUtils.isElementPresent(driver, payerResultGrid));
        Assert.assertTrue("Start Date doesn't exists", TestUtils.isElementPresent(driver, startDateResultGrid));
        Assert.assertTrue("End Date doesn't exists", TestUtils.isElementPresent(driver, endDateResultGrid));
        Assert.assertTrue("Status doesn't exists", TestUtils.isElementPresent(driver, statusResultGrid));
    }


    public void inputValuesOnEditDrugPopup(String label, String name) {

        log.warn("Input values based on label name");
        By finalXpath = By.xpath("//*[@class='panelTable ng-scope']//tr//label[text()='" + label + "']/../../following::td[1]//input");
        TestUtils.input(driver, finalXpath, name);
    }

    public void verifyDupeCheckErrorMessage() {
        log.warn("Verifying dupe check error message");
        String expectedMessage = "We're sorry, but this drug already exists for the selected configuration. Please choose a different drug to proceed, or update the current drug on the deployed drugs page.";
        String actulaMessage = TestUtils.text(driver, dupeCheckErrorMessage);
        Assert.assertEquals("Message doesn't match", expectedMessage.trim(), actulaMessage.trim());

    }


    /**
     * Deploy Approved Drugs from Grid
     */
    public void deployApprovedDrugsfromGrid() {


        try {
            TestUtils.wait(4);
            driver.findElement(By.xpath("//*[@id=\"drugManagerTableID\"]/tbody/tr[1]/td[1]")).click();
            TestUtils.wait(2);
            TestUtils.demoBreakPoint(null, driver, "Deploying the Drug");
            driver.findElement(By.xpath("//*[@data-id='Tools.DrugManager.DeployApprovedModal--deployLinkButton']")).click();
            TestUtils.wait(2);
            driver.findElement(By.xpath("//input[@value='Confirm']")).click();
            TestUtils.wait(2);

        } catch (Exception e) {
            Assert.assertTrue("No records to display.", TestUtils.isElementVisible(driver, By.xpath("//*[@id='drugManagerTableID']//tfoot/tr/td")));
            Assert.fail("No records to display.");
        }
    }

    /**
     * Archive Approved Drugs from Grid
     */
    public void archiveApprovedDrugsfromGrid(String owner) {


        try {
            TestUtils.wait(4);
            TestUtils.click(driver, By.xpath("//*[@id='drugManagerTableID']/tbody/tr[1]/td[1]"));
            TestUtils.wait(2);
            TestUtils.demoBreakPoint(null, driver, "Deploying the Drug");
            TestUtils.click(driver, By.xpath("//*[@data-id='DrugManager.BulkArchiveDrug--actionLink']"));
            TestUtils.wait(2);

            Assert.assertTrue("Archive Drugs header not visible on bulk Archive Popup Model", TestUtils.isElementVisible(driver, By.xpath("//*[text()='Archive Drugs']")));

            //Asserting date field is required
            (driver.findElement(By.xpath("//input[contains(@ng-model,'bulkArchivePopupModel.endDateValue')]"))).sendKeys(WhiteBoard.resolve(owner, ""));
            TestUtils.click(driver, By.xpath("(//input[@value='Continue'])[2]"));
            Assert.assertTrue("This field is required not visible", TestUtils.isElementVisible(driver, By.xpath("(//*[contains(@id,'bulkArchivePopupModel-endDateValue')])[2]")));

            TestUtils.wait(2);

            (driver.findElement(By.xpath("//input[contains(@ng-model,'bulkArchivePopupModel.endDateValue')]"))).sendKeys(WhiteBoard.resolve(owner, "${tomorrow}"));
            TestUtils.click(driver, By.xpath("(//input[@value='Continue'])[2]"));

        } catch (Exception e) {
            Assert.assertTrue("No records to display.", TestUtils.isElementVisible(driver, By.xpath("//*[@id='drugManagerTableID']//tfoot/tr/td")));
            Assert.fail("No records to display.");
        }
    }


    public void verifyNOSearchResultOnDrugManagerPage() {
        log.warn("Verify Search values in Result Grid on Drug Manager Page");
        TestUtils.wait(3);

        Assert.assertTrue("No records to display.", TestUtils.isElementVisible(driver, By.xpath("//*[@id='drugManagerTableID']/tfoot/tr/td")));

    }


    public void brandOrGenericNameOnDrugManagerPage(String globalValue) {
        log.warn("Input Drug Name or Generic Name on Drug Manager Page");
        TestUtils.input(driver, brandName, globalValue);

    }
}

