package atdd.test.pageobjects.drugPolicyMaintenance;

import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CreateNewDrugPolicyPage {
    public static By policyName = By.xpath("//input[@id='drug-policy-name-input']");
    public static By payer = By.xpath("//select[@id ='payersList']");
    public static By lineofBusiness = By.xpath("//select[@id ='lineOfBusinessList']");
    public static By effectiveEndDate = By.xpath("//input[@id='effective-start-date-input']");
    public static By saveButton = By.xpath("//button[contains(text(),'Save')]");
    private static Logger log = Logger.getLogger(CreateNewDrugPolicyPage.class);
    private WebDriver driver;


    public CreateNewDrugPolicyPage(WebDriver driver) {

        this.driver = driver;


    }



    /*
  This method is to enter policyNumber on Create New Drug Policy Pop-Up*/

    public void enterThepolicyNumberonCreateNewDrugPolicyPopUp(String PolicyName) {
        log.warn("Enter policyNumber on Create New Drug Policy Pop-Up");
        TestUtils.input(driver, policyName, PolicyName);

    }

      /*
  This method is to enter effective End Date on Create New Drug Policy Pop-Up*/

    public void enterTheffectiveEndDateinCreateNewDrugPolicyPopUp(String effectiveEndDate) {
        log.warn("Enter policyNumber on Create New Drug Policy Pop-Up");
        TestUtils.input(driver, CreateNewDrugPolicyPage.effectiveEndDate, effectiveEndDate);

    }

    /*
       This method is to Select Payer on on Create New Drug Policy Pop-Up
        */
    public void selectpayerOnCreateNewDrugPolicyPopUp(String payer) {
        log.warn("select the payer on Create NewDrug Policy PopUp");
        TestUtils.select(driver, CreateNewDrugPolicyPage.payer, payer);
    }

    /*
      This method is to Select Line of Business on Create New Drug Policy Pop-Up
       */
    public void selectLineofBusinessOnCreateNewDrugPolicyPopUp(String lineofBusiness) {
        log.warn("select the Line of Business on Create NewDrug Policy PopUp");
        TestUtils.select(driver, CreateNewDrugPolicyPage.lineofBusiness, lineofBusiness);
    }

    /*
     * This method to click save Button on Create New Drug Policy Pop-Up
     *
     * */
    public void clickSaveButton() {
        log.warn("Click save on Create New Drug Policy Pop-Up");
        TestUtils.isElementPresent(driver, saveButton);
        TestUtils.click(driver, saveButton);

    }
        /*
  This method is to Edit policyNumber on Create New Drug Policy Pop-Up*/

    public void editPolicyNameInDrugPolicyMaintenancePagePopUp(String PolicyName) {
        log.warn("Edit policyNumber on Create New Drug Policy Pop-Up");
        driver.findElement(policyName).clear();
        TestUtils.input(driver, policyName, PolicyName);

    }

    /*
          This method is to Edit Line of Business on Create New Drug Policy Pop-Up
           */
    public void editLineofBusinessOnCreateNewDrugPolicyPopUp(String lineofBusiness) {
        log.warn("select the Line of Business on Create NewDrug Policy PopUp");
        TestUtils.select(driver, CreateNewDrugPolicyPage.lineofBusiness, lineofBusiness);
    }
       /*
  This method is to enter effective End Date on Create New Drug Policy Pop-Up*/

    public void editTheffectiveEndDateinCreateNewDrugPolicyPopUp(String effectiveEndDate) {
        log.warn("Enter policyNumber on Create New Drug Policy Pop-Up");
        TestUtils.input(driver, CreateNewDrugPolicyPage.effectiveEndDate, effectiveEndDate);

    }


}


