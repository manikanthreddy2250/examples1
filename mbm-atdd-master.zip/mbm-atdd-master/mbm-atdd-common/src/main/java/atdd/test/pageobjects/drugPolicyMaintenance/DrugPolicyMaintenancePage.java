package atdd.test.pageobjects.drugPolicyMaintenance;

import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

public class DrugPolicyMaintenancePage {


    private WebDriver driver;

    private static Logger log = Logger.getLogger(DrugPolicyMaintenancePage.class);
    public static final By sucessPopup = By.id("globalMessages-description");


    public static By createNewDrugPolicy = By.xpath("//span[contains(text(),'Create New Drug Policy')]");
    public static By policyNameDrugPolicyMaintenanc = By.xpath("//input[@name='searchDrugSearch']");
    public static By policySearchResults = By.xpath("//*[@id='drug-policy-search-input_flyoutList']/li[1]");
    public static By searchBtnDrugPolicyMaintenanc = By.xpath("//button[@type='submit'][@id='search-button']");
    public static By editPencilIconPolicyDetailssession = By.xpath("//*[@id='drugPolicyMaintenancePanelId_content']/div[4]/div[1]/div[1]/div[2]/p/a/uitk-icon-font");
    public static By prayerNameTypeSel = By.xpath("//select[@name='searchPayerName']");
    public static By copyLink = By.xpath("//a[contains(text(),'Copy')]");
    public static By lineOfBusinessTypeSel = By.xpath("//select[@name='LOB']");
    public static By copyButton = By.xpath("//button[contains(text(),'Copy')]");
    public static By croosIconInCopyDrgply = By.xpath("//*[@id='undefined']/uitk-icon-font/span/span[1]/span");





    //Add Drug
    public static By addDrugHyperLink = By.xpath("//a[contains(text(),'Add Drug')]");
    public static By addDrugNameDropDown = By.xpath("//div[@id='policy-search']/div/div/span[3]/uitk-icon-font/span/span/span");
    public static By addDrugNameTypeSel = By.xpath("//div[@id='policy-search']/div/div[2]/div[3]/div/div/uitk-multi-select-option[3]/li");
    public static By addOAMBuilderIdTextBox = By.xpath("//input[@id='drug-brand-builder-id']");
    public static By saveButtonInPolicyDetails = By.xpath("//button[contains(text(),'Save')]");
    public static By addSiteOfCareDropDown = By.xpath("//div[@id='site-of-care-requirement-id']/div/div/span[3]/uitk-icon-font/span/span/span");
    public static By addSiteOfCareTypeSelDropDown = By.xpath("//div[@id='site-of-care-requirement-id']//li[contains(text(),'False')]");
    public static By addDrugDelete = By.xpath("//div[@id='drugBrandTableId']/div[2]/table/tbody/tr[3]/td[1]/a[2]");
    public static By editPencilIconForAddDrug = By.xpath("//a[@id='drugBrandTableId-edit-0']/uitk-icon-font/span/span[1]/span");
    public static By editDrugNameDropDown = By.xpath("//div[@id='policy-search']/div/div/span[3]/uitk-icon-font/span/span/span");
    public static By editDrugNameTypeSel = By.xpath("//div[@id='policy-search']/div/div[2]/div[2]/div/uitk-multi-select-option[2]/li");
    public static By editSiteOfCareDropDown = By.xpath("//div[@id='site-of-care-requirement-id']/div/div/span[3]/uitk-icon-font/span/span/span");
    public static By editSiteOfCareTypeSel = By.xpath("//div[@id='site-of-care-requirement-id']//div[@title='Available List']//li[contains(text(),'True')]");
    public static By copyIconDrugName = By.xpath("//td[@headers='drugBrandsTableActions']/span");
    public static By continueButton = By.xpath("//button[contains(text(),'Continue')]");


    //Disease State Details
    public static By editDrugNameTextBox = By.xpath("//input[@name='searchProcDrugBrandName']");
    public static By editOAMBuilderIdTextBox = By.xpath("//input[@id='drug-brand-builder-id']");
    public static By editsaveButtonInPolicyDetails = By.xpath("//button[contains(text(),'Save')]");

    public static By drugBrandNameHyperLink = By.xpath("//td[@headers='brandName']//a");
    public static By addDRowHyperLink = By.xpath("//a[contains(text(),'Add Row')]");
    public static By addDiseaseStateDropDown = By.xpath("//div[@id='disease-state-details']/div/div/span[3]/uitk-icon-font/span/span/span");
    public static By addDiseaseStateTypeSel = By.xpath("//div[@id='disease-state-details']/div/div[2]/div[3]/div[2]/div/uitk-multi-select-option[2]/li");
    public static By addDiseaseStateDelete = By.xpath("//div[@id='diseaseStateTableId']/div[2]/table/tbody/tr[3]/td[1]/a[2]/uitk-icon-font/span/span[1]/span");
    public static By addDiseaseStatePopUpDeleteBtn = By.xpath("//button[contains(text(),'Delete')]");
    public static By addRowSaveButtonAddRowDieState = By.xpath("//button[contains(text(),'Save')]");
    public static By addRowCancelButtonAddRowDieState = By.xpath("//button[contains(text(),'Cancel')]");

    public static By editPencilIconForDiseaseStateDetails = By.xpath("//a[@id='diseaseStateTableId-edit-0']/uitk-icon-font/span/span[1]/span");
    public static By editDiseaseStateTypeSel = By.xpath("//div[@id='disease-state-details']/div/div[2]/div[2]/div/uitk-multi-select-option[4]/li");

    public static By addDosageExceptionDropDown = By.xpath("//div[@id='dosageException']/div/div[1]/span[3]/uitk-icon-font/span/span/span");
    public static By addDosageExceptionTypeSel = By.xpath("//div[@id='dosageException']/div/div[2]/div[2]/div/uitk-multi-select-option[1]/li");
    public static By typeToSearchDisState = By.xpath("//div[@id='disease-state-details']/div/div[2]/div[1]/div/input");
    public static By crtNewHyperLink = By.xpath("//span[contains(text(),'Create New')]");
    public static By copyIconDiseaseState = By.xpath("//td[@headers='diseaseStateTableActions']/span");


    //Drug Dosage Details And Add Row
    public static By dosageDetailsDelete = By.xpath("//div[@id='dosageTableId']/div[2]/table/tbody/tr[3]/td[1]/a[2]/uitk-icon-font/span/span[1]/span");
    public static By dosageDetailsSubTab = By.xpath("//span[contains(text(),'Dosage Details')]");
    public static By diseaseStatusDetailsSubTab = By.xpath("//span[contains(text(),'Disease State Details')]");
    public static By addDisStateTypeSelDosDetailsDropDown = By.xpath("//div[@id='drug-brand-diagnosis-class-id']/div/div/span[3]/uitk-icon-font/span/span/span");
    public static By addDisStateTypeSelDosDetails = By.xpath("//div[@id='drug-brand-diagnosis-class-id']/div/div[2]/div[2]/div/uitk-multi-select-option[2]/li");
    public static By addInivsContiTypeSelDosageDetailsDropDown = By.xpath("//div[@id='initial-vs-continuation-id']/div/div/span[3]/uitk-icon-font/span/span/span");
    public static By addInivsContiTypeSelDosageDetails = By.xpath("//div[@id='initial-vs-continuation-id']/div/div[2]/div[2]/div/uitk-multi-select-option[2]/li");
    public static By addDoseTextBox = By.xpath("//input[@id='dose-limit-id']");
    public static By addDoseTypeSelDosDetailsDropDown = By.xpath("(//div[@id='dose-measurement-id']/div/div[1]/span[3]/uitk-icon-font/span/span/span)[1]");
    public static By addDoseTypeSelDosDetails = By.xpath("//div[@id='dose-measurement-id']/div/div[2]/div[2]/div/uitk-multi-select-option[2]/li");
    public static By addDosageFrequencyFirstTextBox = By.xpath("//input[@id='dosage-frequency-id']");
    public static By addDosageFrequencySecondTextBox = By.xpath("//input[@id='frequency-limit-id']");
    public static By addDosageFrequencyTypeSelDosDetailsDropDown = By.xpath("(//div[@id='dose-measurement-id']/div/div[1]/span[3]/uitk-icon-font/span/span/span)[2]");
    public static By addDosageFrequencyTypeSelDosDetails = By.xpath("//div[@id='dose-measurement-id']/div/div[2]/div[2]/div/uitk-multi-select-option[3]/li");
    public static By adddurAuthTextBox = By.xpath("//input[@id='duration-limit-id']");
    public static By adddurAuthTypeSelDosDetailsDropDown = By.xpath("//div[@id='duration-measurement-id']/div/div/span[3]/uitk-icon-font/span/span/span");
    public static By adddurAuthTypeSelDosDetails = By.xpath("//div[@id='duration-measurement-id']/div/div[2]/div[2]/div/uitk-multi-select-option[4]/li");
    public static By addTotalDosageTextBox = By.xpath("//input[@id='total-doses-id']");
    public static By editDisStateTypeSelDosDetailsDropDown = By.xpath("//div[@id='drug-brand-diagnosis-class-id']/div/div[1]/span[3]/uitk-icon-font/span/span/span");
    public static By editDisStateTypeSelDosDetails = By.xpath("//div[@id='drug-brand-diagnosis-class-id']/div/div[2]/div[2]/div/uitk-multi-select-option[3]/li");
    public static By editDosageFrequencyTypeSelDosDetailsDropDown = By.xpath("(//div[@id='dose-measurement-id']/div/div[1]/span[3]/uitk-icon-font/span/span/span)[2]");
    public static By editDosageFrequencyTypeSelDosDetails = By.xpath("//div[@id='dose-measurement-id']/div/div[2]/div[2]/div/uitk-multi-select-option[4]/li");
    public static By editPencilIconForDosageDetails = By.xpath("//a[@id='dosageTableId-edit-0']/uitk-icon-font/span/span[1]/span");

    //Version History

    public static final By versionHistoryrecordsPerPage = By.xpath("//select[@id='plain-table-paginator_recordsPerPage']");
    public static By versionHistoryHyperLink = By.xpath("//a[contains(text(),' Version History')]");
    public static By verHistoryReturnBtn = By.xpath("//button[contains(text(),'Return to Drug Policy Maintenance ')]");
    public static By versionHisPageClonePolicyEffSrtDate = By.xpath("//input[@id='effective-start-date-input']");
    public static By cancelButton = By.xpath("//button[contains(text(),'Cancel')]");
    private By columnLabels = By.xpath("//table[@role='grid']/thead/tr[2]//a/span");
    private By versionHisPageCloneBtn = By.xpath("//td[@headers='cloneAction']//span");
    private By versionHisPageViewBtn = By.xpath("//td[@headers='viewAction']//span");


    //Bread crumbs
    public static By homeHyperLink = By.xpath("/html/body/app-root/app-breadcrumbs/div/ul/li[1]/a/span");
    public static By drgpolicyMainHyperLink = By.xpath("/html/body/app-root/app-breadcrumbs/div/ul/li[2]/a/span");

    //View All Details Tooltip / Pop-over
    public static By viewAllDetailsTooltipHyperLink = By.xpath("//div[@id='drugDetailsPanelId_content']/div[1]/div[2]/span[5]/uitk-icon-font/span/span[1]/span");
    public static By closeButtonOnPopOver = By.xpath("//button[contains(text(),'Close')]");

    public DrugPolicyMaintenancePage(WebDriver driver) {

        this.driver = driver;
    }

    public void switchToFrame(String id) {
        driver.switchTo().frame(id);
    }

    /*This method clicks on +Create New Drug Policy*/
    public void clickOnCreateNewDrugPolicy() {
        log.warn("Clicking on Create New Drug Policy");
        switchToFrame("drugPolicyMaintenanceIFrameId");
        TestUtils.click(driver, createNewDrugPolicy);

    }

    public void enterPolicyNameInDrugPolicyMaintenancePage(String SearchpolicyName) {
        log.warn("Enter Policy Name In Drug Policy Maintenance");
        switchToFrame("drugPolicyMaintenanceIFrameId");
        TestUtils.input(driver, policyNameDrugPolicyMaintenanc, SearchpolicyName);
        TestUtils.waitElementVisible(driver, policySearchResults);
        TestUtils.click(driver, policySearchResults);

    }

    public void selectLineOfBusiness(String lineOfBusiness) {
        log.warn("Enter Policy Name In Drug Policy Maintenance");
        switchToFrame("drugPolicyMaintenanceIFrameId");
        TestUtils.select(driver, policyNameDrugPolicyMaintenanc, lineOfBusiness);


    }

    public void clickOnSearchButtonInDrugPolicyMaintenancePage() {
        log.warn("Clicking on Search Button In Drug Policy Maintenance");
        TestUtils.isElementVisible(driver, searchBtnDrugPolicyMaintenanc);
        TestUtils.click(driver, searchBtnDrugPolicyMaintenanc);
        TestUtils.isElementVisible(driver, drugBrandNameHyperLink);
        TestUtils.isElementVisible(driver, drugBrandNameHyperLink);


    }

    /*This method clicks on +Edit pencil Icon*/
    public void clickOnEditpencilIconPolicyDetailssession() {
        log.warn("Clicking on Edit pencil Icon In Policy Details session");
        TestUtils.click(driver, editPencilIconPolicyDetailssession);
    }

    /*This method select payer Name */
    public void selectPayerNameInDrugPolicyMaintenance(String PrayerName) {
        log.warn("Select Payer Name in Drug Policy Maintenance session");
        TestUtils.select(driver, prayerNameTypeSel, PrayerName);


    }

    /*This method clicks on +Add Drug HyperLink*/
    public void clickOnAddDrugHyperLinkInPolicyDetailsSession(String drugname) {
        log.warn("Clicking on Create New Drug Policy");
        switchToFrame("drugPolicyMaintenanceIFrameId");
        TestUtils.isElementVisible(driver, addDrugHyperLink);
        TestUtils.click(driver, addDrugHyperLink);
        TestUtils.isElementVisible(driver, addDrugNameDropDown);
        TestUtils.click(driver, addDrugNameDropDown);
        By addDrugNameValue = By.xpath("//li[contains(text(),'" + drugname + "')]");
        TestUtils.isElementVisible(driver, addDrugNameValue);
        TestUtils.click(driver, addDrugNameValue);

    }


    /*This method select Site Of Care */
    public void selectSiteOfCareInPolicyDetailsSession() {
        log.warn("Select Site Of Care in Policy Details session");
        TestUtils.isElementVisible(driver, addSiteOfCareDropDown);
        TestUtils.click(driver, addSiteOfCareDropDown);
        TestUtils.isElementVisible(driver, addSiteOfCareTypeSelDropDown);
        TestUtils.click(driver, addSiteOfCareTypeSelDropDown);


    }

    public void enterAddOAMBuilderIDInPolicyDetailsSession(String oAMBuilderID) {
        log.warn("Enter OAM Builder Id In Policy Details session");
        TestUtils.isElementVisible(driver, addOAMBuilderIdTextBox);
        TestUtils.input(driver, editOAMBuilderIdTextBox, oAMBuilderID);
    }

    public void ClickingDeleteIconInAddDrugSession() {
        log.warn("Clicking on Delete In Add Drug Session");
        TestUtils.isElementVisible(driver, addDrugDelete);
        TestUtils.click(driver, addDrugDelete);
        TestUtils.isElementVisible(driver, addDiseaseStatePopUpDeleteBtn);
        TestUtils.click(driver, addDiseaseStatePopUpDeleteBtn);

    }

    public void ClickingDeleteIconInDiseaseStateDetails() {
        log.warn("Clicking on Delete In Add Drug Session");
        TestUtils.isElementVisible(driver, addDiseaseStateDelete);
        TestUtils.click(driver, addDiseaseStateDelete);
        TestUtils.isElementVisible(driver, addDiseaseStatePopUpDeleteBtn);
        TestUtils.click(driver, addDiseaseStatePopUpDeleteBtn);

    }

    public void ClickingDeleteIconInDosageDetailssession() {
        log.warn("Clicking on Delete In Add Drug Session");
        TestUtils.isElementVisible(driver, dosageDetailsDelete);
        TestUtils.isElementVisible(driver, dosageDetailsDelete);
        TestUtils.click(driver, dosageDetailsDelete);
        TestUtils.isElementVisible(driver, addDiseaseStatePopUpDeleteBtn);
        TestUtils.click(driver, addDiseaseStatePopUpDeleteBtn);

    }

    public void clickOnSaveButtonInPolicyDetailsSession() {
        log.warn("Clicking on Save Button In  Policy Details session");
        TestUtils.click(driver, saveButtonInPolicyDetails);
    }

    /*This method clicks on Edit Pencil Icon In Add Drug Details Session*/
    public void clickOnlicksonEditPencilIconInAddDrugDetailsSession() {
        log.warn("Clicking on licks on Edit Pencil Icon In Add Drug Details Session");
        switchToFrame("drugPolicyMaintenanceIFrameId");
        TestUtils.isElementVisible(driver, editPencilIconForAddDrug);
        TestUtils.click(driver, editPencilIconForAddDrug);
        TestUtils.isElementVisible(driver, editDrugNameDropDown);
        TestUtils.click(driver, editDrugNameDropDown);


    }

    public void enterEditDrugNameInPolicyDetailsSession(String drugName1) {
        log.warn("Enter Edit Drug Name In Policy Details session");
        switchToFrame("drugPolicyMaintenanceIFrameId");
        TestUtils.isElementVisible(driver, editDrugNameTextBox);
        TestUtils.clearTextBox(editDrugNameTextBox, driver);
        TestUtils.input(driver, editDrugNameTextBox, drugName1);

    }

    /*This method select Site Of Care for Edit Drug */
    public void selectEditSiteOfCareInPolicyDetailsSession(String siteOfCare1) {
        log.warn("Select Site Of Care in Policy Details session");
        TestUtils.isElementVisible(driver, editSiteOfCareDropDown);
        TestUtils.click(driver, editSiteOfCareDropDown);
        TestUtils.isElementVisible(driver, editSiteOfCareTypeSel);
        TestUtils.click(driver, editSiteOfCareTypeSel);
    }

    public void enterEditOAMBuilderIDInPolicyDetailsSession(String oAMBuilderID1) {
        log.warn("Enter OAM Builder Id In Policy Details session");
        driver.findElement(editOAMBuilderIdTextBox).clear();
        TestUtils.input(driver, editOAMBuilderIdTextBox, oAMBuilderID1);

    }

    public void clickOnEditSaveButtonInPolicyDetailsSession() {
        log.warn("Clicking on Edit Save Button In  Policy Details session");
        TestUtils.click(driver, editsaveButtonInPolicyDetails);


    }

    public void clickOndrugbrandNamePolicyDetailsSession() throws InterruptedException {
        log.warn("Clicking on Drug Brand Name hyper link In  Policy Details session");
        switchToFrame("drugPolicyMaintenanceIFrameId");
        Thread.sleep(3000);
        List<WebElement> w = driver.findElements(drugBrandNameHyperLink);
        w.get(0).click();
//        TestUtils.safeClick(driver, drugBrandNameHyperLink);
    }

    public void enterDrugNameInDiseaseStateDetails() {
        log.warn("Enter Disease State In Disease State Details session");
        switchToFrame("drugPolicyMaintenanceIFrameId");
        TestUtils.isElementVisible(driver, addDRowHyperLink);
        TestUtils.click(driver, addDRowHyperLink);
        TestUtils.isElementVisible(driver, addDiseaseStateDropDown);
        TestUtils.click(driver, addDiseaseStateDropDown);
        TestUtils.isElementVisible(driver, addDiseaseStateTypeSel);
        TestUtils.click(driver, addDiseaseStateTypeSel);

    }

    public void enterDiseaseStatesearchtextbox(String Diseasestate) {
        log.warn("Enter Disease State In Disease State Details session");
        switchToFrame("drugPolicyMaintenanceIFrameId");
        TestUtils.isElementVisible(driver, addDRowHyperLink);
        TestUtils.click(driver, addDRowHyperLink);
        TestUtils.isElementVisible(driver, addDiseaseStateDropDown);
        TestUtils.click(driver, addDiseaseStateDropDown);
        TestUtils.input(driver, typeToSearchDisState, Diseasestate);
        By availableList = By.xpath("//div[@title='Available List']//li[contains(text(),'" + Diseasestate + "')]");
        TestUtils.click(driver, availableList);
        TestUtils.click(driver, saveButtonInPolicyDetails);

    }

    public void enterDiseaseStatesearchtextboxForCancel(String Diseasestates) {
        log.warn("Enter Disease State In Disease State Details session");
        switchToFrame("drugPolicyMaintenanceIFrameId");
        TestUtils.isElementVisible(driver, addDRowHyperLink);
        TestUtils.click(driver, addDRowHyperLink);
        TestUtils.isElementVisible(driver, addDiseaseStateDropDown);
        TestUtils.click(driver, addDiseaseStateDropDown);
        TestUtils.input(driver, typeToSearchDisState, Diseasestates);
        By diseasestatexpath = By.xpath("//div[@title='Available List']//li[contains(text(),'" + Diseasestates + "')]");
        TestUtils.click(driver, diseasestatexpath);
        TestUtils.click(driver, cancelButton);

    }


    public void selectDosageExceptionInDiseaseStateDetails() {
        log.warn("Select Dosage Exception In Disease State Details session");
        switchToFrame("drugPolicyMaintenanceIFrameId");
        TestUtils.isElementVisible(driver, addDRowHyperLink);
        TestUtils.click(driver, addDRowHyperLink);

    }

    public void clickOnAddRowSaveButtonInDiseaseStateDetailsSession() {
        log.warn("Clicking on Save Button In Disease State Details Session");
        TestUtils.click(driver, addRowSaveButtonAddRowDieState);


    }

    public void clickOnDosageDetailsSubTab() {
        log.warn("Clicking On Dosage Details SubTab");
        switchToFrame("drugPolicyMaintenanceIFrameId");
        TestUtils.isElementVisible(driver, dosageDetailsSubTab);
        TestUtils.isElementVisible(driver, dosageDetailsSubTab);
        TestUtils.click(driver, dosageDetailsSubTab);
    }

    /*This method select Add Row Disease State Dosage Details */
    public void selectAddRowDiseaseStateDosageDetails(String Diseasestate) throws InterruptedException {
        log.warn("select Add Row Disease State Dosage Details");
        switchToFrame("drugPolicyMaintenanceIFrameId");
        Thread.sleep(5000);
        TestUtils.isElementVisible(driver, addDRowHyperLink);
        TestUtils.click(driver, addDRowHyperLink);
        By addElement = By.xpath("//span[@id='drug-brand-diagnosis-class-id-support-text']//following::span[1]");
        TestUtils.click(driver, addElement);
        By diseasestate = By.xpath("//input[@placeholder='Type to search']");
        TestUtils.input(driver, diseasestate, Diseasestate);
        By diseaseStateSelector = By.xpath("//div[@title='Available List']//li[contains(text(),'" + Diseasestate + "')]");
        TestUtils.click(driver, diseaseStateSelector);
    }

    /*This method select Add Row Initial vs Continuation Dosage Details */
    public void selectAddRowInitialvsContinuationDosageDetails() {
        log.warn("select Add Row Initial vs Continuation Dosage Details");
        TestUtils.click(driver, addInivsContiTypeSelDosageDetailsDropDown);
        TestUtils.click(driver, addInivsContiTypeSelDosageDetails);

    }

    public void selectAddRowDoseDosageDetails(String dose) {
        log.warn("select Add Row Dose Dosage Details");
        TestUtils.input(driver, addDoseTextBox, dose);
        TestUtils.click(driver, addDoseTypeSelDosDetailsDropDown);
        TestUtils.click(driver, addDoseTypeSelDosDetails);


    }

    public void selectAddRowDosageFrequencyFirstDosageDetails(String dosageFrequencyFirst) {
        log.warn("select Add Row Dose Dosage Details");
        TestUtils.input(driver, addDosageFrequencyFirstTextBox, dosageFrequencyFirst);
    }

    public void selectAddRowDosageFrequencySecondDosageDetails(String dosageFrequencySecond) {
        log.warn("select Add Row Dose Dosage Details");
        TestUtils.input(driver, addDosageFrequencySecondTextBox, dosageFrequencySecond);
        TestUtils.click(driver, addDosageFrequencyTypeSelDosDetailsDropDown);
        TestUtils.click(driver, addDosageFrequencyTypeSelDosDetails);


    }

    public void selectAddRowDurationofAuthorizationDosageDetails(String durationofAuthorization) {
        log.warn("select Add Row Dose Dosage Details");
        TestUtils.input(driver, adddurAuthTextBox, durationofAuthorization);
        TestUtils.click(driver, adddurAuthTypeSelDosDetailsDropDown);
        TestUtils.click(driver, adddurAuthTypeSelDosDetails);


    }

    public void enterCreateTotalDosageInDosageDetails(String totalDosage) {
        log.warn("select Add Row Dose Dosage Details");
        TestUtils.input(driver, addTotalDosageTextBox, totalDosage);

    }

    /*This method clicks on Edit Pencil Icon In Add Drug Details Session*/
    public void clickOnEditPencilIconInDiseaseStateDetails() {
        log.warn("Clicking on licks on Edit Pencil Icon In Add Drug Details Session");
        switchToFrame("drugPolicyMaintenanceIFrameId");
        TestUtils.isElementVisible(driver, editPencilIconForDiseaseStateDetails);
        TestUtils.click(driver, editPencilIconForDiseaseStateDetails);
        TestUtils.isElementVisible(driver, addDiseaseStateDropDown);
        TestUtils.click(driver, addDiseaseStateDropDown);
        TestUtils.isElementVisible(driver, editDiseaseStateTypeSel);
        TestUtils.click(driver, editDiseaseStateTypeSel);

    }

    public void clickOnEditPencilIconInDiseaseStateDetailsForAddDosageDropDown() {
        log.warn("Clicking on licks on Edit Pencil Icon In Add Drug Details Session");
        switchToFrame("drugPolicyMaintenanceIFrameId");
        TestUtils.isElementVisible(driver, editPencilIconForDiseaseStateDetails);
        TestUtils.click(driver, editPencilIconForDiseaseStateDetails);
        TestUtils.isElementVisible(driver, addDiseaseStateDropDown);
        TestUtils.click(driver, addRowCancelButtonAddRowDieState);
        TestUtils.isElementVisible(driver, editPencilIconForDiseaseStateDetails);
        TestUtils.click(driver, editPencilIconForDiseaseStateDetails);
    }

    public void selectEditRowDiseaseStateDosageDetails() throws InterruptedException {
        log.warn("Select Edit Row Dosage Details");
        switchToFrame("drugPolicyMaintenanceIFrameId");
        TestUtils.click(driver, editPencilIconForDosageDetails);
        TestUtils.isElementVisible(driver, editDisStateTypeSelDosDetailsDropDown);
        TestUtils.click(driver, editDisStateTypeSelDosDetailsDropDown);
        TestUtils.isElementVisible(driver, editDisStateTypeSelDosDetails);
        TestUtils.click(driver, editDisStateTypeSelDosDetails);
        Thread.sleep(5000);
        TestUtils.isElementVisible(driver, editDosageFrequencyTypeSelDosDetailsDropDown);
        TestUtils.click(driver, editDosageFrequencyTypeSelDosDetailsDropDown);
        TestUtils.click(driver, editDosageFrequencyTypeSelDosDetails);
    }

    public void enterEditTotalDosageInDosageDetails(String totalDosage) {
        log.warn("Enter Edit Row Total Dose Dosage Details");
        driver.findElement(addTotalDosageTextBox).clear();
        TestUtils.input(driver, addTotalDosageTextBox, totalDosage);
    }

    public void ClickOnVersionHistoryHyperLink() {
        log.warn("Clicking on Version History Hyper Link");
        switchToFrame("drugPolicyMaintenanceIFrameId");
        TestUtils.isElementVisible(driver, versionHistoryHyperLink);
        TestUtils.click(driver, versionHistoryHyperLink);
    }

    public void versionHistoryrecordsPerPage(String option) {
        switchToFrame("drugPolicyMaintenanceIFrameId");
        TestUtils.select(driver, versionHistoryrecordsPerPage, option);
        TestUtils.wait(3);
    }


    public void validateColumnNames(List<String> columnNames) {
        switchToFrame("drugPolicyMaintenanceIFrameId");
        List<WebElement> labels = this.driver.findElements(this.columnLabels);

        for (int i = 0; i < columnNames.size(); ++i) {
            Assert.assertEquals("\"" + labels.get(i).getText() + "\"", columnNames.get(i));
        }

    }

    public void clickonReturnDrugpolicyBtn(String arg0) {
        log.warn("Clicking on Return to Drug Policy Maintenance");
        switchToFrame("drugPolicyMaintenanceIFrameId");
        TestUtils.isElementVisible(driver, verHistoryReturnBtn);
        TestUtils.click(driver, verHistoryReturnBtn);
    }

    public void clickOnclickontheCloneiconontheversionHistorypage() {
        log.warn("Clicking on Clone icon In version History Page");
        switchToFrame("drugPolicyMaintenanceIFrameId");
        List<WebElement> options = driver.findElements(versionHisPageCloneBtn);
        for (WebElement e : options) {
            e.click();
            break;
        }
    }

    public void enterEffectiveStartDateInClonePolicyVersionPopUpWindow(String effectiveStartDate) {
        log.warn("Enter Effective Start Date in Clone Policy Version PopUp Window");
        switchToFrame("drugPolicyMaintenanceIFrameId");
        TestUtils.clearTextBox(versionHisPageClonePolicyEffSrtDate, driver);
        TestUtils.input(driver, versionHisPageClonePolicyEffSrtDate, effectiveStartDate);
        TestUtils.click(driver, cancelButton);
        List<WebElement> options = driver.findElements(versionHisPageCloneBtn);
        for (WebElement e : options) {
            e.click();
            break;
        }
        TestUtils.isElementVisible(driver, versionHisPageClonePolicyEffSrtDate);
        TestUtils.clearTextBox(versionHisPageClonePolicyEffSrtDate, driver);
        TestUtils.input(driver, versionHisPageClonePolicyEffSrtDate, effectiveStartDate);
        TestUtils.click(driver, saveButtonInPolicyDetails);
        options = driver.findElements(versionHisPageViewBtn);
        for (WebElement e : options) {
            e.click();
            break;
        }
    }

    public void userClickonbreadcrumbforHomeinDrugPolicyMaintenancepage() {
        switchToFrame("drugPolicyMaintenanceIFrameId");
        TestUtils.isElementVisible(driver, homeHyperLink);
        TestUtils.click(driver, homeHyperLink);
    }

    public void clickonBreadcrumbfromVersionHistorytoDrugPolicyMaintenance() {
        switchToFrame("drugPolicyMaintenanceIFrameId");
        TestUtils.isElementVisible(driver, drgpolicyMainHyperLink);
        TestUtils.click(driver, drgpolicyMainHyperLink);

    }

    public void userclickonBreadcrumbfromVersionHistorytoHome() {
        switchToFrame("drugPolicyMaintenanceIFrameId");
        TestUtils.isElementVisible(driver, homeHyperLink);
        TestUtils.click(driver, homeHyperLink);

    }

    public void clickonBreadcrumbfromDrugDetailstoDrugPolicyMaintenance() {
        switchToFrame("drugPolicyMaintenanceIFrameId");
        TestUtils.isElementVisible(driver, drgpolicyMainHyperLink);
        TestUtils.click(driver, drgpolicyMainHyperLink);

    }

    public void clickonBreadcrumbfromDrugDetailstoHome() {
        switchToFrame("drugPolicyMaintenanceIFrameId");
        TestUtils.isElementVisible(driver, homeHyperLink);
        TestUtils.click(driver, homeHyperLink);

    }

    public void clickonthelinktotheViewAllDetailspopover() {
        switchToFrame("drugPolicyMaintenanceIFrameId");
        TestUtils.isElementVisible(driver, viewAllDetailsTooltipHyperLink);
        TestUtils.click(driver, viewAllDetailsTooltipHyperLink);
    }

    public void clickonClosetoexitfromthepopover() {
        switchToFrame("drugPolicyMaintenanceIFrameId");
        TestUtils.isElementVisible(driver, closeButtonOnPopOver);
        TestUtils.click(driver, closeButtonOnPopOver);
    }

    public void clickontheCopyinicondrugnameunderActions() {
        switchToFrame("drugPolicyMaintenanceIFrameId");
        List<WebElement> w = driver.findElements(copyIconDrugName);
        w.get(0).click();


    }


    public void clickonContinuebuttononpopuptooltip() {
        switchToFrame("drugPolicyMaintenanceIFrameId");
        TestUtils.isElementVisible(driver, continueButton);
        TestUtils.click(driver, continueButton);
    }

    public void selecttheCopyOneDrugtoAnotherdrug() {
        switchToFrame("drugPolicyMaintenanceIFrameId");
        TestUtils.isElementVisible(driver, addDrugNameDropDown);
        TestUtils.click(driver, addDrugNameDropDown);
        TestUtils.isElementVisible(driver, addDrugNameDropDown);
        TestUtils.click(driver, addDrugNameTypeSel);
    }

    public void clickSaveafterenteringthenewDrugName() {
        switchToFrame("drugPolicyMaintenanceIFrameId");
        TestUtils.isElementVisible(driver, saveButtonInPolicyDetails);
        TestUtils.click(driver, saveButtonInPolicyDetails);

    }

    public void successPopUpDisplayed() {
        TestUtils.isElementVisible(driver, sucessPopup);
        TestUtils.wait(2);
    }

    public void clickonCancelbuttononDrugNamewindow() {
        switchToFrame("drugPolicyMaintenanceIFrameId");
        TestUtils.isElementVisible(driver, cancelButton);
        TestUtils.click(driver, cancelButton);

    }

    public void clickontheCopyiniconDiseaseStateunderActions() {
        switchToFrame("drugPolicyMaintenanceIFrameId");
        List<WebElement> w = driver.findElements(copyIconDiseaseState);
        w.get(0).click();
    }

    public void userSelectTheCopyOneDiseaseStateToAnotherDiseaseState() throws InterruptedException {
        switchToFrame("drugPolicyMaintenanceIFrameId");
        TestUtils.isElementVisible(driver, addDiseaseStateDropDown);
        Thread.sleep(5000);
        TestUtils.click(driver, addDiseaseStateDropDown);
        TestUtils.isElementVisible(driver, addDiseaseStateTypeSel);
        TestUtils.click(driver, addDiseaseStateTypeSel);
    }

    public void clickontheCopyiconinthePolicyDetails() {
        switchToFrame("drugPolicyMaintenanceIFrameId");
        TestUtils.isElementVisible(driver, copyLink);
        TestUtils.click(driver, copyLink);
    }

    public void selecttheDrugPolicyforonePayerLineofBusiness(String arg0) {
        switchToFrame("drugPolicyMaintenanceIFrameId");
        TestUtils.isElementVisible(driver, lineOfBusinessTypeSel);
        TestUtils.selectByVisibleText(this.driver.findElement(lineOfBusinessTypeSel), arg0);
    }

    public void clickoncopyicononpopupwindow() {
        switchToFrame("drugPolicyMaintenanceIFrameId");
        TestUtils.isElementVisible(driver, copyButton);
        TestUtils.click(driver, copyButton);
    }

    public void clickonIconCxbuttononDrugNamewindow() {
        switchToFrame("drugPolicyMaintenanceIFrameId");
        TestUtils.isElementVisible(driver, croosIconInCopyDrgply);
        TestUtils.click(driver, croosIconInCopyDrgply);

    }

    public void deleteDiseasestate(String disease_state) {
        switchToFrame("drugPolicyMaintenanceIFrameId");
        By deleteicon = By.xpath("//span[contains(text(),'" + disease_state + "')]//ancestor::tr/td[1]//span[@class='uimf-icon-trash_delete sm-icon']");
        TestUtils.isElementVisible(driver, deleteicon);
        TestUtils.click(driver, deleteicon);
        By DeletePopup = By.xpath("//button[contains(text(),'Delete')]");
        TestUtils.click(driver, DeletePopup);
    }

    public void deleteDrug(String drugName) {
        switchToFrame("drugPolicyMaintenanceIFrameId");
        By deleteicon = By.xpath("//a[contains(text(),'" + drugName + "')]//ancestor::tr//span[@class='uimf-icon-trash_delete sm-icon']");
        TestUtils.isElementVisible(driver, deleteicon);
        TestUtils.click(driver, deleteicon);
        By DeletePopup = By.xpath("//button[contains(text(),'Delete')]");
        TestUtils.click(driver, DeletePopup);
    }

    public void clickDiseaseStatusTab() {
        log.warn("Clicking On Dosage Details SubTab");
        switchToFrame("drugPolicyMaintenanceIFrameId");
        TestUtils.isElementVisible(driver, diseaseStatusDetailsSubTab);
        TestUtils.isElementVisible(driver, diseaseStatusDetailsSubTab);
        TestUtils.click(driver, diseaseStatusDetailsSubTab);

    }
}