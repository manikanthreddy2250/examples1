package atdd.test.pageobjects.icue;


import atdd.test.shared.BaseCucumber;
import atdd.test.shared.Globals;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

public class Icue {


    Logger log;
    Globals gv = BaseCucumber.gv;
    private WebDriver driver;
    private TestUtils utils;
    private String owner;

    //xpath
    public static final String LIST_TABLE = "//table[@class='listTable']";

    //Locators---------------
    public static final By userId = By.xpath("//input[@id='userID']");
    public static final By pass = By.xpath("//input[@id='password']");
    public static final By signOn = By.xpath("//input[@type='SUBMIT']");
    public static final By domainSelect = By.xpath("//select[@id='loginDomain']");
    public static final By vendorCaseId = By.xpath("//input[@id='searchID']");
    public static final By searchBtnHealthSrv = By.xpath("//button[@id='filterButton']");
    public static final By errorMessage = By.xpath("//*[@id='error']");
    public static final By action = By.id("action");
    public static final By performAction = By.xpath("//input[@id='performAction']|//input[@name='PerformAction']");
    public static final By notificationTabLink = By.xpath("//span[.='1. Notification']");
    public static final By healthServiceCaseLink = By.xpath("//a[@id='4' and contains(text(),'Health Service Case')]");
    //Locators--------------

    public Icue(WebDriver webDriver) {
        this.driver = webDriver;
        utils = BaseCucumber.utils;
        log = Logger.getLogger(this.getClass().getName());
    }

    /**
     * Check data from HSC Assignments table. By column header name.
     *
     * @param columnName
     * @param value
     * @return
     */
    public Icue checkHSCAssignmentsColumnElements(String columnName, String value) {
        log.warn("Checking " + value + " values in the " + columnName + " column");
        By clolumnName = By.xpath("//div[@id='intake']//thead/tr/th");
        List<WebElement> column = driver.findElements(clolumnName);
        String tmp = "none";
        boolean res = false;
        int colNum = 0;

        //Getting position of column
        for (WebElement e : column) {
            colNum++;
            tmp = e.getText().trim();
            TestUtils.highlightElement(driver, e);
            if (tmp.equals(columnName)) {
                res = true;
                break;
            }
        }

        Assert.assertTrue("Column " + columnName + " is not present.", res);

        //Getting locator by position
        By tableCell = By.xpath("//table[@class='listTable useDataTable']//tbody//td[" + colNum + "]");

        //Getting text from cell
        String cellValue = driver.findElement(tableCell).getText();
        log.warn("Cell value is: " + cellValue);

        Assert.assertEquals("Cell value " + value + " is not present in the column " + columnName + ". Present: " + cellValue,
                cellValue, value);

        return this;
    }

    /**
     * Check data from Alerts table. By column header name.
     *
     * @param columnName
     * @param value
     * @return
     */
    public Icue checkAlertsColumnElements(String columnName, String value) {
        log.warn("Checking " + value + " values in the " + columnName + " column");
        By clolumnName = By.xpath("//div[@id='alertsTable']/table/tbody/tr/th");
        List<WebElement> column = driver.findElements(clolumnName);
        String tmp = "none";
        boolean res = false;
        int colNum = 0;

        //Getting position of column
        for (WebElement e : column) {
            colNum++;
            tmp = e.getText().trim();
            TestUtils.highlightElement(driver, e);
            if (tmp.equals(columnName)) {
                res = true;
                break;
            }
        }

        Assert.assertTrue("Column " + columnName + " is not present.", res);

        //Getting locator by position
        By tableCell = By.xpath("//div[@id='alertsTable']//tbody//td[" + colNum + "]");

        //Getting text from cell
        String cellValue = driver.findElement(tableCell).getText();
        log.warn("Cell value is: " + cellValue);

        Assert.assertEquals("Cell value " + value + " is not present in the column " + columnName + ". Present: " + cellValue,
                cellValue, value);

        return this;
    }

    /**
     * Click Tab on the Notification Page
     *
     * @param tabTxt
     * @return
     */
    public Icue clickTabOnNotificationPage(String tabTxt) {
        log.warn("Click " + tabTxt + " Tab on Notification Page");

        By tab = By.xpath("//ul[@class='nav nav-tabs']//span[contains(text(),'" + tabTxt + "')]");

        utils.waitElement(driver, tab);
        utils.wait(3);
        driver.findElement(tab).click();
        return this;
    }

    /**
     * Click Search on the Health Service Case Search page
     *
     * @return
     */
    public void clearPCPAlert() {
        log.warn("Click Search on the Health Service Case Search page");
        By alertCheckBox = By.xpath("//div[@id='alertsTable']//input[@name='alertSeqNum']");
        TestUtils.click(this.driver, alertCheckBox);
    }

    /**
     * Click Search on the Health Service Case Search page
     *
     * @return
     */
    public Icue clickSearchHealthService() {
        log.warn("Click Search on the Health Service Case Search page");
        utils.waitElement(driver, searchBtnHealthSrv);
        driver.findElement(searchBtnHealthSrv).click();
        return this;
    }

    /**
     * Entering Vendor Case ID.
     *
     * @param caseId
     * @return
     */
    public Icue enterVendorCaseId(String caseId) {
        log.warn("Enter Vendor Case Id: " + caseId);
        utils.waitElement(driver, vendorCaseId);
        driver.findElement(vendorCaseId).clear();
        driver.findElement(vendorCaseId).sendKeys(caseId);
        return this;
    }

    /**
     * Select option from the Navigation drop-down. Select by text
     *
     * @param nav
     * @return
     */
    public Icue selectNavdropDownOption(String nav) {
        log.warn("Click Navigation drop-down option: " + nav);

        By navDropDownOption = By.xpath("//ul[@class='dropdown-menu']//a[contains(text(), '" + nav + "')]");

        utils.waitElement(driver, navDropDownOption);
        driver.findElement(navDropDownOption).click();

        return this;
    }

    /**
     * Click on Navigation drop-down. Select by Access key. First letter of parameter.
     *
     * @param nav
     * @return
     */
    public Icue clickNavdropDown(String nav) {
        log.warn("Click Navigation drop-down: " + nav);

        String accessKey = nav.substring(0, 1).toUpperCase();

        By navDropDown = By.xpath("//ul[@class='nav']//a[@accesskey='" + accessKey + "']");

        utils.waitElement(driver, navDropDown);
        driver.findElement(navDropDown).click();

        return this;
    }

    /**
     * Enter text in to User ID field
     *
     * @param userIdtxt
     * @return
     */
    public Icue enterUserId(String userIdtxt) {
        log.warn("Enter text in to the User ID field: " + userIdtxt);
        utils.wait(2);
        utils.highlightElement(driver, userId);
        driver.findElement(userId).clear();
        driver.findElement(userId).sendKeys(userIdtxt);

        return this;
    }

    /**
     * Enter text in to User Pass field
     *
     * @param userPass
     * @return
     */
    public Icue enterUserPass(String userPass) {
        log.warn("Enter text in to the Password field");
        utils.wait(2);
        utils.highlightElement(driver, pass);
        driver.findElement(pass).clear();
        driver.findElement(pass).sendKeys(userPass);

        return this;
    }


    /**
     * Select Domain from drop-down
     *
     * @param domainOption
     * @return
     */
    public Icue selectDomain(String domainOption) {
        log.warn("Select Domain: " + domainOption);
        utils.waitElement(driver, domainSelect);
        utils.highlightElement(driver, domainSelect);
        utils.selectByVisibleText(driver, domainSelect, domainOption);
        return this;
    }

    /**
     * click on Sign On button
     *
     * @return
     */
    public Icue clickSignOn() {
        log.warn("Click Sighn in");
        utils.highlightElement(driver, signOn);
        driver.findElement(signOn).click();
        return this;
    }


    /**
     * Verify error message on top of the Icue Page
     */
    public void verifyErrorMessageOnTopOfIcuePage(String msg) {
        log.warn("Verify error message on top of the Icue page");
        utils.waitElement(driver, errorMessage);
        utils.highlightElement(driver, errorMessage);
        Assert.assertEquals("Error message is not valid", msg, driver.findElement(errorMessage).getText());
    }

    /**
     * Verifying HSC Status in the Notification Tab
     *
     * @param status
     */
    public void verifyHSCStatus(String status) {
        log.warn("Verify HSC Status in the Notification Tab");
        Assert.assertTrue(status + "of HSC is not vaild",
                utils.isElementPresent(driver, By.xpath("//div[@id='intake']//../td[contains(text(),'" + status + "')]")));
        utils.highlightElement(driver, By.xpath("//div[@id='intake']//../td[contains(text(),'" + status + "')]"));

    }

    /**
     * Perform Action Generic to All ICUE Page Objects
     *
     * @param s
     */
    public void performAction(Scenario scenario, String s) {
        TestUtils.select(this.driver, action, s);
        TestUtils.demoBreakPoint(scenario, this.driver, "Perform Action: " + s);
        TestUtils.click(this.driver, performAction);
    }

    /**
     * View clinical oncology document from ICUE to MBM
     *
     * @param mbm
     */
    public void clickViewOncologyClinicalInformation(String mbm) {
        log.warn("Click : " + mbm);
        By voci = By.xpath("//a[contains(text(), '" + mbm + "')]");
        utils.waitElement(driver, voci);
        driver.findElement(voci).click();
        TestUtils.switchToNewWindow(driver);
    }

    /**
     * Verify HSC assignment (workqueue) is found in ICUE
     *
     * @param records
     */
    public void verifyHSCAssignments(String records) {
        log.warn("Verify HSC Assignments");
        Assert.assertTrue("No Record Found for HSC Assignments",
                TestUtils.isElementVisible(this.driver, By.xpath("//table[@class='listTable useDataTable']//span[contains(text(),'" + records + "')]")));
        TestUtils.highlightElement(this.driver, By.xpath("//div[@id='intake']//../td[contains(text(),'" + records + "')]"));
    }

    /**
     * Click popup Continue Action button if displayed
     */
    public void tryClickContinueAction() {
        log.warn("Click popup Continue Action button if displayed");
        List<WebElement> els = driver.findElements(By.xpath("//button[.='Continue Action']"));
        if (1 == els.size()) {
            els.get(0).click();
        }
    }

    public void verifyWorkQueueInSidebar(String queue) {
        log.warn("Verify Work Queue");
        Assert.assertTrue("No Record Found for Work Queue",
                TestUtils.isElementVisible(this.driver, By.xpath("//div[@id='serviceRefNumDivSide']//td[contains(text(),'" + queue + "')]")));
    }

    public void verifyAlertsNameInSidebar(String alerts) {
        log.warn("Verify Alerts Name");
        Assert.assertTrue("No Record Found for Alerts Name",
                TestUtils.isElementVisible(this.driver, By.xpath("//div[@id='alertsDivSide']//td[contains(text(),'" + alerts + "')]")));
    }

    public void verifyNoteSection(String option){

        By notesXpath=By.xpath("//td[contains(text(),'"+option+"')]");
        Assert.assertTrue(TestUtils.isElementVisible(driver,notesXpath));
    }

    public void clickHealthServiceCase(){
        log.warn("Clicking Health Service Case link");
        TestUtils.click(driver,healthServiceCaseLink);
        TestUtils.wait(3);
    }

}
