package atdd.test.pageobjects.icue;

import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class IcueContAndAct extends Icue {
    public static final Logger log = Logger.getLogger(IcueContAndAct.class.getName());

    public static final By activityType = By.id("activityType-input");
    public static final By activityResolutionOutcomeType = By.id("activityResolutionOutcomeType-input");
    public static final By communicationDateTimeCOMM = By.id("communicationDateTimeCOMM");
    public static final By TIME_communicationDateTimeCOMM = By.id("TIME_communicationDateTimeCOMM");
    public static final By serviceSeqNum1 = By.id("serviceSeqNum1");
    public static final By channelSourceTypeCOMM = By.id("channelSourceTypeCOMM");
    public static final By communicationTypeCOMM = By.id("communicationTypeCOMM");
    public static final By contactRoleTypeCOMM = By.id("contactRoleTypeCOMM");

    private final WebDriver webDriver;

    /**
     * ICUE Cont&Act Page Object
     *
     * @param webDriver
     */
    public IcueContAndAct(WebDriver webDriver) {
        super(webDriver);
        this.webDriver = webDriver;
    }

    /**
     * Input Activity Type
     *
     * @param s
     */
    public void inputActivityType(String s) {
        log.warn("inputActivityType: " + s);
        TestUtils.input(webDriver, activityType, s);
        TestUtils.click(webDriver, By.xpath("//ul[.='" + s + "']|//li[.='" + s + "']"));
    }

    /**
     * Input Activity Resolution Outcome Type
     *
     * @param s
     */
    public void inputActivityResolutionOutcomeType(String s) {
        log.warn("inputActivityResolutionOutcomeType: " + s);
        TestUtils.input(webDriver, activityResolutionOutcomeType, s);
        TestUtils.click(webDriver, By.xpath("//ul[.='" + s + "']|//li[.='" + s + "']"));
    }

    /**
     * Input Communication Date
     *
     * @param s
     */
    public void inputCommunicationDateTimeCOMM(String s) {
        log.warn("inputCommunicationDateTimeCOMM: " + s);
        TestUtils.input(webDriver, communicationDateTimeCOMM, s);
    }

    /**
     * Input Communication Time
     *
     * @param s
     */
    public void inputTIME_communicationDateTimeCOMM(String s) {
        log.warn("inputTIME_communicationDateTimeCOMM: " + s);
        TestUtils.input(webDriver, TIME_communicationDateTimeCOMM, s);
    }

    /**
     * Click Service Seq #1
     */
    public void clickServiceSeqNum1() {
        log.warn("clickServiceSeqNum1");
        TestUtils.click(webDriver, serviceSeqNum1);
    }

    /**
     * Select Communication Channel Source Type
     *
     * @param s
     */
    public void selectChannelSourceTypeCOMM(String s) {
        log.warn("selectChannelSourceTypeCOMM: " + s);
        TestUtils.select(webDriver, channelSourceTypeCOMM, s);
    }

    /**
     * Select Communication Type
     *
     * @param s
     */
    public void selectCommunicationTypeCOMM(String s) {
        log.warn("selectCommunicationTypeCOMM: " + s);
        TestUtils.select(webDriver, communicationTypeCOMM, s);
    }

    /**
     * Select Communication Contact Role Type
     *
     * @param s
     */
    public void selectContactRoleTypeCOMM(String s) {
        log.warn("selectContactRoleTypeCOMM: " + s);
        TestUtils.select(webDriver, contactRoleTypeCOMM, s);
    }
}
