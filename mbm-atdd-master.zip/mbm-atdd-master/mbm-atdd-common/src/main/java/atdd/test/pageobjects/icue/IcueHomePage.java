package atdd.test.pageobjects.icue;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class IcueHomePage {

    private static final Logger log = Logger.getLogger(IcueHomePage.class.getName());
    private WebDriver driver;

    //Locators---------------
    public static final By mainNav = By.id("mainNav");
    //Locators--------------

    public IcueHomePage(WebDriver driver) {
        this.driver = driver;
    }
}
