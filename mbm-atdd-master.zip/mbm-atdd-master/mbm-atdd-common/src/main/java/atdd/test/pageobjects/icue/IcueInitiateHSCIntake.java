package atdd.test.pageobjects.icue;


import atdd.utils.DateUtils;
import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class IcueInitiateHSCIntake extends Icue {

    public static final Logger log = Logger.getLogger(IcueInitiateHSCIntake.class.getName());

    private final WebDriver webDriver;


    /**
     * ICUE HSC Intake Page Object
     *
     * @param webDriver
     */
    public IcueInitiateHSCIntake(WebDriver webDriver) {
        super(webDriver);
        this.webDriver = webDriver;
    }
    private String owner;


    //Locators---------------
    public static final By source = By.id("channelSourceType");
    public static final By communicDate = By.id("communicationDateTime");
    public static final By serviceSetting = By.id("serviceSettingType");
    public static final By serviceStartDate = By.id("serviceStartDateOP");
    public static final By memberId = By.id("memberIDText");
    public static final By searchBtn = By.xpath("//span[@id='searchicon']/input");
    public static final By searchResults = By.xpath("//table[@class='sectionContent']//span[text()='Member Search Results']");
    public static final By action = By.xpath("//select[@id='action']");
    public static final By performAction = By.xpath("//input[@id='performAction']");
    //Locators--------------


    /**
     * Select Source dropdown value
     * @param sourceOption
     * @return
     */
    public void selectSource(String sourceOption) {
        log.warn("Select Source " + source + " on the Initiate HSC Intake Page");
        TestUtils.select(webDriver, source, sourceOption);
    }

    /**
     * Select Communication start date
     * @return
     */
    public void selectCommunicationDate() {
        log.warn("Select Communication date as today on the Initiate HSC Intake Page");
        String d = DateUtils.todayWithoutFormat();
        TestUtils.input(webDriver, communicDate, d);
    }

    /**
     * Selecting Service Setting dropdown
     * @return
     */
    public void selectServiceSetting(String setting) {
        log.warn("Select Service Setting Outpatient on the Initiate HSC Intake Page");
        TestUtils.select(webDriver, serviceSetting, setting);
    }

    /**
     * Select Service start date
     * @return
     */
    public void selectServiceStartDate() {
        log.warn("Select Service Start date as today on the Initiate HSC Intake Page");
        String d = DateUtils.todayWithoutFormat();
        TestUtils.input(webDriver, serviceStartDate, d);
    }



    /**
     * Enter txt in txt field, click search and wait for results.
     */
    public void searchByMemberId(String subscriberId) {
        log.warn("Searching for member ID on the Initiate HSC Intake Page");
        TestUtils.input(webDriver, memberId, subscriberId);
        TestUtils.click(webDriver, searchBtn);
        TestUtils.wait(2);
        TestUtils.click(webDriver, By.xpath("//*[@id='ext-gen11']//a[.='1']"));
    }

}