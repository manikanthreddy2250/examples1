package atdd.test.pageobjects.icue;


import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class IcueIntakeLongForm extends Icue {

    public static final Logger log = Logger.getLogger(IcueIntakeLongForm.class.getName());

    private final WebDriver webDriver;


    /**
     * ICUE HSC Intake Page Object
     *
     * @param webDriver
     */
    public IcueIntakeLongForm(WebDriver webDriver) {
        super(webDriver);
        this.webDriver = webDriver;
    }
    private String owner;


    //Locators---------------
    public static final By vendorCaseId = By.id("vendorCaseID");
    public static final By primaryDiagnosisCode = By.id("diagnosisCodeDX0");
    public static final By procedureType = By.id("procCodeType");
    public static final By procedureCode= By.id("procedureCode");
    public static final By total = By.id("procedureUnitCount");
    public static final By count = By.id("unitPerFrequencyCount");
    public static final By frequency= By.id("procedureFrequencyType");


    //Locators--------------

    /**
     * Assumption: User is on the Notification Information Page
     * User sets vendor case ID
     * @param vendorCaseID
     */
    public void setVendorCaseId(String vendorCaseID) {
        log.warn("Set vendorCaseID "+vendorCaseID+"on the Notification Information Page");
        TestUtils.input(webDriver, vendorCaseId, vendorCaseID);
    }

    /**
     * Assumption: User is on the Diagnosis Page
     * User sets Primary Diagnosis
     * @param diagnosis
     */
    public void setPrimaryDiagnosis(String diagnosis) {
        log.warn("Set primary diagnosis "+diagnosis+" on the Diagnosis Page");
        TestUtils.input(webDriver, primaryDiagnosisCode, diagnosis);
    }

    /**
     * Assumption: User is on the Services Page
     * User sets Procedure Type
     * @param procedureTypeText
     * @param procedureCodeText
     */
    public void setProcedureTypeCode(String procedureTypeText, String procedureCodeText) {
        log.warn("Set procedure Type "+procedureTypeText+"and "+procedureCodeText+" on the Diagnosis Page");
        TestUtils.select(webDriver, procedureType, procedureTypeText);
        TestUtils.input(webDriver, procedureCode, procedureCodeText);
    }


    /**
     * Assumption: User is on the Services Page
     * User sets Procedure Total
     * @param procedureTotal
     */
    public void setProcedureTotal(String procedureTotal) {
        log.warn("Set procedure Type "+procedureTotal+" on the Diagnosis Page");
        TestUtils.input(webDriver, total, procedureTotal);
    }

    /**
     * Assumption: User is on the Services Page
     * User sets Procedure Count
     * @param procedureCount
     */
    public void setProcedureCount(String procedureCount) {
        log.warn("Set procedure Type "+procedureCount+" on the Diagnosis Page");
        TestUtils.input(webDriver, count, procedureCount);
    }

    /**
     * Assumption: User is on the Diagnosis PAge
     * User sets Procedure Frequency
     * @param procedureFrequency
     */
    public void setProcedureFrequency(String procedureFrequency) {
        log.warn("Set procedure Type "+procedureFrequency+" on the Diagnosis Page");
        TestUtils.select(webDriver, frequency, procedureFrequency);
    }




}