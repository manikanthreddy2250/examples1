package atdd.test.pageobjects.icue;


import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class IcueIntakeShortForm extends Icue {

    public static final Logger log = Logger.getLogger(IcueIntakeShortForm.class.getName());

    private final WebDriver webDriver;


    /**
     * ICUE HSC Intake Page Object
     *
     * @param webDriver
     */
    public IcueIntakeShortForm(WebDriver webDriver) {
        super(webDriver);
        this.webDriver = webDriver;
    }

    private String owner;


    //Locators---------------
    public static final By placeOfService = By.id("placeOfServiceCode");
    public static final By serviceDetail = By.id("serviceDetailType");
    public static final By serviceDescription = By.id("serviceDescriptionType");
    public static final By serviceDetailType = By.id("serviceDetailType");
    public static final By subcategoryType = By.id("subcategoryType");
    public static final By tinTxtField = By.id("taxIdsearchByCriteriaType12");
    public static final By searchTinIcon = By.id("searchIcon");
    public static final By providerLastName = By.id("lastNamesearchByCriteriaType12");
    public static final By providerSearch = By.id("searchButton");
    public static final By requestingProviderInd = By.id("requestingProviderInd");
    public static final By servicingProviderInd = By.id("servicingProviderInd");
    public static final By shortFormCleanUpError = By.id("error");
    public static final By hscLetter = By.id("hscLetterOptOutCcInd1");
    public static final By networkSteerage = By.id("networkSteerageReasonType1");
    //Locators--------------

    /**
     * Select option from Place of Service drop-down
     *
     * @param option
     * @return
     */
    public void selectPlaceOfService(String option) {
        log.warn("Select Place Of Service" + option + "the Intake Short Form Page");
        TestUtils.select(webDriver, placeOfService, option);
    }

    /**
     * Assumption: User is on the Cleanup page and has to select manual letter option
     * select manual letter option
     */
    public void networkSteerageOption() {
        log.warn("Selecting network steerage option");
        TestUtils.select(webDriver, networkSteerage, "Emergency/State Mandate");
    }

    /**
     * Select Service Description
     *
     * @param option
     * @return
     */
    public void selectServiceDescription(String option) {
        log.warn("Select  " + option + " Service Description the Intake Short Form Page");
        TestUtils.select(webDriver, serviceDescription, option);
    }


    /**
     * Select Service Detail option
     *
     * @param option
     * @return
     */
    public void selectServiceDetail(String option) {
        log.warn("Select  " + option + " Service Detail the Intake Short Form Page");
        TestUtils.select(webDriver, serviceDetailType, option);
    }

    /**
     * Select Service Detail option
     *
     * @param option
     * @return
     */
    public void selectSubcategory(String option) {
        log.warn("Select  " + option + " Subcategory the Intake Short Form Page");
        TestUtils.select(webDriver, subcategoryType, option);
    }


    /**
     * Enter TIN
     *
     * @param tin
     * @return
     */
    public void enterTaxIdNum(String tin) {
        log.warn("Entering TIN " + tin + " on the Initiate HSC Intake Page");
        TestUtils.input(webDriver, tinTxtField, tin);
    }

    /**
     * Clicking on providerIndicator (requesting and servicing provider)
     *
     * @return
     */
    public void providerIndicator() {
        log.warn("Click search Tin icon");
        TestUtils.click(webDriver, requestingProviderInd);
        TestUtils.click(webDriver, servicingProviderInd);
    }

    /**
     * Assumption: Provider Tin as been inputed into TIN field
     * Search and select TIN provider from provider window using TIN and last name
     *
     * @param lastName
     * @return
     */
    public void searchTin(String lastName) {
        log.warn("Click search Tin icon");
        TestUtils.click(webDriver, searchTinIcon);
        TestUtils.switchToNewWindow(webDriver);
        TestUtils.input(webDriver, providerLastName, lastName);
        TestUtils.click(webDriver, providerSearch);
        TestUtils.click(webDriver, By.xpath("//*[@id='ext-gen11']//a[.='1']"));
        TestUtils.wait(6);
        TestUtils.switchToNewWindow(webDriver);
    }

    /**
     * Assumption: User is on the Cleanup page and has to select manual letter option
     * select manual letter option
     */
    public void manualLetterOption() {
        log.warn("Selecting Option to send manual letter");
        TestUtils.click(webDriver, hscLetter);
    }

}