package atdd.test.pageobjects.icue;

import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class IcueLoginPage {

    private static final Logger log = Logger.getLogger(IcueLoginPage.class.getName());
    private WebDriver driver;

    //Locators---------------
    public static By userId = By.xpath("//input[@id='userID']");
    public static By pass = By.xpath("//input[@id='password']");
    public static By signOn = By.xpath("//input[@type='SUBMIT']");
    public static By domainSelect = By.xpath("//select[@id='loginDomain']");
    //Locators--------------


    public IcueLoginPage(WebDriver driver) {
        this.driver = driver;
    }

    /**
     * Enter text in to User ID field
     *
     * @param userIdtxt
     * @return
     */
    public IcueLoginPage enterUserId(String userIdtxt) {
        log.warn("Enter text in to the User ID field: " + userIdtxt);
        TestUtils.input(this.driver, userId, userIdtxt);
        return this;
    }

    /**
     * Enter text in to User Pass field
     *
     * @param userPass
     * @return
     */
    public IcueLoginPage enterUserPass(String userPass) {
        log.warn("Enter text in to the Password field");
        TestUtils.input(this.driver, pass, userPass, true);
        return this;
    }


    /**
     * Select Domain from drop-down
     *
     * @param domainOption
     * @return
     */
    public IcueLoginPage selectDomain(String domainOption) {
        log.warn("Select Domain: " + domainOption);
        TestUtils.select(this.driver, domainSelect, domainOption);
        return this;
    }

    /**
     * click on Sign On button
     *
     * @return
     */
    public IcueLoginPage clickSignOn() {
        log.warn("Click Sighn in");
        TestUtils.click(driver, signOn);
        return this;
    }

}