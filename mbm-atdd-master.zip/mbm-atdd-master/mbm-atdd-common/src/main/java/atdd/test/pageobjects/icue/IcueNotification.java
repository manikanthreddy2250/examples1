package atdd.test.pageobjects.icue;

import atdd.utils.MBM;
import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.LinkedHashMap;
import java.util.Map;

public class IcueNotification extends Icue {
    public static final Logger log = Logger.getLogger(IcueNotification.class.getName());

    public static final By hscStatusReasonType = By.id("hscStatusReasonType");
    public static final By serviceRefNum= By.xpath("//*[@id='serviceRefNumDivSide']/table[1]/tbody/tr[1]/td");

    private final WebDriver webDriver;

    /**
     * ICUE Notification Page Object
     *
     * @param webDriver
     */
    public IcueNotification(WebDriver webDriver) {
        super(webDriver);
        this.webDriver = webDriver;
    }

    /**
     * Select Hsc Status Reason Type
     *
     * @param s
     */
    public void selectHscStatusReasonType(String s) {
        log.warn("selectHscStatusReasonType: " + s);
        TestUtils.select(webDriver, hscStatusReasonType, s);
    }

    /**
     * Select Hsc Status Reason Type
     *
     */
    public Map<String, String> storeIcueSRN() {
        log.warn("store Icue SRN");
        String authNumICUE = TestUtils.text(webDriver, serviceRefNum);

        Map<String, String> result = new LinkedHashMap<>();
        result.put(MBM.ICUE_EVICORE_SRN,authNumICUE);

        return result;
    }
}
