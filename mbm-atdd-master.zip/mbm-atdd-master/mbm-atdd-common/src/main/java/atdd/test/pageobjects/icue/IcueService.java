package atdd.test.pageobjects.icue;

import atdd.utils.MBM;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class IcueService extends Icue {
    public static final Logger log = Logger.getLogger(IcueService.class.getName());

    public static final By serviceStartDate= By.id("serviceStartDate");
    public static final By serviceEndDate= By.id("serviceEndDate");

    private final WebDriver webDriver;

    /**
     * ICUE Notification Page Object
     *
     * @param webDriver
     */
    public IcueService(WebDriver webDriver) {
        super(webDriver);
        this.webDriver = webDriver;
    }


    /**
     * Check data from HSC Assignments table. By column header name.
     *
     * @param columnName
     * @return
     */
    public String checkServiceSummaryColumnElements(String columnName) {
        log.warn("Checking values in the " + columnName + " column");
        By clolumnName = By.xpath("//div[@id='serviceLineProcedure']//tr/th");
        List<WebElement> column = webDriver.findElements(clolumnName);
        String tmp = "none";
        boolean res = false;
        int colNum = 0;

        //Getting position of column
        for (WebElement e : column) {
            colNum++;
            tmp = e.getText().trim();
//            utils.highlightElement(e);
            if (tmp.equals(columnName)) {
                res = true;
                break;
            }
        }

        Assert.assertTrue("Column " + columnName + " is not present.", res);

        //Getting locator by position
        By tableCell = By.xpath("//*[@id='serviceLineProcedure']//table[@class='listTable']//tbody//td[" + colNum + "]");

        //Getting text from cell
        String cellValue = webDriver.findElement(tableCell).getText();
        log.warn("Cell value is: " + cellValue);

        return cellValue;
    }

    /**
     * Assumption: User is on the service tab
     * User stores SRN, service start date, service end date
     * @return
     */
    public Map<String, String> storeIcueServiceInfo() {
        String icueServiceStartDate = checkServiceSummaryColumnElements("Service Start Date");
        String icueServiceEndDate = checkServiceSummaryColumnElements("Service End Date");
        Map<String, String> result = new LinkedHashMap<>();
        result.put(MBM.ICUE_EVICORE_SERVICE_START_DATE,icueServiceStartDate);
        result.put(MBM.ICUE_EVICORE_SERVICE_END_DATE, icueServiceEndDate);

        return result;
    }
}
