package atdd.test.pageobjects.icue;

import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class IcueServiceDecision extends Icue {
    public static final Logger log = Logger.getLogger(IcueServiceDecision.class.getName());

    public static final By decisionOutcomeType = By.id("decisionOutcomeType");
    public static final By decisionSubType = By.id("decisionSubType");
    public static final By decisionReasonType = By.id("decisionReasonType");
    public static final By decisionSourceType1SRC = By.id("decisionSourceType1SRC");
    public static final By overrideClaimRemarkCode = By.id("overrideClaimRemarkCode");
    public static final By decisionSourceComment = By.name("decisionSourceComment");

    private final WebDriver webDriver;

    /**
     * ICUE Service Decision Page Object
     *
     * @param webDriver
     */
    public IcueServiceDecision(WebDriver webDriver) {
        super(webDriver);
        this.webDriver = webDriver;
    }

    /**
     * Show Service Line on Decisions Page
     *
     * @param serviceLine
     */
    public void showDecisions(int serviceLine) {
        log.warn("showDecisions: " + serviceLine);
        new Icue(this.webDriver).clickTabOnNotificationPage("5. Decisions");
        TestUtils.click(this.webDriver, By.linkText("" + serviceLine));
    }

    /**
     * Select Decision Outcome Type
     *
     * @param s
     */
    public void selectDecisionOutcomeType(String s) {
        log.warn("selectDecisionOutcomeType: " + s);
        TestUtils.select(webDriver, decisionOutcomeType, s);
    }

    /**
     * Select Decision Sub Type
     *
     * @param s
     */
    public void selectDecisionSubType(String s) {
        log.warn("selectDecisionSubType: " + s);
        TestUtils.select(webDriver, decisionSubType, s);
    }

    /**
     * Select Decision Reason Type
     *
     * @param s
     */
    public void selectDecisionReasonType(String s) {
        log.warn("selectDecisionReasonType: " + s);
        TestUtils.select(webDriver, decisionReasonType, s);
    }

    /**
     * Select Decision Source Type
     *
     * @param s
     */
    public void selectDecisionSourceType1SRC(String s) {
        log.warn("selectDecisionSourceType1SRC: " + s);
        TestUtils.select(webDriver, decisionSourceType1SRC, s);
    }

    /**
     * Select Override Claim Remark Code
     *
     * @param s
     */
    public void selectOverrideClaimRemarkCode(String s) {
        log.warn("selectOverrideClaimRemarkCode: " + s);
        TestUtils.select(webDriver, overrideClaimRemarkCode, s);
    }

    /**
     * Input Decision Source Comment
     *
     * @param s
     */
    public void inputDecisionSourceComment(String s) {
        log.warn("inputDecisionSourceComment: " + s);
        TestUtils.input(webDriver, By.name("decisionSourceComment"), s);
    }
    /**
     * Input claims commnets
     *
     * @param s
     */
    public void inputClaimComments(String s) {
        log.warn("inputClaimComments: " + s);
        TestUtils.input(webDriver, By.name("newClaimComments"), s);
    }
}
