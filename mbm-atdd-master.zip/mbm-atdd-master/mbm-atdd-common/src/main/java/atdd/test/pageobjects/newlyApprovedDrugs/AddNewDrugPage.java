package atdd.test.pageobjects.newlyApprovedDrugs;

import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.List;
import java.util.Map;

public class AddNewDrugPage {

    private static Logger log = Logger.getLogger(AddNewDrugPage.class);
    private WebDriver driver;
    private TestUtils testUtils = new TestUtils();


    public static By brandname = By.id("record-procedureName-0");
    public static By route = By.xpath("//select[@id ='record-medicationAdminRouteType-0']");
    public static By authType = By.xpath("//select[@id ='record-authorizationType-hscAttributeValue-0']");
    public static By payer = By.xpath("//select[@id ='record-customTreatmentApprovalType-0']");
    public static By fadate = By.xpath("//input[@id = 'record-approveDate-0']");
    public static By saveButton = By.xpath("//input[@class = 'open ng-scope tk-btn']");
    public static By nameErrorMessage = By.xpath("//select[@id ='record-authorizationType-hscAttributeValue-0']/following-sibling::*");
    public static By descriptionErrorMessage = By.xpath("//label[contains(text(),'Payer')]/../following-sibling::td//div");
    public static By popUpHeader = By.xpath("//h2[contains(text(), 'Add New Drug')]");
    public static By cancelButton = By.xpath("//input[@class='close tk-btn-tertiary tk-btn']");


    public AddNewDrugPage(WebDriver driver) {
        this.driver = driver;
    }


    /*
     * This method adds New Drug
     * @param brandName, drugRoute, authType, payer
     * */
    public void enterDetailsToAddNewDrug(List<Map<String, String>> maps) {
        Map<String, String> map = null;
        for (Map<String, String> m : maps) {
            map = m;
            TestUtils.input(driver, brandname, map.get("Brand Name"));
            TestUtils.select(driver, route, map.get("Drug Route"));
            TestUtils.select(driver, authType, map.get("Authorization Type"));
            TestUtils.select(driver, payer, map.get("Payer"));
            TestUtils.input(driver, fadate, map.get("Approve Date"));
            TestUtils.click(driver, saveButton);
        }
    }

    /*
     * This method to click save Button on Add New Drugs Pop-up
     *
     * */
    public void clickSaveButton() {
        log.warn("Click save on Newly Approved Drugs Screen");
        TestUtils.click(driver, saveButton);
    }

    /*
    This method is to enter BrandName on Add New Drugs Pop-Up
     */
    public void enterTheBrandNameonAddNewDrugPopUp(String BrandName) {
        log.warn("Enter brand Name on the Add New Drug Pop-up modal");
        TestUtils.input(driver, brandname, BrandName);

    }

    /*
    This method is to Select Drug Route on Add New Drugs Pop-Up
     */
    public void enterDrugRouteOnAddNewDrugPopUp(String drugroute) {
        log.warn("Enter the Drug Route on the Add New Drug Pop-up modal");
        TestUtils.select(driver, route, drugroute);
    }

    /*
    This method is to Select Authorization Type on Add New Drugs Pop-Up
     */
    public void selectAuthTypeOnAddNewDrugPopUp(String authType) {
        log.warn("select the Auth Type on the Add New Drug Pop-up modal");
        TestUtils.select(driver, AddNewDrugPage.authType, authType);
    }

    /*
    This method is to Select Payer on Add New Drugs Pop-Up
     */
    public void selectpayerOnAddNewDrugPopUp(String payer) {
        log.warn("select the payer on the Add New Drug Pop-up modal");
        TestUtils.select(driver, AddNewDrugPage.payer, payer);
    }

    /*
        This method is to Enter FDA Approval Date on Add New Drugs Pop-Up
         */
    public void selectFDAapprovalDateOnAddNewDrugPopUp(String Approvedate) {
        log.warn("Enter the FDA Approval date on Add New Drug Pop-up Modal");
        TestUtils.input(driver, fadate, Approvedate);
    }

    /*
    This method is to verify the position of Authorization Type and Payer on Add New Drugs pop-up
     */
    public void verifyFieldLocation(List<String> label) {
        String auth = label.get(0);
        String payer = label.get(1);
        int authlocY = driver.findElement(By.xpath("//label[contains(text(), '" + auth + "')]")).getLocation().getY();

        int payerlocY = driver.findElement(By.xpath("//label[contains(text(), '" + payer + "')]")).getLocation().getY();

        Assert.assertTrue("Payer is not below Auth dropdown in New Add Drug Pop", authlocY < payerlocY);

    }

    /*
    This method is to verify error message is displayed appropriately
     */
    public void validateErrorMessage(String errorMessage) {
        Assert.assertEquals(errorMessage, driver.findElement(nameErrorMessage).getText());
        Assert.assertEquals(errorMessage, driver.findElement(descriptionErrorMessage).getText());
    }

    /*
     * Close the Add New Drug Pop-Up
     * */
    public void closeAddNewDrugModal() {
        //check if Add New Drug is visible

        if (TestUtils.isElementVisible(driver, popUpHeader)) {
            //close New Drug
            TestUtils.click(driver, cancelButton);
        }

    }


}
