package atdd.test.pageobjects.newlyApprovedDrugs;


import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.util.ArrayList;
import java.util.List;


public class NewlyApprovedDrugsPage {

    public static By authType = By.xpath("//select[@id ='drugTable-tableFilters-authorizationType-0']");
    public static By payer = By.xpath("//select[@id ='drugTable-tableFilters-customTreatmentApprovalType-0']");
    public static By addNewDrug = By.xpath("//a[contains(text(),'Add New Drug')]");
    public static By brandName = By.xpath("//input[@id = 'drugTable-tableFilters-procedureName-0']");
    public static By drugRoute = By.xpath("//select[@id='drugTable-tableFilters-medicationAdminRouteType-0']");
    public static By searchButton = By.cssSelector("input[ng-click*='drugTable.applyTableFiltersOnClick(drugTableFormtableFilters)'][value='Search']");

    private WebDriver driver;
    private static Logger log = Logger.getLogger(NewlyApprovedDrugsPage.class);

    public NewlyApprovedDrugsPage(WebDriver driver) {
        this.driver = driver;
    }

    /*
    Validate the order of Columns in the table
     */
    public void validateTableHeader(List<String> expectedHeader) {
        List<WebElement> headerElements = driver.findElements(By.xpath("//table[@id='drugTableID']/thead/tr/td"));
        for (int i = 0; i < expectedHeader.size(); i++) {
            Boolean value = headerElements.get(i).getText().contains(expectedHeader.get(i));
            Assert.assertTrue("expected and actual doesn't match at index " + i, value);
        }
    }

    /*
    Verify the label names on result Grid
     */

    public void validateLabelValues(List<String> labelValues) {
        for (int i = 0; i < labelValues.size(); i++) {
            String labelName = driver.findElement(By.xpath("//td[contains(text(), '" + labelValues.get(i) + "')]")).getText().trim();
            Boolean value = labelName.equalsIgnoreCase(labelValues.get(i));
            Assert.assertTrue("Search Field Label values is not correct", value);

        }

    }

    /*
    Verify the default selected value for Auth Type
     */
    public void validateDefaultValuesForAuthType() {
        Select sel = new Select(driver.findElement(authType));
        String Selected = sel.getFirstSelectedOption().getText();
        Assert.assertEquals("Select", Selected);

    }

     /*
       Verify the default selected value for Payer
        */

    public void validateDefaultValuesForPayer() {
        Select sel = new Select(driver.findElement(payer));
        String Selected = sel.getFirstSelectedOption().getText();
        Assert.assertEquals("Select", Selected);

    }

    /*
       Verify the all Dropdown Options for the Authorization Type and payer
       in the Search Field Dropdown
        */
    public void validateDrpdwnOptnsInNewlyApprovedDrugScreen(String arg1, List<String> labelValues) {

        switch (arg1) {
            case "Authorization Type":

                Select authvalues = new Select(driver.findElement(authType));
                List<WebElement> Selected = authvalues.getOptions();
                for (int i = 0; i < labelValues.size(); i++) {
                    Assert.assertTrue("Dropdown value is missing " + labelValues.get(i), Selected.get(i).getText().contains(labelValues.get(i)));
                }
                break;

            case "Payer":
                Select payerValues = new Select(driver.findElement(payer));
                List<WebElement> payer = payerValues.getOptions();
                for (int i = 0; i < labelValues.size(); i++) {
                    Assert.assertTrue("Dropdown value is missing " + labelValues.get(i), payer.get(i).getText().contains(labelValues.get(i)));
                }
                break;
            default:

                Assert.fail("Dropdown field not present: " + arg1);
        }
    }

    /*This method clicks on +Add New Drug*/
    public void clickOnAddNewDrug() {
        log.warn("Clicking on add New Drug");
        TestUtils.click(driver, addNewDrug);

    }

    /*
     This method is to enter the BrandName in newly Approved Screen Search Criteria
     */
    public void enterBrandNameOnNewlyApprovedDrugSearchCriteria(String BrandName) {
        log.warn("Enter the Brand Name in Search Criteria of Newly Approved Drug Screen");
        TestUtils.input(driver, brandName, BrandName);

    }

    /*
    This method is to select Drug Route in newly Approved Drugs Screen, Search Criteria section
    */
    public void enterDrugRouteOnNewlyApprovedDrugSearchCriteria(String drugroute) {
        log.warn("Enter the Drug Route in Search Criteria of Newly Approved Drug Screen");
        TestUtils.select(driver, drugRoute, drugroute);
    }

    /*
    This method is to select Authorization Type in newly Approved Drugs Screen, Search Criteria section
    */
    public void selectAuthTypeOnNewlyApprovedDrugSearchCriteria(String authType) {
        log.warn("select the Auth Type in Search Criteria of Newly Approved Drug Screen");
        TestUtils.select(driver, NewlyApprovedDrugsPage.authType, authType);
    }

    /*
    This method is to select Payer in newly Approved Drugs Screen, Search Criteria section
    */
    public void selectpayerOnNewlyApprovedDrugSearchCriteria(String payer) {
        log.warn("select the payer in Search Criteria of Newly Approved Drug Screen");
        TestUtils.select(driver, NewlyApprovedDrugsPage.payer, payer);
    }

    /*
    This method is to get the search result
    based on Search Criteria and store it in list
     */
    public List getValuesinTable() {

        List<WebElement> tableRows = driver.findElements(By.xpath("//table[@id = 'drugTableID']/tbody/tr"));
        int numberOfRows = tableRows.size();
        List<String> expectedValue = new ArrayList<>();

        for (int i = 1; i <= numberOfRows; i++) {
            System.out.println("//table[@id = 'drugTableID']/tbody/tr[" + i + "]/td");
            List<WebElement> tableColumn = driver.findElements(By.xpath("//table[@id = 'drugTableID']/tbody/tr[" + i + "]/td"));


            int numberOfColumns = tableColumn.size();

            for (int j = i + 1; j <= numberOfColumns; j++) {
                System.out.println(tableColumn.get(i + 1).getText());
                System.out.println("//table[@id='drugTableID']/tbody/tr[" + i + "]/td[" + j + "]");
                String columnvalues = driver.findElement(By.xpath("//table[@id='drugTableID']/tbody/tr[" + i + "]/td[" + j + "]")).getText();

                expectedValue.add(columnvalues);

            }
        }

        return expectedValue;
    }

    /**
     * Clicking search Button on Traversal Maintenance Page
     */
    public void clickSearchButton() {
        log.warn("Click Search on Newly Approved Drugs Screen");
        TestUtils.click(driver, searchButton);

    }


    public boolean hasResult() {
        TestUtils.wait(2);
        List<WebElement> els = driver.findElements(By.xpath("//table[@id='drugTableID']//tr"));
        return els.size() != 2 || !els.get(1).getText().equals("No records to display.");
    }

    /**
     * Remove FirstResut from NewlyApprovedDrugTable
     */
    public void removeFirstResut() {
        driver.findElements(By.xpath("//table[@id='drugTableID']//span[@title='Delete Record']")).get(0).click();
        driver.findElement(By.xpath("//form[@name='deleteConfirmPopupForm']//input[@value='Yes']")).click();
        TestUtils.wait(1);
    }

    /*
    This method is to verify no Records founds in search Result Grid
     */
    public void NoRecordsFound() {
        List<WebElement> els = driver.findElements(By.xpath("//table[@id='drugTableID']//tr"));
        System.out.println(els.size());
        Assert.assertTrue("Record Save though mandatory field not selected", els.size() == 2 && els.get(1).getText().equals("No records to display."));
    }

}
