package atdd.test.pageobjects.paan;


import atdd.utils.TestUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class PAAN {

    private WebDriver driver;
    private TestUtils utils;
    //Locators---------------
    public static By signInOptumId = By.xpath("//a[contains(@ng-click, 'onLoginClick')]");
    public static By inputOptumIdEmail = By.xpath("//input[@id='userNameId_input']");
    public static By pass = By.xpath("//input[@id='passwdId_input']");
    public static By sighInBtn = By.xpath("//input[@id='SignIn']");
    public static By securityQuestionTxt = By.xpath("//label[@id='challengeQuestionLabelId']");
    public static By securityAnswerInput = By.xpath("//input[@class='challengeSecurityUserAnswerInput']");
    public static By securityNextBtn = By.xpath("//input[@id='authQuesSubmitButton']");
    public static By continueBtnChooseCareProvider = By.xpath("//input[@id='continueButton']");
    public static By newInquiry = By.xpath("//div[@id='newInquiry']//a");
    public static By submissionAndStatus = By.id("submisionAndStaus");
    public static By submissionAndStatusContinuePopUpBtn = By.xpath("//div[@class='ui-dialog-buttonset']/button[text()='Continue']");
    public static By linkChoice = By.xpath("//a[contains(@href,'dashboards/provider-dashboard')]//span");
    public static By menuCollapsed = By.xpath("//a[@title='Menu']");
    public static By selectServiceDropDown = By.xpath("//select[@id='chemoServiceType']");
    public static By selectProductType = By.xpath("//select[@id='memberProductType']");
    public static By selectMemberState = By.xpath("//select[@id='state']");
    public static By continueBtnSelectWin = By.xpath("//input[@id='continueRedirect']");
    public static By cancelBtnSelectWin = By.xpath("//input[@id='cancelRedirect']");
    public static By continueDisabled = By.xpath("//input[@id='continueRedirect' and @disabled = 'disabled']");
    public static By continueEnabled = By.xpath("//input[@id='continueRedirect' and NOT(@disabled = 'disabled')]");
    public static By corporateTaxIDOwnerDropDown = By.xpath("//select[@id='name']");
    public static By careProviderDropDown = By.xpath("//select[@id='provider']");
    public static By selectDiffProviderBtn = By.xpath("//input[@id='selectdiffproviders']");
    public static By taxIdNumberDropDown = By.xpath("//select[@id='tin']");
    //Locators--------------


}
