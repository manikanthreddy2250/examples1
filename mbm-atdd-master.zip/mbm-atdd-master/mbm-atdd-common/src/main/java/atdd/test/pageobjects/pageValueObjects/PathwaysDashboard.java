package atdd.test.pageobjects.pageValueObjects;

public class PathwaysDashboard {
    private PathwaysDashboardWidget pathwaysDashboard;

    public PathwaysDashboardWidget getPathwaysDashboard() {
        return pathwaysDashboard;
    }

    public void setPathwaysDashboard(PathwaysDashboardWidget pathwaysDashboardWidget) {
        this.pathwaysDashboard = pathwaysDashboardWidget;
    }

}
