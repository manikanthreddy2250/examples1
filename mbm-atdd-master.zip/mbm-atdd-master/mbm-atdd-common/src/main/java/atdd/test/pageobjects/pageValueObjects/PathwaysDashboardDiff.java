package atdd.test.pageobjects.pageValueObjects;

import atdd.utils.QuickJson;
import atdd.utils.StringUtils;
import org.junit.Assert;

import java.util.Map;

public class PathwaysDashboardDiff extends PathwaysDashboard {


    private PathwaysDashboardDiff(PathwaysDashboard pvo) {
        this.setPathwaysDashboard(pvo.getPathwaysDashboard());

    }

    public static PathwaysDashboardDiff diff(PathwaysDashboard a, PathwaysDashboard b) {
        PathwaysDashboard aClone = (PathwaysDashboard) QuickJson.clone(a);
        diffWidget(aClone.getPathwaysDashboard(), b.getPathwaysDashboard());
        return new PathwaysDashboardDiff(aClone);
    }

    private static void diffWidget(PathwaysDashboardWidget a, PathwaysDashboardWidget b) {
        a.setPathwayShown(calcDiff(a.getPathwayShown(), b.getPathwayShown()));
        a.setCancerTypes(calcDiff(a.getPathwaySelected(), b.getCancerTypes()));
        a.setNumberOfCancerTypes(calcDiff(a.getNumberOfCancerTypes(), b.getNumberOfCancerTypes()));
        a.setPathwaySelected(calcDiff(a.getPathwaySelected(), b.getPathwaySelected()));
        a.setPathwayPercentage(calcDiff(a.getPathwayPercentage(), b.getPathwayPercentage()));
        a.setSpecificCancer(calcDiff(a.getSpecificCancer(), b.getSpecificCancer()));
    }

    private static Integer calcDiff(Integer a, Integer b) {
        a = null == a ? 0 : a;
        b = null == b ? 0 : b;
        return a - b;
    }

    public static PathwaysDashboardDiff pathwayPerforamncediff(PathwaysDashboard a, PathwaysDashboard b, String lob) {
        PathwaysDashboard aClone = (PathwaysDashboard) QuickJson.clone(a);
        diffPerformanceWidget(aClone.getPathwaysDashboard(), b.getPathwaysDashboard(), lob);
        return new PathwaysDashboardDiff(aClone);
    }

    private static void diffPerformanceWidget(PathwaysDashboardWidget a, PathwaysDashboardWidget b, String lob) {
        int expectedPathWayShown = 0;
        int expectedPathWaySelected = 0;
        int expectedPathWayPerformancePercentage = 0;
        int actualPathWayShown = 0;
        int actualPathWaySelected = 0;
        int actualPathWayPerformancePercentage = 0;
        int expectedPathWayPerformanceAllProvidersPercentage = 0;
        int actualPathWayPerformanceAllProvidersPercentage = 0;
        for (Map<String, String> m : a.getPathwayPerformance()) {
            if (m.get("Line Of Business").equals(lob)) {
                actualPathWayShown = Integer.parseInt(m.get("Pathways Shown") == null ? "0" : m.get("Pathways Shown"));
                actualPathWaySelected = Integer.parseInt(m.get("Pathways Selected")== null ? "0" : m.get("Pathways Selected"));
                String percentage = m.get("% TIN Adherence") == null ? "0" : m.get("% TIN Adherence");
                actualPathWayPerformancePercentage = StringUtils.tryParseIntOrNull(percentage.replace("%", ""));
                percentage = m.get("% All Providers Adherence") == null ? "0" : m.get("% All Providers Adherence");
                actualPathWayPerformanceAllProvidersPercentage = StringUtils.tryParseIntOrNull(percentage.replace("%", ""));
                if(m.get("Rewards Eligibility") != null){
                    verifyRewardsEligibleStatus(lob, m.get("Rewards Eligibility"));
                }
                break;
            }

        }
        for (Map<String, String> m : b.getPathwayPerformance()) {
            if (m.get("Line Of Business").equals(lob)) {
                expectedPathWayShown = Integer.parseInt(m.get("Pathways Shown") == null ? "0" : m.get("Pathways Shown"));
                expectedPathWaySelected = Integer.parseInt(m.get("Pathways Selected")== null ? "0" : m.get("Pathways Selected"));
                String percentage = m.get("% All Providers Adherence") == null ? "0" : m.get("% All Providers Adherence");
                expectedPathWayPerformanceAllProvidersPercentage = StringUtils.tryParseIntOrNull(percentage.replace("%", ""));
                break;
            }

        }
        expectedPathWayPerformancePercentage = actualPathWayShown > 0 ? (actualPathWaySelected * 100) / actualPathWayShown : 0 ;
        a.setPathwayShown(calcDiff(actualPathWayShown, expectedPathWayShown));
        a.setPathwaySelected(calcDiff(actualPathWaySelected, expectedPathWaySelected));
        a.setPathwayPercentage(calcDiff(actualPathWayPerformancePercentage, expectedPathWayPerformancePercentage));
        a.setPathWayPerformanceAllProvidersPercentage(calcDiff(actualPathWayPerformanceAllProvidersPercentage,
                expectedPathWayPerformanceAllProvidersPercentage));
    }

    private static void verifyRewardsEligibleStatus(String lob, String rewards_eligible) {
        switch (lob) {
            case "Commercial":
                Assert.assertTrue(rewards_eligible.equalsIgnoreCase("Yes"));
                break;
            case "Medicaid":
                Assert.assertTrue(rewards_eligible.equalsIgnoreCase("No"));
                break;
            case "Medicare":
                Assert.assertTrue(rewards_eligible.equalsIgnoreCase("No"));
                break;
            case "Both Medicare and Medicaid":
                Assert.assertTrue(rewards_eligible.equalsIgnoreCase("No"));
                break;
        }
    }
}
