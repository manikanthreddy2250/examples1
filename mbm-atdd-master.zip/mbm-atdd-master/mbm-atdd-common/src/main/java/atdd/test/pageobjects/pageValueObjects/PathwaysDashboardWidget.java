package atdd.test.pageobjects.pageValueObjects;


import java.util.List;
import java.util.Map;

public class PathwaysDashboardWidget {
    private String widget;
    private int pathwayShown;
    private int pathwaySelected;
    private int pathwayPercentage;
    private int pathWayPerformanceAllProvidersPercentage;
    private int cancerTypes;
    private int numberOfCancerTypes;
    private int specificCancer;
    private List<Map<String, String>> pathwayPerformance;

    public String getWidget() {
        return widget;
    }

    public void setWidget(String widget) {
        this.widget = widget;
    }

    public int getPathwayShown() {
        return pathwayShown;
    }

    public void setPathwayShown(int pathwayShown) {
        this.pathwayShown = pathwayShown;
    }

    public int getPathwaySelected() {
        return pathwaySelected;
    }

    public void setPathwaySelected(int pathwaySelected) {
        this.pathwaySelected = pathwaySelected;
    }
    public int getPathwayPercentage() {
        return pathwayPercentage;
    }

    public void setPathwayPercentage(int pathwayPercentage) {
        this.pathwayPercentage = pathwayPercentage;
    }

    public int getPathWayPerformanceAllProvidersPercentage() {
        return pathWayPerformanceAllProvidersPercentage;
    }

    public void setPathWayPerformanceAllProvidersPercentage(int pathWayPerformanceAllProvidersPercentage) {
        this.pathWayPerformanceAllProvidersPercentage = pathWayPerformanceAllProvidersPercentage;
    }

    public int getCancerTypes() {
        return cancerTypes;
    }

    public void setCancerTypes(int cancerTypes) {
        this.cancerTypes = cancerTypes;
    }

    public int getNumberOfCancerTypes() {
        return numberOfCancerTypes;
    }

    public void setNumberOfCancerTypes(int numberOfCancerTypes) {
        this.numberOfCancerTypes = numberOfCancerTypes;
    }

    public int getSpecificCancer() {
        return specificCancer;
    }

    public void setSpecificCancer(int specificCancer) {
        this.specificCancer = specificCancer;
    }


    public List<Map<String, String>> getPathwayPerformance() {
        return pathwayPerformance;
    }

    public void setPathwayPerformance(List<Map<String, String>> pathwayPerformance) {
        this.pathwayPerformance = pathwayPerformance;
    }
}
