package atdd.test.pageobjects.pathwaysDashboard;

import atdd.common.ScenarioLogger;
import atdd.dao.mbm.HscDao;
import atdd.dao.mbm.MyBatisConnectionFactory;
import atdd.test.pageobjects.pageValueObjects.PathwaysDashboard;
import atdd.test.pageobjects.pageValueObjects.PathwaysDashboardWidget;
import atdd.utils.StringUtils;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.apache.log4j.Logger;
import org.joda.time.YearMonth;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public class PathwaysDashboardPage {


    private WebDriver driver;
    private TestUtils utils;
    private static Logger log = Logger.getLogger(PathwaysDashboardPage.class);

    private ScenarioLogger scenarioLogger;
    private Scenario scenario;


    public PathwaysDashboardPage() {
    }

    public PathwaysDashboardPage(WebDriver driver) {
        this.driver = driver;

    }

    public void setScenarioLogger(ScenarioLogger scenarioLogger) {
        this.scenarioLogger = scenarioLogger;
        this.scenario = scenarioLogger.getScenario();
    }

    //Locators
    public static By tinSearch = By.xpath("//*[@id='tinSearch']");
    public static By tinSearchIcon = By.xpath("//*[@id='tinSearchInput']");
    public static By pathWayWidget = By.id("pathwaysDashboardPanelId");
    public static By medicaidRewardsEligibleStatus= By.xpath("//*[@id='pathwaysPerformanceDetailsTableID']//tr[2]//td[1]/span[contains(text(),'Medicaid')]//..//following-sibling::td[1]/span");
    public static By reviewPathwaysResults = By.xpath("//*[@id='reviewButton']");
    public static By totalPathwaysSelected = By.xpath("//*[@id='totalPathwaysSelected']");
    public static By totalPathwaysShown = By.xpath("//*[@id='totalPathwaysShown']");
    public static By pathwayAdherence = By.xpath("//*[@class='caption']");
    //public String WidgetPathwaysPercentage = driver.findElement(pathwayAdherence).getText();



    public PathwaysDashboard collect() {
        PathwaysDashboard result = new PathwaysDashboard();

        result.setPathwaysDashboard(collect("pathwaysDashboardPanelId"));

        return result;
    }


    /**
     * collecting pathways shown , selected and total cancer types
     *
     * @param widget
     * @return
     */
    public PathwaysDashboardWidget collect(String widget) {
        PathwaysDashboardWidget pathwaysDashboardWidget = new PathwaysDashboardWidget();
        pathwaysDashboardWidget.setWidget(widget);

        TestUtils.demoBreakPoint(this.scenario, driver, widget);

        {
            TestUtils.wait(10);
            String s = TestUtils.simpleContent(driver.findElement(By.id("totalPathwaysShown")));
            Integer pathwayShown = StringUtils.tryParseIntOrNull(s);
            pathwaysDashboardWidget.setPathwayShown(pathwayShown);

            s = TestUtils.simpleContent(driver.findElement(By.id("totalPathwaysSelected")));
            Integer pathwaySelected = StringUtils.tryParseIntOrNull(s);
            pathwaysDashboardWidget.setPathwaySelected(pathwaySelected);

            s = TestUtils.simpleContent(driver.findElement(By.id("totalCancerTypes")));
            Integer numberOfCancerTypes = StringUtils.tryParseIntOrNull(s.substring(0, 1));
            pathwaysDashboardWidget.setNumberOfCancerTypes(numberOfCancerTypes);

        }


        return pathwaysDashboardWidget;
    }

    /**
     * collecting percentage
     *
     * @return
     */
    public PathwaysDashboard collectPercentage() {
        PathwaysDashboard result = new PathwaysDashboard();
        result.setPathwaysDashboard(collectPercentage("pathwaysDashboardPanelId"));
        return result;

    }

    /**
     * collecting percentage
     *
     * @return
     */
    public PathwaysDashboardWidget collectPercentage(String widget) {
        PathwaysDashboardWidget pathwaysDashboardWidget = collect(widget);
        TestUtils.demoBreakPoint(this.scenario, driver, widget);
        {
            String s = TestUtils.simpleContent(driver.findElement(By.cssSelector("text[class='caption']")));
            Integer pathwayPercentage = StringUtils.tryParseIntOrNull(s.replace("%", ""));
            pathwaysDashboardWidget.setPathwayPercentage(pathwayPercentage);
        }


        return pathwaysDashboardWidget;
    }

    public PathwaysDashboard collectCancerTypes() {
        PathwaysDashboard result = new PathwaysDashboard();
        result.setPathwaysDashboard(collectCancerTypes("pathwaysDashboardPanelId"));

        return result;

    }

    /**
     * collecnting cancer types
     *
     * @param widget
     * @return
     */
    public PathwaysDashboardWidget collectCancerTypes(String widget) {
        PathwaysDashboardWidget pathwaysDashboardWidget = new PathwaysDashboardWidget();
        pathwaysDashboardWidget.setWidget(widget);
        TestUtils.demoBreakPoint(this.scenario, driver, widget);
        {
            List<WebElement> elements = TestUtils.findElements
                    (driver, By.cssSelector("[id='pathwaysBarChart'] [class='label']"));
            int cancerTypesTotal = 0;
            for (WebElement ele : elements) {
                String text = ele.getText();
                cancerTypesTotal = cancerTypesTotal + StringUtils.tryParseIntOrNull
                        (text.substring(text.indexOf("(") + 1, text.indexOf(")")));
            }
            pathwaysDashboardWidget.setCancerTypes(cancerTypesTotal);
            pathwaysDashboardWidget.setNumberOfCancerTypes(elements.size());
        }


        return pathwaysDashboardWidget;
    }

    public PathwaysDashboard collectSpecificCancerTypes(String cancerType) {
        PathwaysDashboard result = new PathwaysDashboard();
        result.setPathwaysDashboard(collectSpecificCancerTypes(cancerType, "pathwaysDashboardPanelId"));

        return result;

    }

    /**
     * collects specific cancer types
     *
     * @param cancerType
     * @param widget
     * @return
     */
    public PathwaysDashboardWidget collectSpecificCancerTypes(String cancerType, String widget) {
        PathwaysDashboardWidget pathwaysDashboardWidget = new PathwaysDashboardWidget();
        pathwaysDashboardWidget.setWidget(widget);
        TestUtils.demoBreakPoint(this.scenario, driver, widget);
        {
            List<WebElement> elements = driver.findElements
                    (By.xpath("//div[@id='pathwaysBarChart']//*[@class='label']"));
            String text = TestUtils.simpleContent(getCancerTypeWebElement(cancerType, elements));
            int cancerTypesTotal = StringUtils.tryParseIntOrNull
                    (text.substring(text.indexOf("(") + 1, text.indexOf(")")));
            pathwaysDashboardWidget.setSpecificCancer(cancerTypesTotal);
        }


        return pathwaysDashboardWidget;
    }

    private WebElement getCancerTypeWebElement(String cancerType, List<WebElement> elements) {
        WebElement actual = null;
        for (WebElement el : elements) {
            int length = el.getText().replace("...", "").indexOf(" (");
            if (length > 0) {
                String str = el.getText().replace("...", "").substring(0, length);
                if (cancerType.contains(str)) {
                    actual = el;
                    break;
                }
            }
        }
        return actual;
    }

    public PathwaysDashboard collectPercentageBefore() {
        PathwaysDashboard result = new PathwaysDashboard();
        result.setPathwaysDashboard(collectPercentageBefore("pathwaysDashboardPanelId"));

        return result;

    }


    public PathwaysDashboard collectSpecificCancerPercentageBefore(String cancerType) {
        PathwaysDashboard result = new PathwaysDashboard();
        result.setPathwaysDashboard(collectSpecificCancerPercentageBefore(cancerType, "pathwaysDashboardPanelId"));

        return result;

    }

    /**
     * collects specific cancer percentage.
     *
     * @param cancerType
     * @return
     */
    private PathwaysDashboardWidget collectSpecificCancerPercentageBefore(String cancerType, String pathwaysDashboardPanelId) {

        PathwaysDashboardWidget pathwaysDashboardWidget = new PathwaysDashboardWidget();
        WebElement ele = driver.findElement(By.cssSelector("[id='pathwaysBarChart']"));
        List<WebElement> elements = ele.findElements(By.tagName("text"));
        String text = TestUtils.simpleContent(getCancerTypeWebElement(cancerType, elements));
        int specificCancerTotal = StringUtils.tryParseIntOrNull
                (text.substring(text.indexOf("(") + 1, text.indexOf(")")));

        String s = TestUtils.simpleContent(driver.findElement(By.id("totalPathwaysSelected")));
        Integer pathwaySelected = StringUtils.tryParseIntOrNull(s);

        int pathwayPercentage = (specificCancerTotal * 100) / pathwaySelected;
        pathwaysDashboardWidget.setPathwayPercentage(pathwayPercentage);
        return pathwaysDashboardWidget;
    }

    public PathwaysDashboardWidget collectPercentageBefore(String widget) {
        PathwaysDashboardWidget pathwaysDashboardWidget = collect(widget);
        int pathwayPercentage = (pathwaysDashboardWidget.getPathwaySelected() * 100) / pathwaysDashboardWidget.getPathwayShown();
        pathwaysDashboardWidget.setPathwayPercentage(pathwayPercentage);
        return pathwaysDashboardWidget;
    }

    public PathwaysDashboard collectFromDb(String tin) {
        PathwaysDashboard result = new PathwaysDashboard();
        result.setPathwaysDashboard(collectDb("pathwaysDashboardPanelId", tin));
        return result;

    }


    /**
     * collects pathways shown and selected from DB
     *
     * @param widget
     * @param tin
     * @return
     */
    private PathwaysDashboardWidget collectDb(String widget, String tin) {
        PathwaysDashboardWidget pathwaysDashboardWidget = new PathwaysDashboardWidget();
        pathwaysDashboardWidget.setWidget(widget);

        String startDate;
        String endDate;
        if (LocalDate.now().getMonthValue() <= 6) {
            startDate = LocalDate.now().getYear() + "-01-01 04:00:00";
            endDate = LocalDate.now().getYear() + "-07-01 03:59:00";
        } else {
            startDate = LocalDate.now().getYear() + "-07-01 05:00:00";
            endDate = LocalDate.now().getYear() + "-01-01 03:59:00";
        }
        List<Map<String, Object>> list = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectOnPathwaysCount(tin, startDate, endDate);
        Long l1 = new Long(list.get(0).get("pathwayShownCount").toString());
        pathwaysDashboardWidget.setPathwayShown(l1.intValue());
        BigDecimal b1 = new BigDecimal(list.get(0).get("pathwaysSelected").toString());
        pathwaysDashboardWidget.setPathwaySelected(b1.intValue());
        return pathwaysDashboardWidget;
    }

    /**
     * entering TIN
     *
     * @param providerTin
     */
    public void enterTin(String providerTin) {
        TestUtils.input(driver, tinSearch, providerTin);
    }

    /**
     * searching TIN
     */
    public void searchTin() {
        TestUtils.waitElement(driver, tinSearchIcon);
        driver.findElement(tinSearchIcon).click();
        TestUtils.wait(5);
    }

    /**
     * collects specific cancer type percentage
     *
     * @param cancerType
     * @return
     */
    public PathwaysDashboard collectSpecificCancerPercentageAfter(String cancerType) {
        PathwaysDashboard result = new PathwaysDashboard();
        result.setPathwaysDashboard(collectSpecificCancerPercentageAfter("pathwaysDashboardPanelId", cancerType));

        return result;
    }

    /**
     * collects specific cancer type percentage
     *
     * @param widget
     * @param cancerType
     * @return
     */
    private PathwaysDashboardWidget collectSpecificCancerPercentageAfter(String widget, String cancerType) {
        PathwaysDashboardWidget pathwaysDashboardWidget = new PathwaysDashboardWidget();
        pathwaysDashboardWidget.setWidget(widget);
        WebElement ele = driver.findElement(By.id("pathwaysBarChart"));
        List<WebElement> elements = ele.findElements(By.tagName("text"));
        WebElement actual = null;
        for (int i = 0; i < elements.size(); i++) {
            int length = elements.get(i).getText().replace("...", "").indexOf(" (");
            if (length > 0) {
                String str = elements.get(i).getText().replace("...", "").substring(0, length);
                if (cancerType.contains(str)) {
                    actual = elements.get(i - 1);
                    break;
                }
            }
        }
        String s = TestUtils.simpleContent(actual);
        Integer pathwayPercentage = StringUtils.tryParseIntOrNull(s.replace("%", ""));
        pathwaysDashboardWidget.setPathwayPercentage(pathwayPercentage);
        return pathwaysDashboardWidget;
    }

    public PathwaysDashboard collectPathwaysPerformanceDetails() {
        PathwaysDashboard result = new PathwaysDashboard();
        result.setPathwaysDashboard(collectPathwaysPerformanceDetails("pathwaysDashboardPanelId"));

        return result;
    }

    private PathwaysDashboardWidget collectPathwaysPerformanceDetails(String widget) {
        PathwaysDashboardWidget pathwaysDashboardWidget = new PathwaysDashboardWidget();
        pathwaysDashboardWidget.setWidget(widget);
        String tableXpath = "//*[@id='pathwaysPerformanceDetailsTableID']";
        List<Map<String, String>> pathwayPerformance = TestUtils.tableAsMaps(driver,tableXpath,20);

        pathwaysDashboardWidget.setPathwayPerformance(pathwayPerformance);
        return pathwaysDashboardWidget;
    }

    public PathwaysDashboard collectPathwayPerformanceFromDb(String tin) {
        PathwaysDashboard result = new PathwaysDashboard();
        result.setPathwaysDashboard(collectPathwayPerformanceFromDb("pathwaysDashboardPanelId", tin));
        return result;

    }


    /**
     * collects pathways performance count from DB
     * @param widget
     * @param providerTin
     * @return
     */
    private PathwaysDashboardWidget collectPathwayPerformanceFromDb(String widget, String providerTin) {
        PathwaysDashboardWidget pathwaysDashboardWidget = new PathwaysDashboardWidget();
        pathwaysDashboardWidget.setWidget(widget);

        String startDate;
        String endDate;
        if (LocalDate.now().getMonthValue() <= 6) {
            startDate = LocalDate.now().getYear() + "-01-01 04:00:00";
            YearMonth thisMonth    = YearMonth.now();
            endDate =thisMonth + "-01 03:59:59";

        } else {
            startDate = LocalDate.now().getYear() + "-07-01 04:00:00";
            YearMonth thisMonth    = YearMonth.now();
            endDate =thisMonth + "-01 03:59:59";
        }
        List<Map<String, String>> pathwayPerformance = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectOnPathwaysPerformanceCount(providerTin, startDate, endDate);
        pathwaysDashboardWidget.setPathwayPerformance(pathwayPerformance);
        return pathwaysDashboardWidget;
    }

    public void verifyRewardsEligibleStatus(String rewardsEligible) {
        log.warn("Verifying Rewards Eligible Status for medicaid ");
        TestUtils.wait(3);
        Assert.assertTrue("Rewards Eligible Status for medicaid is not yes",
                driver.findElement(medicaidRewardsEligibleStatus).getText().equalsIgnoreCase(rewardsEligible));
    }
    public PathwaysDashboard collectPathwayPerformancePercentageAllProvidersFromDb() {
        PathwaysDashboard result = new PathwaysDashboard();
        result.setPathwaysDashboard(collectPathwayPerformancePercentageAllProvidersFromDb("pathwaysDashboardPanelId"));
        return result;

    }

    private PathwaysDashboardWidget collectPathwayPerformancePercentageAllProvidersFromDb(String widget) {
        PathwaysDashboardWidget pathwaysDashboardWidget = new PathwaysDashboardWidget();
        pathwaysDashboardWidget.setWidget(widget);

        String startDate;
        String endDate;
        if (LocalDate.now().getMonthValue() <= 6) {
            startDate = LocalDate.now().getYear() + "-01-01";
            YearMonth thisMonth    = YearMonth.now().minusMonths(1);
            endDate =thisMonth + "-31";

        } else {
            startDate = LocalDate.now().getYear() + "-07-01";
            YearMonth thisMonth    = YearMonth.now().minusMonths(1);
            endDate =thisMonth + "-31";
        }
        List<Map<String, String>> pathwayPerformance = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectOnPathwaysPerformanceForAllProvidersCount(startDate, endDate);
        pathwaysDashboardWidget.setPathwayPerformance(pathwayPerformance);
        return pathwaysDashboardWidget;
    }

    /**
     * Click on Review Pathways Results button
     */
    public void clickReviewPathwaysResults() {
        log.warn("Verifies Review Pathways Results button is displayed on Pathways Dashboard Widget1");
        Assert.assertTrue("Rewards Eligibility feature flag is toggled off", driver.findElement(reviewPathwaysResults).isDisplayed());
        log.warn("Click Review Pathways Results button");
        TestUtils.waitElement(driver, reviewPathwaysResults);
        driver.findElement(reviewPathwaysResults).click();
        TestUtils.wait(5);
    }

    /**
     * Return Pathways Adherence
     */
    public String returnPathwaysAdherence() {

        log.warn("Click Review Pathways Results button");
        TestUtils.waitElement(driver, pathwayAdherence);
        return (driver.findElement(pathwayAdherence).getText());

    }
    public String returnPathwaysShown() {

        log.warn("Click Review Pathways Results button");
        TestUtils.waitElement(driver, pathwayAdherence);
        return (driver.findElement(totalPathwaysShown).getText());

    }



}
