package atdd.test.pageobjects.pathwaysDashboard;

import atdd.test.shared.BaseCucumber;
import atdd.test.shared.Globals;
import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import static org.junit.Assert.assertTrue;


public class PathwaysReviewResultsPage {

    private WebDriver driver;
    private TestUtils utils;
    Logger log;
    Globals gv;


    public PathwaysReviewResultsPage(WebDriver webDriver) {
        driver = webDriver;
        utils = BaseCucumber.utils;
        log = Logger.getLogger(this.getClass().getName());
        gv = BaseCucumber.gv;
    }

    //Locators -------------------
    public static By viewPeriod = By.xpath("//select[@id='currentPeriod-0']");
    public static By currentRewardPeriod = By.xpath("//*[@class='details-flex']/div[1])");
    public static By pathwayRegimens = By.xpath("//*[@class='details-flex']/div[2])");
    public static By overallPathways = By.xpath("//*[@class='details-flex']/div[3]");
    public static By review = By.xpath("//*[@class='details-flex']/div[4]");
    public static By confirmParticipation = By.xpath("//*[@id='checkbox2']");
    public static By submitButton = By.xpath("//*[@class='submit-button tk-btn']");
    public static By emailText = By.xpath("//*[@class='completed-box ng-scope']");
    public static String pathwayAdherence = PathwaysDashboardPage.pathwayAdherence.toString();
    public static By noteSection = By.xpath("//*[@class='noteSection']");
    public static By targetnotMet = By.xpath("//*[@ng-if='!attested']");
    public static By updatedTimeStamp = By.xpath("//*[@class='flexRow']//small");





    /**
     * compare pathwayRegimens in Review Results page with Pathways Dashboard page count on widget1
     *
     * @return
     */


    public void verifyPathwaysRegimens(String PathwaysSelectedWidget1) {
        log.warn("verifying pathwayRegimens in review results page");
        TestUtils.highlightElement(driver, pathwayRegimens);
        String reviewResultsPathwaysSelected = driver.findElement(pathwayRegimens).getText();
        assertTrue("Review results page Pathways Regimens Value matches with pathways Regimens in Widget1.",
                reviewResultsPathwaysSelected.equals(PathwaysSelectedWidget1));
    }


    /**
     * Return overall Pathways Adherence
     */
    public String returnOverallPathways() {
        log.warn("Returns overall pathways percentage in review results page");
        TestUtils.waitElement(driver, overallPathways);
        return (driver.findElement(overallPathways).getText());

    }

    /**
     * Return Previous periods results (As of now we don't have any other time period)
     */
    public void previousResults(String type) {
        log.warn("Returns previous time period review results");
        TestUtils.highlightElement(driver, viewPeriod);
        new Select(this.driver.findElement(viewPeriod)).selectByVisibleText(type);
    }

    /**
     * verifies view period on review results page
     */
    public void viewPeriodPresent() {

        TestUtils.highlightElement(driver, viewPeriod);
        Assert.assertTrue("View Period Dropdown is displayed", driver.findElement(viewPeriod).isDisplayed());

    }


    /**
     * Verifies the email details section in review results page based on review status of TIN ID
     */

    public void isEmailPresent() {
        log.warn("Verifies for the email details in review results page");
        TestUtils.waitElement(driver, review);
        String reviewStatus = driver.findElement(review).getText();

        if (reviewStatus.equals("Completed")) {
            TestUtils.waitElement(driver, emailText);
            TestUtils.highlightElement(driver, emailText);
            Assert.assertTrue("UHC Email details are not displayed", driver.findElement(emailText).isDisplayed());

        } else if (reviewStatus.equals("Not started")) {
            TestUtils.waitElement(driver, noteSection);
            TestUtils.highlightElement(driver, noteSection);
            Assert.assertTrue("UHC Email details are not displayed", driver.findElement(noteSection).isDisplayed());

        } else if (reviewStatus.equals("Target not met")) {
            TestUtils.waitElement(driver, targetnotMet);
            TestUtils.highlightElement(driver, targetnotMet);
            Assert.assertTrue("UHC Email details are not displayed", driver.findElement(targetnotMet).isDisplayed());

        }


    }


    /**
     * Attestation of both eligible and non eligible Users
     */

    public void  attestation() {
        log.warn("Verifies the review status");
        TestUtils.waitElement(driver, review);
        String reviewStatus = driver.findElement(review).getText();

        if (reviewStatus.equals("Completed")) {
            assertTrue(driver.findElement(emailText).isDisplayed());
        } else if (reviewStatus.equals("Not started")) {

            log.warn("Click confirm Participation check box");
            TestUtils.waitElement(driver, confirmParticipation);
            driver.findElement(confirmParticipation).click();
            TestUtils.wait(2);
            log.warn("Click submit button for attestation");
            TestUtils.waitElement(driver, submitButton);
            driver.findElement(submitButton).click();
            TestUtils.wait(2);
            String status = driver.findElement(review).getText();
            Assert.assertEquals("Completed",status);
            assertTrue(driver.findElement(emailText).isDisplayed());
        } else if (reviewStatus.equals("Target not met")) {
            log.warn("Click confirm Participation check box");
            TestUtils.waitElement(driver, confirmParticipation);
            driver.findElement(confirmParticipation).click();
            TestUtils.wait(2);
            log.warn("Click submit button for attestation");
            TestUtils.waitElement(driver, submitButton);
            driver.findElement(submitButton).click();
            TestUtils.wait(2);
            String status = driver.findElement(review).getText();
            Assert.assertEquals("Completed",status);
            assertTrue(driver.findElement(emailText).isDisplayed());
        }
       assertTrue(reviewStatus.equals("Completed"));

    }

    /**
     * Verifies if user is eligible or non eligible for rewards
     */

    public void userRewardsEligibility() {
        log.warn("Verifies for the email details in review results page");
        TestUtils.waitElement(driver,overallPathways);
        String adherencePercentage = driver.findElement(overallPathways).getText();
        String adherence =	adherencePercentage.replace("%", "");
        int pathwaysPercentage = Integer.parseInt(adherence);
        if (pathwaysPercentage >= 75) {
            log.warn("Provider TIN is eligible for Rewards");
        }
        else{
            log.warn("Provider TIN is not eligible for Rewards");
        }


    }




}








