package atdd.test.pageobjects.priorAuthSearch;


import atdd.dao.OcmMBMDao;
import atdd.test.shared.BaseCucumber;
import atdd.test.shared.Globals;
import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.sql.SQLException;
import java.util.List;


public class PriorAuthorizationSearchDraftPage extends PriorAuthorizationSearchPage {

    private WebDriver driver;
    private TestUtils utils;
    Logger log;
    Globals gv;


    public PriorAuthorizationSearchDraftPage(WebDriver webDriver) {
        driver = webDriver;
        utils = BaseCucumber.utils;
        log = Logger.getLogger(this.getClass().getName());
        gv = BaseCucumber.gv;
    }


    //Locators -------------------
    public final static String searchResultXpath = "//table[@id='hscSearchTableDraftsID']";
    public final static By sortByDraftID = By.xpath("//span[@id='hscSearchTableDrafts-Draft-ID-sortButton']");
    public final static By sortUp = By.xpath("//span[@id='hscSearchTableDrafts-Draft-ID-sortButton' and contains(@class, 'cux-icon-sort_up')]");
    public final static By providersDropDownDraft = By.xpath("//select[contains(@id, 'hscSearchTableDrafts-tableFilters-requestingProviderMPIN')]");
    public final static By memberNameColumnElementsDraft = By.xpath("//tbody[contains(@ng-if,'hscSearchTableDrafts')]/tr/td[3]/span");
    public final static By paginationDisabledDraft = By.xpath("//div[@id='hscSearchTableDraftsID-container']//" + "div[@ng-if='hscSearchTableDrafts.pagination']//li[@disabled='disabled']");
    public final static By everythingByTinDraft = By.xpath("//input[@ng-model='draftCreatedByMeRadio' and contains(@class, 'subEverything')]");
    public final static By creatorColumnElementsDraft = By.xpath("//tbody[contains(@ng-if,'hscSearchTableDrafts')]/tr/td[6]/span");
    public final static By statusColumnElementsDraft = By.xpath("//tbody[contains(@ng-if,'hscSearchTableDrafts')]/tr/td[8]/span[not(contains(@class, 'cux-icon-info'))]");
    public final static By creationDateColumnElementsDraft = By.xpath("//tbody[contains(@ng-if,'hscSearchTableDrafts')]/tr/td[5]/span");
    public final static By draftIDColumnElementsDraft = By.xpath("//tbody[contains(@ng-if,'hscSearchTableDrafts')]/tr/td[2]/span");
    public final static By subscriberIDColumnElementsDraft = By.xpath("//tbody[contains(@ng-if,'hscSearchTableDrafts')]/tr/td[4]/span");
    public final static By clearDraft = By.xpath("//input[contains(@ng-click,'hscSearchTableDrafts.clearSearchOnClick')]");
    public final static By searchDraft = By.xpath("//input[contains(@ng-click,'hscSearchTableDrafts.applyTableFiltersOnClick')]");
    public final static By subscriberIDsearchDraft = By.xpath("//input[contains(@id, 'hscSearchTableDrafts-tableFilters-memberIDText')]");
    public final static By draftIDsearchDraft = By.xpath("//input[contains(@id, 'hscSearchTableDrafts-tableFilters-hscID')]");
    public final static By memberLastNameSearchDraft = By.xpath("//input[contains(@id, 'hscSearchTableDrafts-tableFilters-lastName')]");
    public final static By statusDropDwn = By.xpath("//span[contains(@ng-model,'hscSearchTableDrafts.tableFilters')]//button");
    public final static By editIcon = By.xpath("//span[contains(@class,'ocm-action cux-icon-edit')]");
    public final static By providerTin = By.xpath("//input[contains(@id, 'hscSearchTableDrafts-tableFilters-reqProviderTIN')]");
    public final static By paanTin = By.xpath("//label[@for='draftEverythingRadio'] ");
    public final static By totalRecords = By.xpath("//*[@ng-if='hscSearchTableDrafts.pagination.totalRecordsCount']");
    public final static By SearchByHisSubscriberID = By.xpath("//input[contains(@id, 'hscSearchByHisSubscriberID')]");
    public final static By priorAuthReqSearch = By.xpath("//input[contains(@ng-click,'summarySearch(searchForm)')]");
    public final static By SearchByHisMemFirstName = By.xpath("//*[@id='hscSearchByHisMemFirstName']");
    public final static By SearchByHisMemLastName = By.xpath("//*[@id='hscSearchByHisMemLastName']");
    public final static By SearchByHisMembirthDate = By.xpath("//*[@id='hscSearchTableHistory-tableFilters-birthDate-0']");
    public final static By SubscriberIDHistoryPage = By.xpath("//*[@id='hscSearchTableHistoryID']/tbody/tr/td[3]/span");


    //Locators -------------------

    public void checkEditIconIsNotPresent() {
        log.warn("Checking that Edit icon is not visible on Draft or Submitted page");
        Assert.assertFalse("Not all elements in Pagination are disabled", TestUtils.isElementPresent(driver, editIcon));
    }

    /**
     * Enter Provider TIN
     *
     * @param tin
     */
    public void enterProviderTin_SearchDraft(String tin) {
        log.warn("Enter Provider TIN On the Search page Draft tab: " + tin);
        TestUtils.waitElement(driver, providerTin);
        driver.findElement(providerTin).clear();
        driver.findElement(providerTin).sendKeys(tin);
    }

    /**
     * Select status by clicking on Status drop-down and selecting element.
     *
     * @param status
     */
    public void selectStatusDropDwn(String status) {
        log.warn("Select Status: " + status);
        TestUtils.waitElement(driver, statusDropDwn);
        TestUtils.highlightElement(driver, statusDropDwn);
        driver.findElement(statusDropDwn).click();

        By dropDwnOption = By.xpath("//span[contains(@ng-model,'hscSearchTableDrafts.tableFilters')]//span[text()='" + status + "']");
        TestUtils.highlightElement(driver, dropDwnOption);
        driver.findElement(dropDwnOption).click();
        TestUtils.wait(1);
        driver.findElement(statusDropDwn).click();
    }

    /**
     * Enter Member Last Name On the Search page Draft tab
     *
     * @param memberLastNameInput
     */
    public void enterMemberLastName_SearchDraft(String memberLastNameInput) {
        log.warn("Enter Member Last Name On the Search page Draft tab: " + memberLastNameInput);
        TestUtils.waitElement(driver, memberLastNameSearchDraft);
        driver.findElement(memberLastNameSearchDraft).sendKeys(memberLastNameInput);
    }

    /**
     * Enter Draft ID on the Search page Draft tab
     *
     * @param draftIDInput
     */
    public void enterDraftID_SearchDraft(String draftIDInput) {
        log.warn("Enter Draft ID on the Search page Draft tab: " + draftIDInput);
        TestUtils.waitElement(driver, draftIDsearchDraft);
        driver.findElement(draftIDsearchDraft).sendKeys(draftIDInput);
    }

    /**
     * Enter Subscriber ID on the Search page Draft tab
     *
     * @param subscriberIDInput
     */
    public void enterSubscriberID_SearchDraft(String subscriberIDInput) {
        log.warn("Enter Subscriber ID on the Search page Draft tab: " + subscriberIDInput);
        TestUtils.waitElement(driver, subscriberIDsearchDraft);
        driver.findElement(subscriberIDsearchDraft).sendKeys(subscriberIDInput);
    }

    /**
     * Enter all member ID types on the search Page Draft tab and verify the draft auth are retrieved
     *
     * @param hsc_id, Options
     */

    public void retrieveDraftAuthByAllMemberTypes_SearchDraft(String hsc_id, String Options) {
        List<String> value = null;
        try {
            value = OcmMBMDao.getDao().returnMultipleRowValue("select mbr_id from hsc where hsc_id = '" + hsc_id + "'");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        String mbr_id = value.get(0);
        List<String> mbrIdTypeId = null;
        try {
            mbrIdTypeId = OcmMBMDao.getDao().returnMultipleRowValue("select mbr_id_txt from mbr_id where mbr_id ='" + mbr_id + "'");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        for (int i = 0; i < mbrIdTypeId.size(); i++) {
            driver.findElement(subscriberIDsearchDraft).sendKeys(mbrIdTypeId.get(i));
            clickSearchDraft();
            checkColumnElements_DraftID_SearchDraft(hsc_id);
            driver.findElement(subscriberIDsearchDraft).clear();
        }
    }

    /**
     * Enter all member ID types on the search Page Draft tab and verify the SearchHistory are retrieved
     */

    public void retrieveDraftAuthByAllMemberTypes_SearchHistory(String fn, String ln, String dob) {

        List<String> mbrIdTypeId = null;
        try {
            mbrIdTypeId = OcmMBMDao.getDao().returnMultipleRowValue("Select mbr_id_txt from mbr_id where mbr_id in (select mbr_id from mbr where lst_nm='" + ln + "' and fst_nm='" + fn + "')");

        } catch (SQLException e) {
            e.printStackTrace();
        }
        for (int i = 0; i < mbrIdTypeId.size(); i++) {
            driver.findElement(SearchByHisSubscriberID).sendKeys(mbrIdTypeId.get(i));
            driver.findElement(SearchByHisMemFirstName).sendKeys(fn);
            driver.findElement(SearchByHisMemLastName).sendKeys(ln);
            driver.findElement(SearchByHisMembirthDate).sendKeys(dob);
            clickSearchHist();
            checkColumnElements_SubScriberID_SearchHist(fn, ln);
            TestUtils.wait(2);
            driver.findElement(SearchByHisSubscriberID).clear();
            driver.findElement(SearchByHisMemFirstName).clear();
            driver.findElement(SearchByHisMemLastName).clear();
            driver.findElement(SearchByHisMembirthDate).clear();


        }
    }

    /**
     * Click Clear on the Draft Tab
     */
    public void clickClearDraft() {
        log.warn("Click Clear on the Draft Tab");
        TestUtils.waitElement(driver, clearDraft);
        driver.findElement(clearDraft).click();
        TestUtils.wait(2);
    }

    /**
     * Click Search on the Draft Tab
     */
    public void clickSearchDraft() {
        log.warn("Click Search on the Draft Tab");
        TestUtils.waitElement(driver, searchDraft);
        driver.findElement(searchDraft).click();
        TestUtils.wait(2);
    }

    /**
     * Click Search on the History Tab
     */
    public void clickSearchHist() {
        log.warn("Click Search on the Draft Tab");
        TestUtils.waitElement(driver, priorAuthReqSearch);
        driver.findElement(priorAuthReqSearch).click();
        TestUtils.wait(2);
    }

    /**
     * Getting All values from Status and checking for txt. Draft Page
     *
     * @param elem
     */
    public void checkColumnElements_Status_SearchDraft(String elem) {
        log.warn("Getting All values from Status and checking for txt: " + elem);
        List<WebElement> column = driver.findElements(statusColumnElementsDraft);
        String tmp;
        boolean res = false;

        //Checking that ALL elements are present
        for (WebElement e : column) {
            tmp = e.getText().trim();
            if (!tmp.contains(elem)) {
                res = true;
                log.warn("Found: " + tmp);
                break;
            }
        }

        Assert.assertFalse("Element " + elem + " is NOT present", res);
    }

    /**
     * Getting All values from Member Name and checking for txt. Draft Page
     *
     * @param elem
     */
    public void checkColumnElements_MemberName_SearchDraft(String elem) {
        log.warn("Getting All values from Member Name and checking for txt: " + elem);
        List<WebElement> column = driver.findElements(memberNameColumnElementsDraft);
        String tmp = "none";
        boolean res = false;

        //Checking that at list one element is present
        for (WebElement e : column) {
            tmp = e.getText().trim();
            if (tmp.contains(elem)) {
                res = true;
                log.warn("Found: " + tmp);
                break;
            }
        }

        Assert.assertTrue("Element " + tmp + " is present. Expected " + elem, res);
    }

    /**
     * Getting All values from Subscriber ID and checking for txt. Draft page
     *
     * @param elem
     */
    public void checkColumnElements_SubID_SearchDraft(String elem) {
        log.warn("Getting All values from Subscriber ID and checking for txt: " + elem);
        List<WebElement> column = driver.findElements(subscriberIDColumnElementsDraft);
        String tmp = "none";
        boolean res = false;

        //Checking that at list one element is present
        for (WebElement e : column) {
            tmp = e.getText().trim();
            if (tmp.contains(elem)) {
                res = true;
                log.warn("Found: " + tmp);
                break;
            }
        }

        Assert.assertTrue("Element " + tmp + " is not present. Expected " + elem, res);
    }

    /**
     * Getting All values from Draft ID and checking for txt. At list one match! Draft page
     *
     * @param elem
     */
    public void checkColumnElements_DraftID_SearchDraft(String elem) {
        log.warn("Getting All values from Draft ID and checking for txt. At list one match! " + elem);
        List<WebElement> column = driver.findElements(draftIDColumnElementsDraft);
        String tmp = "none";
        boolean res = false;

        //Checking that at list one element is present
        for (WebElement e : column) {
            tmp = e.getText().trim();
            if (tmp.contains(elem)) {
                res = true;
                log.warn("Found: " + tmp);
                break;
            }
        }
        Assert.assertTrue("Element " + tmp + " is present. Expected " + elem, res);
    }

    /**
     * Getting All values from Creation date and checking for txt. Draft page
     * At list one match!
     *
     * @param elem
     */
    public void checkColumnElements_CreationDate_SearchDraft(String elem) {
        log.warn("Getting All values from Creation date and checking for txt. " + elem);
        List<WebElement> column = driver.findElements(creationDateColumnElementsDraft);
        String tmp = "none";
        boolean res = false;

        //Checking that at list one element is present
        for (WebElement e : column) {
            tmp = e.getText().trim();
            if (tmp.contains(elem)) {
                res = true;
                log.warn("Found: " + tmp);
                break;
            }
        }
        Assert.assertTrue("Element " + tmp + " is present. Expected " + elem, res);
    }

    /**
     * Getting All values from Memer Name and checking for txt. Draft Page
     * Will pass if it has at list one match
     *
     * @param elem
     */
    public void checkColumnElements_CreatorName_SearchDraft(String elem) {
        log.warn("Getting All values from Memer Name and checking for txt: " + elem);
        List<WebElement> column = driver.findElements(creatorColumnElementsDraft);
        String tmp = "none";
        boolean res = false;

        //Checking that at list one element is present
        for (WebElement e : column) {
            tmp = e.getText().trim();
            if (tmp.contains(elem)) {
                res = true;
                log.warn("Found: " + tmp);
                break;
            }
        }

        Assert.assertTrue("Element " + tmp + " is not correct. Expected " + elem, res);
    }

    /**
     * Click Everything for TIN XXXXXX radio button Draft page
     */
    public void clickEverythingByTinDraft() {
        log.warn("Click Everything for TIN XXXXXX radio button Draft page");
        TestUtils.waitElement(driver, everythingByTinDraft);
        TestUtils.highlightElement(driver, everythingByTinDraft);
        driver.findElement(everythingByTinDraft).click();
        driver.findElement(everythingByTinDraft).click();
    }

    /**
     * Check that all 4 elements in Pagination are disabled. Draft
     */
    public void checkDisabledPaginationDraft() {
        log.warn("Check that all 4 elements in Pagination are disabled. Draft");
        int numOfElements = driver.findElements(paginationDisabledDraft).size();
        Assert.assertTrue("Not all elements in Pagination are disabled", numOfElements >= 4);
        TestUtils.highlightElement(driver, paginationDisabledDraft);
    }

    /**
     * Counting number of elements in the name column Draft
     *
     * @return
     */
    public int getNumberOfElementsDraft() {
        int numOfElements = driver.findElements(memberNameColumnElementsDraft).size();
        log.warn("Counting number of elements in the name column Draft: " + numOfElements);
        return numOfElements;
    }

    /**
     * Selecting option from Providers Drop-down. Draft Tab
     *
     * @param item
     * @return
     */
    public PriorAuthorizationSearchDraftPage selectCareProviderDraft(String item) {
        log.warn("Selecting option from Providers Drop-down. Draft Tab " + item);
        TestUtils.waitElement(driver, providersDropDownDraft);
        TestUtils.highlightElement(driver, providersDropDownDraft);

        TestUtils.wait(2);
        Select dropdown = new Select(driver.findElement(providersDropDownDraft));
        dropdown.selectByVisibleText(item);
        TestUtils.wait(2);
        return this;
    }

    /**
     * Check That element Has Urgent Flag Draft tab
     *
     * @return
     */
    public PriorAuthorizationSearchDraftPage checkUrgentFlagDraftTab(String elem) {
        log.warn("Check That element Has Urgent Flag Draft tab: " + elem);
        By urgentFlag = By.xpath("//*[@id='hscSearchTableDraftsID']//span[text()='" + elem
                + "']/../span[contains(@class,'cux-icon-warning_hollow_filled')]");
        TestUtils.waitElement(driver, urgentFlag);
        TestUtils.highlightElement(driver, urgentFlag);
        return this;
    }

    /**
     * Sort Up by Draft ID
     */
    public void sortUPbyDraftID_Draft() {
        log.warn("Sort Up by Draft ID");
        TestUtils.waitElement(driver, sortByDraftID);
        TestUtils.highlightElement(driver, sortByDraftID);

        if (!TestUtils.isElementPresent(driver, sortUp)) {
            driver.findElement(sortByDraftID).click();
            TestUtils.wait(2);
        }

        if (!TestUtils.isElementPresent(driver, sortUp)) {
            driver.findElement(sortByDraftID).click();
            TestUtils.wait(2);
        }

        if (!TestUtils.isElementPresent(driver, sortUp)) {
            log.warn("Cant sort by Draft ID");
        }
        TestUtils.wait(5);
    }

    /**
     * Storing tin on Prior Auth Draft search page.
     */
    public void storeTINonPriorAuthDraftSubmit() {
        log.warn("Storing TIN on Prior Auth Draft Search");
        String tinText = driver.findElement(paanTin).getText();
        TestUtils.highlightElement(driver, paanTin);
        String tin = tinText.substring(tinText.length() - 9);
        gv.setpaanTIN(tin);
        log.warn("Tin Stored:" + tin);
    }

    /**
     * Compare Total Records and confirm that it matches DB results for TIN
     */
    public void TotalRecordsMatchDBforTIN(String authType) {
        log.warn("Compare Total Records and confirm that it matches DB results for TIN");
        String totalRecordsFull = driver.findElement(totalRecords).getText();
        TestUtils.highlightElement(driver, totalRecords);
        int recordCountUI = Integer.parseInt(totalRecordsFull.substring(totalRecordsFull.indexOf(":") + 2));

        int actualRecordCount = 0;

        try {
            actualRecordCount = OcmMBMDao.getDao().getTotalRecordsOnPriorAuthSearch(authType);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        Assert.assertEquals(recordCountUI, actualRecordCount);

    }

    /**
     * Getting SubscriberID from UI and Verifying with DB
     *
     * @param fn
     * @param ln
     */
    public void checkColumnElements_SubScriberID_SearchHist(String fn, String ln) {
        log.warn("Getting SubscriberID from History page and verifying with DB ");
        WebElement subScriber_ID = driver.findElement(SubscriberIDHistoryPage);
        String subId = subScriber_ID.getText().trim();
        List<String> mbrIdTypeId = null;
        try {
            mbrIdTypeId = OcmMBMDao.getDao().returnMultipleRowValue("Select mbr_id_txt from mbr_id where mbr_id_typ_id=1 and mbr_id in (select mbr_id from mbr where lst_nm='" + ln + "' and fst_nm='" + fn + "')");

        } catch (SQLException e) {
            e.printStackTrace();
        }
        TestUtils.wait(2);
        Assert.assertEquals(subId, mbrIdTypeId.get(0));


    }


    public void clickEditIcon() {
        log.warn("Clicking Edit icon on Draft or Submitted page");
        TestUtils.wait(2);
        TestUtils.waitElement(driver,editIcon);
        TestUtils.click(driver, editIcon);
    }
}