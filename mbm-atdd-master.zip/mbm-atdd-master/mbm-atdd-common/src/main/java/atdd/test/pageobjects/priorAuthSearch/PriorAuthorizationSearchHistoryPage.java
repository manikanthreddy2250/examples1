package atdd.test.pageobjects.priorAuthSearch;


import atdd.test.shared.BaseCucumber;
import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class PriorAuthorizationSearchHistoryPage extends PriorAuthorizationSearchPage {

    Logger log;
    private WebDriver driver;
    private TestUtils utils;

    public PriorAuthorizationSearchHistoryPage(WebDriver webDriver) {
        driver = webDriver;
        utils = BaseCucumber.utils;
        log = Logger.getLogger(this.getClass().getName());
    }

    //Locators -------------------
    public final static String searchResultXpath = "//table[@id='hscSearchTableProviderHistoryID']";
    public final static By subIDhistory = By.xpath("//input[@id='hscSearchByHisSubscriberID']");
    public final static By memberFirstNameHistory = By.xpath("//input[@id='hscSearchByHisMemFirstName']");
    public final static By memberLastNameHistory = By.xpath("//input[@id='hscSearchByHisMemLastName']");
    public final static By dobHistory = By.xpath("//input[contains(@id, 'hscSearchTableHistory-tableFilters-birthDate')]");
    public final static By searchBtn = By.xpath("//div[contains(@class,'hscSearchHistory')]//input[@value='Search']");
    public final static By clearBtn = By.xpath("//div[contains(@class,'hscSearchHistory')]//input[@value='Clear']");
    public final static By tableResultsHistory = By.xpath("//table[@id='hscSearchTableHistoryID' or @id='hscSearchTableProviderHistoryID']//tbody/tr");
    public final static By requestNumberRadioBtn = By.xpath("//input[@id='requestNumber']");
    public final static By memberInfoRadioBtn = By.xpath("//input[@id='memberInformation']");
    public final static By providerTypeDropDwn = By.xpath("//select[contains(@id, 'hscProviderHistory-providerSelected')]");
    public final static By requestNumber = By.xpath("//input[@id='hscSearchByDraftRequestNumber']");
    public final static By tinOfReqProvider = By.xpath("//input[@id='hscSearchByDraftTINReqNum']");
    public final static By facilityName = By.xpath("//input[@id='hscSearchByDraftFacilityName']");
    public final static By physicianFirstName = By.xpath("//input[@id='hscSearchByDraftPhyFirstName']");
    public final static By physicianLastName = By.xpath("//input[@id='hscSearchByDraftPhyLastName']");
    public final static By SearchHistoryByMemberInfo = By.xpath("//*[@ng-click='summarySearch(searchForm)']");
    public final static By searchHistoryByAuth = By.xpath("//*[@aria-label='hscSearchDraftSearchButton']");


    //Locators -------------------


    /**
     * Enter Physician Last Name.
     *
     * @param txt
     */
    public void enterPhysicianLastName(String txt) {
        log.warn("Physician Last Name On the History tab: " + txt);
        TestUtils.waitElement(driver, physicianLastName);
        TestUtils.highlightElement(driver, physicianLastName);
        driver.findElement(physicianLastName).clear();
        driver.findElement(physicianLastName).sendKeys(txt);
    }

    /**
     * Enter Physician First Name.
     *
     * @param txt
     */
    public void enterPhysicianFirstName(String txt) {
        log.warn("Physician First Name On the History tab: " + txt);
        TestUtils.waitElement(driver, physicianFirstName);
        TestUtils.highlightElement(driver, physicianFirstName);
        driver.findElement(physicianFirstName).clear();
        driver.findElement(physicianFirstName).sendKeys(txt);
    }

    /**
     * Enter Facility Name.
     *
     * @param txt
     */
    public void enterFacilityName(String txt) {
        log.warn("Enter Facility Name On the History tab: " + txt);
        TestUtils.waitElement(driver, facilityName);
        TestUtils.highlightElement(driver, facilityName);
        driver.findElement(facilityName).clear();
        driver.findElement(facilityName).sendKeys(txt);
    }

    /**
     * Enter TIN of the Requesting Provider.
     *
     * @param txt
     */
    public void enterTinOfReqProv(String txt) {
        log.warn("Enter TIN of the Requesting Provider On the History tab: " + txt);
        TestUtils.waitElement(driver, tinOfReqProvider);
        TestUtils.highlightElement(driver, tinOfReqProvider);
        driver.findElement(tinOfReqProvider).clear();
        driver.findElement(tinOfReqProvider).sendKeys(txt);
    }

    /**
     * Enter Request number
     *
     * @param txt
     */
    public void enterRequestNumber(String txt) {
        log.warn("Enter Request Number On the History tab: " + txt);
        TestUtils.waitElement(driver, requestNumber);
        TestUtils.highlightElement(driver, requestNumber);
        driver.findElement(requestNumber).clear();
        driver.findElement(requestNumber).sendKeys(txt);
    }

    /**
     * Selecting Provider Type
     *
     * @param type
     */
    public void selectProviderType_History(String type) {
        log.warn("Select Provider Type On the History tab: " + type);
        TestUtils.waitElement(driver, providerTypeDropDwn);
        TestUtils.selectByVisibleText(driver, providerTypeDropDwn, type);
    }

    /**
     * Click Member Information radio button On the History tab
     */
    public void clickMemberInfoRadioBtn_History() {
        log.warn("Click Member Information radio button On the History tab");
        TestUtils.waitElement(driver, memberInfoRadioBtn);
        TestUtils.highlightElement(driver, memberInfoRadioBtn);
        driver.findElement(memberInfoRadioBtn).click();
    }

    /**
     * Click Request Number radio button On the History tab
     */
    public void clickRequestNumRadioBtn_History() {
        log.warn("Click Request Number radio button On the History tab");
        TestUtils.waitElement(driver, requestNumberRadioBtn);
        TestUtils.highlightElement(driver, requestNumberRadioBtn);
        driver.findElement(requestNumberRadioBtn).click();
    }

    /**
     * Enter Subscriber ID On the History tab
     *
     * @param subID
     */
    public void enterSubscriberID_History(String subID) {
        log.warn("Enter Subscriber ID On the History tab: " + subID);
        TestUtils.waitElement(driver, subIDhistory);
        TestUtils.highlightElement(driver, subIDhistory);
        driver.findElement(subIDhistory).sendKeys(subID);
    }

    /**
     * Enter Member First Name On the History tab
     *
     * @param txt
     */
    public void enterMemberFirstName_History(String txt) {
        log.warn("Enter Member First Name On the History tab: " + txt);
        TestUtils.waitElement(driver, memberFirstNameHistory);
        TestUtils.highlightElement(driver, memberFirstNameHistory);
        driver.findElement(memberFirstNameHistory).sendKeys(txt);
    }

    /**
     * Enter Member Last Name On the History tab
     *
     * @param txt
     */
    public void enterMemberLastName_History(String txt) {
        log.warn("Enter Member Last Name On the History tab: " + txt);
        TestUtils.waitElement(driver, memberLastNameHistory);
        TestUtils.highlightElement(driver, memberLastNameHistory);
        driver.findElement(memberLastNameHistory).sendKeys(txt);
    }

    /**
     * Enter Member Date of birth On the History tab
     *
     * @param txt
     */
    public void enterMemberDOB_History(String txt) {
        log.warn("Enter Member Date of birth On the History tab: " + txt);
        TestUtils.waitElement(driver, dobHistory);
        TestUtils.highlightElement(driver, dobHistory);
        driver.findElement(dobHistory).sendKeys(txt);
    }

    /**
     * Click Search button On the History tab
     */
    public void clickSearch_History() {
        log.warn("Click Search button On the History tab");
        TestUtils.waitElement(driver, searchBtn);
        TestUtils.highlightElement(driver, searchBtn);
        driver.findElement(searchBtn).click();
        TestUtils.wait(2);
    }

    /**
     * Click Clear button On the History tab
     */
    public void clickClear_History() {
        log.warn("Click Clear button On the History tab");
        TestUtils.waitElement(driver, clearBtn);
        TestUtils.highlightElement(driver, clearBtn);
        driver.findElement(clearBtn).click();
    }

    /**
     * Get number of search results the History tab based on member info
     */
    public int checkNumberOfSearchResults_History() {
        int tmp = driver.findElements(tableResultsHistory).size();
        log.warn("Get number of search results the History tab: " + tmp);
        return tmp;
    }

    /**
     * Click Search on the History Tab
     */
    public void clickSearchHistoryBasedOnMemberInformation() {
        log.warn("Click Search on the History Tab");
        TestUtils.click(driver, SearchHistoryByMemberInfo);
        TestUtils.wait(2);
    }

    /**
     * Click Search on the History Tab based on auth
     */
    public void clickSearchHistoryByAuth() {
        log.warn("Click Search on the History Tab");
        TestUtils.waitElementClickable(driver, searchHistoryByAuth);
        TestUtils.click(driver, searchHistoryByAuth);
        TestUtils.wait(2);
    }
}