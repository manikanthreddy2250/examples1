package atdd.test.pageobjects.priorAuthSearch;

import org.openqa.selenium.By;

public class PriorAuthorizationSearchPage {

    public static final By submittedTab = By.xpath("//li[contains(@class,'tk-tpnl')]/span[text()='Submitted']");
    public static final By draftsTab = By.xpath("//li[contains(@class,'tk-tpnl')]/span[text()='Drafts']");
    public static final By historyTab = By.xpath("//li[contains(@class,'tk-tpnl')]/span[text()='History']");
    public static final By convertedAuthorizationsTab = By.xpath("//li[contains(@class,'tk-tpnl')]/span[text()='Converted Authorizations']");

}
