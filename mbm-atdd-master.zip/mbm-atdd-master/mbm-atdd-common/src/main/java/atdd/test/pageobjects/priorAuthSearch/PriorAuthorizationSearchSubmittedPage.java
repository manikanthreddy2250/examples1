package atdd.test.pageobjects.priorAuthSearch;


import atdd.dao.OcmMBMDao;
import atdd.dao.mbm.HscCustomReasonsDao;
import atdd.dao.mbm.HscDao;
import atdd.dao.mbm.MyBatisConnectionFactory;
import atdd.test.pageobjects.CommonPage;
import atdd.test.pageobjects.NavigationPage;
import atdd.test.shared.BaseCucumber;
import atdd.test.shared.Globals;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;


public class PriorAuthorizationSearchSubmittedPage extends PriorAuthorizationSearchPage {
    private final static Logger log = Logger.getLogger(PriorAuthorizationSearchSubmittedPage.class);

    private WebDriver driver;
    private TestUtils utils;
    Globals gv;
    private Scenario scenario;


    public PriorAuthorizationSearchSubmittedPage(WebDriver webDriver) {
        driver = webDriver;
        utils = BaseCucumber.utils;
        gv = BaseCucumber.gv;
    }


    //Locators -------------------
    public final static String searchResultXpath = "//table[@id='hscSearchTableSubmittedID']";
    public final static By urgentRequestsChkBx = By.xpath("//input[contains(@id='priorityCheckbox')]");
    public final static By providersDropDown = By.xpath("//select[contains(@id, 'hscSearchTableSubmitted-tableFilters-providerMPIN')]");
    public final static By memberNameColumnElements = By.xpath("//tbody[contains(@ng-if,'hscSearchTableSubmitted')]/tr/td[3]/span");
    public final static By paginationDisabled = By.xpath("//li[contains(@ng-disabled,'pagination') and @disabled='disabled']");
    public final static By everythingByTinSub = By.xpath("//input[@ng-model='subCreatedByMeRadio' and contains(@class, 'subEverything')]");
    public final static By subscriberIDColumnElements = By.xpath("//tbody[contains(@ng-if,'hscSearchTableSubmitted')]/tr/td[4]/span");
    public final static By requestNumberColumnElements = By.xpath("//tbody[contains(@ng-if,'hscSearchTableSubmitted')]/tr/td[2]/span");
    public final static By statusColumnElements = By.xpath("//tbody[contains(@ng-if,'hscSearchTableSubmitted')]/tr/td[5]/span");
    public final static By endDateColumnElements = By.xpath("//tbody[contains(@ng-if,'hscSearchTableSubmitted')]/tr/td[7]/span");
    public final static By clearSubmitted = By.xpath("//input[contains(@ng-click,'clearSubmittedAuthSearch(authSearchForm)')]|//input[contains(@ng-click,'hscSearchTableSubmitted.clearSearchOnClick')]");
    public final static By searchSubmitted = By.xpath("//input[contains(@ng-click,'applySubmittedAuthSearchFilters(authSearchForm)')]|//input[contains(@ng-click,'hscSearchTableSubmitted.applyTableFiltersOnClick(hscSearchTableSubmittedFormtableFilters)')]");
    public final static By authNumberInputSearch = By.xpath("//input[contains(@id, 'hscSearchSubmittedRequestNumber')]");
    public final static By authNumberInputSearchOC = By.xpath("//input[@name='Primary Service Reference Num']");
    public final static By memberLastNameSearch = By.xpath("//input[contains(@id, 'hscSearchTableSubmitted-tableFilters-lastName')]");
    public final static By subscriberIDsearch = By.xpath("//input[contains(@id, 'hscSearchTableSubmitted-tableFilters-memberIDText')]");
    public final static By statusSelector = By.xpath("//span[@class='cux-icon-sort_down']");
    public final static By statusDropdownValues = By.xpath("//span[contains(@ng-bind-html,'writeLabel')]");
    public final static By statusDropDwn = By.xpath("//span[contains(@ng-model,'hscSearchTableSubmitted.tableFilters')]//button[contains(@class,'multiSelectButton')]");
    public final static String statusTkMultiSelXpath = "//span[@ng-model='hscSearchTableSubmitted.tableFilters.hscOverallStatusType']//button[contains(@class,'multiSelectButton')]";
    public final static By statusTkMultiSel = By.xpath(statusTkMultiSelXpath);
    public final static By providerTin = By.xpath("//input[contains(@id, 'hscSearchTableSubmitted-tableFilters-providerTIN')]");
    public final static By paanTin = By.xpath("//label[@for='submittedEverythingRadio']");
    public final static By totalRecords = By.xpath("//*[@ng-if='hscSearchTableSubmitted.pagination.totalRecordsCount']");
    public final static By payerLabel = By.xpath("//td[contains(text(),'Payer')]");
    public final static By viewAuth = By.xpath("//*[@ng-click='hscSearchTableSubmitted.selectRecord(record)']");


    public static By viewAuthLink(String requestNumber) {
        return By.xpath("//a[.='" + requestNumber + "']");
    }

    // Added for Submitted Search by using Benefit Type or Request Type Needs.
    public final static By authTypeDropDwn = By.xpath("//span[contains(@ng-model,'hscSearchTableSubmitted.tableFilters.authorizationType')]//button[contains(@class,'multiSelectButton')]");
    public final static String benefitTypeTkMultiSelXpath = "//span[@ng-model='selectBenefit.benefitTypes']";
    public final static String authTypeTkMultiSelXpath = "//span[contains(@ng-model,'hscSearchTableSubmitted.tableFilters.authorizationType')]//button[contains(@class,'multiSelectButton')]";
    public final static By benefitTypeTkMultiSel = By.xpath(benefitTypeTkMultiSelXpath);
    public final static By authTypeTkMultiSel = By.xpath(authTypeTkMultiSelXpath);
    public final static By benefitTypeDropDwn = By.xpath("//span[contains(@ng-model,'selectBenefit.benefitTypes')]//button[contains(@class,'multiSelectButton')]");

    //Locators -------------------

    /**
     * Enter Provider TIN
     *
     * @param tin
     */
    public void enterProviderTIN_Search(String tin) {
        log.warn("Enter " + tin + " Provider TIN on the Search page Submitted tab");
        TestUtils.waitElement(driver, providerTin);
        TestUtils.highlightElement(driver, providerTin);
        driver.findElement(providerTin).clear();
        driver.findElement(providerTin).sendKeys(tin);
    }

    /**
     * Select status by clicking on Status drop-down and selecting element.
     *
     * @param status
     */
    public void selectStatusDropDwn(String status) {
        log.warn("Select Status: " + status);
        TestUtils.waitElement(driver, statusDropDwn);
        TestUtils.highlightElement(driver, statusDropDwn);
        driver.findElement(statusDropDwn).click();

        By dropDwnOption = By.xpath("//span[contains(@ng-model,'hscSearchTableSubmitted.tableFilters')]//span[text()='" + status + "']");
        TestUtils.highlightElement(driver, dropDwnOption);
        driver.findElement(dropDwnOption).click();
        TestUtils.wait(1);
        driver.findElement(statusDropDwn).click();
    }


    /**
     * Enter Subscriber ID on the Search page Submitted tab
     *
     * @param subscriberIDInput
     */
    public void enterSubscriberID_Search(String subscriberIDInput) {
        log.warn("Enter " + subscriberIDInput + " Subscriber ID on the Search page Submitted tab");
        TestUtils.waitElement(driver, subscriberIDsearch);
        TestUtils.highlightElement(driver, subscriberIDsearch);
        driver.findElement(subscriberIDsearch).clear();
        driver.findElement(subscriberIDsearch).sendKeys(subscriberIDInput);
    }

    /**
     * Enter all member ID type present for a member on the Search page Submitted tab and verify the Auth
     * is retrieved
     *
     * @param elem, Option
     */

    public void enterMemberIdOrSubscriberID(String elem, String Option) {
        String RequestNumber = gv.getRequestNumber();

        List<String> value = null;
        try {
            value = OcmMBMDao.getDao().returnMultipleRowValue("select mbr_id from hsc where pri_srvc_ref_nbr ='" + RequestNumber + "' or vend_cse_id='" + RequestNumber + "'");
        } catch (SQLException e) {
            e.printStackTrace();
        }

        List<String> mbrIdTypeId = null;

        String IdType = value.get(0);
        try {
            mbrIdTypeId = OcmMBMDao.getDao().returnMultipleRowValue("select mbr_id_txt from mbr_id where mbr_id ='" + IdType + "'");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        NavigationPage nav = new NavigationPage(driver);
        nav.expandClickPrimaryNav("Authorization");
        By dropDown = By.xpath("//*[@model='item.dropDown']//span[text()='" + Option + "']");
        TestUtils.highlightElement(driver, dropDown);
        driver.findElement(dropDown).click();
        CommonPage cp = new CommonPage(driver);
        cp.acceptAlert();
        for (int i = 0; i < mbrIdTypeId.size(); i++) {
            driver.findElement(subscriberIDsearch).sendKeys(mbrIdTypeId.get(i));
            clickSearchSubmitted();
            checkColumnElements_RequestNumber_SearchSubmitted(RequestNumber);
            driver.findElement(subscriberIDsearch).clear();
        }


    }

    /**
     * Enter Member Last Name On the Search page Submitted tab
     *
     * @param memberLastNameInput
     */
    public void enterMemberLastName_Search(String memberLastNameInput) {
        log.warn("Entering " + memberLastNameInput + " Member Last name on the Search Submitted page");
        TestUtils.waitElement(driver, memberLastNameSearch);
        TestUtils.highlightElement(driver, memberLastNameSearch);
        driver.findElement(memberLastNameSearch).clear();
        driver.findElement(memberLastNameSearch).sendKeys(memberLastNameInput);
    }

    /**
     * Enter Request Number on the Search page Submitted tab
     *
     * @param reqNumberInput
     */
    public void enterRequestNumber(String reqNumberInput) {
        log.warn("Enter " + reqNumberInput + " Request number on the Prior Auth page Submitted");
        TestUtils.waitElement(driver, authNumberInputSearch);
        TestUtils.highlightElement(driver, authNumberInputSearch);
        driver.findElement(authNumberInputSearch).clear();
        driver.findElement(authNumberInputSearch).sendKeys(reqNumberInput);
    }

    /**
     * Enter Request Number on the Search page Submitted tab
     *
     * @param reqNumberInput
     */
    public void enterRequestNumberOC(String reqNumberInput) {
        log.warn("Enter " + reqNumberInput + " Request number on the Prior Auth page Submitted");
        TestUtils.waitElement(driver, authNumberInputSearchOC);
        TestUtils.highlightElement(driver, authNumberInputSearchOC);
        driver.findElement(authNumberInputSearchOC).clear();
        driver.findElement(authNumberInputSearchOC).sendKeys(reqNumberInput);
    }

    /**
     * Click Search on the Submitted Tab
     */
    public PriorAuthorizationSearchSubmittedPage clickSearchSubmitted() {
        log.warn("Click Search on the Submitted Tab");
        TestUtils.safeClick(driver, searchSubmitted);
        TestUtils.wait(5);
        return this;
    }


    /**
     * Click Clear on the Submitted Tab
     */
    public PriorAuthorizationSearchSubmittedPage clickClearSubmitted() {
        log.warn("Clicking Clear on the Submitted Search page");
        TestUtils.waitElement(driver, clearSubmitted);
        driver.findElement(clearSubmitted).click();
        TestUtils.wait(2);
        return this;
    }


    /**
     * Getting All values from Request Number column and checking for txt.
     * At list one element have to match
     *
     * @param elem
     */
    public PriorAuthorizationSearchSubmittedPage checkColumnElements_RequestNumber_SearchSubmitted(String elem) {
        log.warn("Checking " + elem + " values in the Request Number column");
        List<WebElement> column = driver.findElements(requestNumberColumnElements);
        String tmp = "none";
        boolean res = false;

        for (WebElement e : column) {
            tmp = e.getText().trim();
            TestUtils.highlightElement(driver, e);
            if (tmp.equals(elem)) res = true;
        }

        Assert.assertTrue("Element " + elem + " is not present.", res);
        return this;
    }

    /**
     * Getting All values from Memer Name and checking for txt. Submitted Page
     * At list one match
     *
     * @param elem
     */
    public PriorAuthorizationSearchSubmittedPage checkColumnElements_MemberName_SearchSubmitted(String elem) {
        log.warn("Getting All values from Memer Name and checking for " + elem + " Member Name.");
        List<WebElement> column = driver.findElements(memberNameColumnElements);
        String tmp = "none";
        boolean res = false;

        //Checking that at list one element is present
        for (WebElement e : column) {
            tmp = e.getText().trim();
            if (tmp.contains(elem)) res = true;
        }

        Assert.assertTrue("Element " + elem + " is not present.", res);
        return this;
    }

    /**
     * Getting All values from Subscriber ID and checking for txt. Submitted page
     *
     * @param elem
     */
    public PriorAuthorizationSearchSubmittedPage checkColumnElements_SubID_SearchSubmitted(String elem) {
        List<WebElement> column = driver.findElements(subscriberIDColumnElements);
        String tmp = "none";
        boolean res = false;

        //Checking that at list one element is present
        for (WebElement e : column) {
            tmp = e.getText().trim();
            if (tmp.contains(elem)) res = true;
        }

        Assert.assertTrue("Element " + tmp + " is not present. Expected " + elem, res);
        return this;
    }

    /**
     * Click Everything for TIN XXXXXX radio button Submitted page
     */
    public PriorAuthorizationSearchSubmittedPage clickEverythingByTinSub() {
        if (TestUtils.isElementVisible(driver, everythingByTinSub)) {
            TestUtils.click(driver, everythingByTinSub);
        }
        return this;
    }

    /**
     * Check that all 4 elements in Pagination are disabled. Submitted
     */
    public PriorAuthorizationSearchSubmittedPage checkDisabledPagination() {
        int numOfElements = driver.findElements(paginationDisabled).size();
        Assert.assertTrue("Not all elements in Pagination are disabled", numOfElements >= 4);
        TestUtils.highlightElement(driver, paginationDisabled);
        return this;
    }

    /**
     * Counting number of elements in the name column Submitted
     *
     * @return
     */
    public int getNumberOfElementsSubmitted() {
        int numOfElements = driver.findElements(memberNameColumnElements).size();
        return numOfElements;
    }

    /**
     * Selecting option from Providers Drop-down. Submitted Tab
     *
     * @param item
     * @return
     */
    public PriorAuthorizationSearchSubmittedPage selectCareProvider(String item) {
        TestUtils.waitElement(driver, providersDropDown);
        TestUtils.highlightElement(driver, providersDropDown);

        TestUtils.wait(2);
        Select dropdown = new Select(driver.findElement(providersDropDown));
        dropdown.selectByVisibleText(item);
        TestUtils.wait(2);
        return this;
    }

    /**
     * Check CheckBox Urgent requests only
     * Skip if checked
     */
    public PriorAuthorizationSearchSubmittedPage checkCheckBoxUrgentRequests() {
        TestUtils.waitElement(driver, urgentRequestsChkBx);

        TestUtils.highlightElement(driver, urgentRequestsChkBx);
        if (!driver.findElement(urgentRequestsChkBx).isSelected())
            driver.findElement(urgentRequestsChkBx).click();
        return this;
    }

    /**
     * Check That element Has Urgent Flag Submitted tab
     *
     * @return
     */
    public PriorAuthorizationSearchSubmittedPage checkUrgentFlagSubmittedWidget(String elem) {
        By urgentFlag = By.xpath("//*[@id='hscSearchTableSubmittedID']//span[text()='" + elem
                + "']/../span[contains(@class,'cux-icon-warning_hollow_filled')]");
        TestUtils.waitElement(driver, urgentFlag);
        TestUtils.highlightElement(driver, urgentFlag);
        return this;
    }

    /**
     * Click Action on document icon by Request number.
     *
     * @param reqNum
     * @return
     */
    public PriorAuthorizationSearchSubmittedPage clickDocumentIconByRequestNumber(String reqNum) {
        log.warn("Clicking on Document Icon for " + reqNum + "Request num");
        TestUtils.demoBreakPoint(scenario, driver, "Historical Search for:" + reqNum);
        By docActionIcon = By.xpath("//span[text()='" + reqNum + "']/../..//span[contains(@class,'cux-icon-document')] | //a[text()='" + reqNum + "']/../..//span[contains(@class,'cux-icon-document')]");
        TestUtils.click(driver, docActionIcon);
        TestUtils.wait(5);
        return this;
    }


    /**
     * Click Action edit icon by Request number.
     *
     * @param reqNum
     * @return
     */
    public PriorAuthorizationSearchSubmittedPage clickEditIconByRequestNumber(String reqNum) {
        log.warn("Clicking on Edit Icon for " + reqNum + "Request num");
        By docActionIcon = By.xpath("//*[@id='hscSearchTableSubmittedID']/tbody//span[text()='" + reqNum
                + "']/../..//span[contains(@class,'cux-icon-edit')]");
        TestUtils.highlightElement(driver, docActionIcon);
        driver.findElement(docActionIcon).click();
        TestUtils.wait(2);
        return this;
    }

    /**
     * Verifying the status on Prior auth Search Submitted page
     */
    public PriorAuthorizationSearchSubmittedPage checkColumnElements_Status_SearchSubmitted(String status, String reqNum) {
        By statusXpath = By.xpath("//span[text()='" + reqNum + "']/..//following-sibling::td[3] | //a[text()='" + reqNum + "']/..//following-sibling::td[3]");
        log.warn("Checking status of authorization");
        log.warn("status is" + status);
        Assert.assertTrue("verfiying status is not " + status, driver.findElement(statusXpath).getText().contains(status));
        return this;
    }

    /**
     * Verifying the status as Completed
     */
    public PriorAuthorizationSearchSubmittedPage checkColumnElements_Status_SearchSubmitted() {
        log.warn("Checking status of authorization as completed on Search submitted page");
        List<WebElement> column = driver.findElements(statusColumnElements);
        int resultSize = column.size();
        Assert.assertEquals("search results have more than 1 auth", resultSize, 1);
        Assert.assertEquals("Status is not completed", column.get(0).getText(), "Completed");
        return this;
    }

    /**
     * Verifying that End date is not present on search submitted page
     */
    public PriorAuthorizationSearchSubmittedPage checkColumnElements_EndDate_SearchSubmitted() {
        log.warn("Checking End Date is not present for the authorization");
        List<WebElement> column = driver.findElements(endDateColumnElements);
        int resultSize = column.size();
        Assert.assertEquals("search results have more than 1 auth", 1, resultSize);
        Assert.assertEquals("End Date is present for the auth", "-", column.get(0).getText());
        return this;
    }

    /**
     * Selects Status dropdown
     */
    public void selectsStatusDropdown() {
        log.warn("Selecting the status dropdown");
        TestUtils.waitElement(driver, statusSelector);
        TestUtils.highlightElement(driver, statusSelector);
        driver.findElement(statusSelector).click();
    }

    /**
     * Verifies Status option is not present under status dropdown
     */
    public void VerifyOptionNotPresentUnderStatusDropdown(String elem) {
        log.warn("verifying that option " + elem + "is not present under status dropdown");
        List<WebElement> column = driver.findElements(statusDropdownValues);
        String tmp = "none";
        boolean res = true;

        for (WebElement e : column) {
            tmp = e.getText().trim();
            if (tmp.equals(elem)) res = false;
        }

        Assert.assertTrue("Element " + elem + " is present.", res);
    }

    /**
     * Click Action document icon by Status on Prior Auth Submitted page.
     *
     * @param Status
     * @return
     */
    public void clickDocumentIconByStatus(String Status) {
        log.warn("Clicking on Document Icon for " + Status + "Request num");
        By docActionIcon = By.xpath("//*[@id='hscSearchTableSubmittedID']/tbody//span[text()='" + Status
                + "']/../..//span[contains(@class,'cux-icon-document')]");
        TestUtils.highlightElement(driver, docActionIcon);
        driver.findElement(docActionIcon).click();
        TestUtils.wait(2);
    }

    public static By cloneIcon(String authNumber) {
        return By.xpath(searchResultXpath + "//tr[./td[.='" + authNumber + "']]/td[1]//span[@ng-click='hscSearchTableSubmitted.cloneRecord(record)']|" +
                "//table[@id='hscSearchTableSubmittedID']//td[contains(.,'" + authNumber + "')]/preceding-sibling::td[1]//span[@ng-click='hscSearchTableSubmitted.cloneRecord(record)']");
    }

    public static By selectIcon(String authNumber) {
        return By.xpath(searchResultXpath + "//tr[./td[.='" + authNumber + "']]/td[1]//span[@ng-click='hscSearchTableSubmitted.selectRecord(record)']");
    }

    public static By editIcon(String authNumber) {
        return By.xpath(searchResultXpath + "//tr[./td[.='" + authNumber + "']]/td[1]//span[@ng-click='hscSearchTableSubmitted.editRecord(record)']");
    }

    public static By cloneIcon(int row) {
        return By.xpath(searchResultXpath + "/tbody/tr[" + row + "]/td[1]//span[@ng-click='hscSearchTableSubmitted.cloneRecord(record)']");
    }

    public static By selectIcon(int row) {
        return By.xpath(searchResultXpath + "/tbody/tr[" + row + "]/td[1]//span[@ng-click='hscSearchTableSubmitted.selectRecord(record)']");
    }

    public static By editIcon(int row) {
        return By.xpath(searchResultXpath + "/tbody/tr[" + row + "]/td[1]//span[@ng-click='hscSearchTableSubmitted.editRecord(record)']");
    }


    /**
     * Storing tin on Prior Auth Submitted search page.
     */
    public void storeTINonPriorAuthSearchSubmit() {
        log.warn("Storing TIN on Prior Auth Search");
        String tinText = driver.findElement(paanTin).getText();
        TestUtils.highlightElement(driver, paanTin);
        String tin = tinText.substring(tinText.length() - 9);
        gv.setpaanTIN(tin);
        log.warn("Tin Stored:" + tin);
    }

    /**
     * Compare Total Records and confirm that it matches DB results for TIN
     */
    public void TotalRecordsMatchDBforTIN(String authType) {
        log.warn("Compare Total Records and confirm that it matches DB results for TIN");
        String totalRecordsFull = driver.findElement(totalRecords).getText();
        TestUtils.highlightElement(driver, totalRecords);
        int recordCountUI = Integer.parseInt(totalRecordsFull.substring(totalRecordsFull.indexOf(":") + 2));

        int actualRecordCount = 0;

        try {
            actualRecordCount = OcmMBMDao.getDao().getTotalRecordsOnPriorAuthSearch(authType);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        Assert.assertEquals(recordCountUI, actualRecordCount);

    }


    /**
     * Verify Clone Icon is not present Prior Auth Search
     */
    public void verifyCloneIconLocatorNoPresent() {
        log.warn("Verify Clone Icon is not present Prior Auth Search");
        By cloneIcon = By.xpath(searchResultXpath + "//td[contains(.,'" + gv.getRequestNumber() + "')]/preceding-sibling::td[1]//span[@title='Clone Request']");
        Assert.assertFalse("Clone Icon is present", (TestUtils.isElementPresent(driver, cloneIcon)));
    }


    /**
     * Verify  search fields on PriorAuth search Page
     */
    public void verifyLabelPresentOnPriorAuthSearchPage(List<String> labelValues, String tab) {

        for (int i = 0; i < labelValues.size(); i++) {
            By searchLabel = By.xpath("//div[@id='" + tab + "Panel']//td[contains(text(),'" + labelValues.get(i) + "')]");
            Assert.assertTrue("Label value is missing " + labelValues.get(i), driver.findElement(searchLabel).isDisplayed());
        }

    }

    /**
     * select payer
     */
    public void selectPayer(String payerValue) {
        By payerDropdown = By.xpath("//select[@ng-model='selectPayer.payers']");
        TestUtils.select(new Select(driver.findElement(payerDropdown)), payerValue);

    }

    /**
     * Verify  search fields on PriorAuth search Page
     */
    public void verifyLabelNotPresentOnPriorAuthSearchPage(List<String> expectedLabelvalues) {
        for (int i = 0; i < expectedLabelvalues.size(); i++) {
            By searchLabel = By.xpath("//td[contains(text(),'" + expectedLabelvalues.get(i) + "')]");
            Assert.assertFalse("Dropdown value is missing " + expectedLabelvalues.get(i), TestUtils.isElementPresent(driver, searchLabel));
        }
    }

    /**
     * Verify  recordcount with db
     */
    public int verifyRecordCount(String tab, List<Map<String, String>> criteriavalues) {
        int recordCountUI = 0;
        String totalRecordsFull;
        By totalRecords = By.xpath("//*[@ng-if='hscSearchTable" + tab + ".pagination.totalRecordsCount']");
        switch (tab) {
            case "Submitted":
                log.warn("Compare Total Records and confirm that it matches DB results for TIN");
                TestUtils.waitElement(driver, totalRecords);
                totalRecordsFull = driver.findElement(totalRecords).getText();
                TestUtils.highlightElement(driver, totalRecords);
                recordCountUI = Integer.parseInt(totalRecordsFull.substring(totalRecordsFull.indexOf(":") + 2));
                log.warn(recordCountUI + "is recordcount");
                break;
            case "Drafts":
                log.warn("Compare Total Records and confirm that it matches DB results for TIN");
                TestUtils.waitElement(driver, totalRecords);
                totalRecordsFull = driver.findElement(totalRecords).getText();
                TestUtils.highlightElement(driver, totalRecords);
                recordCountUI = Integer.parseInt(totalRecordsFull.substring(totalRecordsFull.indexOf(":") + 2));
                log.warn(recordCountUI + "is recordcount");
                break;
            case "Converted Authorizations":
                break;
        }
        return recordCountUI;
    }

    /**
     * Verify  dropdown is not present on prior auth search page
     */
    public void verifyDropdownisNotPresentOnPriorAuthSearchPage() {

        log.warn("Verifies Payer dropdown is  not displayed on Prior Auth search page");
        Assert.assertFalse("Payer dropdown is  displayed on Prior Auth search page", TestUtils.isElementPresent(driver, payerLabel));
    }

    /**
     * Verify  records retrieved are specific to payer
     */
    public void verifyRecordsRetrieved(String payer, String tab) {
        By totalRecords = By.xpath("//*[@ng-if='hscSearchTable" + tab + ".pagination.totalRecordsCount']");
        String totalRecordsFull = driver.findElement(totalRecords).getText();
        TestUtils.highlightElement(driver, totalRecords);
        int recordCountUI = Integer.parseInt(totalRecordsFull.substring(totalRecordsFull.indexOf(":") + 2));
        for (int i = 1; i <= recordCountUI; i++) {
            By retrivedrow = By.xpath("//div[@id='" + tab + "Panel']//tbody[@class='ng-scope']//tr[" + i + "]/td[2]/span[1]");
            Assert.assertTrue("recoeds are not same", driver.findElement(retrivedrow).getText().equalsIgnoreCase(payer));
        }
    }

    /**
     * Verify  payer dropdown values
     */
    public void verifyPayer(String payer) {
        By payerDropdown = By.xpath("//select[@ng-model='selectPayer.payers']");
        Assert.assertTrue("Payer is not selected as given ", TestUtils.getSelectedValueFromDropdown(driver, payerDropdown).equalsIgnoreCase(payer));
    }

    public void verifyRestrictDisplayedInPrioAuth(String section){
        String id = "";
        section = section.toUpperCase();
        switch(section){
            case "SUBMITTED": {
                id = "hscSearchTableSubmittedID";
                break; }
            case "DRAFTS": {id = "hscSearchTableDraftsID";
                break;}
            case "PROVIDER HISTORY" : {id="hscSearchTableProviderHistoryID";
                break;}
            case "HISTORY" : {id= "hscSearchTableHistoryID";
                break; }
        }
        String xpath = "//table[@id='"+id+"']//span[@class='maskedRowText']";
        List<WebElement> message = driver.findElements( By.xpath(xpath));
        List<String> restrictedMessageDisplayed = new ArrayList<String>();
        System.out.println(" Verifying Restricted Policies Message:");
        message.forEach(i -> restrictedMessageDisplayed.add(i.getText().trim()));
        System.out.println(restrictedMessageDisplayed);
        Assert.assertTrue(restrictedMessageDisplayed.contains("This entry cannot be viewed due to insufficient security privileges."));
    }

    public void verifyRestrictNotDisplayedInPrioAuth(String section) {
        String id = "";
        section = section.toUpperCase();
        switch (section) {
            case "SUBMITTED": {
                id = "hscSearchTableSubmittedID";
                break;
            }
            case "DRAFTS": {
                id = "hscSearchTableDraftsID";
                break;
            }
            case "PROVIDER HISTORY": {
                id = "hscSearchTableProviderHistoryID";
                break;
            }
            case "HISTORY": {
                id = "hscSearchTableHistoryID";
                break;
            }
        }
        By restrictedMessageXpath = By.xpath("//table[@id='" + id + "']//span[@class='maskedRowText']");
        By noRecordsXpath = By.xpath("//table[@id='" + id + "']//td[contains(text(),'Please update your search criteria and try again.')]");
        TestUtils.wait(5);
        if (!(TestUtils.isElementPresent(driver, restrictedMessageXpath))) {
            log.warn("Verifying whether all records displayed ");
            TestUtils.wait(5);
            Assert.assertFalse("Restricted Policy message displayed", TestUtils.isElementVisible(driver, restrictedMessageXpath));
            Assert.assertFalse("No records message displayed", TestUtils.isElementVisible(driver, noRecordsXpath));
        }
    }

    public void clickFirstRecordInPriorAuthSearch(String section) {
        String id = "";
        section = section.toUpperCase();
        switch (section) {
            case "SUBMITTED": {
                id = "hscSearchTableSubmittedID";
                break;
            }
            case "DRAFTS": {
                id = "hscSearchTableDraftsID";
                break;
            }
            case "PROVIDER HISTORY": {
                id = "hscSearchTableProviderHistoryID";
                break;
            }
            case "HISTORY": {
                id = "hscSearchTableHistoryID";
                break;
            }
        }
        By recordXpath = By.xpath("//table[@id='"+id+"']//tr[@class='ocmTableRow ng-scope'][1]//td[3]");
        TestUtils.isElementVisible(driver,recordXpath);
        TestUtils.wait(3);
        TestUtils.click(driver,recordXpath);
        TestUtils.wait(5);
    }

    public void selectBenefitTypeSubmitted(String benefitType){
        By benefitTypeDropdownXpath = By.xpath("//button[@aria-label='hscSearchSubmittedBenefitType_label'and contains(text(),'None Selected')]");
        if (TestUtils.isElementVisible(driver, benefitTypeDropdownXpath)) {
            TestUtils.click(driver, benefitTypeDropdownXpath);
            TestUtils.wait(3);
            By benefitTypeXpath = By.xpath("//span[@class='tk-multi-label ng-binding' and contains(text(),'" + benefitType + "')]");
            TestUtils.click(driver, benefitTypeXpath);
            TestUtils.wait(3);
        }
    }


    public String getTherapyAuthorizationByOverallStatus(String authOverallStatus)
    {
        //Retrieve HSC Custom Reasons from Db using existing HSCDao method
        String therapyRequestNumber = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectTherapyAuthWithReasonByStatus(authOverallStatus);

        return therapyRequestNumber;
    }

    public void selectAllBenefitType(){
        By benefitTypeDropdownXpath = By.xpath("//button[@aria-label='hscSearchSubmittedBenefitType_label'and contains(text(),'None Selected')]");
        Assert.assertTrue(TestUtils.isElementVisible(driver,benefitTypeDropdownXpath));
        TestUtils.click(driver,benefitTypeDropdownXpath);
        TestUtils.wait(3);
        By benefitTypeXpath =By.xpath("//button[@class='tk-help-btn tk-help-btnAll ng-binding ng-scope']");
        TestUtils.click(driver,benefitTypeXpath);
        TestUtils.wait(3);
    }

    public void validateAuthStatus(List<String> authList) {
        for (int i = 0; i < authList.size(); i++) {
            System.out.println(authList.get(i));
            enterRequestNumber(authList.get(i));
            clickSearchSubmitted();
            TestUtils.wait(5);
            WebElement authStatus = driver.findElement(By.xpath("//table[@id='hscSearchTableSubmittedID']//tbody//tr[1]//td[6]"));
            Boolean value = !authList.get(i).contains("Draft");
            Assert.assertTrue("expected and actual match at index " + i, value);
        }
    }

    public void clickFilterSubmitted(){
        By searchBtn = By.xpath("//input[@ng-click='hscSearchTableSubmitted.applyTableFiltersOnClick(hscSearchTableSubmittedFormtableFilters)']");
        TestUtils.click(driver,searchBtn);
        TestUtils.wait(3);
    }

    /**
     * Select status by clicking on Status drop-down and selecting element.
     *
     * @param status
     */
    public void selectOverallStatusDropDwn(String status) {
        // Modified the ng-model.
        log.warn("Select Overall Status: " + status);
        TestUtils.wait(1);
        TestUtils.waitElement(driver, statusTkMultiSel);
        TestUtils.highlightElement(driver, statusTkMultiSel);
        driver.findElement(statusTkMultiSel).click();

        By dropDwnOption = By.xpath("//span[@ng-model='hscSearchTableSubmitted.tableFilters.hscOverallStatusType']//span[text()='" + status + "']");
        TestUtils.highlightElement(driver, dropDwnOption);
        driver.findElement(dropDwnOption).click();
        TestUtils.wait(1);
        driver.findElement(statusTkMultiSel).click();
    }

    /**
     * Select AuthType ( Request Type) by clicking on Request Type drop-down and selecting specific Authtype.
     *
     * @param authType
     */
    public void selectAuthTypeDropDwn(String authType) {
        // Modified the ng-model.
        log.warn("Select Request Type : " + authType);
        TestUtils.wait(1);
        TestUtils.waitElement(driver, authTypeDropDwn);
        TestUtils.highlightElement(driver, authTypeDropDwn);
        driver.findElement(authTypeDropDwn).click();

        By dropDwnOption = By.xpath("//span[@ng-model='hscSearchTableSubmitted.tableFilters.authorizationType']//span[text()='" + authType + "']");
        TestUtils.highlightElement(driver, dropDwnOption);
        driver.findElement(dropDwnOption).click();
        TestUtils.wait(3);
        driver.findElement(authTypeDropDwn).click();
    }

    /**
     * Select benefit type by clicking on Benefit Type drop-down and selecting element.
     * @param benefitType
     */
    public void selectBenefitTypeDropDwn(String benefitType) {
        log.warn("Select BenefitType as : " + benefitType);
        TestUtils.wait(1);
        TestUtils.waitElement(driver, benefitTypeDropDwn);
        TestUtils.highlightElement(driver, benefitTypeDropDwn);
        driver.findElement(benefitTypeDropDwn).click();

        By dropDwnOption = By.xpath("//span[contains(@ng-model,'selectBenefit.benefitTypes')]//span[text()='" + benefitType + "']");
        TestUtils.highlightElement(driver, dropDwnOption);
        driver.findElement(dropDwnOption).click();
        TestUtils.wait(1);
        driver.findElement(benefitTypeDropDwn).click();
    }

    /**
     *
     * @param flagStatus
     */
    public void clickPriorAuthSearchPageFilterButton(String flagStatus) {
        TestUtils.wait(1);
        By btnFilter = By.xpath("//input[@type='button' and @ng-click='applySubmittedAuthSearchFilters(authSearchForm)']");
        boolean flag =false;

        if("true".equalsIgnoreCase(flagStatus)) {
            flag=true;
            TestUtils.click(driver, btnFilter);
            Assert.assertTrue("Click on the Filter Button on Prior Auth Search button ",flag==true);
        }
        else {
            flag=true;
            TestUtils.click(driver,searchSubmitted);
            Assert.assertTrue("Click on the Search Button on Prior Auth Search Button ",flag==true);
        }
    }

    /**
     *
     * @param tabName
     * @param flagStatus
     */

    public void clickPriorAuthSearchPageTabButton(String tabName,String flagStatus) {
        boolean flag =false;
        By btnTab = By.xpath("//ul[@role='tablist']//li//span[text()='"+tabName+"']");

        if("true".equalsIgnoreCase(flagStatus)) {

            TestUtils.click(driver, btnTab);
            flag=true;
            Assert.assertTrue("Click on the Filter Button on Prior Auth Search button ",flag==true);
        }
    }

    /**
     *
     * @param MemberIDTextValue
     */
    public void setSubscriberIDPriorAuthSubmittedPage (String MemberIDTextValue) {

        By inpSubcriberID = By.id("hscSearchSubmittedMemberId");
        TestUtils.clearTextBox(inpSubcriberID,driver);
        TestUtils.input(driver,inpSubcriberID,MemberIDTextValue);
    }


    public void selectStatusDropdown (String OverallStatus) {
        By drpBtn = By.xpath("//button[contains(@name,'btn-hscSearchSubmittedOverallStatusType')]");
        By selectBenefitsTypeValue = By.xpath("//input[@type='checkbox' and @data-title='"+OverallStatus+"']/following-sibling::span[1]");
        TestUtils.click(driver, drpBtn);
        TestUtils.wait(1);
        TestUtils.click(driver, selectBenefitsTypeValue);

    }






}
