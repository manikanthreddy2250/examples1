package atdd.test.pageobjects.regimenMaintenance;

import atdd.test.stepdefinitions.RegimenMaintenance.DiseaseTraversalMicroServicesStepDefination;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Assert;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class DiseaseTraversalMicroServices extends DiseaseTraversalMicroServicesStepDefination{
    public static String getValueByJpath(JSONObject responseJson, String jpath) {
        Object obj = responseJson;
        for (String s : jpath.split("/"))
            if (!s.isEmpty()) {
                if (!(s.contains("[") || s.contains("]")))
                    obj = ((JSONObject) obj).get(s);
                else if (s.contains("[") || s.contains("]")) {
                    obj = ((JSONArray) ((JSONObject) obj).get(s.split("\\[")[0])).get(Integer.parseInt(s.split("\\[")[1].replace("]", "")));
                }

            }

        return obj.toString();
    }
    public void elasticSearchApi() throws IOException {

        Properties prop = new Properties();
        try {
            FileInputStream ip = new FileInputStream(System.getProperty("user.dir") + "/mbm-atdd-common/src/main/resources/apiTemplates/Capability_ElasticSearch/ElasticConfig.properties");
            prop.load(ip);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        String serviceUrl = prop.getProperty("service_url");
        String apiUrl = prop.getProperty("api_url");

        String url = serviceUrl + apiUrl;

        System.out.println("Endpoint that we hitting ---->" + url);
        //1.Get method
        CloseableHttpClient httpClient = HttpClients.createDefault();
        HttpGet httpGet = new HttpGet(url);

        CloseableHttpResponse closeableHttpResponse = httpClient.execute(httpGet);

        //2.Status code
        int statusCode = closeableHttpResponse.getStatusLine().getStatusCode();
        System.out.println("StatusCode ----> " + statusCode);


//       //3. Json Response
        String jsonResponse = EntityUtils.toString(closeableHttpResponse.getEntity(), "UTF-8");
        JSONObject responseJson = new JSONObject(jsonResponse);
//        System.out.println("Response from Json -----> "+responseJson);

        //3. Json Response
//       String jsonResponse= EntityUtils.toString(closeableHttpResponse.getEntity(),"UTF-8");
//        //JSONObject responseJson=new JSONObject(jsonResponse);
//        JSONArray jsonArray = new JSONArray(jsonResponse);
//        for(int i=0; i<jsonArray.length(); i++) {
//            JSONObject obj = jsonArray.getJSONObject(i);
//
//            String treatmentRegimenID = obj.getString("treatementRegimenID");
//            String treatmentRegimenName = obj.getString("treatmentRegimenName");
//
//            System.out.println("treatmentRegimenID ->>> " + treatmentRegimenID);
//            System.out.println("treatmentRegimenName ->>>" + treatmentRegimenName);
//
//        }
        //5. test utility

        String imed_out = getValueByJpath(responseJson, "/hits/hits[0]/_source/treatmentRegimens");
        System.out.println("treatmentRegimenID ->>> " + imed_out);

    }

    public static void elasticSearchApiQuery() throws IOException {

        Properties prop = new Properties();
        try {
            FileInputStream ip = new FileInputStream(System.getProperty("user.dir") + "/mbm-atdd-common/src/main/resources/apiTemplates/Capability_ElasticSearch/ElasticConfig.properties");
            prop.load(ip);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        //Getting the URL
        String serviceUrl = prop.getProperty("service_url");
        String apiUrl = prop.getProperty("api_url");
        String url = serviceUrl + apiUrl;
        System.out.println("Endpoint that we hitting ---->" + url);

        //Getting the ElasticSearchQuery Json file
        FileInputStream json = new FileInputStream(System.getProperty("user.dir") + "/mbm-atdd-common/src/main/resources/apiTemplates/Capability_ElasticSearch/ElasticSearchQuery.json");
        String entitSet;

        //1.POST method
        CloseableHttpClient httpClient = HttpClients.createDefault();
        HttpPost httppost = new HttpPost(url);
        CloseableHttpResponse closeableHttpResponse = httpClient.execute(httppost);

        //2.Status code
        int statusCode = closeableHttpResponse.getStatusLine().getStatusCode();
        System.out.println("StatusCode ----> " + statusCode);


//       //3. Json Response
        String jsonResponse = EntityUtils.toString(closeableHttpResponse.getEntity(), "UTF-8");
        JSONObject responseJson = new JSONObject(jsonResponse);
//        System.out.println("Response from Json -----> "+responseJson);

        //3. Json Response
//       String jsonResponse= EntityUtils.toString(closeableHttpResponse.getEntity(),"UTF-8");
//        //JSONObject responseJson=new JSONObject(jsonResponse);
//        JSONArray jsonArray = new JSONArray(jsonResponse);
//        for(int i=0; i<jsonArray.length(); i++) {
//            JSONObject obj = jsonArray.getJSONObject(i);
//
//            String treatmentRegimenID = obj.getString("treatementRegimenID");
//            String treatmentRegimenName = obj.getString("treatmentRegimenName");
//
//            System.out.println("treatmentRegimenID ->>> " + treatmentRegimenID);
//            System.out.println("treatmentRegimenName ->>>" + treatmentRegimenName);
//
//        }
        //5. test utility

        String imed_out = getValueByJpath(responseJson, "/hits/hits[0]/_source/treatmentRegimens[0]");
        System.out.println("treatmentRegimenID ->>> " + imed_out);

    }

    public static void userValidatesResponse(String sourceString, String treatmentRegimenID, String treatmentRegimeName)
    {

        JSONObject responseJson=jsonResponse(sourceString);
        String output = getValueByJpath(responseJson, "/content");
        System.out.println("Output after extracting ->>>> " + output );
        Assert.assertTrue("Did not find the Treatment Regimen and Treatment Regimen ID",output.contains(treatmentRegimeName) && output.contains(treatmentRegimenID));

    }

    public static void userValidatesResponseNegative(String sourceString, String treatmentRegimenID, String treatmentRegimeName)
    {
        JSONObject responseJson=jsonResponse(sourceString);
        String output = getValueByJpath(responseJson, "/content");
        System.out.println("Output after extracting ->>>> " + output );
        Assert.assertFalse("Did find the Treatment Regimen and Treatment Regimen ID",output.contains(treatmentRegimeName) && output.contains(treatmentRegimenID));
    }
    public static void userValidatesResponseCreate(String sourceString)
    {
        JSONObject responseJson=jsonResponse(sourceString);
        String index = getValueByJpath(responseJson, "/traversals_diseasetype_testv204/settings/index/provided_name");
        Assert.assertTrue("The Travesal Index created doesnt match",index.equalsIgnoreCase("traversals_diseasetype_testv204"));

    }
    public static JSONObject jsonResponse(String sourceString)
    {
        JSONObject responseJson = new JSONObject(sourceString);
        System.out.println("The Response on the Request is ---->>> \n" + responseJson);
        return responseJson;
    }

    public static void userValidatesResponseListClinialAndSource(String sourceString)
    {
        JSONObject responseJson=jsonResponse(sourceString);
        String clinicalVariablesIndication = getValueByJpath(responseJson, "/content[0]/clinicalVariables");
        String treatmentRegimens = getValueByJpath(responseJson, "/content[0]/treatmentRegimens");
        System.out.println("\nThe Clinical variable:"+clinicalVariablesIndication +"\n" +"The Treatmeent Regimens -->> "+treatmentRegimens+"\n" );


    }
    public static void jsonResponseDelete(String sourceString)
    {
        JSONObject responseJson = new JSONObject(sourceString);
        String acknowledgemnet  = getValueByJpath(responseJson, "/acknowledged");
        Assert.assertTrue("Did not match",acknowledgemnet.contains("true"));
    }

    public static String getDocID(String sourceString){
        int i;
        for (i = sourceString.length()-1; i >= 0; i--) {
            if(sourceString.charAt(i) == ' '){
                break;
            }
        }
        return sourceString.substring(i+1,sourceString.length());
    }
}
