package atdd.test.pageobjects.regimenMaintenance;

import atdd.test.core.AbstractStepSet;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.pageobjects.NavigationPage;
import atdd.utils.InvalidSearchCriteriaException;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static atdd.utils.TestUtils.*;

public class EditTraversalLinkagePage extends AbstractStepSet {

    private WebDriver driver;

    private static Logger log = Logger.getLogger(EditTraversalLinkagePage.class);


    private CommonPageObject obj() {
        return new CommonPageObject(scenario(), driver());
    }


    private NavigationPage np = new NavigationPage(driver());

    public EditTraversalLinkagePage(Scenario scenario, WebDriver webDriver) {
        super(scenario, webDriver);
    }

    private By action = By.xpath("//select[@id='editTraversalAction']");
    private By cancerType = By.xpath("//ocm-typeahead[@ng-model='editTraversalSearch.diseaseType']");
    private By multiSelectClinicalVariables = By.xpath("//button[@data-id='Tools.EditTraversalLinkage.QueueNav.ClinicalVariables--groupMultiselect']");
    private By multiSelectRegimenName = By.xpath("//button[@data-id='Tools.EditTraversalLinkage.QueueNav.RegimenName--multiselect']");
    private By pathwayAssignment = By.xpath("//select[contains(@ng-model,'editTraversalSearch.pathwayAssignmentType')]");
    private By payer = By.xpath("//span[@ng-model=\"editTraversalSearch.payer\"]//div[1]/button[@aria-label='payer_label']");
    private By attachButton = By.xpath("//input[@id='attachButton']");
    private By errorMsg = By.xpath("//span[@id='globalMessages-description']/span");
    private By traversalLinkageTable = By.xpath("//table[@id='editTraversalLinkageTableID']");
    private By clientxpath = By.xpath("//button[@data-id='Tools.EditTraversalLinkage.QueueNav.Payer--multiselect']");


    /**
     * Admin User Navigates to Edit Traversal Linkage Page
     * selects all the mandatory fields and attaches the traversal
     *
     * @param maps
     * @throws InvalidSearchCriteriaException
     */
    public void attachTraversal(List<Map<String, String>> maps) throws InvalidSearchCriteriaException {

        if (!driver().getTitle().contains("Edit Traversal Linkage")) {
            np.expandClickPrimaryNav("Tools");
            np.clickOptionFromTopNavMenu("Edit Traversal Linkage");
            obj().CommonPage.waitForNOTBusyIndicator();
        }

        Map<String, String> map = null;
        for (Map<String, String> m : maps) {
            map = m;


            if (!map.get("Cancer Type").isEmpty()) {
                selectCancerTypeOnEditTraversalLinkagePage(map.get("Cancer Type"));
            }

            if (!map.get("Nested Variables Values").isEmpty()) {
                selectValuesMultiSelectDropdown(multiSelectClinicalVariables, map.get("Nested Variables Values"));
            }

            if (!map.get("Regimen Name").isEmpty()) {
                selectValuesMultiSelectDropdown(multiSelectRegimenName, map.get("Regimen Name"));
            }

            if (map.containsKey("Client")) {
                selectClient(map.get("Client"));
            }

            if (map.containsKey("pathway")) {
                selectPathwayRadioSelectors(map.get("pathway"));
            }

            if (map.containsKey("autoApproved")) {
                selectautoApprovedRadioSelectors(map.get("autoApproved"));
            }


            TestUtils.demoBreakPoint(scenario(), driver(), "searching for traversal");
        }

        obj().CommonPage.userClicksAButton("Apply Link");
    }


    /**
     * Selects Action from dropdown on the Edit Traversal Linkage Page
     */
    public void selectActionOnEditTraversalLinkagePage(String arg1) {
        log.warn(" Select Action from Action dropdown");
        TestUtils.waitElement(driver, action);
        TestUtils.wait(5);
        this.driver().findElement(action).click();
        Select dropdown = new Select(this.driver().findElement(action));
        dropdown.selectByVisibleText(arg1);
        TestUtils.wait(3);
        Assert.assertTrue(arg1 + "is not Selected for Cancer Type", arg1.equals(getSelectedValueFromDropdown(this.driver(), action)));
        TestUtils.demoBreakPoint(scenario(), driver(), "selected value from Action Dropdown");
    }


    /**
     * Selects Cancer Type from dropdown on the Edit Traversal Linkage Page
     */
    public void selectCancerTypeOnEditTraversalLinkagePage(String arg1) {
        log.warn(" Select cancer type from Cancer Type dropdown");
        TestUtils.waitElementVisible(driver, cancerType);
        this.driver().findElement(cancerType).click();
        this.driver().findElement(By.xpath("//a[contains(text(),'" + arg1 + "')]")).click();
        TestUtils.demoBreakPoint(scenario(), driver(), "Select value from Cancer Type dropdown");
    }


    /**
     * Selects Pathway from dropdown on the Edit Traversal Linkage Page
     *
     */
//    public void selectPathwayOnEditTraversalLinkagePage(String arg1) {
//        log.warn(" Select value from Pathway Dropdown dropdown");
//        TestUtils.waitElement(this.driver(), pathway);
//        TestUtils.wait(2);
//        this.driver().findElement(pathway).click();
//        Select dropdown = new Select(this.driver().findElement(pathway));
//        dropdown.selectByVisibleText(arg1);
//        TestUtils.wait(3);
//        Assert.assertTrue(arg1 + "is not Selected for cancer type", arg1.equals(getSelectedValueFromDropdown(this.driver(),pathway)));
//    }


    /**
     * select the MultiSelect Dropdown's Such as Regimen and Clinical Variables
     * on Edit Traversal Linkage Page
     *
     * @param Value
     */
    public void selectValuesMultiSelectDropdown(By by, String Value) {
        log.warn("Select the Nested Variable Value: " + Value);
        WebElement el = this.driver().findElement(by);
        el.click();

        if (Value.contains(";")) {
            String[] value = Value.split(";");
            for (String vv : value) {
                System.out.println("//button[@data-id='Tools.EditTraversalLinkage.QueueNav.ClinicalVariables--groupMultiselect']//following::input[@data-title='" + vv + "']//following::span[@class='tk-multi-tick ng-scope'][1]");
                this.driver().findElement(By.xpath("//button[@data-id='Tools.EditTraversalLinkage.QueueNav.ClinicalVariables--groupMultiselect']//following::input[@data-title='" + vv + "']//following::span[@class='tk-multi-tick ng-scope'][1]")).click();

            }
        } else {
            this.driver().findElement(By.xpath("//button[@data-id='Tools.EditTraversalLinkage.QueueNav.ClinicalVariables--groupMultiselect']//following::input[@data-title='" + Value + "']//following::span[@class='tk-multi-tick ng-scope'][1]")).click();

        }
        el.click();
        TestUtils.demoBreakPoint(scenario(), driver(), "Select value from Multi-select Dropdown");
    }

    /*
      Field validation when Mandatory fields is not selected and Clicked on Attach
     */
    public void fieldValidationAndPopUp(String text, String textMessage, String popup) {

        log.warn("Field level Validation and Pop-Up message");
        String expectedColor = "rgba(169, 60, 71, 1)";
        By elementTxt = By.xpath("//button[@data-id='" + text + "'] ");
        String actualBorderColor = this.driver().findElement(elementTxt).getCssValue("border-bottom-color");
        System.out.println(actualBorderColor);
        Assert.assertTrue("border color does not match", expectedColor.equals(actualBorderColor));

        By fieldValidationTxt = By.xpath("//div[contains(text(),'" + textMessage + "')]|//span[contains(text(),'" + textMessage + "')]");
        Assert.assertEquals(this.driver().findElement(fieldValidationTxt).getText(), textMessage);
        Assert.assertEquals(this.driver().findElement(errorMsg).getText(), popup);
        TestUtils.demoBreakPoint(scenario(), driver(), "Field validation Error");
    }

    /*
      Default values displayed for input fields when user lands on Edit Traversal Linkage Page
     */
    public void editTraversalLinkageFieldsDefaultValues(List<Map<String, String>> maps) {
        Map<String, String> map = null;
        for (Map<String, String> m : maps) {
            map = m;
            String defaultClinicalVariables = text(this.driver(), multiSelectClinicalVariables);
            Assert.assertTrue("Clinical Variables dropdown Default value mismatch", map.get("Clinical Variables").equalsIgnoreCase(defaultClinicalVariables));
            String defaultRegimenValue = text(this.driver(), multiSelectRegimenName);
            Assert.assertTrue("Regimen Name dropdown Default value mismatch", map.get("Regimen Name").equalsIgnoreCase(defaultRegimenValue));
            String defaultPathwayValue = text(this.driver(), clientxpath);
            Assert.assertTrue(" Pathway drodpown Default value mismatch", map.get("Client").equalsIgnoreCase(defaultPathwayValue));

        }
        TestUtils.demoBreakPoint(scenario(), driver(), "Default values of all input fields when user lands on Edit Traversal Linkage page");
    }

    /*
    This method is verify the Link Count is displayed as product of Clinical variables values and Regimens
     */
    public void verifyLinkCountOfTraversalAction() {
        List<Map<String, String>> traversalActionResults = tableAsMaps(this.driver(), "//table[@id='editTraversalLinkageTableID']", 10);
        System.out.println(traversalActionResults);
        System.out.println(traversalActionResults.size());
        String clinical_Description = traversalActionResults.get(0).get("Clinical Description");
        String[] ctvPair = clinical_Description.split("__");
        ArrayList al = new ArrayList(ctvPair.length);
        int Product = 1;
        for (int i = 0; i < ctvPair.length; i++) {
            String[] cvtvv = ctvPair[i].split(":");
            int n = cvtvv.length;
            for (int j = 1; j <= n; j = j + 2) {
                if (cvtvv[j].contains(";")) {
                    String[] Cvv = cvtvv[j].split(";");
                    Product = Cvv.length * Product;
                } else {
                    al.add(cvtvv[j]);
                    Product = al.size() * Product;
                    al.remove(0);
                }

            }
        }

        String regimenName = traversalActionResults.get(0).get("Regimen Name");
        if (regimenName.contains(";")) {
            String[] regimen = regimenName.split(";");
            Product = regimen.length * Product;
        } else {
            al.add(regimenName);
            Product = al.size() * Product;
            al.remove(0);
        }

        String Count = traversalActionResults.get(0).get("Link Count");
        int linkCount = Integer.parseInt(Count);
        System.out.println("Product of Variables and Regimens: " + Product);
        Assert.assertEquals("Link Count is not appropriate", Product, linkCount);
        TestUtils.demoBreakPoint(scenario(), driver(), "verifying the Link Count on the Edit traversal Linkage Page");
    }

    /*
      This method is to select the value from payment Assignment Dropdown
     */
    public void selectPathwayAssignmentDropdown(String assignment) {
        log.warn("Selecting Pathway Assignment on the Edit Traversal Linkage Page");
        TestUtils.waitElement(driver, pathwayAssignment);
        Select dropdown = new Select(this.driver().findElement(pathwayAssignment));
        dropdown.selectByVisibleText(assignment);
        TestUtils.demoBreakPoint(scenario(), driver(), "Selected value from Payment Assignment Dropdown");
    }

    /*
      This method is to find out Payer is Required Field and default Value
      of payer field
     */
    public void payerDropdownIsRequired(String label) {
        log.warn("Verify the Payer dropdown is Required dropdown with Default value as NoneSelected");
        TestUtils.wait(3);
        Assert.assertTrue(label + "not visible on Edit Traversal Linkage page", TestUtils.isElementPresent(this.driver(), By.xpath("//label[contains(text(),'" + label + "')]")));
        Assert.assertTrue(label + "is not a Required Field", TestUtils.isElementVisible(this.driver(), By.xpath("//*[contains(text(),'" + label + "')]/span[@title='Required']")));
        String defaultValue = this.driver().findElement(payer).getText();
        Assert.assertEquals(defaultValue, "None Selected");
        TestUtils.demoBreakPoint(scenario(), driver(), "Payer is Required field");
    }

    /*
      This method is to select value from multi-select Dropdown Payer
     */
    public void selectPayerValue(String Payer) {
        log.warn("Select the value from payer Dropdown");
        TestUtils.wait(3);
        TestUtils.click(this.driver(), payer);
        TestUtils.click(this.driver(), By.xpath("//span[contains(text(), '" + Payer + "')]"));
        TestUtils.demoBreakPoint(scenario(), driver(), "Selected Value from Payer List Box");
    }

    /*
    This method is to verify the Payer Field displays the value selected
     */
    public void verifySelectedValueDisplayed(String value) {
        log.warn("Verify the selected value is displayed for Payer");
        TestUtils.wait(3);
        Assert.assertEquals(value, TestUtils.text(this.driver(), payer));
        TestUtils.demoBreakPoint(scenario(), driver(), "selected value from Multi-select dropdown is visible");
    }

    /*
    This method is to select the Pathway Field Radio Button Yes /No
     */
    public void selectPathwayRadioSelectors(String value) {
        log.warn("User selects the Pathway Radio Selector");
        TestUtils.wait(3);
        TestUtils.click(this.driver(), By.xpath("//input[@data-id='Tools.EditTraversalLinkage.QueueNav.Pathway." + value + "--radiobutton']"));
        TestUtils.demoBreakPoint(scenario(), driver(), "Select Radio Button for the Pathway Field");
    }

    /*
         This method is to verify the Auto-Approved Fields is Enabled and selectable
          */
    public void VerifyAutoapprovedIsEnabled() {
        log.warn("Verify Radio Selector Auto-approved is Enabled");
        TestUtils.wait(3);
        Assert.assertTrue("Auto-approved is not Enabled", this.driver().findElement(By.xpath("//input[@name='Auto Approved']")).isEnabled());
        TestUtils.demoBreakPoint(scenario(), driver(), "Auto-approved field is enabled and selectable");
    }

    /*
    This method is to select the Auto-Approved Radio Button
     */
    public void selectautoApprovedRadioSelectors(String value) {
        log.warn("User selects the Pathway Radio Selector");
        TestUtils.wait(3);
        TestUtils.click(this.driver(), By.xpath("//input[@data-id='Tools.EditTraversalLinkage.QueueNav.Autoapproved." + value + "--radiobutton']"));
        TestUtils.demoBreakPoint(scenario(), driver(), "Select button Yes/No for Auto-approved ");
    }

    /*
       This method is to be verify the new Traversal Action Table on Edit Traversal Linkage Page
        are storing the Pathway fields values appropriately
     */
    public void traversalActionAddedtoTable(String Client, String RegimenName, String pathway, String autoApproved) {

        List<Map<String, String>> traversalActionResults = tableAsMaps(this.driver(), "//table[@id='newEditTraversalLinkageTableID']", 10);
        System.out.println(traversalActionResults);
        System.out.println(traversalActionResults.size());
        String actualAssignmentValue = traversalActionResults.get(0).get("Pathway Client");
        String actualPayerValue = traversalActionResults.get(0).get("Regimen Name");
        String actualPathwayValue = traversalActionResults.get(0).get("Pathway");
        String actualAuto_approvedValue = traversalActionResults.get(0).get("Auto-approved");
        Assert.assertEquals(Client, actualAssignmentValue);
        Assert.assertEquals(RegimenName, actualPayerValue);

        Assert.assertEquals(pathway, actualPathwayValue);
        Assert.assertEquals(autoApproved, actualAuto_approvedValue);


        TestUtils.demoBreakPoint(scenario(), driver(), "Values are stored to Pathway Fields in the Table");
    }

    /*
    This method is to select all the input fields in the Edit Traversal Linkage Page
     */
    public void enterAllMandatoryFields(List<Map<String, String>> maps) {

        Map<String, String> map = null;
        for (Map<String, String> m : maps) {
            map = m;
            selectValuesMultiSelectDropdown(multiSelectClinicalVariables, map.get("Nested Variables Values"));
            selectValuesMultiSelectDropdown(multiSelectRegimenName, map.get("Regimen Name"));
            selectClient(map.get("Client"));
            if (map.containsKey("pathway")) {
                selectPathwayRadioSelectors(map.get("pathway"));
            }
            if (map.containsKey("autoApproved")) {
                selectautoApprovedRadioSelectors(map.get("autoApproved"));
            }

        }
        TestUtils.demoBreakPoint(scenario(), driver(), "Select all the Input Fields on Edit Traversal Linkage Page");
    }

    /*
    This method is to verify the Force Clinical Variables value selection error message text validation
     */
    public void fieldLevelValidation(String message) {
        By fieldValidationTxt = By.xpath("//div[contains(text(),'" + message + "')]|//span[contains(text(),'" + message + "')]");
        Assert.assertEquals(this.driver().findElement(fieldValidationTxt).getText(), message);
        TestUtils.demoBreakPoint(scenario(), driver(), "Field level validation when atleast single clinical value for each variable Type not selected");
    }

    /*
    This method is to verify the behavior of the Clinical Variable dropdown without selecting Values
     */
    public void openAndClosesClinicalVariableDropdown(String text, String textMessage) {
        log.warn("doesn't select a Clinical Variable and closes the dropdown");
        TestUtils.click(driver(), multiSelectClinicalVariables);
        TestUtils.click(driver(), multiSelectClinicalVariables);
        String expectedColor = "rgba(169, 60, 71, 1)";
        By elementTxt = By.xpath("//select[contains(@ng-model,'" + text + "')] | //button[contains(@id,'" + text + "')]/../parent::div");
        String actualBorderColor = this.driver().findElement(elementTxt).getCssValue("border-bottom-color");
        System.out.println(actualBorderColor);
        Assert.assertTrue("border color does not match", expectedColor.equals(actualBorderColor));

        By fieldValidationTxt = By.xpath("//div[contains(text(),'" + textMessage + "')]|//span[contains(text(),'" + textMessage + "')]");
        Assert.assertEquals(this.driver().findElement(fieldValidationTxt).getText(), textMessage);
    }


    /*
      This method is to verify the Pathway Fields that are displaying
       upon Selection of Assign, Remove and None
     */
    public void pathwayFieldDisplay() {
        log.warn("verify the pathway and Auto-Approved Radio selector are displayed");
        TestUtils.wait(3);
        Assert.assertTrue("Pathway Radio selector is not visible", TestUtils.isElementVisible(this.driver(), By.xpath("//div[@id='pathwayField']")));
//        Assert.assertTrue("Auto-Approved Radio selector is not visible", TestUtils.isElementVisible(this.driver(), By.xpath("//label[contains(text(),'Auto-approved')]")));
        Assert.assertTrue("Pathway field is defaulted to Yes", this.driver().findElement(By.xpath("//input[@data-id='Tools.EditTraversalLinkage.QueueNav.Pathway.Yes--radiobutton']")).isSelected());
        Assert.assertTrue("Auto-Approved field is defaulted to Yes", this.driver().findElement(By.xpath("//input[@data-id='Tools.EditTraversalLinkage.QueueNav.Autoapproved.Yes--radiobutton']")).isSelected());
        TestUtils.demoBreakPoint(scenario(), driver(), "Verifying the Pathway Fields displayed upon selection of Assignment");
    }


    public void entertheCriteria(List<Map<String, String>> table) {
        if (!driver().getTitle().contains("Edit Traversal Linkage")) {
            np.expandClickPrimaryNav("Tools");
            np.clickOptionFromTopNavMenu("Traversals & Regimens");

            np.clickOptionFromTopNavMenu("Edit Traversal Linkage");
            obj().CommonPage.waitForNOTBusyIndicator();
        }

        Map<String, String> map = null;
        for (Map<String, String> m : table) {
            map = m;

            selectCancerTypeOnEditTraversalLinkagePage(map.get("Cancer Type"));
            clickSearchButton();
        }

    }

    private void clickSearchButton() {
        By searchxpath = By.xpath("//input[@id='searchLinkingSearchButton']");
        this.driver().findElement(searchxpath).click();
    }

    public void selectClient(String client) {
        WebElement el = this.driver().findElement(clientxpath);
        el.click();
        el.sendKeys(client);
        By cl = By.xpath("//span[contains(text(), '" + client + "')]/../../parent::div");
        this.driver().findElement(cl).click();
        el.click();

    }

    public void deleteTraversal() {
        By deletexpath = By.xpath("//span[@ng-click='deleteDocumentPopupModel.openPopup(record)']");
        TestUtils.waitElementVisible(driver, deletexpath);
        List<WebElement> options = driver.findElements(deletexpath);
        for (WebElement e : options) {
            e.click();
            break;
        }
//        TestUtils.click(driver,deletexpath);
        By popupDelete = By.xpath("//input[@data-id='Tools.EditTraversalLinkage.DeleteLinkModal.Delete–primaryButton']");
        TestUtils.click(driver, popupDelete);
    }
}

