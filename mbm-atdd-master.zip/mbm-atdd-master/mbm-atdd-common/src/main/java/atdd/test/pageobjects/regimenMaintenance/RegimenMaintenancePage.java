package atdd.test.pageobjects.regimenMaintenance;

import atdd.test.shared.BaseCucumber;
import atdd.test.shared.Globals;
import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import static org.openqa.selenium.By.cssSelector;
import static org.openqa.selenium.By.xpath;

public class RegimenMaintenancePage {
    Logger log;
    private WebDriver driver;
    private TestUtils utils;
    Globals gv;


    //Locators--------
    public static By addProcedurePopupHeader = By.xpath("//h2[text()='Add Procedure']");
    public static By procedureDrugBrandLabel = By.xpath("//label[text()='Procedure Drug Brand']");
    public static By procedureCodeDescription = By.xpath("//label[text()='Procedure Code Description']");
    public static By procedureDrugCode = By.xpath("//*[contains(@id, 'record-procedureCode')]");
    public static By procedureDrugBrandXpath = By.xpath("//*[contains(@id, 'record-drugBrandName')]");
    public static By procedureFrequencyLabel = By.xpath("//label[text()='Procedure Frequency']");
    public static By procedureFrequencyXpath = By.xpath("//*[contains(@id, 'record-procedureFrequency')]");
    public static By durationDescription = By.xpath("//*[contains (@id, 'record-procDuration')]");
    public static By drugRouteDropDwn = By.xpath("//*[contains(@id, 'record-medicationAdminRoute')]");
    public static By daysOfCycle = By.xpath("//*[contains(@id, 'record-procDayPerCycle')]");
    public static By therapyTypeDropDwn = By.xpath("//select[@ng-model='record.therapyType']");
    public static By cycleLength = By.xpath("//*[contains(@id, 'record-lengthOfCycle')]");
    public static By cycleCount = By.xpath("//*[contains(@id, 'record-cycleUnit')]");
    public static By dosageXpath = By.xpath("//*[contains(@id, 'record-procUnit')]");
    public static By saveButton = cssSelector("input[ng-click*='regimenVersionProcTableModel'][value='Save']");
    public static By errorMessageOnAddProcedurePopup = By.xpath("//span[contains(@id,'popupGlobalMessages')]/span");


    private WebDriver driver() {
        return driver;
    }

    public RegimenMaintenancePage(WebDriver webDriver) {
        this.driver = webDriver;
        utils = BaseCucumber.utils;
        log = Logger.getLogger(this.getClass().getName());
        gv = BaseCucumber.gv;
    }

    /**
     * Verifying the header on Add Procedure popup
     *
     * @param addProcedureHeader
     */
    public void verifyHeaderTextOfAddProcedurePopUp(String addProcedureHeader) {
        String actualHeader = TestUtils.text(driver, addProcedurePopupHeader);
        log.info("Checking popup header. Header is: " + actualHeader);
        Assert.assertTrue("Header is not matching with " + addProcedureHeader + ". Current header is: " + actualHeader,
                addProcedureHeader.equals(actualHeader));

    }

    /**
     * Verifying Procedure Drug Brand label present in Add Procedure PopUp
     */
    public void verifyProcedureDrugBrandLabel() {
        log.warn("verifying Procedure Drug Brand label present in Add Procedure PopUp");
        Assert.assertTrue("Procedure Drug Brand label is not present in Add Procedure PopUp", TestUtils.isElementPresent(driver, procedureDrugBrandLabel));
        TestUtils.highlightElement(driver, procedureDrugBrandLabel);
    }

    /**
     * Selecting ProcedureCodeType from dropdown
     *
     * @param procedureCodeDropDownValue
     * @param procedureCodeDropDownLabel
     */
    public void chooseProcedureCodeType(String procedureCodeDropDownValue, String procedureCodeDropDownLabel) {
        log.warn("Selecting " + procedureCodeDropDownValue + " from " + procedureCodeDropDownLabel + " on AddProcedurePopUp");
        By by = xpath("//select[@ng-model='record.procCodeType']");
        if (TestUtils.isElementVisible(driver, by)) {
            TestUtils.select(driver, by, procedureCodeDropDownValue);
        }
    }

    /**
     * Entering DrugCode in Add Supportive Drugs PopUp
     *
     * @param procedureCode
     */
    public void enterDrugCode(String procedureCode) {
        log.warn("Entering Drug Code");
        TestUtils.highlightElement(driver, procedureDrugCode);
        driver.findElement(procedureDrugCode).sendKeys(procedureCode);
        By drugCodeDropDown = By.xpath("  //a[contains(@title,'" + procedureCode + "')]");
        TestUtils.wait(3);
        TestUtils.wait(2);
        driver.findElement(drugCodeDropDown).click();

    }

    /**
     * selecting procedure Drug Brand in Add Procedure PopUp
     *
     * @param procedureDrugBrand
     */
    public void selectProcedureDrugBrand(String procedureDrugBrand) {
        log.warn("Select " + procedureDrugBrand + " value from procedure Drug Brand from the type-ahead Drop-down");
        TestUtils.highlightElement(driver, procedureDrugBrandXpath);
        driver.findElement(procedureDrugBrandXpath).sendKeys(procedureDrugBrand);
        By drugBrandDropDown = By.xpath("//a[contains(@title,'" + procedureDrugBrand + "')]");
        TestUtils.wait(3);
        TestUtils.wait(2);
        driver.findElement(drugBrandDropDown).click();
    }


    /**
     * Entering Procedure Frequency in Add Prccedure Drugs PopUp
     *
     * @param procedureFrequency
     */
    public void enterProcedureFrequency(String procedureFrequency) {
        log.warn("Entering ProcedureFrequency");
        TestUtils.highlightElement(driver, procedureFrequencyXpath);
        driver.findElement(procedureFrequencyXpath).sendKeys(procedureFrequency);

    }

    /**
     * Entering procedureDurationDescription in Add Procedure  PopUp
     *
     * @param procedureDurationDescription
     */
    public void enterProcedureDurationDescription(String procedureDurationDescription) {
        log.warn("Entering procedureDurationDescription");
        TestUtils.highlightElement(driver, durationDescription);
        driver.findElement(durationDescription).sendKeys(procedureDurationDescription);
    }

    /**
     * selecting drugRoute in Add Procedure PopUp
     *
     * @param drugRoute
     */
    public void selectDrugRoute(String drugRoute) {
        log.warn("Select " + drugRoute + " value from Drug RouteDrop-down");
        TestUtils.waitElement(driver, drugRouteDropDwn);
        TestUtils.selectByVisibleText(driver.findElement(drugRouteDropDwn), drugRoute);

    }

    /**
     * Entering Days of Cycle to be Administered in Add Prccedure Drugs PopUp
     *
     * @param cycles
     */
    public void enterCycleToBeAdministered(String cycles) {
        log.warn("Entering Days of Cycle to be Administered");
        TestUtils.highlightElement(driver, daysOfCycle);
        driver.findElement(daysOfCycle).sendKeys(cycles);

    }

    /**
     * selecting therapy Type in Add Procedure PopUp
     *
     * @param therapyType
     */
    public void selectTherapyType(String therapyType) {
        log.warn("Select " + therapyType + " value from Therapy TypeDrop-down");
        TestUtils.waitElement(driver, therapyTypeDropDwn);
        TestUtils.highlightElement(driver, therapyTypeDropDwn);
        TestUtils.selectByVisibleText(driver.findElement(therapyTypeDropDwn), therapyType);

    }

    /**
     * Entering length Of Cycles to be Administered in Add Prccedure Drugs PopUp
     *
     * @param lengthOfCycles
     */
    public void enterLengthOfCycles(String lengthOfCycles) {
        log.warn("Entering length Of Cycles to");
        TestUtils.highlightElement(driver, cycleLength);
        driver.findElement(cycleLength).sendKeys(lengthOfCycles);

    }

    /**
     * Entering cycle Count Desc in Add Prccedure Drugs PopUp
     *
     * @param cycleCountDesc
     */
    public void entercycleCount(String cycleCountDesc) {
        log.warn("Entering cycle count");
        TestUtils.highlightElement(driver, cycleCount);
        driver.findElement(cycleCount).sendKeys(cycleCountDesc);

    }

    /**
     * Entering Dosage in Add Prccedure Drugs PopUp
     *
     * @param dosage
     */
    public void enterDosage(String dosage) {
        log.warn("Entering dosage");
        TestUtils.highlightElement(driver, dosageXpath);
        driver.findElement(dosageXpath).sendKeys(dosage);

    }

    /**
     * User clicks Save button on Add Procedure PopUp
     */
    public void clickSaveButton() {
        log.warn("Click Save Button Add Procedure PopUp ");
        driver.findElement(saveButton).click();
    }

    /**
     * verifying added procedure details
     * String procedureCode, String procedureFrequency, String cycles, String therapyType, String lengthOfCycles, String cycleCountDesc, String dosage) throws Throwable {
     *
     * @param procedureCode
     * @param procedureFrequency
     * @param cycles
     * @param therapyType
     * @param lengthOfCycles
     * @param cycleCountDesc
     * @param dosage
     */
    public void verifyAddProcedureDetails(String procedureCode, String procedureFrequency, String drugRoute, String cycles, String therapyType, String lengthOfCycles, String cycleCountDesc, String dosage) {
        log.warn("verifying procedure details.");
        TestUtils.wait(3);
        if (driver().findElement(By.xpath("//*[@id='regimenVersionProcTableModelID']/tbody/tr/td[3]/span")).getText().equals(procedureCode)) {
            TestUtils.highlightElement(driver, driver().findElement(By.xpath("//*[@id='regimenVersionProcTableModelID']/tbody/tr/td[3]/span")));
            Assert.assertTrue("procedureCode is not saved correctly.", driver().findElement(By.xpath("//*[@id='regimenVersionProcTableModelID']/tbody/tr/td[3]/span")).getText().equals(procedureCode));
            TestUtils.highlightElement(driver, driver().findElement(By.xpath("//*[@id='regimenVersionProcTableModelID']/tbody/tr/td[6]/span")));
            Assert.assertTrue("procedureFrequency is not saved correctly.", driver().findElement(By.xpath("//*[@id='regimenVersionProcTableModelID']/tbody/tr/td[6]/span")).getText().equals(procedureFrequency));
            TestUtils.highlightElement(driver, driver().findElement(By.xpath("//*[@id='regimenVersionProcTableModelID']/tbody/tr/td[8]/span")));
            Assert.assertTrue("drugRoute is not saved correctly.", driver().findElement(By.xpath("//*[@id='regimenVersionProcTableModelID']/tbody/tr/td[8]/span")).getText().equals(drugRoute));
            TestUtils.highlightElement(driver, driver().findElement(By.xpath("//*[@id='regimenVersionProcTableModelID']/tbody/tr/td[9]/span")));
            Assert.assertTrue("cycles is not saved correctly.", driver().findElement(By.xpath("//*[@id='regimenVersionProcTableModelID']/tbody/tr/td[9]/span")).getText().equals(cycles));
            TestUtils.highlightElement(driver, driver().findElement(By.xpath("//*[@id='regimenVersionProcTableModelID']/tbody/tr/td[10]/span")));
            Assert.assertTrue("therapyType is not saved correctly.", driver().findElement(By.xpath("//*[@id='regimenVersionProcTableModelID']/tbody/tr/td[10]/span")).getText().equals(therapyType));
            TestUtils.highlightElement(driver, driver().findElement(By.xpath("//*[@id='regimenVersionProcTableModelID']/tbody/tr/td[11]/span")));
            Assert.assertTrue("lengthOfCycles is not saved correctly.", driver().findElement(By.xpath("//*[@id='regimenVersionProcTableModelID']/tbody/tr/td[11]/span")).getText().equals(lengthOfCycles));
            TestUtils.highlightElement(driver, driver().findElement(By.xpath("//*[@id='regimenVersionProcTableModelID']/tbody/tr/td[12]/span")));
            Assert.assertTrue("cycleCountDesc is not saved correctly.", driver().findElement(By.xpath("//*[@id='regimenVersionProcTableModelID']/tbody/tr/td[12]/span")).getText().equals(cycleCountDesc));
            TestUtils.highlightElement(driver, driver().findElement(By.xpath("//*[@id='regimenVersionProcTableModelID']/tbody/tr/td[13]/span")));
            Assert.assertTrue("dosage is not saved correctly.", driver().findElement(By.xpath("//*[@id='regimenVersionProcTableModelID']/tbody/tr/td[13]/span")).getText().equals(dosage));


        }
    }

    /**
     * Verifying the error message when Same combination of Procedure code And Procedure Brand Exists
     *
     * @param expectedError
     */
    public void verifyErrorMessageWhenSameProcCodeAndProcBrandExists(String expectedError) {
        TestUtils.wait(4);
        log.warn("Verifying \"Review the form and correct the highlighted fields\" error displayed when Reason for choosing this regimen drop down is not selected");
        TestUtils.waitElement(driver, errorMessageOnAddProcedurePopup);
        TestUtils.highlightElement(driver, errorMessageOnAddProcedurePopup);
        String actualError = this.driver.findElement(errorMessageOnAddProcedurePopup).getText();
        Assert.assertEquals("Different Procedure Code/ProcedureDrugBrand", expectedError, actualError);
    }
}
