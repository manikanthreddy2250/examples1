package atdd.test.pageobjects.rulesManger;

import atdd.dao.mbm.MyBatisConnectionFactoryMember;
import atdd.dao.mbm.RulesManagerDao;
import atdd.utils.DataTableUtils;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.*;

public class RulesManagerPage {

    public static By tin_xpath = By.xpath("//input[@ng-model='addForm.tin']");
    public static By LOB_xpath = By.xpath("//select[@ng-model='addForm.lob']");
    public static By drugcode_xpath = By.xpath("//input[@ng-model='addForm.drug_list']");
    public static By IncludedStatesButton = By.xpath("//button[contains(@class,'multiSelectButton')]");
    public static By addExceptionXpath = By.xpath("//a[@ng-click='addRulePopup.openPopup(record)']");
    public static By subscriberIDTxtBox = By.xpath("//input[@ng-model='addForm.subscriber_id']");
    public static By lastNameTxtBox = By.xpath("//input[@ng-model='addForm.last_name']");
    public static By firstNameTxtBox = By.xpath(("//input[@ng-model='addForm.first_name']"));
    public static By dateOfBirth = By.xpath("//input[@ng-model='addForm.birth_date']");
    public static By payer = By.xpath("//select[contains(@ng-model,'addForm.payer')]");
    public static By authType = By.xpath("//select[contains(@ng-model,'addForm.authorization_type')]");
    public static By effectiveStartDate = By.xpath("//input[@ng-model='addForm.start_date']");
    public static By effectiveEndDate = By.xpath("//input[@ng-model='addForm.end_date']");
    public static By saveDraftButton = By.xpath("//input[@value = 'Save Draft']");
    public static By sortButtonForTable = By.xpath("//span[@ng-click='rulesTable.sortColumns(column)']");
    public static By noRecordsMsg = By.xpath("//*[contains(text(), 'No records to display.')]");
    public static By subscriberIDSearchCriteria = By.xpath("//input[contains(@ng-model,'rulesTable.tableFilters.subscriber_id')]");
    public static By lastNameSearchCriteria = By.xpath("//input[contains(@ng-model,'rulesTable.tableFilters.last_name')]");
    public static By firstNameSearchCriteria = By.xpath("//input[contains(@ng-model,'rulesTable.tableFilters.first_name')]");
    public static By authTypeSearchCriteria = By.xpath("//select[@ng-model='rulesTable.tableFilters.authorization_type']");
    public static By effectiveStartDateSearchCriteria = By.xpath("//input[contains(@ng-model,'rulesTable.tableFilters.start_date')]");
    public static By effectiveEndDateSearchCriteria = By.xpath("//input[contains(@ng-model,'rulesTable.tableFilters.end_date')]");
    public static By birthDateSearchCriteria = By.xpath("//input[contains(@ng-model,'rulesTable.tableFilters.birth_date')]");
    public static By searchButton = By.xpath("//input[@ng-click='rulesTable.applyTableFiltersOnClick(rulesTableFormtableFilters)']");
    public static By clearButton = By.xpath("//input[@ng-click='rulesTable.clearSearchOnClick()']");
    public static By DeleteIcon = By.xpath("//span[@ng-click='deleteConfirmPopup.openPopup(record)']");
    public static By membernameDeletePopup = By.xpath("//*[@id=\"deleteMemberExceptionContent\"]/p/strong");
    public static By deleteButtonMemExcp = By.xpath("//*[@id=\"deleteConfirmPopupID\"]/div[2]/div/form/div/div[2]/input[1]");
    public static By editIcon = By.xpath("//span[@ng-click='editRulePopup.openPopup(record)']");
    public static By editEffectiveStartDate = By.xpath("//input[contains(@ng-model,'editForm.start_date')]");
    public static By editEffectiveEndDate = By.xpath("//input[contains(@ng-model,'editForm.end_date')]");
    public static By editSaveDraftButton = By.xpath("//input[@ng-click='saveEditRule(editRuleForm)']");
    public static By duplicateEntry = By.xpath("//div[@ng-if='model'][contains(.,'Duplicate entry')]");
    public static By refreshError = By.xpath("//div[@ng-if='model'][contains(.,'Please refresh')]");
    public static By cancelAddPopup = By.xpath("//input[@ng-click='addRulePopup.closePopup()']");
    public static By specialtyPharmaDrugClass = By.xpath("//input[@name='Drug Class']");
    public static By xoutButton = By.xpath("//button[@ng-click='addRulePopup.closePopup()']");
    public static By xoutEditButton = By.xpath("//button[@ng-click='editRulePopup.closePopup()']");
    public static By drugGroupType_xpath = By.xpath("//select[@ng-model='addForm.drug_group_type']");
    public static By providerPhysicianType_xpath = By.xpath("//input[@type='radio'][@value='physician']");
    public static By providerFacilityType_xpath = By.xpath("//input[@type='radio'][@value='facility']");
    public static By searchProviderTIN_xpath = By.id("providerSearch-TIN-0");
    public static By searchProviderTIN2_xpath = By.id("providerSearch-TIN-1");
    public static By providerTINSearch = By.xpath("//a[text()='Search']");
    public static By servicingProviderTIN_xpath = By.id("addForm-tin-0");
    public static By successMessage = By.id("globalMessages-description");
    public static By addDrugCode_name = By.xpath("//input[@ng-model='addForm.drug_list']");
    public static By selectDrugCodeValue = By.xpath("//strong[contains(text(),'J1745')]");
    public static By addDrugCodeButton = By.xpath("//a[contains(@ng-click,'add') and text()='Add']");
    public static By selectDrugGroupValue = By.xpath("//select[@ng-model='addForm.drug_group_type']");
    public static By editLOB_xpath = By.xpath("//select[@ng-model='editForm.lob']");
    public static By npiDropdown_xpath = By.xpath("//select[@ng-model='record.providerNPI']");
    public static By selectAuthType =By.xpath("//*[@id='addForm-auth_type-1']");
    public static By selectOrg = By.xpath("//*[@id='addForm-org_id-1'] ");
    public static By selectCustomer = By.xpath("//*[@id='addForm-cust_id-1']");
    public static By selectDesc = By.xpath("//*[@id='addForm-description-0']");
    public static By selectProviderRole = By.xpath("//*[@id='addForm-provider_role-1']");
    public static By selectRuleOutcome = By.xpath("//*[@id='addForm-rule_outcome-1']");
    public static By saliency = By.xpath("//*[@id='salience-value-0']");




    private static Logger log = Logger.getLogger(RulesManagerPage.class);
    private Scenario scenario;
    private WebDriver driver;
    private TestUtils testUtils = new TestUtils();

    public RulesManagerPage(WebDriver driver) {
        this.driver = driver;
    }

    /*
    Validate the order of Columns in table
     */
    public void validateTableHeader(List<String> expectedHeader) {
        List<WebElement> headerElements = driver.findElements(By.xpath("//*[@id=\"rulesTableID\"]/thead/tr/td"));
        for (int i = 0; i < expectedHeader.size(); i++) {
            Boolean value = headerElements.get(i).getText().contains(expectedHeader.get(i));
            Assert.assertTrue("expected and actual doesn't match at index " + i, value);
        }
    }

    /*This method clicks on +Add New Provider/Member*/
    public void clickOnAddPopupHyperLink() {
        log.warn("Clicking on add  Exception");
        TestUtils.waitForNotBusy(driver);
        TestUtils.waitElementVisible(driver, addExceptionXpath);
        TestUtils.click(driver, addExceptionXpath);
    }

    /*This method enter subscriber ID on Add New Member pop up*/
    public void enterSubscriberIDOnAddPopUp(String subscriber_id) {
        log.warn("Enter Subscriber ID  on the Add  Pop-up modal");
        TestUtils.input(driver, subscriberIDTxtBox, subscriber_id);
    }

    /*This method enter last name on Add New Member pop up*/
    public void enterLastNameOnAddPopUp(String last_name) {
        log.warn("Enter Last Name  on the Add Member Exception Pop-up modal");
        TestUtils.input(driver, lastNameTxtBox, last_name);
    }

    /*This method enter first name on Add New Member pop up*/
    public void enterFirstNameOnAddPopUp(String first_name) {
        log.warn("Enter Last Name  on the Add Member Exception Pop-up modal");
        TestUtils.input(driver, firstNameTxtBox, first_name);
    }

    /*This method enter Date of Birth on Add New Member pop up*/
    public void enterDateOfBirthOnOnAddPopUp(String date_of_birth) {
        log.warn("Enter Date of Birth on the Member Exception Screen");
        TestUtils.input(driver, dateOfBirth, date_of_birth);

    }

    /*This method selects auth type on Add New Member pop up*/
    public void selectAuthTypeOnOnAddPopUp(String authorization_type) {
        log.warn("Enter the Auth Type on the Add Member Exception Pop-up modal");
        TestUtils.select(driver, authType, authorization_type);
    }

    /*This method enter start date on Add New Member pop up*/
    public void enterEffectiveStartDateOnAddPopUp(String effective_start_date) {
        log.warn("Enter Effective Start Date on the Member Exception Screen");
        TestUtils.input(driver, effectiveStartDate, effective_start_date);
    }

    /*This method enter end date on Add New Member pop up*/
    public void enterEffectiveEndDateOnAddPopUp(String effective_end_date) {
        log.warn("Enter Effective Start Date on the Member Exception Screen");
        TestUtils.input(driver, effectiveEndDate, effective_end_date);
    }

    /*This method enter end date on Add New Drug Code*/
    public void enterAddDrugCodeOnAddPopUp(String add_drug_code) {
        log.warn("Enter Drug Code on the Admin Guide Exception Screen");
        TestUtils.input(driver, addDrugCode_name, add_drug_code);
    }

    /*This method selects payer on Add New Member pop up*/
    public void selectPayerOnAddPopUp(String payer) {
        log.warn("Enter the Payer on the Add Member Exception Pop-up modal");
        TestUtils.select(driver, RulesManagerPage.payer, payer);
    }

    /*This method clicks save draft button on Add New Member pop up*/
    public void clickSaveDraftButton() {
        log.warn("Click save on the Add Member Exception Pop-up modal");
        TestUtils.click(driver, saveDraftButton);
    }


    /*This method enter subscriber ID on Member exceptions page*/
    public void enterSubscriberIDOnMemberExceptionsSearchCriteria(String subscriberID) {
        log.warn("Enter the Subscriber ID in Search Criteria of Member Exceptions Screen");
        TestUtils.input(driver, subscriberIDSearchCriteria, subscriberID);
        TestUtils.demoBreakPoint(scenario, driver, "Enter Subscriber ID in Search Criteria");

    }

    /*This method enter last name on Member exceptions page*/
    public void selectLastNameOnMemberExceptionSearchCriteria(String last_name) {
        log.warn("Enter the Last Name in Search Criteria of Member Exceptions Screen");
        TestUtils.input(driver, lastNameSearchCriteria, last_name);
        TestUtils.demoBreakPoint(scenario, driver, "Enter last name in Search Criteria");

    }

    /*This method enter first name on Member exceptions page*/
    public void selectFirstNameOnMemberExceptionSearchCriteria(String last_name) {
        log.warn("Enter the First Name in Search Criteria of Member Exceptions Screen");
        TestUtils.input(driver, firstNameSearchCriteria, last_name);
        TestUtils.demoBreakPoint(scenario, driver, "Enter first name in Search Criteria");

    }

    public void selectDateOfBirthOnMemberExceptionSearchCriteria(String dob) {
        log.warn("Enter birth date on the Member Exception Screen");
        TestUtils.demoBreakPoint(scenario, driver, "Enter birth Date in Search Criteria");
        TestUtils.input(driver, birthDateSearchCriteria, dob);
    }

    public void enterEffectiveEndDateOnMemberExceptionsSearchCriteria(String effective_end_date) {
        log.warn("Enter Effective End date on the Member Exception Screen");
        TestUtils.demoBreakPoint(scenario, driver, "Enter Effective End Date in Search Criteria");
        TestUtils.input(driver, effectiveEndDateSearchCriteria, effective_end_date);
    }

    /*This method selects auth type on Member exceptions page*/
    public void selectAuthTypeOnMemberExceptionSearchCriteria(String authorization_type) {
        log.warn("select the Auth Type in Search Criteria of Member Exceptions Screen");
        TestUtils.select(driver, authTypeSearchCriteria, authorization_type);
    }

    /*This method enter start date on Member exceptions page*/
    public void enterEffectiveStartDateOnMemberExceptionsSearchCriteria(String effective_start_date) {
        log.warn("Enter Effective Start date on the Member Exception Screen");
        TestUtils.demoBreakPoint(scenario, driver, "Enter Effective Start Date in Search Criteria");
        TestUtils.input(driver, effectiveStartDateSearchCriteria, effective_start_date);

    }


    /*This method clicks search  button on  Member exceptions page*/
    public void clickSearchButton() {
        log.warn("Click Search on Member Exceptions Screen");
        TestUtils.waitForNotBusy(driver);
        TestUtils.click(driver, searchButton);
    }

    /*This method verifies data exists in grid*/
    public boolean isDataExistsInGrid() {
        boolean isDataExists = false;
        TestUtils.wait(10);
        return TestUtils.isElementVisible(driver, noRecordsMsg);
       /* List<WebElement> els = driver.findElements(By.xpath("//table[@id='rulesTableID']//tr"));
        isDataExists = els.size()>=3;
        return isDataExists;*/
    }

    /*This method verifies that records are displayed as per search criteria*/
    public void VerifyRecordsDisplayedCorrectlywithUI(Map<String, String> map) {
        TestUtils.wait(10);
        List<WebElement> els = driver.findElements(By.xpath("//table[@id='rulesTableID']//tr"));
        System.out.println(els.size());
        List<String> actualValue = new ArrayList<String>();
        for (int i = 1; i < els.size(); i++) {
            List<WebElement> tableColumn = driver.findElements(By.xpath("//table[@id='rulesTableID']//tbody/tr[" + i + "]/td"));
            for (int j = 1; j <= tableColumn.size(); j++) {

                actualValue.add(driver.findElement(By.xpath("//table[@id='rulesTableID']//tbody/tr[" + i + "]/td[" + j + "]")).getText());

            }

            Assert.assertTrue("Subscriber ID doesn't match the added value", actualValue.get(1).equalsIgnoreCase(map.get("Subscriber ID")));
            if (map.get("Effective Start Date") != null && !map.get("Effective Start Date").isEmpty())
                Assert.assertTrue("Effective Start Date doesn't match the added value", actualValue.get(5).equalsIgnoreCase(map.get("Effective Start Date")));
            if (map.get("Effective End Date") != null && !map.get("Effective End Date").isEmpty())
                Assert.assertTrue("Effective End Date doesn't match the added value", actualValue.get(6).equalsIgnoreCase(map.get("Effective End Date")));


        }
    }

    /*This method verifies sorting order for last name in Member exceptions page*/
    public void userVerifiesSortingOrder() {
        List<WebElement> els = driver.findElements(By.xpath("//table[@id='rulesTableID']//tr"));
        System.out.println(els.size());
        ArrayList<String> actualValue = new ArrayList<String>();
        for (int i = 1; i < els.size(); i++) {
            actualValue.add(driver.findElement(By.xpath("//table[@id='rulesTableID']//tbody/tr[" + i + "]/td[3]")).getText());
        }
        Collections.sort(actualValue);
        System.out.println(actualValue);
        TestUtils.wait(5);
        ArrayList<String> actualValue1 = new ArrayList<String>();
        for (int i = 1; i < els.size(); i++) {
            actualValue1.add(driver.findElement(By.xpath("//table[@id='rulesTableID']//tbody/tr[" + i + "]/td[3]")).getText());
        }
        System.out.println(actualValue1);
        Assert.assertEquals(actualValue, actualValue1);
    }

    /*This button clicks on clear button on Member Exceptions page */
    public void clicksOnClearButton() {
        log.warn("Click clear on Member Exceptions Screen");
        TestUtils.wait(5);
        TestUtils.click(driver, clearButton);
    }

    public void VerifyRecordsDisplayedCorrectlyAgainstDB(Map<String, String> map) {
        List<Map<String, Object>> mbrExpDetails = new RulesManagerDao(MyBatisConnectionFactoryMember.getSqlSessionFactory())
                .getMemberExceptionsByVersion(map.get("Subscriber ID"), map.get("Last Name"), map.get("First Name"));
        TestUtils.wait(10);
        List<Map<String, String>> memberUI = TestUtils.tableAsMaps(driver, "//*[@id=\"rulesTableID\"]", 10);
        List<Map<String, String>> memberDb = DataTableUtils.asMapsOfStrings(mbrExpDetails);
        Assert.assertEquals("No.of records in DB are not matching with UI", memberUI.size(), memberDb.size());
        for (int i = 1; i < memberUI.size(); i++) {
            Assert.assertTrue("Last Name doesn't match the added value", memberUI.get(i).get("Last Name").equalsIgnoreCase(memberDb.get(i).get("Last Name")));
            Assert.assertTrue("First Name doesn't match the added value", memberUI.get(i).get("First Name").equalsIgnoreCase(memberDb.get(i).get("First Name")));

        }
    }

    /*This method clicks on edit  icon*/
    public void clickOnEditExceptionLink(String data) {
        //TestUtils.wait(18);
        By editIcon = By.xpath("//span[contains(text(),'" + data + "')]/parent::td/preceding-sibling::td/span[@ng-click='editRulePopup.openPopup(record)']");
        TestUtils.explicitClickAbleWait(driver, editIcon);
        log.warn("Clicking on edit Icon");
        if (TestUtils.isElementPresent(driver, editIcon)) {
            driver.findElement(editIcon).click();
            TestUtils.demoBreakPoint(scenario, driver, "edit  exception");
        } else {
            Assert.fail("No element present with the given criteria");
        }

    }

    /*This method enter start date on Edit New Member pop up*/
    public void enterEffectiveStartDateOnEditMemberExceptionPopUp(String effective_start_date) {
        log.warn("Enter Effective Start Date on the Member Exception Screen");
        TestUtils.input(driver, editEffectiveStartDate, effective_start_date);
    }

    /*This method enter end date on Edit New Member pop up*/
    public void enterEffectiveEndDateOnEditMemberExceptionPopUp(String effective_end_date) {
        log.warn("Enter Effective Start Date on the Member Exception Screen");
        TestUtils.input(driver, editEffectiveEndDate, effective_end_date);
    }

    /*This method clicks save draft button on edit Member pop up*/
    public void clickOnEditSubmitButton() {
        log.warn("Click save on the edit Member Exception Pop-up modal");
        TestUtils.demoBreakPoint(scenario, driver, "edit  exception");
        TestUtils.click(driver, editSaveDraftButton);

    }

    public void addMemberException(Map<String, String> map) {
        clickOnAddPopupHyperLink();
        enterSubscriberIDOnAddPopUp(map.get("Subscriber ID"));
        enterLastNameOnAddPopUp(map.get("Last Name"));
        enterFirstNameOnAddPopUp(map.get("First Name"));
        enterDateOfBirthOnOnAddPopUp(map.get("Date of Birth"));
        TestUtils.demoBreakPoint(scenario, driver, "Add memeber exception");
        clickSaveDraftButton();
    }

    public void clickDeleteIcon(String data) throws InterruptedException {

        By DeleteIcon = By.xpath("//*[contains(@title,'Delete Record')]");
        TestUtils.wait(30);
        if (TestUtils.isElementPresent(driver, DeleteIcon)) {
            driver.findElement(DeleteIcon).click();
            TestUtils.demoBreakPoint(scenario, driver, "delete  exception");
        } else {
            Assert.fail("No element present with the given criteria");
        }

    }

    /*Assumption: User to verify member name displayed in delete popup is equal to the members's last name and first name*/
    public void verifyMemberNamefrompopupWithDatafromGrid() {

        String memberFnameLname = driver.findElement(membernameDeletePopup).getText();
        System.out.println("The LastName and FirstName of the member record is from the grid is: " + memberFnameLname);
        String lnameGrid = driver.findElement(By.xpath("//*[@id=\"rulesTableID\"]/tbody/tr[1]/td[3]/span")).getText();
        String fnameGrid = driver.findElement(By.xpath("//*[@id=\"rulesTableID\"]/tbody/tr[1]/td[4]/span")).getText();
        String fullname = lnameGrid + "," + fnameGrid;

        Assert.assertEquals(fullname, memberFnameLname);
    }

    /*Assumption: User clicks delete button*/
    public void clickDeleteButtonOnConfirmationPopup(String data) {
        By deleteIcon = By.xpath("//input[@ng-click='deleteRulesManagerSheet(record)']");
        driver.findElement(deleteIcon).click();
    }


    public void deleteException(Map<String, String> Data) throws InterruptedException {
        By DeleteIcon = By.xpath("//*[contains(@title,'Delete Record')]");
        Set<String> s = Data.keySet();
        for (String u : s) {
            if (TestUtils.isElementVisible(driver, DeleteIcon)) {
                clickDeleteIcon(Data.get(u));
                TestUtils.waitForNotBusy(driver);
                clickDeleteButtonOnConfirmationPopup(Data.get(u));
            } else log.warn("Nothing to delete");
            TestUtils.demoBreakPoint(scenario, driver, "successfully clicked on delete exception");
        }
    }

    public void verifySortingFunctionality() {
        List<WebElement> SortList = driver.findElements(sortButtonForTable);
        for (int i = 0; i < SortList.size() - 2; i++) {
            SortList.get(i).click();
            List<List<String>> tableHeadersListBeforeSort = TestUtils.tableAsLists(driver, "//table[@id='rulesTableID']", 30);
            if (tableHeadersListBeforeSort.size() > 2) {
                SortList.get(i).click();
                log.warn(tableHeadersListBeforeSort);
                List<List<String>> tableHeadersListAfterSort = TestUtils.tableAsLists(driver, "//table[@id='rulesTableID']", 30);
                log.warn(tableHeadersListAfterSort);
                Assert.assertFalse("Sorting is not working", tableHeadersListAfterSort.equals(tableHeadersListBeforeSort));
                SortList.get(i).click();
                tableHeadersListAfterSort = TestUtils.tableAsLists(driver, "//table[@id='rulesTableID']", 30);
                log.warn(tableHeadersListAfterSort);
                Assert.assertEquals(tableHeadersListAfterSort, tableHeadersListBeforeSort);
            }

        }

    }

    public void editException(Map<String, String> map) {

        Set<String> s = map.keySet();
        for (String u : s) {
            clickOnEditExceptionLink(map.get(u));
            TestUtils.waitForNotBusy(driver);
            break;
        }
        enterEffectiveStartDateOnEditMemberExceptionPopUp(map.get("Effective Start Date"));
        enterEffectiveEndDateOnEditMemberExceptionPopUp(map.get("Effective End Date"));
        clickOnEditSubmitButton();
    }

    public void editExceptionDrugGroup(Map<String, String> map) {

        Set<String> s = map.keySet();
        for (String u : s) {
            clickOnEditExceptionLink(map.get(u));
            TestUtils.waitForNotBusy(driver);
            break;
        }
        enterLOBnEditPopUp(map.get("Line of Business"));
        clickOnEditSubmitButton();
    }

    public void editExceptionBuyAndBill(Map<String, String> map) {

        editException(map);
        if (TestUtils.isElementVisible(driver, refreshError)) {
            editException(map);
        }
        if (TestUtils.isElementVisible(driver, duplicateEntry)) {
            this.driver.findElement(xoutEditButton).click();
        }
    }

    /**
     * Performs an edit for a rule in Preferred Procedures
     * @param map The fields to edit and their new value.
     */
    public void editPreferredProcedure(Map<String, String> map) {

        // Open the Edit dialogue and modify the values that are provided
        TestUtils.click(driver, editIcon);
        Set<String> values = map.keySet();
        for (String key : values) {
            switch (key) {
                case "Effective Start Date":
                    TestUtils.input(driver, RulesManagerPage.editEffectiveStartDate, map.get(key));
                    break;
                default:
                    break;
            }
        }

        // Save the edit
        TestUtils.click(driver, saveDraftButton);

    }

    public void addProviderException(Map<String, String> values) {
        clickOnAddPopupHyperLink();
        enterTINOnAddPopUp(values.get("Servicing Provider TIN"));
        enterLOBnAddPopUp(values.get("Line of Business"));
        enterStatesOnAddPopUp(values.get("Included States"));
        enterDrugCodenOnAddPopUp(values.get("Add Drug Code"));
        clickSaveDraftButton();
    }

    private void enterStatesOnAddPopUp(String States) {
        if (!(validateEmptyString(States))) {
            log.warn("Enter States on the Add  Pop-up modal");
            String[] StatesArray = States.split(",");
            TestUtils.click(driver, IncludedStatesButton);
            for (String s : StatesArray) {
                driver.findElement(By.xpath("//span[contains(text(),'" + s + "')]/../../parent::div")).click();
            }
            TestUtils.click(driver, IncludedStatesButton);
        }
    }

    private void enterLOBnAddPopUp(String LOB) {
        if (!(validateEmptyString(LOB))) {
            log.warn("Enter LOB on the add Pop-up");
            TestUtils.select(driver, LOB_xpath, LOB);
        }
    }

    private void enterLOBnEditPopUp(String LOB) {
        if (!(validateEmptyString(LOB))) {
            log.warn("Enter LOB on the add Pop-up");
            TestUtils.select(driver, editLOB_xpath, LOB);
        }
    }

    private void enterTINOnAddPopUp(String TIN) {
        if (!(validateEmptyString(TIN))) {
            log.warn("Enter Tin  on the Add  Pop-up modal");
            TestUtils.input(driver, tin_xpath, TIN);
        }
    }

    private void enterDrugCodenOnAddPopUp(String DrugCode) {
        if (!(validateEmptyString(DrugCode))) {
            log.warn("Enter Drugcode  on the Add  Pop-up modal");
            String[] DrugCodeArray = DrugCode.split(",");
            for (String s : DrugCodeArray) {
                By drugNameDropDown = By.xpath("//a[contains(@title,'" + s + "')]");
                driver.findElement(drugcode_xpath).sendKeys(s);
//                TestUtils.input(driver, drugcode_xpath, s);
                TestUtils.wait(5);
                TestUtils.scrollToElement(driver, drugNameDropDown);

                driver.findElement(drugNameDropDown).click();
//                TestUtils.click(driver, drugNameDropDown);
                TestUtils.wait(1);
                TestUtils.scrollToElement(driver, By.xpath("//input[@ng-model='addForm.drug_list']/ancestor::td/a[contains(text(),'Add')]"));
                driver.findElement(By.xpath("//input[@ng-model='addForm.drug_list']/ancestor::td/a[contains(text(),'Add')]")).click();

            }
        }

    }

    private boolean validateEmptyString(String data) {
        return data.equals(" ");
    }

    public void VerifyRecordsDisplayedCorrectlyAgainstDBProvider(Map<String, String> searchValues) {
        List<Map<String, Object>> providerExpDetails = new RulesManagerDao(MyBatisConnectionFactoryMember.getSqlSessionFactory())
                .getProviderExceptionsByVersion(searchValues.get("Servicing Provider TIN"));
        TestUtils.wait(10);
        List<Map<String, String>> providerUI = TestUtils.tableAsMaps(driver, "//*[@id=\"rulesTableID\"]", 10);
        List<Map<String, String>> providerDb = DataTableUtils.asMapsOfStrings(providerExpDetails);
        Assert.assertEquals("No.of records in DB are not matching with UI", providerUI.size(), providerDb.size());
        for (int i = 1; i < providerUI.size(); i++) {
            Assert.assertTrue("TIN doesn't match the added value", providerUI.get(i).get("Requesting Provider TIN").equalsIgnoreCase(providerDb.get(i).get("Requesting Provider TIN")));
        }
    }

    public void BuyAndBillException(Map<String, String> values) {
        clickOnAddPopupHyperLink();
        enterLOBnAddPopUp(values.get("Line of Business"));
        enterStatesOnAddPopUp(values.get("Included States"));
        enterDrugCodenOnAddPopUp(values.get("Add Drug Code"));
        clickSaveDraftButton();
        if (TestUtils.isElementVisible(driver, refreshError)) {
            driver.navigate().refresh();
            BuyAndBillException(values);
        }
        if (TestUtils.isElementVisible(driver, duplicateEntry)) {
            TestUtils.highlightElement(driver, xoutButton);
            this.driver.findElement(xoutButton).click();
        }
    }

    public void deleteBuyAndBillException(Map<String, String> t) throws InterruptedException {


        if (!isDataExistsInGrid()) {
            // TestUtils.click(driver, deleteIcon);
        } else {
            Assert.fail("No element presnt with the given criteria");
        }

        TestUtils.waitForNotBusy(driver);
        //clickDeleteButtonOnConfirmationPopup();
        TestUtils.demoBreakPoint(scenario, driver, "sucessfully clicked ondelete  exception");


    }


    /*
This method is to verify Records founds in search Result Grid
 */
    public void VerifyRecordsDisplayedCorrectlyAgainstBuyAndBill(Map<String, String> map) {
        TestUtils.wait(5);
        List<WebElement> els = driver.findElements(By.xpath("//table[@id='rulesTableID']//tr"));
        System.out.println(els.size());
        List<String> actualValue = new ArrayList<String>();
        for (int i = 1; i < els.size(); i++) {
            List<WebElement> tableColumn = driver.findElements(By.xpath("//table[@id='rulesTableID']//tbody/tr[" + i + "]/td"));
            for (int j = 1; j <= tableColumn.size(); j++) {

                actualValue.add(driver.findElement(By.xpath("//table[@id='rulesTableID']//tbody/tr[" + i + "]/td[" + j + "]")).getText());

            }
            Assert.assertTrue("DrugCode doesn't match the added value", actualValue.get(2).contains(map.get("Drug Code")));
            Assert.assertTrue("LOB doesn't match the added value", actualValue.get(1).equalsIgnoreCase(map.get("Line of Business")));

        }
    }

    /**
     * Asserts that a Preferred Procedures entry exists given a filtering 'Drug Code'.
     *
     * @param searchValues The value to look for in the results table.
     */
    public void verifyPreferredProcedureRecordExists(Map<String, String> searchValues) {
        Assert.assertTrue(
                "Searched element is NOT visible",
                TestUtils.isElementPresent(driver, getRowInTableByText(searchValues.get("Drug Code")))
        );
    }

    public void enterDrugForBuyAndBill(Map<String, String> map) {
        TestUtils.waitElementVisible(driver, specialtyPharmaDrugClass);
        String drugCode = map.get("Drug Code");
        String drugClass = map.get("Drug Class");
        TestUtils.input(driver, specialtyPharmaDrugClass, map.get("Drug Class"));
        TestUtils.waitForNotBusy(driver);
        TestUtils.click(driver, By.xpath("//a[@title=\"" + drugClass + "\"]"));
        TestUtils.click(driver, (By.xpath("//button[@data-id='CloneAuth.AuthType.DrugCode—-dropdownMenu']")));
        TestUtils.wait(2);
        TestUtils.input(driver, (By.xpath("//input[@ng-model='inputLabel.labelFilter']")), drugCode);
        TestUtils.wait(2);
        TestUtils.click(driver, By.xpath("//*[contains(text(),'" + drugCode + "')]//parent::span"));
    }

    public void addSupplierList(Map<String, String> values) {
        TestUtils.demoBreakPoint(scenario, driver, "Before Adding");
        clickOnAddPopupHyperLink();
        enterDrugGroupnAddPopUp(values.get("Drug Group"));
        enterLOBnAddPopUp(values.get("Line of Business"));
        enterStatesOnAddPopUp(values.get("Included States"));
        enterEffectiveStartDateOnAddPopUp(values.get("Effective Start Date"));
        enterEffectiveEndDateOnAddPopUp(values.get("Effective End Date"));

        //Provider Searching and selecting
        selectProviderType(values.get("Provider Type"));
        searchProviderTIN(values.get("Search Provider TIN"));
        selectProviderByNPI(values.get("Provider NPI"));
        selectNPIForCertainProviderTIN(values.get("Provider NPI"));

        enterDrugCodenOnAddPopUp(values.get("Add Drug Code"));
        clickSaveDraftButton();
    }

    public void addMSEProviderException(Map<String, String> values) {
        clickOnAddPopupHyperLink();
        enterServicingProviderTIN(values.get("Servicing Provider TIN"));
        enterLOBnAddPopUp(values.get("Line of Business"));
        enterStatesOnAddPopUp(values.get("Included States"));
        enterEffectiveStartDateOnAddPopUp(values.get("Effective Start Date"));
        enterEffectiveEndDateOnAddPopUp(values.get("Effective End Date"));
        clickSaveDraftButton();
    }

    //Adding methods for the Admin Guide Exception UI Screen
    public void addAdminGuideException(Map<String, String> values) {
        clickOnAddPopupHyperLink();
        enterServicingProviderTIN(values.get("Servicing Provider TIN"));
        enterLOBnAddPopUp(values.get("Line of Business"));
        enterStatesOnAddPopUp(values.get("Included States"));
        enterEffectiveStartDateOnAddPopUp(values.get("Effective Start Date"));
        enterEffectiveEndDateOnAddPopUp(values.get("Effective End Date"));
        enterAddDrugCodeOnAddPopUp(values.get("Add Drug Code"));
        clickOnDrugCodeValue();
        clickOnAddDrugCodeButton();
        clickSaveDraftButton();
    }

    //The below method is used to add the Drug code value into the text box and select it for the Admin Guide Exception UI Screen
    public void clickOnDrugCodeValue() {
        log.debug("Clicking on adding Drug Code Value");
        TestUtils.waitForNotBusy(driver);
        TestUtils.waitElementVisible(driver, selectDrugCodeValue);
        TestUtils.click(driver, selectDrugCodeValue);
    }

    //The below method is used to click on the add button after the Drug code value is selected for the Admin Guide Exception UI Screen
    public void clickOnAddDrugCodeButton() {
        log.debug("Clicking on adding Drug Code Button");
        TestUtils.waitForNotBusy(driver);
        TestUtils.waitElementVisible(driver, addDrugCodeButton);
        TestUtils.click(driver, addDrugCodeButton);
    }

    //Adding methods for the Drug Group UI Screen
    public void addDrugGroup(Map<String, String> values) {
        clickOnAddPopupHyperLink();
        selectOnDrugGroupValue(values.get("Drug Group"));
        enterLOBnAddPopUp(values.get("Line of Business"));
        enterAddDrugCodeOnAddPopUp(values.get("Add Drug Code"));
        clickOnDrugCodeValue();
        clickOnAddDrugCodeButton();
        clickSaveDraftButton();
    }

    //The below method is used to add the Drug Group value into the drop down box and select it for the Drug Group UI Screen
    private void selectOnDrugGroupValue(String drugGroupValue) {
        if (!(validateEmptyString(drugGroupValue))) {
            log.warn("Enter drugGroupValue on the Add Pop-up");
            TestUtils.select(driver, selectDrugGroupValue, drugGroupValue);
        }
    }

    /*This method enter first name on Add New Member pop up*/
    public void enterServicingProviderTIN(String servicingProviderTIN) {
        log.warn("Entering Servicing Provider TIN on the Add MSE Provider Exception Pop-up modal");
        TestUtils.input(driver, servicingProviderTIN_xpath, servicingProviderTIN);
    }

    public void enterDrugGroupnAddPopUp(String drugGroup) {
        if (!(validateEmptyString(drugGroup))) {
            log.warn("Enter Drug Group on the Add  Pop-up modal");
            TestUtils.select(driver, drugGroupType_xpath, drugGroup);
        }
    }

    public void selectProviderType(String providerType) {
        if (!(validateEmptyString(providerType))) {
            log.warn("Enter Provider Type on the Add  Pop-up modal");
            if (providerType.contains("Physician")) {
                TestUtils.click(driver, providerPhysicianType_xpath);
            } else if (providerType.contains("Facility")) {
                TestUtils.click(driver, providerFacilityType_xpath);
            } else {
                log.warn("Option doesn't exist");
            }
        }
    }

    public void searchProviderTIN(String searchProviderTIN) {
        if (!(validateEmptyString(searchProviderTIN))) {
            if (TestUtils.waitElementVisible(driver, searchProviderTIN_xpath)) {
                TestUtils.input(driver, searchProviderTIN_xpath, searchProviderTIN);
            } else {
                TestUtils.input(driver, searchProviderTIN2_xpath, searchProviderTIN);
            }

            TestUtils.waitElementClickable(driver, providerTINSearch);
            TestUtils.click(driver, providerTINSearch);
        }
    }

    public void SelfadministeredDrugException(Map<String, String> values) {
        clickOnAddPopupHyperLink();
        enterLOBnAddPopUp(values.get("Line of Business"));
        enterDrugCodenOnAddPopUp(values.get("Add Drug Code"));
        clickSaveDraftButton();
        if (TestUtils.isElementVisible(driver, refreshError)) {
            driver.navigate().refresh();
            SelfadministeredDrugException(values);
        }
        if (TestUtils.isElementVisible(driver, duplicateEntry)) {
            TestUtils.highlightElement(driver, xoutButton);
            this.driver.findElement(xoutButton).click();
        }
    }

    /*This method verifies that records are displayed as per search criteria*/
    public boolean genericVerifyRecordsDisplayedCorrectlyWithUI(Map<String, String> map) {
//        TestUtils.wait(3);
        TestUtils.waitElementVisible(driver, By.xpath("//*[@id=\"rulesTableID\"]/tbody/tr/td"));
        Integer correctMatches = 0;
        Integer minimumNumberOfMatches = map.size();
        List<WebElement> listTableColumns = driver.findElements(By.xpath("//*[@id=\"rulesTableID\"]/tbody/tr/td"));
        List<String> actualValue = new ArrayList<String>();

        //Applies values to List for comparison
        for (int i = 1; i < listTableColumns.size(); i++) {
            List<WebElement> tableColumn = driver.findElements(By.xpath("//table[@id='rulesTableID']//tbody/tr[" + i + "]/td"));
            for (int j = 1; j <= tableColumn.size(); j++) {
                actualValue.add(driver.findElement(By.xpath("//table[@id='rulesTableID']//tbody/tr[" + i + "]/td[" + j + "]")).getText());
            }
        }

        //Checking to see if the list returned matches criteria from the search values in the map
        if (listTableColumns.size() > 0) {
            for (String value : actualValue) {
                for (Map.Entry<String, String> entry : map.entrySet()) {
                    if (value.contains(entry.getValue())) {
                        correctMatches++;

                    }
                }
            }
            /*
             * Correct matches must be equal to or greater than minimum number of matches
             * This is because Eff. Start date could also match last updated and create date
             */
            Assert.assertTrue("Returned result(s) doesn't match what was returned", (correctMatches >= minimumNumberOfMatches));
        } else {
            log.warn("No results found");
            return false;
        }
        return true;
    }


    private void selectProviderByNPI(String providerNPI) {
        Integer option = 0;
        Boolean control = false;
        By selectFirstOption = By.xpath("//*[@id=\'selectButton-0\']");
        TestUtils.waitElementClickable(driver, selectFirstOption);
        try {
            for (int i = 1; i < 10; i++) {
                By selectOptionNPI = By.xpath("//*[@id=\"providerSearchTableID\"]/tbody/tr[" + i + "]/td[3]/span");
                if (driver.findElement(selectOptionNPI).getText().contains(providerNPI)) {
                    By clickOptionByNPI = By.xpath("//*[@id=\'selectButton-" + option + "\']");
                    TestUtils.waitElementClickable(driver, clickOptionByNPI);
                    TestUtils.click(driver, clickOptionByNPI);
                    control = true;
                    break;
                }
                if (control) break;
                option++;

            }
        } catch (Exception e) {
            log.warn("Could not find result");
        }
        TestUtils.wait(5);
    }

    private void selectNPIForCertainProviderTIN(String providerNPI) {
        if (!(validateEmptyString(providerNPI))) {
            log.warn("Enter LOB on the add Pop-up");
            TestUtils.select(driver, npiDropdown_xpath, providerNPI);
        }
    }

    /**
     * Enters datas in Add Preferred Procdedure modal by label name
     *
     * @param values
     */
    public void preferredProcedures(Map<String, String> values) {
        clickOnAddPopupHyperLink();


        for (String value : values.keySet()) {
            enterAddPreferredProcedure(value, values.get(value));

        }
        clickSaveDraftButton();

    }

    /**
     * Returns the element representation of a table row given a text filter to look for within the row entry.
     *
     * @param filteringValue The value to look for in the table.
     * @return The By of the table entry.
     */
    private By getRowInTableByText(String filteringValue) {
        return By.xpath("//*[@id=\"rulesTableID\"]/tbody/tr/td/span[text()='" + filteringValue + "']");
    }

    /**
     * Enters datas in Add Preferred Procdedure modal by label name
     *
     * @param labelName
     * @param value
     */

    private void enterAddPreferredProcedure(String labelName, String value) {

        // If inputting 'Drug Code', search for the unique XPath type and select the option for the type-ahead
        if (labelName.equals("Drug Code")) {
            WebElement el = TestUtils.slowFindElement(driver, "Drug Code", null);
            TestUtils.input(driver, el, value, false);
            TestUtils.wait(5);
            el.sendKeys(Keys.ENTER);

        } else {

            // Input values
            By labelXpath = By.xpath("//table[@id='addExcpetionPopupId']//label[text()='" + labelName + "']/../following-sibling::td/input|//table[@id='addExcpetionPopupId']//label[text()='" + labelName + "']/../following-sibling::td/uitk-select|//table[@id='addExcpetionPopupId']//label[text()='" + labelName + "']/../following-sibling::td/select|//table[@id='addExcpetionPopupId']//label[text()='" + labelName + "']/../following-sibling::td/span");
            TestUtils.input(driver, labelXpath, value);

        }

    }

    public void addProviderEligibilityRule(Map<String, String> values)
    {
        clickOnAddPopupHyperLink();
        selectAuthtypeOnProviderEligibility(values.get("Authorization Type"));
        selectOrgOnProviderEligibility(values.get("Organization"));
        selectCustOnProviderEligiblity(values.get("Customer"));
        enterDescProviderEligiblity(values.get("Description"));
        selectProviderRoleOnProviderEligiblity(values.get("Provider Role"));
        selectRuleOutcomeProviderEligiblity(values.get("Rule OutCome"));
        enterStatesOnAddPopUp(values.get("State"));
        enterEffectiveStartDateOnAddPopUp(values.get("Effective Start Date"));
        enterEffectiveEndDateOnAddPopUp(values.get("Effective End Date"));
        selectSaliencyProviderEligiblity(values.get("Saliency"));
        clickSaveDraftButton();
    }

    private void selectAuthtypeOnProviderEligibility(String  authtype) {
        if (!(validateEmptyString(authtype))) {
            log.warn(" Select authorization type on the Add Pop-up");
            TestUtils.select(driver, selectAuthType, authtype);
        }
    }
    private void selectOrgOnProviderEligibility(String   org) {
        if (!(validateEmptyString(org))) {
            log.warn("Select organization on the Add Pop-up");
            TestUtils.select(driver,  selectOrg, org);
        }
    }
    private void selectCustOnProviderEligiblity(String    cust) {
        if (!(validateEmptyString(cust))) {
            log.warn(" Select  Customer on the Add Pop-up");
            TestUtils.select(driver, selectCustomer, cust);
        }
    }

    private void selectProviderRoleOnProviderEligiblity(String  providerRole) {
        if (!(validateEmptyString(providerRole))) {
            log.warn(" Select  Provider Role on the Add Pop-up");
            TestUtils.select(driver,  selectProviderRole, providerRole);
        }
    }
    private void enterDescProviderEligiblity(String     desc) {
        if (!(validateEmptyString(desc))) {
            log.warn("Enter  Description on the Add Pop-up");
            TestUtils.input(driver,selectDesc, desc);

        }
    }
    private void selectRuleOutcomeProviderEligiblity(String      outCome) {
        if (!(validateEmptyString(outCome))) {
            log.warn("select  Rule OutCome on the Add Pop-up");
            TestUtils.select(driver, selectRuleOutcome,  outCome);
        }
    }

    private void selectSaliencyProviderEligiblity(String  sal) {
        if (!(validateEmptyString(sal))) {
            log.warn("select Saliency on the Add Pop-up");
            TestUtils.input(driver,  saliency,  sal);
        }
    }
}

