package atdd.test.pageobjects.security;

import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class SecurityPage {

    private static Logger log = Logger.getLogger(SecurityPage.class);
    private Scenario scenario;
    private WebDriver driver;
    private TestUtils testUtils = new TestUtils();
    private By permissionId = By.xpath("//input[@ng-model='record.permissionID']");
    private By DescPermission = By.xpath("//input[@ng-model='record.permissionDesc']");
    private By permissionGroupId = By.xpath("//input[@ng-model='record.permissionGroupID']");
    private By DescPermissionGroup = By.xpath("//input[@ng-model='record.permissionGroupDesc']");
    private By savePermission = By.xpath("//input[@value='Save']");
    private By editPermissionGroup = By.xpath("//*[@id=\"permissionGroupModelID\"]/tbody/tr[3]/td[1]/span");
    private By editPermission = By.xpath("//*[@id=\"permissionModelID\"]/tbody/tr[3]/td[1]/span");
    private By editUser = By.xpath("//*[@id=\"userTableID\"]/tbody/tr[1]/td[1]/span");


    public SecurityPage(WebDriver driver) {
        this.driver = driver;
    }


    public void enterPermissionId(String id) {
        log.warn("Enters PermissionId");
        TestUtils.input(driver,permissionId,id);
    }

    public void enterDescription(String desc) {
        log.warn("Enters Description");
        TestUtils.input(driver,DescPermission,desc);
    }

    public void clickOnSavePermissionButton() {
        log.warn("Clicks on save button");
        TestUtils.click(driver,savePermission);
    }

    public void clickOnEditPermissionIcon() {
        log.warn("Clicks on edit permision Icon");
        TestUtils.click(driver,By.xpath("(//span[@title='Edit'])[1]"));
    }

    public void enterPermissionGroupId(String id) {
        log.warn("Enters PermissionGroupId");
        TestUtils.input(driver,permissionGroupId,id);
    }

    public void enterPermissionGroupDescription(String desc) {
        log.warn("Enters Description");
        TestUtils.input(driver,DescPermissionGroup,desc);
    }

    public void clickOnEditPermissionGroupIcon() {
        log.warn("Clicks on edit permision group Icon");
        TestUtils.click(driver,editPermissionGroup);
    }

    public void clickOnEditUserIcon() {
        log.warn("Clicks on edit user Icon");
        TestUtils.click(driver,editUser);
    }
}
