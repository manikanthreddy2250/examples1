package atdd.test.pageobjects.supportiveMaintenance;

import atdd.test.shared.BaseCucumber;
import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

import static org.openqa.selenium.By.cssSelector;

/**
 * Created by pvavilal on 2/12/19.
 */
public class AddSupportiveDrugsModalPage {
    Logger log;
    private WebDriver driver;
    private TestUtils utils;

    //Locators--------
    private By drugCodeXpath = By.xpath("//*[contains (@id, 'record-procedureCode')]");
    private By drugnameXpath = By.cssSelector("[name='supportiveDrugTable.editPopupForm'] [name='Treatment Supp Care Procedure Desc']");
    private By drugTypeXpath = By.cssSelector("[name='supportiveDrugTable.editPopupForm'] select[ref-nm='supportiveType']");
    private By dosageXpath = By.xpath("//input[@id= 'supportiveDrugDosage']");
    private By drugRoutXpath = By.xpath("//*[@id='record-medicationAdminRouteType-0']");
    private By cycleXpath = By.xpath("//*[@id='supportiveDrugCycle']");
    private By lengthOfCyclesXpath = By.xpath("//*[@id='supportiveDrugLenOfCycle']");
    private By authorizationDurationXpath = By.xpath("//*[@id='supportiveDrugAuthDuration']");
    private By startDateXpath = By.xpath("//input[contains(@id,'record-startDate')]");
    private By inactiveDateXpath = By.xpath("//input[contains(@id,'record-endDate')]");
    private By messageXpath = By.xpath(".//*[@id='supportiveDrugMessage']");
    private By saveButton = cssSelector("input[ng-click*='supportiveDrugTable'][value='Save']");
    private By cancerTypeXpath = By.xpath("//*[@id='record-diseaseType-0']");
    private By cancerTypeLabel = By.xpath("//*[@id='supportiveDrugDiseaseTypeLabel']/label[text()= 'Cancer Type']");

    public AddSupportiveDrugsModalPage(WebDriver webDriver) {
        driver = webDriver;
        utils = BaseCucumber.utils;
        log = Logger.getLogger(this.getClass().getName());
    }

    //Methods

    /**
     * Entering DrugCode in Add Supportive Drugs PopUp
     *
     * @param drugCode
     */
    public void enterDrugCode(String drugCode) {
        log.warn("Entering Drug Code");
        TestUtils.highlightElement(driver, drugCodeXpath);
        driver.findElement(drugCodeXpath).sendKeys(drugCode);
        By primaryCancerDropDown = By.xpath("  //a[contains(@title,'" + drugCode + "')]");
        TestUtils.wait(3);
        TestUtils.wait(2);
        driver.findElement(primaryCancerDropDown).click();

    }

    /**
     * Entering Drug Name in Add Supportive Drugs PopUp
     *
     * @param drugName
     */
    public void enterDrugName(String drugName) {
        log.warn("Entering Drug Name");
        TestUtils.highlightElement(driver, drugnameXpath);
        driver.findElement(drugnameXpath).clear();
        driver.findElement(drugnameXpath).sendKeys(drugName);

    }

    /**
     * selecting DrugType in Add Supportive Drugs PopUp
     *
     * @param drugType
     */
    public void selectDrugType(String drugType) {
        log.warn("Select " + drugType + " as Drug Type");
        TestUtils.highlightElement(driver, drugTypeXpath);
        TestUtils.selectByVisibleText(driver.findElement(drugTypeXpath), drugType);
    }

    /**
     * Entering Dosage in Add Supportive Drugs PopUp
     *
     * @param dosage
     */
    public void enterDosage(String dosage) {
        log.warn("Entering Dosage");
        TestUtils.highlightElement(driver, dosageXpath);
        driver.findElement(dosageXpath).clear();
        driver.findElement(dosageXpath).sendKeys(dosage);

    }

    /**
     * Entering Drug Route in Add Supportive Drugs PopUp
     *
     * @param drugRoute
     */
    public void enterDrugRoute(String drugRoute) {
        log.warn("Entering Drug Route");
        TestUtils.highlightElement(driver, drugRoutXpath);
        driver.findElement(drugRoutXpath).sendKeys(drugRoute);
    }

    /**
     * Entering Cycle To Be Administered in Add Supportive Drugs PopUp
     *
     * @param cycle
     */
    public void enterCycleToBeAdministered(String cycle) {
        log.warn("Entering Cycle To Be Administered");
        TestUtils.highlightElement(driver, cycleXpath);
        driver.findElement(cycleXpath).clear();
        driver.findElement(cycleXpath).sendKeys(cycle);
    }

    /**
     * Entering lenghtOfCycle in Add Supportive Drugs PopUp
     *
     * @param lenghtOfCycle
     */
    public void enterLengthOfCycles(String lenghtOfCycle) {
        log.warn("Entering length od Cycle");
        TestUtils.highlightElement(driver, lengthOfCyclesXpath);
        driver.findElement(lengthOfCyclesXpath).clear();
        driver.findElement(lengthOfCyclesXpath).sendKeys(lenghtOfCycle);
    }

    /**
     * Entering authorization duration in Add Supportive Drugs PopUp
     *
     * @param authDuration
     */
    public void enterAuthorizationDuration(String authDuration) {
        log.warn("Entering length od Cycle");
        TestUtils.highlightElement(driver, authorizationDurationXpath);
        driver.findElement(authorizationDurationXpath).clear();
        driver.findElement(authorizationDurationXpath).sendKeys(authDuration);
    }

    /**
     * User enters start date in Add Supportive Drug PopUp
     *
     * @param startDate
     */
    public void enterStartDate(String startDate) {
        log.warn("Entering length od Cycle");
        TestUtils.highlightElement(driver, startDateXpath);
        driver.findElement(startDateXpath).clear();
        driver.findElement(startDateXpath).sendKeys(startDate);
    }

    /**
     * User enters inactive date in Add Supportive Drug PopUp
     *
     * @param inactiveDate
     */
    public void enterInactiveDate(String inactiveDate) {
        log.warn("Entering length od Cycle");
        TestUtils.highlightElement(driver, inactiveDateXpath);
        driver.findElement(inactiveDateXpath).clear();
        driver.findElement(inactiveDateXpath).sendKeys(inactiveDate);
    }

    /**
     * User enters message in Add Supportive Drug PopUp
     *
     * @param message
     */
    public void enterMessage(String message) {
        log.warn("Entering length od Cycle");
        TestUtils.highlightElement(driver, messageXpath);
        driver.findElement(messageXpath).clear();
        driver.findElement(messageXpath).sendKeys(message);
    }

    /**
     * User clicks Save button on Add Supportive Drug PopUp
     */
    public void clickSaveButton() {
        log.warn("Click Save Button Add Supportive Drugs ");
        driver.findElement(saveButton).click();
    }

    /**
     * verifying drug type is present in drug type dropdown in Add Supportive Drugs PopUp
     *
     * @param drugType
     */
    public void verifyDrugType(String drugType) {
        By drugTypeSelector = By.xpath("//*[@id='record-treatmentSuppCareType-0']/option");
        List<WebElement> options = driver.findElements(drugTypeSelector);
        boolean isMatched = false;
        for (WebElement option : options) {
            if (option.getText().equals(drugType)) {
                isMatched = true;
                break;
            }
        }
        Assert.assertTrue(" drugType is not matched with dropw down values in the pop up", isMatched);

    }

    /**
     * selecting Cancer type in Add Supportive Drugs PopUp
     *
     * @param cancerType
     */
    public void selectCancerType(String cancerType) {
        log.warn("Select " + cancerType + " as Drug Type");
        TestUtils.highlightElement(driver, cancerTypeXpath);
        TestUtils.selectByVisibleText(driver.findElement(cancerTypeXpath), cancerType);
    }

    /**
     * verifying cancer Type is present in the supportive drug column
     */
    public void verifyCancerType() {
        log.warn("verfying cancer Typer is present in the supportive drug column .");
        Assert.assertTrue("cancer Typer is not present in the supportive drug column", TestUtils.isElementPresent(driver, cancerTypeLabel));
        TestUtils.highlightElement(driver, cancerTypeLabel);
    }

    /**
     * verifying drugCode present in the add supportive drug modal popup
     *
     * @param drugCode
     */
    public void verifyDrugCode(String drugCode) {
        log.warn("verifying " + drugCode + " present in the add supportive drug modal popup.");
        Assert.assertTrue(drugCode + "Not present in the add supportive drug modal popup.",
                TestUtils.isElementPresent(driver.findElement(By.xpath("//*[@name='supportiveDrugTable.editPopupForm']//span[text()='" + drugCode + "']"))));
        TestUtils.highlightElement(driver, driver.findElement(By.xpath("//*[@name='supportiveDrugTable.editPopupForm']//span[text()='" + drugCode + "']")));
    }
}
