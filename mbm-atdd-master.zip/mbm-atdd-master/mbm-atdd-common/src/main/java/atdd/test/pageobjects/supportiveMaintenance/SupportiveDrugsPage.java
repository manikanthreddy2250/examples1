package atdd.test.pageobjects.supportiveMaintenance;

import atdd.test.shared.BaseCucumber;
import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by pvavilal on 2/12/19.
 */
public class SupportiveDrugsPage {

    private final WebDriver driver;
    Logger log;
    private TestUtils utils;

    //Locators--------
    public static By deleteIcon = By.xpath("//*[@id='supportiveDrugTableID']/tbody/tr/td/span[3]");
    public static By yesButton = By.xpath("//*[@value='Yes']");
    public static By cancerTypeColumnHeader = By.xpath("//*[@class='tk-dtbl-header-cell']/span[text()= 'Cancer Type']");
    public static By drugCodes = By.xpath("//*[@id='supportiveDrugTableID']/tbody/tr/td[2]/span");
    public static By drugDetails = By.xpath("//*[@id='supportiveDrugTableID']/tbody/tr");
    public static By drugTypeInput = By.xpath("//input[@ng-model='supportiveDrugTable.tableFilters.treatmentSuppCareType']");
    public static By drugRouteInput = By.xpath("//input[@ng-model='supportiveDrugTable.tableFilters.medicationAdminRouteType']");
    public static By cancerTypeInput = By.xpath("//input[@ng-model='supportiveDrugTable.tableFilters.diseaseType']");
    public static By cancerTypeDropDownList = By.xpath("//input[@ng-model='supportiveDrugTable.tableFilters.diseaseType']/following-sibling::ul");
    public static By searchButton = By.xpath("//input[@value='Search']");
    public static By pagination = By.xpath("//div[@ng-if='supportiveDrugTable.pagination']");
    public static By footer = By.xpath("//table[@id='supportiveDrugTableID']/tfoot");

    private WebDriver driver() {
        return driver;
    }

    public SupportiveDrugsPage(WebDriver webDriver) {
        this.driver = webDriver;
        utils = BaseCucumber.utils;
        log = Logger.getLogger(this.getClass().getName());
    }

    //Methods

    /**
     * Clicking Edit Icon on Supportive Drugs Page
     */
    public void clickEditIcon() {
        log.warn("clicking Edit (pencil) Icon present in Supportive Drugs grid .");
        TestUtils.wait(2);
        driver().findElement(By.xpath("//*[@id='supportiveDrugTableID']/tbody/tr[1]/td[1]//span[@title='Edit']")).click();

    }

    /**
     * Clicking Delete Icon present in Supportive Drugs grid
     */
    public void clcikDeleteIcon() {
        log.warn("clicking Delete Icon present in Supportive Drugs grid .");
        driver().findElement(deleteIcon).click();
    }

    /**
     * Clicking Yes Button in Supportive Drugs grid
     */
    public void clickYesButton() {
        log.warn("clicking Yes Button in Supportive Drugs grid .");
        driver().findElement(yesButton).click();
    }

    /**
     * Verifying cancer Typer is present in the supportive drug column
     */
    public void verifyCancerType() {
        log.warn("verfying cancer Typer is present in the supportive drug column .");
        Assert.assertTrue("cancer Typer is not present in the supportive drug column", TestUtils.waitElement(driver, cancerTypeColumnHeader));
        TestUtils.highlightElement(driver, cancerTypeColumnHeader);
    }

    /**
     * verfying supportive drug details
     *
     * @param drugCode
     * @param drugName
     * @param drugType
     * @param cancerType
     * @param drugRoute
     * @param authorizationDuration
     * @param startDate
     * @param inactiveDate
     */
    public void verifySupportiveDrugDetails(String drugCode, String drugName, String drugType, String cancerType, String drugRoute, String authorizationDuration, String startDate, String inactiveDate) {
        log.warn("verfying supportive drug details.");
        TestUtils.wait(3);
        for (int i = 1; i <= driver().findElements(drugCodes).size(); i++) {
            if (driver().findElement(By.xpath("//*[@id='supportiveDrugTableID']/tbody/tr[" + i + "]/td[2]/span")).getText().equals(drugCode)
                    && driver().findElement(By.xpath("//*[@id='supportiveDrugTableID']/tbody/tr[" + i + "]/td[3]/span")).getText().equals(drugName)
                    && driver().findElement(By.xpath("//*[@id='supportiveDrugTableID']/tbody/tr[" + i + "]/td[7]/span")).getText().equals(authorizationDuration)) {
                TestUtils.highlightElement(driver, driver().findElement(By.xpath("//*[@id='supportiveDrugTableID']/tbody/tr[" + i + "]/td[2]/span")));
                Assert.assertTrue("drugCode is not saved correctly.", driver().findElement(By.xpath("//*[@id='supportiveDrugTableID']/tbody/tr[" + i + "]/td[2]/span")).getText().equals(drugCode));
                TestUtils.highlightElement(driver, driver().findElement(By.xpath("//*[@id='supportiveDrugTableID']/tbody/tr[" + i + "]/td[3]/span")));
                Assert.assertTrue("drugName is not saved correctly.", driver().findElement(By.xpath("//*[@id='supportiveDrugTableID']/tbody/tr[" + i + "]/td[3]/span")).getText().equals(drugName));
                TestUtils.highlightElement(driver, driver().findElement(By.xpath("//*[@id='supportiveDrugTableID']/tbody/tr[" + i + "]/td[4]/span")));
                Assert.assertTrue("drugType is not saved correctly.", driver().findElement(By.xpath("//*[@id='supportiveDrugTableID'" +
                        "]/tbody/tr[" + i + "]/td[4]/span")).getText().equals(drugType));
                TestUtils.highlightElement(driver, driver().findElement(By.xpath("//*[@id='supportiveDrugTableID']/tbody/tr[" + i + "]/td[5]/span")));
                Assert.assertTrue("cancerType is not saved correctly.", driver().findElement(By.xpath("//*[@id='supportiveDrugTableID']/tbody/tr[" + i + "]/td[5]/span")).getText().equals(cancerType));
                TestUtils.highlightElement(driver, driver().findElement(By.xpath("//*[@id='supportiveDrugTableID']/tbody/tr[" + i + "]/td[6]/span")));
                Assert.assertTrue("drugRoute is not saved correctly.", driver().findElement(By.xpath("//*[@id='supportiveDrugTableID']/tbody/tr[" + i + "]/td[6]/span")).getText().equals(drugRoute));
                TestUtils.highlightElement(driver, driver().findElement(By.xpath("//*[@id='supportiveDrugTableID']/tbody/tr[" + i + "]/td[7]/span")));
                Assert.assertTrue("authorizationDuration is not saved correctly.", driver().findElement(By.xpath("//*[@id='supportiveDrugTableID']/tbody/tr[" + i + "]/td[7]/span")).getText().equals(authorizationDuration));
                TestUtils.highlightElement(driver, driver().findElement(By.xpath("//*[@id='supportiveDrugTableID']/tbody/tr[" + i + "]/td[8]/span")));
                Assert.assertTrue("start date is not saved correctly.", driver().findElement(By.xpath("//*[@id='supportiveDrugTableID']/tbody/tr[" + i + "]/td[8]/span")).getText().equals(startDate));
                TestUtils.highlightElement(driver, driver().findElement(By.xpath("//*[@id='supportiveDrugTableID']/tbody/tr[" + i + "]/td[9]/span")));
                Assert.assertTrue("inactive date is not saved correctly.", driver().findElement(By.xpath("//*[@id='supportiveDrugTableID']/tbody/tr[" + i + "]/td[9]/span")).getText().equals(inactiveDate));
                break;
            }
        }
    }

    /**
     * Deleting supportive drug details
     *
     * @param drugCode
     * @param drugName
     * @param authorizationDuration
     */
    public void deleteSupportiveDrug(String drugCode, String drugName, String authorizationDuration) {
        log.warn("deleting supportive drug details.");
        for (int i = 1; i <= driver().findElements(drugCodes).size(); i++) {
            if (driver().findElement(By.xpath("//*[@id='supportiveDrugTableID']/tbody/tr[" + i + "]/td[2]/span")).getText().equals(drugCode)
                    && driver().findElement(By.xpath("//*[@id='supportiveDrugTableID']/tbody/tr[" + i + "]/td[3]/span")).getText().equals(drugName)
                    && driver().findElement(By.xpath("//*[@id='supportiveDrugTableID']/tbody/tr[" + i + "]/td[7]/span")).getText().equals(authorizationDuration)) {
                driver().findElement(By.xpath("//*[@id='supportiveDrugTableID']/tbody/tr[" + i + "]/td[1]/span[3]")).click();
                break;
            }
        }
    }

    /**
     * Verifying delete confirmation message.
     *
     * @param drugName
     */
    public void verifyDeleteConfirmationMessage(String drugName) {
        log.warn("verifying delete confirmation message.");
        String expectedConfirmationMessage = "Are you sure you want to delete " + drugName + "?";
        String actualConfirmationMessage = driver().findElement(By.xpath("//*[@name='supportiveDrugDeletePopupForm']/div/p")).getText();
        TestUtils.highlightElement(driver, driver().findElement(By.xpath("//*[@name='supportiveDrugDeletePopupForm']/div/p")));
        Assert.assertTrue("delete confirmation message does not match.", actualConfirmationMessage.equals(expectedConfirmationMessage));

    }

    /**
     * Verifying drug deleted or not
     *
     * @param drugName
     */
    public void verifyDrugDeletedSuccessfuly(String drugName) {
        log.warn("verifying drug deleted or not");
        TestUtils.wait(2);
        Assert.assertFalse("drug not deleted", TestUtils.waitElement(driver,
                By.xpath("//*[@id='supportiveDrugTableID']/tbody/tr/td[3]/span[text()='" + drugName + "']")));

    }

    /**
     * Deleting supportive drug details.
     *
     * @param drugCode
     * @param drugName
     * @param authorizationDuration
     */
    public void editSupportiveDrug(String drugCode, String drugName, String authorizationDuration) {
        log.warn("deleting supportive drug details.");
        for (int i = 1; i <= driver().findElements(drugCodes).size(); i++) {
            if (driver().findElement(By.xpath("//*[@id='supportiveDrugTableID']/tbody/tr[" + i + "]/td[2]/span")).getText().equals(drugCode)
                    && driver().findElement(By.xpath("//*[@id='supportiveDrugTableID']/tbody/tr[" + i + "]/td[3]/span")).getText().equals(drugName)
                    && driver().findElement(By.xpath("//*[@id='supportiveDrugTableID']/tbody/tr[" + i + "]/td[7]/span")).getText().equals(authorizationDuration)) {
                driver().findElement(By.xpath("//*[@id='supportiveDrugTableID']/tbody/tr[" + i + "]/td[1]/span[2]")).click();
                break;
            }
        }
    }

    public void clickSearchButton() {
        log.warn("Clicking Search button on Supportive Drugs page.");
        TestUtils.click(driver(), searchButton);
    }

    public String getPaginationText() {
        log.warn("Getting pagination text on Supportive Drugs page.");
        String text = TestUtils.text(driver(), pagination);
        return text;
    }

    public void inputCancerType(String text) {
        TestUtils.input(driver(), cancerTypeInput, text);
    }

    public List<String> getCancerTypeDropdownList() {
        List<String> result = new ArrayList<>();
        WebElement dropDownElement = driver().findElement(cancerTypeDropDownList);
        List<WebElement> liElements = dropDownElement.findElements(By.xpath("li"));
        for (WebElement li : liElements) {
            result.add(li.getText());
        }
        return result;
    }

    public String getCancerTypeValue() {
        return TestUtils.value(driver(), cancerTypeInput);
    }

    public String getFooterMessage() {
        return TestUtils.text(driver(), footer);
    }
}
