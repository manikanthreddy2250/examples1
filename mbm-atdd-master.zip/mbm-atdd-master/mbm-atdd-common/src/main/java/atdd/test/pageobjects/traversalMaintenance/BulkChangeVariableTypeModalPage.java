package atdd.test.pageobjects.traversalMaintenance;

import atdd.test.shared.BaseCucumber;
import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class BulkChangeVariableTypeModalPage {

    Logger log;
    private WebDriver driver;
    private TestUtils utils;


    private By title = By.xpath("//div[contains(@ng-focus,'bulkEditTraversalPopupModel')]/h2");
    private By cancelBtn = By.xpath("//div[@id='bulkEditVariableTypeButtons']//input[@aria-label='traversalCancelButton']");
    private By apply = By.xpath("//div[@id='bulkEditVariableTypeButtons']//input[@aria-label='traversalVariableSaveButton']");
    private By fromSelect = By.xpath("//select[contains(@id, 'bulkEditVariableType-fromType')]");
    private By toSelect = By.xpath("//select[contains(@id, 'bulkEditVariableType-toType')]");

    private By fromVariableType = By.xpath("//select[contains(@id,'bulkEditVariable-clinicalVariables-type')]");
    private By toVariableType = By.xpath("//*[contains(@id,'bulkEditVariableType-toType')]");
    private By applyButtonBulkChangeVariableType = By.xpath("//*[@id='bulkEditVariableTypeButtons']/input[1]");
    private By bulkChangeVariableTypeValue = By.xpath("//*[contains(@id,'bulkEditVariable-clinicalVariables')]");
    private By invalidcharacterOrDuplicateValueErrorMessage = By.xpath("//span[contains(@id,'popupGlobalMessages')]/span");
    private By experrmsg = By.xpath("//div[text()='Invalid format']");
    private By bulkChangeVariableValueErrorPopup = By.xpath("//*[contains(@id,'popupGlobalMessages')]/div/button/span[1]");
    private By cuxIconCaretrRight = By.xpath("//span[@class='ocm-action tk-panl-helper ng-scope cux-icon-caret_right'][1]");
    private By actualVariableVal = By.xpath("//*[contains(@id,'diseaseTraversalDrawer')]/td[2]/table/tbody/tr[1]/td[2]");

    public BulkChangeVariableTypeModalPage(WebDriver webDriver) {
        super();
        this.driver = webDriver;
        utils = BaseCucumber.utils;
        log = Logger.getLogger(this.getClass().getName());
    }

    /**
     * Checking Bulk Modal title
     */
    public String getTitle() {
        log.warn("Getting Bulk Modal Title");
        TestUtils.highlightElement(driver, title);
        return this.driver.findElement(title).getText();
    }

    /**
     * Click Cancel button
     */
    public void clickCancelBtn() {
        log.warn("Click Calcel Button on Bulk Change Variable Type");
        TestUtils.waitElement(driver, cancelBtn);
        this.driver.findElement(cancelBtn).click();
    }

    /**
     * Click Apply Button
     */
    public void clickApply() {
        log.warn("Click Apply Button in Bulk Change Variable Type Modal");
        TestUtils.waitElement(driver, apply);
        this.driver.findElement(apply).click();
    }

    /**
     * Selecting option from From Variable Type dropdown
     *
     * @param option
     */
    public void selectFromType(String option) {
        log.warn("Selecting option " + option + " From Variable Type in Bulk Change Variable Type Modal");
        TestUtils.waitElement(driver, fromSelect);
        TestUtils.selectByVisibleText(driver, fromSelect, option);
    }

    /**
     * Selecting option to From Variable Type dropdown
     *
     * @param option
     */
    public void selectToType(String option) {
        log.warn("Selecting option " + option + " To Variable Type in Bulk Change Variable Type Modal");
        TestUtils.waitElement(driver, toSelect);
        TestUtils.selectByVisibleText(driver, toSelect, option);
    }

}
