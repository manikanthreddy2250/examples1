package atdd.test.pageobjects.traversalMaintenance;

import atdd.test.shared.BaseCucumber;
import atdd.test.shared.Globals;
import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class BulkChangeVariableValueModalPage {

    Logger log;
    private By title = By.xpath("//div[contains(@ng-focus,'bulkEditTraversalPopupModel')]/h2");
    private By bulkEditDescription = By.xpath("//div[@class='bulkEditDescription']");
    private By bulkEditVarValTypeLabel = By.xpath("//span[@id='bulkEditVarValTypeLabel']/label");
    private By bulkEditVarValValueLabel = By.xpath("//span[@id='bulkEditVarValValueLabel']/label");
    private By bulkEditVarValType = By.xpath("//select[@ng-model='bulkEditVariable.clinicalVariables.type']");
    private By bulkEditVarValValue = By.xpath("//select[@ng-model='bulkEditVariable.clinicalVariables.value']");
    private By cancelLink = By.xpath("//div[@id='bulkEditVariableValueButtons']/input[@aria-label='traversalCancelButton']");
    private By applyButton = By.xpath("//div[@id='bulkEditVariableValueButtons']/input[@aria-label='traversalVariableSaveButton']");
    private By xoutButton = By.xpath("//button[@ng-click='bulkEditTraversalPopupModel.closePopup()']");
    private By toVariableType = By.xpath("//*[contains(@id,'bulkEditVariableType-toType')]");
    private By applyButtonBulkChangeVariableType = By.xpath("//*[@id='bulkEditVariableTypeButtons']/input[1]");
    private By bulkChangeVariableTypeValue = By.xpath("//select[@ng-model='bulkEditVariable.clinicalVariables.type']");
    private By invalidcharacterOrDuplicateValueErrorMessage = By.xpath("//span[contains(@id,'popupGlobalMessages')]/span");
    private By experrmsg = By.xpath("//div[text()='Invalid format']");
    private By bulkChangeVariableValueErrorPopup=  By.xpath("//*[contains(@id,'popupGlobalMessages')]/div/button/span[1]");
    private By cuxIconCaretrRight=  By.xpath("//span[@class='ocm-action tk-panl-helper ng-scope cux-icon-caret_right'][1]");
    private By actualVariableVal = By.xpath("//*[contains(@id,'diseaseTraversalDrawer')]/td[2]/table/tbody/tr[1]/td[2]");

    private WebDriver driver;
    private TestUtils utils;
    private Globals globals;

    public BulkChangeVariableValueModalPage(WebDriver webDriver) {
        super();
        this.driver = webDriver;
        utils = BaseCucumber.utils;
        log = Logger.getLogger(this.getClass().getName());

    }

    public String getTitle() {
        return this.driver.findElement(title).getText();
    }

    public String getBulkEditDescription() {
        return this.driver.findElement(bulkEditDescription).getText();
    }

    public String getVariableTypeLabel() {
        return this.driver.findElement(bulkEditVarValTypeLabel).getText().split(",")[0].trim();
    }

    public String getVariableValueLabel() {
        return this.driver.findElement(bulkEditVarValValueLabel).getText().split(",")[0].trim();
    }

    public String getSelectedVariableType() {
        return this.driver.findElement(bulkEditVarValType).getAttribute("value");
    }

    public String getVariableValue() {
        return this.driver.findElement(bulkEditVarValValue).getAttribute("value");
    }

    public void clickCancelLink() {
        this.driver.findElement(cancelLink).click();
    }

    /**
     * clicking X Button
     */
    public void clickXoutButton() {
        this.driver.findElement(xoutButton).click();
    }

    /**
     * clicking Apply Button
     */
    public void clickApplyButton() {
        this.driver.findElement(applyButton).click();
    }

    public void shouldDisappear() {
        Wait wait = new WebDriverWait(this.driver, 5000);
        wait.until(ExpectedConditions.invisibilityOfElementLocated(title));
    }

    /**
     * get variable typeOptions
     * @return
     */
    public Set<String> getVariableTypeOptions() {
        String sOptions = this.driver.findElement(bulkEditVarValType).getText();
        String[] options = sOptions.split("\n");
        Set<String> optionSet = new HashSet<String>(Arrays.asList(options));
        return optionSet;
    }

    /**
     * Entering Variable type
     * @param type
     */
    public void enterVariableType(String type) {
        Select select = new Select(this.driver.findElement(bulkEditVarValType));
        select.selectByVisibleText(type);
    }

    /**
     * Entering Variable Value
     * @param value
     */
    public void enterVariableValue(String value) {
        Select select = new Select(this.driver.findElement(bulkEditVarValValue));
        select.selectByVisibleText(value);
    }


    /**
     User enterVariableTypeValue in the model page
     */
    public void enterVariableTypeValue(String value) {
        log.warn("User enterVariableTypeValue in the model page\n");
        TestUtils.waitElement(driver, toVariableType);
        TestUtils.highlightElement(driver, toVariableType);
        Select select = new Select(this.driver.findElement(toVariableType));
        select.selectByVisibleText(value);
    }

    /**
     User clicking Apply Button BulkChange VariableType
     */
    public void clickApplyButtonBulkChangeVariableType() {
        log.warn("clickApplyButtonBulkChangeVariableType");
        TestUtils.waitElement(driver, applyButtonBulkChangeVariableType);
        TestUtils.highlightElement(driver, applyButtonBulkChangeVariableType);
        this.driver.findElement(applyButtonBulkChangeVariableType).click();

    }


    /**
     enteringVariableTypeInBulkChangeVariableValue
     */
    public void enterVariableTypeInBulkChangeVariableValue(String type) {
        log.warn("enterVariableTypeInBulkChangeVariableValue");
        TestUtils.waitElement(driver, bulkChangeVariableTypeValue);
        TestUtils.highlightElement(driver, bulkChangeVariableTypeValue);
        Select select = new Select(this.driver.findElement(bulkChangeVariableTypeValue));
        select.selectByVisibleText(type);
    }

    /**DUPE check Type or value Check 3 Tr
     * Verifying "Duplicate Variable Type error message,There is a duplicate traversal combination in the selected
     * traversals, please correct the traversal entries in order to proceed.
     */
    public void verifyingBulkEditVariableDuplicateCheckErrorMessagefor3Traversals() {
        log.warn("Verifying \"Duplicate Variable Value error message,There is a duplicate traversal combination in the selected traversals, please correct the traversal entries in order to proceed.");
        TestUtils.waitElement(driver, invalidcharacterOrDuplicateValueErrorMessage);
        TestUtils.highlightElement(driver, invalidcharacterOrDuplicateValueErrorMessage);
        String expectedError = "The traversal combination that has been entered already exists, please correct the traversal in order to proceed.";
        String actualError=this.driver.findElement(invalidcharacterOrDuplicateValueErrorMessage).getText();
        Assert.assertEquals("Duplicate Type, please update your variable Type",expectedError,actualError);
    }

    /**DUPE type check 2tr
     * Verifying "Duplicate Variable Type error message,There is a duplicate traversal combination in the selected
     * traversals, please correct the traversal entries in order to proceed.
     */

    public void verifyingBulkEditVariableDuplicateCheckErrorMessagefor2Traversals() {
        log.warn("Verifying \"Duplicate Variable Type Value error message,Cannot add duplicate variable type");
        TestUtils.waitElement(driver, invalidcharacterOrDuplicateValueErrorMessage);
        TestUtils.highlightElement(driver, invalidcharacterOrDuplicateValueErrorMessage);
        String expectedError = "Cannot add duplicate variable type";
        String actualError=this.driver.findElement(invalidcharacterOrDuplicateValueErrorMessage).getText();
        Assert.assertEquals("Duplicate type, please update your variable Type value",expectedError,actualError);
    }

    /**
     * Verifying "Invalid character, please update your variable value"  message is displayed When enter ; or _  on BulkChangeVariableValue model
     */
    public void verifyingInvalidcharacterErrorMessage() {
        log.warn("VerifyingInvalidcharacterErrorMessage is dispalyed while entering invalid charactor ; or _");
        TestUtils.waitElement(driver, invalidcharacterOrDuplicateValueErrorMessage);
        TestUtils.highlightElement(driver, invalidcharacterOrDuplicateValueErrorMessage);
        String expectedError = "Invalid character, please update your variable value";
        String actualError = this.driver.findElement(invalidcharacterOrDuplicateValueErrorMessage).getText();
        Assert.assertEquals("Invalid character, please update your variable value", expectedError, actualError);
    }

    /**
     * clicksOn_X_InvalidcharacterErrorPopup
     */
    public void clicksOn_X_InvalidcharacterErrorPopup(){
        log.warn("clicksOn_X_InvalidcharacterErrorPopup");
        TestUtils.waitElement(driver, bulkChangeVariableValueErrorPopup);
        TestUtils.highlightElement(driver, bulkChangeVariableValueErrorPopup);
        TestUtils.click(this.driver,bulkChangeVariableValueErrorPopup);
    }

    /**
     * clearingTextinVariableValueTextField
     */
    public void clearTextinVariableValueTextField(){
        log.warn("clearTextinVariableValueTextField");
        TestUtils.waitElement(driver, bulkEditVarValValue);
        TestUtils.highlightElement(driver, bulkEditVarValValue);
        this.driver.findElement(bulkEditVarValValue).clear();
    }

    /**
     * Verifying "Duplicate Variable Type error message,Cannot add duplicate variable type
     */
    public void verifyingBulkEditVariableTypeDuplicateCheckErrorMessage() {
        log.warn("verifyingBulkEditVariableTypeDuplicateCheckErrorMessage");
        TestUtils.waitElement(driver, invalidcharacterOrDuplicateValueErrorMessage);
        TestUtils.highlightElement(driver, invalidcharacterOrDuplicateValueErrorMessage);
        String expectedError = "There is a duplicate traversal combination in the selected traversals, please correct the traversal entries in order to proceed.";
        String actualError=this.driver.findElement(invalidcharacterOrDuplicateValueErrorMessage).getText();
        Assert.assertEquals("Cannot add duplicate variable value",expectedError.trim(),actualError);
    }

    /**
     * clicks on cuxIcon Caretright
     */

    public void clicksOncuxIconCaretrRight(){
        log.warn("clicksOncuxIconCaretrRight");
        TestUtils.waitElement(driver, cuxIconCaretrRight);
        TestUtils.highlightElement(driver, cuxIconCaretrRight);
        TestUtils.click(this.driver,cuxIconCaretrRight);
    }

    /**
     * User Entering VariableValueWithLeadingAndTrailingSpaces
     * @param value
     */
    public void enterVariableValueWithLeadingAndTrailingSpaces(String value) {
        WebElement el = this.driver.findElement(bulkEditVarValValue);
        driver.findElement(bulkEditVarValValue).clear();
        el.clear();
        String valueWithSpaces="  "+value+"   ";
        el.sendKeys(valueWithSpaces);
    }

    /**
     * User getting Actual Varaible Value from UI
     */
    public String getActualVariabeVal() {
        log.warn("gettingActualVariabeVal");
        TestUtils.waitElement(driver, actualVariableVal);
        TestUtils.highlightElement(driver, actualVariableVal);
        String actVarVal = TestUtils.text(this.driver, actualVariableVal);
        return actVarVal;
    }


    /**
     * ReturningexpErrorMsgBy
     */
    public By expErrorMsgBy() {
        log.warn("expErrorMsgBy");
        TestUtils.waitElement(driver, bulkChangeVariableValueErrorPopup);
        TestUtils.highlightElement(driver, bulkChangeVariableValueErrorPopup);
        return experrmsg ;
    }

}