package atdd.test.pageobjects.traversalMaintenance;

import atdd.test.shared.BaseCucumber;
import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BulkDeleteModalPage {

    Logger log;
    private By title = By.xpath("//div[contains(@ng-focus,'bulkEditTraversalPopupModel')]/h2");
    private By bulkDeleteDescription = By.xpath("//*[@id='traversalBulkEditFieldTable']/p");
    private By cancelLink = By.xpath("//*[@ng-if='bulkDelete']/input[@aria-label='traversalCancelButton']");
    private By yesButton = By.xpath("//*[@ng-if='bulkDelete']/input[@aria-label='traversalSaveButton']");
    private By xoutButton = By.xpath("//button[@ng-click='bulkEditTraversalPopupModel.closePopup()']");
    private WebDriver driver;
    private TestUtils utils;


    public BulkDeleteModalPage(WebDriver webDriver) {
        this.driver = webDriver;
        utils = BaseCucumber.utils;
        log = Logger.getLogger(this.getClass().getName());
    }

    /**
     * Checking Bulk Modal title
     */
    public String getTitle() {
        log.warn("Getting Bulk Modal Title");
        TestUtils.highlightElement(driver, title);
        return this.driver.findElement(title).getText();
    }

    /**
     * Checking Bulk Modal Description
     */
    public String getBulkDeleteDescription() {
        log.warn("Getting Bulk Delete Description");
        TestUtils.highlightElement(driver, bulkDeleteDescription);
        return this.driver.findElement(bulkDeleteDescription).getText();
    }


    /**
     * Click Bulk Delete Cancel Link
     */
    public void clickCancelLink() {
        log.warn("Cancel out of Bulk Delete using Cancel Link");
        TestUtils.highlightElement(driver, cancelLink);
        this.driver.findElement(cancelLink).click();
    }

    /**
     * Click Bulk Delete X Out Button
     */
    public void clickXoutButton() {
        log.warn("Click x out of Bulk Delete using xout button");
        TestUtils.highlightElement(driver, xoutButton);
        this.driver.findElement(xoutButton).click();
    }

    /**
     * Click Bulk Delete Yes Button
     */
    public void clickYesButton() {
        log.warn("Click Yes Button in Bulk Modal");
        TestUtils.highlightElement(driver, yesButton);
        this.driver.findElement(yesButton).click();
    }

    /**
     * Verify Modal Disappears
     */
    public void shouldDisappear() {
        log.warn("Verify modal no longer appears after closing");
        Wait wait = new WebDriverWait(this.driver, 5000);
        wait.until(ExpectedConditions.invisibilityOfElementLocated(title));
    }

}
