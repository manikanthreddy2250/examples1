package atdd.test.pageobjects.traversalMaintenance;

import atdd.test.shared.BaseCucumber;
import atdd.test.shared.Globals;
import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BulkEditAuthorizationDurationModalPage {

    Logger log;
    private By title = By.xpath("//div[contains(@ng-focus,'bulkEditTraversalPopupModel')]/h2");
    private By bulkEditDescription = By.xpath("//div[@class='bulkEditDescription']");
    private By bulkEditDurationLabel = By.xpath("//span[@id='bulkEditAuthDurationLabel']/label");
    private By bulkEditDurationType = By.xpath("//*[@ng-model='bulkEditDuration.bulkEditDurationValue']");
    private By bulkEditDurationValue = By.id("bulkEditAuthDurationInput");
    private By bulkEditDurationValidationMsg = By.xpath("//*[@class='bulkGreaterThanZeroStyle ng-scope']");
    private By cancelLink = By.xpath("//div[@id='bulkEditAuthDurationButtons']/input[@aria-label='traversalCancelButton']");
    private By applyButton = By.xpath("//div[@id='bulkEditAuthDurationButtons']/input[@aria-label='traversalVariableSaveButton']");
    private By xoutButton = By.xpath("//button[@ng-click='bulkEditTraversalPopupModel.closePopup()']");


    private WebDriver driver;
    private TestUtils utils;
    private Globals globals;

    public BulkEditAuthorizationDurationModalPage(WebDriver webDriver) {
        super();
        this.driver = webDriver;
        utils = BaseCucumber.utils;
        log = Logger.getLogger(this.getClass().getName());

    }

    /**
     * Checking Bulk Modal title
     */
    public String getTitle() {
        log.warn("Getting Bulk Modal Title");
        return this.driver.findElement(title).getText();
    }

    /**
     * Checking Bulk Modal Description
     */
    public String getBulkEditDescription() {
        log.warn("Getting Bulk Edit Description");
        return this.driver.findElement(bulkEditDescription).getText();
    }

    /**
     * Checking Bulk Auth Duration Label
     */
    public String getDurationLabel() {
        log.warn("Getting Bulk Duration Label");
        return this.driver.findElement(bulkEditDurationLabel).getText().split(",")[0].trim();
    }

    /**
     * Checking Bulk Auth Duration Type
     */
    public String getEditDurationType() {
        log.warn("Getting Bulk Duration Type");
        return this.driver.findElement(bulkEditDurationType).getAttribute("value");
    }

    /**
     * Checking Bulk Auth Duration Type
     */
    public String getEditDurationValidationMsg() {
        log.warn("Getting Edit Duration Validation Message");
        TestUtils.highlightElement(driver, bulkEditDurationValidationMsg);
        return this.driver.findElement(bulkEditDurationValidationMsg).getText();
    }


    /**
     * Click Bulk Auth Duration Cancel Link
     */
    public void clickCancelLink() {
        log.warn("Cancel out of Bulk Auth Duration using Cancel Link");
        this.driver.findElement(cancelLink).click();
    }

    /**
     * Click Bulk Auth Duration X Out Button
     */
    public void clickXoutButton() {
        log.warn("Click x out of Bulk Auth Duration using xout button");
        this.driver.findElement(xoutButton).click();
    }

    /**
     * Click Bulk Auth Duration Apply Button
     */
    public void clickApplyButton() {
        log.warn("Click Apply Button in Bulk Modal");
        this.driver.findElement(applyButton).click();
    }

    /**
     * Verify Modal Disappears
     */
    public void shouldDisappear() {
        log.warn("Verify modal no longer appears after closing");
        Wait wait = new WebDriverWait(this.driver, 5000);
        wait.until(ExpectedConditions.invisibilityOfElementLocated(title));
    }

    /**
     * Enter Auth Duration Value
     */
    public void enterVariableValue(String value) {
        log.warn("Entering Auth Duration Value in Bulk Edit Modal");
        WebElement el = this.driver.findElement(bulkEditDurationValue);
        el.clear();
        el.sendKeys(value);
    }


}