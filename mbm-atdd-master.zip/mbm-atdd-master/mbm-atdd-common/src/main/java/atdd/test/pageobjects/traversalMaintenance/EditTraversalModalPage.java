package atdd.test.pageobjects.traversalMaintenance;

import atdd.test.shared.BaseCucumber;
import atdd.test.shared.Globals;
import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.util.List;

import static org.openqa.selenium.By.*;

public class EditTraversalModalPage extends TraversalMaintenancePage {

    public final static String F_EXTRACT_VALUE = "//table[@id='traversalAddEditClinicalVariableSelectionsTable']/tbody//td[contains(.,\"%s\")]/following-sibling::td[2]";

    private WebDriver driver;
    private TestUtils utils;
    private Globals globals;
    Logger log;
    public static Globals gv;
    private String owner;

    //Locators
    private By editTraversalPopUp = xpath("//*[@id='diseaseTraversalMaintenanceTable-editPopupID']//div[contains(@class, 'tk-lbox-dialog')]");
    private By saveButtonXpath = cssSelector("input[ng-click*='diseaseTraversalMaintenanceTable'][value='Save']");
    private By cancelButtonXpath = cssSelector("input[ng-click*='diseaseTraversalMaintenanceTable'][value='Cancel']");
    private By startDateCalenderpickerXpath = xpath("//*[@name='Start Date']/following-sibling::span/span[@title='Calendar']");
    private By endDateCalenderpickerXpath = xpath("//*[@name='End Date']/following-sibling::span/span[@title='Calendar']");
    private By popupEndDateXpath = name("End Date");
    private By popupauthorizationDuration = xpath("//*[@id='traversalAuthDurationEdit']  | //*[@id='traversalAuthDurationAdd']");
    private By popupauthorizationDurationAdd = xpath("//*[@id='traversalAuthDurationAdd']");
    private By clinicalVariableTitleXpath = cssSelector("[class='sectionHeader'] span");
    private By greyLineXpath = xpath("(//*[@class='sectionHeader']/span/following-sibling::hr)[1]");
    private By addClinicalVariabelLinkXpath = xpath("//a[text()=' Add Clinical Variable']");
    private By variableTypesXpath = xpath("(//strong[contains(text(), 'Type')]//../following-sibling::td[@class='ng-binding']) [position() mod 2 = 1 and position() >= 1]");//(//th[contains(text(), 'Type')]/following-sibling::td[@class='ng-binding']) [position() mod 2 = 1 and position() >= 1]"
    private By variableValuesXpath = xpath("(//strong[contains(text(), 'Type')]//../following-sibling::td[@class='ng-binding']) [position() mod 2 = 0 and position() >= 1]");//(//th[contains(text(), 'Type')]/following-sibling::td[@class='ng-binding']) [position() mod 2 = 0 and position() >= 1]"
    private By clinicalVariableAndTypeRows = xpath("//tr[@ng-if='record.diseaseTraversalClinicalVariableVOList']");
    private By removeLink = By.xpath("//a[text()='Remove']");
    private By cancerTypeDropDown = xpath("//*[@id='traversalCancerType']//select");
    private By cancerTypeDropDownSelectedOption = xpath("//select[@ng-model='record.diseaseType']/option[@ng-selected='true']");
    private By popupStartDateXpath = name("Start Date");
    private By variableTypeDropDownXpath = xpath("//*[@id='traversalVariableType']/select");
    private By variablevalueDropDownXpath = xpath("//select[@id='VariableText']");
    private By variableValueTextArea = xpath("//button[contains(@class,'multiSelectButton')]");
    private int variableTypeAndValueCountBeforeRemove;


    public EditTraversalModalPage(WebDriver webDriver) {
        super(webDriver);
        this.driver = webDriver;
        utils = BaseCucumber.utils;
        log = Logger.getLogger(this.getClass().getName());

    }

    //Methods

    /**
     * Checking text in the Variable Value text box
     *
     * @param variableValue
     */
    public void verifyVariableValue(String variableValue) {
        log.warn("verfying that Variable Value is: " + variableValue);
        TestUtils.highlightElement(driver, variableValueTextArea);
        String actualVariableValue = driver.findElement(variableValueTextArea).getAttribute("value");
        Assert.assertTrue("Variable value is: " + actualVariableValue + " expected: " + variableValue,
                variableValue.equals(actualVariableValue));
    }

    /**
     * Verifying Variable Type selection
     *
     * @param variableType
     */
    public void verifyVariableType(String variableType) {
        log.warn("verfying that Variable Type is: " + variableType);
        String actualVariableType = TestUtils.getSelectedValueFromDropdown(driver, variableTypeDropDownXpath);
        Assert.assertTrue("Variable Type is: " + actualVariableType + " expected: " + variableType,
                variableType.equals(actualVariableType));
        TestUtils.highlightElement(driver, driver.findElement(variableTypeDropDownXpath));
    }

    /**
     * verifying edit Traversal PopUp present
     */
    public void verifyEditTraversalPopUp() {
        log.warn("verifying edit Traversal PopUp present .");
        Assert.assertTrue("edit Traversal PopUp not present.", TestUtils.isElementPresent(driver, editTraversalPopUp));
        TestUtils.highlightElement(driver, editTraversalPopUp);
    }

    /**
     * Check that Element with expected text is present
     */
    public void checkElementByTextWithRequiredMark() {
        log.warn("Checking element by *Required text");
        TestUtils.wait(3);
        String expectedText = "* Required";
        boolean present = false;

        //Checking
        if (TestUtils.isElementPresent(driver, By.xpath("//div[@id='addEditTrvrsRequiredText']"))) {
            TestUtils.highlightElement(driver, By.xpath("//div[@id='addEditTrvrsRequiredText']"));
            String actualText = "* " + driver.findElement(By.xpath("//div[@id='addEditTrvrsRequiredText']")).getText();
            Assert.assertTrue("* Required text does not match", actualText.equals(expectedText));
            present = true;
        }

        Assert.assertTrue("Element with text *Required text is NOT visible. ", present);

    }

    /**
     * Check that element with Text has Required mark
     *
     * @param txt
     */
    public void checkRequiredElementByText(String txt) {
        log.warn("verifying required mark is present .");
        By elementTxt = By.xpath("(//*[contains(text(),'" + txt + "')]/span[@title='Required'])[2]");
        Assert.assertTrue("Element with text " + txt + " is NOT visible. ", TestUtils.isElementPresent(driver, elementTxt));
        TestUtils.highlightElement(driver, elementTxt);
    }

    /**
     * Verfying Cancer type as a Dropdown on Edit Traversal pop up
     */
    public void verifyCancerTypeAsDropDown() {
        log.warn("verifying Cancer Type Drop Down is present .");
        Assert.assertTrue("Cancer Type Drop Down is not present. ", TestUtils.isElementPresent(driver, cancerTypeDropDown));
        TestUtils.highlightElement(driver, cancerTypeDropDown);
    }

    /**
     * Verfying Start Date Pre-Populated on Edit Traversal pop up
     */
    public void verifyStartDatePrePopulated() {
        log.warn("verfying start date is prepopulated or not from Traversal Maintenance grid .");
        String actualStartDate = driver.findElement(popupStartDateXpath).getAttribute("value");
        TestUtils.highlightElement(driver, popupStartDateXpath);
        Assert.assertTrue("Start date does not match with pop up and grid. ", actualStartDate.equals(startDate));
    }

    /**
     * Verfying Calender Picker beside start date on Edit Traversal pop up
     */
    public void verifyCalenderPickerBesideStartDate() {
        log.warn("verfying calendar picker is present beside start date or not in the popup .");
        Assert.assertTrue("Calender picker is not visible beside start date ", TestUtils.isElementPresent(driver, startDateCalenderpickerXpath));
        TestUtils.highlightElement(driver, startDateCalenderpickerXpath);

    }

    /**
     * Verfying Calender Picker beside end date on Edit Traversal pop up
     */
    public void verifyCalenderPickerBesideEndDate() {
        log.warn("verfying calendar picker is present beside end date  or not in the popup .");
        Assert.assertTrue("Calender picker is not visible beside end date ", TestUtils.isElementPresent(driver, endDateCalenderpickerXpath));
        TestUtils.highlightElement(driver, endDateCalenderpickerXpath);

    }

    /**
     * Verfying End Date Pre-Populated on Edit Traversal pop up
     */
    public void verifyEndDatePrePopulated() {
        log.warn("verfying end date is prepopulated or not from Traversal Maintenance.");
        String actualEndDate = driver.findElement(popupEndDateXpath).getAttribute("value");
        TestUtils.highlightElement(driver, popupEndDateXpath);
        Assert.assertTrue("end date does not match with popoup and grid. ", actualEndDate.equals(endDate));

    }

    /**
     * Verfying Authorization Duration Pre-Populated on Edit Traversal pop up
     */
    public void verifyAuthorizationDurationPopulated() {
        log.warn("verfying Authorization Duration is prepopulated or not from Traversal Maintenance .");
        String actualAuthorizationDuration = driver.findElement(popupauthorizationDuration).getAttribute("value");
        TestUtils.highlightElement(driver, popupauthorizationDuration);
        actualAuthorizationDuration = actualAuthorizationDuration + " Month";
        Assert.assertTrue("Authorization Duration does not match with pop up and grid. ", actualAuthorizationDuration.equals(authorizationDuration));

    }

    /**
     * Verfying clinical variable Title on Edit Traversal pop up
     */
    public void verifyClinicalVariableTitle() {
        log.warn("verfying Clinical Variable Title is present or not in the pop up .");
        Assert.assertTrue("Clinical Variable Title is not present in the pop up", TestUtils.isElementPresent(driver, clinicalVariableTitleXpath));
        TestUtils.highlightElement(driver, clinicalVariableTitleXpath);
    }

    /**
     * Verfying grey line and color underneath clinical variable Title on Edit Traversal pop up
     */
    public void verifyGreyLineUnderneathClinicalVariable() {
        String expectedColor = "rgba(204, 204, 204, 1)";
        log.warn("verfying Grey lin under Clinical Variable Title is present or not in the popup .");
        Assert.assertTrue("Grey Line is NOT present under Clinical Variable Title  in the pop up", TestUtils.isElementPresent(driver, greyLineXpath));
        TestUtils.highlightElement(driver, greyLineXpath);
        String actualColor = driver.findElement(greyLineXpath).getCssValue("border-top-color");
        Assert.assertTrue("Grey Line color does not match in the pop up", actualColor.equals(expectedColor));
    }

    public void verifyVariableValueAsDropDownList() {
        log.warn("verfying variable type is dropdown or not in the popup .");
        Assert.assertTrue("variable Type Dropdown is not present in the pop up", TestUtils.isElementPresent(driver, variableTypeDropDownXpath));
        TestUtils.highlightElement(driver, variablevalueDropDownXpath);
    }

    /**
     * Verfying clinical variable Type as drop down on Edit Traversal pop up
     */
    public void verifyVariableTypeAsDropDownList() {
        log.warn("verfying variable type is dropdown or not in the popup .");
        Assert.assertTrue("variable Type Dropdown is not present in the pop up", TestUtils.isElementPresent(driver, variableTypeDropDownXpath));
        TestUtils.highlightElement(driver, variableTypeDropDownXpath);
    }

    /**
     * Verfying Add clinical variabel link on Edit Traversal pop up
     */
    public void verifyAddClinicalVariabelLink() {
        log.warn("verfying Add Clinical Variabel Link is present or not in the popup .");
        Assert.assertTrue(" Add Clinical Variabel Link is not present in the pop up", TestUtils.isElementPresent(driver, addClinicalVariabelLinkXpath));
        TestUtils.highlightElement(driver, addClinicalVariabelLinkXpath);
    }

    /**
     * Verfying clinical variabel type pre populated on Edit Traversal pop up
     */
    public void verifyTraversalTypePrePopulated() {
        log.warn("verfying variable Types are prepopulated or not from Traversal Maintenance grid .");
        List<WebElement> actualVariableTypes = driver.findElements(variableTypesXpath);
        for (int i = 0; i < actualVariableTypes.size(); i++) {
            Assert.assertTrue("variable type  does not match with popoup and grid. ",
                    actualVariableTypes.get(i).getText().equals(clinicalVariableTypes.get(i)));
            TestUtils.highlightElement(driver, actualVariableTypes.get(i));
        }
    }

    /**
     * Verfying clinical variabel value pre populated on Edit Traversal pop up
     */
    public void verifyTraversalValuePrePopulated() {
        log.warn("verfying variable Value are prepopulated or not from Traversal Maintenance grid .");
        List<WebElement> actualVariableValues = driver.findElements(variableValuesXpath);
        for (int i = 0; i < actualVariableValues.size(); i++) {
            Assert.assertTrue("variable value  does not match with pop up and grid. ",
                    actualVariableValues.get(i).getText().equals(clinicalVariableValues.get(i)));
            TestUtils.highlightElement(driver, actualVariableValues.get(i));
        }
    }


    /**
     * Verfying Remove ActionButton on Edit Traversal pop up
     */
    public void verifyRemoveActionButton() {
        log.warn("verfying x remove link is present or not in the pop up .");
        List<WebElement> results = driver.findElements(clinicalVariableAndTypeRows);
        List<WebElement> removeIcons = driver.findElements(By.xpath("//*[@class='icon cux-icon-remove']"));
        List<WebElement> removeLinks = driver.findElements(By.xpath("//a[text()='Remove']"));
        Assert.assertTrue("remove icon is not present.", results.size() == removeIcons.size());
        Assert.assertTrue("remove Link is not present.", results.size() == removeLinks.size());
    }

    /**
     * Verfying Save Button on Edit Traversal pop up
     */
    public void verifySaveButton() {
        log.warn("verfying save button is present or not in the pop up .");
        Assert.assertTrue("save Button is not present in the pop up", TestUtils.isElementPresent(driver, saveButtonXpath));
        TestUtils.highlightElement(driver, saveButtonXpath);

    }

    /**
     * Verfying Cancel Link on Edit Traversal pop up
     */
    public void verifyCancelLink() {
        log.warn("verfying cancel button is present or not in the popup .");
        Assert.assertTrue("cancel Button is not present in the pop up", TestUtils.isElementPresent(driver, cancelButtonXpath));
        TestUtils.highlightElement(driver, cancelButtonXpath);

    }

    /**
     * storing remove Link rows on Edit Traversal pop up
     */
    public void storeRemoveLinkRows() {
        log.warn("Storing remove link rows in the popup .");
        List<WebElement> column = driver.findElements(removeLink);
        variableTypeAndValueCountBeforeRemove = column.size();
    }

    /**
     * Clciking remove Link on Edit Traversal pop up
     */
    public void clickRemoveLink() {
        log.warn("clicking remove link in the popup .");
        driver.findElement(By.xpath("(//a[text()='Remove'])[1]")).click();
        TestUtils.highlightElement(driver, By.xpath("(//a[text()='Remove'])[1]"));
    }

    /**
     * verifying clinical variable Type and Value removed on Edit Traversal pop up
     */
    public void verifyTypeAndValueRemoved() {
        log.warn("verifying type and value has been removed from the pop up .");
        List<WebElement> column = driver.findElements(removeLink);
        int actualVariableTypeAndValueCountBeforeRemove = column.size();
        Assert.assertTrue("type and value is not removed", variableTypeAndValueCountBeforeRemove > actualVariableTypeAndValueCountBeforeRemove);
    }

    /**
     * verifying Remaining  clinical variable Type and Value displayed on Edit Traversal pop up
     */
    public void verifyRemainingTypeAndValuesAreDisplayed() {
        log.warn("verifying remaining type and value are displaying in the popup .");
        List<WebElement> results = driver.findElements(clinicalVariableAndTypeRows);
        for (int i = 1; i <= results.size(); i++) {
            Assert.assertTrue("variable type is not present.", TestUtils.isElementPresent(driver, By.xpath("((//strong[contains(text(), 'Type')]//../following-sibling::td[@class='ng-binding']) [position() mod 2 = 1 and position() >= 1])[" + i + "]")));
            TestUtils.highlightElement(driver, By.xpath("((//strong[contains(text(), 'Type')]//../following-sibling::td[@class='ng-binding']) [position() mod 2 = 1 and position() >= 1])[" + i + "]"));
            Assert.assertTrue("variable value  is not present.", TestUtils.isElementPresent(driver, By.xpath("((//strong[contains(text(), 'Type')]//../following-sibling::td[@class='ng-binding']) [position() mod 2 = 0 and position() >= 1])[" + i + "]")));
            TestUtils.highlightElement(driver, By.xpath("((//strong[contains(text(), 'Type')]//../following-sibling::td[@class='ng-binding']) [position() mod 2 = 0 and position() >= 1])[" + i + "]"));
        }

    }

    /**
     * cliciking remove link to remove all types and values on Edit Traversal pop up
     */
    public void removeAllTypesAndValues() {
        log.warn("clicking remove link in the popup .");
        List<WebElement> column = driver.findElements(removeLink);
        for (WebElement e : column) {
            TestUtils.highlightElement(driver, e);
            e.click();
        }
    }

    /**
     * Selecting variabel Type on Edit Traversal pop up
     *
     * @param variableType
     */
    public void selectVariableType(String variableType) {
        log.warn("Selecting variableType");
        TestUtils.highlightElement(driver, variableTypeDropDownXpath);
        TestUtils.selectByVisibleText(driver.findElement(variableTypeDropDownXpath), variableType);
    }

    /**
     * Selecting variable value on Edit Traversal pop up
     *
     * @param variableValue
     */
    public void selectVariableValue(String variableValue) {
        log.warn("Selecting variableValue: " + variableValue);
        TestUtils.highlightElement(driver, variablevalueDropDownXpath);
        TestUtils.selectByVisibleText(driver.findElement(variablevalueDropDownXpath), variableValue);
    }


    /**
     * Selecting the clinical Variable Type and variable Value on Edit Traversal Pop-Up
     *
     * @param description
     */

    public void selectVariableTypeAndVariableValue(String description) {
        log.warn("Selecting the Clinical Variable Type and Variable Value in Edit Traversal Pop-up ");
        System.out.println(description);
        String[] clinicalVariable = description.split(";");
        String[] variables = clinicalVariable[1].split("-");
        TestUtils.highlightElement(driver, variableTypeDropDownXpath);
        TestUtils.selectByVisibleText(driver.findElement(variableTypeDropDownXpath), variables[0].trim());
        TestUtils.highlightElement(driver, variablevalueDropDownXpath);
        TestUtils.selectByVisibleText(driver.findElement(variablevalueDropDownXpath), variables[1].trim());
    }

    /**
     * cliciking cancel link on Edit Traversal pop up
     */
    public void clickCancelLink() {
        log.warn("Click cancel on EditTraversal ");
        driver.findElement(cancelButtonXpath).click();
    }

    /**
     * cliciking cancel link on Edit Traversal pop up
     */
    public void selectCancerTypeOnEditTraversal(String cancerType) {
        log.warn("Selecting cancerType on Edit Traversal");
        TestUtils.highlightElement(driver, cancerTypeDropDown);
        TestUtils.selectByVisibleText(driver.findElement(cancerTypeDropDown), cancerType);
    }


    /**
     * entering start date on Edit Traversal pop up
     *
     * @param startDate
     */
    public void enterStartDate(String startDate) {
        log.warn("Entering start date ");
        TestUtils.wait(2);
        TestUtils.highlightElement(driver, popupStartDateXpath);
        driver.findElement(popupStartDateXpath).clear();
        driver.findElement(popupStartDateXpath).sendKeys(startDate);
    }

    /**
     * clearing end date on Edit Traversal pop up
     */
    public void clearEndDate() {
        log.warn("Clearing End date ");
        TestUtils.highlightElement(driver, popupEndDateXpath);
        driver.findElement(popupEndDateXpath).clear();
    }

    /**
     * clearing AutorizationDuration on Edit Traversal pop up
     */
    public void clearAutorizationDuration() {
        log.warn("Clearing Autorization Duration ");
        TestUtils.highlightElement(driver, popupauthorizationDuration);
        driver.findElement(popupauthorizationDuration).clear();
    }

    /**
     * clicking save button on Edit Traversal pop up
     */
    public void clickSaveButton() {
        log.warn("Click Save Button on EditTraversal ");
        driver.findElement(saveButtonXpath).click();
    }

    /**
     * entering end date on Edit Traversal pop up
     *
     * @param endDate
     */

    public void enterEndDate(String endDate) {
        log.warn("Entering end date ");
        TestUtils.highlightElement(driver, popupEndDateXpath);
        driver.findElement(popupEndDateXpath).clear();
        driver.findElement(popupEndDateXpath).sendKeys(endDate);
    }

    /**
     * entering authorization Duration on Edit Traversal pop up
     *
     * @param authorizationDuration
     */
    public void enterAuthorizationDuration(String authorizationDuration) {
        log.warn("Entering Authorization Duration  ");
        TestUtils.highlightElement(driver, popupauthorizationDuration);
        driver.findElement(popupauthorizationDuration).clear();
        driver.findElement(popupauthorizationDuration).sendKeys(authorizationDuration);
    }

    /**
     * entering authorization Duration on Add Traversal pop up
     *
     * @param authorizationDuration
     */
    public void enterAuthorizationDurationAdd(String authorizationDuration) {
        log.warn("Entering Authorization Duration on Add popup ");
        TestUtils.highlightElement(driver, popupauthorizationDurationAdd);
        driver.findElement(popupauthorizationDurationAdd).clear();
        driver.findElement(popupauthorizationDurationAdd).sendKeys(authorizationDuration);
    }

    /**
     * verifying red color for border and message on Edit Traversal pop up
     *
     * @param txtMessage
     */
    public void verifyingRedColorBorderAndMessage(String txtMessage) {
        log.warn("verifying Red Color Border And Message  ");
        String expectedColor = "rgba(169, 60, 71, 1)";
        By elementTxt = By.xpath("//*[contains(text(),'" + txtMessage + "')]");
        String actualMessageColor = "";

        for (WebElement e : driver.findElements(elementTxt)) {
            actualMessageColor = e.getCssValue("color");
            Assert.assertTrue("error message color does not match", expectedColor.equals(actualMessageColor));
        }
        String actualBorderColor = driver.findElement(popupEndDateXpath).getCssValue("border-bottom-color");
        Assert.assertTrue("end date border color does not match", expectedColor.equals(actualBorderColor));
        actualBorderColor = driver.findElement(popupauthorizationDuration).getCssValue("border-bottom-color");
        Assert.assertTrue("authorizaiton Duration border color does not match", expectedColor.equals(actualBorderColor));

    }

    /**
     * Clicking Add clinical variable on Edit Traversal pop up
     */
    public void clickAddClinicalVariable() {
        log.warn("Click Add Clinical Variable on EditTraversal ");
        TestUtils.waitElement(driver, addClinicalVariabelLinkXpath);
        TestUtils.onMouseHover(driver, addClinicalVariabelLinkXpath);
        TestUtils.highlightElement(driver, addClinicalVariabelLinkXpath);
        driver.findElement(addClinicalVariabelLinkXpath).click();
    }

    /**
     * Removing variable type and  variable value if are already present in the popup
     *
     * @param variableType
     * @param variableValue
     */
    public void RemoveVariableTypeAndVariableValueIfAlreadyPresent(String variableType, String variableValue) {
        log.warn("removing variableType and  variableValue if are already present in the popup");

        List<WebElement> variableTypes = driver.findElements(variableTypesXpath);
        List<WebElement> variableValues = driver.findElements(variableValuesXpath);
        List<WebElement> removeLinks = driver.findElements(removeLink);

        for (int i = 0; i < variableTypes.size(); i++) {
            if (variableTypes.get(i).getText().equals(variableType) && variableValues.get(i).getText().equals(variableValue)) {
                TestUtils.highlightElement(driver, variableTypes.get(i));
                TestUtils.highlightElement(driver, variableValues.get(i));
                TestUtils.highlightElement(driver, removeLinks.get(i));
                removeLinks.get(i).click();
                break;
            }
        }
    }

    /**
     * verifying variableType, variableValue, startDate are discarded on Edit Traversal pop up
     *
     * @param variableType, variableValue, startDate
     */
    public void verifyGivenValuesAreDiscarded(String variableType, String variableValue, String startDate) {
        log.warn("verfying given values are discarded or not in Edit Traversal popup");
        String actualVariableType = TestUtils.getSelectedValueFromDropdown(driver, variableTypeDropDownXpath);
        Assert.assertTrue("Type is not discarded", !variableType.equals(actualVariableType));
        TestUtils.highlightElement(driver, driver.findElement(variableTypeDropDownXpath));
        String actualVariableValue = driver.findElement(variablevalueDropDownXpath).getAttribute("value");
        Assert.assertTrue("value is not discarded", !variableValue.equals(actualVariableValue));
        TestUtils.highlightElement(driver, driver.findElement(variablevalueDropDownXpath));
        String actualStartdate = driver.findElement(popupStartDateXpath).getAttribute("value");
        TestUtils.wait(2);
        Assert.assertTrue("Start date is not discarded", !startDate.equals(actualStartdate));
        TestUtils.highlightElement(driver, driver.findElement(popupStartDateXpath));
    }


    /**
     * @return String: the displayed Authorization Duration
     */
    public String getAuthorizationDuration() {
        log.warn("the displayed Authorization Duration");
        return driver.findElement(popupauthorizationDuration).getAttribute("value");
    }

    /**
     * @return String: the displayed Stage value
     */
    public String getStage() {
        log.warn("the displayed Stage");
        return driver.findElement(By.xpath(String.format(F_EXTRACT_VALUE, "Stage"))).getText();
    }

    /**
     * @return String: the displayed Histology value
     */
    public String getHistology() {
        log.warn("the displayed Histology");
        return driver.findElement(By.xpath(String.format(F_EXTRACT_VALUE, "Histology"))).getText();
    }

    /**
     * @return String: the displayed Indication value
     */
    public String getDeseaseStatus() {
        log.warn("the displayed Authorization Duration");
        return driver.findElement(By.xpath(String.format(F_EXTRACT_VALUE, "Indication"))).getText();
    }

    /**
     * @return String: the displayed Line of Therapy value
     */
    public String getLineOfTherapy() {
        log.warn("the displayed Authorization Duration");
        return driver.findElement(By.xpath(String.format(F_EXTRACT_VALUE, "Line of Therapy"))).getText();
    }

    /**
     * @return String: the displayed MSI/MMR value
     */
    public String getMsiMmr() {
        log.warn("the displayed Authorization Duration");
        return driver.findElement(By.xpath(String.format(F_EXTRACT_VALUE, "MSI/MMR"))).getText();
    }

    /**
     * @return String: the displayed Cancer Type value
     */
    public String getCancerType() {
        log.warn("the displayed Authorization Duration");
        return driver.findElement(cancerTypeDropDownSelectedOption).getText();
    }

    /**
     * Select Cancer Type on the Edit Traversal Page
     *
     * @param cancerType
     */
    public void selectCancerType(String cancerType) {
        log.warn("the displayed Authorization Duration");
        WebElement el = driver.findElement(cancerTypeDropDown);
        Select select = new Select(el);
        select.selectByVisibleText(cancerType);
    }

    /**
     * Enter Variable Value text
     *
     * @param variableValue
     */
    public void enterVariableValue(String variableValue) {
        log.warn("Enter the Variable Value: " + variableValue);
        WebElement el = driver.findElement(variableValueTextArea);
        el.click();
        if (variableValue.contains(";")) {
            String[] Variablevalue = variableValue.split(";");
            for (String vv : Variablevalue) {
                System.out.println("//span[contains(text(), '" + vv + "')]/preceding-sibling::span");
                driver.findElement(By.xpath("//span[contains(text(), '" + vv + "')]/preceding-sibling::span")).click();
            }
        } else {
            driver.findElement(By.xpath("//span[contains(text(), '" + variableValue + "')]/preceding-sibling::span")).click();

        }


    }
}