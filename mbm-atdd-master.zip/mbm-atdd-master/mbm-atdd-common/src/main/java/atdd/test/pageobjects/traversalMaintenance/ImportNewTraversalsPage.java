package atdd.test.pageobjects.traversalMaintenance;

import atdd.test.shared.BaseCucumber;
import atdd.test.shared.Globals;
import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;



public class ImportNewTraversalsPage {

    private WebDriver driver;
    private TestUtils utils;

    Logger log;
    Globals gv;

    private By builderIDLabel= By.xpath("//span[@id='traversalImportBuilderIDLabel']/label");
    private By templateIDLabel= By.xpath("//span[@id='traversalImportAssessmentIDLabel']/label");
    private By previewAssessmentButton= By.xpath("//input[@id='traversalPreviewButton']");
    private By clearButton= By.xpath("//input[@id='traversalImportClearButton']");
    private By importTraversalsButton= By.xpath("//input[@id='traversalImportButton']");
    private By cancelHyperlink=By.xpath("//input(@id='traversalImportCancelButton')");
    private By builderId= By.xpath("//span[@id='traversalImportBuilderIDLabel']");
    private By templateID= By.xpath("//span[@id='traversalImportAssessmentIDLabel']");

    public ImportNewTraversalsPage(WebDriver webDriver) {
        this.driver = webDriver;
        utils = BaseCucumber.utils;
        log = Logger.getLogger(this.getClass().getName());
        gv = BaseCucumber.gv;
    }


    //Methods -------------------

    /**
     * Assumption: Import New Traversal Screen is displayed
     * This Method is to verify the UI elements
     * When user just lands on the Import New Traversals Screen
     */
    public void verifyImportNewTraversalsUI() {
        Assert.assertEquals("Builder ID", getBuilderIDLabel());
        Assert.assertEquals("Template ID", getTemplateIDLabel());
        Assert.assertEquals("Preview Assessment", getPreviewAssessmentButton());
        Assert.assertEquals("Clear", clearLabel());
        Assert.assertEquals("Import Traversals", importTraversalLabel());

    }

    /*
      This method is to verify the Builder ID field is a Required field
      and return the Label Value
     */
    public String getBuilderIDLabel() {
        Assert.assertEquals("true",driver.findElement(builderId).getAttribute("required"));
        return this.driver.findElement(builderIDLabel).getText().split(",")[0].trim();
    }


    /*
      This method is to verify the Template ID field is a Required field
      and return the Label Value
     */
    public String getTemplateIDLabel() {
        Assert.assertEquals("true",driver.findElement(templateID).getAttribute("required"));
        return this.driver.findElement(templateIDLabel).getText().split(",")[0].trim();
    }

    /*
      This method is to verify the Preview Button is Enabled
      and return the Label Value
     */
    public String getPreviewAssessmentButton() {
        driver.findElement(previewAssessmentButton).isEnabled();
        return this.driver.findElement(previewAssessmentButton).getAttribute("value").split(",")[0].trim();
    }

    /*
      This method is to verify the Clear Button is Enabled
      and return the Label Value
     */
    public String clearLabel() {
        driver.findElement(clearButton).isEnabled();
        return this.driver.findElement(clearButton).getAttribute("value").split(",")[0].trim();
    }

    /*
      This method is to verify the Import New Traversal is disabled.
      and return the Label Value
     */
    public String importTraversalLabel() {
        boolean value=!(driver.findElement(importTraversalsButton).isEnabled());
        Assert.assertTrue("ImportTraversal Button is Enabled when user lands on Import traversal", value);
        return this.driver.findElement(importTraversalsButton).getAttribute("value").split(",")[0].trim();
    }



}
