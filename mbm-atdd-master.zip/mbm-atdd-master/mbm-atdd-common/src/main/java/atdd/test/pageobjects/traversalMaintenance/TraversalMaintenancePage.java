package atdd.test.pageobjects.traversalMaintenance;

import atdd.dao.OcmMBMDao;
import atdd.dao.mbm.MyBatisConnectionFactory;
import atdd.dao.mbm.RefDao;
import atdd.test.pageobjects.CommonPage;
import atdd.test.shared.BaseCucumber;
import atdd.test.shared.Globals;
import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.sql.SQLException;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static atdd.utils.TestUtils.*;
import static org.openqa.selenium.By.xpath;

public class TraversalMaintenancePage {
    private WebDriver driver;
    private TestUtils utils;

    Logger log;
    Globals gv;

    String dbTraversalID;
    String dbCancerType;
    String dses_trvrs_id;
    String cancerTypeDropDownValue;

    protected static String authorizationDuration = "";
    protected static String startDate = "";
    protected static String endDate = "";
    protected static List<String> clinicalVariableTypes;
    protected static List<String> clinicalVariableValues;

    private By traversalID = By.xpath("//*[@id='traversalSearchTraversalID']");
    private By Status = By.xpath("//button[@data-id='Tools.TraversalMaintenance.TraversalSearch.Status--dropdownMenu']");
    private By tableResult = By.xpath("//tr[@class='ocmTableRow']/td");
    private By cancerType = By.xpath("//input[@ng-model='traversalSearchTableFilters.diseaseType']");
    private By regimenName = By.xpath("//button[@data-id='Tools.TraversalMaintenance.QueueNav.RegimenName--multiselect']");
    private By clinicalVariableType = By.xpath("//*[@id='traversalSearchVariableType']");
    private By clinicalVariableValue = By.xpath("//*[@id='traversalSearchVariableValue']");
    private By multiSelectClinicalVariables = By.xpath("//button[@data-id='Tools.TraversalMaintenance.QueueNav.ClinicalVariables--groupMultiselect']");
    private By clearBtn = By.xpath("//*[@id='tra//input[@id='traversalImportBuilderID']versalSearchClearButton']");
    private By builderID = By.xpath("//input[@data-id='Tools.ImportNewTraversal.SearchNav.BuilderID--input']");
    private By templateID = By.xpath("//input[@data-id='Tools.ImportNewTraversal.SearchNav.TemplateID--input']");
    private By assessmentDetailtbl = By.xpath("//table[@id='assessmentDetailsTableModelID']/tbody");
    private By descriptionValues = By.xpath("//*[@id='diseaseTraversalMaintenanceTableID']/tbody/tr/td[6]/span");
    private By idValues = By.xpath("//*[@id='diseaseTraversalMaintenanceTableID']/tbody/tr/td[4]/span");
    private By searchButton = By.xpath("//input[@data-id='Tools.EditTraversalLinkage.QueueNav.Filter--primaryButton']");
    private By cancerTypeValues = By.xpath("//*[@id='diseaseTraversalMaintenanceTableID']/tbody/tr/td[5]/span");
    private By authorizationDurationXpath = xpath("//*[@id='diseaseTraversalMaintenanceTableID']/tbody/tr/td[7]/span");
    private By cancerTypeLabel = By.xpath("//*[@id='traversalSearchCancerTypeLabel']/label");
    private By authDurationValues = By.xpath("//*[@id='diseaseTraversalMaintenanceTableID']/tbody/tr/td[7]/span");
    private By startDateXpath = xpath("//*[@id='diseaseTraversalMaintenanceTableID']/tbody/tr/td[8]/span");
    private By startDateValues = By.xpath("//*[@id='diseaseTraversalMaintenanceTableID']/tbody/tr/td[8]/span");
    private By endDateXpath = xpath("//*[@id='diseaseTraversalMaintenanceTableID']/tbody/tr/td[9]/span");
    private By endDateValues = By.xpath("//*[@id='diseaseTraversalMaintenanceTableID']/tbody/tr/td[9]/span");
    private By nextLnk = By.xpath("//li[@class='next']");
    private By firstLnk = By.xpath("//li[@class='first']");
    private By previousLnk = By.xpath("//li[@class='previous' and not(contains(@disabled, 'disabled'))]");
    private By lastLnk = By.xpath("//li[@class='last' and not(contains(@disabled, 'disabled'))]");
    private By requiredLabel = By.xpath("//*[@id='requiredText']");
    private By msgForWithoutSearch = By.xpath("//*[@id='diseaseTraversalMaintenanceTableID']/tfoot");
    private By searchResults = By.xpath("//*[@id='diseaseTraversalMaintenanceTableID']/tbody/tr");
    private By totalRecordsLabel = By.xpath("//*[@ng-if='diseaseTraversalMaintenanceTable.pagination.totalRecordsCount']");
    private By showSelectBox = By.xpath("//*[@ng-model='diseaseTraversalMaintenanceTable.pagination.recordsPerPage']");
    //Advanced Search
    private By advancedSearchLink = By.xpath("//a[@id='advancedSearchButton']");
    private By advancedSearchWindow = By.xpath("//div[@id='diseaseTraversalMaintenanceTable-advancedSearchPopupID']/div/div");
    private By advancedSearchWindowTitle = By.xpath("//div[@class='tk-lbox-header']//h2[contains(text(),'Advanced Search')]");
    private By advancedSearchRequiredLabel = By.xpath("//div[@id='advancedSearchRequiredText']");
    private By advancedSearchCancerTypeCaption = By.xpath("//span[@id='traversalAdvancedSearchCancerTypeLabel']");
    private By advancedSearchDurationCaption = By.xpath("//span[@id='traversalAdvancedSearchAuthDurationLabel']");
    private By advancedSearchVariableTypeCaption = By.xpath("//span[@id='traversalAdvancedSearchVariableTypeLabel']");
    private By advancedSearchVariableValueCaption = By.xpath("//span[@id='traversalAdvancedSearchVariableValueLabel']");
    private By advancedSearchCancerType = By.xpath("//select[contains(@id,'traversalAdvancedSearchTableFilters-diseaseType')]");
    private By advancedSearchDuration = By.xpath("//input[@id='traversalAdvancedSearchAuthDuration']");
    private By advancedSearchVariableType = By.xpath("//*[@ng-model='clinicalVariableAdvancedSearch.type']");
    private By advancedSearchVariableValue = By.xpath("//*[@ng-model='clinicalVariableAdvancedSearch.value']");
    private By advancedSearchXbutton = By.xpath("//button[@ng-click='diseaseTraversalMaintenanceTable.advancedSearchPopup.closePopup()']/span");
    private By advancedSearchSearchButton = By.xpath("//input[@id='traversalAdvancedSearchButton']");
    private By advancedSearchClearButton = By.xpath("//input[@id='traversalAdvancedSearchButton']/following-sibling::input[1]");
    private By advancedSearchCancelLink = By.xpath("//input[@id='traversalAdvancedSearchButton']/following-sibling::input[2]");
    private By advancedSearchAddClinicalVariable = By.xpath("//a[text()='Add Clinical Variable']");
    private By advancedSearchClinicalVariableSection = By.xpath("//div[@id='advancedSearchDiv']//h3[text()='Clinical Variable']");
    private By advancedSearchSearchAppliedText = By.xpath("//span[@id='advancedSearchFiltersDisplayLabel']");
    private By advancedSearchSearchAppliedValues = By.xpath("//ul[@id='advancedSearchFiltersDisplayList']");
    private By clinicalVariableTypeXpath = xpath("//*[@class='clinVars ng-scope']//*[@class='ng-binding']");
    private By clinicalVariableValueXpath = xpath("//*[@class='clinVars ng-scope']//*[@class='ng-binding']/following-sibling::td");
    private By expandIcon = xpath("//span[@class='ocm-action tk-panl-helper ng-scope cux-icon-caret_right']");
    private By descriptionSortBtn = By.xpath("//*[@id='diseaseTraversalMaintenanceTable-Description-sortButton']");
    private By idSortBtn = By.xpath("//*[@id='diseaseTraversalMaintenanceTable-ID-sortButton']");
    private By cancerTypeSortBtn = By.xpath("//*[@id='diseaseTraversalMaintenanceTable-Cancer-Type-sortButton']");
    private By authDurationSortBtn = By.xpath("//*[@id='diseaseTraversalMaintenanceTable-Authorization-Duration-sortButton']");
    private By startDateSortBtn = By.xpath("//*[@id='diseaseTraversalMaintenanceTable-Start-Date-sortButton']");
    private By endDateSortBtn = By.xpath("//*[@id='diseaseTraversalMaintenanceTable-End-Date-sortButton']");
    private By selectAllCheckBox = By.xpath("//input[@ng-click='selectAllTasks({event : $event})']");
    private By deleteButton = By.xpath("//span[@class='ocm-action cux-icon-trash_delete ng-scope']");
    //Delete Traversal Warning Popup
    private By deleteTraversalWarningPopupHeader = By.xpath("//div[contains(@ng-focus,\"deleteTraversalPopup.setFocus('start')\")]/h2");
    private By deleteTraversalWarningPopupContent = By.xpath("//*[@id='deleteConfirmPopupID']");
    private By deleteTraversalWarningPopupCloseButton = By.xpath("//button[@ng-click='deleteTraversalPopup.closePopup()']");
    private By applyBulkAction = By.xpath("//select[@id='traversalBulkAction']");
    private By applyToSelectedBulkAction = By.xpath("//a[contains(@ng-click, 'bulkEditTraversals')]");

    private By addTraversal = By.xpath("//a[.='Add Traversal']");
    private By selectAllCheckBox2 = By.id("inputCheckAll");
    private By traversalBulkActionDropDownList = By.id("traversalBulkAction");
    private By applyToSelectedLink = By.xpath("//a[.='Apply To Selected']");
    private By deleteYesModal = By.xpath("//input[@id='dsesTrvslConfirmYesBtn']");
    private By addTraversalAuthDuration = By.xpath("//input[@name='durationFieldAdd']");
    private By startDate_AddTraversal = By.xpath("//input[@name='Start Date']");
    private By addTraversalVariableType = By.xpath("//select[@ng-model='clinicalVariable.type']");
    private By addTraversalVariableValue = By.xpath("//textarea[@ng-model='clinicalVariable.value']");
    private By errorMsg = By.xpath("//span[@id='globalMessages-description']/span");
    private By pathwayClient = By.xpath("//button[@data-id='Tools.TraversalMaintenance.QueueNav.Payer--multiselect']");


    public TraversalMaintenancePage(WebDriver webDriver) {
        this.driver = webDriver;
        utils = BaseCucumber.utils;
        log = Logger.getLogger(this.getClass().getName());
        gv = BaseCucumber.gv;
    }

    public void switchToFrame(String id) {
        driver.switchTo().frame(id);
    }

    private String owner;
    //Methods -------------------

    /**
     * Deleting all elements with expected description. NOT Exact match. One by one. Not Bulk option.
     *
     * @param descr
     */
    public void clickDeleteALLRecordByContainsDescription(String descr) {
        log.warn("Deleting All records with description: " + descr);

        By deleteIcon = By.xpath("//span[contains(text(),'" + descr + "')]/../..//span[contains(@class,'cux-icon-trash_delete')]");
        By deleteIconFirst = By.xpath("(//span[contains(text(),'" + descr + "')]/../..//span[contains(@class,'cux-icon-trash_delete')])[1]");
        List<WebElement> column = driver.findElements(deleteIcon);

        //deleting all
        for (WebElement del : column) {
            highlightElement(driver, deleteIconFirst);
            //Table refreshed after each deletion. Have to find it again
            onMouseHover(driver, deleteIconFirst);
            driver.findElement(deleteIconFirst).click();
            TestUtils.wait(2);
            driver.findElement(deleteYesModal).click();
            TestUtils.wait(3);
            log.warn("One record Deleted successfully.");
        }
    }

    /**
     * Click Delete on Traversal which contains expected text in the descripion. Not exact match!
     *
     * @param descr
     */
    public void clickDeleteRecordByContainsDescription(String descr) {
        log.warn("Deleting record with description: " + descr);
        By deleteIcon = By.xpath("//span[contains(text(),'" + descr + "')]/../..//span[contains(@class,'cux-icon-trash_delete')]");
        if (isElementPresent(driver, deleteIcon)) {
            highlightElement(driver, deleteIcon);
            driver.findElement(deleteIcon).click();
            TestUtils.wait(2);
            driver.findElement(deleteYesModal).click();
            TestUtils.wait(3);
            log.warn("One record Deleted successfully.");
        } else log.warn("Record with description: " + descr + " is not present");
    }

    /**
     * Clicks on Last hyperlink on the Traversal Maintenance Page
     */
    public void clickOnLastHyperLink() {
        log.warn("Clicks on Last hyperlink on the Traversal Maintenance Page ");
        TestUtils.wait(2);
        if (isElementPresent(driver, lastLnk)) {
            highlightElement(driver, lastLnk);
            driver.findElement(lastLnk).click();
            TestUtils.wait(3);
        } else log.warn("Last link is not active. Just one page?");
    }

    /**
     * Click on Previous pagination link
     */
    public void clickOnPreviousHyperLink() {
        log.warn("Clicks on Previous hyperlink on the Traversal Maintenance Page ");
        TestUtils.wait(2);
        if (isElementPresent(driver, previousLnk)) {
            highlightElement(driver, previousLnk);
            driver.findElement(previousLnk).click();
            TestUtils.wait(3);
        } else log.warn("Previous link is not active. Just one page?");
    }

    public static Comparator<String> naturalOrdering() {
        final Pattern compile = Pattern.compile("(\\d+)|(\\D+)");
        return (s1, s2) -> {
            final Matcher matcher1 = compile.matcher(s1);
            final Matcher matcher2 = compile.matcher(s2);
            while (true) {
                final boolean found1 = matcher1.find();
                final boolean found2 = matcher2.find();
                if (!found1 || !found2) {
                    return Boolean.compare(found1, found2);
                } else if (!matcher1.group().equals(matcher2.group())) {
                    if (matcher1.group(1) == null || matcher2.group(1) == null) {
                        return matcher1.group().compareToIgnoreCase(matcher2.group());
                    } else {
                        return Integer.valueOf(matcher1.group(1)).compareTo(Integer.valueOf(matcher2.group(1)));
                    }
                }
            }
        };
    }


    /**
     * Select option from Apply Bulk Action and click Apply.
     *
     * @param action
     */
    public void applyBulkAction(String action) {
        log.warn("Selecting " + action + " option from Apply Bulk Action and click Apply.");
        waitElement(driver, applyBulkAction);
        highlightElement(driver, applyBulkAction);
        selectByVisibleText(driver, applyBulkAction, action);
        TestUtils.wait(2);
        driver.findElement(applyToSelectedBulkAction).click();
        TestUtils.wait(2);
    }

    /**
     * Selecting checkbox by Text(contains) in any column
     *
     * @param idtxt
     */
    public void selectCheckBoxByTxtContains(String idtxt) {
        log.warn("Selecting checkbox by ID: " + idtxt);
        By chkBxById = By.xpath("//*[@id='diseaseTraversalMaintenanceTableID']/tbody//span[contains(text(),'" + idtxt + "')]/../..//input");
        highlightElement(driver, By.xpath("//*[@id='diseaseTraversalMaintenanceTableID']/tbody//span[contains(text(),'" + idtxt + "')]"));
        boolean selected = driver.findElement(chkBxById).isSelected();
        if (!selected)
            driver.findElement(chkBxById).click();
    }

    /**
     * Selecting checkbox by Text in any column
     *
     * @param idtxt
     */
    public void selectCheckBoxByTxt(String idtxt) {
        log.warn("Selecting checkbox by ID: " + idtxt);
        By chkBxById = By.xpath("//*[@id='diseaseTraversalMaintenanceTableID']/tbody//span[text()='" + idtxt + "']/../..//input");
        highlightElement(driver, By.xpath("//*[@id='diseaseTraversalMaintenanceTableID']/tbody//span[text()='" + idtxt + "']"));
        boolean selected = driver.findElement(chkBxById).isSelected();
        if (!selected)
            driver.findElement(chkBxById).click();
    }

    /**
     * Selecting Chrckbox by position
     *
     * @param pos
     */
    public void selectCheckBoxByPosition(int pos) {
        log.warn("Selecting checkbox from row #" + pos);
        By chkBxByPos = By.xpath("//*[@id='diseaseTraversalMaintenanceTableID']/tbody/tr[" + pos + "]/td[1]/input");
        highlightElement(driver, By.xpath("//*[@id='diseaseTraversalMaintenanceTableID']/tbody/tr[" + pos + "]/td[1]"));
        boolean selected = driver.findElement(chkBxByPos).isSelected();
        if (!selected)
            driver.findElement(chkBxByPos).click();
    }

    /**
     * Check that ID from Global Variables is not present in the search results
     */
    public void checkStoredIdNotPresent() {
        log.warn("Checking that ID elements from Global Variables are not present in the search result.");
        List<String> idVal = gv.getListOfId();
        List<WebElement> results = driver.findElements(idValues);
        boolean present = false;
        String idExists = "";

        for (WebElement we : results) {
            for (String id : idVal) {
                if (we.getText().equals(id)) {
                    present = true;
                    idExists = id;
                    break;
                }
            }
            if (present) break;
        }

        Assert.assertFalse("Element with id " + idExists + " is present on the page!", present);
    }

    /**
     * Validate text in the Breadcrumb
     */
    public void validateBreadcrumb(String breadcrumbValue) {

        Boolean breadCrumElement = driver.findElement(By.xpath("(//ul[@class='oui-crum']/li/span[text()='"
                + breadcrumbValue + "'])[2]")).isDisplayed();
        Assert.assertTrue("breadcrum value doesnot match", breadCrumElement);
    }

    /**
     * Clicking on the Breadcrumb by Text
     */
    public void clickOnBreadcrumb(String breadCrumbLink) {
        driver.findElement(By.xpath("(//ul[@class='oui-crum']/li/a[text()='" + breadCrumbLink + "'])[2]|(//ul/li/a/span[text()='" + breadCrumbLink + "'])[1]")).click();
    }

    /**
     * Getting value of id cell by position
     *
     * @param pos
     * @return
     */
    public String getIdValueByPosition(int pos) {
        By idPos = By.xpath("//*[@id='diseaseTraversalMaintenanceTableID']/tbody/tr[" + pos + "]/td[4]/span");
        highlightElement(driver, idPos);
        String val = driver.findElement(idPos).getText();
        log.warn("ID number " + pos + " value is: " + val);
        return val;
    }

    /**
     * Enters Traversal ID on the Traversal Maintenance Page
     */
    public void enterDataIntoTraversalIDOnTraversalMaintenancePage(String arg1) {
        log.warn("enter the Traversal ID: " + traversalID);
        waitElement(driver, traversalID);
        highlightElement(driver, traversalID);
        driver.findElement(traversalID).sendKeys(arg1);
        TestUtils.wait(2);
        Assert.assertTrue(arg1 + "is not populated for traversal Id", arg1.equals(driver.findElement(traversalID).getAttribute("value")));
    }

    public void selectStatusOnTraversalMaintenancePage(String arg1) {

        log.warn(" Select status type from status dropdown");
        waitElement(driver, Status);
        TestUtils.wait(2);
        driver.findElement(Status).click();
        TestUtils.input(driver, Status, arg1);
        TestUtils.wait(3);
    }


    /**
     * Selects Cancer Type from dropdown on the Traversal Maintenance Page
     */
    public void selectCancerTypeOnTraversalMaintenancePage(String arg1) {
        log.warn(" Select cancer type from cancer type dropdown");
        waitElement(driver, cancerType);
        TestUtils.wait(2);
        driver.findElement(cancerType).click();
        driver.findElement(By.xpath("//a[contains(text(),'" + arg1 + "')]")).click();
    }

    /**
     * Selects Clinical Variable Type from dropdown on the Traversal Maintenance Page
     */
    public void selectClinicalVariableTypeOnTraversalMaintenancePage(String arg1) {
        log.warn(" Select Clinical variable Type from cancer type dropdown");
        waitElement(driver, clinicalVariableType);
        TestUtils.wait(2);
        driver.findElement(clinicalVariableType).click();
        Select dropdown = new Select(driver.findElement(clinicalVariableType));
        //Skip if it not present
        boolean present = checkSelectValue(driver, clinicalVariableType, arg1);
        if (present) {
            dropdown.selectByVisibleText(arg1);
            TestUtils.wait(2);
            Assert.assertTrue(arg1 + "is not Selected for clinical Variable Type", arg1.equals(getSelectedValueFromDropdown(driver, clinicalVariableType)));
        } else log.warn(arg1 + " is not present in the Variable Type drop-down");
    }

    /**
     * Clicks Clear button on the Traversal Maintenance Page
     */
    public void clickClearButton() {
        log.warn("Click Clear button On the Traversal Maintenance Page");
        waitElement(driver, clearBtn);
        highlightElement(driver, clearBtn);
        driver.findElement(clearBtn).click();
    }

    /**
     * Checks Cancer Type is cleared on the Traversal Maintenance Page
     */
    public void checkCancerTypeValueIsCleared() {
        log.warn("Verifies Cancer type value is cleared");
        Assert.assertEquals("ClinicalVariableValue is not cleared", getSelectedValueFromDropdown(driver, cancerType), "");
    }

    /**
     * Checks Clinical Variable Type is cleared on the Traversal Maintenance Page
     */
    public void checkClinicalVariableTypeValueIsCleared() {
        log.warn("Verifies Clinical Variable Type value is cleared");
        Assert.assertEquals("ClinicalVariableValue is not cleared", getSelectedValueFromDropdown(driver, clinicalVariableType), "");
    }

    /**
     * Checks Clinical Variable Value is cleared on the Traversal Maintenance Page
     */
    public void checkClinicalVariableValueValueIsCleared() {
        log.warn("Verifies Clinical Variable value is cleared");
        Assert.assertEquals("ClinicalVariableValue is not cleared", getSelectedValueFromDropdown(driver, clinicalVariableValue), "");
    }


    /**
     * Checks description field is sortable on the Traversal Maintenance Page
     */
    public void checkDescriptionColIsSortable() {
        checkOrderOfColumn(descriptionSortBtn, descriptionValues);
    }

    /**
     * Checks Cancer Type field is sortable on the Traversal Maintenance Page
     */
    public void checkCancerTypeColIsSortable() {
        checkOrderOfColumn(cancerTypeSortBtn, cancerTypeValues);
    }

    /**
     * Checks Authorization Duration field is sortable on the Traversal Maintenance Page
     */
    public void checkAuthDurationColIsSortable() {

        checkOrderOfColumn(authDurationSortBtn, authDurationValues);
    }

    /**
     * Checks Start Date field is sortable on the Traversal Maintenance Page
     */
    public void checkStartDtenColIsSortable() {
        checkOrderOfColumn(startDateSortBtn, startDateValues);
    }


    /**
     * Checks End Date field is sortable on the Traversal Maintenance Page
     */
    public void checkEndDateColIsSortable() {
        checkOrderOfColumn(endDateSortBtn, endDateValues);
    }

    /**
     * Checks Id field is default sortable on the Traversal Maintenance Page
     */
    public void checkIdColIsDefaultSortable() {
        List<String> obtainedList = getPaginatedResultsList(idValues);
        ArrayList<Integer> sortedList = new ArrayList<>();
        ArrayList<Integer> intObtainedList = new ArrayList<>();
        for (String s : obtainedList) {
            sortedList.add(Integer.valueOf(s));
            intObtainedList.add(Integer.valueOf(s));
        }
        Collections.sort(sortedList);
        Assert.assertTrue(sortedList.equals(intObtainedList));
    }

    /**
     * Selects Clinical Variable Value from dropdown on the Traversal Maintenance Page
     */
    public void selectClinicalVariableValueOnTraversalMaintenancePage(String arg1) {
        log.warn(" Select Clinical Variable Value from cancer type dropdown");
        waitElement(driver, clinicalVariableValue);
        TestUtils.wait(2);
        driver.findElement(clinicalVariableValue).click();
        Select dropdown = new Select(driver.findElement(clinicalVariableValue));
        dropdown.selectByVisibleText(arg1);
        TestUtils.wait(2);
        Assert.assertTrue(arg1 + "is not Selected for clinical Variable Value", arg1.equals(getSelectedValueFromDropdown(driver, clinicalVariableValue)));

    }

    /**
     * Checks ID field is sortable on the Traversal Maintenance Page
     */
    public void checkIDColIsSortable() {
        driver.findElement(firstLnk).click();
        new CommonPage(driver).waitForNOTBusyIndicator();
        driver.findElement(idSortBtn).click();
        new CommonPage(driver).waitForNOTBusyIndicator();
        List<String> obtainedList = getPaginatedResultsList(idValues);
        ArrayList<Integer> sortedList = new ArrayList<>();
        ArrayList<Integer> intObtainedList = new ArrayList<>();
        for (String s : obtainedList) {
            sortedList.add(Integer.valueOf(s));
            intObtainedList.add(Integer.valueOf(s));
        }
        Collections.sort(sortedList);
        Collections.reverse(sortedList);
        Assert.assertTrue(sortedList.equals(intObtainedList));
    }

    /**
     * Verifying Column is sortable on the Traversal Maintenance Page
     *
     * @param sortBtn,result
     * @return
     */

    public void checkOrderOfColumn(By sortBtn, By result) {
        driver.findElement(firstLnk).click();
        new CommonPage(driver).waitForNOTBusyIndicator();
        driver.findElement(sortBtn).click();
        new CommonPage(driver).waitForNOTBusyIndicator();
        checkAscendingSortedOrder(result);
        TestUtils.wait(4);
        driver.findElement(firstLnk).click();
        new CommonPage(driver).waitForNOTBusyIndicator();
        driver.findElement(sortBtn).click();
        new CommonPage(driver).waitForNOTBusyIndicator();
        checkDescendingSortedOrder(result);
    }

    /**
     * Verifying obtained list is sorted in Ascending order on the Traversal Maintenance Page
     *
     * @param results
     * @return
     */

    public void checkAscendingSortedOrder(By results) {

        List<String> obtainedList = getPaginatedResultsList(results);
        ArrayList<String> sortedList = new ArrayList<>();
        for (String s : obtainedList) {
            sortedList.add(s);
        }

        sortedList.sort(naturalOrdering());
        Assert.assertTrue(sortedList.equals(obtainedList));
    }


    /**
     * Obtaining results from current pages on the Traversal Maintenance Page
     *
     * @param elem
     * @return
     */

    public List<String> getResultsList(By elem) {
        return driver.findElements(elem).stream().map(WebElement::getText).collect(Collectors.toList());
    }

    /**
     * Obtaining results from all pages on the Traversal Maintenance Page
     *
     * @param row
     * @return
     */

    public List<String> getPaginatedResultsList(By row) {

        List<String> results = getResultsList(row);
        boolean morePages = false;

        while (!morePages) {
            driver.findElement(nextLnk).click();
            new CommonPage(driver).waitForNOTBusyIndicator();
            results.addAll(getResultsList(row));
            morePages = Boolean.parseBoolean(driver.findElement(nextLnk).getAttribute("disabled"));

        }

        return results;
    }

    /**
     * Checks Delete,Expand,Edit icons on results grid on the Traversal Maintenance Page
     */
    public void checkExpandEditAndDeleteIcons() {
        log.warn("Verifying Expand,edit,Delete icon");
        List<WebElement> results = driver.findElements(idValues);
        for (int i = 1; i <= results.size(); i++) {
            Assert.assertTrue("Expand Icon doesn't exist for ID" + i, isElementPresent(driver, By.xpath("//*[@id='diseaseTraversalMaintenanceTableID']/tbody/tr[" + i + "]/td[2]/span")));
            Assert.assertTrue("Edit Icon doesn't exist for ID" + i, isElementPresent(driver, By.xpath("//*[@id='diseaseTraversalMaintenanceTableID']/tbody/tr[" + i + "]/td[3]/span[@title='Edit Traversal']")));
            Assert.assertTrue("Delete Icon doesn't exist for ID" + i, isElementPresent(driver, By.xpath("//*[@id='diseaseTraversalMaintenanceTableID']/tbody/tr[" + i + "]/td[3]/span[@title='Delete Traversal']")));
        }

    }

    /**
     * verifying Edit Icon on Traversal Maintenance Page
     */
    public void verifyEditIcon() {
        log.warn("verifying Edit (pencil) Icon present in Traversal Maintenance grid .");
        List<WebElement> results = driver.findElements(idValues);
        for (int i = 1; i <= results.size(); i++) {
            Assert.assertTrue("Edit Icon doesn't exist for ID" + i, isElementPresent(driver, By.xpath("//*[@id='diseaseTraversalMaintenanceTableID']/tbody/tr[" + i + "]/td[3]/span[@title='Edit Traversal']")));
            highlightElement(driver, By.xpath("//*[@id='diseaseTraversalMaintenanceTableID']/tbody/tr[" + i + "]/td[3]/span[@title='Edit Traversal']"));
        }

    }

    /**
     * Checks Checkbox selected option on results grid on the Traversal Maintenance Page
     */
    public void checkCheckBoxSelectedOption() {
        log.warn("Verifying Checkbox selected option");
        List<WebElement> results = driver.findElements(idValues);
        for (int i = 1; i <= results.size(); i++) {
            Assert.assertTrue("Checkbox doesn't exist for ID" + i, isElementPresent(driver, By.xpath("//*[@id='diseaseTraversalMaintenanceTableID']/tbody/tr[" + i + "]/td[1]/input")));
        }
    }

    /**
     * Checks LastUpdated icon on results grid on the Traversal Maintenance Page
     */
    public void checkLastUpdatedIcon() {
        log.warn("Verifying LastUpdated icon");
        List<WebElement> results = driver.findElements(idValues);
        for (int i = 1; i <= results.size(); i++) {
            Assert.assertTrue("LastUpdated Icon doesn't exist for ID" + i, isElementPresent(driver, By.xpath("//*[@id='diseaseTraversalMaintenanceTableID']/tbody/tr[" + i + "]/td[10]/span")));
            driver.findElement(By.xpath("//*[@id='diseaseTraversalMaintenanceTableID']/tbody/tr[" + i + "]/td[10]/span")).click();
        }
    }

    /**
     * Verifying obtained list is sorted in Descending order on the Traversal Maintenance Page
     *
     * @param results
     * @return
     */

    public void checkDescendingSortedOrder(By results) {

        List<String> obtainedList = getPaginatedResultsList(results);
        ArrayList<String> sortedList = new ArrayList<>();
        for (String s : obtainedList) {
            sortedList.add(s);
        }
        sortedList.sort(naturalOrdering());
        Collections.reverse(sortedList);
        Assert.assertTrue(sortedList.equals(obtainedList));
    }

    /**
     * Checks search fields on the Traversal Maintenance Page
     */

    public void validateSearchFields() {
        log.warn("Verifying search fields");
        Assert.assertTrue("Cancer Type Label doesn't exist", driver.findElement(cancerTypeLabel).getText().contains("Cancer Type"));
        Assert.assertTrue("Search button doesn't exists", isElementPresent(driver, searchButton));
        Assert.assertTrue("Clear button doesn't exists", isElementPresent(driver, clearBtn));

    }


    /**
     * Verifies Show Records dropdown and values on the Traversal Maintenance Page
     */

    public void validateShowRecordsDropdown(int arg1, int arg2) {
        int[] exp = {arg1, arg2};
        int count = 0;
        Select select = new Select(driver.findElement(showSelectBox));
        List<WebElement> allOptions = select.getOptions();
        for (WebElement we : allOptions) {
            for (int i = 0; i < exp.length; i++) {
                if (we.getText().equals(String.valueOf(exp[i]))) {
                    count++;
                }
            }
        }
        Assert.assertTrue("Show records doesn't have options as 50 and 100", count == exp.length);

    }


    /**
     * Verifies Please provide search message on the Traversal Maintenance Page
     */
    public void checkProvideSearchCriteriaMsg() {
        log.warn("Validate Msg without any search performed");
        Assert.assertEquals("Please provide search msg is not present", "Please Provide Search Criteria.", driver.findElement(msgForWithoutSearch).getText());

    }

    /**
     * Verifies Required label on the Traversal Maintenance Page
     */
    public void checkRequiredLabel() {
        log.warn("Validate Required Label");
        Assert.assertEquals("Required label is not present", "Required", driver.findElement(requiredLabel).getText());
    }


    /**
     * Validates that results are populated according to the search inputs on results grid
     */
    public void validateSearchResults(String cancerType) {
        log.warn("Validating search results");
        List<String> obtainedList;
        try {
            List<WebElement> results = driver.findElements(searchResults);
            if (results.size() >= 0) {
                obtainedList = getPaginatedResultsList(cancerTypeValues);
                for (int i = 0; i < obtainedList.size(); i++) {
                    Assert.assertTrue("Results are not according to the search performed", obtainedList.get(i).equalsIgnoreCase(cancerType));
                }
            }
        } catch (Exception e) {
            Assert.assertEquals("Got wrong message for search with no results", "No records to display.", driver.findElement(msgForWithoutSearch).getText());
        }

    }

    /**
     * Returns total number of pages on the Traversal Maintenance Page
     *
     * @Return
     */
    public int getPageCount() {
        boolean morePages = false;
        int count = 1;
        while (!morePages) {
            count++;
            driver.findElement(nextLnk).click();
            new CommonPage(driver).waitForNOTBusyIndicator();
            morePages = Boolean.parseBoolean(driver.findElement(nextLnk).getAttribute("disabled"));
        }
        return count;
    }


    /**
     * Checks total no.of pages wrt total records on results grid on the Traversal Maintenance Page
     */
    public void validatePagesCount() {
        String[] totalRecordsLab = driver.findElement(totalRecordsLabel).getText().split(":");
        int totalRecords = Integer.parseInt(totalRecordsLab[1].trim());

        Select select = new Select(driver.findElement(showSelectBox));
        int totalRecsPerPage = Integer.parseInt(select.getFirstSelectedOption().getText());
        int pagesCount = totalRecords / totalRecsPerPage + (totalRecords % totalRecsPerPage == 0 ? 0 : 1);

        Assert.assertEquals("Pages count is incorrect wrt total records", pagesCount, getPageCount());

    }

    /**
     * Clicking search Button on Traversal Maintenance Page
     */
    public void clickSearchButton() {
        log.warn("Click Search on Traversal Maintenance");
        highlightElement(driver, searchButton);
        driver.findElement(searchButton).click();
    }

    /**
     * verifying Delete Icon on Traversal Maintenance Page
     */
    public void verifyDeleteIcon() {
        log.warn("verifying Delete Icon present in Traversal Maintenance grid .");
        List<WebElement> results = driver.findElements(idValues);
        for (int i = 1; i <= results.size(); i++) {
            Assert.assertTrue("Delete Icon doesn't exist for ID" + i, isElementPresent(driver, By.xpath("//*[@id='diseaseTraversalMaintenanceTableID']/tbody/tr[" + i + "]/td[3]/span[@title='Delete Traversal']")));
            highlightElement(driver, By.xpath("//*[@id='diseaseTraversalMaintenanceTableID']/tbody/tr[" + i + "]/td[3]/span[@title='Delete Traversal']"));
        }

    }

    /**
     * verifying Expand Icon on Traversal Maintenance Page
     */
    public void verifyExpandIcon() {
        log.warn("verifying Expand Icon present in Traversal Maintenance grid .");
        List<WebElement> results = driver.findElements(idValues);
        for (int i = 1; i <= results.size(); i++) {
            Assert.assertTrue("Expand Icon doesn't exist for ID" + i, isElementPresent(driver, By.xpath("//*[@id='diseaseTraversalMaintenanceTableID']/tbody/tr[" + i + "]/td[2]/span")));
            highlightElement(driver, By.xpath("//*[@id='diseaseTraversalMaintenanceTableID']/tbody/tr[" + i + "]/td[2]/span"));
        }
    }

    /**
     * Clicking Edit Icon on Traversal Maintenance Page
     */
    public void clickEditIcon() {
        log.warn("clicking Edit (pencil) Icon present in Traversal Maintenance grid .");
        TestUtils.wait(2);
        driver.findElement(By.xpath("//*[@id='diseaseTraversalMaintenanceTableID']/tbody/tr[1]/td[3]/span[@title='Edit Traversal']")).click();
    }

    /**
     * Storing Authorization Duration from Traversal Maintenance Page
     */
    public void storeAuthorizationDuration() {
        log.warn("storing Authorization Duration from Traversal Maintenance grid .");
        List<WebElement> column = driver.findElements(authorizationDurationXpath);
        authorizationDuration = getvalue(column);
    }

    /**
     * Storing start Date from Traversal Maintenance Page
     */
    public void storeStartDate() {
        log.warn("storing Start Date from Traversal Maintenance grid .");
        List<WebElement> column = driver.findElements(startDateXpath);
        startDate = getvalue(column);
    }

    /**
     * Storing End Date from Traversal Maintenance Page
     */
    public void storeEndDate() {
        log.warn("storing End Date from Traversal Maintenance grid .");
        List<WebElement> column = driver.findElements(endDateXpath);
        endDate = getvalue(column);
    }

    /**
     * Method Used to get startdate enddate and authorization duration value from Traversal Maintenance Page
     *
     * @param column
     */
    private String getvalue(List<WebElement> column) {
        String value = "";
        for (WebElement e : column) {
            scrollUntilElementIsDisplay(driver, e);
            if (isElementPresent(e)) {
                value = e.getText();
                break;
            }
        }
        return value;
    }

    /**
     * Method Used to get variable value & variable type from Traversal Maintenance Page
     *
     * @param column
     */
    private List<String> getvalues(List<WebElement> column) {
        List<String> values = new ArrayList<>();
        for (WebElement e : column) {
            scrollUntilElementIsDisplay(driver, e);
            if (isElementPresent(e)) {
                values.add(e.getText());
            }
        }
        return values;
    }

    /**
     * Clicking Expand Icon on Traversal Maintenance Page
     */
    public void clickExpandIcon() {
        log.warn("clicking Expand Icon present in Traversal Maintenance grid .");
        List<WebElement> column = driver.findElements(expandIcon);
        for (WebElement e : column) {
            if (isElementPresent(e)) {
                highlightElement(driver, e);
                e.click();
                break;
            }
        }

    }

    /**
     * Sotring Clinical variable Type from  Traversal Maintenance Page
     */
    public void storeClinicalVariableType() {
        log.warn("storing clinical variable type from Traversal Maintenance grid .");
        List<WebElement> column = driver.findElements(clinicalVariableTypeXpath);
        clinicalVariableTypes = getvalues(column);
    }

    /**
     * Sotring Clinical variable value from  Traversal Maintenance Page
     */
    public void storeClinicalVariableValue() {
        log.warn("storing clinical variable value from Traversal Maintenance grid .");
        List<WebElement> column = driver.findElements(clinicalVariableValueXpath);
        clinicalVariableValues = getvalues(column);
    }

    /**
     * verifying startdate, enddate,variableType,variableValue and authorization duration value that is saved on edit traversal from Traversal Maintenance Page
     */
    public void verifySavedDataInTravesalMaintenacePage(String startDate, String endDate, String authorizationDuration, String variableType, String variableValue) {
        log.warn("verifying Saved Data In Traversal Maintenance Page");
        List<WebElement> column = driver.findElements(startDateXpath);
        String actualStartDate = getvalue(column);
        Assert.assertTrue("Start date is not matched", startDate.equals(actualStartDate));
        column = driver.findElements(endDateXpath);
        String actualEndDate = getvalue(column);
        Assert.assertTrue("End date is not matched", endDate.equals(actualEndDate));
        column = driver.findElements(authorizationDurationXpath);
        String actualAuthorizationDuration = getvalue(column);
        authorizationDuration = authorizationDuration + " Month";
        Assert.assertTrue("Authorization Duration is not matched", authorizationDuration.equals(actualAuthorizationDuration));
        column = driver.findElements(clinicalVariableTypeXpath);
        clinicalVariableTypes = getvalues(column);
        Assert.assertTrue("Variable Type is not matched", clinicalVariableTypes.contains(variableType));
        column = driver.findElements(clinicalVariableValueXpath);
        clinicalVariableValues = getvalues(column);
        Assert.assertTrue("Variable Value is not matched", clinicalVariableValues.contains(variableValue));
    }
    //Advanced Search

    /**
     * Clicking Advanced Search Button on Traversal Maintenance Page
     */
    public void clickAdvancedSearchButton() {
        log.warn("Click Advanced Search Link on Traversal Maintenance");
        highlightElement(driver, advancedSearchLink);
        driver.findElement(advancedSearchLink).click();
    }

    /**
     * Checks Advanced search Pop Up fields on the Traversal Maintenance Page
     */
    public void verifyAdvancedSearchPopUpElements() {
        log.warn("Verifying search fields");

        Assert.assertTrue("Title Advanced Search doesn't exist on Advanced Search Pop Up",
                driver.findElement(advancedSearchWindowTitle).getText().contains("Advanced Search"));
        Assert.assertTrue("Text Required* doesn't exist on Advanced Search Pop Up",
                driver.findElement(advancedSearchRequiredLabel).getText().contains("Required"));

        Assert.assertTrue("Cancer Type Label doesn't exist on Advanced Search Pop Up",
                driver.findElement(advancedSearchCancerTypeCaption).getText().contains("Cancer Type"));
        Assert.assertTrue("Authorization Duration Label doesn't exist on Advanced Search Pop Up",
                driver.findElement(advancedSearchDurationCaption).getText().contains("Authorization Duration"));
        Assert.assertTrue("Variable Type Label doesn't exist on Advanced Search Pop Up",
                driver.findElement(advancedSearchVariableTypeCaption).getText().contains("Variable Type"));
        Assert.assertTrue("Variable Value Label doesn't exist on Advanced Search Pop Up",
                driver.findElement(advancedSearchVariableValueCaption).getText().contains("Variable Value"));
        Assert.assertTrue("Add Clinical Variable hyperlink doesn't exist on Advanced Search Pop Up",
                driver.findElement(advancedSearchAddClinicalVariable).getText().contains("Add Clinical Variable"));
        Assert.assertTrue("Clinical Variable section doesn't exist on Advanced Search Pop Up",
                driver.findElement(advancedSearchClinicalVariableSection).getText().contains("Clinical Variable"));

        Assert.assertTrue("Cancer Type Element doesn't exist on Advanced Search Pop Up",
                driver.findElement(advancedSearchCancerType).isDisplayed());
        Assert.assertTrue("Authorization Duration Element doesn't exist on Advanced Search Pop Up",
                driver.findElement(advancedSearchDuration).isDisplayed());
        Assert.assertTrue("Variable Type Element doesn't exist on Advanced Search Pop Up",
                driver.findElement(advancedSearchVariableType).isDisplayed());
        Assert.assertTrue("Variable Value Element doesn't exist on Advanced Search Pop Up",
                driver.findElement(advancedSearchVariableValue).isDisplayed());

        Assert.assertTrue("X Element doesn't exist on Advanced Search Pop Up",
                driver.findElement(advancedSearchXbutton).isDisplayed());
        Assert.assertTrue("Search button Element doesn't exist on Advanced Search Pop Up",
                driver.findElement(advancedSearchSearchButton).isDisplayed());
        Assert.assertTrue("Clear button Element doesn't exist on Advanced Search Pop Up",
                driver.findElement(advancedSearchClearButton).isDisplayed());
        Assert.assertTrue("Cancel button Element doesn't exist on Advanced Search Pop Up",
                driver.findElement(advancedSearchCancelLink).isDisplayed());

    }

    /**
     * Selects Cancer Type from dropdown on the Advanced Search Pop Up
     */
    public void selectCancerTypeOnAdvancedSearchPopUp(String arg1) {
        log.warn(" Select cancer type from cancer type dropdown on Advanced Search Pop Up");
        waitElement(driver, advancedSearchCancerType);
        TestUtils.wait(2);
        driver.findElement(advancedSearchCancerType).click();
        Select dropdown = new Select(driver.findElement(advancedSearchCancerType));
        dropdown.selectByVisibleText(arg1);
        TestUtils.wait(3);
    }

    /**
     * Enters Authorization Duration on the Traversal Maintenance Page
     */
    public void enterAuthorizationDurationOnAdvancedSearchPopUp(String arg1) {
        log.warn("enter the Authorization Duration");
        waitElement(driver, advancedSearchDuration);
        highlightElement(driver, advancedSearchDuration);
        driver.findElement(advancedSearchDuration).sendKeys(arg1);
    }

    /**
     * Selects Variable Type from dropdown on the Advanced Search Pop Up
     */
    public void selectVariableTypeOnAdvancedSearchPopUp(String arg1) {
        log.warn(" Select Vriable type from cancer type dropdown on Advanced Search Pop Up");
        waitElement(driver, advancedSearchVariableType);
        TestUtils.wait(2);
        driver.findElement(advancedSearchVariableType).click();
        Select dropdown = new Select(driver.findElement(advancedSearchVariableType));
        dropdown.selectByVisibleText(arg1);
        TestUtils.wait(3);
    }

    /**
     * Selects Variable Value from dropdown on the Advanced Search Pop Up
     */
    public void selectVariableValueOnAdvancedSearchPopUp(String arg1) {
        log.warn(" Select Variable Value from cancer type dropdown on Advanced Search Pop Up");
        waitElement(driver, advancedSearchVariableValue);
        TestUtils.wait(2);
        driver.findElement(advancedSearchVariableValue).click();
        Select dropdown = new Select(driver.findElement(advancedSearchVariableValue));
        dropdown.selectByVisibleText(arg1);
        TestUtils.wait(3);
    }

    /**
     * Clicking Search Button on Advanced Search Pop Up
     */
    public void clickSearchButtonOnAdvancedSearchPopUp() {
        log.warn("Click Search button on Advanced Search Pop Up");
        highlightElement(driver, advancedSearchSearchButton);
        driver.findElement(advancedSearchSearchButton).click();
    }

    /**
     * Clicking Clear Button on Advanced Search Pop Up
     */
    public void clickClearButtonOnAdvancedSearchPopUp() {
        log.warn("Click Clear button on Advanced Search Pop Up");
        highlightElement(driver, advancedSearchClearButton);
        driver.findElement(advancedSearchClearButton).click();
    }

    /**
     * Clicking Cancel Button on Advanced Search Pop Up
     */
    public void clickCancelButtonOnAdvancedSearchPopUp() {
        log.warn("Click Cancel button on Advanced Search Pop Up");
        highlightElement(driver, advancedSearchCancelLink);
        driver.findElement(advancedSearchCancelLink).click();
    }

    /**
     * Clicking X Button on Advanced Search Pop Up
     */
    public void clickXbuttonOnAdvancedSearchPopUp() {
        log.warn("Click X button on Advanced Search Pop Up");
        highlightElement(driver, advancedSearchXbutton);
        driver.findElement(advancedSearchXbutton).click();
    }

    /**
     * Checks Cancer Type is cleared on Advanced Search Pop Up
     */
    public void checkCancerTypeValueIsClearedOnAdvancedSearchPopUp() {
        log.warn("Verifies Cancer type value is cleared on Advanced Search Pop Up");
        Assert.assertEquals("Cancer Type Value is not cleared", getSelectedValueFromDropdown(driver, advancedSearchCancerType), "");
    }

    /**
     * Checks Authorization Duration is cleared on Advanced Search Pop Up
     */
    public void checkAuthorizationDurationValueIsClearedOnAdvancedSearchPopUp() {
        log.warn("Verifies Authorization Duration value is cleared on Advanced Search Pop Up");
        Assert.assertEquals("Authorization Duration Value is not cleared", driver.findElement(advancedSearchDuration).getText(), "");
    }

    /**
     * Checks Variable Type is cleared on Advanced Search Pop Up
     */
    public void checkVariableTypeValueIsClearedOnAdvancedSearchPopUp() {
        log.warn("Verifies Variable Type value is cleared on Advanced Search Pop Up");
        Assert.assertEquals("Variable Value is not cleared", getSelectedValueFromDropdown(driver, advancedSearchVariableType), "");
    }

    /**
     * Checks Variable Value is cleared on Advanced Search Pop Up
     */
    public void checkVariableValueValueIsClearedOnAdvancedSearchPopUp() {
        log.warn("Verifies Variable value is cleared on Advanced Search Pop Up");
        Assert.assertEquals("Variable Value is not cleared", getSelectedValueFromDropdown(driver, advancedSearchVariableValue), "");
    }

    /**
     * Verify search applied text on the Traversal Maintenance Page after advance search
     */
    public void verifySearchAppliedTextAfterAdvancedSearch() {
        log.warn("Verifying search applied text");
        Assert.assertTrue("Search Applied Label doesn't exist", driver.findElement(advancedSearchSearchAppliedText).getText().contains("Search Applied"));
    }

    /**
     * Verify search applied type and value for cancer type after advance search
     */
    public void verifySearchAppliedForCancerType(String arg1) {
        TestUtils.demoBreakPoint(null, driver, "count of records");
        log.warn("Verifying search applied type and value for Cancer Type");
        Assert.assertTrue("Cancer Type Label doesn't exist", driver.findElement(advancedSearchSearchAppliedValues).getText().contains("Cancer Type"));
        Assert.assertTrue("Cancer Type Value doesn't exist", driver.findElement(advancedSearchSearchAppliedValues).getText().contains(arg1));
    }

    /**
     * Verify search applied type and value for duration after advance search
     */
    public void verifySearchAppliedForDuration(String arg1) {
        log.warn("Verifying search applied type and value for Duration");
        Assert.assertTrue("Duration Label doesn't exist", driver.findElement(advancedSearchSearchAppliedValues).getText().contains("Duration"));
        Assert.assertTrue("Duration Value doesn't exist", driver.findElement(advancedSearchSearchAppliedValues).getText().contains(arg1));
    }

    /**
     * Checks Clinical Variable Type and Clinical Variable Value are populated when expand button is clicked on results grid on the Traversal Maintenance Page
     */
    public void checkClinicalVariableTypeAndValueArePopulated() {
        log.warn("Clinical Variable Type and Clinical Variable Value are populated");

        driver.findElement(By.xpath("//*[@id='diseaseTraversalMaintenanceTableID']/tbody/tr[1]/td[2]/span")).click();
        Assert.assertEquals("Clinical Variable Type doesn't exist for ID", "Clinical Variable Type", driver.findElement(By.xpath("//tr[contains(@class, 'clinVars')]//thead/tr[1]/td[1]")).getText());
        Assert.assertEquals("Clinical Variable Value doesn't exist for ID", "Clinical Variable Value", driver.findElement(By.xpath("//tr[contains(@class, 'clinVars')]//thead/tr[1]/td[2]")).getText());

        storeClinicalVariableType();
        storeClinicalVariableValue();

        String description = driver.findElement(xpath("//*[@id='diseaseTraversalMaintenanceTableID']/tbody/tr[1]/td[6]/span")).getText();
        description = description.toLowerCase();
        List<String> actualClinicalDetails = new ArrayList<>();
        String[] arrOfStr = description.split("; ");
        actualClinicalDetails = Arrays.asList(Arrays.copyOfRange(arrOfStr, 1, arrOfStr.length));

        List<String> obtainedClinicalDetails = new ArrayList<>();
        for (int i = 0; i < clinicalVariableTypes.size(); i++) {
            obtainedClinicalDetails.add((clinicalVariableTypes.get(i) + " - " + clinicalVariableValues.get(i)).toLowerCase());
        }

        Set<String> obtainedClinicalDetailsSet = new HashSet<String>(obtainedClinicalDetails);
        Set<String> actualClinicalDetailsSet = new HashSet<String>(actualClinicalDetails);

        Assert.assertEquals(obtainedClinicalDetailsSet, actualClinicalDetailsSet);
    }

    /**
     * Clicking Add Clinical Variable Link on Advanced Search Pop Up
     */
    public void clickAddClinicalVariableAdvancedSearch() {
        log.warn("Click Add Clinical Variable Link on Advanced Search Pop Up");
        highlightElement(driver, advancedSearchAddClinicalVariable);
        driver.findElement(advancedSearchAddClinicalVariable).click();
    }

    /**
     * Verify search applied type and value for duration after advance search
     */
    public void verifyTextDisplayedInNextLineAdvancedSearchApplied() {
        log.warn("Verifying search applied type and value in stacked");
        Assert.assertTrue("Duration Label doesn't exist", driver.findElement(advancedSearchSearchAppliedValues).getText().contains("\n"));
    }

    /**
     * Clicks on select All checkbox on the Traversal Maintenance Page
     */
    public void clickSelectAllCheckBox() {
        log.warn("Clicks on select All checkbox on the Traversal Maintenance Page ");
        waitElement(driver, selectAllCheckBox);
        highlightElement(driver, selectAllCheckBox);
        driver.findElement(selectAllCheckBox).click();

    }

    /**
     * Verifies that checkbox next to each traversal is selected on results grid for current page on the Traversal Maintenance Page
     */
    public void verifyCheckBoxNextToTraversalIsSelectedForCurrentPage() {
        log.warn("Verifies that checkbox next to each traversal is selected on results grid");
        List<WebElement> results = driver.findElements(idValues);
        for (int i = 1; i < results.size(); i++) {
            Assert.assertTrue("check box is not selected next to traversal of row" + i, driver.findElement(By.xpath("//*[@id='diseaseTraversalMaintenanceTableID']/tbody/tr[" + i + "]/td[1]/input")).isSelected());
        }
    }

    /**
     * Verifies that checkbox next to each traversal is unselected on results grid for current page on the Traversal Maintenance Page
     */
    public void verifyCheckBoxNextToTraversalIsUnSelectedForCurrentPage() {
        log.warn("Verifies that checkbox next to each traversal is unselected on results grid");
        List<WebElement> results = driver.findElements(idValues);
        for (int i = 1; i < results.size(); i++) {
            Assert.assertFalse("check box is selected next to traversal of row" + i, driver.findElement(By.xpath("//*[@id='diseaseTraversalMaintenanceTableID']/tbody/tr[" + i + "]/td[1]/input")).isSelected());
        }
    }


    /**
     * Verifies that checkbox next to each traversal is unselected on results grid for next page on the Traversal Maintenance Page
     */
    public void verifyCheckBoxNextToTraversalIsUnSelectedForNextPages() {
        log.warn("Verifies that checkbox next to each traversal is unselected on results grid");
        boolean morePages = false;
        driver.findElement(nextLnk).click();
        TestUtils.wait(4);

        while (!morePages) {
            //  Assert.assertFalse("Select All checkbox is selected for next page",driver.findElement(selectAllCheckBox).isSelected());
            List<WebElement> resultsOfNextPage = driver.findElements(idValues);
            for (int i = 1; i < resultsOfNextPage.size(); i++) {
                Assert.assertFalse("check box is selected next to traversal of row" + i, driver.findElement(By.xpath("//*[@id='diseaseTraversalMaintenanceTableID']/tbody/tr[" + i + "]/td[1]/input")).isSelected());
            }
//            driver.findElement(nextLnk).click();
            new CommonPage(driver).waitForNOTBusyIndicator();
            morePages = Boolean.parseBoolean(driver.findElement(nextLnk).getAttribute("disabled"));
        }
    }

    /**
     * Clicks on First hyperlink on the Traversal Maintenance Page
     */
    public void clickOnFirstHyperLink() {
        log.warn("Clicks on First hyperlink on the Traversal Maintenance Page ");
        waitElement(driver, firstLnk);
        highlightElement(driver, firstLnk);
        driver.findElement(firstLnk).click();
    }


    /*return the TraversalID from DB,
     * where HSC_ID is either associated to travesral id
     * or not*/

    public String validateAndReturnTraversalID(String traversalIDType) throws SQLException {

        List<String> value = OcmMBMDao.getDao().returnMultipleRowValue("select dses_trvrs_id from dses_trvrs");
        for (int i = 0; i < value.size(); i++) {
            dses_trvrs_id = value.get(i);
            List<String> list_of_hsc_id = OcmMBMDao.getDao().returnMultipleRowValue("select hsc_id from hsc where dses_trvrs_id =" + dses_trvrs_id);
            String hsc_id = null;

            try {
                hsc_id = list_of_hsc_id.get(0);
                if (traversalIDType.equals("associated")) {
                    dbTraversalID = dses_trvrs_id;
                    return dbTraversalID;
                }
            } catch (Exception knownException) {
                dbTraversalID = dses_trvrs_id;
            }
            cancerTypeDropDownValue = getDiseaseType();
            if ((cancerTypeDropDownValue.equals("Prostate Cancer") || cancerTypeDropDownValue.equals("Breast Cancer"))
                    && hsc_id == null) {
                return dbTraversalID;
            }
        }
        log.warn("Check DB - no data matched with the hsc " + traversalIDType + " condition");
        return null;
    }

    /**
     * getDiseaseType
     *
     * @return
     * @throws SQLException
     */
    public String getDiseaseType() throws SQLException {
        List<String> listOfDiseaseType = OcmMBMDao.getDao().returnMultipleRowValue("select dses_typ_id from dses_trvrs where dses_trvrs_id =" + this.dses_trvrs_id);
        dbCancerType = listOfDiseaseType.get(0);
        List<String> value = OcmMBMDao.getDao().returnMultipleRowValue("select ref_desc from ref where ref_nm='diseaseType' and ref_cd=" + dbCancerType);
        return cancerTypeDropDownValue = value.get(0);
    }

    /**
     * ValidateTraversalDataNotPresentInDB
     *
     * @throws SQLException
     */
    public void validateTraversalDataNotPresentInDB() throws SQLException {
        List<String> value = OcmMBMDao.getDao().returnMultipleRowValue("select * from dses_trvrs where dses_trvrs_id =" + dbTraversalID);
        Iterator itr = value.iterator();
        Assert.assertFalse("Traversal ID is not deleted from DB", itr.hasNext());
    }

    /**
     * UserSearchForTraversalIDRecord
     *
     * @throws SQLException
     */
    public void userSearchForTraversalIDRecord() throws SQLException {
        enterDataIntoTraversalIDOnTraversalMaintenancePage(dbTraversalID);
        selectCancerTypeOnTraversalMaintenancePage(getDiseaseType());
        clickSearchButton();
    }

    /**
     * Deleting the very first record from UI
     */
    public void deleteFirstRecord() {
        log.warn("deleting the very first record from UI");
        driver.findElement(deleteButton).click();
    }

    /**
     * Valdiating presence of record in TraversalDetails
     */
    public void validateRecordPresentInTraversalDetails() {
        log.warn("Valdiating presence of record in details");
        Boolean record = isElementPresent(driver, By.xpath("//*[text()='" + dbTraversalID + "']"));
        Assert.assertTrue("Record is not displayed", record);
    }

    /* selects the bulk action item on traversal maintance page*/

    public void clickOnBulkAction(String dropdownvalue) {
        By dropdown_Apply_Bulk_Action = By.xpath("//select[@ng-model='diseaseTraversalMaintenanceTable.bulkAction']");
        log.warn(" Select bulk action from bulk action dropdown");
        waitElement(driver, dropdown_Apply_Bulk_Action);
        TestUtils.wait(2);
        Select dropdown = new Select(driver.findElement(dropdown_Apply_Bulk_Action));
        dropdown.selectByVisibleText(dropdownvalue);
        log.warn("user selects " + dropdownvalue + "from bulk action dropdown");
        TestUtils.wait(3);
    }
    /* clicks on apply  Selected hyperlink on traversal maintance page*/

    public void clickOnApplySelected(String button_label) {
        By button_applytoSeleced = By.xpath("//a[contains(text(),'" + button_label + "')]");
        log.warn("user clicks on apply to selected");
        TestUtils.wait(2);
        driver.findElement(button_applytoSeleced).click();
    }

    /* verifies text displayed on editauth duration popup */

    public void verifyTextDisplayedInEditAuthDurationPopup(String text) {
        By label_text = By.xpath("//div[@class='bulkEditDescription']");
        String displayed_text = driver.findElement(label_text).getText();
        log.warn("verifing text present on the popup as" + text);
        Assert.assertEquals("the displayed text is not as expected", text, displayed_text);
    }

    /* enter data into  textbox  displayed for editauth duration popup */

    public void enterDataIntoTraversalDurationOnEditAuthDurationPopup(String duration) {
        By textbox_EditAuthDuration = By.xpath("//input[@name='bulkEditAuthDurationName']");
        driver.findElement(textbox_EditAuthDuration).clear();
        driver.findElement(textbox_EditAuthDuration).sendKeys(duration);
        log.warn("entering data into the editauthduration textbox");
    }

    /* clicks on X button on edit auth duration popup */

    public void user_click_The_x_Button_On_Popup() {
        By Cancel_button = By.xpath("//button[@ng-click='bulkEditTraversalPopupModel.closePopup()']");
        driver.findElement(Cancel_button).click();
        log.warn("clicks on x button on edit auth popup");
    }

    /* clicks on apply on edit auth duration popup */

    public void clickOnApply(String arg0, String message) {
        By apply_button = By.xpath("//input[@value='" + arg0 + "']");
        By pagination_table_count = By.xpath("//select[@ng-change='diseaseTraversalMaintenanceTable.setPage(1)']//option[@selected='selected']");
        String s = driver.findElement(pagination_table_count).getText();
        driver.findElement(apply_button).click();
        log.warn("clicking on apply button on edit auth duration popup");
        By elementTxt = By.xpath("//*[contains(text(),'" + message + "')]");


        boolean present = false;

        //Checking
        if (isElementPresent(driver, elementTxt)) {
            highlightElement(driver, elementTxt);
            present = true;
        }

        Assert.assertTrue("Element with text " + s + message + " is NOT visible. ", present);
    }

    /**
     * Verify Advanced Search Window closed
     */
    public void verifyAdvancedSearchWindowClosed() {
        log.warn("Verifying Advanced Search Window closed");
        waitNotElement(driver, advancedSearchWindow);
        Assert.assertTrue("Advanced Search Window exist", !driver.findElement(advancedSearchWindow).isDisplayed());
    }

    /**
     * Select DecisionOption FromWarningMessage
     *
     * @param decisionOption
     */
    public void selectDecisionOptionFromWarningMessage(String decisionOption) {
        log.warn("User has slected the option " + decisionOption + " to delete the travesal");
        driver.findElement(By.xpath("(//input[@value='" + decisionOption + "' and contains(@class,'tk-btn')])[1]")).click();
    }

    /**
     * Validate Delete TraversalWarningPopUp
     */
    public void validateDeleteTraversalWarningPopUp() {
        log.warn("User to validate delete traversal warning pop up");
        Assert.assertTrue("delete traversal warning popup header not displayed correctly",
                isElementPresent(driver, deleteTraversalWarningPopupHeader));
        Assert.assertTrue("",
                isElementPresent(driver, deleteTraversalWarningPopupCloseButton));
        String deleteTraversalContent = driver.findElement(deleteTraversalWarningPopupContent).getText();
        log.warn(deleteTraversalContent);
        Assert.assertTrue("Delete traversal content text is in correct",
                deleteTraversalContent.equals("Are you sure you want to delete this traversal?"));
    }


    public boolean clinicalVariableValueContainsOption(String valueOption) {
        this.driver.findElement(By.id("traversalSearchVariableValue")).click();
        List<WebElement> options = this.driver.findElements(By.xpath("//select[@id='traversalSearchVariableValue']/option"));
        return containsOption(options, valueOption);
    }

    public boolean hasResult() {
        TestUtils.wait(2);
        List<WebElement> els = driver.findElements(By.xpath("//table[@id='diseaseTraversalMaintenanceTableID']//tr"));
        return els.size() != 2 || !els.get(1).getText().equals("No records to display.");
    }

    /**
     * Remove FirstResut from TraversalMaintenanceTable
     */
    public void removeFirstResut() {
        driver.findElements(By.xpath("//table[@id='diseaseTraversalMaintenanceTableID']//span[@title='Delete Traversal']")).get(0).click();
        TestUtils.demoBreakPoint(null, driver, "removing the traversal");
        driver.findElement(By.xpath("//form[@name='deleteTraversalPopupForm']//input[@value='Yes']")).click();
        TestUtils.wait(1);
    }

    /**
     * Clicking Add Traversal link
     */
    public void clickAddTraversal() {
        log.warn("Clicking Add Traversal");
        highlightElement(driver, addTraversal);
        onMouseHover(driver, addTraversal);
        this.driver.findElement(addTraversal).click();
    }

    public boolean clinicalVariableTypeContainsOption(String typeOption) {
        this.driver.findElement(By.id("traversalSearchVariableType")).click();
        List<WebElement> options = this.driver.findElements(By.xpath("//select[@id='traversalSearchVariableType']/option"));
        return containsOption(options, typeOption);
    }

    private boolean containsOption(List<WebElement> options, String label) {
        if (1 == options.size()) {
            //the only empty option
            return false;
        } else {
            for (WebElement option : options) {
                if (label.equals(option.getText())) {
                    return true;
                }
            }
        }
        return false;

    }

    /**
     * Getting ResultCount
     *
     * @return
     */
    public String getResultCount() {
        String s = this.driver.findElement(By.xpath("//span[contains(.,'Total Records:')]")).getText();
        return s.split(":", 2)[1].trim();
    }

    /**
     * Getting TraversalIdByRow
     *
     * @param sRow
     * @return
     */
    public String getTraversalIdByRow(String sRow) {
        String id = this.driver.findElement(By.xpath("//table[@id='diseaseNewTraversalMaintenanceTableID']/tbody/tr[" + sRow + "]/td[2]")).getText();
        return id;
    }

    public void clickSelectAllCheckBox2() {
        this.driver.findElement(selectAllCheckBox2).click();
    }

    /**
     * Select Bulk Action
     *
     * @param action
     */
    public void selectBulkAction(String action) {
        log.warn("Select Bulk Action");
        Select select = new Select(this.driver.findElement(traversalBulkActionDropDownList));
        select.selectByVisibleText(action);
    }

    /**
     * Click Apply to Selected on Bulk items
     */
    public void clickApplyToSelectedLink() {
        log.warn("Select Apply to Bulk Action");
        this.driver.findElement(applyToSelectedLink).click();
    }

    /**
     * verifying RedBorderColorFor BulkAction SelectBox
     */
    public void verifyRedBorderColorForBulkActionSelectBox() {

        log.warn("verifying Red Color Border ");
        String expectedColor = "rgba(169, 60, 71, 1)";

        String actualBorderColor = driver.findElement(applyBulkAction).getCssValue("border-bottom-color");
        Assert.assertTrue("border color does not match", expectedColor.equals(actualBorderColor));

    }

    /**
     * Select cancer type on add traversal page
     * <p>
     * * @param cancertype to be selected
     */

    public void selectCancerTypeOnAddTraversalPage(String cancerType) {
        By cancerType_addTraversal = By.xpath("//select[@ng-model='record.diseaseType']");
        log.warn(" Select cancer type from cancer type dropdown");
        waitElement(driver, cancerType_addTraversal);
        driver.findElement(cancerType_addTraversal).click();
        Select dropdown = new Select(driver.findElement(cancerType_addTraversal));
        dropdown.selectByVisibleText(cancerType);
        TestUtils.wait(3);
        Assert.assertTrue(cancerType + "is not Selected for cancer type", cancerType.equals(getSelectedValueFromDropdown(driver, cancerType_addTraversal)));

    }

    /**
     * enter start date  on add traversal page
     * <p>
     * * @param startdate to be selected
     */
    public void enterStartDateOnAddTraversalPage(String startdate) {
        log.warn("entering startdate into the add traversal page");
        highlightElement(driver, startDate_AddTraversal);
        waitElement(driver, startDate_AddTraversal);
        driver.findElement(startDate_AddTraversal).sendKeys(startdate);

    }

    /**
     * enter  authorization duration  on add traversal page
     * <p>
     * * @param  authorization duration to be selected
     */

    public void enterAuthorizationDurationOnAddTraversalPage(String authduration) {
        log.warn("enter the Authorization Duration");
        waitElement(driver, addTraversalAuthDuration);
        highlightElement(driver, addTraversalAuthDuration);
        driver.findElement(addTraversalAuthDuration).sendKeys(authduration);
    }

    /**
     * select variable Type  on add traversal page
     * <p>
     * * @param  variable type to be selected
     */
    public void selectVariableTypeOnAddTraversalPage(String variableType) {
        log.warn(" Select Variable type from cancer type dropdown on Add traversal page");
        waitElement(driver, addTraversalVariableType);
        highlightElement(driver, addTraversalVariableType);
        TestUtils.wait(2);
        driver.findElement(addTraversalVariableType).click();
        Select dropdown = new Select(driver.findElement(addTraversalVariableType));
        dropdown.selectByVisibleText(variableType);
        TestUtils.wait(3);
    }

    /**
     * select  variable value  on add traversal page
     * <p>
     * * @param  variable value to be selected
     */
    public void enterVariableValueOnAddTraversalPage(String variablevalue) {
        log.warn("enter the variable value");
        waitElement(driver, addTraversalVariableValue);
        highlightElement(driver, addTraversalVariableValue);
        driver.findElement(addTraversalVariableValue).sendKeys(variablevalue);
    }

    /**
     * close  message  on add traversal page
     */
    public void closeMessageOnAddTraversalPage() {
        log.warn("closing the message");
        By close_msg = By.xpath("//button[@ng-click='closeMessage()']");
        highlightElement(driver, close_msg);
        driver.findElement(close_msg).click();
    }

    /**
     * entering start date and end date on the edit bulk start date and end date page
     */
    public void enterStartDateAndEndDateOnBulkPage(String startdate, String enddate) {
        log.warn("entering start date and end date");
        By StartDate_bulkPage = By.xpath("//input[@name='Bulk Edit Start Date Value']");
        highlightElement(driver, StartDate_bulkPage);
        driver.findElement(StartDate_bulkPage).sendKeys(startdate);
        By EndDate_bulkPage = By.xpath("//input[@name='Bulk Edit End Date Value']");
        highlightElement(driver, EndDate_bulkPage);
        driver.findElement(EndDate_bulkPage).sendKeys(enddate);

    }

    /**
     * click apply on Bulk Start date and End Date page
     */
    public void clickOnApplyOnBulkStartAndEndDatePage() {
        log.warn("clicking on apply on edit bulk start date and end date page");
        By apply_bulkEditPage = By.xpath("//input[@value='Apply']");
        highlightElement(driver, apply_bulkEditPage);
        driver.findElement(apply_bulkEditPage).click();

    }

    /**
     * verifing count of records retrived in advanced search
     */

    public void verifyCount(int count) {
        log.warn("verifying count of the records");
        By count_of_records = By.xpath("//span[contains(text(),'Total Records')]");
        String s = driver.findElement(count_of_records).getText();
        String[] count_value = s.split("Total Records: ");
        Assert.assertEquals("the retrieved traversals are not same", count, Integer.parseInt(count_value[1]));

    }


    /**
     * verifying red color for border and message for Traversal Maintenance Required fields
     *
     * @param txtMessage
     */
    public void verifyingRedColorBorderAndMessage(String txtMessage) {
        log.warn("verifying Red Color Border And Message  ");
        String expectedColor = "rgba(169, 60, 71, 1)";
        By elementTxt = By.xpath("//*[contains(text(),'" + txtMessage + "')]");
        String actualMessageColor = "";
        actualMessageColor = driver.findElement(elementTxt).getCssValue("color");
        Assert.assertTrue("error message color does not match", expectedColor.equals(actualMessageColor));


    }

    /*
    This method is to verify the field border is Red and Error pop-up message
    when user doesn't select mandatory field
     */
    public void fieldValidationAndPopUp(String text, String textMessage, String popup) {

        log.warn("Field level Validation and Pop-Up message");
        String expectedColor = "rgba(169, 60, 71, 1)";
        By elementTxt = By.xpath("//select[contains(@id,'" + text + "')]|//input[contains(@id, '" + text + "')]");
        String actualBorderColor = driver.findElement(elementTxt).getCssValue("border-bottom-color");
        System.out.println(actualBorderColor);
        Assert.assertTrue("border color does not match", expectedColor.equals(actualBorderColor));

        By fieldValidationTxt = By.xpath("//div[contains(text(),'" + textMessage + "')]|//span[contains(text(),'" + textMessage + "')]");
        Assert.assertEquals(driver.findElement(fieldValidationTxt).getText(), textMessage);
        Assert.assertEquals(driver.findElement(errorMsg).getText(), popup);
    }

    /*
    This method to verify the message displayed in the table when search result is empty
     */
    public void noRecordDisplay(String arg1) {
        log.warn("No Records Display message in search result Grid");
        String message = TestUtils.text(driver, tableResult);
        System.out.println(message);
        Assert.assertTrue("Message is not matching", message.equalsIgnoreCase(arg1));
    }


    /**
     * select the Nested ClinicalVariableValues on Traversal Maintenance Page
     *
     * @param variableValue
     */
    public void selectNestedClinicalVariables(String variableValue) {
        log.warn("Select the Nested Variable Value: " + variableValue);
        WebElement el = driver.findElement(multiSelectClinicalVariables);
        el.click();

        if (variableValue.contains(";")) {
            String[] Variablevalue = variableValue.split(";");
            for (String vv : Variablevalue) {
                System.out.println("//span[contains(text(), '" + vv + "')]/../../parent::div");
                driver.findElement(By.xpath("//span[contains(text(),'" + vv + "')]/../../parent::div//label//span[1]/div")).click();
                el.click();

            }
        } else {
            driver.findElement(By.xpath("//span[contains(text(), '" + variableValue + "')]")).click();
            driver.findElement(By.xpath("//span[contains(text(), '" + variableValue + "')]")).click();
            el.click();
        }


    }

    /*

    This method is verify the default values of all the fields when user lands on the
    Traversal Maintenance Screen
     */

    public void searchFilterDefaultValues(List<Map<String, String>> maps) {
        log.warn("Default values when user lands on Traversal Maintenance Screen");
        Map<String, String> map = null;
        for (Map<String, String> m : maps) {
            map = m;
            TestUtils.waitElementVisible(driver, Status);
            String statusValue = driver.findElement(Status).getText();
            Assert.assertTrue("Default value mismatch", map.get("Status").equalsIgnoreCase(statusValue));
            String cancerTypeValue = driver.findElement(cancerType).getText();
            System.out.println(cancerTypeValue);
            Assert.assertTrue("Default value is mismatch", map.get("Cancer Type").equalsIgnoreCase(cancerTypeValue));
            String defaultClinicalVariables = text(driver, multiSelectClinicalVariables);
            Assert.assertTrue("Default value mismatch", map.get("Clinical Variables").equalsIgnoreCase(defaultClinicalVariables));
            String RegimenName = driver.findElement(regimenName).getText();
            Assert.assertTrue("Default value mismatch", map.get("Regimen Name").equalsIgnoreCase(RegimenName));
            String PathwayClient = driver.findElement(pathwayClient).getText();
            Assert.assertTrue("Default value mismatch", map.get("Pathway Client").equalsIgnoreCase(PathwayClient));


        }

    }


    /*
    This method is to very the Import New Traversal Hyperlink present
     */
    public void ImportTraversalHyperlinkPresent() {
        log.warn("Verify the Import New traversal Hyperlink is Present");
        Assert.assertTrue("Import New Traversal Hyperlink is not Present", TestUtils.isElementPresent(driver, By.linkText("Import New Traversal")));
    }


    /*
    Cancer Type dropdown displays all the active Cancer Types available in MBMNOW.
     */

    public void cancerTypeDropdownDisplayAvailableValue() {
        log.warn("verify the Cancer Dropdown displays all available values in MBMNOW");
        TestUtils.waitElement(driver, cancerType);
        TestUtils.wait(2);
        TestUtils.click(driver, cancerType);
        List<WebElement> elements = driver.findElements(By.xpath("//div[@id='traversalSearchTableFilters-diseaseType_errfQQOXvxUsLvuVPSNGe']//following::ul/li"));
        List<String> cancerListUI = new ArrayList<String>();
        for (WebElement e : elements) {
            cancerListUI.add(e.getText());
        }
//        List<String> cancerListUI = TestUtils.getDropdownListOptions(driver, cancerType);
//        cancerListUI.remove("Select");
        Collections.sort(cancerListUI);
        List<Map<String, Object>> cancertype = new RefDao(MyBatisConnectionFactory.getSqlSessionFactory()).refNameDescription("diseaseType");

        ArrayList<String> cancerListDb = new ArrayList<String>(cancertype.size());
        for (int i = 0; i < cancertype.size(); i++) {
            cancerListDb.add((String) cancertype.get(i).get("ref_desc"));
        }
        Collections.sort(cancerListDb);
        Assert.assertEquals(cancerListDb, cancerListUI);

    }

    /*
    This method is to verify the Clinical variable Types are sorted alphabetically and
    is dropdown is multi-Select
     */
    public void clinicalVariableDropdown() {
        log.warn("Click on Clinical Variables Dropdown");
        TestUtils.waitElement(driver, multiSelectClinicalVariables);
        TestUtils.wait(2);
        driver.findElement(multiSelectClinicalVariables).click();
        By elem = By.xpath("//div[contains(@class,'tk-multi-chck-cont')]//label");
        List<WebElement> option = driver.findElements(elem);

        if (text(driver, cancerType).equalsIgnoreCase(" ")) {
            Assert.assertTrue("Clinical Variables Dropdown is not Empty", option.isEmpty());
        } else {
            String s = text(driver, multiSelectClinicalVariables);
            System.out.println(s);
            Assert.assertTrue("clinical variables is not empty", s.equals("Select"));
            String[] variableType = s.split(",");
            System.out.println(variableType);
            List<String> wordList = Arrays.asList(variableType);
            List<String> List1 = wordList;
            Collections.sort(wordList);
            Collections.sort(wordList);
            if (List1.equals(wordList)) {
                Assert.assertTrue("Clinical Variables Type are not sorted alphabetically", List1.equals(wordList));

            }
//            boolean sorted = TestUtils.checkSorting(wordList);
//            Assert.assertTrue("Clinical Variables Type are not sorted alphabetically", sorted);

        }
    }


    /*
      Displays Count of Variables Values Selected in the Clinical Variables Dropdown
     */
    public void countOfVariablesSelected() {
        log.warn("Verifying No.of Variables selected");
        String variablesCount = text(driver, multiSelectClinicalVariables);
        TestUtils.click(driver, multiSelectClinicalVariables);
        int count = 0;
        By elem = By.xpath("//div[contains(@class, 'tk-multi-vert selected')]");
        List<WebElement> option = driver.findElements(elem);
        for (WebElement lst : option) {
            lst.isSelected();
            count++;
        }
        Assert.assertEquals(variablesCount, count + " Selected");
    }


    /*

    This Method is to verify the Variables Values automatically Selected when
    user Selects Clinical variables Type in Clinical variables Dropdown
     */
    public void nestedVariableValuesAutomaticallySelected(String variablesValue) {
        log.warn("Nested Clinical Variables Values are automatically Selected");
        TestUtils.click(driver, multiSelectClinicalVariables);
        if (variablesValue.contains(";")) {
            String[] Variablevalue = variablesValue.split(";");
            for (String vv : Variablevalue) {
                System.out.println("//span[contains(text(), '" + vv + "')]/../input");
                Assert.assertTrue("Nested values are not selected", driver.findElement(By.xpath("//span[contains(text(), '" + vv + "')]/../input")).isSelected());
            }
        }
    }


    /*
    This method is to verify minimizing Dropdown after values selected doesn'tn
    filter the dropdown upon Maximizing
     */
    public void minimizingDropdownNotFilter() {
        log.warn("Minimizing Dropdown doesn't filter the values");
        TestUtils.click(driver, multiSelectClinicalVariables);
        By values = By.xpath("//span[contains(@class, 'tk-multi-label')]");
        TestUtils.wait(5);
        List<WebElement> optionList = driver.findElements(values);
        ArrayList<String> beforeMinimize = new ArrayList<String>(optionList.size());

        for (WebElement list : optionList) {
            beforeMinimize.add(list.getText());
        }
        TestUtils.click(driver, multiSelectClinicalVariables);

        System.out.println(beforeMinimize);
        TestUtils.click(driver, multiSelectClinicalVariables);
        List<WebElement> afterlist = driver.findElements(values);
        ArrayList<String> maximize = new ArrayList<String>(optionList.size());
        for (WebElement list2 : afterlist) {
            maximize.add(list2.getText());
        }
        System.out.println(maximize);
        Assert.assertTrue("Minimizing dropdown is filtering the value", beforeMinimize.equals(maximize));
    }

    /*
      In this method user Enter Builder ID and Template ID on the
    Import New Traversal Screen and clicks on Preview Button
     */

    public void enterBuilderIdandTemplateId(String builderId, String templateId) {
        log.warn("Enter Builder ID and Template ID on the Import New Traversal Screen");
        TestUtils.waitElementVisible(driver, builderID);
        TestUtils.input(driver, builderID, builderId);
        TestUtils.waitElementVisible(driver, templateID);
        TestUtils.input(driver, templateID, templateId);
        CommonPage cp = new CommonPage(driver);
        cp.userClicksAButton("Preview Assessment");
    }

    /*
    This method is to verify the assessment section is not visible when user clicks on clear button

     */

    public void traversalAreaAfterClear(String expectedHeader) {
        log.warn("Assessment Details section not displayed when user clicks on Clear Button");
        Assert.assertTrue("Builder Id is cleared", text(driver, builderID).isEmpty());
        Assert.assertTrue("Builder Id is cleared", text(driver, templateID).isEmpty());
        boolean Notdisplayed = true;
        List<WebElement> dynamicElement = driver.findElements(By.xpath("//h3[contains(.,'" + expectedHeader + "')]"));
        if (dynamicElement.size() != 0)
            Assert.fail("Assessment Details section visible even after Clear");
        else
            System.out.println("Assessment Details Section not visible");
    }

    /*
      This method is to verify the search result displays Clinical Description as per search filter
      variable values selected
     */
    public void traversalPopulatesvariablesSelected() {
        log.warn("Display search Result of Traversals which has Clinical variables selected");
        List<Map<String, String>> traversalActionResults = tableAsMaps(driver, "//table[@id='diseaseNewTraversalMaintenanceTableID']", 10);
        System.out.println(traversalActionResults);
        String traversalId = traversalActionResults.get(0).get("ID");
        String Description = driver.findElement(By.xpath("//td[.='" + traversalId + "']/following-sibling::td[2]/span")).getText();
        String[] clinicalvariablespair = Description.split(";");
        ArrayList<String> clinical_description = new ArrayList<>(clinicalvariablespair.length);
        for (int i = 0; i < clinicalvariablespair.length; i++) {
            String[] clinical_variables = clinicalvariablespair[i].split("__");
            clinical_description.add(clinical_variables[1]);
        }
        System.out.println(clinical_description);
        TestUtils.click(driver, multiSelectClinicalVariables);
        By selectedValue = By.xpath("//div[contains(@class, 'tk-multi-vert selected')]//label/span[2]");
        List<WebElement> selectedValues = driver.findElements(selectedValue);
        ArrayList<String> clinicalSelected = new ArrayList<String>(selectedValues.size());
        for (WebElement value : selectedValues) {
            clinicalSelected.add(value.getText());
        }
        Assert.assertEquals(clinical_description, clinicalSelected);
    }

}

