package atdd.test.pageobjects.utilizationManagement;

import atdd.common.ICondition;
import atdd.common.Retry;
import atdd.utils.StringUtils;
import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class AddAssignmentPage {

    public static final String pageTitleAddAssignmentXpath = "//*[.='Add Assignment' and contains(@class, 'pageTitle')]";
    public static final String pageTitleEditAssignmentXpath = "//*[.='Edit Assignment' and contains(@class, 'pageTitle')]";
    public static final String pageTitleViewAssignmentXpath = "//*[.='View Assignment' and contains(@class, 'pageTitle')]";
    public static final String addEditAssignmentFormXpath = "//form[@name='addEditAssignmentForm']";
    public static final String addEditAssignmentPanelTableXpath = addEditAssignmentFormXpath + "//table[@class='panelTable']";

    public static By cancelButton = By.xpath(addEditAssignmentFormXpath + "/..//input[@value='Cancel']");
    public static By addAssignmentButton = By.xpath("//input[@value='Add Assignment']");
    public static By saveAssignmentButton = By.xpath("//input[@value='Save Assignment']");

    public static By editAssignmentLink = By.xpath("//a[.='Edit Assignment']");

    public static String assignmentTypeDropdownListXpath = "//select[@ref-nm='itemTaskType']";
    public static By assignmentTypeDropdownList = By.xpath(assignmentTypeDropdownListXpath);
    public static String descriptorDropdownListXpath = "//select[@ref-nm='descriptionId']";
    public static By descriptorDropdownList = By.xpath(descriptorDropdownListXpath);
    public static By statusDropdownList = By.xpath("//select[@ref-nm='itemTaskStatus']");
    public static By statusReadonly = By.xpath(addEditAssignmentPanelTableXpath + "//td[contains(., 'Status')]/following-sibling::td[1]");
    public static By outcomeDropdownList = By.xpath("//select[@ref-nm='outcomeId']");
    public static By priorityDropdownList = By.xpath("//select[@ref-nm='itemTaskPriority']");
    public static By assignedToMeRadioButton = By.xpath("//input[@value='myUserValue']");
    public static By assignedToUserRadioButton = By.xpath("//input[@value='userValue']");
    public static By assignedToQueueRadioButton = By.xpath("//input[@value='queueValue']");
    public static By assignedToUserTypeAhead = By.xpath("//*[(name()='ocm:typeahead' or name()='ocm-typeahead') and @id='userSelect']");
    public static String assignedToUserTextBoxXpath = "//input[@name='Owner']";
    public static By assignedToUserTextBox = By.xpath(assignedToUserTextBoxXpath);
    public static By assignedToUserDropdown = By.xpath("//input[@ng-model='assignmentRecord.owner']/following-sibling::ul");
    public static By assignedToQueueTypeAhead = By.xpath("//*[(name()='ocm:typeahead' or name()='ocm-typeahead') and @id='queueSelect']");
    public static String assignedToQueueTextBoxXpath = "//input[@name='Work Queue Id']";
    public static By assignedToQueueTextBox = By.xpath(assignedToQueueTextBoxXpath);
    public static By dueDateTextBox = By.xpath("//input[@name='Due Date']");
    public static By dueTimeTextBox = By.xpath("//input[@name='Due Time']");
    public static By dueTimeAMRadioBox = By.xpath("//input[@value='AM']");
    public static By dueTimePMRadioBox = By.xpath("//input[@value='PM']");
    public static By assignmentCommentsTextBox = By.xpath("//input[@id='assignmentCommentsText']");
    public static String assignmentsTableXpath = "//table[@id='assignmentsMaintenanceTableID']";

    private static Logger log = Logger.getLogger(AddAssignmentPage.class);
    private WebDriver driver;

    /*Page Constructor*/
    public AddAssignmentPage(WebDriver driver) {
        this.driver = driver;
    }

    public boolean clickCancel() {
        return TestUtils.clickUntil(driver, cancelButton, new ICondition() {
            @Override
            public boolean evaluate() throws Exception {
                return !TestUtils.isElementVisible(driver, cancelButton);
            }
        });
    }

    public boolean clickAddAssignment() {
        return TestUtils.clickUntil(driver, addAssignmentButton, new ICondition() {
            @Override
            public boolean evaluate() throws Exception {
                return !TestUtils.isElementVisible(driver, addAssignmentButton);
            }
        });

    }

    public boolean clickSaveAssignment() {
        return TestUtils.clickUntil(driver, saveAssignmentButton, new ICondition() {
            @Override
            public boolean evaluate() throws Exception {
                return !TestUtils.isElementVisible(driver, saveAssignmentButton);
            }
        });
    }

    public void selectAssignmentType(Map<String, String> map) {
        String value = map.get("Assignment Type");
        if (!StringUtils.isEmpty(value)) {
            String note = "selectAssignmentType: " + value;
            boolean success = new Retry(note) {
                @Override
                protected void tryOnce() throws Exception {
                    TestUtils.input(driver, assignmentTypeDropdownList, value);
                }

                @Override
                protected boolean until() throws Exception {
                    WebElement el = driver.findElement(By.xpath(assignmentTypeDropdownListXpath));
                    return value.equals(TestUtils.simpleContent(el));
                }
            }.execute();
            if (!success) {
                throw new RuntimeException("Failed: " + note);
            }
            TestUtils.wait(1);
        }
    }

    public void selectDescriptor(Map<String, String> map) {
        String value = map.get("Assignment Descriptor");
        if (!StringUtils.isEmpty(value)) {
            String note = "selectDescriptor: " + value;
            boolean success = new Retry(note) {
                @Override
                protected void tryOnce() throws Exception {
                    TestUtils.select(driver, descriptorDropdownList, value);
                }

                @Override
                protected boolean until() throws Exception {
                    WebElement el = driver.findElement(By.xpath(descriptorDropdownListXpath));
                    return value.equals(TestUtils.simpleContent(el));
                }
            }.execute();
            if (!success) {
                throw new RuntimeException("Failed: " + note);
            }
        }
    }

    public void selectPriority(Map<String, String> map) {
        String value = map.get("Priority");
        if (!StringUtils.isEmpty(value)) {
            TestUtils.select(driver, priorityDropdownList, value);
        }
    }

    public void inputAssignedTo(Map<String, String> map) {
        String value = map.get("Assigned To");
        TestUtils.wait(1);
        if (!StringUtils.isEmpty(value)) {
            String[] p = value.split(":", 2);
            switch (p[0]) {
                case "Me":
                    TestUtils.safeClick(driver, assignedToMeRadioButton);
                    break;
                case "Another User":
                    TestUtils.click(driver, assignedToUserRadioButton);
                    TestUtils.waitElementVisible(driver, assignedToUserTextBoxXpath);
                    TestUtils.input(driver, assignedToUserTextBox, p[1]);
                    TestUtils.waitElementVisible(driver, "//a[.='" + p[1] + "']");
                    TestUtils.safeClick(driver, By.xpath("//a[.='" + p[1] + "']"));
                    break;
                case "Queue":
                    TestUtils.click(driver, assignedToQueueRadioButton);
                    TestUtils.waitElementVisible(driver, assignedToQueueTextBoxXpath);
                    TestUtils.input(driver, assignedToQueueTextBox, p[1]);
                    TestUtils.waitElementVisible(driver, "//a[.='" + p[1] + "']");
                    TestUtils.safeClick(driver, By.xpath("//a[.='" + p[1] + "']"));
                    break;
                default:
                    Assert.fail("Unknown Assigned To: " + p[0]);
            }
        }
    }

    public void typeDueDate(Map<String, String> map) {
        String value = map.get("Due Date");
        if (!StringUtils.isEmpty(value)) {
            if (value.contains(" ")) {
                String[] p = value.split(" ");
                Assert.assertEquals(3, p.length);
                TestUtils.input(driver, dueDateTextBox, p[0]);
                TestUtils.input(driver, dueTimeTextBox, p[1]);
                switch (p[2].toUpperCase()) {
                    case "AM":
                        TestUtils.click(driver, dueTimeAMRadioBox);
                        break;
                    case "PM":
                        TestUtils.click(driver, dueTimePMRadioBox);
                        break;
                    default:
                        Assert.fail("Unknown option: " + p[2]);
                }
            } else {
                TestUtils.input(driver, dueDateTextBox, value);
            }
        }
    }

    public void typeComments(Map<String, String> map) {
        String value = map.get("Assignment Comments");
        if (!StringUtils.isEmpty(value)) {
            TestUtils.input(driver, assignmentCommentsTextBox, value);
        }
    }

    public void selectStatus(Map<String, String> map) {
        String value = map.get("Status");
        if (!StringUtils.isEmpty(value)) {
            this.selectStatus(value);
        }
    }

    public void selectOutcome(Map<String, String> map) {
        String value = map.get("Outcome");
        if (!StringUtils.isEmpty(value)) {
            this.selectOutcome(value);
        }
    }

    public boolean clickEditAssignmentLink() {
        return TestUtils.clickUntil(driver, editAssignmentLink, new ICondition() {
            @Override
            public boolean evaluate() throws Exception {
                return TestUtils.isElementVisible(driver, pageTitleEditAssignmentXpath);
            }
        });
    }

    public void selectOutcome(String outcome) {
        TestUtils.select(driver, outcomeDropdownList, outcome);
        TestUtils.wait(1);

    }

    public void selectStatus(String status) {
        TestUtils.select(driver, statusDropdownList, status);
        TestUtils.wait(2);
    }

    public void validateListofAssignmentType() {
        List<String> expectedAssignmentTypes = new ArrayList<String>();
        Collections.addAll(expectedAssignmentTypes,"Denial Letter", "Initiate Letter", "MD Review", "Pharmacist Review", "Request Missing Information", "Requested Info From Acct Mgmt Team", "Review Case","Schedule P2P");
        List<String> assignmentTypeActual = new ArrayList<String>();
        By assignmentTypeDropdwnXpath=By.xpath("//select[@ng-model='assignmentRecord.typeId']");
        TestUtils.click(driver,assignmentTypeDropdwnXpath);
        TestUtils.wait(2);
        List<WebElement>  assignmentTypes = driver.findElements(By.xpath("//option[@ng-repeat='option in itemTaskTypeLIST']"));
        assignmentTypes.forEach(i-> assignmentTypeActual.add(i.getText().trim()));
        log.warn(assignmentTypeActual);
        log.warn(expectedAssignmentTypes);
        Assert.assertEquals("All Assignment Types are displayed", expectedAssignmentTypes,assignmentTypeActual);
    }

    public void enterDueDate(String duedate){
        log.warn("Enter the Duedate: " + duedate);
        TestUtils.input(driver, dueDateTextBox, duedate);
    }

    public void validateOutcomeValues(){
        List<String> expectedOutcomeValues = new ArrayList<String>();
        Collections.addAll(expectedOutcomeValues,"Peer to Peer Scheduling Unsuccessful", "Scheduled Peer to Peer", "Warm Transferred to MD");
        List<String> OutcomeValueActual = new ArrayList<String>();
        By outcomeDropdwnXpath=By.xpath("//select[@ng-model='assignmentRecord.outcomeId']");
        TestUtils.click(driver,outcomeDropdwnXpath);
        TestUtils.wait(3);
        List<WebElement> outcomeValue = driver.findElements(By.xpath("//option[@ng-repeat='option in itemTaskOutcomeLIST']"));
        outcomeValue.forEach(i-> OutcomeValueActual.add(i.getText().trim()));
        log.warn(OutcomeValueActual);
        log.warn(expectedOutcomeValues);
        Assert.assertEquals("All outcome field values are displayed", expectedOutcomeValues,OutcomeValueActual);
    }

    public boolean isEditIconDisplayed(String rownum){
        log.warn("Clicking on Edit Assignment icon");
        By editIconXpath= By.xpath("//tr[@ng-if='assignmentsMaintenanceTable.records.length != 0']["+rownum+"]//span[@ng-click='assignmentsMaintenanceTable.editRecord(record)']");
        Assert.assertTrue(!(TestUtils.isElementVisible(driver,editIconXpath)));
        return true;
    }
}
