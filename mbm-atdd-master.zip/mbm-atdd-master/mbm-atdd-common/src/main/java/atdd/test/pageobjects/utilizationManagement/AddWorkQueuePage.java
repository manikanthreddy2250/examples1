package atdd.test.pageobjects.utilizationManagement;

import atdd.common.ICondition;
import atdd.utils.StringUtils;
import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.ArrayList;
import java.util.List;

public class AddWorkQueuePage {

    private static Logger log = Logger.getLogger(AddWorkQueuePage.class);
    private WebDriver driver;

    //public static for all locators
    public static By name = By.id("workQueueName");
    public static By description = By.id("workQueueDescription");
    public static By status = By.id("workQueueStatus");
    public static By saveButton = By.xpath("//input[@class='open ng-scope tk-btn']");
    public static By cancelButton = By.xpath("//input[@class='close tk-btn-tertiary tk-btn']");
    public static By popUpHeader = By.xpath("(//*[text()='Add Work Queue'])[2]");
    public static By nameErrorMessage = By.id("record-name_err");
    public static By descriptionErrorMessage = By.id("record-description_err");


    public AddWorkQueuePage(WebDriver driver) {
        this.driver = driver;
    }

    /*
     * This method adds a work queue
     * @param name, description, status
     * */
    public void enterDetailsToAddWorkQueue(String name, String description, String status) {
        if (!StringUtils.isEmpty(name)) TestUtils.input(driver, AddWorkQueuePage.name, name);
        if (!StringUtils.isEmpty(description)) TestUtils.input(driver, AddWorkQueuePage.description, description);
        if (!StringUtils.isEmpty(status)) TestUtils.input(driver, AddWorkQueuePage.status, status);
    }

    /*
     * This method validates add work queue popup
     * */

    public void validatePopUpContent() {
        log.warn("valdiating elements on popup");
        Assert.assertTrue("Header is not displayed", driver.findElement(popUpHeader).isDisplayed());
        Assert.assertTrue("Cancel Button is not displayed", driver.findElement(cancelButton).isDisplayed());
        Assert.assertTrue("Save Button is not displayed", driver.findElement(saveButton).isDisplayed());
    }

    /*
     * get the attributes of name, description and status
     * return attributeValues
     * */
    public List getAttributesWorkQueue() {
        log.warn("Getting the value from Edit Work Queue Modal");
        List<String> attributeValues = new ArrayList<>();
        attributeValues.add(driver.findElement(name).getAttribute("value"));
        attributeValues.add(driver.findElement(description).getAttribute("value"));
        attributeValues.add(TestUtils.getSelectedValueFromDropdown(driver, status));
        return attributeValues;
    }

    /*
     * This method clears the text fields and
     * new input fields are entered
     * @param editDetails
     * */
    public void editWorkQueue(List<String> editDetails) {
        log.warn("Clear and enter the work queue details");
        //get the the details to be added
        String name = editDetails.get(0);
        String description = editDetails.get(1);
        String status = editDetails.get(2);
        //clear the text box
        driver.findElement(AddWorkQueuePage.name).clear();
        driver.findElement(AddWorkQueuePage.description).clear();
        //enter the work queue details
        driver.findElement(AddWorkQueuePage.name).sendKeys(name);
        driver.findElement(AddWorkQueuePage.description).sendKeys(description);
        TestUtils.select(driver, AddWorkQueuePage.status, status);
        //save the added details
        TestUtils.click(driver, saveButton);
    }

    /*
     * This method validates error message for
     * any required field left blank
     * @param errorMessage*/
    public void validateErrorMessage(String errorMessage) {
        //click on save button and validate the error message
        driver.findElement(description).clear();
        driver.findElement(saveButton).click();
        TestUtils.wait(3);

        Assert.assertEquals(errorMessage, driver.findElement(nameErrorMessage).getText());
        Assert.assertEquals(errorMessage, driver.findElement(descriptionErrorMessage).getText());
    }

    /*
     * Close the workqueue
     * */
    public void closeAddWorkQueueModal() {
        //check if add work queue is visible
        if (driver.findElement(popUpHeader).isDisplayed()) {
            //close add work queue
            driver.findElement(cancelButton).click();
        }
    }

    /*
     * Clear all field in edit work queue
     * */
    public void clearEditWorkQueue() {
        //clear the edit work queue
        driver.findElement(name).clear();
        driver.findElement(description).clear();
    }

    public void clickSaveButton() {
        //save the added details
        TestUtils.clickUntil(driver, saveButton, new ICondition() {
            @Override
            public boolean evaluate() throws Exception {
                return !TestUtils.isElementVisible(driver, saveButton);
            }
        });
        TestUtils.waitForAngularRequestsToFinish(driver);
    }
}
