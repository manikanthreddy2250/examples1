package atdd.test.pageobjects.utilizationManagement;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class BulkAssignPopupPage {

    public static final String bulkAssignFormXpath = "//form[@name='bulkAssignPopupModelForm']";

    public static final By assignedToMeRadioButtonPopup = By.xpath(bulkAssignFormXpath + "//input[@value='myUserValue']");

    public static final By assignedToAnotherUserRadioButtonPopup = By.xpath(bulkAssignFormXpath + "//input[@value='userValue']");
    public static final String assignedToAnotherUserTypeAheadXpath = bulkAssignFormXpath + "//*[(name()='ocm:typeahead' or name()='ocm-typeahead') and @id='userBulkSelect']";
    public static final By assignedToAnotherUserInputBoxPopup = By.xpath(assignedToAnotherUserTypeAheadXpath + "/input");
    public static final By assignedToAnotherUserPopupDropdown = By.xpath(assignedToAnotherUserTypeAheadXpath + "/ul");

    public static final By assignedToQueueRadioButtonPopup = By.xpath(bulkAssignFormXpath + "//input[@value='queueValue']");
    public static final String assignedToQueueTypeAheadXpath = bulkAssignFormXpath + "//*[(name()='ocm:typeahead' or name()='ocm-typeahead') and @id='queueBulkSelect']";
    public static final By assignedToQueueInputBoxPopup = By.xpath(assignedToQueueTypeAheadXpath + "/input");
    public static final By assignedToQueuePopupDropdown = By.xpath(assignedToQueueTypeAheadXpath + "/ul");

    public static final By assignButton = By.xpath(bulkAssignFormXpath + "//input[@value='Assign']");
    public static final By cancelButton = By.xpath(bulkAssignFormXpath + "//input[@value='Cancel']");

    private static Logger log = Logger.getLogger(BulkAssignPopupPage.class);
    private WebDriver driver;

    /*Page Constructor*/
    public BulkAssignPopupPage(WebDriver driver) {
        this.driver = driver;
    }

}
