package atdd.test.pageobjects.utilizationManagement;


import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import static org.hamcrest.CoreMatchers.containsString;

public class CaseSummaryNotesSection {

    public static final By notesDisplayArea = By.className("noteDisplayArea");
    public static final By newNoteButton = By.className("newNoteButton");
    public static final By notesArea =  By.id("notesArea");
    public static final By noteSectionPanel = By.xpath("//*[@id='notesSectionPanelIdContent']/div/div[1]/div[2]");
    public static final By notesSectionPanelIdContent = By.xpath("//*[@id='notesSectionPanelIdContent']/div/div[1]/div[2]");
    public static final By timeStampTable = By.className("noteTimestampTable");
    public static final By noteUserTable = By.className("noteUserTable");
    public static final By noteCell = By.className("noteCell");
    public static final By sucessPopup =  By.id("globalMessages-description");
    public static final By popupContinue =  By.xpath("//*[@id='navigationWarningBackButtonPopupModelID']/div[2]/div/form/div/div[2]/input[1]");
    public static final By popupXbutton =  By.xpath("//*[@id='navigationWarningBackButtonPopupModelID']/div[2]/div/div[1]/div[2]/button/span[1]");
    public static final By popupCancelButton = By.xpath("//*[@id='navigationWarningBackButtonPopupModelID']/div[2]/div/form/div/div[2]/input[2]");
    public static final By popupWarningMessage = By.id("backWarningTextDiv");
    public static final By notesSaveButton = By.id("notesSaveButton");
    public static final By notesCancelButton = By.id("notesCancelButton");


    private static Logger log = Logger.getLogger(CaseSummaryNotesSection.class);
    private WebDriver driver;

    /*Page Constructor*/
    public CaseSummaryNotesSection(WebDriver driver) {
        this.driver = driver;
    }


    /**
     * Verifies note is not editable
     */
    public void userNotAbletoEditNote() {
        if (!TestUtils.isClickable(driver, noteSectionPanel)) {
            System.out.println("Cannot be Edited");
        }
    }

    /**
     * Verifies note cannot be deleted
     */
    public void userNotAbletoDeleteNote() {
        if (!TestUtils.isClickable(driver, notesSectionPanelIdContent)) {
            System.out.println("Cannot be Deleted");
        }
    }

    /**
     * Get's and verifies timestamp
     *
     * @param authorName --User name expected on the timestamp
     */
    public void authorAndDateTimetoNote(String authorName) {
        TestUtils.isElementVisible(driver, timeStampTable);
        org.junit.Assert.assertThat(driver.findElement(noteUserTable).getText(), containsString(authorName));
        TestUtils.isElementVisible(driver, noteUserTable);
        TestUtils.wait(2);
    }

    /**
     * Checks is existing note is visible
     */
    public void existingNoteVisible() {
        TestUtils.isElementVisible(driver, notesDisplayArea);
        TestUtils.wait(2);
    }

    /**
     *  Clicks on existing note
     */
    public void clickOnExistingNote() {
        TestUtils.click(driver, noteCell);
        TestUtils.wait(2);
    }

    /**
     * Checks to see if note area is visible
     */
    public void notesAreaVisible() {
        TestUtils.isElementVisible(driver, notesArea);
        TestUtils.wait(2);
    }

    /**
     * Clicks new note button
     */
    public void userClicksOnNewNote() {
        TestUtils.click(driver, newNoteButton);
        TestUtils.wait(2);
    }

    /**
     * checks to see if note text area is empty
     */
    public void textInNoteAreaIsEmpty() {

        String t = TestUtils.text(driver, notesArea);
        try {
            if (t.isEmpty()) {
                System.out.println("NotesArea is Empty");
            } else {
                System.out.println("NotesArea is not Empty");
            }
        } catch (Exception NoSuchElementException) {

        }
    }

    /**
     * Checks and returns boolean state of note area
     * @return
     */
    public Boolean getStateOfNoteArea(){

        return TestUtils.isElementVisible(driver,notesArea);

    }

    /**
     * Checks to see if note area is still displayed
     */
    public void textInNoteAreaStillDisplayed() {
        String t = TestUtils.text(driver, notesArea);
        if (t == "XXXX") {
            System.out.println("NotesArea text is still diplayed");
        } else {
            System.out.println("NotesArea text is not diplayed");
        }

    }

    /**
     * Checks for success popup message after note is saved
     */
    public void successPopUpDisplayed() {
        TestUtils.isElementVisible(driver, sucessPopup);
        TestUtils.wait(2);
    }

    /**
     * Clicks the X button of the cancel popup
     */
    public void clickXbuttonTopRightCancelPopUp() {
        TestUtils.click(driver, popupXbutton);
        TestUtils.wait(2);
    }

    /**
     * Clicks continue button of the cancel popup
     */
    public void clickContinuebuttonCancelPopUp() {
        TestUtils.click(driver, popupContinue);
        TestUtils.wait(2);
    }

    /**
     * Clicks the cancel button of the cancel popup
     */
    public void clickCancelbuttonCancelPopUp() {
        TestUtils.click(driver, popupCancelButton);
        TestUtils.wait(2);
    }

    /**
     * Checks to see if the cancel popup is displayed
     */
    public void cancelPopUpDisplayed() {
        TestUtils.isElementVisible(driver, popupWarningMessage);
        TestUtils.wait(2);
    }

    /**
     * Types Sample Text in note area
     */
    public void typeNotesArea() {
        TestUtils.input(driver, notesArea, "Sample text");
        TestUtils.wait(2);
    }

    /**
     * Types noteComment into text area
     *
     * @param noteComment -- Variable that holds the note comment user wishes to add
     */
    public void addDetailToNote(String noteComment) {
        TestUtils.input(driver, notesArea, noteComment);
        TestUtils.wait(2);
    }

    /**
     * Clicks save button for notes
     */
    public void selectSaveButton() {
        TestUtils.isClickable(driver, notesSaveButton);
    }

    /**
     * Clicks cancel button for notes
     */
    public void selectCancelButton() {
        TestUtils.isClickable(driver, notesCancelButton);
    }

    /**
     * Clicks cancel button
     */
    public void clickCancelButton() {
        TestUtils.waitElementVisible(driver, notesCancelButton);
        TestUtils.waitElementClickable(driver, notesCancelButton);
        TestUtils.click(driver, notesCancelButton);
    }

    /**
     * Clicks Save button
     */
    public void clickSaveButton() {
        TestUtils.click(driver, notesSaveButton);
        TestUtils.wait(3);
    }


}

