package atdd.test.pageobjects.utilizationManagement;

import atdd.common.ImmediateAbortException;
import atdd.common.ScenarioLogger;
import atdd.test.pageobjects.CommonPageObject;
import atdd.utils.TestUtils;
import atdd.utils.WhiteBoard;
import cucumber.api.Scenario;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import java.util.List;
import atdd.utils.*;
import org.openqa.selenium.support.ui.Select;

public class FaxSection {

    public static final By clicksendfax = By.xpath("//input[@type='button' and @value='Send Fax']");
    public static final By faxconfpopupyes = By.xpath("//*[@id=\"confirmFaxCheckbox\"]");
    //*[@id="sendFaxPopupModelID"]/div[2]/div/form/div/div[2]/input[1]
    public static final By faxconfpopupsave = By.xpath("//input[@type='submit' and @value='Save']");
    public static final By faxhistory = By.xpath("//a[@ng-if=\"communicationType == 'Fax'\"]");
    public static final By faxinformationpopup = By.xpath("//form[@name='editProviderDetailsPopupModelForm'");

    public static String clickFaxbuttoninCommunicationsection = "//input[@name='communicationType' and @value='Fax']";
    public static String selectRequestingProvideronSendFaxTo = "//*[@id=\"sendFaxToID\"]/tbody/tr[2]/td[1]/input";
    public static String selectServicingProvideronSendFaxTo = "//*[@id=\"sendFaxToID\"]/tbody/tr[1]/td[1]/input";
    public static String sendFaxTotableXpath = "//table[@id='sendFaxToID']";
    public static String clinicalcontactname = "//*[@id=\"memberDemo-assignedToName-0\"]";
    public static String clinicalcontactfaxnumber = "//*[@id=\"faxNumberInput\"]";
    public static String clinicalcontactphonenumber = "//*[@id=\"phone\"]";

    public static String faxinformationpopupproviderfax = "//form[@name=\"editProviderDetailsPopupModelForm\"]/div/div[1]/div[2]/table/tbody/tr[1]/td[2]/input";
//    /html/body/div[2]/div[1]/div[18]/div[2]/uitk-panel/div/div[2]/div/div/div[5]/div[2]/div/form/div/div[1]/div[2]/table/tbody/tr[1]/td[2]/input
    public static String faxinformationpopupsendfaxnumber = "//form[@name=\"editProviderDetailsPopupModelForm\"]/div/div[1]/div[2]/table/tbody/tr[2]/td[2]/input";
//    /html/body/div[2]/div[1]/div[18]/div[2]/uitk-panel/div/div[2]/div/div/div[5]/div[2]/div/form/div/div[1]/div[2]/table/tbody/tr[2]/td[2]/input
    public static String faxinformationpopupattention = "//form[@name=\"editProviderDetailsPopupModelForm\"]/div/div[1]/div[2]/table/tbody/tr[3]/td[2]/input";
//    /html/body/div[2]/div[1]/div[18]/div[2]/uitk-panel/div/div[2]/div/div/div[5]/div[2]/div/form/div/div[1]/div[2]/table/tbody/tr[3]/td[2]/input
    public static String faxinformationpopupsave = "//input[@ng-click='editProviderFaxDetailsTo()']";

    public String actualRequestnumber;
    private static Logger log = Logger.getLogger(FaxSection.class);
    private WebDriver driver;
    private Scenario scenario;
    private ScenarioLogger scenarioLogger = null;
    private String owner;

    /*Page Constructor*/
    public FaxSection(WebDriver driver) {
        this.driver = driver;
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return driver;
    }


    public void selectcheckboxonfaxpage(String locatorString) throws Throwable {
        Assert.assertFalse(StringUtils.isEmpty(locatorString));
        By locatorxpath = By.xpath(locatorString);
        WebDriver d = driver();

        boolean selected = driver.findElement(locatorxpath).isSelected();
        if (!selected)
            driver.findElement(locatorxpath).click();
        TestUtils.wait(2);


    }


    public void captureauthnumberandnavigatetoauthsummary() throws Throwable {

        actualRequestnumber =   obj().RequestStatusPage.getAuthorizationNumber();
        log.warn("Submitted Auth number is "+actualRequestnumber);
        WhiteBoard.getInstance().putString(owner, "requestNumber", actualRequestnumber);
        scenarioLogger.warn("New string added for " + owner + ": " + "requestNumber" + "=" + actualRequestnumber);
        obj().NavigationPage.navigatesToMenuItem("Home>Authorization>Search");
        obj().PriorAuthorizationSearchSubmittedPage.enterRequestNumber(actualRequestnumber);
//        obj().PriorAuthorizationSearchSubmittedPage.enterRequestNumber("SC001216043");
        obj().PriorAuthorizationSearchSubmittedPage.clickSearchSubmitted();
        obj().CommonPage.waitForNOTBusyIndicator();
        obj().PriorAuthorizationSearchSubmittedPage.clickFirstRecordInPriorAuthSearch("SUBMITTED");
    }

    public void navigatetoFaxsection() throws Throwable {
        String locatorString = WhiteBoard.resolve(owner, clickFaxbuttoninCommunicationsection);
        selectcheckboxonfaxpage(locatorString);

    }

    public void sendFaxTotable (Scenario scenario, String prefix, String keyHeader) throws Throwable {
        TestUtils.extractGridToWhiteBoard(driver(), scenario, prefix, keyHeader, sendFaxTotableXpath, false, false);
        TestUtils.demoBreakPoint(scenario, driver(), sendFaxTotableXpath + " is extracted with prefix " + prefix + " and key header " + keyHeader);
    }

    public void selectinSendFaxToTable(String provider) throws Throwable {
        String locatorString = null;
        if (provider.equals("Requesting")) {
            locatorString = WhiteBoard.resolve(owner, selectRequestingProvideronSendFaxTo);
        } else if (provider.equals("Servicing")) {
            locatorString = WhiteBoard.resolve(owner, selectServicingProvideronSendFaxTo);
        }
        selectcheckboxonfaxpage(locatorString);
        TestUtils.wait(2);

       // if(TestUtils.isElementVisible(driver, faxinformationpopup)) {
        try {
            TestUtils.wait(2);
            driver.findElement(By.xpath(faxinformationpopupproviderfax)).sendKeys("5555555555");
            driver.findElement(By.xpath(faxinformationpopupsendfaxnumber)).sendKeys("5555555555");
            driver.findElement(By.xpath(faxinformationpopupattention)).clear();
            driver.findElement(By.xpath(faxinformationpopupattention)).sendKeys("Automation Test");
            TestUtils.wait(2);
            driver.findElement(By.xpath(faxinformationpopupsave)).click();
            TestUtils.wait(5);

        } catch (Exception e) {
            // Do Nothing
        }
    }

    public void fillClinicalContactInfo(String faxType) throws Throwable {



        driver.findElement(By.xpath(clinicalcontactname)).clear();
        driver.findElement(By.xpath(clinicalcontactname)).sendKeys("Automation Test");
        driver.findElement(By.xpath(clinicalcontactfaxnumber)).sendKeys("5555555555");
        driver.findElement(By.xpath(clinicalcontactphonenumber)).sendKeys("5555555555");


        By faxtypedropdown = By.xpath("//select[@ng-model='selectedFaxType']");
        TestUtils.select(new Select(driver.findElement(faxtypedropdown)), faxType);
//        TestUtils.click(driver,faxtype);
//        TestUtils.wait(1);
//        By faxTypeValueXpath = By.xpath("//*[@id=\"memberInformationSection\"]/table[2]/tbody/tr[1]/td[2]/select/option[2]");
//                "" +
//                "//select[@ref-nm='letterType']//option[text()='"+letterType+"']");
//        TestUtils.click(driver,faxTypeValueXpath);
//        TestUtils.wait(1);
//        TestUtils.click(driver, By.xpath("//*[@id=\"letterInformationSection\"]/table[2]/tbody/tr/td[1]/span/label"));
//
//        if (letterType.equals("Lack of Information")) {
//            int size = driver.findElements(By.tagName("iframe")).size();
//            for(int i=0; i<size; i++)
//                driver.switchTo().frame(i);
//            //driver.switchTo().frame("Rich Text Editor, editor1");
//            driver.findElement(By.tagName("body")).sendKeys("Test text using body");
//            //TestUtils.input(driver, By.xpath("/html/body"), "Test text");
//            driver.switchTo().defaultContent();
//        }
    }

    public void sendFax() throws Throwable {
        TestUtils.click(driver, clicksendfax);
        TestUtils.wait(3);
        if (TestUtils.isClickable(driver, faxconfpopupsave)) {
            TestUtils.click(driver, faxconfpopupsave);
        } else {
            TestUtils.click(driver, faxconfpopupyes);
            TestUtils.click(driver, faxconfpopupsave);
        }
        TestUtils.wait(20);
    }

    public void openFaxHistory() throws Throwable {
        TestUtils.click(driver, faxhistory);
        TestUtils.wait(2);
    }

    public void validatefaxrow(String template, String recipient, String sentto) throws Throwable{
        // table id = letterHistoryID
        //thead xpath = //*[@id="letterHistoryID"]/thead
        WebElement simpleTable = driver.findElement(By.id("faxHistoryID"));

        //Get all rows
        List<WebElement> rows = simpleTable.findElements(By.tagName("tr"));

        int rowcount = 0;
        //Traverse data from each row
        for (WebElement row : rows) {
            int count = 0;
            List<WebElement> cols = row.findElements(By.tagName("td"));
            for (WebElement col : cols) {
                System.out.print(col.getText() + "\t");
                if (rowcount == 1 && count == 1)
                    if (!col.getText().equals(template)) {
                        throw new ImmediateAbortException("Fax Template is wrong");
                    }
                if (rowcount == 1 && count == 2)
                    if (!col.getText().equals(recipient)){
                        throw new ImmediateAbortException("Fax Recipient is wrong");
                    }
                if (rowcount == 1 && count == 3)
                    if (!col.getText().equals(sentto)) {
                        throw new ImmediateAbortException("Fax Sent address is wrong");
                    }
                count++;
            }
            rowcount++;
        }
    }
}