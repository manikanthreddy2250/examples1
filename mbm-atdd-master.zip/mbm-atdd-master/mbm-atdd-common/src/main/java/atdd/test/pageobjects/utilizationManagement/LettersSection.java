package atdd.test.pageobjects.utilizationManagement;

import atdd.common.ImmediateAbortException;
import atdd.common.ScenarioLogger;
import atdd.test.pageobjects.CommonPageObject;
import atdd.utils.TestUtils;
import atdd.utils.WhiteBoard;
import cucumber.api.Scenario;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import java.util.List;
import atdd.utils.*;


public class LettersSection {

    public static final String workQueueSearchFormXpath = "//form[@name='workQueueSearchForm']";
    public static final By clickcreateletter = By.xpath("//*[@id=\"panelIdContent\"]/div/div[9]/input");
    public static final By letterhistory = By.xpath("//*[@id=\"panelIdContent\"]/div/a");

    public static String clickLettersbuttoninCommunicationsection = "//input[@name='communicationType' and @value='Letter']";
    public static String selectRequestingProvideronSendLetterTo = "//*[@id=\"sendLetterToID\"]/tbody/tr[2]/td[1]/input";
    public static String selectServicingProvideronSendLetterTo = "//*[@id=\"sendLetterToID\"]/tbody/tr[1]/td[1]/input";
    public static String selectMemberonSendLetterTo = "//*[@id=\"sendLetterToID\"]/tbody/tr[3]/td[1]/input";
    public static String sendLetterTotableXpath = "//table[@id='sendLetterToID']";
    public static String selectCarrieronSendLetterTo = "//*[@id=\"sendLetterToID\"]/tbody/tr[4]/td[1]/input";

    public static final By clickViewIconinCommunicationsection = By.xpath("//table[@id=\"letterHistoryID\"]/tbody/tr[1]/td[1]/span[@ng-click='letterPreview(record, $event)']");
    public static final By clickOnHH = By.xpath("//input[@id='hours-0']");
    public static final By clickOnMM = By.xpath("//input[@id='minutes-0']");
    public static final By clickOnPM = By.xpath("//button[@ng-click='toggleMeridian()']");
    public static final By clickOnMarkLetterAsSent = By.xpath("//td/input[@type='button'][1]");
    public static final By refreshLetterHistoryTable = By.xpath("//div/input[@value='Refresh']");
    public static final By sendFaxBtn = By.xpath("//tbody/tr/td/input[@value='Send Fax']");

    public static final By autoLettersPopUpHeader = By.xpath("//*[@id=\"printLettersPopupModelID\"]/div[2]/div/div[1]/div[1]/h2");
    public static final By physicalmailonAutoLettersPopup = By.xpath("//*[@id=\"printLetters\"]/div[2]/span");
    public static final By faxonAutoLettersPopup = By.xpath("//*[@id=\"printLetters\"]/div[3]/span");

    public static final By autoletterpopupsendletters = By.xpath("//*[@id='printLetters']/div[5]/input[1]");
    public static final By autoletterpopupconfirmcheckbox = By.xpath("//*[@id='confirmFaxCheckbox']");

    public String actualRequestnumber;
    private static Logger log = Logger.getLogger(LettersSection.class);
    private WebDriver driver;
    private Scenario scenario;
    private ScenarioLogger scenarioLogger = null;
    private String owner;

    /*Page Constructor*/
    public LettersSection(WebDriver driver) {
        this.driver = driver;
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return driver;
    }


    public void selectradiobuttononletterspage(String locatorString) throws Throwable {
        Assert.assertFalse(StringUtils.isEmpty(locatorString));
        WebDriver d = driver();
        try {
            By by = CommonPageObject.pageObjectUtils.getLocator(locatorString);
            if (!TestUtils.click(d, by)) {
                throw new InvalidLocatorException("Not clickable: " + by);
            }
        } catch (Exception e) {
            WebElement e1;
            List<WebElement> ele = TestUtils.findElements(d, locatorString);
            if (ele.size() > 0) {
                e1 = ele.get(0);
            } else {
                e1 = TestUtils.slowFindElement(d, locatorString, null);
            }
            TestUtils.waitElementVisible(d, locatorString);
            TestUtils.wait(3);
            Assert.assertTrue(TestUtils.click(d, e1));
        }
        TestUtils.wait(2);
    }


    public void captureauthnumberandnavigatetoauthsummary() throws Throwable {

        actualRequestnumber =   obj().RequestStatusPage.getAuthorizationNumber();
        log.warn("Submitted Auth number is "+actualRequestnumber);
        WhiteBoard.getInstance().putString(owner, "requestNumber", actualRequestnumber);
        scenarioLogger.warn("New string added for " + owner + ": " + "requestNumber" + "=" + actualRequestnumber);
        obj().NavigationPage.navigatesToMenuItem("Home>Authorization>Search");

        try {
            TestUtils.wait(2);
            obj().PriorAuthorizationSearchSubmittedPage.selectBenefitTypeSubmitted("Medical");
        } catch (Exception e) {
        }

        try {
            TestUtils.wait(2);
            obj().PriorAuthorizationSearchSubmittedPage.enterRequestNumber(actualRequestnumber);
        } catch (Exception e) {
            TestUtils.wait(2);
            obj().PriorAuthorizationSearchSubmittedPage.enterRequestNumberOC(actualRequestnumber);
        }


        obj().PriorAuthorizationSearchSubmittedPage.clickSearchSubmitted();
        obj().CommonPage.waitForNOTBusyIndicator();
        obj().PriorAuthorizationSearchSubmittedPage.clickFirstRecordInPriorAuthSearch("SUBMITTED");
    }

    public void navigatetoLetterssection() throws Throwable {
        String locatorString = WhiteBoard.resolve(owner, clickLettersbuttoninCommunicationsection);
        selectradiobuttononletterspage(locatorString);

    }

    public void sendLetterTotable (Scenario scenario, String prefix, String keyHeader) throws Throwable {
        TestUtils.extractGridToWhiteBoard(driver(), scenario, prefix, keyHeader, sendLetterTotableXpath, false, false);
        TestUtils.demoBreakPoint(scenario, driver(), sendLetterTotableXpath + " is extracted with prefix " + prefix + " and key header " + keyHeader);
    }

    public void selectRPinSendLetterToTable() throws Throwable {
        String locatorString = WhiteBoard.resolve(owner, selectRequestingProvideronSendLetterTo);
        selectradiobuttononletterspage(locatorString);
        TestUtils.wait(2);
    }

    public void selectSPinSendLetterToTable() throws Throwable {
        String locatorString = WhiteBoard.resolve(owner, selectServicingProvideronSendLetterTo);
        selectradiobuttononletterspage(locatorString);
        TestUtils.wait(2);
    }

    public void selectMemberinSendLetterToTable() throws Throwable {
        String locatorString = WhiteBoard.resolve(owner, selectMemberonSendLetterTo);
        selectradiobuttononletterspage(locatorString);
        TestUtils.wait(2);
    }

    public void selectCarrierinSendLetterToTable() throws Throwable {
        String locatorString = WhiteBoard.resolve(owner, selectCarrieronSendLetterTo);
        selectradiobuttononletterspage(locatorString);
        TestUtils.wait(2);
    }

    public void fillDeliveryType(String deliveryType) throws Throwable {
        By deliveryTypeDropdownXpath = By.xpath("//select[@ref-nm='letterDeliveryType']");
        Assert.assertTrue(TestUtils.isElementVisible(driver,deliveryTypeDropdownXpath));
        TestUtils.click(driver,deliveryTypeDropdownXpath);
        TestUtils.wait(1);
        By deliveryTypeValueXpath =By.xpath("//select[@ref-nm='letterDeliveryType']//option[text()='"+deliveryType+"']");
        TestUtils.click(driver,deliveryTypeValueXpath);
        TestUtils.wait(1);
        TestUtils.click(driver, By.xpath("//*[@id=\"memberInformationSection\"]/table[2]/tbody/tr/td[1]/span/label"));

    }

    public void fillLetterType(String letterType) throws Throwable {
        By letterTypeDropdownXpath = By.xpath("//select[@ref-nm='letterType']");
        Assert.assertTrue(TestUtils.isElementVisible(driver,letterTypeDropdownXpath));
        TestUtils.click(driver,letterTypeDropdownXpath);
        TestUtils.wait(1);
        By letterTypeValueXpath =By.xpath("//select[@ref-nm='letterType']//option[text()='"+letterType+"']");
        TestUtils.click(driver,letterTypeValueXpath);
        TestUtils.wait(1);
        TestUtils.click(driver, By.xpath("//*[@id=\"letterInformationSection\"]/table[2]/tbody/tr/td[1]/span/label"));

        if (letterType.equals("Lack of Information")) {
            int size = driver.findElements(By.tagName("iframe")).size();
            for(int i=0; i<size; i++)
                driver.switchTo().frame(i);
            //driver.switchTo().frame("Rich Text Editor, editor1");
            driver.findElement(By.tagName("body")).sendKeys("Test text using body");
            //TestUtils.input(driver, By.xpath("/html/body"), "Test text");
            driver.switchTo().defaultContent();
        }
    }

    public void selectLanguage(String language) throws Throwable {
        By languageDropdownXpath = By.xpath("//select[@ref-nm='languageCodeNISO']");
        Assert.assertTrue(TestUtils.isElementVisible(driver,languageDropdownXpath));
        TestUtils.click(driver,languageDropdownXpath);
        TestUtils.wait(1);
        By languageValueXpath =By.xpath("//select[@ref-nm='languageCodeNISO']//option[text()='"+language+"']");
        TestUtils.click(driver,languageValueXpath);
        TestUtils.wait(1);
        TestUtils.click(driver, By.xpath("//*[@id=\"memberInformationSection\"]/table[3]/tbody/tr/td[1]/span/label"));

    }

    public void createLetter() throws Throwable {
        TestUtils.click(driver, clickcreateletter);
        TestUtils.wait(5);
    }

    public void openLettersHistory() throws Throwable {
        TestUtils.click(driver, letterhistory);
        TestUtils.wait(2);
    }

    public void validateletterrow(String template, String deliverytype, String sentto, String recipient) throws Throwable{
        // table id = letterHistoryID
        //thead xpath = //*[@id="letterHistoryID"]/thead
        WebElement simpleTable = driver.findElement(By.id("letterHistoryID"));

        //Get all rows
        List<WebElement> rows = simpleTable.findElements(By.tagName("tr"));

        int rowcount = 0;
        //Traverse data from each row
        for (WebElement row : rows) {
            int count = 0;
            List<WebElement> cols = row.findElements(By.tagName("td"));
            for (WebElement col : cols) {
                System.out.print(col.getText() + "\t");
                if (rowcount == 1 && count == 1)
                    if (!col.getText().equals(template)) {
                        throw new ImmediateAbortException("Letter Template is wrong");
                    }
                if (rowcount == 1 && count == 2)
                    if (!col.getText().equals(recipient)){
                        throw new ImmediateAbortException("Letter Recipient is wrong");
                    }
                if (rowcount == 1 && count == 3)
                    if (!col.getText().equals(sentto)) {
                        throw new ImmediateAbortException("Letter Sent address is wrong");
                    }
                if (rowcount == 1 && count == 7)
                    if (!col.getText().equals(deliverytype)) {
                        throw new ImmediateAbortException("Letter Delivery Type is wrong");
                    }
                count++;
            }
            rowcount++;
        }
        TestUtils.wait(5);
    }

    public void clickOnViewIcon()throws Throwable{
        log.warn("Clicking on icon view");
        TestUtils.wait(2);
        TestUtils.click(driver, clickViewIconinCommunicationsection);
        TestUtils.wait(5);

    }

    public void validateLetterSatus(String status){
        log.warn("Cheking if letter status Successfully Sent");
        WebElement webElement = driver.findElement(By.xpath("//table[@id='letterHistoryID']/tbody/tr[1]/td[6]"));
        Assert.assertEquals(status,webElement.getText());
    }

    public void setLetterAsSentforPDF(String hh,String mm)throws Throwable{
        log.warn("Entering " + hh + "with"+mm+" to generate the letter");
        TestUtils.waitElement(driver, clickOnHH);
        driver.findElement(clickOnHH).clear();
        driver.findElement(clickOnHH).sendKeys(hh);
        driver.findElement(clickOnMM).clear();
        driver.findElement(clickOnMM).sendKeys(mm);
        TestUtils.click(driver, clickOnPM);
        TestUtils.click(driver, clickOnMarkLetterAsSent);
        TestUtils.wait(5);

    }

    public void refreshLetterHistoryTableAfterGeneratingThePDF(){
        log.warn("Refresh the Letter History Table");
        TestUtils.click(driver, refreshLetterHistoryTable);
        TestUtils.wait(2);
    }

    public void validateSendApprovedDeniedLettersPopup(String Decision, String SPName, String SPAddress, String memberName, String memberAddress, String RPName, String RPFaxNumber){
        log.warn("Verifying the Auto Letters Pop-up");
        String autoLetterPopUpHeaderDisplayed = driver.findElement(autoLettersPopUpHeader).getText();
        String autoLetterPopUpHeaderExpected = "Send "+ Decision + " Letters?";
        Assert.assertEquals(autoLetterPopUpHeaderExpected, autoLetterPopUpHeaderDisplayed);

        //Verifying the Physical Mail text:
        String physicalmailTextDisplay = driver.findElement(physicalmailonAutoLettersPopup).getText();
        String physicalmailTextDisplayed = physicalmailTextDisplay.split("\n")[1];
        String physicalmailTextExpected = "Physical Mail";
        Assert.assertEquals(physicalmailTextDisplayed, physicalmailTextExpected);


        //Verifying the Physical Mail table information
        WebElement popupLettersTable = driver.findElement(By.id("sendLetterToPopUpID"));

        //Get all rows
        List<WebElement> lettersrows = popupLettersTable.findElements(By.tagName("tr"));

        int lettersrowcount = 0;
        //Traverse data from each row
        for (WebElement letterrow : lettersrows) {
            int lettercount = 0;
            String popuplettername = null, popuplettersenttotype = null, popuplettersenttoaddress = null;
            List<WebElement> lettercols = letterrow.findElements(By.tagName("td"));
            for (WebElement lettercol : lettercols) {
                System.out.print(lettercol.getText() + "\t");

                if (lettercount == 1) {
                    popuplettername = lettercol.getText();
                }
                if (lettercount == 2) {
                    popuplettersenttotype = lettercol.getText();
                }
                if (lettercount == 3) {
                    popuplettersenttoaddress = lettercol.getText();
                    if (popuplettersenttotype.equals("Member")) {
                        Assert.assertEquals(memberName,popuplettername);
                        Assert.assertEquals(memberAddress,popuplettersenttoaddress);
                        lettersrowcount++;
                    } else if (popuplettersenttotype.equals("Servicing Provider")) {
                        Assert.assertEquals(SPName,popuplettername);
                        Assert.assertEquals(SPAddress,popuplettersenttoaddress);
                        lettersrowcount++;
//                    } else if (popupsenttotype.equals("Carrier")) {
//                        Assert.assertEquals(SPName,popupname);
//                        Assert.assertEquals(SPAddress,popupsenttoaddress);
                    }
                }
                lettercount++;
            }
        }
        TestUtils.wait(5);
        if (SPName.equals(RPName)) {
            if (lettersrowcount != 1) {
                Assert.fail("Auto Letters Pop-up Letters information is not validated completely when Servicing Provider and Requesting Provider are same");
            }
        }
        else {
            if (lettersrowcount != 2)
                Assert.fail("Auto Letters Pop-up Letters information is not validated completely when Servicing Provider and Requesting Provider are different");
        }
        TestUtils.wait(5);


        //Verifying the Fax text:
        String faxTextDisplay = driver.findElement(faxonAutoLettersPopup).getText();
        String faxTextDisplayed = faxTextDisplay.split("\n")[1];
        String faxTextExpected = "Fax";
        Assert.assertEquals(faxTextDisplayed, faxTextExpected);

        //Verifying the Fax table information
        WebElement popupFaxTable = driver.findElement(By.id("sendFaxToPopUpID"));

        //Get all rows
        List<WebElement> faxrows = popupFaxTable.findElements(By.tagName("tr"));

        int faxrowcount = 0;
        //Traverse data from each row
        for (WebElement faxrow : faxrows) {
            int faxcount = 0;
            String popupfaxname = null, popupfaxsenttotype = null, popupfaxsenttoaddress = null;
            List<WebElement> faxcols = faxrow.findElements(By.tagName("td"));
            for (WebElement faxcol : faxcols) {
                System.out.print(faxcol.getText() + "\t");

                if (faxcount == 1) {
                    popupfaxname = faxcol.getText();
                }
                if (faxcount == 2) {
                    popupfaxsenttotype = faxcol.getText();
                }
                if (faxcount == 3) {
                    popupfaxsenttoaddress = faxcol.getText();
                    if (popupfaxsenttotype.equals("Requesting Provider")) {
                        Assert.assertEquals(RPName,popupfaxname);
                        Assert.assertEquals(RPFaxNumber,popupfaxsenttoaddress);
                        faxrowcount++;
                    }
                }
                faxcount++;
            }
        }
        TestUtils.wait(5);
        if (faxrowcount != 1)
            Assert.fail("Auto Letters Pop-up Fax information is not validated completely");
        TestUtils.wait(5);
    }


    public void validateCarrierNameAddressonAutoLettersPopup(String Decision, String CarrierName, String CarrierAddress) {
        log.warn("Verifying the Auto Letters Pop-up with Carrier Information");

        //Verifying the Physical Mail table information with Carrier Information
        WebElement popupLettersTable = driver.findElement(By.id("sendLetterToPopUpID"));

        //Get all rows
        List<WebElement> lettersrows = popupLettersTable.findElements(By.tagName("tr"));

        int Carrierrowcount = 0;
        //Traverse data from each row
        for (WebElement letterrow : lettersrows) {
            int lettercount = 0;
            String popuplettername = null, popuplettersenttotype = null, popuplettersenttoaddress = null;
            List<WebElement> lettercols = letterrow.findElements(By.tagName("td"));
            for (WebElement lettercol : lettercols) {
                System.out.print(lettercol.getText() + "\t");

                if (lettercount == 1) {
                    popuplettername = lettercol.getText();
                }
                if (lettercount == 2) {
                    popuplettersenttotype = lettercol.getText();
                }
                if (lettercount == 3) {
                    popuplettersenttoaddress = lettercol.getText();
                    if (popuplettersenttotype.equals("Carrier")) {
                        Assert.assertEquals(CarrierName, popuplettername);
                        Assert.assertEquals(CarrierAddress, popuplettersenttoaddress);
                        Carrierrowcount++;
                    }
                }
                lettercount++;
            }
        }
        TestUtils.wait(5);
        if (Carrierrowcount != 1)
            Assert.fail("Auto Letters Pop-up Letters information is not validated completely when Servicing Provider and Requesting Provider are different");
        TestUtils.wait(5);
    }


    public void confirminformationandclicksendletters() {
        if (TestUtils.isClickable(driver, autoletterpopupsendletters)) {
            TestUtils.click(driver, autoletterpopupsendletters);
        } else {
            TestUtils.click(driver, autoletterpopupconfirmcheckbox);
            TestUtils.click(driver, autoletterpopupsendletters);
        }
        TestUtils.wait(20);
    }

    public void validateLettersfromAutoLettersPopupinLetterHistory(String LetterType, String SPName, String SPAddress, String memberName, String memberAddress, String RPName, String RPFaxNumber){
        WebElement simpleTable = driver.findElement(By.id("letterHistoryID"));

        //Get all rows
        List<WebElement> rows = simpleTable.findElements(By.tagName("tr"));
        int finalchecks = 0;
        //Traverse data from each row
        for (WebElement row : rows) {
            int count = 0;
            String template = null, recipient = null, sentto = null;
            List<WebElement> cols = row.findElements(By.tagName("td"));
            for (WebElement col : cols) {
                System.out.print(col.getText() + "\t");
                if (count == 1) {
                    template = col.getText();
                }
                if (count == 2) {
                    recipient = col.getText();
                }
                if (count == 3) {
                    sentto = col.getText();
                }
                if (count == 7) {
                    if (col.getText().equals("Fax")) {
                        finalchecks++;
                        Assert.assertEquals(LetterType,template);
                        Assert.assertEquals(RPName,recipient);
                        Assert.assertEquals(RPFaxNumber,sentto);
                    } else if (col.getText().equals("Physical Mail") && recipient.equals(SPName) && !SPName.equals(RPName)) {
                        finalchecks++;
                        Assert.assertEquals(LetterType,template);
                        Assert.assertEquals(SPAddress,sentto);
                    } else if (col.getText().equals("Physical Mail") && recipient.equals(memberName)) {
                        finalchecks++;
                        Assert.assertEquals(LetterType,template);
                        Assert.assertEquals(memberAddress,sentto);
                    }
                }
                count++;
            }
        }
        if (SPName.equals(RPName)) {
            if (finalchecks != 2) {
                Assert.fail("Letter History is not validated completely");
            }
        }
        else {
            if (finalchecks != 3)
                Assert.fail("Letter History is not validated completely");
        }
        TestUtils.wait(5);
    }


    public void validateCarrierLettersfromAutoLettersPopupinLetterHistory(String LetterType, String CarrierName, String CarrierAddress) {
        WebElement simpleTable = driver.findElement(By.id("letterHistoryID"));

        //Get all rows
        List<WebElement> rows = simpleTable.findElements(By.tagName("tr"));
        int finalchecks = 0;
        //Traverse data from each row
        for (WebElement row : rows) {
            int count = 0;
            String template = null, recipient = null, sentto = null;
            List<WebElement> cols = row.findElements(By.tagName("td"));
            for (WebElement col : cols) {
                System.out.print(col.getText() + "\t");
                if (count == 1) {
                    template = col.getText();
                }
                if (count == 2) {
                    recipient = col.getText();
                }
                if (count == 3) {
                    sentto = col.getText();
                }
                if (count == 7) {
                    if (col.getText().equals("Physical Mail") && recipient.equals(CarrierName)) {
                        finalchecks++;
                        Assert.assertEquals(LetterType,template);
                        Assert.assertEquals(CarrierName,recipient);
                        Assert.assertEquals(CarrierAddress,sentto);
                    }
                }
                count++;
            }
        }
        if (finalchecks != 1)
            Assert.fail("Letter History for Carrier letter is not validated completely");
        TestUtils.wait(5);
    }
}