package atdd.test.pageobjects.utilizationManagement;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class PanelSummaryPage {

    public static final String PANNEL_SUMMARY_TABLE_XPATH = ViewAuthPage.SUMMARY_PANEL_XPATH + "//form[@name='summary']/table";

    public static final By headerSummary = By.xpath(ViewAuthPage.SUMMARY_PANEL_XPATH + "//h4/..");
    public static final By labelStatus = By.xpath(PANNEL_SUMMARY_TABLE_XPATH + "//label[contains(.,'Status')]");
    public static final By labelRequestNumber = By.xpath(PANNEL_SUMMARY_TABLE_XPATH + "//label[contains(.,'Request Number')]");
    public static final By labelDateOfSubmmition = By.xpath(PANNEL_SUMMARY_TABLE_XPATH + "//label[contains(.,'Date of Submission')]");
    public static final By labelPriority = By.xpath(PANNEL_SUMMARY_TABLE_XPATH + "//label[contains(.,'Priority')]");
    public static final By labelAssignedTo = By.xpath(PANNEL_SUMMARY_TABLE_XPATH + "//label[contains(.,'Assigned To')]");
    public static final By labelAnticipatedTreatmentStartDate = By.xpath(PANNEL_SUMMARY_TABLE_XPATH + "//label[contains(.,'Anticipated Treatment Start Date')]");
    public static final By labelCompletionStatus = By.xpath(PANNEL_SUMMARY_TABLE_XPATH + "//label[contains(.,'Completion Status')]");

    private static Logger log = Logger.getLogger(PanelSummaryPage.class);
    private WebDriver driver = null;

    /*Page Constructor*/
    public PanelSummaryPage(WebDriver driver) {
        this.driver = driver;
    }

}
