package atdd.test.pageobjects.utilizationManagement;

import atdd.common.ICondition;
import atdd.common.Retry;
import atdd.dao.mbm.HscAtrDao;
import atdd.dao.mbm.HscCustomReasonsDao;
import atdd.dao.mbm.HscDao;
import atdd.dao.mbm.MyBatisConnectionFactory;
import atdd.utils.TestUtils;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;


public class ViewAuthPage {

    public static final String STICKY_HEADER_XPATH = "//div[contains(@class, 'stickyMenu')]";

    public static final String AUTH_REQ_HEADER_XPATH = "//span[contains(@class, 'authReqHeader')]";

    public static final String SUMMARY_PANEL_XPATH = "//div[@id='summarySectionPanelId']";
    public static final String MEMBER_PANEL_XPATH = "//div[@id='coveragePanelId']";
    public static final String SERVICES_AND_DECISIONS_PANEL_XPATH = "//div[@id='servicesPanelId']";
    public static final String CLINICAL_PANEL_XPATH = "//div[@id='clinicalSectionPanelId']";
    public static final String ASSIGNMENTS_PANEL_XPATH = "//div[@id='assignmentPanelId']";
    public static final String ACTIVITIES_PANEL_XPATH = "//div[@id='activityHistoryPanelId']";
    public static final String NOTES_PANEL_XPATH = "//div[@id='notesSectionPanelId']";
    public static final String PROVIDER_PANEL_XPATH = "//div[@id='umProviderPanelId']";
    public static final String COMMUNICATION_PANEL_XPATH = "//div[@id='faxRequestPanelId']";
    public static final String TREATMENTREVIEW_PANEL_XPATH = "//div[@id='treatmentReview']";

    public static final By stickyHeader = By.xpath(STICKY_HEADER_XPATH);
    public static final By memberHeader = By.xpath(STICKY_HEADER_XPATH + "/div[contains(@class, 'stickyHeader')]");

    public static final By authReqHeader = By.xpath(AUTH_REQ_HEADER_XPATH);

    public static final By tabSummary = By.xpath(STICKY_HEADER_XPATH + "//button[. = 'Summary']");
    public static final By tabMember = By.xpath(STICKY_HEADER_XPATH + "//button[. = 'Member']");
    public static final By tabServiceAndDecisions = By.xpath(STICKY_HEADER_XPATH + "//button[. = 'Services and Decisions']");
    public static final By tabClinical = By.xpath(STICKY_HEADER_XPATH + "//button[. = 'Clinical']");
    public static final By tabAssignments = By.xpath(STICKY_HEADER_XPATH + "//button[. = 'Assignments']");
    public static final By tabActivities = By.xpath(STICKY_HEADER_XPATH + "//button[. = 'Activities']");
    public static final By tabNotes = By.xpath(STICKY_HEADER_XPATH + "//button[. = 'Notes']");
    public static final By tabProvider = By.xpath(STICKY_HEADER_XPATH + "//button[. = 'Provider']");
    public static final By tabCommunication = By.xpath(STICKY_HEADER_XPATH + "//button[. = 'Communication']");
    public static final By tabTreatmentReview = By.xpath(STICKY_HEADER_XPATH + "//button[. = 'Treatment Review']");


    public static final By panelSummary = By.xpath(SUMMARY_PANEL_XPATH);
    public static final By panelMember = By.xpath(MEMBER_PANEL_XPATH);
    public static final By panelServicesAndDecisions = By.xpath(SERVICES_AND_DECISIONS_PANEL_XPATH);
    public static final By panelClinical = By.xpath(CLINICAL_PANEL_XPATH);
    public static final By panelAssignments = By.xpath(ASSIGNMENTS_PANEL_XPATH);
    public static final By panelActivities = By.xpath(ACTIVITIES_PANEL_XPATH);
    public static final By panelNotes = By.xpath(NOTES_PANEL_XPATH);
    public static final By panelProvider = By.xpath(PROVIDER_PANEL_XPATH);
    public static final By panelCommunication = By.xpath(COMMUNICATION_PANEL_XPATH);
    public static final By panelTreatmentReview = By.xpath(TREATMENTREVIEW_PANEL_XPATH);

    public static final By cancelAuthorizationRequestLink = By.xpath("//a[.='Cancel Authorization Request']");
    public static final By cancelReasonSelect = By.xpath("//form[@name='cancelWorkqueueAuthPopupModelForm']//select[@ref-nm='hscStatusReasonType']");
    public static final By cancelRequestButton = By.xpath("//form[@name='cancelWorkqueueAuthPopupModelForm']//input[@value='Cancel Request']");

    public static final By assignmentPageIdContent = By.xpath("//*[@id='assignmentPanelIdContent']/div/div[3]/table/tbody/tr//input");
    public static final By closeAssignmentHistoryPopupModalId = By.xpath("//*[@id='assignmentHistoryPopupModelID']//input[@value='Close']");
    public static final By decisionEnteredBy = By.xpath("//*[@id='decisionsForm']/form/table/tbody/tr/td[1]/table/tbody/tr[11]/td[2]/p");
    public static final By decisionForm = By.xpath("//*[@id='decisionsForm']/form/table/tbody");
    public static final By decisionTimeErr = By.xpath("//*[@id='decisionTime_err']");
    public static final By decisionDateErr = By.xpath("//*[@id='decisionDate-date_err']");
    public static final By decisionRenderedBy = By.xpath("//*[@id='hscServiceDecisionVO-decisionMadeByUserID-0']");
    public static final By resourceCommentText = By.id("resourceCommentText");
    public static final By claimNote = By.id("claimNote");
    public static final By medicalBenefitServicesTableRows = By.xpath("//*[@id='medicalBenefitServicesTableID']/tbody/tr");
    public static final By medicalBenefitServicesTableDecisionStatus = By.xpath("//*[@id='medicalBenefitServicesTableID']/tbody/tr[1]/td[3]/a");
    public static final String splitDecisionWarningCloseButtonXpath = "//div[@class='popup-header-wrapper' and .//h2[text()='Split Decision Warning']]//button";

    public static final By makeDecisionsButton = By.id("makeDecisionsButton");
    public static final By saveDecisionsButton = By.id("saveDecisionsButton");
    public static final By decisionSubType = By.xpath("//*[@id='hscServiceDecisionVO-decisionSubType-0']");
    public static final By decisionReason2 = By.xpath("//*[@id='decisionsForm']/form/table/tbody/tr/td[1]/table/tbody/tr[4]/td[2]/*/select");
    public static final By AuthorizationRequestLink = By.xpath("//*[@id='hscSearchTableSubmittedID']//a");

    public static final By CriteriaAndJustification=By.xpath("//table[@id='frmCriteriaAndJustification']/tbody/tr[1]/td/span");
    public static final By CustomRequestReasonLabel= By.xpath("//table[@id='frmCriteriaAndJustification']/tbody/tr[2]/td/span/label");
    public static final By CustomRequestReasonValues= By.id("CustomRequestReasonfeature");
    public static final By AuthorizationRequestNumber = By.xpath("//span[@class='authReqHeader ng-scope']/span[2]");


    public static final By treatmentReviewTab = By.xpath("//*[@class='tab']//button[text()='Treatment Review']");
    public static final By patientHistoryrecordsPerPage = By.xpath("//*[@ng-model='phHistoryTable.pagination.recordsPerPage']");
    public static final By nextLink = By.xpath("//a[@ng-click='phHistoryTable.setPage(phHistoryTable.pagination.currentPageNumber + 1)']");
    public static final By firstLink = By.xpath("//a[@ng-click='phHistoryTable.setPage(1)']");
    public static final By adminDenialReviewSection = By.xpath("//*[@ng-if='adminDenialReviewEnabled']");
    public static final By adminDenialReviewReason = By.xpath("//*[@ng-if='adminDenialReviewEnabled']/descendant::span[@class='ng-binding']");
    public static String panelExpandString = "//span[@ng-if='panel.collapsible']/following::span[contains(.,'{SectionName}')]";
    public static String sumamryWorkQueueName = "//label[contains(.,'Assigned To')]/following::td/span[contains(.,'{queueName}') and @class = 'ng-binding']";


    //PH locators
    public static final By numberOfWeeks = By.xpath("//*[@id='numWeeks']");
    public static final By numberOfVisits = By.xpath("//*[@id='numVisits']");
    public static final By treatmentStartDate = By.xpath("//*[contains(@id,'hscServiceNonFacilityVO-serviceStartDate')]");
    public static final By treatmentEndDate = By.xpath("//*[contains(@id,'hscServiceNonFacilityVO-serviceEndDate')]");
    public static final By submitButton =By.xpath("//input[@value='Submit'][@type='button']");
    public static final By categoryDD = By.xpath("//select[contains(@ng-model,'hscServiceDecisionVO.decnClinicalRespCatgryId')]");
    public static final By responseDD = By.xpath("//select[contains(@id,'mainResponse')]");
    public static final By selectMD = By.xpath("//select[contains(@ng-model,'mdReviewValue')]");
    public static final By mdReviewComments = By.xpath("//textarea[@id='mdReviewComments']");
    public static final By reassignMDButton = By.xpath("//*[@id='reAssignButton']");
    public static final By byPassLink = By.xpath("//*[@id='byPassButton']");


    private static Logger log = Logger.getLogger(ViewAuthPage.class);
    protected WebDriver driver;

    public static boolean isViewAuthPageLoaded(WebDriver d) {
        return true
                && TestUtils.isElementVisible(d, ViewAuthPage.STICKY_HEADER_XPATH)
                && TestUtils.isElementVisible(d, ViewAuthPage.SUMMARY_PANEL_XPATH)
                && TestUtils.isElementVisible(d, ViewAuthPage.MEMBER_PANEL_XPATH)
                && TestUtils.isElementVisible(d, ViewAuthPage.SERVICES_AND_DECISIONS_PANEL_XPATH)
                && ( TestUtils.isElementVisible(d, ViewAuthPage.CLINICAL_PANEL_XPATH) || (TestUtils.isElementVisible(d, ViewAuthPage.TREATMENTREVIEW_PANEL_XPATH)))
                && TestUtils.isElementVisible(d, ViewAuthPage.ASSIGNMENTS_PANEL_XPATH)
                && TestUtils.isElementVisible(d, ViewAuthPage.ACTIVITIES_PANEL_XPATH)
                && TestUtils.isElementVisible(d, ViewAuthPage.NOTES_PANEL_XPATH)
                && TestUtils.isElementVisible(d, ViewAuthPage.PROVIDER_PANEL_XPATH)
                && TestUtils.isElementVisible(d, ViewAuthPage.COMMUNICATION_PANEL_XPATH)
                ;
    }

    public static boolean waitForViewAuthPageLoaded(WebDriver d) {
        TestUtils.waitForNotBusy(d);
        return new Retry("Wait for ViewAuthPage to be loaded.") {
            int wait = 3;

            @Override
            protected void tryOnce() throws Exception {
                if (!landed()) {
                    throw new RuntimeException("Need recover.");
                }
            }

            private boolean landed() {
                TestUtils.wait(wait > 10 ? 10 : wait++);
                return isViewAuthPageLoaded(d);
            }

            @Override
            protected void weakRecover(Exception e) throws Exception {
                TestUtils.refreshPage(d);
            }

        }.execute();
    }

    /*Page Constructor*/
    public ViewAuthPage(WebDriver driver) {
        this.driver = driver;
    }

    public static Map<String, String> dataOfDecision(String option) {
        Map<String, String> map = new LinkedHashMap<>();
        switch (option) {
            case "Denied":
                map.put("Decision Outcome", "Denied/Not Covered");
                map.put("Decision Type", "Administrative");
                map.put("Decision Reason - Medical Benefit", "D1 Deny, Not Medically Necessary");
                map.put("Decision Notes", "decision note");
                map.put("Custom Request Reason", "Max Dosage Exceeded (Specialty)");
                map.put("Resource(s) Used", "All");
                map.put("Resource Details", "resource details");
                map.put("Claim Type / Comment", "claim type / comment");
                return map;
            case "Approved":
                map.put("Decision Outcome", "Approved/Covered");
                map.put("Decision Type", "Administrative");
                map.put("Decision Reason - Medical Benefit", "A1 Approve, Medically Appropriate");
                map.put("Decision Notes", "decision note");
                map.put("Custom Request Reason", "Max Dosage Exceeded (Specialty)");
                map.put("Resource(s) Used", "All");
                map.put("Resource Details", "resource details");
                map.put("Claim Type / Comment", "claim type / comment");
                return map;
            default:
                // do nothing
        }
        return null;
    }

    public void cancelAuthorizationRequest(String reason) {
        TestUtils.click(driver, cancelAuthorizationRequestLink);
        TestUtils.input(driver, cancelReasonSelect, reason);
        TestUtils.click(driver, cancelRequestButton);
        TestUtils.wait(2);
    }

    public List<String> getLinks() {
        List<String> links = new ArrayList<>();
        String xpath = "//div[@ng-if='onLoadHscMemProvView']//a";
        List<WebElement> els = TestUtils.findElements(driver, xpath);
        if (els.size() > 0) {
            for (WebElement el : els) {
                links.add(el.getText().trim());
            }
        }
        return links;
    }

    public boolean clickMakeDecisions() {
        return TestUtils.clickUntil(driver, makeDecisionsButton, new ICondition() {
            @Override
            public boolean evaluate() {
                return TestUtils.isElementVisible(driver, saveDecisionsButton);

            }
        });
    }

    public boolean clickSaveDecisions() {
        return TestUtils.clickUntil(driver, saveDecisionsButton, new ICondition() {
            @Override
            public boolean evaluate() {
                return TestUtils.isElementVisible(driver, saveDecisionsButton);

            }
        });
    }

    public void selectDecisionType(String decisionType) {
        log.warn("Enter decision Type " + decisionType);
        TestUtils.wait(2);
        TestUtils.selectByVisibleText(driver, decisionSubType,decisionType);
    }

    public void selectDecisionReason(String reason) {
        log.warn("Enter decision reason " + reason);
        TestUtils.wait(2);
        TestUtils.selectByVisibleText(driver, decisionReason2,reason);
    }


    public void selectAllCriteriaResourceUsed() {
        By criteriaDropdwnXpath=By.xpath("//span[@id='resourcesUsedSelect']//span[@class='cux-icon-sort_down']");
        By allXpath= By.xpath("//span[@id='resourcesUsedSelect']//button[@aria-describedby='allBtnAl1yText']");
        TestUtils.click(driver, criteriaDropdwnXpath);
        TestUtils.wait(2);
        TestUtils.click(driver,allXpath);
        TestUtils.wait(5);
    }

    public void enterResourceDetails(String data) {
        log.warn("Enter the Resource details: " + data);
        TestUtils.wait(2);
        By resourceTextAreaXpath=By.xpath("//textarea[@id='resourceDetails']");
        TestUtils.wait(2);
        driver.findElement(resourceTextAreaXpath).click();
        driver.findElement(resourceTextAreaXpath).sendKeys(data);
        TestUtils.wait(2);
    }

    public void clickSaveDecisionbutton() {
        TestUtils.wait(2);
        TestUtils.waitElementClickable(driver, saveDecisionsButton);
        TestUtils.click(driver, saveDecisionsButton);
    }

    public void clickTreatmentReviewbutton() {
        TestUtils.wait(3);
        TestUtils.waitElementClickable(driver, tabTreatmentReview);
        TestUtils.click(driver, tabTreatmentReview);
    }

    public List<String> getCustomReasons(){
        TestUtils.waitElementVisible(driver,CustomRequestReasonLabel);
        return TestUtils.asTextList(driver,CustomRequestReasonValues);

    }

    public String getAuthorizationRequestNumber(){
        TestUtils.scrollToElement(driver, AuthorizationRequestNumber);
        return TestUtils.text(driver,AuthorizationRequestNumber);

    }

    public void validateCustomReasonsOnScreenWithDB()
    {

        // Read the Custom Reasons Displayed in UI.
        List<String> uiCustomReasons = new ArrayList<>();

        // Retrieve Custom Reasons Displayed in UI, Loop through and remove "," at the end for true Comaprison with DB
        for(String hscUIreason : getCustomReasons()){
            // remove the Comma at the end of the string only.
            if(hscUIreason.lastIndexOf(",") == hscUIreason.length()-1 )
                uiCustomReasons.add(hscUIreason.substring(0, hscUIreason.length()-1));
            else
                uiCustomReasons.add(hscUIreason);
        }

        // Retrieve Authorization Number displayed on UM Page
        String requestNumber = getAuthorizationRequestNumber();

        // Retrieve HSC_ID using Authorization Request Number..
        long hscID = HscDao.getHscIdByAuthNumber(requestNumber);

        //Retrieve HSC Custom Reasons from Db
        List<Map<String, Object>> listReasons = new HscCustomReasonsDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectHscCustomReasonById(hscID);

        //Copy hashmap values to collection of custom reasons.
        List<String> dbCustomReason = HscCustomReasonsDao.asList(listReasons);

        // Compare the Reason collection from DB and UI. If they both match, it is PASS.
        Assert.assertTrue(dbCustomReason.equals(uiCustomReasons));

    }


    public void clickResponseLink(){
        List<WebElement> responseLinkXpath =driver.findElements(By.xpath("//a[@ng-click='openPhHistoryResponsePopup(null,record.primaryServiceReferenceNumber)']"));
        for (WebElement myElement : responseLinkXpath) {
            String link = myElement.getText();
            log.warn(link);
            if (link != "") {
                myElement.click();
                TestUtils.wait(3);
            }
            break;
        }
    }

    public void validateResponseTitle(){
        By responseTitleExpectedXpath= By.xpath("//tr[@ng-if='phHistoryResponseTable.records.length != 0'][1]//td[@ng-if='!record.memberMasked == true'][1]//span[@class='responseHeaderTable ng-binding']");
        String responseTitleExpected= TestUtils.text(driver,responseTitleExpectedXpath);
        By responseTitleActualXpath= By.xpath("//h3[@id='responseDetails']");
        String responseTitleActual= TestUtils.text(driver,responseTitleActualXpath);
        Assert.assertEquals("Response Titles displayed properly",responseTitleExpected,responseTitleActual);
    }

    public void validateRequestNumberOnNewTab(String actualRequestNumber){
        String expectedRequestNumber = driver.findElement(By.xpath("//td[contains(@class,'labelColumn ng-binding ng-scope')]//span")).getText();
        Assert.assertTrue("New Tab opens with valid request number", expectedRequestNumber.equalsIgnoreCase(actualRequestNumber));
    }

    public void clickAuthorizationRequestNumber(){
        TestUtils.wait(5);
        TestUtils.isElementVisible(driver,AuthorizationRequestLink);
        TestUtils.click(driver,AuthorizationRequestLink);
        TestUtils.wait(5);
    }

    public String getRequestNumber(){

        String authorizationNumber = TestUtils.text(driver,AuthorizationRequestLink);
        return authorizationNumber;
    }

    public void openNewTab(){
        driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL + "t");
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
    }

    public boolean clickTreatmentReview() {
        TestUtils.wait(10);
        return TestUtils.clickUntil(driver, treatmentReviewTab, new ICondition() {
            @Override
            public boolean evaluate() {
                return TestUtils.isElementVisible(driver, treatmentReviewTab);

            }
        });
    }

    public void patientHistoryrecordsPerPage(String option) {
        TestUtils.select(driver, patientHistoryrecordsPerPage, option);
        TestUtils.wait(3);
    }

    public void validateAuthSubmittedDateShouldBeWithinThreeYears() {
        List<String> list = new ArrayList<>();
        List<WebElement> noOfPages = driver.findElements(By.xpath("//li[@ng-click='phHistoryTable.setPage(pageNumber)']//a[@class='ng-binding']"));
        for(int j = 0; j <= noOfPages.size() - 1; j++)
        {
            List<WebElement> authSubmittedDates = driver.findElements(By.xpath("//table[@id='phHistoryTableID']//tbody//tr//td[3]"));
            for (int i = 0; i < authSubmittedDates.size(); i++) {
                System.out.println(authSubmittedDates.get(i).getText());
                String submittedDate = authSubmittedDates.get(i).getText();
                compareDates(submittedDate);
            }
            if(j==noOfPages.size() - 1)
            {
                break;
            }
            TestUtils.click(driver, nextLink);
        }

    }

    public static void compareDates(String submittedDate) {
        //SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy");
        Calendar cal = Calendar.getInstance();

        cal.add(Calendar.YEAR, -3);
        String threeYearsBackDate = cal.get(Calendar.DATE) + "-" +
                (cal.get(Calendar.MONTH) + 1) + "-" + cal.get(Calendar.YEAR);

        try {
            Date date1 = sdf.parse(submittedDate);
            Date date2 = sdf.parse(threeYearsBackDate);
            Assert.assertTrue("SubmittedDate is After ThreeYearsBackDate",date1.after(date2) || date1.equals(date2));
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    public void validateAuthNotPartOfPatientHistoryList(String requestNumber) {
        List<String> list = new ArrayList<>();
        List<WebElement> noOfPages = driver.findElements(By.xpath("//li[@ng-click='phHistoryTable.setPage(pageNumber)']//a[@class='ng-binding']"));
        for(int j = 0; j <= noOfPages.size() - 1; j++) {
            List<WebElement> authNumbersList = driver.findElements(By.xpath("//table[@id='phHistoryTableID']//tbody//tr//td[1]"));
            for (int i = 0; i < authNumbersList.size(); i++) {
                System.out.println(authNumbersList.get(i).getText());
                Boolean value = !authNumbersList.get(i).getText().contains(requestNumber);
                Assert.assertTrue("expected and actual match at index " + i, value);
            }
            if(j==noOfPages.size() - 1)
            {
                break;
            }
            TestUtils.click(driver, nextLink);
            TestUtils.wait(10);
        }
    }

    public void clickOnFirstLink(){
        TestUtils.click(driver, firstLink);
    }

    public List<String> listAllAuthOfPatientHistoryTab() {
        List<String> list = new ArrayList<>();
        List<WebElement> noOfPages = driver.findElements(By.xpath("//li[@ng-click='phHistoryTable.setPage(pageNumber)']//a[@class='ng-binding']"));
        for(int j = 0; j <= noOfPages.size() - 1; j++) {
            List<WebElement> authNumbersList = driver.findElements(By.xpath("//table[@id='phHistoryTableID']//tbody//tr//td[1]"));
            for (int i = 0; i < authNumbersList.size(); i++) {
                list.add(authNumbersList.get(i).getText());
            }
            if(j==noOfPages.size() - 1)
            {
                break;
            }
            TestUtils.click(driver, nextLink);
        }
        return list;
    }

    public void validatePatientHistoryHeader(){
        List<String> expectedHeader = new ArrayList<String>();
        Collections.addAll(expectedHeader, "Authorization","Provider","Submitted","Start","End","Primary Diagnosis","Specialty","Pain 24 hrs","Pain Week","Scores","Visits Authorized", "Responses");
        List<String> actualHeader = new ArrayList<String>();
        TestUtils.wait(5);
        List<WebElement> actualHeaderXpath= driver.findElements(By.xpath("//thead[@ng-if='::phHistoryTable.customTable.hideTableHeader != true && phHistoryTable.hideTableHeader != true']//span[@class='tk-dtbl-header-cell']"));
        actualHeaderXpath.forEach(i-> actualHeader.add(i.getText().trim()));
        Assert.assertTrue("Patient History Headers displayed correctly", expectedHeader.containsAll(actualHeader));
    }

    public void validateSpecialtyIcon(){

        List<String> list = new ArrayList<>();
        List<WebElement> noOfPages = driver.findElements(By.xpath("//li[@ng-click='phHistoryTable.setPage(pageNumber)']//a[@class='ng-binding']"));
        for(int j = 0; j <= noOfPages.size() - 1; j++)
        {
            List<String> expectedSpecialtyIcon = new ArrayList<String>();
            Collections.addAll(expectedSpecialtyIcon,"PT" , "ST" , "OT");
            List<String> actualSpecialtyIcon = new ArrayList<String>();
            List<WebElement> actualSpecialtyIconXpath= driver.findElements(By.xpath("//span[@style='border: solid 1px black; color: black; padding: 3px 20px; margin: 4px 2px; border-radius: 16px;']"));
            actualSpecialtyIconXpath.forEach(i-> actualSpecialtyIcon.add(i.getText().trim()));
            Assert.assertTrue("Specialty Icons displaying correctly" ,expectedSpecialtyIcon.containsAll(actualSpecialtyIcon));

            if(j==noOfPages.size() - 1)
            {
                break;
            }
            TestUtils.click(driver, nextLink);
        }
    }

    /**
     * making a decision on PH auth
     * @param decision
     * @param maps
     */
    public void addDecision(String decision, List<Map<String, String>> maps) {
        for (Map<String, String> map : maps) {
            switch (decision) {
                case "Approval":
                    enterNumberOfWeeks(map.get("Number of weeks"));
                    enterNumberOfVisits(map.get("Number of Visits"));
                    enterTreatmentStartDate(map.get("Treatment Start Date"));
                    enterTreatmentEndDate(map.get("Treatment End Date"));
                    clickSubmit();
                    break;
                case "Denial":
                    enterCategory(map.get("Category"));
                    enterTreatmentStartDate(map.get("Treatment Start Date"));
                    enterTreatmentEndDate(map.get("Treatment End Date"));
                    enterResponse(map.get("Response"));
                    clickSubmit();
                    break;
            }
        }
    }
    public String getAdminDenialReviewReason(){
        return TestUtils.text(driver,adminDenialReviewReason);
    }

    public void validateAdminDenialReviewSection(String state){
        TestUtils.waitForNotBusy(driver);
        if(state.equalsIgnoreCase("displayed"))
            Assert.assertTrue("Admin Denial Review Section is not displayed",
                    TestUtils.isElementVisible(driver,adminDenialReviewSection));
        else
            Assert.assertFalse("Admin Denial Review Section is displayed",
                    TestUtils.isElementVisible(driver,adminDenialReviewSection));
    }

    public void validateQueueInSummarySection(String queue){
        TestUtils.waitForNotBusy(driver);
        TestUtils.waitElementClickable(driver,By.xpath(panelExpandString.replace("{SectionName}","Summary")));
        TestUtils.safeClick(driver,By.xpath(panelExpandString.replace("{SectionName}","Summary")));
        Assert.assertTrue(TestUtils.isElementVisible(driver,sumamryWorkQueueName.replace("{queueName}",queue)));
    }

    public void validateAdminDenialReason(Map<String, String> pf){
        Assert.assertTrue("Admin Denial reason does not match the comment entered on Request Details page for Admin Denial Review",
                pf.get("rdptadminDenialReviewComment").equals(getAdminDenialReviewReason()));
    }





    /**
     * clicking submit button on add approval modal
     */
    public void clickSubmit() {
        TestUtils.click(driver, submitButton);
    }


    /**
     * Entering NumberOfWeeks
     *
     * @param numOfWeeks
     * @return
     */
    public ViewAuthPage enterNumberOfWeeks(String numOfWeeks) {
        log.warn("Entering " + numOfWeeks);
        TestUtils.input(driver,numberOfWeeks,numOfWeeks);
        return this;
    }
    /**
     * Entering NumberOfWeeks
     *
     * @param numOfVisits
     * @return
     */
    public ViewAuthPage enterNumberOfVisits(String numOfVisits) {
        log.warn("Entering " + numOfVisits);
        TestUtils.input(driver,numberOfVisits,numOfVisits);
        return this;
    }
    /**
     * Entering TreatmentStartDate
     *
     * @param startDate
     * @return
     */
    public ViewAuthPage enterTreatmentStartDate(String startDate) {
        log.warn("Entering " + startDate);
        TestUtils.input(driver,treatmentStartDate,startDate);
        return this;
    }
    /**
     * Entering TreatmentEndDate
     *
     * @param endDate
     * @return
     */
    public ViewAuthPage enterTreatmentEndDate(String endDate) {
        log.warn("Entering " + endDate);
        TestUtils.highlightElement(driver, treatmentEndDate);
        TestUtils.input(driver,treatmentEndDate,endDate);
        return this;
    }

    /**
     * Selecting category
     * @param category
     * @return
     */
    public ViewAuthPage enterCategory(String category) {
        log.warn("Entering " + category);
        TestUtils.select(driver, categoryDD, category);
        return this;
    }

    /**
     * Selecting response
     * @param response
     * @return
     */
    public ViewAuthPage enterResponse(String response) {
        log.warn("Entering " + response);
        TestUtils.wait(2);
        TestUtils.select(driver, responseDD, response);
        return this;
    }

    /**
     * Selecting MD
     * @param md
     */
    public void selectingMD(String md, String comments) {
        log.warn("selecting " + md);
        TestUtils.select(driver, selectMD, md);
        TestUtils.input(driver, mdReviewComments, comments);
        TestUtils.click(driver,reassignMDButton);
    }

    /**
     * by passing MD
     */
    public void bypassMD() {
        log.warn("by passing MD");
        TestUtils.click(driver, byPassLink);

    }

    /**
     * verifying comments on notes section
     * @param comment
     */
    public void verifyComments(String comment) {
        String actualMessage = TestUtils.text(driver, By.xpath("(//span[@class='noteHeaderTable ng-binding'])[1]"));
        Assert.assertEquals(comment, actualMessage);
    }
}
