package atdd.test.pageobjects.utilizationManagement;

import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.util.*;

public class WorkQueueMaintenancePage {

    private static Logger log = Logger.getLogger(WorkQueueMaintenancePage.class);
    private WebDriver driver;

    public static String resultTableXpath = "//table[@id='workQueueMaintenanceTableID']";
    public static String filterTableXpath = "//form[@name='workQueueMaintenanceTableFormtableFilters']//table";
    public static By addWorkQueue = By.xpath("//span[@class='tableActions ng-scope']/a");
    public static By recordsPerPageSelect = By.xpath("//div[@class='pagination ng-scope']/ul/li[2]/select");
    public static By homeBreadCrum = By.xpath("//ul[@class='oui-crum']/li/a");
    public static By pageBreadCrum = By.xpath("//ul[@class='oui-crum']/li[2]/span");
    public static By nameSearch = By.xpath("//input[@id='workQueueMaintenanceTable-tableFilters-name-0']");
    public static By descriptionSearch = By.xpath("//input[@id='workQueueMaintenanceTable-tableFilters-description-0']");
    public static By statusSearch = By.xpath("//select");
    public static By searchButton = By.xpath("//input[@value='Search']");
    public static By clearButton = By.xpath("//input[@value='Clear']");


    /*Page Constructor*/
    public WorkQueueMaintenancePage(WebDriver driver) {
        this.driver = driver;
    }

    /*This method clicks on +Add Work Queue*/
    public void clickOnAddWorkQueue() {
        log.warn("Clicking on add work queue");
        TestUtils.safeClick(driver, addWorkQueue);
    }

    public void validateTableHeader(List<String> expectedHeader) {
        List<WebElement> headerElements = driver.findElements(By.xpath("//table[@id='workQueueMaintenanceTableID']/thead/tr/td"));
        for (int i = 0; i < expectedHeader.size(); i++) {
            Boolean value = headerElements.get(i).getText().contains(expectedHeader.get(i));
            Assert.assertTrue("expected and actual doesn't match at index " + i, value);
        }
    }


    /*
     * Validate the records per drop down
     * @param defaultValue, dropDownOptions
     * */
    public void validateRecordsPerPageDropDown(String defaultValue, List<String> dropDownOptions) {
        Select sel = new Select(driver.findElement(recordsPerPageSelect));
        //check the default record value
        Assert.assertTrue(defaultValue + " is not expected default value", sel.getFirstSelectedOption().getText().equals(defaultValue));
        // check the list options in dropdown
        List<WebElement> listOfOption = sel.getOptions();
        for (int i = 0; i < listOfOption.size(); i++) {
            Assert.assertTrue("List of options displayed doesnot match for records per page", listOfOption.get(i).getText().equalsIgnoreCase(dropDownOptions.get(i)));
        }
    }

    /*
     * Navigate to last page of table
     * @param pageTONavigate
     * */
    public void tablePageNavigation(String pageToNavigate) {
        log.warn("User Navigating to " + pageToNavigate + " page");
        String str = pageToNavigate;
        driver.findElement(By.xpath("//li[@class='" + str.toLowerCase() + "']"));
    }

    /*
     * Select the last record on table
     * return record
     * */
    public List<String> getLastRecordOnWorkQueuePage() {
        //Get the number of rows present on page
        TestUtils.wait(3);
        List<WebElement> tableColumn = driver.findElements(By.xpath("//tr[@class='ocmTableRow ng-scope']"));
        int numberOfRows = tableColumn.size();
        //Get the respective values and store in a list
        List<String> actualValue = new ArrayList<String>();
        for (int i = 3; i <= 5; i++) {
            actualValue.add(driver.findElement(By.xpath("//table[@id='workQueueMaintenanceTableID']/tbody" +
                    "/tr[" + numberOfRows + "]/td[" + i + "]")).getText());
        }
        return actualValue;
    }

    /*
     * Validating breadcrums
     * */
    public void validateBreadcrum() {
        log.warn("Validating breadcrum");
        Assert.assertTrue("Home link not displayed in pagination", driver.findElement(homeBreadCrum).getText().equals("Home"));
        Assert.assertTrue("Page text not displayed in pagination", driver.findElement(pageBreadCrum).getText().equals("Work Queue Maintenance"));

    }

    /*
     * Click on last work queue edit icon
     * */
    public void clickOnLastEditIcon() {
        log.warn("Clicking on the first edit icon");
        List<WebElement> tableColumn = driver.findElements(By.xpath("//tr[@class='ocmTableRow ng-scope']"));
        int numberOfRows = tableColumn.size();
        log.warn("No of Rows displayed on UI is " + numberOfRows);
        Assert.assertTrue("Element not found, check the records table",
                driver.findElement(By.xpath("(//span[@class='ocm-action cux-icon-edit ng-scope'])[" + numberOfRows + "]")).isDisplayed());
        driver.findElement(By.xpath("(//span[@class='ocm-action cux-icon-edit ng-scope'])[" + numberOfRows + "]")).click();
    }

    /*
     * This method returs the id of last work on the page
     * return lastWorkQueueID
     * */
    public String getLastWorkQueueID() {
        //Get the number of rows present on page
        List<WebElement> tableColumn = driver.findElements(By.xpath("//tr[@class='ocmTableRow ng-scope']"));
        int numberOfRows = tableColumn.size();
        String lastWorkQueueID = driver.findElement(By.xpath("//table[@id='workQueueMaintenanceTableID']/tbody" +
                "/tr[" + numberOfRows + "]/td[2]")).getText();
        return lastWorkQueueID;
    }

    /*
     * This method searches for work queue w.r.t to the
     * value given by the user
     * @param searchValue
     * */
    public void searchWorkQueue(HashMap<String, String> searchValue) {
        if (searchValue.containsKey("Name")) {
            String name = searchValue.get("Name");
            driver.findElement(nameSearch).sendKeys(name);
        }
        if (searchValue.containsKey("Description")) {
            String description = searchValue.get("Description");
            driver.findElement(descriptionSearch).sendKeys(description);
        }
        if (searchValue.containsKey("Status")) {
            String status = searchValue.get("Status");
            driver.findElement(statusSearch).sendKeys(status);
        }

    }

    /*
     *
     * This method validates whether the entry is available on the
     * on the table or not
     * @param validationInput
     * */

    public void validateTable(Map<String, String> validationInput) {
        //get all the name records from UI
        List<WebElement> nameRecords = new ArrayList<>();
        nameRecords = driver.findElements(By.xpath("//table[@id='workQueueMaintenanceTableID']/tbody/tr/td[3]"));
        // get all the description records from UI and validate
        List<WebElement> descriptionRecords = new ArrayList<>();
        nameRecords = driver.findElements(By.xpath("//table[@id='workQueueMaintenanceTableID']/tbody/tr/td[4]"));
        //get all the status details from the UI
        List<WebElement> statusRecords = new ArrayList<>();
        nameRecords = driver.findElements(By.xpath("//table[@id='workQueueMaintenanceTableID']/tbody/tr/td[5]"));
        //validate that name/description and status contains only the text(name / description contains function and status exact text function) entered
        Set<Map.Entry<String, String>> validationValue = validationInput.entrySet();
        for (Map.Entry<String, String> map : validationValue) {
            String value = map.getValue();
            switch (value) {
                case "Status":
                    for (int i = 0; i < statusRecords.size(); i++) {
                        if (!nameRecords.get(i).getText().equals(validationInput.get("Status"))) {
                            Assert.fail("Expected string does not match status");
                        }
                    }
                case "Name":
                    for (int i = 0; i < nameRecords.size(); i++) {
                        if (!nameRecords.get(i).getText().contains(validationInput.get("Name"))) {
                            Assert.fail("Expected string does not match status");
                        }
                    }
                case "Description":
                    for (int i = 0; i < descriptionRecords.size(); i++) {
                        if (!nameRecords.get(i).getText().contains(validationInput.get("Description"))) {
                            Assert.fail("Expected string does not match status");
                        }
                    }
            }
        }
    }

    public void clickSearchButton() {
        TestUtils.click(driver, searchButton);
    }

    public void clickClearButton() {
        TestUtils.click(driver, clearButton);
    }

    public void clickEditIcon(int row) {
        String f = "%s//tbody/tr/td[%d]/span";
        String xpath = String.format(f, resultTableXpath, row);
        TestUtils.click(driver, By.xpath(xpath));
    }

}
