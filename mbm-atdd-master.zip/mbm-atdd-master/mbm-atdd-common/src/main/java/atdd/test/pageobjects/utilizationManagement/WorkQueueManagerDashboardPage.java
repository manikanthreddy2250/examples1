package atdd.test.pageobjects.utilizationManagement;

import atdd.common.ScenarioLogger;
import atdd.test.pageobjects.utilizationManagement.pageValueObject.*;
import atdd.utils.StringUtils;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class WorkQueueManagerDashboardPage {

    public static String unassignedTileXpath = "//div[./div[@class='title']/span[contains(., 'Unassigned')]]";
    public static String assignedTileXpath = "//div[./div[@class='title']/span[contains(., 'Assigned')]]";

    private ScenarioLogger scenarioLogger;
    private Scenario scenario;

    public static String widgetXpath(String widget) {
        return "//div[contains(@ng-click,'selectSection(') and contains(., '" + widget + "')]";
    }

    private static Logger log = Logger.getLogger(WorkQueueManagerDashboardPage.class);
    private WebDriver driver = null;

    /*Page Constructor*/
    public WorkQueueManagerDashboardPage(WebDriver driver) {
        this.driver = driver;
    }

    public PvoWorkQueueManagerDashboard collect() {
        PvoWorkQueueManagerDashboard result = new PvoWorkQueueManagerDashboard();

        result.setPastDue(collect("Past Due"));
        result.setDue24(collect("Due in 24 hours"));
//        Out of scope - 2/27
//        result.setDue48(collect("Due in 48 hours"));
        result.setAllOpenAuthorizations(collect("All Open Authorizations"));

        return result;
    }

    public PvoWorkQueueManagerDashboardWidget collect(String widget) {
        PvoWorkQueueManagerDashboardWidget pvoWorkQueueManagerDashboard = new PvoWorkQueueManagerDashboardWidget();
        pvoWorkQueueManagerDashboard.setWidget(widget);

        String targetWidgetXpath = widgetXpath(widget);
        TestUtils.click(driver, By.xpath(targetWidgetXpath));
        TestUtils.demoBreakPoint(this.scenario, driver, widget);

        {
            String currWidget = "Past Due";
            String widgetXpath = widgetXpath(currWidget);
            String s = TestUtils.simpleContent(driver.findElement(By.xpath(widgetXpath + "//h1")));
            Integer total = StringUtils.tryParseIntOrNull(s);
            pvoWorkQueueManagerDashboard.setPastDue(total);
            if (widget.equals(currWidget)) {
                pvoWorkQueueManagerDashboard.setTotal(total);
            }
        }
        {
            String currWidget = "Due in 24 hours";
            String widgetXpath = widgetXpath(currWidget);
            String s = TestUtils.simpleContent(driver.findElement(By.xpath(widgetXpath + "//h1")));
            Integer total = StringUtils.tryParseIntOrNull(s);
            pvoWorkQueueManagerDashboard.setDue24(total);
            if (widget.equals(currWidget)) {
                pvoWorkQueueManagerDashboard.setTotal(total);
            }
        }
//        Out of scope - 2/27
//        {
//            String currWidget = "Due in 48 hours";
//            String widgetXpath = widgetXpath(currWidget);
//            String s = TestUtils.simpleContent(driver.findElement(By.xpath(widgetXpath + "//h1")));
//            Integer total = StringUtils.tryParseIntOrNull(s);
//            pvoWorkQueueManagerDashboard.setDue48(total);
//            if (widget.equals(currWidget)) {
//                pvoWorkQueueManagerDashboard.setTotal(total);
//            }
//        }
        {
            String currWidget = "All Open Authorizations";
            String widgetXpath = widgetXpath(currWidget);
            String s = TestUtils.simpleContent(driver.findElement(By.xpath(widgetXpath + "//h1")));
            Integer total = StringUtils.tryParseIntOrNull(s);
            pvoWorkQueueManagerDashboard.setAllOpenAuthorizations(total);
            if (widget.equals(currWidget)) {
                pvoWorkQueueManagerDashboard.setTotal(total);
            }
        }

        pvoWorkQueueManagerDashboard.setUnassignedList(collectUnassigned());

        pvoWorkQueueManagerDashboard.setAssignedList(collectAssigned());

        return pvoWorkQueueManagerDashboard;
    }

    private PvoWorkQueueManagerDashboardAssignedList collectAssigned() {
        PvoWorkQueueManagerDashboardAssignedList pvoWorkQueueManagerDashboardAssignedList = new PvoWorkQueueManagerDashboardAssignedList();

        String tileXpath = assignedTileXpath;

        // setTotal, setUrgent, setMdReviews
        List<WebElement> headers = driver.findElements(By.xpath(tileXpath + "//div[@class='summary']/*"));
        pvoWorkQueueManagerDashboardAssignedList.setTotal(extractCount(headers.get(1)));
        pvoWorkQueueManagerDashboardAssignedList.setUrgent(extractCount(headers.get(2)));
        pvoWorkQueueManagerDashboardAssignedList.setMdReviews(extractCount(headers.get(3)));

        // setUnassignedRowList
        Map<String, PvoWorkQueueManagerDashboardAssignedRow> assignedRowList = new LinkedHashMap<>();
        String rowsXpath = tileXpath + "//div[@class='list']/div[contains(@class, 'row')]";
        List<WebElement> rows = driver.findElements(By.xpath(rowsXpath));
        for (WebElement row : rows) {
            List<WebElement> cols = row.findElements(By.xpath("./*"));
            PvoWorkQueueManagerDashboardAssignedRow assignedRow = new PvoWorkQueueManagerDashboardAssignedRow();
            String userFullName = TestUtils.simpleContent(cols.get(0));
            assignedRow.setUserFullName(userFullName);
            assignedRow.setTotal(extractCount(cols.get(1)));
            assignedRow.setUrgent(extractCount(cols.get(2)));
            assignedRow.setMdReviews(extractCount(cols.get(3)));
            assignedRowList.put(userFullName, assignedRow);
        }
        pvoWorkQueueManagerDashboardAssignedList.setAssignedRowList(assignedRowList);

        return pvoWorkQueueManagerDashboardAssignedList;
    }

    private PvoWorkQueueManagerDashboardUnassignedList collectUnassigned() {
        PvoWorkQueueManagerDashboardUnassignedList pvoWorkQueueManagerDashboardUnassignedList = new PvoWorkQueueManagerDashboardUnassignedList();

        String tileXpath = unassignedTileXpath;

        // setTotal
        List<WebElement> headers = driver.findElements(By.xpath(tileXpath + "//div[@class='summary']/*"));
        pvoWorkQueueManagerDashboardUnassignedList.setTotal(extractCount(headers.get(1)));

        // setUnassignedRowList
        Map<String, PvoWorkQueueManagerDashboardUnassignedRow> unassignedRowList = new LinkedHashMap<>();
        String rowsXpath = tileXpath + "//div[@class='list']/div[contains(@class, 'row')]";
        List<WebElement> rows = driver.findElements(By.xpath(rowsXpath));
        for (WebElement row : rows) {
            List<WebElement> cols = row.findElements(By.xpath("./*"));
            PvoWorkQueueManagerDashboardUnassignedRow unassignedRow = new PvoWorkQueueManagerDashboardUnassignedRow();
            String queueName = TestUtils.simpleContent(cols.get(0));
            unassignedRow.setQueueName(queueName);
            unassignedRow.setTotal(extractCount(cols.get(1)));
            unassignedRowList.put(queueName, unassignedRow);
        }
        pvoWorkQueueManagerDashboardUnassignedList.setUnassignedRowList(unassignedRowList);

        return pvoWorkQueueManagerDashboardUnassignedList;
    }

    private Integer extractCount(WebElement el) {
        try {
            String sTotal = TestUtils.simpleContent(el).trim();
            if (sTotal.contains("(") && sTotal.contains(")")) {
                int pl = sTotal.indexOf('(');
                int pr = sTotal.indexOf(')');
                return Integer.parseInt(sTotal.substring(pl + 1, pr));
            } else {
                return Integer.parseInt(sTotal);
            }
        } catch (Exception e) {
            return null;
        }
    }

    public void setScenarioLogger(ScenarioLogger scenarioLogger) {
        this.scenarioLogger = scenarioLogger;
        this.scenario = scenarioLogger.getScenario();
    }
}
