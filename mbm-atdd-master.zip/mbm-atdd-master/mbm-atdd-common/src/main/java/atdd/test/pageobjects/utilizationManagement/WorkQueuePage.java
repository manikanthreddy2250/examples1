package atdd.test.pageobjects.utilizationManagement;

import atdd.common.ICondition;
import atdd.utils.TestUtils;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.List;

public class WorkQueuePage {

    public static final String WORK_QUEUE_ITEMS_TABLE_XPATH = "//table[@id='workQueueItemsTableID']";

    public static final String workQueueSearchFormXpath = "//form[@name='workQueueSearchForm']";

    public static final By assignedToLabel = By.xpath(workQueueSearchFormXpath + "//label[contains(.,'Assigned To') and not(contains(., 'Queue'))]");
    public static final By assignedToMeRadioButton = By.xpath(workQueueSearchFormXpath + "//input[@name='Assigned To Type' and @value='sessionUser']");
    public static final By assignedToAnotherUserRadioButton = By.xpath(workQueueSearchFormXpath + "//input[@name='Assigned To Type' and @value='anotherUser']");
    public static final By assignedToQueueRadioButton = By.xpath(workQueueSearchFormXpath + "//input[@name='Assigned To Type' and @value='workQueue']");

    public static final By assignedToUserLabel = By.xpath(workQueueSearchFormXpath + "//label[contains(.,'Assigned To User')]");
    public static final By assignedToUserTypeAhead = By.xpath(workQueueSearchFormXpath + "//*[(name()='ocm:typeahead' or name()='ocm-typeahead') and @id='workQueueSearchUser']");
    public static final By assignedToUserTextBox = By.xpath(workQueueSearchFormXpath + "//*[(name()='ocm:typeahead' or name()='ocm-typeahead') and @id='workQueueSearchUser']/input");
    public static final By assignedToUserDropdown = By.xpath(workQueueSearchFormXpath + "//*[(name()='ocm:typeahead' or name()='ocm-typeahead') and @id='workQueueSearchUser']/ul");

    public static final By assignedToQueueLabel = By.xpath(workQueueSearchFormXpath + "//label[contains(.,'Assigned To Queue')]");
    public static final By assignedToQueueTypeAhead = By.xpath(workQueueSearchFormXpath + "//*[(name()='ocm:typeahead' or name()='ocm-typeahead') and @id='workQueueSearchQueue']");
    public static final By assignedToQueueTextBox = By.xpath(workQueueSearchFormXpath + "//*[(name()='ocm:typeahead' or name()='ocm-typeahead') and @id='workQueueSearchQueue']/input");
    public static final By assignedToQueueDropdown = By.xpath(workQueueSearchFormXpath + "//*[(name()='ocm:typeahead' or name()='ocm-typeahead') and @id='workQueueSearchQueue']/ul");

    public static final By stateOfResidenceLabel = By.xpath(workQueueSearchFormXpath + "//label[contains(.,'SOR')]");
    public static final By stateOfResidenceButton = By.xpath(workQueueSearchFormXpath + "//button[@id='btn-stateOfResidence']");
    public static final By stateOfResidenceSelection = By.xpath(workQueueSearchFormXpath + "//span[@id='stateOfResidence']");

    public static final By reviewPriorityLabel = By.xpath(workQueueSearchFormXpath + "//label[contains(.,'Review Priority')]");
    public static final By reviewPrioritySelect = By.xpath(workQueueSearchFormXpath + "//select[@id='workQueueSearchFilters-reviewPriority-0']");
    public static final By reviewPriorityOptionStandard = By.xpath(workQueueSearchFormXpath + "//option[@value=1]");
    public static final By reviewPriorityOptionUrgent = By.xpath(workQueueSearchFormXpath + "//option[@value=2]");

    public static final By filterButton = By.xpath(workQueueSearchFormXpath + "//input[@value='Filter']");
    public static final By clearButton = By.xpath(workQueueSearchFormXpath + "//input[@value='Clear']");

    public static final By recordsPerPage = By.xpath("//select[@ng-model='workQueueItemsTable.pagination.recordsPerPage']");
    public static final By assignSelectedButton = By.xpath("//input[@value='Assign Selected']");
    public static final By selectAllButton = By.xpath("//*[@id='selectAllAssignments']");
    public static final By refreshLink = By.xpath("//a[.='Refresh Page']");
    public static final By EditAssignmentLink = By.xpath("//a[.='Edit Assignment']");

    public static final By sorTkMultiSel = By.xpath("//span[@ng-model='workQueueSearchFilters.stateOfResidence']");
    public static final By assignmentDueDateSelect = By.xpath("//select[@ng-model='workQueueSearchFilters.assignmentDueDate']");
    public static final By dateOfServiceSelect = By.xpath("//select[@ng-model='workQueueSearchFilters.dateOfService']");
    public static final By tatDueDateInput = By.xpath("//input[@ng-model='workQueueSearchFilters.tatDueDate']");
    public static final By assignmentTypeSelect = By.xpath("//select[@ng-model='workQueueSearchFilters.assignmentType']");

    public static String showAdvancedLinkXpath = "//a[text()='Show Advanced']";
    public static String hideAdvancedLinkXpath = "//a[text()='Hide Advanced']";

    public static final By checkBoxOnWorkQueuePage(String row) {
        return By.xpath("//tbody[@class='ng-scope']//tr[1]//td[1]//input[" + row + "]");
    }

    private static Logger log = Logger.getLogger(WorkQueuePage.class);
    private WebDriver driver;

    /*Page Constructor*/
    public WorkQueuePage(WebDriver driver) {
        this.driver = driver;
    }

    public void clickActionIconByMemberName(String memberName) {
        TestUtils.wait(2);
        String xpath = "(//td[.='" + memberName + "']/preceding-sibling::td[12]/span)[1]";
        TestUtils.safeClick(driver, By.xpath(xpath));

        Assert.assertTrue(ViewAuthPage.waitForViewAuthPageLoaded(driver));
    }

    public void clickActionIconByRow(int row) {
        String xpath = WORK_QUEUE_ITEMS_TABLE_XPATH + "/tbody/tr[" + row + "]/td[2]/span[1]";
        TestUtils.safeClick(driver, By.xpath(xpath));

        Assert.assertTrue(ViewAuthPage.waitForViewAuthPageLoaded(driver));
    }

    public void clickCloseIconByMemberName(String memberName) {
        String xpath = "(//td[.='" + memberName + "']/preceding-sibling::td[10]/span)[2]";
        TestUtils.safeClick(driver, By.xpath(xpath));
    }

    public void clickActionIconByReferenceNumber(String requestNumber) {
        Assert.assertTrue(navigateToPageWithRequestNumber(requestNumber));
        String xpath="//span[contains(text(),'"+requestNumber+"')]/parent::td/preceding-sibling::td/span[@ng-click='workQueueItemsTable.autoAssignment(record)']";
        TestUtils.safeClick(driver, By.xpath(xpath));
        ViewAuthPage.waitForViewAuthPageLoaded(driver);
    }


    public void showPerPage(String option) {
        TestUtils.select(driver, recordsPerPage, option);
        TestUtils.wait(3);
    }

    public void selectPage(String pageNumber) {
        TestUtils.click(driver, By.xpath("//li[@ng-click='workQueueItemsTable.setPage(pageNumber)']/a[.=" + pageNumber + "]"));
        TestUtils.wait(3);
    }

    public void clickAssignSelectedButton() {
        TestUtils.clickUntil(driver, assignSelectedButton, new ICondition() {
            @Override
            public boolean evaluate() throws Exception {
                return TestUtils.isElementVisible(driver, BulkAssignPopupPage.assignedToMeRadioButtonPopup);
            }
        });
    }

    public void selectAllAssignment() {
        TestUtils.click(driver, selectAllButton);
        TestUtils.wait(2);
    }

    public List<String> unassignedWorkQueue() {
        TestUtils.wait(2);
        List<WebElement> listOFQueuesEle = driver.findElements(By.xpath("//*[@id='workQueueItemsTableID']/tbody/tr/td[13]"));
        List<String> listOFQueues = new ArrayList<String>();
        for (int i = 0; i < listOFQueuesEle.size(); i++) {
            listOFQueues.add(listOFQueuesEle.get(i).getText());
        }
        //driver.findElement(selectAllButton).click();
        return listOFQueues;
    }

    public void slectAllQueueItems() {
        TestUtils.click(driver, selectAllButton);
    }

    public void validateMyWorkQueueAssigned(List<String> expectedQueue, List<String> actualQueue) {

        for (int i = 0; i < expectedQueue.size(); i++) {
            for (int j = 0; j < actualQueue.size(); j++) {
                if (actualQueue.get(i).equals(expectedQueue.get(i))) {

                }
            }
        }

    }

    public Boolean compareAssignedAndUnassignedQueues(List<String> expectedQueue, List<String> actualQueue) {
        Boolean flag = false;
        for (int i = 0; i < expectedQueue.size(); i++) {
            if (!actualQueue.contains(expectedQueue.get(i))) {
                Assert.fail();
            }
            flag = true;
        }
        return flag;
    }

    public void userSearchForAssignedByForWorkQueue() {
        driver.findElement(By.xpath("//*[@id='workQueueSearchFilters-owner-0']")).sendKeys(Keys.RETURN);
    }

    /**
     * Click the sort icon on the specified header.
     *
     * @param header
     */
    public void clickSortIcon(String header) {
        By sortIcon = By.xpath(WORK_QUEUE_ITEMS_TABLE_XPATH + "/thead/tr/td[contains(.,'" + header + "')]/span[@title='Sort']");
        TestUtils.safeClick(driver, sortIcon);
        TestUtils.wait(5);
    }


    public void clickEditICOn() {
        By editIcon = By.xpath("//span[@title='Edit']");
        driver.findElement(editIcon).click();
    }

    public void ClicksOnCheckBoxOnWorkQueuePageForRow(String row) {
        TestUtils.wait(2);
        By by = checkBoxOnWorkQueuePage(row);
        if (!TestUtils.isChecked(driver, by))
            TestUtils.click(driver, by);
    }

    public void selectByRequestNumber(String requestNumber) {
        Assert.assertTrue(navigateToPageWithRequestNumber(requestNumber));
        String xpath = "//td[.='" + requestNumber + "']/preceding-sibling::td[6]/input";
        List<WebElement> els = TestUtils.findElements(driver, xpath);
        for (final WebElement el : els) {
            Assert.assertTrue(TestUtils.clickUntil(driver, el, new ICondition() {
                @Override
                public boolean evaluate() throws Exception {
                    return TestUtils.isChecked(el);
                }
            }));
        }
    }

    public boolean navigateToPageWithRequestNumber(String requestNumber) {
        String td = "//td[.='" + requestNumber + "']";
        return TestUtils.clickUntil(driver, By.xpath("//a[text()='Next']"), new ICondition() {
            @Override
            public boolean evaluate() throws Exception {
                return TestUtils.waitElementVisible(driver, td, 10);
            }
        });
    }
}




