package atdd.test.pageobjects.utilizationManagement.pageValueObject;

import atdd.utils.AssertUtils;

import java.util.Map;

public class PvoWorkQueueManagerDashboardAssignedList {
    private Integer total;
    private Integer urgent;
    private Integer mdReviews;
    private Map<String, PvoWorkQueueManagerDashboardAssignedRow> assignedRowList;

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }

    public Integer getUrgent() {
        return urgent;
    }

    public void setUrgent(Integer urgent) {
        this.urgent = urgent;
    }

    public Integer getMdReviews() {
        return mdReviews;
    }

    public void setMdReviews(Integer mdReviews) {
        this.mdReviews = mdReviews;
    }

    public Map<String, PvoWorkQueueManagerDashboardAssignedRow> getAssignedRowList() {
        return assignedRowList;
    }

    public void setAssignedRowList(Map<String, PvoWorkQueueManagerDashboardAssignedRow> assignedRowList) {
        this.assignedRowList = assignedRowList;
    }

    public void appendHealthyIssues(StringBuilder healthyIssues) {
        healthyIssues.append("\n");

        SumsContainer sumsContainer = this.getSumsContainer();
        healthyIssues.append(AssertUtils.assertEquals(this.getTotal(), sumsContainer.totalSum) + "\n");
//        healthyIssues.append(AssertUtils.assertEquals(this.getUrgent(), sumsContainer.urgentSum) + "\n");
        healthyIssues.append(AssertUtils.assertEquals(this.getMdReviews(), sumsContainer.mdReviewsSum) + "\n");

        if (!healthyIssues.toString().trim().isEmpty()) {
            healthyIssues.append("\n\tAbove messages are from " + PvoWorkQueueManagerDashboardWidget.class + "\n\t");
        }

        healthyIssues.append("\n");
    }

    private SumsContainer getSumsContainer() {
        SumsContainer sumsContainer = new SumsContainer();
        for (String queueName : this.getAssignedRowList().keySet()) {
            Integer rowTotal = this.getAssignedRowList().get(queueName).getTotal();
            if (null != sumsContainer.totalSum) {
                if (null == rowTotal) {
                    sumsContainer.totalSum = null;
                } else {
                    sumsContainer.totalSum += rowTotal;
                }
            }
            Integer rowUrgent = this.getAssignedRowList().get(queueName).getUrgent();
            if (null != sumsContainer.urgentSum) {
                if (null == rowUrgent) {
                    sumsContainer.urgentSum = null;
                } else {
                    sumsContainer.urgentSum += rowUrgent;
                }
            }
            Integer rowMdReviews = this.getAssignedRowList().get(queueName).getMdReviews();
            if (null != sumsContainer.mdReviewsSum) {
                if (null == rowMdReviews) {
                    sumsContainer.mdReviewsSum = null;
                } else {
                    sumsContainer.mdReviewsSum += rowMdReviews;
                }
            }
        }
        return sumsContainer;
    }

    private class SumsContainer {
        public Integer totalSum = 0;
        public Integer urgentSum = 0;
        public Integer mdReviewsSum = 0;
    }
}
