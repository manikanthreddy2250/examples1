package atdd.test.stepdefinitions;

import atdd.common.*;
import atdd.common.ui.SlowBy;
import atdd.dao.mbm.HscDao;
import atdd.dao.mbm.MyBatisConnectionFactory;
import atdd.dao.mbm.MyBatisConnectionFactoryMbmShared;
import atdd.dao.mbm.UserTblDao;
import atdd.test.core.CsqaManager;
import atdd.test.core.TeamBase;
import atdd.test.core.TeamFactory;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.pageobjects.authorization.*;
import atdd.test.pageobjects.authorization.physicalHealth.*;
import atdd.test.pageobjects.priorAuthSearch.PriorAuthorizationSearchSubmittedPage;
import atdd.test.stepsets.*;
import atdd.test.stepsets.auth.RequestStatusPageWorker;
import atdd.utils.*;
import com.hierynomus.msdtyp.AccessMask;
import com.hierynomus.mssmb2.SMB2CreateDisposition;
import com.hierynomus.mssmb2.SMB2ShareAccess;
import com.hierynomus.smbj.SMBClient;
import com.hierynomus.smbj.auth.AuthenticationContext;
import com.hierynomus.smbj.connection.Connection;
import com.hierynomus.smbj.session.Session;
import com.hierynomus.smbj.share.DiskShare;
import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

import static atdd.test.stepsets.AuthorizationRequest.AUTHORIZATION_OBJECT_NAME;

public class CommonSetStepDefinition {
    public static final Logger log = Logger.getLogger(CommonSetStepDefinition.class.getName());
    private static final String COOKIE_KEY = "Cookie";
    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }

    /**
     * A profile based universal login step
     */
    @Given("^user login$")
    public void userLogin() throws Throwable {
        userLoginWith(null);
    }

    /**
     * A profile based universal login step
     */
    @Given("^user login with \"([^\"]*)\"$")
    public void userLoginWith(String stringMap) throws Throwable {
        Map<String, String> map = new LinkedHashMap<>(0);
        if (!StringUtils.isEmpty(stringMap)) {
            stringMap = WhiteBoard.resolve(owner, stringMap);
            map = DataTableUtils.asMap(stringMap);
        }
        Map<String, String> pf = ExcelLib.completeProfile(owner, map);
        boolean success = new Retry("userLogin") {
            @Override
            protected void tryOnce() throws Throwable {
                WebDriver d = Login.login(scenario, pf);
            }

            @Override
            protected long getTimeoutMillis() {
                // 5 minutes
                return 5 * 60 * 1000;
            }
        }.execute();
        if (!success) {
            throw new RuntimeException("Timeout: " + pf);
        }
    }

    /**
     * Assumption: Add Request page is displayed.
     * Search member and select Authorization Type according to the profile.
     */

    @And("^user searches for Member and selects auth type$")
    public void userSearchesForMemberAndSelectsAuthType() throws Throwable {
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        pf.put(ExcelLib.STOP_AT_NEXT_PAGE_BEGIN, AuthorizationTypePage.class.getName());
        TeamBase team = TeamFactory.getTeam(scenario, pf);
        boolean success = team.teamwork(2 * 60 * 1000);

        if (!success) {
            throw new RuntimeException("Timeout: " + pf);
        }

    }

    /**
     * Assumption: Requesting Provider page is displayed.
     * User enters Requesting Provider Details based on pf
     *
     * @throws Throwable
     */
    @And("^User enters Requesting Provider Details$")
    public void userEntersRequestingProviderDetails() throws Throwable {
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        pf.put(ExcelLib.CONTINUE_FROM_PAGE, RequestingProviderPage.class.getName());
        pf.put(ExcelLib.STOP_AT_NEXT_PAGE_BEGIN, RequestingProviderPage.class.getName());
        TeamBase team = TeamFactory.getTeam(scenario, pf);
        boolean success = team.teamwork(2 * 60 * 1000);

        if (!success) {
            throw new RuntimeException("Timeout: " + pf);
        }
    }


    /**
     * Assumption: Servicing Provider page is displayed.
     * User enters Servicing Provider Details based on pf
     *
     * @throws Throwable
     */
    @And("^User enters Servicing Provider Details$")
    public void userEntersServicingProviderDetails() throws Throwable {
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        pf.put(ExcelLib.CONTINUE_FROM_PAGE, ServicingProviderPage.class.getName());
        pf.put(ExcelLib.STOP_AT_NEXT_PAGE_BEGIN, ServicingProviderPage.class.getName());
        TeamBase team = TeamFactory.getTeam(scenario, pf);
        boolean success = true;

        if (!success) {
            throw new RuntimeException("Timeout: " + pf);
        }
    }

    /**
     * Assumption: Request Details page is displayed.
     * User enters Request Details based on pf
     *
     * @throws Throwable
     */

    @And("^user enters Request Details$")
    public void userEntersRequestDetails() throws Throwable {
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        pf.put(ExcelLib.CONTINUE_FROM_PAGE, RequestDetailsPage.class.getName());
        pf.put(ExcelLib.STOP_AT_NEXT_PAGE_BEGIN, RequestDetailsPage.class.getName());
        TeamBase team = TeamFactory.getTeam(scenario, pf);
        boolean success = team.teamwork(2 * 60 * 1000);

        if (!success) {
            throw new RuntimeException("Timeout: " + pf);
        }
    }

    /**
     * Assumption: Clinical Status  page is displayed.
     * User enters Clinical Statu based on pf
     */
    @And("^User answers Clinical Status questions$")
    public void userAnswersClinicalStatusQuestions() throws Throwable {
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        pf.put(ExcelLib.CONTINUE_FROM_PAGE, ClinicalStatusPage.class.getName());
        pf.put(ExcelLib.STOP_AT_NEXT_PAGE_BEGIN, ClinicalStatusPage.class.getName());
        TeamBase team = TeamFactory.getTeam(scenario, pf);
        boolean success = team.teamwork(2 * 60 * 1000);

        if (!success) {
            throw new RuntimeException("Timeout: " + pf);
        }

    }

    @And("^user answers FoMs page questions$")
    public void userAnswersFoMsPageQuestions() throws LostBrowserException {
        TestUtils.wait(5);
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        pf.put(ExcelLib.CONTINUE_FROM_PAGE, FOMsPage.class.getName());
        pf.put(ExcelLib.STOP_AT_NEXT_PAGE_BEGIN, FOMsPage.class.getName());
        TeamBase team = TeamFactory.getTeam(scenario, pf);
        boolean success = team.teamwork(2 * 60 * 1000);

        if (!success) {
            throw new RuntimeException("Timeout: " + pf);
        }

    }

    @And("^user answers assessments on FoMs page$")
    public void userAnswersgFoMsPageQuestions() throws LostBrowserException {
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        pf.put(ExcelLib.CONTINUE_FROM_PAGE, FOMsPage.class.getName());
        pf.put(ExcelLib.STOP_AT_PAGE, FOMsPage.class.getName());
        TeamBase team = TeamFactory.getTeam(scenario, pf);
        boolean success = team.teamwork(2 * 60 * 1000);

        if (!success) {
            throw new RuntimeException("Timeout: " + pf);
        }

    }

    /**
     * Assumption: Regimens page is displayed.
     * Input Regimens page according to the profile.
     *
     * @throws Throwable
     */
    @And("^User selects Regimen$")
    public void userSelectsFirstRegimen() throws Throwable {
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        pf.put(ExcelLib.CONTINUE_FROM_PAGE, RegimensPage.class.getName());
        pf.put(ExcelLib.STOP_AT_NEXT_PAGE_BEGIN, RegimensPage.class.getName());
        TeamBase team = TeamFactory.getTeam(scenario, pf);
        boolean success = team.teamwork(2 * 60 * 1000);

        if (!success) {
            throw new RuntimeException("Timeout: " + pf);
        }
    }


    /**
     * Assumption: Request Summary page is displayed.
     * Extract  information from Request Summary page and stores in whiteBoard
     *
     * @param objectName
     * @throws StopAtPageException
     */
    @And("^User stores \"([^\"]*)\" object and submits auth$")
    public void userStoresObjectAndSubmitsAuth(String objectName) throws Throwable {
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        TeamBase team;
        if(objectName.equals("requestSummaryPH")){
            pf.put(ExcelLib.CONTINUE_FROM_PAGE, RequestSummaryPagePH.class.getName());
            pf.put(ExcelLib.STOP_AT_NEXT_PAGE_BEGIN, RequestSummaryPagePH.class.getName());
            team = TeamFactory.getTeam(scenario, pf);
        }else {
            pf.put(ExcelLib.CONTINUE_FROM_PAGE, RequestSummaryPage.class.getName());
            pf.put(ExcelLib.STOP_AT_NEXT_PAGE_BEGIN, RequestSummaryPage.class.getName());
            team = TeamFactory.getTeam(scenario, pf);
        }
        boolean success = team.teamwork(2 * 60 * 1000);
        Map<String, Map<String, String>> outcome = team.getOutcome();
        WhiteBoard.storeMaps(owner, objectName, Conf.getOutputPath(), outcome);

        if (!success) {
            throw new RuntimeException("Timeout: " + pf);
        }
    }

    @And("^user enters Request Details for PH$")
    public void userEntersRequestDetailsForPH() throws Throwable {
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        pf.put(ExcelLib.CONTINUE_FROM_PAGE, RequestDetailsPagePH.class.getName());
        pf.put(ExcelLib.STOP_AT_NEXT_PAGE_BEGIN, RequestDetailsPagePH.class.getName());
        TeamBase team = TeamFactory.getTeam(scenario, pf);
        boolean success = team.teamwork(2 * 60 * 1000);

        if (!success) {
            throw new RuntimeException("Timeout: " + pf);
        }
    }

    @And("^user enters patient questions$")
    public void userEntersPatientQuestions() throws Throwable {
        TestUtils.wait(5);
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        pf.put(ExcelLib.CONTINUE_FROM_PAGE, PatientQuestionsPage.class.getName());
        pf.put(ExcelLib.STOP_AT_NEXT_PAGE_BEGIN, PatientQuestionsPage.class.getName());
        TeamBase team = TeamFactory.getTeam(scenario, pf);
        boolean success = team.teamwork(2 * 60 * 1000);

        if (!success) {
            throw new RuntimeException("Timeout: " + pf);
        }
    }

    /**
     * userVerifiesAccordingToGivenTable  pf vs WhiteBoard
     *
     * @param maps
     */
    @And("^user verifies according to given table$")
    public void userVerifiesAccordingToGivenTable(List<Map<String, String>> maps) throws Throwable {
        for (Map<String, String> map : maps) {
            scenarioLogger.warn("\r\n");
            String expected0 = map.get("expected");
            String actual0 = map.get("actual");
            String expected = WhiteBoard.resolve(owner, map.get("expected"));
            String actual = WhiteBoard.resolve(owner, map.get("actual"));
            String actual1 = "";
            String actual2 = "";
            if (actual == null) {
                if (actual0.contains("authAuthorizationStatus")) {
                    actual1 = actual0.replace("authAuthorizationStatus", "authRequestStatus");
                } else if (actual0.contains("authRequestStatus")) {
                    actual1 = actual0.replace("authRequestStatus", "authAuthorizationStatus");
                }

                actual2 = WhiteBoard.resolve(owner, actual1);
                if (actual2 == null) {
                    actual = "";
                } else {
                    actual = actual2;
                }
            }
            if (null == expected) {
                expected = "";
            }
            scenarioLogger.warn("expected=[" + expected + (expected.equals(expected0) ? "]" : "] <<< " + expected0));
            scenarioLogger.warn("actual=[" + actual + (actual.equals(actual0) ? "]" : "] <<< " + actual0));

            String method = map.get("method");
            if (StringUtils.isEmpty(method)) {
                method = "equals";
            }

            String failNote = "Comparing [" + expected0 + "] vs [" + actual0 + "] using method " + method + " ...";
            switch (method) {
                case "equals":
                    Assert.assertEquals(failNote, expected.trim(), actual.trim());
                    break;
                case "notEquals":
                    Assert.assertNotEquals(failNote, expected.trim(), actual.trim());
                    break;
                case "daysAfter":
                    int days = Integer.parseInt(WhiteBoard.resolve(owner, map.get("days")));
                    String expectedDateFormat = WhiteBoard.resolve(owner, map.get("expected format"));
                    String actualDateFormat = WhiteBoard.resolve(owner, map.get("actual format"));
                    if (StringUtils.isEmpty(expectedDateFormat)) {
                        expectedDateFormat = "MM-dd-yyyy";
                    }
                    if (StringUtils.isEmpty(actualDateFormat)) {
                        actualDateFormat = "MM-dd-yyyy";
                    }
                    Date expectedDate = new SimpleDateFormat(expectedDateFormat).parse(expected);
                    Date actualDate = new SimpleDateFormat(actualDateFormat).parse(actual);
                    Assert.assertEquals(failNote, expectedDate, DateUtils.addTo(actualDate, days, Calendar.DATE));
                    break;
                default:
                    Assert.fail("Unknown method: " + method);
            }
            scenarioLogger.warn("Validation OK");
        }
    }

    /**
     * Extract and stores values from requestStatusPage in WhiteBoard based on @param objectName
     *
     * @param objectName
     */
    @And("^User stores \"([^\"]*)\" object$")
    public void userStoresObject(String objectName) throws Throwable {

        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        TeamBase team;
        if(objectName.equals("requestStatusPH")){
            pf.put(ExcelLib.CONTINUE_FROM_PAGE, RequestStatusPagePH.class.getName());
            team = TeamFactory.getTeam(scenario, pf);
        }else if(objectName.equals("requestSummaryPH")){
            pf.put(ExcelLib.CONTINUE_FROM_PAGE, RequestSummaryPagePH.class.getName());
            team = TeamFactory.getTeam(scenario, pf);
        }
        else{
            pf.put(ExcelLib.CONTINUE_FROM_PAGE, RequestStatusPage.class.getName());
            team = TeamFactory.getTeam(scenario, pf);
        }
        boolean success = team.teamwork(5 * 60 * 1000);
        Map<String, Map<String, String>> outcome = team.getOutcome();
        WhiteBoard.storeMaps(owner, objectName, Conf.getOutputPath(), outcome);

        if (!success) {
            throw new RuntimeException("Timeout: " + pf);
        }
    }

    /**
     * UserVerifiesAuthorizationOnRequestStatusPage based on WhiteBoard against pf
     */
    @And("^User verifies authorization on Request Status page$")
    public void userVerifiesAuthorizationOnRequestStatusPage() throws Throwable {
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        pf.put(ExcelLib.CONTINUE_FROM_PAGE, RequestStatusPage.class.getName());
        TeamBase team = TeamFactory.getTeam(scenario, pf);
        boolean success = team.teamwork(2 * 60 * 1000);
        Map<String, Map<String, String>> outcome = team.getOutcome();

    }

    /**
     * User add a new authorization request based on the profile
     *
     * @throws Exception
     */
    @Given("^user add a new authorization request$")
    public void userAddANewAuthorizationRequest() throws Throwable {
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        TeamBase team = TeamFactory.getTeam(scenario, pf);
        boolean success = team.teamwork(2 * 60 * 1000);
        Map<String, Map<String, String>> outcome = team.getOutcome();

        if (!success) {
            throw new RuntimeException("Timeout: " + pf);
        }
    }

    /**
     * Generic
     * User verifyMatches between UI and passing variable
     *
     * @param expressionLeft
     * @param expressionRight
     */
    @Then("^verify \"([^\"]*)\" matches \"([^\"]*)\"$")
    public void verifyMatches(String expressionLeft, String expressionRight) throws Throwable {
        String valueLeft = WhiteBoard.resolve(owner, expressionLeft);
        String valueRight = WhiteBoard.resolve(owner, expressionRight.split(" or "));
        log.warn("valueLeft=" + valueLeft);
        log.warn("valueRight=" + valueRight);
        Assert.assertEquals(valueRight.trim(), valueLeft.trim());
    }

    /**
     * Asserting globalMessages-description
     *
     * @param expectedMessage
     */
    @Then("^user receives global message \"([^\"]*)\"$")
    public void userReceivesGlobalMessage(String expectedMessage) throws Throwable {
        String actualMessage = obj().CommonPage.getGlobalMessagesDescription();
        Assert.assertEquals(expectedMessage, actualMessage);

        TestUtils.demoBreakPoint(scenario, driver(), expectedMessage);
    }

    /**
     * Authorization requests are added based on pf with retry
     *
     * @param dataTable
     */
    @Given("^below authorization requests are added$")
    public void belowAuthorizationRequestsAreAdded(DataTable dataTable) throws Throwable {
        AuthorizationRequest authorizationRequest = new AuthorizationRequest(scenario, driver());
        List<Map<String, String>> maps = dataTable.asMaps(String.class, String.class);
        if (isTransposed(maps)) {
            maps = DataTableUtils.asMutableMapsTranspose(dataTable);
        }
        maps = WhiteBoard.resolve(owner, maps);
        for (Map<String, String> map : maps) {
            String authorizationObjectName = map.get(AUTHORIZATION_OBJECT_NAME);
            if (StringUtils.isEmpty(authorizationObjectName) || authorizationObjectName.startsWith("-")) {
                continue;
            }
            authorizationRequest.addAuthWithRetry(map);
        }
    }

    private boolean isTransposed(List<Map<String, String>> maps) {
        Map<String, String> map = maps.get(0);
        int count = 0;
        if (map.containsKey(AUTHORIZATION_OBJECT_NAME)) {
            count++;
        }
        if (map.containsKey(MBM.AUTH_TITLE)) {
            count++;
        }
        if (map.containsKey(MBM.MEMB_TITLE)) {
            count++;
        }
        if (map.containsKey(MBM.RP_TITLE)) {
            count++;
        }
        if (map.containsKey(MBM.SP_TITLE)) {
            count++;
        }
        return count < 2;
    }

    /**
     * Clone and verifies DB this step does not resubmit cloned auth
     *
     * @param dataTable
     */
    @Then("^clone and verify$")
    public void cloneAndVerify(DataTable dataTable) throws Throwable {
        String output = Conf.getOutputPath();
        List<Map<String, String>> maps = DataTableUtils.asMutableMapsTranspose(dataTable);
        maps = WhiteBoard.resolve(owner, maps);
        for (Map<String, String> map : maps) {
            String to = map.get("Clone To");
            if (null != to && !to.startsWith("-")) {
                map.put(MBM.AUTH_AUTHORIZATION_TYPE, map.get(AuthorizationRequest.CLONE_TO_AUTHORIZATION_TYPE));
                Map<String, String> pf = WhiteBoard.resolve(owner, ExcelLib.completeProfile(owner, map));
                TestUtils.demoBreakPoint(scenario, driver(), "Cloning: " + pf.toString());
                WhiteBoard.getInstance().putMap(owner, to + "_" + AuthorizationRequest.OUTCOME_PROFILE, pf);

                String from = map.get("Clone From");
                String rsf = "${" + from + "_" + AuthorizationRequest.OUTCOME_REQUEST_STATUS + ".%s}";
                String hscf = "${" + from + "_" + AuthorizationRequest.OUTCOME_HSC_SNAPSHOT + ".%s}";
                String authNumber = WhiteBoard.resolve(owner, String.format(rsf, MBM.AUTH_REQUEST_NUMBER),
                        String.format(rsf, MBM.AUTH_AUTHORIZATION_NUMBER));
                String cloneMarker = WhiteBoard.resolve(owner, String.format(rsf, MBM.RPPC_FULL_NAME));
                long fromHscId = Long.parseLong(WhiteBoard.resolve(owner, String.format(hscf, "hsc-hsc_id")));

                new Retry("cloneAndVerify>" + to) {

                    private WebDriver webDriver = null;

                    @Override
                    protected void tryOnce() throws StopAtPageException, ImmediateAbortException, LostBrowserException {
                        this.webDriver = Login.login(scenario, pf);
                        AuthorizationRequest ar = new AuthorizationRequest(scenario, this.webDriver);


                        Map<String, Map<String, String>> draftOutcome = ar.cloneAuth(
                                authNumber,
                                map.get("Clone on Page"),
                                map.get("Clone To Authorization Type"),
                                map.get("Clone To Cancer"),
                                map.get("drugCode"),
                                map.get("Clone To Class"),
                                fromHscId,
                                cloneMarker, pf);
                        WhiteBoard.storeMaps(owner, to, output, draftOutcome);

                        String[] keyFiltersInclude = new String[]{
                                "cmnctTrans-.*", "hsc-.*", "hscAtr-.*", "hscDiag-.*", "hscFlowupCntc-.*",
                                "hscProvRf-.*", "hscProvRoleRf-.*", "hscProvSj-.*", "hscProvRoleSj-.*", "hscMsr-.*"
                        };
                        MapComparer diff1 = new MapComparer<String, String>(
                                WhiteBoard.getInstance().getMap(owner, from + "_" + AuthorizationRequest.OUTCOME_HSC_SNAPSHOT),
                                draftOutcome.get(AuthorizationRequest.OUTCOME_HSC_SNAPSHOT + "_from"), keyFiltersInclude);
                        MapComparer diff2 = new MapComparer<String, String>(
                                draftOutcome.get(AuthorizationRequest.OUTCOME_HSC_SNAPSHOT + "_to"),
                                draftOutcome.get(AuthorizationRequest.OUTCOME_HSC_SNAPSHOT + "_from"), keyFiltersInclude);
                        final Map<String, CompareReport> TF = diff2.bareLeft();
                        final Map<String, CompareReport> FT = diff2.bareRight();

                        scenarioLogger.warn("======================diff1=====================");
                        scenarioLogger.warn("\r\n" + CompareReport.toString(diff1.bareLeft()));
                        scenarioLogger.warn("\r\n" + CompareReport.toString(diff1.bareRight()));
                        scenarioLogger.warn("======================diff2=====================");
                        scenarioLogger.warn("\r\n" + CompareReport.toString(TF));
                        scenarioLogger.warn("\r\n" + CompareReport.toString(FT));

                        Map<String, String> featureHelper = new LinkedHashMap<>(map);
                        CompareReport.append(featureHelper, TF, "TF");
                        CompareReport.append(featureHelper, FT, "FT");
                        StringBuilder sb = new StringBuilder();
                        for (String key : featureHelper.keySet()) {
                            sb.append(key + "\t" + featureHelper.get(key) + "\r\n");
                        }
                        scenarioLogger.warn("======================feature helper=====================");
                        scenarioLogger.warn(sb.toString());
                        try {
                            String output = Conf.getOutputPath();
                            FileUtils.writeStringToFile(new File(output + System.currentTimeMillis() + "_" + to + ".txt"), sb.toString());
                        } catch (Exception e) {//do nothing
                        }

                        Set<String> tfKeySet = DataTableUtils.extractKeys(map.keySet(), "TF.*");
                        for (String table_column : tfKeySet) {
                            scenarioLogger.warn("Validating To V.S. From: " + table_column);
                            CompareReport.Status expectedStatus = null;
                            try {
                                expectedStatus = CompareReport.Status.valueOf(map.get(table_column));
                                Assert.assertNotNull(expectedStatus);
                            } catch (Exception e) {
                                Assert.fail("Missing or invalid expected status for: " + table_column);
                            }
                            CompareReport.Status actualStatus = null;
                            if (TF.containsKey(table_column.substring(2))) {
                                System.out.println(table_column.substring(2));
                                actualStatus = TF.get(table_column.substring(2)).getStatus();
                            }
                            checkCompareReportStatus(expectedStatus, actualStatus);
                            scenarioLogger.warn("OK: " + (TF.get(table_column.substring(2)) == null ? "Not Cloned" : TF.get(table_column.substring(2))));
                        }

                        Set<String> ftKeySet = DataTableUtils.extractKeys(map.keySet(), "FT.*");
                        for (String table_column : ftKeySet) {
                            scenarioLogger.warn("Validating From V.S. To: " + table_column);
                            CompareReport.Status expectedStatus = null;
                            try {
                                expectedStatus = CompareReport.Status.valueOf(map.get(table_column));
                                Assert.assertNotNull(expectedStatus);
                            } catch (Exception e) {
                                Assert.fail("Missing or invalid expected status for: " + table_column);
                            }
                            CompareReport.Status actualStatus = null;
                            if (FT.containsKey(table_column.substring(2))) {
                                actualStatus = FT.get(table_column.substring(2)).getStatus();
                            }
                            checkCompareReportStatus(expectedStatus, actualStatus);
//                            scenarioLogger.warn("OK: " + (FT.get(table_column.substring(2)) != null ? FT.get(table_column.substring(2)).toString():"Not Cloned"));
                        }

                        for (String key : TF.keySet()) {
                            String reportedKey = "TF" + key;
                            Assert.assertTrue("Unexpected key " + reportedKey, map.containsKey(reportedKey));
                        }

                        for (String key : FT.keySet()) {
                            String reportedKey = "FT" + key;
                            Assert.assertTrue("Unexpected key " + reportedKey, map.containsKey(reportedKey));
                        }

                        TestUtils.demoBreakPoint(scenario, this.webDriver, "Validation OK");

                        pf.put(ExcelLib.CONTINUE_FROM_PAGE, RequestingProviderPage.class.getName());
                        pf.put(ExcelLib.STOP_AT_NEXT_PAGE_BEGIN, ClinicalStatusPage.class.getName());
                        TeamBase team = TeamFactory.getTeam(scenario, pf);
                        boolean success = team.teamwork(2 * 60 * 1000);

                        String note = success ? "Please review screenshots manually." : "Screenshots missing after Requesting Provider page.";
                        TestUtils.demoBreakPoint(scenario, this.webDriver, note);
                    }

                    @Override
                    protected long getTimeoutMillis() {
                        // 10 minutes
                        return 10 * 60 * 1000;
                    }

                    @Override
                    protected void timeout() {
                        String note = "Timeout: " + to;
                        TestUtils.demoBreakPoint(scenario, this.webDriver, note);
                        Assert.fail(note);
                    }

                }.execute();

            }
        }
    }

    /**
     * @param expectedStatus
     * @param actualStatus
     */
    private void checkCompareReportStatus(CompareReport.Status expectedStatus, CompareReport.Status actualStatus) {
        scenarioLogger.warn("checkCompareReportStatus: expectedStatus=" + expectedStatus + ", actualStatus=" + actualStatus);
        switch (expectedStatus) {
            case UNPREDICTABLE:
                scenarioLogger.warn("Skip unpredictable");
                break;
            case IGNORE:
                Assert.assertNull(actualStatus);
                break;
            case EQUAL:
            case MISSING:
            case NOT_EQUAL:
                Assert.assertEquals(expectedStatus, actualStatus);
                break;
            default:
                Assert.fail("Unknown expected status: " + expectedStatus);
        }
    }

    /**
     * clone auth and submit cloned auth
     *
     * @param dataTable
     */
    @Then("^clone to submit and verify")
    public void cloneToSubmitAndVerify(DataTable dataTable) throws Throwable {
        List<Map<String, String>> maps = DataTableUtils.asMutableMapsTranspose(dataTable);
        maps = WhiteBoard.resolve(owner, maps);
        for (Map<String, String> map : maps) {
            String to = map.get(AuthorizationRequest.CLONE_TO);
            if (null != to && !to.startsWith("-")) {
                AuthorizationRequest.cloneWithRetry(map, owner, scenario);
                String actualAuthStatus = AuthorizationRequest.getAuthStatus(owner, to);
                String expectedAuthStatus = map.get(MBM.AUTH_AUTHORIZATION_STATUS);
                Assert.assertEquals(expectedAuthStatus, actualAuthStatus);
            }
        }
    }

    /**
     * @param pfTitle
     * @param requestObjectName
     * @param stringDataTable
     * @throws Throwable
     */
    @And("^user adds a \"([^\"]*)\" request \"([^\"]*)\" with \"([^\"]*)\"$")
    public void userAddsARequestWith(String pfTitle, String requestObjectName, String stringDataTable) throws Throwable {
        Map<String, String> pf = new LinkedHashMap<>();
        if (!StringUtils.isEmpty(pfTitle)) {
            pf.put(MBM.AUTH_TITLE, pfTitle);
        }
        if (null != stringDataTable) {
            pf.putAll(DataTableUtils.asMap(stringDataTable));
        }

        pf = ExcelLib.completeProfile(owner, pf);
        pf.put(AUTHORIZATION_OBJECT_NAME, WhiteBoard.resolve(owner, requestObjectName));
        AuthorizationRequest authorizationRequest = new AuthorizationRequest(scenario, driver());
        authorizationRequest.addAuthWithRetry(pf);
    }

    /**
     * @param pfTitle
     * @param requestObjectName
     * @param stringDataTable
     * @param ifExpression
     * @throws Throwable
     */
    @And("^user adds a \"([^\"]*)\" request \"([^\"]*)\" with \"([^\"]*)\" if \"([^\"]*)\"$")
    public void userAddsARequestWithIf(String pfTitle, String requestObjectName, String stringDataTable, String ifExpression) throws Throwable {
        if (WhiteBoard.evaluate(owner, ifExpression)) {
            userAddsARequestWith(pfTitle, requestObjectName, stringDataTable);
        }
    }

    @And("^user adds a \"([^\"]*)\" request \"([^\"]*)\"$")
    public void userAddsARequest(String pfTitle, String requestObjectName) throws Throwable {
        this.userAddsARequestWith(pfTitle, requestObjectName, null);
    }

    @And("^user adds an authorization request \"([^\"]*)\"$")
    public void userAddsAnAuthorizationRequest(String requestObjectName) throws Throwable {
        this.userAddsARequestWith(null, requestObjectName, null);
    }

    @And("^user adds a \"([^\"]*)\" request \"([^\"]*)\" if \"([^\"]*)\"$")
    public void userAddsARequestIf(String pfTitle, String requestObjectName, String conditionExpression) throws Throwable {
        if (WhiteBoard.evaluate(owner, conditionExpression)) {
            userAddsARequest(pfTitle, requestObjectName);
        }
    }

    @When("^user clones \"([^\"]*)\" to \"([^\"]*)\" with \"([^\"]*)\" and stop at page \"([^\"]*)\"$")
    public void userClonesToWithAndStopAtPage(String from, String to, String stringMap, String stopAtPage) throws Throwable {
        Map<String, String> referenceProfile = WhiteBoard.getInstance().getMap(owner, from + "_" + AuthorizationRequest.OUTCOME_PROFILE);
        AuthorizationRequest authorizationRequest = new AuthorizationRequest(scenario, driver());
        authorizationRequest.tryRestore(from, referenceProfile);
        Map<String, String> map = DataTableUtils.asMap(stringMap);
        map.put(AuthorizationRequest.CLONE_FROM, from);
        map.put(AuthorizationRequest.CLONE_TO, to);
        map.put(ExcelLib.STOP_AT_PAGE, stopAtPage);

        AuthorizationRequest.cloneWithRetry(map, owner, scenario);
    }

    /**
     * User selects passing treatmentType(new or continuation of treatment) from feature file  as treatment type on Request Details page
     *
     * @param treatmentType
     */
    @And("^user selects \"([^\"]*)\" as treatment type on Request Details page$")
    public void userSelectsAsTreatmentTypeOnRequestDetailsPage(String treatmentType) throws Throwable {
        treatmentType = WhiteBoard.resolve(owner, treatmentType);
        obj().RequestDetailsPage.selectDropDownValueInChangingTreatmentTypeSel(treatmentType);
        if (ExcelLib.RDCD_TREATMENT_CHANGING.equalsIgnoreCase(treatmentType)) {
            Map<String, String> pf = ExcelLib.instance(ExcelLib.LIB_AUTH_PROFILE).getObjectByTitle(ExcelLib.TITLE_DEFAULT);
            String[] justifications = ExcelLib.splitJustifications(pf.get(MBM.RDCD_CHANGING_TREATMENT_JUSTIFICATION));
            for (String justification : justifications) {
                obj().RequestDetailsPage.changeTreatmentJustificationSelection(justification);
            }
        }
        TestUtils.demoBreakPoint(scenario, driver(), "Select treatment type: " + treatmentType);
    }


    /**
     * User selects passing drug from feature file as drug type on Request Details page
     *
     * @param drugType
     */
    @And("^user selects \"([^\"]*)\" as drug type on Request Details page$")
    public void userSelectsAsDrugTypeOnRequestDetailsPage(String drugType) throws Throwable {
        obj().RequestDetailsPage.selectDropdownDrugType(drugType);
    }

    /**
     * user continues from "page" and submit the request "request" from feature file
     *
     * @param fromPage
     * @param name
     * @throws Throwable
     */
    @Then("^user continues from \"([^\"]*)\" and submit the request \"([^\"]*)\"$")
    public void userContinuesFromAndSubmitTheRequest(String fromPage, String name) throws Throwable {
        name = WhiteBoard.resolve(owner, name);
        Map<String, String> pf = WhiteBoard.getInstance().getMap(owner, name + "_" + AuthorizationRequest.OUTCOME_PROFILE);
        if (null == pf) {
            pf = ExcelLib.completeProfile(owner, null);
        }
        pf.put(ExcelLib.CONTINUE_FROM_PAGE, fromPage);
        pf.remove(ExcelLib.STOP_AT_PAGE_BEGIN);
        pf.remove(ExcelLib.STOP_AT_PAGE);
        pf.remove(ExcelLib.STOP_AT_NEXT_PAGE_BEGIN);

        TeamBase team = TeamFactory.getTeam(scenario, pf);
        boolean success = team.teamwork();
        Map<String, Map<String, String>> outcome = team.getOutcome();
        WhiteBoard.storeMaps(owner, name, Conf.getOutputPath(), outcome);
        Assert.assertTrue(success);
    }

    /**
     * user continues the request "auth1" starting from "RequestDetailsPage" and stop at "RequestSummaryPage"
     *
     * @param authName
     * @param fromPage
     * @param toPage
     * @throws Throwable
     */
    @Then("^user continues the request \"([^\"]*)\" starting from \"([^\"]*)\" and stop at \"([^\"]*)\"$")
    public void userContinuesTheRequestStartingFromAndStopAt(String authName, String fromPage, String toPage) throws Throwable {
        Map<String, String> pf = WhiteBoard.getInstance().getMap(owner, authName + "_" + AuthorizationRequest.OUTCOME_PROFILE);
        pf.put(ExcelLib.CONTINUE_FROM_PAGE, fromPage);
        pf.remove(ExcelLib.STOP_AT_PAGE_BEGIN);
        pf.put(ExcelLib.STOP_AT_PAGE, toPage);
        pf.remove(ExcelLib.STOP_AT_NEXT_PAGE_BEGIN);

        TeamBase team = TeamFactory.getTeam(scenario, pf);
        boolean success = team.teamwork();
        Map<String, Map<String, String>> outcome = team.getOutcome();
        WhiteBoard.storeMaps(owner, authName, Conf.getOutputPath(), outcome);
        Assert.assertTrue(success);
    }

    /**
     * The member is resetting in DB
     *
     * @throws IOException
     */
    @Given("^the member is reset$")
    public void theMemberIsReset() throws Throwable {
        Map<String, String> pf = WhiteBoard.getInstance().getMap(owner, ExcelLib.THE_MEMBER);
        String subscriberId = pf.get(MBM.MEMB_SUBSCRIBER_ID);
        new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).resetMember(subscriberId, owner);
    }

    /**
     * The authorization request is being cancelled in DB for passing authObject from feature file
     *
     * @param authObject
     */
    @Given("^the authorization request \"([^\"]*)\" is reset$")
    public void theAuthorizationRequestIsReset(String authObject) throws Throwable {
        String authNumber = AuthorizationRequest.getAuthNumber(owner, authObject);
        new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).resetAuth(authNumber);
    }

    @When("^user backdates \"([^\"]*)\" to \"([^\"]*)\"$")
    public void userBackdatesTo(String authObjectName, String backdate) throws Throwable {
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        WebDriver d = Login.login(scenario, pf);
        AuthorizationRequest ar = new AuthorizationRequest(scenario, d);

        String authNumber = AuthorizationRequest.getAuthNumber(owner, authObjectName);
        backdate = WhiteBoard.resolve(owner, backdate);
        ar.backdate(authNumber, backdate);

        RequestStatusPageWorker worker = new RequestStatusPageWorker(scenario, d, pf);
        pf.put(ExcelLib.CONTINUE_FROM_PAGE, RequestStatusPage.class.getName());
        TeamBase team = TeamFactory.getTeam(scenario, pf);
        boolean success = team.teamwork();
        Map<String, Map<String, String>> outcome = team.getOutcome();
        WhiteBoard.storeMaps(owner, authObjectName, Conf.getOutputPath(), outcome);
        Assert.assertTrue("Fail to collect information from Request Status page.", success);
    }


    @And("^user \"([^\"]*)\" the record with \"([^\"]*)\" from the search result on Prior Authorization Requests page$")
    public void userTheRecordWithFromTheSearchResultOnPriorAuthorizationRequestsPage(String action, String indexExpression) throws Throwable {
        action = WhiteBoard.resolve(owner, action);
        indexExpression = WhiteBoard.resolve(owner, indexExpression);
        log.warn("action=" + action);
        log.warn("indexExpression=" + indexExpression);

        Map<String, String> user = WhiteBoard.getInstance().getMap(owner, ExcelLib.THE_USER);
        WebDriver webDriver = Login.login(scenario, user);

        List<Map<String, String>> results = TestUtils.tableAsMaps(webDriver, "//table[@id='hscSearchTableSubmittedID']", 30);
        Map.Entry<String, String> index = DataTableUtils.asMap(indexExpression).entrySet().iterator().next();
        Map<String, Map<String, String>> indexedResults = DataTableUtils.dataTableAsMapsIndexedByKeyHeader(index.getKey(), results);
        Map<String, String> record = indexedResults.get(index.getValue());

        int row = Integer.parseInt(record.get(DataTableUtils.INDEX_ROW_NUMBER));
        switch (action) {
            case "clones":
                TestUtils.click(webDriver, PriorAuthorizationSearchSubmittedPage.cloneIcon(row));
                break;
            case "selects":
                TestUtils.click(webDriver, PriorAuthorizationSearchSubmittedPage.selectIcon(row));
                break;
            case "edits":
                TestUtils.click(webDriver, PriorAuthorizationSearchSubmittedPage.editIcon(row));
                break;
            default:
                throw new RuntimeException("Invalid action: " + action);
        }
    }

    @Given("^system property \"([^\"]*)\" is \"([^\"]*)\"$")
    public void systemPropertyIs(String key, String value) throws Throwable {
        key = WhiteBoard.resolve(owner, key);
        value = WhiteBoard.resolve(owner, value);
        scenarioLogger.warn("key=" + key);
        scenarioLogger.warn("value=" + value);
        String currentValue = Conf.getInstance().getProperty(key);
        scenarioLogger.warn("currentValue=" + currentValue);
        if (value.equals(currentValue)) {
            return;
        }

        System.setProperty(key, value);
        scenarioLogger.warn("After set: System.getProperty(key)=" + System.getProperty(key));
        if (key.equals(Conf.ENVSET)) {
            scenarioLogger.warn("After set: Conf.getInstance().getProperty(Conf.ENVSET)=" + Conf.getInstance().getProperty(Conf.ENVSET));
            ExcelLib.reset();
            scenarioLogger.warn("ExcelLib.reset()");
            CsqaManager.reset();
            scenarioLogger.warn("CsqaManager.reset()");
        }
        WhiteBoard.getInstance().refreshProperties();
        scenarioLogger.warn("WhiteBoard.getInstance().refreshProperties()");
    }

    @And("^User retrieve hsc_id \"([^\"]*)\" from URL$")
    public void userRetrieveHsc_idByMarker(String hscIdVarName) throws Throwable {
        String currentUrl = driver().getCurrentUrl();
        long hscId = TestUtils.getHscIdFromURL(currentUrl);
        WhiteBoard.getInstance().putString(owner, hscIdVarName, "" + hscId);
    }


    /**
     * User verifies PopupAgainst passing checkOption vs passing action
     *
     * @param checkOption
     */
    @Then("^user verifies \"([^\"]*)\" member blocking popup$")
    public void userVerifiesMemberBlockingPopup(String checkOption) throws Throwable {
        MemberBlockingCheck memberBlockingCheck = new MemberBlockingCheck(scenario, driver());
        switch (checkOption) {
            case "AuthNotRequired": {
                TestUtils.wait(4);
                Assert.assertTrue(memberBlockingCheck.authNotRequired());
                break;
            }
            case "ExpiredMemberCoverage": {
                TestUtils.wait(4);
                Assert.assertTrue(memberBlockingCheck.expiredMemberCoverage());
                break;
            }
            case "Selfadministereddrug": {
                TestUtils.wait(4);
                Assert.assertTrue(memberBlockingCheck.Selfadministereddrug());
                break;
            }
            case "RadOncAuthNotRequired": {
                TestUtils.wait(4);
                Assert.assertTrue(memberBlockingCheck.RadOncAuthNotRequired());
                break;
            }
            default:
                Assert.fail("Unknown Member Blocking option: " + checkOption);
        }
    }

    @And("^user searches for Member$")
    public void userSearchesForMember() throws Throwable {
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        pf.put(ExcelLib.STOP_AT_NEXT_PAGE_BEGIN, MemberSearchPage.class.getName());
        TeamBase team = TeamFactory.getTeam(scenario, pf);
        boolean success = team.teamwork(2 * 60 * 1000);

        if (!success) {
            throw new RuntimeException("Timeout: " + pf);
        }
    }


    @And("^User verify \"([^\"]*)\" header$")
    public void userVerifiesHeaderServicingProviderHeader(String header) throws Throwable {
        obj().RequestSummaryPage.verifytheServicingProviderPharmacyHeader(header);
    }

    @Given("^user reads file from NAS drive with \"([^\"]*)\" and stores in \"([^\"]*)\"$")
    public void userReadsFileFromNASDriveWithAndStoresIn(String fileName, String NasDriverData) throws Throwable {
        // Open connection to NAS drive
        Connection nasConnection = new SMBClient().connect(System.getenv(MBM.NAS_LOCATION));
        Session session = nasConnection.authenticate(new AuthenticationContext(System.getenv(MBM.NAS_USER), System.getenv(MBM.NAS_PASS).toCharArray(), MBM.MS));
        DiskShare ndbShare = (DiskShare) session.connectShare(System.getenv(MBM.SHARED_LOCATION));
        Set<AccessMask> accessMaskSet = new HashSet<>();
        accessMaskSet.add(AccessMask.GENERIC_READ);
        com.hierynomus.smbj.share.File smbjfile = ndbShare.openFile(System.getenv(MBM.NAS_SUBFOLDER) + '\\' + fileName, accessMaskSet, null, SMB2ShareAccess.ALL, SMB2CreateDisposition.FILE_OPEN, null);
        InputStream is = smbjfile.getInputStream();
        parseFile(is, NasDriverData);

    }

    private void parseFile(InputStream is, String NasDriverData) throws IOException {
        List<FileIntake> fileRead = new ArrayList<>();
        Reader reader = new InputStreamReader(is);
        BufferedReader br = new BufferedReader(reader);
        String line = "";
        int lineNumber = 0;
        while ((line = br.readLine()) != null) {
            if (lineNumber > 0) {
                String[] fields = line.split("\\|");
                FileIntake p = new FileIntake(fields[0], fields[1], fields[2], fields[3], fields[4], fields[5], fields[6], fields[7], fields[8], fields[9], fields[10], fields[11], fields[12], fields[14], fields[15], fields[16], fields[17], fields[18], fields[28], fields[30], fields[31]);
                fileRead.add(p);
            }
            lineNumber = ++lineNumber;
        }
        FileIntakeKeeper.getInstance().putFileIntakeListMap(owner, NasDriverData, fileRead);
    }

    /**
     * User verifies label corresponding values from UI
     *
     * @param dataTable
     */
    @And("^user verifies Backdating Start Date\\? and Authorization Start Date according to given table on Status page$")
    public void userVerifiesAccordingToGivenTableOnStatusPage(DataTable dataTable) throws Throwable {
        List<Map<String, String>> maps = dataTable.asMaps(String.class, String.class);
        for (Map<String, String> map : maps) {
            String label = map.get("label");
            String expected = WhiteBoard.resolve(owner, map.get("expected"));
            String actual = driver().findElement(By.xpath("//*[@id='serviceDetailsSection']//*[text()='" + expected + "']")).getText();
            obj().RequestStatusPage.verifyAsperTable(expected, actual, label);

        }
    }

    @Then("^user verifies objects with prefix \"([^\"]*)\" matches below table$")
    public void userVerifiesObjectsWithPrefixMatchesBelowTable(String prefix, List<Map<String, String>> mapsExpected) throws Throwable {
        List<Map<String, String>> mapsActual = WhiteBoard.getInstance().combine(owner, prefix);
        MapsComparer mapsComparer = new MapsComparer(mapsExpected, mapsActual, scenarioLogger);
        mapsComparer.assertMatches();
    }

    @Then("^user verifies objects with prefix \"([^\"]*)\" looks like below table$")
    public void userVerifiesObjectsWithPrefixLooksLikeBelowTable(String prefix, List<Map<String, String>> mapsExpected) throws Throwable {
        prefix = WhiteBoard.resolve(owner, prefix);
        List<Map<String, String>> mapsActual = WhiteBoard.getInstance().combine(owner, prefix);
        MapsComparer mapsComparer = new MapsComparer(mapsExpected, mapsActual, scenarioLogger);
        mapsComparer.assertMatches(false);
    }

    @Then("^user verifies objects \"([^\"]*)\" matches objects \"([^\"]*)\" using below mapping ignoring keys \"([^\"]*)\"$")
    public void userVerifiesObjectsMatchesObjectsMappingInBelowOrder(String prefixActual, String prefixExpecetd, String ignoringLeys, List<Map<Integer, Integer>> mappings) throws Throwable {
        List<Map<String, String>> mapsActual = WhiteBoard.getInstance().combine(owner, prefixActual);
        List<Map<String, String>> mapsExpecetd = WhiteBoard.getInstance().combine(owner, prefixExpecetd);
        MapsComparer mapsComparer = new MapsComparer(mapsExpecetd, mapsActual, scenarioLogger);
        mapsComparer.setIgnoredKeys(ignoringLeys.split(","));
        mapsComparer.assertMatches(true, mappings.get(0));
    }

    @Then("^user verifies objects \"([^\"]*)\" matches objects \"([^\"]*)\" on key \"([^\"]*)\" using below mapping$")
    public void userVerifiesObjectsMatchesObjectsOnKeyUsingBelowMapping(String prefixActual, String prefixExpecetd, String anchorKey, List<Map<String, String>> mappings) throws Throwable {
        List<Map<String, String>> mapsActual = WhiteBoard.getInstance().combine(owner, prefixActual);
        List<Map<String, String>> mapsExpected = WhiteBoard.getInstance().combine(owner, prefixExpecetd);
        MapsComparer mapsComparer = new MapsComparer(mapsExpected, mapsActual, scenarioLogger);
        mapsComparer.assertMatches(true, anchorKey, mappings.get(0));
    }

    @Then("^user verifies objects \"([^\"]*)\" matches objects \"([^\"]*)\" on key \"([^\"]*)\"$")
    public void userVerifiesObjectsMatchesObjectsOnKey(String prefixActual, String prefixExpecetd, String anchorKey) throws Throwable {
        List<Map<String, String>> mapsActual = WhiteBoard.getInstance().combine(owner, prefixActual);
        List<Map<String, String>> mapsExpected = WhiteBoard.getInstance().combine(owner, prefixExpecetd);
        MapsComparer mapsComparer = new MapsComparer(mapsExpected, mapsActual, scenarioLogger);
        mapsComparer.assertMatches(true, anchorKey, null);
    }

    @Given("^date \"([^\"]*)\" with format \"([^\"]*)\" is \"([^\"]*)\" days after date \"([^\"]*)\" with format \"([^\"]*)\"$")
    public void dateWithFormatIsDaysAfterDateWithFormat(String dateToName0, String formatTo0, String days0, String dateFrom0, String formatFrom0) throws Throwable {
        String dateToName1 = WhiteBoard.resolve(owner, dateToName0);
        String formatTo1 = WhiteBoard.resolve(owner, formatTo0);
        String days1 = WhiteBoard.resolve(owner, days0);
        String dateFrom1 = WhiteBoard.resolve(owner, dateFrom0);
        String formatFrom1 = WhiteBoard.resolve(owner, formatFrom0);

        int days = Integer.parseInt(days1);

        if (StringUtils.isEmpty(formatTo1)) {
            formatTo1 = "MM-dd-yyyy";
        }
        if (StringUtils.isEmpty(formatFrom1)) {
            formatFrom1 = "MM-dd-yyyy";
        }
        Date dateFrom = new SimpleDateFormat(formatFrom1).parse(dateFrom1);
        Date dateTo = DateUtils.addTo(dateFrom, days, Calendar.DATE);
        String dateToValue = new SimpleDateFormat(formatTo1).format(dateTo);

        WhiteBoard.getInstance().putString(owner, dateToName1, dateToValue);
    }


    /**
     * user verifies the records in not saved and displayed on UI when Clicked on Saved w/o entering all mandatory
     * fields
     *
     * @param dataTable
     */
    @Then("^User Verifies the record will not be saved$")
    public void user_Verifies_the_record_will_not_be_saved(DataTable dataTable) throws Throwable {
        List<Map<String, String>> maps = WhiteBoard.resolve(owner, dataTable.asMaps(String.class, String.class));
        Map<String, String> map = null;
        for (Map<String, String> m : maps) {
            map = m;
            new NewlyApprovedDrugs(scenario, driver()).VerifyResultGrid(map);
        }
    }

    /**
     * Verify Briova Tin on Servicing Provider Details page is same as selection from PAAN
     *
     * @param args1
     */
    @And("^User verifies Briova Tin for \"([^\"]*)\" on Servicing Provider Details Page$")
    public void userVerifiesBriovaTinOnServicingProviderDetailsPage(String args1) throws Throwable {
        Map<String, String> paanProvider = ExcelLib.instance(ExcelLib.LIB_PP).getObjectByTitle(args1);
        By ppid = By.xpath(".//label[contains(text(),'Facility Name')]/following::td[1]");
        By pptin = By.xpath(".//label[contains(text(),'Facility TIN')]/following::td[1]");
        String ppName = driver().findElement(ppid).getText();
        String ppTin = driver().findElement(pptin).getText();
        Assert.assertTrue("Corporate Tax ID is Incorrect", paanProvider.get("ppCorporateTaxIdOwner").equalsIgnoreCase(ppName));
        Assert.assertTrue("Corporate Tax ID is Incorrect", paanProvider.get("ppTin").equalsIgnoreCase(ppTin));
    }

    @Then("^user validates \"([^\"]*)\" matches \"([^\"]*)\"$")
    public void userValidatesMatches(String valueActual0, String valueExpected0) throws Throwable {
        Assert.assertTrue("Error: Values mismatched!", matches(valueActual0, valueExpected0));
    }

    @Then("^user validates \"([^\"]*)\" does not match \"([^\"]*)\"$")
    public void userValidatesDoesNotMatch(String valueActual0, String valueExpected0) throws Throwable {
        Assert.assertTrue("Error: Values matched!", !matches(valueActual0, valueExpected0));
    }

    private boolean matches(String valueActual0, String valueExpected0) {
        String valueActual1 = WhiteBoard.resolve(owner, valueActual0);
        String valueExpected1 = WhiteBoard.resolve(owner, valueExpected0);
        valueActual1 = null == valueActual1 ? "" : valueActual1;
        valueActual1.replace("\r\n", "\\n");
        valueActual1.replace("\n", "\\n");
        valueExpected1 = null == valueExpected1 ? "" : valueExpected1;
        valueExpected1.replace("\r\n", "\\n");
        valueExpected1.replace("\n", "\\n");

        scenarioLogger.warn("Expected: [" + valueExpected1 + "]" + (valueExpected1.equals(valueExpected0) ? "" : "<< [" + valueExpected0 + "]"));
        scenarioLogger.warn("Actual: [" + valueActual1 + "]" + (valueActual1.equals(valueActual0) ? "" : "<< [" + valueActual0 + "]"));

        return valueActual1.equals(valueExpected1) || valueActual1.matches(valueExpected1);
    }

    @And("^datetime \"([^\"]*)\" is converted using \"([^\"]*)\" from format \"([^\"]*)\" and zone \"([^\"]*)\" to format \"([^\"]*)\" and zone \"([^\"]*)\"$")
    public void datetimeIsConvertedUsingFromFormatAndZoneToFormatAndZone(String objectName, String dateTime, String fromFormat, String fromTz, String toFormat, String toTz) throws Throwable {
        dateTime = WhiteBoard.resolve(owner, dateTime);
        fromFormat = WhiteBoard.resolve(owner, fromFormat);
        fromTz = WhiteBoard.resolve(owner, fromTz);
        toFormat = WhiteBoard.resolve(owner, toFormat);
        toTz = WhiteBoard.resolve(owner, toTz);

        String output = ZonedDateUtils.convertDateTime(dateTime, fromFormat, fromTz, toFormat, toTz);

        //Add convertedTime output onto whiteboard
        WhiteBoard.getInstance().putString(owner, objectName, output);
    }

    @And("^User enters all provider details on the Provider search modal page$")
    public void userEntersAllProviderDetailsOnTheProviderSearchModalPage(DataTable dataTable) throws Throwable {
        List<Map<String, String>> maps = WhiteBoard.resolve(owner, dataTable.asMaps(String.class, String.class));
        TestUtils.wait(2);
        new ServicingOrRequestingProviderSearchModal(scenario, driver(), MBM.RP).search(maps.get(0));
    }

    @And("^make sure user is of role \"([^\"]*)\"$")
    public void makeSureUserIsOfRole(String expectedRole) throws Throwable {
        Map<String, String> pf0 = WhiteBoard.getInstance().getMap(owner, ExcelLib.THE_USER);
        Map<String, String> pf = WhiteBoard.resolve(owner, pf0);
        String userId = pf.get(MBM.USER_USERNAME);

        new UserTblDao(MyBatisConnectionFactoryMbmShared.getSqlSessionFactory()).updateRoleByUserId(userId, expectedRole);

    }

    @And("^User enters all servicing provider details on the servicing Provider search modal page$")
    public void userEntersAllServicingProviderDetailsOnTheServicingProviderSearchModalPage(DataTable dataTable) throws Throwable {
        List<Map<String, String>> maps = WhiteBoard.resolve(owner, dataTable.asMaps(String.class, String.class));
        TestUtils.wait(2);
        new ServicingOrRequestingProviderSearchModal(scenario, driver(), MBM.SP).search(maps.get(0));
    }

    @When("^user inputs \"([^\"]*)\" in \"([^\"]*)\" on \"([^\"]*)\"$")
    public void userInputsInOn(String value, String locatorName, String pageName) throws Throwable {
        By by = CommonPageObject.pageObjectUtils.getLocator(pageName, locatorName);
        TestUtils.input(driver(), by, WhiteBoard.resolve(owner, value));
    }

    @Then("^user verifies all items in map \"([^\"]*)\" matches \"([^\"]*)\"$")
    public void userVerifiesAllItemsInMapMatches(String mapName, String regex) throws Throwable {
        Map<String, String> map = WhiteBoard.getInstance().getMap(owner, mapName);
        for (String key : map.keySet()) {
            String value = map.get(key);
            Assert.assertTrue(key + " mismatch: [" + regex + "] vs [" + value + "]", value.matches(regex));
        }
    }

    /**
     * User verifies PopupAgainst passing checkOption vs passing action
     *
     * @param checkOption
     */
    @Then("^user verifies \"([^\"]*)\" Drug Exception popup$")
    public void userVerifiesDrugExceptionPopup(String checkOption) throws Throwable {
        DrugExceptionsCheck drugExceptionsCheck = new DrugExceptionsCheck(scenario, driver());
        switch (checkOption) {
            case "levoleucovorinDrug": {
                TestUtils.wait(4);
                Assert.assertTrue(drugExceptionsCheck.levoleucovorinDrug());
                break;
            }
            case "highDoseYervoyDrug": {
                TestUtils.wait(4);
                Assert.assertTrue(drugExceptionsCheck.highDoseYervoyDrug());
                break;
            }
            case "denosumab": {
                TestUtils.wait(4);
                Assert.assertTrue(drugExceptionsCheck.denosumabDrug());
                break;
            }
            default:
                Assert.fail("Drug Exception option: " + checkOption);
        }
    }

    @Then("^user clicks on \"([^\"]*)\" on the homepage$")
    public void userClicksOnOnTheHomepage(String Link) throws Throwable {
        obj().CommonPage.clickOnHyperlink(Link);
    }

    @Then("^user verifies the contents of the privacy policy$")
    public void userVerifiesTheContentsOfThePrivacyPolicy() throws Throwable {
        obj().CommonPage.verifyContentOfPrivacyPolicy();
    }

    @Then("^user verifies the contents of the privacy policy on login page$")
    public void userVerifiesTheContentsOfThePrivacyPolicyOnLoginPage() throws Throwable {
        obj().CommonPage.verifyContentOfPrivacyPolicyOnLogin();
    }

    @Then("^user verifies the contents of terms and conditions on login page$")
    public void userVerifiesTheContentsOfTermsAndConditionsOnLoginPageDivClassTermsContentsNgScope() throws Throwable {
        obj().CommonPage.verifyContentOfTermsAndConditionsOnLogin();
    }

    @Then("^user verifies the contents of terms and conditions$")
    public void userVerifiesTheContentsOfTermsAndConditions() throws Throwable {
        obj().CommonPage.verifyContentOfTermsAndConditions();
    }

    @Then("^user verifies no items in map \"([^\"]*)\" matches \"([^\"]*)\"$")
    public void userVerifiesNoItemsInMapMatches(String mapName, String regex) throws Throwable {
        Map<String, String> map = WhiteBoard.getInstance().getMap(owner, mapName);
        for (String key : map.keySet()) {
            String value = map.get(key);
            Assert.assertTrue(key + " mismatch: [" + regex + "] vs [" + value + "]", value.matches(regex));
        }
    }

    @And("^user clicks \"([^\"]*)\" button$")
    public void userClicksButton(String buttonIdentifier) throws Throwable {
        By by = SlowBy.by(driver(), buttonIdentifier, null, null, null);
        TestUtils.click(driver(), by);
    }

    @And("^user verifies \"([^\"]*)\" on page \"([^\"]*)\" is \"([^\"]*)\"$")
    public void userVerifiesOnPageIs(String locatorName, String pageName, String evaluation) throws Throwable {
        By by = CommonPageObject.pageObjectUtils.getLocator(pageName, locatorName);
        switch (evaluation.toLowerCase()) {
            case "checked":
                Assert.assertTrue(TestUtils.isChecked(driver(), by));
                break;
            case "unchecked":
                Assert.assertFalse(TestUtils.isChecked(driver(), by));
                break;
            case "displayed":
                Assert.assertTrue(TestUtils.isElementVisible(driver(), by));
                break;
            case "not displayed":
                Assert.assertFalse(TestUtils.isElementVisible(driver(), by));
                break;
            default:
                Assert.fail("Unsupported evaluation: " + evaluation);
        }

    }

    @Then("^User verify the \"([^\"]*)\" Values on the PriorAuth Search page \"([^\"]*)\"$")
    public void userVerifyTheValuesOnThePriorAuthSearchPage(String arg1, String tab, DataTable arg3) throws Throwable {
        List<String> expectedLabelvalues = arg3.asList(String.class);
        obj().CommonPage.verifyPayerDropdownValues(tab, expectedLabelvalues);
    }

    @And("^User verifies Payer dropdown is not present on the PriorAuth Search page for \"([^\"]*)\"$")
    public void userVerifiesPayerDropdownIsNotPresentOnThePriorAuthSearchPageFor(String tab) throws Throwable {
        obj().CommonPage.verifyPayerDropdownIsnotPresent(tab);
    }

    @Given("^user restore request \"([^\"]*)\" with \"([^\"]*)\"$")
    public void userRestoreRequestWith(String requestObjectName, String stringMap) throws Throwable {
        AuthorizationRequest authorizationRequest = new AuthorizationRequest(scenario, driver());
        Assert.assertTrue(authorizationRequest.tryRestore(requestObjectName, DataTableUtils.asMap(stringMap)) > 0);
    }

    @And("^\"([^\"]*)\" is \"([^\"]*)\" is validated$")
    public void isValidated(String label, String expected) throws Throwable {

        By by = By.xpath("(//label[contains(text(),'" + label + "')]//ancestor::td[1]//following::td[1]//*)[1]");

        Assert.assertEquals("String does not match", expected, TestUtils.simpleContent(driver().findElement(by)));


    }

    @Then("^Get webCookie for textfile$")
    public void getCookieForWhiteBoard() throws Throwable {
        Set<Cookie> cookies = driver().manage().getCookies();
        String stringCookie = "";
        for (Cookie cookie : cookies) {
            stringCookie += cookie.toString() + "; ";
        }
        WhiteBoard.getInstance().putString(owner, COOKIE_KEY, stringCookie);
    }

    @Then("^User verifies \"([^\"]*)\" is visible on the page$")
    public void userValidatedQuestionOnAuthpage(String question) throws Throwable {
        obj().CommonPage.userValidatedQuestionOnAuthpage();
    }


    /**
     * Assumption: Clinical Status  page is displayed.
     * User enters Clinical Statu based on pf
     */
    @And("^User answers Clinical Status questions for MSE$")
    public void userAnswersClinicalStatusQuestionsFoeMSE() throws Throwable {
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        pf.put(ExcelLib.CONTINUE_FROM_PAGE, ClinicalStatusPage.class.getName());
        pf.put(ExcelLib.STOP_AT_PAGE, ClinicalStatusPage.class.getName());
        TeamBase team = TeamFactory.getTeam(scenario, pf);
        boolean success = team.teamwork(2 * 60 * 1000);

        if (!success) {
            throw new RuntimeException("Timeout: " + pf);
        }


    }

    @And("^user refreshes cache from system settings$")
    public void userRefreshesCacheFromSystemSettings() throws Throwable {
        obj().CommonPage.refreshesCacheFromSystemSettings();
    }

    @Given("^app version matches spcl care build$")
    public void userVerifiesAppVersion() throws Throwable {
        String expectedVersion = System.getenv("appversion");
        if (expectedVersion == null) {
            Assert.fail("Failed: No version provided.");
        }
        AbstractLogin newLogin = new AbstractLogin(scenario, driver()) {
            @Override
            public boolean isValid() throws LostBrowserException {
                return false;
            }

            @Override
            public String getAppVersion() {
                List<WebElement> versionList = TestUtils.findElements(driver(), "//*[@id=\"appVersion\"]");
                String version = versionList.get(0).getText();
                return version;
            }
        };
        String currentVersion = newLogin.getAppVersion();
        Assert.assertEquals(expectedVersion, currentVersion);
    }

    @And("^user verifies Crendentials Change Detected popup$")
    public void userVerifiesCrendentialsChangeDetectedPopup() throws Throwable {
        obj().CommonPage.verifyCredentialsChangeDetectedPopup();

    }

    @And("^User verifies that user is logged out$")
    public void userVerifiesThatUserIsLoggedOut() throws Throwable {
        obj().CommonPage.verifyUserIsLoggedOut();
    }

    /* User verifies the auth status message in Request Status Page*/
    @And("^user verifies the \"([^\"]*)\" when SRN is not generated$")
    public void userVerifiesTheWhenSRNIsNotGenerated(String arg0) throws Throwable {

        obj().CommonPage.userVerifiesTheStatusVerbiageInRequestStatusPage(arg0);

    }


    @And("^user selects \"([^\"]*)\" on the Authorizationtype dropdown on the clonePopup$")
    public void userSelectsOnTheAuthorizationtypeDropdownOnTheClonePopup(String authType) throws Throwable {
        obj().CommonPage.selectAuthTypeOnCLonePopup(authType);
    }


    @And("^User enters the required fields for the \"([^\"]*)\" Clone with \"([^\"]*)\"$")
    public void userEntersTheRequiredFieldsForTheCloneWith(String CloneDetails, String stringmap) throws Throwable {
        Map<String, String> map = DataTableUtils.asMap(stringmap);
        switch (CloneDetails) {
            case "ChemoApproved to SupportiveApproved":
                obj().RequestDetailsPage.selectDropdownDrugCategory(map.get("DrugCategory"));
                obj().RequestDetailsPage.selectSupportiveDrug(map.get("DrugName"));
                obj().RequestDetailsPage.selectDropdownDosage(map.get("Dosage"));
                obj().RequestDetailsPage.clickContinueButton();
        }
    }

    @And("^User enters the required fields for the \"([^\"]*)\" Clone using profile \"([^\"]*)\"$")
    public void userEntersTheRequiredFieldsForTheCloneUsingProfile(String CloneDetails, String pfTitle) throws Throwable {
        Map<String, String> pf = new LinkedHashMap<>();
        switch (CloneDetails) {
            case "ChemoApproved to SupportiveApproved":
                pf.put(MBM.AUTH_TITLE, pfTitle);
                pf = ExcelLib.completeProfile(owner, pf);
                pf.put(ExcelLib.CONTINUE_FROM_PAGE, RequestDetailsPage.class.getName());
                TeamBase team = TeamFactory.getTeam(scenario, pf);
        }
    }

    @And("^User enters the required fields for the \"([^\"]*)\" Clone using profile \"([^\"]*)\",Cancer \"([^\"]*)\"$")
    public void userEntersTheRequiredFieldsForTheCloneUsingProfileCancer(String CloneDetails, String pfTitle, String stringMap) throws Throwable {
        Map<String, String> pf = new LinkedHashMap<>();
        switch (CloneDetails) {
            case "ChemoApproved to SupportiveApproved":
                pf.put(MBM.AUTH_TITLE, pfTitle);
                pf = ExcelLib.completeProfile(owner, pf);
                Map<String, String> map = DataTableUtils.asMap(stringMap);
                pf.putAll(map);
                pf.put(ExcelLib.CONTINUE_FROM_PAGE, RequestingProviderPage.class.getName());
                TeamBase team = TeamFactory.getTeam(scenario, pf);
                boolean success = team.teamwork(2 * 60 * 1000);

        }
    }


//    @And("^User enters the required fields for the \"([^\"]*)\" Clone using profile \"([^\"]*)\",\"([^\"]*)\"$")
//    public void userEntersTheRequiredFieldsForTheCloneUsingProfile(String CloneDetails, String pfTitle, String stringMap) throws Throwable {
//        Map<String, String> pf = new LinkedHashMap<>();
//        pf.put(MBM.AUTH_TITLE, pfTitle);
//        pf = ExcelLib.completeProfile(owner, pf);
//        Map<String, String> map = DataTableUtils.asMap(stringMap);
//        pf.putAll(map);
//        obj().CommonPage.verifyHeader("Requesting Provider");
//        obj().RequestingProviderPage.clickContinueButton();
//        obj().CommonPage.verifyHeader("Servicing Provider");
//        obj().ServicingProviderPage.clicKContinueButton();
//        obj().CommonPage.verifyHeader("Request Details");
//        if (CloneDetails.contains("SameCancer")) {
//            obj().RequestDetailsPage.enterClincalDetailsForClone(pf);
//            obj().RequestDetailsPage.clickContinueButton();
//            pf.put(ExcelLib.CONTINUE_FROM_PAGE, ClinicalStatusPage.class.getName());
//        } else {
//            pf.put(ExcelLib.CONTINUE_FROM_PAGE, RequestDetailsPage.class.getName());
//        }
//        TeamBase team = TeamFactory.getTeam(scenario, pf);
//        boolean success = team.teamwork(2 * 60 * 1000);
//
//    }

    @And("^User enters the required fields for cloning from \"([^\"]*)\" to \"([^\"]*)\" using \"([^\"]*)\" using profile \"([^\"]*)\",\"([^\"]*)\"$")
    public void userEntersTheRequiredFieldsForCloningFromToUsingUsingProfile(String From, String to, String CloneDetails, String pfTitle, String stringMap) throws Throwable {
        Map<String, String> pf = new LinkedHashMap<>();
        pf.put(MBM.AUTH_TITLE, pfTitle);
        pf = ExcelLib.completeProfile(owner, pf);
        Map<String, String> map = DataTableUtils.asMap(stringMap);
        pf.putAll(map);
        obj().CommonPage.verifyHeader("Requesting Provider");
        obj().RequestingProviderPage.clickContinueButton();
        obj().CommonPage.verifyHeader("Servicing Provider");
        obj().ServicingProviderPage.clicKContinueButton();
        obj().CommonPage.verifyHeader("Request Details");
        if(to.contains("Radonc"))
        enterDetailsForRadoncClone(to, CloneDetails, pf);
        else{
            if (CloneDetails.contains("SameCancer")) {
                obj().RequestDetailsPage.enterClincalDetailsForClone(pf,to);
                obj().RequestDetailsPage.clickContinueButton();
                pf.put(ExcelLib.CONTINUE_FROM_PAGE, ClinicalStatusPage.class.getName());
            } else {
                pf.put(ExcelLib.CONTINUE_FROM_PAGE, RequestDetailsPage.class.getName());
            }
        }
        TeamBase team = TeamFactory.getTeam(scenario, pf);
        Assert.assertTrue(team.teamwork(2 * 60 * 1000));
    }

    public void enterDetailsForRadoncClone(String to, String CloneDetails, Map<String, String> pf) throws Throwable {
        if (CloneDetails.contains("SameCancer")) {
            obj().RequestDetailsPage.clickContinueButton();
            obj().ClinicalStatusPage.clickContinueButton();
            obj().TechniquePage.clickContinueButtonTechnique();
            TestUtils.waitElementVisible(driver(), "//h2[.='Additional Services']", 15);
            obj().CommonPage.verifyHeader("Additional Services");
            obj().AdditionalServicesPage.enterAdditionalServicesForClone(pf);
            pf.put(ExcelLib.CONTINUE_FROM_PAGE, RequestSummaryPage.class.getName());
        }else if(CloneDetails.contains("NoTechnique")){
            obj().RequestDetailsPage.clickContinueButton();
            obj().ClinicalStatusPage.clickContinueButton();
            obj().TechniquePage.selectTechniqueRadioButton("No Technique");
            obj().TechniquePage.clickContinueButtonTechnique();
            TestUtils.waitElementVisible(driver(), "//h2[.='Additional Services']", 15);
            obj().CommonPage.verifyHeader("Additional Services");
            obj().AdditionalServicesPage.enterAdditionalServicesForNoTechnique(pf);
            pf.put(ExcelLib.CONTINUE_FROM_PAGE, RequestSummaryPage.class.getName());
        } else {
            obj().RequestDetailsPage.enterClincalDetailsForClone(pf,to);
            obj().RequestDetailsPage.clickContinueButton();
            pf.put(ExcelLib.CONTINUE_FROM_PAGE, ClinicalStatusPage.class.getName());
        }
    }

    @And("^User clicks on text \"([^\"]*)\"$")
    public void userClicksOnText(String text) throws Throwable {
      obj().CommonPage.userClicksOntext(text);
    }
}
