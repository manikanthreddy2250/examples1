package atdd.test.stepdefinitions;

import atdd.common.Retry;
import atdd.common.ScenarioLogger;
import atdd.dao.icue.HscDaoIcue;
import atdd.dao.icue.HscSrvcNonFaclDaoIcue;
import atdd.dao.icue.MyBatisConnectionFactoryICUE;
import atdd.dao.mbm.HscSrvcNonFaclDao;
import atdd.dao.mbm.MyBatisConnectionFactory;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.pageobjects.authorization.DupTermPopupPage;
import atdd.test.stepsets.AuthorizationRequest;
import atdd.test.stepsets.DupTermCheck;
import atdd.test.stepsets.Login;
import atdd.utils.ExcelLib;
import atdd.utils.MBM;
import atdd.utils.TestUtils;
import atdd.utils.WhiteBoard;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import java.io.IOException;
import java.util.*;

public class DupeTermStepDefinition {

        public static final Logger log = Logger.getLogger(DupeTermStepDefinition.class.getName());

        private ScenarioLogger scenarioLogger = null;

        private Scenario scenario;
        private String owner;

        private CommonPageObject obj() throws Throwable {
            return new CommonPageObject(scenario, driver());
        }

        private WebDriver driver() throws Throwable {
            return Login.login(scenario);
        }

        @Before
        public void beforeScenario(Scenario scenario) throws Throwable {
            this.scenario = scenario;
            this.owner = scenario.getId();
            this.scenarioLogger = new ScenarioLogger(scenario, log);
        }


        /**
         * userVerifies oldRequest is termed by new request
         *
         * @param oldRequestName
         * @param newRequestName
         */
        @And("^user verifies \"([^\"]*)\" is termed by \"([^\"]*)\"$")
        public void userVerifiesIsTermedBy(String oldRequestName, String newRequestName) throws Throwable {
            AuthorizationRequest authorizationRequest = new AuthorizationRequest(scenario, driver());
            authorizationRequest.tryRestore(oldRequestName, null);
            authorizationRequest.tryRestore(newRequestName, null);

            HscSrvcNonFaclDao dao = new HscSrvcNonFaclDao(MyBatisConnectionFactory.getSqlSessionFactory());
            HscSrvcNonFaclDaoIcue icuedao = new HscSrvcNonFaclDaoIcue(MyBatisConnectionFactoryICUE.getSqlSessionFactory());

            boolean success = new Retry("userVerifiesIsTermedBy") {

                @Override
                protected void tryOnce() throws Exception {
                    Date oldRequestStartDate = null;
                    Date oldRequestEndDate = null;
                    String oldAuthNumber = AuthorizationRequest.getAuthNumber(owner, oldRequestName);
                    List<Map<String, Object>> oldSrvcList = dao.selectByAuthNumber(oldAuthNumber);

                    if (oldSrvcList.size() == 0) {
                        oldSrvcList = icuedao.selectByIcueAuthNumber(oldAuthNumber);
                        int i = 0;
                        for (Map<String, Object> srvc : oldSrvcList) {
                            oldSrvcList.set(i, TestUtils.mapKeysToLowerCase(srvc));
                            i++;
                        }

                    }

                    for (Map<String, Object> srvc : oldSrvcList) {
                        Date srvcStrtDt = (Date) srvc.get("srvc_strt_dt");
                        Date srvcEndDt = (Date) srvc.get("srvc_end_dt");
                        if (null == oldRequestStartDate) {
                            oldRequestStartDate = srvcStrtDt;
                            oldRequestEndDate = srvcEndDt;
                        } else {
                            Assert.assertEquals(oldRequestStartDate, srvcStrtDt);
                            Assert.assertEquals(oldRequestEndDate, srvcEndDt);
                        }
                    }

                    Date newRequestStartDate = null;
                    Date newRequestEndDate = null;
                    String newAuthNumber = AuthorizationRequest.getAuthNumber(owner, newRequestName);
                    List<Map<String, Object>> newSrvcList = dao.selectByAuthNumber(newAuthNumber);
                    for (Map<String, Object> srvc : newSrvcList) {
                        Date srvcStrtDt = (Date) srvc.get("srvc_strt_dt");
                        Date srvcEndDt = (Date) srvc.get("srvc_end_dt");
                        if (null == newRequestStartDate) {
                            newRequestStartDate = srvcStrtDt;
                            newRequestEndDate = srvcEndDt;
                        } else {
                            Assert.assertEquals(newRequestStartDate, srvcStrtDt);
                            Assert.assertEquals(newRequestEndDate, srvcEndDt);
                        }
                    }

                    try {
                        TestUtils.demoBreakPoint(scenario, driver(),
                                "\r\nOld Request " + oldAuthNumber + " StartDate = " + oldRequestStartDate.toString()
                                        + ", EndDate = " + oldRequestEndDate.toString()
                                        + "\r\nNew Request " + newAuthNumber + " StartDate = " + newRequestStartDate.toString()
                                        + ", EndDate = " + newRequestEndDate.toString());
                    } catch (Throwable throwable) {
                        //do nothing
                    }
                    Calendar nextDayOfOldRequestEndDate = Calendar.getInstance();
                    nextDayOfOldRequestEndDate.setTime(oldRequestEndDate);
                    nextDayOfOldRequestEndDate.add(Calendar.DATE, 1);
                    if (!(
                            (oldRequestStartDate.equals(oldRequestEndDate) && oldRequestEndDate.equals(newRequestStartDate))
                                    || nextDayOfOldRequestEndDate.getTime().equals(newRequestStartDate)
                    )) {
                        throw new RuntimeException("Terming check failed. May need to wait for some time.");
                    }
                }

                @Override
                protected long getTimeoutMillis() {
                    return 5 * 60 * 1000;
                }

            }.execute();

            Assert.assertTrue("Terming check success.", success);

        }

        /**
         * User verifies PopupAgainst passing checkOption vs passing action
         *
         * @param checkOption
         * @param requestObjectNameList
         * @param action
         */
        @Then("^user verifies \"([^\"]*)\" popup against \"([^\"]*)\" and \"([^\"]*)\"$")
        public void userVerifiesPopupAgainstAnd(String checkOption, List<String> requestObjectNameList, String action) throws Throwable {
            Map<String, String> pf = ExcelLib.completeProfile(owner, null);
            String subcriberId = pf.get(MBM.MEMB_SUBSCRIBER_ID);
            String payer = pf.get(MBM.PAYER);
            TestUtils.wait(3);

            obj().RequestDetailsPage.clickContinueButton();
            TestUtils.waitElementVisible(driver(), DupTermPopupPage.existingAuthMessageDiv);

            List<String> listOfAuthNum = new ArrayList<>(requestObjectNameList.size());

            for (String requestObjectName : requestObjectNameList) {
                String authNum;
                AuthorizationRequest authorizationRequest;
                authorizationRequest = new AuthorizationRequest(scenario, driver());
                authorizationRequest.tryRestore(requestObjectName, pf);
                authNum = AuthorizationRequest.getAuthNumber(owner, requestObjectName);
                listOfAuthNum.add(authNum);
            }

            DupTermCheck dupTermCheck = new DupTermCheck(scenario, driver(), listOfAuthNum, subcriberId);
            switch (checkOption) {
                case "Dup Check": {
                    Assert.assertTrue(dupTermCheck.dupPopupOK(payer));
                    break;
                }
                case "Term Check": {
                    Assert.assertTrue(dupTermCheck.termPopupOK());
                    break;
                }
                case "Initial Treatment Term Check":
                    Assert.assertTrue(dupTermCheck.initialTreatmentTermPopupOK());
                    break;
                default:
                    Assert.fail("Unknown Dup/Term check option: " + checkOption);
            }

            switch (action) {
                case "accept":
                    obj().DupTermPopupPage.clickOK();
                    break;
                case "continue":
                    obj().DupTermPopupPage.clickContinue();
                    break;
                default:
                    Assert.fail("Unknown Dup/Term check option: " + action);
            }
        }

        /**
         * The member is resetting in ICUE DB
         *
         * @throws IOException
         */
        @Given("^the member is reset in ICUE$")
        public void theMemberIsResetinICUE() throws Throwable {
            Map<String, String> pf = WhiteBoard.getInstance().getMap(owner, ExcelLib.THE_MEMBER);
            String subscriberId = pf.get(MBM.MEMB_SUBSCRIBER_ID);
            new HscDaoIcue(MyBatisConnectionFactoryICUE.getSqlSessionFactory()).resetMemberIcue(subscriberId);
        }

    }


