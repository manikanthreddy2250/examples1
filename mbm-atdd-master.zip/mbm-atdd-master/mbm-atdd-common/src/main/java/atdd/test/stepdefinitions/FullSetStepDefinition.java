package atdd.test.stepdefinitions;

import atdd.common.ScenarioLogger;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.stepsets.Login;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

public class FullSetStepDefinition {
    public static final Logger log = Logger.getLogger(FullSetStepDefinition.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }

//    /**
//     * A profile based universal login step
//     */
//    @Given("^user login$")
//    public void userLogin() {
//        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
//        boolean success = new Retry("userLogin") {
//            @Override
//            protected void tryOnce() {
//                WebDriver d = Login.login(scenario, pf);
//
//            }
//
//            @Override
//            protected long getTimeoutMillis() {
//                // 5 minutes
//                return 5 * 60 * 1000;
//            }
//        }.execute();
//        if (!success) {
//            throw new RuntimeException("Timeout: " + pf);
//        }
//
//
//    }
//
//    /**
//     * Assumption: Add Request page is displayed.
//     * Search member and select Authorization Type according to the profile.
//     */
//
//    @And("^user searches for Member and selects auth type$")
//    public void userSearchesForMemberAndSelectsAuthType() {
//        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
//        pf.put(ExcelLib.STOP_AT_NEXT_PAGE_BEGIN, AuthorizationTypePage.class.getName());
//        TeamBase team = TeamFactory.getTeam(scenario, pf);
//        boolean success = team.teamwork(2 * 60 * 1000);
//
//        if (!success) {
//            throw new RuntimeException("Timeout: " + pf);
//        }
//
//    }
//
//    /**
//     * Assumption: Requesting Provider page is displayed.
//     * User enters Requesting Provider Details based on pf
//     *
//     * @throws Throwable
//     */
//    @And("^User enters Requesting Provider Details$")
//    public void userEntersRequestingProviderDetails() {
//        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
//        pf.put(ExcelLib.CONTINUE_FROM_PAGE, RequestingProviderPage.class.getName());
//        pf.put(ExcelLib.STOP_AT_NEXT_PAGE_BEGIN, RequestingProviderPage.class.getName());
//        TeamBase team = TeamFactory.getTeam(scenario, pf);
//        boolean success = team.teamwork(2 * 60 * 1000);
//
//        if (!success) {
//            throw new RuntimeException("Timeout: " + pf);
//        }
//    }
//
//
//    /**
//     * Assumption: Servicing Provider page is displayed.
//     * User enters Servicing Provider Details based on pf
//     *
//     * @throws Throwable
//     */
//    @And("^User enters Servicing Provider Details$")
//    public void userEntersServicingProviderDetails() {
//        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
//        pf.put(ExcelLib.CONTINUE_FROM_PAGE, ServicingProviderPage.class.getName());
//        pf.put(ExcelLib.STOP_AT_NEXT_PAGE_BEGIN, ServicingProviderPage.class.getName());
//        TeamBase team = TeamFactory.getTeam(scenario, pf);
//        boolean success = team.teamwork(2 * 60 * 1000);
//
//        if (!success) {
//            throw new RuntimeException("Timeout: " + pf);
//        }
//    }
//
//    /**
//     * Assumption: Request Details page is displayed.
//     * User enters Request Details based on pf
//     *
//     * @throws Throwable
//     */
//
//    @And("^user enters Request Details$")
//    public void userEntersRequestDetails() {
//        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
//        pf.put(ExcelLib.CONTINUE_FROM_PAGE, RequestDetailsPage.class.getName());
//        pf.put(ExcelLib.STOP_AT_NEXT_PAGE_BEGIN, RequestDetailsPage.class.getName());
//        TeamBase team = TeamFactory.getTeam(scenario, pf);
//        boolean success = team.teamwork(2 * 60 * 1000);
//
//        if (!success) {
//            throw new RuntimeException("Timeout: " + pf);
//        }
//    }
//
//    /**
//     * Assumption: Clinical Status  page is displayed.
//     * User enters Clinical Statu based on pf
//     */
//    @And("^User answers Clinical Status questions$")
//    public void userAnswersClinicalStatusQuestions() {
//        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
//        pf.put(ExcelLib.CONTINUE_FROM_PAGE, ClinicalStatusPage.class.getName());
//        pf.put(ExcelLib.STOP_AT_NEXT_PAGE_BEGIN, ClinicalStatusPage.class.getName());
//        TeamBase team = TeamFactory.getTeam(scenario, pf);
//        boolean success = team.teamwork(2 * 60 * 1000);
//
//        if (!success) {
//            throw new RuntimeException("Timeout: " + pf);
//        }
//
//
//    }
//
//    /**
//     * Assumption: Regimens page is displayed.
//     * Input Regimens page according to the profile.
//     *
//     * @throws Throwable
//     */
//    @And("^User selects Regimen$")
//    public void userSelectsFirstRegimen() {
//        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
//        pf.put(ExcelLib.CONTINUE_FROM_PAGE, RegimensPage.class.getName());
//        pf.put(ExcelLib.STOP_AT_NEXT_PAGE_BEGIN, RegimensPage.class.getName());
//        TeamBase team = TeamFactory.getTeam(scenario, pf);
//        boolean success = team.teamwork(2 * 60 * 1000);
//
//        if (!success) {
//            throw new RuntimeException("Timeout: " + pf);
//        }
//    }
//
//
//    /**
//     * Assumption: Request Summary page is displayed.
//     * Extract  information from Request Summary page and stores in whiteBoard
//     *
//     * @param objectName
//     * @throws StopAtPageException
//     */
//    @And("^User stores \"([^\"]*)\" object and submits auth$")
//    public void userStoresObjectAndSubmitsAuth(String objectName) throws StopAtPageException {
//        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
//        pf.put(ExcelLib.CONTINUE_FROM_PAGE, RequestSummaryPage.class.getName());
//        pf.put(ExcelLib.STOP_AT_NEXT_PAGE_BEGIN, RequestSummaryPage.class.getName());
//        TeamBase team = TeamFactory.getTeam(scenario, pf);
//        boolean success = team.teamwork(2 * 60 * 1000);
//        Map<String, Map<String, String>> outcome = team.getOutcome();
//        WhiteBoard.storeMaps(owner, objectName, Conf.getOutputPath(), outcome);
//
//        if (!success) {
//            throw new RuntimeException("Timeout: " + pf);
//        }
//    }
//
//    /**
//     * userVerifiesAccordingToGivenTable  pf vs WhiteBoard
//     *
//     * @param maps
//     */
//    @And("^user verifies according to given table$")
//    public void userVerifiesAccordingToGivenTable(List<Map<String, String>> maps) throws ParseException {
//        for (Map<String, String> map : maps) {
//            scenarioLogger.warn("\r\n");
//            String expected0 = map.get("expected");
//            String actual0 = map.get("actual");
//            String expected = WhiteBoard.resolve(owner, map.get("expected"));
//            String actual = WhiteBoard.resolve(owner, map.get("actual"));
//            if (null == expected) {
//                expected = "";
//            }
//            if (null == actual) {
//                actual = "";
//            }
//            scenarioLogger.warn("expected=[" + expected + (expected.equals(expected0) ? "]" : "] <<< " + expected0));
//            scenarioLogger.warn("actual=[" + actual + (actual.equals(actual0) ? "]" : "] <<< " + actual0));
//
//            String method = map.get("method");
//            if (StringUtils.isEmpty(method)) {
//                method = "equals";
//            }
//
//            String failNote = "Comparing [" + expected0 + "] vs [" + actual0 + "] using method " + method + " ...";
//            switch (method) {
//                case "equals":
//                    Assert.assertEquals(failNote, expected.trim(), actual.trim());
//                    break;
//                case "notEquals":
//                    Assert.assertNotEquals(failNote, expected.trim(), actual.trim());
//                    break;
//                case "daysAfter":
//                    int days = Integer.parseInt(WhiteBoard.resolve(owner, map.get("days")));
//                    String expectedDateFormat = WhiteBoard.resolve(owner, map.get("expected format"));
//                    String actualDateFormat = WhiteBoard.resolve(owner, map.get("actual format"));
//                    if (StringUtils.isEmpty(expectedDateFormat)) {
//                        expectedDateFormat = "MM-dd-yyyy";
//                    }
//                    if (StringUtils.isEmpty(actualDateFormat)) {
//                        actualDateFormat = "MM-dd-yyyy";
//                    }
//                    Date expectedDate = new SimpleDateFormat(expectedDateFormat).parse(expected);
//                    Date actualDate = new SimpleDateFormat(actualDateFormat).parse(actual);
//                    Assert.assertEquals(failNote, expectedDate, DateUtils.addTo(actualDate, days, Calendar.DATE));
//                    break;
//                default:
//                    Assert.fail("Unknown method: " + method);
//            }
//            scenarioLogger.warn("Validation OK");
//        }
//    }
//
//    /**
//     * Extract and stores values from requestStatusPage in WhiteBoard based on @param objectName
//     *
//     * @param objectName
//     */
//    @And("^User stores \"([^\"]*)\" object$")
//    public void userStoresObject(String objectName) {
//        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
//        pf.put(ExcelLib.CONTINUE_FROM_PAGE, RequestStatusPage.class.getName());
//        TeamBase team = TeamFactory.getTeam(scenario, pf);
//        boolean success = team.teamwork(2 * 60 * 1000);
//        Map<String, Map<String, String>> outcome = team.getOutcome();
//        WhiteBoard.storeMaps(owner, objectName, Conf.getOutputPath(), outcome);
//
//        if (!success) {
//            throw new RuntimeException("Timeout: " + pf);
//        }
//
//    }
//
//    /**
//     * UserVerifiesAuthorizationOnRequestStatusPage based on WhiteBoard against pf
//     */
//    @And("^User verifies authorization on Request Status page$")
//    public void userVerifiesAuthorizationOnRequestStatusPage() {
//        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
//        pf.put(ExcelLib.CONTINUE_FROM_PAGE, RequestStatusPage.class.getName());
//        TeamBase team = TeamFactory.getTeam(scenario, pf);
//        boolean success = team.teamwork(2 * 60 * 1000);
//        Map<String, Map<String, String>> outcome = team.getOutcome();
//
//    }
//
//
//    /**
//     * User searches the traversal based on criteria provided in @param dataTable
//     *
//     * @param dataTable
//     * @throws Throwable
//     */
//    @Given("^user searches the traversal by below criteria on the Traversal Maintenance page$")
//    public void userSearchesTheTraversalByBelowCriteriaOnTheTraversalMaintenancePage(DataTable dataTable) throws InvalidSearchCriteriaException {
//        Map<String, String> theUser = WhiteBoard.getInstance().getMap(owner, ExcelLib.THE_USER);
//        Login.login(scenario, theUser);
//        new TraversalMaintenance(scenario, driver()).search(dataTable.asMaps(String.class, String.class).get(0));
//    }
//
//    /**
//     * User edit the traversal on the traversalMaintenance Page based on @param dataTable
//     *
//     * @param traversalId
//     * @param dataTable
//     */
//    @Then("^user edit the traversal \"([^\"]*)\" on the Traversal Maintenance page with below updates$")
//    public void userEditTheTraversalOnTheTraversalMaintenancePageWithBelowUpdates(String traversalId, DataTable dataTable) {
//        new TraversalMaintenance(scenario, driver()).editTraversalById(traversalId, dataTable.asMaps(String.class, String.class).get(0));
//    }
//
//    /**
//     * Traversal Object is extracted On The traversal maintenancePage based on @param traversalIdOrRow
//     *
//     * @param objectName
//     * @param traversalIdOrRow
//     */
//    @And("^traversal object \"([^\"]*)\" is extracted by \"([^\"]*)\" on the Traversal Maintenance page$")
//    public void traversalObjectIsExtractedByOnTheTraversalMaintenancePage(String objectName, String traversalIdOrRow) {
//        if (traversalIdOrRow.startsWith("row")) {
//            traversalIdOrRow = obj().TraversalMaintenance.getTraversalIdByRow(traversalIdOrRow.split("\\s+", 2)[1]);
//        }
//        TraversalMaintenance traversalMaintenance = new TraversalMaintenance(scenario, driver());
//        Map<String, String> traversal = traversalMaintenance.extractTraversalById(traversalIdOrRow);
//        WhiteBoard.getInstance().putMap(owner, objectName, traversal);
//    }
//
//    /**
//     * User add a new authorization request based on the profile
//     *
//     * @throws Exception
//     */
//    @Given("^user add a new authorization request$")
//    public void userAddANewAuthorizationRequest() {
//        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
//        TeamBase team = TeamFactory.getTeam(scenario, pf);
//        boolean success = team.teamwork(2 * 60 * 1000);
//        Map<String, Map<String, String>> outcome = team.getOutcome();
//
//        if (!success) {
//            throw new RuntimeException("Timeout: " + pf);
//        }
//    }
//
//    /**
//     * Assumption: traversalMaintenance page is displayed.
//     * Extract  information from traversalMaintenance page and stores in whiteBoard
//     *
//     * @param traversalName
//     */
//    @And("^traversal object \"([^\"]*)\" is extracted from the Request Status page$")
//    public void traversalObjectIsExtractedFromTheRequestStatusPage(String traversalName) {
//        RequestStatus traversalMaintenance = new RequestStatus(scenario, driver());
//        Map<String, String> traversal = traversalMaintenance.extractTheTraversal();
//        WhiteBoard.getInstance().putMap(owner, traversalName, traversal);
//    }
//
//    /**
//     * Generic
//     * User verifyMatches between UI and passing variable
//     *
//     * @param expressionLeft
//     * @param expressionRight
//     */
//    @Then("^verify \"([^\"]*)\" matches \"([^\"]*)\"$")
//    public void verifyMatches(String expressionLeft, String expressionRight) {
//        String valueLeft = WhiteBoard.resolve(owner, expressionLeft);
//        String valueRight = WhiteBoard.resolve(owner, expressionRight.split(" or "));
//        log.warn("valueLeft=" + valueLeft);
//        log.warn("valueRight=" + valueRight);
//        Assert.assertEquals(valueLeft.trim(), valueRight.trim());
//    }
//
//    /**
//     * User enter the Clinical Variable type and variable Value in Edit Traversal
//     *
//     * @param description
//     */
//    @When("^User enter the \"([^\"]*)\" Clinical Variable Type and Variable Value in Edit Traversal$")
//    public void user_enter_the_Clinical_Variable_Type_and_Variable_Value_in_Edit_Traversal(String description) {
//        String Description = WhiteBoard.resolve(owner, description);
//        obj().EditTraversalModalPage.selectVariableTypeAndVariableValue(Description);
//    }
//
//    /**
//     * UserRemovesAllTraversalsWithBelowCriteriaOnTheTraversalMaintenancePage based on feature file data table
//     *
//     * @param dataTable
//     * @throws Throwable
//     */
//    @Then("^user removes all traversals with below criteria on the Traversal Maintenance page$")
//    public void userRemovesAllTraversalsWithBelowCriteriaOnTheTraversalMaintenancePage(DataTable dataTable) {
//        try {
//            this.userSearchesTheTraversalByBelowCriteriaOnTheTraversalMaintenancePage(dataTable);
//        } catch (InvalidSearchCriteriaException e) {
//            return;
//        }
//        while (obj().TraversalMaintenance.hasResult()) {
//            obj().TraversalMaintenance.removeFirstResut();
//        }
//    }
//
//    /**
//     * UserAddBelowTraversalsOnTheTraversalMaintenancePage
//     *
//     * @param dataTable
//     */
//    @Given("^user add below traversals on the Traversal Maintenance page$")
//    public void userAddBelowTraversalsOnTheTraversalMaintenancePage(DataTable dataTable) {
//        List<Map<String, String>> maps = WhiteBoard.resolve(owner, dataTable.asMaps(String.class, String.class));
//        new TraversalMaintenance(scenario, driver()).add(maps);
//    }
//
//    /**
//     * Assumption: BulkChangeVariableValueModalPage is displayed.
//     * verify the UI Of bulk change variable value PopupModal
//     */
//    @Then("^verify the UI of Bulk Change Variable Value popup modal$")
//    public void verifyTheUIOfBulkChangeVariableValuePopupModal() {
//        TraversalMaintenance tm = new TraversalMaintenance(scenario, driver());
//        tm.applyBulkAction("Change Variable Value");
//        tm.verifyBulkChangeVariableValueUI();
//        obj().BulkChangeVariableValueModalPage.clickCancelLink();
//        obj().BulkChangeVariableValueModalPage.shouldDisappear();
//
//        tm.applyBulkAction("Change Variable Value");
//        obj().BulkChangeVariableValueModalPage.clickXoutButton();
//        obj().BulkChangeVariableValueModalPage.shouldDisappear();
//
//        TestUtils.demoBreakPoint(scenario, driver(), "UI Check OK");
//    }
//
//    /**
//     * User verifies Error message when clicked on Save w/o entering all mandatory fields
//     *
//     * @param dataTable
//     */
//    @Then("^User navigates to Add New Drug pop-up and validates the error message$")
//    public void user_navigates_to_add_New_Drug_pop_up__and_validates_the_error_message(DataTable dataTable) {
//        List<Map<String, String>> maps = WhiteBoard.resolve(owner, dataTable.asMaps(String.class, String.class));
//        Map<String, String> map = null;
//        for (Map<String, String> m : maps) {
//            map = m;
//            new NewlyApprovedDrugs(scenario, driver()).navigatetoAddNewDrugPopUpValidateErrorMsg(map);
//        }
//    }
//
//    /*
//      Verify Auth Type Dropdown and Payer Dropdown and the default selected values in Newly Approved Drug Screen
//     */
//    @Then("^User verify the Search fields in the Newly Approved Drug Screen$")
//    public void user_verify_the_Search_fields_in_the_Newly_Approved_Drug_Screen(DataTable arg1) {
//        List<String> expectedLabelvalues = arg1.asList(String.class);
//        new NewlyApprovedDrugs(scenario, driver()).validateSearchFieldInNewlyApprovedDrugScreen(expectedLabelvalues);
//
//    }
//
//    @Then("^User verify the \"([^\"]*)\" Values in the Newly Approved Drug Screen$")
//    public void user_verify_the_Values_in_the_Newly_Approved_Drug_Screen(String arg1, DataTable arg2) {
//        List<String> expectedLabelvalues = arg2.asList(String.class);
//        new NewlyApprovedDrugs(scenario, driver()).validateDropdownOptionsInNewlyApprovedDrugScreen(arg1, expectedLabelvalues);
//
//    }
//
//    /**
//     * User searches the New Added Drugs based on criteria provided in @param dataTable
//     *
//     * @param dataTable
//     * @throws Throwable
//     */
//    @And("^user searches the New Added Drug by below criteria on the Newly Approved Drugs page$")
//    public void userSearchesTheNewAddedDrugByBelowCriteriaOnTheNewApprovedDrugsPage(DataTable dataTable) throws InvalidSearchCriteriaException {
//        List<Map<String, String>> maps = WhiteBoard.resolve(owner, dataTable.asMaps(String.class, String.class));
//        Map<String, String> map = null;
//        for (Map<String, String> m : maps) {
//            map = m;
//            new NewlyApprovedDrugs(scenario, driver()).search(map);
//        }
//    }
//
//    /**
//     * User Enter All the mandatory fields in Add New Drug Pop-Up Model in Newly Approved Drugs Screen
//     *
//     * @param dataTable
//     */
//
//    @Given("^User adds New Drug with below information$")
//    public void user_adds_New_Drug_with_below_information(DataTable dataTable) {
//        List<Map<String, String>> maps = WhiteBoard.resolve(owner, dataTable.asMaps(String.class, String.class));
//        Map<String, String> map = null;
//        for (Map<String, String> m : maps) {
//            map = m;
//            new NewlyApprovedDrugs(scenario, driver()).addNewDrug(map);
//        }
//    }
//
//
//    /**
//     * Assumption: BulkChangeVariableValueModalPage is displayed.
//     * verify The variable type dropdown list contains only contains the options based on feature file variable
//     */
//    @And("^verify the Variable Type dropdown list contains and only contains the options \"([^\"]*)\"$")
//    public void verifyTheVariableTypeDropdownListContainsAndOnlyContainsTheOptions(String expectedOptionsString) {
//        String[] expectedOptions = expectedOptionsString.split("\\s*,\\s*");
//        Set<String> expectedOptionSet = new HashSet<String>(Arrays.asList(expectedOptions));
//        Set<String> actualOptionSet = obj().BulkChangeVariableValueModalPage.getVariableTypeOptions();
//        Assert.assertEquals(expectedOptionSet, actualOptionSet);
//
//        obj().BulkChangeVariableValueModalPage.clickXoutButton();
//        obj().BulkChangeVariableValueModalPage.shouldDisappear();
//    }
//
//    /**
//     * Assumption: TraversalMaintenance is displayed.
//     * User Select all rows on the traversal maintenancePage
//     */
//    @Given("^user select \"([^\"]*)\" on the Traversal Maintenance page$")
//    public void userSelectOnTheTraversalMaintenancePage(String rowExpression) {
//        if ("all rows".equals(rowExpression)) {
//            new TraversalMaintenance(scenario, driver()).selectAll();
//        }
//    }
//
//    /**
//     * Assumption: TraversalMaintenance is displayed.
//     * user apply bulk action to selected rows on the traversalMaintenance Page
//     *
//     * @param action
//     */
//    @And("^user apply bulk action \"([^\"]*)\" to selected rows on the Traversal Maintenance page$")
//    public void userApplyBulkActionToSelectedRowsOnTheTraversalMaintenancePage(String action) {
//        new TraversalMaintenance(scenario, driver()).applyBulkAction(action);
//    }
//
//    /**
//     * User input information on bulk change variable value modal Page based on dataTable
//     *
//     * @param dataTable
//     */
//    @And("^user input below information on Bulk Change Variable Value page$")
//    public void userInputBelowInformationOnBulkChangeVariableValuePage(DataTable dataTable) {
//        List<Map<String, String>> maps = dataTable.asMaps(String.class, String.class);
//        new TraversalMaintenance(scenario, driver()).bulkChangeVariableValue(maps.get(0));
//    }
//
//    @And("^user input below information on Bulk Change Variable Type page$")
//    public void userInputBelowInformationOnBulkChangeVariableTypePage(DataTable dataTable) {
//        List<Map<String, String>> maps = dataTable.asMaps(String.class, String.class);
//        new TraversalMaintenance(scenario, driver()).bulkChangeVariableType(maps.get(0));
//    }
//
//    /**
//     * Asserting globalMessages-description
//     *
//     * @param expectedMessage
//     */
//    @Then("^user receives global message \"([^\"]*)\"$")
//    public void userReceivesGlobalMessage(String expectedMessage) {
//        String actualMessage = obj().CommonPage.getGlobalMessagesDescription();
//        Assert.assertEquals(expectedMessage, actualMessage);
//
//        TestUtils.demoBreakPoint(scenario, driver(), expectedMessage);
//    }
//
//    /**
//     * Asserting number of rows dispalayed vs expected from feature file
//     *
//     * @param expectedCount
//     */
//    @Then("^there should be \"([^\"]*)\" rows displayed on the Traversal Maintenance page$")
//    public void thereShouldBeRowsDisplayedOnTheTraversalMaintenancePage(String expectedCount) {
//        String actualCount = obj().TraversalMaintenance.getResultCount();
//        Assert.assertEquals(expectedCount, actualCount);
//    }
//
//    /**
//     * verifying the UI of Bulk Edit Authorization Duration popup modal
//     */
//    @Then("^verify the UI of Bulk Edit Authorization Duration popup modal$")
//    public void verifyTheUIOfBulkEditAuthorizationDurationPopupModal() {
//        TraversalMaintenance tm = new TraversalMaintenance(scenario, driver());
//        tm.applyBulkAction("Edit Authorization Duration");
//        tm.verifyBulkEditAuthorizationUI();
//        obj().BulkEditAuthorizationDurationModalPage.clickCancelLink();
//        obj().BulkEditAuthorizationDurationModalPage.shouldDisappear();
//
//        tm.applyBulkAction("Edit Authorization Duration");
//        obj().BulkEditAuthorizationDurationModalPage.clickXoutButton();
//        obj().BulkEditAuthorizationDurationModalPage.shouldDisappear();
//    }
//
//    /**
//     * User input information on Bulk Edit Authorization Duration page based on dataTable
//     *
//     * @param dataTable
//     */
//    @And("^user input below information on Bulk Edit Authorization Duration page$")
//    public void userInputBelowInformationOnBulkEditAuthorizationDurationPage(DataTable dataTable) {
//        List<Map<String, String>> maps = dataTable.asMaps(String.class, String.class);
//        String value = maps.get(0).get("Duration");
//        new TraversalMaintenance(scenario, driver()).verifyBulkEditAuthorization(value);
//    }
//
//    /**
//     * Authorization requests are added based on pf with retry
//     *
//     * @param dataTable
//     */
//    @Given("^below authorization requests are added$")
//    public void belowAuthorizationRequestsAreAdded(DataTable dataTable) {
//        List<Map<String, String>> maps = DataTableUtils.asMutableMapsTranspose(dataTable);
//        maps = WhiteBoard.resolve(owner, maps);
//        for (Map<String, String> map : maps) {
//            String authorizationObjectName = map.get(AuthorizationRequest.AUTHORIZATION_OBJECT_NAME);
//            if (null != authorizationObjectName && !authorizationObjectName.startsWith("-")) {
//                AuthorizationRequest.addAuthWithRetry(map, owner, scenario);
//            }
//        }
//    }
//
//    /**
//     * Clone and verifies DB this step does not resubmit cloned auth
//     *
//     * @param dataTable
//     */
//    @Then("^clone and verify$")
//    public void cloneAndVerify(DataTable dataTable) {
//        String output = Conf.getOutputPath();
//
//        List<Map<String, String>> maps = DataTableUtils.asMutableMapsTranspose(dataTable);
//        maps = WhiteBoard.resolve(owner, maps);
//        for (Map<String, String> map : maps) {
//            String to = map.get("Clone To");
//            if (null != to && !to.startsWith("-")) {
//                map.put(MBM.AUTH_AUTHORIZATION_TYPE, map.get(AuthorizationRequest.CLONE_TO_AUTHORIZATION_TYPE));
//                Map<String, String> pf = WhiteBoard.resolve(owner, ExcelLib.completeProfile(owner, map));
//                TestUtils.demoBreakPoint(scenario, null, "Cloning: " + pf.toString());
//                WhiteBoard.getInstance().putMap(owner, to + "_" + AuthorizationRequest.OUTCOME_PROFILE, pf);
//
//                String from = map.get("Clone From");
//                String rsf = "${" + from + "_" + AuthorizationRequest.OUTCOME_REQUEST_STATUS + ".%s}";
//                String hscf = "${" + from + "_" + AuthorizationRequest.OUTCOME_HSC_SNAPSHOT + ".%s}";
//                String authNumber = WhiteBoard.resolve(owner, String.format(rsf, MBM.AUTH_REQUEST_NUMBER), String.format(rsf, MBM.AUTH_AUTHORIZATION_NUMBER));
//                String cloneMarker = WhiteBoard.resolve(owner, String.format(rsf, MBM.RPPC_FULL_NAME));
//                long fromHscId = Long.parseLong(WhiteBoard.resolve(owner, String.format(hscf, "hsc-hsc_id")));
//
//                new Retry("cloneAndVerify>" + to) {
//
//                    private WebDriver webDriver = null;
//
//                    @Override
//                    protected void tryOnce() throws StopAtPageException {
//                        this.webDriver = Login.login(scenario, pf);
//                        AuthorizationRequest ar = new AuthorizationRequest(scenario, this.webDriver);
//
//
//                        Map<String, Map<String, String>> draftOutcome = ar.cloneAuth(
//                                authNumber,
//                                map.get("Clone on Page"),
//                                map.get("Clone To Authorization Type"),
//                                map.get("Clone To Cancer"),
//                                map.get("drugCode"),
//                                map.get("Clone To Class"),
//                                fromHscId,
//                                cloneMarker);
//                        WhiteBoard.storeMaps(owner, to, output, draftOutcome);
//
//                        String[] keyFiltersInclude = new String[]{
//                                "cmnctTrans-.*", "hsc-.*", "hscAtr-.*", "hscDiag-.*", "hscFlowupCntc-.*",
//                                "hscProvRf-.*", "hscProvRoleRf-.*", "hscProvSj-.*", "hscProvRoleSj-.*", "hscMsr-.*"
//                        };
//                        MapComparer diff1 = new MapComparer<String, String>(
//                                WhiteBoard.getInstance().getMap(owner, from + "_" + AuthorizationRequest.OUTCOME_HSC_SNAPSHOT),
//                                draftOutcome.get(AuthorizationRequest.OUTCOME_HSC_SNAPSHOT + "_from"), keyFiltersInclude);
//                        MapComparer diff2 = new MapComparer<String, String>(
//                                draftOutcome.get(AuthorizationRequest.OUTCOME_HSC_SNAPSHOT + "_to"),
//                                draftOutcome.get(AuthorizationRequest.OUTCOME_HSC_SNAPSHOT + "_from"), keyFiltersInclude);
//                        final Map<String, CompareReport> TF = diff2.bareLeft();
//                        final Map<String, CompareReport> FT = diff2.bareRight();
//
//                        scenarioLogger.warn("======================diff1=====================");
//                        scenarioLogger.warn("\r\n" + CompareReport.toString(diff1.bareLeft()));
//                        scenarioLogger.warn("\r\n" + CompareReport.toString(diff1.bareRight()));
//                        scenarioLogger.warn("======================diff2=====================");
//                        scenarioLogger.warn("\r\n" + CompareReport.toString(TF));
//                        scenarioLogger.warn("\r\n" + CompareReport.toString(FT));
//
//                        Map<String, String> featureHelper = new LinkedHashMap<>(map);
//                        CompareReport.append(featureHelper, TF, "TF");
//                        CompareReport.append(featureHelper, FT, "FT");
//                        StringBuilder sb = new StringBuilder();
//                        for (String key : featureHelper.keySet()) {
//                            sb.append(key + "\t" + featureHelper.get(key) + "\r\n");
//                        }
//                        scenarioLogger.warn("======================feature helper=====================");
//                        scenarioLogger.warn(sb.toString());
//                        try {
//                            FileUtils.writeStringToFile(new File(output + System.currentTimeMillis() + "_" + to + ".txt"), sb.toString());
//                        } catch (Exception e) {//do nothing
//                        }
//
//                        Set<String> tfKeySet = DataTableUtils.extractKeys(map.keySet(), "TF.*");
//                        for (String table_column : tfKeySet) {
//                            scenarioLogger.warn("Validating To V.S. From: " + table_column);
//                            CompareReport.Status expectedStatus = null;
//                            try {
//                                expectedStatus = CompareReport.Status.valueOf(map.get(table_column));
//                                Assert.assertNotNull(expectedStatus);
//                            } catch (Exception e) {
//                                Assert.fail("Missing or invalid expected status for: " + table_column);
//                            }
//                            CompareReport.Status actualStatus = null;
//                            if (TF.containsKey(table_column.substring(2))) {
//                                actualStatus = TF.get(table_column.substring(2)).getStatus();
//                            }
//                            checkCompareReportStatus(expectedStatus, actualStatus);
//                            scenarioLogger.warn("OK: " + TF.get(table_column.substring(2)).toString());
//                        }
//
//                        Set<String> ftKeySet = DataTableUtils.extractKeys(map.keySet(), "FT.*");
//                        for (String table_column : ftKeySet) {
//                            scenarioLogger.warn("Validating From V.S. To: " + table_column);
//                            CompareReport.Status expectedStatus = null;
//                            try {
//                                expectedStatus = CompareReport.Status.valueOf(map.get(table_column));
//                                Assert.assertNotNull(expectedStatus);
//                            } catch (Exception e) {
//                                Assert.fail("Missing or invalid expected status for: " + table_column);
//                            }
//                            CompareReport.Status actualStatus = null;
//                            if (FT.containsKey(table_column.substring(2))) {
//                                actualStatus = FT.get(table_column.substring(2)).getStatus();
//                            }
//                            checkCompareReportStatus(expectedStatus, actualStatus);
//                            scenarioLogger.warn("OK: " + FT.get(table_column.substring(2)).toString());
//                        }
//
//                        for (String key : TF.keySet()) {
//                            String reportedKey = "TF" + key;
//                            Assert.assertTrue("Unexpected key " + reportedKey, map.containsKey(reportedKey));
//                        }
//
//                        for (String key : FT.keySet()) {
//                            String reportedKey = "FT" + key;
////                            Assert.assertTrue("Unexpected key " + reportedKey, map.containsKey(reportedKey));
//                        }
//
//                        TestUtils.demoBreakPoint(scenario, this.webDriver, "Validation OK");
//
//                        pf.put(ExcelLib.CONTINUE_FROM_PAGE, RequestingProviderPage.class.getName());
//                        pf.put(ExcelLib.STOP_AT_NEXT_PAGE_BEGIN, ClinicalStatusPage.class.getName());
//                        TeamBase team = TeamFactory.getTeam(scenario, pf);
//                        boolean success = team.teamwork(2 * 60 * 1000);
//
//                        String note = success ? "Please review screenshots manually." : "Screenshots missing after Requesting Provider page.";
//                        TestUtils.demoBreakPoint(scenario, this.webDriver, note);
//                    }
//
//                    @Override
//                    protected long getTimeoutMillis() {
//                        // 10 minutes
//                        return 10 * 60 * 1000;
//                    }
//
//                    @Override
//                    protected void timeout() {
//                        String note = "Timeout: " + to;
//                        TestUtils.demoBreakPoint(scenario, this.webDriver, note);
//                        Assert.fail(note);
//                    }
//
//                }.execute();
//
//            }
//        }
//    }
//
//    private void checkCompareReportStatus(CompareReport.Status expectedStatus, CompareReport.Status actualStatus) {
//        scenarioLogger.warn("checkCompareReportStatus: expectedStatus=" + expectedStatus + ", actualStatus=" + actualStatus);
//        switch (expectedStatus) {
//            case UNPREDICTABLE:
//                scenarioLogger.warn("Skip unpredictable");
//                break;
//            case IGNORE:
//                Assert.assertNull(actualStatus);
//                break;
//            case EQUAL:
//            case MISSING:
//            case NOT_EQUAL:
//                Assert.assertEquals(expectedStatus, actualStatus);
//                break;
//            default:
//                Assert.fail("Unknown expected status: " + expectedStatus);
//        }
//    }
//
//    /**
//     * clone auth and submit cloned auth
//     *
//     * @param dataTable
//     */
//    @Then("^clone to submit and verify")
//    public void cloneToSubmitAndVerify(DataTable dataTable) {
//        List<Map<String, String>> maps = DataTableUtils.asMutableMapsTranspose(dataTable);
//        maps = WhiteBoard.resolve(owner, maps);
//        for (Map<String, String> map : maps) {
//            String to = map.get(AuthorizationRequest.CLONE_TO);
//            if (null != to && !to.startsWith("-")) {
//                AuthorizationRequest.cloneWithRetry(map, owner, scenario);
//                String actualAuthStatus = AuthorizationRequest.getAuthStatus(owner, to);
//                String expectedAuthStatus = map.get(MBM.AUTH_AUTHORIZATION_STATUS);
//                Assert.assertEquals(expectedAuthStatus, actualAuthStatus);
//            }
//        }
//    }
//
//    /**
//     * Verifying the UI of Bulk Delete popup modal
//     *
//     * @throws Throwable
//     */
//    @Then("^verify the UI of Bulk Delete popup modal$")
//    public void verifyTheUIOfBulkDeletePopupModal() {
//        TraversalMaintenance tm = new TraversalMaintenance(scenario, driver());
//        tm.applyBulkAction("Delete");
//        tm.verifyBulkDeleteUI();
//        obj().BulkDeleteModalPage.clickCancelLink();
//        obj().BulkDeleteModalPage.shouldDisappear();
//
//        tm.applyBulkAction("Delete");
//        obj().BulkDeleteModalPage.clickXoutButton();
//        obj().BulkDeleteModalPage.shouldDisappear();
//    }
//
//    /**
//     * Writing message at demo breakPoints
//     *
//     * @param message
//     */
//    @Then("^take note \"([^\"]*)\"$")
//    public void takeNote(String message) {
//        TestUtils.demoBreakPoint(scenario, driver(), message);
//
//    }
//
//    /**
//     * User searches the traversal on the Traversal Maintenance page based on datatable
//     *
//     * @param dataTable
//     * @throws Throwable
//     */
//    @Given("^user searches the traversal on the Traversal Maintenance page$")
//    public void userSearchesTheTraversalByBelowCriteriaTheTraversalMaintenancePage(DataTable dataTable) throws InvalidSearchCriteriaException {
//        Map<String, String> theUser = WhiteBoard.getInstance().getMap(owner, ExcelLib.THE_USER);
//        new TraversalMaintenance(scenario, driver()).search(dataTable.asMaps(String.class, String.class).get(0));
//    }
//
//    /**
//     * User searches and remove the traversal on the Traversal Maintenance page
//     *
//     * @param dataTable
//     * @throws Throwable
//     */
//    @Then("^user removes all traversals on the Traversal Maintenance page$")
//    public void userRemovesAllTraversalsOnTheTraversalMaintenancePage(DataTable dataTable) throws InvalidSearchCriteriaException {
//        List<Map<String, String>> data = dataTable.asMaps(String.class, String.class);
//
//        for (Map<String, String> entry : data) {
//            new TraversalMaintenance(scenario, driver()).search(entry);
//            while (obj().TraversalMaintenance.hasResult()) {
//                obj().TraversalMaintenance.removeFirstResut();
//            }
//        }
//    }
//
//    @Given("^\"([^\"]*)\" is \"([^\"]*)\"$")
//    public void is(String key, String value) {
//        String value1 = WhiteBoard.resolve(owner, value);
//        log.warn("value=" + value);
//        log.warn("value1=" + value1);
//
//        WhiteBoard.getInstance().putString(owner, key, value1);
//        scenarioLogger.warn("New string added for " + owner + ": " + key + "=" + value1);
//    }
//
//    @Given("^\"([^\"]*)\" is \"([^\"]*)\" if \"([^\"]*)\"$")
//    public void isif(String key, String value, String conditionExpression) {
//        try {
//            if (WhiteBoard.evaluate(owner, conditionExpression)) {
//                is(key, value);
//            }
//        } catch (EvaluateException e) {
//            //do nothing
//        }
//    }
//
//    @Given("^\"([^\"]*)\" is map \"([^\"]*)\"$")
//    public void isMap(String key, String value) {
//        Map<String, String> map = DataTableUtils.asMap(value);
//        map = WhiteBoard.resolve(owner, map);
//        log.warn("value=" + value);
//        log.warn("map=" + WhiteBoard.getInstance().protect(map));
//
//        WhiteBoard.getInstance().putMap(owner, key, map);
//        scenarioLogger.warn("New map added for " + owner + ": " + key + "=" + map);
//    }
//
//    /**
//     * User adds a request as per passing variables from feature file
//     *
//     * @param pfTitle
//     * @param requestObjectName
//     * @param stringDataTable
//     * @throws Exception
//     */
//    @And("^user adds a \"([^\"]*)\" request \"([^\"]*)\" with \"([^\"]*)\"$")
//    public void userAddsARequestWith(String pfTitle, String requestObjectName, String stringDataTable) {
//        Map<String, String> pf = new LinkedHashMap<>();
//        pf.put(MBM.AUTH_TITLE, pfTitle);
//        pf.putAll(DataTableUtils.asMap(stringDataTable));
//
//        pf = ExcelLib.completeProfile(owner, pf);
//        pf.put(AuthorizationRequest.AUTHORIZATION_OBJECT_NAME, requestObjectName);
//        AuthorizationRequest.addAuthWithRetry(pf, owner, scenario);
//    }
//
//    @And("^user adds a \"([^\"]*)\" request \"([^\"]*)\"$")
//    public void userAddsARequest(String pfTitle, String requestObjectName) {
//        this.userAddsARequestWith(pfTitle, requestObjectName, "0=0");
//    }
//
//    @And("^user adds a \"([^\"]*)\" request \"([^\"]*)\" if \"([^\"]*)\"$")
//    public void userAddsARequestIf(String pfTitle, String requestObjectName, String conditionExpression) throws Throwable {
//        if (WhiteBoard.evaluate(owner, conditionExpression)) {
//            userAddsARequest(pfTitle, requestObjectName);
//        }
//    }
//
//    @When("^user clones \"([^\"]*)\" to \"([^\"]*)\" with \"([^\"]*)\" and stop at page \"([^\"]*)\"$")
//    public void userClonesToWithAndStopAtPage(String from, String to, String stringMap, String stopAtPage) {
//        Map<String, String> map = DataTableUtils.asMap(stringMap);
//        map.put(AuthorizationRequest.CLONE_FROM, from);
//        map.put(AuthorizationRequest.CLONE_TO, to);
//        map.put(ExcelLib.STOP_AT_PAGE, stopAtPage);
//
//        AuthorizationRequest.cloneWithRetry(map, owner, scenario);
//    }
//
//    /**
//     * User selects passing treatmentType(new or continuation of treatment) from feature file  as treatment type on Request Details page
//     *
//     * @param treatmentType
//     */
//    @And("^user selects \"([^\"]*)\" as treatment type on Request Details page$")
//    public void userSelectsAsTreatmentTypeOnRequestDetailsPage(String treatmentType) {
//        treatmentType = WhiteBoard.resolve(owner, treatmentType);
//        obj().RequestDetailsPage.selectDropDownValueInChangingTreatmentTypeSel(treatmentType);
//        if (ExcelLib.RDCD_TREATMENT_CHANGING.equalsIgnoreCase(treatmentType)) {
//            Map<String, String> pf = ExcelLib.instance(ExcelLib.LIB_AUTH_PROFILE).getObjectByTitle(ExcelLib.TITLE_DEFAULT);
//            String[] justifications = ExcelLib.splitJustifications(pf.get(MBM.RDCD_CHANGING_TREATMENT_JUSTIFICATION));
//            for (String justification : justifications) {
//                obj().RequestDetailsPage.changeTreatmentJustificationSelection(justification);
//            }
//        }
//        TestUtils.demoBreakPoint(scenario, driver(), "Select treatment type: " + treatmentType);
//    }
//
//
//    /**
//     * User selects passing drug from feature file as drug type on Request Details page
//     *
//     * @param drugType
//     */
//    @And("^user selects \"([^\"]*)\" as drug type on Request Details page$")
//    public void userSelectsAsDrugTypeOnRequestDetailsPage(String drugType) {
//        obj().RequestDetailsPage.selectDropdownDrugType(drugType);
//    }
//
//    /**
//     * user continues from "page" and submit the request "request" from feature file
//     *
//     * @param fromPage
//     * @param name
//     * @throws Throwable
//     */
//    @Then("^user continues from \"([^\"]*)\" and submit the request \"([^\"]*)\"$")
//    public void userContinuesFromAndSubmitTheRequest(String fromPage, String name) throws Throwable {
//        Map<String, String> pf = WhiteBoard.getInstance().getMap(owner, name + "_" + AuthorizationRequest.OUTCOME_PROFILE);
//        pf.put(ExcelLib.CONTINUE_FROM_PAGE, fromPage);
//        TeamBase team = TeamFactory.getTeam(scenario, pf);
//        boolean success = team.teamwork();
//        Map<String, Map<String, String>> outcome = team.getOutcome();
//        WhiteBoard.storeMaps(owner, name, Conf.getOutputPath(), outcome);
//        Assert.assertTrue(success);
//    }
//
//    /**
//     * userVerifies oldRequest is termed by new request
//     *
//     * @param oldRequestName
//     * @param newRequestName
//     */
//    @And("^user verifies \"([^\"]*)\" is termed by \"([^\"]*)\"$")
//    public void userVerifiesIsTermedBy(String oldRequestName, String newRequestName) {
//        AuthorizationRequest.tryRestore(owner, oldRequestName, null);
//        AuthorizationRequest.tryRestore(owner, newRequestName, null);
//
//        HscSrvcNonFaclDao dao = new HscSrvcNonFaclDao(MyBatisConnectionFactory.getSqlSessionFactory());
//        HscSrvcNonFaclDao icuedao = new HscSrvcNonFaclDao(MyBatisConnectionFactoryICUE.getSqlSessionFactory());
//
//        boolean success = new Retry("userVerifiesIsTermedBy") {
//
//            @Override
//            protected void tryOnce() throws Exception {
//                Date oldRequestStartDate = null;
//                Date oldRequestEndDate = null;
//                String oldAuthNumber = AuthorizationRequest.getAuthNumber(owner, oldRequestName);
//                List<Map<String, Object>> oldSrvcList = dao.selectByAuthNumber(oldAuthNumber);
//
//                if (oldSrvcList.size() == 0) {
//                    oldSrvcList = icuedao.selectByIcueAuthNumber(oldAuthNumber);
//                    int i = 0;
//                    for (Map<String, Object> srvc : oldSrvcList) {
//                        oldSrvcList.set(i, TestUtils.mapKeysToLowerCase(srvc));
//                        i++;
//                    }
//
//                }
//
//                for (Map<String, Object> srvc : oldSrvcList) {
//                    Date srvcStrtDt = (Date) srvc.get("srvc_strt_dt");
//                    Date srvcEndDt = (Date) srvc.get("srvc_end_dt");
//                    if (null == oldRequestStartDate) {
//                        oldRequestStartDate = srvcStrtDt;
//                        oldRequestEndDate = srvcEndDt;
//                    } else {
//                        Assert.assertEquals(oldRequestStartDate, srvcStrtDt);
//                        Assert.assertEquals(oldRequestEndDate, srvcEndDt);
//                    }
//                }
//
//                Date newRequestStartDate = null;
//                Date newRequestEndDate = null;
//                String newAuthNumber = AuthorizationRequest.getAuthNumber(owner, newRequestName);
//                List<Map<String, Object>> newSrvcList = dao.selectByAuthNumber(newAuthNumber);
//                for (Map<String, Object> srvc : newSrvcList) {
//                    Date srvcStrtDt = (Date) srvc.get("srvc_strt_dt");
//                    Date srvcEndDt = (Date) srvc.get("srvc_end_dt");
//                    if (null == newRequestStartDate) {
//                        newRequestStartDate = srvcStrtDt;
//                        newRequestEndDate = srvcEndDt;
//                    } else {
//                        Assert.assertEquals(newRequestStartDate, srvcStrtDt);
//                        Assert.assertEquals(newRequestEndDate, srvcEndDt);
//                    }
//                }
//
//                TestUtils.demoBreakPoint(scenario, null,
//                        "\r\nOld Request " + oldAuthNumber + " StartDate = " + oldRequestStartDate.toString()
//                                + ", EndDate = " + oldRequestEndDate.toString()
//                                + "\r\nNew Request " + newAuthNumber + " StartDate = " + newRequestStartDate.toString()
//                                + ", EndDate = " + newRequestEndDate.toString());
//                Calendar nextDayOfOldRequestEndDate = Calendar.getInstance();
//                nextDayOfOldRequestEndDate.setTime(oldRequestEndDate);
//                nextDayOfOldRequestEndDate.add(Calendar.DATE, 1);
//                if (!(
//                        (oldRequestStartDate.equals(oldRequestEndDate) && oldRequestEndDate.equals(newRequestStartDate))
//                                || nextDayOfOldRequestEndDate.getTime().equals(newRequestStartDate)
//                )) {
//                    throw new RuntimeException("Terming check failed. May need to wait for some time.");
//                }
//            }
//
//            @Override
//            protected long getTimeoutMillis() {
//                return 5 * 60 * 1000;
//            }
//
//        }.execute();
//
//        Assert.assertTrue("Terming check success.", success);
//
//    }
//
//    /**
//     * The member is resetting in DB
//     *
//     * @throws IOException
//     */
//    @Given("^the member is reset$")
//    public void theMemberIsReset() throws IOException {
//        Map<String, String> pf = WhiteBoard.getInstance().getMap(owner, ExcelLib.THE_MEMBER);
//        String subscriberId = pf.get(MBM.MEMB_SUBSCRIBER_ID);
//        new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).resetMember(subscriberId);
//    }
//
//    /**
//     * The authorization request is being cancelled in DB for passing authObject from feature file
//     *
//     * @param authObject
//     */
//    @Given("^the authorization request \"([^\"]*)\" is reset$")
//    public void theAuthorizationRequestIsReset(String authObject) {
//        String authNumber = AuthorizationRequest.getAuthNumber(owner, authObject);
//        new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).resetAuth(authNumber);
//    }
//
//    @When("^user backdates \"([^\"]*)\" to \"([^\"]*)\"$")
//    public void userBackdatesTo(String authObjectName, String backdate) {
//        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
//        WebDriver d = Login.login(scenario, pf);
//        AuthorizationRequest ar = new AuthorizationRequest(scenario, d);
//
//        String authNumber = AuthorizationRequest.getAuthNumber(owner, authObjectName);
//        backdate = WhiteBoard.resolve(owner, backdate);
//        ar.backdate(authNumber, backdate);
//
//        RequestStatusPageWorker worker = new RequestStatusPageWorker(scenario, d, pf);
//        pf.put(ExcelLib.CONTINUE_FROM_PAGE, RequestStatusPage.class.getName());
//        TeamBase team = TeamFactory.getTeam(scenario, pf);
//        boolean success = team.teamwork();
//        Map<String, Map<String, String>> outcome = team.getOutcome();
//        WhiteBoard.storeMaps(owner, authObjectName, Conf.getOutputPath(), outcome);
//        Assert.assertTrue("Fail to collect information from Request Status page.", success);
//    }
//
//    @And("^user searches the submitted authorization by \"([^\"]*)\"$")
//    public void userSearchesTheSubmittedAuthorizationBy(String stringMap) {
//        stringMap = WhiteBoard.resolve(owner, stringMap);
//        log.warn("stringMap=" + stringMap);
//
//        Map<String, String> user = ExcelLib.completeProfile(owner, null);
//        AuthorizationRequest ar = new AuthorizationRequest(scenario, Login.login(scenario, user));
//
//        Map<String, String> pf = DataTableUtils.asMap(stringMap);
//        ar.searchSubmitted(pf);
//    }
//
//    @And("^user searches the history authorization by \"([^\"]*)\"$")
//    public void userSearchesTheHistoryAuthorizationBy(String stringMap) {
//        stringMap = WhiteBoard.resolve(owner, stringMap);
//        log.warn("stringMap=" + stringMap);
//
//        Map<String, String> user = ExcelLib.completeProfile(owner, null);
//        AuthorizationRequest ar = new AuthorizationRequest(scenario, Login.login(scenario, user));
//
//        Map<String, String> pf = DataTableUtils.asMap(stringMap);
//        ar.searchHistory(pf);
//    }
//
//    @And("^user \"([^\"]*)\" the record with \"([^\"]*)\" from the search result on Prior Authorization Requests page$")
//    public void userTheRecordWithFromTheSearchResultOnPriorAuthorizationRequestsPage(String action, String indexExpression) {
//        action = WhiteBoard.resolve(owner, action);
//        indexExpression = WhiteBoard.resolve(owner, indexExpression);
//        log.warn("action=" + action);
//        log.warn("indexExpression=" + indexExpression);
//
//        Map<String, String> user = WhiteBoard.getInstance().getMap(owner, ExcelLib.THE_USER);
//        WebDriver webDriver = Login.login(scenario, user);
//
//        List<Map<String, String>> results = TestUtils.tableAsMaps(webDriver, "//table[@id='hscSearchTableSubmittedID']", -1, 30);
//        Map.Entry<String, String> index = DataTableUtils.asMap(indexExpression).entrySet().iterator().next();
//        Map<String, Map<String, String>> indexedResults = DataTableUtils.dataTableAsMapsIndexedByKeyHeader(index.getKey(), results);
//        Map<String, String> record = indexedResults.get(index.getValue());
//
//        int row = Integer.parseInt(record.get(DataTableUtils.INDEX_ROW_NUMBER));
//        switch (action) {
//            case "clones":
//                TestUtils.click(webDriver, PriorAuthorizationSearchSubmittedPage.cloneIcon(row));
//                break;
//            case "selects":
//                TestUtils.click(webDriver, PriorAuthorizationSearchSubmittedPage.selectIcon(row));
//                break;
//            case "edits":
//                TestUtils.click(webDriver, PriorAuthorizationSearchSubmittedPage.editIcon(row));
//                break;
//            default:
//                throw new RuntimeException("Invalid action: " + action);
//        }
//    }
//
//    @And("^User search for created authorization against \"([^\"]*)\" object on submitted Prior Authorization Search$")
//    public void userSearchForCreatedAuthorizationAgainstObjectOnSubmittedPriorAuthorizationSearch(String objectName) {
//        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
//        String authNumber = AuthorizationRequest.getAuthNumber(owner, objectName);
//        AuthorizationRequest ar = new AuthorizationRequest(scenario, Login.login(scenario, pf));
//        ar.searchSubmittedByAuthNumber(authNumber);
//    }
//
//
//    @And("^User checks the \"([^\"]*)\" and clicks view icon$")
//    public void userChecksTheAndClicksViewIcon(String objectName) {
//        String actualAuthStatus = AuthorizationRequest.getAuthStatus(owner, objectName);
//        String actualAuthNumber = AuthorizationRequest.getAuthNumber(owner, objectName);
//        obj().PriorAuthorizationSearchSubmittedPage.checkColumnElements_Status_SearchSubmitted(actualAuthStatus, actualAuthNumber);
//        obj().PriorAuthorizationSearchSubmittedPage.clickDocumentIconByRequestNumber(actualAuthNumber);
//    }
//
//    @And("^User checks the \"([^\"]*)\" and clicks edit icon$")
//    public void userChecksTheAndClicksEditIcon(String objectName) {
//        String actualAuthStatus = AuthorizationRequest.getAuthStatus(owner, objectName);
//        String actualAuthNumber = AuthorizationRequest.getAuthNumber(owner, objectName);
//        obj().PriorAuthorizationSearchSubmittedPage.checkColumnElements_Status_SearchSubmitted(actualAuthStatus, actualAuthNumber);
//        obj().PriorAuthorizationSearchSubmittedPage.clickEditIconByRequestNumber(actualAuthNumber);
//    }
//
//    @Given("^system property \"([^\"]*)\" is \"([^\"]*)\"$")
//    public void systemPropertyIs(String key, String value) {
//        System.setProperty(key, value);
//        if (Conf.ENVSET.equals(key)) {
//            WhiteBoard.getInstance().refreshProperties();
//        }
//    }
//
//    @And("^User retrieve hsc_id \"([^\"]*)\" from URL$")
//    public void userRetrieveHsc_idByMarker(String hscIdVarName) {
//        String currentUrl = driver().getCurrentUrl();
//        long hscId = TestUtils.getHscIdFromURL(currentUrl);
//        WhiteBoard.getInstance().putString(owner, hscIdVarName, "" + hscId);
//    }
//
//    @And("^User search for draft authorization by hsc_id \"([^\"]*)\" on draft Prior Authorization Search$")
//    public void userSearchForCreatedAuthorizationAgainstObjectOnDraftPriorAuthorizationSearch(String hscIdVarName) {
//        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
//        AuthorizationRequest ar = new AuthorizationRequest(scenario, Login.login(scenario, pf));
//        String hscId = WhiteBoard.resolve(owner, hscIdVarName);
//        ar.searchDraftByHscId(hscId);
//    }
//
//    /**
//     * User verifies PopupAgainst passing checkOption vs passing action
//     *
//     * @param checkOption
//     * @param requestObjectNameList
//     * @param action
//     */
//    @Then("^user verifies \"([^\"]*)\" popup against \"([^\"]*)\" and \"([^\"]*)\"$")
//    public void userVerifiesPopupAgainstAnd(String checkOption, List<String> requestObjectNameList, String action) {
//        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
//        String subcriberId = pf.get(MBM.MEMB_SUBSCRIBER_ID);
//
//        obj().RequestDetailsPage.clickContinueButton();
//        TestUtils.waitElementVisible(driver(), DupTermPopupPage.existingAuthMessageDiv);
//
//        List<String> listOfAuthNum = new ArrayList<>(requestObjectNameList.size());
//
//        for (String requestObjectName : requestObjectNameList) {
//            String authNum;
//            AuthorizationRequest.tryRestore(owner, requestObjectName, pf);
//            authNum = AuthorizationRequest.getAuthNumber(owner, requestObjectName);
//            listOfAuthNum.add(authNum);
//        }
//
//        DupTermCheck dupTermCheck = new DupTermCheck(scenario, driver(), listOfAuthNum, subcriberId);
//        switch (checkOption) {
//            case "Dup Check": {
//                Assert.assertTrue(dupTermCheck.dupPopupOK());
//                break;
//            }
//            case "Term Check": {
//                Assert.assertTrue(dupTermCheck.termPopupOK());
//                break;
//            }
//            case "Initial Treatment Term Check":
//                Assert.assertTrue(dupTermCheck.initialTreatmentTermPopupOK());
//                break;
//            default:
//                Assert.fail("Unknown Dup/Term check option: " + checkOption);
//        }
//
//        switch (action) {
//            case "accept":
//                obj().DupTermPopupPage.clickOK();
//                break;
//            case "continue":
//                obj().DupTermPopupPage.clickContinue();
//                break;
//            default:
//                Assert.fail("Unknown Dup/Term check option: " + action);
//        }
//    }
//
//
//    /**
//     * User verifies PopupAgainst passing checkOption vs passing action
//     *
//     * @param checkOption
//     */
//    @Then("^user verifies \"([^\"]*)\" member blocking popup$")
//    public void userVerifiesMemberBlockingPopup(String checkOption) {
//        MemberBlockingCheck memberBlockingCheck = new MemberBlockingCheck(scenario, driver());
//        switch (checkOption) {
//            case "AuthNotRequired": {
//                TestUtils.wait(4);
//                Assert.assertTrue(memberBlockingCheck.authNotRequired());
//                break;
//            }
//            default:
//                Assert.fail("Unknown Member Blocking option: " + checkOption);
//        }
//    }
//
//    @Then("^User validates table header in Newly Approved Drug screen is in below Order$")
//    public void user_validates_table_header_in_Newly_Approved_Drug_Screen_is_in_below_Order(DataTable arg1) {
//        List<String> expectedLabelList = arg1.asList(String.class);
//        new NewlyApprovedDrugs(scenario, driver()).validatePaginationHeader(expectedLabelList);
//    }
//
//    /**
//     * User Verify when New Drug added the record is saved to NEW_proc
//     */
//
//    @Then("^User verify record is saved in the Newly Approved Drug Table$")
//    public void user_verify_record_is_saved_in_the_Newly_Approved_Drug_Table() {
//        NewProcDao dao = new NewProcDao(MyBatisConnectionFactory.getSqlSessionFactory());
//        List<Map<String, Object>> newproc = dao.selectByBrandName();
//        for (Map<String, Object> entry : newproc) {
//            new NewlyApprovedDrugs(scenario, driver()).validateTheRecordsSavedtoDB(entry);
//        }
//
//    }
//
//    /**
//     * User Deletes the Drug by clicking on Delete Icon based
//     * on Search Criteria provided in Newly Approved Drugs Screen
//     *
//     * @param dataTable
//     * @throws Throwable
//     */
//
//    @Then("^user removes all New Added Drug on the Newly Approved Drugs page$")
//    public void userRemovesAllNewAddedDrugOnTheNewlyApprovedDrugsPage(DataTable dataTable) throws Throwable {
//        List<Map<String, String>> data = dataTable.asMaps(String.class, String.class);
//
//        for (Map<String, String> entry : data) {
//            new NewlyApprovedDrugs(scenario, driver()).search(entry);
//            while (obj().NewlyApprovedDrugsPage.hasResult()) {
//                obj().NewlyApprovedDrugsPage.removeFirstResut();
//            }
//        }
//    }
//
//
//    @And("^user searches for Member$")
//    public void userSearchesForMember() throws Throwable {
//        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
//        pf.put(ExcelLib.STOP_AT_NEXT_PAGE_BEGIN, MemberSearchPage.class.getName());
//        TeamBase team = TeamFactory.getTeam(scenario, pf);
//        boolean success = team.teamwork(2 * 60 * 1000);
//
//        if (!success) {
//            throw new RuntimeException("Timeout: " + pf);
//        }
//    }
//
//    @And("^User clicks view icon for request on Prior Authorization Search and stores \"([^\"]*)\" object$")
//    public void userClicksViewIconOnPrioriAuthSearchAndStoresObject(String objectName) {
//        obj().PriorAuthorizationSearchSubmittedPage.clickDocumentIconByRequestNumber(AuthorizationRequest.getAuthNumber(owner, objectName));
//        this.userStoresObject(objectName);
//    }
//
//    @And("^User verify \"([^\"]*)\" header$")
//    public void userVerifiesHeaderServicingProviderHeader(String header) {
//        obj().RequestSummaryPage.verifytheServicingProviderPharmacyHeader(header);
//    }
//
//    /**
//     * The member is resetting in ICUE DB
//     *
//     * @throws IOException
//     */
//    @Given("^the member is reset in ICUE$")
//    public void theMemberIsResetinICUE() {
//        Map<String, String> pf = WhiteBoard.getInstance().getMap(owner, ExcelLib.THE_MEMBER);
//        String subscriberId = pf.get(MBM.MEMB_SUBSCRIBER_ID);
//        new HscDao(MyBatisConnectionFactoryICUE.getSqlSessionFactory()).resetMemberIcue(subscriberId);
//    }
//
//    @Given("^user reads file from NAS drive with \"([^\"]*)\" and stores in \"([^\"]*)\"$")
//    public void userReadsFileFromNASDriveWithAndStoresIn(String fileName, String NasDriverData) throws Throwable {
//        // Open connection to NAS drive
//        Connection nasConnection = new SMBClient().connect(System.getenv(MBM.NAS_LOCATION));
//        Session session = nasConnection.authenticate(new AuthenticationContext(System.getenv(MBM.NAS_USER), System.getenv(MBM.NAS_PASS).toCharArray(), MBM.MS));
//        DiskShare ndbShare = (DiskShare) session.connectShare(System.getenv(MBM.SHARED_LOCATION));
//        Set<AccessMask> accessMaskSet = new HashSet<>();
//        accessMaskSet.add(AccessMask.GENERIC_READ);
//        com.hierynomus.smbj.share.File smbjfile = ndbShare.openFile(System.getenv(MBM.NAS_SUBFOLDER) + '\\' + fileName, accessMaskSet, null, SMB2ShareAccess.ALL, SMB2CreateDisposition.FILE_OPEN, null);
//        InputStream is = smbjfile.getInputStream();
//        parseFile(is, NasDriverData);
//
//    }
//
//    private void parseFile(InputStream is, String NasDriverData) throws IOException {
//        List<FileIntake> fileRead = new ArrayList<>();
//        Reader reader = new InputStreamReader(is);
//        BufferedReader br = new BufferedReader(reader);
//        String line = "";
//        int lineNumber = 0;
//        while ((line = br.readLine()) != null) {
//            if (lineNumber > 0) {
//                String[] fields = line.split("\\|");
//                FileIntake p = new FileIntake(fields[0], fields[1], fields[2], fields[3], fields[4], fields[5], fields[6], fields[7], fields[8], fields[9], fields[10], fields[11], fields[12], fields[14], fields[15], fields[16], fields[17], fields[18], fields[28], fields[30], fields[31]);
//                fileRead.add(p);
//            }
//            lineNumber = ++lineNumber;
//        }
//        WhiteBoard.getInstance().putFileIntakeListMap(owner, NasDriverData, fileRead);
//    }
//
//
//    @Given("^variables are imported from \"([^\"]*)\"$")
//    public void variablesAreImportedFrom(String propertiesFile) throws Throwable {
//        Properties properties = new Properties();
//        properties.load(new FileReader(new File(propertiesFile)));
//        WhiteBoard.register(owner, properties);
//    }
//
//    @And("^User search for created authorization against \"([^\"]*)\" object on historical Prior Authorization Search$")
//    public void userSearchForCreatedAuthorizationAgainstObjectOnhistoricalPriorAuthorizationSearch(String objectName) {
//        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
//        String providerType = TestUtils.toInitCap(pf.get("ppType"));
//        String TIN = pf.get("rppdProviderTIN");
//        String physicianFirstName = pf.get("rppdProviderFirstName");
//        String physicianLastName = pf.get("rppdProviderLastName");
//        String authNumber = AuthorizationRequest.getAuthNumber(owner, objectName);
//        AuthorizationRequest ar = new AuthorizationRequest(scenario, Login.login(scenario, pf));
//        ar.searchHistoryByAuthNumber(authNumber, TIN, providerType, physicianFirstName, physicianLastName);
//
//    }
//
//    @And("^User checks the \"([^\"]*)\"  on history search page and clicks view icon$")
//    public void userChecksTheOnHistorySearchPageAndClicksViewIcon(String objectName) {
//        String actualAuthNumber = AuthorizationRequest.getAuthNumber(owner, objectName);
//        obj().PriorAuthorizationSearchSubmittedPage.clickDocumentIconByRequestNumber(actualAuthNumber);
//    }
//
//    @And("^User search for created authorization on historical Prior Authorization Search by Member Information$")
//    public void userSearchForCreatedAuthorizationOnHistoricalPriorAuthorizationSearchByMemberInformation() {
//        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
//        AuthorizationRequest ar = new AuthorizationRequest(scenario, Login.login(scenario, pf));
//        String subscriberID = pf.get("membSubscriberID");
//        subscriberID = "00" + subscriberID;
//        String memberLastName = pf.get("membLastName");
//        String memberFirstName = pf.get("membFirstName");
//        String dateofBirth = pf.get("membDateofBirth");
//        ar.searchHistoryByMemberInformation(subscriberID, memberFirstName, memberLastName, dateofBirth);
//    }
//
//    /**
//     * User verifies the Fields position in Add New Drug Pop-Up Model in Newly Approved Drugs Screen
//     *
//     * @param dataTable
//     */
//
//    @When("^User clicks Add New Drug and performs field Validation$")
//    public void user_clicks_and_performs_field_Validation(DataTable dataTable) throws Throwable {
//        List<String> expectedLabelvalues = dataTable.asList(String.class);
//        new NewlyApprovedDrugs(scenario, driver()).fieldValidation(expectedLabelvalues);
//    }
//
//    /**
//     * user verifies the records in not saved and displayed on UI when Clicked on Saved w/o entering all mandatory
//     * fields
//     *
//     * @param dataTable
//     */
//    @Then("^User Verifies the record will not be saved$")
//    public void user_Verifies_the_record_will_not_be_saved(DataTable dataTable) throws Throwable {
//        List<Map<String, String>> maps = WhiteBoard.resolve(owner, dataTable.asMaps(String.class, String.class));
//        Map<String, String> map = null;
//        for (Map<String, String> m : maps) {
//            map = m;
//            new NewlyApprovedDrugs(scenario, driver()).VerifyResultGrid(map);
//        }
//    }
//
//
//    @Then("^User navigates to Drugs Exception Screen successfully$")
//    public void user_navigates_to_Drugs_Exception_Screen_successfully(DataTable arg1) {
//        Map<String, String> map = WhiteBoard.resolve(owner, arg1.asMaps(String.class, String.class).get(0));
//        new DrugExceptions(scenario, driver()).validatePageNavigation(map);
//    }
//
//    /**
//     * User verifies label corresponding values from UI
//     *
//     * @param dataTable
//     */
//    @And("^user verifies Backdating Start Date\\? and Authorization Start Date according to given table on Status page$")
//    public void userVerifiesAccordingToGivenTableOnStatusPage(DataTable dataTable) {
//        List<Map<String, String>> maps = dataTable.asMaps(String.class, String.class);
//        for (Map<String, String> map : maps) {
//            String label = map.get("label");
//            String expected = WhiteBoard.resolve(owner, map.get("expected"));
//            String actual = driver().findElement(By.xpath("//*[@id='serviceDetailsSection']//*[text()='" + expected + "']")).getText();
//            obj().RequestStatusPage.verifyAsperTable(expected, actual, label);
//
//        }
//    }
//
//
//    @Then("^User verify the Search fields in the Drug Exception Screen$")
//    public void user_verify_the_Search_fields_in_the_Drug_Exception_Screen(DataTable arg1) {
//        List<String> expectedLabelvalues = arg1.asList(String.class);
//        new DrugExceptions(scenario, driver()).validateSearchFieldInDrugExceptionScreen(expectedLabelvalues);
//
//    }
//
//    @Then("^User validates table header in Drug Exceptions screen is in below Order$")
//    public void user_validates_table_header_in_Drug_Exceptions_Screen_is_in_below_Order(DataTable arg1) {
//        List<String> expectedLabelList = arg1.asList(String.class);
//        new DrugExceptions(scenario, driver()).validatePaginationHeader(expectedLabelList);
//    }
//
//    @Then("^User clicks Add Drugs Exception Link$")
//    public void User_clicks_Add_Drugs_Exception_Link() {
//        new DrugExceptions(scenario, driver()).clickOnAddDrugException();
//    }
//
//    @Then("^User performs field Validation on Drugs Exception Page$")
//    public void User_performs_field_Validation_on_Drugs_Exception_Page(DataTable arg1) {
//        List<String> expectedLabelvalues = arg1.asList(String.class);
//        new DrugExceptions(scenario, driver()).fieldValidation(expectedLabelvalues);
//    }
//
//    @Then("^User adds below information on Add Drugs Exception Pop Up Page$")
//    public void User_Add_Below_Information_On_Add_Drugs_Exception_Pop_Up_Page(DataTable dataTable) {
//        List<Map<String, String>> maps = WhiteBoard.resolve(owner, dataTable.asMaps(String.class, String.class));
//        Map<String, String> map = null;
//        for (Map<String, String> m : maps) {
//            map = m;
//            new DrugExceptions(scenario, driver()).enterfieldValues(map);
//        }
//    }
//
//    /**
//     * User searches the New Added Drugs based on criteria provided in @param dataTable
//     *
//     * @param dataTable
//     * @throws Throwable
//     */
//    @And("^user searches the added Drug Exceptions by below criteria verifies the data is displayed$")
//    public void userSearchesTheAddedDrugExceptionsByBelowCriteriaVerifiesTheDataIsDisplayed(DataTable dataTable) throws InvalidSearchCriteriaException {
//        List<Map<String, String>> maps = WhiteBoard.resolve(owner, dataTable.asMaps(String.class, String.class));
//        Map<String, String> map = null;
//        for (Map<String, String> m : maps) {
//            map = m;
//            new DrugExceptions(scenario, driver()).search(map);
//        }
//    }
//
//    @Then("^user verifies objects with prefix \"([^\"]*)\" matches below table$")
//    public void userVerifiesObjectsWithPrefixMatchesBelowTable(String prefix, List<Map<String, String>> mapsExpected) throws Throwable {
//        List<Map<String, String>> mapsActual = WhiteBoard.getInstance().combine(owner, prefix);
//        MapsComparer mapsComparer = new MapsComparer(mapsExpected, mapsActual, scenarioLogger);
//        mapsComparer.assertMatches();
//    }
//
//    @Then("^user verifies objects with prefix \"([^\"]*)\" looks like below table$")
//    public void userVerifiesObjectsWithPrefixLooksLikeBelowTable(String prefix, List<Map<String, String>> mapsExpected) throws Throwable {
//        List<Map<String, String>> mapsActual = WhiteBoard.getInstance().combine(owner, prefix);
//        MapsComparer mapsComparer = new MapsComparer(mapsExpected, mapsActual, scenarioLogger);
//        mapsComparer.assertMatches(false);
//    }
//
//    @Then("^user verifies objects \"([^\"]*)\" matches objects \"([^\"]*)\" using below mapping ignoring keys \"([^\"]*)\"$")
//    public void userVerifiesObjectsMatchesObjectsMappingInBelowOrder(String prefixActual, String prefixExpecetd, String ignoringLeys, List<Map<Integer, Integer>> mappings) {
//        List<Map<String, String>> mapsActual = WhiteBoard.getInstance().combine(owner, prefixActual);
//        List<Map<String, String>> mapsExpecetd = WhiteBoard.getInstance().combine(owner, prefixExpecetd);
//        MapsComparer mapsComparer = new MapsComparer(mapsExpecetd, mapsActual, scenarioLogger);
//        mapsComparer.setIgnoredKeys(ignoringLeys.split(","));
//        mapsComparer.assertMatches(true, mappings.get(0));
//    }
//
//    @Then("^user verifies objects \"([^\"]*)\" matches objects \"([^\"]*)\" on key \"([^\"]*)\" using below mapping$")
//    public void userVerifiesObjectsMatchesObjectsOnKeyUsingBelowMapping(String prefixActual, String prefixExpecetd, String anchorKey, List<Map<String, String>> mappings) {
//        List<Map<String, String>> mapsActual = WhiteBoard.getInstance().combine(owner, prefixActual);
//        List<Map<String, String>> mapsExpected = WhiteBoard.getInstance().combine(owner, prefixExpecetd);
//        MapsComparer mapsComparer = new MapsComparer(mapsExpected, mapsActual, scenarioLogger);
//        mapsComparer.assertMatches(true, anchorKey, mappings.get(0));
//    }
//
//    @Then("^user verifies objects \"([^\"]*)\" matches objects \"([^\"]*)\" on key \"([^\"]*)\"$")
//    public void userVerifiesObjectsMatchesObjectsOnKey(String prefixActual, String prefixExpecetd, String anchorKey) {
//        List<Map<String, String>> mapsActual = WhiteBoard.getInstance().combine(owner, prefixActual);
//        List<Map<String, String>> mapsExpected = WhiteBoard.getInstance().combine(owner, prefixExpecetd);
//        MapsComparer mapsComparer = new MapsComparer(mapsExpected, mapsActual, scenarioLogger);
//        mapsComparer.assertMatches(true, anchorKey, null);
//    }
//
//    @Given("^date \"([^\"]*)\" with format \"([^\"]*)\" is \"([^\"]*)\" days after date \"([^\"]*)\" with format \"([^\"]*)\"$")
//    public void dateWithFormatIsDaysAfterDateWithFormat(String dateToName0, String formatTo0, String days0, String dateFrom0, String formatFrom0) throws ParseException {
//        String dateToName1 = WhiteBoard.resolve(owner, dateToName0);
//        String formatTo1 = WhiteBoard.resolve(owner, formatTo0);
//        String days1 = WhiteBoard.resolve(owner, days0);
//        String dateFrom1 = WhiteBoard.resolve(owner, dateFrom0);
//        String formatFrom1 = WhiteBoard.resolve(owner, formatFrom0);
//
//        int days = Integer.parseInt(days1);
//
//        if (StringUtils.isEmpty(formatTo1)) {
//            formatTo1 = "MM-dd-yyyy";
//        }
//        if (StringUtils.isEmpty(formatFrom1)) {
//            formatFrom1 = "MM-dd-yyyy";
//        }
//        Date dateFrom = new SimpleDateFormat(formatFrom1).parse(dateFrom1);
//        Date dateTo = DateUtils.addTo(dateFrom, days, Calendar.DATE);
//        String dateToValue = new SimpleDateFormat(formatTo1).format(dateTo);
//
//        WhiteBoard.getInstance().putString(owner, dateToName1, dateToValue);
//    }

}


