package atdd.test.stepdefinitions;


import atdd.test.shared.BaseCucumber;
import atdd.test.stepsets.Login;
import atdd.utils.*;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;


public class Hooks {
    WebDriver driver;
    public static final Logger log = Logger.getLogger(Hooks.class.getName());
    RallyUtils rallyUtils = new RallyUtils();
    public Scenario scenario;
    public String testFoldername;
    public String build = Conf.getInstance().getProperty("envset");

    static {
        WhiteBoard.getInstance().register(Conf.getInstance());
    }


    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        BaseCucumber.setUp();
        build = Conf.getInstance().getProperty("envset").trim();
    }

    @After
    public void tearDown(Scenario scenario) throws Throwable {
        try {
            Login.quitScenarioLogins(scenario);
            if (scenario.isFailed()) {
                TestUtils.demoBreakPoint(scenario, driver(), "Last screenshot:");
            }
        } catch (Throwable t) {
            t.printStackTrace();
            scenario.write(t.getMessage());
            // do nothing
        }

        try {
            MemberKeeper.getInstance().releaseByOwner(scenario.getId());
        } catch (Throwable t) {
            t.printStackTrace();
            scenario.write(t.getMessage());
        }

        System.out.println("######################+++++++++++++++++++" + scenario.getId());
    }

    @After
    public void after(Scenario scenario) throws Throwable {
        boolean rally = Boolean.parseBoolean(Conf.getInstance().getProperty("rallyutils"));
        if (rally) {
            try {
                String owner = scenario.getId();
                build = WhiteBoard.getInstance().getString(owner, "build");
                if(build==null)
                {
                    build=Conf.getInstance().getProperty("envset");
                }
                String status = rallyUtils.scenarioStatus(scenario.getStatus());
                String featureName = scenario.getId().split(";")[0];

                if (scenario.getSourceTagNames().size() == 1) {
                    for (String tag : scenario.getSourceTagNames()) {
                        if (tag.contains("Smoke")) {
                            testFoldername = tag.substring(1);
                            rallyUtils.updateRallyWithResultSmoke(testFoldername, status, build, scenario.getName());
                            break;
                        }
                    }
                } else {
                    boolean flag = false;
                    for (String tag : scenario.getSourceTagNames()) {
                        if (tag.startsWith("@Capability_")) {
                            testFoldername = tag.substring(1);
                            if (!rallyUtils.verifyTestFolderInRally(testFoldername))
                            {
                                rallyUtils.createTestFolder(testFoldername,"Regression_Suite");
                            }
                            rallyUtils.updateRallyWithResult(featureName, testFoldername, status, build, scenario.getName());
                            flag = true;
                            break;

                        }
                    }
                        if (!rallyUtils.verifyforTestcaseInRally(scenario.getName())) {
                            rallyUtils.createTestCaseinTestFolder(featureName, scenario.getName());
                        }
                        rallyUtils.UpdateTCStatusInRally(scenario.getName(), status, build);
                    }


            } catch (Exception e) {
                log.warn("error in rallyutils");
            }
        } else {
            log.warn("rally is not set true");
        }
    }
}



