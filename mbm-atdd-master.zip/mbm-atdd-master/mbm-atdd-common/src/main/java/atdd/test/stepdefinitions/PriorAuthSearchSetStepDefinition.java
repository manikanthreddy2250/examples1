package atdd.test.stepdefinitions;

import atdd.common.*;
import atdd.test.pageobjects.*;
import atdd.test.stepsets.*;
import atdd.utils.*;
import cucumber.api.*;
import cucumber.api.java.*;
import cucumber.api.java.en.*;
import org.apache.log4j.*;
import org.openqa.selenium.*;

import java.util.*;

public class PriorAuthSearchSetStepDefinition {
    public static final Logger log = Logger.getLogger(FullSetStepDefinition.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }

    @And("^user searches the submitted authorization by \"([^\"]*)\"$")
    public void userSearchesTheSubmittedAuthorizationBy(String stringMap) throws Throwable {
        stringMap = WhiteBoard.resolve(owner, stringMap);
        log.warn("stringMap=" + stringMap);

        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        AuthorizationRequest ar = new AuthorizationRequest(scenario, Login.login(scenario, pf));

        Map<String, String> criteria = DataTableUtils.asMap(stringMap);
        ar.searchSubmitted(criteria);
    }

    @And("^user searches the history authorization by \"([^\"]*)\"$")
    public void userSearchesTheHistoryAuthorizationBy(String stringMap) throws Throwable {
        stringMap = WhiteBoard.resolve(owner, stringMap);
        log.warn("stringMap=" + stringMap);

        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        AuthorizationRequest ar = new AuthorizationRequest(scenario, Login.login(scenario, pf));

        Map<String, String> criteria = DataTableUtils.asMap(stringMap);
        ar.searchHistory(criteria);
    }


    @And("^User search for created authorization against \"([^\"]*)\" object on submitted Prior Authorization Search$")
    public void userSearchForCreatedAuthorizationAgainstObjectOnSubmittedPriorAuthorizationSearch(String objectName) throws Throwable {
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        String authNumber = AuthorizationRequest.getAuthNumber(owner, objectName);
        AuthorizationRequest ar = new AuthorizationRequest(scenario, Login.login(scenario, pf));
        ar.searchSubmittedByAuthNumber(authNumber);
    }


    @And("^User checks the \"([^\"]*)\" and clicks view icon$")
    public void userChecksTheAndClicksViewIcon(String objectName) throws Throwable {
        String actualAuthStatus = AuthorizationRequest.getAuthStatus(owner, objectName);
        String actualAuthNumber = AuthorizationRequest.getAuthNumber(owner, objectName);
        obj().PriorAuthorizationSearchSubmittedPage.checkColumnElements_Status_SearchSubmitted(actualAuthStatus, actualAuthNumber);
        obj().PriorAuthorizationSearchSubmittedPage.clickDocumentIconByRequestNumber(actualAuthNumber);
    }


    @And("^User search for draft authorization by hsc_id \"([^\"]*)\" on draft Prior Authorization Search$")
    public void userSearchForCreatedAuthorizationAgainstObjectOnDraftPriorAuthorizationSearch(String hscIdVarName) throws Throwable {
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        AuthorizationRequest ar = new AuthorizationRequest(scenario, Login.login(scenario, pf));
        String hscId = WhiteBoard.resolve(owner, hscIdVarName);
        ar.searchDraftByHscId(hscId);
    }


    @And("^User clicks view icon for request on Prior Authorization Search and stores \"([^\"]*)\" object$")
    public void userClicksViewIconOnPrioriAuthSearchAndStoresObject(String objectName) throws Throwable {
        obj().PriorAuthorizationSearchSubmittedPage.clickDocumentIconByRequestNumber(AuthorizationRequest.getAuthNumber(owner, objectName));
        CommonSetStepDefinition common = new CommonSetStepDefinition();
        common.userStoresObject(objectName);
    }

    @And("^User search for created authorization against \"([^\"]*)\" object on historical Prior Authorization Search$")
    public void userSearchForCreatedAuthorizationAgainstObjectOnhistoricalPriorAuthorizationSearch(String objectName) throws Throwable {
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        String providerType = TestUtils.toInitCap(pf.get("ppType"));
        String TIN = pf.get("rppdProviderTIN");
        String physicianFirstName = pf.get("rppdProviderFirstName");
        String physicianLastName = pf.get("rppdProviderLastName");
        String authNumber = AuthorizationRequest.getAuthNumber(owner, objectName);
        AuthorizationRequest ar = new AuthorizationRequest(scenario, Login.login(scenario, pf));
        ar.searchHistoryByAuthNumber(authNumber, TIN, providerType, physicianFirstName, physicianLastName);

    }

    @And("^User checks the \"([^\"]*)\"  on history search page and clicks view icon$")
    public void userChecksTheOnHistorySearchPageAndClicksViewIcon(String objectName) throws Throwable {
        String actualAuthNumber = AuthorizationRequest.getAuthNumber(owner, objectName);
        obj().PriorAuthorizationSearchSubmittedPage.clickDocumentIconByRequestNumber(actualAuthNumber);
    }

    @And("^User search for created authorization on historical Prior Authorization Search by Member Information$")
    public void userSearchForCreatedAuthorizationOnHistoricalPriorAuthorizationSearchByMemberInformation() throws Throwable {
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        AuthorizationRequest ar = new AuthorizationRequest(scenario, Login.login(scenario, pf));
        String subscriberID = pf.get("membSubscriberID");
        subscriberID = "00" + subscriberID;
        String memberLastName = pf.get("membLastName");
        String memberFirstName = pf.get("membFirstName");
        String dateofBirth = pf.get("membDateofBirth");
        ar.searchHistoryByMemberInformation(subscriberID, memberFirstName, memberLastName, dateofBirth);
    }

}


