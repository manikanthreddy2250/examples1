package atdd.test.stepdefinitions.RegimenMaintenance;

import atdd.common.Retry;
import atdd.common.ScenarioLogger;
import atdd.test.pageobjects.regimenMaintenance.DiseaseTraversalMicroServices;
import atdd.utils.QuickHttp;
import atdd.utils.StringUtils;
import atdd.utils.WhiteBoard;
import com.jayway.restassured.response.Response;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;
import org.junit.Assert;


public class DiseaseTraversalMicroServicesStepDefination {
    public static final Logger log = Logger.getLogger(DiseaseTraversalMicroServicesStepDefination.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }

    @And("^User performs an elastic search$")
    public void userPerformsAnElasticSearch() throws Throwable {
        //  elasticSearchApi();
    }

    @And("^User performs an elastic search using Query$")
    public void userPerformsAnElasticSearchUsingQuery() throws Throwable {
        DiseaseTraversalMicroServices.elasticSearchApiQuery();
    }

    @Then("^user validates \"([^\"]*)\" response \"([^\"]*)\" and \"([^\"]*)\"$")
    public void userValidatesResponseAnd(String sourceString, String treatmentRegimenID, String treatmentRegimenName) throws Throwable {
        sourceString = WhiteBoard.resolve(owner, sourceString);
        DiseaseTraversalMicroServices.userValidatesResponse(sourceString, treatmentRegimenID, treatmentRegimenName);
    }

    @Then("^user validates \"([^\"]*)\" response of the Create$")
    public void userValidatesResponseOfTheCreate(String sourceString) throws Throwable {
        sourceString = WhiteBoard.resolve(owner, sourceString);
        DiseaseTraversalMicroServices.userValidatesResponseCreate(sourceString);
    }

    @Then("^user validates \"([^\"]*)\" response of the List Cinical Variables$")
    public void userValidatesResponseOfTheListCinicalVariables(String sourceString) throws Throwable {
        sourceString = WhiteBoard.resolve(owner, sourceString);
        DiseaseTraversalMicroServices.userValidatesResponseListClinialAndSource(sourceString);
    }

    @Then("^user validates \"([^\"]*)\" response for the Index$")
    public void userValidatesResponseForTheIndex(String sourceString) throws Throwable {
        sourceString = WhiteBoard.resolve(owner, sourceString);
        DiseaseTraversalMicroServices.jsonResponse(sourceString);
    }

    @Then("^user validates \"([^\"]*)\" response after Delete$")
    public void userValidatesResponseAfterDelete(String sourceString) throws Throwable {
        sourceString = WhiteBoard.resolve(owner, sourceString);
        DiseaseTraversalMicroServices.jsonResponseDelete(sourceString);
    }

     @When("^service \"([^\"]*)\" is called with request \"([^\"]*)\" and response \"([^\"]*)\" with Status code \"([^\"]*)\"$")
    public void serviceIsCalledWithRequestAndResponseWithStatusCode(String wsName, String reqBodyOrFile, String resBodyStringName, int statusCode) throws Throwable {
        Retry retry = new Retry("serviceIsCalledWithRequestAndResponse", 60 * 1000, 5 * 1000, 0) {
            @Override
            protected void tryOnce() throws Exception {
                Response res = QuickHttp.http(wsName, reqBodyOrFile, owner);
                if ( statusCode!= res.getStatusCode()) {
                    throw new RuntimeException("Error response status: " + res.getStatusCode());
                }
                this.outcomeCompleted = res;
            }
        };
        Assert.assertTrue("Calling service " + wsName + "success.", retry.execute());

        Response res = (Response) retry.getOutcomeCompleted();
        String resBody = res.body().asString();
        log.warn("resBody=" + resBody);
        resBodyStringName = WhiteBoard.resolve(owner, resBodyStringName);
        if (StringUtils.isEmpty(resBodyStringName)) {
            log.warn("No string name specified:" + resBodyStringName);
            // do nothing
        } else {
            WhiteBoard.getInstance().putString(owner, resBodyStringName, resBody);
            scenarioLogger.warn("New string added for " + owner + ": " + resBodyStringName + "=" + resBody);
        }
    }

    @And("^\"([^\"]*)\" is extracted from \"([^\"]*)\"$")
    public void isExtractedFrom(String varName, String sourceString){
        String varName1 = WhiteBoard.resolve(owner, varName);
        log.warn("varName=" + varName);
        log.warn("varName1=" + varName1);
        String realOwner = owner;
        String[] p = varName.split("\\.", 2);
        if (2 == p.length) {
            realOwner = p[0];
            varName1 = p[1];
            log.warn("varName1=" + varName1);
        }
        String response = WhiteBoard.resolve(owner,sourceString);
        String value = DiseaseTraversalMicroServices.getDocID(response);
        value = value.trim();
        String value1 = WhiteBoard.resolve(owner, value);
        log.warn("value=" + value);
        log.warn("value1=" + value1);
        WhiteBoard.getInstance().putString(realOwner, varName1, value1);
        scenarioLogger.warn("New string added for " + realOwner + ": " + varName1 + "=" + value1);
    }

    @Then("^user validates \"([^\"]*)\" response \"([^\"]*)\" and \"([^\"]*)\" not present$")
    public void userValidatesResponseAndNotPresent(String sourceString, String treatmentRegimenID, String treatmentRegimenName) {
        sourceString = WhiteBoard.resolve(owner, sourceString);
        DiseaseTraversalMicroServices.userValidatesResponseNegative(sourceString, treatmentRegimenID, treatmentRegimenName);
    }
}

