package atdd.test.stepdefinitions.RegimenMaintenance;

import atdd.common.ScenarioLogger;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.pageobjects.regimenMaintenance.EditTraversalLinkagePage;
import atdd.test.stepdefinitions.newlyApprovedDrugs.NewlyApprovedDrugsSetStepDefinition;
import atdd.test.stepsets.Login;
import atdd.utils.ExcelLib;
import atdd.utils.WhiteBoard;
import cucumber.api.DataTable;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import java.util.List;
import java.util.Map;

public class EditTraversalLinkageSetStepDefinition {

    public static final Logger log = Logger.getLogger(NewlyApprovedDrugsSetStepDefinition.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }

    @Given("^user selects Pathway Assignment as \"([^\"]*)\" on Edit Traversal Linkage Page$")
    public void user_selects_Pathway_Assignment_as_on_Edit_Traversal_Linkage_Page(String assignment) throws Throwable {
         new EditTraversalLinkagePage(scenario,driver()).selectPathwayAssignmentDropdown(assignment);
    }

    @Then("^user verifies \"([^\"]*)\" dropdown is visible and is Required field$")
    public void user_verifies_dropdown_is_visible_and_is_Required_field(String payer) throws Throwable {
          new EditTraversalLinkagePage(scenario, driver()).payerDropdownIsRequired(payer);
    }


    @Then("^User verifies \"([^\"]*)\" is bordered red and \"([^\"]*)\" and \"([^\"]*)\" message on Edit Traversal Linkage$")
    public void user_verifies_is_bordered_red_and_message_on_Edit_Traversal_Linkage(String arg1, String arg2, String arg3) throws Throwable {
        new EditTraversalLinkagePage(scenario, driver()).fieldValidationAndPopUp(arg1, arg2, arg3);
    }

    @When("^user Attaches Link/Unlink Traversal by below Criteria on the Edit Traversal Linkage Page$")
    public void user_Attaches_Link_Unlink_Traversal_by_below_Criteria_on_the_Edit_Traversal_Linkage_Page(DataTable dataTable) throws Throwable {
        Map<String, String> theUser = WhiteBoard.getInstance().getMap(owner, ExcelLib.THE_USER);
        Login.login(scenario, theUser);
        List<Map<String, String>> maps = WhiteBoard.resolve(owner, dataTable.asMaps(String.class, String.class));
        new EditTraversalLinkagePage(scenario, driver()).attachTraversal(maps);

    }

    @Given("^user selects \"([^\"]*)\" from the Payer dropdown$")
    public void user_selects_from_the_Payer_dropdown(String arg1) throws Throwable {
        new EditTraversalLinkagePage(scenario, driver()).selectPayerValue(arg1);
    }

    @Then("^user verifies Payer should display \"([^\"]*)\"$")
    public void user_verifies_Payer_should_display(String SelectedValue) throws Throwable {
        new EditTraversalLinkagePage(scenario, driver()).verifySelectedValueDisplayed(SelectedValue);
    }

    @Given("^user selects Radio selector \"([^\"]*)\" for Pathway field$")
    public void user_selects_Radio_selector_for_Pathway_field(String arg1) throws Throwable {
        new EditTraversalLinkagePage(scenario, driver()).selectPathwayRadioSelectors(arg1);
    }

    @Then("^user verifies Auto-Approved is Enabled$")
    public void user_verifies_Auto_Approved_is_Enabled() throws Throwable {
        new EditTraversalLinkagePage(scenario, driver()).VerifyAutoapprovedIsEnabled();
    }

    @Given("^user selects Radio selector \"([^\"]*)\" for Auto-Approved field$")
    public void user_selects_Radio_selector_for_Auto_Approved_field(String arg1) throws Throwable {
        new EditTraversalLinkagePage(scenario, driver()).selectautoApprovedRadioSelectors(arg1);
    }

    @Then("^user verifies a traversal action row is added to table with \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" and \"([^\"]*)\"$")
    public void user_verifies_a_traversal_action_row_is_added_to_table_with_and(String arg1, String arg2, String arg3, String arg4) throws Throwable {
        new EditTraversalLinkagePage(scenario, driver()).traversalActionAddedtoTable(arg1,arg2,arg3,arg4);
    }

    @Then("^user validates default values for Search fields on Edit Traversal Linkage Page$")
    public void user_validates_default_values_for_Search_fields_on__Edit_Traversal_Linkage_Page(DataTable dataTable) throws Throwable {
        List<Map<String, String>> maps = WhiteBoard.resolve(owner, dataTable.asMaps(String.class, String.class));
        new EditTraversalLinkagePage(scenario, driver()).editTraversalLinkageFieldsDefaultValues(maps);
    }

    @When("^user selects all the mandatory fields on the Edit Traversal Linkage Page$")
    public void user_selects_all_the_mandatory_fields_on_the_Edit_Traversal_Linkage_Page(DataTable dataTable) throws Throwable {
        List<Map<String, String>> maps = WhiteBoard.resolve(owner, dataTable.asMaps(String.class, String.class));
        new EditTraversalLinkagePage(scenario, driver()).enterAllMandatoryFields(maps);
    }

    @Then("^user sees an field-level \"([^\"]*)\"$")
    public void user_sees_an_field_level(String arg1) throws Throwable {
        new EditTraversalLinkagePage(scenario, driver()).fieldLevelValidation(arg1);

    }

    @Then("^user verifies Pathway fields on the Edit Traversal Linkage Page$")
    public void user_verifies_Pathway_fields_on_the_Edit_Traversal_Linkage_Page() throws Throwable {
        new EditTraversalLinkagePage(scenario, driver()).pathwayFieldDisplay();
    }

    @When("^User selects \"([^\"]*)\" from Action Dropdown on Edit Traversal Linkage Page$")
    public void user_selects_from_Action_Dropdown_on_Edit_Traversal_Linkage_Page(String arg1) throws Throwable {
        new EditTraversalLinkagePage(scenario, driver()).selectActionOnEditTraversalLinkagePage(arg1);
    }

    @When("^user selects \"([^\"]*)\" from Cancer Type Dropdown on Edit Travesal Linkage Page$")
    public void user_selects_from_Cancer_Type_Dropdown_on_Edit_Travesal_Linkage_Page(String arg1) throws Throwable {
        new EditTraversalLinkagePage(scenario, driver()).selectCancerTypeOnEditTraversalLinkagePage(arg1);
    }

    @Then("^user verifies \"([^\"]*)\" is bordered red and \"([^\"]*)\" when clinical values not selected and dropdown closed$")
    public void user_verifies_is_bordered_red_and_when_clinical_values_not_selected_and_dropdown_closed(String arg1, String arg2) throws Throwable {
        new EditTraversalLinkagePage(scenario, driver()).openAndClosesClinicalVariableDropdown(arg1, arg2);
    }

    @And("^user selects the below criteria on Edit Traversal Linkage Page$")
    public void userSelectsTheBelowCriteriaOnEditTraversalLinkagePage(DataTable table) throws Throwable {
        List<Map<String, String>> maps = WhiteBoard.resolve(owner, table.asMaps(String.class, String.class));
        new EditTraversalLinkagePage(scenario, driver()).entertheCriteria(maps);
    }

    @And("^user selects Pathway Client as \"([^\"]*)\"$")
    public void userSelectsPathwayClientAs(String client) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        new EditTraversalLinkagePage(scenario, driver()).selectClient(client);

    }

    @And("^user deletes the traversal added$")
    public void userDeletesTheTraversalAdded() throws Throwable {
        new EditTraversalLinkagePage(scenario, driver()).deleteTraversal();

    }
}
