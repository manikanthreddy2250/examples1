package atdd.test.stepdefinitions.RegimenMaintenance;

import atdd.common.ScenarioLogger;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.pageobjects.regimenMaintenance.RegimenMaintenancePage;
import atdd.test.stepdefinitions.authorization.RequestingProviderStepDefinition;
import atdd.test.stepsets.Login;
import atdd.utils.LocationUtils;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;

public class RegimenMaintenanceStepDefinition {

    public static final Logger log = Logger.getLogger(RequestingProviderStepDefinition.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }


    @Given("^user click on \"([^\"]*)\" hyperlink on Regimen Maintenance$")
    public void user_click_on_hyperlink_on_Regimen_Maintenance(String hyperLink) throws Throwable {
        obj().CommonPage.clickOnHyperlink(hyperLink);
    }

    @And("^user click on \"([^\"]*)\" hyperlink on Add Regimen Page$")
    public void userClickOnHyperlinkOnAddRegimenPage(String addProcedureHyperLink) throws Throwable {
        obj().CommonPage.clickOnHyperlink(addProcedureHyperLink);
    }


    @Then("^user verifies header \"([^\"]*)\" on Add Procedure popup$")
    public void userVerifiesHeaderOnAddProcedurePopup(String addProcedureHeader) throws Throwable {
        obj().RegimenMaintenancePage.verifyHeaderTextOfAddProcedurePopUp(addProcedureHeader);
    }


    @And("^User verifies Procedure Drug Brand label present in Add Procedure PopUp$")
    public void userVerifiesProcedureDrugBrandLabelPresentInAddProcedurePopUp() throws Throwable {
        obj().RegimenMaintenancePage.verifyProcedureDrugBrandLabel();

    }


    @And("^User selects \"([^\"]*)\" from the \"([^\"]*)\" dropdown list in Add Procedure PopUp$")
    public void userSelectsFromTheDropdownListInAddProcedurePopUp(String procedureCodeDropDownValue, String procedureCodeDropDownLabel) throws Throwable {
        obj().RegimenMaintenancePage.chooseProcedureCodeType(procedureCodeDropDownValue, procedureCodeDropDownLabel);
    }


    @And("^User Selects \"([^\"]*)\" as drug code in Add Procedure  PopUp$")
    public void userSelectsAsDrugCodeInAddProcedurePopUp(String procedureCode) throws Throwable {
        obj().RegimenMaintenancePage.enterDrugCode(procedureCode);
    }

    @And("^User enters \"([^\"]*)\" as Procedure Frequency in Add Procedure PopUp$")
    public void userEntersAsProcedureFrequencyInAddProcedurePopUp(String procedureFrequency) throws Throwable {
        obj().RegimenMaintenancePage.enterProcedureFrequency(procedureFrequency);
    }

    @And("^User enters \"([^\"]*)\" as procedure Duration Description in Add Procedure PopUp$")
    public void userEntersAsProcedureDurationDescriptionInAddProcedurePopUp(String procedureDurationDescription) throws Throwable {
        obj().RegimenMaintenancePage.enterProcedureDurationDescription(procedureDurationDescription);

    }

    @And("^User Selects \"([^\"]*)\" as drug Route in Add Procedure  PopUp$")
    public void userSelectsAsDrugRouteInAddProcedurePopUp(String drugRoute) throws Throwable {
        obj().RegimenMaintenancePage.selectDrugRoute(drugRoute);
    }

    @And("^User enters \"([^\"]*)\" as cycle to be administered in Add Procedure PopUp$")
    public void userEntersAsCycleToBeAdministeredInAddProcedurePopUp(String cycles) throws Throwable {
        obj().RegimenMaintenancePage.enterCycleToBeAdministered(cycles);
    }

    @And("^User selects \"([^\"]*)\" as therapy Type in Add Procedure  PopUp$")
    public void userSelectsAsTherapyTypeInAddProcedurePopUp(String therapyType) throws Throwable {
        obj().RegimenMaintenancePage.selectTherapyType(therapyType);
    }

    @And("^User enters \"([^\"]*)\" as length Of Cycles in Add Procedure PopUp$")
    public void userEntersAsLengthOfCyclesinAddProcedurePopUp(String lengthOfCycles) throws Throwable {
        obj().RegimenMaintenancePage.enterLengthOfCycles(lengthOfCycles);

    }

    @And("^User enters \"([^\"]*)\" as Cycle Count Desc  in Add Procedure PopUp$")
    public void userEntersAsCycleCountDescInAddProcedurePopUp(String cycleCountDesc) throws Throwable {
        obj().RegimenMaintenancePage.entercycleCount(cycleCountDesc);

    }

    @And("^User enters \"([^\"]*)\" as dosage in Add Procedure PopUp$")
    public void userEntersAsDosageInAddProcedurePopUp(String dosage) throws Throwable {
        obj().RegimenMaintenancePage.enterDosage(dosage);

    }

    @And("^User clicks Save button on Add Procedure PopUp$")
    public void userClicksSaveButtonOnAddProcedurePopUp() throws Throwable {
        obj().RegimenMaintenancePage.clickSaveButton();

    }


    @And("^User Selects \"([^\"]*)\" as procedure Drug Brand from the type ahead dropdown in Add Procedure PopUp$")
    public void userSelectsAsProcedureDrugBrandFromTheTypeAheadDropdownInAddProcedurePopUp(String procedureDrugBrand) throws Throwable {
        obj().RegimenMaintenancePage.selectProcedureDrugBrand(procedureDrugBrand);
    }

    @And("^User verifies \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" on Add Regimen Page$")
    public void userVerifiesOnAddRegimenPage(String procedureCode, String procedureFrequency, String drugRoute, String cycles, String therapyType, String lengthOfCycles, String cycleCountDesc, String dosage) throws Throwable {
        obj().RegimenMaintenancePage.verifyAddProcedureDetails(procedureCode, procedureFrequency, drugRoute, cycles, therapyType, lengthOfCycles, cycleCountDesc, dosage);

    }

    @Then("^User verifies error message \"([^\"]*)\" displayed on Add Procedure Pop-up$")
    public void userVerifiesErrorMessageDisplayedOnAddProcedurePopUp(String expectedError) throws Throwable {
        obj().RegimenMaintenancePage.verifyErrorMessageWhenSameProcCodeAndProcBrandExists(expectedError);
    }

    @And("^user should see the Procedure Drug Brand field is between the Procedure Code Description and Procedure Frequency fields$")
    public void userShouldSeeTheProcedureDrugBrandFieldIsBetweenTheProcedureCodeDescriptionAndProcedureFrequencyFields() throws Throwable {
        Assert.assertTrue(LocationUtils.upDownSameColumn(driver(), RegimenMaintenancePage.procedureCodeDescription, RegimenMaintenancePage.procedureDrugBrandLabel));
        Assert.assertTrue(LocationUtils.upDownSameColumn(driver(), RegimenMaintenancePage.procedureDrugBrandLabel, RegimenMaintenancePage.procedureFrequencyLabel));
    }


}
