package atdd.test.stepdefinitions;

import atdd.common.EvaluateException;
import atdd.common.ScenarioLogger;
import atdd.utils.*;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import org.apache.log4j.Logger;

import java.io.File;
import java.io.FileReader;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class WhiteBoardDefinition {
    public static final Logger log = Logger.getLogger(WhiteBoardDefinition.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;


    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }

    @Given("^show WhiteBoard strings$")
    public void showWhiteBoardStrings() throws Throwable {
        this.scenarioLogger.warn(WhiteBoard.getInstance().jsonStringVars(this.owner));
    }

    @Given("^show WhiteBoard maps$")
    public void showWhiteBoardMaps() throws Throwable {
        this.scenarioLogger.warn(WhiteBoard.getInstance().jsonMapVars(this.owner));
    }

    @Given("^show WhiteBoard global strings$")
    public void showWhiteBoardGlobalStrings() throws Throwable {
        this.scenarioLogger.warn(WhiteBoard.getInstance().jsonStringVars(WhiteBoard.OWNER_GLOBAL));
    }

    @Given("^show WhiteBoard global maps$")
    public void showWhiteBoardGlobalMaps() throws Throwable {
        this.scenarioLogger.warn(WhiteBoard.getInstance().jsonMapVars(WhiteBoard.OWNER_GLOBAL));
    }

    @Given("^\"([^\"]*)\" is below text$")
    public void isBelowText(String key, String text) throws Throwable {
        is(key, text);
    }

    @Given("^\"([^\"]*)\" is \"([^\"]*)\"$")
    public void is(String key, String value) throws Throwable {
        String key1 = WhiteBoard.resolve(owner, key);
        log.warn("key=" + key);
        log.warn("key1=" + key1);
        String realOwner = owner;
        String[] p = key.split("\\.", 2);
        if (2 == p.length) {
            realOwner = p[0];
            key1 = p[1];
            log.warn("key1=" + key1);
        }
        String value1 = WhiteBoard.resolve(owner, value);
        log.warn("value=" + value);
        log.warn("value1=" + value1);

        WhiteBoard.getInstance().putString(realOwner, key1, value1);
        scenarioLogger.warn("New string added for " + realOwner + ": " + key1 + "=" + value1);
    }

    @Given("^\"([^\"]*)\" is \"([^\"]*)\" or \"([^\"]*)\"$")
    public void is(String key, String value1, String value2) throws Throwable {
        String key1 = WhiteBoard.resolve(owner, key);
        log.warn("key=" + key);
        log.warn("key1=" + key1);
        log.warn("value1=" + value1);
        log.warn("value2=" + value2);

        String value = WhiteBoard.resolve(owner, value1, value2);
        log.warn("value=" + value);

        String realOwner = owner;
        String[] p = key.split("\\.", 2);
        if (2 == p.length) {
            realOwner = p[0];
            key1 = p[1];
            log.warn("key1=" + key1);
        }

        WhiteBoard.getInstance().putString(realOwner, key1, value);
        scenarioLogger.warn("New string added for owner " + realOwner + ": " + key + "=" + value);
    }

    @Given("^\"([^\"]*)\" is \"([^\"]*)\" if \"([^\"]*)\"$")
    public void isif(String key, String value, String conditionExpression) throws Throwable {
        try {
            if (WhiteBoard.evaluate(owner, conditionExpression)) {
                is(key, value);
            }
        } catch (EvaluateException e) {
            //do nothing
        }
    }

    @Given("^\"([^\"]*)\" is map \"([^\"]*)\"$")
    public void isMap(String key, String value) throws Throwable {
        String key1 = WhiteBoard.resolve(owner, key);
        log.warn("key=" + key);
        log.warn("key1=" + key1);

        String realOwner = owner;
        String[] p = key.split("\\.", 2);
        if (2 == p.length) {
            realOwner = p[0];
            key1 = p[1];
            log.warn("key1=" + key1);
        }

        Map<String, String> map = DataTableUtils.asMap(value);
        log.warn("value=" + value);
        log.warn("map=" + WhiteBoard.getInstance().protect(map));

        WhiteBoard.getInstance().putMap(realOwner, key1, map);
        scenarioLogger.warn("New map added for " + realOwner + ": " + key1);
    }

    @Given("^\"([^\"]*)\" is$")
    public void is(String key, List<String> list) throws Throwable {
        String key1 = WhiteBoard.resolve(owner, key);
        log.warn("key=" + key);
        log.warn("key1=" + key1);

        String realOwner = owner;
        String[] p = key.split("\\.", 2);
        if (2 == p.length) {
            realOwner = p[0];
            key1 = p[1];
            log.warn("key1=" + key1);
        }

        list = WhiteBoard.resolveStringList(owner, list);
        WhiteBoard.getInstance().putList(realOwner, key1, list);
        scenarioLogger.warn("New list added for owner " + realOwner + ": " + key1 + "=" + list);
    }

    @Given("^\"([^\"]*)\" represents \"([^\"]*)\"$")
    public void represents(String key, String value) throws Throwable {
        String key1 = WhiteBoard.resolve(owner, key);
        log.warn("key=" + key);
        log.warn("key1=" + key1);
        log.warn("value=" + value);

        String realOwner = owner;
        String[] p = key.split("\\.", 2);
        if (2 == p.length) {
            realOwner = p[0];
            key1 = p[1];
            log.warn("key1=" + key1);
        }

        WhiteBoard.getInstance().putString(realOwner, key1, value);
        scenarioLogger.warn("New string added for owner " + realOwner + ": " + key1 + "=" + value);
    }

    @Given("^variables are imported from \"([^\"]*)\"$")
    public void variablesAreImportedFrom(String propertiesFile) throws Throwable {
        propertiesFile = WhiteBoard.resolve(owner, propertiesFile);
        File file = TestUtils.projectFile(propertiesFile);
        Properties properties = new Properties();
        properties.load(new FileReader(file));
        WhiteBoard.register(owner, properties);
    }

    @Given("^maps are imported from \"([^\"]*)\"$")
    public void mapsAreImportedFrom(String jsonStringOrFile) throws Throwable {
        importMaps(owner, jsonStringOrFile);
    }

    @Given("^maps are imported from below json text$")
    public void mapsAreImportedFromBelowJsonText(String jsonStringOrFile) throws Throwable {
        importMaps(owner, jsonStringOrFile);
    }

    @Given("^GLOBAL maps are imported from \"([^\"]*)\"$")
    public void globalMapsAreImportedFrom(String jsonStringOrFile) throws Throwable {
        importMaps(WhiteBoard.OWNER_GLOBAL, jsonStringOrFile);
    }

    @Given("^GLOBAL maps are imported from below json text$")
    public void globalMapsAreImportedFromBelowJsonText(String jsonStringOrFile) throws Throwable {
        importMaps(WhiteBoard.OWNER_GLOBAL, jsonStringOrFile);
    }

    private void importMaps(String realOwner, String jsonStringOrFile) throws Throwable {
        jsonStringOrFile = WhiteBoard.resolve(owner, jsonStringOrFile);
        String jsonString = StringUtils.readOrReturn(jsonStringOrFile);
        Map<String, Map<String, String>> namedMaps = QuickJson.readNamedMaps(jsonString);
        for (String name : namedMaps.keySet()) {
            WhiteBoard.getInstance().putMap(realOwner, name, namedMaps.get(name));
            scenarioLogger.warn("New map added for " + realOwner + ": " + name);
        }
    }

}

