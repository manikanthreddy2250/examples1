package atdd.test.stepdefinitions.activityTracking;

import atdd.common.ScenarioLogger;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.stepsets.Login;
import atdd.utils.TestUtils;
import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import java.util.List;

public class ActivityTrackingStepDefinition {

    public static final Logger log = Logger.getLogger(ActivityTrackingStepDefinition.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }

    @Then("^User verify the Payer Values on the Activity Tracking Page$")
    public void userVerifyThePayerValuesOnTheActivityTrackingPage(DataTable arg2) throws Throwable {
        List<String> expectedLabelvalues = arg2.asList(String.class);
        obj().ActivityTrackingHistoryPage.verifyDropdownOptionsInActivityTrackingHistory(expectedLabelvalues);
    }


    @And("^user verifies the labels on the activity tracking page$")
    public void userVerifiesTheLabelsOnTheActivityTrackingPage(DataTable labelTable) throws Throwable {
        List<String> expectedLabelvalues = labelTable.asList(String.class);
        obj().ActivityTrackingHistoryPage.verifyLabelPresentOnInActivityTrackingHistory(expectedLabelvalues);
    }

    @And("^user verifies the payer dropdown has \"([^\"]*)\" selected by default on activity tracking page$")
    public void userVerifiesThePayerDropdownHasSelectedByDefaultOnActivityTrackingPage(String payerName) throws Throwable {
        obj().ActivityTrackingHistoryPage.verifyDefaultSelectedPayerName(payerName);
    }

    @And("^Activity Tracking history items are extracted with prefix \"([^\"]*)\" and key header \"([^\"]*)\"$")
    public void activityTrackingHistoryItemsAreExtractedWithPrefixAndKeyHeader(String prefix, String keyHeader) throws Throwable {
        TestUtils.wait(3);
        TestUtils.extractGridToWhiteBoard(driver(), scenario, prefix, keyHeader, obj().ActivityTrackingHistoryPage.activityTrackingHistory_XPATH, true, false);
    }

    @And("^User validates \"([^\"]*)\" Activity type displayed in History tracking page$")
    public void userValidatesActivityTypeDisplayedInHistoryTrackingPage(String activityType) throws Throwable {
        obj().ActivityTrackingHistoryPage.validateActivityInHistory(activityType);
    }

    @And("^User click on search button in Activity Tracking History page$")
    public void userClickOnSearchButtonInActivityTrackingHistoryPage() throws Throwable {
        obj().ActivityTrackingHistoryPage.clickSearchButtonInHistory();
    }

    @And("^User selects \"([^\"]*)\" in Activity History page$")
    public void userSelectsInActivityHistoryPage(String activityType) throws Throwable {
        obj().ActivityTrackingHistoryPage.selectActivityType(activityType);
    }
}
