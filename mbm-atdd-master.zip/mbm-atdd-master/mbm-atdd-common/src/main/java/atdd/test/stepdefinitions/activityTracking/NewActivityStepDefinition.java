package atdd.test.stepdefinitions.activityTracking;

import atdd.common.MapsComparer;
import atdd.common.ScenarioLogger;
import atdd.dao.mbm.HscDao;
import atdd.dao.mbm.MyBatisConnectionFactory;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.stepsets.Login;
import atdd.utils.*;
import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.Map;

public class NewActivityStepDefinition {

    public static final Logger log = Logger.getLogger(NewActivityStepDefinition.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }

    @And("^User clicks Save button on the New Activity Page$")
    public void clickSaveButton() throws Throwable {
        obj().NewActivityPage.clickSaveBtn();
    }

    @And("^User selects \"([^\"]*)\" Activity Type on the New Activity Page$")
    public void selectActivityType(String option) throws Throwable {
        obj().NewActivityPage.selectActivityType(option);
    }

    @And("^User selects \"([^\"]*)\" Resolution Reason on the New Activity Page$")
    public void selectResolutionReason(String option) throws Throwable {
        obj().NewActivityPage.selectResolutionReason(option);
    }

    @And("^User selects \"([^\"]*)\" Role on the New Activity Page$")
    public void selectRole(String option) throws Throwable {
        obj().NewActivityPage.selectRole(option);
    }

    @And("^User selects \"([^\"]*)\" Communication Type on the New Activity Page$")
    public void selectCommunicationType(String option) throws Throwable {
        obj().NewActivityPage.selectCommunicationType(option);
    }

    @And("^User enters \"([^\"]*)\" Date on the New Activity Page$")
    public void enterDate(String txt) throws Throwable {
        obj().NewActivityPage.enterDate(txt);
    }

    @And("^User enters \"([^\"]*)\" Time on the New Activity Page$")
    public void enterTime(String txt) throws Throwable {
        obj().NewActivityPage.enterTime(txt);
    }

    @And("^User enters \"([^\"]*)\" Call Contact Name on the New Activity Page$")
    public void enterCallContactName(String txt) throws Throwable {
        obj().NewActivityPage.enterCallContactName(txt);
    }

    @Then("^user should verify that value in Variable Value dropdown is \"([^\"]*)\" on the drop down on the New Activity Page$")
    public void userShouldVerifyThatValueInVariableValueDropdownIsOnTheDropDownOnTheNewActivityPage(String txt) throws Throwable {
        log.warn("verifying that value in Variable Value dropdown is" + txt);
        obj().NewActivityPage.userVerifiesTheContentsOfDropdown(txt);
    }

    @Then("^user should verify that following values are visible in the New ActivityTracking widget$")
    public void user_should_verify_that_following_values_are_visible_in_the_New_ActivityTracking_widget(DataTable arg1) throws Throwable {
        obj().NewActivityPage.validationOfNewActivityTrackingWidget(arg1);

    }

    @Then("^user should verify that following values are visible in the ActivityTracking widget in HomePage$")
    public void user_should_verify_that_following_values_are_visible_in_the_ActivityTracking_widget_in_HomePage(DataTable arg1) throws Throwable {
        obj().NewActivityPage.validationOfActivityTrackingWidgetInHomePage(arg1);

    }

    @And("^User navigate to Home page$")
    public void userNavigateToHomePage() throws Throwable {
        log.warn("userNavigatingToHomePage");
        WebElement Home = driver().findElement(By.xpath("//span[contains(text(),'Home')]"));
        Home.click();
        try {
            driver().switchTo().alert().accept();
        } catch (Exception e) {
            // do nothing
        }
        TestUtils.wait(2);
    }

    /**
     * getting top 10 ActivityTracking from DB
     *
     * @param varName
     * @throws Throwable
     */
    @When("^\"([^\"]*)\" is extracted from DB$")
    public void isExtractedFromDB(String varName) throws Throwable {
        List<Map<String, Object>> list = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectTop10ActivityTracking();
        Object result = list;
        if (null == result) {
            WhiteBoard.getInstance().putString(owner, varName + "_rows", "0");
            return;
        }
        if (result instanceof List) {
            List<Map<String, Object>> mapList = null;
            try {
                mapList = (List<Map<String, Object>>) result;
            } catch (Exception e) {
                // do nothing
            }
            if (null == mapList) {
                WhiteBoard.getInstance().putString(owner, varName + "_rows", "0");
                return;
            } else {
                List<Map<String, String>> stringMapList = DataTableUtils.asMapsOfStrings(mapList);
                Map<String, Map<String, String>> indexedMaps = DataTableUtils.dataTableAsMapsIndexedByKeyHeader(DataTableUtils.INDEX_ROW_NUMBER, stringMapList);
                WhiteBoard.storeMaps(owner, varName, Conf.getOutputPath(), indexedMaps);
            }
        } else {
            String s = result.toString();
            WhiteBoard.getInstance().putString(owner, varName, s);
            scenarioLogger.warn("New string added for " + owner + ": " + varName + "=" + s);
        }
    }

    @And("^user adds New Activity Tracking$")
    public void userAddsNewActivityTracking(DataTable dataTable) throws Throwable {
        List<Map<String, String>> maps = WhiteBoard.resolve(owner, dataTable.asMaps(String.class, String.class));
        TestUtils.wait(2);
        obj().NewActivityPage.add(maps);
    }


    @And("^user adds New Activity$")
    public void userAddsNewActivity(DataTable dataTable) throws Throwable {
        List<Map<String, String>> maps = WhiteBoard.resolve(owner, dataTable.asMaps(String.class, String.class));
        TestUtils.wait(2);
        obj().NewActivityPage.addActivity(maps);
    }

    @And("^user verifies the ui values prefix \"([^\"]*)\" with db values  for activitytracking history page$")
    public void userVerifiesTheUiValuesPrefixWithDbValuesForActivitytrackingHistoryPage(String prefix) throws Throwable {
        List<Map<String, String>> mapsActual = WhiteBoard.getInstance().combine(owner, prefix);
        List<Map<String, String>> mapsExpected = verifyDbAndUivalues();
        MapsComparer mapsComparer = new MapsComparer(mapsExpected, mapsActual, scenarioLogger);
        mapsComparer.assertMatches(false);
    }

    @And("^user verifies the ui values prefix \"([^\"]*)\" with db values  for activitytracking history page for \"([^\"]*)\"$")
    public void userVerifiesTheUiValuesPrefixWithDbValuesForActivitytrackingHistoryPageFor(String prefix, String user) throws Throwable {
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        List<Map<String, String>> mapsActual = WhiteBoard.getInstance().combine(owner, prefix);
        List<Map<String, String>> mapsExpected = verifyDbAndUivaluesforuser(pf.get(MBM.USER_USERUID));
        MapsComparer mapsComparer = new MapsComparer(mapsExpected, mapsActual, scenarioLogger);
        mapsComparer.assertMatches(false);
    }

    private List<Map<String, String>> getMaps(List<Map<String, Object>> list) {
        List<Map<String, String>> stringMapList = null;
        Object result = list;
        if (null == result) {
            WhiteBoard.getInstance().putString(owner, "db_activity_history_rows", "0");

        }
        if (result instanceof List) {
            List<Map<String, Object>> mapList = null;
            try {
                mapList = (List<Map<String, Object>>) result;
            } catch (Exception e) {
                // do nothing
            }
            if (null == mapList) {
                WhiteBoard.getInstance().putString(owner, "db_activity_history_rows", "0");

            } else {
                stringMapList = DataTableUtils.asMapsOfStrings(mapList);
                Map<String, Map<String, String>> indexedMaps = DataTableUtils.dataTableAsMapsIndexedByKeyHeader(DataTableUtils.INDEX_ROW_NUMBER, stringMapList);
                WhiteBoard.storeMaps(owner, "db_activity_history", Conf.getOutputPath(), indexedMaps);
            }
        } else {
            String s = result.toString();
            WhiteBoard.getInstance().putString(owner, "db_activity_history", s);
            scenarioLogger.warn("New string added for " + owner + ": " + "db_activity_history" + "=" + s);
        }
        return stringMapList;
    }

    private List<Map<String, String>> verifyDbAndUivalues() {
        List<Map<String, Object>> list = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).verifyActivityTrackingHistoryvalues();
        List<Map<String, String>> mapsExpected = getMaps(list);
        return mapsExpected;
    }

    private List<Map<String, String>> verifyDbAndUivaluesforuser(String user) {
        List<Map<String, Object>> list = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).verifyActivityTrackingHistoryvaluesforuser(user);
        List<Map<String, String>> mapsExpected = getMaps(list);
        return mapsExpected;
    }

    @And("^user clicks the add wizard$")
    public void clickAddActivityWizard() {
       new TestUtils().getElementUsingText("Add",".//span").click();
    }

    @And("^user clicks the activity in add wizard$")
    public void clickActivutyOnAddActivityWizard() {
        new TestUtils().getElementUsingText("Activity",".//button").click();
    }

    @And("^User enters \"([^\"]*)\" Member ID on the New Activity Page$")
    public void userEntersMemberIDOnTheNewActivityPage(String txt) throws Throwable {
        obj().NewActivityPage.enterMemberID(txt);
    }

    @And("^User enters \"([^\"]*)\" Call Back Number on the New Activity Page$")
    public void userEntersCallBackNumberOnTheNewActivityPage(String txt) throws Throwable {
        obj().NewActivityPage.enterCallBackNumber(txt);
    }

    @And("^User validate resolution reasons displayed in New Activity Tracking page$")
    public void userValidateResolutionReasonsDisplayedInNewActivityTrackingPage() throws Throwable {
        obj().NewActivityPage.validateResolutionReasonValues();
    }

}





