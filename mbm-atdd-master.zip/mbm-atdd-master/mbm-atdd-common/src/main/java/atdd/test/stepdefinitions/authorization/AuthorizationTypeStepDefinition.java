package atdd.test.stepdefinitions.authorization;

import atdd.common.ScenarioLogger;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.stepsets.Login;
import atdd.utils.TestUtils;
import cucumber.api.DataTable;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * Created by jrossy on 3/15/19.
 */
public class AuthorizationTypeStepDefinition {

    public static final Logger log = Logger.getLogger(AuthorizationTypeStepDefinition.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }

    @Then("^User should see Authorization Type section below Member Information$")
    public void user_should_see_Authorization_Type_section_below_Member_Information() throws Throwable {
        obj().AuthorizationTypePage.VerifySelectAuthSectionsDisplayed();
    }

    @Then("^user should see a dropdown field named Authorization Type which is Required$")
    public void user_should_see_a_dropdown_field_named_Authorization_Type_which_is_Required() throws Throwable {
        obj().AuthorizationTypePage.verifyAuthTpeDropdownOnSelectAuthSection();
    }

    @Then("^user should verify dropdown options on Authorization Type dropdown$")
    public void user_should_verify_dropdown_options_as(DataTable dropDownValues) throws Throwable {
        obj().AuthorizationTypePage.validateAuthTypeDropdownOptions(dropDownValues);
    }

    @Then("^user selects \"([^\"]*)\" from Authorization Type dropdown$")
    public void user_selects_from_Authorization_Type_dropdown(String arg1) throws Throwable {
        obj().AuthorizationTypePage.selectAuthType(arg1);
    }

    @And("^User clicks on info icon besides the Authorization text on Member search page$")
    public void userClicksOnInfoIconBesidesTheAuthorizationTextOnMemberSearchPage() throws Throwable {
        obj().AuthorizationTypePage.userClicksOnAuthInfoIcon();
    }

    @Then("^User should verify a popup is displayed with title \"([^\"]*)\"$")
    public void userShouldVerifyAPopupIsDisplayedWithTitle(String arg0) throws Throwable {
        obj().AuthorizationTypePage.verifiesAuthTypePopupIsDisplayed(arg0);
    }

    @And("^User clicks on X button on the popup on Member search page$")
    public void userClicksOnXButtonOnThePopupOnMemberSearchPage() throws Throwable {
        obj().AuthorizationTypePage.userClicksOnXBtnOnAuthTypePopup();
    }

    @Then("^User should verify that Authorization popup is closed$")
    public void userShouldVerifyThatAuthorizationPopupIsClosed() throws Throwable {
        obj().AuthorizationTypePage.verifiesAuthTypePopupIsClosed();
    }

    @And("^User verifies the authorization type content$")
    public void userVerifiesTheContentAsOfThePopupOnMemberSearchPage(DataTable arg0) throws Throwable {
        obj().AuthorizationTypePage.verifyContentOfAuthTypesPopup(arg0);
    }

    /*
     * This scenario validates default value for authorization type
     * @param expectedDefaultValue*/
    @And("^User validates the default value for authorization type dropdown is \"([^\"]*)\"$")
    public void user_validates_the_default_value_for_authorization_type_dropdown_is(String expectedDefaultValue) throws Throwable {
        obj().AuthorizationTypePage.verifyAuthorizationTypeDropDownDefaultValue(expectedDefaultValue);
    }

    @And("^user click back button on Authorization Type page$")
    public void userClickBackButtonOnAuthorizationTypePage() throws Throwable {
        obj().AuthorizationTypePage.clickBackButton();
    }

    @And("^user clicks continue button on expired member blocking popup$")
    public void userClicksContinueButtonOnExpiredMemberBlockingPopup() throws Throwable {
        obj().AuthorizationTypePage.clickContinueButtonExpiredMemberBlockingPopu();
    }


    @And("^user validating display of preferred and non-preferred breakout in UI for drug class \"([^\"]*)\",\"([^\"]*)\" with associated \"([^\"]*)\"$")
    public void userValidatingDisplayOfPreferredAndNonPreferredBreakoutInUIForDrugClassWithAssociated(String drugClass, String drugCode, String testFlag) throws Throwable {


        obj().AuthorizationTypePage.validatingDisplayOfPreferredAndNonPreferredBreakoutInUI(drugClass, testFlag);
        TestUtils.wait(1);
        obj().AuthorizationTypePage.enterSepcialtyPharmaDrugCode(drugCode);
//        TestUtils.input(driver(), (By.xpath("//*[@id=\"memberDetailsProcedureCodePreferred\"]/div[2]/form/div[1]/div/input\n")), drugCode.substring(0, 5));
//        TestUtils.wait(1);
//
//        TestUtils.click(driver(), By.xpath("//*[@id=\"memberDetailsProcedureCodePreferred\"]//span[contains(.,'" + drugCode + "')]"));
//
//        //validating specialty steerage Preferred Product indicator for  pref/non pref selection by user
       boolean found = TestUtils.isElementVisible(driver(), "//p[contains(.,'Preferred Product')]");

        if (testFlag.equals("preferred")) {
            Assert.assertTrue("Preferred Product indicator not visible for selection of preferred product", found);
        } else {
            Assert.assertTrue("Preferred Product indicator not visible for selection of preferred product", !found);

        }
        TestUtils.wait(1);

        try {
            obj().AuthorizationTypePage.selectDropDownValueInplaceofServiceTypeSel("Office");
        } catch (Exception e) {
            //Do nothing
        }

        TestUtils.click(driver(), By.xpath("//*[@id=\"toggleMemConfContinueBtn\"]"));
        TestUtils.wait(3);

        //validating specialty steerage pop up for non pref selection by user
        boolean popupFound = TestUtils.isElementVisible(driver(), "//h2[text()='Product Is Not Eligible for Auto-approval']");
        if (testFlag.equals("non preferred")) {
            Assert.assertTrue("Product Is Not Eligible for Auto-approval message visible for selection of preferred product", popupFound);
        } else
            Assert.assertTrue("Preferred Product indicator not visible for selection of preferred product", !popupFound);


    }

    @And("^user enters \"([^\"]*)\" in Specialty Pharmacy Drug Class$")
    public void userEntersInSpecialtyPharmacyDrugClass(String drugclass) throws Throwable {
        obj().AuthorizationTypePage.selectSpecialtyPharmaDrugClass(drugclass);
    }

    @And("^User enters the \"([^\"]*)\" in the drug code$")
    public void user_enters_the_in_the_drug_code(String dcode) throws Throwable {
        obj().AuthorizationTypePage.enterSepcialtyPharmaDrugCode(dcode);
    }

    @And("^User selects Yes from Buy and Bill dropdown$")
    public void userselectsyesfrombuyandbilldropdown() throws Throwable {
        obj().AuthorizationTypePage.selectYesfromBuyandBill();

    }

    @And("^User selects No from Buy and Bill dropdown$")
    public void userselectsnofrombuyandbilldropdown() throws Throwable {
        obj().AuthorizationTypePage.selectNofromBuyandBill();

    }

    @Then("^User selects Okay from the warning popup$")
    public void user_selects_Okay_from_the_warning_popup() throws Throwable {
        obj().AuthorizationTypePage.clickOkay();
    }

    @Then("^User selects Back from the warning popup$")
    public void user_selects_Back_from_the_warning_popup() throws Throwable {
        obj().AuthorizationTypePage.clickCancel();
    }


    @And("^user should see a dropdown field named Self-administered which is Required$")
    public void userShouldSeeADropdownFieldNamedSelfAdministeredWhichIsRequired() throws Throwable{
        obj().AuthorizationTypePage.verifySelfAdministeredDropdown();
    }

    @And("^user selects \"([^\"]*)\" from self administered dropdown$")
    public void userSelectsFromSelfAdministeredDropdown(String arg1) throws Throwable {
        obj().AuthorizationTypePage.selectsgpType(arg1);
    }

    @And("^user selects Return to Dashboard on the self administered popup$")
    public void userSelectsReturnToDashboardOnTheSelfAdministeredPopup() throws Throwable {
        obj().AuthorizationTypePage.ClickReturntoDashboard();
    }

    //Place of Service
    @And("^user selects \"([^\"]*)\" from Place Of Service dropdown$")
    public void userSelectsPlaceOfServiceDropdown(String service) throws Throwable {
        obj().AuthorizationTypePage.selectDropDownValueInplaceofServiceTypeSel(service);
    }


    //Place of Service
    @And("^User click on continue button on existing Pharmacy Authentication PopUp$")
    public void userClickOnContinueOnExistingPharmacyPopUp() throws Throwable {
        obj().AuthorizationTypePage.ClickExistingPharmacyPopUPContinue();
    }


    //Place of Service
    @And("^User verify existing Pharmacy Authentication PopUp$")
    public void VerifyExistingPharmacyPopUPonAuthTypePage() throws Throwable {
        obj().AuthorizationTypePage.VerifyExistingPharmacyPopUP();
    }

    @And("^user should verify the default value from the drop down is \"([^\"]*)\"$")
    public void userShouldVerifyTheDefaultValueFromTheDropDownIs(String blank) throws Throwable {
        obj().AuthorizationTypePage.VerifyAuthTypeIsBlank(blank);
    }
}