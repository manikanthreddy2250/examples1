package atdd.test.stepdefinitions.authorization;

import atdd.common.ScenarioLogger;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.stepsets.Login;
import atdd.utils.WhiteBoard;
import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

public class ClinicalStatusStepDefinition {
    public static final Logger log = Logger.getLogger(ClinicalStatusStepDefinition.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }

    @And("^User clicks Continue button on Clinical Status Page$")
    public void userClicksButtonOnClinicalStatusPage() throws Throwable {
        obj().ClinicalStatusPage.clickContinueButton();
        obj().CommonPage.waitForNOTBusyIndicator();
    }


    @And("^User selects \"([^\"]*)\" from the \"([^\"]*)\" dropdown list in Clinical Status page$")
    public void userSelectsFromTheDropdownListInClinicalStatusPage(String clinicalStatusDropDownValue, String clinicalStatusDropDownLabel) throws Throwable {
        obj().ClinicalStatusPage.chooseClinicalStatus(clinicalStatusDropDownValue, clinicalStatusDropDownLabel);
    }

    @And("^User selects \"([^\"]*)\" radio button for i attest that on Clinical Status Page$")
    public void userSelectsRadioButtonForIAttestThatOnClinicalStatusPage(String radio) throws Throwable {
        obj().ClinicalStatusPage.selectRadioButton(radio);
    }

    @Then("^User verifies the \"([^\"]*)\" dropdown list in Clinical Status page$")
    public void user_verifies_the_dropdown_list_in_Clinical_Status_page(String arg1, DataTable arg2) throws Throwable {
        obj().ClinicalStatusPage.verifySelectFieldElements(arg1, arg2);
    }

    @And("^User selects \"([^\"]*)\" for the somatostatin receptor-positive metastatic question in the attestation$")
    public void userSelectsForTheSomatostatinReceptorPositiveMetastaticQuestionInTheAttestation(String dropdownvalue) throws Throwable {
        obj().ClinicalStatusPage.selectSomatostationReceptorMetastaticQuestion(dropdownvalue);
    }

    @Then("^User selects \"([^\"]*)\" from the Immunotherapy dropdown list in Clinical Status page$")
    public void user_selects_from_the_Immunotherapy_dropdown_list_in_Clinical_Status_page(String arg1) throws Throwable {
        obj().ClinicalStatusPage.selectImmunotherapyOption(arg1);
    }

    @And("^User verifies hidden Header \"([^\"]*)\" not visible on the page$")
    public void userVerifiesHiddenQuestionNotVisibleOnThePage(String arg0) throws Throwable {
        obj().ClinicalStatusPage.verifyHiddenQuestion();

    }

    @And("^User verifies hidden Header \"([^\"]*)\" visible on the page$")
    public void userVerifiesInitialInfusionVisibleOnThePage(String arg0) throws Throwable {
        obj().ClinicalStatusPage.verifyInitialInfusionQuestion();

    }

    @And("^User Select options is Elapsre\"([^\"]*)\" on Clinical Status Page$")
    public void selectElapsreDropdown(String options) throws Throwable{
        obj().ClinicalStatusPage.selectElapsreDropdown(options);
    }

    @And("^User verifies the clinicalStatusInfo by hsc_id \"([^\"]*)\" from database with \"([^\"]*)\"$")
    public void userVerifiesTheClinicalStatusInfoByHsc_idFromDatabseWith(String hscIdVarName, String actualValue) throws Throwable {
        obj().ClinicalStatusPage.validateClinicalAssessmentInfoFromDB(WhiteBoard.resolve(owner, hscIdVarName),actualValue);
    }
}
