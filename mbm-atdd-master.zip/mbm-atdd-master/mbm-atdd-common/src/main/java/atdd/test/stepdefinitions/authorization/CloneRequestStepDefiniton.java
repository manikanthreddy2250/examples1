package atdd.test.stepdefinitions.authorization;

import atdd.test.pageobjects.CommonPageObject;
import atdd.test.shared.BaseCucumber;
import atdd.test.stepsets.Login;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

public class CloneRequestStepDefiniton {
    private final static Logger log = Logger.getLogger(CloneRequestStepDefiniton.class);
    TestUtils utils = BaseCucumber.utils;
    private Scenario scenario;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void before(Scenario scenario) throws Throwable {
        this.scenario = scenario;
    }

    @And("^User verifies that clone icon is under action tab$")
    public void userVerifiesThatCloneIconIsUnderActionTab() throws Throwable {
        obj().CloneRequestPage.user_Verifies_That_Clone_Icon_is_Present();

    }

    @And("^User clicks on clone option in dashboard$")
    public void userClicksOnOptionInDashboard() throws Throwable {

        obj().CloneRequestPage.clickCloneOption();
        obj().CommonPage.switchWindowTo(1);
    }

    @And("^user clicks the x button on popup$")
    public void userVerifiesTheButtonOnPopup() throws Throwable {
        obj().CloneRequestPage.user_click_The_x_Button_On_Popup();

    }

    @And("^User selects \"([^\"]*)\" from Authorization type dropdown in the Clone Request Page$")
    public void userSelectsFromAuthorizationTypeDropdownInTheClonePopup(String SelectauthType) throws Throwable {

        obj().CloneRequestPage.selectAuthType(SelectauthType);
    }


    @And("^User enters \"([^\"]*)\" Cancer field in Clone RequestPage$")
    public void userEntersCancerFieldInCloneRequestPage(String CancerType) throws Throwable {
        obj().CloneRequestPage.user_Enters_Cancer_Field_In_Clone_Request_Page(CancerType);
    }


    @And("^User verifies that clone icon is under action tab in Prior auth search$")
    public void userVerifiesThatCloneIconIsUnderActionTabInPriorAuthSearch() throws Throwable {
        obj().CloneRequestPage.user_Verifies_That_Clone_Icon_Is_Under_Action_Tab_In_Prior_Auth_Search();
    }

    @And("^User verifies \"([^\"]*)\" is present under the title of clone popup$")
    public void userVerifiesIsPresentUnderTheTitleOfClonePopup(String text) throws Throwable {
        obj().CloneRequestPage.user_Verifies_Is_Present_Under_The_Title_Of_Clone_Popup(text);
    }


    @And("^User verifies the contents of Authorization Type dropdown$")
    public void userVerifiesTheContentsOfAuthorizationTypeDropdown() throws Throwable {
        obj().CloneRequestPage.user_Verifies_The_Contents_Of_Dropdown();
    }


    @And("^User clicks Continue button on Clone Request page and verifies \"([^\"]*)\"$")
    public void userClicksContinueButtonOnCloneRequestPageAndVerifies(String message) throws Throwable {
        obj().CloneRequestPage.clickContinueOnCloneRequestPage(message);
    }

    @And("^User verifies that clone icon is not present under action tab$")
    public void userVerifiesThatCloneIconIsNotPresentUnderActionTabInPriorAuthSearch() throws Throwable {
        obj().CloneRequestPage.user_Verifies_That_Clone_Icon_is_not_Present();
    }

    @And("^User clicks Continue button on Clone Request page$")
    public void userClicksContinueButtonOnCloneRequestPage() throws Throwable {
        obj().CloneRequestPage.user_click_The_continue_Button_On_Popup();
    }


    @And("^User selects \"([^\"]*)\" from Infusion type dropdown in the Clone Request Page$")
    public void userSelectsInitialInfusionDropdownInTheClonePopup(String SelectInitialInfusionType) throws Throwable {

        obj().CloneRequestPage.selectInitialInfusion(SelectInitialInfusionType);
    }

    @And("^User selects \"([^\"]*)\" place of service in the clone request page$")
    public void userSelectsPlaceOfServiceInTheCloneRequestPage(String arg0) throws Throwable {
        obj().CloneRequestPage.selectPlaceOfService(arg0);
    }

    @And("^user enters \"([^\"]*)\" on the clone Request page$")
    public void userEntersOnTheCloneRequestPage(String cancer) throws Throwable {
        obj().CloneRequestPage.EnterCancerType(cancer);
    }

    @And("^User selects \"([^\"]*)\" place of service in the clone specialty pharmacy$")
    public void userSelectsPlaceOfServiceInTheCloneSpecialtyPharmacy(String arg0) throws Throwable {
        obj().CloneRequestPage.selectPlaceOfServiceForSpecialtyPharmacy(arg0);
    }

    @And("^User selects Continue Clone auth stepper And Submit$")
    public void userSelectsContinueCloneAuthAndSubmit() throws Throwable {
        obj().CloneRequestPage.ContinueCloneAuthStepperAndSubmit();
    }


}
