package atdd.test.stepdefinitions.authorization;

import atdd.common.MapsComparer;
import atdd.common.ScenarioLogger;
import atdd.dao.OcmMBMDao;
import atdd.dao.mbm.HscDao;
import atdd.dao.mbm.MbrDao;
import atdd.dao.mbm.MyBatisConnectionFactory;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.stepsets.Login;
import atdd.utils.DataTableUtils;
import atdd.utils.ExcelLib;
import atdd.utils.MBM;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.List;
import java.util.Map;


public class MemberInformationStepDefinition {

    public static final Logger log = Logger.getLogger(MemberInformationStepDefinition.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }


    @And("^User selects \"([^\"]*)\" Authorization Type option on the Member search page$")
    public void selectAuthorizationType(String option) throws Throwable {
        obj().AuthorizationTypePage.selectAuthorizationType(option);
    }

    @And("^User verifies \"([^\"]*)\" header on Member Information page$")
    public void userVerifiesHeaderOnMemberInformationPage(String header) throws Throwable {
        boolean present = obj().CommonPage.verifyHeader(header);
        Assert.assertTrue("Header " + header + " does not exists", present);
    }

    @And("^User click on Continue button on Member Information page$")
    public void userClickOnContinueButtonOnMemberInformationPage() throws Throwable {
        obj().MemberInformationPage.clickContinueButton();
        obj().CommonPage.waitForNOTBusyIndicator();
    }

    @Given("^release members with below subscriber id's$")
    public void releaseMembersWithBelowSubscriberIdS(List<String> subscriberIds) throws Throwable {
        for (String subscriberId : subscriberIds) {
            scenarioLogger.warn("Releasing member with subscriber id: " + subscriberId);
            new MbrDao(MyBatisConnectionFactory.getSqlSessionFactory()).releaseMemberBySubscriberId(subscriberId);
        }
    }

    @Then("^User should see 'HSC ID' in HSC table with Member \"([^\"]*)\" and \"([^\"]*)\" for the given \"([^\"]*)\"$")
    public void userShouldSeeHSCIDInHSCTableWithMemberAndForTheGiven(String lastName, String dateOfBirth, String userName) throws Throwable {
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        userName = pf.get(userName);
        dateOfBirth = OcmMBMDao.convertDateOfBirthToDB(pf.get(dateOfBirth));
        List<Map<String, Object>> results = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory())
                .getHscIdFromDb(userName, pf.get(lastName), dateOfBirth);
        String id = results.get(0).get("hsc_id").toString();
        String lname = results.get(0).get("lst_nm").toString();
        String dob = results.get(0).get("bth_dt").toString();
        log.warn("hsc_id: " + id + " lastName: " + lname + " dateOfBirth: " + dob);
        Assert.assertFalse("The HSC ID Does not exists in HSC table", id.isEmpty());
        Assert.assertTrue("The lastName Does not exists in HSC table", pf.get(lastName).equalsIgnoreCase(lname));
        Assert.assertTrue("The dateOfBirth Does not exists in HSC table", dateOfBirth.equalsIgnoreCase(dob));

    }
    @And("^user validates member information against DB for UHC$")
    public void userValidatesMemberInformationAgainstDBForUHC() throws Throwable {
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        List<Map<String, Object>> mbrDetails = new MbrDao(MyBatisConnectionFactory.getSqlSessionFactory())
                .getMemberInformationDetails(pf.get(MBM.MEMB_SUBSCRIBER_ID));
        List<Map<String, String>> member1 = TestUtils.transposedTableAsMaps(driver(), "//div[@id='memberInformationPanelIdContent']//table", 10);
        List<Map<String, String>> memberDb = DataTableUtils.asMapsOfStrings(mbrDetails);
        MapsComparer mapsComparer = new MapsComparer(memberDb, member1, scenarioLogger);
        mapsComparer.assertMatches(false);

    }

    @And("^User should navigate to Member Information page$")
    public void userShouldNavigateToMemberInformationPage() throws Throwable {
        obj().MemberInformationPage.verifyMemberInformationDisplayed();
    }


    @Then("^User verifies RI Blocking pop up on Member Information page$")
    public void user_verifies_RI_Blocking_pop_up_on_Member_Information_page() throws Throwable {
        obj().MemberInformationPage.verifyRIBlockingPopupDisplayed();

    }

    @And("^User verifies \"([^\"]*)\" blocking message on Member Information page$")
    public void userVerifiesblockingMessageOnMemberInformationPage(String message) throws Throwable {
        Assert.assertTrue("Cancer Type Value doesn't exist", TestUtils.text(driver(),By.id("globalMessages-description")).contains(message));
    }
}
