package atdd.test.stepdefinitions.authorization;


import atdd.common.ScenarioLogger;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.stepsets.Login;
import atdd.utils.TestUtils;
import cucumber.api.DataTable;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import java.util.List;
import java.util.Map;


public class MemberSearchStepDefinition {

    public static final Logger log = Logger.getLogger(MemberSearchStepDefinition.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }
    @When("User perform Search for member")
    public void searchForUser(DataTable searchParam) throws Throwable {
        //Getting params
        List<Map<String, String>> list = searchParam.asMaps(String.class, String.class);
        String lastName = list.get(0).get("Last Name");
        String dateOfBirth = list.get(0).get("Date Of Birth");
        String subscriberId = list.get(0).get("Subscriber ID");
        String authorizationType = list.get(0).get("Authorization Type");

        //boolean ttt = lastName.equals("-");

        if (!TestUtils.checkNullOrDash(lastName)) {
            scenario.write("Entering Last Name: " + lastName);
            obj().MemberSearchPage.enterLastName(lastName);
        }

        if (!TestUtils.checkNullOrDash(dateOfBirth)) {
            scenario.write("Entering Date Of Birth: " + dateOfBirth);
            obj().MemberSearchPage.enterDOB(dateOfBirth);
        }

        scenario.write("Entering Subscriber ID: " + subscriberId);
        obj().MemberSearchPage.enterSubscriberID(subscriberId);

        scenario.write("Clicking Search Button");
        obj().MemberSearchPage.clickSearchButton();
        obj().CommonPage.waitForNOTBusyIndicator();

        scenario.write("Selecting Authorization Type: " + authorizationType);
        obj().AuthorizationTypePage.selectAuthorizationType(authorizationType);

        scenario.write("Clicking Continue Button on Member Information page");
        obj().MemberInformationPage.clickContinueButton();
        obj().CommonPage.waitForNOTBusyIndicator();

    }

    @And("^User click on Continue Button on the Member search page$")
    public void userClickOnContinueButtonOnMemberSearchPage() throws Throwable {
        obj().MemberSearchPage.clickContinueButton();
        obj().CommonPage.waitForNOTBusyIndicator();
    }

    @And("^User click on Search Button on the Member search page$")
    public void userClickOnSearchButtonOnMemberSearchPage() throws Throwable {
        obj().MemberSearchPage.clickSearchButton();
        obj().CommonPage.waitForNOTBusyIndicator();
    }

    @And("^Enter \"([^\"]*)\" Last name on the Member search page$")
    public void enterLastName(String name) throws Throwable {
        obj().MemberSearchPage.enterLastName(name);
    }

    @And("^Enter \"([^\"]*)\" Subscriber ID on the Member search page$")
    public void enterSubscriberId(String subID) throws Throwable {
        obj().MemberSearchPage.enterSubscriberID(subID);
    }

    @And("^Enter \"([^\"]*)\" Date Of Birth on the Member search page$")
    public void enterDOB(String dob) throws Throwable {
        obj().MemberSearchPage.enterDOB(dob);
    }

    @And("^Enter \"([^\"]*)\" Last name, \"([^\"]*)\" Subscriber ID, \"([^\"]*)\" Date Of Birth and click Search on the Member search page$")
    public void enterLastNameSubIdDOB(String lname, String subId, String dob) throws Throwable {
        obj().MemberSearchPage.enterLastName(lname).
                enterSubscriberID(subId).
                enterDOB(dob).
                clickSearchButton();
    }

    @And("^User select \"([^\"]*)\" from authorization type dropdown$")
    public void user_select_from_authorization_type_dropdown(String arg1) throws Throwable {
        obj().MemberSearchPage.selectDropDownValueInAuthorizationType(arg1);
    }

    @And("^user should see search \"([^\"]*)\" message on member search page$")
    public void userShouldSeeSearchMessageOnMemberSearchPage(String message) throws Throwable {
        obj().MemberSearchPage.verifySearchMessage(message);
    }

    @And("^user validates the Member Search page is displayed$")
    public void userValidatesTheMemberSearchPageIsDisplayed() throws Throwable {
        obj().MemberSearchPage.verifyMemberSearchPageIsDisplayed();
    }

    @And("^user clicks on details icon under actions column on memeber search page$")
    public void userClicksOnDetailsIconUnderActionsColumnOnMemeberSearchPage() throws Throwable {
        obj().MemberSearchPage.clickDetailsIcon();
    }

    @And("^user click last name radio button on Member search page$")
    public void userClickLastNameRadioButtonOnMemberSearchPage() throws Throwable {
        obj().MemberSearchPage.clickLastNameRadioButton();
    }

    @And("^User clicks all members radio button on the Member search page$")
    public void userClicksAllMembersRadioButtonOnTheMemberSearchPage() throws Throwable {
        obj().MemberSearchPage.clickAllMembersRadioButton();
    }

    @Then("^User should verify restricted message displayed in Member search page$")
    public void userShouldVerifyRestrictedMessageDisplayedInMemberSearchPage() throws Throwable {
        obj().MemberSearchPage.verifyRestrictedMessageInMemberSearch();
    }

    @And("^User select first record in the Member data in Member Information page$")
    public void userSelectFirstRecordInTheMemberDataInMemberInformationPage() throws Throwable {
        obj().MemberSearchPage.selectMemberData();
    }
}
