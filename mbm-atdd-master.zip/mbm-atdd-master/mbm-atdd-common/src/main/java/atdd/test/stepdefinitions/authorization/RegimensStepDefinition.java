package atdd.test.stepdefinitions.authorization;

import atdd.common.MapsComparer;
import atdd.common.ScenarioLogger;
import atdd.dao.mbm.HscDao;
import atdd.dao.mbm.MyBatisConnectionFactory;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.stepsets.Login;
import atdd.utils.*;
import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class RegimensStepDefinition {

    public static final Logger log = Logger.getLogger(RegimensStepDefinition.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }

    @And("^User enters \"([^\"]*)\" Drug Code in add drug pop up window in Regimen page$")
    public void userEntersDrugCodeInAddDrugPopUpWindowInRegimenPage(String drugCode) throws Throwable {
        obj().RegimensPage.enterTextInDrugCodeTextBox(drugCode);
    }

    @And("^User selcts Urgent Request checkbox in custom Regimen Page$")
    public void selectUrgenrRequestChkBx() throws Throwable {
        obj().RegimensPage.selectUrgentRequestCheckbox();
    }

    @And("^User verifies \"([^\"]*)\" header in Regimen page$")
    public void userVerifiesHeaderInRegimenPage(String header) throws Throwable {
        obj().RegimensPage.verifyHeaderText(header);
    }

    @And("^User selects first regimen on Regimen Page$")
    public void userSelectsFirstRegimenOnRegimenPage() throws Throwable {
        obj().RegimensPage.selectRegimen();
    }

    @And("^User click Continue button in Regimen Page$")
    public void userClickContinueButtonInRegimenPage() throws Throwable {
        obj().RegimensPage.clickContinueButton();
        obj().CommonPage.waitForNOTBusyIndicator();
    }

    @And("^User clicks on Create Custom Regimen hyperlink in Regimen page$")
    public void userClicksOnCreateCustomRegimenHyperlinkInRegimenPage() throws Throwable {
        obj().RegimensPage.clickCustomRegimenLink();
    }

    @And("^User clicks on \"([^\"]*)\" hyperlink in Regimen page$")
    public void userClicksOnHyperlinkInRegimenPage(String linkTitle) throws Throwable {
        obj().CommonPage.clickOnHyperlink(linkTitle);
    }

    @And("^User enters \"([^\"]*)\" Drug Name count in add drug pop up window in Regimen page$")
    public void userEntersDrugNameCountInAddDrugPopUpWindowInRegimenPage(String drugName) throws Throwable {
        obj().RegimensPage.enterTextIndrugNameTextBox(drugName);
    }

    @And("^User enters \"([^\"]*)\" drug route in Regimen page$")
    public void userEntersDrugRouteInRegimenPage(String drugroute) throws Throwable {
        obj().RegimensPage.selectdrugrouteinregimen(drugroute);
    }

    @And("^User enters \"([^\"]*)\" dosage count in add drug pop up window in Regimen page$")
    public void userEntersDosageCountInAddDrugPopUpWindowInRegimenPage(String dosage) throws Throwable {
        obj().RegimensPage.enterTextInDosageTextBox(dosage);
    }

    @And("^User enters \"([^\"]*)\" Days of Administration count in add drug pop up window in Regimen page$")
    public void userEntersDaysOfAdministrationCountInAddDrugPopUpWindowInRegimenPage(String daysofAdministration) throws Throwable {
        obj().RegimensPage.enterTextInDaysofAdministrationTextBox(daysofAdministration);
    }

    @And("^User enters \"([^\"]*)\" Length of Cycles count in add drug pop up window in Regimen page$")
    public void userEntersLengthOfCyclesCountInAddDrugPopUpWindowInRegimenPage(String lengthofCycles) throws Throwable {
        obj().RegimensPage.enterTextInLengthofCyclesTextBox(lengthofCycles);

    }

    @And("^User clicks Add button in add drug pop up window in Regimen page$")
    public void userClicksAddButtonInAddDrugPopUpWindowInRegimenPage() throws Throwable {
        obj().RegimensPage.clickAddButton();
    }

    @Then("^User clicks on Ok button on Supportive Care Drug pop up in Regime page$")
    public void user_clicks_on_Ok_button_on_Supportive_Care_Drug_pop_up_in_Regime_page() throws Throwable {
        obj().RegimensPage.clickOkButtonOnSupportiveCareDrug();
    }

    @And("^User enters \"([^\"]*)\" in regimen justification textbox in Regimen page$")
    public void userEntersInRegimenJustificationTextboxInRegimenPage(String regimenJustification) throws Throwable {
        obj().RegimensPage.enterRegimenJustification(regimenJustification);
    }

    @And("^User click Continue button in custom Regimen Page$")
    public void userClickContinueButtonInCustomRegimenPage() throws Throwable {
        obj().RegimensPage.clickContinueButtonInCustomRegimenPage();
    }

    @And("^User selects an \"([^\"]*)\" Request outcome in custom Regimen Page$")
    public void userSelectsAnRequestOutcomeInCustomRegimenPage(String urgentRequestOutcome) throws Throwable {
        obj().RegimensPage.selectsValueFromUrgentRequestOutcomeDropdown(urgentRequestOutcome);
    }

    @And("^User verifies \"([^\"]*)\" Drug Code in add drug pop up window$")
    public void userVerifiesDrugCodeInAddDrugPopUpWindowInRegimenPage(String drugName) throws Throwable {
        obj().RegimensPage.verifiesTextIndrugCodeTextBox(drugName);
    }

    @And("^User verifies \"([^\"]*)\" Drug Name count in add drug pop up window$")
    public void userVerifiesDrugNameCountInAddDrugPopUpWindowInRegimenPage(String drugName) throws Throwable {
        obj().RegimensPage.verifiesTextIndrugNameTextBox(drugName);
    }

    @And("^User verifies \"([^\"]*)\" drug route in add drug pop up window$")
    public void userVerifiesDrugRouteInRegimenPage(String drugroute) throws Throwable {
        obj().RegimensPage.verifiesdrugrouteinregimen(drugroute);
    }

    @And("^User verifies \"([^\"]*)\" dosage count in add drug pop up window$")
    public void userVerifiesDosageCountInAddDrugPopUpWindowInRegimenPage(String dosage) throws Throwable {
        obj().RegimensPage.verifiesTextInDosageTextBox(dosage);
    }

    @And("^User verifies \"([^\"]*)\" Days of Administration count in add drug pop up window$")
    public void userVerifiesDaysOfAdministrationCountInAddDrugPopUpWindowInRegimenPage(String daysofAdministration) throws Throwable {
        obj().RegimensPage.verifiesTextInDaysofAdministrationTextBox(daysofAdministration);
    }

    @And("^User verifies \"([^\"]*)\" Length of Cycles count in add drug pop up window$")
    public void userVerifiesLengthOfCyclesCountInAddDrugPopUpWindowInRegimenPage(String lengthofCycles) throws Throwable {
        obj().RegimensPage.verifiesTextInLengthofCyclesTextBox(lengthofCycles);
    }

    @And("^User verifies Drug Name \"([^\"]*)\" in add drug pop up window in Regimen page$")
    public void userVerifiesDrugNameInAddDrugPopUpWindowInRegimenPage(String expectedDrugName) throws Throwable {
        obj().RegimensPage.verifyDrugName(expectedDrugName);
    }

    @And("^user should see the \"([^\"]*)\" error message on the Custom Regimen Page$")
    public void verifiesRegimensErrorMessage(String arg1) throws Throwable {
        obj().RegimensPage.verifiesRegimensErrorMessage(arg1);

    }

    @And("^user verifies Add Radio pharma drug message is diaplayed on Medical Review Request Page$")
    public void verifiesAddRadioPharmaDrugsMessage() throws Throwable {
        obj().RegimensPage.verifiesAddRadioPharmaDrugsMessage();

    }

    @And("^User clicks on Ok button on supportive care drug pop up on Medical Request Page$")
    public void clickOkButtonOnSupprtiveCareDrug() throws Throwable {
        obj().RegimensPage.clickOkButtonOnSupprtiveCareDrug();

    }

    @And("^User Verifies dosage count is populated with empty value in add drug pop up window in Regimen page$")
    public void userVerifiesDosageCountAsBlankInAddDrugPopUpWindowInRegimenPage() throws Throwable {
        obj().RegimensPage.verifyTextInDosageTextBox();
    }

    @And("^User Verifies daysofAdministration is populated with empty value in add drug pop up window in Regimen page$")
    public void userVerifiesDaysofAdministrationAsBlankInAddDrugPopUpWindowInRegimenPage() throws Throwable {
        obj().RegimensPage.verifyTextInDaysofAdministrationTextBox();
    }

    @And("^User Verifies lengthofCycles is populated with empty value in add drug pop up window in Regimen page$")
    public void userVerifiesLengthofCyclesAsBlankInAddDrugPopUpWindowInRegimenPage() throws Throwable {
        obj().RegimensPage.verifyTextInLengthofCyclesTextBox();
    }

    //TODO This needs to be removed once stepsets fully implemented. We are passing a string that isnt even used.
    @And("^User clicks on \"([^\"]*)\" hyperlink for supprotive flow in Regimen page$")
    public void userClicksOnHyperlinkForSupprotiveFlowInRegimenPage(String arg0) throws Throwable {
        obj().RegimensPage.clickAddDrugLink();
    }

    @And("^User validates Radiopharmaceutical Drug Notification popup and validates message \"([^\"]*)\"$")
    public void user_validates_Radiopharmaceutical_Drug_Notification_popup_and_validates_message(String arg1) throws Throwable {
        obj().RegimensPage.valdiateRadioPharmaDrugNotificationPopup(arg1);
    }

    @And("^User clicks on cancel button on radiopharma drug notification popup$")
    public void user_clicks_on_cancel_button_on_radiopharma_drug_notification_popup() throws Throwable {
        obj().RegimensPage.clickCancelButtonOnRadioPharmaNotificationDrugPopUp();
    }

    @And("^User clicks on Continue button on radiopharmadrug notification popup$")
    public void user_clicks_on_Continue_button_on_radiopharmadrug_notification_popup() throws Throwable {
        obj().RegimensPage.clickContinueButtonOnRadioPharmaNotificationDrugPopUp();
    }

    @And("^user clicks on Show Other Options Requiring Clinical Review hyperlink$")
    public void userClicksOnShowOtherOptionsRequiringClinicalReviewHyperlink() throws Throwable {
        obj().RegimensPage.showOtherOptionsRequiringClinicalReviewhyperlink();
    }


    @And("^User click Continue button on popup$")
    public void userClickContinueButtonOnPopup() throws Throwable {
        obj().RegimensPage.clickContinueButtononPopup();
    }

    @Then("^User verify that Transparency Metrics is not visible on the page$")
    public void user_verify_that_Transparency_Metrics_is_not_visible_on_the_page() throws Throwable {
        obj().RegimensPage.transparencyMetricsNotVisible();
    }


    @And("^user verifies header \"([^\"]*)\" on popup$")
    public void userVerifiesHeaderOnPopup(String arg0) throws Throwable {
        obj().RegimensPage.verifypopup(arg0);
    }

    @And("^user clicks on Hide Other Options Requiring Clinical Review hyperlink$")
    public void userClicksOnHideOtherOptionsRequiringClinicalReviewHyperlink() throws Throwable {
        obj().RegimensPage.hideOtherOptionsRequiringClinicalReviewhyperlink();

    }

    @And("^user selecting first choice from Available Growth Factors for Auto-Approval$")
    public void userSelectingFirstChoiceFromAvailableGrowthFactorsForAutoApproval() throws Throwable {
        obj().RegimensPage.selectingFirstChoiceforAvailableGrowthFactorsforAutoApproval();
    }

    @And("^user selecting first choice from Other Options \\(Requiring Clinical Review\\)$")
    public void userSelectingFirstChoiceFromOtherOptionsRequiringClinicalReview() throws Throwable {
        obj().RegimensPage.otherOptionRequiringClinicalReview();


    }

    @And("^user verifies \"([^\"]*)\"  popup message on Supportive Drug Review Required popup$")
    public void userVerifiesPopupMessageOnSupportiveDrugReviewRequiredPopup(String message) throws Throwable {
        obj().RegimensPage.verifySupportiveDrugReviewRequiredpopupMessage(message);
    }

    @And("^user verifies \"([^\"]*)\"  popup message on Other Options \\(Requiring Clinical Review\\)$")
    public void userVerifiesPopupMessageOnOtherOptionsRequiringClinicalReview(String popupMessage) throws Throwable {
        obj().RegimensPage.verifypopupMessageOtherOptionsRequiringClinicalReview(popupMessage.trim());

    }

    @And("^user verifies \"([^\"]*)\"  popup message on Other Options \\(Requiring Clinical Review\\)popup$")
    public void userVerifiesPopupMessageOnOtherOptionsRequiringClinicalReviewPopup(String popupMessage) throws Throwable {
        obj().RegimensPage.verifySupportiveDrugReviewRequiredpopupMessage(popupMessage.trim());

    }

    @And("^user verifies header \"([^\"]*)\" on Supportive Drug Review Required popup$")
    public void userVerifiesHeaderOnSupportiveDrugReviewRequiredPopup(String arg0) throws Throwable {
        obj().RegimensPage.verifypopupSupportiveDrugReviewRequired(arg0);
    }

    @And("^User click Continue button on supportive review popup$")
    public void userClickContinueButtonOnSupportiveReviewPopup() throws Throwable {
        obj().RegimensPage.continueFromSupportiveReviewRequiredPopup();
    }

    @And("^User verify Supportive Drug pop up on Regimen Page$")
    public void userVerifySupportiveDrugPopUpOnRegimenPage() throws Throwable {
        obj().RegimensPage.verifySupportiveDrugPopUp();
    }

    @And("^User select \"([^\"]*)\" and click continue button on Supportive Drug pop up on Regimen Page$")
    public void userSelectOptionAndClickContinueButtonOnRegimenPage(String arg1) throws Throwable {
        obj().RegimensPage.selectOptionAndClickContinueButton(arg1);
    }

    @And("^User click ok button on drug notification popup$")
    public void user_clicks_on_ok_button_on_radiopharma_drug_notification_popup() throws Throwable {
        obj().RegimensPage.clickOralDrugOK();
    }

    @And("^User select \"([^\"]*)\" Index regimen on Regimen Page$")
    public void userSelectsAutoapprovedRegimenOnRegimenPage(String arg1) throws Throwable {
        obj().RegimensPage.selectAutoapprovedRegimen(arg1);
    }

    @Then("^user should verify that following Available Growth Factors for Auto-Approval values are visible in the regimensPanel in Regimens page$")
    public void userShouldVerifyThatFollowingAvailableGrowthFactorsForAutoApprovalValuesAreVisibleInTheRegimensPanelInRegimensPage(DataTable dataTable) throws Throwable {
        List<String> expectedLabelvalues = dataTable.asList(String.class);
        obj().RegimensPage.isDrugPopulatedOnAvailableGrowthFactorsforAutoApprovalTable(expectedLabelvalues);

    }

    @Then("^user should verify that in the Other Options \\(Requiring Clinical Review\\) table folowing drug not visible in the regimensPanel in Regimens page$")
    public void userShouldVerifyThatInTheOtherOptionsRequiringClinicalReviewTableFolowingDrugNotVisibleInTheRegimensPanelInRegimensPage(DataTable dataTable) throws Throwable {
        List<String> expectedLabelvalues = dataTable.asList(String.class);
        obj().RegimensPage.isNotDrugPopulatedOnOtherOptionRequiringClinicalReviewTable(expectedLabelvalues);


    }

    @Then("^user should verify that following Available Growth Factors for Auto-Approval values are not visible in the regimensPanel in Regimens page$")
    public void userShouldVerifyThatFollowingAvailableGrowthFactorsForAutoApprovalValuesAreNotVisibleInTheRegimensPanelInRegimensPage(DataTable dataTable) throws Throwable {
        List<String> expectedLabelvalues = dataTable.asList(String.class);
        obj().RegimensPage.isDrugNotPopulatedOnAvailableGrowthFactorsforAutoApprovalTable(expectedLabelvalues);

    }

    @Then("^user should verify that in the Other Options \\(Requiring Clinical Review\\) table folowing drugs are visible in the regimensPanel in Regimens page$")
    public void userShouldVerifyThatInTheOtherOptionsRequiringClinicalReviewTableFolowingDrugsAreVisibleInTheRegimensPanelInRegimensPage(DataTable dataTable) throws Throwable {
        List<String> expectedLabelvalues = dataTable.asList(String.class);
        obj().RegimensPage.isDrugPopulatedOnOtherOptionRequiringClinicalReviewTable(expectedLabelvalues);

    }

    @And("^user adds drug on the custom regimen$")
    public void userAddsDrugOnTheCustomRegimen() throws Throwable {
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        TestUtils.wait(2);
        obj().RegimensPage.clickCustomRegimenLink();
        TestUtils.wait(3);
        obj().RegimensPage.clickAddDrugLink();
        obj().RegimensPage.enterTextInDrugCodeTextBox(pf.get(MBM.RGDR_DRUG_CODE_0));
        obj().RegimensPage.selectdrugrouteinregimen(pf.get(MBM.RGDR_DRUG_ROUTE_0));
        obj().RegimensPage.enterTextInDosageTextBox(pf.get(MBM.RGDR_DOSAGE_0));
        obj().RegimensPage.enterTextInDaysofAdministrationTextBox(pf.get(MBM.RGDR_DAY_S_OF_CYCLE_TO_BE_ADMINISTERED_0));
        obj().RegimensPage.enterTextInLengthofCyclesTextBox(pf.get(MBM.RGDR_LENGTH_OF_CYCLES_DAYS_OR_WEEKS_0));
        obj().RegimensPage.clickAddButton();

    }

    @And("^Regimen service lines are extracted with prefix \"([^\"]*)\" and key \"([^\"]*)\"$")
    public void regimenServiceLinesAreExtractedWithPrefixAndKey(String prefix, String keyHeader) throws Throwable {
        TestUtils.wait(5);
        int i = 1;
        for (String regimen : WhiteBoard.getInstance().
                getMap(owner, "regimenNameCollection").values()) {
            TestUtils.click(driver(), By.xpath("( " + obj().RegimensPage.regimenDropDownButton + ")[1]"));
            String xpath = "(//table[@role= 'presentation'][@class = 'second'])[" + i + "]";
            String prefixKey = regimen + "_" + prefix;
            TestUtils.extractGridToWhiteBoard(driver(), scenario, prefixKey, keyHeader, xpath, false, false);
            i++;
        }
    }

    @When("^\"([^\"]*)\" Regimens are extracted from DB with cancer type \"([^\"]*)\" and payer is \"([^\"]*)\"$")
    public void regimensAreExtractedFromDBWithCancerTypeAndPayerIs(String varName, String cancerType, String payer) throws Throwable {
        for (String regimen : WhiteBoard.getInstance().getMap(owner, "regimenNameCollection").values()) {
            List<Map<String, Object>> list = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectServiceLinesWithPayerFilter(regimen, cancerType, payer);
            if (extractRegimenFromDb(varName, regimen, list)) return;
        }
    }

    @Then("^user verifies objects with prefix \"([^\"]*)\" looks like below regimen table$")
    public void userVerifiesObjectsWithPrefixLooksLikeBelowRegimenTable(String prefix, List<Map<String, String>> mapsExpected) throws Throwable {
        for (String regimen : WhiteBoard.getInstance().
                getMap(owner, "regimenNameCollection").values()) {
            String dbPrefix = regimen + "_db_" + prefix;
            String prefixKey = regimen + "_" + prefix;
            List<Map<String, String>> actualMaps = WhiteBoard.getInstance().combine(owner, prefixKey);
            List<Map<String, String>> expectedMaps = WhiteBoard.getInstance().combine(owner, dbPrefix);
            MapsComparer mapsComparer = new MapsComparer(expectedMaps, actualMaps, scenarioLogger);
            mapsComparer.assertMatches(false);
        }
    }

    @When("^\"([^\"]*)\" Regimens are extracted without payer filter from DB with cancer type \"([^\"]*)\"$")
    public void regimensAreExtractedWithoutPayerFilterFromDBWithCancerType(String varName, String cancerType) throws Throwable {
        for (String regimen : WhiteBoard.getInstance().getMap(owner, "regimenNameCollection").values()) {
            List<Map<String, Object>> list = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectServiceLinesWithoutPayerFilter(regimen, cancerType);
            if (extractRegimenFromDb(varName, regimen, list)) return;
        }
    }

    private boolean extractRegimenFromDb(String varName, String regimen, List<Map<String, Object>> list) {
        Object result = list;
        if (null == result) {
            WhiteBoard.getInstance().putString(owner, regimen + "_" + varName + "_rows", "0");
            return true;
        }
        if (result instanceof List) {
            List<Map<String, Object>> mapList = null;
            try {
                mapList = (List<Map<String, Object>>) result;
            } catch (Exception e) {
                // do nothing
            }
            if (null == mapList) {
                WhiteBoard.getInstance().putString(owner, regimen + "_" + varName + "_rows", "0");
                return true;
            } else {
                List<Map<String, String>> stringMapList = DataTableUtils.asMapsOfStrings(mapList);
                Map<String, Map<String, String>> indexedMaps = DataTableUtils.dataTableAsMapsIndexedByKeyHeader(DataTableUtils.INDEX_ROW_NUMBER, stringMapList);
                WhiteBoard.storeMaps(owner, regimen + "_" + varName, Conf.getOutputPath(), indexedMaps);
            }
        } else {
            String s = result.toString();
            WhiteBoard.getInstance().putString(owner, regimen + "_" + varName, s);

        }
        return false;
    }

    @When("^User selects \"([^\"]*)\" Regimen by name$")
    public void user_Selects_Regimen_label(String rgLabel) throws Throwable {
        obj().RegimensPage.selectRegimen(rgLabel);
    }


    @When("^user verifies warning text on the \"([^\"]*)\" Pop-up$")
    public void user_verifies_warning_text_on_the_Pop_up(String arg1) throws Throwable {
        obj().RegimensPage.verifyOffPathwayRegimenpopupText(arg1);
    }

    @When("^User verifies Regimen Reason Pop-up$")
    public void user_verifies_regimen_Pop_up() throws Throwable {
        obj().RegimensPage.verifyRegimenpopupdropdown();
    }

    @When("^User clicks Continue on Regimen Reason Pop-up$")
    public void user_clicks_continue_regimen_Pop_up() throws Throwable {
        obj().RegimensPage.ContinueRegimenReasonPopUp();
    }

    @When("^User verifies error message \"([^\"]*)\" displayed on Regimen Reason Pop-up$")
    public void user_verifies_error_message_regimen_Pop_up(String expectedError) throws Throwable {
        obj().RegimensPage.verifyErrorMessagewhenReasonNotSelected(expectedError);
    }

    @Then("^User fills Reason for choosing this regimen with \"([^\"]*)\"$")
    public void user_fills_reason_for_choosing_this_regimen(String regimenreason) throws Throwable {
        obj().RegimensPage.fillreasonforchoosingthisregimendropdown(regimenreason);
    }

    @Then("^User verifies the On-Pathway Icon on the Regimen Screen$")
    public void user_verifies_the_On_Pathway_Icon_on_the_Regimen_Screen() throws Throwable {
        obj().RegimensPage.verifyOnPathwayIcon();
    }

    @And("^User sends \"([^\"]*)\" in regimen justification textbox in Regimen page$")
    public void userSendsInRegimenJustificationTextboxInRegimenPage(String arg0) throws Throwable {
        obj().RegimensPage.sendingRegimenJustification(arg0);
    }


    @And("^User click Yes button on Chemo Regimen Question popup$")
    public void userClickYesButtonOnChemoRegimenQuestionPopup() throws Throwable {
        obj().RegimensPage.clickChemoRegimenQuestionYes();

    }


    @And("^user selecting \"([^\"]*)\" choice from available growth factors$")
    public void userSelectingChoiceFromOtherOptionsRequiringClinicalReview(String drugCode) throws Throwable {
        obj().RegimensPage.selectingDrugChoice(drugCode);
    }


    @And("^user verifies \"([^\"]*)\"  popup message on Regimen Page Continue$")
    public void userVerifiesEPANotificationPopUp(String popupMessage) throws Throwable {
        obj().RegimensPage.verifyEPAPopUpMessage(popupMessage.trim());

    }

    @And("^user verifies \"([^\"]*)\"  popup message on Regimen Page Continue in UHC$")
    public void userVerifiesNotificationPopUpUHC(String popupMessage) throws Throwable {
        obj().RegimensPage.verifyPopUpMessageUHC(popupMessage.trim());

    }

    @And("^User click Expand button on Regimen Page$")
    public void userExpandDrugButtonOnRegimenPage() throws Throwable {
        obj().RegimensPage.regimenDrugExpand();

    }


    @And("^user extracts regimen name from UI as below if \"([^\"]*)\"$")
    public void userExtractsRegimenNameFromUIAsBelowIf(String ifExpression, DataTable dataTable) throws Throwable {
        if (WhiteBoard.evaluate(owner, ifExpression)) {
            TestUtils.wait(3);
            List<String> expectedValues = dataTable.asList(String.class);
            List<String> actualValues = new ArrayList<>();
            List<WebElement> elements = driver().findElements(By.xpath("//div[@class='regimen-header-wrapper']//span[@class='title ng-binding']"));
            Map<String, String> regimenNames = new LinkedHashMap<>(elements.size());
            int index = 1;
            for (WebElement ele : elements) {
                regimenNames.put("" + index++, ele.getText());
                actualValues.add(ele.getText());
            }
            Assert.assertTrue("regimen Actual is missing some values in Expected", actualValues.containsAll(expectedValues));
            WhiteBoard.getInstance().putMap(owner, "regimenNameCollection", regimenNames);
        }

    }

    @When("^user adds clinical documentation$")
    public void userAddsClinicalDocumentation() throws Throwable {
        obj().RegimensPage.addClinicalDocumentation("/src/main/resources/sampleFileForUpload/testFile.txt");
    }

    @And("^User click Continue button in custom Regimen Page when \"([^\"]*)\"$")
    public void userClickContinueButtonInCustomRegimenPageWhen(String testFlag) throws Throwable {
        if (testFlag.equals("non preferred")) {
            obj().RegimensPage.clickContinueButtonInCustomRegimenPage();
            TestUtils.wait(3);
        }
    }

    @And("^User clicks on \"([^\"]*)\" in Regimens page$")
    public void userClicksExpandAllOnInRegimensPage(String arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        obj().RegimensPage.regimensExpandAll();
    }

    @And("^user verifies \"([^\"]*)\" in the regimen$")
    public void userVerifiesInTheRegimen(String drugCode) throws Throwable {
        String ActualDrugCode = driver().findElement(By.xpath("(//div[@aria-label=\"Regimens\"]//div[contains(@id,'regimenDrawer')]/div/table//tr/td[text()='" + drugCode + "'])[1]")).getText();
        Assert.assertTrue("Drug code not verified", ActualDrugCode.equals(drugCode));
    }

    @And("^User should verify Drug Exception Notification popup displayed$")
    public void userShouldVerifyDrugExceptionNotificationPopupDisplayed() throws Throwable {
        obj().RegimensPage.verifyDrugExceptionNotification();
    }


    @And("^User click on Continue Button in Drug Exception Notification popup$")
    public void userClickOnContinueButtonInDrugExceptionNotificationPopup() throws Throwable {
        obj().RegimensPage.clickDrugExceptionContinueButton();
    }

    @And("^User should verify Rounded Dosage popup displayed$")
    public void userShouldVerifyRoundedDosagePopupDisplayed() throws Throwable {
        obj().RegimensPage.verifyRoundedDosagePopUp();
    }
    @And("^User accepts recommended rounded dosage on popup$")
    public void accept_RoundedDosage() throws Throwable {
        obj().RegimensPage.acceptRoundedDosage();

    }
    @And("^User rejects recommended rounded dosage on popup$")
    public void reject_RoundedDosage() throws Throwable {
        obj().RegimensPage.rejectRoundedDosage();

    }
    @And("^User clicks on confirm button of rounded dosage popup$")
    public void confirm_RoundedDosage() throws Throwable {
        obj().RegimensPage.clickConfirmButtonOnRoundedDosagePopUp();

    }

    @And("^User click Popup Other Option Continue button in Regimen Page$")
    public void userClickContinueButtonInRegimenPageOtherOption() throws Throwable {
        obj().RegimensPage.clickContinueButtonOtherOption();
        obj().CommonPage.waitForNOTBusyIndicator();
    }

    @And("^User click on close button on Pharmacy benefits notification popup$")
    public void clickCloseButtonOnPharmaNotificationPopUp() throws Throwable {
        obj().RegimensPage.clickCloseButtonOnPharmaNotificationPopUp();
    }


    @And("^User clicks Yes on Recommended Dosage popup$")
    public void userClicksYesOnRecommendedDosagePopup() throws Throwable {
        obj().RegimensPage.clickYesOnRecommendedDosageScreen();
    }

    @And("^User selects the Antimatic and Growth drug radio button$")
    public void userSelectsTheAntimaticAndGrowthDrugRadioButton() throws Throwable {
        obj().RegimensPage.userSelectsTheAntimaticAndGrowthDrugRadiobttn();
    }


    @And("^User selects \"([^\"]*)\" from the Supportive drug dropdown$")
    public void userSelectsFromTheSupportiveDrugDropdown(String dropdown) throws Throwable {
        obj().RegimensPage.userSelectsFromThedropdown(dropdown);
    }

    @And("^User selects the checkboxes on the Additional Service page$")
    public void userSelectsTheCheckboxesOnTheAdditionalServicePage() throws Throwable {
        obj().RegimensPage.userSelectsTheCheckboxesOnTheAdditionalServicepage();
    }
}