package atdd.test.stepdefinitions.authorization;

import atdd.common.ScenarioLogger;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.stepsets.Login;
import atdd.utils.DateUtils;
import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import java.util.List;
import java.util.Map;
import java.util.Random;

public class RequestDetailsStepDefinition {
    public static final Logger log = Logger.getLogger(RequestDetailsStepDefinition.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }

    @When("User fills Request details")
    public void searchForUser(DataTable provoderSet) throws Throwable {
        //Getting params
        List<Map<String, String>> list = provoderSet.asMaps(String.class, String.class);
        String height_of_the_patient = list.get(0).get("Height of the Patient");
        String weight_of_the_patient = list.get(0).get("Weight of the Patient");
        String initial_diagnosis_date = list.get(0).get("Initial Diagnosis Date");
        String place_of_service = list.get(0).get("Place of Service");
        String anticipatedTreatmentStartDate = list.get(0).get("Anticipated Treatment Start Date");
        String icdCode = list.get(0).get("ICD-10 Code");
        String primary_cancer = list.get(0).get("Primary Cancer");
        String chemotherapy_clinical_trial = list.get(0).get("Chemotherapy Clinical Trial");
        String disease_progressed = list.get(0).get("Disease Progressed");
        String changing_treatment = list.get(0).get("Changing Treatment");
        String changing_treatment_justification = list.get(0).get("Changing Treatment Justification");

        scenario.write("Enterng Height of the Patient: " + height_of_the_patient);
        obj().RequestDetailsPage.enterTextInHeightOfThePatient(height_of_the_patient);

        scenario.write("Entering Weight of the Patient: " + weight_of_the_patient);
        obj().RequestDetailsPage.enterTextInWeightOfThePatient(weight_of_the_patient);

        scenario.write("Entering Initial Diagnosis Date: " + initial_diagnosis_date);
        obj().RequestDetailsPage.enterTextInInitialDiagnosisDate(initial_diagnosis_date);

        scenario.write("Entering Place of Service: " + place_of_service);
        obj().RequestDetailsPage.selectDropDownValueInplaceofServiceTypeSel(place_of_service);

        scenario.write("Entering Anticipated Treatment Start Date");
        obj().RequestDetailsPage.enterTextInAnticipatedTreatmentTextBox(DateUtils.mmDdYyyy());

        scenario.write("Entering ICD-10 Code: " + icdCode);
        obj().RequestDetailsPage.enterTextinIcdCode(icdCode);

        scenario.write("Entering Primary Cancer: " + primary_cancer);
        obj().RequestDetailsPage.enterTextinprimaryCancer(primary_cancer);

        scenario.write("Entering Chemotherapy Clinical Trial: " + chemotherapy_clinical_trial);
        obj().RequestDetailsPage.selectDropDownValueInChemotherapyTrialCancerTypeSel(chemotherapy_clinical_trial);

        /*ToDo
        scenario.write("Entering Contact Fax Number: " + fax_number);
        obj().RequestingProviderPage.enterTextInContactFaxNumberTextBox(fax_number);

        scenario.write("Entering Contact Fax Number: " + fax_number);
        obj().RequestingProviderPage.enterTextInContactFaxNumberTextBox(fax_number);

        scenario.write("Entering Contact Fax Number: " + fax_number);
        obj().RequestingProviderPage.enterTextInContactFaxNumberTextBox(fax_number);
*/
    }

    @And("^User enters \"([^\"]*)\" height field in Request Details page$")
    public void userEntersHeightFieldInRequestDetailsPage(String height) throws Throwable {
        obj().RequestDetailsPage.enterTextInHeightOfThePatient(height);
    }

    @And("^User enters \"([^\"]*)\" weight field in Request Details page$")
    public void userEntersWeightFieldInRequestDetailsPage(String weight) throws Throwable {
        obj().RequestDetailsPage.enterTextInWeightOfThePatient(weight);
    }

    @When("^User enters \"([^\"]*)\" phone field in Request Details page$")
    public void userEntersPhoneFieldInRequestDetailsPage(String phone) throws Throwable {
        obj().RequestDetailsPage.enterTextInPatientContactNumber(phone);
    }

    @And("^User enters \"([^\"]*)\" initialDiagnosisDate field in Request Details page$")
    public void userEntersInitialDiagnosisDateFieldInRequestDetailsPage(String initialDiagnosisDate) throws Throwable {
        obj().RequestDetailsPage.enterTextInInitialDiagnosisDate(initialDiagnosisDate);
    }

    @And("^User enters \"([^\"]*)\" place of Service field in Request Details page$")
    public void userEntersPlaceOfServiceFieldInRequestDetailsPage(String service) throws Throwable {
        obj().RequestDetailsPage.selectDropDownValueInplaceofServiceTypeSel(service);
    }

    @And("^User enters treatmentStartDate field in Request Details page$")
    public void userEntersTreatmentStartDateFieldInRequestDetailsPage() throws Throwable {
        obj().RequestDetailsPage.enterTextInAnticipatedTreatmentTextBox(DateUtils.mmDdYyyy());
    }

    @And("^User enters \"([^\"]*)\" treatmentStartDate field in Request Details page$")
    public void userEntersTreatmentStartDateFieldInRequestDetailsPage(String date) throws Throwable {
        obj().RequestDetailsPage.enterTextInAnticipatedTreatmentTextBox(date);
    }

    @And("^User enter \"([^\"]*)\" ICDCode field in Request Details page$")
    public void userEnterICDCodeFieldInRequestDetailsPage(String iCDCode) throws Throwable {
        obj().RequestDetailsPage.enterTextinIcdCode(iCDCode);
    }

    @And("^User enter \"([^\"]*)\" additional ICDCode field in Request Details page$")
    public void userEnteradditionalICDCodeFieldInRequestDetailsPage(String iCDCode) throws Throwable {
        obj().RequestDetailsPage.addAdditionalIcd10Code(iCDCode);
    }

    //New Steps
    @And("^User enter \"([^\"]*)\" PrimaryICDCode field in Request Details page$")
    public void userEnterPrimaryIcdCode(String userEnterPrimaryIcdCode) throws Throwable {
        obj().RequestDetailsPage.enterPrimaryIcdCodeAndClickAddCode(userEnterPrimaryIcdCode);
    }


    @And("^User selects \"([^\"]*)\" from Performance Scale in Request Details page$")
    public void selectFromPerformanceScale(String scale) throws Throwable {
        obj().RequestDetailsPage.selectDropDownPerformanceScale(scale);
    }

    @And("^User selects \"([^\"]*)\" from Performance Status in Request Details page$")
    public void selectFromPerformanceStatus(String ststus) throws Throwable {
        obj().RequestDetailsPage.selectDropDownPerformanceStatus(ststus);
    }

    @And("^User enters \"([^\"]*)\" primaryCancer field in Request Details page$")
    public void userEntersPrimaryCancerFieldInRequestDetailsPage(String primaryCancer) throws Throwable {
        obj().RequestDetailsPage.enterTextinprimaryCancer(primaryCancer);
    }

    @And("^User selects \"([^\"]*)\" Supportive Care Only Request field in Request Details page$")
    public void userSelectsSupportiveCareOnlyRequestFieldInRequestDetailsPage(String supportiveCareRequest) throws Throwable {
        obj().RequestDetailsPage.selectDropDownValueInSupportiveCareRequest(supportiveCareRequest);
    }

    @And("^User selects \"([^\"]*)\" Chemotherapy Trial Cancer dropdown list in Request Details page$")
    public void userSelectsChemotherapyTrialCancerDropdownListInRequestDetailsPage(String chemotherapyTrialCancer) throws Throwable {
        obj().RequestDetailsPage.selectDropDownValueInChemotherapyTrialCancerTypeSel(chemotherapyTrialCancer);
    }

    @And("^User selects \"([^\"]*)\" diseaseStatus dropdown list in Request Details page$")
    public void userSelectsDiseaseStatusDropdownListInRequestDetailsStepperPage(String diseaseProgressed) throws Throwable {
        obj().RequestDetailsPage.selectDropDownValueInDiseaseProgressedTypeSel(diseaseProgressed);
    }

    @And("^User selects \"([^\"]*)\" new Treatment dropdown list in Request Details page$")
    public void userSelectsChangingTreatmentDropdownListInRequestDetailsPage(String changingTreatment) throws Throwable {
        obj().RequestDetailsPage.selectDropDownValueInChangingTreatmentTypeSel(changingTreatment);
    }


    @And("^User selects \"([^\"]*)\" label in Changing Treatment Justification section on Request Details Page$")
    public void userSelectsLabelInChangingTreatmentJustificationSectionOnRequestDetailsPage(String justificationReason) throws Throwable {
        obj().RequestDetailsPage.changeTreatmentJustificationSelection(justificationReason);
    }

    @And("^User clicks Continue button on Request Details Page$")
    public void userClicksContinueButtonOnRequestDetailsPage() throws Throwable {
        obj().RequestDetailsPage.clickContinueButton();
        obj().CommonPage.waitForNOTBusyIndicator();
    }
    //Hyperlinks

    @And("^User clicks AddDoses Hyperlink on Request Details Page$")
    public void userClicksAddDosesHyperlinkOnRequestDetailsPage() throws Throwable {
        obj().RequestDetailsPage.clickingAddDosage();

    }

    //Speciality Disease state
    @And("^User enters \"([^\"]*)\" SpecialityDiseaseState in Request Details page$")
    public void userEntersDiseaseStateInRequestDetailsPage(String s) throws Throwable {
        obj().RequestDetailsPage.enterTextInDiseaseState(s);
    }

    //Add Doses
    @And("^User enters \"([^\"]*)\"  for Number of Doses per Administration$")
    public void userEntersForNumberOfDosesPerAdministration(String numberofdosesforAdmin) throws Throwable {
        obj().RequestDetailsPage.enteringNumberofDoses(numberofdosesforAdmin);
    }


    @And("^User enters \"([^\"]*)\" for Dose value and \"([^\"]*)\" as Unit Value$")
    public void userEntersForDoseValueAndAsUnitValue(String drugDosge, String unit) throws Throwable {
        obj().RequestDetailsPage.enteringDrugDosage(drugDosge, unit);
        //obj().RequestDetailsPage.enteringNumberofDoses(numberofDoses);

    }

    @Then("^User selects \"([^\"]*)\" from Justification for Backdating of Start Date$")
    public void user_selects_from_Justification_for_Backdating_of_Start_Date(String arg1) throws Throwable {
        obj().RequestDetailsPage.selectJustificationForBackdatingOfStartDating(arg1);
    }

    @And("^User enters \"([^\"]*)\" for Frequency value and \"([^\"]*)\" as dropdown Value$")
    public void userEntersForFrequencyValueAndAsDropdownValue(String every, String frequencydropdown) throws Throwable {
        obj().RequestDetailsPage.inputFrequecy(every);
        obj().RequestDetailsPage.selectsValueFromFrequencyOfAdministration(frequencydropdown);
    }

    @And("^User enters \"([^\"]*)\" for Total Number of Doses value$")
    public void userEntersForTotalNumberOfDosesValue(String numberofDoses) throws Throwable {
        obj().RequestDetailsPage.inputTotoalNumberofDoses(numberofDoses);
    }

    @And("^User clicks on Add  button in Dosage popup$")
    public void userClicksOnAddButtonInDosagePopup() throws Throwable {
        obj().RequestDetailsPage.specialtyPharmaclickAddButton();
    }

    @And("^User enters \"([^\"]*)\" Initial Date of Progression dropdown list in Request Details page$")
    public void userEntersInitialDateOfProgressionDropdownListInRequestDetailsPage(String initialDateofProgression) throws Throwable {
        obj().RequestDetailsPage.enterTextInInitialDateofProgression(initialDateofProgression);
    }

    @And("^User enters \"([^\"]*)\" in Other Description in Request Details page$")
    public void userEntersInOtherDescriptionInRequestDetailsPage(String description) throws Throwable {
        obj().RequestDetailsPage.enterOtherDecription(description);
    }

    @And("User selects \"([^\"]*)\" Radiopharmaceutical dropdown list in Request Details page$")
    public void userSelectsRadiopharmaceuticalsRequestDropdownListInRequestDetailsStepperPage(String RadiopharmaceuticalReq) throws Throwable {
        obj().RequestDetailsPage.selectDropDownValueInRadiopharmaceuticalRequestTypeSel(RadiopharmaceuticalReq);
    }

    @And("^User enters \"([^\"]*)\" as height and validate error message$")
    public void user_enters_as_height_and_validate_error_message(String arg1) throws Throwable {
        obj().RequestDetailsPage.validateBoundaryValueForHeight(arg1);
    }

    @Then("^User selects \"([^\"]*)\" from Cancer Clinical Trial$")
    public void user_selects_from_Cancer_Clinical_Trial(String arg1) throws Throwable {
        obj().RequestDetailsPage.selectDropDownValueInCacnerClinicalTrial(arg1);
    }

    @Then("^User selects \"([^\"]*)\" from Has Disease Progressed or Relapsed$")
    public void user_selects_from_Has_Disease_Progressed_or_Relapsed(String arg1) throws Throwable {
        obj().RequestDetailsPage.selectDropDownValueIndiseaseProgressedOrRelapsed(arg1);
    }

    @Then("^User selects \"([^\"]*)\" from Is patient currently taking Leuprolide Acetate\\?$")
    public void user_selects_from_Is_patient_currently_taking_Leuprolide_Acetate(String drug) throws Throwable {
        obj().RequestDetailsPage.selectDropDownValueInLeuprolideAcetateSel(drug);
    }

    @Then("^User selects \"([^\"]*)\" from Is patient currently taking Octreotide\\?$")
    public void user_selects_from_Is_patient_currently_taking_Octreotide(String drug) throws Throwable {
        obj().RequestDetailsPage.selectDropDownValueInOctreotide(drug);
    }


    @And("^Element with text \"([^\"]*)\" and Required mark is visible on Request Details page$")
    public void elementWithTextAndRequiredMarkIsVisibleOnRequestDetailsPage(String txt) throws Throwable {
        obj().RequestDetailsPage.checkRequiredElementByText(txt);
    }

    @And("^User selects \"([^\"]*)\" from the Drug Type dropdown list in Request Details page$")
    public void userSelectsFromTheDrugTypeDropdownListInRequestDetailsPage(String drugType) throws Throwable {
        obj().RequestDetailsPage.selectDropdownDrugType(drugType);
    }

    @And("^User selects \"([^\"]*)\" from Is the line of therapy being given dropdown list in Request Details page$")
    public void userSelectsFromIsTheLineOfTherapyBeingGivenDropdownListInRequestDetailsPage(String lineOfTherapy) throws Throwable {
        obj().RequestDetailsPage.selectDropDownLineOfTherapy(lineOfTherapy);
    }

    @When("^verify Error Message \"([^\"]*)\" on Request Details Page$")
    public void verify_Error_Message_on_Request_Details_Page(String arg1) throws Throwable {
        obj().RequestDetailsPage.verifyTextOnRequestDetailsPage(arg1);
    }

    @And("^height is not required on the Request Details Page$")
    public void heightIsNotRequiredOnTheRequestDetailsPage() throws Throwable {
        obj().RequestDetailsPage.checkHeightWithRequiredMark();
    }

    @And("^User selects \"([^\"]*)\" on Is patient currently taking -drug- question in Request Details page$")
    public void userSelectsOnIsPatientCurrentlyTakingDrugQuestionInRequestDetailsPage(String IsMedicineTaken) throws Throwable {
        obj().RequestDetailsPage.selectDropDownValueInCurrentMedicineTypeSel(IsMedicineTaken);
    }

    @Then("^User verifies \"([^\"]*)\" field is not displayed$")
    public void user_verifies_field_is_not_displayed(String ClinicalTrial) throws Throwable {
        obj().RequestDetailsPage.verifytheClinicalTrialFields(ClinicalTrial);
    }

    @Then("^User enters \"([^\"]*)\" clinical Trial Name field in Request Details Page$")
    public void user_enters_clinical_Trial_Name_field_in_Request_Details_Page(String TrialName) throws Throwable {
        obj().RequestDetailsPage.enterTextInClinicalTrialName(TrialName);
    }

    @Then("^User enters \"([^\"]*)\" clinical Trial Phase field in Request Details Page$")
    public void user_enters_clinical_Trial_Phase_field_in_Request_Details_Page(String TrialPhase) throws Throwable {
        obj().RequestDetailsPage.enterTextInClinicalTrialPhase(TrialPhase);
    }

    @And("User verifies \"([^\"]*)\" option is present in Radiopharmaceutical dropdown in Request Details page$")
    public void userVerifiesRadiopharmaceuticalsOptionInRequestDropdownListInRequestDetailsStepperPage(String RadiopharmaceuticalReq) throws Throwable {
        obj().RequestDetailsPage.verifyDropDownValueInRadiopharmaceuticalRequestTypeSel(RadiopharmaceuticalReq);
    }

    @And("^User should verify a popup is displayed with title Drug Exception Notification on Drug Exception modal page$")
    public void userShouldVerifyAPopupIsDisplayedWithTitleDrugExceptionNotificationOnRequestDetailsPage() throws Throwable {
        obj().RequestDetailsPage.verifyDrugExceptionPopUpHeader();
    }

    @And("^User verifies popup message \"([^\"]*)\" Drug Exception modal page$")
    public void userVerifiesPopupMessageDrugExceptionModalPage(String message) throws Throwable {
        obj().RequestDetailsPage.verifyDrugExceptionPopUpMessage(message);
    }

    @And("^User should see close button on Drug Exception modal page$")
    public void userShouldSeeCloseButtonOnDrugExceptionModalPage() throws Throwable {
        obj().RequestDetailsPage.verifyCloseButtonOnDrugExceptionModalPage();
    }

    @And("^User verifies X action button on Drug Exception modal page$")
    public void userVerifiesXActionButtonOnDrugExceptionModalPage() throws Throwable {
        obj().RequestDetailsPage.verifyXActionButton();
    }

    @And("^User selects \"([^\"]*)\"selecting Treatment dropdown as Continuation of Treatment in Request Details page$")
    public void userSelectsChangingTreatmentContinuationofTreatmentDropdownListInRequestDetailsPage(String changingTreatment) throws Throwable {
        obj().RequestDetailsPage.selectDropDownValueInChangingTreatmentTypeSel(changingTreatment);
    }

    @Then("^User navigates to request details Screen successfully and verify header \"([^\"]*)\"$")
    public void userNavigatesToRequestDetailsScreenSuccessfullyAndVerifyHeader(String arg0) throws Throwable {
        obj().RequestDetailsPage.verifyHeader();

    }

    @And("^user verifies hidden Header \"([^\"]*)\" not visible on the page$")
    public void userVerifiesHiddenHeaderNotVisibleOnThePage(String arg0) throws Throwable {
        obj().RequestDetailsPage.verifyHiddenHeader();

    }


    @Then("^User navigates to request details Screen and verify no visible header for \"([^\"]*)\"$")
    public void userNavigatesToRequestDetailsScreenAndVerifyNoVisibleHeaderFor(String arg0) throws Throwable {
        obj().RequestDetailsPage.verifyHeaderforMS();
    }

    @And("^User selects \"([^\"]*)\" Therapy on Request Details Page$")
    public void selectTherapyOnRequestDetailsPage(String therapyName) throws Throwable {
        obj().RequestDetailsPage.selectTherapyOnRequestDetailsPage(therapyName);

    }

    @And("^user clicks back button on RequestDetails Page$")
    public void userClicksBackButtonOnRequestDetailsPage()throws Throwable {
        obj().RequestDetailsPage.clickBackButton();
        obj().CommonPage.waitForNOTBusyIndicator();
    }
}
