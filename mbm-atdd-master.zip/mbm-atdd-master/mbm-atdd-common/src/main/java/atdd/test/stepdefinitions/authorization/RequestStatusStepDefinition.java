package atdd.test.stepdefinitions.authorization;

import atdd.common.ScenarioLogger;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.stepsets.Login;
import atdd.utils.TestUtils;
import atdd.utils.WhiteBoard;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import atdd.test.pageobjects.authorization.physicalHealth.*;

public class RequestStatusStepDefinition {
    public static final Logger log = Logger.getLogger(RequestStatusStepDefinition.class.getName());
    public String actualRequestnumber;
    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }

    @And("^User verifies \"([^\"]*)\" on Request Status page$")
    public void userVerifiesOnRequestStatusPage(String requestStatusMessage) throws Throwable {
        TestUtils.wait(5);
        obj().RequestStatusPage.verifyAuthorizationRequestStatus(requestStatusMessage);
    }

    @And("^User verifies Anticipated Treatment Start Date under service details on Request Status page$")
    public void userVerifiesAnticipatedTreatmentStartDateUnderServiceDetailsOnRequestStatusPage() throws Throwable {
        obj().RequestStatusPage.verifyAnticipatedTreatmentStartDate();
    }

    @And("^User verifies Is it an Urgent Request is \"([^\"]*)\" under custom regimen on Request Status page$")
    public void userVerifiesIsItAnUrgentRequestIsUnderCustomRegimenOnRequestStatusPage(String urgentRequestValue) throws Throwable {
        obj().RequestStatusPage.verifyIsItAnUrgentRequest(urgentRequestValue);
    }

    @And("^User verifirs Urgent Request Outcome \"([^\"]*)\" under custom regimen on Request Status page$")
    public void userVerifirsUrgentRequestOutcomeUnderCustomRegimenOnRequestStatusPage(String urgentRequestOutcomeValue) throws Throwable {
        obj().RequestStatusPage.verifyIsItAnUrgentRequestOutcome(urgentRequestOutcomeValue);
    }

    @And("^User stores the Authorization Number Present on Request Status page$")
    public void userAuthNumberOnRequestStatusPage() throws Throwable {
        obj().RequestStatusPagePH.storeAuthNumber();
    }

    @And("^User verifies the end date is not present on Request Status page$")
    public void userVerifiesEndDateIsNotPresentOnRequestStatusPage() throws Throwable {
        obj().RequestStatusPage.verifyEndDateHidden();
    }

    @And("^User verifies \"([^\"]*)\" under clinical details on Request Status page$")
    public void userVerifiesUnderClinicalDetailsOnRequestStatusPage(String expectedDescription) throws Throwable {
        obj().RequestStatusPage.verifyOtherDecription(expectedDescription);
    }

    @And("^user verifies custom regimen is changed to \"([^\"]*)\" on Request Status page$")
    public void userVerifiesMedicalReviewRequestOnRequestSummaryPage(String MedicalReviewReq) throws Throwable {
        obj().RequestStatusPage.verifyMedicalReviewRequest(MedicalReviewReq);
    }

    @And("^user verifies regimen justification is changed to \"([^\"]*)\" on Request Status page$")
    public void userVerifiesRequestJustificationOnRequestSummaryPage(String requestJustification) throws Throwable {
        obj().RequestStatusPage.verifyRequestJustification(requestJustification);
    }

    @And("^User verifies Primary Cancer \"([^\"]*)\" under clinical details on Request Status page$")
    public void userVerifiesPrimaryCancerUnderClinicalDetailsOnRequestStatusPage(String expectedPrimaryCancer) throws Throwable {
        obj().RequestStatusPage.verifyPrimaryCancer(expectedPrimaryCancer);
    }

    @And("^User verifies Supportive Care Only Request \"([^\"]*)\" under clinical details on Request Status page$")
    public void userVerifiesSupportiveCareOnlyRequestUnderClinicalDetailsOnRequestStatusPage(String expectedSupportiveCare) throws Throwable {
        obj().RequestStatusPage.verifySupportiveCare(expectedSupportiveCare);
    }

    @And("^User verifies Chemotherapy Clinical Trial \"([^\"]*)\" under clinical details on Request Status page$")
    public void userVerifiesChemotherapyClinicalTrialUnderClinicalDetailsOnRequestStatusPage(String expectedChemotherapyClinicalTrial) throws Throwable {
        obj().RequestStatusPage.verifyChemotherapyClinicalTrial(expectedChemotherapyClinicalTrial);
    }

    @And("^User verifies diseaseStatus \"([^\"]*)\" under clinical details on Request Status page$")
    public void userVerifiesDiseaseStatusUnderClinicalDetailsOnRequestStatusPage(String expectedDiseaseStatus) throws Throwable {
        obj().RequestStatusPage.verifyDiseaseStatus(expectedDiseaseStatus);
    }

    @And("^User verifies Initial Date of Progression \"([^\"]*)\" under clinical details on Request Status page$")
    public void userVerifiesInitialDateOfProgressionUnderClinicalDetailsOnRequestStatusPage(String expectedInitialDateOfProgression) throws Throwable {
        obj().RequestStatusPage.verifyInitialDateOfProgression(expectedInitialDateOfProgression);
    }

    @And("^User verifies Changing Treatment \"([^\"]*)\" under clinical details on Request Status page$")
    public void userVerifiesChangingTreatmentUnderClinicalDetailsOnRequestStatusPage(String expectedChangingTreatment) throws Throwable {
        obj().RequestStatusPage.verifyChangingTreatment(expectedChangingTreatment);
    }

    @And("^User verifies Changing Treatment Justification \"([^\"]*)\" under clinical details on Request Status page$")
    public void userVerifiesChangingTreatmentJustificationUnderClinicalDetailsOnRequestStatusPage(String expectedChangingTreatmentJustification) throws Throwable {
        obj().RequestStatusPage.verifyChangingTreatmentJustification(expectedChangingTreatmentJustification);
    }

    @And("^User verifies \"([^\"]*)\" label is visible on Request Status page$")
    public void userVerifiesLabelIsVisibleOnRequestStatusPage(String label) throws Throwable {
        obj().RequestStatusPage.verifyLabel(label);
    }

    @And("^User verifies Drug Type \"([^\"]*)\" under clinical details on Request Status page$")
    public void userVerifiesDrugTypeUnderClinicalDetailsOnRequestStatusPage(String expectedDrugType) throws Throwable {
        obj().RequestStatusPage.verifyDrugType(expectedDrugType);
    }

    @And("^User verifies Is the first line of therapy being given \"([^\"]*)\" under clinical details on Request Status page$")
    public void userVerifiesIsTheFirstLineOfTherapyBeingGivenUnderClinicalDetailsOnRequestStatusPage(String expectedLineOfTherapy) throws Throwable {
        obj().RequestStatusPage.verifyIsTheFirstLineOfTherapy(expectedLineOfTherapy);
    }

    @And("^User verifies \"([^\"]*)\" Radiopharmaceutical drug name under the status on Request Status page$")
    public void userVerifiesRadiopharmaceuticalDrugNameUnderTheStatusOnRequestStatusPage(String drug) throws Throwable {
        obj().RequestStatusPage.verifyRadiopharmaceuticalDrug(drug);
    }

    @And("^User verifies \"([^\"]*)\" under clinical status on Request Status page$")
    public void userVerifiesUnderClinicalStatusOnRequestStatusPage(String header) throws Throwable {
        obj().RequestStatusPage.verifyTherapeuticRadiopharmaceuticalUnderClinicalStatus(header);
    }

    @And("^User verifies \"([^\"]*)\" Radiopharmaceutical drug name under Therapeutic Radiopharmaceutical on Request Status page$")
    public void userVerifiesRadiopharmaceuticalDrugNameUnderTherapeuticRadiopharmaceuticalOnRequestStatusPage(String drug) throws Throwable {
        obj().RequestStatusPage.verifyRadiopharmaceuticalDrugNameUnderTherapeuticRadiopharmaceutical(drug);
    }

    @Then("^User verifies \"([^\"]*)\" and \"([^\"]*)\" in Confirmation Page$")
    public void user_verifies_and_in_Confirmation_Page(String expectedClinicalTrialName, String expectedClinicalTrialPhase) throws Throwable {
        obj().RequestStatusPage.verifyClinicalTrialNameandPhase(expectedClinicalTrialName, expectedClinicalTrialPhase);
    }

    @And("^User verifies regimen reason is \"([^\"]*)\" in Request Status page$")
    public void userVerifiesRegimenreasonOnRequestStatusPage(String regimenreason) throws Throwable {
        obj().RequestSummaryPage.verifyRegimenreason(regimenreason);
    }

    @And("^User Verify High Risk Regimen Authorization Duration under Regimen section on Request Status page$")
    public void userVerifyHighRiskRegimenAuthorizationDurationUnderRegimenSectionOnRequestStatusPage() throws Throwable {
        obj().RequestStatusPage.getAuthorizationDuration();
    }

    @Then("^User Verify calculated months between Authorization start date and Authorization End Date as \"([^\"]*)\" months equal to High Risk regimen duration months$")
    public void userVerifyCalculatedMonthsBetweenAuthorizationStartDateAndEndDateAsMonthsEqualToHighRiskRegimenDurationMonths(String monthsBetween) throws Throwable {
        obj().RequestStatusPage.getCalculatedAuthorizationDuration();
    }
    @And("^User retrieve the Authorization request number$")
    public void userRetrieveTheAuthorizationRequestNumber() throws Throwable {
        actualRequestnumber =   obj().RequestStatusPage.getAuthorizationNumber();
        log.warn("Submitted Auth number is "+actualRequestnumber);
        WhiteBoard.getInstance().putString(owner, "requestNumber", actualRequestnumber);
        scenarioLogger.warn("New string added for " + owner + ": " + "requestNumber" + "=" + actualRequestnumber);
    }


    @And("^User enters Vendor case ID as submitted Request number in Icue$")
    public void userEntersVendorCaseIDAsSubmittedRequestNumberInIcue() throws Throwable {
        obj().Icue.enterVendorCaseId(actualRequestnumber);
    }

    @And("^User enters the submitted authorization number in PriorAuth Search Submitted page$")
    public void userEntersTheSubmittedAuthorizationNumberInPriorAuthSearchSubmittedPage() throws Throwable {
        obj().PriorAuthorizationSearchSubmittedPage.enterRequestNumber(actualRequestnumber);
    }

    @And("^User clicks view icon on submitted authorization number in PriorAuth Search Submitted page$")
    public void userClicksViewIconOnsubmittedAuthorizationNumberInPriorAuthSearchSubmittedPage() throws Throwable {
        obj().PriorAuthorizationSearchSubmittedPage.clickDocumentIconByRequestNumber(actualRequestnumber);
    }

    //Benefit Type drop down selection to Medical - Mandatory field.
    @And("^User choose the BenefitType as \"([^\"]*)\"$")
    public void userChooseTheBenefitTypeAsMedical(String benefitType) throws Throwable {
        obj().PriorAuthorizationSearchSubmittedPage.selectBenefitTypeDropDwn(benefitType);
    }

    // Overall Auth Status Type drop down selection
    @And("^User choose the Status as \"([^\"]*)\"$")
    public void userChooseTheStatus(String authOverallStatus) throws Throwable {
        obj().PriorAuthorizationSearchSubmittedPage.selectOverallStatusDropDwn(authOverallStatus);
    }

    // Status Type drop down selection to Pending Review - Mandatory field.
    @And("^User Enter Therapy Authorization With Reasons By Status \"([^\"]*)\"$")
    public void userEnterTherapyAuthorizationWithReasonsByStatus(String authOverallStatus) throws Throwable {
        String therapyAuthNumber = obj().PriorAuthorizationSearchSubmittedPage.getTherapyAuthorizationByOverallStatus(authOverallStatus);
        obj().PriorAuthorizationSearchSubmittedPage.enterRequestNumber(therapyAuthNumber);
    }

}