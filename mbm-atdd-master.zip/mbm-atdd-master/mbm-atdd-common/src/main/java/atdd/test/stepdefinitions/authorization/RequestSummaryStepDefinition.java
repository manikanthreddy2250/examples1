package atdd.test.stepdefinitions.authorization;

import atdd.common.ScenarioLogger;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.shared.BaseCucumber;
import atdd.test.stepsets.Login;
import atdd.utils.TestUtils;
import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.List;
import java.util.Map;


public class RequestSummaryStepDefinition {
    public static final Logger log = Logger.getLogger(RequestSummaryStepDefinition.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }

    @And("^User click Submit button on Request Summary page$")
    public void userClickSubmitButtonOnRequestSummaryPage() throws Throwable {
        obj().RequestSummaryPage.clickSubmitButton();
    }


    @And("^User verifies Anticipated Treatment Start Date under service details on Request Summary page$")
    public void userVerifiesAnticipatedTreatmentStartDateUnderServiceDetailsOnRequestSummaryPage() throws Throwable {
        obj().RequestSummaryPage.verifyAnticipatedTreatmentStartDate();
    }

    @And("^User verifies Is it an Urgent Request is \"([^\"]*)\" under custom regimen on Request Summary page$")
    public void userVerifiesIsItAnUrgentRequestIsUnderCustomRegimenOnRequestSummaryPage(String urgentRequestValue) throws Throwable {
        obj().RequestSummaryPage.verifyIsItAnUrgentRequest(urgentRequestValue);
    }

    @And("^User verifirs Urgent Request Outcome \"([^\"]*)\" under custom regimen on Request Summary page$")
    public void userVerifirsUrgentRequestOutcomeUnderCustomRegimenOnRequestSummaryPage(String expectedUrgentRequestOutcomeValue) throws Throwable {
        obj().RequestSummaryPage.verifyIsItAnUrgentRequestOutcome(expectedUrgentRequestOutcomeValue);
    }

    @And("^User verifies \"([^\"]*)\" under clinical details on Request Summary page$")
    public void userVerifiesUnderClinicalDetailsOnRequestSummaryPage(String expectedDescription) throws Throwable {
        obj().RequestSummaryPage.verifyOtherDecription(expectedDescription);
    }

    @And("^user verifies regimen justification is changed to \"([^\"]*)\" in Request summary page$")
    public void userVerifiesRequestJustificationOnRequestSummaryPage(String requestJustification) throws Throwable {
        obj().RequestSummaryPage.verifyRequestJustification(requestJustification);
    }

    @And("^User verifies regimen reason is \"([^\"]*)\" in Request Summary page$")
    public void userVerifiesRegimenreasonOnRequestSummaryPage(String regimenreason) throws Throwable {
        obj().RequestSummaryPage.verifyRegimenreason(regimenreason);
    }

    @And("^Element with text \"([^\"]*)\" is visible on Request Summary page$")
    public void elementWithTextIsVisibleOnRequestSummaryPage(String txt) throws Throwable {
        obj().RequestSummaryPage.checkRequiredElementByText(txt);
    }

    @And("^User verifies Primary Cancer \"([^\"]*)\" under clinical details on Request Summary page$")
    public void userVerifiesPrimaryCancerUnderClinicalDetailsOnRequestSummaryPage(String expectedPrimaryCancer) throws Throwable {
        obj().RequestSummaryPage.verifyPrimaryCancer(expectedPrimaryCancer);
    }

    @And("^User verifies Supportive Care Only Request \"([^\"]*)\" under clinical details on Request Summary page$")
    public void userVerifiesSupportiveCareOnlyRequestUnderClinicalDetailsOnRequestSummaryPage(String expectedSupportiveCare) throws Throwable {
        obj().RequestSummaryPage.verifySupportiveCare(expectedSupportiveCare);
    }

    @And("^User verifies Chemotherapy Clinical Trial \"([^\"]*)\" under clinical details on Request Summary page$")
    public void userVerifiesChemotherapyClinicalTrialUnderClinicalDetailsOnRequestSummaryPage(String expectedChemotherapyClinicalTrial) throws Throwable {
        obj().RequestSummaryPage.verifyChemotherapyClinicalTrial(expectedChemotherapyClinicalTrial);
    }

    @And("^User verifies diseaseStatus \"([^\"]*)\" under clinical details on Request Summary page$")
    public void userVerifiesDiseaseStatusUnderClinicalDetailsOnRequestSummaryPage(String expectedDiseaseStatus) throws Throwable {
        obj().RequestSummaryPage.verifyDiseaseStatus(expectedDiseaseStatus);
    }

    @And("^User verifies Initial Date of Progression \"([^\"]*)\" under clinical details on Request Summary page$")
    public void userVerifiesInitialDateOfProgressionUnderClinicalDetailsOnRequestSummaryPage(String expectedInitialDateOfProgression) throws Throwable {
        obj().RequestSummaryPage.verifyInitialDateOfProgression(expectedInitialDateOfProgression);
    }

    @And("^User verifies Changing Treatment \"([^\"]*)\" under clinical details on Request Summary page$")
    public void userVerifiesChangingTreatmentUnderClinicalDetailsOnRequestSummaryPage(String expectedChangingTreatment) throws Throwable {
        obj().RequestSummaryPage.verifyChangingTreatment(expectedChangingTreatment);
    }

    @And("^User verifies Changing Treatment Justification \"([^\"]*)\" under clinical details on Request Summary page$")
    public void userVerifiesChangingTreatmentJustificationUnderClinicalDetailsOnRequestSummaryPage(String expectedChangingTreatmentJustification) throws Throwable {
        obj().RequestSummaryPage.verifyChangingTreatmentJustification(expectedChangingTreatmentJustification);
    }

    @And("^User verifies \"([^\"]*)\" label is visible on Request Summary page$")
    public void userVerifiesLabelIsVisibleOnRequestSummaryPage(String label) throws Throwable {
        obj().RequestSummaryPage.verifyLabel(label);
    }

    @And("^User verifies Drug Type \"([^\"]*)\" under clinical details on Request Summary page$")
    public void userVerifiesDrugTypeUnderClinicalDetailsOnRequestSummaryPage(String expectedDrugType) throws Throwable {
        obj().RequestSummaryPage.verifyDrugType(expectedDrugType);
    }


    @And("^User verifies Is the first line of therapy being given \"([^\"]*)\" under clinical details on Request Summary page$")
    public void userVerifiesIsTheFirstLineOfTherapyBeingGivenUnderClinicalDetailsOnRequestSummaryPage(String expectedLineOfTherapy) throws Throwable {
        obj().RequestSummaryPage.verifyIsTheFirstLineOfTherapy(expectedLineOfTherapy);
    }

    @And("^User verifies \"([^\"]*)\" under clinical status on Request Summary page$")
    public void userVerifiesUnderClinicalStatusOnRequestSummaryPage(String header) throws Throwable {
        obj().RequestSummaryPage.verifyTherapeuticRadiopharmaceuticalUnderClinicalStatus(header);
    }

    @And("^User verifies \"([^\"]*)\" Radiopharmaceutical drug name under Therapeutic Radiopharmaceutical on Request Summary page$")
    public void userVerifiesRadiopharmaceuticalDrugNameUnderTherapeuticRadiopharmaceuticalOnRequestSummaryPage(String drug) throws Throwable {
        obj().RequestSummaryPage.verifyRadiopharmaceuticalDrugNameUnderTherapeuticRadiopharmaceutical(drug);
    }

    @And("^User verifies height \"([^\"]*)\" under clinical details on Request Summary page$")
    public void userVerifiesHeightUnderClinicalDetailsOnRequestSummaryPage(String height) throws Throwable {
        obj().RequestSummaryPage.verifyHeightOnRequestSummary(height);
    }

    @Then("^User verifies \"([^\"]*)\" Clinical Trial Name is the one entered in Request Details Page and is under Clinical Status section in Request Summary Page$")
    public void user_verifies_Clinical_Trial_Name_is_the_one_entered_in_Request_Details_Page_and_is_under_Clinical_Status_section_in_Request_Summary_Page(String arg1) throws Throwable {
        if (arg1.equalsIgnoreCase("gv")) arg1 = BaseCucumber.gv.getClinicalTrialName();
        obj().RequestSummaryPage.verifytheClinicalTrialName(arg1);
    }

    @Then("^User verifies \"([^\"]*)\" Clinical Trial Phase is the one entered in Request Details Page and is under Clinical Status section in Request Summary Page$")
    public void user_verifies_Clinical_Trial_Phase_is_the_one_entered_in_Request_Details_Page_and_is_under_Clinical_Status_section_in_Request_Summary_Page(String arg1) throws Throwable {
        if (arg1.equalsIgnoreCase("gv")) arg1 = BaseCucumber.gv.getClinicalTrialPhase();
        obj().RequestSummaryPage.verifytheClinicalTrialPhase(arg1);
    }

    @And("^user clicks on Back to Dashboard button on Request Status page$")
    public void and_user_clicks_on_Back_to_Dashboard_button_on_Edit_Authorization_page() throws Throwable {
        obj().EditAuthorizationPage.clickBackdToDashboardButton();
    }

    @And("^user verifies Is it an Urgent Request\\? according to given table on Status page$")
    public void userVerifiesIsItAnUrgentRequestAccordingToGivenTableOnStatusPage(DataTable dataTable) throws Throwable {
        List<Map<String, String>> maps = dataTable.asMaps(String.class, String.class);
        for (Map<String, String> map : maps) {
            String label = map.get("label");
            String expected = map.get("expected");
            String actual = driver().findElement(By.xpath("//label[text()='" + label + "']/../../following-sibling::td/span")).getText();
            obj().RequestStatusPage.verifyAsperTable(expected, actual, label);

        }
    }

    @And("^User verifies Dosage & Total Billing Units on Request Summary page$")
    public void dosageTotalBillingUnitsRequestSummaryPage() throws Throwable {
        TestUtils.wait(10);
        obj().RequestSummaryPage.verifyDosage_BillableUnits();
    }

    @And("^User Clicks on Edit Details link from Current Functional Measure Socre section$")
    public void ClickEditDetailsFromCurrentFunctionalMeasureSocreSection() throws Throwable {
        TestUtils.wait(10);
        obj().RequestSummaryPage.clickCFMSEditDetails();
    }


    @And("^User verifies the Auto-Approvable Dosage and Billing Units Grid and dosage \"([^\"]*)\" value$")
    public void userVerifiesTheAutoApprovableDosageAndBillingUnitsGridAndDosageValue(String dosage) throws Throwable {
        obj().RequestSummaryPage.verifyAutoApprovalDosage(dosage);
    }
}