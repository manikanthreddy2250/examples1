package atdd.test.stepdefinitions.authorization;

import atdd.common.ScenarioLogger;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.stepsets.Login;
import atdd.utils.TestUtils;
import cucumber.api.DataTable;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import java.util.List;
import java.util.Map;


public class RequestingProviderSearchModalStepDefinition {
    public static final Logger log = Logger.getLogger(RequestingProviderSearchModalStepDefinition.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }

    @When("User changes provider")
    public void searchForUser(DataTable provoderSet) throws Throwable {
        //Getting params
        List<Map<String, String>> list = provoderSet.asMaps(String.class, String.class);
        String physTin = list.get(0).get("Physician TIN");
        String facilityTin = list.get(0).get("Facility TIN");

        // scenario.write("Clicking Change Provider link");
//      obj().CommonPage.clickOnHyperlink("Change provider");

        if (!TestUtils.checkNullOrDash(physTin)) {
            scenario.write("Selecting TIN and or NPI radiobutton");
            obj().RequestingProviderSearchModalPage.selectTINRadioBtn_ChangeProvModal();

            scenario.write("Entring TIN on Physitian Tab " + physTin);
            obj().RequestingProviderSearchModalPage.userEntersTINPhys(physTin);

            scenario.write("Clicking Search button");
            obj().RequestingProviderSearchModalPage.clickSearchButton();

            scenario.write("Selecting First record");
            obj().RequestingProviderSearchModalPage.selectFirstPhysicianSearchResult();
        } else if (!TestUtils.checkNullOrDash(facilityTin)) {
            scenario.write("Clicking Facility Tab");
            obj().RequestingProviderSearchModalPage.clickFacilityTab();

            scenario.write("Selecting TIN radio button on the Facility TAB");
            obj().RequestingProviderSearchModalPage.selectTINRadioBtn_ChangefacilityProvModal();

            scenario.write("Entering TIN " + facilityTin + " on the Facility TAB");
            obj().RequestingProviderSearchModalPage.userEntersTINFacility(facilityTin);

            scenario.write("Clicking Search button");
            obj().RequestingProviderSearchModalPage.clickSearchButton();

            scenario.write("Selecting First record");
            obj().RequestingProviderSearchModalPage.selectFirstFacilitySearchResult();
        }

        obj().RequestingProviderSearchModalPage.clickChangeButton();

    }

    @And("^User validates the \"([^\"]*)\" Physician tab in Requesting Provider search modal page$")
    public void userValidatesThePhysicianTabInRequestingProviderSearchModalPage(String tab) throws Throwable {
        obj().RequestingProviderSearchModalPage.verifyProviderPhyscianTabOnPopup(tab);
    }

    @And("^User enter the npi number \"([^\"]*)\" on Physician Tab in Requesting Provider search modal page$")
    public void userEnterTheNpiNumberOnPhysicianTabInRequestingProviderSearchModalPage(String npiNumber) throws Throwable {
        obj().RequestingProviderSearchModalPage.enterNpiNumberInPhysicianTab(npiNumber);
    }

    @And("^User enter the TIN \"([^\"]*)\" on physician Tab in Requesting Provider search modal page$")
    public void userEnterTheTINOnPhysicianTabInRequestingProviderSearchModalPage(String TIN) throws Throwable {
        obj().RequestingProviderSearchModalPage.userEntersTINPhys(TIN);
    }

    @And("^User clicks Search button in Requesting Provider search modal page$")
    public void userClicksSearchButtonInRequestingProviderSearchModalPage() throws Throwable {
        obj().RequestingProviderSearchModalPage.clickSearchButton();
    }

    @And("^User selects first record from the Physician npi results grid on Requesting Provider search modal page$")
    public void userSelectsFirstRecordFromThePhysicianNpiResultsGridOnRequestingProviderSearchPage() throws Throwable {
        obj().RequestingProviderSearchModalPage.selectFirstPhysicianSearchResult();
    }

    @And("^User clicks Change button in Requesting Provider search modal page$")
    public void userClicksChangeButtonInRequestingProviderSearchModalPage() throws Throwable {
        obj().RequestingProviderSearchModalPage.clickChangeButton();
    }

    @Then("^User selects TIN and/or NPI radio button on Requesting Provider search modal page$")
    public void userSelecntTIN_Modal() throws Throwable {
        obj().RequestingProviderSearchModalPage.selectTINRadioBtn_ChangeProvModal();
    }

    @And("^User clicks on Facility tab in Requesting Provider search modal page$")
    public void userClicksOnFacilityTab() throws Throwable {
        obj().RequestingProviderSearchModalPage.clickFacilityTab();
    }

    @And("^User enter the TIN \"([^\"]*)\" on Facility Tab in Requesting Provider search modal page$")
    public void userEnterTheTINOnFacilityTabInRequestingProviderSearchModalPage(String TIN) throws Throwable {
        obj().RequestingProviderSearchModalPage.userEntersTINFacility(TIN);
    }

    @And("^User selects first record from the Facility TIN results grid on Requesting Provider search modal page$")
    public void userSelectsFirstRecordFromTheFacilityTINResultsGridOnRequestingProviderSearchPage() throws Throwable {
        obj().RequestingProviderSearchModalPage.selectFirstPhysicianSearchResult();
    }

    @Then("^User clicks TIN radio button in Requesting Provider search modal page$")
    public void userSelectFacilityTIN_Modal() throws Throwable {
        obj().RequestingProviderSearchModalPage.selectTINRadioBtn_ChangefacilityProvModal();
    }


    @And("^User validates the \"([^\"]*)\" column in the search results table$")
    public void userValidatesTheColumnInTheSearchResultsTable(String Label) throws Throwable {
        obj().RequestingProviderSearchModalPage.validateLabelInTable(Label);
    }


    @And("^User clicks Clear button in Requesting Provider search modal page$")
    public void userClicksClearButtonInRequestingProviderSearchModalPage() throws Throwable {
        obj().RequestingProviderSearchModalPage.clickClearButton();
    }

    @And("^user verifies the contact no as \"([^\"]*)\" on error msg$")
    public void userVerifiesTheContactNoAsOnErrorMsg(String contact) throws Throwable {
        obj().RequestingProviderSearchModalPage.validateLabelInTable(contact);
    }

    @And("^User verifies the payer as \"([^\"]*)\"$")
    public void userVerifiesThePayerAs(String Payer) throws Throwable {
        obj().RequestingProviderSearchModalPage.validateProviderName(Payer);
    }

    @And("^user should not see NPI search field$")
    public void userShouldNotSeeNPISearchField() throws Throwable {
        obj().RequestingProviderSearchModalPage.verifyNoNPISearchField();
    }

    @And("^User enters the \"([^\"]*)\" and navigate to Requesting provider details page$")
    public void userEntersTheAndNavigateToRequestingProviderDetailsPage(String TIN) throws Throwable {
        obj().RequestingProviderSearchModalPage.selectTINRadioBtn_ChangeProvModal();
        obj().RequestingProviderSearchModalPage.userEntersTINPhys(TIN);
        obj().RequestingProviderSearchModalPage.clickSearchButton();
        obj().RequestingProviderSearchModalPage.selectFirstPhysicianSearchResult();
        obj().RequestingProviderSearchModalPage.clickChangeButton();

    }
}

