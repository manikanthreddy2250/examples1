package atdd.test.stepdefinitions.authorization;


import atdd.common.MapsComparer;
import atdd.common.ScenarioLogger;
import atdd.dao.mbm.MbrDao;
import atdd.dao.mbm.MyBatisConnectionFactory;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.pageobjects.authorization.RequestingProviderPage;
import atdd.test.stepsets.Login;
import atdd.utils.DataTableUtils;
import atdd.utils.ExcelLib;
import atdd.utils.MBM;
import atdd.utils.TestUtils;
import cucumber.api.PendingException;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class RequestingProviderStepDefinition {

    public static final Logger log = Logger.getLogger(RequestingProviderStepDefinition.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }

    @When("User fills provider details")
    public void searchForUser() throws Throwable {
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        TestUtils.wait(2);
        obj().RequestingProviderPage.enterTextInProvPhoneNbrTextBox(pf.get(MBM.RPPD_PROVIDER_PHONE_NUMBER));
        obj().RequestingProviderPage.enterTextInProvFaxNbrTextBox(pf.get(MBM.RPPD_PROVIDER_FAX_NUMBER));
        obj().RequestingProviderPage.enterTextInContactNameTextBox(pf.get(MBM.RPPC_FULL_NAME));
        obj().RequestingProviderPage.enterTextInContactPhoneNumberTextBox(pf.get(MBM.RPPC_PHONE_NUMBER));
        obj().RequestingProviderPage.enterTextInContactFaxNumberTextBox(pf.get(MBM.RPPC_FAX_NUMBER));
        if (!pf.get(MBM.USER_TITLE).equals("a PAAN provider") && !pf.get(MBM.USER_TITLE).equals("a bcbs provider")
                && !pf.get(MBM.USER_TITLE).equals("a UM nurse")) {
            obj().RequestingProviderPage.selectRequestReceivedBy(pf.get(MBM.RPPC_REQUEST_RECEIVED_BY));
        }
        TestUtils.safeClick(driver(), RequestingProviderPage.continueButton);


    }


    @And("^User click Save Draft button in Requesting Provider page$")
    public void userClickSaveDraftButtonInRequestingProviderPage() throws Throwable {
        obj().RequestingProviderPage.clickSaveDraftButton();
    }

    @Then("^User click on \"([^\"]*)\" hyperlink on Requesting Provider page$")
    public void userClickOnHyperlinkOnRequestingProviderPage(String hyperlink) throws Throwable {
        obj().CommonPage.clickOnHyperlink(hyperlink);
    }

    @And("^User enters the \"([^\"]*)\" Req ProviderPhoneNumber in Requesting Provider page$")
    public void userEntersTheReqProviderPhoneNumberInRequestingProviderPage(String reqProviderPhoneNumber) throws Throwable {
        obj().RequestingProviderPage.enterTextInProvPhoneNbrTextBox(reqProviderPhoneNumber);

    }

    @And("^User enters the \"([^\"]*)\" Req ProviderFaxNumber in Requesting Provider page$")
    public void userEntersTheReqProviderFaxNumberInRequestingProviderPage(String reqProviderFaxNumber) throws Throwable {
        obj().RequestingProviderPage.enterTextInProvFaxNbrTextBox(reqProviderFaxNumber);
    }

    @And("^User enters the \"([^\"]*)\" Contact Person Phone Number in Requesting Provider page$")
    public void userEntersTheContactPersonPhoneNumberInRequestingProviderPage(String phoneNumber) throws Throwable {
        obj().RequestingProviderPage.enterTextInContactPhoneNumberTextBox(phoneNumber);
    }

    @And("^User enters the \"([^\"]*)\" Contact Person fax Number in Requesting Provider page$")
    public void userEntersTheContactPersonFaxNumberInRequestingProviderPage(String faxNumber) throws Throwable {
        obj().RequestingProviderPage.enterTextInContactFaxNumberTextBox(faxNumber);
    }

    @And("^User click Continue button in Requesting Provider page$")
    public void userClickContinueButtonInRequestingProviderPage() throws Throwable {
        obj().RequestingProviderPage.clickContinueButton();
        obj().CommonPage.waitForNOTBusyIndicator();
    }

    @Then("^User click Select a Requesting Provider in Requesting Provider page$")
    public void userClickSelectARequestingProviderInRequestingProviderPage() throws Throwable {
        obj().RequestingProviderPage.clickSelectaRequestingProvider();
    }

    @And("^User enters the \"([^\"]*)\" Contact Name in Requesting Provider page$")
    public void userEntersTheContactNameInRequestingProviderPage(String contactName) throws Throwable {
        obj().RequestingProviderPage.enterTextInContactNameTextBox(contactName);
    }

    @And("^user verifies that the fields on Requesting Provider page are editable$")
    public void userVerifiesThatTheFieldsOnRequestingProviderPageAreEditable() throws Throwable {
        obj().RequestingProviderPage.verifyFieldsAreEditable();
    }

    @And("^User verifies the data on the requesting provider details  as same as the previous authorization \"([^\"]*)\"$")
    public void userVerifiesTheDataOnTheRequestingProviderDetailsAsSameAsThePreviousAuthorization(String Tin) throws Throwable {
        obj().RequestingProviderPage.verifyDataofRequestingProviderPage(Tin);
    }

    @And("user verifies the data present on the Provider Page as LastName and FirstName$")
    public void userVerifiesTheDataPresentOnTheProviderPageAsAnd() throws Throwable {
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        obj().RequestingProviderPage.verifyTheValuesOnRequestingProvider(pf);
    }

    @And("^user clicks on continue button on the requesting provider page$")
    public void userClicksOnContinueButtonOnTheRequestingProviderPage() throws Throwable {

        int count = 0;
        int maxTries = 3;
        while (true) {
            try {
                TestUtils.safeClick(driver(), By.xpath("//*[@id=\"requestingProviderPanelIdContent\"]/div/div/input[3]"));
                TestUtils.wait(3);
                TestUtils.text(driver(), By.xpath("//*[@id=\"servicingProviderPanelId\"]/div[1]/h2/span"));
                break;
            } catch (Exception e) {
                if (++count == maxTries) throw e;
            }
        }

    }


    @And("^Fax Number is not a required field$")
    public void faxNumberIsNotARequiredField() throws Throwable {
        obj().RequestingProviderPage.verifyFaxNumberIsNotRequired();
    }


    @And("^Change provider button is displayed$")
    public void changeProviderButtonIsDisplayed() throws Throwable {
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        obj().RequestingProviderPage.verifyChangeProviderIsVisible(pf);
    }
    @And("^communication type is not a required field$")
    public void communicationTypeIsNotRequired() throws Throwable {
        obj().RequestingProviderPage.verifyCommunicationTypeIsNotRequired();
    }
    @And("^User verifies the search modal displays \"([^\"]*)\"")
    public void userVerifysearchModaldisplayIsCorrect(String message) throws Throwable {
        obj().RequestingProviderSearchModalPage.verifySearchModalProviderNotFoundMessage(message);
    }
    @And("^user verifies text of provider point of contact header is \"([^\"]*)\"$")
    public void userShouldBeLandingOnPage(String title) throws Throwable {
        obj().RequestingProviderPage.verifyTextOfPointOfContactHeader(title);
    }
    @And("^user clicks on contact us link")
    public void clickOnContactUsLink() throws Throwable {
        obj().RequestingProviderSearchModalPage.clickOnContactUs();
    }

    @And("^user clicks on member head expansion icon$")
    public void clickOnMemberHeaderExpansion() throws Throwable {
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        obj().RequestingProviderPage.clickOnMemberHeaderExpansion(pf);
    }


    @And("^user verifies the data of the header$")
    public void userVerifiesTheDataIsCorrectInAllThreeFields() throws Throwable {
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        List<List<String>> memberData1 = TestUtils.asLists(driver(), "//div[@class='memberHeader mh-expanded ng-scope']//table//tr//td", "span[1]", "span[2]");
        List<Map<String, String>> actualMemberData = new ArrayList<>();
        Map<String, String> map = new LinkedHashMap<>();
        for(List<String> lst : memberData1){
            map.put(lst.get(0), lst.get(1));
        }
        actualMemberData.add(map);

        long HSC = TestUtils.getHscIdFromURL(driver().getCurrentUrl());
        List<Map<String, Object>> list = new MbrDao(MyBatisConnectionFactory.getSqlSessionFactory()).
                getHeaderData(Long.parseLong(pf.get(MBM.MEMB_SUBSCRIBER_ID)), HSC);
        List<Map<String, String>> memberDb = DataTableUtils.asMapsOfStrings(list);

        MapsComparer mapsComparer = new MapsComparer(memberDb, actualMemberData, scenarioLogger);
        mapsComparer.assertMatches(false);

    }



    /**
     * Will attempted to find the expanded header and verify it is not available.
     *
     * @throws Throwable
     */
    @And("^user verifes that expanded header is not available$")
    public void userVerifesThatExpandedHeaderIsNotAvailable() throws Throwable {
        obj().RequestingProviderPage.verifyHeaderIsNotAvailable();
    }

    /**
     * Will verify that the fax number is required under the "Point of Contact Header"
     *
     * @throws Throwable
     */
    @And("^user verifies fax number is required$")
    public void userVerifiesFaxNumberIsRequired() throws Throwable {
        obj().RequestingProviderPage.verifyFaxNumberIsRequired();
    }

    /**
     * Will verify that the communication type function is available on the requesting provider page.
     *
     * @throws Throwable
     */
    @And("^communication type is displayed$")
    public void communicationTypeIsDisplayed() throws Throwable {
        obj().RequestingProviderPage.verifyCommunicationTypeIsDisplayed();
    }

    @And("^User validate Insurance subType file in Header section$")
    public void userValidateInsuranceSubTypeFileInHeaderSection() throws Throwable {
        obj().RequestingProviderPage.verifySubInsuranceTypeInHeaderSection();
    }


    @Then("^Blocked Authorization Override popup should be displayed$")
    public void blockedAuthorizationOverridePopupShouldBeDisplayed() throws Throwable {
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
       obj().RequestingProviderPage.verifyBlockerOverridePopup(pf);
    }

    @And("^user selects the override reason to continue$")
    public void userSelectsTheOverrideReasonToContinue() throws Throwable {
        obj().RequestingProviderPage.selectBlockeroverrideOption("Provider Faxed Auth");
         obj().RequestingProviderPage.clickOverrideContinueButton();
    }

    @And("^User fills the requesting provider details$")
    public void userFillsTheProviderDetails() throws Throwable {
        log.warn("Filling the Requesting provider details");
            Map<String, String> pf = ExcelLib.completeProfile(owner, null);
            TestUtils.wait(2);
            obj().RequestingProviderPage.enterTextInProvPhoneNbrTextBox(pf.get(MBM.RPPD_PROVIDER_PHONE_NUMBER));
            obj().RequestingProviderPage.enterTextInProvFaxNbrTextBox(pf.get(MBM.RPPD_PROVIDER_FAX_NUMBER));
            obj().RequestingProviderPage.enterTextInContactNameTextBox(pf.get(MBM.RPPC_FULL_NAME));
            obj().RequestingProviderPage.enterTextInContactPhoneNumberTextBox(pf.get(MBM.RPPC_PHONE_NUMBER));

    }
    @When("^User clicks Continue button on Requesting Provider Page$")
    public void userClicksContinueButtonOnRequestingProviderPage() throws Throwable{
        log.warn("clicking on the continue button");
        TestUtils.safeClick(driver(), RequestingProviderPage.continueButton);
    }

    @And("^User clicks \"([^\"]*)\" button on override popup$")
    public void userClicksButtonOnOverridePopup(String arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        log.warn("clicking on the continue button");

    }


    @Then("^a notify popup should be displayed$")
    public void aNotifyPopupShouldBeDisplayed() throws Throwable {
        obj().RequestingProviderPage.verifyNotifyPopup();
    }


    @Given("^User should navigate to Requesting Provider page$")
    public void user_should_navigate_to_Requesting_Provider_page() throws Throwable {
       obj().RequestingProviderPage.verifyRequestingProviderPageisDisplayed();
    }
}

