package atdd.test.stepdefinitions.authorization;

import atdd.common.ScenarioLogger;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.stepsets.Login;
import atdd.utils.ExcelLib;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import java.util.Map;


public class ServicingProviderStepDefinition {
    public static final Logger log = Logger.getLogger(ServicingProviderStepDefinition.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }

    @And("^User click Add Servicing Provider button in Servicing Provider page$")
    public void userClickAddServicingProviderButtonInServicingProviderPage() throws Throwable {
        obj().ServicingProviderPage.clickAddServicingProvider();
    }

    @And("^User click Yes button in Servicing Provider page$")
    public void userClickYesButtonInServicingProviderPage() throws Throwable {
        obj().ServicingProviderPage.clickYesButton();
        obj().CommonPage.waitForNOTBusyIndicator();
    }

    @And("^User click Continue button in Servicing Provider page$")
    public void userClickContinueButtonInServicingProviderPage() throws Throwable {
        obj().ServicingProviderPage.clicKContinueButton();
        obj().CommonPage.waitForNOTBusyIndicator();
    }

    @And("^User verifies \"([^\"]*)\" button visible on Servicing Provider/Pharmacy page$")
    public void userVerifiesButtonOnServicingProviderPharmacyPage(String x) throws Throwable {
        obj().ServicingProviderPage.verifyAddServicingProviderOrPharmacyButton();

    }

    @And("^User verifies \"([^\"]*)\" button NOT visible in Servicing Provider/Pharmacy page$")
    public void userVerifiesButtonNOTVisibleInServicingProviderPharmacyPage(String x) throws Throwable {
        obj().ServicingProviderPage.verifyAddServicingProviderOrPharmacyButtonNotVisibleOnthePage();

    }
    @And("^user clicks button on Servicing Provider Page$")
    public void userClicksButtonOnServicingProviderPage() throws Throwable {
        obj().ServicingProviderPage.clickBackButton();
        obj().CommonPage.waitForNOTBusyIndicator();
    }

    @And("^User verifies OON Check pop up message$")
    public void userVerifiesOONCheckPopUpMessage() throws Throwable {
        obj().ServicingProviderPage.verifyOONCheckPopUpMessage();
    }

    @And("^User verifies Narrow Network OON Check on servicing provider page$")
    public void userVerifiesNNOONCheckPopUpMessage() throws Throwable {
        obj().ServicingProviderPage.verifyNNOONCheckPopUpMessage();
    }

    @Then("^SP Blocked Authorization Override popup should be displayed$")
    public void SPblockedAuthorizationOverridePopupShouldBeDisplayed() throws Throwable {
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        obj().ServicingProviderPage.SPverifyBlockerOverridePopup(pf);
    }

    @And("^user selects the SP override reason to continue$")
    public void userSelectsTheOverrideReasonToContinue() throws Throwable {
        obj().ServicingProviderPage.SPselectBlockeroverrideOption("Provider Out Of Network");
        obj().ServicingProviderPage.SPselectBlockeroverrideJustification("Test");
        obj().ServicingProviderPage.SPclickOverrideContinueButton();
    }

    @Then("^User verifies default data populated on servicing provider page$")
    public void userVerifiesDefaultDataPopulatedOnServicingProviderPage() throws Throwable {
        log.warn("verfying limited supplier data defaulted on Servicing provider page");
        obj().ServicingProviderPage.verifyDefaultProviderData();
    }

    @Given("^user verifies dropdown values on Override Reason dropdown$")
    public void user_verifies_dropdown_values_on_Override_Reason_dropdown() throws Throwable {
        obj().ServicingProviderPage.verifyOverRideReasonValues();
    }

    @Given("^user selects \"([^\"]*)\" override reason$")
    public void user_selects_override_reason(String override) throws Throwable {
        obj().ServicingProviderPage.selectOverRideReason(override);
    }

    @Given("^user clicks Continue button from authorization override popup$")
    public void user_clicks_Continue_button_from_authorization_override_popup() throws Throwable {
        obj().ServicingProviderPage.continueOverridePopup();
    }

    @Given("^User validates Overridden Blocking Rules table in UM page$")
    public void user_validates_Overridden_Blocking_Rules_table() throws Throwable {
        obj().ServicingProviderPage.overriddenBlockingRulesTableUM();
    }

    @Given("^User validates Overridden Blocking Rules table in Request Summary page$")
    public void user_validates_Overridden_Blocking_Rules_table_in_Request_Summary_page() throws Throwable {
        obj().ServicingProviderPage.overriddenBlockingRulesTableReqSummary();
    }

    @Given("^User validates Overridden Blocking Rules table in Request Status page$")
    public void User_validates_Overridden_Blocking_Rules_table_in_Request_Status_page() throws Throwable {
        obj().ServicingProviderPage.overriddenBlockingRulesTableReqStatus();
    }

    @Given("^User validates warning message to select override reason$")
    public void user_validates_warning_message_to_select_override_reason() throws Throwable {
        obj().ServicingProviderPage.warningMessageOverrideReason();
    }

    @Given("^User selects Cancel button from authorization override popup$")
    public void user_selects_Cancel_button_from_authorization_override_popup() throws Throwable {
        obj().ServicingProviderPage.cancelOverridePopup();
    }


    @Then("^User verifies Provider RI Blocking pop up on Servicing Provider page$")
    public void user_verifies_Provider_RI_Blocking_pop_up_on_Servicing_Provider_page() throws Throwable {
        obj().ServicingProviderPage.verifyProviderRIBlockingPopupDisplayed();
    }
    @Then("^User verifies Provider RI Blocking pop up on Servicing Provider Search Pop up$")
    public void user_verifies_Provider_RI_Blocking_pop_up_on_Servicing_Provider_Search_Pop_up() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        obj().ServicingProviderPage.verifyProviderRIBlockingOnSPSPopupDisplayed();
    }

}
