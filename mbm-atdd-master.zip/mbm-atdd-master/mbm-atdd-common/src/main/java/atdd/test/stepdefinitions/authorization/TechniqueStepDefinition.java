package atdd.test.stepdefinitions.authorization;

import atdd.common.ScenarioLogger;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.stepsets.Login;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

public class TechniqueStepDefinition {

    public static final Logger log = Logger.getLogger(TechniqueStepDefinition.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }


    @And("^User verifies \"([^\"]*)\" header in Technique page$")
    public void userVerifiesHeaderInTechniquePage(String header) throws Throwable {
        obj().TechniquePage.verifyHeaderText(header);
    }

    @And("^User selects Technique on Technique Page$")
    public void userSelectTechniqueOnTechniquePage(String techniquename) throws Throwable {
        obj().TechniquePage.selectTechniqueRadioButton(techniquename);
    }

    @And("^User selects \"([^\"]*)\" Technique Radio Button on Technique Page$")
    public void userSelectTechniqueRadioButtonOnTechniquePage(String techniquename) throws Throwable {
        obj().TechniquePage.selectTechniqueRadioButton(techniquename);
    }

    @And("^User clicks Savedraft button in Technique page$")
    public void userClicksSavedraftButtonInTechniquePage() throws Throwable {
        obj().TechniquePage.clickSaveDraftButtonTechnique();
    }


    @And("^User selects \"([^\"]*)\" in Cpt Code dropdown in Technique Page$")
    public void userSelectsCptCodeDropdownInTechniquePage(String cptcode) throws Throwable {
        obj().TechniquePage.selectCptcodeTechnique(cptcode);
    }

}