package atdd.test.stepdefinitions.authorization.physicalHealth;

import atdd.common.ScenarioLogger;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.stepsets.Login;
import atdd.utils.TestUtils;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.DataTable;

public class FOMsStepDefinition {

    public static final Logger log = Logger.getLogger(FOMsStepDefinition.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);

    }

    @And("^user clicks back button on FOM's page$")
    public void UserClicksBackButtonOnFOMSPage() throws Throwable {
        obj().FOMsPage.clickBackButton();
    }

    @And("^user adds an assessment with \"([^\"]*)\"$")
    public void UserAddsAnAssessmentWith(String assesement) throws Throwable {
        obj().FOMsPage.selectAssessment(assesement);

    }

    @And("^user skips the SBST assessment$")
    public void UserAddsAnSBSTAssessment() throws Throwable{
        obj().FOMsPage.expandandskipSBSTAssessment();
    }

    @And("^user Skip SBST assessment$")
    public void UserSkipSBSTassessment() throws Throwable{
        obj().FOMsPage.skipSBSTAssessment();
    }

    @And("^user adds a supplementary assessment$")
    public void UserAddsASupplementaryAssessment() throws Throwable{
        obj().FOMsPage.addASupplementaryAssessment();

    }

    @And("^user clicks on Remove Assessment$")
    public void UserClicksOnRemoveAssessment() throws Throwable{
        obj().FOMsPage.RemoveAssessment();
    }

    @And("^user verifies the assessment tile appears$")
    public void UserVerifiesTheAssessmentTileAppears() throws Throwable{
        obj().FOMsPage.verifybackAssessmentDisplays();
    }



    @And("^user should verify dropdown options on Patient Ability to complete form dropdown$")
    public void UserShouldVerifyPatientAbilityDropdownOptions(DataTable dropDownValues) throws Throwable {
        obj().FOMsPage.ValidatePatientAbilityToCompleteFormDropdownOptions(dropDownValues);
    }

    @And("^user should verify dropdown options on Enter the Score dropdown in SBST form$")
    public void UserShouldVerifySBSTEnterScoreDropdownOptions(DataTable dropDownValues) throws Throwable {
        obj().FOMsPage.ValidateSBSTFormEnterTheScoreDropdownOptions(dropDownValues);
    }

    @And("^user should verify dropdown options on Add an Assessment dropdown$")
    public void UserShouldVerifyAddAnAssessmentDropdownOptions(DataTable dropDownValues) throws Throwable {
        obj().FOMsPage.ValidateAddanAssessmentDropdownOptions(dropDownValues);
    }

    @And("^user should verify SBST Start Assessment Questions$")
    public void UserShouldVerifySBSTStartAssessmentQuestions(DataTable sbstQ) throws Throwable {
        obj().FOMsPage.ValidateSBSTFormStartAssessmentQuestions(sbstQ);
    }

    @And("^user should verify BACK Index Start Assessment Questions$")
    public void UserShouldVerifyBACKIndexStartAssessmentQuestions(DataTable backQ) throws Throwable {
        obj().FOMsPage.ValidateBACKIndexStartAssessmentQuestions(backQ);
    }

    @And("^user should verify NECK Index Start Assessment Questions$")
    public void UserShouldVerifyNECKIndexStartAssessmentQuestions(DataTable neckQ) throws Throwable {
        obj().FOMsPage.ValidateNeckIndexStartAssessmentQuestions(neckQ);
    }

    @And("^user should verify DASH Start Assessment Questions$")
    public void UserShouldVerifyDASHStartAssessmentQuestions(DataTable dashQ) throws Throwable {
        obj().FOMsPage.ValidateDashStartAssessmentQuestions(dashQ);
    }
    @And("^user should verify LEFS Start Assessment Questions$")
    public void UserShouldVerifyLEFSStartAssessmentQuestions(DataTable lefsQ) throws Throwable {
        obj().FOMsPage.ValidateLEFSStartAssessmentQuestions(lefsQ);
    }

    @And("^user verify Assessment score is displayed on assessment tile$")
    public void VerifyAssessmentScoreOnAssessmentTile() throws Throwable{
        obj().FOMsPage.ValidateScoreOnTile();
    }

    @And("^user verify expected \"([^\"]*)\" is displayed as \"([^\"]*)\"$")
    public void VerifyExpectedAssessmentScoreIsDisplayedAs(String assessment, String expectedScore) throws Throwable{
        obj().FOMsPage.GetScoreOnTile(assessment, expectedScore);
    }

    @And("^user verify Add an assessment dropdown is hidden for status incomplete$")
    public void VerifyAddanAssessmenisHidden() throws Throwable {
        obj().FOMsPage.ValidateAddanAssessmentHidden();
    }

    @And("^user verify Remove Assessment link is displayed for status incomplete$")
    public void VerifyRemoveAssessmentisDisplayedforStatusIncomplete() throws Throwable {
        obj().FOMsPage.ValidateRemoveAssessmentisDisplayedforIncompleteStatus();
    }

    @And("^Verify Add an assessment is displayed$")
    public void VerifyAddanAssessmentisDisplayed() throws Throwable {
        obj().FOMsPage.ValidateAddanAssessmentIsDisplayed();
    }

    @And("^verify only one accordion can be opened$")
    public void VerifyOnlyOneAccordionIsOpened() throws Throwable {
        obj().FOMsPage.OnlyOneAccordianIsOpen();
    }
    @And("^user Opens \"([^\"]*)\" Accordian$")
    public void OneAccordion(String FormName) throws Throwable {
        obj().FOMsPage.OpenAccordian(FormName);
    }

    @And("^user complete an assessment with success message$")
    public void CompleteAssessmentWithSuccessMessage() throws Throwable {
        obj().FOMsPage.skipSBSTAssessment();
        obj().FOMsPage.successPopUpDisplayed();
    }

    @And("^user verify success message is displayed$")
    public void UserVerifySuccessMessageIsDisplayed() throws Throwable {
        obj().FOMsPage.successPopUpDisplayed();
    }

    @And("^verify the \"([^\"]*)\" Accordion is closed$")
    public void verifyAccordionClosed(String FormName) throws Throwable {
        obj().FOMsPage.verifyAccordionClosed(FormName);

    }

    @And("^verify that user is not displayed with previously added assessments$")
    public void verifyUserNotDisplayedWithPreviouslyAddedAssessments_as() throws Throwable {
        obj().FOMsPage.HidePreviouslyAddedAssessments();
    }

    @And("^verify that user can edit assessments multiple times$")
    public void VerifyUserEditAssessmentsMultipleTimes() throws Throwable {
        obj().FOMsPage.EditAssessmentsMultipleTimes();
    }

    @And("^verify Select existing form dropdown options on Other form$")
    public void VerifySelectExistingFormDropdownOptionsOnOtherForm(DataTable dropDownValues) throws Throwable {
        obj().FOMsPage.ValidateSelectExistingFormDropdownOptions(dropDownValues);

    }

    @And("^user selects Other:Other assessment$")
    public void UserSelectsOtherOtherAssessment() throws Throwable {
        obj().FOMsPage.skipSBSTAssessment();
        obj().FOMsPage.selectsOtherOtherassessment();
    }

    @And("^user verify Other assessment fields are displayed$")
    public void VerifyFollowingFieldsDisplayedOnOtherAssessment() throws Throwable {
        obj().FOMsPage.OtherassessmentFields();
    }

    @And("^user verify SBST form is required and can not be removed$")
    public void VerifySBSTFormIsRequiredAndCanNotBeRemoved() throws Throwable {
        obj().FOMsPage.RequiredSbstFormAndNotRemoved();
    }

    @And("^user complete SBST form$")
    public void UserCompleteSBSTForm() throws Throwable {
        obj().FOMsPage.skipSBSTAssessment();
    }

    @And("^user Adds \"([^\"]*)\" Option assessment$")
    public void AddOptionalAssesment(String FormName) throws Throwable {
        obj().FOMsPage.AddOptionalAssesment(FormName);
    }

    @And("^user clicks on Continue button$")
    public void UserClicksContinueButton() throws Throwable  {
        obj().FOMsPage.clickContinueButton();
    }

    @And("^user clicks on Save Assessment button$")
    public void UserClicksSaveAssessmentButton() throws Throwable  {
        obj().FOMsPage.clickSaveAssessment();
    }

    @And("^verify error message \"([^\"]*)\" is displayed$")
    public void VerifyErrorMessageIsDisplayed(String expectedError) throws Throwable  {
        obj().FOMsPage.VerifyErrorMessageIsDisplayed(expectedError);
    }

    @And("^verify user can enter score Manually as \"([^\"]*)\" in Optional Forms$")
    public void VerifyUserCanEnterScoreManuallyInOptionalForms(String OptionalManualScore) throws Throwable  {
        obj().FOMsPage.EnterManualScoreInOptionalForms(OptionalManualScore);
    }

    @And("^verify user can enter score Manually as \"([^\"]*)\" in Other Forms$")
    public void VerifyUserCanEnterScoreManuallyInOtherForms(String OtherScore) throws Throwable  {
        obj().FOMsPage.EnterManualScoreInOtherForms(OtherScore);
    }

    @And("^user Adds Other assessment as \"([^\"]*)\" from the dropdown list$")
    public void UserAddsOtherAssessmentFromDropdownList(String ExistingForm) throws Throwable  {
        obj().FOMsPage.AddsOtherAssessmentFromDropdownList(ExistingForm);
    }

    @And("^Clear Select existing form dropdown$")
    public void ClearSelectExistingFormDropdown() throws Throwable  {
        obj().FOMsPage.ClearSelectExistingFormDropdownValue();
    }


}