package atdd.test.stepdefinitions.authorization.physicalHealth;

import atdd.common.MapsComparer;
import atdd.common.ScenarioLogger;
import atdd.dao.mbm.HscDao;
import atdd.dao.mbm.HscPhQuestDao;
import atdd.dao.mbm.MyBatisConnectionFactory;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.stepsets.Login;
import atdd.utils.*;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import cucumber.api.Scenario;
import cucumber.api.java.Before;

import java.util.List;
import java.util.Map;

public class PatientQuestionsStepDefinition {

    public static final Logger log = Logger.getLogger(PatientQuestionsStepDefinition.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);

    }



    @And("^user verifies questionnaire check box is checked for under (\\d+) by default$")
    public void userVerifiesQuestionnaireCheckBoxIsCheckedForUnder(int age) throws Throwable {
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        obj().PatientQuestionsPage.verifyQuestionarieCheckbox(age, pf);
    }

    @And("^user verifies questionnaire check box is unchecked for over (\\d+) by default$")
    public void userVerifiesQuestionnaireCheckBoxIsUncheckedForOver(int age) throws Throwable {
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        obj().PatientQuestionsPage.verifyQuestionarieCheckbox(age,pf);
    }

    @And("^user verifies All Fields Required label is hidden$")
    public void userVerifiesAllFieldsRequiredLabelIsHidden() throws Throwable {
        obj().PatientQuestionsPage.verifyAllFieldsRequiredHidden();
    }

    @And("^user clicks continue button on patient questions page$")
    public void userClicksContinueButtonOnPatientQuestionsPage() throws Throwable {
        obj().PatientQuestionsPage.clickContinueButton();
    }

    @And("^user fills patient questions partially$")
    public void userFillsPatientQuestionsPartially() throws Throwable {
        String dateOfBirth = TestUtils.text(driver(),obj().PatientQuestionsPage.dob);
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
            obj().PatientQuestionsPage.clickCompletingQuestionnaireCheckbox();
            obj().PatientQuestionsPage.selectDropDownValueInHowOftenDoYouFeelYourSymptoms(pf.get(MBM.PQ_HOW_OFTEN_DO_YOU_FEEL_YOUR_SYMPTOMS));
            obj().PatientQuestionsPage.selectDropDownValueInHowMuchHaveYourSymptomsInterferedWithYourDailyActivities(pf.
                    get(MBM.PQ_HOW_MUCH_HAVE_YOUR_SYMPTOMS_INTERFERED_WITH_YOUR_DAILY_ACTIVITIES));
            obj().PatientQuestionsPage.selectDropDownValueInHowIsYourConditionChanging(pf.get(MBM.PQ_HOW_IS_YOUR_CONDITION_CHANGING_SINCE_CARE_AT_THIS_FACILITY));
            obj().PatientQuestionsPage.selectDropDownValueInOverallHealthRightNow(pf.get(MBM.PQ_IN_GENERAL_WOULD_YOU_SAY_YOUR_OVERALL_HEALTH_RIGHT_NOW_IS));
            obj().PatientQuestionsPage.enterdatePatientCompletedQuestions(pf.get(MBM.PQ_DATE_PATIENT_COMPLETED_QUESTIONS));


    }

    @Then("^user verifies against db$")
    public void userVerifiesAgainstDb() throws Throwable {
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        long hscId = TestUtils.getHscIdFromURL(driver().getCurrentUrl());
        List<Map<String, Object>> list = new HscPhQuestDao(MyBatisConnectionFactory.getSqlSessionFactory()).getPQ(hscId);
        obj().PatientQuestionsPage.verifiesAgainstDb(list,pf);

    }


    @And("^user clicks questionnaire check box$")
    public void userClicksQuestionnaireCheckBox() throws Throwable {
        obj().PatientQuestionsPage.clickCompletingQuestionnaireCheckbox();
    }


    @And("^user verifies All Fields Required label is visible$")
    public void userVerifiesAllFieldsRequiredLabelIsVisible() throws Throwable {
        obj().PatientQuestionsPage.verifyAllFieldsRequiredVisible();
    }


    @And("^user clicks save draft button$")
    public void userClicksSaveDraftButton() throws Throwable {
        obj().PatientQuestionsPage.clickSaveDraft();
    }

    @And("^user clicks back button on PQ page$")
    public void userClicksBackButtonOnPQPage() throws Throwable {
        obj().PatientQuestionsPage.clickBackButton();
    }

    @And("^user verifies all fields are same as existing$")
    public void userVerifiesAllFieldsAreSameAsExisting() throws Throwable {
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        obj().PatientQuestionsPage.verifiesAllFieldsAreSameAsExisting(pf);
    }
}