package atdd.test.stepdefinitions.authorization.physicalHealth;

import atdd.common.ScenarioLogger;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.stepsets.Login;
import atdd.utils.ExcelLib;
import atdd.utils.MBM;
import atdd.utils.TestUtils;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import cucumber.api.Scenario;
import cucumber.api.java.Before;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class RequestDetailsStepDefinitionPH {

    public static final Logger log = Logger.getLogger(RequestDetailsStepDefinitionPH.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);

    }

    private ArrayList<String> formatListByUser(List<String> listOfFields, Map<String,String> pf){
        ArrayList<String> allFields = new ArrayList<>(listOfFields);
        if(((pf.get(MBM.USER_TITLE).contains("PAAN")))){
            log.warn("Image Number and Date Received fields dont exist for PAAN User");
            allFields.remove(0);
            allFields.remove(0);
        }
        return allFields;
    }

    @Then("^user checks list of DX Codes in Primary Diagnosis Code feild in Request Detail page$")
    public void user_checks_list_of_DX_Codes_in_Primary_Diagnosis_Code_feild_in_Request_Detail_page(List<String> listOfICDCodes) throws Throwable {

        log.warn("Cheking size of listOfICDCodes "+listOfICDCodes+" equals to 11");
        obj().RequestDetailsPagePH.validateIcdCodeAndGetText(listOfICDCodes);
    }

    @And("^user  enters a Date you want submission to begin on calendar \"([^\"]*)\" lesser from the date in which the authorization is being created$")
    public void user_enters_a_Date_you_want_submission_to_begin_on_calendar_lesser_from_the_date_in_which_the_authorization_is_being_created(String date) throws Throwable {
        if(date.isEmpty()){
            Random rand = new Random();
            date = String.valueOf(rand.nextInt((120-74)) + 74);
        }
        log.warn("User Enters date which is lesser for "+date+" days from current/todays date ");
        obj().RequestDetailsPagePH.enterLaterDaysFromToday(date);

    }

    @Then("^user verifies \"([^\"]*)\" filed is there$")
    public void user_verifies_filed_is_there(String fieldName) throws Throwable {


        Assert.assertTrue("Validation for field on Request Details page that "+fieldName+" is there",TestUtils.text(driver(), obj().RequestDetailsPagePH.ReasonForLateSubmissionText).contains(fieldName));

    }

    @And("^user enteres same \"([^\"]*)\" to first and secondary provider credentil fields$")
    public void user_enteres_same_to_first_and_secondary_provider_credentil_fields(String credential) throws Throwable {
        log.warn("Selecting the same "+credential+" for the first and second provider credentials");
        obj().RequestDetailsPagePH.selectDropDownValueInPrimaryProviderCredential(credential);
        obj().RequestDetailsPagePH.selectDropDownValueInSecondaryProviderCredentil(credential);
    }


    @Then("^user validate for getting \"([^\"]*)\" popup message$")
    public void user_validate_for_getting_popup_message(String errorPopUp) throws Throwable {

        log.warn("");
        String errorMessage = TestUtils.text(driver(),obj().RequestDetailsPagePH.errorPopUpForDuplProviderCredentials);
        Assert.assertEquals(errorPopUp, errorMessage);

    }

    @And("^user enteres same \"([^\"]*)\" to primary and additional Diagnosis code fields and clicks continue btn$")
    public void user_enteres_same_to_primary_and_additional_Diagnosis_code_fields_and_clicks_continue_btn(String code) throws Throwable {

        log.warn("");
        obj().RequestDetailsPagePH.enterPrimaryIcdCodeAndClickAddCode(code);
        obj().RequestDetailsPagePH.enterAdditionalDiagCodeAndClickAddCode(code);
//        obj().RequestDetailsPage.clickContinueButton();
    }

    @Then("^user validate for getting \"([^\"]*)\" popup message for duplication$")
    public void user_validate_for_getting_popup_message_for_duplication(String popUpMessage) throws Throwable {

        log.warn("");
        Assert.assertTrue("Validation for field on Request Details page that "+popUpMessage+" is there",TestUtils.text(driver(), obj().RequestDetailsPagePH.popUpForPrimAndAdditionalDiagCode).contains(popUpMessage));
    }
    @Then("^user verifies list of fields on Request Details Page$")
    public void user_verifies_list_of_fields_on_Request_Details_Page(List<String> listOfFields) throws Throwable {
        log.warn("Validating all Labels on Request Details Page");
        TestUtils.wait(5);
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        obj().RequestDetailsPagePH.validateAllVisibleLabels(formatListByUser(listOfFields,pf));
    }

    @Given("^user clicks on continue button on the Request Details Page$")
    public void user_clicks_on_continue_button_on_the_Request_Details_Page() throws Throwable {
       log.warn("User clicks on continue button on Request Details Page");
       obj().RequestDetailsPagePH.clickContinueButton();
       TestUtils.waitForNotBusy(driver());
    }

    @Then("^user clicks on back button on Patient Questions page$")
    public void user_clicks_on_back_button_on_patient_Questions_Page() throws Throwable {
        log.warn("User Clicks Back Button on Patient Question Page");
        TestUtils.wait(10);
        obj().PatientQuestionsPage.clickBackButton();
    }

    @Then("^user should return to the Request Details Page with the Therapy Type questions and responses selected prior to clicking the Continue Button$")
    public void user_should_return_to_the_Request_Details_Page_with_the_Therapy_Type_questions_and_responses_selected_prior_to_clicking_the_Continue_Button(List<String> listOfFields) throws Throwable {
        log.warn("Checking all input values ");
        TestUtils.wait(5);
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        obj().RequestDetailsPagePH.validateAllEnteredValues(formatListByUser(listOfFields,pf),pf);
    }

    @And("^user clicks on Save Draft button$")
    public void user_clicks_on_Save_Draft_button() throws Throwable {

        log.warn("User clicks on Save Draft Button");
        obj().RequestDetailsPagePH.clickSaveDraftButton();

    }

    @Then("^the responses should save to Database$")
    public void the_responses_should_save_to_Database(List<String> listOfFields) throws Throwable {
        //Database validation
        log.warn("User validates HSC Atr values on save draft");
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        obj().RequestDetailsPagePH.validateHSCAtrData(formatListByUser(listOfFields,pf),pf);
    }

    @And("^user should remain on the same page$")
    public void user_should_remain_on_the_same_page() throws Throwable {
        log.warn("User should be  on the Request Details Page");
        Assert.assertTrue(obj().RequestDetailsPagePH.requestDetailsPHPageIsDisplayed());
    }

    @And("^user inputs \"([^\"]*)\" numbers to Image Number field to get \"([^\"]*)\" field validation$")
    public void user_inputs_numbers_to_Image_Number_field_to_get_field_validation(String numbers, String errorMessage) throws Throwable {
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        log.warn("Expecting to get image number field validation message");
        obj().RequestDetailsPagePH.enterImageNumber(numbers,pf);
        Assert.assertTrue("ImageNumber Field Validation message is't there",TestUtils.text(driver(),obj().RequestDetailsPagePH.imageNumberFieldValidationMessage).contains(errorMessage));
    }

    @And("^user inputs future date (\\d+) to Date Received field to get \"([^\"]*)\" field validation$")
    public void user_inputs_future_date_to_Date_Received_field_to_get_field_validation(int date, String errorMessage) throws Throwable {
        log.warn("User inputs and gets " +errorMessage);
        obj().RequestDetailsPagePH.enterDateReceived(TestUtils.getFutureDate(date));
        TestUtils.safeClick(driver(),obj().RequestDetailsPagePH.clickAnywhereInWebPage);
        Assert.assertTrue("Field Validation message is't there",TestUtils.text(driver(),obj().RequestDetailsPagePH.dateReceivedValidationMessage).contains(errorMessage));
    }


    @And("^user inputs (\\d+) to Date Submission field to get \"([^\"]*)\" field validation$")
    public void user_inputs_to_Date_Submission_field_to_get_field_validation(int date, String errorMessage) throws Throwable {
        log.warn("");
        obj().RequestDetailsPagePH.enterTextInDateYouWantTheTreatmentToStart(TestUtils.getFutureDate(date));
        TestUtils.click(driver(),obj().RequestDetailsPagePH.clickAnywhereInWebPage);
        Assert.assertTrue("Field Validation message is't there",TestUtils.text(driver(),obj().RequestDetailsPagePH.getDateYouWantThisTreatmentToBeginMessage).contains(errorMessage));

    }

    @And("^user updates Primary Cause of Current Episode dropdown to \"([^\"]*)\"$")
    public void user_updates_Primary_Cause_of_Current_Episode_dropdown_to(String postSurgical) throws Throwable {
        log.warn("");
        obj().RequestDetailsPagePH.selectDropDownValueInPrimaryCauseOfCurrentEpisode(postSurgical);
    }

    @And("^user inputs future date (\\d+) to Surgery Date field to get \"([^\"]*)\" field validation$")
    public void user_inputs_future_date_to_Surgery_Date_field_to_get_field_validation(int date, String errorMessage) throws Throwable {

        log.warn("");
        obj().RequestDetailsPagePH.enteringSurgeryDate(TestUtils.getFutureDate(date));
        TestUtils.click(driver(),obj().RequestDetailsPagePH.clickAnywhereInWebPage);
        Assert.assertTrue("Field Validation message is't there",TestUtils.text(driver(),obj().RequestDetailsPagePH.surgeryDateFieldValMessage).contains(errorMessage));

    }
    @Then("^user should validate \"([^\"]*)\" pop-up message for duplication$")
    public void user_should_validate_pop_up_message_for_duplication(String duplErrorPopUp) throws Throwable {

        log.warn("USer should get "+duplErrorPopUp+" pop-up error message for Duplication for already been submitted Authorization");
        String actualErrorPopUp = TestUtils.text(driver(),obj().RequestDetailsPagePH.getErrorPopUpForDuplication);
        Assert.assertTrue("Doesnt get pup-up for Duplicate Authorization", actualErrorPopUp.contains(duplErrorPopUp));
    }

    @Then("^user should see the Pop up/Validation message for duplicate$")
    public void userShouldSeeThePopUpValidationMessageForDuplicate() {

        log.warn("User should get Existing Authorization pop-up error message for Duplication");
       // Assert.assertTrue("Doesnt get pup-up for Duplicate Authorization", obj().RequestDetailsPagePH.);
    }

    @And("^user selects the Date Received greater than (\\d+) business days from the date that the authorization is being created$")
    public void userSelectsTheDateReceivedGreaterThanDaysFromTheDateThatTheAuthorizationIsBeingCreated(int num) throws Throwable {

        log.warn("User inputs 3 business days earlier date into Date Received ");
        obj().RequestDetailsPagePH.enterDateReceived(TestUtils.getBusinessDaysEarlierFromToday(num));
       }


    @And("^User selects a Date you want this submission to begin (\\d+) calendar days earlier than the Date Received$")
    public void userSelectsADateYouWantThisSubmissionToBeginCalendarEarlierThanTheDateReceived(int numOfDays) throws  Throwable {

        obj().RequestDetailsPagePH.enterTextInDateYouWantTheTreatmentToStart(TestUtils.getPastDateFromGivenDate(TestUtils.getBusinessDaysEarlierFromToday(3),  numOfDays+1));

    }



    @Then("^user should see  \"([^\"]*)\" drop-down field$")
    public void userShouldSeeDropDownField(String  fieldName) throws Throwable {
        log.warn("User should see "+ fieldName + " drop down field ");
        obj().RequestDetailsPagePH.validateVisibleLabel(fieldName);
    }


    @And("^user selects \"([^\"]*)\" option for Primary cause of current episode$")
    public void userSelectsOptionForPrimaryCauseOfCurrentEpisode(String  option) throws Throwable {
        log.warn("User selects the "+ option + " drop down field ");
     obj().RequestDetailsPagePH.selectDropDownValueInPrimaryCauseOfCurrentEpisode(option);
    }

    @And("^user selects \"([^\"]*)\" option for  Secondary cause of current episode$")
    public void userSelectsOptionForSecondaryCauseOfCurrentEpisode(String  option) throws Throwable {
        log.warn("User selects the "+ option + " drop down field ");
      obj().RequestDetailsPagePH.selectDropDownValueInSecondaryCauseOfCurrentEpisode(option);
    }

    @And("^user selects \"([^\"]*)\" option for Type of surgery$")
    public void userSelectsOptionForTypeOfSurgery(String  option) throws Throwable {
        log.warn("User selects the "+ option + " drop down field ");
      obj().RequestDetailsPagePH.selectDropDownValueInTypeOfSurgery(option);
    }

    @And("^user selects a Date you want treatment to start date earlier than (\\d+) calendar days from the date the authorization is being created$")
    public void userSelectsADateYouWantTreatmentToStartDateEarlierThanCalendarDaysFromTheDateTheAuthorizationIsBeingCreated(int  num)  throws Throwable{

        obj().RequestDetailsPagePH.enterTextInDateYouWantTheTreatmentToStart(TestUtils.getPastDateFromGivenDate(TestUtils.getTodayDate(),  num + 1));
    }

    @Then("^user should see a conditional fields for \"([^\"]*)\"$")
    public void userShouldSeeAConditionalFieldsFor(String  fieldName) throws Throwable {
        obj().RequestDetailsPagePH.verifyConditionalFields(fieldName);
    }

    @And("^user selects \"([^\"]*)\" option from Timely Filing Reason drop down$")
    public void userSelectsOptionFromTimelyFilingReasonDropDown(String option) throws Throwable {
        log.warn("user selects timely filing Reason option");
       obj().RequestDetailsPagePH.selectDropDownValueInTimelyFilingReason(option);
    }

    @And("^user selects other than \"([^\"]*)\" for Patient Type$")
    public void userSelectsOtherThanForPatientType(String arg0) throws Throwable {
        log.warn("user enters other than " +arg0 + " for Patient Type");
        obj().RequestDetailsPagePH.selecPatientTypedDropDown(arg0);
    }

    @Then("^user verifies popup displayed with \"([^\"]*)\" $")
    public void userVerifiesPopupDisplayedWith(String  msg) throws Throwable {
        Assert.assertTrue("Validation for field on Request Details page that "+ msg+" is there",TestUtils.text(driver(),
                obj().RequestDetailsPagePH.getImageNumberPopUp).contains(msg));
    }

    @And("^user inputs \"([^\"]*)\" number to Image Number field$")
    public void userInputsNumbersToImageNumberField(String  num) throws Throwable {
        log.warn("user enters Image number");
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        obj().RequestDetailsPagePH.enterImageNumber(num, pf);
    }

    @And("^user selects Late submission Note as \"([^\"]*)\"$")
    public void selectLateSubmissionNote(String note) throws Throwable{
        log.warn("user selects late submission note as: "+note);
        obj().RequestDetailsPagePH.lateSubmissionNote(note);
    }

    @And("^user clicks on \"([^\"]*)\" button on Dupe Check Pop Up$")
    public void userClicksOnButtonOnDupeCheckPopUp(String arg0) throws Throwable {
        log.warn("Action on Dupe Check pop up");

    }

    @And("^user should remain on the \"([^\"]*)\" page$")
    public void userShouldRemainOnTheSamePage(String header) throws Throwable {
        log.warn("User should be  on the Request Details Page");
        TestUtils.wait(2);
        boolean present = obj().CommonPage.verifyHeader(header);
        Assert.assertTrue("Header " + header + " does not exists", present);
    }


    @And("^user adds more than (\\d+) additional diagnosis code$")
    public void userAddsMoreThanAdditionalDiagnosisCode(int arg0) throws Throwable {
        log.warn("User enters additional diagnosis code more than 9");
        obj().RequestDetailsPagePH.enterAdditionalDiagcodes(arg0);
    }

    @Then("^user should see popup displayed with \"([^\"]*)\" $")
    public void userShouldSeePopupDisplayedWith(String  msg) throws Throwable {
        Assert.assertTrue("Validation for field on Request Details page that "+ msg+" is there", obj().RequestDetailsPagePH.validateICDPopUPText(msg));
    }

    @And("^user inputs more than (\\d+)  to Scheduled Frequency visits to get \"([^\"]*)\"$")
    public void userInputsMoreThanToScheduledFrequencyVisitsToGet(String days, String msg) throws Throwable {
        log.warn("users inputs into Scheduled Frequency Visits");
        obj().RequestDetailsPagePH.enterScheduledNumberOfVisits(days);
        Assert.assertTrue("Field Validation message is't there",TestUtils.text(driver(),obj().RequestDetailsPagePH.numberOfVisitsErrorMessage).contains(msg));

    }

    @And("^user inputs future date to Date of Initial Evaluation field to get \"([^\"]*)\"$")
    public void userInputsFutureDateToDateOfInitialEvaluationFieldToGet(String  msg) throws Throwable {
        log.warn("");
        obj().RequestDetailsPagePH.enterDateOfInitialEvaluation(TestUtils.getTomorrowDateMMddyyyy());
        TestUtils.click(driver(),obj().RequestDetailsPagePH.clickAnywhereInWebPage);
        Assert.assertTrue("Field Validation message is't there",TestUtils.text(driver(),obj().RequestDetailsPagePH.dateOfInitialEvalErrorMsg).contains(msg));
    }
    @And("^user clicks on Continue button on Dupe Check Pop Up$")
    public void userClicksOnContinueButtonOnDupeCheckPopUp() throws Throwable {
        log.warn("Action on Dupe Check pop up");
        obj().RequestDetailsPagePH.clickContinueOnDupeCheckPopUp();
    }

    @Then("^user verifies Dupe Check popup displayed with Duplicate Authorization Number$")
    public void userVerifiesDupeCheckPopUp() throws Throwable {
        log.warn("Validation on Dupe Check pop up");
        obj().RequestDetailsPagePH.validateDupeCheckPopUPText();
    }

    @And("^User continues if the authorization is duplicate$")
    public void userContinuesIfAuthIsDuplicate() throws Throwable {
        log.warn("Action on Dupe Check pop up");
       obj().RequestDetailsPagePH.continueEvenIfItsDuplicate();
    }

    @And("^user adds \"([^\"]*)\" to Additional Diagnosis code$")
    public void userAddsToAdditionalDiagnosisCode(String arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        log.warn("User enters additional diagnosis code");
        obj().RequestDetailsPagePH.enterAdditionalDiagCodeAndClickAddCode(arg0);
    }

    @When("^user tries to add the same \"([^\"]*)\" to Additional Diagnosis code$")
    public void userTriesToAddTheSameToAdditionalDiagnosisCode(String arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        log.warn("User enters additional diagnosis code");
        obj().RequestDetailsPagePH.enterAdditionalDiagCodeAndClickAddCode(arg0);
    }

    @And("^user selects \"([^\"]*)\" option for Secondary Type of surgery$")
    public void userSelectsOptionForSecondaryTypeOfSurgery(String  option) throws Throwable {
        log.warn("User selects the "+ option + " drop down field ");
        obj().RequestDetailsPagePH.selectDropDownValueInSecondaryTypeOfSurgery(option);
    }

    @Then("^user should see a secondary conditional fields for \"([^\"]*)\"$")
    public void userShouldSeeASecondaryConditionalFieldsFor(String  fieldName) throws Throwable {
        obj().RequestDetailsPagePH.verifyConditionalFields(fieldName);
    }

    @Then("^user should see a secondary surgery conditional fields$")
    public void userShouldSeeASecondarySurgeryConditionalFields() throws Throwable{

        obj().RequestDetailsPagePH.verifySecondaryConditionalFields();
    }

    @And("^user clicks continue button on Request Details PH$")
    public void userClicksContinueButtonOnRequestDetailsPH()throws Throwable {
        obj().RequestDetailsPagePH.clickContinueButton();

    }

    @And("^User navigates to request details Screen successfully$")
    public void userNavigatesToRequestDetailsScreenSuccessfully() throws Throwable {
        obj().RequestDetailsPagePH.requestDetailsPHPageIsDisplayed();
    }
}