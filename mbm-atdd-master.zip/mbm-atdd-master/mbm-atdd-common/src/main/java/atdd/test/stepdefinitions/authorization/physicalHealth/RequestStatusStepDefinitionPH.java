package atdd.test.stepdefinitions.authorization.physicalHealth;

import atdd.common.ScenarioLogger;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.stepsets.Login;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

public class RequestStatusStepDefinitionPH {

    public static final Logger log = Logger.getLogger(RequestStatusStepDefinitionPH.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }

    @Then("^user verifies \"([^\"]*)\" status for authorization on Request Status page$")
    public void user_verifies_status_for_authorization_on_Request_Status_page(String status) throws Throwable {
        log.warn("User validates Authorization Status");
        obj().RequestStatusPagePH.verifyAuthorizationRequestStatus(status);
    }

    @Then("^user verifies \"([^\"]*)\" therapy as Authorization on Request Status Page$")
    public void user_verifies_therapy_as_Authorization_on_Request_Status_Page(String therapy) throws Throwable {
        log.warn("User validates Authorization Status");
        obj().RequestStatusPagePH.verifyAuthorizationType(therapy);
    }

    @Then("^user verifies authorization number is displayed on Request Status Page$")
    public void user_verifies_authorization_number_is_displayed_on_Request_Status_Page() throws Throwable {
        log.warn("User validates Authorization Number");
        obj().RequestStatusPagePH.verifyAuthorizationNumber();
    }

    @Then("^user verifies Authorization start date value on Request Status Page$")
    public void user_verifies_Authorization_start_date_value_on_Request_Status_Page() throws Throwable {
        log.warn("User validates Authorization Number");
        obj().RequestStatusPagePH.verifyTAuthorizationStartDate();
    }

    @Then("^user verifies Authorization end date value on Request Status Page that matches Database value$")
    public void user_verifies_Authorization_end_date_value_on_Request_Status_Page_that_matches_Database_value() throws Throwable {
        log.warn("User validates Authorization Number");
        obj().RequestStatusPagePH.verifyTAuthorizationEndDate();
    }

    @Then("^user verifies \"([^\"]*)\" authorization message on Request Status page$")
    public void user_verifies_authorization_message_on_Request_Status_page(String status) throws Throwable {
        log.warn("User validates Authorization Message");
        obj().RequestStatusPagePH.verifyAuthorizationMessage(status);
    }

    @Then("^user verifies Number of visits count is displayed with value matching Database on Request Status Page$")
    public void user_verifies_Number_of_visits_count_is_displayed_with_value_matching_Database_on_Request_Status_Page() throws Throwable {
        log.warn("User validates Number of Visits");
        obj().RequestStatusPagePH.verifyNumberOfVisits();
    }

    @Then("^user verifies Authorization start date value is not Request Status Page$")
    public void user_verifies_Authorization_start_date_value_is_not_Request_Status_Page() throws Throwable {
        log.warn("User validates Start Date not displayed");
        obj().RequestStatusPagePH.verifyStartDateHidden();
    }

    @Then("^user verifies Authorization end date value is not displayed on Request Status Page$")
    public void user_verifies_Authorization_end_date_value_is_not_displayed_on_Request_Status_Page() throws Throwable {
        log.warn("User validates End Date not displayed");
        obj().RequestStatusPagePH.verifyEndDateHidden();
    }

    @Then("^user verifies Number of visits count is not displayed on Request Status Page$")
    public void user_verifies_Number_of_visits_count_is_not_displayed_on_Request_Status_Page() throws Throwable {
        log.warn("User validates Number of Visits not displayed");
        obj().RequestStatusPagePH.verifyNumberOfVisitsHidden();
    }

}
