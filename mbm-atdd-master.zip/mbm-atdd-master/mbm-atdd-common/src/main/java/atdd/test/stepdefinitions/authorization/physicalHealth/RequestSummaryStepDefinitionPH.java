package atdd.test.stepdefinitions.authorization.physicalHealth;

import atdd.common.ScenarioLogger;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.shared.BaseCucumber;
import atdd.test.stepsets.Login;
import atdd.utils.TestUtils;
import cucumber.api.DataTable;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.List;
import java.util.Map;


public class RequestSummaryStepDefinitionPH {
    public static final Logger log = Logger.getLogger(RequestSummaryStepDefinitionPH.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }

    @And("^user submits therapy auth$")
    public void userSubmitsTherapyAuth()throws Throwable {
        obj().RequestSummaryPagePH.clickSubmitButton();
    }

    @And("^user skips to Request Summary Page$")
    public void userSkipsToRequestSummaryPage() throws Throwable{
        obj().PatientQuestionsPage.clickBackButton();
        obj().RequestDetailsPagePH.clickContinueButton();
    }
}