package atdd.test.stepdefinitions.authorization.physicalHealth;

import atdd.common.ScenarioLogger;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.stepsets.Login;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.Then;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

public class UMStepDefinitionPH {

    public static final Logger log = Logger.getLogger(UMStepDefinitionPH.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;
    private String category="";
    private String response ="";

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }

    @Then("^user verifies \"([^\"]*)\" Tab on UM page$")
    public void user_verifies_tab_on_um_page(String tab) throws Throwable {
        log.warn("User validates Authorization Status");
        obj().UMPagePH.verifyUMTabName(tab);
    }

    @Then("^user click \"([^\"]*)\" Tab on UM page$")
    public void user_click_tab_on_um_page(String tab) throws Throwable {
        log.warn("User validates Authorization Status");
        obj().UMPagePH.clickOnUMTabName(tab);
    }


    @Then("^user take denial decision with category \"([^\"]*)\" and response \"([^\"]*)\" on UM page$")
    public void userTakeDenialDecision(String category, String response) throws Throwable {
        this.category= category;
        this.response=response;
        obj().UMPagePH.userTakesDenialDecision(category, response);
    }

    @Then("^user take approved decision with response \"([^\"]*)\" on UM page$")
    public void userTakeApprovedDecision(String response) throws Throwable {
        this.response=response;
        obj().UMPagePH.userTakesApprovedDecision(response);
    }

    @Then("^user validate denial decision on UM page$")
    public void userValidateDenialDecision() throws Throwable {
        obj().UMPagePH.userValidateDenialDecision(category, response);
    }

    @Then("^user validate approval decision on UM page$")
    public void userValidateApprovalDecision() throws Throwable {
        obj().UMPagePH.userValidateApprovalDecision( response);
    }

    @Then("^user validate Summary and Member section on UM page$")
    public void userValidateSummarySection() throws Throwable {
        obj().UMPagePH.validateUMFieldValue("Status", "Pending Review");
        obj().UMPagePH.validateUMFieldValue("Completion Status", "Open");
    }

    @Then("^user validate Note section on UM page$")
    public void userValidateNoteSection() throws Throwable {
        obj().UMPagePH.userEnterRandomNotesAndValidateTheSame();
    }

    @Then("^user validate Provider section on UM page$")
    public void userValidateProviderSection() throws Throwable {
        obj().UMPagePH.userEditProviderDetailsAndValidateTheSame();
    }

    @Then("^user validate Assignment section on UM page$")
    public void userValidateAssignmentSection() throws Throwable {
        user_click_tab_on_um_page("Notes");
        obj().UMPagePH.userEnterRandomNotesAndValidateTheSame();
    }



}
