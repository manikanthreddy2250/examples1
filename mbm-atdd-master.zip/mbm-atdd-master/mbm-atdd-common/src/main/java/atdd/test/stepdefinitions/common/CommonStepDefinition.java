package atdd.test.stepdefinitions.common;


import atdd.common.EvaluateException;
import atdd.common.Retry;
import atdd.common.ScenarioLogger;
import atdd.dao.mbm.HscDao;
import atdd.dao.mbm.MyBatisConnectionFactory;
import atdd.test.stepsets.AuthorizationRequest;
import atdd.test.stepsets.Login;
import atdd.test.stepsets.QueryShared;
import atdd.utils.*;
import com.jayway.restassured.response.Response;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.io.IOException;
import java.time.ZonedDateTime;
import java.util.*;

import static atdd.utils.ExcelLib.THE_MEMBER;


public class CommonStepDefinition {

    public static final Logger log = Logger.getLogger(CommonStepDefinition.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }

    @And("^User waits for \"([^\"]*)\" seconds$")
    public void waitForSec(String ss) throws Throwable {
        ss = WhiteBoard.resolve(owner, ss);
        Integer sec = StringUtils.tryParseIntOrNull(ss);
        Assert.assertNotNull(sec);

        this.scenarioLogger.warn("now=" + WhiteBoard.resolve(owner, "${now}"));
        this.scenarioLogger.warn("User waits for " + sec + " seconds until " + WhiteBoard.resolve(owner, "${now>+" + sec + "s>MM-dd-yyyy h:mm a}") + "...");
        TestUtils.wait(sec);
        this.scenarioLogger.warn("now=" + WhiteBoard.resolve(owner, "${now}"));
    }

    @And("^Delete \"([^\"]*)\" file$")
    public void deleteFile(String path) throws Throwable {
        String userdir = System.getProperty("user.dir");
        path = userdir + path;
        log.warn("Deleting file: " + path);
        TestUtils.deleteFile(path);
    }

    @And("^breakpoint$")
    public void breakpoint() throws Throwable {
        WhiteBoard.getInstance();
    }

    @And("^\"([^\"]*)\" is the offset in hours between \"([^\"]*)\" and \"([^\"]*)\"$")
    public void isTheOffsetInHoursBetweenAnd(String varName, String zoneA, String zoneB) throws Throwable {
        zoneA = WhiteBoard.resolve(owner, zoneA);
        zoneB = WhiteBoard.resolve(owner, zoneB);
        WhiteBoard.getInstance().putString(owner, varName, "" + ZonedDateUtils.offsetInHours(zoneA, zoneB));
    }

    @Then("^user verifies \"([^\"]*)\" is around \"([^\"]*)\"$")
    public void userVerifiesIsAround(String dtStringActual0, String dtStringExpected0) throws Throwable {
        String dtStringActual1 = WhiteBoard.resolve(owner, dtStringActual0);
        String dtStringExpected1 = WhiteBoard.resolve(owner, dtStringExpected0);
        scenarioLogger.warn("Expected: [" + dtStringExpected1 + "]" + (dtStringExpected1.equals(dtStringExpected0) ? "" : " << [" + dtStringExpected0 + "]"));
        scenarioLogger.warn("Actual: [" + dtStringActual1 + "]" + (dtStringActual1.equals(dtStringActual0) ? "" : " << [" + dtStringActual0 + "]"));

        ZonedDateTime dtActual = ZonedDateUtils.parse(dtStringActual1);
        ZonedDateTime dtExpected = ZonedDateUtils.parse(dtStringExpected1);
        long diffInMillis = dtExpected.toInstant().toEpochMilli() - dtActual.toInstant().toEpochMilli();
        scenarioLogger.warn("Diff in millis: " + diffInMillis);

        Assert.assertTrue(diffInMillis >= 0 && diffInMillis <= 60 * 1000);
    }

    @And("^\"([^\"]*)\" is combination of \"([^\"]*)\"$")
    public void isCombinationOf(String resultMapName, String mapNames) throws Throwable {
        Map<String, String> resultMap = new LinkedHashMap<>();
        for (String mapName : mapNames.split(",")) {
            mapName = mapName.trim();
            Map<String, String> map = WhiteBoard.getInstance().getMap(owner, mapName);
            if (null != map) {
                resultMap.putAll(map);
            }
        }
        WhiteBoard.getInstance().putMap(owner, resultMapName, resultMap);
    }

    @Then("^user validates \"([^\"]*)\" matches \"([^\"]*)\" with below exceptional mappings$")
    public void userValidatesMatchesWithBelowExceptionalMappings(String leftMapName, String rightMapName, List<List<String>> exceptionalMappingsList) throws Throwable {
        Map<String, String> exceptionalMappings = new LinkedHashMap<>();
        if (null == exceptionalMappingsList
                || (1 == exceptionalMappingsList.size() && 1 == exceptionalMappingsList.get(0).size())
        ) {
            scenarioLogger.warn("No exceptional mappings");
        } else {
            for (List<String> pair : exceptionalMappingsList) {
                String leftKey = pair.get(0);
                String rightKey = pair.get(1);
                exceptionalMappings.put(leftKey, rightKey);
            }
        }
        scenarioLogger.warn("exceptionalMappings=" + exceptionalMappings);

        leftMapName = WhiteBoard.resolve(owner, leftMapName);
        rightMapName = WhiteBoard.resolve(owner, rightMapName);
        Map<String, String> leftMap = WhiteBoard.getInstance().getMap(owner, leftMapName);
        Map<String, String> rightMap = WhiteBoard.getInstance().getMap(owner, rightMapName);

        Iterator<String> itLeft = leftMap.keySet().iterator();
        while (itLeft.hasNext()) {
            String leftKey = itLeft.next();
            if ("ROW_NUMBER".equals(leftKey)) {
                continue;
            }

            scenarioLogger.warn("\r\n");
            scenarioLogger.warn("leftKey=" + leftKey);

            String expectedRightKey = null;
            if (exceptionalMappings.containsKey(leftKey)) {
                expectedRightKey = exceptionalMappings.get(leftKey);
                if (StringUtils.isEmpty(expectedRightKey)) {
                    expectedRightKey = leftKey;
                }
                if ("MISSING".equals(expectedRightKey)) {
                    scenarioLogger.warn("rightKey=" + expectedRightKey);
                    Assert.assertTrue(!rightMap.containsKey(leftKey));
                    scenarioLogger.warn("OK");
                    continue;
                }
            } else {
                expectedRightKey = leftKey;
            }
            scenarioLogger.warn("expectedRightKey=" + expectedRightKey);
            Assert.assertTrue("Missing key", rightMap.containsKey(expectedRightKey));

            String leftValue = n(leftMap.get(leftKey));
            String rightValue = n(rightMap.get(expectedRightKey));
            scenarioLogger.warn("leftValue=" + leftValue);
            scenarioLogger.warn("rightValue=" + rightValue);
            Assert.assertTrue("Mismatching values", leftValue.equals(rightValue) || leftValue.matches(rightValue));

            scenarioLogger.warn("OK");

        }
    }

    private String n(String s) {
        if (StringUtils.isEmpty(s)) {
            return "";
        }
        s = s.trim();
        s = s.replace("\n", " ");
        s = s.replace("\r", "");
        return s;
    }

    @And("^put \"([^\"]*)\" into map \"([^\"]*)\"$")
    public void putIntoMap(String stringMap, String mapName) throws Throwable {
        Map<String, String> map = WhiteBoard.getInstance().getMap(owner, mapName);
        Map<String, String> update = DataTableUtils.asMap(stringMap);
        map.putAll(update);
    }

    @Then("^user validates \"([^\"]*)\" starts with the keys in below order$")
    public void userValidatesStartsWithTheKeysInBelowOrder(String mapName, List<String> list) throws Throwable {
        mapName = WhiteBoard.resolve(owner, mapName);
        scenarioLogger.warn("mapName=" + mapName);
        scenarioLogger.warn("list=" + list);
        Map<String, String> map = WhiteBoard.getInstance().getMap(owner, mapName);
        scenarioLogger.warn("map=" + map);

        Iterator<String> it = map.keySet().iterator();
        for (int i = 0; i < list.size(); i++) {
            scenarioLogger.warn("i=" + i);
            String expected = list.get(i);
            String actual = it.next();
            Assert.assertEquals(expected, actual);
            scenarioLogger.warn("OK");
        }
    }

    @Then("^user verifies \"([^\"]*)\" \"([^\"]*)\" below keys$")
    public void userVerifiesContainsBelowKeys(String prefix, String constraint, List<String> expectedOptions) throws Throwable {
        if (constraint.equals("contains")) {
            for (String option : expectedOptions) {
                option = WhiteBoard.resolve(owner, option);
                Assert.assertTrue(WhiteBoard.getInstance().containsMap(owner, prefix + "_" + option));
            }
        } else if (constraint.equals("does not contain")) {
            for (String option : expectedOptions) {
                option = WhiteBoard.resolve(owner, option);
                Assert.assertFalse(WhiteBoard.getInstance().containsMap(owner, prefix + "_" + option));
            }
        } else {
            Assert.fail("Constraint not recognized!");
        }
    }

    @And("^hscID \"([^\"]*)\" is extracted from url \"([^\"]*)\"$")
    public void hscidIsExtractedFromUrl(String hscIDName, String url) throws Throwable {
        String hscID = TestUtils.getHscIdFromURL(url) + "";
        WhiteBoard.getInstance().putString(owner, hscIDName, hscID);
        scenarioLogger.warn(hscIDName + "=" + hscID);
    }

    @And("^user verifies \"([^\"]*)\" aganist DB$")
    public void userVerifiesAganistDB(String authNumber) throws Throwable {
        String number = WhiteBoard.resolve(owner, authNumber);
        Map<String, Object> hsc = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectByAuthNumber(number).get(0);
        Assert.assertTrue("db not matches with ui", (number.equals(hsc.get("pri_srvc_ref_nbr")) ||
                number.equals(hsc.get("vend_cse_id"))));

    }

    @Then("^user validates \"([^\"]*)\"$")
    public void userValidates(String conditionExpression) throws Throwable {
        Assert.assertTrue("user validates " + conditionExpression, WhiteBoard.evaluate(owner, conditionExpression));
    }

    @Then("^user validates list \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void userValidatesList(String listName, String verb, String stringList) throws Throwable {
        List<String> valueList = DataTableUtils.asList(WhiteBoard.resolve(owner, stringList));
        userValidatesListBelowValues(listName, verb, valueList);
    }

    @Then("^user validates list \"([^\"]*)\" \"([^\"]*)\" below values$")
    public void userValidatesListBelowValues(String listName, String verb, List<String> expectedList) throws Throwable {
        List<String> list = WhiteBoard.getInstance().getList(owner, listName);
        expectedList = WhiteBoard.resolveStringList(owner, expectedList);
        scenarioLogger.warn("list=" + list.toString());
        scenarioLogger.warn("otherList=" + expectedList.toString());
        switch (verb) {
            case "contains":
                Assert.assertTrue(list.containsAll(expectedList));
                break;
            case "does not contain":
                int size0 = expectedList.size();
                expectedList.removeAll(list);
                int size1 = expectedList.size();
                Assert.assertEquals(size0, size1);
                break;
            default:
                Assert.fail("Unknown verb: " + verb);
        }
        scenarioLogger.warn("OK");
    }

    @Then("^user validates list \"([^\"]*)\" according to below table$")
    public void userValidatesListAccordingToBelowTable(String listName, List<List<String>> table) throws Throwable {
        Map<String, List<String>> listByVerb = new HashMap<>();
        for (List<String> row : table) {
            String verb = row.get(0).trim();
            if (!listByVerb.containsKey(verb)) {
                listByVerb.put(verb, new LinkedList<>());
            }
            listByVerb.get(verb).add(row.get(1));
        }
        for (String verb : listByVerb.keySet()) {
            userValidatesListBelowValues(listName, verb, listByVerb.get(verb));
        }
    }

    /**
     * Implements dynamic sheet IDs for Rules Manager pages, which vary by environments.
     *
     * @param rulesManagerPage The page to set the sheet ID for the current environment.
     */
    @And("^the user sets the Rules Manager endpoints for the page: \"([^\"]*)\"$")
    public void setRulesManagerEndpointValues(String rulesManagerPage) {

        String env = Conf.getInstance().getProperty("envset").split("_")[0];
        switch (rulesManagerPage) {
            case "Expert Rules":
                // Set the Whiteboard values for sheet ID to be used for Rules Manager endpoints
                if (env.equals("int")) WhiteBoard.getInstance().putString(owner, "sheetId", "140");
                else if (env.equals("stage")) WhiteBoard.getInstance().putString(owner, "sheetId", "71");
                break;
            default:
                break;
        }

    }

    /**
     * Use this step to call a named WebService with specified request body and store the response body to WhiteBoard
     * A named service must have below properties:
     * - dev_headers_wf_queue_add=src/main/resources/apiTemplates/template/headers.txt
     * - dev_method_wf_queue_add=post
     * - dev_endpoint_wf_queue_add=${url_work_flow}/mbm/workqueue/v1.0/workQueue
     * <p>
     * "dev" matches the property value for Conf.ENVSET
     * "headers", "method" and "endpoint" are the WebService properties
     * "wf_queue_add" is the name of the WebService to be referenced in your feature file
     *
     * @param wsName
     * @param reqBodyOrFile
     * @param resBodyStringName
     * @throws IOException
     */
    @When("^service \"([^\"]*)\" is called with request \"([^\"]*)\" and response \"([^\"]*)\"$")
    public void serviceIsCalledWithRequestAndResponse(String wsName, String reqBodyOrFile, String resBodyStringName) throws Throwable {
        Retry retry = new Retry("serviceIsCalledWithRequestAndResponse", 60 * 1000, 5 * 1000, 0) {
            @Override
            protected void tryOnce() throws Exception {

                Response res = QuickHttp.http(wsName, reqBodyOrFile, owner);
                if (200 != res.getStatusCode()) {
                    throw new RuntimeException("Error response status: " + res.getStatusCode());
                }

                this.outcomeCompleted = res;
            }
        };
        Assert.assertTrue("Calling service " + wsName + "success.", retry.execute());
        Response res = (Response) retry.getOutcomeCompleted();
        String resBody = res.body().asString();
        log.warn("resBody=" + resBody);
        resBodyStringName = WhiteBoard.resolve(owner, resBodyStringName);
        if (StringUtils.isEmpty(resBodyStringName)) {
            log.warn("No string name specified:" + resBodyStringName);
            // do nothing
        } else {
            WhiteBoard.getInstance().putString(owner, resBodyStringName, resBody);
            scenarioLogger.warn("New string added for " + owner + ": " + resBodyStringName + "=" + resBody);
        }
    }

    /**
     * Use this step to extract information from a source string by a query string
     *
     * @param varName:        WhiteBoard variable name for the extracted value
     * @param sourceString:   a block of free text or a json string or a mybatis connection factory class name
     * @param queryExpression {@Link atdd.common.QueryExpression}
     */
    @And("^\"([^\"]*)\" is extracted from \"([^\"]*)\" with query \"([^\"]*)\"$")
    public void isExtractedFromWithQuery(String varName, String sourceString, String queryExpression) throws Throwable {
        new QueryShared(scenario).isExtractedFromWithQuery(varName, sourceString, queryExpression);
    }

    /**
     * Use this step to extract information from a source string by a query string
     *
     * @param varName:        WhiteBoard variable name for the extracted value
     * @param sourceString:   a block of free text or a json string or a mybatis connection factory class name
     * @param queryExpression {@Link atdd.common.QueryExpression}
     */
    @And("^\"([^\"]*)\" is extracted from \"([^\"]*)\" with query$")
    public void isExtractedFromWithQueryDocString(String varName, String sourceString, String queryExpression) throws Throwable {
        new QueryShared(scenario).isExtractedFromWithQuery(varName, sourceString, queryExpression);
    }

    /**
     * Use this step to extract information from a source string by a query string
     *
     * @param varName:         WhiteBoard variable name for the extracted value
     * @param sourceString:    a block of free text or a json string or a mybatis connection factory class name
     * @param queryExpression: {@Link atdd.common.QueryExpression}
     */
    @And("^\"([^\"]*)\" is extracted from \"([^\"]*)\" with query \"([^\"]*)\" if \"([^\"]*)\"$")
    public void isExtractedFromWithQueryIf(String varName, String sourceString, String queryExpression, String ifExpression) throws Throwable {
        try {
            if (WhiteBoard.evaluate(owner, ifExpression)) {
                isExtractedFromWithQuery(varName, sourceString, queryExpression);
            }
        } catch (EvaluateException e) {
            //do nothing
        }
    }

    @Then("^user validates \"([^\"]*)\" using below queries$")
    public void userValidatesUsingBelowQueries(String sourceString, List<Map<String, String>> maps) throws Throwable {
        sourceString = WhiteBoard.resolve(owner, sourceString);
        try {
            scenarioLogger.warn(QuickJson.prettyJson(sourceString));
        } catch (Exception e) {
            scenarioLogger.warn(sourceString);
        }
        maps = WhiteBoard.resolve(owner, maps);
        String varName = ZonedDateUtils.timestamp();
        QueryShared queryShared = new QueryShared(scenario);
        for (Map<String, String> map : maps) {

            String queryExpression = map.get("queryExpression");
            scenarioLogger.warn("queryExpression=" + queryExpression);

            String expected = map.get("expected");
            scenarioLogger.warn("expected=" + expected);
            WhiteBoard.getInstance().removeMap(owner, varName);
            queryShared.isExtractedFromWithQuery(varName, sourceString, queryExpression);
            String actual = WhiteBoard.getInstance().getString(owner, varName);
            scenarioLogger.warn("actual=" + actual);

            String method = map.get("method");
            if (StringUtils.isEmpty(method)) {
                method = "equals";
            }
            scenarioLogger.warn("method=" + method);
            switch (method) {
                case "matches":
                    Assert.assertTrue(actual.matches(expected));
                    break;
                case "equals":
                    if (expected.matches("-?\\d+(\\.\\d+)?")) {
                        Assert.assertEquals(StringUtils.tryParseDoubleOrZero(expected), StringUtils.tryParseDoubleOrZero(actual));
                    } else {
                        Assert.assertEquals(expected, actual);
                    }
                    break;
                case "notNull":
                    if (org.apache.commons.lang.StringUtils.isBlank(actual)) {
                        Assert.assertFalse(true);
                    } else if (actual.matches("null")) {
                        Assert.assertFalse(true);
                    } else {
                        Assert.assertTrue(true);
                    }
                    break;
                case "contains":
                    // Validate that the actual value contains the expected substrings
                    String[] expectedValues = expected.split(",");
                    for (String expectedValue : expectedValues) {
                        Assert.assertTrue(actual.contains(expectedValue.trim()));
                    }
                    break;
                case "does not contain":
                    // Validate that the actual value does not contain any of the given substrings
                    String[] unexpectedValues = expected.split(",");
                    for (String unexpectedValue : unexpectedValues) {
                        Assert.assertFalse(actual.contains(unexpectedValue.trim()));
                    }
                    break;
                default:
                    Assert.fail("Unknown method:" + method);
            }
        }
    }

    /**
     * Writing message to cucumber report
     *
     * @param message
     */
    @Then("^take note \"([^\"]*)\"$")
    public void takeNote(String message) throws Throwable {
        message = WhiteBoard.resolve(owner, message);
        scenarioLogger.warn(message);
    }

    @Then("^Deletes existing exception if \"([^\"]*)\" is greater than zero by calling service \"([^\"]*)\" with request \"([^\"]*)\" and response \"([^\"]*)\"$")
    public void deletesExistingException(String totalRecords, String wsName, String reqBodyOrFile, String resBodyStringName) throws Throwable {

        totalRecords = WhiteBoard.getInstance().getString(owner, totalRecords);
        scenarioLogger.warn("Total Records=" + totalRecords);

        if (Integer.parseInt(totalRecords) > 0) {
            scenarioLogger.warn("Deleting exception");
            serviceIsCalledWithRequestAndResponse(wsName, reqBodyOrFile, resBodyStringName);
        } else scenarioLogger.warn("No exception to be deleted");
    }
    /**
     * The provider is resetting in DB
     *
     * @throws IOException
     */
    @And("^user resets provider authorizations$")
    public void userResetsProviderAuthorizations() {
        Map<String, String> pf = WhiteBoard.getInstance().getMap(owner, ExcelLib.THE_REQUESTING_PROVIDER);
        String providerTin = pf.get(MBM.RPPD_PROVIDER_TIN);
        new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).resetProvider(providerTin);
    }

    @Given("^user restore request \"([^\"]*)\" with hscID \"([^\"]*)\"$")
    public void userRestoreRequest(String authName, String hscID) throws Throwable {
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        AuthorizationRequest authorizationRequest = new AuthorizationRequest(scenario, driver());
        hscID = WhiteBoard.resolve(owner, hscID);
        authorizationRequest.restore(Conf.getOutputPath(), authName, owner, Long.parseLong(hscID), Arrays.asList("db"), pf);
    }

    /**
     * Step to validate that the icon indicating that a selected drug is preferred exists and is visible.
     *
     * @throws Throwable Should the call to 'driver()' fail.
     */
    @And("^the user should see the figure that marks this as a preferred product$")
    public void shouldSeePrefProcMarker() throws Throwable {

        // The icon which indicates that a selected drug is preferred
        By preferredProductIcon = By.xpath("//*[contains(@class, 'cux-icon-star_rating_filled')]");

        Assert.assertTrue(
                "Preferred procedure marker doesn't exist",
                TestUtils.isElementPresent(driver(), preferredProductIcon)
        );

    }



    private String setCustomer(String customer) {
        String str=null;
        switch (customer){
            case "UHC":
                str="1";
                break;
            case "BCBS":
                str="2";
                break;
            case "PHN":
                str="7";
                break;
        }
        return str;
    }

    private String setAuthorizationType(String authtype) {
        String str=null;
        switch(authtype) {

            case "Outpatient Chemotherapy":
                str="1";
                break;
            case "Cancer Supportive Drug Only":
                str="2";
                break;
            case "Therapeutic Radiopharmaceuticals":
                str="3";
                break;
            case "Specialty Pharmacy":
                str="4";
                break;
            case "Oral Drugs":
                str="5";
                break;
            case "Radiaton Oncology":
                str="9";
                break;
        }
        return str;
    }

    @And("^\"([^\"]*)\" is extracted using \"([^\"]*)\" for \"([^\"]*)\" for \"([^\"]*)\"$")
    public void isExtractedUsingForFor(String authNumber, String customer, String authtype, String cancer) throws Throwable {
        String authorizationType=setAuthorizationType(authtype);
        String payer=setCustomer(customer);
        String cancerType=setCancer(cancer);
        Map<String, String> pf = WhiteBoard.getInstance().getMap(owner, THE_MEMBER);
        String SubscriberID = pf.get(MBM.MEMB_SUBSCRIBER_ID);
        //List<Map<String, Object>> stringMapList = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectAuthNumberFrom(payer,authorizationType,Integer.parseInt(SubscriberID),cancerType);
        List<Map<String, Object>> stringMapList = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectAuthNumberFrom(payer,authorizationType,SubscriberID,cancerType);
        List<Map<String, String>> mapList = DataTableUtils.asMapsOfStrings(stringMapList);
        if (!(mapList.get(0).containsKey("pri_srvc_ref_nbr")) || "INVALID".equals(mapList.get(0).get("pri_srvc_ref_nbr"))) {
            mapList.get(0).put("pri_srvc_ref_nbr", mapList.get(0).get("vend_cse_id"));
        }

        Map<String, Map<String, String>> indexedMaps = DataTableUtils.dataTableAsMapsIndexedByKeyHeader(DataTableUtils.INDEX_ROW_NUMBER, mapList);
        WhiteBoard.storeMaps(owner, authNumber, Conf.getOutputPath(), indexedMaps);
        log.warn("result "+indexedMaps);
    }

    private String setCancer(String cancer) {
        String str=null;
        switch(cancer) {

            case "Waldenstroms Macroglobulinemia/Lymphoplasmacytic Lymphoma":
                str = "49";
                break;
            case "Prostate Cancer":
                str = "36";
                break;
            case "Breast Cancer":
                str = "72";
                break;
            case "Central Nervous System Tumors":
                str = "75";
                break;
        }
        return str;
    }

    private String setSupportiveType(String supptype) {
        String str = null;
        switch (supptype) {

            case "Bone Modifiers":
                str = "BM";
                break;
            case "Growth Factors":
                str = "GF";
                break;
        }
        return str;
    }

    @And("^\"([^\"]*)\" is extracted using \"([^\"]*)\" for \"([^\"]*)\" for \"([^\"]*)\" for supportive auths of \"([^\"]*)\"$")
    public void isExtractedUsingForForForSupportiveAuthsOf(String authNumber, String customer, String authtype, String Cancer, String Supptype) throws Throwable {
        String authorizationType = setAuthorizationType(authtype);
        String payer = setCustomer(customer);
        String cancer = setCancer(Cancer);
        String SupportiveType = setSupportiveType(Supptype);
        Map<String, String> pf = WhiteBoard.getInstance().getMap(owner, THE_MEMBER);
        String SubscriberID = pf.get(MBM.MEMB_SUBSCRIBER_ID);
        List<Map<String, Object>> stringMapList = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectAuthNumberForSupportive(payer, authorizationType, SubscriberID, cancer, SupportiveType);
        List<Map<String, String>> mapList = DataTableUtils.asMapsOfStrings(stringMapList);
        if (!(mapList.get(0).containsKey("pri_srvc_ref_nbr"))) {
            mapList.get(0).put("pri_srvc_ref_nbr", mapList.get(0).get("vend_cse_id"));
        }

        Map<String, Map<String, String>> indexedMaps = DataTableUtils.dataTableAsMapsIndexedByKeyHeader(DataTableUtils.INDEX_ROW_NUMBER, mapList);
        WhiteBoard.storeMaps(owner, authNumber, Conf.getOutputPath(), indexedMaps);
        log.warn("result " + indexedMaps);
    }
}

//  Deletes existing exception if "totalRecords" is greater than zero, then calls service "rulesSheetSearch" with request "${payload}" and response "processStartResponse"

//    @Then ("^Deletes existing exception if \"([^\"]*)\" is greater than zero by calling \"([^\"]*)\" with payload \"([^\"]*)\"$")
