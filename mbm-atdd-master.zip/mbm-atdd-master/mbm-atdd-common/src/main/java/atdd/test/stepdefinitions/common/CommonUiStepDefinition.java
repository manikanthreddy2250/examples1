package atdd.test.stepdefinitions.common;


import atdd.common.ICondition;
import atdd.common.Retry;
import atdd.common.ScenarioLogger;
import atdd.common.ui.OcmTypeAheadElement;
import atdd.common.ui.SlowBy;
import atdd.test.core.ISearchable;
import atdd.test.core.SearchCriteria;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.pageobjects.UserSecuritySettingsPage;
import atdd.test.stepsets.Login;
import atdd.utils.*;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;

import java.util.*;


public class CommonUiStepDefinition {

    public static final Logger log = Logger.getLogger(CommonUiStepDefinition.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }

    @And("^User verifies \"([^\"]*)\" header$")
    public void userVerifiesHeaderOnMemberInformationPage(String header) throws Throwable {
        TestUtils.wait(2);
        boolean present = obj().CommonPage.verifyHeader(header);
        Assert.assertTrue("Header " + header + " does not exists", present);
    }

    @When("^User waits for Busy indication$")
    public void user_waitsBusy() throws Throwable {
        obj().CommonPage.waitForNOTBusyIndicator();
    }

    @And("^Perform aXe web accessibility test and save it to \"([^\"]*)\" folder with \"([^\"]*)\" file name$")
    public void aXeTest(String pathToFile, String fileName) throws Throwable {
        boolean test = Boolean.parseBoolean(System.getenv("aXeTest"));
        log.warn("aXe Test key is: " + test);
        if (test) {
            String userdir = System.getProperty("user.dir");
            pathToFile = userdir + pathToFile;
            TestUtils.aXeTestAccessibility(driver(), pathToFile, fileName);
        }
    }

    @When("^Item \"([^\"]*)\" from Browser Local storage has value \"([^\"]*)\"$")
    public void checkItemFromLocalStorage(String item, String expectedValue) throws Throwable {
        Assert.assertEquals("Local storage value " + item + " does not match value " + expectedValue,
                obj().CommonPage.util_GetItemFromLocalStorage(item), expectedValue);
    }

    @And("^Save Page source in to folder \"([^\"]*)\" with title name and \"([^\"]*)\"$")
    public void saveHtmlName(String path, String name) throws Throwable {
        boolean test = Boolean.parseBoolean(System.getenv("htmlTest"));
        log.warn("Html Test key is: " + test);
        if (test) {
            TestUtils.wait(2);
            String userdir = System.getProperty("user.dir");
            path = userdir + path;
            log.warn("Path:" + path);
            log.warn("File name: " + driver().getTitle() + name);
            TestUtils.safeHTMLsoureCode(driver(), path, name);
        }
    }

    @And("^Save Page source in to folder \"([^\"]*)\" with title name$")
    public void saveHtml(String path) throws Throwable {
        boolean test = Boolean.parseBoolean(System.getenv("htmlTest"));
        log.warn("Html Test key is: " + test);
        if (test) {
            TestUtils.wait(2);
            String userdir = System.getProperty("user.dir");
            path = userdir + path;
            log.warn(path);
            TestUtils.safeHTMLsoureCode(driver(), path, "");
        }
    }

    @When("^URL \"([^\"]*)\" returns \"([^\"]*)\" code$")
    public void checkURLcode(String url, int code) throws Throwable {
        obj().CommonPage.verifyURLStatus(url, code);
    }

    @And("^Maximize browser window$")
    public void maxBrowser() throws Throwable {
        obj().CommonPage.maximizeBrowser();
    }

    @And("^Element with text \"([^\"]*)\" is not visible on the page$")
    public void checkNotElementByTxt(String txt) throws Throwable {
        obj().CommonPage.checkNotElementByText(txt);
    }

    @And("^Element with text \"([^\"]*)\" is visible on the page$")
    public void checkElementByTxt(String txt) throws Throwable {
        obj().CommonPage.checkElementByText(txt);
    }

    @And("^Element by Xpath \"([^\"]*)\" is visible on the page$")
    public void checkElementByXpath(String txt) throws Throwable {
        obj().CommonPage.checkElementByXpath(By.xpath(txt));
    }

    @And("^Element with text \"([^\"]*)\" and Required mark is visible on the page$")
    public void checkRequiredElementByTxt(String txt) throws Throwable {
        obj().CommonPage.checkRequiredElementByText(txt);
    }

    @When("^Current URL contains \"([^\"]*)\"$")
    public void checkPartUrl(String url) throws Throwable {
        obj().CommonPage.checkCurrentURL(url);
    }

    @When("^Page Title is \"([^\"]*)\"$")
    public void checkPageTitle(String titleName) throws Throwable {
        obj().CommonPage.checkPageTitle(titleName);
    }

    @And("^User jumps to window with \"([^\"]*)\" title$")
    public void changeChildWindow(String title) throws Throwable {
        obj().CommonPage.switchWindowTo(title);
    }

    @And("^User jumps to window with \"([^\"]*)\" number")
    public void changeChildWindowByNum(int num) throws Throwable {
        obj().CommonPage.switchWindowTo(num);
    }

    @And("^User click accept on the popup alert window$")
    public void clickAcceptAlert() throws Throwable {
        obj().CommonPage.acceptAlert();
        TestUtils.wait(5);
    }

    @When("^User clicks \"([^\"]*)\" button$")
    public void userClicksAButton(String buttonText) throws Throwable {
        obj().CommonPage.userClicksAButton(buttonText);
    }


    @Then("^system should display success message$")
    public void systemShouldDisplaySuccessMessage() throws Throwable {
        obj().CommonPage.successMsgDisplay();
    }

    @And("^user waits for few seconds$")
    public void userWaitsForFewSeconds() throws Throwable {
        obj().CommonPage.WaitsForFewSeconds();
    }

    @And("^User opens a new tab$")
    public void user_opens_new_Tab() throws Throwable {
        obj().CommonPage.opensNewTab();
    }

    @And("^User takes Screen Shot of the page \"([^\"]*)\" with title name and \"([^\"]*)\"$")
    public void userTakesScreenShotOfThePageWithTitleNameAnd(String path, String name) throws Throwable {
        TestUtils.wait(2);
        String userdir = System.getProperty("user.dir");
        path = userdir + path;
        log.warn("Path:" + path);
        log.warn("File name: " + driver().getTitle() + name);
        TestUtils.takeScreenShot(driver(), path, name);
    }

    @And("^user verifies there are \"([^\"]*)\" elements with xpath \"([^\"]*)\"$")
    public void userVerifiesThereAreElementsWithXpath(String count0, String xpath0) throws Throwable {
        String count1 = WhiteBoard.resolve(owner, count0);
        String xpath1 = WhiteBoard.resolve(owner, xpath0);
        Assert.assertEquals("Number of elements mismatch.",
                Integer.parseInt(count1), TestUtils.countElementsByXpath(driver(), xpath1));
    }

    @Given("^user refreshes current page$")
    public void userRefreshesCurrentPage() throws Throwable {
        TestUtils.refreshPage(driver());
    }

    /**
     * Add --End-- at the end of the dropdown options so code knows it's the end of the option list.
     *
     * @param pageName
     * @param data
     * @throws InvalidLocatorException
     */
    @Then("^user verifies on \"([^\"]*)\" below dropdown lists contain and contains only the options in below order$")
    public void userVerifiesOnBelowDropdownListsContainsAndContainsOnlyTheOptionsInBelowOrder(String pageName, List<List<String>> data) throws Throwable {

        pageName = WhiteBoard.resolve(owner, pageName);
        int rows = data.size();
        int cols = data.get(0).size();


        for (int col = 0; col < cols; col++) {
            List<String> expectedOptions = new ArrayList<>(rows);
            for (int row = 1; row < rows; row++) {

                String option = data.get(row).get(col);
                if (option != null && !option.equals("--End--")) {
                    expectedOptions.add(option);
                } else break;
            }
            expectedOptions = WhiteBoard.resolveStringList(owner, expectedOptions);
            boolean hasExpectedOptions = null != expectedOptions && expectedOptions.size() > 0;

            By locator = CommonPageObject.pageObjectUtils.getLocator(pageName, data.get(0).get(col));
            boolean elementVisible = TestUtils.isElementVisible(driver(), locator);

            if (hasExpectedOptions) {
                if (elementVisible) {
                    List<String> actualOptions = TestUtils.getDropdownListOptions(driver(), locator);
                    TestUtils.demoBreakPoint(scenario, driver(), "Dropdown list for " + locator);
                    Assert.assertEquals("Options are different.", expectedOptions, actualOptions);
                } else {
                    Assert.fail("Couldn't find element: " + locator);
                }
            } else {
                if (elementVisible) {
                    Assert.fail("Missing expected options for element: " + locator);
                } else {
                    scenarioLogger.warn("OK");
                }
            }
        }
    }

    @And("^user verifies on \"([^\"]*)\" right side dropdown list contains and contains only the options in below order based on left side inputs$")
    public void userVerifiesOnRightSideDropdownListContainsAndContainsOnlyTheOptionsInBelowOrderBasedOnLeftSideValue(String pageName, List<List<String>> combinations) throws Throwable {
        pageName = WhiteBoard.resolve(owner, pageName);
        List<String> headers = combinations.get(0);
        headers = WhiteBoard.resolveStringList(owner, headers);
        String locatorExpressionLeft = headers.get(0);
        String locatorExpressionRight = headers.get(1);
        By locatorLeft = CommonPageObject.pageObjectUtils.getLocator(pageName, locatorExpressionLeft);
        By locatorRight = CommonPageObject.pageObjectUtils.getLocator(pageName, locatorExpressionRight);

        List<String> expectedOptions = null;
        for (int i = 1; i < combinations.size(); i++) {
            List<String> row = combinations.get(i);
            row = WhiteBoard.resolveStringList(owner, row);
            String left = row.get(0);
            String right = row.get(1);
            if (!StringUtils.isEmpty(left)) {
                if (null != expectedOptions) {
                    List<String> actualOptions = TestUtils.getDropdownListOptions(driver(), locatorRight);
                    Assert.assertEquals("Options are different.", expectedOptions, actualOptions);
                }
                expectedOptions = new ArrayList<>();
                TestUtils.input(driver(), locatorLeft, left);
                TestUtils.wait(1);
            }
            expectedOptions.add(right);
        }
    }

    @And("^user verifies \"([^\"]*)\" looks like below layout$")
    public void userVerifiesLooksLikeBelowLayout(String pageName, List<List<String>> layout) throws Throwable {

        //TODO: fix for Jenkins
//        layout = WhiteBoard.resolveListOfStringList(owner, layout);
//        int rows = layout.size();
//        int cols = layout.get(0).size();
//
//        // left-right
//        TestUtils.scrollTo(driver(), 0, 0);
//        for (int row = 0; row < rows; row++) {
//            By lastLocator = null;
//            for (int col = 0; col < cols; col++) {
//                String locatorName = layout.get(row).get(col);
//                if (!StringUtils.isEmpty(locatorName)) {
//                    By currentLocator = CommonPageObject.getLocator(pageName, locatorName);
//                    if (null != lastLocator) {
//                        scenarioLogger.warn("Checking: " + pageName + "." + locatorName);
//                        scenarioLogger.warn("left-right: " + lastLocator + "-" + currentLocator);
//                        Assert.assertTrue("Should be displayed in left-right.", LocationUtils.leftRightSameRow(driver(), lastLocator, currentLocator));
//                        Assert.assertFalse("Should NOT be displayed in up-down.", LocationUtils.upDownSameColumn(driver(), lastLocator, currentLocator));
//                    }
//                    lastLocator = currentLocator;
//                    scenarioLogger.warn("Last locator: " + pageName + "." + locatorName);
//                }
//            }
//        }
//
//        // up-down
//        TestUtils.scrollTo(driver(), 0, 0);
//        for (int col = 0; col < cols; col++) {
//            By lastLocator = null;
//            for (int row = 0; row < rows; row++) {
//                String locatorName = layout.get(row).get(col);
//                if (!StringUtils.isEmpty(locatorName)) {
//                    By currentLocator = CommonPageObject.getLocator(pageName, locatorName);
//                    if (null != lastLocator) {
//                        scenarioLogger.warn("Checking: " + pageName + "." + locatorName);
//                        scenarioLogger.warn("up-down: " + lastLocator + "-" + currentLocator);
//                        Assert.assertFalse("Should NOT be displayed in left-right.", LocationUtils.leftRightSameRow(driver(), lastLocator, currentLocator));
//                        Assert.assertTrue("Should be displayed in up-down.", LocationUtils.upDownSameColumn(driver(), lastLocator, currentLocator));
//                    }
//                    lastLocator = currentLocator;
//                    scenarioLogger.warn("Last locator: " + pageName + "." + locatorName);
//                }
//            }
//        }
//
//        TestUtils.demoBreakPoint(scenario, driver(), pageName + " Layout");
    }

    //TODO - Look into why filter click isn't working
    @When("^user clicks \"([^\"]*)\" on \"([^\"]*)\"$")
    public void userClicksOn(String locator, String pageName) throws Throwable {
        TestUtils.click(driver(), CommonPageObject.pageObjectUtils.getLocator(pageName, locator));
        TestUtils.wait(2);
    }

    @When("^user clicks \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\"$")
    public void userClicksForOn(String locatorMethodName, String stringArgs, String pageName) throws Throwable {
        stringArgs = WhiteBoard.resolve(owner, stringArgs);
        String[] args = stringArgs.split("\\s*,\\s*");
        By by = CommonPageObject.pageObjectUtils.getLocator(pageName, locatorMethodName, args);
        TestUtils.click(driver(), by);
    }

    @And("^user searches for Member with \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
    public void userSearchesForMemberWith(String subId, String lname, String dob) throws Throwable {
        subId = WhiteBoard.resolve(owner, subId);
        lname = WhiteBoard.resolve(owner, lname);
        dob = WhiteBoard.resolve(owner, dob);

        obj().MemberSearchPage.enterLastName(lname).
                enterSubscriberID(subId).
                enterDOB(dob).
                clickSearchButton();
    }

    @And("^user searches for Member with \"([^\"]*)\",\"([^\"]*)\"$")
    public void userSearchesForMemberWith(String lname, String dob) throws Throwable {
        lname = WhiteBoard.resolve(owner, lname);
        dob = WhiteBoard.resolve(owner, dob);
        obj().MemberSearchPage.enterLastName(lname).
                enterDOB(dob).
                clickSearchButton();
    }


    @Given("^user adds below data on \"([^\"]*)\" and click \"([^\"]*)\"$")
    public void userAddsBelowDataOnAndClick(String pageName, String saveButtonLocatorName, List<Map<String, String>> maps) throws Throwable {
        maps = WhiteBoard.resolve(owner, maps);
        for (Map<String, String> map : maps) {
            for (String locatorName : map.keySet()) {
                By by = CommonPageObject.pageObjectUtils.getLocator(pageName, locatorName);
                TestUtils.input(driver(), by, map.get(locatorName));
            }

            TestUtils.demoBreakPoint(scenario, driver(), "Add Data");

            By saveButtonLocator = CommonPageObject.pageObjectUtils.getLocator(pageName, saveButtonLocatorName);
            TestUtils.click(driver(), saveButtonLocator);

            TestUtils.demoBreakPoint(scenario, driver(), "Add Data completed");
        }

    }

    @When("^user searches on \"([^\"]*)\" using below criteria and extract result as \"([^\"]*)\" with key header \"([^\"]*)\"$")
    public void userSearchesOnUsingBelowCriteriaAndExtractResultAsWithKeyHeader(String searchablePageName, String prefix, String keyHeader, List<Map<String, String>> maps) throws Throwable {
        ISearchable searchable = CommonPageObject.pageObjectUtils.newSearchable(searchablePageName, driver());
        SearchCriteria searchCriteria = new SearchCriteria(scenario, driver());
        searchCriteria.setCriteria(WhiteBoard.resolve(owner, maps).get(0), searchable.getFilterTableXpath());
        TestUtils.click(driver(), searchable.getSearchButtonLocator());
        TestUtils.wait(3);
        TestUtils.extractGridToWhiteBoard(driver(), scenario, prefix, keyHeader, searchable.getResultTableXpath(), searchable.hasPagination(), false);
    }


    @And("^user verifies the logo for bcbs$")
    public void userVerifiesTheLogoForBcbs() throws Throwable {
        obj().CommonPage.verifyBcbslogo();
    }

    @And("^user verifies the uhc env logo$")
    public void userVerifiesTheUhcEnvLogo() throws Throwable {
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        if (pf.get(MBM.USER_TITLE).contains("PAAN") || pf.get(MBM.USER_TITLE).contains("a uhc oncology user")) {
            TestUtils.wait(2);
            Assert.assertTrue(TestUtils.isElementVisible(this.driver(), obj().CommonPage.uhcProviderLogo));
            Assert.assertEquals("uhg header background color does not match", "#122377",
                    Color.fromString(this.driver().findElement(obj().CommonPage.headerColor).getCssValue("background-color")).asHex());
        } else {
            Assert.assertTrue(TestUtils.isElementVisible(this.driver(), obj().CommonPage.optumLogoUhcEnv));
            Assert.assertEquals("optum header background color does not match", "#63666a",
                    Color.fromString(this.driver().findElement(obj().CommonPage.headerColor).getCssValue("background-color")).asHex());

        }
    }

    @And("^\"([^\"]*)\" options are extracted as map \"([^\"]*)\" on \"([^\"]*)\"$")
    public void optionsAreExtractedAsMapOn(String dropdownLocatorName, String mapName, String pageName) throws Throwable {
        By by = CommonPageObject.pageObjectUtils.getLocator(pageName, dropdownLocatorName);
        List<String> optionList = TestUtils.getDropdownListOptions(driver(), by);
        Map<String, String> optionsByRow = DataTableUtils.toMapByRow(optionList);
        scenarioLogger.warn(optionsByRow.toString());
        WhiteBoard.getInstance().putMap(owner, mapName, optionsByRow);
    }

    @And("^user verifies \"([^\"]*)\" is checked on \"([^\"]*)\"$")
    public void userVerifiesIsSelectedOn(String elementName, String pageName) throws Throwable {
        By by = CommonPageObject.pageObjectUtils.getLocator(pageName, elementName);
        Assert.assertTrue(TestUtils.isChecked(driver(), by));
    }

    @Then("^user verifies \"([^\"]*)\" is blank on \"([^\"]*)\"$")
    public void userVerifiesIsBlankOn(String elementName, String pageName) throws Throwable {
        By by = CommonPageObject.pageObjectUtils.getLocator(pageName, elementName);
        Assert.assertTrue(TestUtils.value(driver(), by).trim().isEmpty());
    }

    @And("^\"([^\"]*)\" section is extracted as map \"([^\"]*)\"$")
    public void sectionIsExtractedAsMap(String sectionHeader, String mapName) throws Throwable {
        WebDriver driver = driver();
        Retry retry = new Retry("Wait for section to be visible: " + sectionHeader) {

            @Override
            protected void tryOnce() throws Exception {
                // do nothing
            }

            @Override
            protected boolean until() throws Exception {
                String xpath = TestUtils.getSectionTableXpath(driver, sectionHeader);
                if (null == xpath) {
                    return false;
                } else {
                    this.setOutcomeCompleted(xpath);
                    return true;
                }
            }
        };
        Assert.assertTrue(retry.execute());

        String tableXpath = (String) retry.getOutcomeCompleted();
        Assert.assertNotNull(tableXpath);

        TestUtils.demoBreakPoint(scenario, driver(), sectionHeader + " section is extracted as map " + mapName);
        Map<String, String> map = TestUtils.transposedTableAsMaps(driver(), tableXpath, 30).get(0);
        Map<String, Map<String, String>> maps = new HashMap<>(1);
        maps.put(mapName, map);
        WhiteBoard.storeMaps(owner, "", Conf.getOutputPath(), maps);
    }


    @And("^\"([^\"]*)\" section is extracted as map \"([^\"]*)\" if any$")
    public void sectionIsExtractedAsMapIfAny(String sectionHeader, String mapName) throws Throwable {
        String tableXpath = TestUtils.getSectionTableXpath(driver(), sectionHeader);
        if (!StringUtils.isEmpty(tableXpath)) {
            sectionIsExtractedAsMap(sectionHeader, mapName);
        } else {
            TestUtils.demoBreakPoint(scenario, driver(), "No such section: " + sectionHeader);
        }
    }


    @When("^user inputs \"([^\"]*)\" in \"([^\"]*)\"$")
    public void userInputsIn(String value, String locatorString) throws Throwable {
        WebDriver driver = driver();
        final String value1 = WhiteBoard.resolve(owner, value);
        Retry retry = new Retry("Input " + value + " with field " + locatorString) {
            @Override
            protected void tryOnce() throws Exception {
                WebElement el = TestUtils.slowFindElement(driver, locatorString, null);
                if (null == el) {
                    Assert.fail("Couldn't find element: " + locatorString);
                } else {
                    Assert.assertTrue("Couldn't input value " + value + " in element: " + locatorString, TestUtils.input(driver, el, value1, false));
                }
            }
        };

        Assert.assertTrue("Input fail.", retry.execute());
    }

    @And("^user clicks \"([^\"]*)\"$")
    public void userClicks(String locatorString) throws Throwable {
        locatorString = WhiteBoard.resolve(owner, locatorString);
        Assert.assertFalse(StringUtils.isEmpty(locatorString));

        WebDriver d = driver();
        try {
            By by = CommonPageObject.pageObjectUtils.getLocator(locatorString);
            if (!TestUtils.click(d, by)) {
                throw new InvalidLocatorException("Not clickable: " + by);
            }
        } catch (Exception e) {
            WebElement e1;
            List<WebElement> ele = TestUtils.findElements(d, locatorString);
            if (ele.size() > 0) {
                e1 = ele.get(0);
            } else {
                e1 = TestUtils.slowFindElement(d, locatorString, null);
            }
            TestUtils.waitElementVisible(d, locatorString);
            Assert.assertTrue(TestUtils.click(d, e1));
        }
    }

    @And("^user clicks \"([^\"]*)\" until \"([^\"]*)\" is \"([^\"]*)\"$")
    public void userClicksUntilIs(String clickLocator, String displayLocator0, String untilCriteria) throws Throwable {
        clickLocator = WhiteBoard.resolve(owner, clickLocator);
        String displayLocator = WhiteBoard.resolve(owner, displayLocator0);

        WebDriver d = driver();

        boolean success = TestUtils.clickUntil(d, clickLocator, new ICondition() {
            @Override
            public boolean evaluate() {
                boolean displayed = TestUtils.isElementVisible(d, SlowBy.by(d, displayLocator, null, null, null));
                if ("displayed".equals(untilCriteria)) {
                    return displayed;
                } else if ("not displayed".equals(untilCriteria)) {
                    return !displayed;
                } else {
                    throw new AssertionError("Unknown until criteria: " + untilCriteria);
                }
            }
        });
        String msg = "user clicks " + clickLocator + " until " + displayLocator + " is " + untilCriteria;
        Assert.assertTrue(msg, success);
    }

    @And("^user clicks \"([^\"]*)\" and waits until \"([^\"]*)\" is \"([^\"]*)\"$")
    public void userClicksAndWaitsUntilIs(String clickLocator, String displayLocator0, String untilCriteria) throws Throwable {
        clickLocator = WhiteBoard.resolve(owner, clickLocator);
        String displayLocator = WhiteBoard.resolve(owner, displayLocator0);

        WebDriver d = driver();
        ICondition condition = new ICondition() {
            @Override
            public boolean evaluate() {
                boolean displayed = TestUtils.isElementVisible(d, SlowBy.by(d, displayLocator, null, null, null));
                if ("displayed".equals(untilCriteria)) {
                    return displayed;
                } else if ("not displayed".equals(untilCriteria)) {
                    return !displayed;
                } else {
                    throw new AssertionError("Unknown until criteria: " + untilCriteria);
                }
            }
        };
        if (TestUtils.waitUntil("Check if already " + untilCriteria, 5, condition)) {
            scenarioLogger.warn("Already " + untilCriteria);
            return;
        }

        By clickBy = SlowBy.by(d, clickLocator, null, null, null);

        Assert.assertTrue(TestUtils.click(d, clickBy));

        boolean success = TestUtils.waitUntil("Wait until " + untilCriteria, 10, condition);
        String msg = "user clicks " + clickLocator + " and wait until " + displayLocator + " is " + untilCriteria;
        Assert.assertTrue(msg, success);
    }

    @And("^user waits until \"([^\"]*)\" is \"([^\"]*)\"$")
    public void userClicksAndWaitsUntilIs(String displayLocator0, String untilCriteria) throws Throwable {
        userClicksAndWaitsUntilIs(displayLocator0, untilCriteria, 15);
    }

    @And("^user waits until \"([^\"]*)\" is \"([^\"]*)\" within \"([^\"]*)\" seconds$")
    public void userClicksAndWaitsUntilIs(String displayLocator0, String untilCriteria, int withinSeconds) throws Throwable {
        String displayLocator = WhiteBoard.resolve(owner, displayLocator0);

        WebDriver d = driver();
        ICondition condition = new ICondition() {
            @Override
            public boolean evaluate() {
                By locator = null;
                try {
                    locator = CommonPageObject.pageObjectUtils.getLocator(displayLocator);
                } catch (Exception e) {
                    log.warn(e.getMessage());
                    // do nothing
                }
                if (null == locator) {
                    locator = SlowBy.by(d, displayLocator, null, null, null);
                }
                boolean displayed = TestUtils.isElementVisible(d, locator);
                if ("displayed".equals(untilCriteria)) {
                    return displayed;
                } else if ("not displayed".equals(untilCriteria)) {
                    return !displayed;
                } else {
                    throw new AssertionError("Unknown until criteria: " + untilCriteria);
                }
            }
        };
        if (!TestUtils.waitUntil("user waits until " + displayLocator + " " + untilCriteria, withinSeconds, condition)) {
            Assert.fail("Failed: user waits until " + displayLocator + " " + untilCriteria);
        }
    }

    @When("^table \"([^\"]*)\" is extracted as maps with prefix \"([^\"]*)\" and key header \"([^\"]*)\"$")
    public void tableIsExtractedAsMapsWithPrefix(String tableXpath, String prefix, String keyHeader) throws Throwable {
        tableXpath = WhiteBoard.resolve(owner, tableXpath);
        try {
            tableXpath = CommonPageObject.pageObjectUtils.getXpath(tableXpath);
        } catch (InvalidLocatorException e) {
            // do nothing
        }
        TestUtils.extractGridToWhiteBoard(driver(), scenario, prefix, keyHeader, tableXpath, false, false);
        TestUtils.demoBreakPoint(scenario, driver(), tableXpath + " is extracted with prefix " + prefix + " and key header " + keyHeader);
    }

    @When("^transposed table \"([^\"]*)\" is extracted as maps with prefix \"([^\"]*)\" and key header \"([^\"]*)\"$")
    public void transposedTableIsExtractedAsMapsWithPrefix(String tableXpath, String prefix, String keyHeader) throws Throwable {
        tableXpath = WhiteBoard.resolve(owner, tableXpath);
        try {
            tableXpath = CommonPageObject.pageObjectUtils.getXpath(tableXpath);
        } catch (InvalidLocatorException e) {
            // do nothing
        }
        TestUtils.extractGridToWhiteBoard(driver(), scenario, prefix, keyHeader, tableXpath, false, true);
        TestUtils.demoBreakPoint(scenario, driver(), tableXpath + " is extracted with prefix " + prefix + " and key header " + keyHeader);
    }

    @Then("^user verifies \"([^\"]*)\" is \"([^\"]*)\" pixels beneath \"([^\"]*)\" on \"([^\"]*)\"$")
    public void userVerifiesIsPixelsBeneathOn(String subjectName, String pixels, String referenceName, String pageName) throws Throwable {
        By subjectLocator = CommonPageObject.pageObjectUtils.getLocator(pageName, subjectName);
        By referenceLocator = CommonPageObject.pageObjectUtils.getLocator(pageName, referenceName);

        String[] p = pixels.split("to", 2);
        int from = Integer.parseInt(p[0].trim());
        int to = Integer.parseInt(p[1].trim());
        int actual = LocationUtils.verticalDistanceInPixels(driver(), referenceLocator, subjectLocator);

        TestUtils.demoBreakPoint(scenario, driver(), subjectName + " is " + pixels + " pixels beneath " + referenceName);

        Assert.assertTrue(pixels, actual >= from && actual <= to);
    }

    @And("^user verifies content of \"([^\"]*)\" on page \"([^\"]*)\" matches \"([^\"]*)\"$")
    public void userVerifiesContentOfOnPageMatches(String elementName, String pageName, String expectedContent) throws Throwable {
        By by = CommonPageObject.pageObjectUtils.getLocator(pageName, elementName);
        String actualContent = TestUtils.simpleContent(driver().findElement(by));
        expectedContent = WhiteBoard.resolve(owner, expectedContent);
        scenarioLogger.warn("Expected content: " + expectedContent);
        scenarioLogger.warn("Actual content: " + actualContent);
        Assert.assertTrue(expectedContent.equals(actualContent) || actualContent.matches(expectedContent));
    }

    @And("^user verifies content of \"([^\"]*)\" on page \"([^\"]*)\" contains \"([^\"]*)\"$")
    public void userVerifiesContentOfOnPageContains(String elementName, String pageName, String expectedContent) throws Throwable {
        By by = CommonPageObject.pageObjectUtils.getLocator(pageName, elementName);
        String actualContent = TestUtils.text(driver(), by);
        expectedContent = WhiteBoard.resolve(owner, expectedContent);
        Assert.assertTrue("", actualContent.contains(expectedContent));
    }

    @And("^User verifies the third tab as Converted Authorizations$")
    public void userVerifiesTheThirdTabAsConvertedAuthorizations() throws Throwable {
        obj().NavigationPage.userVerifiesTheConvertedAuthTab();
    }

    @Then("^user verifies map \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void userVerifiesMap(String mapName, String evaluation, String targetOption) throws Throwable {
        TestUtils.demoBreakPoint(scenario, driver(), "user verifies map " + mapName + " " + evaluation + " " + targetOption);
        Map<String, String> map = WhiteBoard.getInstance().getMap(owner, mapName);
        targetOption = WhiteBoard.resolve(owner, targetOption);
        switch (evaluation) {
            case "contains value":
                Assert.assertTrue(map.containsValue(targetOption));
                break;
            case "does not contain value":
                Assert.assertTrue(!map.containsValue(targetOption));
                break;
            default:
                Assert.fail("Unsupported evaluation: " + evaluation);
        }
    }

    @Then("^user should see message \"([^\"]*)\"$")
    public void userShouldSeeMessage(String expectedValue) throws Throwable {
        String note = "user should see message '" + expectedValue + "'";
        TestUtils.demoBreakPoint(scenario, driver(), note);
        Assert.assertTrue(note, TestUtils.waitElementVisible(driver(), "//*[text()='" + expectedValue + "']"));
    }

    @Then("^user should see global message \"([^\"]*)\"$")
    public void userShouldSeeGlobalMessage(String expectedValue) throws Throwable {
        expectedValue = WhiteBoard.resolve(owner, expectedValue);
        TestUtils.demoBreakPoint(scenario, driver(), "user should see global message '" + expectedValue + "'");
        String actualValue = obj().CommonPage.getGlobalMessagesDescription();
        Assert.assertEquals(expectedValue, actualValue);
    }

    @Then("^user should see global message \"([^\"]*)\" if \"([^\"]*)\"$")
    public void userShouldSeeGlobalMessageIf(String expectedValue, String conditionExpression) throws Throwable {
        if (WhiteBoard.evaluate(owner, conditionExpression)) {
            userShouldSeeGlobalMessage(expectedValue);
        }
    }

    @And("^user dismisses the global message$")
    public void userDismissesTheGlobalMessage() throws Throwable {
        obj().CommonPage.dismissGlobalMessage();
    }

    @When("^is clickable \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\"$")
    public void isLinkClickable(String locatorMethodName, String stringArgs, String pageName) throws Throwable {
        stringArgs = WhiteBoard.resolve(owner, stringArgs);
        String[] args = stringArgs.split("\\s*,\\s*");
        By by = CommonPageObject.pageObjectUtils.getLocator(pageName, locatorMethodName, args);
        boolean click = TestUtils.waitElementVisible(driver(), by);
        Assert.assertFalse(click);

    }

    @And("^hscID \"([^\"]*)\" is extracted from current url$")
    public void hscidIsExtractedFromCurrentUrl(String hscIDName) throws Throwable {
        String url = driver().getCurrentUrl();
        String hscID = TestUtils.getHscIdFromURL(url) + "";
        WhiteBoard.getInstance().putString(owner, hscIDName, hscID);
        scenarioLogger.warn(hscIDName + "=" + hscID);
    }

    @And("^grid \"([^\"]*)\" with \"([^\"]*)\" is extracted as \"([^\"]*)\"$")
    public void searchResultIsExtractedAsFromTableWithXpath(String tableXpath, String with, String name) throws Throwable {
        tableXpath = WhiteBoard.resolve(owner, tableXpath);
        if (StringUtils.isEmpty(tableXpath)) {
            Assert.fail("Missing tableXpath: " + tableXpath);
        }
        TestUtils.demoBreakPoint(scenario, driver(), "Extracting " + tableXpath + " as " + name);

        with = WhiteBoard.resolve(owner, with);
        Map<String, String> map = DataTableUtils.asMap(with);

        String layout = map.get("layout");
        if ("singleRecordTable".equals(layout)) {

            List<List<String>> lists = TestUtils.tableAsLists(driver(), tableXpath, 30);
            Map<String, String> singleRecord = new LinkedHashMap<>();
            List<String> lastRow = lists.get(0);
            for (int i = 1; i < lists.size(); i++) {
                List<String> currRow = lists.get(i);
                if (currRow.size() == lastRow.size()) {
                    for (int j = 0; j < currRow.size(); j++) {
                        String key = lastRow.get(j);
                        if (singleRecord.containsKey(key)) {
                            key += 2;
                        }
                        singleRecord.put(key, currRow.get(j));
                    }
                    if (i < lists.size() - 1) {
                        lastRow = lists.get(++i);
                    }
                } else {
                    lastRow = currRow;
                }
            }

            WhiteBoard.getInstance().putMap(owner, name, singleRecord);

        } else if ("transposedTable".equals(layout)) {
            Map<String, String> transposedTable = TestUtils.transposedTableAsMaps(driver(), tableXpath, 30).get(0);
            WhiteBoard.getInstance().putMap(owner, name, transposedTable);
        } else {

            String keyHeader = map.get("keyHeader");
            if (StringUtils.isEmpty(keyHeader)) {
                keyHeader = "ROW_NUMBER";
            }

            boolean hasPagination = false;
            if (Boolean.parseBoolean(map.get("hasPagination"))) {
                hasPagination = true;
            }

            TestUtils.extractGridToWhiteBoard(driver(), scenario, name, keyHeader, tableXpath, hasPagination, false);
        }
    }

    @Then("^user should see message \"([^\"]*)\" and dismiss$")
    public void userShouldSeeMessageAndDismiss(String msg) throws Throwable {
        TestUtils.demoBreakPoint(scenario, driver(), "user should see message '" + msg + "'");
        String msgXpath = "//span[contains(text(), '" + msg + "')]";
        Assert.assertTrue(TestUtils.isElementVisible(driver(), msgXpath));
        TestUtils.click(driver(), By.xpath("//button[contains(@class, 'oui-pmsg-close')]"));
    }

    @Then("^user should see NO \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\"$")
    public void userShouldSeeNOForOn(String locatorMethodName, String stringArgs, String pageName) throws Throwable {
        stringArgs = WhiteBoard.resolve(owner, stringArgs);
        String[] args = stringArgs.split("\\s*,\\s*");
        By by = CommonPageObject.pageObjectUtils.getLocator(pageName, locatorMethodName, args);
        Assert.assertFalse(TestUtils.waitElementVisible(driver(), by, 10));
    }

    @And("^user searches for user \"([^\"]*)\" on User Security Settings page$")
    public void userSearchesForUserOnUserSecuritySettingsPage(String userId) throws Throwable {
        TestUtils.input(driver(), UserSecuritySettingsPage.userIdInputBox, userId);
        TestUtils.click(driver(), UserSecuritySettingsPage.filterButton);
        TestUtils.wait(2);
    }

    @And("^user verifies the message displayed on the contact us page  as\"([^\"]*)\"$")
    public void userVerifiesTheMessageDisplayedOnTheContactUsPageAs(String message) throws Throwable {
        obj().CommonPage.verifyMessageOnContactUsPage(message);
    }

    @Then("^user verifies ocm-typeahead element \"([^\"]*)\" on \"([^\"]*)\" \"([^\"]*)\" values in \"([^\"]*)\"$")
    public void userVerifiesOcmTypeaheadElementOnValuesIn(String locatorName, String pageName, String verb, String listName) throws Throwable {
        By by = CommonPageObject.pageObjectUtils.getLocator(pageName, locatorName);
        OcmTypeAheadElement ocmTypeAheadElement = new OcmTypeAheadElement(driver(), driver().findElement(by));
        List<String> list = WhiteBoard.getInstance().getList(owner, listName);
        for (String target : list) {
            TestUtils.demoBreakPoint(scenario, driver(), "target=" + target);
            switch (verb) {
                case "accepts":
                    Assert.assertTrue(ocmTypeAheadElement.edit(target));
                    break;
                case "does not accept":
                    Assert.assertFalse(ocmTypeAheadElement.edit(target));
                    break;
                default:
                    Assert.fail("Unknown verb: " + verb);
            }
        }
    }

    @Then("^user verifies element \"([^\"]*)\" on \"([^\"]*)\" \"([^\"]*)\" values in \"([^\"]*)\"$")
    public void userVerifiesElementOnValuesIn(String locatorName, String pageName, String verb, String listName) throws Throwable {
        By by = CommonPageObject.pageObjectUtils.getLocator(pageName, locatorName);

        List<String> list = WhiteBoard.getInstance().getList(owner, listName);
        for (String target : list) {
            boolean success = TestUtils.input(driver(), by, target);
            TestUtils.demoBreakPoint(scenario, driver(), "target=" + target);
            switch (verb) {
                case "accepts":
                    Assert.assertTrue(success);
                    break;
                case "does not accept":
                    Assert.assertFalse(success);
                    break;
                default:
                    Assert.fail("Unknown verb: " + verb);
            }
        }
    }

    @And("^column \"([^\"]*)\" is extracted as list \"([^\"]*)\" from grid \"([^\"]*)\"$")
    public void columnIsExtractedAsListFromGrid(String columnName, String listName, String tableXpathOrExpression) throws Throwable {
        String xpath = null;
        try {
            xpath = CommonPageObject.pageObjectUtils.getXpath(tableXpathOrExpression);
        } catch (InvalidLocatorException e) {
            xpath = tableXpathOrExpression;
        }
        List<String> list = TestUtils.tableColumnAsList(driver(), xpath, columnName);
        WhiteBoard.getInstance().putList(owner, listName, list);
        TestUtils.demoBreakPoint(scenario, driver(), "column " + columnName + " is extracted as list " + listName + " from grid " + xpath);
    }

    @Then("^user validates \"([^\"]*)\" is \"([^\"]*)\" on \"([^\"]*)\"$")
    public void userValidatesIsOn(String locatorName, String verb, String pageName) throws Throwable {
        By by = CommonPageObject.pageObjectUtils.getLocator(pageName, locatorName);

        TestUtils.demoBreakPoint(scenario, driver(), "userValidatesIsOn()");
        switch (verb.trim().toLowerCase()) {
            case "displayed":
                Assert.assertTrue(TestUtils.isElementVisible(driver(), by));
                break;
            case "not displayed":
                Assert.assertFalse(TestUtils.isElementVisible(driver(), by));
                break;
            default:
                Assert.fail("Unknown verb: " + verb);
        }
    }

    @And("^user verifies section header \"([^\"]*)\" exists$")
    public void userVerifiesSectionHeaderExists(String s) throws Throwable {
        Assert.assertTrue(s + "is showing", TestUtils.isElementVisible(driver(), " //*[@class='sectionHeader']/span[text()='" + s + "']"));
    }

    @When("^user switches to the new browser tab$")
    public void userSwitchesToTheNewBrowserTab() throws Throwable {
        WebDriver driver = driver();
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());

        if (1 == tabs.size()) {
            Retry retry = new Retry("Retry waiting for new tab") {
                @Override
                protected void tryOnce() throws Exception {
                    tabs.clear();
                    tabs.addAll(driver.getWindowHandles());
                }

                @Override
                protected boolean until() throws Exception {
                    return tabs.size() > 1;
                }
            };
            Assert.assertTrue("Only one tab found.", retry.execute());
        }
        driver().switchTo().window(tabs.get(tabs.size() - 1));
    }

    @Then("^user validates content of \"([^\"]*)\" matches \"([^\"]*)\"$")
    public void userValidatesContentOfMatches(String locator, String expectedContentRegex) throws Throwable {
        WebDriver driver = driver();
        WebElement el = TestUtils.slowFindElement(driver, locator, null);
        if (null == el) {
            List<WebElement> elContainer = new ArrayList<>(1);
            Retry retry = new Retry("Retry waiting for element " + locator) {

                @Override
                protected void tryOnce() throws Exception {
                    WebElement el = TestUtils.slowFindElement(driver, locator, null);
                    if (null != el) {
                        elContainer.clear();
                        elContainer.add(el);
                    }
                }

                @Override
                protected boolean until() throws Exception {
                    return 1 == elContainer.size();
                }
            };
            Assert.assertTrue(retry.execute());
            el = elContainer.get(0);
        }
        String actualContent = TestUtils.simpleContent(el);
        TestUtils.demoBreakPoint(scenario, driver, "user validates content of \"" + locator + "\" matches \"" + expectedContentRegex + "\"");
        Assert.assertTrue(actualContent.matches(expectedContentRegex));
    }

    @And("^user closes the current tab$")
    public void userClosesTheCurrentTab() throws Throwable {
        TestUtils.closeCurrentTab(Login.getLastAccessedLogin(scenario).driver());
    }

    @Given("^user inputs below data$")
    public void userInputsBelowData(List<List<String>> data0) throws Throwable {
        List<List<String>> data1 = WhiteBoard.resolveListOfStringList(owner, data0);
        TestUtils.inputAll(driver(), data1, null, null);
        TestUtils.demoBreakPoint(scenario, driver(), "Input completed: " + data1.toString());
    }

    @Given("^user inputs below data by labels$")
    public void userInputsBelowDataByLabels(List<List<String>> data0) throws Throwable {
        List<List<String>> data1 = WhiteBoard.resolveListOfStringList(owner, data0);
        TestUtils.inputAllByLabels(driver(), data1, null);
        TestUtils.demoBreakPoint(scenario, driver(), "Input completed: " + data1.toString());
    }

    @Given("^user inputs below data by labels within \"([^\"]*)\"$")
    public void userInputsBelowDataByLabels(String parentXpath, List<List<String>> data0) throws Throwable {
        List<List<String>> data1 = WhiteBoard.resolveListOfStringList(owner, data0);
        TestUtils.inputAllByLabels(driver(), data1, parentXpath);
        TestUtils.demoBreakPoint(scenario, driver(), "Input completed: " + data1.toString());
    }

    /**
     * Writing message and screenshot to cucumber report
     *
     * @param message
     */
    @Then("^take note \"([^\"]*)\" with screenshot$")
    public void takeNoteWithScreenshot(String message) throws Throwable {
        message = WhiteBoard.resolve(owner, message);
        TestUtils.demoBreakPoint(scenario, driver(), message);
    }

    @Given("^current url is stored as \"([^\"]*)\"$")
    public void currentUrlIsStoredAs(String urlName) throws Throwable {
        WhiteBoard.getInstance().putString(owner, urlName, Login.getLastAccessedLogin(scenario).driver().getCurrentUrl());
    }

    @And("^User click Continue button in Regimen Page for Oral$")
    public void userClickContinueButtonInRegimenPageForOral() throws Throwable {
        obj().CommonPage.userClicksContinueButton();
    }

    @And("^user verifies \"([^\"]*)\"  popup message on Regimen Page Continue in Oral$")
    public void userVerifiesNotificationPopUpOral(String popupMessage) throws Throwable {
        obj().CommonPage.verifyPopUpMessageOral(popupMessage.trim());

    }

    @When("^user inputs \"([^\"]*)\" in Delivery Type field$")
    public void userInputsInDeliveryTypeField(String text) throws Throwable {
        obj().CommonPage.userInputsInDeliveryTypeField(text);
        TestUtils.wait(1);
    }

    @When("^user inputs \"([^\"]*)\" in Letter Type field$")
    public void userInputsInLetterTypeField(String text) throws Throwable {
        obj().CommonPage.userInputsInLetterTypeField(text);
        TestUtils.wait(1);
    }

    @When("^user inputs \"([^\"]*)\" hours in Sent Letter$")
    public void userInputsInHoursLetterSent(String hours) throws Throwable {
        obj().CommonPage.userInputsInHoursLetterSent(hours);
        TestUtils.wait(1);
    }


    @When("^user inputs \"([^\"]*)\" minutes in Sent Letter$")
    public void userInputsInMinutesLetterSent(String minutes) throws Throwable {
        obj().CommonPage.userInputsInminutesLetterSent(minutes);
        TestUtils.wait(1);
    }


    @When("^user clicks mark letter as sent$")
    public void userClicksMarkLetterAsSent() throws Throwable {
        obj().CommonPage.userClicksAButton("Mark Letter as Sent");
        TestUtils.wait(3);
    }


    @When("^user closed authorization request$")
    public void userClosesAuthorizationRequestPage() throws Throwable {
        obj().CommonPage.closeAuthorizationRequest("Notification requirements met");
        TestUtils.wait(1);
        obj().CommonPage.waitForNOTBusyIndicator();
    }


    @And("^user clicks download pdf button$")
    public void userClicksDownloadPDFButton() throws Throwable {
        obj().CommonPage.userClicksDownloadPDFButton();
        TestUtils.wait(1);
    }


    @And("^user clicks refresh button$")
    public void userClicksRefreshutton() throws Throwable {
        obj().CommonPage.waitForRefresh("Refresh", 180);
        obj().CommonPage.userClicksRefreshutton();

        TestUtils.wait(1);
    }


    @When("^user inputs \"([^\"]*)\" for fax number field$")
    public void userInputsFaxNumber(String text) throws Throwable {
        obj().CommonPage.userInputsFaxNumber(text);
        TestUtils.wait(1);
    }


    @When("^user inputs \"([^\"]*)\" for phone number field$")
    public void userInputsPhoneNumber(String text) throws Throwable {
        obj().CommonPage.userInputsPhoneNumber(text);
        TestUtils.wait(1);
    }

    @When("^user inputs \"([^\"]*)\" for name field$")
    public void userInputsName(String text) throws Throwable {
        obj().CommonPage.userInputsName(text);
        TestUtils.wait(1);
    }


    @When("^user inputs \"([^\"]*)\" for fax type$")
    public void userInputsFaxType(String text) throws Throwable {
        obj().CommonPage.userInputsFaxType(text);
        TestUtils.wait(1);
    }


    @And("^user clicks send fax button$")
    public void userClicksSendFaxButton() throws Throwable {
        obj().CommonPage.userClicksSendFaxButton();

        TestUtils.wait(1);
    }

    @And("^user clicks save fax button$")
    public void userClicksSaveFaxButton() throws Throwable {
        TestUtils.wait(2);
        obj().CommonPage.userClicksSaveFaxButton();

    }


    @And("^user clicks \"([^\"]*)\" hyperlink$")
    public void clickOnHyperlink(String hyperLinkName) throws Throwable {
        TestUtils.wait(2);
        obj().CommonPage.clickOnHyperlink(hyperLinkName);

    }

    @And("^user validates TAT page$")
    public void validateTATPage() throws Throwable {
        TestUtils.wait(2);
        obj().CommonPage.validateTATPage();

    }


    @And("^user validates pre filled field values in clone model for \"([^\"]*)\" and \"([^\"]*)\"$")
    public void userValidatesPreFilledFieldValuesInCloneModelForAnd(String drugDescription, String testFlag) throws Throwable {

        if (testFlag.equals("non preferred")) {

            String actualMessage = (driver().findElement(By.xpath("//*[@id='cloneAuthContent']/div[1]/div/div"))).getText();
            String expectedMessage = "This product requires further clinical review. Continuing with this product may lead to a peer-to-peer outreach to understand why the preferred product(s) are not appropriate for this member.";


            Assert.assertTrue("This product requires further clinical review... message not visible", actualMessage.equals(expectedMessage));
        } else {
            if (!testFlag.equals("non preferred")) {
                boolean found = true;
                try {
                    driver().findElement(By.xpath("//*[@id='cloneAuthContent']/div[1]/div/div"));
                } catch (NoSuchElementException e) {
                    found = false;
                }
                Assert.assertTrue(!found);
            }


        }


        String ActualDrugDescription = (driver().findElement(By.xpath("//*[@id='cloneAuthProcCdDesc']"))).getText();
        Assert.assertTrue("Drug description not visible as expected ", drugDescription.equals(ActualDrugDescription));

        try {
            TestUtils.input(driver(), By.xpath("//select[contains(@id,'cloneAuthDetails-placeOfServiceCode')]"), "Office");
        } catch (Throwable throwable) {
            //Do nothing
        }
        TestUtils.wait(2);


        TestUtils.safeClick(driver(), By.xpath("//*[@id=\"cloneContinue\"]"));
        TestUtils.wait(3);


    }

    @And("^User select letter option in Communication panel in View Auth page$")
    public void userSelectLetterOptionInCommunicationPanelInViewAuthPage() throws Throwable {
        obj().CommonPage.selectTypeInCommunication("LETTER");
    }

    @And("^User click on Letter History link$")
    public void userClickOnLetterHistoryLink() throws Throwable {
        obj().CommonPage.clickLetterHistory();
    }

    @And("^User verify whether letter history record present or create a new record$")
    public void userVerifyWhetherLetterHistoryRecordPresentOrCreateANewRecord() throws Throwable {
        obj().CommonPage.letterHistoryRecordsDisplayed("REQUESTING PROVIDER", "Fax", "Approval");
    }

    @And("^User click on View icon for the record present in Letter History section$")
    public void userClickOnViewIconForTheRecordPresentInLetterHisftorySection() throws Throwable {
        obj().CommonPage.clickLetterHistoryPDFView();
    }

    @And("^User verify pdf Preview is displayed in Preview section in Letter$")
    public void userVerifyPdfPreviewIsDisplayedInPreviewSectionInLetter() throws Throwable {
        obj().CommonPage.verifyPdfPreviewinLetter();
    }

    @And("^user changes \"([^\"]*)\" value to \"([^\"]*)\" from local storage$")
    public void userChangesValueToFromLocalStorage(String variable, String value) throws Throwable {
        obj().CommonPage.changevalueFromLocalStorage(variable, value);
    }

    @And("^user selects provider on Communication part$")
    public void userSelectsProviderOnCommunicationPart() throws Throwable {
        WebDriver d = driver();

        List<WebElement> ele = TestUtils.findElements(d, By.xpath("//input[@name='selectedProviders']"));
        if(ele.size()>0) {
            ele.get(1).click();
        }

    }

    @And("^user clicks Fax History hyperlink$")
    public void userClicksFaxHistoryHyperlink() throws Throwable {
        obj().CommonPage.clickonFaxHyperlink();
    }

    @And("^User clicks OK button$")
    public void userClicksOKButton() throws Throwable {
        obj().CommonPage.clickOnOK();
    }

    @And("^user clicks Add Drug$")
    public void userClicksAddDrug() throws Throwable {
        obj().CommonPage.clickOnAddDrug();
    }

    /**
     *
     * @param authnumber
     * @param date
     * @param reason
     * @throws Throwable
     */
    @When("^user backdates \"([^\"]*)\" to \"([^\"]*)\" with justification \"([^\"]*)\" and confirms changes$")
    public void userBackdatesToWithJustification(String authnumber, String date, String reason) throws Throwable {
        String date1=WhiteBoard.resolve(owner,date);
        obj().EditAuthorizationPage.clickBackdatingStartDateCheckBox();
        obj().EditAuthorizationPage.enterAuthorizationStartDateOnBackdatingScreen(date1);
        obj().EditAuthorizationPage.selectJustificationForBackdatingOfStartDate(reason);
        obj().EditAuthorizationPage.clickConfirmButton();

    }
    /**
     *
     * @throws Throwable
     */
    @And("^user adds clinical documentation on edit auth screen for \"([^\"]*)\"$")
    public void userAddsClinicalDocumentationOnEditAuthScreenFor(String pftitle) throws Throwable {
        Map<String, String> pf = new LinkedHashMap<>();
        pf.put(MBM.AUTH_TITLE, pftitle);
        pf = ExcelLib.completeProfile(owner, pf);
        String fileName=pf.get(MBM.RGID_CLINICAL_DOCUMENTATION);
        obj().EditAuthorizationPage.clickAddDocumentationOnBackDatingScreen(fileName);

    }
    @And("^User verifies \"([^\"]*)\" status on Request Status page$")
    public void userVerifiesStatusOnRequestStatusPage(String status) throws Throwable {
        obj().CommonPage.verifyAuthStatusLabel(status);
    }
    
    @Then("^user should see \"([^\"]*)\" link on the page$")
    public void userShouldSeeLinkOnThePage(String arg0) throws Throwable {
        obj().CommonPage.verifyLink(arg0);
    }
    
}
