package atdd.test.stepdefinitions.common;

import atdd.dao.OcmMBMDao;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.shared.BaseCucumber;
import atdd.test.shared.Globals;
import atdd.test.stepsets.Login;
import atdd.test.stepsets.QueryShared;
import atdd.utils.*;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Map;
import java.util.Properties;


public class DBStepDefinition {
    private final static Logger log = Logger.getLogger(DBStepDefinition.class);
    TestUtils utils = BaseCucumber.utils;
    Properties Config = Conf.getInstance();
    Globals gv = BaseCucumber.gv;
    private Connection connect = null;
    PreparedStatement ps;

    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void before(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
    }

    @Then("^Prepare Traversal data for Cancer type \"([^\"]*)\" which contains \"([^\"]*)\" in the description$")
    public void prepareTraversalDataByDescription(String cancerType, String descr) throws Throwable {

        log.warn("Prepare Traversal data for Cancer Type " + cancerType + " which contains " + descr + " in the description");

        //Get query
        String query = gv.getTraversalInfoByDescription(cancerType, descr);
        log.warn("Query: " + query);
        Map<String, String> results = OcmMBMDao.getDao().getMapOfRecords(query);

        //Set globals
        String dses_trvrs_id = results.get("dses_trvrs_id");
        gv.setTraversalID(dses_trvrs_id);

        String clin_var_val = results.get("clin_var_val");
        gv.setTraversalDescription(clin_var_val);

        String auth_dur_mo_cnt = results.get("auth_dur_mo_cnt");
        gv.setAuthdurmocnt(auth_dur_mo_cnt);

        String clin_var_typ_id = results.get("clin_var_typ_id");
        gv.setClinvartypid(clin_var_typ_id);

        String disease_type = results.get("disease_type");
        gv.setDiseasetype(disease_type);

        log.warn("\ndses_trvrs_id = " + dses_trvrs_id + "\nclin_var_val = " + clin_var_val +
                "\nauth_dur_mo_cnt = " + auth_dur_mo_cnt + "\nclin_var_typ_id = " + clin_var_typ_id +
                "\ndisease_type = " + disease_type);
    }

    @Then("^Prepare User data created by \"([^\"]*)\" for E&I members for PriorAuth search Submitted tab$")
    public void prepareSubmittedTabSearchForUserForIandI(String user) throws Throwable {

        //Getting user name. Same as in Login Procedure.
        String usernameTarget = Config.getProperty(user);
        //if property not found, we will use String from parameter.
        if (usernameTarget == null) {
            usernameTarget = user;
        }
        //If we will take it from Jenkins or system variables
        if (user.contains("Jenkins")) {
            log.warn("Getting User from Jenkins");
            String userNameTargetSystem = System.getenv("LoginUser");

            if (userNameTargetSystem != null) usernameTarget = userNameTargetSystem;
            else Assert.fail("Can't find Jenkins Login User Name");
        }

        //Get
        String query = gv.getSubmittedDBSearchCreatedByUserForIandI(usernameTarget);
        log.warn("Query: " + query);
        Map<String, String> results = OcmMBMDao.getDao().getMapOfRecords(query);

        String hsc_id = results.get("hsc_id");
        gv.setHsc_id(hsc_id);

        String requestNumber = results.get("vend_cse_id");
        gv.setRequestNumber(requestNumber);

        String prisrvcrefnbr = results.get("pri_srvc_ref_nbr");
        gv.setPrisrvcrefnbr(prisrvcrefnbr);

        String lastName = results.get("lst_nm");
        gv.setLastName(lastName);

        String firstName = results.get("fst_nm");
        gv.setFirstName(firstName);

        String subscriberId = results.get("mbr_id_txt");
        gv.setSubscriberId(subscriberId);

        String status = results.get("hscOverallStatusDesc");
        gv.setStatus(status);

        String startDate = results.get("creat_dttm");
        gv.setStartDate(startDate);

        String endDate = results.get("srvc_end_dt");
        gv.setEndDate(endDate);

        String requestingProvider = results.get("reqProviderFullName");
        gv.setRequestingProvider(requestingProvider);

        String servicingProvider = results.get("serProviderFullName");
        gv.setServicingProvider(servicingProvider);

        String reqProviderTIN = results.get("reqProviderTIN");
        gv.setReqProviderTIN(reqProviderTIN);

        log.warn("\nhsc_id = " + hsc_id + "\nRequest Number = " + requestNumber + "\nLast Name = " + lastName +
                "\nFirst Name = " + firstName + "\nSubscriber ID = " + subscriberId + "\nStatus = " + status +
                "\nStart Date = " + startDate + "\nEnd Date = " + endDate + "\nRequesting Provider = "
                + requestingProvider + "\nServicing Provider = " + servicingProvider +
                "\nRequesting Provider TIN = " + reqProviderTIN);

    }

    @Then("^Find and remember Traversal ID which is linked to HSC and has more than 2 occurrence$")
    public void findLinkedHscTraversal() throws Throwable {

        //Get
        String query = gv.getTraversalIDsLinkedToHscProstate;
        Map<String, String> results = OcmMBMDao.getDao().getMapOfRecords(query);

        String traversalID = results.get("dses_trvrs_id");
        gv.setTraversalID(traversalID);

        String traversalDesc = results.get("dses_trvrs_desc");
        gv.setTraversalDescription(traversalDesc);

        log.warn("\ndses_trvrs_id = " + traversalID +
                "\ndses_trvrs_desc = " + traversalDesc);
    }

    @Then("^Find and remember Traversal ID which is NOT linked to HSC and has more than 2 occurrence$")
    public void findNOTLinkedHscTraversal() throws Throwable {

        //Get
        String query = gv.getTraversalIDsNOTLinkedToHsc;
        Map<String, String> results = OcmMBMDao.getDao().getMapOfRecords(query);

        String traversalID = results.get("dses_trvrs_id");
        gv.setTraversalID(traversalID);

        String traversalDesc = results.get("dses_trvrs_desc");
        gv.setTraversalDescription(traversalDesc);

        log.warn("\ndses_trvrs_id = " + traversalID +
                "\ndses_trvrs_desc = " + traversalDesc);
    }

    @Then("^Prepare User data created by \"([^\"]*)\" for PriorAuth search Draft tab$")
    public void prepareDraftTabSearchForUser(String user) throws Throwable {

        //Getting user name. Same as in Login Procedure.
        String usernameTarget = Config.getProperty(user);
        //if property not found, we will use String from parameter.
        if (usernameTarget == null) {
            usernameTarget = user;
        }
        //If we will take it from Jenkins or system variables
        if (user.contains("Jenkins")) {
            log.warn("Getting User from Jenkins");
            String userNameTargetSystem = System.getenv("LoginUser");

            if (userNameTargetSystem != null) usernameTarget = userNameTargetSystem;
            else Assert.fail("Can't find Jenkins Login User Name");
        }

        //Get query
        String query = gv.getDraftDBsearchCreatedByUser(usernameTarget);
        log.warn("Query: " + query);
        Map<String, String> results = OcmMBMDao.getDao().getMapOfRecords(query);

        String hsc_id = results.get("hsc_id");
        gv.setHsc_id(hsc_id);

        String lastName = results.get("lst_nm");
        gv.setLastName(lastName);

        String firstName = results.get("fst_nm");
        gv.setFirstName(firstName);

        String subscriberId = results.get("mbr_id_txt");
        gv.setSubscriberId(subscriberId);

        String startDate = results.get("creat_dttm");
        gv.setStartDate(startDate);

        String requestingProvider = results.get("reqProviderFullName");
        gv.setRequestingProvider(requestingProvider);

        String servicingProvider = results.get("serProviderFullName");
        gv.setServicingProvider(servicingProvider);

        String creatorFirstName = results.get("creatorFirstName");
        gv.setCreatorFirstName(creatorFirstName);

        String creatorLastName = results.get("creatorLastName");
        gv.setCreatorLastName(creatorLastName);

        log.warn("\nhsc_id = " + hsc_id + "\nLast Name = " + lastName +
                "\nFirst Name = " + firstName + "\nSubscriber ID = " + subscriberId +
                "\nStart Date = " + startDate + "\nRequesting Provider = "
                + requestingProvider + "\nServicing Provider = " + servicingProvider);

    }

    @Then("^Prepare User data created by \"([^\"]*)\" for PriorAuth search Submitted tab$")
    public void prepareSubmittedTabSearchForUser(String user) throws Throwable {

        //Getting user name. Same as in Login Procedure.
        String usernameTarget = Config.getProperty(user);
        //if property not found, we will use String from parameter.
        if (usernameTarget == null) {
            usernameTarget = user;
        }
        //If we will take it from Jenkins or system variables
        if (user.contains("Jenkins")) {
            log.warn("Getting User from Jenkins");
            String userNameTargetSystem = System.getenv("LoginUser");

            if (userNameTargetSystem != null) usernameTarget = userNameTargetSystem;
            else Assert.fail("Can't find Jenkins Login User Name");
        }

        //Get
        String query = gv.getSubmittedDBSearchCreatedByUser(usernameTarget);
        log.warn("Query: " + query);
        Map<String, String> results = OcmMBMDao.getDao().getMapOfRecords(query);

        String hsc_id = results.get("hsc_id");
        gv.setHsc_id(hsc_id);

        String requestNumber = results.get("vend_cse_id");
        gv.setRequestNumber(requestNumber);

        String prisrvcrefnbr = results.get("pri_srvc_ref_nbr");
        gv.setPrisrvcrefnbr(prisrvcrefnbr);

        String lastName = results.get("lst_nm");
        gv.setLastName(lastName);

        String firstName = results.get("fst_nm");
        gv.setFirstName(firstName);

        String subscriberId = results.get("mbr_id_txt");
        gv.setSubscriberId(subscriberId);

        String status = results.get("hscOverallStatusDesc");
        gv.setStatus(status);

        String startDate = results.get("creat_dttm");
        gv.setStartDate(startDate);

        String endDate = results.get("srvc_end_dt");
        gv.setEndDate(endDate);

        String requestingProvider = results.get("reqProviderFullName");
        gv.setRequestingProvider(requestingProvider);

        String servicingProvider = results.get("serProviderFullName");
        gv.setServicingProvider(servicingProvider);

        String reqProviderTIN = results.get("reqProviderTIN");
        gv.setReqProviderTIN(reqProviderTIN);

        log.warn("\nhsc_id = " + hsc_id + "\nRequest Number = " + requestNumber + "\nLast Name = " + lastName +
                "\nFirst Name = " + firstName + "\nSubscriber ID = " + subscriberId + "\nStatus = " + status +
                "\nStart Date = " + startDate + "\nEnd Date = " + endDate + "\nRequesting Provider = "
                + requestingProvider + "\nServicing Provider = " + servicingProvider +
                "\nRequesting Provider TIN = " + reqProviderTIN);

    }

    @Then("^Prepare User data for PriorAuth search Draft tab$")
    public void prepareDraftTabSearch() throws Throwable {

        //Get
        String query = gv.draftDBsearch;
        Map<String, String> results = OcmMBMDao.getDao().getMapOfRecords(query);

        String hsc_id = results.get("hsc_id");
        gv.setHsc_id(hsc_id);

        String lastName = results.get("lst_nm");
        gv.setLastName(lastName);

        String firstName = results.get("fst_nm");
        gv.setFirstName(firstName);

        String subscriberId = results.get("mbr_id_txt");
        gv.setSubscriberId(subscriberId);

        String startDate = results.get("creat_dttm");
        gv.setStartDate(startDate);

        String requestingProvider = results.get("reqProviderFullName");
        gv.setRequestingProvider(requestingProvider);

        String servicingProvider = results.get("serProviderFullName");
        gv.setServicingProvider(servicingProvider);

        String creatorFirstName = results.get("creatorFirstName");
        gv.setCreatorFirstName(creatorFirstName);

        String creatorLastName = results.get("creatorLastName");
        gv.setCreatorLastName(creatorLastName);

        log.warn("\nhsc_id = " + hsc_id + "\nLast Name = " + lastName +
                "\nFirst Name = " + firstName + "\nSubscriber ID = " + subscriberId +
                "\nStart Date = " + startDate + "\nRequesting Provider = "
                + requestingProvider + "\nServicing Provider = " + servicingProvider);

    }

    @Then("^Prepare User data for PriorAuth search Submitted tab$")
    public void prepareSubmittedTabSearch() throws Throwable {

        //Get
        String query = gv.submittedDBSearch;
        Map<String, String> results = OcmMBMDao.getDao().getMapOfRecords(query);

        String hsc_id = results.get("hsc_id");
        gv.setHsc_id(hsc_id);

        String requestNumber = results.get("vend_cse_id");
        gv.setRequestNumber(requestNumber);

        String prisrvcrefnbr = results.get("pri_srvc_ref_nbr");
        gv.setPrisrvcrefnbr(prisrvcrefnbr);

        String lastName = results.get("lst_nm");
        gv.setLastName(lastName);

        String firstName = results.get("fst_nm");
        gv.setFirstName(firstName);

        String subscriberId = results.get("mbr_id_txt");
        gv.setSubscriberId(subscriberId);

        String status = results.get("hscOverallStatusDesc");
        gv.setStatus(status);

        String startDate = results.get("creat_dttm");
        gv.setStartDate(startDate);

        String endDate = results.get("srvc_end_dt");
        gv.setEndDate(endDate);

        String requestingProvider = results.get("reqProviderFullName");
        gv.setRequestingProvider(requestingProvider);

        String servicingProvider = results.get("serProviderFullName");
        gv.setServicingProvider(servicingProvider);

        log.warn("\nhsc_id = " + hsc_id + "\nRequest Number = " + requestNumber + "\nLast Name = " + lastName +
                "\nFirst Name = " + firstName + "\nSubscriber ID = " + subscriberId + "\nStatus = " + status +
                "\nStart Date = " + startDate + "\nEnd Date = " + endDate + "\nRequesting Provider = "
                + requestingProvider + "\nServicing Provider = " + servicingProvider);

    }

    @Then("^User should see 'HSC ID' in HSC table with Member \"([^\"]*)\" and DOB \"([^\"]*)\" and User Role \"([^\"]*)\"$")
    public void userShouldSeeHSCIDInHSCTableWithMemberAndDOBAndUserRole(String lastName, String dateOfBirth, String userName) throws Throwable {
        userName = Config.getProperty(userName);
        Map<String, String> results = OcmMBMDao.getDao().getHscIdForUSerFromDb(lastName, dateOfBirth, userName);

        String hsc_id = results.get("hsc_id");
        gv.setHsc_id(hsc_id);
        log.warn("hsc_id: " + hsc_id);
    }

    @And("^User verifies \"([^\"]*)\" vendor case id with Prefix \"([^\"]*)\" on Data Base$")
    public void userVerifiesVendorCaseIdWithPrefixOnDataBase(String caseId, String prefix) throws Throwable {
        if (caseId.equalsIgnoreCase("gv"))
            caseId = gv.getRequestNumber();
        Map<String, String> results = OcmMBMDao.getDao().getVendorCaseId(caseId);
        String vendorCaseId = results.get("vend_cse_id");
        Assert.assertTrue("The vendor case id Does not start with given prefix that is" + prefix, vendorCaseId.startsWith(prefix));


    }

    @And("^user verifies that records count for advanced search \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
    public void userVerifiesThatTheRecordsContainsAndAnd(String cancertype, String variabletype, String variablevalue, String variabletype1, String variablevalue1) throws Throwable {
        int count = 0;
        try {
            count = OcmMBMDao.getDao().validateCountOfrecords(cancertype, variabletype, variablevalue, variabletype1, variablevalue1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        obj().TraversalMaintenancePage.verifyCount(count);

    }

    @Given("^\"([^\"]*)\" is executed with \"([^\"]*)\" connection$")
    public void isExecutedInDatabase(String sql, String clazz) throws Throwable {
        new QueryShared(scenario).isExecutedInDatabase(sql, clazz);
    }

    @Given("^\"([^\"]*)\" is executed with \"([^\"]*)\" connection if \"([^\"]*)\"$")
    public void isExecutedInDatabaseIf(String sqlOrFileName0OrMyBatisSqlIdWithParams0, String sqlSessionFactoryClassName0, String ifExpression) throws Throwable {
        if (WhiteBoard.evaluate(owner, ifExpression)) {
            isExecutedInDatabase(sqlOrFileName0OrMyBatisSqlIdWithParams0, sqlSessionFactoryClassName0);
        }
    }

    @And("^user verfies \"([^\"]*)\" against \"([^\"]*)\"$")
    public void userVerfiesAgainst(String NasDriveData, String DBData) throws Throwable {
        ArrayList<FileIntake> expectedData = new ArrayList<>();
        ArrayList<FileIntake> actualData = new ArrayList<>();
        expectedData.addAll(FileIntakeKeeper.getInstance().getFileIntakeMap(owner, NasDriveData));
        actualData.addAll(FileIntakeKeeper.getInstance().getFileIntakeMap(owner, DBData));
        Assert.assertTrue(expectedData.size() <= actualData.size());

        for (FileIntake expected : expectedData) {
            DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
            String date = df.format(new SimpleDateFormat("yyyyMMdd").parse(expected.getBirthDate()));
            String coverageEndDate = df.format(new SimpleDateFormat("MMddyyyy").parse(expected.getCoverageEligibilityEndDate()));
            String coverageStartDate = df.format(new SimpleDateFormat("MMddyyyy").parse(expected.getCoverageEligibilityStartDate()));
            Assert.assertTrue(actualData.stream().anyMatch(o -> o.getMemberID().equals(expected.getMemberID())));
            Assert.assertTrue(actualData.stream().anyMatch(o -> o.getFirstName().equals(expected.getFirstName())));
            Assert.assertTrue(actualData.stream().anyMatch(o -> o.getLastName().trim().equals(expected.getLastName())));
            Assert.assertTrue(actualData.stream().anyMatch(o -> o.getMiddleInitial().equals(expected.getMiddleInitial())));
            Assert.assertTrue(actualData.stream().anyMatch(o -> o.getAddress1().equals(expected.getAddress1())));
            Assert.assertTrue(actualData.stream().anyMatch(o -> o.getAddress2().equals(expected.getAddress2())));
            Assert.assertTrue(actualData.stream().anyMatch(o -> o.getBirthDate().equals(date)));
            Assert.assertTrue(actualData.stream().anyMatch(o -> o.getCoverageEligibilityEndDate().equals(coverageEndDate)));
            Assert.assertTrue(actualData.stream().anyMatch(o -> o.getCoverageEligibilityStartDate().equals(coverageStartDate)));
            Assert.assertTrue(actualData.stream().anyMatch(o -> o.getCity().equals(expected.getCity())));
            Assert.assertTrue(actualData.stream().anyMatch(o -> o.getCoverageEligibilityStatus().equals(expected.getCoverageEligibilityStatus())));
            Assert.assertTrue(actualData.stream().anyMatch(o -> o.getGender().equals(expected.getGender())));
            Assert.assertTrue(actualData.stream().anyMatch(o -> o.getGroupID().equals(expected.getGroupID())));
            Assert.assertTrue(actualData.stream().anyMatch(o -> o.getPhone().equals(expected.getPhone())));
            Assert.assertTrue(actualData.stream().anyMatch(o -> o.getPostalCode().equals(expected.getPostalCode())));
            Assert.assertTrue(actualData.stream().anyMatch(o -> o.getRelationship().equals(expected.getRelationship())));
            Assert.assertTrue(actualData.stream().anyMatch(o -> o.getState().equals(expected.getState())));
            Assert.assertTrue(actualData.stream().anyMatch(o -> o.getSubscriberFirstName().equals(expected.getSubscriberFirstName())));
            Assert.assertTrue(actualData.stream().anyMatch(o -> o.getSubscriberLastName().trim().equals(expected.getSubscriberLastName().trim())));
            Assert.assertTrue(actualData.stream().anyMatch(o -> o.getSubscriberMemberID().equals(expected.getSubscriberMemberID())));
            Assert.assertTrue(actualData.stream().anyMatch(o -> o.getSubscriberMiddleInitial().equals(expected.getSubscriberMiddleInitial())));
        }
    }

}



