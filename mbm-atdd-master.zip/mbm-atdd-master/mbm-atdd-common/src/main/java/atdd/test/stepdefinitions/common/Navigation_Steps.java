package atdd.test.stepdefinitions.common;

import atdd.common.ScenarioLogger;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.pageobjects.NavigationPage;
import atdd.test.shared.BaseCucumber;
import atdd.test.stepsets.Login;
import atdd.utils.*;
import cucumber.api.PendingException;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.ArrayList;
import java.util.List;


public class Navigation_Steps {

    public static final Logger log = Logger.getLogger(Navigation_Steps.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }

    @Given("^User opens browser '(.*)'$")
    public void userOpensBrowser(String browser) throws Throwable {
        BaseCucumber.setDriver(browser);
    }

    @Then("^He opens '(.*)' URL$")
    public void heOpensUrl(String urlKey) throws Throwable {
        String targetURL = Conf.getInstance().getProperty(urlKey);
        if (null == targetURL) {
            targetURL = Conf.getInstance().getProperty(Conf.TEST_HOST_KEY) + Conf.getInstance().getProperty(Conf.TEST_ENDPOINT_KEY);
        }
        Assert.assertNotNull(targetURL);
        driver().get(targetURL);
    }

    @Then("^User closes Analytics window on Request Status page$")
    public void closeAnalytics() throws Throwable {
        obj().NavigationPage.closeAnalytics();
    }

    @And("^Select \"([^\"]*)\" primary navigation menu$")
    public void selectPrimaryNavigationMenu(String option) throws Throwable {
        obj().NavigationPage.expandClickPrimaryNav(option);
    }

    @And("^User selects \"([^\"]*)\" option from primary navigation dropdown")
    public void userSelectsFromPrimaryNavMenu(String option) throws Throwable {
        obj().NavigationPage.clickOptionFromPrimaryNavMenu(option);
    }

    @And("^User selects \"([^\"]*)\" option from \"([^\"]*)\" primary navigation dropdown$")
    public void clickNavMenuDropDown(String option, String navOption) throws Throwable {
        obj().NavigationPage.clickNavOptionByDropDownOption(navOption, option);
    }

    @When("^User selects Submitted tab on the PriorAuth Search page$")
    public void user_selects_SubmittedTab() throws Throwable {
        obj().NavigationPage.selectSubmittedTab_Search();
        obj().CommonPage.waitForNOTBusyIndicator();
    }

    @When("^User selects Draft tab on the PriorAuth Search page$")
    public void user_selects_DraftTab() throws Throwable {
        obj().NavigationPage.selectDraftTab_Search();
        obj().CommonPage.waitForNOTBusyIndicator();
    }

    @When("^User selects History tab on the PriorAuth Search page$")
    public void user_selects_HistoryTab() throws Throwable {
        obj().NavigationPage.selectHistoryTab_Search();
        obj().CommonPage.waitForNOTBusyIndicator();
    }

    @When("^User selects Converted Authorizations tab on the PriorAuth Search page$")
    public void userSelectsConvertedAuthorizationsTabOnThePriorAuthSearchPage() throws Throwable {
        obj().NavigationPage.selectConvertedAuthorizationsTab_Search();
        obj().CommonPage.waitForNOTBusyIndicator();
    }

    @And("^Select \"([^\"]*)\" system navigation dropdown$")
    public void selectSystemNavigationMenu(String option) throws Throwable {
        obj().NavigationPage.expandClickPrimaryNav(option);
    }

    @And("^User selects \"([^\"]*)\" option from top navigation dropdown")
    public void userSelectsFromTopNavMenu(String option) throws Throwable {
        obj().NavigationPage.clickOptionFromTopNavMenu(option);
    }

    @And("^user navigates to menu item \"([^\"]*)\"$")
    public void userNavigatesToMenuItem(String trace) throws Throwable {
        obj().NavigationPage.navigatesToMenuItem(trace);
    }

    /**
     * This scenario validates correct submenu displayed under main menu
     *
     * @param mainMenu0, expectedSubMenuList
     */
    @And("^User validates \"([^\"]*)\" contains only below options$")
    public void user_validates_contains_only_below_options(String mainMenu0, List<String> expectedSubMenuList) throws Throwable {
        WebDriver d = driver();
        NavigationPage page = new NavigationPage(d);

        String mainMenu = StringUtils.peel(mainMenu0, "-");
        boolean shouldSee = mainMenu.equals(mainMenu0);
        boolean actualSee = page.waitMainMenu(mainMenu);
        Assert.assertEquals(shouldSee, actualSee);

        if (!shouldSee) {
            return;
        }

        page.expandClickPrimaryNav(mainMenu);
        List<String> actualSubMenuList = page.getsubMenuValue(mainMenu);

        TestUtils.demoBreakPoint(scenario, d, "Verifying sub-menu list of main menu " + mainMenu);
        Assert.assertEquals("Submenu list not matching.", expectedSubMenuList, actualSubMenuList);
    }

    @And("^user verifies \"([^\"]*)\" pop up$")
    public void userVerifiesPopUp(String message) throws Throwable {
        obj().NavigationPage.verifySystemUnvailablePopUp(message);
    }

    @And("^user navigates to UHC home page$")
    public void userNavigatesToUHCHomePage() throws Throwable {
        obj().NavigationPage.navigateToUHCHomePage();
    }

    @And("^user navigates to BCBS home page$")
    public void userNavigatesToBCBSHomePage() throws Throwable {
        obj().NavigationPage.navigateToBCBSHomePage();

    }

    @Then("^user should be landing on \"([^\"]*)\" page$")
    public void userShouldBeLandingOnPage(String header0) throws Throwable {
        header0 = WhiteBoard.resolve(owner, header0).trim();
        String header = StringUtils.peel(header0, "-");

        boolean shouldSee = header.equals(header0);
        boolean actualSee = obj().CommonPage.waitHeader(header, 15);

        TestUtils.demoBreakPoint(scenario, driver(), "User should be landing on " + header + " page.");
        Assert.assertEquals(shouldSee, actualSee);
    }

    @Then("^user should be landing on \"([^\"]*)\" page if \"([^\"]*)\"$")
    public void userShouldBeLandingOnPageIf(String header0, String conditionExpression) throws Throwable {
        if (WhiteBoard.evaluate(owner, conditionExpression)) {
            userShouldBeLandingOnPage(header0);
        }
    }

    /**
     * Example:
     * And user verifies the menu items matches below table
     * | Home | Authorization | Work Queue      | Activity Tracking | Contact Us |
     * |      | Add New       | Unassigned Work | Add New           |            |
     * |      | Search        | My Work         | History           |            |
     *
     * @param table
     */
    @And("^user verifies the menu items matches below table$")
    public void userVerifiesTheMenuItemsMatchesBelowTable(List<List<String>> table) throws Throwable {
        table = DataTableUtils.transpose(table);
        for (List<String> l : table) {
            String mainMenu = l.get(0);
            List<String> subMenuList = new ArrayList<>(l.subList(1, l.size()));
            List<String> validSubMenuList = new ArrayList<>(subMenuList.size());
            for (String subMenu : subMenuList) {
                if (StringUtils.isEmpty(subMenu)) {
                    continue;
                }
                String subMenu1 = StringUtils.peel(subMenu, "-");
                if (!subMenu1.equals(subMenu)) {
                    continue;
                }
                validSubMenuList.add(subMenu);
            }
            user_validates_contains_only_below_options(mainMenu, validSubMenuList);
        }
    }

    @And("^user verifies the menu items matches below table if \"([^\"]*)\"$")
    public void userVerifiesTheMenuItemsMatchesBelowTable(String condition, List<List<String>> table) throws Throwable {
        if (WhiteBoard.evaluate(owner, condition)) {
            userVerifiesTheMenuItemsMatchesBelowTable(table);
        }
    }

    @Then("^user verifies menu item \"([^\"]*)\" is not displayed$")
    public void userVerifiesMenuItemIsNotDisplayed(String trace) throws Throwable {
        String[] p = trace.split(">");

        boolean success = false;
        for (String item : p) {
            String xpath = "//li//span[.='" + item + "']";
            if (TestUtils.isElementVisible(driver(), xpath)) {
                TestUtils.click(driver(), By.xpath(xpath));
            } else {
                success = true;
                break;
            }
        }
        Assert.assertTrue(success);
    }

    @When("^user navigates to url \"([^\"]*)\"$")
    public void userNavigatesToUrl(String url) throws Throwable {
        url = WhiteBoard.resolve(owner, url);
        driver().get(url);
    }

    @And("^user navigates to button item \"([^\"]*)\"$")
    public void userNavigatesToButtonItem(String itemText) throws Throwable {
        obj().CommonPage.clickElementByText(itemText);

    }

    @And("^user expands the first row$")
    public void expandFirstRowInActivities() throws Throwable {
        obj().CommonPage.expandFirstRowInActivities();

    }

    @Then("^user will be landing on \"([^\"]*)\" page$")
    public void userWillBeLandingOnPage(String header0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        header0 = WhiteBoard.resolve(owner, header0).trim();
        String header = StringUtils.peel(header0, "-");
        Assert.assertEquals(header, header0);
    }


    /**
     * Navigate between Customers using customer selection on menu bar
     * Navigate to customer method uses contain text
     * @throws Throwable
     */
    @And("^user navigates to \"([^\"]*)\" customer using customer selection$")
    public void userNavigatesToCustomer(String customer) throws Throwable {
        obj().NavigationPage.navigateToCustomer(customer);
    }

    @And("^user navigates to Home Page$")
    public void userNavigatesToHomePage() throws Throwable {
        obj().NavigationPage.navigatesToMenuItem("Home>");
        TestUtils.wait(3);

    }

    @And("^user verifies \"([^\"]*)\" header on pop up$")
    public void userVerifiesHeaderOnPopUp(String message) throws Throwable {
        obj().NavigationPage.userVerifiesHeaderOnpopUp(message);
    }
}
