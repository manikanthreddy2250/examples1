package atdd.test.stepdefinitions.common;

import atdd.utils.*;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import org.junit.Assert;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ProfileStepDefinition {

    private Scenario scenario;
    private String owner;


    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
    }

    @Given("^user is \"([^\"]*)\"$")
    public void userIs(String title) throws Throwable {
        if (StringUtils.isEmpty(title)) {
            return;
        }
        title = WhiteBoard.resolve(owner, title);
        Map<String, String> pf = ExcelLib.instance(ExcelLib.LIB_USER).getObjectByTitle(title);
        Assert.assertNotNull(pf);
        WhiteBoard.getInstance().putMap(owner, ExcelLib.THE_USER, pf);

        //for report
        scenario.write(title + "=" + WhiteBoard.getInstance().protect(pf));
    }

    @And("^user is \"([^\"]*)\" with below changes$")
    public void userIsWithBelowChanges(String title, List<Map<String, String>> belowChanges) throws Throwable {
        if (StringUtils.isEmpty(title)) {
            return;
        }
        title = WhiteBoard.resolve(owner, title);
        Map<String, String> pf = ExcelLib.instance(ExcelLib.LIB_USER).getObjectByTitle(title);
        Assert.assertNotNull(pf);
        Map<String, String> updates = WhiteBoard.resolve(owner, belowChanges.get(0));
        Assert.assertNotNull(updates);
        pf.putAll(updates);
        WhiteBoard.getInstance().putMap(owner, ExcelLib.THE_USER, pf);

        //for report
        scenario.write(title + "=" + WhiteBoard.getInstance().protect(pf));
    }

    @And("^user is \"([^\"]*)\" with \"([^\"]*)\"$")
    public void userIsWith(String title, String belowChanges) throws Throwable {
        if (StringUtils.isEmpty(title)) {
            return;
        }
        List<Map<String, String>> maps = new ArrayList<>(1);
        maps.add(DataTableUtils.asMap(WhiteBoard.resolve(owner, belowChanges)));
        userIsWithBelowChanges(title, maps);
    }

    @Given("^member is \"([^\"]*)\"$")
    public void memberIs(String title) throws Throwable {
        if (StringUtils.isEmpty(title)) {
            return;
        }
        title = WhiteBoard.resolve(owner, title);
        Map<String, String> pf = ExcelLib.instance(ExcelLib.LIB_MEMB).getObjectByTitle(title);
        Assert.assertNotNull(pf);
        WhiteBoard.getInstance().putMap(owner, ExcelLib.THE_MEMBER, pf);

        //for report
        scenario.write(title + "=" + WhiteBoard.getInstance().protect(pf));
    }

    @And("^member is \"([^\"]*)\" with below changes$")
    public void memberIsWithBelowChanges(String title, List<Map<String, String>> belowChanges) throws Throwable {
        if (StringUtils.isEmpty(title)) {
            return;
        }
        title = WhiteBoard.resolve(owner, title);
        Map<String, String> pf = ExcelLib.instance(ExcelLib.LIB_MEMB).getObjectByTitle(title);
        Assert.assertNotNull(pf);
        Map<String, String> updates = WhiteBoard.resolve(owner, belowChanges.get(0));
        Assert.assertNotNull(updates);
        pf.putAll(updates);
        WhiteBoard.getInstance().putMap(owner, ExcelLib.THE_MEMBER, pf);

        //for report
        scenario.write(title + "=" + WhiteBoard.getInstance().protect(pf));
    }

    @And("^member is \"([^\"]*)\" with \"([^\"]*)\"$")
    public void memberIsWith(String title, String belowChanges) throws Throwable {
        if (StringUtils.isEmpty(title)) {
            return;
        }
        List<Map<String, String>> maps = new ArrayList<>(1);
        maps.add(DataTableUtils.asMap(WhiteBoard.resolve(owner, belowChanges)));
        memberIsWithBelowChanges(title, maps);
    }

    @And("^requesting provider is \"([^\"]*)\"$")
    public void requestingProviderIs(String title) throws Throwable {
        if (StringUtils.isEmpty(title)) {
            return;
        }
        title = WhiteBoard.resolve(owner, title);
        Map<String, String> pf = ExcelLib.instance(ExcelLib.LIB_RP).getObjectByTitle(title);
        Assert.assertNotNull(pf);
        WhiteBoard.getInstance().putMap(owner, ExcelLib.THE_REQUESTING_PROVIDER, pf);

        //for report
        scenario.write(title + "=" + WhiteBoard.getInstance().protect(pf));
    }

    @And("^requesting provider is \"([^\"]*)\" with below changes$")
    public void requestingProviderIsWithBelowChanges(String title, List<Map<String, String>> belowChanges) throws Throwable {
        if (StringUtils.isEmpty(title)) {
            return;
        }
        title = WhiteBoard.resolve(owner, title);
        Map<String, String> pf = ExcelLib.instance(ExcelLib.LIB_RP).getObjectByTitle(title);
        Assert.assertNotNull(pf);
        Map<String, String> updates = WhiteBoard.resolve(owner, belowChanges.get(0));
        Assert.assertNotNull(updates);
        pf.putAll(updates);
        WhiteBoard.getInstance().putMap(owner, ExcelLib.THE_REQUESTING_PROVIDER, pf);

        //for report
        scenario.write(title + "=" + WhiteBoard.getInstance().protect(pf));
    }

    @And("^requesting provider is \"([^\"]*)\" with \"([^\"]*)\"$")
    public void requestingProviderIsWith(String title, String belowChanges) throws Throwable {
        if (StringUtils.isEmpty(title)) {
            return;
        }
        List<Map<String, String>> maps = new ArrayList<>(1);
        maps.add(DataTableUtils.asMap(WhiteBoard.resolve(owner, belowChanges)));
        requestingProviderIsWithBelowChanges(title, maps);
    }

    @And("^servicing provider is \"([^\"]*)\"$")
    public void servicingProviderIs(String title) throws Throwable {
        if (StringUtils.isEmpty(title)) {
            return;
        }
        title = WhiteBoard.resolve(owner, title);
        Map<String, String> pf = ExcelLib.instance(ExcelLib.LIB_SP).getObjectByTitle(title);
        Assert.assertNotNull(pf);
        WhiteBoard.getInstance().putMap(owner, ExcelLib.THE_SERVICING_PROVIDER, pf);

        //for reportWhiteBoard.getInstance().protect(pf)
        scenario.write(title + "=" + WhiteBoard.getInstance().protect(pf));
    }

    @And("^servicing provider is \"([^\"]*)\" with below changes$")
    public void servicingProviderIsWithBelowChanges(String title, List<Map<String, String>> belowChanges) throws Throwable {
        if (StringUtils.isEmpty(title)) {
            return;
        }
        title = WhiteBoard.resolve(owner, title);
        Map<String, String> pf = ExcelLib.instance(ExcelLib.LIB_SP).getObjectByTitle(title);
        Assert.assertNotNull(pf);
        Map<String, String> updates = WhiteBoard.resolve(owner, belowChanges.get(0));
        Assert.assertNotNull(updates);
        pf.putAll(updates);
        WhiteBoard.getInstance().putMap(owner, ExcelLib.THE_SERVICING_PROVIDER, pf);

        //for report
        scenario.write(title + "=" + WhiteBoard.getInstance().protect(pf));
    }

    @And("^servicing provider is \"([^\"]*)\" with \"([^\"]*)\"$")
    public void servicingProviderIsWith(String title, String belowChanges) throws Throwable {
        if (StringUtils.isEmpty(title)) {
            return;
        }
        List<Map<String, String>> maps = new ArrayList<>(1);
        maps.add(DataTableUtils.asMap(WhiteBoard.resolve(owner, belowChanges)));
        servicingProviderIsWithBelowChanges(title, maps);
    }

    @And("^paan provider is \"([^\"]*)\"$")
    public void paanProviderIs(String title) throws Throwable {
        if (StringUtils.isEmpty(title)) {
            return;
        }
        title = WhiteBoard.resolve(owner, title);
        Map<String, String> pf = ExcelLib.instance(ExcelLib.LIB_PP).getObjectByTitle(title);
        Assert.assertNotNull(pf);
        WhiteBoard.getInstance().putMap(owner, ExcelLib.THE_PAAN_PROVIDER, pf);

        //for report
        scenario.write(title + "=" + WhiteBoard.getInstance().protect(pf));
    }

    @And("^paan provider is \"([^\"]*)\" with below changes$")
    public void paanProviderIsWithBelowChanges(String title, List<Map<String, String>> belowChanges) throws Throwable {
        if (StringUtils.isEmpty(title)) {
            return;
        }
        title = WhiteBoard.resolve(owner, title);
        Map<String, String> pf = ExcelLib.instance(ExcelLib.LIB_PP).getObjectByTitle(title);
        Assert.assertNotNull(pf);
        Map<String, String> updates = WhiteBoard.resolve(owner, belowChanges.get(0));
        Assert.assertNotNull(updates);
        pf.putAll(updates);
        WhiteBoard.getInstance().putMap(owner, ExcelLib.THE_PAAN_PROVIDER, pf);

        //for report
        scenario.write(title + "=" + WhiteBoard.getInstance().protect(pf));
    }

    @And("^paan provider is \"([^\"]*)\" with \"([^\"]*)\"$")
    public void paanProviderIsWith(String title, String belowChanges) throws Throwable {
        if (StringUtils.isEmpty(title)) {
            return;
        }
        List<Map<String, String>> maps = new ArrayList<>(1);
        maps.add(DataTableUtils.asMap(WhiteBoard.resolve(owner, belowChanges)));
        paanProviderIsWithBelowChanges(title, maps);
    }

    @And("^profile is \"([^\"]*)\"$")
    public void profileIs(String title) throws Throwable {
        if (StringUtils.isEmpty(title)) {
            return;
        }
        title = WhiteBoard.resolve(owner, title);
        Map<String, String> pf = ExcelLib.instance(ExcelLib.LIB_AUTH_PROFILE).getObjectByTitle(title);
        Assert.assertNotNull(pf);
        WhiteBoard.getInstance().putMap(owner, ExcelLib.THE_AUTH_PROFILE, pf);

        //for report
        scenario.write(title + "=" + WhiteBoard.getInstance().protect(pf));
    }

    @And("^profile is \"([^\"]*)\" with below changes$")
    public void profileIsWithBelowChanges(String title, List<Map<String, String>> belowChanges) throws Throwable {
        if (StringUtils.isEmpty(title)) {
            return;
        }
        title = WhiteBoard.resolve(owner, title);
        Map<String, String> pf = ExcelLib.instance(ExcelLib.LIB_AUTH_PROFILE).getObjectByTitle(title);
        Assert.assertNotNull(pf);

        Map<String, String> updates = WhiteBoard.resolve(owner, belowChanges.get(0));
        Assert.assertNotNull(updates);
        pf.putAll(updates);
        WhiteBoard.getInstance().putMap(owner, ExcelLib.THE_AUTH_PROFILE, pf);

        //for report
        scenario.write(title + "=" + WhiteBoard.getInstance().protect(pf));


        {
            String t = pf.get(MBM.USER_TITLE);
            if (!StringUtils.isEmpty(t)) {
                List<Map<String, String>> changes = new ArrayList<>(1);
                changes.add(updates);
                userIsWithBelowChanges(t, changes);
            }
        }

        {
            String t = pf.get(MBM.MEMB_TITLE);
            if (!StringUtils.isEmpty(t)) {
                List<Map<String, String>> changes = new ArrayList<>(1);
                changes.add(updates);
                memberIsWithBelowChanges(t, changes);
            }
        }

        {
            String t = pf.get(MBM.RP_TITLE);
            if (!StringUtils.isEmpty(t)) {
                List<Map<String, String>> changes = new ArrayList<>(1);
                changes.add(updates);
                requestingProviderIsWithBelowChanges(t, changes);
            }
        }

        {
            String t = pf.get(MBM.SP_TITLE);
            if (!StringUtils.isEmpty(t)) {
                List<Map<String, String>> changes = new ArrayList<>(1);
                changes.add(updates);
                servicingProviderIsWithBelowChanges(t, changes);
            }
        }

        {
            String t = pf.get(MBM.PP_TITLE);
            if (!StringUtils.isEmpty(t)) {
                List<Map<String, String>> changes = new ArrayList<>(1);
                changes.add(updates);
                paanProviderIsWithBelowChanges(t, changes);
            }
        }

    }

    @And("^profile is \"([^\"]*)\" with \"([^\"]*)\"$")
    public void profileIsWith(String title, String belowChanges) throws Throwable {
        if (StringUtils.isEmpty(title)) {
            return;
        }
        List<Map<String, String>> maps = new ArrayList<>(1);
        maps.add(DataTableUtils.asMap(WhiteBoard.resolve(owner, belowChanges)));
        profileIsWithBelowChanges(title, new ArrayList<>());
    }

    @Given("^\"([^\"]*)\" is reserved for \"([^\"]*)\" minutes$")
    public void isReservedForMinutes(String title, String inMinutes) throws Throwable {
        if (StringUtils.isEmpty(title)) {
            return;
        }
        Map<String, String> pf = ExcelLib.instance(ExcelLib.LIB_MEMB).getObjectByTitle(title, owner, inMinutes);
        WhiteBoard.getInstance().putMap(owner, ExcelLib.THE_MEMBER, pf);

        //for report
        scenario.write(title + "=" + WhiteBoard.getInstance().protect(pf));
    }

    @Given("^below profiles are appended to \"([^\"]*)\" with title column \"([^\"]*)\"$")
    public void belowProfilesAreAppendedToWithKeyColumn(String libKey, String titleKey, List<Map<String, String>> data0) throws Throwable {
        ExcelLib lib = ExcelLib.instance(libKey);
        List<Map<String, String>> data = WhiteBoard.resolve(owner, data0);
    }
}
