package atdd.test.stepdefinitions.common;

import atdd.common.ScenarioLogger;
import atdd.dao.mbm.HscDao;
import atdd.dao.mbm.MyBatisConnectionFactory;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.stepsets.AuthorizationRequest;
import atdd.test.stepsets.Login;
import atdd.utils.ExcelLib;
import atdd.utils.RestUtility;
import atdd.utils.WhiteBoard;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import java.util.List;
import java.util.Map;

public class RestStepDefinition {
    public static final Logger log = Logger.getLogger(RestStepDefinition.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }

    @When("^authorization request \"([^\"]*)\" is refreshed$")
    public void authorizationRequestIsRefreshed(String authObjectNameOrAuthNumber) throws Throwable {
        authObjectNameOrAuthNumber = WhiteBoard.resolve(owner, authObjectNameOrAuthNumber);
        log.warn("authObjectNameOrAuthNumber=" + authObjectNameOrAuthNumber);

        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        String hscId = null;
        AuthorizationRequest authorizationRequest = new AuthorizationRequest(scenario, driver());
        if (authorizationRequest.tryRestore(authObjectNameOrAuthNumber, pf) > 0) {
            Map<String, String> hscSnapshot = WhiteBoard.getInstance().getMap(owner, authObjectNameOrAuthNumber + "_" + AuthorizationRequest.OUTCOME_HSC_SNAPSHOT);
            hscId = null == hscSnapshot ? null : hscSnapshot.get("hsc-hsc_id");
        } else {
            try {
                authObjectNameOrAuthNumber = AuthorizationRequest.getAuthNumber(owner, authObjectNameOrAuthNumber);
                Map<String, Object> hsc = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectByAuthNumber(authObjectNameOrAuthNumber).get(0);
                hscId = "" + hsc.get("hsc_id");
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }

        Assert.assertTrue("Refresh success", AuthorizationRequest.retryRefresh(scenario, driver(), Long.parseLong(hscId)));
    }

    @Given("^authorization request \"([^\"]*)\" is resent$")
    public void authorizationRequestIsResent(String authObjectNameOrAuthNumber) throws Throwable {
        authObjectNameOrAuthNumber = WhiteBoard.resolve(owner, authObjectNameOrAuthNumber);
        log.warn("authObjectNameOrAuthNumber=" + authObjectNameOrAuthNumber);

        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        String hscId = null;
        AuthorizationRequest authorizationRequest = new AuthorizationRequest(scenario, driver());
        if (authorizationRequest.tryRestore(authObjectNameOrAuthNumber, pf) > 0) {
            Map<String, String> hscSnapshot = WhiteBoard.getInstance().getMap(owner, authObjectNameOrAuthNumber + "_" + AuthorizationRequest.OUTCOME_HSC_SNAPSHOT);
            hscId = null == hscSnapshot ? null : hscSnapshot.get("hsc-hsc_id");
        } else {
            try {
                Map<String, Object> hsc = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectByAuthNumber(authObjectNameOrAuthNumber).get(0);
                hscId = "" + hsc.get("hsc_id");
            } catch (Exception e1) {
                throw new RuntimeException(e1);
            }
        }

        WebDriver webDriver = Login.login(scenario, pf);
        String resBody = new RestUtility(scenario, webDriver).resend(hscId);
        log.warn("resBody = " + resBody);
        validateResendResponseBody(resBody, hscId);
    }

    private void validateResendResponseBody(String resBody, String hscId) {
        Assert.assertNotNull(resBody);
        Assert.assertTrue(resBody.contains("\"statExists\":false"));
        Assert.assertTrue(resBody.contains("\"warnExists\":false"));
        Assert.assertTrue(resBody.contains("\"errorExists\":false"));
        Assert.assertTrue(resBody.contains("\"hscID\":" + hscId));
    }

    @Given("^call member query service for member with subscriber id \"([^\"]*)\"$")
    public void callMemberQueryServiceForMemberWithSubscriberId(String subscriberId) throws Throwable {
        String resBody = new RestUtility(scenario, Login.login(scenario)).memberQuery(subscriberId);
        scenarioLogger.warn("Member Query service response for " + subscriberId + ": " + resBody);
    }

    @Given("^call member query service for members with below subscriber id's$")
    public void callMemberQueryServiceForMembersWithBelowSubscriberIdS(List<String> subscriberIds) throws Throwable {
        for (String sid : subscriberIds) {
            callMemberQueryServiceForMemberWithSubscriberId(sid);
        }
    }
}

