package atdd.test.stepdefinitions.common;

import atdd.common.ScenarioLogger;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.stepsets.Login;
import atdd.utils.TestUtils;
import atdd.utils.WhiteBoard;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import java.util.List;
import java.util.Map;

public class SecuritySettingsDefinition {
    public static final Logger log = Logger.getLogger(SecuritySettingsDefinition.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }

    @And("^user clicks on \"([^\"]*)\" link on User Security Settings page$")
    public void userClicksOnLinkOnUserSecuritySettingsPage(String adduser) throws Throwable {
        obj().CommonPage.clickOnHyperlink(adduser);
    }

    @Then("^user adds below data on User Security Settings page$")
    public void userAddsBelowDataOnUserSecuritySettingsPage(List<Map<String, String>> maps) throws Throwable {
        maps = WhiteBoard.resolve(owner, maps);
        TestUtils.wait(2);
        obj().UserSecuritySettingsPage.enterDataOnUserSecurityPage(maps);
    }


    @And("^user enters \"([^\"]*)\" into User Security Settings page as \"([^\"]*)\"$")
    public void userEntersIntoUserSecuritySettingsPageAs(String value, String label) throws Throwable {
        obj().UserSecuritySettingsPage.enterinfoOnSecurityPage(value, label);
    }

    @Then("^user select \"([^\"]*)\" from User Role dropdown$")
    public void userSelectFromUserRoleDropdown(String dropdownValue) throws Throwable {
        obj().UserSecuritySettingsPage.selectDropdownValue(dropdownValue);
    }

    @Then("^user select \"([^\"]*)\" from User Credentials dropdown$")
    public void userSelectFromUsercredentialsDropdown(String dropdownValue) throws Throwable {
        obj().UserSecuritySettingsPage.selectUserCeredentialsDropdownValue(dropdownValue);
    }

    @Then("^user verifies the User Credentials dropdown list contains only options in below Order$")
    public void user_verifies_the_User_Credentials_dropdown_list_contains_only_options_in_below_Order(List<List<String>> data) throws Throwable {
        obj().UserSecuritySettingsPage.verifyDropdownList(data);

    }
}

