package atdd.test.stepdefinitions.dashboard;

import atdd.common.ScenarioLogger;
import atdd.dao.mbm.HscDao;
import atdd.dao.mbm.MyBatisConnectionFactory;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.stepsets.Login;
import atdd.utils.*;
import cucumber.api.DataTable;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;


public class DashboardStepDefinition {

    public static final Logger log = Logger.getLogger(DashboardStepDefinition.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }

    @And("^User checks that Status is Completed on Search Dashboard page$")
    public void user_checks_Status() throws Throwable {
        obj().Dashboard.check_Status_SearchSubmitted();

    }

    @And("^User checks that End Date is blank on Search Dashboard page$")
    public void user_checks_EndDate() throws Throwable {
        obj().Dashboard.check_EndDate_SearchSubmitted();

    }

    @When("^user clicks on Create New Request link in the submitted prior authorization requests widget$")
    public void user_clicks_on_Create_New_Request_link_in_the_submitted_prior_authorization_requests_widget() throws Throwable {
        obj().Dashboard.createNewAuthFromPriorAuthReqWidget();
    }

    @When("^user clicks on Create New Request link in the draft prior authorization requests widget$")
    public void user_clicks_on_Create_New_Request_link_in_the_draft_prior_authorization_requests_widget() throws Throwable {
        obj().Dashboard.createNewAuthFromDraftsWidget();
    }

    @And("^User should see static content \"([^\"]*)\"$")
    public void userShouldSeeStaticContent(String staticContent) throws Throwable {
        obj().Dashboard.verifyStaticContent(staticContent);
    }

    /**
     * Verify Clone Icon is not present on the Dashboard
     */
    @And("^User validates clone icon is not visible on the dashboard$")
    public void userValidatesCloneIconIsNotVisibleOnPriorAuthSearchSubmittedPage() throws Throwable {
        obj().Dashboard.verifyCloneIconLocatorNoPresent();
    }


    @Then("^User should verify top ten submitted authorizations that they most recently touched$")
    public void userShouldVerifyTopTenSubmittedAuthorizationsThatTheyMostRecentlyTouchedBy() throws Throwable {
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        List<Map<String, Object>> hsc = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).getTop10SubmittedAuthorizationsThatTheyMostRecentlyTouchedByOps(pf.get(MBM.USER_USERUID));
        obj().Dashboard.verifyTop10SubmittedAuthorizations(hsc);
    }

    /**
     * This step valdiates the sequence of widgets displayed on UI
     *
     * @param userType - Type of user you logged in with
     *                 firstWidget/secondWidget/thirdWidget - Widgets on the Dashboard page
     */
    @And("^User validates dashboard widget for \"([^\"]*)\" in below sequence$")
    public void user_validates_dashboard_widget_for_in_below_sequence(String userType, DataTable widgets) throws Throwable {
        //Getting params
        List<Map<String, String>> list = widgets.asMaps(String.class, String.class);
        String firstWidget = list.get(0).get("First Widget");
        String secondWidget = list.get(0).get("Second Widget");
        String thirdWidget = list.get(0).get("Third Widget");

        obj().Dashboard.verifyWidgetSequence(userType, firstWidget, secondWidget, thirdWidget);
    }

    @Then("^User should verify top ten drafts that they most recently touched$")
    public void userShouldVerifyTopTenDraftsThatTheyMostRecentlyTouched() throws Throwable {
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        List<Map<String, Object>> hsc = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).verifyTop10Drafts(pf.get(MBM.USER_USERUID));
        obj().Dashboard.verifyDrafts(hsc);

    }

    @Then("^User should verify top ten submitted authorizations that are updated on Dashboard$")
    public void userShouldVerifyTopTenSubmittedAuthorizationsThatAreUpdatedOnDashboard() throws Throwable {
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        List<Map<String, Object>> hsc = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).getTop10SubmittedAuthorizationsThatTheyMostRecentlyTouchedByProvider(pf.get(MBM.USER_USERUID));
        obj().Dashboard.verifySubmittedByProvider(hsc);
    }

    @And("^user switches from UHC to BCBS$")
    public void userSwitchesFromUHCToBCBS() throws Throwable {
        obj().Dashboard.clickSwitchPayers();
    }

    @And("^user switch from UHC to BCBS$")
    public void userSwitchFromUHCToBCBS() throws Throwable {
        obj().Dashboard.clickSwitchForBcbs();
    }

    @And("^user should redirect to BCBS homepage$")
    public void userShouldRedirectToBCBSHomepage() throws Throwable {
        obj().Dashboard.verifyUserRedirectedToBCBSHompage();
    }

    @And("^user switches from BCBS to UHC$")
    public void userSwitchesFromBCBSToUHC() throws Throwable {
        obj().Dashboard.clickSwitchPayers();
    }

    @And("^user switch from BCBS to UHC$")
    public void userSwitchFromBCBSToUHC() throws Throwable {
        obj().Dashboard.clickSwitchForUhc();
    }

    @And("^user should redirect to UHC homepage$")
    public void userShouldRedirectToUHCHomepage() throws Throwable {
        obj().Dashboard.verifyUserRedirectedToUHCHompage();
    }

    @And("^user should not see any switch payer button$")
    public void userShouldNotSeeAnySwitchPayerButton() throws Throwable {
        obj().Dashboard.verifyUserShouldNotAnySeeSwitchPayersButton();
    }

    /**
     * activity tracking widget on dashboard
     *
     * @param prefix
     * @param keyHeader
     */
    @And("^Activity Tracking items are extracted with prefix \"([^\"]*)\" and key header \"([^\"]*)\"$")
    public void activityTrackingItemsAreExtractedWithPrefixAndKeyHeader(String prefix, String keyHeader) throws Throwable {
        TestUtils.wait(3);
        TestUtils.extractGridToWhiteBoard(driver(), scenario, prefix, keyHeader, obj().Dashboard.activityTrackingWidget_XPATH, false, false);
    }

    /**
     * extracting comments, call back number and rols from UI table
     *
     * @param prefix
     */
    @And("^Activity Tracking sub items are extracted with prefix \"([^\"]*)\" and key header$")
    public void userClicksOpenDrawerOnActivityTrackingAndValidatesAsBelow(String prefix) throws Throwable {
        int size = driver().findElements(By.xpath("//table[@id='viewActivityTrackingOperationID']/tbody//td[1]/span")).size();
        Map<String, Map<String, String>> namedMaps = new LinkedHashMap<>(size);

        for (int i = 1; i <= size; i++) {
            Map<String, String> maps = new LinkedHashMap<>(size);
            String xpath = "(//table[@id='viewActivityTrackingOperationID']/tbody//td[1]/span)[" + i + "]";
            TestUtils.wait(5);
            TestUtils.click(driver(), By.xpath(xpath));
            String commentsXpath = "(//table[@id='viewActivityTrackingOperationID']/tbody//td[@colspan='5']//div/span/label)[" + i + "]";
            String commentsValueXpath = "(//table[@id='viewActivityTrackingOperationID']/tbody//td[@colspan='5']//div)[" + i + "]";

            String callBackNumberXpath = "(//table[@id='viewActivityTrackingOperationID']/tbody//td[@colspan='1']//div/span/label)[" + i + "]";
            int j = i + i;
            String callBackNumberValueXpath = "(//table[@id='viewActivityTrackingOperationID']/tbody//td[@colspan='1']//div)[" + j + "]";

            String rolexpath = "(//table[@id='viewActivityTrackingOperationID']/tbody//td[@colspan='2']//div/span/label)[" + i + "]";
            String roleValuexpath = "(//table[@id='viewActivityTrackingOperationID']/tbody//td[@colspan='2']//div)[" + i + "]";

            maps.put(driver().findElement(By.xpath(commentsXpath)).getText().trim(), driver().findElement(By.xpath(commentsValueXpath)).getText().split("\n\n\n")[1]);
            maps.put(driver().findElement(By.xpath(rolexpath)).getText().trim(), driver().findElement(By.xpath(roleValuexpath)).getText().split("\n\n\n")[1]);
            maps.put(driver().findElement(By.xpath(callBackNumberXpath)).getText().trim(), driver().findElement(By.xpath(callBackNumberValueXpath)).getText().split("\n\n\n")[1]);
            namedMaps.put(Integer.toString(i), maps);
        }
        WhiteBoard.storeMaps(owner, prefix, Conf.getOutputPath(), namedMaps);
    }

    @Then("^User verifies restrict policy message displayed in the first record in Draft and Activity$")
    public void userVerifiesRestrictPolicyMessageDisplayedInTheFirstRecordInDraftAndActivity() throws Throwable {

        obj().Dashboard.verifyRestrictedMessageDisplayed("DRAFT");
        obj().Dashboard.verifyRestrictedMessageDisplayed("ACTIVITY");

    }

    @And("^User verifies restrict policy message not displayed in the first record in Submitted Authorizations and Activity$")
    public void userVerifiesRestrictPolicyMessageNotDisplayedInTheFirstRecordInSubmittedAuthorizationsAndActivity() throws Throwable {

        obj().Dashboard.verifyRestrictedMessageNotDisplayed("SUBMITTED AUTHORIZATION");
        obj().Dashboard.verifyRestrictedMessageNotDisplayed("ACTIVITY");

    }

    @And("^User verifies restrict policy message displayed in the first record in Submitted Authorizations and Activity$")
    public void userVerifiesRestrictPolicyMessageDisplayedInTheFirstRecordInSubmittedAuthorizationsAndActivity() throws Throwable {

        obj().Dashboard.verifyRestrictedMessageDisplayed("SUBMITTED AUTHORIZATION");
        obj().Dashboard.verifyRestrictedMessageDisplayed("ACTIVITY");
    }

    @Then("^User verifies restrict policy message not displayed in the first record in Draft and Activity$")
    public void userVerifiesRestrictPolicyMessageNotDisplayedInTheFirstRecordInDraftAndActivity() throws Throwable {

        obj().Dashboard.verifyRestrictedMessageNotDisplayed("DRAFT");
        obj().Dashboard.verifyRestrictedMessageNotDisplayed("ACTIVITY");
    }

    @And("^User should verify restricted message displayed in Activity in Home page$")
    public void userShouldVerifyRestrictedMessageDisplayedInActivityInHomePage() throws Throwable {

        obj().Dashboard.verifyRestrictedMessageDisplayed("ACTIVITY");
    }

    @And("^User verify restricted policy message not displayed in Home page$")
    public void userVerifyRestrictedPolicyMessageNotDisplayedInHomePage() throws Throwable {

        obj().Dashboard.verifyRestrictedMessageNotDisplayed("ACTIVITY");
    }

    @And("^User Navigate to Global Navigation Select \"([^\"]*)\" and Select Sub Menu \"([^\"]*)\"$")
    public void globalNavigationMenuDropDown(String globalNavigationMenu, String subMenu) throws Throwable {
        obj().Dashboard.clickGlobalNavigationMenu(globalNavigationMenu, subMenu);
    }

    @And("^user should verify \"([^\"]*)\" present in the ActivityTracking widget in HomePage$")
    public void userShouldVerifyPresentInTheActivityTrackingWidgetInHomePage(String activityType) throws Throwable {
        obj().Dashboard.validateActivityType(activityType);
    }

    @And("User should verify \"([^\"]*)\" Column is displayed in Draft Authorization Request Table on home page$")
    public void userShouldVerifyColumnIsDisplayedInDraftAuthorizationRequestTableOnHomePage(String columnName) throws Throwable {
        obj().Dashboard.validateColumnInDraftTable(columnName);
    }


    @And("User should verify \"([^\"]*)\" Column is displayed in Submitted Authorization Request Table on home page$")
    public void userShouldVerifyColumnIsDisplayedInSubmittedAuthorizationRequestTableOnHomePage(String columnName) throws Throwable {
        obj().Dashboard.validateColumnInSubmittedTable(columnName);
    }

    @And("User verify Request Type value as \"([^\"]*)\" present in Draft Authorization Request Table on HomePage$")
    public void userVerifyRequestTypeValueAsPresentInDraftAuthorizationRequestTableOnHomePage(String requestType) throws Throwable {
        obj().Dashboard.validateRequestTypeValueInDraftTable(requestType);
    }


    @And("User verify Request Type value as \"([^\"]*)\" present in Submitted Authorization Request Table on HomePage$")
    public void userVerifyRequestTypeValueAsPresentInSubmittedAuthorizationRequestTableOnHomePage(String requestType) throws Throwable {
        obj().Dashboard.validateRequestTypeValueInSubmittedTable(requestType);
    }


    @And("^User can click on customer selection dropdown$")
    public void userCanClickOnCustomerSelectionDropdown() throws Throwable {
        obj().Dashboard.clickOncustomerDropDown();

    }

    @And("^user should redirect to BCBS homepage for optum care$")
    public void userShouldRedirectToBCBSHomepageForOptumCare() throws Throwable {
        obj().Dashboard.verifyUserRedirectedToBCBSHompageforOPtumcare();

    }

    @And("^user should redirect to UHC homepage for optum care$")
    public void userShouldRedirectToUHCHomepageForOptumCare() throws Throwable {
        obj().Dashboard.verifyUserRedirectedToUHCHompageforOPtumcare();

    }

    @And("^user switch from UHC to Arizona$")
    public void userSwitchFromUHCToArizona() throws Throwable {
        obj().Dashboard.clickSwitchForArizona();

    }

    @And("^user should redirect to Arizona homepage for optum care$")
    public void userShouldRedirectToArizonaHomepageForOptumCare() throws Throwable {
        obj().Dashboard.verifyUserRedirectedToArizonaHompageforOPtumcare();

    }

    @And("^user switch from Arizona to UHC$")
    public void userSwitchFromArizonaToUHC() throws Throwable {
        obj().Dashboard.clickSwitchForUhc();

    }

    @And("^user switch from BCBS to Arizona$")
    public void userSwitchFromBCBSToArizona() throws Throwable {
        obj().Dashboard.clickSwitchBcbsToArizona();

    }

    @And("^user switch from Arizona to BCBS$")
    public void userSwitchFromArizonaToBCBS() throws Throwable {
        obj().Dashboard.clickSwitchArizonaToBcbs();

    }


    @And("^user switch from UHC to Southwest Medical$")
    public void userSwitchFromUHCToSouthwestMedical() throws Throwable {
        obj().Dashboard.clickSwitchUHCToSouthwestMedical();

    }

    @And("^user should redirect to Southwest Medical homepage for optum care$")
    public void userShouldRedirectToSouthwestMedicalHomepageForOptumCare() throws Throwable {
        obj().Dashboard.verifyUserRedirectedToSouthwestMedicalHompageforOPtumcare();

    }

    @And("^user switch from Southwest Medical to UHC$")
    public void userSwitchFromSouthwestMedicalToUHC() throws Throwable {
        obj().Dashboard.clickSwitchSouthwestMedicalToUHC();

    }

    @And("^user switch from BCBS to Southwest Medical$")
    public void userSwitchFromBCBSToSouthwestMedical() throws Throwable {
        obj().Dashboard.clickSwitchBcbsToSouthwestMedical();

    }

    @And("^user switch from Southwest Medical to BCBS$")
    public void userSwitchFromSouthwestMedicalToBCBS() throws Throwable {
        obj().Dashboard.clickSwitchSouthwestMedicalToBcbs();

    }

    @Then("^user selects the Open Authorization Edit Icon on the main page$")
    public void user_selects_the_Open_Authorization_Edit_Icon_on_the_main_page() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    obj().Dashboard.clickEditOpenAuthIcon();
    }
}

