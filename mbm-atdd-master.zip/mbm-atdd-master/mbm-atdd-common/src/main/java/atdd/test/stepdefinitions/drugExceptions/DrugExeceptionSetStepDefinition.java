package atdd.test.stepdefinitions.drugExceptions;

import atdd.common.ScenarioLogger;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.stepsets.DrugExceptions;
import atdd.test.stepsets.Login;
import atdd.utils.WhiteBoard;
import cucumber.api.DataTable;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import java.util.List;
import java.util.Map;

public class DrugExeceptionSetStepDefinition {
    public static final Logger log = Logger.getLogger(DrugExeceptionSetStepDefinition.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }





    @Then("^User verify the Search fields in the Drug Exception Screen$")
    public void user_verify_the_Search_fields_in_the_Drug_Exception_Screen(DataTable arg1) throws Throwable {
        List<String> expectedLabelvalues = arg1.asList(String.class);
        new DrugExceptions(scenario, driver()).validateSearchFieldInDrugExceptionScreen(expectedLabelvalues);

    }

    @Then("^User validates table header in Drug Exceptions screen is in below Order$")
    public void user_validates_table_header_in_Drug_Exceptions_Screen_is_in_below_Order(DataTable arg1) throws Throwable {
        List<String> expectedLabelList = arg1.asList(String.class);
        new DrugExceptions(scenario, driver()).validatePaginationHeader(expectedLabelList);
    }

    @Then("^User clicks Add Drugs Exception Link$")
    public void User_clicks_Add_Drugs_Exception_Link() throws Throwable {
        new DrugExceptions(scenario, driver()).clickOnAddDrugException();
    }

    @Then("^User performs field Validation on Drugs Exception Page$")
    public void User_performs_field_Validation_on_Drugs_Exception_Page(DataTable arg1) throws Throwable {
        List<String> expectedLabelvalues = arg1.asList(String.class);
        new DrugExceptions(scenario, driver()).fieldValidation(expectedLabelvalues);
    }

    @Then("^User adds below information on Add Drugs Exception Pop Up Page$")
    public void User_Add_Below_Information_On_Add_Drugs_Exception_Pop_Up_Page(DataTable dataTable) throws Throwable {
        List<Map<String, String>> maps = WhiteBoard.resolve(owner, dataTable.asMaps(String.class, String.class));
        Map<String, String> map = null;
        for (Map<String, String> m : maps) {
            map = m;
            new DrugExceptions(scenario, driver()).enterfieldValues(map);
        }
    }

    /**
     * User searches the New Added Drugs based on criteria provided in @param dataTable
     *
     * @param dataTable
     * @throws Throwable
     */
    @And("^user searches the added Drug Exceptions by below criteria verifies the data is displayed$")
    public void userSearchesTheAddedDrugExceptionsByBelowCriteriaVerifiesTheDataIsDisplayed(DataTable dataTable) throws Throwable {
        List<Map<String, String>> maps = WhiteBoard.resolve(owner, dataTable.asMaps(String.class, String.class));
        Map<String, String> map = null;
        for (Map<String, String> m : maps) {
            map = m;
            new DrugExceptions(scenario, driver()).search(map);
        }
    }


    @Then("^user adds Drug on Drug Exception$")
    public void userAddsDrugOnDrugException(DataTable dataTable) throws Throwable {
        List<Map<String, String>> maps = WhiteBoard.resolve(owner, dataTable.asMaps(String.class, String.class));
        Map<String, String> map = null;
        for (Map<String, String> m : maps) {
            map = m;
            new DrugExceptions(scenario, driver()).addDrug(map);
        }
    }

    @And("^user deletes the drug from Drug Exception$")
    public void userDeletesTheDrugFromDrugException(DataTable dataTable) throws Throwable {
        List<Map<String, String>> maps = WhiteBoard.resolve(owner, dataTable.asMaps(String.class, String.class));
        Map<String, String> map = null;
        for (Map<String, String> m : maps) {
            map = m;
            new DrugExceptions(scenario, driver()).deleteDrug(map);
        }
    }


}
