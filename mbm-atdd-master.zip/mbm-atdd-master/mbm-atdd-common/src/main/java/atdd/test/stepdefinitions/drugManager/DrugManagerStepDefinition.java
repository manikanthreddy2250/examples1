package atdd.test.stepdefinitions.drugManager;

import atdd.common.ScenarioLogger;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.shared.BaseCucumber;
import atdd.test.shared.Globals;
import atdd.test.stepsets.DrugPolicyMaintenance;
import atdd.test.stepsets.Login;
import atdd.utils.TestUtils;
import atdd.utils.WhiteBoard;
import cucumber.api.DataTable;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import java.util.List;
import java.util.Map;

public class DrugManagerStepDefinition {
    public static final Logger log = Logger.getLogger(DrugManagerStepDefinition.class.getName());
    static String globalValue = null;

    private ScenarioLogger scenarioLogger = null;
    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);

    }

    TestUtils utils = BaseCucumber.utils;
    Globals gv = BaseCucumber.gv;


    @Then("^user should see Search and Clear buttons$")
    public void user_should_see_Search_and_Clear_buttons() throws Throwable {
        obj().DrugManagerPage.validateSearchClearButtons();
    }

    @Then("^user should validate default message on results grid")
    public void user_should_validate_the_results_grid_on_the_Traversal_Maintenance_page() throws Throwable {
        obj().DrugManagerPage.validateDefaultSearchResults();
    }

    @And("Verify Elements with text is visible on the Drug Manager page")
    public void verifyElementsWithTextIsVisibleOnTheDrugManagerPage(DataTable test) throws Throwable {
        List<List<String>> data = test.raw();
        obj().DrugManagerPage.checkElementsByText(data);
    }

    @And("Verify Elements with text is visible on the Add Drug Popup")
    public void verifyElementsWithTextIsVisibleOnTheAddDrugPopup(DataTable test) throws Throwable {
        List<List<String>> data = test.raw();
        obj().DrugManagerPage.checkPopupElementsByText(data);
    }

    @And("user should see header \"([^\"]*)\" on pop up")
    public void userShouldSeeHeaderOnPopUp(String arg0) throws Throwable {
        obj().DrugManagerPage.checkPopupHeaderByText(arg0);
    }

    @And("user should see Save and Cancel buttons on the Add Drug Popup")
    public void userShouldSeeSaveAndCancelButtons() throws Throwable {
        obj().DrugManagerPage.validateSaveCancelButtons();
    }


    @And("user select auth type as \"([^\"]*)\" on Drug Manager Page")
    public void user_select_auth_type_as_on_Drug_Manager_Page(String string) throws Throwable {
        obj().DrugManagerPage.selectAuthTypeOnDrugManagerPage(string);
    }

    @And("user input drug code as \"([^\"]*)\" on Drug Manager Page")
    public void user_select_drug_code_as_on_Drug_Manager_Page(String string) throws Throwable {
        obj().DrugManagerPage.inputDrugCodeOnDrugManagerPage(string);
    }

    @And("user input brand or generic name as \"([^\"]*)\" on Drug Manager Page")
    public void user_select_benefits_as_on_Drug_Manager_Page(String string) throws Throwable {
        obj().DrugManagerPage.inputBrandOrGenericNameOnDrugManagerPage(string);
    }

    @And("user select payer as \"([^\"]*)\" on Drug Manager Page")
    public void user_select_payer_as_on_Drug_Manager_Page(String string) throws Throwable {
        obj().DrugManagerPage.selectPayerOnDrugManagerPage(string);
    }

    @And("user select start date as \"([^\"]*)\" on Drug Manager Page")
    public void user_select_start_date_as_on_Drug_Manager_Page(String string) throws Throwable {
        obj().DrugManagerPage.enterStartDateOnDrugManagerPage(owner, string);
    }

    @And("user select end date as \"([^\"]*)\" on Drug Manager Page")
    public void user_select_end_date_as_on_Drug_Manager_Page(String string) throws Throwable {
        obj().DrugManagerPage.selectEndDateOnDrugManagerPage(owner, string);
    }

    @Given("user select status as \"([^\"]*)\" on Drug Manager Page")
    public void user_select_drug_type_as_on_Drug_Manager_Page(String string) throws Throwable {
        obj().DrugManagerPage.selectStatusOnDrugManagerPage(string);
    }

    @Given("user check search values are cleared on Drug Manager Page")
    public void user_check_auth_type_value_cleared_on_Drug_Manager_Page() throws Throwable {
        obj().DrugManagerPage.checkSearchValuesAreClearedOnDrugManagerPage();
    }

    @And("user verify search result for \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\" on Drug Manager Page")
    public void userVerifySearchResultForAndOnDrugManagerPage(String arg0, String arg1, String arg2, String arg3) throws Throwable {
        obj().DrugManagerPage.verifySearchResultOnDrugManagerPage(arg0, arg1 + globalValue, arg2, arg3);
    }


    @And("Verify Elements with text or label are required")
    public void userVerifyTheResultGridForDeployedStatusOnDrugManagerPage(DataTable test) throws Throwable {
        List<List<String>> data = test.raw();
        obj().DrugManagerPage.checkRequiredElementsByText(data);
    }

    @And("user verify the result grid on Drug Manager Page")
    public void userVerifyTheResultGridForDraftStatusOnDrugManagerPage() throws Throwable {
        obj().DrugManagerPage.verifyResultGridFirstRowAfterSearchAction();
    }

    @And("user should see close X icon on pop up")
    public void userShouldSeeCloseXIconOnPopUp() throws Throwable {
        obj().DrugManagerPage.checkCloseIconOnPopUpWindow();
    }

    @And("Verify Auth Type dropdown as required element on Drug Manager Page")
    public void verifyAuthTypeDropdownAsRequiredElementOnDrugManagerPage() throws Throwable {
        obj().DrugManagerPage.checkAuthTypeAsRequiredElement();
    }


    @Then("^user verifies dupe check error popup message on add or edit drug model$")
    public void userVerifiesDupeCheckErrorPopupMessageOnAddOrEditDrugModel() throws Throwable {
        obj().DrugManagerPage.verifyDupeCheckErrorMessage();

    }


    @Then("^user add drug as below table$")

    public void userAddDrugAsBelowTable(List<List<String>> data0) throws Throwable {

        List<List<String>> data = WhiteBoard.resolveListOfStringList(owner, data0);

        obj().DrugManagerPage.selectAuthTypeOnAddDrugPopup(data.get(0).get(1));
        obj().DrugManagerPage.selectBenefitsOnAddDrugPopup(data.get(1).get(1));
        obj().DrugManagerPage.selectPayerOnAddDrugPopup(data.get(2).get(1));
        obj().DrugManagerPage.enterStartDateOnAddDrugPopup(data.get(3).get(1), owner);
        obj().DrugManagerPage.selectEndDateOnAddDrugPopup(data.get(4).get(1), owner);
        obj().DrugManagerPage.selectBasedOnLabel(data.get(5).get(0), data.get(5).get(1));
        obj().DrugManagerPage.inputTypeAheadAddDrugPopup(data.get(6).get(0), data.get(6).get(1));
        if (data.get(0).get(1).equals("Outpatient Chemotherapy")) {
            obj().DrugManagerPage.selectDrugRouteOnAddDrugPopup(data.get(8).get(1));
        }

        if (data.get(0).get(1).equals("Specialty Pharmacy")) {
            obj().DrugManagerPage.inputTypeAheadAddDrugPopup(data.get(7).get(0), data.get(7).get(1));
        }

        // enter drug name and generic name
        obj().DrugManagerPage.inputValuesOnEditDrugPopup(data.get(9).get(0), globalValue);
        obj().DrugManagerPage.inputValuesOnEditDrugPopup(data.get(10).get(0), globalValue);


        if (data.get(0).get(1).equals("Specialty Pharmacy")) {
            obj().DrugManagerPage.inputValuesOnEditDrugPopup(data.get(11).get(0), data.get(11).get(1));
        }
        if (data.get(0).get(1).equals("Specialty Pharmacy")) {
            obj().DrugManagerPage.selectBasedOnLabel("HCPCS Units", "G");
        }

    }

    @Then("^user should not see header \"([^\"]*)\"$")
    public void userShouldNotSeeHeader(String arg0) throws Throwable {
        obj().DrugManagerPage.checkPopupHeaderNotVisibleByText(arg0);
    }


    @Then("^user deploy approved drugs from the gird$")
    public void userDeployApprovedSrugsFromTheGird() throws Throwable {
        obj().DrugManagerPage.deployApprovedDrugsfromGrid();

    }


    @And("^user searches drug with following drug details$")
    public void userSearchesDrugWithFollowingDrugDetails(List<List<String>> data0) throws Throwable {

        List<List<String>> data = WhiteBoard.resolveListOfStringList(owner, data0);
        TestUtils.wait(3);
        obj().DrugManagerPage.selectAuthTypeOnDrugManagerPage(data.get(0).get(1));
        obj().DrugManagerPage.inputDrugCodeOnDrugManagerPage(data.get(1).get(1));
        obj().DrugManagerPage.inputBrandOrGenericNameOnDrugManagerPage(data.get(2).get(1) + globalValue);
        obj().DrugManagerPage.selectStatusOnDrugManagerPage(data.get(4).get(1));

    }

    @And("^user edit drug in search result with following drug details$")
    public void userClickEditIconInSearchResult(List<List<String>> data0) throws Throwable {
        List<List<String>> data = WhiteBoard.resolveListOfStringList(owner, data0);
        obj().DrugManagerPage.clickEditIconInSearchResult();
        obj().DrugManagerPage.enterStartDateOnAddDrugPopup(data.get(0).get(1), data.get(1).get(1), data.get(5).get(1), owner);
        obj().DrugManagerPage.selectEndDateOnAddDrugPopup(data.get(2).get(1), owner);
        obj().DrugManagerPage.inputValuesOnEditDrugPopup(data.get(4).get(0), data.get(4).get(1) + globalValue);


    }

    @And("^user verify \"([^\"]*)\" on the result grid$")
    public void userVerifyOnTheResultGrid(String arg0) throws Throwable {
        obj().DrugManagerPage.verifyNOSearchResultOnDrugManagerPage();

    }

    @And("^user click edit icon in search result$")
    public void userClickEditIconInSearchResult() throws Throwable {
        obj().DrugManagerPage.clickEditIconInSearchResult();
    }

    @And("^user Clone drug in search result with following drug details$")
    public void userClickCloneIconInSearchResult(List<List<String>> data0) throws Throwable {
        List<List<String>> data = WhiteBoard.resolveListOfStringList(owner, data0);
        obj().DrugManagerPage.clickCloneIconInSearchResult();
//        obj().DrugManagerPage.selectBenefitsOnAddDrugPopup(data.get(7).get(1));
        obj().DrugManagerPage.selectPayerOnAddDrugPopup(data.get(6).get(1));
        obj().DrugManagerPage.enterStartDateOnAddDrugPopup(data.get(0).get(1), data.get(1).get(1), data.get(5).get(1), owner);
        obj().DrugManagerPage.selectEndDateOnAddDrugPopup(data.get(2).get(1), owner);
        obj().DrugManagerPage.inputValuesOnEditDrugPopup(data.get(3).get(0), data.get(3).get(1));
        obj().DrugManagerPage.inputValuesOnEditDrugPopup(data.get(4).get(0), data.get(4).get(1) + globalValue);

    }

    @Then("^user archive approved drugs from the gird$")
    public void userArchiveApprovedDrugsFromTheGird() throws Throwable {

        obj().DrugManagerPage.archiveApprovedDrugsfromGrid(owner);


    }

    @And("^user stores \"([^\"]*)\"$")
    public void userStores(String arg0) {
        String s = WhiteBoard.resolve(owner, arg0);
        globalValue = s;


    }

    @And("^user input brand or generic name on Drug Manager Page$")
    public void userInputBrandOrGenericNameOnDrugManagerPage() throws Throwable {
        obj().DrugManagerPage.brandOrGenericNameOnDrugManagerPage(globalValue);

    }


    @And("^user deletes the drug added$")
    public void userDeletesTheDrugAdded(DataTable table) throws Throwable {
        List<Map<String, String>> maps = WhiteBoard.resolve(owner, table.asMaps(String.class, String.class));
        Map<String, String> map = null;
        for (Map<String, String> m : maps) {
            map = m;

            DrugPolicyMaintenance dpm = new DrugPolicyMaintenance(scenario, driver());
            dpm.clickonDelete(map);


        }
    }
}





