package atdd.test.stepdefinitions.drugPolicyMaintenance;

import atdd.common.ScenarioLogger;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.stepsets.DrugPolicyMaintenance;
import atdd.test.stepsets.Login;
import atdd.utils.TestUtils;
import atdd.utils.WhiteBoard;
import cucumber.api.DataTable;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import java.util.List;
import java.util.Map;

public class DrugPolicyMaintenanceSetStepDefinition {
    public static final Logger log = Logger.getLogger(DrugPolicyMaintenanceSetStepDefinition.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }

    /**
     * User Enter All the mandatory fields in adds Create New Drug Policy with below information
     *
     * @param dataTable
     */

    @And("^User adds Create New Drug Policy with below information$")
    public void userAddsCreateNewDrugPolicyWithBelowInformation(DataTable dataTable) throws Throwable {
        List<Map<String, String>> maps = WhiteBoard.resolve(owner, dataTable.asMaps(String.class, String.class));
        Map<String, String> map = null;
        for (Map<String, String> m : maps) {
            map = m;

            DrugPolicyMaintenance dpm = new DrugPolicyMaintenance(scenario, driver());
            dpm.createNewDrugPolicy(map);
        }
    }


    @And("^User Edits Drug Policy with below information$")
    public void userEditsDrugPolicyWithBelowInformation(DataTable dataTable) throws Throwable {
        List<Map<String, String>> maps = WhiteBoard.resolve(owner, dataTable.asMaps(String.class, String.class));
        Map<String, String> map = null;
        for (Map<String, String> m : maps) {
            map = m;

            DrugPolicyMaintenance dpm = new DrugPolicyMaintenance(scenario, driver());
            dpm.searchAndEditDrugPolicy(map);
            dpm.clickOnEditPencilIconInPolicyDetailsSession();
            dpm.editPolicyDetails(map);


        }
    }


    @And("^User can search Policy Name in Drug Policy Maintenance session$")
    public void userCanSearchPolicyNameInDrugPolicyMaintenanceSession(DataTable dataTable) throws Throwable {
        List<Map<String, String>> maps = WhiteBoard.resolve(owner, dataTable.asMaps(String.class, String.class));
        new DrugPolicyMaintenance(scenario, driver()).searchAndEditDrugPolicy(maps.get(0));

    }


    @And("^User click on Add Drug Hyper link And Enter Mandatory Fields in Policy Details session$")
    public void userClickOnAddDrugHyperLinkAndEnterMandatoryFieldsInPolicyDetailsSession(DataTable dataTable) throws Throwable {
        List<Map<String, String>> maps = WhiteBoard.resolve(owner, dataTable.asMaps(String.class, String.class));
        Map<String, String> map = null;
        for (Map<String, String> m : maps) {
            map = m;

            DrugPolicyMaintenance dpm = new DrugPolicyMaintenance(scenario, driver());
            dpm.clickOnAddDrugHyperLinkAndEnterMandatoryFields(map);


        }
    }

    @And("^User can click on Edit Pencil icon And Edit the drug name in add drug details session$")
    public void userCanClickOnEditPencilIconAndEditTheDrugNameInAddDrugDetailsSession(DataTable dataTable) throws Throwable {
        List<Map<String, String>> maps = WhiteBoard.resolve(owner, dataTable.asMaps(String.class, String.class));
        Map<String, String> map = null;
        for (Map<String, String> m : maps) {
            map = m;

            DrugPolicyMaintenance dpm = new DrugPolicyMaintenance(scenario, driver());
            dpm.clickOnEditpenciliconAndEnterMandatoryFieldsForAddDrug(map);


        }
    }

    @And("^User can clicks on drug brand name in drug policy details session$")
    public void userCanClicksOnDrugBrandNameInDrugPolicyDetailsSession() throws Throwable {
        DrugPolicyMaintenance dpm = new DrugPolicyMaintenance(scenario, driver());
        dpm.clickOnAddDrugBrandNameinDrugPolicyDetailssession();
    }

    @And("^User click on Add Row Hyper link And Enter Mandatory Fields in Disease State Details$")
    public void userClickOnAddRowHyperLinkAndEnterMandatoryFieldsInDiseaseStateDetails() throws Throwable {

        DrugPolicyMaintenance dpm = new DrugPolicyMaintenance(scenario, driver());
        dpm.clickOnAddRowHyperLinkAndEnterMandatoryFieldsInDiseaseStateDetails();

    }


    @And("^User click on Dosage Details sub tab in Disease State Details session$")
    public void userClickOnDosageDetailsSubTabInDiseaseStateDetailsSession() throws Throwable {
        DrugPolicyMaintenance dpm = new DrugPolicyMaintenance(scenario, driver());
        dpm.clickOnDosageDetailsSubTabInDiseaseStateDetailsSession();
    }

    @And("^User click on Add Row Hyper link And Enter Mandatory Fields in Dosage Details session$")
    public void userClickOnAddRowHyperLinkAndEnterMandatoryFieldsInDosageDetailsSession(DataTable dataTable) throws Throwable {
        List<Map<String, String>> maps = WhiteBoard.resolve(owner, dataTable.asMaps(String.class, String.class));
        Map<String, String> map = null;
        for (Map<String, String> m : maps) {
            map = m;

            DrugPolicyMaintenance dpm = new DrugPolicyMaintenance(scenario, driver());
            dpm.clickOnAddRowHyperLinkAndEnterMandatoryFieldsInDosageDetailsSession(map);

        }
    }

    @And("^User click on Edit Pencil icon And Edit the Disease State Details$")
    public void userClickOnOnEditPencilIconAndEditTheDiseaseStateDetails() throws Throwable {
        DrugPolicyMaintenance dpm = new DrugPolicyMaintenance(scenario, driver());
        dpm.clickOnEditpenciliconAndEnterMandatoryFieldsForDiseaseStateDetails();

    }

    @And("^User click on Edit Pencil icon And Edit the Dosage Details session$")
    public void userClickOnEditPencilIconAndEditTheDosageDetailsSession(DataTable dataTable) throws Throwable {
        List<Map<String, String>> maps = WhiteBoard.resolve(owner, dataTable.asMaps(String.class, String.class));
        Map<String, String> map = null;
        for (Map<String, String> m : maps) {
            map = m;

            DrugPolicyMaintenance dpm = new DrugPolicyMaintenance(scenario, driver());
            dpm.clickOnEditpenciliconAndEnterMandatoryFieldsForDosageDetailssession(map);

        }
    }

    @And("^User CLick on Version History Hyper Link$")
    public void userCLickOnVersionHistoryHyperLink() throws Throwable {
        DrugPolicyMaintenance dpm = new DrugPolicyMaintenance(scenario, driver());
        dpm.clickOnVersionHistoryHyperLinkInDrugPolicyMaintenancePage();
    }

    @When("^user selects to show \"([^\"]*)\" rows per page on Version History pagination$")
    public void userSelectsToShowRowsPerPageOnVersionHistoryPagination(String option) throws Throwable {
        obj().DrugPolicyMaintenancePage.versionHistoryrecordsPerPage(option);

    }


    @And("^(?:User can see columns )(\".*\")(?: on grid$)")
    public void userCanSeeColumnsOnGrid(List<String> columnNames) throws Throwable {
        obj().DrugPolicyMaintenancePage.validateColumnNames(columnNames);

    }

    @And("^User click on the \"([^\"]*)\" button$")
    public void userClickOnTheButton(String arg0) throws Throwable {
        obj().DrugPolicyMaintenancePage.clickonReturnDrugpolicyBtn(arg0);

    }

    @And("^User can click on the Clone icon on the version History page$")
    public void userCanClickOnTheCloneIconOnTheVersionHistoryPage() throws Throwable {
        obj().DrugPolicyMaintenancePage.clickOnclickontheCloneiconontheversionHistorypage();

    }

    @And("^User can enter \"([^\"]*)\" in Clone Policy Version pop up window$")
    public void userCanEnterInClonePolicyVersionPopUpWindow(String effectiveStartDate) throws Throwable {
        obj().DrugPolicyMaintenancePage.enterEffectiveStartDateInClonePolicyVersionPopUpWindow(effectiveStartDate);

    }

    @And("^User click on Edit Pencil icon And Edit Dosage Exception to Disease State Details$")
    public void userClickOnEditPencilIconAndEditDosageExceptionToDiseaseStateDetails() throws Throwable {
        DrugPolicyMaintenance dpm = new DrugPolicyMaintenance(scenario, driver());
        dpm.clickOnEditpenciliconAndEditDosageExceptiontoDiseaseStateDetails();

    }

    @And("^User Click on breadcrumb for Home in Drug Policy Maintenance page$")
    public void userClickOnBreadcrumbForHomeInDrugPolicyMaintenancePage() throws Throwable {
        obj().DrugPolicyMaintenancePage.userClickonbreadcrumbforHomeinDrugPolicyMaintenancepage();

    }

    @And("^User Click on Breadcrumb from Version History to Drug Policy Maintenance$")
    public void userClickOnBreadcrumbFromVersionHistoryToDrugPolicyMaintenance() throws Throwable {
        obj().DrugPolicyMaintenancePage.clickonBreadcrumbfromVersionHistorytoDrugPolicyMaintenance();

    }

    @And("^User click on Breadcrumb from Version History to Home$")
    public void userClickOnBreadcrumbFromVersionHistoryToHome() throws Throwable {
        obj().DrugPolicyMaintenancePage.userclickonBreadcrumbfromVersionHistorytoHome();

    }

    @And("^User click on Breadcrumb from Drug Details to Drug Policy Maintenance$")
    public void userClickOnBreadcrumbFromDrugDetailsToDrugPolicyMaintenance() throws Throwable {
        obj().DrugPolicyMaintenancePage.clickonBreadcrumbfromDrugDetailstoDrugPolicyMaintenance();


    }

    @And("^User click on Breadcrumb from Drug Details to Home$")
    public void userClickOnBreadcrumbFromDrugDetailsToHome() throws Throwable {
        obj().DrugPolicyMaintenancePage.clickonBreadcrumbfromDrugDetailstoHome();

    }

    @And("^User click on the link to the View All Details pop-over$")
    public void userClickOnTheLinkToTheViewAllDetailsPopOver() throws Throwable {
        obj().DrugPolicyMaintenancePage.clickonthelinktotheViewAllDetailspopover();


    }

    @And("^User click on Close to exit from the pop-over$")
    public void userClickOnCloseToExitFromThePopOver() throws Throwable {
        obj().DrugPolicyMaintenancePage.clickonClosetoexitfromthepopover();


    }

    @And("^User click on Add Row Hyper link And type in the Disease State search text box$")
    public void userClickOnAddRowHyperLinkAndTypeInTheDiseaseStateSearchTextBox(DataTable dataTable) throws Throwable {
        List<Map<String, String>> maps = WhiteBoard.resolve(owner, dataTable.asMaps(String.class, String.class));
        new DrugPolicyMaintenance(scenario, driver()).typeToSearchDiseaseState(maps.get(0));


    }


    @And("^User click on Cancel button the New Disease State will not be saved$")
    public void userClickOnCancelButtonTheNewDiseaseStateWillNotBeSaved(DataTable dataTable) throws Throwable {
        List<Map<String, String>> maps = WhiteBoard.resolve(owner, dataTable.asMaps(String.class, String.class));
        new DrugPolicyMaintenance(scenario, driver()).cancelTypeToSearchDiseaseState(maps.get(0));
    }

    @And("^User click on click the Copy in icon drug name under Actions$")
    public void userClickOnClickTheCopyInIconDrugNameUnderActions() throws Throwable {
        obj().DrugPolicyMaintenancePage.clickontheCopyinicondrugnameunderActions();

    }

    @And("^User click on Continue button on popup tool tip$")
    public void userClickOnContinueButtonOnPopupToolTip() throws Throwable {
        obj().DrugPolicyMaintenancePage.clickonContinuebuttononpopuptooltip();

    }

    @And("^User select the Copy One Drug to Another drug$")
    public void userSelectTheCopyOneDrugToAnotherDrug() throws Throwable {
        obj().DrugPolicyMaintenancePage.selecttheCopyOneDrugtoAnotherdrug();

    }

    @And("^User click Save after entering the new Drug Name$")
    public void userClickSaveAfterEnteringTheNewDrugName() throws Throwable {
        obj().DrugPolicyMaintenancePage.clickSaveafterenteringthenewDrugName();

    }

    @And("^success popup message is display$")
    public void successPopupMessageIsDisplay() throws Throwable {
        TestUtils.demoBreakPoint(scenario, driver(), "Success popup displayed after note is saved");
        obj().DrugPolicyMaintenancePage.successPopUpDisplayed();

    }

    @And("^User click on Cancel button on Drug Name window$")
    public void userClickOnCancelButtonOnDrugNameWindow() throws Throwable {
        obj().DrugPolicyMaintenancePage.clickonCancelbuttononDrugNamewindow();

    }

    @And("^User click on click the Copy icon in Disease State Details under Actions$")
    public void userClickOnClickTheCopyIconInDiseaseStateDetailsUnderActions() throws Throwable {
        obj().DrugPolicyMaintenancePage.clickontheCopyiniconDiseaseStateunderActions();

    }

    @And("^User click Save after entering the new Disease State$")
    public void userClickSaveAfterEnteringTheNewDiseaseState() throws Throwable {
        obj().DrugPolicyMaintenancePage.clickSaveafterenteringthenewDrugName();

    }

    @And("^User click on Cancel button on Disease State window$")
    public void userClickOnCancelButtonOnDiseaseStateWindow() throws Throwable {
        obj().DrugPolicyMaintenancePage.clickonCancelbuttononDrugNamewindow();

    }

    @And("^User select the Copy One Disease State to Another Disease State$")
    public void userSelectTheCopyOneDiseaseStateToAnotherDiseaseState() throws Throwable {
        obj().DrugPolicyMaintenancePage.userSelectTheCopyOneDiseaseStateToAnotherDiseaseState();

    }

    @And("^User click on click the Copy icon in the Policy Details$")
    public void userClickOnClickTheCopyIconInThePolicyDetails() throws Throwable {
        obj().DrugPolicyMaintenancePage.clickontheCopyiconinthePolicyDetails();

    }

    @And("^User selects \"([^\"]*)\" Line of Business in Copy Drug Policy$")
    public void userSelectsLineOfBusinessInCopyDrugPolicy(String arg0) throws Throwable {
        obj().DrugPolicyMaintenancePage.selecttheDrugPolicyforonePayerLineofBusiness(arg0);

    }

    @And("^User click on copy icon on pop up window$")
    public void userClickOnCopyIconOnPopUpWindow() throws Throwable {
        obj().DrugPolicyMaintenancePage.clickoncopyicononpopupwindow();

    }

    @And("^User click on Cancel button on pop up window$")
    public void userClickOnCancelButtonOnPopUpWindow() throws Throwable {
        obj().DrugPolicyMaintenancePage.clickonCancelbuttononDrugNamewindow();

    }

    @And("^User click on X icon on Pop up window$")
    public void userClickOnXIconOnPopUpWindow() throws Throwable {
        obj().DrugPolicyMaintenancePage.clickonIconCxbuttononDrugNamewindow();

    }

    @And("^User deletes the added disease state$")
    public void userDeletesTheAddedDiseaseState(DataTable d) throws Throwable {
        List<Map<String, String>> maps = WhiteBoard.resolve(owner, d.asMaps(String.class, String.class));
        new DrugPolicyMaintenance(scenario, driver()).deleteDiseasestate(maps.get(0));
    }

    @And("^User click on Disease State Details sub tab in Disease State Details session$")
    public void userClickOnDiseaseStateDetailsSubTabInDiseaseStateDetailsSession() throws Throwable {
        DrugPolicyMaintenance dpm = new DrugPolicyMaintenance(scenario, driver());
        dpm.clickOnDiseaseStateSubTabInDiseaseStateDetailsSession();
    }
}














