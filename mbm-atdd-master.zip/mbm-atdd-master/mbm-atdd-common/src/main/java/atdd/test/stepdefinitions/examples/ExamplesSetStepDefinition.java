package atdd.test.stepdefinitions.examples;

import atdd.common.ScenarioLogger;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.stepdefinitions.rulesManger.RulesManagerSetStepDefinition;
import atdd.test.stepsets.Examples;
import atdd.test.stepsets.Login;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

public class ExamplesSetStepDefinition {
    public static final Logger log = Logger.getLogger(RulesManagerSetStepDefinition.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;
    private WebDriver driver;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }
    @And("^then soft assertions are processed$")
    public void processSoftAsserts() throws Throwable {
        new Examples(scenario, driver()).processSoftAssertionResults();
    }

    @And("^Hard assert fail on 2nd assert$")
    public void hardAssertDemo() throws Throwable {
        new Examples(scenario, driver()).hardAssertDemo();
    }

    @And("^Soft assert fail on 2nd assert$")
    public void softAssertDemo() throws Throwable {
        new Examples(scenario, driver()).softAssertDemo();
    }

    @And("^Mixed asserts with hard assert passing and softassert failing$")
    public void mixAssertDemo() throws Throwable {
        new Examples(scenario, driver()).mixAssertDemo();
    }

    @And("^Mixed asserts with hard assert passing and softassert passing$")
    public void mixAssertDemoAllPass() throws Throwable {
        new Examples(scenario, driver()).mixAssertDemoAllPass();
    }

    @And("^All softAsserts failing but no assertAll at end$")
    public void noAssertAll() throws Throwable {
        new Examples(scenario, driver()).noAssertAll();
    }
}
