package atdd.test.stepdefinitions.icue;

import atdd.common.ScenarioLogger;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.stepsets.AuthorizationRequest;
import atdd.test.stepsets.Login;
import atdd.test.stepsets.icue.IcueDecision;
import atdd.test.stepsets.icue.IcueInitiateIntake;
import atdd.test.stepsets.icue.IcueSearch;
import atdd.utils.ExcelLib;
import atdd.utils.StringUtils;
import atdd.utils.TestUtils;
import atdd.utils.WhiteBoard;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.Map;

public class IcueSetStepDefinition {
    public static final Logger log = Logger.getLogger(IcueSetStepDefinition.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }

    @When("^user searches the request \"([^\"]*)\" from ICUE system$")
    public void userSearchesTheRequestFromICUESystem(String authObjectNameOrSrnOrVid) throws Throwable {
        authObjectNameOrSrnOrVid = WhiteBoard.resolve(owner, authObjectNameOrSrnOrVid);
        log.warn("userSearchesTheRequestFromICUESystem: " + authObjectNameOrSrnOrVid);

        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        String authNumber = null;
        AuthorizationRequest authorizationRequest = new AuthorizationRequest(scenario, driver());
        if (authorizationRequest.tryRestore(authObjectNameOrSrnOrVid, pf) > 0) {
            authNumber = AuthorizationRequest.getAuthNumber(owner, authObjectNameOrSrnOrVid);
        } else if (null == authNumber) {
            authNumber = AuthorizationRequest.getAuthNumber(owner, authObjectNameOrSrnOrVid);
        } else {
            authNumber = WhiteBoard.resolve(owner, authObjectNameOrSrnOrVid);
        }
        Assert.assertTrue("authNumber should be valid", !StringUtils.isEmpty(authNumber));

        WebDriver webDriver = Login.login(scenario, pf);
        new IcueSearch(scenario, webDriver).search(authNumber);

    }

    @When("^user \"([^\"]*)\" the authorization request \"([^\"]*)\" from ICUE system$")
    public void userTheAuthorizationRequestFromICUESystem(String action, String authObjectNameOrSrnOrVid) throws Throwable {
        action = WhiteBoard.resolve(owner, action);
        authObjectNameOrSrnOrVid = WhiteBoard.resolve(owner, authObjectNameOrSrnOrVid);
        log.warn("userSearchesTheRequestFromICUESystem: " + action + "," + authObjectNameOrSrnOrVid);

        this.userSearchesTheRequestFromICUESystem(authObjectNameOrSrnOrVid);

        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        WebDriver webDriver = Login.login(scenario, pf);
        switch (action) {
            case "approves":
                new IcueDecision(scenario, webDriver).approve();
                break;
            case "denies":
                new IcueDecision(scenario, webDriver).deny();
                break;
            case "cancels":
                new IcueDecision(scenario, webDriver).cancel();
                break;
            case "underAppeals":
                new IcueDecision(scenario, webDriver).underAppeals();
                break;
            case "reconsideration":
                new IcueDecision(scenario, webDriver).reconsideration();
                break;
            case "overridingApprovedToDenied":
                new IcueDecision(scenario, webDriver).overridingApprovedToDenied();
                break;
            default:
                Assert.fail("Invalid action: " + action);
        }

    }


    @And("^User initiates a new HSC Intake in ICUE$")
    public void userInitiatesANewHSCIntake() throws Throwable {
        Map<String, String> pf = ExcelLib.completeProfile(owner, null);
        WebDriver webDriver = Login.login(scenario, pf);
        IcueInitiateIntake intake = new IcueInitiateIntake(scenario, webDriver);
        intake.initiateIntake(pf);
        intake.shortForm(pf);
    }

    @And("^User completes HSC with jcode \"([^\"]*)\" and \"([^\"]*)\" HSC Intake \"([^\"]*)\"$")
    public void userCompletesHSCwithJcode(String jcode, String action, String objectName) throws Throwable {
        IcueInitiateIntake intake = new IcueInitiateIntake(scenario, driver());
        Map<String, String> icueServiceRef = intake.longForm(jcode);
        WhiteBoard.getInstance().putMap(owner, objectName + "_" + AuthorizationRequest.ICUE_SRN, icueServiceRef);

        String authNumber = AuthorizationRequest.getAuthNumber(owner, objectName);

        new IcueSearch(scenario, driver()).search(authNumber);

        switch (action) {
            case "approves":
                new IcueDecision(scenario, driver()).approve();
                break;
            case "denies":
                new IcueDecision(scenario, driver()).deny();
                break;
            case "cancels":
                new IcueDecision(scenario, driver()).cancel();
                break;
            case "pends":
                log.warn("No decision is being given to service lines");
                break;
            case "overridingApprovedToDenied":
                new IcueDecision(scenario, driver()).overridingApprovedToDenied();
                break;
            default:
                Assert.fail("Invalid action: " + action);
        }
    }

    @And("^user stores \"([^\"]*)\" Icue Tab for request \"([^\"]*)\"$")
    public void userStoresIcuePageForRequest(String page, String objectName) throws Throwable {
        IcueInitiateIntake intake = new IcueInitiateIntake(scenario, driver());
        Map<String, String> icueSummary = intake.getOutcome(page);
        WhiteBoard.getInstance().putMap(owner, objectName + "_" + AuthorizationRequest.ICUE_SERVICE_SUMMARY, icueSummary);
    }

    @And("^user navigates to icue menu item \"([^\"]*)\"$")
    public void userNavigatesToIcueMenuItem(String trace) throws Throwable {
        String[] items = trace.split(">");
        if (items.length > 1) {
            for (int i = 0; i < items.length; i++) {
                String item = items[i].trim();
                TestUtils.safeClick(driver(), By.xpath("//a[contains(.,'" + item + "')]"));
            }
        }
    }
}
