package atdd.test.stepdefinitions.icue;

import atdd.test.pageobjects.CommonPageObject;
import atdd.test.shared.BaseCucumber;
import atdd.test.shared.Globals;
import atdd.test.stepsets.Login;
import atdd.utils.Conf;
import atdd.utils.TestUtils;
import atdd.utils.WhiteBoard;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

public class IcueStepDefinition {
    Logger log = Logger.getLogger(this.getClass().getName());
    TestUtils utils = BaseCucumber.utils;
    Globals gv = BaseCucumber.gv;


    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
    }

    @When("^Data from \"([^\"]*)\" Clolumn is \"([^\"]*)\" on the Notification Assignments Icue page$")
    public void enterVendorCaseID(String column, String cellValue) throws Throwable {
        column = WhiteBoard.resolve(owner, column);
        cellValue = WhiteBoard.resolve(owner, cellValue);
        log.warn("column=" + column);
        log.warn("cellValue=" + cellValue);

        obj().Icue.checkHSCAssignmentsColumnElements(column, cellValue);
    }

    @When("^Data from \"([^\"]*)\" Clolumn is \"([^\"]*)\" on the Assignments & Alerts page$")
    public void VerifyAssignmentsAndAlertsData(String column, String cellValue) throws Throwable {
        column = WhiteBoard.resolve(owner, column);
        cellValue = WhiteBoard.resolve(owner, cellValue);
        log.warn("column=" + column);
        log.warn("cellValue=" + cellValue);

        obj().Icue.checkAlertsColumnElements(column, cellValue);
    }

    @And("^User clear the PCP Alerts on the Assignments & Alerts page$")
    public void clearPCPAlerts() throws Throwable {
        obj().Icue.clearPCPAlert();
        obj().Icue.performAction(scenario, "Clear Alerts");
    }

    @And("^User clicks \"([^\"]*)\" Tab on the Notification Icue page$")
    public void clickTabNotofocationPage(String tab) throws Throwable {
        obj().Icue.clickTabOnNotificationPage(tab);
    }

    @And("^User clicks on Search button on the Icue Health Service Case Page page$")
    public void clickSearchHealthService() throws Throwable {
        obj().Icue.clickSearchHealthService();
    }

    @And("^User enters \"([^\"]*)\" Vendor Case ID on the Icue Health Service Case Page page$")
    public void enterVendorCaseID(String caseId) throws Throwable {
        obj().Icue.enterVendorCaseId(caseId);
    }

    @And("^User selects \"([^\"]*)\" option from navigation drop-down on the Icue page$")
    public void clicknavoption(String nav) throws Throwable {
        obj().Icue.selectNavdropDownOption(nav);
    }

    @And("^User clicks on \"([^\"]*)\" navigation drop-down on the Icue page$")
    public void clicknav(String nav) throws Throwable {
        obj().Icue.clickNavdropDown(nav);
    }

    @And("^User enters \"([^\"]*)\" User ID on the Icue Login page$")
    public void enterUserId(String user) throws Throwable {
        String msidUser = System.getenv(user);
        String msIdConfig = Conf.getInstance().getProperty(user);

        //If nothing from Jenkins or bash_profile file
        if (msidUser == null)
            msidUser = msIdConfig;
        //If nothing in the Config
        if (msIdConfig == null && msidUser == null)
            msidUser = user;


        obj().Icue.enterUserId(msidUser);
    }

    @And("^User enters \"([^\"]*)\" user password on the Icue Login page$")
    public void enterUserPass(String pass) throws Throwable {
        String msidPass = System.getenv(pass);
        String msIdPassConfig = Conf.getInstance().getProperty(pass);

        //If nothing from Jenkins or bash_profile file
        if (msidPass == null)
            msidPass = msIdPassConfig;
        //If nothing in the Config
        if (msIdPassConfig == null && msidPass == null)
            msidPass = pass;

        obj().Icue.enterUserPass(msidPass);
    }

    @When("^User selects \"([^\"]*)\" Domain on the Icue Login page$")
    public void selectWidget(String domain) throws Throwable {
        obj().Icue.selectDomain(domain);
    }

    @And("^User clicks on Sign On on the Icue Login page$")
    public void clickSignInLoginPage() throws Throwable {
        obj().Icue.clickSignOn();
    }

    @And("User should verify the error message \"([^\"]*)\" on top of Icue page")
    public void verifyErrorMsgOnIcuePage(String msg) throws Throwable {
        obj().Icue.verifyErrorMessageOnTopOfIcuePage(msg);

    }

    @And("^User checks HSC Status \"([^\"]*)\" on the Notification Icue page$")
    public void userChecksHSCStatusOnTheNotificationIcuePage(String status) throws Throwable {
        obj().Icue.verifyHSCStatus(status);
    }

    @And("^User clicks \"([^\"]*)\" under service ref on Notification Tab$")
    public void userClicksUnderServiceRefOnNotificationTab(String mbm) throws Throwable {
        obj().Icue.clickViewOncologyClinicalInformation(mbm);
        TestUtils.wait(4);

    }

    @And("^User checks \"([^\"]*)\" under HSC Assignments$")
    public void userChecksUnderHSCAssignments(String records) throws Throwable {
        obj().Icue.verifyHSCAssignments(records);
    }

    @And("^User verify \"([^\"]*)\" work queue in left side pane section$")
    public void userVerifyWorkQueueInSidebar(String arg1) throws Throwable {
        obj().Icue.verifyWorkQueueInSidebar(arg1);
    }

    @And("^User verify \"([^\"]*)\" alert name in left side pane section$")
    public void userVerifyAlertsNameInSidebar(String arg1) throws Throwable {
        obj().Icue.verifyAlertsNameInSidebar(arg1);
    }

    @When("^user adds /changes initialDiagnosisDate field on ICUE Diagnosis tab$")
    public void userAddsChangesInitialDiagnosisDateFieldOnICUEDiagnosisTab() {
    }

    @And("^User verifies whether Clinical Status Exception displayed in Notes section$")
    public void userVerifiesWhetherClinicalStatusExceptionDisplayedInNotesSection() throws Throwable {
        obj().Icue.verifyNoteSection("Clinical Status Exception");
    }

    @And("^User selects \"([^\"]*)\" in the Icue page$")
    public void userSelectsInTheIcuePage(String arg0) throws Throwable {
        obj().Icue.clickHealthServiceCase();
    }

    @And("^User verifies whether Cancer Disease state and No Regimen found displayed in Notes section$")
    public void userVerifiesWhetherCancerDiseaseStateAndNoRegimenFoundDisplayedInNotesSection() throws Throwable {
        obj().Icue.verifyNoteSection("Cancer/Disease State Other");
        obj().Icue.verifyNoteSection("No Regimen Match Found");
    }

    @And("^User verifies whether Drug Exception displayed in Notes section$")
    public void userVerifiesWhetherDrugExceptionDisplayedInNotesSection() throws Throwable {
        obj().Icue.verifyNoteSection("Drug Exception");
    }
}
