package atdd.test.stepdefinitions.newlyApprovedDrugs;

import atdd.common.ScenarioLogger;
import atdd.dao.mbm.MyBatisConnectionFactory;
import atdd.dao.mbm.NewProcDao;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.stepsets.Login;
import atdd.test.stepsets.NewlyApprovedDrugs;
import atdd.utils.WhiteBoard;
import cucumber.api.DataTable;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import java.util.List;
import java.util.Map;

public class NewlyApprovedDrugsSetStepDefinition {
    public static final Logger log = Logger.getLogger(NewlyApprovedDrugsSetStepDefinition.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }


    /**
     * User verifies Error message when clicked on Save w/o entering all mandatory fields
     *
     * @param dataTable
     */
    @Then("^User navigates to Add New Drug pop-up and validates the error message$")
    public void user_navigates_to_add_New_Drug_pop_up__and_validates_the_error_message(DataTable dataTable) throws Throwable {
        List<Map<String, String>> maps = WhiteBoard.resolve(owner, dataTable.asMaps(String.class, String.class));
        Map<String, String> map = null;
        for (Map<String, String> m : maps) {
            map = m;
            new NewlyApprovedDrugs(scenario, driver()).navigatetoAddNewDrugPopUpValidateErrorMsg(map);
        }
    }

    /*
      Verify Auth Type Dropdown and Payer Dropdown and the default selected values in Newly Approved Drug Screen
     */
    @Then("^User verify the Search fields in the Newly Approved Drug Screen$")
    public void user_verify_the_Search_fields_in_the_Newly_Approved_Drug_Screen(DataTable arg1) throws Throwable {
        List<String> expectedLabelvalues = arg1.asList(String.class);
        new NewlyApprovedDrugs(scenario, driver()).validateSearchFieldInNewlyApprovedDrugScreen(expectedLabelvalues);

    }

    @Then("^User verify the \"([^\"]*)\" Values in the Newly Approved Drug Screen$")
    public void user_verify_the_Values_in_the_Newly_Approved_Drug_Screen(String arg1, DataTable arg2) throws Throwable {
        List<String> expectedLabelvalues = arg2.asList(String.class);
        new NewlyApprovedDrugs(scenario, driver()).validateDropdownOptionsInNewlyApprovedDrugScreen(arg1, expectedLabelvalues);

    }

    /**
     * User searches the New Added Drugs based on criteria provided in @param dataTable
     *
     * @param dataTable
     * @throws Throwable
     */
    @And("^user searches the New Added Drug by below criteria on the Newly Approved Drugs page$")
    public void userSearchesTheNewAddedDrugByBelowCriteriaOnTheNewApprovedDrugsPage(DataTable dataTable) throws Throwable {
        List<Map<String, String>> maps = WhiteBoard.resolve(owner, dataTable.asMaps(String.class, String.class));
        Map<String, String> map = null;
        for (Map<String, String> m : maps) {
            map = m;
            new NewlyApprovedDrugs(scenario, driver()).search(map);
        }
    }

    /**
     * User Enter All the mandatory fields in Add New Drug Pop-Up Model in Newly Approved Drugs Screen
     *
     * @param dataTable
     */

    @Given("^User adds New Drug with below information$")
    public void user_adds_New_Drug_with_below_information(DataTable dataTable) throws Throwable {
        List<Map<String, String>> maps = WhiteBoard.resolve(owner, dataTable.asMaps(String.class, String.class));
        Map<String, String> map = null;
        for (Map<String, String> m : maps) {
            map = m;
            new NewlyApprovedDrugs(scenario, driver()).addNewDrug(map);
        }
    }




    @Then("^User validates table header in Newly Approved Drug screen is in below Order$")
    public void user_validates_table_header_in_Newly_Approved_Drug_Screen_is_in_below_Order(DataTable arg1) throws Throwable {
        List<String> expectedLabelList = arg1.asList(String.class);
        new NewlyApprovedDrugs(scenario, driver()).validatePaginationHeader(expectedLabelList);
    }

    /**
     * User Verify when New Drug added the record is saved to NEW_proc
     */

    @Then("^User verify record is saved in the Newly Approved Drug Table$")
    public void user_verify_record_is_saved_in_the_Newly_Approved_Drug_Table() throws Throwable {
        NewProcDao dao = new NewProcDao(MyBatisConnectionFactory.getSqlSessionFactory());
        List<Map<String, Object>> newproc = dao.selectByBrandName();
        for (Map<String, Object> entry : newproc) {
            new NewlyApprovedDrugs(scenario, driver()).validateTheRecordsSavedtoDB(entry);
        }

    }

    /**
     * User Deletes the Drug by clicking on Delete Icon based
     * on Search Criteria provided in Newly Approved Drugs Screen
     *
     * @param dataTable
     * @throws Throwable
     */

    @Then("^user removes all New Added Drug on the Newly Approved Drugs page$")
    public void userRemovesAllNewAddedDrugOnTheNewlyApprovedDrugsPage(DataTable dataTable) throws Throwable {
        List<Map<String, String>> data = dataTable.asMaps(String.class, String.class);

        for (Map<String, String> entry : data) {
            new NewlyApprovedDrugs(scenario, driver()).search(entry);
            while (obj().NewlyApprovedDrugsPage.hasResult()) {
                obj().NewlyApprovedDrugsPage.removeFirstResut();
            }
        }
    }

    /**
     * User verifies the Fields position in Add New Drug Pop-Up Model in Newly Approved Drugs Screen
     *
     * @param dataTable
     */

    @When("^User clicks Add New Drug and performs field Validation$")
    public void user_clicks_and_performs_field_Validation(DataTable dataTable) throws Throwable {
        List<String> expectedLabelvalues = dataTable.asList(String.class);
        new NewlyApprovedDrugs(scenario, driver()).fieldValidation(expectedLabelvalues);
    }
}
