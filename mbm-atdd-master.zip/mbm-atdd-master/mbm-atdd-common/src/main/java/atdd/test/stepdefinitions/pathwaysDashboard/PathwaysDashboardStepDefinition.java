package atdd.test.stepdefinitions.pathwaysDashboard;

import atdd.common.ScenarioLogger;
import atdd.dao.mbm.HscDao;
import atdd.dao.mbm.HscSrvcDecnDao;
import atdd.dao.mbm.MyBatisConnectionFactory;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.pageobjects.pageValueObjects.PathwaysDashboard;
import atdd.test.pageobjects.pageValueObjects.PathwaysDashboardDiff;
import atdd.test.pageobjects.pathwaysDashboard.PathwaysDashboardPage;
import atdd.test.stepsets.Login;
import atdd.utils.*;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;
import java.util.TimeZone;

public class PathwaysDashboardStepDefinition {
    public static final Logger log = Logger.getLogger(PathwaysDashboardStepDefinition.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }

    /**
     * collecting pathways shown, selected and total cancer types count
     *
     * @param pathwayShownCount
     * @throws Throwable
     */
    @When("^user extracts Pathways Dashboard page as \"([^\"]*)\"$")
    public void userExtractsPathwaysDashboardPageAs(String pathwayShownCount) throws Throwable {
        TestUtils.wait(20);
        PathwaysDashboardPage pathwaysDashboardPage = new PathwaysDashboardPage(driver());
        pathwaysDashboardPage.setScenarioLogger(scenarioLogger);
        PathwaysDashboard result = pathwaysDashboardPage.collect();
        storeJson(pathwayShownCount, result);

    }

    /**
     * calculates pathways difference
     *
     * @param diffName
     * @param after
     * @param before
     * @throws Throwable
     */

    @When("^pathways dashboard shown difference \"([^\"]*)\" is calculated by \"([^\"]*)\" and \"([^\"]*)\"$")
    public void pathwaysDashboardShownDifferenceIsCalculatedByAnd(String diffName, String after, String before) throws Throwable {
        Class<PathwaysDashboard> clazz = PathwaysDashboard.class;
        String jsonAfter = WhiteBoard.resolve(owner, after);
        PathwaysDashboard pvoAfter = (PathwaysDashboard) QuickJson.readValue(jsonAfter, clazz);
        String jsonBefore = WhiteBoard.resolve(owner, before);
        PathwaysDashboard pvoBefore = (PathwaysDashboard) QuickJson.readValue(jsonBefore, clazz);
        PathwaysDashboardDiff diff = PathwaysDashboardDiff.diff(pvoAfter, pvoBefore);
        String diffJson = QuickJson.prettyJson(diff);
        WhiteBoard.getInstance().putString(owner, WhiteBoard.resolve(owner, diffName), diffJson);
        scenarioLogger.warn(diffName + "=\n" + diffJson);
    }

    /**
     * collecting data from DB for pathways shown and selected
     *
     * @param pathwayShownDbCount
     * @throws Throwable
     */
    @Then("^user extracts Pathways Dashboard db as \"([^\"]*)\"$")
    public void userExtractsPathwaysDashboardDbAs(String pathwayShownDbCount) throws Throwable {
        Map<String, String> pf = WhiteBoard.getInstance().getMap(owner, ExcelLib.THE_REQUESTING_PROVIDER);
        String providerTin = pf.get(MBM.RPPD_PROVIDER_TIN);
        PathwaysDashboardPage po = new PathwaysDashboardPage();
        po.setScenarioLogger(scenarioLogger);
        PathwaysDashboard result = po.collectFromDb(providerTin);
        storeJson(pathwayShownDbCount, result);

    }

    /**
     * calcultaes pathways percentage
     *
     * @param calculatePathways
     * @throws Throwable
     */
    @When("^user calculates pathways percentage as \"([^\"]*)\"$")
    public void userCalculatesPathwaysPercentageAs(String calculatePathways) throws Throwable {
        TestUtils.wait(20);
        PathwaysDashboardPage po = new PathwaysDashboardPage(driver());
        po.setScenarioLogger(scenarioLogger);
        PathwaysDashboard result = po.collectPercentageBefore();
        storeJson(calculatePathways, result);

    }

    /**
     * storing results in json
     *
     * @param json
     * @param result
     */
    private void storeJson(String json, PathwaysDashboard result) {
        String jsonString = QuickJson.writeValueAsString(result);
        json = WhiteBoard.resolve(owner, json);
        WhiteBoard.getInstance().putString(owner, json, jsonString);
    }

    /**
     * extracts pathways percentage from UI
     *
     * @param extractsPathways
     * @throws Throwable
     */
    @Then("^user extracts Pathways Percentage as \"([^\"]*)\"$")
    public void userExtractsPathwaysPercentageAs(String extractsPathways) throws Throwable {
        TestUtils.wait(20);
        PathwaysDashboardPage po = new PathwaysDashboardPage(driver());
        po.setScenarioLogger(scenarioLogger);
        PathwaysDashboard result = po.collectPercentage();
        storeJson(extractsPathways, result);
    }

    /**
     * extratcs cancer types from pathways dashboard
     *
     * @param extractsCancerTypes
     * @throws Throwable
     */

    @When("^user extracts cancer types from Dashboard page as \"([^\"]*)\"$")
    public void userExtractsCancerTypesFromDashboardPageAs(String extractsCancerTypes) throws Throwable {
        TestUtils.wait(20);
        PathwaysDashboardPage po = new PathwaysDashboardPage(driver());
        po.setScenarioLogger(scenarioLogger);
        PathwaysDashboard result = po.collectCancerTypes();
        storeJson(extractsCancerTypes, result);
    }

    /**
     * extracts specific cancer type from dahsboard based on selection
     *
     * @param cancerType
     * @param extractsSpecficCancerTypes
     * @throws Throwable
     */
    @When("^user extracts for \"([^\"]*)\" from Dashboard page as \"([^\"]*)\"$")
    public void userExtractsForFromDashboardPageAs(String cancerType, String extractsSpecficCancerTypes) throws Throwable {
        TestUtils.wait(20);
        PathwaysDashboardPage po = new PathwaysDashboardPage(driver());
        po.setScenarioLogger(scenarioLogger);
        PathwaysDashboard result = po.collectSpecificCancerTypes(cancerType);
        storeJson(extractsSpecficCancerTypes, result);


    }

    /**
     * searches pathways dashboard by TIN
     *
     * @throws Throwable
     */
    @And("^user searches by requesting provider TIN$")
    public void userSearchesByRequestingProviderTIN() throws Throwable {
        if (!TestUtils.isElementVisible(driver(), PathwaysDashboardPage.pathWayWidget)) {
            PathwaysDashboardPage po = new PathwaysDashboardPage(driver());
            po.setScenarioLogger(scenarioLogger);
            Map<String, String> pf = WhiteBoard.getInstance().getMap(owner, ExcelLib.THE_REQUESTING_PROVIDER);
            String providerTin = pf.get(MBM.RPPD_PROVIDER_TIN);
            obj().PathwaysDashboardPage.enterTin(providerTin);
            obj().PathwaysDashboardPage.searchTin();
        }

    }

    /**
     * caclculates specific cancer percentage and stores results in json
     *
     * @param cancerType
     * @param calculatePathways
     * @throws Throwable
     */

    @When("^user calculates specific cancer \"([^\"]*)\" percentage as \"([^\"]*)\"$")
    public void userCalculatesSpecificCancerPercentageAs(String cancerType, String calculatePathways) throws Throwable {
        TestUtils.wait(20);
        PathwaysDashboardPage po = new PathwaysDashboardPage(driver());
        po.setScenarioLogger(scenarioLogger);
        PathwaysDashboard result = po.collectSpecificCancerPercentageBefore(cancerType);
        storeJson(calculatePathways, result);
    }

    /**
     * extracts specific cancer percentage from UI.
     *
     * @param cancerType
     * @param calculatePathways
     * @throws Throwable
     */
    @Then("^user extracts specific cancer \"([^\"]*)\" Percentage as \"([^\"]*)\"$")
    public void userExtractsSpecificCancerPercentageAs(String cancerType, String calculatePathways) throws Throwable {
        TestUtils.wait(20);
        PathwaysDashboardPage po = new PathwaysDashboardPage(driver());
        po.setScenarioLogger(scenarioLogger);
        PathwaysDashboard result = po.collectSpecificCancerPercentageAfter(cancerType);
        storeJson(calculatePathways, result);
    }

    @When("^user extracts Pathways performance as \"([^\"]*)\"$")
    public void userExtractsPathwaysPerformanceAs(String pathwayPerformanceCount) throws Throwable {
        TestUtils.wait(20);
        PathwaysDashboardPage pathwaysDashboardPage = new PathwaysDashboardPage(driver());
        pathwaysDashboardPage.setScenarioLogger(scenarioLogger);
        PathwaysDashboard result = pathwaysDashboardPage.collectPathwaysPerformanceDetails();
        storeJson(pathwayPerformanceCount, result);
    }

    @And("^user makes medicaid as reqewards eligible in DB$")
    public void userMakesMedicaidAsReqewardsEligibleInDB() {
        new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).insertRewardsEligible();

    }

    @And("^user deletes medicaid as rewards eligible in DB$")
    public void userDeletesMedicaidAsRewardsEligibleInDB() {
        new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).deleteRewardsEligible();
    }

    @When("^pathways Pathways performance shown difference \"([^\"]*)\" is calculated by \"([^\"]*)\" and \"([^\"]*)\" for \"([^\"]*)\" line of business$")
    public void pathwaysPathwaysPerformanceShownDifferenceIsCalculatedByAndForLineOfBusiness(String diffName, String after, String before, String lob) throws Throwable {
        Class<PathwaysDashboard> clazz = PathwaysDashboard.class;
        String jsonAfter = WhiteBoard.resolve(owner, after);
        PathwaysDashboard pvoAfter = (PathwaysDashboard) QuickJson.readValue(jsonAfter, clazz);
        String jsonBefore = WhiteBoard.resolve(owner, before);
        PathwaysDashboard pvoBefore = (PathwaysDashboard) QuickJson.readValue(jsonBefore, clazz);
        PathwaysDashboardDiff diff = PathwaysDashboardDiff.pathwayPerforamncediff(pvoAfter, pvoBefore, lob);
        String diffJson = QuickJson.prettyJson(diff);
        WhiteBoard.getInstance().putString(owner, WhiteBoard.resolve(owner, diffName), diffJson);
        scenarioLogger.warn(diffName + "=\n" + diffJson);
    }

    @Then("^user extracts Pathways Pathways performance db as \"([^\"]*)\"$")
    public void userExtractsPathwaysPathwaysPerformanceDbAs(String pathwayShownDbCount) throws Throwable {
        Map<String, String> pf = WhiteBoard.getInstance().getMap(owner, ExcelLib.THE_REQUESTING_PROVIDER);
        String providerTin = pf.get(MBM.RPPD_PROVIDER_TIN);
        PathwaysDashboardPage po = new PathwaysDashboardPage();
        po.setScenarioLogger(scenarioLogger);
        PathwaysDashboard result = po.collectPathwayPerformanceFromDb(providerTin);
        storeJson(pathwayShownDbCount, result);
    }

    @And("^user validates as \"([^\"]*)\" as reqewards eligible for medicaid$")
    public void userValidatesAsAsReqewardsEligibleForMedicaid(String rewardsEligible) throws Throwable {
        obj().PathwaysDashboardPage.verifyRewardsEligibleStatus(rewardsEligible);

    }


    @Then("^user validates \"([^\"]*)\" using below queries for \"([^\"]*)\" line of business$")
    public void userValidatesUsingBelowQueriesForLineOfBusiness(String sourceString, String lob) throws Throwable {
        Class<PathwaysDashboard> clazz = PathwaysDashboard.class;
        String json = WhiteBoard.resolve(owner, sourceString);
        PathwaysDashboard pathwaysDashboard = (PathwaysDashboard) QuickJson.readValue(json, clazz);
        PathwaysDashboard aClone = (PathwaysDashboard) QuickJson.clone(pathwaysDashboard);
        for (Map<String, String> m : aClone.getPathwaysDashboard().getPathwayPerformance()) {
            if (m.get("Line Of Business").equals(lob)) {
                Assert.assertEquals(0, Integer.parseInt(m.get("Pathways Shown")));
                Assert.assertEquals(0, Integer.parseInt(m.get("Pathways Selected")));
                Assert.assertEquals(0, Integer.parseInt(m.get("% TIN Adherence").replace("%", "")));
                break;
            }

        }
    }

    @Then("^user extracts Pathways Pathways performance for All Providers percentage from db as \"([^\"]*)\"$")
    public void userExtractsPathwaysPathwaysPerformanceForAllProvidersPercentageFromDbAs(String allProvidersPercentage) throws Throwable {
        PathwaysDashboardPage po = new PathwaysDashboardPage();
        po.setScenarioLogger(scenarioLogger);
        PathwaysDashboard result = po.collectPathwayPerformancePercentageAllProvidersFromDb();
        storeJson(allProvidersPercentage, result);

    }

    @And("^user makes medicaid lob \"([^\"]*)\" to exchange member for \"([^\"]*)\"$")
    public void userMakesMedicaidLobToExchangeMemberFor(String lob, String hscID)  {
        hscID = WhiteBoard.resolve(owner, hscID);
        new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).updateLOB(lob, hscID);
    }


    @And("^User enters \"([^\"]*)\" in Tin search box$")
    public void userEntersInTinSearchBox(String TINID) throws Throwable {
        scenario.write("Entering TIn ID: " + TINID);
        obj().PathwaysDashboardPage.enterTin(TINID);
    }

    @Then("^User clicks Tin search button$")
    public void userClicksTinSearchButton() throws Throwable {
        scenario.write("Clicking Tin Search Button");
        obj().PathwaysDashboardPage.searchTin();
        obj().CommonPage.waitForNOTBusyIndicator();
    }

    @And("^User clicks on Review Results button$")
    public void userClicksOnReviewResultsButton() throws Throwable {
        scenario.write("Clicking Review Results Button");
        obj().PathwaysDashboardPage.clickReviewPathwaysResults();
        obj().CommonPage.waitForNOTBusyIndicator();
    }


    @And("^user validates as exchange member lob does not exists in \"([^\"]*)\"$")
    public void userValidatesAsExchangeMemberLobDoesNotExistsIn(String after)  {
        Class<PathwaysDashboard> clazz = PathwaysDashboard.class;
        String json = WhiteBoard.resolve(owner, after);
        PathwaysDashboard pathwaysDashboard = (PathwaysDashboard) QuickJson.readValue(json, clazz);
        PathwaysDashboard aClone = (PathwaysDashboard) QuickJson.clone(pathwaysDashboard);
        for (Map<String, String> m : aClone.getPathwaysDashboard().getPathwayPerformance()) {
            Assert.assertFalse(m.get("Line Of Business").equals("Exchange"));
        }

    }

    @And("^user changes decision render date form curent month to previous month for with hscID \"([^\"]*)\"$")
    public void userChangesDecisionRenderDateFormCurentMonthToForWithHscID(String hscID)  {
        hscID = WhiteBoard.resolve(owner, hscID);
        Calendar aCalendar = Calendar.getInstance();
        aCalendar.add(Calendar.MONTH, -1);
        aCalendar.set(Calendar.DATE, aCalendar.getActualMinimum(Calendar.DAY_OF_MONTH));
        Date lastDateOfPreviousMonth = aCalendar.getTime();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        dateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        String previousMonth = dateFormat.format(lastDateOfPreviousMonth);
        new HscSrvcDecnDao(MyBatisConnectionFactory.getSqlSessionFactory()).updateDecisionRenderDate(previousMonth, hscID);


    }

}


