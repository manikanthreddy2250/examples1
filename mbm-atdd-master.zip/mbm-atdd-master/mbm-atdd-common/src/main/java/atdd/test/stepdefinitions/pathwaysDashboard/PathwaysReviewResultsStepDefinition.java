package atdd.test.stepdefinitions.pathwaysDashboard;

import atdd.common.ScenarioLogger;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.stepsets.Login;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import static org.junit.Assert.assertTrue;

public class PathwaysReviewResultsStepDefinition {

    public static final Logger log = Logger.getLogger(PathwaysReviewResultsStepDefinition.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }

    @And("^User compares pathways selected in widget one and review results page$")
    public void userComparesPathwaysSelectedInWidgetOneAndReviewResultsPage() throws Throwable {

        String pathwaysAdherence = obj().PathwaysDashboardPage.returnPathwaysAdherence();
        obj().PathwaysDashboardPage.clickReviewPathwaysResults();
        String overallPathways = obj().PathwaysReviewResultsPage.returnOverallPathways();
        log.warn("Widget1_Pathways%: " + pathwaysAdherence + " ReviewReults_Pathways%: " + overallPathways);
        assertTrue(pathwaysAdherence.equals(overallPathways));


    }


    @Then("^User Validates Email details for UHC$")
    public void UserValidatesEmaildetailsforUHC() throws Throwable {
       obj().PathwaysReviewResultsPage.isEmailPresent();


    }

    @Then("^User Validates One tin can attest for group of providers$")
    public void UserValidatesOnetincanattestforgroupofproviders() throws Throwable {
        obj().PathwaysReviewResultsPage.attestation();

    }


    @Then("^User selects timeperiod as \"([^\"]*)\"$")
    public void userSelectsTimeperiodAs(String arg1) throws Throwable {
        obj().PathwaysReviewResultsPage.previousResults(arg1);
    }

    @Then("^User Validates the option to select previous periods$")
    public void userValidatesTheOptionToSelectPreviousPeriods() throws Throwable {
        obj().PathwaysReviewResultsPage.viewPeriodPresent();
    }

    @Then("^User validates review status after attestation for all the users$")
    public void userValidatesReviewStatusAfterAttestationForAllTheUsers() throws Throwable {
        obj().PathwaysReviewResultsPage.attestation();
    }

    @And("^Validates the user is eligible or non eligible for rewards$")
    public void validatesTheUserIsEligibleOrNonEligibleForRewards() throws Throwable {
        obj().PathwaysReviewResultsPage.userRewardsEligibility();

    }


}

