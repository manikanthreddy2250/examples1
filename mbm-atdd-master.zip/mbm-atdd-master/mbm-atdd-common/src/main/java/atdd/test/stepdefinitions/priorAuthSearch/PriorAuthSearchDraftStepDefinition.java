package atdd.test.stepdefinitions.priorAuthSearch;

import atdd.common.ScenarioLogger;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.shared.BaseCucumber;
import atdd.test.shared.Globals;
import atdd.test.stepsets.Login;
import atdd.utils.TestUtils;
import cucumber.api.PendingException;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

public class PriorAuthSearchDraftStepDefinition {
    public static final Logger log = Logger.getLogger(PriorAuthSearchDraftStepDefinition.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }

    TestUtils utils =BaseCucumber.utils;
    Globals gv = BaseCucumber.gv;
    @And("^User enters the \"([^\"]*)\" Provider TIN on the Draft tab PriorAuth Search page$")
    public void user_enter_ProviderTINDraft(String tin) throws Throwable {
        if(tin.equalsIgnoreCase("gv")) tin = gv.getReqProviderTIN();
        obj().PriorAuthorizationSearchDraftPage.enterProviderTin_SearchDraft(tin);
    }

    @When("^Edit Icon is not visible on Draft or Submitted tab PriorAuth Search page$")
    public void checkEditNotPresent() throws Throwable {
        obj().PriorAuthorizationSearchDraftPage.checkEditIconIsNotPresent();
    }

    @And("^User checks that in Status column we have \"([^\"]*)\" value on the Draft tab PriorAuth Search page$")
    public void user_checks_StatusDraft(String val) throws Throwable {
        if (val.equalsIgnoreCase("gv")) val = gv.getStatus();
        obj().PriorAuthorizationSearchDraftPage.checkColumnElements_Status_SearchDraft(val);
    }

    @When("^User selects \"([^\"]*)\" Status option on the Draft tab PriorAuth Search page$")
    public void user_selects_status(String status) throws Throwable {
        obj().PriorAuthorizationSearchDraftPage.selectStatusDropDwn(status);
    }

    @When("Check that Pagination is disabled on the Draft tab PriorAuth Search page$")
    public void checkPaginationDisabledDraft() throws Throwable {
        obj().PriorAuthorizationSearchDraftPage.checkDisabledPaginationDraft();
    }

    @And("^User enter the \"([^\"]*)\" Member Last Name on the Draft tab PriorAuth Search page$")
    public void user_enter_MemberLastNameDraft(String lname) throws Throwable {
        //For global variables and using wildcard
        if(lname.contains("gv")) {
            lname = lname.replace("gv", gv.getLastName());
        }
        obj().PriorAuthorizationSearchDraftPage.enterMemberLastName_SearchDraft(lname);
    }

    @And("^User enter the \"([^\"]*)\" Draft ID on the Draft tab PriorAuth Search page$")
    public void user_enter_DraftIDDraft(String drid) throws Throwable {
        if(drid.equalsIgnoreCase("gv")) drid = gv.getHsc_id();
        obj().PriorAuthorizationSearchDraftPage.enterDraftID_SearchDraft(drid);
    }

    @And("^User checks that in Subscriber ID column we have \"([^\"]*)\" values on the Draft tab PriorAuth Search page$")
    public void user_checks_SubscIDDraft(String col) throws Throwable {
        if(col.equalsIgnoreCase("gv")) col = gv.getSubscriberId();
        obj().PriorAuthorizationSearchDraftPage.checkColumnElements_SubID_SearchDraft(col);
    }

    @And("^User enter the \"([^\"]*)\" Subscriber ID on the Draft tab PriorAuth Search page$")
    public void user_enter_SubcriberIDDraft(String subid) throws Throwable {
        if(subid.equalsIgnoreCase("gv")) subid = gv.getSubscriberId();
        obj().PriorAuthorizationSearchDraftPage.enterSubscriberID_SearchDraft(subid);
    }

    @When("^user checks that the Draft ID we have \"([^\"]*)\" is retrieved for all memberIDTypes by \"([^\"]*)\" in Draft tab PriorAuth Search page$")
    public void user_checks_that_the_Draft_ID_we_have_is_retrieved_for_all_memberIDTypes_by_in_Draft_tab_PriorAuth_Search_page(String arg1, String arg2) throws Throwable {
        if(arg1.equalsIgnoreCase("gv")) arg1 = gv.getHsc_id();
        obj().PriorAuthorizationSearchDraftPage.retrieveDraftAuthByAllMemberTypes_SearchDraft(arg1, arg2);
    }

    @Then("^User clicks Clear on the Draft tab PriorAuth Search page$")
    public void user_ClickClear_DraftTab() throws Throwable {
        obj().PriorAuthorizationSearchDraftPage.clickClearDraft();
    }

    @Then("^User clicks Search on the Draft tab PriorAuth Search page$")
    public void user_ClickSearch_DraftTab() throws Throwable {
        obj().PriorAuthorizationSearchDraftPage.clickSearchDraft();
        obj().CommonPage.waitForNOTBusyIndicator();
    }

    @And("^User checks that in Member column we have \"([^\"]*)\" values on the Draft tab PriorAuth Search page$")
    public void user_checks_MemberNameDraft(String val) throws Throwable {
        if(val.equalsIgnoreCase("gv")){
            val = gv.getLastName();
            val = val + ", " + gv.getFirstName();
        }
        obj().PriorAuthorizationSearchDraftPage.checkColumnElements_MemberName_SearchDraft(val);
    }

    @And("^User checks that in Draft ID column we have \"([^\"]*)\" value on the Draft tab PriorAuth Search page$")
    public void user_checks_DraftIDDraft(String val) throws Throwable {
        if(val.equalsIgnoreCase("gv")) val = gv.getHsc_id();
        obj().PriorAuthorizationSearchDraftPage.checkColumnElements_DraftID_SearchDraft(val);
    }

    @And("^User checks that in Creation Date column we have \"([^\"]*)\" value on the Draft tab PriorAuth Search page$")
    public void user_checks_CreationDateDraft(String val) throws Throwable {
        if(val.equalsIgnoreCase("gv")) {

            val = gv.getStartDate();
            log.warn("\nGetting Date from DB: " + val);

            //Date from DB is UTC. UI date is local. Have to convert to the Local time.

            DateFormat utcFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            utcFormat.setTimeZone(TimeZone.getTimeZone("UTC"));

            Date date = null;
            try {
                date = utcFormat.parse(val);
            } catch (ParseException e) {
                e.printStackTrace();
            }

            DateFormat localFormat = new SimpleDateFormat("MM-dd-yyyy");
            //localFormat.setTimeZone(TimeZone.getTimeZone("PST"));
            localFormat.setTimeZone(TimeZone.getDefault());

            val = localFormat.format(date);
            log.warn("\nConverted Local Date: " + val);

        }
        obj().PriorAuthorizationSearchDraftPage.checkColumnElements_CreationDate_SearchDraft(val);
    }

    @And("^User checks that in Creator column we have \"([^\"]*)\" values on the Draft tab PriorAuth Search page$")
    public void user_checks_CreatorDraft(String creat) throws Throwable {
        if(creat.equalsIgnoreCase("gv")){
            creat = gv.getCreatorLastName();
            creat = creat + ", " + gv.getCreatorFirstName();
        }
        obj().PriorAuthorizationSearchDraftPage.checkColumnElements_CreatorName_SearchDraft(creat);
    }

    @When("^User selects Everything By TIN radio button on the Draft tab PriorAuth Search page$")
    public void user_selects_EverythingByTinDraft() throws Throwable {
        obj().PriorAuthorizationSearchDraftPage.clickEverythingByTinDraft();
    }

    @When("^We have less than \"([^\"]*)\" elements in the search results on the Draft tab PriorAuth Search page$")
    public void checkLessElementsDraft(int expected) throws Throwable {
        int actual = obj().PriorAuthorizationSearchDraftPage.getNumberOfElementsDraft();
        Assert.assertTrue("Expected Elements: " + expected + " Actual: " + actual, actual <= expected);
    }

    @When("^User selects \"([^\"]*)\" from Providers dropDown on the Draft tab PriorAuth Search page$")
    public void selectProvidersDraft(String option) throws Throwable {
        obj().PriorAuthorizationSearchDraftPage.selectCareProviderDraft(option);
    }

    @When("^\"([^\"]*)\" record has Urgent flag on the Draft tab PriorAuth Search page$")
    public void checkUrgentDraft(String reqNum) throws Throwable {
        if(reqNum.equalsIgnoreCase("gv")) reqNum = gv.getRequestNumber();
        obj().PriorAuthorizationSearchDraftPage.checkUrgentFlagDraftTab(reqNum);
    }

    @And("^Sort Up by Draft ID on the Draft tab PriorAuth Search page$")
    public void sortUpDraft() throws Throwable {
        obj().PriorAuthorizationSearchDraftPage.sortUPbyDraftID_Draft();
    }

    @And("^User should verify restricted message displayed in PriorAuth search drafts page$")
    public void userShouldVerifyRestrictedMessageDisplayedInPriorAuthSearchDraftsPage() throws Throwable {
        obj().PriorAuthorizationSearchSubmittedPage.verifyRestrictDisplayedInPrioAuth("DRAFTS");

    }

    @And("^User should verify restricted message not displayed in PriorAuth search drafts page$")
    public void userShouldVerifyRestrictedMessageNotDisplayedInPriorAuthSearchDraftsPage() throws Throwable {
        obj().PriorAuthorizationSearchSubmittedPage.verifyRestrictNotDisplayedInPrioAuth("DRAFTS");
    }

    @And("^User clicks the Edit Icon for  Auth in \"([^\"]*)\" tab PriorAuth Search Page$")
    public void userClicksTheEditIconForAuthInTabPriorAuthSearchPage(String arg0) throws Throwable {
        obj().PriorAuthorizationSearchDraftPage.clickEditIcon();
    }
}
