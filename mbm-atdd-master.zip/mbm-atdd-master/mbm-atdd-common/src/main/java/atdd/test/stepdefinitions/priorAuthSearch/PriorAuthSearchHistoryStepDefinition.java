package atdd.test.stepdefinitions.priorAuthSearch;

import atdd.common.ScenarioLogger;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.stepsets.Login;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;

public class PriorAuthSearchHistoryStepDefinition {
    public static final Logger log = Logger.getLogger(PriorAuthSearchHistoryStepDefinition.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }

    @And("^User enters \"([^\"]*)\" Physician Last Name on the History tab PriorAuth Search page$")
    public void enterPhysLastName(String txt) throws Throwable {
        obj().PriorAuthorizationSearchHistoryPage.enterPhysicianLastName(txt);
    }

    @And("^User enters \"([^\"]*)\" Physician First Name on the History tab PriorAuth Search page$")
    public void enterPhysFirstName(String txt) throws Throwable {
        obj().PriorAuthorizationSearchHistoryPage.enterPhysicianFirstName(txt);
    }

    @And("^User enters \"([^\"]*)\" Facility Name on the History tab PriorAuth Search page$")
    public void enterFacilityName(String txt) throws Throwable {
        obj().PriorAuthorizationSearchHistoryPage.enterFacilityName(txt);
    }

    @And("^User enters \"([^\"]*)\" TIN of the Requesting Provider on the History tab PriorAuth Search page$")
    public void enterTinReqProv(String txt) throws Throwable {
        obj().PriorAuthorizationSearchHistoryPage.enterTinOfReqProv(txt);
    }

    @And("^User enters \"([^\"]*)\" Request Number on the History tab PriorAuth Search page$")
    public void enterReqNum(String txt) throws Throwable {
        obj().PriorAuthorizationSearchHistoryPage.enterRequestNumber(txt);
    }

    @Then("^User selects the \"([^\"]*)\" option from Provider Type drop-down on the History tab PriorAuth Search page$")
    public void selectProviderType(String type) throws Throwable {
        obj().PriorAuthorizationSearchHistoryPage.selectProviderType_History(type);
    }

    @And("^User clicks Member Information radio button on the History tab PriorAuth Search page$")
    public void user_clicksMemberInfoRadio_History() throws Throwable {
        obj().PriorAuthorizationSearchHistoryPage.clickMemberInfoRadioBtn_History();
    }

    @And("^User clicks Request Number radio button on the History tab PriorAuth Search page$")
    public void user_clicksRequestNumRadio_History() throws Throwable {
        obj().PriorAuthorizationSearchHistoryPage.clickRequestNumRadioBtn_History();
    }

    @Then("^User enters the \"([^\"]*)\" Subscriber ID on the History tab PriorAuth Search page$")
    public void user_enter_SubID_History(String subid) throws Throwable {
        obj().PriorAuthorizationSearchHistoryPage.enterSubscriberID_History(subid);
    }

    @Then("^User enters the \"([^\"]*)\" Member First Name on the History tab PriorAuth Search page$")
    public void user_enter_MemberFirstName_History(String fname) throws Throwable {
        obj().PriorAuthorizationSearchHistoryPage.enterMemberFirstName_History(fname);
    }

    @Then("^User enters the \"([^\"]*)\" Member Last Name on the History tab PriorAuth Search page$")
    public void user_enter_MemberLastName_History(String lname) throws Throwable {
        obj().PriorAuthorizationSearchHistoryPage.enterMemberLastName_History(lname);
    }

    @Then("^User enters the \"([^\"]*)\" Member Date of birth on the History tab PriorAuth Search page$")
    public void user_enter_MemberDOB_History(String dob) throws Throwable {
        obj().PriorAuthorizationSearchHistoryPage.enterMemberDOB_History(dob);
    }

    @And("^User clicks Search button on the History tab PriorAuth Search page$")
    public void user_clicksSearch_History() throws Throwable {
        obj().PriorAuthorizationSearchHistoryPage.clickSearch_History();
    }

    @And("^User clicks Clear button on the History tab PriorAuth Search page$")
    public void user_clicksClear_History() throws Throwable {
        obj().PriorAuthorizationSearchHistoryPage.clickClear_History();
    }

    @When("^We have \"([^\"]*)\" of search results on the History tab PriorAuth Search page$")
    public void checkSearch_History(int res) throws Throwable {
        int tmp = obj().PriorAuthorizationSearchHistoryPage.checkNumberOfSearchResults_History();
        Assert.assertTrue("Actual search result: " + tmp + " Expected: " + res, tmp == res);
    }

    @When("^We have \"([^\"]*)\" or more of search results on the History tab PriorAuth Search page$")
    public void checkMoreThanSearch_History(int res) throws Throwable {
        int tmp = obj().PriorAuthorizationSearchHistoryPage.checkNumberOfSearchResults_History();
        Assert.assertTrue("Actual search result: " + tmp + " Expected: " + res, tmp >= res);
    }

    @Then("^User verifies in the history page for retrieved subScriberID for same subscriber's firstName \"([^\"]*)\" lastName \"([^\"]*)\" DOB \"([^\"]*)\"$")
    public void UserverifiesthatInTheHistoryTabRetrievedAuthForAllMemberIDTypesForSameSubscriberSFirstNameLastNameDOB(String arg0, String arg1, String arg2) throws Throwable {
        obj().PriorAuthorizationSearchDraftPage.retrieveDraftAuthByAllMemberTypes_SearchHistory(arg0,arg1,arg2);

    }

    @And("^User should verify restricted message displayed in PriorAuth search history page$")
    public void userShouldVerifyRestrictedMessageDisplayedInPriorAuthSearchDraftsPage() throws Throwable {
        obj().PriorAuthorizationSearchSubmittedPage.verifyRestrictDisplayedInPrioAuth("HISTORY");

    }

    @And("^User should verify restricted message displayed in PriorAuth search Provider history page$")
    public void userShouldVerifyRestrictedMessageDisplayedInPriorAuthSearchProviderHistoryPage() throws Throwable {
        obj().PriorAuthorizationSearchSubmittedPage.verifyRestrictDisplayedInPrioAuth("PROVIDER HISTORY");

    }

    @And("^User should verify restricted message not displayed in PriorAuth search Provider history page$")
    public void userShouldVerifyRestrictedMessageNotDisplayedInPriorAuthSearchProviderHistoryPage() throws Throwable {
        obj().PriorAuthorizationSearchSubmittedPage.verifyRestrictNotDisplayedInPrioAuth("PROVIDER HISTORY");
    }

    @And("^User should verify restricted message not displayed in PriorAuth search history page$")
    public void userShouldVerifyRestrictedMessageNotDisplayedInPriorAuthSearchDraftsPage() throws Throwable {
        obj().PriorAuthorizationSearchSubmittedPage.verifyRestrictNotDisplayedInPrioAuth("HISTORY");

    }
}
