package atdd.test.stepdefinitions.priorAuthSearch;

import atdd.common.ScenarioLogger;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.pageobjects.priorAuthSearch.PriorAuthorizationSearchDraftPage;
import atdd.test.pageobjects.priorAuthSearch.PriorAuthorizationSearchHistoryPage;
import atdd.test.pageobjects.priorAuthSearch.PriorAuthorizationSearchSubmittedPage;
import atdd.test.shared.BaseCucumber;
import atdd.test.shared.Globals;
import atdd.test.stepsets.AuthorizationRequest;
import atdd.test.stepsets.Login;
import atdd.utils.TestUtils;
import atdd.utils.WhiteBoard;
import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.Map;

public class PriorAuthSearchSubmittedStepDefinition {

    Globals gv = BaseCucumber.gv;

    public static final Logger log = Logger.getLogger(PriorAuthSearchSubmittedStepDefinition.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }

    @And("^User enters the \"([^\"]*)\" Provider TIN on the PriorAuth Search Submitted page$")
    public void user_enter_ProviderTIN(String tin) throws Throwable {
        if (tin.equalsIgnoreCase("gv")) tin = gv.getReqProviderTIN();
        obj().PriorAuthorizationSearchSubmittedPage.enterProviderTIN_Search(tin);
    }

    @When("^User selects \"([^\"]*)\" Status option on the Submitted tab PriorAuth Search page$")
    public void user_selects_status(String status) throws Throwable {
        obj().PriorAuthorizationSearchSubmittedPage.selectStatusDropDwn(status);
    }

    @And("^User enters the \"([^\"]*)\" Subscriber ID on the PriorAuth Search Submitted page$")
    public void user_enter_SubcriberID(String subid) throws Throwable {
        if (subid.equalsIgnoreCase("gv")) subid = gv.getSubscriberId();
        obj().PriorAuthorizationSearchSubmittedPage.enterSubscriberID_Search(subid);
    }

    @When("^user enters the associated \"([^\"]*)\" Member Id Types in \"([^\"]*)\"$")
    public void user_enters_the_associated_Member_Id_Types_in(String arg1, String arg2) throws Throwable {
        obj().PriorAuthorizationSearchSubmittedPage.enterMemberIdOrSubscriberID(arg1, arg2);

    }


    @And("^User enters the \"([^\"]*)\" Member Last Name on the PriorAuth Search Submitted page$")
    public void user_enter_MemberLastName(String lname) throws Throwable {
        if (lname.equalsIgnoreCase("gv")) lname = gv.getLastName();
        obj().PriorAuthorizationSearchSubmittedPage.enterMemberLastName_Search(lname);
    }

    @Then("^User enters the \"([^\"]*)\" Request Number on the PriorAuth Search Submitted page$")
    public void user_enter_RequestNumber(String num) throws Throwable {
        if (num.equalsIgnoreCase("gv")) num = gv.getRequestNumber();// for vend_cse_id

        String pri_ref = gv.getPrisrvcrefnbr();
        if (num.equalsIgnoreCase("gv_pri_ref") && pri_ref != null) num = pri_ref; // for pri_svc_ref_nbr

        obj().PriorAuthorizationSearchSubmittedPage.enterRequestNumber(num);
    }

    @And("^User clicks on document action icon for \"([^\"]*)\" Request number on the PriorAuth Search Submitted page$")
    public void userClicksOnDocIcon(String reqNum) throws Throwable {
        if (reqNum.equalsIgnoreCase("gv")) {
            String prisrvcrefnbr = gv.getPrisrvcrefnbr();
            if (prisrvcrefnbr == null) {
                reqNum = gv.getRequestNumber();
            } else reqNum = prisrvcrefnbr;
        }
        obj().PriorAuthorizationSearchSubmittedPage.clickDocumentIconByRequestNumber(reqNum);
    }

    @Then("^User clicks Search on the PriorAuth Search Submitted page$")
    public void user_ClickSearch_SubmittedTab() throws Throwable {
        obj().PriorAuthorizationSearchSubmittedPage.clickSearchSubmitted();
        obj().CommonPage.waitForNOTBusyIndicator();
    }

    @Then("^User clicks Clear on the PriorAuth Search Submitted page$")
    public void user_ClickClear_SubmittedTab() throws Throwable {
        obj().PriorAuthorizationSearchSubmittedPage.clickClearSubmitted();
    }

    @And("^User checks that in Request Number column we have \"([^\"]*)\" values on the PriorAuth Search Submitted page$")
    public void user_checks_RequestNum(String val) throws Throwable {
        if (val.equalsIgnoreCase("gv")) {
            String prisrvcrefnbr = gv.getPrisrvcrefnbr();
            if (prisrvcrefnbr == null) {
                val = gv.getRequestNumber();
            } else val = prisrvcrefnbr;
        }
        obj().PriorAuthorizationSearchSubmittedPage.checkColumnElements_RequestNumber_SearchSubmitted(val);
    }

    @And("^User checks that in Member last name column we have \"([^\"]*)\" values on the PriorAuth Search Submitted page$")
    public void user_checks_MemberName(String lname) throws Throwable {
        if (lname.equalsIgnoreCase("gv")) lname = gv.getLastName();
        obj().PriorAuthorizationSearchSubmittedPage.checkColumnElements_MemberName_SearchSubmitted(lname);
    }

    @And("^User checks that in Subscriber ID column we have \"([^\"]*)\" values on the PriorAuth Search Submitted page$")
    public void user_checks_SubscID(String val) throws Throwable {
        if (val.equalsIgnoreCase("gv")) val = gv.getSubscriberId();
        obj().PriorAuthorizationSearchSubmittedPage.checkColumnElements_SubID_SearchSubmitted(val);
    }

    @When("^User selects Everything By TIN radio button on the PriorAuth Search Submitted page$")
    public void user_selects_EverythingByTin() throws Throwable {
        obj().PriorAuthorizationSearchSubmittedPage.clickEverythingByTinSub();
    }

    @When("Check that Pagination is disabled on the PriorAuth Search Submitted page$")
    public void checkPaginationDisabled() throws Throwable {
        obj().PriorAuthorizationSearchSubmittedPage.checkDisabledPagination();
    }

    @When("^We have less than \"([^\"]*)\" elements in the search results on the PriorAuth Search Submitted page$")
    public void checkLessElementsSubmitted(int expected) throws Throwable {
        int actual = obj().PriorAuthorizationSearchSubmittedPage.getNumberOfElementsSubmitted();
        Assert.assertTrue("Expected Elements: " + expected + " Actual: " + actual, actual <= expected);
    }

    @When("^User selects \"([^\"]*)\" from Providers dropDown on the PriorAuth Search Submitted page$")
    public void selectProvidersSubmitted(String option) throws Throwable {
        obj().PriorAuthorizationSearchSubmittedPage.selectCareProvider(option);
    }

    @And("^Check Urgent requests only Check Box on the PriorAuth Search Submitted page$")
    public void ckeckUrgentChkBx() throws Throwable {
        obj().PriorAuthorizationSearchSubmittedPage.checkCheckBoxUrgentRequests();
    }

    @When("^\"([^\"]*)\" record has Urgent flag on the PriorAuth Search Submitted page$")
    public void checkRecordsSubmittedWidget(String reqNum) throws Throwable {
        if (reqNum.equalsIgnoreCase("gv")) reqNum = gv.getRequestNumber();
        obj().PriorAuthorizationSearchSubmittedPage.checkUrgentFlagSubmittedWidget(reqNum);
    }


    @And("^User clicks on document action icon for the Request number on the PriorAuth Search Submitted page$")
    public void userClicksOnDocumentActionIconForTheRequestNumberOnThePriorAuthSearchSubmittedPage() throws Throwable {
        obj().PriorAuthorizationSearchSubmittedPage.clickDocumentIconByRequestNumber(gv.getRequestNumber());
    }

    @And("^User checks that Status is Completed on Search Submitted page$")
    public void user_checks_Status() throws Throwable {
        obj().PriorAuthorizationSearchSubmittedPage.checkColumnElements_Status_SearchSubmitted();
    }

    @And("^User checks that End Date is blank on Search Submitted page$")
    public void user_checks_EndDate() throws Throwable {
        obj().PriorAuthorizationSearchSubmittedPage.checkColumnElements_EndDate_SearchSubmitted();
    }

    @And("^User selects Status dropdown on the PriorAuth Search Submitted page$")
    public void user_selects_statusDropdown() throws Throwable {
        obj().PriorAuthorizationSearchSubmittedPage.selectsStatusDropdown();
    }

    @And("^User should verify that \"([^\"]*)\" option is not present under status dropdown$")
    public void user_verifies_statusDropdownOptions(String optionValue) throws Throwable {
        obj().PriorAuthorizationSearchSubmittedPage.VerifyOptionNotPresentUnderStatusDropdown(optionValue);
    }

    @And("^User clicks on document action icon for the \"([^\"]*)\" on the PriorAuth Search Submitted page$")
    public void userClicksOnDocumentActionIconForTheOnThePriorAuthSearchSubmittedPage(String status) throws Throwable {
        obj().PriorAuthorizationSearchSubmittedPage.clickDocumentIconByStatus(status);
    }

    @And("^User stores TIN from \"([^\"]*)\" PriorAuth Search Page$")
    public void userStoresTIN(String authType) throws Throwable {
        if (authType.toLowerCase().equals("submitted")) {
            obj().PriorAuthorizationSearchSubmittedPage.storeTINonPriorAuthSearchSubmit();
        } else if (authType.toLowerCase().equals("draft")) {
            obj().PriorAuthorizationSearchDraftPage.storeTINonPriorAuthDraftSubmit();
        } else {
            log.warn("This is not a valid search page and cannot store tin");
        }
    }


    @And("^User should see Total \"([^\"]*)\" Records number match records in DB for TIN$")
    public void userShouldSeeTotalRecordsNumberMatchRecordsInDBForTIN(String authType) throws Throwable {
        if (authType.toLowerCase().equals("submitted")) {
            obj().PriorAuthorizationSearchSubmittedPage.TotalRecordsMatchDBforTIN(authType);
        } else if (authType.toLowerCase().equals("draft")) {
            obj().PriorAuthorizationSearchDraftPage.TotalRecordsMatchDBforTIN(authType);
        } else {
            log.warn("This is not a valid search page and cannot store tin");
        }
    }

    @And("^User validates clone icon is not visible on PriorAuth Search Submitted page$")
    public void userValidatesCloneIconIsNotVisibleOnPriorAuthSearchSubmittedPage() throws Throwable {
        obj().PriorAuthorizationSearchSubmittedPage.verifyCloneIconLocatorNoPresent();
    }

    @And("^user searches \"([^\"]*)\" Prior Authorization Requests by below criteria$")
    public void userSearchesPriorAuthorizationRequestsByBelowCriteria(String tab, List<Map<String, String>> criteria) throws Throwable {
        AuthorizationRequest ar = new AuthorizationRequest(scenario, driver());
        Map<String, String> criteria0 = WhiteBoard.resolve(owner, criteria).get(0);
        switch (tab) {
            case "Submitted":
                ar.searchSubmitted(criteria0);
                break;
            case "Drafts":
                ar.searchDraft(criteria0);
                break;
            case "History":
                ar.searchHistory(criteria0);
                break;
            default:
                Assert.fail("Unknown tab: " + tab);
        }
    }

    @And("^\"([^\"]*)\" Prior Authorization Requests search result is extracted with prefix \"([^\"]*)\" and key header \"([^\"]*)\"$")
    public void priorAuthorizationRequestsSearchResultIsExtractedWithPrefixAndKeyHeader(String tab, String prefix, String keyHeader) throws Throwable {
        String searchResultTableXpath = null;
        switch (tab) {
            case "Submitted":
                searchResultTableXpath = PriorAuthorizationSearchSubmittedPage.searchResultXpath;
                break;
            case "Drafts":
                searchResultTableXpath = PriorAuthorizationSearchDraftPage.searchResultXpath;
                break;
            case "History":
                searchResultTableXpath = PriorAuthorizationSearchHistoryPage.searchResultXpath;
                break;
            default:
                Assert.fail("Unknown tab: " + tab);
        }
        TestUtils.extractGridToWhiteBoard(driver(), scenario, prefix, keyHeader, searchResultTableXpath, true, false);
    }


    @And("^user selects the payer as \"([^\"]*)\"$")
    public void userSelectsThePayerAs(String payer) throws Throwable {
        obj().PriorAuthorizationSearchSubmittedPage.selectPayer(payer);
    }


    @And("^user verifies the label is not present on the priorauth search page$")
    public void userVerifiesTheLabelIsNotPresentOnThePriorauthSearchPage(DataTable labelTable) throws Throwable {
        List<String> expectedLabelvalues = labelTable.asList(String.class);
        obj().PriorAuthorizationSearchSubmittedPage.verifyLabelNotPresentOnPriorAuthSearchPage(expectedLabelvalues);
    }


    @And("^user verifies the labels on the PriorAuth Search page for \"([^\"]*)\"$")
    public void userVerifiesTheLabelsOnThePriorAuthSearchPageFor(String tab, DataTable labelTable) throws Throwable {
        List<String> expectedLabelvalues = labelTable.asList(String.class);
        obj().PriorAuthorizationSearchSubmittedPage.verifyLabelPresentOnPriorAuthSearchPage(expectedLabelvalues, tab);
    }

    @And("^User verifies Payer dropdown is not present on the PriorAuth Search page$")
    public void userVerifiesPayerDropdownIsNotPresentOnThePriorAuthSearchPage() throws Throwable {
        obj().PriorAuthorizationSearchSubmittedPage.verifyDropdownisNotPresentOnPriorAuthSearchPage();
    }
    @And("^user verifies the total records retrieved for only authorizations \"([^\"]*)\" for \"([^\"]*)\"$")
    public void userVerifiesTheTotalRecordsRetrievedForOnlyAuthorizationsFor(String payer, String tab) throws Throwable {
        obj().PriorAuthorizationSearchSubmittedPage.verifyRecordsRetrieved(payer,tab);
    }
    @And("^user verifies the payer dropdown has \"([^\"]*)\" selected$")
    public void userVerifiesThePayerDropdownHasSelected(String payer) throws Throwable {
        obj().PriorAuthorizationSearchSubmittedPage.verifyPayer(payer);
    }

    @Given("^user searches submitted Prior Authorization Requests in dashboard by below criteria$")
    public void userSearchesSubmittedPriorAuthorizationRequestsInDashboardByBelowCriteria(List<Map<String, String>> submitted) throws Throwable {

        Map<String, String> criteria0 = WhiteBoard.resolve(owner, submitted).get(0);
        TestUtils.wait(3);
        obj().NavigationPage.navigatesToMenuItem("Home>");
        TestUtils.wait(3);

        String auth = criteria0.get("Request Number");
        WebElement ele = driver().findElement(By.xpath("//table[@id='viewAuthorizationTableID']//td[contains(.,'" + auth + "')]/preceding-sibling::td[1]//span[@title='Clone Request']"));
        ele.click();

    }

    @And("^User should verify restricted message displayed in PriorAuth search submitted page$")
    public void userShouldVerifyRestrictedMessageDisplayedInPriorAuthSearchPage() throws Throwable {
        obj().PriorAuthorizationSearchSubmittedPage.verifyRestrictDisplayedInPrioAuth("SUBMITTED");

    }

    @And("^User should verify restricted message not displayed in PriorAuth search submitted page$")
    public void userShouldVerifyRestrictedMessageNotDisplayedInPriorAuthSearchSubmittedPage() throws Throwable {
        obj().PriorAuthorizationSearchSubmittedPage.verifyRestrictNotDisplayedInPrioAuth("SUBMITTED");
    }

    @And("^User clicks on the Request number from the Submitted Auth search record$")
    public void userClicksOnTheRequestNumberFromTheSubmittedAuthSearchRecord() throws Throwable {
        obj().PriorAuthorizationSearchSubmittedPage.clickFirstRecordInPriorAuthSearch("SUBMITTED");
    }

    @And("^User selects \"([^\"]*)\" as Benefit Type$")
    public void userSelectsAsBenefitType(String benefit) throws Throwable {
     obj().PriorAuthorizationSearchSubmittedPage.selectBenefitTypeSubmitted(benefit);
    }

//    @And("^User enters \"([^\"]*)\" authorization number in PriorAuth search submitted page$")
//    public void userEntersAuthorizationNumberInPriorAuthSearchSubmittedPage(String reqNum) throws Throwable {
//        obj().PriorAuthorizationSearchSubmittedPage.enterRequestNumber(reqNum);
//    }

    @And("^User selects \"([^\"]*)\" as Authorization Type$")
    public void userSelectsAsAuthorizationType(String authType) throws Throwable {
        obj().PriorAuthorizationSearchSubmittedPage.selectAuthTypeDropDwn(authType);
    }

    @And("^User selects All Benefit Type$")
    public void userSelectsAllBenefitType() throws Throwable {
        obj().PriorAuthorizationSearchSubmittedPage.selectAllBenefitType();
    }

    @And("^User click Search button in PriorAuth Search submitted page$")
    public void userClickSearchButtonInPriorAuthSearchSubmittedPage() throws Throwable {
        obj().PriorAuthorizationSearchSubmittedPage.clickFilterSubmitted();
    }

    @And("^User enters \"([^\"]*)\" authorization number in PriorAuth search submitted page$")
    public void userEntersAuthorizationNumberInPriorAuthSearchSubmittedPage(String reqNum) throws Throwable {
        obj().PriorAuthorizationSearchSubmittedPage.enterRequestNumber(reqNum);
    }

    @And("^User clicks on Treatment Review Panel$")
    public void userClicksTreatmentReviewPanel() throws Throwable {
        obj().ViewAuthPage.clickTreatmentReviewbutton();
    }

    @Then("^User Should See Custom Reasons And Compare With Database$")
    public void userShouldSeeCustomReasonsAndCompareWithDatabase() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        obj().ViewAuthPage.validateCustomReasonsOnScreenWithDB();

    }

    @And("^User Filter Records \"([^\"]*)\" Submitted Auth search record$")
    public void clickFilterButton(String flagStatus) throws Throwable{
        obj().PriorAuthorizationSearchSubmittedPage.clickPriorAuthSearchPageFilterButton(flagStatus);
    }

    @And("^Verify User Select Tab for  \"([^\"]*)\"  and flag \"([^\"]*)\" Submitted Auth search record$")
    public  void clickTabforSelectingBenefitTypeAuth( String tabName, String flagStatus) throws Throwable {

        obj().PriorAuthorizationSearchSubmittedPage.clickPriorAuthSearchPageTabButton(tabName,flagStatus);
    }


    @And("^User set MemberID \"([^\"]*)\" on Prior Auth Submitted Page.$")
    public void selectBenefitTypeEntersMemberID(String memberID) throws  Throwable {
        obj().PriorAuthorizationSearchSubmittedPage.setSubscriberIDPriorAuthSubmittedPage(memberID);
    }

    @And("^User Select Status dropdown for Prior Auth \"([^\"]*)\"$")
    public void selectStatusofPriorAuth(String overallStatus) throws  Throwable {
        obj().PriorAuthorizationSearchSubmittedPage.selectStatusDropdown(overallStatus);
    }


}
