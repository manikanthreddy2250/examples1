package atdd.test.stepdefinitions.rulesManger;

import atdd.common.ScenarioLogger;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.stepsets.Login;
import atdd.test.stepsets.RulesManager;
import atdd.utils.TestUtils;
import atdd.utils.WhiteBoard;
import cucumber.api.DataTable;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import java.util.List;
import java.util.Map;

public class RulesManagerSetStepDefinition {
    public static final Logger log = Logger.getLogger(RulesManagerSetStepDefinition.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;
    private WebDriver driver;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }


    /**
     * Rules Manager Publish Changes - generic to all
     * @throws Throwable
     */
    @And("^user Publish Changes$")
    public void userPublishChanges() throws Throwable {
        new RulesManager(scenario, driver()).clickPublishChangesLink();
    }

    /**
     *
     * @param popupName
     * @param values
     * @throws Throwable
     */
    @Then("^User adds below information on \"([^\"]*)\" Pop Up Page$")
    public void userAddsBelowInformationOnPopUpPage(String popupName, DataTable values) throws Throwable {
        List<Map<String, String>> maps = WhiteBoard.resolve(owner, values.asMaps(String.class, String.class));
        Map<String, String> map = null;
        for (Map<String, String> m : maps) {
            map = m;
            new RulesManager(scenario, driver()).addInfoOnPopUp(popupName, map);
        }

    }

    @Then("^user searches for the \"([^\"]*)\" by below criteria and deletes it")
    public void userSearchesandDeletesIfRecordExists(String exceptionName, List<Map<String, String>> searchValues) throws Throwable {
        Map<String, String> criteria0 = WhiteBoard.resolve(owner, searchValues).get(0);

        boolean flag = new RulesManager(scenario, driver()).searchByCriteria(exceptionName, criteria0);
        TestUtils.wait(5);
        // flag = true;
        if (flag) {
            new RulesManager(scenario, driver()).deleteRecordFromTable(exceptionName, criteria0);
        } else {
            log.warn("Record not found so not performing delete operation.");

        }
    }





    /**
     *
     * @param exceptionName
     * @param searchValues
     * @throws Throwable
     */
    @Then("^user searches for the \"([^\"]*)\" by below criteria$")
    public void userSearchesForTheByBelowCriteria(String exceptionName, List<Map<String, String>> searchValues) throws Throwable {
        Map<String, String> criteria0 = WhiteBoard.resolve(owner, searchValues).get(0);
        new RulesManager(scenario, driver()).searchByCriteria(exceptionName, criteria0);
    }

    /**
     *
     * @param ExceptionName
     * @param t
     * @throws Throwable
     */
    @And("^user deletes record from \"([^\"]*)\" table$")
    public void userDeletesRecordFromTable(String ExceptionName, DataTable t) throws Throwable {
        List<Map<String, String>> maps = WhiteBoard.resolve(owner, t.asMaps(String.class, String.class));
        Map<String, String> map = null;
        for (Map<String, String> m : maps) {
            map = m;
            new RulesManager(scenario, driver()).deleteRecordFromTable(ExceptionName, map);
        }

    }

    /**
     *
     * @param ExceptionName
     * @throws Throwable
     */
    @Then("^user verifies sorting functionality of the table for the \"([^\"]*)\" Table$")
    public void userVerifiesSortingFunctionalityOfTheTableForTheTable(String ExceptionName) throws Throwable {
        new RulesManager(scenario, driver()).verifySortForExceptionTable(ExceptionName);
    }

    /**
     *
     * @param Exception
     * @param arg1
     * @throws Throwable
     */
    @And("^User validates table header in \"([^\"]*)\" screen is in below Order$")
    public void userValidatesTableHeaderInScreenIsInBelowOrder(String Exception, DataTable arg1) throws Throwable {
        new RulesManager(scenario, driver()).validateTableHeaders(Exception, arg1);
    }

    /**
     *
     * @param Exception
     * @param table
     * @throws Throwable
     */
    @And("^User edits the newly added \"([^\"]*)\"$")
    public void userEditsTheNewlyAdded(String Exception, DataTable table) throws Throwable {
        List<Map<String, String>> maps = WhiteBoard.resolve(owner, table.asMaps(String.class, String.class));
        Map<String, String> map = null;
        for (Map<String, String> m : maps) {
            map = m;
            new RulesManager(scenario, driver()).editException(Exception, map);
        }
    }

    /**
     *
     * @throws Throwable
     */
    @And("^user clicks on clear button on Rules manager page$")
    public void userClicksOnClearButtonOnRulesManagerPage() throws Throwable {
        new RulesManager(scenario, driver()).clear();
    }

    @And("^User validates the \"([^\"]*)\" with search data$")
    public void userValidatesTheWithSearchData(String exceptionName,DataTable table) throws Throwable {

        List<Map<String, String>> maps = WhiteBoard.resolve(owner, table.asMaps(String.class, String.class));
        Map<String, String> map = null;
        for (Map<String, String> m : maps) {
            map = m;
            new RulesManager(scenario, driver()).validateSearchByCriteria(exceptionName, map);
        }

    }


    @And("^User selects the \"([^\"]*)\" drugs$")
    public void userSelectsTheDrugs(String exceptionName,DataTable table) throws Throwable {
        List<Map<String, String>> maps = WhiteBoard.resolve(owner, table.asMaps(String.class, String.class));
        Map<String, String> map = null;
        for (Map<String, String> m : maps) {
            map = m;
            new RulesManager(scenario, driver()).enterDrugDetails(exceptionName, map);
        }
    }
    
     @And("^User selects \"([^\"]*)\" from Buy and Bill dropdown in the Clone Request Page$")
    public void userSelectsFromBuyAndBillDropdownInTheCloneRequestPage(String arg0) throws Throwable {
        obj().CloneRequestPage.selectBuyAndBill(arg0);
    }

    @And("^User verified \"([^\"]*)\" is visible on the page$")
    public void userVerifiedIsVisibleOnThePage(String arg0) throws Throwable {

        new RulesManager(scenario,driver()).checkBuyAndBill(arg0);
    }

    @And("^User should verify BuyAndBill message and \"([^\"]*)\" button is disabled$")
    public void userShouldVerifyBuyAndBillMessageAndButtonIsDisabled(String arg0) throws Throwable {
        new RulesManager(scenario,driver()).checkBuyAndBillMessageForNo(arg0);
    }

    @When("^User clicks clear draft button$")
    public void user_clicks_clear_draft_button() throws Throwable {
        new RulesManager(scenario, driver()).cancelDraft();
    }

    @When("^User clicks on cancel changes button$")
    public void user_clicks_on_cancel_changes_button() throws Throwable {
        new RulesManager(scenario, driver()).clearChanges();
    }

    @When("^user clicks Continue from Product Is Not Eligible for Auto-approval$")
    public void user_clicks_continue_from_product_is_not_eligible_for_auto_approval() throws Throwable {
        new RulesManager(scenario, driver()).continueAutoApproval();
    }

    /**
     * Allows for navigation to a page within the Rules Manager.
     * @param rulePage The name of the page.
     */
    @Then("^the user navigates to the \"([^\"]*)\" rule page$")
    public void navigateToRulePage(String rulePage) throws Throwable {
        new RulesManager(scenario, driver()).navigateToRulePage(rulePage);
    }

}
