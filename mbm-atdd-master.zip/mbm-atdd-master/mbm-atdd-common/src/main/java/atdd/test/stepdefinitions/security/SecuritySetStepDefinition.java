package atdd.test.stepdefinitions.security;

import atdd.common.ScenarioLogger;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.stepsets.Login;
import atdd.test.stepsets.Security;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

public class SecuritySetStepDefinition {

    public static final Logger log = Logger.getLogger(SecuritySetStepDefinition.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;
    private WebDriver driver;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }

    @And("^user enters \"([^\"]*)\" and \"([^\"]*)\" in Save permission section$")
    public void userEntersAndInSavePermissionSection(String arg0, String arg1) throws Throwable {
        new Security(scenario, driver()).addPermission(arg0, arg1);
    }

    @And("^user saves permission$")
    public void userSavesPermission() throws Throwable {
        new Security(scenario,driver()).savePermission();
    }

    @And("^user clicks Edit permission icon$")
    public void userClicksEditIcon() throws Throwable {
        new Security(scenario,driver()).editPermission();
    }

    @And("^user enters \"([^\"]*)\" and \"([^\"]*)\" in Save permission Group section$")
    public void userEntersAndInSavePermissionGroupSection(String arg0, String arg1) throws Throwable {
        new Security(scenario, driver()).addPermissionGroup(arg0, arg1);
    }

    @And("^user clicks Edit permission group icon$")
    public void userClicksEditPermissionGroupIcon() throws Throwable {
        new Security(scenario,driver()).editPermissionGroup();
    }

    @And("^user clicks Edit User icon$")
    public void userClicksEditUserIcon() throws Throwable{
        TestUtils.wait(3);
        new Security(scenario,driver()).editUser();
    }
}
