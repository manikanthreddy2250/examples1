package atdd.test.stepdefinitions.supportiveMaintenance;

import atdd.common.ScenarioLogger;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.stepsets.Login;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;


public class AddSupportiveDrugsModalStepDefinition {
    public static final Logger log = Logger.getLogger(AddSupportiveDrugsModalStepDefinition.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }


    @And("^User Selects \"([^\"]*)\" as drug code in Add Supportive Drugs PopUp$")
    public void userSelectsAsDrugCodeInAddSupportiveDrugsPopUp(String drugCode) throws Throwable {
        obj().AddSupportiveDrugsModalPage.enterDrugCode(drugCode);
    }

    @And("^User enters \"([^\"]*)\" as drug name in Add Supportive Drugs PopUp$")
    public void userEntersAsDrugNameInAddSupportiveDrugsPopUp(String drugName) throws Throwable {
        obj().AddSupportiveDrugsModalPage.enterDrugName(drugName);
    }

    @And("^User Selects \"([^\"]*)\" as drug type in Add Supportive Drugs PopUp$")
    public void userSelectsAsDrugTypeInAddSupportiveDrugsPopUp(String drugType) throws Throwable {
        obj().AddSupportiveDrugsModalPage.selectDrugType(drugType);
    }

    @And("^User enters \"([^\"]*)\" as drugdosage in Add Supportive Drugs PopUp$")
    public void userEntersAsDrugdosageInAddSupportiveDrugsPopUp(String dosage) throws Throwable {
        obj().AddSupportiveDrugsModalPage.enterDosage(dosage);
    }

    @And("^User Selects \"([^\"]*)\" as drug route in Add Supportive Drug PopUp$")
    public void userSelectsAsDrugRouteInAddSupportiveDrugPopUp(String drugRoute) throws Throwable {
        obj().AddSupportiveDrugsModalPage.enterDrugRoute(drugRoute);
    }

    @And("^User enters \"([^\"]*)\" as cycle to be administered in Add Supportive Drug PopUp$")
    public void userEntersAsCycleToBeAdministeredInAddSupportiveDrugPopUp(String cycle) throws Throwable {
        obj().AddSupportiveDrugsModalPage.enterCycleToBeAdministered(cycle);
    }

    @And("^User enters \"([^\"]*)\" as lengthofcycles in Add Supportive Drug PopUp$")
    public void userEntersAsLengthofcyclesInAddSupportiveDrugPopUp(String lenghtOfCycle) throws Throwable {
        obj().AddSupportiveDrugsModalPage.enterLengthOfCycles(lenghtOfCycle);
    }

    @And("^User enters \"([^\"]*)\" as authorizationduration in Add Supportive Drug PopUp$")
    public void userEntersAsAuthorizationdurationInAddSupportiveDrugPopUp(String authDuration) throws Throwable {
        obj().AddSupportiveDrugsModalPage.enterAuthorizationDuration(authDuration);
    }

    @And("^User enters \"([^\"]*)\" as startdate in Add Supportive Drug PopUp$")
    public void userEntersAsStartdateInAddSupportiveDrugPopUp(String startDate) throws Throwable {
        obj().AddSupportiveDrugsModalPage.enterStartDate(startDate);
    }

    @And("^User enters \"([^\"]*)\" as inactive date in Add Supportive Drug PopUp$")
    public void userEntersAsInactiveDateInAddSupportiveDrugPopUp(String inactiveDate) throws Throwable {
        obj().AddSupportiveDrugsModalPage.enterInactiveDate(inactiveDate);
    }

    @And("^User enters \"([^\"]*)\" as message in Add Supportive Drug PopUp$")
    public void userEntersAsMessageInAddSupportiveDrugPopUp(String message) throws Throwable {
        obj().AddSupportiveDrugsModalPage.enterMessage(message);
    }

    @And("^User clicks Save button on Add Supportive Drug PopUp$")
    public void userClicksSaveButtonOnAddSupportiveDrugPopUp() throws Throwable {
        obj().AddSupportiveDrugsModalPage.clickSaveButton();
    }

    @And("^User verifies \"([^\"]*)\" is present in drug type dropdown in Add Supportive Drugs PopUp$")
    public void userVerifiesIsPresentInDrugTypeDropdownInAddSupportiveDrugsPopUp(String drugType) throws Throwable {
        obj().AddSupportiveDrugsModalPage.verifyDrugType(drugType);
    }

    @And("^User Selects \"([^\"]*)\" as cancer type in Add Supportive Drugs PopUp$")
    public void userSelectsAsCancerTypeInAddSupportiveDrugsPopUp(String cancerType) throws Throwable {
        obj().AddSupportiveDrugsModalPage.selectCancerType(cancerType);
    }


    @And("^User verifies Cancer Type label present in Add Supportive Drugs PopUp$")
    public void userVerifiesCancerTypeLabelPresentInAddSupportiveDrugsPopUp() throws Throwable {
        obj().AddSupportiveDrugsModalPage.verifyCancerType();
    }

    @And("^User verifies \"([^\"]*)\" as drug code in Add Supportive Drugs PopUp$")
    public void userVerifiesAsDrugCodeInAddSupportiveDrugsPopUp(String drugCode) throws Throwable {
        obj().AddSupportiveDrugsModalPage.verifyDrugCode(drugCode);
    }
}
