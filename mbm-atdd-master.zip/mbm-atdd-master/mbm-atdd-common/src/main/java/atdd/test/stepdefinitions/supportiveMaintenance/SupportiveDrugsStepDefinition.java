package atdd.test.stepdefinitions.supportiveMaintenance;

import atdd.test.core.SearchCriteria;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.pageobjects.supportiveMaintenance.SupportiveDrugsPage;
import atdd.test.shared.BaseCucumber;
import atdd.test.shared.Globals;
import atdd.test.stepsets.AuthorizationRequest;
import atdd.test.stepsets.Login;
import atdd.utils.DataTableUtils;
import atdd.utils.LocationUtils;
import atdd.utils.TestUtils;
import atdd.utils.WhiteBoard;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import java.util.List;
import java.util.Map;


public class SupportiveDrugsStepDefinition {

    public final static Logger log = Logger.getLogger(SupportiveDrugsStepDefinition.class);
    TestUtils utils = BaseCucumber.utils;

    private Scenario scenario;
    private String owner;
    public static Globals gv;
    public AuthorizationRequest authorizationRequest;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
    }

    @Then("^User click on \"([^\"]*)\" hyperlink on Supportive Drugs page$")
    public void userClickOnHyperlinkOnSupportiveDrugsPage(String hyperlink) throws Throwable {
        obj().CommonPage.clickOnHyperlink(hyperlink);
    }

    @Then("^User click Edit icon on on Supportive Drugs page$")
    public void userClickEditIconOnOnSupportiveDrugsPage() throws Throwable {
        obj().SupportiveDrugsPage.clickEditIcon();
    }

    @And("^User click on the delete icon on Supportive Drugs page$")
    public void userClickOnTheDeleteIconOnSupportiveDrugsPage() throws Throwable {
        obj().SupportiveDrugsPage.clcikDeleteIcon();
    }

    @And("^User click yes button on Delete Supportive Drug$")
    public void userClickYesButtonOnDeleteSupportiveDrug() throws Throwable {
        obj().SupportiveDrugsPage.clickYesButton();
    }

    @And("^User should see Cancer Type column on Supportive Drugs page$")
    public void userShouldSeeCancerTypeColumnOnSupportiveDrugsPage() throws Throwable {
        obj().SupportiveDrugsPage.verifyCancerType();

    }

    @And("^User verifes \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" on Supportive Drugs page$")
    public void userVerifesOnSupportiveDrugsPage(String drugCode, String drugName, String drugType, String cancerType, String drugRoute, String authorizationDuration, String startDate, String inactiveDate) throws Throwable {
        obj().SupportiveDrugsPage.verifySupportiveDrugDetails(drugCode, drugName, drugType, cancerType, drugRoute, authorizationDuration, startDate, inactiveDate);
    }

    @And("^User verifies \"([^\"]*)\" is present in Delete supportive drug alert on Supportive Drugs page$")
    public void userVerifiesIsPresentInDeleteSupportiveDrugAlertOnSupportiveDrugsPage(String drugName) throws Throwable {
        obj().SupportiveDrugsPage.verifyDeleteConfirmationMessage(drugName);
    }

    @And("^User verifies \"([^\"]*)\" got deleted on Add Supportive Drug PopUp$")
    public void userVerifiesGotDeletedOnAddSupportiveDrugPopUp(String drugName) throws Throwable {
        obj().SupportiveDrugsPage.verifyDrugDeletedSuccessfuly(drugName);
    }

    @And("^User click on the delete icon for the created Supportive Drug \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" on Supportive Drugs page$")
    public void userClickOnTheDeleteIconForTheCreatedSupportiveDrugOnSupportiveDrugsPage(String drugCode, String drugName, String authorizationDuration) throws Throwable {
        obj().SupportiveDrugsPage.deleteSupportiveDrug(drugCode, drugName, authorizationDuration);
    }

    @And("^User click on the edit icon for the created Supportive Drug \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" on Supportive Drugs page$")
    public void userClickOnTheEditIconForTheCreatedSupportiveDrugOnSupportiveDrugsPage(String drugCode, String drugName, String authorizationDuration) throws Throwable {
        obj().SupportiveDrugsPage.editSupportiveDrug(drugCode, drugName, authorizationDuration);
    }

    @Then("^user should see the Cancer Type field is between the Drug Type and the Drug Route search fields$")
    public void userShouldSeeTheCancerTypeFieldIsBetweenTheDrugTypeAndTheDrugRouteSearchFields() throws Throwable {
        Assert.assertTrue(LocationUtils.leftRightSameRow(driver(), SupportiveDrugsPage.drugTypeInput, SupportiveDrugsPage.cancerTypeInput));
        Assert.assertTrue(LocationUtils.leftRightSameRow(driver(), SupportiveDrugsPage.cancerTypeInput, SupportiveDrugsPage.drugRouteInput));
    }

    @When("^user searches the Supportive Drugs by \"([^\"]*)\"$")
    public void userSearchesTheSupportiveDrugsBy(String stringMap) throws Throwable {
        stringMap = WhiteBoard.resolve(owner, stringMap);
        log.warn("stringMap=" + stringMap);

        Map<String, String> criteria = DataTableUtils.asMap(stringMap);
        String filterTableXpath = "//form[@name='supportiveDrugTableFormtableFilters']/table";
        new SearchCriteria(scenario, driver()).setCriteria(criteria, filterTableXpath);

        obj().SupportiveDrugsPage.clickSearchButton();
        TestUtils.wait(1);
    }

    @Then("^user should see \"([^\"]*)\" in the search result on Supportive Drugs page$")
    public void userShouldSeeInTheSearchResultOnSupportiveDrugsPage(String pagination) throws Throwable {
        String text = obj().SupportiveDrugsPage.getPaginationText();
        Assert.assertTrue(text.contains(pagination));
    }

    @When("^user inputs \"([^\"]*)\" in Cancer Type field on Supportive Drugs page$")
    public void userInputsInCancerTypeFieldOnSupportiveDrugsPage(String text) throws Throwable {
        obj().SupportiveDrugsPage.inputCancerType(text);
        TestUtils.wait(1);
    }

    @Then("^user should see only below options are listed in the Cancer Type Dropdown on Supportive Drugs page$")
    public void userShouldSeeOnlyBelowOptionsAreListedInTheCancerTypeDropdownOnSupportiveDrugsPage(List<String> expectedList) throws Throwable {
        List<String> actualList = obj().SupportiveDrugsPage.getCancerTypeDropdownList();
        Assert.assertEquals(expectedList, actualList);
    }

    @And("^user clicks on Search button on the Supportive Drugs page$")
    public void userClicksOnSearchButtonOnTheSupportiveDrugsPage() throws Throwable {
        obj().SupportiveDrugsPage.clickSearchButton();
    }

    @Then("^user should see \"([^\"]*)\" in the Cancer Type field on Supportive Drugs page$")
    public void userShouldSeeInTheCancerTypeFieldOnSupportiveDrugsPage(String expectedValue) throws Throwable {
        String actualValue = obj().SupportiveDrugsPage.getCancerTypeValue();
        Assert.assertEquals(expectedValue, actualValue);
    }

    @Then("^user should see \"([^\"]*)\" in the search result table foot on Supportive Drugs page$")
    public void userShouldSeeInTheSearchResultTableFootOnSupportiveDrugsPage(String expectedMessage) throws Throwable {
        String actualMessage = obj().SupportiveDrugsPage.getFooterMessage();
        Assert.assertEquals(expectedMessage, actualMessage);
    }
}

