package atdd.test.stepdefinitions.traversalMaintenance;

import atdd.common.ScenarioLogger;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.stepsets.Login;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.Then;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

public class BulkDeleteModalPageStepDefinition {
    public static final Logger log = Logger.getLogger(BulkDeleteModalPageStepDefinition.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }

    @Then("^User clicks YES on the Bulk Edit Traversals PopUp window$")
    public void clickYesBulkDelete() throws Throwable {
        obj().BulkDeleteModalPage.clickYesButton();
    }

    @Then("^User clicks Cancel on the Bulk Edit Traversals PopUp window$")
    public void clickCancelBulkDelete() throws Throwable {
        obj().BulkDeleteModalPage.clickCancelLink();
    }

    @Then("^User clicks X on the Bulk Edit Traversals PopUp window$")
    public void clickXBulkDelete() throws Throwable {
        obj().BulkDeleteModalPage.clickXoutButton();
    }

    @Then("^Verify all elements on Bulk Edit Traversals PopUp window$")
    public void verifyBulkDelete() throws Throwable {
        //Open
        obj().TraversalMaintenancePage.applyBulkAction("Delete");
        TestUtils.wait(1);
        //Check txt
        obj().CommonPage.checkElementByText("Bulk Delete Traversals");
        obj().CommonPage.checkElementByText("Are you sure you want to delete these traversals?");

        //Close and verify that it's not visible
        obj().BulkDeleteModalPage.clickXoutButton();
        TestUtils.wait(1);
        obj().CommonPage.checkNotElementByText("Bulk Delete Traversals");
        obj().CommonPage.checkNotElementByText("Are you sure you want to delete these traversals?");

        //Open
        obj().TraversalMaintenancePage.applyBulkAction("Delete");
        TestUtils.wait(1);
        //Check txt
        obj().CommonPage.checkElementByText("Bulk Delete Traversals");
        obj().CommonPage.checkElementByText("Are you sure you want to delete these traversals?");

        //Click Cancel and verify that it' not visible
        obj().BulkDeleteModalPage.clickCancelLink();
        TestUtils.wait(1);
        obj().CommonPage.checkNotElementByText("Bulk Delete Traversals");
        obj().CommonPage.checkNotElementByText("Are you sure you want to delete these traversals?");

    }
}
