package atdd.test.stepdefinitions.traversalMaintenance;


import atdd.common.ScenarioLogger;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.stepsets.Login;
import atdd.utils.TestUtils;
import atdd.utils.WhiteBoard;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

public class EditTraversalModalStepDefinition {
    public static final Logger log = Logger.getLogger(EditTraversalModalStepDefinition.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }

    @And("^Verify that Variable Value text is \"([^\"]*)\" on Edit Traversal pop up$")
    public void verifyVariableValue(String txt) throws Throwable {
        obj().EditTraversalModalPage.verifyVariableValue(txt);
    }

    @And("^Verify that Variable Type selection is \"([^\"]*)\" on Edit Traversal pop up$")
    public void verifyVariableType(String txt) throws Throwable {
        obj().EditTraversalModalPage.verifyVariableType(txt);
    }

    @And("^User enters \"([^\"]*)\" variable Type on Add Traversal pop up window$")
    public void userEntersVariableValue(String variableValue) throws Throwable {
        obj().EditTraversalModalPage.enterVariableValue(variableValue);
    }

    @Then("^User verifies Edit Traversal pop up window$")
    public void userVerifiesEditTraversalPopUpWindow() throws Throwable {
        obj().EditTraversalModalPage.verifyEditTraversalPopUp();
    }

    @And("^User verifies Cancer Type as a drop down list on Edit Traversal pop up$")
    public void userVerifiesCancerTypeAsADropDownListOnEditTraversalPopUp() throws Throwable {
        obj().EditTraversalModalPage.verifyCancerTypeAsDropDown();
    }

    @And("^User verifies grey line underneath clinical Variable on Edit Traversal pop up$")
    public void userVerifiesGreyLineUnderneathClinicalVariableOnEditTraversalPopUp() throws Throwable {
        obj().EditTraversalModalPage.verifyGreyLineUnderneathClinicalVariable();
    }

    @And("^User verifies Variable Value as a drop down list on Edit Traversal pop up$")
    public void userVerifiesVariableValueAsADropDownListOnEditTraversalPopUp() throws Throwable {
        obj().EditTraversalModalPage.verifyVariableValueAsDropDownList();
    }

    @And("^User verifies Variable Type as a drop down list on Edit Traversal pop up$")
    public void userVerifiesVariableTypeAsADropDownListOnEditTraversalPopUp() throws Throwable {
        obj().EditTraversalModalPage.verifyVariableTypeAsDropDownList();
    }

    @And("^User verifies Type pre-populated with the traversal type on Edit Traversal pop up$")
    public void userVerifiesTypePrePopulatedWithTheTraversalTypeOnEditTraversalPopUp() throws Throwable {
        obj().EditTraversalModalPage.verifyTraversalTypePrePopulated();
    }

    @And("^User verifies Value pre-populated with the traversal value on Edit Traversal pop up$")
    public void userVerifiesValuePrePopulatedWithTheTraversalValueOnEditTraversalPopUp() throws Throwable {
        obj().EditTraversalModalPage.verifyTraversalValuePrePopulated();
    }

    @And("^User verifies X Remove as an action button on Edit Traversal pop up$")
    public void userVerifiesXRemoveAsAnActionButtonOnEditTraversalPopUp() throws Throwable {
        obj().EditTraversalModalPage.verifyRemoveActionButton();
    }

    @And("^User verifies Save button on Edit Traversal pop up$")
    public void userVerifiesSaveButtonOnEditTraversalPopUp() throws Throwable {
        obj().EditTraversalModalPage.verifySaveButton();
    }

    @And("^User verifies Cancel Link on Edit Traversal pop up$")
    public void userVerifiesCancelLinkOnEditTraversalPopUp() throws Throwable {
        obj().EditTraversalModalPage.verifyCancelLink();
    }

    @And("^Element with text \"([^\"]*)\" and Required mark is visible on Edit Traversal pop up$")
    public void elementWithTextAndRequiredMarkIsVisibleOnEditTraversalPopUp(String txt) throws Throwable {
        obj().EditTraversalModalPage.checkRequiredElementByText(txt);
    }

    @And("^Element with Required mark along with text Required is visible on Edit Traversal pop up$")
    public void elementWithRequiredMarkAlongWithTextIsVisibleOnEditTraversalPopUp() throws Throwable {
        obj().EditTraversalModalPage.checkElementByTextWithRequiredMark();
    }

    @And("^User verifies Start date is pre-populated on Edit Traversal pop up$")
    public void userVerifiesStartDateIsPrePopulatedOnEditTraversalPopUp() throws Throwable {
        obj().EditTraversalModalPage.verifyStartDatePrePopulated();
    }

    @And("^User verifies calender picker beside Start Date on Edit Traversal pop up$")
    public void userVerifiesCalenderPickerBesideStartDateOnEditTraversalPopUp() throws Throwable {
        obj().EditTraversalModalPage.verifyCalenderPickerBesideStartDate();
    }

    @And("^User verifies End date is pre-populated on Edit Traversal pop up$")
    public void userVerifiesEndDateIsPrePopulatedOnEditTraversalPopUp() throws Throwable {
        obj().EditTraversalModalPage.verifyEndDatePrePopulated();
    }

    @And("^User verifies calender picker beside End Date on Edit Traversal pop up$")
    public void userVerifiesCalenderPickerBesideEndDateOnEditTraversalPopUp() throws Throwable {
        obj().EditTraversalModalPage.verifyCalenderPickerBesideEndDate();
    }

    @And("^Element with text Clinical Variable title on Edit Traversal pop up$")
    public void elementWithTextClinicalVariableTitleOnEditTraversalPopUp() throws Throwable {
        obj().EditTraversalModalPage.verifyClinicalVariableTitle();
    }

    @And("^User verifies Add Clinical Variable link on Edit Traversal pop up$")
    public void userVerifiesAddClinicalVariableLinkOnEditTraversalPopUp() throws Throwable {
        obj().EditTraversalModalPage.verifyAddClinicalVariabelLink();
    }

    @When("^User click Remove link on Edit Traversal pop up$")
    public void userClickRemoveLinkOnEditTraversalPopUp() throws Throwable {
        obj().EditTraversalModalPage.clickRemoveLink();
    }

    @And("^User selects \"([^\"]*)\" variable Type on Edit Traversal pop up window$")
    public void userSelectsVariableTypeOnEditTraversalPopUpWindow(String variableType) throws Throwable {
        obj().EditTraversalModalPage.selectVariableType(variableType);
    }

    @And("^User selects \"([^\"]*)\" variable value on Edit Traversal pop up window$")
    public void userSelectsVariableValueOnEditTraversalPopUpWindow(String variableValue) throws Throwable {
        obj().EditTraversalModalPage.selectVariableValue(variableValue);
    }

    @When("^User enter the \"([^\"]*)\" values in Clinical Variable Type and Variable Value in Edit Traversal pop up window$")
    public void user_enter_values_in_Edit_Traversal_pop_up_window(String description) throws Throwable {
        obj().EditTraversalModalPage.selectVariableTypeAndVariableValue(description);
    }

    @When("^User click cancel link on Edit Traversal pop up window$")
    public void userClickCancelLinkOnEditTraversalPopUpWindow() throws Throwable {
        obj().EditTraversalModalPage.clickCancelLink();
    }

    @And("^User enters \"([^\"]*)\" start date on Edit Traversal pop up$")
    public void userEntersStartDateOnEditTraversalPopUp(String startDate) throws Throwable {
        String todayDate = WhiteBoard.resolve(owner, startDate);
        obj().EditTraversalModalPage.enterStartDate(todayDate);
    }

    @And("^User clears end date on Edit Traversal pop up$")
    public void userClearsEndDateOnEditTraversalPopUp() throws Throwable {
        obj().EditTraversalModalPage.clearEndDate();
    }

    @And("^User clears Authorization Duration on Edit Traversal pop up$")
    public void userClearsAuthorizationDurationOnEditTraversalPopUp() throws Throwable {
        obj().EditTraversalModalPage.clearAutorizationDuration();
    }

    @And("^User verifies Authorization Duration is pre-populated on Edit Traversal pop up$")
    public void userVerifiesAuthorizationDurationIsPrePopulatedOnEditTraversalPopUp() throws Throwable {
        obj().EditTraversalModalPage.verifyAuthorizationDurationPopulated();
    }

    @And("^User clicks save button on Edit Traversal pop up$")
    public void userClicksSaveButtonOnEditTraversalPopUp() throws Throwable {
        obj().EditTraversalModalPage.clickSaveButton();
        TestUtils.wait(3);
    }

    @And("^User verifies Type and Value removed from Edit Traversal pop up$")
    public void userVerifiesTypeAndValueRemovedFromEditTraversalPopUp() throws Throwable {
        obj().EditTraversalModalPage.verifyTypeAndValueRemoved();
    }

    @And("^User continues to see if any remaning values are displayed on Edit Traversal pop up$")
    public void userContinuesToSeeIfAnyRemaningValuesAreDisplayedOnEditTraversalPopUp() throws Throwable {
        obj().EditTraversalModalPage.verifyRemainingTypeAndValuesAreDisplayed();
    }

    @When("^User tries to Remove all Type and Value on Edit Traversal pop up$")
    public void userTriesToRemoveAllTypeAndValueOnEditTraversalPopUp() throws Throwable {
        obj().EditTraversalModalPage.removeAllTypesAndValues();
    }

    @And("^User verifies \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" that was entered will be discarded on Edit Traversal pop up$")
    public void userVerifiesThatWasEnteredWillBeDiscarded(String variableType, String variableValue, String startDate) throws Throwable {
        obj().EditTraversalModalPage.verifyGivenValuesAreDiscarded(variableType, variableValue, startDate);
    }

    @And("^User enters \"([^\"]*)\" end date on Edit Traversal pop up$")
    public void userEntersEndDateOnEditTraversalPopUp(String endDate) throws Throwable {
        String tomorrowDate = WhiteBoard.resolve(owner, endDate);
        obj().EditTraversalModalPage.enterEndDate(tomorrowDate);
    }

    @And("^User enters \"([^\"]*)\" Authorization Duration on Edit Traversal pop up$")
    public void userEntersAuthorizationDurationOnEditTraversalPopUp(String authorizationDuration) throws Throwable {
        obj().EditTraversalModalPage.enterAuthorizationDuration(authorizationDuration);
    }

    @And("^User verifies red border around and \"([^\"]*)\" error message in red color for any required input that is not populated on Edit Traversal pop up$")
    public void userVerifiesRedBorderAroundAndThisFieldIsRequiredErrorMessageInRedColorForAnyRequiredInputThatIsNotPopulated(String txtMessage) throws Throwable {
        obj().EditTraversalModalPage.verifyingRedColorBorderAndMessage(txtMessage);
    }

    @And("^User clicks Add clinical variable on Edit Traversal pop up$")
    public void userClicksAddClinicalVariableOnEditTraversalPopUp() throws Throwable {
        obj().EditTraversalModalPage.clickAddClinicalVariable();
    }

    @When("^User removes \"([^\"]*)\" and \"([^\"]*)\" if already present on Edit Traversal pop up$")
    public void userRemovesAndIfAlreadyPresentOnEditTraversalPopUp(String variableType, String variableValue) throws Throwable {
        obj().EditTraversalModalPage.RemoveVariableTypeAndVariableValueIfAlreadyPresent(variableType, variableValue);
    }

    @And("^user selects Cancer Type as \"([^\"]*)\" on Edit Traversal pop up$")
    public void userSelectsCancerTypeAsOnEditTraversalPopUp(String cancerType) throws Throwable {
        obj().EditTraversalModalPage.selectCancerTypeOnEditTraversal(cancerType);
    }

    @And("^User stores Remove link rows on Edit Traversal pop up$")
    public void userStoresRemoveLinkRowsOnEditTraversalPopUp() throws Throwable {
        obj().EditTraversalModalPage.storeRemoveLinkRows();
    }
}
