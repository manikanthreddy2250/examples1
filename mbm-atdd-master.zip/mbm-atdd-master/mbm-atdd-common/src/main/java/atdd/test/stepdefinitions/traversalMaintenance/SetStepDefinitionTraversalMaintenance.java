package atdd.test.stepdefinitions.traversalMaintenance;

import atdd.common.ImmediateAbortException;
import atdd.common.ScenarioLogger;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.pageobjects.traversalMaintenance.ImportNewTraversalsPage;
import atdd.test.pageobjects.traversalMaintenance.TraversalMaintenancePage;
import atdd.test.stepsets.Login;
import atdd.test.stepsets.RequestStatus;
import atdd.test.stepsets.TraversalMaintenance;
import atdd.utils.ExcelLib;
import atdd.utils.InvalidSearchCriteriaException;
import atdd.utils.TestUtils;
import atdd.utils.WhiteBoard;
import cucumber.api.DataTable;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import java.util.*;

public class SetStepDefinitionTraversalMaintenance {
    public static final Logger log = Logger.getLogger(SetStepDefinitionTraversalMaintenance.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }


    /**
     * User searches the traversal based on criteria provided in @param dataTable
     *
     * @param dataTable
     * @throws Throwable
     */
    @Given("^user searches the traversal by below criteria on the Traversal Maintenance page$")
    public void userSearchesTheTraversalByBelowCriteriaOnTheTraversalMaintenancePage(DataTable dataTable) throws Throwable {
        Map<String, String> theUser = WhiteBoard.getInstance().getMap(owner, ExcelLib.THE_USER);
        Login.login(scenario, theUser);
        new TraversalMaintenance(scenario, driver()).search(dataTable.asMaps(String.class, String.class).get(0));
    }

    /**
     * User edit the traversal on the traversalMaintenance Page based on @param dataTable
     *
     * @param traversalId
     * @param dataTable
     */
    @Then("^user edit the traversal \"([^\"]*)\" on the Traversal Maintenance page with below updates$")
    public void userEditTheTraversalOnTheTraversalMaintenancePageWithBelowUpdates(String traversalId, DataTable dataTable) throws Throwable {
        new TraversalMaintenance(scenario, driver()).editTraversalById(traversalId, dataTable.asMaps(String.class, String.class).get(0));
    }

    /**
     * Traversal Object is extracted On The traversal maintenancePage based on @param traversalIdOrRow
     *
     * @param objectName
     * @param traversalIdOrRow
     */
    @And("^traversal object \"([^\"]*)\" is extracted by \"([^\"]*)\" on the Traversal Maintenance page$")
    public void traversalObjectIsExtractedByOnTheTraversalMaintenancePage(String objectName, String traversalIdOrRow) throws Throwable {
        if (traversalIdOrRow.startsWith("row")) {
            traversalIdOrRow = obj().TraversalMaintenancePage.getTraversalIdByRow(traversalIdOrRow.split("\\s+", 2)[1]);
        }
        TraversalMaintenance traversalMaintenance = new TraversalMaintenance(scenario, driver());
        Map<String, String> traversal = traversalMaintenance.extractTraversalById(traversalIdOrRow);
        WhiteBoard.getInstance().putMap(owner, objectName, traversal);
    }


    /**
     * Assumption: traversalMaintenance page is displayed.
     * Extract  information from traversalMaintenance page and stores in whiteBoard
     *
     * @param traversalName
     */
    @And("^traversal object \"([^\"]*)\" is extracted from the Request Status page$")
    public void traversalObjectIsExtractedFromTheRequestStatusPage(String traversalName) throws Throwable {
        RequestStatus traversalMaintenance = new RequestStatus(scenario, driver());
        Map<String, String> traversal = traversalMaintenance.extractTheTraversal();
        WhiteBoard.getInstance().putMap(owner, traversalName, traversal);
    }


    /**
     * User enter the Clinical Variable type and variable Value in Edit Traversal
     *
     * @param description
     */
    @When("^User enter the \"([^\"]*)\" Clinical Variable Type and Variable Value in Edit Traversal$")
    public void user_enter_the_Clinical_Variable_Type_and_Variable_Value_in_Edit_Traversal(String description) throws Throwable {
        String Description = WhiteBoard.resolve(owner, description);
        obj().EditTraversalModalPage.selectVariableTypeAndVariableValue(Description);
    }

    /**
     * UserRemovesAllTraversalsWithBelowCriteriaOnTheTraversalMaintenancePage based on feature file data table
     *
     * @param dataTable
     * @throws Throwable
     */
    @Then("^user removes all traversals with below criteria on the Traversal Maintenance page$")
    public void userRemovesAllTraversalsWithBelowCriteriaOnTheTraversalMaintenancePage(DataTable dataTable) throws Throwable {
        try {
            this.userSearchesTheTraversalByBelowCriteriaOnTheTraversalMaintenancePage(dataTable);
        } catch (InvalidSearchCriteriaException e) {
            return;
        } catch (ImmediateAbortException e) {
            e.printStackTrace();
        }
        while (obj().TraversalMaintenancePage.hasResult()) {
            obj().TraversalMaintenancePage.removeFirstResut();
        }
    }

    /**
     * UserAddBelowTraversalsOnTheTraversalMaintenancePage
     *
     * @param dataTable
     */
    @Given("^user add below traversals on the Traversal Maintenance page$")
    public void userAddBelowTraversalsOnTheTraversalMaintenancePage(DataTable dataTable) throws Throwable {
        List<Map<String, String>> maps = WhiteBoard.resolve(owner, dataTable.asMaps(String.class, String.class));
        new TraversalMaintenance(scenario, driver()).add(maps);
    }

    /**
     * Assumption: BulkChangeVariableValueModalPage is displayed.
     * verify the UI Of bulk change variable value PopupModal
     */
    @Then("^verify the UI of Bulk Change Variable Value popup modal$")
    public void verifyTheUIOfBulkChangeVariableValuePopupModal() throws Throwable {
        TraversalMaintenance tm = new TraversalMaintenance(scenario, driver());
        tm.applyBulkAction("Change Variable Value");
        tm.verifyBulkChangeVariableValueUI();
        obj().BulkChangeVariableValueModalPage.clickCancelLink();
        obj().BulkChangeVariableValueModalPage.shouldDisappear();

        tm.applyBulkAction("Change Variable Value");
        obj().BulkChangeVariableValueModalPage.clickXoutButton();
        obj().BulkChangeVariableValueModalPage.shouldDisappear();

        TestUtils.demoBreakPoint(scenario, driver(), "UI Check OK");
    }


    /**
     * Assumption: BulkChangeVariableValueModalPage is displayed.
     * verify The variable type dropdown list contains only contains the options based on feature file variable
     */
    @And("^verify the Variable Type dropdown list contains and only contains the options \"([^\"]*)\"$")
    public void verifyTheVariableTypeDropdownListContainsAndOnlyContainsTheOptions(String expectedOptionsString) throws Throwable {
        String[] expectedOptions = expectedOptionsString.split("\\s*,\\s*");
        Set<String> expectedOptionSet = new HashSet<String>(Arrays.asList(expectedOptions));
        Set<String> actualOptionSet = obj().BulkChangeVariableValueModalPage.getVariableTypeOptions();
        Assert.assertEquals(expectedOptionSet, actualOptionSet);

        obj().BulkChangeVariableValueModalPage.clickXoutButton();
        obj().BulkChangeVariableValueModalPage.shouldDisappear();
    }

    /**
     * Assumption: TraversalMaintenance is displayed.
     * User Select all rows on the traversal maintenancePage
     */
    @Given("^user select \"([^\"]*)\" on the Traversal Maintenance page$")
    public void userSelectOnTheTraversalMaintenancePage(String rowExpression) throws Throwable {
        if ("all rows".equals(rowExpression)) {
            new TraversalMaintenance(scenario, driver()).selectAll();
        }
    }

    /**
     * Assumption: TraversalMaintenance is displayed.
     * user apply bulk action to selected rows on the traversalMaintenance Page
     *
     * @param action
     */
    @And("^user apply bulk action \"([^\"]*)\" to selected rows on the Traversal Maintenance page$")
    public void userApplyBulkActionToSelectedRowsOnTheTraversalMaintenancePage(String action) throws Throwable {
        new TraversalMaintenance(scenario, driver()).applyBulkAction(action);
    }

    /**
     * User input information on bulk change variable value modal Page based on dataTable
     *
     * @param dataTable
     */
    @And("^user input below information on Bulk Change Variable Value page$")
    public void userInputBelowInformationOnBulkChangeVariableValuePage(DataTable dataTable) throws Throwable {
        List<Map<String, String>> maps = dataTable.asMaps(String.class, String.class);
        new TraversalMaintenance(scenario, driver()).bulkChangeVariableValue(maps.get(0));
    }

    @And("^user input below information on Bulk Change Variable Type page$")
    public void userInputBelowInformationOnBulkChangeVariableTypePage(DataTable dataTable) throws Throwable {
        List<Map<String, String>> maps = dataTable.asMaps(String.class, String.class);
        new TraversalMaintenance(scenario, driver()).bulkChangeVariableType(maps.get(0));
    }


    /**
     * Asserting number of rows dispalayed vs expected from feature file
     *
     * @param expectedCount
     */
    @Then("^there should be \"([^\"]*)\" rows displayed on the Traversal Maintenance page$")
    public void thereShouldBeRowsDisplayedOnTheTraversalMaintenancePage(String expectedCount) throws Throwable {
        String actualCount = obj().TraversalMaintenancePage.getResultCount();
        Assert.assertEquals(expectedCount, actualCount);
    }

    /**
     * verifying the UI of Bulk Edit Authorization Duration popup modal
     */
    @Then("^verify the UI of Bulk Edit Authorization Duration popup modal$")
    public void verifyTheUIOfBulkEditAuthorizationDurationPopupModal() throws Throwable {
        TraversalMaintenance tm = new TraversalMaintenance(scenario, driver());
        tm.applyBulkAction("Edit Authorization Duration");
        tm.verifyBulkEditAuthorizationUI();
        obj().BulkEditAuthorizationDurationModalPage.clickCancelLink();
        obj().BulkEditAuthorizationDurationModalPage.shouldDisappear();

        tm.applyBulkAction("Edit Authorization Duration");
        obj().BulkEditAuthorizationDurationModalPage.clickXoutButton();
        obj().BulkEditAuthorizationDurationModalPage.shouldDisappear();
    }

    /**
     * User input information on Bulk Edit Authorization Duration page based on dataTable
     *
     * @param dataTable
     */
    @And("^user input below information on Bulk Edit Authorization Duration page$")
    public void userInputBelowInformationOnBulkEditAuthorizationDurationPage(DataTable dataTable) throws Throwable {
        List<Map<String, String>> maps = dataTable.asMaps(String.class, String.class);
        String value = maps.get(0).get("Duration");
        new TraversalMaintenance(scenario, driver()).verifyBulkEditAuthorization(value);
    }

    /**
     * Verifying the UI of Bulk Delete popup modal
     *
     * @throws Throwable
     */
    @Then("^verify the UI of Bulk Delete popup modal$")
    public void verifyTheUIOfBulkDeletePopupModal() throws Throwable {
        TraversalMaintenance tm = new TraversalMaintenance(scenario, driver());
        tm.applyBulkAction("Delete");
        tm.verifyBulkDeleteUI();
        obj().BulkDeleteModalPage.clickCancelLink();
        obj().BulkDeleteModalPage.shouldDisappear();

        tm.applyBulkAction("Delete");
        obj().BulkDeleteModalPage.clickXoutButton();
        obj().BulkDeleteModalPage.shouldDisappear();
    }


    /**
     * User searches the traversal on the Traversal Maintenance page based on datatable
     *
     * @param dataTable
     * @throws Throwable
     */
    @Given("^user searches the traversal on the Traversal Maintenance page$")
    public void userSearchesTheTraversalByBelowCriteriaTheTraversalMaintenancePage(DataTable dataTable) throws Throwable {
        Map<String, String> theUser = WhiteBoard.getInstance().getMap(owner, ExcelLib.THE_USER);
        new TraversalMaintenance(scenario, driver()).search(dataTable.asMaps(String.class, String.class).get(0));
    }

    /**
     * User searches and remove the traversal on the Traversal Maintenance page
     *
     * @param dataTable
     * @throws Throwable
     */
    @Then("^user removes all traversals on the Traversal Maintenance page$")
    public void userRemovesAllTraversalsOnTheTraversalMaintenancePage(DataTable dataTable) throws Throwable {
        List<Map<String, String>> data = dataTable.asMaps(String.class, String.class);

        for (Map<String, String> entry : data) {
            new TraversalMaintenance(scenario, driver()).search(entry);
            while (obj().TraversalMaintenancePage.hasResult()) {
                obj().TraversalMaintenancePage.removeFirstResut();
            }
        }
    }

    @When("^User clicks on \"([^\"]*)\" hyperlink in Traversal Maintenance Screen$")
    public void user_clicks_on_hyperlink_in_Traversal_Maintenance_Screen(String linkTitle) throws Throwable {
        obj().CommonPage.clickOnHyperlink(linkTitle);
    }

    @Then("^verify the UI of Import New Traversals Screen$")
    public void verify_the_UI_of_Import_New_Traversals_Screen() throws Throwable {
        new ImportNewTraversalsPage(driver()).verifyImportNewTraversalsUI();
    }


    @Then("^User verifies \"([^\"]*)\" is bordered red and \"([^\"]*)\" and \"([^\"]*)\" message on Traversal Maintenance Page$")
    public void user_verifies_is_bordered_red_and_message_on_Traversal_Maintenance_Page(String arg1, String arg2, String arg3) throws Throwable {
        new TraversalMaintenancePage(driver()).fieldValidationAndPopUp(arg1, arg2, arg3);
    }

    @When("^user searches the new traversal Screen by below criteria on the Traversal Maintenance page$")
    public void user_searches_the_new_traversal_Screen_by_below_criteria_on_the_Traversal_Maintenance_page(DataTable dataTable) throws Throwable {
        Map<String, String> theUser = WhiteBoard.getInstance().getMap(owner, ExcelLib.THE_USER);
        Login.login(scenario, theUser);
        List<Map<String, String>> maps = WhiteBoard.resolve(owner, dataTable.asMaps(String.class, String.class));
        new TraversalMaintenance(scenario, driver()).searchFilter(maps);
    }

    @Then("^user validates \"([^\"]*)\" in Traversal Search Result Grid$")
    public void user_validates_in_Traversal_Search_Result_Grid(String arg1) throws Throwable {
        new TraversalMaintenancePage(driver()).noRecordDisplay(arg1);
    }

    @Then("^user validates default values for Search fields on Traversal Maintenance Page$")
    public void user_validates_default_values_for_Search_fields_on_Traversal_Maintenance_Page(DataTable dataTable) throws Throwable {
        List<Map<String, String>> maps = WhiteBoard.resolve(owner, dataTable.asMaps(String.class, String.class));
        new TraversalMaintenancePage(driver()).searchFilterDefaultValues(maps);
    }

    @Then("^user verifies \"([^\"]*)\" Hyperlinks are displayed on Traversal Maintenance Page$")
    public void user_verifies_Hyperlinks_are_displayed_on_Traversal_Maintenance_Page(String arg1) throws Throwable {
        new TraversalMaintenancePage(driver()).ImportTraversalHyperlinkPresent();
    }

    @Then("^user verifies the Cancer Type Dropdown is Scrollable and displays all available Cancer Type on the Traversal Maintenance Page$")
    public void user_verifies_the_Cancer_Type_Dropdown_is_Scrollable_and_displays_all_available_cancer_Type_on_the_Traversal_Maintenance_Page() throws Throwable {
        new TraversalMaintenancePage(driver()).cancerTypeDropdownDisplayAvailableValue();
    }

    @Then("^user see a Empty Clinical Variables Dropdown When Cancer Type is not selected$")
    public void user_see_a_Empty_Clinical_Variables_Dropdown_When_Cancer_Type_is_not_selected() throws Throwable {
        new TraversalMaintenancePage(driver()).clinicalVariableDropdown();
    }

    @Then("^user verifies the Clinical Variables Dropdown behavior and dropdown values are sorted alphabetically$")
    public void user_verifies_the_Clinical_Variables_Dropdown_behavior_and_dropdown_values_are_sorted_alphabetically() throws Throwable {
        new TraversalMaintenancePage(driver()).clinicalVariableDropdown();
    }

    @Then("^user verifies Clinical variables displays the count of Variables values based on selection$")
    public void user_verifies_Clinical_variables_displays_the_count_of_Variables_values_based_on_selection() throws Throwable {
        new TraversalMaintenancePage(driver()).countOfVariablesSelected();
    }

    @Then("^user verifies the \"([^\"]*)\" Values are automatically selected$")
    public void user_verifies_the_Values_are_automatically_selected(String arg1) throws Throwable {
         new TraversalMaintenancePage(driver()).nestedVariableValuesAutomaticallySelected(arg1);
    }

    @Then("^User should only see a single search result \"([^\"]*)\" matching that \"([^\"]*)\"$")
    public void user_should_only_see_a_single_search_result_matching_that(String arg1, String exceptedTraversalID) throws Throwable {
       String actualtraversalId = obj().TraversalMaintenancePage.getTraversalIdByRow(arg1.split("\\s+", 2)[1]);
        Assert.assertEquals(exceptedTraversalID, actualtraversalId);
    }

    @Then("^Minimizing dropdown doesn't filter the values$")
    public void minimizing_dropdown_doesn_t_filter_the_values() throws Throwable {
        new TraversalMaintenancePage(driver()).minimizingDropdownNotFilter();
    }

    @Given("^User enter \"([^\"]*)\" and \"([^\"]*)\" and Preview Assessment$")
    public void user_enter_and_and_Preview_Assessment(String builderID, String templateID) throws Throwable {
        new TraversalMaintenancePage(driver()).enterBuilderIdandTemplateId(builderID,templateID);
    }

    @Then("^user verifies \"([^\"]*)\" section is not displayed when clear Button is clicked$")
    public void user_verifies_section_is_not_displayed_when_celar_Button_is_clicked(String arg1) throws Throwable {
         obj().CommonPage.userClicksAButton("Clear");
         new TraversalMaintenancePage(driver()).traversalAreaAfterClear(arg1);
    }

    @Then("^User verifies Search Result populates only ClinicalVariables which are Selected Values$")
    public void user_verifies_Search_Result_populates_only_ClinicalVariables_which_are_Selected_Values() throws Throwable {
        new TraversalMaintenancePage(driver()).traversalPopulatesvariablesSelected();
    }




}
