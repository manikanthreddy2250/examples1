package atdd.test.stepdefinitions.traversalMaintenance;

import atdd.common.ScenarioLogger;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.shared.BaseCucumber;
import atdd.test.shared.Globals;
import atdd.test.stepsets.Login;
import atdd.test.stepsets.TraversalMaintenance;
import atdd.utils.TestUtils;
import atdd.utils.WhiteBoard;
import cucumber.api.DataTable;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.List;
import java.util.Map;

public class TraversalMaintenanceStepDefinition {
    public static final Logger log = Logger.getLogger(TraversalMaintenanceStepDefinition.class.getName());

    private ScenarioLogger scenarioLogger = null;

    private Scenario scenario;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }

    TestUtils utils = BaseCucumber.utils;
    Globals gv = BaseCucumber.gv;

    @When("^Clinical Variable Value contains \"([^\"]*)\" value on the Traversal Maintenance page$")
    public void checkClinicalVariableValue(String expectedVar) throws Throwable {
        boolean expected = TestUtils.checkSelectValue(driver(), By.xpath("//*[@id='traversalSearchVariableValue']"), expectedVar);
        log.warn("Checking that Clinical Variable Value contains: " + expectedVar);
        Assert.assertTrue("Clinical Variable Type does NOT contain", expected);
    }

    @When("^Clinical Variable Value does NOT contain \"([^\"]*)\" value on the Traversal Maintenance page$")
    public void checkNotClinicalVariableValue(String expectedVar) throws Throwable {
        boolean expected = TestUtils.checkSelectValue(driver(), By.xpath("//*[@id='traversalSearchVariableValue']"), expectedVar);
        log.warn("Checking that Clinical Variable Value does NOT contain: " + expectedVar);
        Assert.assertFalse("Clinical Variable Type contains", expected);
    }

    @When("^Clinical Variable Type contains \"([^\"]*)\" value on the Traversal Maintenance page$")
    public void checkClinicalVariableType(String expectedVar) throws Throwable {
        boolean expected = TestUtils.checkSelectValue(driver(), By.xpath("//*[@id='traversalSearchVariableType']"), expectedVar);
        log.warn("Checking that Clinical Variable Type contains: " + expectedVar);
        Assert.assertTrue("Clinical Variable Type does NOT contain", expected);
    }

    @When("^Clinical Variable Type does NOT contain \"([^\"]*)\" value on the Traversal Maintenance page$")
    public void checkNotClinicalVariableType(String expectedVar) throws Throwable {
        boolean expected = TestUtils.checkSelectValue(driver(), By.xpath("//*[@id='traversalSearchVariableType']"), expectedVar);
        log.warn("Checking that Clinical Variable Type does NOT contain: " + expectedVar);
        Assert.assertFalse("Clinical Variable Type contains", expected);
    }

    @When("^Traversal description from Globals is: \"([^\"]*)\"$")
    public void checkTraversalFromGV(String expectedTr) throws Throwable {
        String expected = gv.getTraversalDescription();
        log.warn("Checking that remembered Traversal description " + expected + " match to expected: " + expectedTr);
        Assert.assertTrue("Traversal Description from globals " + expected +
                " does not match with " + expectedTr, expected.equals(expectedTr));
    }

    @And("^User delete all records with \"([^\"]*)\" description on the Traversal Maintenance page$")
    public void deleteALLByDescription(String descr) throws Throwable {
        obj().TraversalMaintenancePage.clickDeleteALLRecordByContainsDescription(descr);
        user_clicks_on_Previous_hyperlink_on_the_Traversal_Maintenance_page();
        obj().TraversalMaintenancePage.clickDeleteALLRecordByContainsDescription(descr);
    }

    @And("^User delete record with \"([^\"]*)\" description on the Traversal Maintenance page$")
    public void deleteByDescription(String descr) throws Throwable {
        obj().TraversalMaintenancePage.clickDeleteRecordByContainsDescription(descr);
    }

    @Then("^user clicks on Last hyperlink on the Traversal Maintenance page$")
    public void user_clicks_on_Last_hyperlink_on_the_Traversal_Maintenance_page() throws Throwable {
        obj().TraversalMaintenancePage.clickOnLastHyperLink();
        TestUtils.waitForAngularRequestsToFinish(driver());
    }

    @Then("^user clicks on Previous hyperlink on the Traversal Maintenance page$")
    public void user_clicks_on_Previous_hyperlink_on_the_Traversal_Maintenance_page() throws Throwable {
        obj().TraversalMaintenancePage.clickOnPreviousHyperLink();
        TestUtils.waitForAngularRequestsToFinish(driver());
    }

    @Then("^User clicks on Add Traversal link on the Traversal Maintenance page$")
    public void clickAddTraversal() throws Throwable {
        clickAddTraversal();
    }

    @Then("^User selects \"([^\"]*)\" option from Apply Bulk Action and click Apply on the Traversal Maintenance page$")
    public void selectApplyBulkActionAndClickApply(String option) throws Throwable {
        obj().TraversalMaintenancePage.applyBulkAction(option);
    }

    @And("^User selects checkbox by \"([^\"]*)\" text in description on the Traversal Maintenance page$")
    public void selectCheckBoxByTxtContains(String idtxt) throws Throwable {
        selectCheckBoxByTxtContains(idtxt);
    }

    @And("^User selects checkbox by \"([^\"]*)\" ID on the Traversal Maintenance page$")
    public void selectCheckBoxByTxt(String idtxt) throws Throwable {
        if (idtxt.equalsIgnoreCase("gv")) idtxt = gv.getTraversalID();
        selectCheckBoxByTxt(idtxt);
    }

    @And("^User selects checkbox number \"([^\"]*)\" on the Traversal Maintenance page$")
    public void selectCheckBoxByPos(int pos) throws Throwable {
        obj().TraversalMaintenancePage.selectCheckBoxByPosition(pos);
    }

    @Then("^Check that Stored ID values are not present on the Traversal Maintenance page$")
    public void checkIDListNotPresent() throws Throwable {
        obj().TraversalMaintenancePage.checkStoredIdNotPresent();
    }

    @And("^Store ID value from row number \"([^\"]*)\" on the Traversal Maintenance page$")
    public void storeIdValByPosition(int pos) throws Throwable {
        String idVal = obj().TraversalMaintenancePage.getIdValueByPosition(pos);
        gv.addToIDList(idVal);
    }

    @Then("^User validates the \"([^\"]*)\" in the breadcrumb$")
    public void user_validates_the_in_the_breadcrum(String arg1) throws Throwable {
        obj().TraversalMaintenancePage.validateBreadcrumb(arg1);
    }

    @Then("^User clicks on the \"([^\"]*)\" breadcrumb$")
    public void user_clicks_on_the_link_present_in_breadcrum(String arg1) throws Throwable {
        obj().TraversalMaintenancePage.clickOnBreadcrumb(arg1);
    }
    @And("^User clicks search on Traversal Maintenance page$")
    public void userClicksSearchOnTraversalMaintenancePage() throws Throwable {
        obj().TraversalMaintenancePage.clickSearchButton();
    }

    @And("^User verifies Edit icon on Traversal Maintenance page$")
    public void userVerifiesEditIconOnTraversalMaintenancePage() throws Throwable {
        obj().TraversalMaintenancePage.verifyEditIcon();
    }

    @And("^User verifies Delete icon on Traversal Maintenance page$")
    public void userVerifiesDeleteIconOnTraversalMaintenancePage() throws Throwable {
        obj().TraversalMaintenancePage.verifyDeleteIcon();
    }

    @And("^User verifies Expand icon on Traversal Maintenance page$")
    public void userVerifiesExpandIconOnTraversalMaintenancePage() throws Throwable {
        obj().TraversalMaintenancePage.verifyExpandIcon();
    }

    @When("^User clicks Edit icon on Traversal Maintenance page$")
    public void userClicksEditIconOnTraversalMaintenancePage() throws Throwable {
        obj().TraversalMaintenancePage.clickEditIcon();
    }

    @And("^User Stores Authorization Duration on Traversal Maintenance page$")
    public void userStoresAuthorizationDurationOnTraversalMaintenancePage() throws Throwable {
        obj().TraversalMaintenancePage.storeAuthorizationDuration();
    }

    @And("^User Stores Start Date on Traversal Maintenance page$")
    public void userStoresStartDateOnTraversalMaintenancePage() throws Throwable {
        obj().TraversalMaintenancePage.storeStartDate();
    }

    @And("^User Stores End Date on Traversal Maintenance page$")
    public void userStoresEndDateOnTraversalMaintenancePage() throws Throwable {
        obj().TraversalMaintenancePage.storeEndDate();
    }

    @When("^User clicks Expand icon on Traversal Maintenance page$")
    public void userClicksExpandIconOnTraversalMaintenancePage() throws Throwable {
        obj().TraversalMaintenancePage.clickExpandIcon();
    }

    @And("^User stores Clinical Variable Type for Cancer Type on Traversal Maintenance page$")
    public void userStoresClinicalVariableTypeForCancerTypeOnTraversalMaintenancePage() throws Throwable {
        obj().TraversalMaintenancePage.storeClinicalVariableType();
    }

    @And("^User stores Clinical Variable Value for Description on Traversal Maintenance page$")
    public void userStoresClinicalVariableValueForDescriptionOnTraversalMaintenancePage() throws Throwable {
        obj().TraversalMaintenancePage.storeClinicalVariableValue();
    }

    @And("^User verifies the data \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" will be displayed on Traversal Maintenance page$")
    public void userVerifiesTheDataWillBeDisplayedOnTraversalMaintenancePage(String startDate, String endDate, String authorizationDuration, String variableType, String variableValue) throws Throwable {
        obj().TraversalMaintenancePage.verifySavedDataInTravesalMaintenacePage(startDate, endDate, authorizationDuration, variableType, variableValue);
    }

    @Then("^User enters \"([^\"]*)\" into TraversalID field on the Traversal Maintenance page$")
    public void user_enters_TraversalID_into_field_on_the_Traversal_Maintenance_page(String travId) throws Throwable {
        if (travId.equalsIgnoreCase("gv")) travId = gv.getTraversalID();
        obj().TraversalMaintenancePage.enterDataIntoTraversalIDOnTraversalMaintenancePage(travId);
    }

    @Then("^user selects Cancer Type as \"([^\"]*)\" on the Traversal Maintenance page$")
    public void user_selects_Cancer_Type_as_on_the_Traversal_Maintenance_page(String arg1) throws Throwable {
        obj().TraversalMaintenancePage.selectCancerTypeOnTraversalMaintenancePage(arg1);
    }

    @Then("^user selects Clinical Variable Type as \"([^\"]*)\" on the Traversal Maintenance page$")
    public void user_selects_Clinical_Variable_Type_as_on_the_Traversal_Maintenance_page(String arg1) throws Throwable {
        obj().TraversalMaintenancePage.selectClinicalVariableTypeOnTraversalMaintenancePage(arg1);
    }

    @Then("^user selects Clinical Variable Value as \"([^\"]*)\" on the Traversal Maintenance page$")
    public void user_selects_Clinical_Variable_Value_as_on_the_Traversal_Maintenance_page(String arg1) throws Throwable {
        obj().TraversalMaintenancePage.selectClinicalVariableValueOnTraversalMaintenancePage(arg1);
    }

    @Then("^user clicks on Clear button on the Traversal Maintenance page$")
    public void user_clicks_on_Clear_button_on_the_Traversal_Maintenance_page() throws Throwable {
        obj().TraversalMaintenancePage.clickClearButton();
    }

    @Then("^user should verify that value in Cancer Type dropdown is cleared on the Traversal Maintenance page$")
    public void user_should_verify_that_value_in_Cancer_Type_dropdown_is_cleared_on_the_Traversal_Maintenance_page() throws Throwable {
        obj().TraversalMaintenancePage.checkCancerTypeValueIsCleared();
    }

    @Then("^user should verify that value in Clinical Variable Type dropdown is cleared on the Traversal Maintenance page$")
    public void user_should_verify_that_value_in_Clinical_Variable_Type_dropdown_is_cleared_on_the_Traversal_Maintenance_page() throws Throwable {
        obj().TraversalMaintenancePage.checkClinicalVariableTypeValueIsCleared();
    }

    @Then("^user should verify that value in Clinical Variable Value dropdown is cleared on the Traversal Maintenance page$")
    public void user_should_verify_that_value_in_Clinical_Variable_Value_dropdown_is_cleared_on_the_Traversal_Maintenance_page() throws Throwable {
        obj().TraversalMaintenancePage.checkClinicalVariableValueValueIsCleared();
    }

    @Then("^user clicks on Search button on the Traversal Maintenance page$")
    public void user_clicks_on_Search_button_on_the_Traversal_Maintenance_page() throws Throwable {
        obj().TraversalMaintenancePage.clickSearchButton();
    }

    @Then("^user should see an Expand, Edit and Delete icon$")
    public void user_should_see_an_Expand_Edit_and_Delete_icon() throws Throwable {
        obj().TraversalMaintenancePage.checkExpandEditAndDeleteIcons();
    }

    @Then("^user should see a checkbox selection option$")
    public void user_should_see_a_checkbox_selection_option() throws Throwable {
        obj().TraversalMaintenancePage.checkCheckBoxSelectedOption();
    }

    @Then("^user should see an ID column that is sortable$")
    public void user_should_see_an_ID_column_that_is_sortable() throws Throwable {
        obj().TraversalMaintenancePage.checkIDColIsSortable();
    }

    @Then("^user should see the ID column as the default sort$")
    public void user_should_see_the_ID_column_as_the_default_sort() throws Throwable {
        obj().TraversalMaintenancePage.checkIdColIsDefaultSortable();
    }

    @Then("^user should see a Cancer Type column that is sortable$")
    public void user_should_see_a_Cancer_Type_column_that_is_sortable() throws Throwable {
        obj().TraversalMaintenancePage.checkCancerTypeColIsSortable();
    }

    @Then("^user should see a Description column that is sortable$")
    public void user_should_see_a_Description_column_that_is_sortable() throws Throwable {
        obj().TraversalMaintenancePage.checkDescriptionColIsSortable();
    }

    @Then("^user should see an Authorization Duration column that is sortable$")
    public void user_should_see_an_Authorization_Duration_column_that_is_sortable() throws Throwable {
        obj().TraversalMaintenancePage.checkAuthDurationColIsSortable();
    }

    @Then("^user should see a Start Date column that is sortable$")
    public void user_should_see_a_Start_Date_column_that_is_sortable() throws Throwable {
        obj().TraversalMaintenancePage.checkStartDtenColIsSortable();
    }

    @Then("^user should see an End Date column that is sortable$")
    public void user_should_see_an_End_Date_column_that_is_sortable() throws Throwable {
        obj().TraversalMaintenancePage.checkEndDateColIsSortable();
    }

    @Then("^user should see an Updated column that when clicked will display the Traversal last updated date and User ID$")
    public void user_should_see_an_Updated_column_that_when_clicked_will_display_the_Traversal_last_updated_date_and_User_ID() throws Throwable {
        obj().TraversalMaintenancePage.checkLastUpdatedIcon();
    }

    @Then("^user should see the Clinical Variable Type and Clinical Variable value when clicked on expand button below the row populated with the Clinical Variable for this traversal$")
    public void user_should_see_the_Clinical_Variable_Type_below_the_row_populated_with_the_Clinical_Variable_for_this_traversal() throws Throwable {
        obj().TraversalMaintenancePage.checkClinicalVariableTypeAndValueArePopulated();
    }

    @Then("^user should not see any data pre-populated in the grid$")
    public void user_should_not_see_any_data_pre_populated_in_the_grid() throws Throwable {
        obj().TraversalMaintenancePage.checkProvideSearchCriteriaMsg();
    }


    @Then("^user should see cancerType,Search and Clear buttons$")
    public void user_should_see_Search_and_Clear_buttons() throws Throwable {
        obj().TraversalMaintenancePage.validateSearchFields();
    }

    @Then("^user should see Show select records defaulted to (\\d+) with selection arrows Per Page and user can change to (\\d+)$")
    public void user_should_see_Show_select_records_defaulted_to_with_selection_arrows_Per_Page_and_user_can_change_to(int arg1, int arg2) throws Throwable {
        obj().TraversalMaintenancePage.validateShowRecordsDropdown(arg1, arg2);
    }


    @Then("^user should see Page numbers between the First and Last selections that will be equal to the total number of records divided by the Show record value$")
    public void user_should_see_Page_numbers_between_the_First_and_Last_selections_that_will_be_equal_to_the_total_number_of_records_divided_by_the_Show_record_value() throws Throwable {
        obj().TraversalMaintenancePage.validatePagesCount();
    }

    @Then("^user should validate the results grid on the Traversal Maintenance page with Cancer Type as \"([^\"]*)\"$")
    public void user_should_validate_the_results_grid_on_the_Traversal_Maintenance_page(String arg1) throws Throwable {
        obj().TraversalMaintenancePage.validateSearchResults(arg1);
    }


    @Then("^user clicks on Select All check box on the Traversal Maintenance page$")
    public void user_clicks_on_Select_All_check_box_on_the_Traversal_Maintenance_page() throws Throwable {
        TestUtils.waitForAngularRequestsToFinish(driver());
        obj().TraversalMaintenancePage.clickSelectAllCheckBox();
    }

    //Advanced Search
    @Then("^user clicks on Advanced Search link on the Traversal Maintenance page$")
    public void user_clicks_on_Advanced_Search_link_on_the_Traversal_Maintenance_page() throws Throwable {
        obj().TraversalMaintenancePage.clickAdvancedSearchButton();
    }

    @Then("^user should see the Check Box next to all of the traversals selected for current page$")
    public void user_should_see_the_Check_Box_next_to_all_of_the_traversals_selected_for_current_page() throws Throwable {
        obj().TraversalMaintenancePage.verifyCheckBoxNextToTraversalIsSelectedForCurrentPage();
    }

    @Then("^user should see the Check Box next to all of the traversals unselected for current page$")
    public void user_will_see_the_Check_Box_next_to_all_of_the_traversals_unselected_for_current_page() throws Throwable {
        obj().TraversalMaintenancePage.verifyCheckBoxNextToTraversalIsUnSelectedForCurrentPage();
    }

    @Then("^user should see the Check Box next to all of the traversals unselected for next pages$")
    public void user_should_see_the_Check_Box_next_to_all_of_the_traversals_unselected_for_next_pages() throws Throwable {
        obj().TraversalMaintenancePage.verifyCheckBoxNextToTraversalIsUnSelectedForNextPages();
    }

    @Then("^user clicks on First hyperlink on the Traversal Maintenance page$")
    public void user_clicks_on_First_hyperlink_on_the_Traversal_Maintenance_page() throws Throwable {
        obj().TraversalMaintenancePage.clickOnFirstHyperLink();
        TestUtils.waitForAngularRequestsToFinish(driver());
    }

    @Then("^User fetch a TraversalID from DB which is \"([^\"]*)\" with HSC$")
    public void user_fetch_a_TraversalID_from_DB_which_is_with_HSC(String arg1) throws Throwable {
        String dbTraversalID = obj().TraversalMaintenancePage.validateAndReturnTraversalID(arg1);
        if (dbTraversalID == null) {
            Assert.fail("Check DB - no data matched with the hsc " + arg1 + " condition");
        }
    }

    @Then("^User search for the Traversal ID on Traversal Maintenace Page$")
    public void user_search_for_the_Traversal_ID() throws Throwable {
        obj().TraversalMaintenancePage.userSearchForTraversalIDRecord();
    }

    @Then("^User delete the Traversal ID on Traversal Maintenace Page$")
    public void user_delete_the_Traversal_ID() throws Throwable {
        obj().TraversalMaintenancePage.deleteFirstRecord();
    }

    @Then("^User can see the traversal data in the database will be deleted$")
    public void user_can_see_the_traversal_data_in_the_database_will_be_deleted() throws Throwable {
        obj().TraversalMaintenancePage.validateTraversalDataNotPresentInDB();
    }

    @Then("^User validates the record is not deleted on Traversal Maintenance Page$")
    public void record_is_not_deleted_on_Traversal_Maintenance_Page() throws Throwable {
        obj().TraversalMaintenancePage.validateRecordPresentInTraversalDetails();
    }


    @When("^User verify all Elements on Advanced Search Pop Up Window$")
    public void user_verify_all_Elements_on_Advanced_Search_Pop_Up_Window() throws Throwable {
        obj().TraversalMaintenancePage.verifyAdvancedSearchPopUpElements();
    }

    @When("^user selects Cancer Type as \"([^\"]*)\" on the Advanced Search Pop Up$")
    public void user_selects_Cancer_Type_as_on_the_Advanced_Search_Pop_Up(String arg1) throws Throwable {
        obj().TraversalMaintenancePage.selectCancerTypeOnAdvancedSearchPopUp(arg1);
    }

    @When("^user enter Authorization Duration as \"([^\"]*)\" on the Advanced Search Pop Up$")
    public void user_enter_Authorization_Duration_as_on_the_Advanced_Search_Pop_Up(String arg1) throws Throwable {
        obj().TraversalMaintenancePage.enterAuthorizationDurationOnAdvancedSearchPopUp(arg1);
    }

    @When("^user selects Variable Type as \"([^\"]*)\" on the Advanced Search Pop Up$")
    public void user_selects_Variable_Type_as_on_the_Advanced_Search_Pop_Up(String arg1) throws Throwable {
        obj().TraversalMaintenancePage.selectVariableTypeOnAdvancedSearchPopUp(arg1);
    }

    @When("^user selects Variable Value as \"([^\"]*)\" on the Advanced Search Pop Up$")
    public void user_selects_Variable_Value_as_on_the_Advanced_Search_Pop_Up(String arg1) throws Throwable {
        obj().TraversalMaintenancePage.selectVariableValueOnAdvancedSearchPopUp(arg1);
    }

    @When("^user clicks on Search button on the Advanced Search Pop Up$")
    public void user_clicks_on_Search_button_on_the_Advanced_Search_Pop_Up() throws Throwable {
        obj().TraversalMaintenancePage.clickSearchButtonOnAdvancedSearchPopUp();
    }

    @Then("^user clicks on Clear button on the Advanced Search Pop Up$")
    public void user_clicks_on_Clear_button_on_the_Advanced_Search_Pop_Up() throws Throwable {
        obj().TraversalMaintenancePage.clickClearButtonOnAdvancedSearchPopUp();
    }

    @Then("^user clicks on Cancel button on the Advanced Search Pop Up$")
    public void user_clicks_on_Cancel_button_on_the_Advanced_Search_Pop_Up() throws Throwable {
        obj().TraversalMaintenancePage.clickCancelButtonOnAdvancedSearchPopUp();
    }

    @Then("^user clicks on X button on the Advanced Search Pop Up$")
    public void user_clicks_on_X_button_on_the_Advanced_Search_Pop_Up() throws Throwable {
        obj().TraversalMaintenancePage.clickXbuttonOnAdvancedSearchPopUp();
    }

    @Then("^user should verify that value in Cancer Type dropdown is cleared on the Advanced Search Pop Up$")
    public void user_should_verify_that_value_in_Cancer_Type_dropdown_is_cleared_on_the_Advanced_Search_Pop_Up() throws Throwable {
        obj().TraversalMaintenancePage.checkCancerTypeValueIsClearedOnAdvancedSearchPopUp();
    }

    @Then("^user should verify that value in Authorization Duration input box is cleared on the Advanced Search Pop Up$")
    public void user_should_verify_that_value_in_Authorization_Duration_input_box_is_cleared_on_the_Advanced_Search_Pop_Up() throws Throwable {
        obj().TraversalMaintenancePage.checkAuthorizationDurationValueIsClearedOnAdvancedSearchPopUp();
    }

    @Then("^user should verify that value in Variable Type dropdown is cleared on the Advanced Search Pop Up$")
    public void user_should_verify_that_value_in_Variable_Type_dropdown_is_cleared_on_the_Advanced_Search_Pop_Up() throws Throwable {
        obj().TraversalMaintenancePage.checkVariableTypeValueIsClearedOnAdvancedSearchPopUp();
    }

    @Then("^user should verify that value in Variable Value dropdown is cleared on the Advanced Search Pop Up$")
    public void user_should_verify_that_value_in_Variable_Value_dropdown_is_cleared_on_the_Advanced_Search_Pop_Up() throws Throwable {
        obj().TraversalMaintenancePage.checkVariableValueValueIsClearedOnAdvancedSearchPopUp();
    }

    @Then("^user should see the Search Applied Text next to the Advanced Search link$")
    public void user_should_see_the_Search_Applied_Text_next_to_the_Advanced_Search_link() throws Throwable {
        obj().TraversalMaintenancePage.verifySearchAppliedTextAfterAdvancedSearch();
    }

    @Then("^user should see the cancer Type Text and value \"([^\"]*)\" is displayed in a grey oval$")
    public void user_should_see_the_cancer_Type_Text_and_value_is_displayed_in_a_grey_oval(String arg1) throws Throwable {
        obj().TraversalMaintenancePage.verifySearchAppliedForCancerType(arg1);
    }

    @Then("^user should see the Authorization Duration Text and value \"([^\"]*)\" is displayed in a grey oval$")
    public void user_should_see_the_Authorization_Duration_Text_and_value_is_displayed_in_a_grey_oval(String arg1) throws Throwable {
        obj().TraversalMaintenancePage.verifySearchAppliedForDuration(arg1);
    }

    @Then("^user should see the Advanced Search Pop Up window closed$")
    public void user_should_see_the_Advanced_Search_Pop_Up_window_closed() throws Throwable {
        obj().TraversalMaintenancePage.verifyAdvancedSearchWindowClosed();
    }

    @Then("^user click on Add Clinical Variable link on the Advanced Search Pop Up$")
    public void user_click_on_Add_Clinical_Variable_link_on_the_Advanced_Search_Pop_Up() throws Throwable {
        obj().TraversalMaintenancePage.clickAddClinicalVariableAdvancedSearch();
    }

    @Then("^User can see types and values will be stacked if the number of Types selected exceeds the space allowed to display the values$")
    public void user_can_see_types_and_values_will_be_stacked_if_the_number_of_Types_selected_exceeds_the_space_allowed_to_display_the_values() throws Throwable {
        obj().TraversalMaintenancePage.verifyTextDisplayedInNextLineAdvancedSearchApplied();
    }

    @And("^User selects \"([^\"]*)\" from warning popup$")
    public void user_selects_from_warning_popup(String arg1) throws Throwable {
        obj().TraversalMaintenancePage.selectDecisionOptionFromWarningMessage(arg1);
    }

    @Then("^User validates the delete traversal warning pop up$")
    public void user_validates_the_delete_traversal_warning_pop_up() throws Throwable {
        obj().TraversalMaintenancePage.validateDeleteTraversalWarningPopUp();
    }

    @And("^user clicks on \"([^\"]*)\" in Apply Bulk Action dropdown$")
    public void userClicksOnInApplyBulkActionDropdown(String dropdownvalue) throws Throwable {
        obj().TraversalMaintenancePage.clickOnBulkAction(dropdownvalue);
    }


    @And("^user clicks on \"([^\"]*)\" button on the Traversal Maintenance page$")
    public void userClicksOnButtonOnTheTraversalMaintenancePage(String arg0) throws Throwable {
        obj().TraversalMaintenancePage.clickOnApplySelected(arg0);
//        obj().CommonPage.switchWindowTo(1);
    }


    @And("^User verifies the text on the popup as \"([^\"]*)\"$")
    public void userVerifiesTheTextOnThePopupAs(String text) throws Throwable {
        obj().TraversalMaintenancePage.verifyTextDisplayedInEditAuthDurationPopup(text);
    }

    @And("^user enters the \"([^\"]*)\" duration in the Edit Authorization Duration textbox on the popup$")
    public void userEntersTheDurationInTheEditAuthorizationDurationTextboxOnThePopup(String duration) throws Throwable {
        obj().TraversalMaintenancePage.enterDataIntoTraversalDurationOnEditAuthDurationPopup(duration);
    }

    @And("^user clicks the x button on popup of Edit Authorization Duration$")
    public void userClicksTheXButtonOnPopupOfEditAuthorizationDuration() throws Throwable {
        obj().TraversalMaintenancePage.user_click_The_x_Button_On_Popup();
    }


    @And("^User clicks on \"([^\"]*)\" button on popup and verifies the success message as \"([^\"]*)\"$")
    public void userClicksOnButtonOnPopupAndVerifiesTheSuccessMessageAs(String arg0, String message) throws Throwable {
        obj().TraversalMaintenancePage.clickOnApply(arg0, message);
    }

    @And("^User verifies red border color for bulk action select box on the Traversal Maintenance page$")
    public void userVerifiesRedBorderColorForBulkActionSelectBoxOnTheTraversalMaintenancePage() throws Throwable {
        obj().TraversalMaintenancePage.verifyRedBorderColorForBulkActionSelectBox();
    }


    @Then("^user input below information on Bulk Change Variable Value and variable type$")
    public void user_input_below_information_on_Bulk_Change_Variable_Value_and_variable_type(DataTable dataTable) throws Throwable {

        List<Map<String, String>> maps = dataTable.asMaps(String.class, String.class);
        new TraversalMaintenance(scenario, driver()).bulkChangeVariableErrorCheck(maps);

    }

    @Then("^user validates duplicate logic for updating Bulk Change Variable Value and variable type$")
    public void user_validates_duplicate_logic_for_updating_Bulk_Change_Variable_Value_and_variable_type(DataTable dataTable) throws Throwable {
        List<Map<String, String>> maps = dataTable.asMaps(String.class, String.class);
        new TraversalMaintenance(scenario, driver()).bulkChangeVariableDuplicateErrorCheck(maps);
    }

    @And("^User selects checkbox all rows on the Traversal Maintenance page$")
    public void userSelectsCheckboxAllRowsOnTheTraversalMaintenancePage() throws Throwable {
        driver().findElement(By.xpath("//*[@id='nputCheckAll']")).click();
    }


    @Then("^user should verify that value in Variable Value is \"([^\"]*)\" with no  leading and trailing spaces in Traversal Maintenance page$")
    public void userShouldVerifyThatValueInVariableValueIsWithNoLeadingAndTrailingSpacesInTraversalMaintenancePage(String arg0) throws Throwable {
        new TraversalMaintenance(scenario, driver()).checkClinicalVariable(arg0);
    }

    /**
     * @param dataTable Validate duplicate logic for updating Bulk Change Variable Type in Traversal maintenance page
     */
    @Then("^user validates duplicate logic for updating Bulk Change Variable Type for 3 traversals$")
    public void user_validates_duplicate_logic_for_updating_Bulk_Change_variable_type_3traversal(DataTable dataTable) throws Throwable {
        List<Map<String, String>> maps = dataTable.asMaps(String.class, String.class);
        new TraversalMaintenance(scenario, driver()).bulkChangeVariableTypeDuplicateErrorCheckfor3Traversals(maps);
    }

    @Then("^user validates duplicate logic for updating Bulk Change Variable Type for 2 traversals$")
    public void user_validates_duplicate_logic_for_updating_Bulk_Change_variable_type_2traversal(DataTable dataTable) throws Throwable {
        List<Map<String, String>> maps = dataTable.asMaps(String.class, String.class);
        new TraversalMaintenance(scenario, driver()).bulkChangeVariableTypeDuplicateErrorCheckfor2Traversals(maps);
    }

    @And("^User click cancel link on Bulk Edit Authorization Duration popup modal$")
    public void userClickCancelLinkOnEditAuthorizationPopUpWindow() throws Throwable {
        obj().BulkEditAuthorizationDurationModalPage.clickCancelLink();
        obj().BulkEditAuthorizationDurationModalPage.shouldDisappear();
    }

    @And("^user selects Cancer Type as \"([^\"]*)\" on the Add traversal page$")
    public void userSelectsCancerTypeAsOnTheAddTraversalPage(String cancerType) throws Throwable {
        obj().TraversalMaintenancePage.selectCancerTypeOnAddTraversalPage(cancerType);
    }

    @And("^user enters start date as \"([^\"]*)\" on the Add traversal page$")
    public void userEntersOnTheAddTraversalPage(String startdate) throws Throwable {
        String todayDate = WhiteBoard.resolve(owner, startdate);
        obj().TraversalMaintenancePage.enterStartDateOnAddTraversalPage(todayDate);
    }

    @And("^user enters  auth duration as \"([^\"]*)\" on the Add traversal Page$")
    public void userEntersAuthDurationAsOnTheAddTraversalPage(String authduration) throws Throwable {
        obj().TraversalMaintenancePage.enterAuthorizationDurationOnAddTraversalPage(authduration);
    }

    @And("^user selects variable type as \"([^\"]*)\" on the Add traversal Page$")
    public void userSelectsOnTheAddTraversalPage(String variableType) throws Throwable {
        obj().TraversalMaintenancePage.selectVariableTypeOnAddTraversalPage(variableType);
    }

    @And("^user selects  variable value as \"([^\"]*)\" on the Add traversal Page$")
    public void userSelectsVariableValueAsOnTheAddTraversalPage(String variablevalue) throws Throwable {
        obj().TraversalMaintenancePage.enterVariableValueOnAddTraversalPage(variablevalue);
    }


    @And("^user closes the message on add traversal page$")
    public void userClosesTheMessageOnAddTraversalPage() throws Throwable {
        obj().TraversalMaintenancePage.closeMessageOnAddTraversalPage();
    }


    @When("^User enters Variable Value with leading and trailing spaces in Variable value field in Bulk Change Variable model in Traversal Maintenance page$")
    public void user_enters_Variable_Value_with_leading_and_trailing_spaces_in_Variable_value_fieled_in_Bulk_Change_Variable_model_in_Traversal_Maintenance_page(DataTable dataTable) throws Throwable {

        List<Map<String, String>> maps = dataTable.asMaps(String.class, String.class);
        new TraversalMaintenance(scenario, driver()).EnterBulkChangeVariableLeadingandTrailingSpace(maps);


    }

    @Then("^user validates duplicate logic for updating Bulk Change Variable Value and variable type for 2 traversals$")
    public void uservalidates_duplicate_logic_for_updating_Bulk_Change_Variable_Value_and_variable_type(DataTable dataTable) throws Throwable {
        List<Map<String, String>> maps = dataTable.asMaps(String.class, String.class);
        new TraversalMaintenance(scenario, driver()).bulkChangeVariableDuplicateErrorCheckWithtwoTraversals(maps);
    }

    @Then("^User enters \"([^\"]*)\" and \"([^\"]*)\" on Bulk start date and end date page$")
    public void userEntersAndOnBulkStartDateAndEndDatePage(String startdate, String enddate) throws Throwable {
        String todayDate = WhiteBoard.resolve(owner, startdate);
        String tomorrowDate = WhiteBoard.resolve(owner, enddate);
        obj().TraversalMaintenancePage.enterStartDateAndEndDateOnBulkPage(todayDate, tomorrowDate);
    }

    @Then("^User clicks on Apply on Bulk start date and end date page$")
    public void userClicksOnApplyOnBulkStartDateAndEndDatePage() throws Throwable {
        obj().TraversalMaintenancePage.clickOnApplyOnBulkStartAndEndDatePage();
    }


}

