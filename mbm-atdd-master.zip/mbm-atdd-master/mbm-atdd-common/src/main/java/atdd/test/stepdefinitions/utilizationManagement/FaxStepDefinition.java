package atdd.test.stepdefinitions.utilizationManagement;

import atdd.common.ScenarioLogger;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.stepsets.Login;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

public class FaxStepDefinition {
    public static final Logger log = Logger.getLogger(FaxStepDefinition.class.getName());

    private Scenario scenario;
    private ScenarioLogger scenarioLogger = null;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }

    @And("^user navigates to Fax section in Communication tab$")
    public void navigatetofaxsectionunderCommunicationTab() throws Throwable {
        obj().FaxSection.navigatetoFaxsection();
    }

    @When("^SendFaxTo table is extracted as maps with prefix \"([^\"]*)\" and key header \"([^\"]*)\"$")
    public void tableIsExtractedAsMapsWithPrefix(String prefix, String keyHeader) throws Throwable {
        obj().FaxSection.sendFaxTotable(scenario, prefix, keyHeader);
    }

    @And("^user generates \"([^\"]*)\" fax for \"([^\"]*)\" Provider$")
    public void selectsRequestingProviderinFaxTable(String letterType, String provider) throws Throwable {
        obj().FaxSection.selectinSendFaxToTable(provider);
        obj().FaxSection.fillClinicalContactInfo(letterType);
        obj().FaxSection.sendFax();
    }

    @And("^user navigates to fax history$")
    public void usernavigatestofaxhistory() throws Throwable {
        obj().FaxSection.navigatetoFaxsection();
        obj().FaxSection.openFaxHistory();
    }

    @And("^user verifies \"([^\"]*)\" fax sent row is added in fax history for \"([^\"]*)\" and sent to \"([^\"]*)\"$")
    public void validatefaxrowaddedinfaxhistory(String template, String recipient, String sentto) throws Throwable {
        obj().FaxSection.validatefaxrow(template, recipient, sentto);
    }

}