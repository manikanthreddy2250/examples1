package atdd.test.stepdefinitions.utilizationManagement;

import atdd.common.ScenarioLogger;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.stepsets.Login;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

public class UtilizationManagementStepDefinition {
    public static final Logger log = Logger.getLogger(UtilizationManagementStepDefinition.class.getName());

    private Scenario scenario;
    private ScenarioLogger scenarioLogger = null;
    private String owner;

    private CommonPageObject obj() throws Throwable {
        return new CommonPageObject(scenario, driver());
    }

    private WebDriver driver() throws Throwable {
        return Login.login(scenario);
    }

    @Before
    public void beforeScenario(Scenario scenario) throws Throwable {
        this.scenario = scenario;
        this.owner = scenario.getId();
        this.scenarioLogger = new ScenarioLogger(scenario, log);
    }

    @And("^user searches and navigate to Authorization Summary screen$")
    public void AuthNumberiscapturedsearchedandAuthSummpageopened() throws Throwable {
        obj().LettersSection.captureauthnumberandnavigatetoauthsummary();
    }

    @And("^user navigates to Letter section in Communication tab$")
    public void navigatetolettersectionunderCommunicationTab() throws Throwable {
        obj().LettersSection.navigatetoLetterssection();
    }

    @When("^SendLetterTo table is extracted as maps with prefix \"([^\"]*)\" and key header \"([^\"]*)\"$")
    public void tableIsExtractedAsMapsWithPrefix(String prefix, String keyHeader) throws Throwable {
        obj().LettersSection.sendLetterTotable(scenario, prefix, keyHeader);
    }

    @And("^user generates \"([^\"]*)\" letter as \"([^\"]*)\" for Requesting Provider$")
    public void selectsRequestingProviderinLetterTable(String letterType, String deliveryType) throws Throwable {
        obj().LettersSection.selectRPinSendLetterToTable();
        obj().LettersSection.fillDeliveryType(deliveryType);
        obj().LettersSection.fillLetterType(letterType);
        obj().LettersSection.createLetter();
    }

    @And("^user generates \"([^\"]*)\" letter as \"([^\"]*)\" for Servicing Provider$")
    public void selectsServicingProviderinLetterTable(String letterType, String deliveryType) throws Throwable {
        obj().LettersSection.selectSPinSendLetterToTable();
        obj().LettersSection.fillDeliveryType(deliveryType);
        obj().LettersSection.fillLetterType(letterType);
        obj().LettersSection.createLetter();
    }

    @And("^user generates \"([^\"]*)\" letter as \"([^\"]*)\" for Carrier$")
    public void selectsCarrierinLetterTable(String letterType, String deliveryType) throws Throwable {
        obj().LettersSection.selectCarrierinSendLetterToTable();
        obj().LettersSection.fillDeliveryType(deliveryType);
        obj().LettersSection.fillLetterType(letterType);
        obj().LettersSection.createLetter();
    }

    @And("^user generates \"([^\"]*)\" letter as \"([^\"]*)\" in \"([^\"]*)\" for Member$")
    public void selectsMemberinLetterTable(String letterType, String deliveryType, String language) throws Throwable {
        obj().LettersSection.selectMemberinSendLetterToTable();
        obj().LettersSection.fillDeliveryType(deliveryType);
        obj().LettersSection.selectLanguage(language);
        obj().LettersSection.fillLetterType(letterType);
        obj().LettersSection.createLetter();
    }

    @And("^user navigates to letter history$")
    public void usernavigatestoletterhistory() throws Throwable {
        obj().LettersSection.navigatetoLetterssection();
        obj().LettersSection.openLettersHistory();
    }

    @And("^user verifies \"([^\"]*)\" letter sent row is added with delivery type as \"([^\"]*)\" sent to address as \"([^\"]*)\" for \"([^\"]*)\" in letter history$")
    public void validateletterrowaddedinletterhistory(String template, String deliverytype, String sentto, String recipient) throws Throwable {
        obj().LettersSection.validateletterrow(template, deliverytype, sentto, recipient);
    }

    @And("^user clicks on view icon$")
    public void user_clicks_on_view_icon() throws Throwable {
        obj().LettersSection.clickOnViewIcon();
    }

    @And("^user provides \"([^\"]*)\" as as hour and \"([^\"]*)\" as minute and clicks on mark letter as sent$")
    public void user_provides_as_as_hour_and_as_minute_and_clicks_on_mark_letter_as_sent(String hour, String minute) throws Throwable {
        obj().LettersSection.setLetterAsSentforPDF(hour,minute);
    }

    @And("^user verifies letter status as \"([^\"]*)\"$")
    public void user_verifies_letter_status_as(String status) throws Throwable {
        obj().LettersSection.validateLetterSatus(status);
    }

    /**
     * Fills out the following fields based on the parameters being passed in
     *
     * @param Decision
     * @param SPName
     * @param SPAddress
     * @param memberName
     * @param memberAddress
     * @param RPName
     * @param RPFaxNumber
     */
    @Then("^user verifies \"([^\"]*)\" AutoLetters Pop-up with \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
    public void validateSendDecisionLettersPopup(String Decision, String SPName, String SPAddress, String memberName, String memberAddress, String RPName, String RPFaxNumber) throws Throwable {
        obj().LettersSection.validateSendApprovedDeniedLettersPopup(Decision, SPName, SPAddress, memberName, memberAddress, RPName, RPFaxNumber);
    }


    @Then("^user verifies \"([^\"]*)\" AutoLetters Pop-up with carrier info as \"([^\"]*)\" and \"([^\"]*)\"$")
    public void validateCarrierInfoonAutoLetters(String Decision, String CarrierName, String CarrierAddress) throws Throwable {
        obj().LettersSection.validateCarrierNameAddressonAutoLettersPopup(Decision, CarrierName, CarrierAddress);
    }


    @And("^user confirm and click Send Letters on Auto Letters Pop-up$")
    public void confirmandsendletters() throws Throwable {
        obj().LettersSection.confirminformationandclicksendletters();
    }

    /**
     * Verifies the fields based on the parameters being passed in
     *
     * @param LetterType
     * @param SPName
     * @param SPAddress
     * @param memberName
     * @param memberAddress
     * @param RPName
     * @param RPFaxNumber
     */
    @Then("^user verifies \"([^\"]*)\" letter sent to \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" in letter history$")
    public void validatelettersfromautoletterspopup(String LetterType, String SPName, String SPAddress, String memberName, String memberAddress, String RPName, String RPFaxNumber) throws Throwable {
        obj().LettersSection.validateLettersfromAutoLettersPopupinLetterHistory(LetterType, SPName, SPAddress, memberName, memberAddress, RPName, RPFaxNumber);
    }


    @Then("^user verifies \"([^\"]*)\" Carrier letter sent to \"([^\"]*)\" and \"([^\"]*)\" in letter history$")
    public void validateCarrierlettersfromautoletterspopup(String LetterType, String CarrierName, String CarrierAddress) throws Throwable {
        obj().LettersSection.validateCarrierLettersfromAutoLettersPopupinLetterHistory(LetterType, CarrierName, CarrierAddress);
    }
}