package atdd.test.stepsets;

import atdd.test.core.AbstractStepSet;
import atdd.utils.*;
import cucumber.api.Scenario;
import org.openqa.selenium.WebDriver;

import java.util.Map;

public abstract class AbstractLogin extends AbstractStepSet {

    public static String getUserIdentifier(Scenario scenario, Map<String, String> pf) {
        String userTitle = pf.get(MBM.USER_TITLE);
        String testEndpoint = pf.get(Conf.TEST_ENDPOINT_KEY);
        String zone = Conf.getInstance().getProperty(Conf.TIME_ZONE_KEY);

        return StringUtils.append(null == scenario ? "NA" : (scenario.getName()), "_",
                userTitle, testEndpoint, zone);
    }

    public static boolean userIdentifierBelongsToScenario(String userIdentifier, Scenario scenario) {
        if (null == scenario) {
            return userIdentifier.startsWith("NA_");
        } else {
            return userIdentifier.startsWith(scenario.getName() + "_");
        }
    }

    public AbstractLogin(Scenario scenario, WebDriver webDriver) {
        super(scenario, webDriver);
    }

    public void login(Map<String, String> pf) {
        String testEndpoint = pf.get(Conf.TEST_ENDPOINT_KEY);
        if (!StringUtils.isEmpty(testEndpoint)) {
            Map<String, String> pfUser = WhiteBoard.getInstance().getMap(scenario().getId(), ExcelLib.THE_USER);
            if (null != pfUser) {
                pfUser.put(Conf.TEST_ENDPOINT_KEY, testEndpoint);
            }
        }
    }

    public abstract boolean isValid() throws LostBrowserException;

    public abstract String getAppVersion();

    public boolean isValidBasic(String expectedUrl) throws LostBrowserException {
        try {
            String url = null;
            try {
                url = driver().getCurrentUrl();
                if (null == url) {
                    throw new LostBrowserException("Missing url.");
                }
            } catch (Exception e) {
                throw new LostBrowserException(e.getMessage());
            }
            if (!url.startsWith(expectedUrl)) {
                return false;
            }
            driver().switchTo().window(driver().getWindowHandle());
            return true;
        } catch (LostBrowserException e) {
            throw e;
        } catch (Exception e) {
            return false;
        }
    }
}
