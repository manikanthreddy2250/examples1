package atdd.test.stepsets;

import atdd.common.ImmediateAbortException;
import atdd.test.pageobjects.CommonPage;
import atdd.test.pageobjects.directsso.SignInClinicalManager;
import atdd.utils.Conf;
import atdd.utils.StringUtils;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.openqa.selenium.WebDriver;

import java.util.Map;

abstract class AbstractLoginMbm extends AbstractLogin {

    protected String version;
    protected Map<String, String> pf;

    public AbstractLoginMbm(Scenario scenario, WebDriver webDriver) {
        super(scenario, webDriver);
    }


    /**
     * Check if the browser is valid.
     *
     * @return
     */
    @Override
    public boolean isValid() throws LostBrowserException {
        try {
            String url = null;
            try {
                if (TestUtils.isElementVisible(driver(), "//input[@value='Sign In']")) {
                    return false;
                }
                url = driver().getCurrentUrl();
                if (null == url) {
                    throw new LostBrowserException("Missing url.");
                }
                if (url.contains("signoff")) {
                    throw new LostBrowserException("Signed off.");
                }
                if (url.contains("login")) {
                    throw new LostBrowserException("Invalid username or password.");
                }
                if (url.contains("permission-denied")) {
                    throw new LostBrowserException("Permission denied.");
                }
            } catch (Exception e) {
                throw new LostBrowserException(e.getMessage());
            }
            String host = Conf.getInstance().getProperty(Conf.TEST_HOST_KEY);
            if (!url.startsWith(host)) {
                return false;
            }
            SignInClinicalManager signinclinicalManager = new SignInClinicalManager(driver());
            String newVersion = signinclinicalManager.getVersion();
            if (!StringUtils.isEmpty(newVersion) && newVersion.equals(version)) {
                this.version = newVersion;
                return true;
            } else {
                if (new CommonPage(driver()).verifyHeader("Permission Denied")) {
                    return true;
                } else {
                    throw new ImmediateAbortException("\nExpected Version: " + version + "\nActual Version: " + newVersion);
                }
            }
        } catch (LostBrowserException e) {
            throw e;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Return the application version.
     *
     * @return
     */
    @Override
    public String getAppVersion() {
        return version;
    }

}
