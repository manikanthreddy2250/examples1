package atdd.test.stepsets;

import atdd.common.ICondition;
import atdd.common.ImmediateAbortException;
import atdd.common.Retry;
import atdd.dao.mbm.*;
import atdd.test.core.*;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.pageobjects.authorization.ClonePopupPage;
import atdd.test.pageobjects.authorization.EditAuthorizationPage;
import atdd.test.pageobjects.authorization.RequestingProviderPage;
import atdd.test.pageobjects.priorAuthSearch.PriorAuthorizationSearchSubmittedPage;
import atdd.utils.*;
import cucumber.api.Scenario;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.*;

public class AuthorizationRequest extends AbstractStepSet {



    private CommonPageObject obj() {
        return new CommonPageObject(scenario(), driver());
    }

    public static final Logger log = Logger.getLogger(AuthorizationRequest.class.getName());

    public static final String RESTORE_PATH = "restorePath";
    public static final String OUTCOME_PROFILE = "profile";
    public static final String OUTCOME_HSC_SNAPSHOT = "hscSnapshot";
    public static final String OUTCOME_REQUEST_STATUS = "requestStatus";
    public static final String OUTCOME_HSC = "hsc";
    public static final String OUTCOME_HSC_PROV_ROLE_RF = "hscProvRoleRf";
    public static final String OUTCOME_HSC_PROV_ROLE_SJ = "hscProvRoleSj";
    public static final String OUTCOME_HSC_PROV_RF = "hscProvRf";
    public static final String OUTCOME_HSC_PROV_SJ = "hscProvSj";
    public static final String OUTCOME_HSC_ATR = "hscAtr";
    public static final String OUTCOME_HSC_MSR = "hscMsr";
    public static final String OUTCOME_HSC_DIAG = "hscDiag";
    public static final String OUTCOME_HSC_FLOWUP_CNTC = "hscFlowupCntc";
    public static final String OUTCOME_CMNCT_TRANS = "cmnctTrans";
    private static final String OUTCOME_HSC_SRVC_NON_FACL = "hscSrvcNonFacl";
    private static final String OUTCOME_HSCMEMPROVVIEW = "hscmemprovview";
    private static final String OUTCOME_WORKQUEUEVIEW = "workqueueview";
    public static final String OUTCOME_REQUEST_SUMMARY = "requestSummary";
    public static final String OUTCOME_REQUEST_SUMMARY_PH = "requestSummaryPH";
    public static final String OUTCOME_REQUEST_STATUS_PH = "requestStatusPH";
    public static final String ICUE_SRN = "icueSrn";
    public static final String ICUE_SERVICE_SUMMARY = "icueServiceSummary";
    public static final String AUTHORIZATION_OBJECT_NAME = "Authorization Object";
    public static final String CLONE_TO = "Clone To";
    public static final String CLONE_TO_AUTHORIZATION_TYPE = "Clone To Authorization Type";
    public static final String CLONE_FROM = "Clone From";
    public static final String CLONE_ON_PAGE = "Clone on Page";
    public static final String CLONE_TO_CANCER = "Clone To Cancer";
    public static final String CLONE_ON_PAGE_DASHBOARD = "Dashboard";
    public static final String CLONE_ON_PAGE_SEARCH = "Search";
    public static final String IGNORE = "IGNORE";
    public static final String CLONE_TO_CLASS = "Clone To Class";
    public static final String CLONE_TO_DRUG_CODE = "drugCode";


    /**
     * Based on hsc_id, retrieve all hsc related information from MBM database and append them to the outcome map.
     * <p>
     * For example:
     * {
     * "cmnctTrans-chnl_src_typ_id": "1",
     * "cmnctTrans-cmnct_dttm": "2019-03-15 17:48:53.0",
     * "cmnctTrans-cmnct_trans_id": "35502",
     * "cmnctTrans-cntc_at_risk_ind": "0",
     * "cmnctTrans-cntc_chk_ind": "0",
     * "cmnctTrans-cntc_nm": "TOLANI ABDULKADIR",
     * "cmnctTrans-dsclmr_giv_dttm": "2019-03-15 12:49:02.00000024",
     * "cmnctTrans-dsclmr_giv_ind": "0",
     * "cmnctTrans-dsclmr_id": "0",
     * "cmnctTrans-engage_id": "0",
     * "cmnctTrans-fax_intntl_ind": "0",
     * "cmnctTrans-fax_nbr": "454-545-4545",
     * "cmnctTrans-hsc_id": "39002",
     * "cmnctTrans-ltr_req_seq_nbr": "0",
     * "cmnctTrans-mbr_id": "0",
     * "cmnctTrans-mbr_pgm_id": "0",
     * "cmnctTrans-pri_tel_intntl_ind": "0",
     * "cmnctTrans-pri_tel_nbr": "232-323-2323",
     * "hsc-aprv_trt_rgmn_ver_id": "33013",
     * "hsc-bhv_hlth_epsd_id": "0",
     * "hsc-cob_ind": "0",
     * "hsc-cont_of_care_ind": "0",
     * "hsc-copied_hsc_id": "0",
     * "hsc-dses_trvrs_id": "530116",
     * "hsc-hsc_id": "39002",
     * "hsc-hsc_sts_rsn_typ_id": "1",
     * "hsc-hsc_sts_typ_id": "2",
     * "hsc-mbr_clin_trial_id": "0",
     * "hsc-mbr_cov_seq_nbr": "1",
     * "hsc-mbr_id": "501",
     * "hsc-pre_dtrm_ind": "0",
     * "hsc-req_cstm_trt_rgmn_ind": "0",
     * "hsc-req_trt_rgmn_ver_id": "33013",
     * "hsc-rev_prr_typ_id": "1",
     * "hsc-srvc_setting_typ_id": "2",
     * "hsc-tplnt_rel_ind": "0",
     * "hsc-um_dlgt_deriv_ind": "0",
     * "hsc-vend_cse_id": "A000039002",
     * "hsc-vend_typ_id": "1",
     * "hscAtr-1-Height in Inches": "23",
     * "hscAtr-10-Adverse Events": "1",
     * "hscAtr-11-Toxicity": "1",
     * "hscAtr-12-Medical Contraindication": "1",
     * "hscAtr-13-Non-medical Concerns": "1",
     * "hscAtr-14-Maintenance Therapy": "1",
     * "hscAtr-15-Member Phone Number": "555-555-5555",
     * "hscAtr-16-Place of Service": "11",
     * "hscAtr-17-Initial Treatment Date": "2019-03-15T00:00:00.000Z",
     * "hscAtr-18-Supportive Care": "0",
     * "hscAtr-2-Weight in Pounds": "123",
     * "hscAtr-20-Authorization Start Date": "2019-03-14T00:00:00.000Z",
     * "hscAtr-23-Backdating Authorization": "1",
     * "hscAtr-24-Backdate Auth Justification": "2",
     * "hscAtr-3-Initial Diagnosis Date": "2019-02-01T00:00:00.000Z",
     * "hscAtr-30-HSC Initial Submission Datetime": "2019-03-15T17:50:48.539Z",
     * "hscAtr-34-HSC Initial Submission Date": "2019-03-15T00:00:00.000Z",
     * "hscAtr-4-Primary Cancer": "36",
     * "hscAtr-43-Authorization Exceptions": "CONTINUE",
     * "hscAtr-44-Performance Scale": "1",
     * "hscAtr-45-Performance Status": "2",
     * "hscAtr-48-Provider Exception": "CONTINUE",
     * "hscAtr-5-Chemotherapy Trial Cancer": "0",
     * "hscAtr-53-Authorization Type": "1",
     * "hscAtr-6-Disease Progressed": "0",
     * "hscAtr-8-Initial or Changing Treatment": "2",
     * "hscAtr-9-Disease Progression": "1",
     * "hscDiag-admit_ind": "0",
     * "hscDiag-diag_cd": "C23",
     * "hscDiag-diag_cd_schm_typ_id": "0",
     * "hscDiag-diag_seq_nbr": "1",
     * "hscDiag-hsc_id": "39002",
     * "hscDiag-inac_ind": "0",
     * "hscDiag-pri_ind": "1",
     * "hscFlowupCntc-cntc_nm": "TOLANI ABDULKADIR",
     * "hscFlowupCntc-cntc_seq_num": "1",
     * "hscFlowupCntc-fax_intntl_ind": "0",
     * "hscFlowupCntc-fax_nbr": "454-545-4545",
     * "hscFlowupCntc-hsc_id": "39002",
     * "hscFlowupCntc-inac_ind": "0",
     * "hscFlowupCntc-pri_tel_intntl_ind": "0",
     * "hscFlowupCntc-pri_tel_nbr": "232-323-2323",
     * "hscFlowupCntc-sec_tel_intntl_ind": "0",
     * "hscProvRf-adr_ln_1_txt": "827 LINDEN AVE",
     * "hscProvRf-adr_ln_2_txt": "",
     * "hscProvRf-cty_nm": "BALTIMORE",
     * "hscProvRf-fax_nbr": "456-789-0123",
     * "hscProvRf-fed_tax_id": "520591667",
     * "hscProvRf-fst_nm": "TOLANI",
     * "hscProvRf-hsc_id": "39002",
     * "hscProvRf-lst_nm": "ABDULKADIR",
     * "hscProvRf-ndb_adr_seq_nbr": "11",
     * "hscProvRf-ndb_mpin": "002559569",
     * "hscProvRf-pri_tel_nbr": "999-000-1234",
     * "hscProvRf-prov_clin_id": "0",
     * "hscProvRf-prov_npi": "1699734293",
     * "hscProvRf-prov_seq_nbr": "1",
     * "hscProvRf-st_cd": "MD",
     * "hscProvRf-zip_cd_txt": "21201-4606",
     * "hscProvRoleRf-hsc_id": "39002",
     * "hscProvRoleRf-prov_role_typ_id": "RF",
     * "hscProvRoleRf-prov_seq_nbr": "1",
     * "hscProvRoleSj-hsc_id": "39002",
     * "hscProvRoleSj-prov_role_typ_id": "SJ",
     * "hscProvRoleSj-prov_seq_nbr": "2",
     * "hscProvSj-adr_ln_1_txt": "155 5TH ST",
     * "hscProvSj-adr_ln_2_txt": "",
     * "hscProvSj-cty_nm": "BARBERTON",
     * "hscProvSj-fed_tax_id": "341573781",
     * "hscProvSj-fst_nm": "SANDRA",
     * "hscProvSj-hsc_id": "39002",
     * "hscProvSj-lst_nm": "HAZRA",
     * "hscProvSj-ndb_adr_seq_nbr": "14",
     * "hscProvSj-ndb_mpin": "000231671",
     * "hscProvSj-ntwk_sts_typ_id": "1",
     * "hscProvSj-prov_clin_id": "0",
     * "hscProvSj-prov_npi": "1215972195",
     * "hscProvSj-prov_seq_nbr": "2",
     * "hscProvSj-st_cd": "OH",
     * "hscProvSj-zip_cd_txt": "44203-3332"
     * }
     *
     * @param outcome
     * @param hsc_id
     */
    public static void appendDbInfo(Map<String, Map<String, String>> outcome, long hsc_id, boolean simple) {
        SqlSessionFactory factory = MyBatisConnectionFactory.getSqlSessionFactory();
        Set<String> ignore = new HashSet<String>();
        ignore.add("creat_dttm");
        ignore.add("creat_user_id");
        ignore.add("chg_dttm");
        ignore.add("chg_user_id");
        ignore.add("updt_ver_nbr");

        HscDao hscDao = new HscDao(factory);
        List<Map<String, Object>> hscs = hscDao.selectById(hsc_id);
        Assert.assertEquals(1, hscs.size());
        Map<String, String> hsc = new LinkedHashMap<>(hscs.get(0).size());
        WhiteBoard.putAll(hsc, hscs, "", ignore);
        outcome.put(OUTCOME_HSC, hsc);
        log.warn("hsc collected: " + hsc.toString());

        HscmemprovviewDao hscmemprovviewDao = new HscmemprovviewDao(factory);
        List<Map<String, Object>> hscmemprovviews = hscmemprovviewDao.selectByHscId(hsc_id);
        if (hscmemprovviews.size() > 0) {
            Map<String, String> hscmemprovview = new LinkedHashMap<>(hscmemprovviews.get(0).size());
            WhiteBoard.putAll(hscmemprovview, hscmemprovviews, "", ignore);
            outcome.put(OUTCOME_HSCMEMPROVVIEW, hscmemprovview);
            log.warn("hscmemprovview collected: " + hscmemprovview.toString());
        }

        if (simple) {
            return;
        }

        HscProvRoleDao hscProvRoleDao = new HscProvRoleDao(factory);
        List<Map<String, Object>> hscProvRoleRfs = hscProvRoleDao.selectRequestingProviderByHscId(hsc_id);
        Assert.assertEquals(1, hscProvRoleRfs.size());
        Map<String, String> hscProvRoleRf = new LinkedHashMap<>(hscProvRoleRfs.get(0).size());
        WhiteBoard.putAll(hscProvRoleRf, hscProvRoleRfs, "", ignore);
        outcome.put(OUTCOME_HSC_PROV_ROLE_RF, hscProvRoleRf);
        log.warn("hscProvRoleRf collected: " + hscProvRoleRf.toString());

        List<Map<String, Object>> hscProvRoleSjs = hscProvRoleDao.selectServicingProviderByHscId(hsc_id);
        int rows = hscProvRoleSjs.size();
        Assert.assertTrue(1 == rows || 0 == rows);
        if (1 == rows) {
            Map<String, String> hscProvRoleSj = new LinkedHashMap<>(hscProvRoleSjs.get(0).size());
            WhiteBoard.putAll(hscProvRoleSj, hscProvRoleSjs, "", ignore);
            outcome.put(OUTCOME_HSC_PROV_ROLE_SJ, hscProvRoleSj);
            log.warn("hscProvRoleSj collected: " + hscProvRoleSj.toString());
        }

        HscProvDao hscProvDao = new HscProvDao(factory);
        List<Map<String, Object>> hscProvRfs = hscProvDao.selectRequestingProviderByHscId(hsc_id);
        Assert.assertEquals(1, hscProvRfs.size());
        Map<String, String> hscProvRf = new LinkedHashMap<>(hscProvRfs.get(0).size());
        WhiteBoard.putAll(hscProvRf, hscProvRfs, "", ignore);
        outcome.put(OUTCOME_HSC_PROV_RF, hscProvRf);
        log.warn("hscProvRf collected: " + hscProvRf.toString());


        List<Map<String, Object>> hscProvSjs = hscProvDao.selectServicingProviderByHscId(hsc_id);
        rows = hscProvRoleSjs.size();
        Assert.assertTrue(1 == rows || 0 == rows);
        if (1 == rows) {
            Map<String, String> hscProvSj = new LinkedHashMap<>(hscProvSjs.get(0).size());
            WhiteBoard.putAll(hscProvSj, hscProvSjs, "", ignore);
            outcome.put(OUTCOME_HSC_PROV_SJ, hscProvSj);
            log.warn("hscProvSj collected: " + hscProvSj.toString());
        }

        HscAtrDao hscAtrDao = new HscAtrDao(factory);
        List<Map<String, Object>> hscAtrs = hscAtrDao.selectById(hsc_id);
        Map<String, String> hscAtrMap = HscAtrDao.asMap(hscAtrs);
        outcome.put(OUTCOME_HSC_ATR, hscAtrMap);
        log.warn("hscAtrMap collected: " + hscAtrMap.toString());

        HscMsrDao hscMsrDao = new HscMsrDao(factory);
        List<Map<String, Object>> hscMsr = hscMsrDao.selectByHscId(hsc_id);
        Map<String, String> hscMsrMap = HscMsrDao.asMap(hscMsr);
        outcome.put(OUTCOME_HSC_MSR, hscMsrMap);
        log.warn("hscMsrMap collected: " + hscMsrMap.toString());


        HscDiagDao hscDiagDao = new HscDiagDao(factory);
        List<Map<String, Object>> hscDiags = hscDiagDao.selectById(hsc_id);
        if (hscDiags.size() > 0) {
            Map<String, String> hscDiag = new LinkedHashMap<>(hscDiags.get(0).size());
            WhiteBoard.putAll(hscDiag, hscDiags, "", ignore);
            outcome.put(OUTCOME_HSC_DIAG, hscDiag);
            log.warn("hscDiag collected: " + hscDiag.toString());
        }

        HscFlwupCntcDao hscFlwupCntcDao = new HscFlwupCntcDao(factory);
        List<Map<String, Object>> hscFlwupCntcs = hscFlwupCntcDao.selectByHscId(hsc_id);
        Assert.assertEquals(1, hscFlwupCntcs.size());
        Map<String, String> hscFlwupCntc = new LinkedHashMap<>(hscFlwupCntcs.get(0).size());
        WhiteBoard.putAll(hscFlwupCntc, hscFlwupCntcs, "", ignore);
        outcome.put(OUTCOME_HSC_FLOWUP_CNTC, hscFlwupCntc);
        log.warn("hscFlwupCntc collected: " + hscFlwupCntc.toString());

        CmnctTransDao cmnctTransDao = new CmnctTransDao(factory);
        List<Map<String, Object>> cmnctTranses = cmnctTransDao.selectByHscId(hsc_id);
        if (cmnctTranses.size() > 0) {
            Map<String, String> cmnctTrans = new LinkedHashMap<>(cmnctTranses.get(0).size());
            WhiteBoard.putAll(cmnctTrans, cmnctTranses, "", ignore);
            outcome.put(OUTCOME_CMNCT_TRANS, cmnctTrans);
            log.warn("cmnctTrans collected: " + cmnctTrans.toString());
        }

        HscSrvcNonFaclDao hscSrvcNonFaclDao = new HscSrvcNonFaclDao(factory);
        List<Map<String, Object>> hscSrvcNonFacls = hscSrvcNonFaclDao.selectById(hsc_id);
        if (hscSrvcNonFacls.size() > 0) {
            Map<String, String> hscSrvcNonFacl = new LinkedHashMap<>(hscSrvcNonFacls.get(0).size());
            WhiteBoard.putAll(hscSrvcNonFacl, hscSrvcNonFacls, "", ignore);
            outcome.put(OUTCOME_HSC_SRVC_NON_FACL, hscSrvcNonFacl);
            log.warn("hscSrvcNonFacl collected: " + hscSrvcNonFacl.toString());
        }

        WorkqueueviewDao workqueueviewDao = new WorkqueueviewDao(factory);
        List<Map<String, Object>> workqueueviews = workqueueviewDao.selectStarByHscId(hsc_id);
        if (workqueueviews.size() > 0) {
            Map<String, String> workqueueview = new LinkedHashMap<>(workqueueviews.get(0).size());
            WhiteBoard.putAll(workqueueview, workqueueviews, "", ignore);
            outcome.put(OUTCOME_WORKQUEUEVIEW, workqueueview);
            log.warn("workqueueview collected: " + workqueueview.toString());
        }
    }

    /**
     * Add an authorization using a map.
     * Retry for 20 minutes if something went wrong.
     * Throws ImmediateAbortException for any unrecoverable exceptions.
     *
     * @param map
     */
    public void addAuthWithRetry(Map<String, String> map) throws ImmediateAbortException, LostBrowserException, InterruptedException {
        Map<String, String> pf = WhiteBoard.resolve(getOwner(), ExcelLib.completeProfile(getOwner(), WhiteBoard.resolve(getOwner(), map)));
        String output = Conf.getOutputPath();
        String name = map.get(AUTHORIZATION_OBJECT_NAME);
        if (StringUtils.isEmpty(name)) {
            throw new ImmediateAbortException("Missing authorization name.");
        }

        String owner = map.get("owner");
        if (StringUtils.isEmpty(owner)) {
            owner = getOwner();
        }

        long hscID = tryRestore(name, pf);
        if (hscID > 0) {
            String mapKey = name + "_" + OUTCOME_HSC_SNAPSHOT;
            if (!WhiteBoard.getInstance().containsMap(owner, mapKey)) {
                List<String> modes = RequestStatusCollector.getModes(pf);
                if (modes.contains("page")) {
                    SqlSessionFactory factory = MyBatisConnectionFactory.getSqlSessionFactory();
                    HscmemprovviewDao hscmemprovviewDao = new HscmemprovviewDao(factory);
                    Map<String, Object> hscmemprovview = hscmemprovviewDao.selectByHscId(hscID).get(0);
                    String requestNumber = (String) hscmemprovview.get("pri_srvc_ref_nbr");

                    Map<String, String> criteria = new HashMap<>(1);
                    criteria.put("Request Number", requestNumber);
                    searchSubmitted(criteria);

                    TestUtils.clickUntil(driver(), PriorAuthorizationSearchSubmittedPage.selectIcon(requestNumber), new ICondition() {

                        @Override
                        public boolean evaluate() throws Exception {
                            return obj().CommonPage.verifyHeader("Request Status");
                        }
                    });
                    Map<String, Map<String, String>> outcome = RequestStatusCollector.collect(hscID, driver(), scenario(), modes, pf);
                    WhiteBoard.storeMaps(owner, name, output, outcome, true);
                } else {
                    Map<String, Map<String, String>> outcome = RequestStatusCollector.collect(hscID, null, scenario(), modes,pf);
                    WhiteBoard.storeMaps(owner, name, output, outcome, true);
                }
            }
            TestUtils.demoBreakPoint(scenario(), driver(), "Restore success: " + name);
        } else {

            // mark the authorization with authorization name
            if (tryRestoreFromDb(pf)) {
                pf.put(MBM.RPPC_FULL_NAME, name);
            }

            TestUtils.demoBreakPoint(scenario(), driver(), "Adding: " + name);

            WhiteBoard.getInstance().putMap(owner, name + "_" + OUTCOME_PROFILE, pf);

            TeamBase team = TeamFactory.getTeam(scenario(), pf);
            boolean success = team.teamwork();
            Map<String, Map<String, String>> outcome = team.getOutcome();
            WhiteBoard.storeMaps(owner, name, output, outcome, true);
            Assert.assertTrue(success);

        }
    }

    public void restore(String output, String name, String owner, long hscID, List<String> modes,  Map<String, String> pf) {
        if (modes.contains("page")) {
            SqlSessionFactory factory = MyBatisConnectionFactory.getSqlSessionFactory();
            HscmemprovviewDao hscmemprovviewDao = new HscmemprovviewDao(factory);
            Map<String, Object> hscmemprovview = hscmemprovviewDao.selectByHscId(hscID).get(0);
            String requestNumber = (String) hscmemprovview.get("pri_srvc_ref_nbr");
            if (StringUtils.isEmpty(requestNumber)) {
                requestNumber = (String) hscmemprovview.get("vend_cse_id");
            }

            Map<String, String> criteria = new HashMap<>(1);
            criteria.put("Request Number", requestNumber);
            searchSubmitted(criteria);

            TestUtils.clickUntil(driver(), PriorAuthorizationSearchSubmittedPage.selectIcon(requestNumber), new ICondition() {

                @Override
                public boolean evaluate() throws Exception {
                    return obj().CommonPage.verifyHeader("Request Status");
                }
            });
            Map<String, Map<String, String>> outcome = RequestStatusCollector.collect(hscID, driver(), scenario(), modes,pf);
            WhiteBoard.storeMaps(getOwner(), name, output, outcome, true);
        } else {
            Map<String, Map<String, String>> outcome = RequestStatusCollector.collect(hscID, null, scenario(), modes,pf);
            WhiteBoard.storeMaps(owner, name, output, outcome, true);
        }
    }

    /**
     * Cloning an existing authorization using a map.
     * Retry for 10 minutes if something went wrong.
     * In the map, below keys must be specified:
     * CLONE_FROM
     * CLONE_TO
     * CLONE_TO_AUTHORIZATION_TYPE
     *
     * @param map
     * @param owner
     * @param scenario
     */
    public static void cloneWithRetry(Map<String, String> map, String owner, Scenario scenario) {
        String output = Conf.getOutputPath();
        String from = map.get(CLONE_FROM);
        String fromProfile = from + "_" + OUTCOME_PROFILE;
        Map<String, String> fromPf = WhiteBoard.getInstance().containsMap(owner, fromProfile) ? WhiteBoard.getInstance().getMap(owner, fromProfile) : new HashMap<>();

        String to = map.get(CLONE_TO);
        map.put(MBM.AUTH_AUTHORIZATION_TYPE, map.containsKey(CLONE_TO_AUTHORIZATION_TYPE) ? map.get(CLONE_TO_AUTHORIZATION_TYPE) : fromPf.get(MBM.AUTH_AUTHORIZATION_TYPE));
        Map<String, String> pf = WhiteBoard.resolve(owner, ExcelLib.completeProfile(owner, map));
        TestUtils.demoBreakPoint(scenario, null, "Cloning: " + pf.toString());

//        String mapKey = from + "_" + OUTCOME_REQUEST_STATUS;
//        String rsf = "${" + mapKey + ".%s}";
//        String authNumber = WhiteBoard.resolve(owner, String.format(rsf, MBM.AUTH_REQUEST_NUMBER), String.format(rsf, MBM.AUTH_AUTHORIZATION_NUMBER));
        String authNumber = WhiteBoard.resolve(owner, "${" + from + "_hscSnapshot.hscmemprovview-pri_srvc_ref_nbr}");

        Retry retry = new Retry("cloneWithRetry") {

            private WebDriver webDriver = null;

            @Override
            protected void tryOnce() throws ImmediateAbortException, LostBrowserException {
                this.webDriver = Login.login(scenario, pf);
                AuthorizationRequest ar = new AuthorizationRequest(scenario, this.webDriver);
                Map<String, Map<String, String>> draftOutcome = ar.cloneAuth(
                        authNumber,
                        pf.containsKey(CLONE_ON_PAGE) ? pf.get(CLONE_ON_PAGE) : CLONE_ON_PAGE_SEARCH,
                        pf.get(MBM.AUTH_AUTHORIZATION_TYPE),
                        pf.containsKey(CLONE_TO_CANCER) ? pf.get(CLONE_TO_CANCER) : fromPf.get(MBM.RDCD_PRIMARY_CANCER),
                        pf.containsKey(CLONE_TO_CLASS) ? pf.get(CLONE_TO_CLASS) : fromPf.get(MBM.RDCD_SPECIALTY_PHARMADRUG_CLASS),
                        pf.containsKey(CLONE_TO_DRUG_CODE) ? pf.get(CLONE_TO_DRUG_CODE) : fromPf.get(MBM.RDCD_SPECIALTY_PHARMA_DRUG_CODE),
                        0,
                        null, pf);

                draftOutcome.put(OUTCOME_PROFILE, pf);
                WhiteBoard.storeMaps(owner, to, output, draftOutcome);

                pf.put(ExcelLib.CONTINUE_FROM_PAGE, RequestingProviderPage.class.getName());
                TeamBase team = TeamFactory.getTeam(scenario, pf);
                if (!team.teamwork(1)) {
                    throw new RuntimeException("Clone success but submit failed.");
                }
                outcomeCompleted = team.getOutcome();

            }

            @Override
            protected long getTimeoutMillis() {
                // 10 minutes
                return 10 * 60 * 1000;
            }

            @Override
            protected void timeout() {
                String note = "Timeout: " + to;
                TestUtils.demoBreakPoint(scenario, this.webDriver, note);
                Assert.fail(note);
            }

        };
        boolean success = retry.execute();
        WhiteBoard.storeMaps(owner, to,output, (Map<String, Map<String, String>>) retry.getOutcomeCompleted());
        Assert.assertTrue(success);

    }

    /**
     * Get the authorization number from a request object
     * Return the value of AUTH_AUTHORIZATION_NUMBER or AUTH_REQUEST_NUMBER which ever is not null
     *
     * @param owner
     * @param requestObjectName
     * @return
     */
    public static String getAuthNumber(String owner, String requestObjectName) {
        String psrn = "${" + requestObjectName + "_" + OUTCOME_HSC_SNAPSHOT + ".hsc-pri_srvc_ref_nbr}";
        String vci = "${" + requestObjectName + "_" + OUTCOME_HSC_SNAPSHOT + ".hsc-vend_cse_id}";
        String authNumber = "${" + requestObjectName + "_" + OUTCOME_REQUEST_STATUS + "." + MBM.AUTH_AUTHORIZATION_NUMBER + "}";
        String reqNumber = "${" + requestObjectName + "_" + OUTCOME_REQUEST_STATUS + "." + MBM.AUTH_REQUEST_NUMBER + "}";
        String icueNumber = "${" + requestObjectName + "_" + ICUE_SRN + "." + MBM.ICUE_EVICORE_SRN + "}";

        String result = WhiteBoard.resolve(owner, psrn, vci, authNumber, reqNumber, icueNumber);
        return result;
    }

    /**
     * Restore an authorization object from local folder Conf.getOutputPath().
     * Return true if success and false if not success.
     * No Exception will be thrown.
     *
     * @param requestObjectName
     * @param referenceProfile
     * @return
     */
    public long tryRestore(String requestObjectName, Map<String, String> referenceProfile) {

        if (!tryRestoreEnabled(referenceProfile)) {
            log.debug("<<<<<1 tryRestore(" + requestObjectName + ", referenceProfile)");
            return -1;
        }

        String owner = referenceProfile.get("owner");
        if (StringUtils.isEmpty(owner)) {
            owner = getOwner();
        }

        log.debug(">>>>> tryRestore(" + requestObjectName + ", referenceProfile)");
        String mapKey = requestObjectName + "_" + OUTCOME_HSC_SNAPSHOT;
        if (WhiteBoard.getInstance().containsMap(owner, mapKey)) {
            //check if hsc_id is valid
            String s = WhiteBoard.getInstance().getMap(owner, requestObjectName + "_" + OUTCOME_HSC_SNAPSHOT).get("hsc-hsc_id");
            long hscID = Long.parseLong(s);
            SqlSessionFactory factory = MyBatisConnectionFactory.getSqlSessionFactory();
            HscmemprovviewDao hscmemprovviewDao = new HscmemprovviewDao(factory);
            List<Map<String, Object>> hscmemprovviews = hscmemprovviewDao.selectByHscId(hscID);
            if (null != hscmemprovviews && 1 == hscmemprovviews.size()) {
                log.warn("Just created or already restored: " + requestObjectName);
                log.debug("<<<<<0 tryRestore(" + requestObjectName + ", referenceProfile)");
                return hscID;
            } else {
                log.warn("Unable to restore. Clearing: " + requestObjectName);
                WhiteBoard.getInstance().removeAll(owner, requestObjectName + "_.*");
                WhiteBoard.getInstance().removeAll(WhiteBoard.OWNER_GLOBAL, requestObjectName + "_.*");
            }
        }

        if (tryRestoreFromDb(referenceProfile)) {
            try {
                log.debug("<<<<<2 tryRestore(" + requestObjectName + ", referenceProfile)");
                return tryRestoreFromDb(requestObjectName, referenceProfile);
            } catch (Exception e) {
                log.warn(e.getMessage());
                referenceProfile.remove("tryRestoreFromDb");
                // do nothing to restore from file system
            }
        }

        log.debug("<<<<<3 tryRestore(" + requestObjectName + ", referenceProfile)");
        return tryRestoreFromFileSystem(owner, requestObjectName, referenceProfile);
    }

    private static boolean tryRestoreFromDb(Map<String, String> referenceProfile) {
        String s = referenceProfile.get("tryRestoreFromDb");
        return !StringUtils.isEmpty(s) && !s.trim().equalsIgnoreCase("false");
    }

    private static boolean tryRestoreEnabled(Map<String, String> referenceProfile) {
        String sProfileOption = null == referenceProfile ? null : referenceProfile.get("tryRestoreEnabled");
        if (!StringUtils.isEmpty(sProfileOption)) {
            return Boolean.parseBoolean(sProfileOption);
        }

        return Boolean.parseBoolean(Conf.getInstance().getProperty("tryRestoreEnabled"));
    }

    private long tryRestoreFromDb(String requestObjectName, Map<String, String> referenceProfile) {
        log.debug(">>>>> tryRestoreFromDb(" + requestObjectName + ", referenceProfile)");

        SqlSessionFactory factory = MyBatisConnectionFactory.getSqlSessionFactory();
        HscmemprovviewDao hscmemprovviewDao = new HscmemprovviewDao(factory);

        List<Map<String, Object>> hscmemprovviews = null;

        String expectedOverallStatus = referenceProfile.get("tryRestoreFromDb").trim();
        if (expectedOverallStatus.equalsIgnoreCase("true")) {
            hscmemprovviews = hscmemprovviewDao.selectByMarker(requestObjectName);
            log.debug("hscmemprovviews=" + hscmemprovviews);
        } else {
            if (expectedOverallStatus.contains("=")) {
                String varName = WhiteBoard.resolve(getOwner(), requestObjectName + "_${random5}");
                String sourceString = "${mbmdb_MyBatisConnectionFactory}";
                String queryExpression = "mybatis select * from hscmemprovview where hsc_id in (SELECT hsc_id FROM hsc_flwup_cntc where cntc_nm = '" + requestObjectName + "') and " + expectedOverallStatus + " order by creat_dttm desc limit 1;";
                new QueryShared(scenario()).isExtractedFromWithQuery(varName, sourceString, queryExpression);
                if ("1".equals(WhiteBoard.getInstance().getString(getOwner(), varName + "_rows"))) {
                    hscmemprovviews = new ArrayList<>(1);
                    hscmemprovviews.add(WhiteBoard.getInstance().getMapAsObjectByString(getOwner(), varName + "_1"));
                    log.debug("hscmemprovviews=" + hscmemprovviews);
                } else {
                    log.debug("<<<<<0 tryRestoreFromDb(" + requestObjectName + ", referenceProfile)");
                    return -11;
                }
            } else {
                hscmemprovviews = hscmemprovviewDao.selectByMarkerAndOverallStatus(requestObjectName, expectedOverallStatus);
                log.debug("hscmemprovviews=" + hscmemprovviews);
            }
        }

        if (hscmemprovviews.size() <= 0) {
            log.debug("<<<<<1 tryRestoreFromDb(" + requestObjectName + ", referenceProfile)");
            return -12;
        }

        for (Map<String, Object> hscmemprovview : hscmemprovviews) {
            if (hscmemprovviewMatchesProfile(hscmemprovview, referenceProfile)) {
                Object hsc_id = hscmemprovview.get("hsc_id");
                long hscId = hsc_id instanceof Long ? (long) hsc_id : Long.parseLong((String) hsc_id);
                log.debug("<<<<<2 tryRestoreFromDb(" + requestObjectName + ", referenceProfile)");
                return hscId;
            }
        }
        log.debug("<<<<<3 tryRestoreFromDb(" + requestObjectName + ", referenceProfile)");
        return -13;
    }

    private static boolean hscmemprovviewMatchesProfile(Map<String, Object> hscmemprovview, Map<String, String> referenceProfile) {
//        String rgType = referenceProfile.get(MBM.RG_TYPE);
//        switch (rgType) {
//            case ExcelLib.RG_TYPE_AUTO_APPROVE:
//                if (!hscmemprovview.get("hsc_sts_typ_id").equals("2")) {
//                    return false;
//                }
//                break;
//            case ExcelLib.RG_TYPE_CUSTOM:
//                if (!hscmemprovview.get("hsc_sts_typ_id").equals("1")) {
//                    return false;
//                }
//                break;
//            default:
//                log.warn("Unknown regimens type: " + rgType);
//                return false;
//        }
//
//        String membFirstName = referenceProfile.get(MBM.MEMB_FIRST_NAME);
//        if (!hscmemprovview.get("fst_nm").equals(membFirstName)) {
//            return false;
//        }
//        String membLasttName = referenceProfile.get(MBM.MEMB_LAST_NAME);
//        if (!hscmemprovview.get("lst_nm").equals(membLasttName)) {
//            return false;
//        }
        return true;
    }

    private static long tryRestoreFromFileSystem(String owner, String requestObjectName, Map<String, String> referenceProfile) {
        String stringPaths = Conf.getOutputPath();
        if (null != referenceProfile && referenceProfile.containsKey(RESTORE_PATH)) {
            String s = referenceProfile.get(RESTORE_PATH);
            if (!StringUtils.isEmpty(s)) {
                stringPaths = s.trim() + ";" + stringPaths;
            }
        }
        String[] paths = stringPaths.split(";");

        String mapKey = "";

        mapKey = requestObjectName + "_" + OUTCOME_PROFILE;
        try {
            if (!WhiteBoard.getInstance().containsMap(owner, mapKey)) {
                Map<String, String> map = QuickJson.readMap(mapKey + ".json", paths);
                if (null != referenceProfile && !equivalentProfiles(map, referenceProfile)) {
                    return -21;
                }
                WhiteBoard.getInstance().putMap(owner, mapKey, map);
            }
        } catch (Exception e) {
            log.error(e.getMessage());
            log.error("Unable to restore " + mapKey);
            return -22;
        }

        mapKey = requestObjectName + "_" + OUTCOME_HSC_SNAPSHOT;
        try {
            if (!WhiteBoard.getInstance().containsMap(owner, mapKey)) {
                Map<String, String> localHscSnapshot = QuickJson.readMap(mapKey + ".json", paths);
                if (null == localHscSnapshot) {
                    throw new RuntimeException("Unable to read file " + Conf.getOutputPath() + mapKey + ".json");
                }
                if (isHscSnapshotStale(localHscSnapshot, referenceProfile)) {
                    throw new RuntimeException("The hsc snapshot is stale: " + Conf.getOutputPath() + mapKey + ".json");
                }
                WhiteBoard.getInstance().putMap(owner, mapKey, localHscSnapshot);
            }
        } catch (Exception e) {
            log.error(e.getMessage());
            log.error("Unable to restore " + mapKey);
            return -23;
        }

        mapKey = requestObjectName + "_" + OUTCOME_REQUEST_STATUS;
        try {
            if (!WhiteBoard.getInstance().containsMap(owner, mapKey)) {
                Map<String, String> map = QuickJson.readMap(mapKey + ".json", paths);
                WhiteBoard.getInstance().putMap(owner, mapKey, map);
            }
        } catch (Exception e) {
            log.error(e.getMessage());
            log.error("Unable to restore " + mapKey);
        }

        mapKey = requestObjectName + "_" + OUTCOME_REQUEST_SUMMARY;
        try {
            if (!WhiteBoard.getInstance().containsMap(owner, mapKey)) {
                Map<String, String> map = QuickJson.readMap(mapKey + ".json", paths);
                WhiteBoard.getInstance().putMap(owner, mapKey, map);
            }
        } catch (Exception e) {
            log.error(e.getMessage());
            log.error("Unable to restore " + mapKey);
        }
        String s = WhiteBoard.getInstance().getMap(owner, requestObjectName + "_" + OUTCOME_HSC_SNAPSHOT).get("hsc-hsc_id");
        return Long.parseLong(s);
    }

    private static boolean equivalentProfiles(Map<String, String> pfA, Map<String, String> pfB) {
        String featureA = CsqaManager.getInstance().getFeature(pfA);
        String featureB = CsqaManager.getInstance().getFeature(pfB);
        if (!featureA.equals(featureB)) {
            return false;
        }
        String membTitleA = pfA.get(MBM.MEMB_TITLE);
        String membTitleB = pfB.get(MBM.MEMB_TITLE);
        return membTitleA.equals(membTitleB);
    }

    private static boolean ignoreKeys(Map<String, String> pfACopy, Map<String, String> pfBCopy, String... keys) {
        for (String key : keys) {
            if (pfACopy.containsKey(key) && pfBCopy.containsKey(key)) {
                pfACopy.remove(key);
                pfBCopy.remove(key);
            } else if (!pfACopy.containsKey(key) && !pfBCopy.containsKey(key)) {
                //do nothing
            } else {
                return false;
            }
        }
        return true;
    }

    /**
     * Check if a local HSC snapshot matches the database status.
     *
     * @param localHscSnapshot
     * @param referenceProfile
     * @return
     */
    public static boolean isHscSnapshotStale(Map<String, String> localHscSnapshot, Map<String, String> referenceProfile) {
        String sHscId = localHscSnapshot.get("hsc-hsc_id");
        String sStatus0 = localHscSnapshot.get("hsc-hsc_sts_typ_id");
        List<Map<String, Object>> hscs = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectById(Long.parseLong(sHscId));
        if (1 != hscs.size()) {
            throw new RuntimeException(hscs.size() + " rows found in hsc table searching by hsc_id=" + sHscId);
        }
        String sStatus1 = "" + hscs.get(0).get("hsc_sts_typ_id");

        log.warn("sHscId=" + sHscId);
        log.warn("sStatus0=" + sStatus0);
        log.warn("sStatus1=" + sStatus1);

        boolean matches = matches(sStatus0, sStatus1);

        return !matches;
    }

    private static boolean matches(String left, String right) {
        if (IGNORE.equals(left) || IGNORE.equals(right)) {
            return true;
        }
        if (null == left) {
            return null == right;
        } else {
            return left.equals(right);
        }
    }

    /**
     * Constructor
     *
     * @param scenario
     * @param webDriver
     */
    public AuthorizationRequest(Scenario scenario, WebDriver webDriver) {
        super(scenario, webDriver);
    }

    /**
     * Assumption: Prior Authorization Search page is displayed.
     * Search submitted request by given auth number.
     *
     * @param authNumber
     */
    public void searchSubmittedByAuthNumber(String authNumber) {
        Map<String, String> criteria = new LinkedHashMap<>();
        criteria.put("Request Number", authNumber);
        this.searchSubmitted(criteria);
        TestUtils.waitElementVisible(driver(), By.xpath("//td[.='" + authNumber + "']"));
        TestUtils.demoBreakPoint(scenario(), driver(), "Search complete: " + authNumber);
    }

    /**
     * Assumption: Prior Authorization Search page is displayed.
     * Search historical request by given auth number.
     *
     * @param authNumber
     */

    public void searchHistoryByAuthNumber(String authNumber, String TIN, String providerType, String physicianFirstName, String physicianLastName) {
        Map<String, String> criteria = new LinkedHashMap<>();
        criteria.put("Request Number", authNumber);
        criteria.put("TIN of the Requesting Provider", TIN);
        criteria.put("Provider Type", providerType);
        criteria.put("Physician First Name", physicianFirstName);
        criteria.put("Physician Last Name", physicianLastName);
        this.searchHistoryByAuthNumber(criteria, providerType);
        TestUtils.waitElementVisible(driver(), By.xpath("//span[.='" + authNumber + "']"));
        TestUtils.demoBreakPoint(scenario(), driver(), "Search complete: " + authNumber);
    }

    /**
     * Assumption: Prior Authorization Search page is displayed.
     * Search historical request by member information.
     *
     * @param SubscriberID
     * @param memberFirstName
     * @param memberLastName
     * @param dateofBirth
     */

    public void searchHistoryByMemberInformation(String SubscriberID, String memberFirstName, String memberLastName, String dateofBirth) {
        Map<String, String> criteria = new LinkedHashMap<>();
        criteria.put("Subscriber / Member ID", SubscriberID);
        criteria.put("Member First Name", memberFirstName);
        criteria.put("Member Last Name", memberLastName);
        criteria.put("Date of Birth", dateofBirth);
        this.searchHistoryByMemberInformationCriteria(criteria);

    }

    /**
     * Assumption: user login completed
     * Search submitted request by given criteria.
     *
     * @param criteria
     */
    public void searchSubmitted(Map<String, String> criteria) {
        criteria = WhiteBoard.resolve(getOwner(), criteria);

        obj().NavigationPage.navigatesToMenuItem("Home>Authorization>Search");
        obj().NavigationPage.selectSubmittedTab_Search();
        TestUtils.wait(3);
        try {
            String globalNavigationMenu = TestUtils.text(driver(), By.id("globalNavigationMenu"));
            if (globalNavigationMenu.contains("PAAN")) {
                obj().PriorAuthorizationSearchSubmittedPage.clickEverythingByTinSub();
            }
        } catch (Exception e) {
            //do nothing
        }

        obj().PriorAuthorizationSearchSubmittedPage.clickEverythingByTinSub();
        obj().PriorAuthorizationSearchSubmittedPage.selectBenefitTypeSubmitted("Medical");

        String filterTableXpath = "(//form[@name='authSearchForm']|//form[@name='hscSearchTableSubmittedFormtableFilters']/table)";
        new SearchCriteria(scenario(), driver()).setCriteria(criteria, filterTableXpath);

        obj().PriorAuthorizationSearchSubmittedPage.clickSearchSubmitted();

    }

    /**
     * Assumption: user login completed
     * Search submitted request by given criteria.
     *
     * @param criteria
     */
    public void searchHistory(Map<String, String> criteria) {
        obj().NavigationPage.navigatesToMenuItem("Home>Authorization>Search");
        obj().NavigationPage.selectHistoryTab_Search();
        TestUtils.wait(1);

        String filterTableXpath = "//form[@name='searchForm']/table";
        new SearchCriteria(scenario(), driver()).setCriteria(criteria, filterTableXpath);

        obj().PriorAuthorizationSearchHistoryPage.clickSearch_History();
        TestUtils.wait(1);

    }

    /**
     * Assumption: Prior Authorization Search page is displayed.
     * Search Historical request by given criteria.
     *
     * @param criteria
     * @param providerType
     */
    public void searchHistoryByAuthNumber(Map<String, String> criteria, String providerType) {
        obj().NavigationPage.navigatesToMenuItem("Authorization>Search");
        obj().NavigationPage.selectHistoryTab_Search();
        TestUtils.wait(1);
        TestUtils.select(driver(), By.xpath("//*[contains(@id,'hscProviderHistory-providerSelected-0')]"), providerType);
        String filterTableXpath = "//form[@name='searchForm']/table";
        new SearchCriteria(scenario(), driver()).setCriteria(criteria, filterTableXpath);
        TestUtils.demoBreakPoint(scenario(), driver(), "Search based on requestInformation");
        obj().PriorAuthorizationSearchHistoryPage.clickSearchHistoryByAuth();
        TestUtils.wait(1);
    }


    /**
     * Assumption: Prior Authorization Search page is displayed.
     * Search Historical request by given criteria.
     *
     * @param criteria
     */
    public void searchHistoryByMemberInformationCriteria(Map<String, String> criteria) {
        obj().NavigationPage.navigatesToMenuItem("Authorization>Search");
        obj().NavigationPage.selectHistoryTab_Search();
        TestUtils.click(driver(), By.xpath("//*[@id='memberInformation']"));
        TestUtils.wait(1);
        String filterTableXpath = "//form[@name='searchForm']/table";
        new SearchCriteria(scenario(), driver()).setCriteria(criteria, filterTableXpath);
        TestUtils.demoBreakPoint(scenario(), driver(), "Search based on memberInformation");
        obj().PriorAuthorizationSearchHistoryPage.clickSearchHistoryBasedOnMemberInformation();
        TestUtils.wait(1);
    }

    /**
     * Assumption: Dashboard page is displayed.
     * Clone a request by given parameters.
     *
     * @param authNumber
     * @param cloneOnPage
     * @param toAuthType
     * @param toCancerType
     * @param fromHscId
     * @param cloneMarker
     * @return
     */
    public Map<String, Map<String, String>> cloneAuth(String authNumber, String cloneOnPage, String toAuthType, String toCancerType, String drugCode, String cloneToClass, long fromHscId, String cloneMarker, Map<String, String> pf) {
        Map<String, Map<String, String>> outcome = new LinkedHashMap<>();

        By cloneIconLocator = null;
        if (null == cloneOnPage) {
            cloneOnPage = CLONE_ON_PAGE_SEARCH;
        }
        switch (cloneOnPage) {
            case CLONE_ON_PAGE_DASHBOARD:
                obj().NavigationPage.navigatesToMenuItem("Home");
                cloneIconLocator = obj().Dashboard.getCloneIconLocator(authNumber);
                TestUtils.demoBreakPoint(scenario(), driver(), "Dashboard: " + authNumber);
                break;
            case CLONE_ON_PAGE_SEARCH:
                this.searchSubmittedByAuthNumber(authNumber);
                cloneIconLocator = obj().PriorAuthorizationSearchSubmittedPage.cloneIcon(authNumber);
                TestUtils.demoBreakPoint(scenario(), driver(), "Search: " + authNumber);
                break;
            default:
                throw new RuntimeException("Unknown Clone On Page: " + cloneOnPage);
        }
        if (!toAuthType.equals("Specialty Pharmacy")) {
            TestUtils.click(driver(), cloneIconLocator);
            TestUtils.wait(1);
            TestUtils.select(driver(), ClonePopupPage.authorizationDropdown, toAuthType);
            TestUtils.wait(1);
            TestUtils.input(driver(), ClonePopupPage.cancerTypeInput, toCancerType);
            TestUtils.wait(1);
            TestUtils.click(driver(), ClonePopupPage.getCancerTypeAutoCompleteOptionLocator(toCancerType));
            TestUtils.wait(1);
            TestUtils.demoBreakPoint(scenario(), driver(), "Clone popup.");
            TestUtils.click(driver(), ClonePopupPage.cloneContinue);
            TestUtils.waitElementVisible(driver(), ClonePopupPage.thisRequestHasBeenClonedSuccessfully);
        } else {
            if (pf.get("Clone To").equals("specialtypharmaSameClass")) {
                TestUtils.click(driver(), cloneIconLocator);
                TestUtils.wait(1);
                TestUtils.click(driver(), ClonePopupPage.cloneContinue);
                TestUtils.waitElementVisible(driver(), ClonePopupPage.thisRequestHasBeenClonedSuccessfully);
            } else {
                TestUtils.click(driver(), cloneIconLocator);
                TestUtils.wait(1);
                TestUtils.input(driver(), ClonePopupPage.specialtyPharmaDrugClass, cloneToClass);
                TestUtils.input(driver(), ClonePopupPage.specialtyPharmaDrugCode, drugCode);
                By drugCodeBy = By.xpath("//a[contains(@title,'" + drugCode + "')]");
                TestUtils.click(driver(), drugCodeBy);
                TestUtils.demoBreakPoint(scenario(), driver(), "Clone popup.");
                TestUtils.wait(2);
                TestUtils.click(driver(), ClonePopupPage.cloneContinue);
                TestUtils.wait(3);
                TestUtils.waitElementVisible(driver(), ClonePopupPage.thisRequestHasBeenClonedSuccessfully);
            }
        }
        obj().RequestingProviderPage.verifyFieldsAreEditable();

        if (!StringUtils.isEmpty(cloneMarker)) {
            {
                Map<String, Map<String, String>> dbGroup = new LinkedHashMap<>();
                appendDbInfo(dbGroup, fromHscId, false);
                Map<String, String> dbGroupPhoto = WhiteBoard.snapshot(dbGroup);
                outcome.put(OUTCOME_HSC_SNAPSHOT + "_from", dbGroupPhoto);
            }
            {
                Map<String, Map<String, String>> dbGroup = new LinkedHashMap<>();
                HscmemprovviewDao hscmemprovviewDao = new HscmemprovviewDao(MyBatisConnectionFactory.getSqlSessionFactory());
                List<Map<String, Object>> hscmemprovviews = hscmemprovviewDao.selectByMarker(cloneMarker);
                long hsc_id = 0;
                for (Map<String, Object> hscmemprovview : hscmemprovviews) {
                    if (!hscmemprovview.get("hsc_id").equals(fromHscId)) {
                        hsc_id = (long) hscmemprovview.get("hsc_id");
                        break;
                    }
                }
                appendDbInfo(dbGroup, hsc_id, false);
                Map<String, String> dbGroupPhoto = WhiteBoard.snapshot(dbGroup);
                outcome.put(OUTCOME_HSC_SNAPSHOT + "_to", dbGroupPhoto);
            }
        }

        log.warn("outcome=" + outcome);
        TestUtils.demoBreakPoint(scenario(), driver(), "Clone completed.");
        return outcome;
    }

    /**
     * Call resend service for the specified hsc_id.
     * Retry for Conf.getResendTimeoutInMinutes().
     *
     * @param hsc_id
     * @return
     */
    public static boolean retryResend(Scenario scenario, WebDriver webDriver, long hsc_id) {
        Map<String, Object> hsc = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectById(hsc_id).get(0);
        if (hsc.containsKey("pri_srvc_ref_nbr")) {
            return true;
        }
        RestUtility restUtility = new RestUtility(scenario, webDriver);

        return new Retry("retryResend") {

            @Override
            protected void tryOnce() {
                String resBody = restUtility.resend("" + hsc_id);
                log.warn("Resend service response body: " + resBody);
            }

            @Override
            protected boolean until() {
                Map<String, Object> hsc = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectById(hsc_id).get(0);
                return hsc.containsKey("pri_srvc_ref_nbr");
            }

            @Override
            protected long getTimeoutMillis() {
                return Conf.getResendTimeoutInMinutes() * 60 * 1000;
            }
        }.execute();
    }

    /**
     * Call refresh service for the specified hsc_id.
     * Retry for Conf.getRefreshTimeoutInMinutes().
     *
     * @param hsc_id
     * @return
     */
    public static boolean retryRefresh(Scenario scenario, WebDriver webDriver, long hsc_id) {
        Map<String, Object> hsc = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectById(hsc_id).get(0);
        if (!hsc.containsKey("pri_srvc_ref_nbr")) {
            throw new RuntimeException("This request with hsc_id=" + hsc_id + " has not been sent to ICUE system yet.");
        }

        String primarySRN = (String) hsc.get("pri_srvc_ref_nbr");

        return new Retry("retryRefresh") {
            String resBody;

            @Override
            protected void tryOnce() {
                resBody = new RestUtility(scenario, webDriver).refresh(primarySRN, "" + hsc_id);
                log.warn("Refresh service response body: " + resBody);
            }

            @Override
            protected boolean until() {
                return this.resBody.equals("Successfully processed Primary SRN: " + primarySRN + " with HSC ID: " + hsc_id + ".");
            }

            @Override
            protected long getTimeoutMillis() {
                return Conf.getRefreshTimeoutInMinutes() * 60 * 1000;
            }
        }.execute();
    }

    /**
     * Backdate the specified authorization request
     *
     * @param authNumber
     * @param backdate
     */
    public void backdate(String authNumber, String backdate) {
        this.searchSubmittedByAuthNumber(authNumber);
        By editIcon = obj().PriorAuthorizationSearchSubmittedPage.editIcon(authNumber);
        TestUtils.click(driver(), editIcon);

        while (!TestUtils.isElementVisible(driver(), EditAuthorizationPage.authorizationStartDateInput)) {
            try {
                obj().EditAuthorizationPage.clickBackdatingStartDateCheckBox();
            } catch (Exception e) {
                TestUtils.sleep(1000);
            }
        }

        obj().EditAuthorizationPage.enterAuthorizationStartDate(backdate);
        obj().EditAuthorizationPage.selectJustificationForBackdatingOfStartDate("System Unavailable");

        TestUtils.demoBreakPoint(scenario(), driver(), "Backdating " + authNumber + " to " + backdate);

        Assert.assertTrue(new Retry("backdate", 5 * 60 * 1000, 0, 0) {

            @Override
            protected void tryOnce() throws Exception {
                obj().EditAuthorizationPage.clickConfirmButton();
            }

            @Override
            protected boolean until() throws Exception {
                return obj().CommonPage.verifyHeader("Request Status");
            }

        }.execute());

    }

    /**
     * Get the authorization Status from a request object
     * Return the value of AUTH_AUTHORIZATION_STATUS or AUTH_REQUEST_STATUS which ever is not null
     *
     * @param owner
     * @return
     */
    public static String getAuthStatus(String owner, String requestObjectName) {
        String fAuthStatus = "${" + requestObjectName + "_" + OUTCOME_REQUEST_STATUS + "." + MBM.AUTH_AUTHORIZATION_STATUS + "}";
        String fReqStatus = "${" + requestObjectName + "_" + OUTCOME_REQUEST_STATUS + "." + MBM.AUTH_REQUEST_STATUS + "}";
        String actualAuthStatus = WhiteBoard.resolve(owner, fAuthStatus, fReqStatus);
        return actualAuthStatus;
    }

    /**
     * Assumption: Prior auth search page is displayed.
     * Search draft request by given hsc_id
     *
     * @param hscId
     */

    public void searchDraftByHscId(String hscId) {
        Map<String, String> criteria = new LinkedHashMap<>();
        criteria.put("Draft ID", hscId);
        this.searchDraft(criteria);
        TestUtils.waitElementVisible(driver(), By.xpath("//span[.='" + hscId + "']"));
        TestUtils.demoBreakPoint(scenario(), driver(), "Search complete: " + hscId);
    }


    /**
     * Assumption: Prior auth search page is displayed.
     * Search draft request by given hsc_id
     *
     * @param criteria
     */
    public void searchDraft(Map<String, String> criteria) {
        obj().NavigationPage.expandClickPrimaryNav("Authorization");
        obj().NavigationPage.clickOptionFromPrimaryNavMenu("Search");
        TestUtils.wait(1);
        try {
            this.driver().switchTo().alert().accept();
        } catch (Exception e) {
            // do nothing
        }
        TestUtils.wait(1);

        obj().NavigationPage.selectDraftTab_Search();
        TestUtils.wait(1);
        try {
            String globalNavigationMenu = TestUtils.text(driver(), By.id("globalNavigationMenu"));
            if (globalNavigationMenu.contains("PAAN")) {
                obj().PriorAuthorizationSearchSubmittedPage.clickEverythingByTinSub();
            }
        } catch (Exception e) {
            //do nothing
        }

        String filterTableXpath = "//form[@name='hscSearchTableDraftsFormtableFilters']/table";
        new SearchCriteria(scenario(), driver()).setCriteria(criteria, filterTableXpath);

        obj().PriorAuthorizationSearchDraftPage.clickSearchDraft();
        TestUtils.wait(1);

    }
}
