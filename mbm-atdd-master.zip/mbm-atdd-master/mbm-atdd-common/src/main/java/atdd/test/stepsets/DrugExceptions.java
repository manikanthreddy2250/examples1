package atdd.test.stepsets;

import atdd.test.core.AbstractStepSet;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.pageobjects.drugExceptions.DrugExceptionsPage;
import atdd.utils.InvalidSearchCriteriaException;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.openqa.selenium.WebDriver;

import java.util.List;
import java.util.Map;

public class DrugExceptions extends AbstractStepSet {
    private CommonPageObject obj() {
        return new CommonPageObject(scenario(), driver());
    }

    private DrugExceptionsPage dep = new DrugExceptionsPage(driver());

    public DrugExceptions(Scenario scenario, WebDriver webDriver) {
        super(scenario, webDriver);
    }


    public void validatePageNavigation(Map<String,String> map)
    {
        if (!driver().getTitle().contains("Drug Exceptions"))
        {
            obj().NavigationPage.navigatesToMenuItem("Tools>Rules & Exceptions>Exceptions");
            obj().CommonPage.waitForNOTBusyIndicator();
        }
        obj().CommonPage.verifyHeader(map.get("Header"));
    }


       /*
     Assumption: User already logged in and navigates to Drug Exceptions
    * and verifies the default selected values for search fields
    *
    * @param label
     */

    public void validateSearchFieldInDrugExceptionScreen(List label){
        if (!driver().getTitle().contains("Drug Exceptions")) {
            obj().NavigationPage.navigatesToMenuItem("Tools>Rules & Exceptions>Exceptions");
            obj().CommonPage.waitForNOTBusyIndicator();
        }
        dep.validateLabelValues(label);
        dep.validateDefaultValuesForAuthType();
        dep.validateDefaultValuesForPayer();

    }

    /*
     Assumption: User already logged in and navigates to Drug Exceptions
    * and verifies the new added column
    * the provided details
    *
    * @param expectedHeader
     */
    public void validatePaginationHeader(List expectedHeader) {
        if (!driver().getTitle().contains("Drug Exceptions")) {
            obj().NavigationPage.navigatesToMenuItem("Tools>Rules & Exceptions>Exceptions");
            obj().CommonPage.waitForNOTBusyIndicator();
        }
        dep.validateTableHeader(expectedHeader);
    }


    /**
     * Assumption: Admin user login and Dashboard page is displayed.
     * Search Drug according to the criteria.
     * verifies result Grid stores values correctly and verifies the sort order
     *
     * @param map

     */
    public void search(Map<String, String> map) throws InvalidSearchCriteriaException {
        if (!driver().getTitle().contains("Drug Exceptions")) {
            obj().NavigationPage.navigatesToMenuItem("Tools>Rules & Exceptions>Exceptions");
            obj().CommonPage.waitForNOTBusyIndicator();
        }

        dep.enterDrugCodeOnDrugExceptionsSearchCriteria(map.get("Drug Code"));
        dep.selectAuthTypeOnDrugExceptionSearchCriteria(map.get("Authorization Type"));
        dep.enterEffectiveStartDateOnDrugExceptionsSearchCriteria(map.get("Effective Start Date"));

        dep.clickSearchButton();
        dep.VerifyRecordsDisplayedCorrectly(map);
        dep.userVerifiesSortingOrder();
    }

    public void clickOnAddDrugException(){
        if (!driver().getTitle().contains("Drug Exceptions")) {
            obj().NavigationPage.navigatesToMenuItem("Tools>Rules & Exceptions>Exceptions");
            obj().CommonPage.waitForNOTBusyIndicator();
        }
        dep.clickOnAddDrugExceptionLink();
    }


    public void fieldValidation(List<String> label) {
        dep.verifyFieldsOnAddDrugExceptionPopUp(label);
    }


    /*
    Enter values in the Add Drug Exception Popup mandatory fields
     */
    public void enterfieldValues(Map<String, String> map) {
        if (!driver().getTitle().contains("Drug Exceptions")) {
            obj().NavigationPage.navigatesToMenuItem("Tools>Rules & Exceptions>Exceptions");
            obj().CommonPage.waitForNOTBusyIndicator();
        }

        dep.clickOnAddDrugExceptionLink();
        dep.enterDrugCodeOnAddDrugExceptionPopUp(map.get("Drug Code"));
        dep.selectDrugRouteOnAddDrugExceptionPopUp(map.get("Drug Route"));
        dep.selectPayerOnAddDrugExceptionPopUp(map.get("Payer"));
        dep.selectAuthTypeOnAddDrugExceptionPopUp(map.get("Authorization Type"));
        dep.enterMessageOnAddDrugExceptionPopUp(map.get("Message"));
        dep.clickSaveButton();
    }

    /**
     * adding drug exception for Chemo auth type
     * @param map
     */
    public void addDrug(Map<String, String> map) {
        if (!driver().getTitle().contains("Drug Exceptions")) {
            obj().NavigationPage.navigatesToMenuItem("Tools>Rules & Exceptions>Exceptions");
            obj().CommonPage.waitForNOTBusyIndicator();
        }
        dep.clickOnAddDrugExceptionLink();
        dep.selectPayerOnAddDrugExceptionPopUp(map.get("Payer"));
        dep.selectAuthTypeOnDrugException(map.get("Authorization Type"));
        dep.enterDrugCodeOnAddDrugExceptionPopUp(map.get("Drug Code"));
        dep.selectDrugRouteOnAddDrugExceptionPopUp(map.get("Drug Route"));
        dep.selectState();
        dep.selectLob();
        dep.clickRegimenCustom();
        dep.enterMessageOnAddDrugExceptionPopUp(map.get("Message"));
        dep.clickSaveButton();

    }

    /**
     * deleting drug
     * @param map
     */
    public void deleteDrug(Map<String, String> map) {
        if (!driver().getTitle().contains("Drug Exceptions")) {
            obj().NavigationPage.navigatesToMenuItem("Tools>Rules & Exceptions>Exceptions");
            obj().CommonPage.waitForNOTBusyIndicator();
        }
        dep.enterDrugCodeOnDrugExceptionsSearchCriteria(map.get("Drug Code"));
        dep.selectAuthTypeOnDrugExceptionSearchCriteria(map.get("Authorization Type"));
        dep.enterEffectiveStartDateOnDrugExceptionsSearchCriteria(map.get("Effective Start Date"));
        dep.clickSearchButton();
        TestUtils.wait(10);
        while (dep.hasResult()) {
            dep.removeFirstResult();
        }

    }
}
