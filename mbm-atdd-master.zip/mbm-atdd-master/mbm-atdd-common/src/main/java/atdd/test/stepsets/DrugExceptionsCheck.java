package atdd.test.stepsets;

import atdd.test.core.AbstractStepSet;
import atdd.test.pageobjects.CommonPageObject;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.openqa.selenium.WebDriver;

public class DrugExceptionsCheck extends AbstractStepSet {

    public DrugExceptionsCheck(Scenario scenario, WebDriver webDriver) {
        super(scenario, webDriver);
    }
    private CommonPageObject obj() {
        return new CommonPageObject(scenario(), driver());
    }

    public static final String Levoleucovorin_Drug = "Levoleucovorin will only be approved if Leucovorin is not available. A peer to peer will be required to attest to a shortage of leucovorin before a decision will be rendered. According to the NCCN treatment options include the dose of Levoleucovorin that is commonly used in Europe; lower doses of Levoleucovorin; or treatment without leucovorin. If you would like to change your request to Leucovorin, use the review history to go back to treatment selection and update your request.";

    public static final String highDoseYervoy_Drug = "High Dose Yervoy will only be approved if Ipilimumab is not available. A peer to peer will be required to attest to a shortage of Ipilimumab before a decision will be rendered. According to the NCCN treatment, options include the dose of Yervoy that is commonly used in Eurpoe; lower doses of Yervoy; or treatment without Ipilimumab. If you would like to change your request to Ipilimumab, use the review history to go back to the treatment election and update your request.";

    public static final String denosumab_Drug = "Test Drug";



    /**
     * Assumption: Drug Exceptions on regimens page is displayed.
     * Validate the message is as expected.
     *
     * @return
     */
    public boolean levoleucovorinDrug () {
        TestUtils.demoBreakPoint(scenario(), driver(), "Drug Exception check");
        String expectedMessage = String.format(Levoleucovorin_Drug);
        String actualMessage = obj().RegimensPage.drugExceptionMessage();
        TestUtils.wait(1);
        return expectedMessage.equals(actualMessage);
    }

    /**
     *Assumption: Drug Exceptions on regimens page is displayed.
     * Validate the message is as expected.
     * @return
     */

    public boolean highDoseYervoyDrug() {
        TestUtils.demoBreakPoint(scenario(), driver(), "Drug Exception check");
        String expectedMessage = String.format(highDoseYervoy_Drug);
        String actualMessage = obj().RegimensPage.drugExceptionMessage();
        TestUtils.wait(1);
        return expectedMessage.equals(actualMessage);
    }

    /**
     * Assumption: Drug Exceptions on regimens page is displayed.
     *validate the message is as expected.
     * @return
     */
    public boolean denosumabDrug() {
        TestUtils.demoBreakPoint(scenario(), driver(), "Drug Exception check");
        String expectedMessage = String.format(denosumab_Drug);
        String actualMessage = obj().RegimensPage.drugExceptionMessage();
        TestUtils.wait(1);
        return expectedMessage.equals(actualMessage);
    }
}
