package atdd.test.stepsets;

import atdd.test.core.AbstractStepSet;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.pageobjects.NavigationPage;
import atdd.test.pageobjects.drugPolicyMaintenance.CreateNewDrugPolicyPage;
import atdd.test.pageobjects.drugPolicyMaintenance.DrugPolicyMaintenancePage;
import cucumber.api.Scenario;
import org.openqa.selenium.WebDriver;

import java.util.Map;

public class DrugPolicyMaintenance extends AbstractStepSet {

    private CommonPageObject obj() {
        return new CommonPageObject(scenario(), driver());
    }

    private NavigationPage np = new NavigationPage(driver());
    private CreateNewDrugPolicyPage cndp = new CreateNewDrugPolicyPage(driver());
    private DrugPolicyMaintenancePage dpmp = new DrugPolicyMaintenancePage(driver());

    public DrugPolicyMaintenance(Scenario scenario, WebDriver webDriver) {
        super(scenario, webDriver);
    }


    /*
     * Assumption: user clicks on Add New Drug Hyperlink in Newly Approved Drugs
     * and enter all the mandatory fields and clicks on Save
     * @param map
     * */
    public void createNewDrugPolicy(Map<String, String> map) {
        dpmp.clickOnCreateNewDrugPolicy();
        cndp.enterThepolicyNumberonCreateNewDrugPolicyPopUp(map.get("Create Policy Name"));
        cndp.selectpayerOnCreateNewDrugPolicyPopUp(map.get("Payer"));
        cndp.selectLineofBusinessOnCreateNewDrugPolicyPopUp(map.get("Line of Business"));
        cndp.enterTheffectiveEndDateinCreateNewDrugPolicyPopUp(map.get("Effective End Date"));
        cndp.clickSaveButton();
    }

    public void searchAndEditDrugPolicy(Map<String, String> map) throws InterruptedException {
        Thread.sleep(10000);
        dpmp.enterPolicyNameInDrugPolicyMaintenancePage(map.get("Search Policy Name"));
    }


    public void typeToSearchDiseaseState(Map<String, String> map) throws InterruptedException {
        Thread.sleep(10000);
        dpmp.enterDiseaseStatesearchtextbox(map.get("Disease State"));
    }

    public void cancelTypeToSearchDiseaseState(Map<String, String> map) throws InterruptedException {
        Thread.sleep(10000);
        dpmp.enterDiseaseStatesearchtextboxForCancel(map.get("Disease States"));
    }


    public void clickOnEditPencilIconInPolicyDetailsSession() {
        dpmp.clickOnEditpencilIconPolicyDetailssession();
    }

    public void editPolicyDetails(Map<String, String> map) {
        cndp.editPolicyNameInDrugPolicyMaintenancePagePopUp(map.get("Edit Policy Name"));
        cndp.editLineofBusinessOnCreateNewDrugPolicyPopUp(map.get("Edit Line of Business"));
        cndp.editTheffectiveEndDateinCreateNewDrugPolicyPopUp(map.get("Edit EffectiveEndDate"));
        cndp.clickSaveButton();
    }


    public void clickOnAddDrugHyperLinkAndEnterMandatoryFields(Map<String, String> map) {
        dpmp.clickOnAddDrugHyperLinkInPolicyDetailsSession(map.get("drugName"));
        dpmp.selectSiteOfCareInPolicyDetailsSession();
        dpmp.enterAddOAMBuilderIDInPolicyDetailsSession(map.get("OAM Builder ID"));
        dpmp.clickOnSaveButtonInPolicyDetailsSession();


    }

    public void clickOnEditpenciliconAndEnterMandatoryFieldsForAddDrug(Map<String, String> map) {
        dpmp.clickOnlicksonEditPencilIconInAddDrugDetailsSession();
        dpmp.selectEditSiteOfCareInPolicyDetailsSession(map.get("Site of Care1"));
        dpmp.enterEditOAMBuilderIDInPolicyDetailsSession(map.get("OAM Builder ID1"));
        dpmp.clickOnEditSaveButtonInPolicyDetailsSession();

    }

    public void clickOnAddDrugBrandNameinDrugPolicyDetailssession() throws InterruptedException {
        dpmp.clickOndrugbrandNamePolicyDetailsSession();


    }

    public void clickOnAddRowHyperLinkAndEnterMandatoryFieldsInDiseaseStateDetails() {
        dpmp.enterDrugNameInDiseaseStateDetails();
        dpmp.clickOnAddRowSaveButtonInDiseaseStateDetailsSession();


    }

    public void clickOnDosageDetailsSubTabInDiseaseStateDetailsSession() {
        dpmp.clickOnDosageDetailsSubTab();


    }

    public void clickOnAddRowHyperLinkAndEnterMandatoryFieldsInDosageDetailsSession(Map<String, String> map) throws InterruptedException {
        dpmp.selectAddRowDiseaseStateDosageDetails(map.get("Diseasestate"));
        dpmp.selectAddRowInitialvsContinuationDosageDetails();
        dpmp.selectAddRowDoseDosageDetails(map.get("Dose"));
        dpmp.selectAddRowDosageFrequencyFirstDosageDetails(map.get("Create FDosage Frequency"));
        dpmp.selectAddRowDosageFrequencySecondDosageDetails(map.get("Create SDosage Frequency"));
        dpmp.selectAddRowDurationofAuthorizationDosageDetails(map.get("Create Duration of Authorization"));
        dpmp.enterCreateTotalDosageInDosageDetails(map.get("Create Total Dosage"));
        dpmp.clickOnAddRowSaveButtonInDiseaseStateDetailsSession();


    }

    public void clickOnEditpenciliconAndEnterMandatoryFieldsForDiseaseStateDetails() {
        dpmp.clickOnEditPencilIconInDiseaseStateDetails();
        dpmp.clickOnAddRowSaveButtonInDiseaseStateDetailsSession();
        dpmp.ClickingDeleteIconInDiseaseStateDetails();
    }

    public void clickOnEditpenciliconAndEditDosageExceptiontoDiseaseStateDetails() {
        dpmp.clickOnEditPencilIconInDiseaseStateDetailsForAddDosageDropDown();
    }

    public void clickOnEditpenciliconAndEnterMandatoryFieldsForDosageDetailssession(Map<String, String> map) throws InterruptedException {
        dpmp.selectEditRowDiseaseStateDosageDetails();
        dpmp.enterEditTotalDosageInDosageDetails(map.get("Edit Total Dosage"));
        dpmp.clickOnAddRowSaveButtonInDiseaseStateDetailsSession();
        dpmp.ClickingDeleteIconInDosageDetailssession();
    }

    public void clickOnVersionHistoryHyperLinkInDrugPolicyMaintenancePage() {
        dpmp.ClickOnVersionHistoryHyperLink();

    }

    public void deleteDiseasestate(Map<String, String> map) {
        dpmp.deleteDiseasestate(map.get("Disease State"));

    }

    public void clickonDelete(Map<String, String> map) {
        dpmp.deleteDrug((map.get("drugName")));
    }

    public void clickOnDiseaseStateSubTabInDiseaseStateDetailsSession() {

        dpmp.clickDiseaseStatusTab();


    }
}



