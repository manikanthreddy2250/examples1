package atdd.test.stepsets;

import atdd.dao.icue.HscDaoIcue;
import atdd.dao.icue.MyBatisConnectionFactoryICUE;
import atdd.dao.mbm.HscDao;
import atdd.dao.mbm.MbrDao;
import atdd.dao.mbm.MyBatisConnectionFactory;
import atdd.test.core.AbstractStepSet;
import atdd.test.pageobjects.CommonPageObject;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.openqa.selenium.WebDriver;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class DupTermCheck extends AbstractStepSet {
    private CommonPageObject obj() {
        return new CommonPageObject(scenario(), driver());
    }

    public static final String F_DUP_CHECK_MSG = "There are one or more pending authorization requests for %s %s.\n" +
            "\n" +
            "A new authorization request cannot be submitted until a decision is made on pending Request: %s.\n" +
            "Please contact us at 1-888-397-8129 for any questions.";
    public static final String F_DUP_CHECK_MSG_PHN = "There are one or more pending authorization requests for %s %s.\n" +
            "\n" +
            "A new authorization request cannot be submitted until a decision is made on pending request: %s.\n" +
            "\n" +
            "Please contact us at 1-888-832-0972 for any questions.";
    public static final String F_TERM_CHECK_MSG = "There are one or more approved authorization requests for %s %s.\n" +
            "\n" +
            "If this new request is approved, Authorization %s will be terminated.";
    public static final String F_I_TERM_CHECK_MSG = "There are one or more approved authorization requests for %s %s. The existing Authorizations are %s.\n" +
            "\n" +
            "In order to continue, please select that you are changing the treatment to Continuation Therapy for this member.";

    private final String fstNm;
    private final String lstNm;
    private final String midlNm;
    private String stringOfAuthNumbers;


    /**
     * Constructor
     *
     * @param scenario
     * @param webDriver
     */
    public DupTermCheck(Scenario scenario, WebDriver webDriver, List<String> againstAuthNumberList, String subscriberId) {
        super(scenario, webDriver);
        List<String> authStringList = new ArrayList<>();
        Map<String, Object> mbr = new MbrDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectBySubscriberId(subscriberId).get(0);

        for (int i = 0; i < againstAuthNumberList.size(); i++) {
            List<Map<String, Object>> hscList = new HscDao(MyBatisConnectionFactory.getSqlSessionFactory()).selectByAuthNumber(againstAuthNumberList.get(i));

            if (hscList.size() == 0) {
                hscList = new HscDaoIcue(MyBatisConnectionFactoryICUE.getSqlSessionFactory()).selectByIcueAuthNumber(againstAuthNumberList.get(i));
                i = 0;
                for (Map<String, Object> srvc : hscList) {
                    hscList.set(i, TestUtils.mapKeysToLowerCase(srvc));
                    i++;
                }
            }
            Map<String, Object> hsc = hscList.get(0);

            String authNum = (hsc.containsKey("pri_srvc_ref_nbr") ? hsc.get("pri_srvc_ref_nbr") : hsc.get("vend_cse_id")).toString();
            authStringList.add(authNum);
        }

        stringOfAuthNumbers = authStringList.toString();
        stringOfAuthNumbers = stringOfAuthNumbers.substring(1, stringOfAuthNumbers.length() - 1);
        this.fstNm = (String) mbr.get("fst_nm");
        this.lstNm = (String) mbr.get("lst_nm");
        this.midlNm = (String) mbr.get("midl_nm");
    }

    /**
     * Assumption: Dup Popup page is displayed.
     * Validate the message is as expected.
     *
     * @return
     */
    public boolean dupPopupOK(String payer) {
        String expectedMessage;
        switch (payer) {
            case "Peoples Health Network": {
                if (this.midlNm.isEmpty()) {
                    expectedMessage = String.format(F_DUP_CHECK_MSG_PHN, this.fstNm, this.lstNm, stringOfAuthNumbers);
                } else {
                    String mlname = this.midlNm + ' ' + this.lstNm;
                    expectedMessage = String.format(F_DUP_CHECK_MSG_PHN, this.fstNm, mlname, stringOfAuthNumbers);
                }
                break;
            }
            case "UnitedHealthcare": {
                if (this.midlNm.isEmpty()) {
                    expectedMessage = String.format(F_DUP_CHECK_MSG, this.fstNm, this.lstNm, stringOfAuthNumbers);
                } else {
                    String mlname = this.midlNm + ' ' + this.lstNm;
                    expectedMessage = String.format(F_DUP_CHECK_MSG, this.fstNm, mlname, stringOfAuthNumbers);
                }
                break;
            }
            case "BlueCross BlueShield of South Carolina": {
                if (this.midlNm.isEmpty()) {
                    expectedMessage = String.format(F_DUP_CHECK_MSG, this.fstNm, this.lstNm, stringOfAuthNumbers);
                } else {
                    String mlname = this.midlNm + ' ' + this.lstNm;
                    expectedMessage = String.format(F_DUP_CHECK_MSG, this.fstNm, mlname, stringOfAuthNumbers);
                }
                break;
            }
            default: {
                if (this.midlNm.isEmpty()) {
                    expectedMessage = String.format(F_DUP_CHECK_MSG, this.fstNm, this.lstNm, stringOfAuthNumbers);
                } else {
                    String mlname = this.midlNm + ' ' + this.lstNm;
                    expectedMessage = String.format(F_DUP_CHECK_MSG, this.fstNm, mlname, stringOfAuthNumbers);
                }
                break;
            }
        }
        String actualMessage = obj().DupTermPopupPage.getMessage();

        log(expectedMessage, actualMessage, "Dup popup check");
        return expectedMessage.contains(actualMessage);
    }


    /**
     * Assumption: Term Popup page with continue button is displayed.
     * Validate the message is as expected.
     *
     * @return
     */
    public boolean termPopupOK() {
        String expectedMessage = String.format(F_TERM_CHECK_MSG, this.fstNm, this.lstNm, stringOfAuthNumbers);
        String actualMessage = obj().DupTermPopupPage.getMessage();

        log(expectedMessage, actualMessage, "Term popup check");
        return expectedMessage.equals(actualMessage);
    }

    /**
     * Assumption: Term Popup page without continue button is displayed.
     * Validate the message is as expected.
     *
     * @return
     */
    public boolean initialTreatmentTermPopupOK() {
        String expectedMessage = String.format(F_I_TERM_CHECK_MSG, this.fstNm, this.lstNm, stringOfAuthNumbers);
        String actualMessage = obj().DupTermPopupPage.getMessage();

        log(expectedMessage, actualMessage, "Initial Treatment Term popup check");
        return expectedMessage.equals(actualMessage);
    }

    private void log(String expectedMessage, String actualMessage, String header) {
        String note = "";
        note += "\r\n" + header;
        note += "\r\n[EXPECTED]\r\n" + expectedMessage;
        note += "\r\n[ACTUAL]\r\n" + actualMessage;
        TestUtils.demoBreakPoint(scenario(), driver(), note);
    }
}
