package atdd.test.stepsets;

import atdd.test.core.AbstractStepSet;
import atdd.test.pageobjects.CommonPageObject;
import cucumber.api.Scenario;
import org.assertj.core.api.SoftAssertions;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;

public class Examples extends AbstractStepSet {

   private SoftAssertions softAssertions = new SoftAssertions();

    public Examples(Scenario scenario, WebDriver webDriver) {
        super(scenario, webDriver);

    }

    private CommonPageObject obj() {
        return new CommonPageObject(scenario(), driver());
    }

    //Processes the soft asserts to determine failures.  Required at the end if using soft asserts
    public void processSoftAssertionResults()
    {
        softAssertions.assertAll();
    }

    public void hardAssertDemo()
    {
        System.out.println("1st - Hard assert Pass");
        Assert.assertTrue(true);
        System.out.println("2nd - Hard Assert Fail");
        Assert.assertTrue(false );
        System.out.println("3rd - Hard Assert Pass");
        Assert.assertTrue(true);
        processSoftAssertionResults();
    }

    public void softAssertDemo()
    {
        Boolean pass = true;
        System.out.println("1st assert - Pass");
        softAssertions.assertThat(pass).isEqualTo(true);
        System.out.println("2nd assert - Fail");
        softAssertions.assertThat(pass).isEqualTo(false);
        System.out.println("3rd assert - Pass");
        softAssertions.assertThat(pass).isEqualTo(true);
        System.out.println("Processing all softAsserts");
        processSoftAssertionResults();
    }

    public void mixAssertDemo(){
        Boolean pass = true;
        System.out.println("1st - hard assert pass");
        Assert.assertTrue(true);
        System.out.println("2nd - Soft Assert pass");
        softAssertions.assertThat(pass).isEqualTo(true);
        System.out.println("3rd - Soft Assert fail");
        softAssertions.assertThat(pass).isEqualTo(false);
        System.out.println("4th - Hard Assert pass");
        Assert.assertTrue(true);
        processSoftAssertionResults();
    }

    public void mixAssertDemoAllPass(){
        Boolean pass = true;
        System.out.println("1st - hard assert pass");
        Assert.assertTrue(true);
        System.out.println("2nd - Soft Assert pass");
        softAssertions.assertThat(pass).isEqualTo(true);
        System.out.println("3rd - Soft Assert pass");
        softAssertions.assertThat(pass).isEqualTo(true);
        System.out.println("4th - Hard Assert pass");
        Assert.assertTrue(true);
        processSoftAssertionResults();
    }

    public void noAssertAll(){
        Boolean pass = true;
        System.out.println("1st - soft assert fail - but no assert all");
        softAssertions.assertThat(pass).isEqualTo(false);
    }

}
