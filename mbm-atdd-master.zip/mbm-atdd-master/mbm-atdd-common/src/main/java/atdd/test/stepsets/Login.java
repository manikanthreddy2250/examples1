package atdd.test.stepsets;

import atdd.common.ICondition;
import atdd.common.ImmediateAbortException;
import atdd.common.ScenarioLogger;
import atdd.common.WaitUntil;
import atdd.test.shared.BaseCucumber;
import atdd.utils.*;
import cucumber.api.Scenario;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import java.lang.reflect.Constructor;
import java.util.*;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Login {

    private static final Logger log = Logger.getLogger(Login.class);

    /**
     * Persisted AbstractLogin per each user.
     */
    private static final LinkedHashMap<String, AbstractLogin> loginKeeper = new LinkedHashMap<>();
    private static final Lock loginKeeperLock = new ReentrantLock();


    /**
     * Get the context profile and login.
     *
     * @param scenario
     * @return
     */
    public static WebDriver login(Scenario scenario) throws ImmediateAbortException, LostBrowserException {
        return login(scenario, ExcelLib.completeProfile(scenario.getId(), null));
    }

    /**
     * A profile based universal login method.
     * Keep the AbstractLogin object in loginKeeper after login.
     * If the user is already logged in, return the AbstractLogin kept in loginKeeper.
     * If the AbstractLogin is no longer valid, destroy it and login again.
     * <p>
     * Before returning the WebDriver object:
     * BaseCucumber.driver will be replaced with the new WebDriver object to be returned.
     * BaseCucumber.obj will be recreated based on the new WebDriver object to be returned.
     * Any client that has a local copy of BaseCucumber.driver or BaseCucumber.obj is responsible to copy again.
     * But if your feature is having only one user, it should not be impacted.
     *
     * @param scenario
     * @param pf
     * @return
     * @throws Exception
     */
    public static WebDriver login(Scenario scenario, Map<String, String> pf) throws ImmediateAbortException, LostBrowserException {
        loginKeeperLock.lock();
        try {
            ScenarioLogger scenarioLogger = new ScenarioLogger(scenario, log);
            String userIdentifier = AbstractLogin.getUserIdentifier(scenario, pf);

            AbstractLogin login = null;
            if (null == pf) {
                login = getLastAccessedLogin(scenario);
            } else {
                if (loginKeeper.containsKey(userIdentifier)) {
                    AbstractLogin keptLogin = loginKeeper.remove(userIdentifier);
                    keptLogin.setScenario(scenario);
                    boolean isValid = new WaitUntil(
                            "Wait until browser is valid.",
                            10000, 1000, 1000,
                            new ICondition() {
                                @Override
                                public boolean evaluate() throws Exception {
                                    TestUtils.waitForAngularRequestsToFinish(keptLogin.driver());
                                    return keptLogin.isValid();
                                }
                            }
                    ).execute();
                    if (isValid) {
                        login = keptLogin;
                        // make it the last accessed login
                        loginKeeper.put(userIdentifier, keptLogin);
                    } else {
                        try {
                            BaseCucumber.closeBrowser(keptLogin.driver());
                        } catch (Exception e) {
                            // do nothing
                        }
                    }
                }
            }
            if (null != login && "Yes".equalsIgnoreCase(pf.get("forceQuit"))) {
                try {
                    BaseCucumber.closeBrowser(login.driver());
                } catch (Throwable e) {
                    // do nothing
                } finally {
                    loginKeeper.remove(userIdentifier);
                    login = null;
                }
            }

            if (null == login) {
                AbstractLogin newLogin = null;
                WebDriver driver = null;
                try {
                    String loginMethod = pf.get(MBM.USER_LOGIN_METHOD);
                    String clazz = Conf.getInstance().getProperty("loginClass" + loginMethod);
                    Constructor<?> constructor = Class.forName(clazz).getConstructor(Scenario.class, WebDriver.class);

                    Conf.getInstance().setProperty("remoteJobName", userIdentifier + "_" + loginMethod);
                    BaseCucumber.setDriver("jenkins");
                    driver = BaseCucumber.driver;

                    newLogin = (AbstractLogin) constructor.newInstance(new Object[]{scenario, driver});
                    newLogin.login(pf);
                    Assert.assertTrue(newLogin.isValid());

                } catch (LostBrowserException e) {
                    BaseCucumber.closeBrowser(driver);
                    throw e;
                } catch (Exception e) {
                    BaseCucumber.closeBrowser(driver);
                    throw new RuntimeException(userIdentifier + " login fail: " + e.getMessage());
                }
                loginKeeper.put(userIdentifier, newLogin);
                login = newLogin;
                scenarioLogger.warn("################################");
                scenarioLogger.warn("URL:");
                scenarioLogger.warn("\t" + driver.getCurrentUrl());
                scenarioLogger.warn("VERSION:");
                scenarioLogger.warn("\t" + login.getAppVersion());
                scenarioLogger.warn("################################");
                WhiteBoard.getInstance().putString(scenario.getId(), "build", login.getAppVersion());
            }

            BaseCucumber.resetPageObjects(login.driver());
            return login.driver();
        } finally {
            loginKeeperLock.unlock();
        }
    }

    /**
     * Quit all kept AbstractLogin's for specified scenario
     */
    public static void quitScenarioLogins(Scenario scenario) {
        loginKeeperLock.lock();
        try {
            ScenarioLogger scenarioLogger = new ScenarioLogger(scenario, log);
            Set<String> userIdentifierSet = new HashSet<>(1);
            for (String userIdentifier : loginKeeper.keySet()) {
                if (AbstractLogin.userIdentifierBelongsToScenario(userIdentifier, scenario)) {
                    try {
                        scenarioLogger.warn("Quiting: " + userIdentifier);
                        AbstractLogin d = loginKeeper.get(userIdentifier);
                        TestUtils.demoBreakPoint(scenario, d.driver(), "Last screenshot:");
                        BaseCucumber.closeBrowser(d.driver());
                        userIdentifierSet.add(userIdentifier);
                        scenarioLogger.warn("Quit success: ");
                    } catch (ImmediateAbortException e) {
                        scenarioLogger.warn("Last Screenshot - Scenario Failed");
                    } catch (Exception e) {
                        scenarioLogger.warn("Quit failed: " + e.getMessage());
                    }
                }
            }
            for (String s : userIdentifierSet) {
                loginKeeper.remove(s);
            }
        } finally {
            loginKeeperLock.unlock();
        }
    }

    public static AbstractLogin getLastAccessedLogin(Scenario scenario) {
        loginKeeperLock.lock();
        try {
            LinkedList<String> idList = new LinkedList<>(loginKeeper.keySet());
            ListIterator<String> it = idList.listIterator(idList.size());
            while (it.hasPrevious()) {
                String userIdentifier = it.previous();
                if (AbstractLogin.userIdentifierBelongsToScenario(userIdentifier, scenario)) {
                    return loginKeeper.get(userIdentifier);
                }
            }
            return null;
        } finally {
            loginKeeperLock.unlock();
        }
    }
}
