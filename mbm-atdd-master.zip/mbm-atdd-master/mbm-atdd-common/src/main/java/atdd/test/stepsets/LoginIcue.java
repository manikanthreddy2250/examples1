package atdd.test.stepsets;

import atdd.common.Retry;
import atdd.test.pageobjects.icue.IcueHomePage;
import atdd.test.pageobjects.icue.IcueLoginPage;
import atdd.utils.Conf;
import atdd.utils.MBM;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.Map;

class LoginIcue extends AbstractLogin {

    private String version;

    public LoginIcue(Scenario scenario, WebDriver webDriver) {
        super(scenario, webDriver);
    }

    /**
     * A profile based universal iCUE login method.
     *
     * @param pf
     */
    @Override
    public void login(Map<String, String> pf) {
        driver().get(Conf.getInstance().getProperty("IcueURL"));

        String userName = pf.get(MBM.USER_USERNAME);
        String password = pf.get(MBM.USER_PASSWORD);
        login(userName, password);
    }

    /**
     * Check if the browser is valid.
     *
     * @return
     */
    @Override
    public boolean isValid() throws LostBrowserException {
        String expectedUrl = Conf.getInstance().getProperty("IcueURL");
        return isValidBasic(expectedUrl);
    }

    /**
     * Return the application version.
     *
     * @return
     */
    @Override
    public String getAppVersion() {
        return version;
    }

    /**
     * Login ICUE system
     *
     * @param usernameId
     * @param pwd
     */
    public void login(String usernameId, String pwd) {
        IcueLoginPage icueLoginPage = new IcueLoginPage(driver());
        icueLoginPage.enterUserId(usernameId);
        icueLoginPage.enterUserPass(pwd);
        icueLoginPage.selectDomain("MS");
        TestUtils.demoBreakPoint(scenario(), driver(), "Login ICUE: " + usernameId);

        boolean ok = new Retry("login>" + usernameId) {

            @Override
            protected void tryOnce() {
                try {
                    if (TestUtils.isElementVisible(driver(), IcueLoginPage.signOn)) {
                        icueLoginPage.clickSignOn();
                        TestUtils.wait(2);
                    }
                } catch (Exception e) {
                    // do nothing to call until()
                }
            }

            @Override
            protected boolean until() {
                return TestUtils.isElementVisible(driver(), IcueHomePage.mainNav);
            }

        }.execute();

        if (!ok) {
            String note = " ICUE login with user " + usernameId + " failed: " + driver().getCurrentUrl();
            TestUtils.demoBreakPoint(scenario(), driver(), note);
            throw new RuntimeException(note);
        } else {
            TestUtils.demoBreakPoint(scenario(), driver(), "Login success.");
            String aboutXpath = "//a[.='About']";
            try {
                TestUtils.click(driver(), By.xpath(aboutXpath));
                this.version = driver().switchTo().alert().getText();
            } catch (Exception e) {
                scenarioLogger.error("Unable to read version by: " + aboutXpath);
                this.version = "UNKNOWN";
            } finally {
                try {
                    driver().switchTo().alert().dismiss();
                } catch (Exception e) {
                    // do nothing
                }
            }
        }

    }


}
