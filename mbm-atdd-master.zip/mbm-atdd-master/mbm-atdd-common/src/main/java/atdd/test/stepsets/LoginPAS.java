package atdd.test.stepsets;

import atdd.common.ICondition;
import atdd.common.Retry;
import atdd.utils.Conf;
import atdd.utils.MBM;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.Map;

class LoginPAS extends AbstractLogin {

    private String version;

    public LoginPAS(Scenario scenario, WebDriver webDriver) {
        super(scenario, webDriver);
    }

    /**
     * A profile based universal iCUE login method.
     *
     * @param pf
     */
    @Override
    public void login(Map<String, String> pf) {
        driver().get(Conf.getInstance().getProperty("pasUrl"));

        String userName = pf.get(MBM.USER_USERNAME);
        String password = pf.get(MBM.USER_PASSWORD);
        login(userName, password);
    }

    /**
     * Check if the browser is valid.
     *
     * @return
     */
    @Override
    public boolean isValid() throws LostBrowserException {
        String expectedUrl = Conf.getInstance().getProperty("pasUrl");
        return isValidBasic(expectedUrl);
    }

    /**
     * Return the application version.
     *
     * @return
     */
    @Override
    public String getAppVersion() {
        return version;
    }

    /**
     * Login ICUE system
     *
     * @param usernameId
     * @param pwd
     */
    public void login(String usernameId, String pwd) {
        Retry retry = new Retry("Regry login PAS.", new ICondition() {
            @Override
            public boolean evaluate() throws Exception {
                return TestUtils.isElementVisible(driver(), By.xpath("//label[text()='Home']"));
            }
        }) {

            @Override
            protected void tryOnce() throws Exception {
                TestUtils.input(driver(), By.id("username"), usernameId);
                TestUtils.input(driver(), By.id("password"), pwd);
                TestUtils.demoBreakPoint(scenario(), driver(), "Login PAS");
                TestUtils.click(driver(), By.xpath("//a[@title='Sign On']"));
            }
        };
        TestUtils.demoBreakPoint(scenario(), driver(), "Logged in PAS");
        this.version = driver().findElement(By.xpath("//span[contains(text(), 'apsrt')]")).getText();
    }


}
