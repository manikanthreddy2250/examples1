package atdd.test.stepsets;

import atdd.common.ImmediateAbortException;
import atdd.test.core.AbstractStepSet;
import atdd.test.pageobjects.CommonPage;
import atdd.test.pageobjects.directsso.SignInClinicalManager;
import atdd.test.pageobjects.paan.PAAN;
import atdd.utils.*;
import cucumber.api.Scenario;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.Map;

class LoginThroughPaan extends AbstractLoginMbm {

    private final static Logger log = Logger.getLogger(LoginThroughPaan.class.getName());
    private static PAAN paan = new PAAN();
    WebDriver driver1;

    public LoginThroughPaan(Scenario scenario, WebDriver webDriver) {
        super(scenario, webDriver);
        driver1 = webDriver;
    }

    /**
     * A profile based universal PAAN login method.
     *
     * @param pf
     */
    public void login(Map<String, String> pf) {
        super.login(pf);
        this.pf = pf;
        log.warn("login: pf=" + pf.toString());

        driver().get(Conf.getInstance().getProperty("PAANTestUrl"));

        TestUtils.click(driver(), By.xpath("//span[.='Sign in with Optum ID']"));
        TestUtils.wait(1);
        TestUtils.input(driver(), By.id("userNameId_input"), pf.get(MBM.USER_USERNAME));
        TestUtils.input(driver(), By.id("passwdId_input"), pf.get(MBM.USER_PASSWORD), true);
        TestUtils.demoBreakPoint(scenario(), driver(), "Login: " + pf.get(MBM.USER_TITLE) + ": " + pf.get(MBM.USER_USERNAME));
        TestUtils.click(driver(), By.id("SignIn"));
        TestUtils.wait(5);
        String title = driver().getTitle();

        log.warn("Title: " + title);
        List<WebElement> els = driver().findElements(By.id("challengeQuestionLabelId"));
        if (els.size() > 0) {
            String securityQuestion = TestUtils.text(driver(), By.id("challengeQuestionLabelId"));
            while (!knownQuestions(securityQuestion)) {
                securityQuestion = TestUtils.text(driver(), By.id("challengeQuestionLabelId"));
            }
            TestUtils.click(driver(), By.id("authQuesSubmitButton"));
        }
        TestUtils.wait(10);
        if (!driver().getTitle().trim().equals("Link")) {
            TestUtils.demoBreakPoint(scenario(), driver(), "User is not on LINK Dashboard. Navigating to the Link dashboard.");
            TestUtils.click(driver(), PAAN.menuCollapsed);
            TestUtils.wait(4);
            TestUtils.click(driver(), PAAN.linkChoice);
        }
        TestUtils.click(driver(), By.xpath(Conf.getInstance().getProperty("paanLink")));
        TestUtils.wait(10);
        TestUtils.wait(30);

        //TestUtils.switchToNewWindow(driver());
        TestUtils.switchToLatestWindow(driver());
        if (driver().getTitle().equals("Certificate Error: Navigation Blocked")) {
            TestUtils.wait(20);
            driver().navigate().to("javascript:document.getElementById('overridelink').click()");
        } else {
            log.warn("User is not using IE");
        }
        if(TestUtils.isElementVisible(driver(),By.xpath("//button[contains(text(),'Advanced')]"))) {
            TestUtils.click(driver(),By.xpath("//button[contains(text(),'Advanced')]"));
            TestUtils.click(driver(),By.xpath("//a[contains(text(),'Proceed to acdalpha.uhc.com (unsafe)')]"));
        }
        TestUtils.demoBreakPoint(scenario(), driver(), "Inside PAAN application");


        String ppTitle = pf.get(MBM.PP_TITLE);
        if (StringUtils.isEmpty(ppTitle)) {
            // do nothing
        } else {
            String ppType = pf.get(MBM.PP_TYPE);
            if (StringUtils.isEmpty(ppTitle)) {
                // do nothing
            } else {
                switch (pf.get(MBM.PP_TYPE)) {
                    case ExcelLib.PP_TYPE_PHYSICIAN:
                        String changeToProviderFirstName = pf.get(MBM.PP_FIRST_NAME);
                        String changeToProviderLastName = pf.get(MBM.PP_LAST_NAME);
                        String businessName =  TestUtils.text(driver(),By.xpath("//input[@id='businessName']//.."));
                        String tinID =  TestUtils.text(driver(),By.xpath("//input[@id='federalTaxID']//..\n"));
                        String changeToBusinessName  = pf.get(MBM.PP_CORPORATE_TAX_ID_OWNER);
                        String changeToTinID = pf.get(MBM.PP_TIN);
                        if (StringUtils.isEmpty(changeToProviderFirstName) || StringUtils.isEmpty(changeToProviderLastName)) {
                            // do nothing

                            if (!(changeToBusinessName.equals(businessName)))

                            {
                                if (isEditingPP())
                                    TestUtils.click(driver(), By.id("selectdiffprovider"));
                                TestUtils.wait(5);

                                TestUtils.click(driver(), By.id("name"));
                                TestUtils.wait(5);
                                TestUtils.select(driver(), By.id("name"), pf.get(MBM.PP_CORPORATE_TAX_ID_OWNER));
                                TestUtils.wait(5);
                                TestUtils.waitElementVisible(driver(), By.id("continueButton"));
                                TestUtils.wait(10);
                                TestUtils.click(driver(), By.id("continueButton"));
                                TestUtils.wait(20);

                            }

                        } else {

                            By fnBy = By.xpath("//td[contains(., '" + changeToProviderFirstName + "')]");
                            By lnBy = By.xpath("//td[contains(., '" + changeToProviderLastName + "')]");
                            if (TestUtils.isElementVisible(driver(), fnBy) && TestUtils.isElementVisible(driver(), lnBy)) {
                                if (isEditingPP()) {
                                    // do nothing
                                } else {
                                    TestUtils.click(driver(), By.id("continueButton"));
                                    TestUtils.wait(5);
                                }
                            } else {
                                if (isEditingPP()) {
                                    TestUtils.click(driver(), By.id("selectdiffprovider"));
                                    TestUtils.wait(15);
                                }
                                TestUtils.select(driver(), By.id("name"), pf.get(MBM.PP_CORPORATE_TAX_ID_OWNER));
                                TestUtils.wait(10);
                                TestUtils.select(driver(), By.id("tin"), pf.get(MBM.PP_TIN));
                                String careProvider = pf.get(MBM.PP_CARE_PROVIDER);
                                //String careProvider = pf.get("ppFirstName")+", "+pf.get("ppLastName");
                                TestUtils.select(driver(), By.id("providers"), careProvider.toUpperCase());
                                TestUtils.demoBreakPoint(scenario(), driver(), "Change PAAN provider: " + careProvider);
                                TestUtils.click(driver(), By.id("continueButton"));
                                TestUtils.wait(5);
                            }
                        }
                        break;
                    case ExcelLib.PP_TYPE_FACILITY:
                        //TODO
                        break;
                    default:
                        throw new RuntimeException("Invalid PAAN Provider type: " + pf.get(MBM.PP_TYPE));
                }
            }
        }
        if (driver().getTitle().equals("Certificate Error: Navigation Blocked")) {
            TestUtils.wait(20);
            driver().navigate().to("javascript:document.getElementById('overridelink').click()");
        } else {
            log.warn("User is not using IE");
        }
        //changed
        String ppChemoServiceType = pf.get(MBM.PP_CHEMO_SERVICE_TYPE);
        if(StringUtils.isEmpty(ppChemoServiceType)){
            TestUtils.waitElementVisible(driver(), By.xpath("//a[@id='submisionAndStausForSPT']/u"));
            TestUtils.wait(3);
            TestUtils.click(driver(), By.xpath("//a[@id='submisionAndStausForSPT']/u"));
            String oldWindowHandle = TestUtils.switchToLatestWindow(driver());
            //TestUtils.demoBreakPoint(scenario(), driver(), "Change PAAN provider: " );
            TestUtils.wait(30);
        }
        else {
            TestUtils.waitElementVisible(driver(), By.xpath("//a[@id='submisionAndStaus']/u"));
            TestUtils.click(driver(), By.xpath("//a[@id='submisionAndStaus']/u"));
            //String oldWindowHandle = TestUtils.switchToNewWindow(driver());
            String oldWindowHandle = TestUtils.switchToLatestWindow(driver());
            TestUtils.wait(30);
        }
        if (driver().getTitle().equals("Certificate Error: Navigation Blocked")) {
            TestUtils.wait(20);
            driver().navigate().to("javascript:document.getElementById('overridelink').click()");
        } else {
            log.warn("User is not using IE");
        }

        if (StringUtils.isEmpty(ppChemoServiceType) ) {
           /* TestUtils.select(driver(), By.id("chemoServiceType"), "Oncology");
            TestUtils.wait(3);
            TestUtils.select(driver(), By.id("memberProductType"), "Medicaid");
            TestUtils.wait(3);
            TestUtils.select(driver(), By.id("state"), "FLORIDA");
            */

            TestUtils.click(driver(), By.id("specltPharmTransType"));
            TestUtils.wait(3);
            TestUtils.select(driver(),By.id("specltPharmTransType"), pf.get(MBM.PP_SPECIALTY_TRANSACTION_TYPE));
            TestUtils.wait(3);
            TestUtils.click(driver(), By.id("mbmMemberProductType"));
            TestUtils.wait(3);
            TestUtils.select(driver(),By.id("mbmMemberProductType"), pf.get(MBM.PP_MEMBER_PRODUCT_TYPE));
            TestUtils.wait(3);
            TestUtils.click(driver(), By.id("drugClass"));
            TestUtils.wait(3);
            TestUtils.select(driver(),By.id("drugClass"), pf.get(MBM.PP_SPECIALTY_DRUG_CLASS));
            TestUtils.wait(3);

        } else {
            TestUtils.click(driver(), By.id("chemoServiceType"));
            TestUtils.wait(3);
            TestUtils.select(driver(), By.id("chemoServiceType"), pf.get(MBM.PP_CHEMO_SERVICE_TYPE));
            TestUtils.wait(3);
            TestUtils.click(driver(), By.id("memberProductType"));
            TestUtils.wait(5);
            TestUtils.select(driver(), By.id("memberProductType"), pf.get(MBM.PP_MEMBER_PRODUCT_TYPE));
            TestUtils.wait(3);
            if (ExcelLib.PP_MEMBER_PRODUCT_TYPE_MEDICAID.equals(pf.get(MBM.PP_MEMBER_PRODUCT_TYPE))) {
                Assert.assertTrue(pf.containsKey(MBM.PP_STATE));
                TestUtils.select(driver(), By.id("state"), pf.get(MBM.PP_STATE));
                TestUtils.wait(3);
            }
        }
        TestUtils.demoBreakPoint(scenario(), driver(), "About to redirect to MBM");
        TestUtils.click(driver(), By.id("continueRedirect"));

        // TestUtils.swithToOldWindow(driver1, oldWindowHandle);
        AbstractStepSet a = new AbstractStepSet(scenario(), driver1);

        TestUtils.swithToWindow(driver(), "mbmnow");

        MbmUtils.immediateRecover(driver());

        SignInClinicalManager signinclinicalManager = new SignInClinicalManager(driver());
        this.version = signinclinicalManager.getVersion();
        log.warn("login: success");
    }


    private boolean knownQuestions(String securityQuestion) {
        log.warn(securityQuestion);
        switch (securityQuestion) {
            case "What is your favorite color?":
                TestUtils.input(driver(), By.xpath("//input[contains(@id, 'userAnswer')]"), pf.get(MBM.USER_FAVORITE_COLOR));
                break;
            case "What was your first phone number?":
                TestUtils.input(driver(), By.xpath("//input[contains(@id, 'userAnswer')]"), pf.get(MBM.USER_FIRST_PHONE_NUMBER));
                break;
            case "What is your best friend's name?":
                TestUtils.input(driver(), By.xpath("//input[contains(@id, 'userAnswer')]"), pf.get(MBM.USER_BEST_FRIEND));
                break;
            case "Who is your favorite sports team?":
                TestUtils.input(driver(), By.xpath("//input[contains(@id, 'userAnswer')]"), pf.get(MBM.USER_FAVORITE_SPORTS_TEAM));
                break;
            case "What is the name of your first pet?":
                TestUtils.input(driver(), By.xpath("//input[contains(@id, 'userAnswer')]"), pf.get(MBM.USER_FIRST_PET));
                break;
            default:
                TestUtils.input(driver(), By.xpath("//input[contains(@id, 'userAnswer')]"), "xxxx");
                TestUtils.click(driver(), By.id("authQuesSubmitButton"));
                return false;
        }
        return true;
    }

    private boolean isEditingPP() {
        return "true".equals(TestUtils.js(driver(),
                "try { return document.getElementById('selectdiffprovider').offsetWidth > 0 && " +
                        "document.getElementById('selectdiffprovider').offsetHeight > 0; " +
                        "} catch (err) { return false; }"));
    }

    @Override
    public boolean isValid() throws LostBrowserException {
        try {
            String url = null;
            try {
                url = driver().getCurrentUrl();
                if (null == url) {
                    throw new LostBrowserException("Missing url.");
                }
                if (url.contains("signoff")) {
                    throw new LostBrowserException("Signed off.");
                }
                if (url.contains("login")) {
                    throw new LostBrowserException("Invalid username or password.");
                }
                if (url.contains("permission-denied")) {
                    throw new LostBrowserException("Permission denied.");
                }
            } catch (Exception e) {
                throw new LostBrowserException(e.getMessage());
            }
            String host = Conf.getInstance().getProperty(Conf.TEST_HOST_KEY);
            if (!url.startsWith(host)) {
                return false;
            }
            SignInClinicalManager signinclinicalManager = new SignInClinicalManager(driver());
            String newVersion = signinclinicalManager.getVersion();
            if (!StringUtils.isEmpty(newVersion) && newVersion.equals(version)) {
                this.version = newVersion;
                return true;
            } else {
                if (new CommonPage(driver()).verifyHeader("Permission Denied")) {
                    return true;
                } else {
                    throw new ImmediateAbortException("\nExpected Version: " + version + "\nActual Version: " + newVersion);
                }
            }
        } catch (LostBrowserException e) {
            throw e;
        } catch (Exception e) {
            return false;
        }
    }

}

