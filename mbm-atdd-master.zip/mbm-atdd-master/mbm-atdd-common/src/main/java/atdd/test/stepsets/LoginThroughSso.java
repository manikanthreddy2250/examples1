package atdd.test.stepsets;

import atdd.test.pageobjects.directsso.SignInClinicalManager;
import atdd.utils.*;
import cucumber.api.Scenario;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import java.util.Map;

class LoginThroughSso extends AbstractLoginMbm {

    private final static Logger log = Logger.getLogger(AbstractLoginMbm.class.getName());

    public LoginThroughSso(Scenario scenario, WebDriver webDriver) {
        super(scenario, webDriver);
    }

    /**
     * A profile based universal SSO login method.
     *
     * @param pf
     */
    @Override
    public void login(Map<String, String> pf) {
        super.login(pf);
        this.pf = pf;
        driver().get(this.getUrl());

        String userName = pf.get(MBM.USER_USERNAME);
        String password = pf.get(MBM.USER_PASSWORD);
        login(userName, password);
    }

    /**
     * SSO login method.
     *
     * @param usernameId
     * @param pwd
     */
    private void login(String usernameId, String pwd) {
        SignInClinicalManager signinclinicalManager = new SignInClinicalManager(driver());
        signinclinicalManager.enterUserId(usernameId);
        signinclinicalManager.enterUserPass(pwd);
        TestUtils.demoBreakPoint(scenario(), driver(), "Login: " + usernameId);
        signinclinicalManager.clickSignInLoginPage();
        TestUtils.wait(3);
        MbmUtils.immediateRecover(driver());
        this.version = signinclinicalManager.getVersion();
    }

    /**
     * Calculate the login url
     *
     * @return
     */
    private String getUrl() {
        String endpoint = pf.get(Conf.TEST_ENDPOINT_KEY);
        if (StringUtils.isEmpty(endpoint)) {
            endpoint = Conf.getInstance().getProperty(Conf.TEST_ENDPOINT_KEY);
        }
        return Conf.getInstance().getProperty(Conf.TEST_HOST_KEY) + endpoint;
    }

}
