package atdd.test.stepsets;

import atdd.test.pageobjects.directsso.SignInClinicalManager;
import atdd.utils.*;
import cucumber.api.Scenario;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.io.IOException;
import java.util.Map;

class LoginThroughTestHarness extends AbstractLoginMbm {

    private final static Logger log = Logger.getLogger(LoginThroughTestHarness.class.getName());
    private final Map<String, String> testHarnessParams;

    public LoginThroughTestHarness(Scenario scenario, WebDriver webDriver) throws IOException {
        super(scenario, webDriver);
        this.testHarnessParams = QuickJson.readMap(Conf.getInstance().getProperty("testHarnessParams"));
    }

    /**
     * A profile based universal SSO login method.
     *
     * @param pf
     */
    @Override
    public void login(Map<String, String> pf) {
        super.login(pf);
        this.pf = pf;
        driver().get(this.getUrl());

        for (String key : this.testHarnessParams.keySet()) {
            By by = By.xpath("(//td[contains(text(), '" + key + "')]/following-sibling::td[1]/*)[1]");
            String value = this.testHarnessParams.get(key);
            value = WhiteBoard.resolve(getOwner(), value);
            TestUtils.input(driver(), by, value);
        }

        TestUtils.demoBreakPoint(scenario(), driver(), "Login: Test Harness");

        SignInClinicalManager signinclinicalManager = new SignInClinicalManager(this.driver());
        TestUtils.click(driver(), By.xpath("//input[@value='Submit']"));
        MbmUtils.immediateRecover(driver());
        this.version = signinclinicalManager.getVersion();
    }


    /**
     * Calculate the login url
     *
     * @return
     */
    private String getUrl() {
        return Conf.getInstance().getProperty("testHarnessUrl");
    }

}
