package atdd.test.stepsets;

public class LostBrowserException extends Exception {
    public LostBrowserException(String msg) {
        super(msg);
    }
}
