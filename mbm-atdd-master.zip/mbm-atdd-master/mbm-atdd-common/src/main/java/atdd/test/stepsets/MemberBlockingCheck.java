package atdd.test.stepsets;


import atdd.test.core.AbstractStepSet;
import atdd.test.pageobjects.CommonPageObject;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.openqa.selenium.WebDriver;

public class MemberBlockingCheck extends AbstractStepSet {

    public MemberBlockingCheck(Scenario scenario, WebDriver webDriver) {
        super(scenario, webDriver);
    }

    private CommonPageObject obj() {
        return new CommonPageObject(scenario(), driver());
    }

    public static final String AUTH_NOT_REQUIRED = "An authorization is not required for this member based on the member’s health plan and/or authorization type." +
            "\n" +
            "Please contact the number on the back of the member's insurance card for additional questions.";

    public static final String EXPIRED_MEMBER_COVERAGE = "Member's Coverage End Date is earlier than today's date. Select Continue to create an authorization with a backdated start date or select Cancel to select another member.";

    public static final String SELF_ADMIN_EXCEPTION = "We’re sorry, but an authorization for the selected self-administered drug will not be processed as it may be covered under the member's pharmacy benefit rather than medical benefit.";

    public static final String RADONC_AUTH_NOT_REQUIRED = "An authorization is not required for this member based on the member's health plan. Please contact the number on the back of the member's insurance card for additional questions.";
    /**
     * Assumption: Global Message Member blocking Popup page is displayed.
     * Validate the message is as expected.
     *
     * @return
     */
    public boolean authNotRequired() {
        TestUtils.demoBreakPoint(scenario(), driver(), "Dup popup check");
        String expectedMessage = String.format(AUTH_NOT_REQUIRED);
        String actualMessage = obj().NavigationPage.getGlobalMessage();
        TestUtils.wait(1);
        return expectedMessage.equals(actualMessage);
    }

    public boolean expiredMemberCoverage() {
        TestUtils.demoBreakPoint(scenario(), driver(), "Expired Menber");
        String expectedMessage = String.format(EXPIRED_MEMBER_COVERAGE);
        String actualMessage = obj().NavigationPage.getExpiredMemberCoverage();
        TestUtils.wait(1);
        return expectedMessage.equals(actualMessage);
    }

    public boolean Selfadministereddrug() {
        TestUtils.demoBreakPoint(scenario(), driver(), "Selfadmin check");
        String expectedMessage = String.format(SELF_ADMIN_EXCEPTION);
        String actualMessage = obj().NavigationPage.getSelfadminException();
        TestUtils.wait(1);
        return expectedMessage.equals(actualMessage);
    }
    public boolean RadOncAuthNotRequired() {
        TestUtils.demoBreakPoint(scenario(), driver(), "Dup popup check");
        String expectedMessage = String.format(RADONC_AUTH_NOT_REQUIRED);
        String actualMessage = obj().NavigationPage.getGlobalMessage();
        TestUtils.wait(1);
        return expectedMessage.equals(actualMessage);
    }

}
