package atdd.test.stepsets;

import atdd.test.core.AbstractStepSet;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.pageobjects.NavigationPage;
import atdd.test.pageobjects.newlyApprovedDrugs.AddNewDrugPage;
import atdd.test.pageobjects.newlyApprovedDrugs.NewlyApprovedDrugsPage;
import atdd.utils.InvalidSearchCriteriaException;
import cucumber.api.Scenario;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import java.util.List;
import java.util.Map;

public class NewlyApprovedDrugs extends AbstractStepSet {
    private CommonPageObject obj() {
        return new CommonPageObject(scenario(), driver());
    }

    private NavigationPage np = obj().NavigationPage;
    private NewlyApprovedDrugsPage nadp = obj().NewlyApprovedDrugsPage;
    private AddNewDrugPage andp = obj().AddNewDrugPage;

    public NewlyApprovedDrugs(Scenario scenario, WebDriver webDriver) {
        super(scenario, webDriver);
    }

    /*
     Assumption: User already logged in and navigates to Newly Approved Drug
    * and verifies the new added column
    * the provided details
    *
    * @param expectedHeader
     */
    public void validatePaginationHeader(List expectedHeader) {
        if (!driver().getTitle().contains("Newly Approved Drugs")) {
            obj().NavigationPage.navigatesToMenuItem("Tools>Procedures>Newly Approved Drugs");
            obj().CommonPage.waitForNOTBusyIndicator();
        }
        nadp.validateTableHeader(expectedHeader);
    }

    /*
     * Assumption: User verifies when the record is saved the data will
     * be saved to the Newly Approved Drug table NEW_PROC
     * @param newproc
     * */

    public void validateTheRecordsSavedtoDB(Map<String, Object> newproc){

        if (!driver().getTitle().contains("Newly Approved Drugs")) {
            obj().NavigationPage.navigatesToMenuItem("Tools>Procedures>Newly Approved Drugs");
            obj().CommonPage.waitForNOTBusyIndicator();
        }

        List<String> webelemnt= nadp.getValuesinTable();

        System.out.println(newproc.get("new_proc_id").toString());
        String[] result = newproc.get("aprv_dt").toString().split("-");
        String Date = result[1] + "-" + result[2] + "-" + result[0];
        System.out.println(Date);

        Assert.assertTrue("proc_nm in DB doesn't match with BrandName", webelemnt.get(0).equalsIgnoreCase(newproc.get("proc_nm").toString()));
        Assert.assertEquals("1",newproc.get("auth_typ_id").toString() );
        Assert.assertEquals("1", newproc.get("cstm_trt_aprv_typ_id").toString());
        Assert.assertTrue("aprv_dt in DB doesn't match with FDA Approval Date", webelemnt.get(5).equalsIgnoreCase(Date));

    }


    /*
     Assumption: User already logged in and navigates to Newly Approved Drug
    * and verifies the default selected values for search fields
    *
    * @param label
     */

    public void validateSearchFieldInNewlyApprovedDrugScreen(List label){
        if (!driver().getTitle().contains("Newly Approved Drugs")) {
            obj().NavigationPage.navigatesToMenuItem("Tools>Procedures>Newly Approved Drugs");
            obj().CommonPage.waitForNOTBusyIndicator();
        }
        nadp.validateLabelValues(label);
        nadp.validateDefaultValuesForAuthType();
        nadp.validateDefaultValuesForPayer();

    }

    public void validateDropdownOptionsInNewlyApprovedDrugScreen(String arg1, List label){
        if (!driver().getTitle().contains("Newly Approved Drugs")) {
            obj().NavigationPage.navigatesToMenuItem("Tools>Procedures>Newly Approved Drugs");
            obj().CommonPage.waitForNOTBusyIndicator();
        }

        nadp.validateDrpdwnOptnsInNewlyApprovedDrugScreen(arg1 ,label);
    }

    /*
     * Assumption: user clicks on Add New Drug Hyperlink in Newly Approved Drugs
     * and enter all the mandatory fields and clicks on Save
     * @param map
     * */
    public void addNewDrug(Map<String, String> map) {
        if (!driver().getTitle().contains("Newly Approved Drugs")) {
            obj().NavigationPage.navigatesToMenuItem("Tools>Procedures>Newly Approved Drugs");
            obj().CommonPage.waitForNOTBusyIndicator();
        }

        nadp.clickOnAddNewDrug();
        andp.enterTheBrandNameonAddNewDrugPopUp(map.get("Brand Name"));
        andp.enterDrugRouteOnAddNewDrugPopUp(map.get("Drug Route"));
        andp.selectAuthTypeOnAddNewDrugPopUp(map.get("Authorization Type"));
        andp.selectpayerOnAddNewDrugPopUp(map.get("Payer"));
        andp.selectFDAapprovalDateOnAddNewDrugPopUp(map.get("Approve Date"));
        andp.clickSaveButton();
    }


    /**
     * Assumption: Admin user login and Dashboard page is displayed.
     * Search Traversals according to the criteria.
     *
     * @param map

     */
    public void search(Map<String, String> map) throws InvalidSearchCriteriaException {
        if (!driver().getTitle().contains("Newly Approved Drugs")) {
            obj().NavigationPage.navigatesToMenuItem("Tools>Procedures>Newly Approved Drugs");
            obj().CommonPage.waitForNOTBusyIndicator();
        }

        nadp.enterBrandNameOnNewlyApprovedDrugSearchCriteria(map.get("Brand Name"));
        nadp.enterDrugRouteOnNewlyApprovedDrugSearchCriteria(map.get("Drug Route"));
        nadp.selectAuthTypeOnNewlyApprovedDrugSearchCriteria(map.get("Authorization Type"));
        nadp.selectpayerOnNewlyApprovedDrugSearchCriteria(map.get("Payer"));

        nadp.clickSearchButton();


    }

    /**
     * Assumption: Admin user login and Dashboard page is displayed.
     * Navigates to Newly Approved Drugs and verify the fields position
     * in the Add New Drug Pop-up screen
     *
     * @param label

     */

    public void fieldValidation(List<String> label) {
        if (!driver().getTitle().contains("Newly Approved Drugs")) {
            obj().NavigationPage.navigatesToMenuItem("Tools>Procedures>Newly Approved Drugs");
            obj().CommonPage.waitForNOTBusyIndicator();
        }
        nadp.clickOnAddNewDrug();
        andp.verifyFieldLocation(label);

    }

    /*
    User Validate the Error message displayed on Add New Drug Popup modal when
    user clicks on save w/o entering mandatory fields
     */

    public void navigatetoAddNewDrugPopUpValidateErrorMsg(Map<String, String> map) {
        if (!driver().getTitle().contains("Newly Approved Drugs")) {
            obj().NavigationPage.navigatesToMenuItem("Tools>Procedures>Newly Approved Drugs");
            obj().CommonPage.waitForNOTBusyIndicator();
        }
        nadp.clickOnAddNewDrug();
        andp.enterTheBrandNameonAddNewDrugPopUp(map.get("Brand Name"));
        andp.enterDrugRouteOnAddNewDrugPopUp(map.get("Drug Route"));
        andp.selectFDAapprovalDateOnAddNewDrugPopUp(map.get("Approve Date"));
        andp.clickSaveButton();
        andp.validateErrorMessage(map.get("Add Error"));

    }

    /*
    verify records in not saved and displayed when
    user clicks on save w/o entering mandatory fields
     */

    public void VerifyResultGrid(Map<String, String> map) throws InvalidSearchCriteriaException {
        if (!driver().getTitle().contains("Newly Approved Drugs")) {
            obj().NavigationPage.navigatesToMenuItem("Tools>Procedures>Newly Approved Drugs");
            obj().CommonPage.waitForNOTBusyIndicator();
        }
        andp.closeAddNewDrugModal();
        nadp.enterBrandNameOnNewlyApprovedDrugSearchCriteria(map.get("Brand Name"));
        nadp.clickSearchButton();
        nadp.NoRecordsFound();


    }
}
