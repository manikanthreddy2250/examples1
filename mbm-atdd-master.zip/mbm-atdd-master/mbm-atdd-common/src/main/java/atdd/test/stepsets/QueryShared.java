package atdd.test.stepsets;

import atdd.common.QueryBase;
import atdd.common.QueryExpression;
import atdd.test.core.AbstractStepSet;
import atdd.utils.*;
import cucumber.api.DataTable;
import cucumber.api.Scenario;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.Assert;

import java.io.Reader;
import java.io.StringReader;
import java.util.List;
import java.util.Map;

public class QueryShared extends AbstractStepSet {
    public QueryShared(Scenario scenario) {
        super(scenario, null);
    }

    public void isExecutedInDatabase(String sqlOrFileName0OrMyBatisSqlIdWithParams0, String sqlSessionFactoryClassName0) {
        String sqlOrFileName0OrMyBatisSqlIdWithParams1 = WhiteBoard.resolve(getOwner(), sqlOrFileName0OrMyBatisSqlIdWithParams0);
        String sqlOrMyBatisSqlIdWithParams0 = StringUtils.readOrReturn(sqlOrFileName0OrMyBatisSqlIdWithParams1);
        String sqlOrMyBatisSqlIdWithParams1 = WhiteBoard.resolve(getOwner(), sqlOrMyBatisSqlIdWithParams0);

        String sqlSessionFactoryClassName1 = WhiteBoard.resolve(getOwner(), sqlSessionFactoryClassName0);
        SqlSessionFactory sqlSessionFactory = MyBatisUtils.getSqlSessionFactory(sqlSessionFactoryClassName1);

        if (sqlOrMyBatisSqlIdWithParams1.startsWith("mybatis")) {
            try (SqlSession sqlSession = sqlSessionFactory.openSession(true)) {
                String myBatisSqlIdWithParams = sqlOrMyBatisSqlIdWithParams1;
                String[] p = myBatisSqlIdWithParams.split("\\s+", 3);
                String sqlId = p[1];
                String paramString = (3 == p.length ? p[2] : null);
                if (null == paramString) {
                    // no parameters
                    sqlSession.update(sqlId);
                } else {
                    if (paramString.contains("=")) {
                        // hashmap parameters
                        Map<String, String> params = DataTableUtils.asMap(paramString);
                        sqlSession.update(sqlId, params);
                    } else {
                        // single string parameter
                        sqlSession.update(sqlId, paramString);
                    }
                }
            } catch (Exception e) {
                Assert.fail("Execution fail: " + sqlOrMyBatisSqlIdWithParams1 + "\r\n" + e.getMessage());
            }
        } else {
            String sql = sqlOrMyBatisSqlIdWithParams1;
            Reader reader = new StringReader(sql);
            MyBatisUtils.execute(sqlSessionFactory, reader, true, true);
        }

    }

    public void isExtractedFromWithQuery(String varName, String sourceString, String queryExpression) {
        varName = WhiteBoard.resolve(getOwner(), varName);
        sourceString = WhiteBoard.resolve(getOwner(), sourceString);
        queryExpression = WhiteBoard.resolve(getOwner(), queryExpression);
        logger.debug("varName=" + varName);
        logger.debug("sourceString=" + sourceString);
        logger.debug("queryExpression=" + queryExpression);

        QueryExpression qe = new QueryExpression(queryExpression);

        QueryBase q = qe.compile(sourceString);
        Object result = q.query(qe.getQuery());

        if (result instanceof List) {
            List<Object> objList = null;
            List<Map<String, Object>> mapList = null;
            try {
                objList = (List<Object>) result;
            } catch (Exception e) {
                Assert.fail("Unknown type in list: " + result);
            }
            try {
                mapList = (List<Map<String, Object>>) result;
            } catch (Exception e) {
                // do nothing
            }

            if (null == mapList) {
                if (1 == objList.size()) {
                    String s = objList.get(0).toString();
                    WhiteBoard.getInstance().putString(getOwner(), varName, s);
                    scenarioLogger.warn("Value extracted:" + s);
                } else {
                    List<String> strList = DataTableUtils.asListOfStrings(objList);
                    WhiteBoard.getInstance().putList(getOwner(), varName, strList);
                    try {
                        logger.debug(varName + "_rows=" + WhiteBoard.getInstance().getString(getOwner(), varName + "_rows"));
                        scenarioLogger.warn("Value extracted:" + strList);
                    } catch (Throwable e) {
                        logger.debug("log error");
                    }
                }
            } else {
                List<Map<String, String>> stringMapList = DataTableUtils.asMapsOfStrings(mapList);
                Map<String, Map<String, String>> indexedMaps = DataTableUtils.dataTableAsMapsIndexedByKeyHeader(DataTableUtils.INDEX_ROW_NUMBER, stringMapList);
                WhiteBoard.storeMaps(getOwner(), varName, Conf.getOutputPath(), indexedMaps);
                try {
                    logger.debug(varName + "_rows=" + WhiteBoard.getInstance().getString(getOwner(), varName + "_rows"));
                    String dtString = DataTable.create(stringMapList).toString();
                    scenarioLogger.warn("Value extracted:\r" + dtString);
                } catch (Throwable e) {
                    logger.debug("log error");
                }
            }
        } else {
            String s = null == result ? "" : StringUtils.peel(result.toString());
            WhiteBoard.getInstance().putString(getOwner(), varName, s);
            scenarioLogger.warn("Value extracted:" + s);
        }
    }
}
