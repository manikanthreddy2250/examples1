package atdd.test.stepsets;

import atdd.test.core.AbstractStepSet;
import atdd.test.pageobjects.authorization.RequestStatusPage;
import cucumber.api.Scenario;
import org.openqa.selenium.WebDriver;

import java.util.LinkedHashMap;
import java.util.Map;

public class RequestStatus extends AbstractStepSet {

    public RequestStatus(Scenario scenario, WebDriver webDriver) {
        super(scenario, webDriver);
    }

    /**
     * Assumption: Request Status page is displayed.
     * Extract Traversal related information from Request Status page.
     *
     * @return
     */
    public Map<String, String> extractTheTraversal() {
        RequestStatusPage rsp = new RequestStatusPage(driver());
        Map<String, String> object = new LinkedHashMap<>();
        object.put("cancerType", rsp.getCancerType());
        object.put("duration", rsp.getAuthorizationDuration());
        object.put("calculatedDuration", rsp.getCalculatedAuthorizationDuration());
        // TODO:
        // object.put("stage", rsp.getStage());
        // object.put("histology", rsp.getHistology());
        // object.put("diseaseStatus", rsp.getDeseaseStatus());
        // object.put("lineOfTherapy", rsp.getLineOfTherapy());
        // object.put("msiMmr", rsp.getMsiMmr());
        return object;
    }
}
