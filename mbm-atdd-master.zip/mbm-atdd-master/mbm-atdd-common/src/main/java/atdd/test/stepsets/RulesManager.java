package atdd.test.stepsets;

import atdd.test.core.AbstractStepSet;
import atdd.test.core.SearchCriteria;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.pageobjects.NavigationPage;
import atdd.test.pageobjects.rulesManger.RulesManagerPage;
import atdd.utils.InvalidSearchCriteriaException;
import atdd.utils.TestUtils;
import cucumber.api.DataTable;
import cucumber.api.Scenario;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.Map;

public class RulesManager extends AbstractStepSet {
    public static final By deleteRecord = By.xpath("//span[contains (@class, 'cux-icon-trash_delete oui-ttip ng-scope')]");
    public static final By deleteButton = By.xpath("//input[contains (@ng-click, 'deleteRulesManagerSheet(record)')]");
    public static final By clickPublishChangesLink = By.xpath("//a[@ng-click='publishDraftPopup()']");
    public static By publishButton = By.xpath("//input[@ng-click ='publishRuleChanges()']");
    public static By cancelPublishbtn = By.xpath(("//*[@id=\"cancelButton\"]"));
    public static By buyAndBillLabel = By.xpath("//label[contains(.,'Buy and Bill, required.')]");
    public static By buyAndBillErrorMsg = By.xpath("//div[contains(@class,'oui-pmsg-warning-body buy-and-bill-warning')]");
    public static By cloneContinue = By.xpath("//input[contains(@id,'cloneContinue')]");
    private NavigationPage np = new NavigationPage(driver());
    private RulesManagerPage rmp = new RulesManagerPage(driver());

    public static By cancelDraftLink = By.xpath("//*[@id=\"rulesTableID-container\"]/div[1]/div[1]/span[2]/a[1]");
    public static By clearChanges = By.xpath("//*[@id=\"cancelBtn\"]");
    public static By continueAuto = By.className("tk-btn ");

    /** The XPath of the form which contains text fields in order to use filter functionality. */
    public static final String filterResultsFormXpath = "//form[@name='rulesTableFormtableFilters']/table";

    /** Variable reference to the URL endpoint for the Rules Manager page. */
    private final String rulesManagerUrlEndpoint = "rulesManager";

    /**
     * The XPaths for navigation to the Preferred Procedures page
     */
    private final By prefProcParentLink = By.xpath("(//a[contains(text(),'Preferred Procedures')])[1]");
    private final By prefProcChildLink = By.xpath("//*[@id=\"content-wrapper\"]/div[1]/ul/li[3]/ul/li/a");

    public RulesManager(Scenario scenario, WebDriver webDriver) {
        super(scenario, webDriver);

    }

    private CommonPageObject obj() {
        return new CommonPageObject(scenario(), driver());
    }

    /*
    Assumption: User already logged in and navigates to Member Exceptions page
   * and verifies the columns and
   * the provided details
   *
   * @param expectedHeader
    */
    public void validatePaginationHeader(List expectedHeader) {
        rmp.validateTableHeader(expectedHeader);
    }



    /*Checks member existence for subscriberID*/

    public boolean isMemberExistsForSubscriberID(String subscriberID) {
        boolean isDataExists = false;
        rmp.enterSubscriberIDOnMemberExceptionsSearchCriteria(subscriberID);
        rmp.clickSearchButton();
        isDataExists = rmp.isDataExistsInGrid();
        return isDataExists;
    }

    /**
     * Assumption: Admin user login and Dashboard page is displayed.
     * Search Member Exception according to the criteria.
     *
     * @param map
     */
    public void search(Map<String, String> map) throws InvalidSearchCriteriaException {
        if (!driver().getTitle().contains("Rules Manager")) {
            obj().NavigationPage.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
            obj().CommonPage.waitForNOTBusyIndicator();
        }

        rmp.selectLastNameOnMemberExceptionSearchCriteria(map.get("Last Name"));
        rmp.selectFirstNameOnMemberExceptionSearchCriteria(map.get("First Name"));
        rmp.selectDateOfBirthOnMemberExceptionSearchCriteria(map.get("Date of Birth"));
        rmp.enterSubscriberIDOnMemberExceptionsSearchCriteria(map.get("Subscriber ID"));
        rmp.clickSearchButton();

    }

    /**
     * Assumption: Admin user login and Dashboard page is displayed.
     * Search Member Exception according to the criteria.
     * verifies result Grid stores values correctly against DB
     *
     * @param map
     */
    public void validateAgainstDB(Map<String, String> map) throws InvalidSearchCriteriaException {
        search(map);
        rmp.VerifyRecordsDisplayedCorrectlyAgainstDB(map);
    }

    /**
     * Assumption: Admin user login and Dashboard page is displayed.
     * Search Member Exception according to the criteria.
     * verifies result Grid stores values correctly and verifies the sort order
     *
     * @param map
     */
    public void validatewithUI(Map<String, String> map) throws InvalidSearchCriteriaException {
        search(map);
        rmp.VerifyRecordsDisplayedCorrectlywithUI(map);
        rmp.userVerifiesSortingOrder();
        rmp.clicksOnClearButton();
    }

    /**
     * Allows for deletion of a variable type of record.
     * This method implemented due to an incompatibility with a similar method in {@link RulesManagerPage} for deletion
     * performed in the Preferred Procedures page.
     *
     * @param recordType The type of record to delete: Preferred Procedure, Member Exception, etc.
     * @param map        Data to use as a filter before deletion.
     */
    public void deleteRecord(String recordType, Map<String, String> map) {
        switch (recordType) {
            case "Preferred Procedure":
                deleteRecord();
                break;
            default:
                boolean isDataExists = isMemberExistsForSubscriberID(map.get("Subscriber ID"));
                if (!isDataExists) {
                    deleteRecord();
                }
                break;
        }
    }

    /**
     * Performs deletion of the first record in the table of values of Preferred Procedures, Member Exceptions, etc.
     */
    public void deleteRecord() {
        TestUtils.waitForNotBusy(driver());
        TestUtils.click(driver(), deleteRecord);
        TestUtils.waitForNotBusy(driver());
        TestUtils.click(driver(), deleteButton);
    }

    /**
     * Generic: Publish rule changes
     */
    public void clickPublishChangesLink() {
        TestUtils.waitElementVisible(driver(), clickPublishChangesLink);
        TestUtils.click(driver(), clickPublishChangesLink);
        TestUtils.wait(2);
        if (TestUtils.isElementClickable(driver(), publishButton))
            TestUtils.click(driver(), publishButton);
        else
            TestUtils.click(driver(), cancelPublishbtn);
    }

    /**
     * Generic: Validate table headers
     *
     * @param exception The type of the Rules page (Preferred Procedures, Member Exception, etc)
     * @param table Data to match for validation
     */
    public void validateTableHeaders(String exception, DataTable table) {
        switch (exception) {
            case "Member Exception":
                TestUtils.wait(15);
                if (!(verifyHeader("Member Exception"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'UHC Exceptions')]"));
                    np.clickOnException("Member Exception");
                    break;
                }
            case "Provider Exception":
                TestUtils.wait(15);
                if (!(verifyHeader("Provider Exception"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'UHC Exceptions')]"));
                    np.clickOnException("Provider Exception");
                    break;
                }
            case "Buy And Bill Exception":
                TestUtils.wait(15);
                if (!(verifyHeader("Buy And Bill"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'UHC PreHSC')]"));
                    np.clickOnException("Buy And Bill");
                    break;
                }

            case "Supplier List":
                TestUtils.wait(15);
                if (!(verifyHeader("Supplier List"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'UHC Exceptions')]"));
                    np.clickOnException("Supplier List");
                    break;
                }

            case "MSE Provider Exceptions":
                TestUtils.wait(15);
                if (!(verifyHeader("MSE Provider Exception"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'UHC Exceptions')]"));
                    np.clickOnException("MSE Provider Exception");
                    break;
                }

            case "Admin Guide Exception":
                TestUtils.wait(15);
                if (!(verifyHeader("Admin Guide Exception"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'UHC Exceptions')]"));
                    np.clickOnException("Admin Guide Exception");
                    break;
                }

            case "Drug Group":
                TestUtils.wait(15);
                if (!(verifyHeader("Drug Group"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'UHC Exceptions')]"));
                    np.clickOnException("Drug Group");
                    break;
                }

            case "Self Administered Drug Exception":
                TestUtils.wait(15);
                if (!(verifyHeader("Self-Administered Drug"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'UHC PreHSC')]"));
                    np.clickOnException("Self-Administered Drug");
                    break;
                }
            case "Preferred Procedures":
                TestUtils.wait(5);
                if (!(verifyHeader("Preferred Procedures"))) {
//                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("(//a[contains(text(),'Preferred Procedures')])[1]"));
                    np.clickOnException("Preferred Procedures");
                }
                break;
        }
        TestUtils.wait(15);
        List<String> expectedLabelList = table.asList(String.class);
        List<String> tableHeadersList = TestUtils.tableAsLists(this.driver(), "//table[@id='rulesTableID']", 30).get(0);
        TestUtils.wait(5);
        Assert.assertEquals("Table headers do not match", expectedLabelList, tableHeadersList);
        System.out.print(tableHeadersList);

    }


    /**
     * Generic: Add Exception mandatory fields
     *
     * @param popupName The type of the Rules page (Preferred Procedures, Member Exception, etc)
     * @param values The data to fill in
     */
    public void addInfoOnPopUp(String popupName, Map<String, String> values) {

        popupName = popupName.replace(" ", "");
        String Popup = popupName.split("Add")[1];
        switch (Popup) {
            case "MemberException":
                TestUtils.wait(15);
                if (!(verifyHeader("Member Exception"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'UHC Exceptions')]"));
                    np.clickOnException("Member Exception");
                }
                rmp.addMemberException(values);
                break;
            case "ProviderException":
                TestUtils.wait(15);
                if (!(verifyHeader("Provider Exception"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'UHC Exceptions')]"));
                    np.clickOnException("Provider Exception");
                }
                rmp.addProviderException(values);
                break;
            case "BuyAndBillException":
                TestUtils.wait(15);
                if (!(verifyHeader("Buy And Bill"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'UHC PreHSC')]"));
                    np.clickOnException("Buy And Bill");
                }
                rmp.BuyAndBillException(values);
                break;
            case "SupplierList":
                TestUtils.wait(15);
                if (!(verifyHeader("Supplier List"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'UHC Exceptions')]"));
                    np.clickOnException("Supplier List");
                }
                rmp.addSupplierList(values);
                break;


            case "Self-AdministeredDrug":
                TestUtils.wait(15);
                if (!(verifyHeader("Self-Administered Drug"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'UHC PreHSC')]"));
                    np.clickOnException("Self-Administered Drug");
                }
                rmp.SelfadministeredDrugException(values);
                break;
            case "PreferredProcedures":
                TestUtils.wait(15);
                if (!(verifyHeader("Preferred Procedures"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'Preferred Procedures')]"));
                    np.clickOnException("Preferred Procedures");
                }
                rmp.preferredProcedures(values);
                break;

            case "MSEProviderExceptions":
                TestUtils.wait(15);
                if (!(verifyHeader("MSE Provider Exceptions"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'UHC Exceptions')]"));
                    np.clickOnException("MSE Provider Exceptions");
                }
                rmp.addMSEProviderException(values);
                break;

            case "AdminGuideException":
                TestUtils.wait(15);
                if (!(verifyHeader("Admin Guide Exception"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'UHC Exceptions')]"));
                    np.clickOnException("Admin Guide Exception");
                }
                rmp.addAdminGuideException(values);
                break;

            case "DrugGroup":
                TestUtils.wait(15);
                if (!(verifyHeader("Drug Group"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'UHC Exceptions')]"));
                    np.clickOnException("Drug Group");
                }
                rmp.addDrugGroup(values);
                break;

            case "ProviderEligibility":
                TestUtils.wait(15);
                if (!(verifyHeader("Provider Eligibility"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'Eligibility Rules')]"));
                    np.clickOnException("Provider Eligibility");
                }
                rmp.addProviderEligibilityRule(values);
                break;
        }
    }

    /**
     * Generic: Verify exception header
     *
     * @param exceptionHeader The value to validate as the header
     * @return Whether or not the expected result was the actual result
     */
    private boolean verifyHeader(String exceptionHeader) {
        By headerXpath = By.xpath("//span[@ng-if='rulesTable.title && !rulesTable.isPopup']/h2[contains(text(),'" + exceptionHeader + "')]");
        return TestUtils.isElementPresent(driver(), headerXpath);
    }

    /**
     * Generic: Search rules by criteria
     *
     * @param ExceptionName The type of the Rules page (Preferred Procedures, Member Exception, etc)
     * @param searchValues Data to match for search
     */
    public boolean searchByCriteria(String ExceptionName, Map<String, String> searchValues) {
        switch (ExceptionName) {
            case "Member Exception":
                TestUtils.wait(15);
                if (!(verifyHeader("Member Exception"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'UHC Exceptions')]"));
                    np.clickOnException("Member Exception");
                }
                TestUtils.waitForNotBusy(driver());
                String filterTableXpath = "//form[@name='rulesTableFormtableFilters']/table";
                TestUtils.wait(5);
                new SearchCriteria(scenario(), driver()).setCriteria(searchValues, filterTableXpath);
                rmp.clickSearchButton();
                rmp.VerifyRecordsDisplayedCorrectlyAgainstDB(searchValues);
                break;

            case "Provider Exception":
                TestUtils.wait(15);
                if (!(verifyHeader("Provider Exception"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'UHC Exceptions')]"));
                    np.clickOnException("Provider Exception");
                }
                TestUtils.waitForNotBusy(driver());
                filterTableXpath = "//form[@name='rulesTableFormtableFilters']/table";
                TestUtils.wait(5);
                new SearchCriteria(scenario(), driver()).setCriteria(searchValues, filterTableXpath);
                rmp.clickSearchButton();
                rmp.VerifyRecordsDisplayedCorrectlyAgainstDBProvider(searchValues);
                break;

            case "Buy And Bill Exception":
                TestUtils.wait(15);
                if (!(verifyHeader("Buy And Bill"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'UHC PreHSC')]"));
                    np.clickOnException("Buy And Bill");
                }
                TestUtils.waitForNotBusy(driver());
                filterTableXpath = "//form[@name='rulesTableFormtableFilters']/table";
                TestUtils.wait(5);
                new SearchCriteria(scenario(), driver()).setCriteria(searchValues, filterTableXpath);
                rmp.clickSearchButton();
                break;

            case "Self Administered Drug":
                TestUtils.wait(15);
                if (!(verifyHeader("Self-Administered Drug"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'UHC PreHSC')]"));
                    np.clickOnException("Self-Administered Drug");
                }
                TestUtils.waitForNotBusy(driver());
                filterTableXpath = "//form[@name='rulesTableFormtableFilters']/table";
                TestUtils.wait(5);
                new SearchCriteria(scenario(), driver()).setCriteria(searchValues, filterTableXpath);
                rmp.clickSearchButton();
                break;

            case "MSE Provider Exceptions":
                TestUtils.wait(15);
                if (!(verifyHeader("MSE Provider Exceptions"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'UHC PreHSC')]"));
                    np.clickOnException("MSE Provider Exceptions");
                }
                TestUtils.waitForNotBusy(driver());
                filterTableXpath = "//form[@name='rulesTableFormtableFilters']/table";
                TestUtils.wait(5);
                new SearchCriteria(scenario(), driver()).setCriteria(searchValues, filterTableXpath);
                rmp.clickSearchButton();
                return rmp.genericVerifyRecordsDisplayedCorrectlyWithUI(searchValues);
            // break;

            case "Admin Guide Exception":
                TestUtils.wait(15);
                if (!(verifyHeader("Admin Guide Exception"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'UHC PreHSC')]"));
                    np.clickOnException("Admin Guide Exception");
                }
                TestUtils.waitForNotBusy(driver());
                filterTableXpath = "//form[@name='rulesTableFormtableFilters']/table";
                TestUtils.wait(5);
                new SearchCriteria(scenario(), driver()).setCriteria(searchValues, filterTableXpath);
                rmp.clickSearchButton();
                return rmp.genericVerifyRecordsDisplayedCorrectlyWithUI(searchValues);
            // break;

            case "Drug Group":
                TestUtils.wait(15);
                if (!(verifyHeader("Drug Group"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'UHC PreHSC')]"));
                    np.clickOnException("Drug Group");
                }
                TestUtils.waitForNotBusy(driver());
                filterTableXpath = "//form[@name='rulesTableFormtableFilters']/table";
                TestUtils.wait(5);
                new SearchCriteria(scenario(), driver()).setCriteria(searchValues, filterTableXpath);
                rmp.clickSearchButton();
                return rmp.genericVerifyRecordsDisplayedCorrectlyWithUI(searchValues);
            //   break;

            case "Supplier List":
                TestUtils.wait(15);
                if (!(verifyHeader("Supplier List"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'UHC Exceptions')]"));
                    np.clickOnException("Supplier List");
                }
                TestUtils.waitForNotBusy(driver());
                filterTableXpath = "//form[@name='rulesTableFormtableFilters']/table";
                TestUtils.wait(5);
                new SearchCriteria(scenario(), driver()).setCriteria(searchValues, filterTableXpath);
                rmp.clickSearchButton();
                return rmp.genericVerifyRecordsDisplayedCorrectlyWithUI(searchValues);
            //  break;
            case "Preferred Procedures":
                // Input drug code
                WebElement drugCodeInput = TestUtils.slowFindElement(driver(), "Pref_proc_cd", null);
                TestUtils.input(driver(), drugCodeInput, searchValues.get("Drug Code"), false);
                TestUtils.wait(3);
                drugCodeInput.sendKeys(Keys.ENTER);
                searchValues.remove("Drug Code");

                // Search for the rest of the fields with the generic functionality
                new SearchCriteria(scenario(), driver()).setCriteria(searchValues, filterResultsFormXpath);
                rmp.clickSearchButton();
                return rmp.genericVerifyRecordsDisplayedCorrectlyWithUI(searchValues);

            case "Provider Eligibility":
                TestUtils.wait(15);
                if (!(verifyHeader("Provider Eligibility"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'Eligibility Rules')]"));
                    np.clickOnException("Provider Eligibility");
                }
                TestUtils.waitForNotBusy(driver());
                filterTableXpath = "//form[@name='rulesTableFormtableFilters']/table";
                TestUtils.wait(5);
                new SearchCriteria(scenario(), driver()).setCriteria(searchValues, filterTableXpath);
                rmp.clickSearchButton();
                return rmp.genericVerifyRecordsDisplayedCorrectlyWithUI(searchValues);
        }
        return false;
    }

    /**
     * Generic: Delete exception
     *
     * @param exceptionName The type of the Rules page (Preferred Procedures, Member Exception, etc)
     * @param t Data to match for search
     * @throws InterruptedException Thrown if clicking of a record-deletion button is interrupted
     */
    public void deleteRecordFromTable(String exceptionName, Map<String, String> t) throws InterruptedException {

        switch (exceptionName) {
            case "Member Exception":
                TestUtils.wait(15);
                if (!(verifyHeader("Member Exception"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'UHC Exceptions')]"));
                    np.clickOnException("Member Exception");
                }
                rmp.deleteException(t);
                break;

            case "Provider Exception":
                TestUtils.wait(15);
                if (!(verifyHeader("Provider Exception"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'UHC Exceptions')]"));
                    np.clickOnException("Provider Exception");
                }
                rmp.deleteException(t);
                break;

            case "Buy and Bill Exception":
                TestUtils.wait(15);
                if (!(verifyHeader("Buy And Bill"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'UHC PreHSC')]"));
                    np.clickOnException("Buy And Bill");
                }
                rmp.deleteException(t);
                break;

            case "MSE Provider Exceptions":
                TestUtils.wait(15);
                if (!(verifyHeader("MSE Provider Exceptions"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'UHC Exceptions')]"));
                    np.clickOnException("MSE Provider Exceptions");
                }
                searchByCriteria(exceptionName, t);
                rmp.deleteException(t);
                break;

            case "Admin Guide Exception":
                TestUtils.wait(15);
                if (!(verifyHeader("Admin Guide Exception"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'UHC Exceptions')]"));
                    np.clickOnException("Admin Guide Exception");
                }
                searchByCriteria(exceptionName, t);
                rmp.deleteException(t);
                break;

            case "Drug Group":
                TestUtils.wait(15);
                if (!(verifyHeader("Drug Group"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'UHC Exceptions')]"));
                    np.clickOnException("Drug Group");
                }
                rmp.deleteException(t);
                break;

            case "Supplier List":
                TestUtils.wait(15);
                if (!(verifyHeader("Supplier List"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'UHC Exceptions')]"));
                    np.clickOnException("Supplier List");
                }
                searchByCriteria(exceptionName, t);
                rmp.deleteException(t);
                break;

            case "Preferred Procedures":
                deleteRecord("Preferred Procedure", null);
                break;
            case "Provider Eligibility":
                TestUtils.wait(15);
                if (!(verifyHeader("Provider Eligibility"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'Eligibility Rules')]"));
                    np.clickOnException("Provider Eligibility");
                }
                searchByCriteria(exceptionName, t);
                rmp.deleteException(t);
                break;
        }
    }

    /**
     * Generic: Verify rule sorting
     *
     * @param exceptionName The type of the Rules page (Preferred Procedures, Member Exception, etc)
     */
    public void verifySortForExceptionTable(String exceptionName) {
        switch (exceptionName) {
            case "Member Exception":
                TestUtils.wait(15);
                if (!(verifyHeader("Member Exception"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'UHC Exceptions')]"));
                    np.clickOnException("Member Exception");
                }
                rmp.verifySortingFunctionality();
                break;

            case "Provider Exception":
                TestUtils.wait(15);
                if (!(verifyHeader("Provider Exception"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'UHC Exceptions')]"));
                    np.clickOnException("Provider Exception");
                }
                rmp.verifySortingFunctionality();
                break;

            case "Buy and Bill Exception":
                TestUtils.wait(15);
                if (!(verifyHeader("Buy And Bill"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'UHC PreHSC')]"));
                    np.clickOnException("Buy And Bill");
                }
                rmp.verifySortingFunctionality();
                break;

            case "MSE Provider Exceptions":
                TestUtils.wait(15);
                if (!(verifyHeader("MSE Provider Exceptions"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'UHC Exceptions')]"));
                    np.clickOnException("MSE Provider Exceptions");
                }
                rmp.verifySortingFunctionality();
                break;

            case "Admin Guide Exception":
                TestUtils.wait(15);
                if (!(verifyHeader("Admin Guide Exception"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'UHC Exceptions')]"));
                    np.clickOnException("Admin Guide Exception");
                }
                rmp.verifySortingFunctionality();
                break;

            case "Drug Group":
                TestUtils.wait(15);
                if (!(verifyHeader("Drug Group"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'UHC Exceptions')]"));
                    np.clickOnException("Drug Group");
                }
                rmp.verifySortingFunctionality();
                break;

            case "Supplier List":
                TestUtils.wait(15);
                if (!(verifyHeader("Supplier List"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'UHC Exceptions')]"));
                    np.clickOnException("Supplier List");
                }
                rmp.verifySortingFunctionality();
                break;
        }
    }

    /**
     * Generic: Edit Exception
     *
     * @param exception The type of the Rules page (Preferred Procedures, Member Exception, etc)
     * @param table The data to use for editing
     */
    public void editException(String exception, Map<String, String> table) {
        switch (exception) {
            case "Member Exception":
                TestUtils.wait(15);
                if (!(verifyHeader("Member Exception"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'UHC Exceptions')]"));
                    np.clickOnException("Member Exception");
                }
                rmp.editException(table);
                break;

            case "Provider Exception":
                TestUtils.wait(15);
                if (!(verifyHeader("Provider Exception"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'UHC Exceptions')]"));
                    np.clickOnException("Provider Exception");
                }
                TestUtils.waitForNotBusy(driver());
                rmp.editException(table);
                break;

            case "Buy And Bill Exception":
                TestUtils.wait(15);
                if (!(verifyHeader("Buy And Bill"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'UHC PreHSC')]"));
                    np.clickOnException("Buy And Bill");
                }
                TestUtils.waitForNotBusy(driver());
                rmp.editException(table);
                break;

            case "MSE Provider Exceptions":
                TestUtils.wait(15);
                if (!(verifyHeader("MSE Provider Exceptions"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'UHC Exceptions')]"));
                    np.clickOnException("MSE Provider Exceptions");
                }
                TestUtils.waitForNotBusy(driver());
                rmp.editException(table);
                break;

            case "Admin Guide Exception":
                TestUtils.wait(15);
                if (!(verifyHeader("Admin Guide Exception"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'UHC Exceptions')]"));
                    np.clickOnException("Admin Guide Exception");
                }
                TestUtils.waitForNotBusy(driver());
                rmp.editException(table);
                break;

            case "Drug Group":
                TestUtils.wait(15);
                if (!(verifyHeader("Drug Group"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'UHC Exceptions')]"));
                    np.clickOnException("Drug Group");
                }
                TestUtils.waitForNotBusy(driver());
                rmp.editExceptionDrugGroup(table);
                break;

            case "Supplier List":
                TestUtils.wait(15);
                if (!(verifyHeader("Supplier List"))) {
                    np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), By.xpath("//a[contains(text(),'UHC Exceptions')]"));
                    np.clickOnException("Supplier List");
                }
                TestUtils.waitForNotBusy(driver());
                rmp.editException(table);
                break;

            case "Preferred Procedure":
                TestUtils.waitForNotBusy(driver());
                rmp.editPreferredProcedure(table);
                break;
        }
    }

    /**
     * Performs a click on the button to clear filters.
     */
    public void clear() {
        rmp.clicksOnClearButton();
    }

    public void validateSearchByCriteria(String ExceptionName, Map<String, String> searchValues) {
        switch (ExceptionName) {

            case "Buy And Bill Exception":
                TestUtils.wait(15);
                TestUtils.waitForNotBusy(driver());
                rmp.VerifyRecordsDisplayedCorrectlyAgainstBuyAndBill(searchValues);
                break;

            case "Preferred Procedure":
                TestUtils.waitForNotBusy(driver());
                rmp.verifyPreferredProcedureRecordExists(searchValues);
                break;

        }
    }

    public void enterDrugDetails(String ExceptionName, Map<String, String> map) {
        switch (ExceptionName) {

            case "Buy And Bill Exception":
                TestUtils.wait(15);
                TestUtils.waitForNotBusy(driver());
                rmp.enterDrugForBuyAndBill(map);
                break;

        }
    }

    public void checkBuyAndBill(String arg0) {
        Assert.assertTrue("Buy and Bill is not visible", TestUtils.isElementVisible(driver(), buyAndBillLabel));

    }

    public void checkBuyAndBillMessageForNo(String arg0) {
        Assert.assertTrue("Buy and Bill is not visible", TestUtils.isElementVisible(driver(), buyAndBillLabel));
        Assert.assertFalse("Continue button is enabled", TestUtils.isElementClickable(driver(), cloneContinue));

    }

    public void cancelDraft() {

        driver().findElement(cancelDraftLink).click();
    }

    public void clearChanges() {
        driver().findElement(clearChanges).click();
    }

    public void continueAutoApproval() {
        driver().findElement(continueAuto).click();

    }

    /**
     * Performs navigation to a given page in the Rules Manager tool.
     * @param rulePage The rules page to navigate to.
     */
    public void navigateToRulePage(String rulePage) {

        // Validate driver is at the Rules Manager page
        if (!TestUtils.getCurrentUrl().contains(rulesManagerUrlEndpoint)) {
            np.navigatesToMenuItem("Tools>Rules & Exceptions>Rules Manager");
        }

        // Perform navigation to the given page
        switch (rulePage) {
            case "Preferred Procedures":
                if (!(verifyHeader("Preferred Procedures"))) {
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), prefProcParentLink);
                    obj().CommonPage.waitForNOTBusyIndicator();
                    TestUtils.click(driver(), prefProcChildLink);
                    obj().CommonPage.waitForNOTBusyIndicator();
                }
                break;
            case "Expert Rules":
                if (!(verifyHeader("Expert Rules"))) {
                    np.clickOnException("Decisions");
                    np.clickOnException("Expert Rules");
                }
            default:
                break;
        }
    }

}
