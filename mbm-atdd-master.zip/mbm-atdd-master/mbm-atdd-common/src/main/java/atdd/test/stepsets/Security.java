package atdd.test.stepsets;

import atdd.test.core.AbstractStepSet;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.pageobjects.security.SecurityPage;
import cucumber.api.Scenario;
import org.openqa.selenium.WebDriver;

public class Security extends AbstractStepSet {

    private SecurityPage sp = new SecurityPage(driver());


    public Security(Scenario scenario, WebDriver webDriver) {
        super(scenario, webDriver);

    }

    private CommonPageObject obj() {
        return new CommonPageObject(scenario(), driver());
    }

    public void addPermission(String Id, String Desc){
        sp.enterPermissionId(Id);
        sp.enterDescription(Desc);
    }

    public void savePermission(){
        sp.clickOnSavePermissionButton();
    }

    public void editPermission(){
        sp.clickOnEditPermissionIcon();
    }

    public void addPermissionGroup(String arg0, String arg1) {
        sp.enterPermissionGroupId(arg0);
        sp.enterPermissionGroupDescription(arg1);
    }

    public void editPermissionGroup() {
        sp.clickOnEditPermissionGroupIcon();
    }

    public void editUser() {
        sp.clickOnEditUserIcon();
    }
}
