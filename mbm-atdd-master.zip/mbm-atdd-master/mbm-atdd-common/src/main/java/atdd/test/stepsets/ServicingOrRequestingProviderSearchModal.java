package atdd.test.stepsets;

import atdd.common.Retry;
import atdd.test.core.AbstractStepSet;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.pageobjects.authorization.RequestingProviderSearchModalPage;
import atdd.utils.ExcelLib;
import atdd.utils.MBM;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.openqa.selenium.WebDriver;

import java.util.Map;

public class ServicingOrRequestingProviderSearchModal extends AbstractStepSet {
    private final String prefix;

    private CommonPageObject obj() {
        return new CommonPageObject(scenario(), driver());
    }

    private RequestingProviderSearchModalPage rpsmp = obj().RequestingProviderSearchModalPage;

    public ServicingOrRequestingProviderSearchModal(Scenario scenario, WebDriver webDriver, String prefix) {
        super(scenario, webDriver);
        this.prefix = prefix;
    }

    public void search(Map<String, String> map) {
        if (map.containsKey("SearchType")) {
            if (map.get("SearchType").equals("physician")) {
                rpsmp.clickPhysicianTab();
                switch (map.get("SearchBy")) {
                    case "Physician Name + State/ZIP":
                        if (map.containsKey("FirstName")) {
                            rpsmp.enterFirstName(map.get("FirstName"));
                        }
                        if (map.containsKey("LastName")) {
                            rpsmp.enterLastName(map.get("LastName"));
                        }
                        if (map.containsKey("State")) {
                            rpsmp.selectState(map.get("State"));
                        }
                        if (map.containsKey("Zip")) {
                            rpsmp.enterPhysicianZip(map.get("Zip"));
                        }
                        break;
                    case "TIN and/or NPI":
                        rpsmp.selectTINRadioBtn_ChangeProvModal();
                        if (map.containsKey("TIN")) {
                            rpsmp.userEntersTINPhys(map.get("TIN"));
                        }
                        if (map.containsKey("NPI")) {
                            rpsmp.enterNpiNumberInPhysicianTab(map.get("NPI"));
                        }
                        break;
                }
            } else if (map.get("SearchType").equals("facility")) {
                rpsmp.clickFacilityTab();
                if (map.containsKey("SearchBy")) {
                    switch (map.get("SearchBy")) {
                        case "Facility Name + State/ZIP":
                            if (map.containsKey("FacilityName")) {
                                rpsmp.enterFacilityName(map.get("FacilityName"));
                            }
                            if (map.containsKey("State")) {
                                rpsmp.enterFacilityState(map.get("State"));
                            }
                            if (map.containsKey("Zip")) {
                                rpsmp.enterFacilityZip(map.get("Zip"));
                            }
                            break;
                        case "TIN":
                            rpsmp.selectTINRadioBtn_ChangefacilityProvModal();
                            if (map.containsKey("TIN")) {
                                rpsmp.userEntersTINFacility(map.get("TIN"));
                            }
                            if (map.containsKey("NPI")) {
                                rpsmp.userEntersNPIFacility(map.get("NPI"));
                            }
                            break;
                    }
                }
            }

            rpsmp.clickSearchButton();
        } else {
            searchAndSelectProvider(map);
        }
    }

    protected void searchAndSelectProvider(Map<String, String> pf) {
        String providerType = pf.get(prefix + "Type");
        //Switching based on the rpType/spType as Facility or Physician.
        
        String tin = pf.get(prefix + "pdProviderTIN");
        String npi = pf.get(prefix + "pdProviderNPI");
        switch (providerType) {
            case ExcelLib.RP_TYPE_FACILITY:
                boolean success = new Retry("Retry search and select Facility Provider: TIN=" + tin + " NPI=" + npi) {

                    @Override
                    protected void tryOnce() throws Exception {
                        obj().RequestingProviderSearchModalPage.clickFacilityTab();
                        obj().RequestingProviderSearchModalPage.selectTINRadioBtn_FacilitySearchpage();
                        obj().RequestingProviderSearchModalPage.userEntersTINFacility(tin);
                        obj().RequestingProviderSearchModalPage.userEntersNPIFacility(npi);
                        obj().RequestingProviderSearchModalPage.clickSearchButton();

                    }

                    @Override
                    protected boolean until() throws Exception {
                        return TestUtils.waitElementVisible(driver(), RequestingProviderSearchModalPage.firstFacilitySearchResult,10);
                    }

                }.execute();
                if (success) {
                    obj().RequestingProviderSearchModalPage.selectFirstFacilitySearchResult();
                    obj().RequestingProviderSearchModalPage.clickChangeButton();
                } else {
                    obj().RequestingProviderSearchModalPage.clickCancelButton();
                    throw new RuntimeException("Fail to search Facility Provider: TIN=" + tin + " NPI=" + npi);
                }

                break;
            case ExcelLib.RP_TYPE_PHYSICIAN:
                success = new Retry("Retry search and select Physician Provider: TIN=" + tin + " NPI=" + npi) {

                    @Override
                    protected void tryOnce() throws Exception {
                        obj().RequestingProviderSearchModalPage.clickPhysicianTab();
                        obj().RequestingProviderSearchModalPage.selectTINRadioBtn_ChangeProvModal();
                        TestUtils.wait(2);
                        obj().RequestingProviderSearchModalPage.userEntersTINPhys(tin);
                        obj().RequestingProviderSearchModalPage.enterNpiNumberInPhysicianTab(npi);
                        if(pf.get(MBM.PAYER).equals("OptumRx")) {
                            obj().RequestingProviderSearchModalPage.clickNpiRegistrySearchButton();
                        } else {
                            obj().RequestingProviderSearchModalPage.clickSearchButton();
                        }

                    }

                    @Override
                    protected boolean until() throws Exception {
                        return TestUtils.waitElementVisible(driver(), RequestingProviderSearchModalPage.firstPhysicianSearchResult, 10);
                    }

                }.execute();
                if (success) {
                    obj().RequestingProviderSearchModalPage.selectFirstPhysicianSearchResult();
                    obj().RequestingProviderSearchModalPage.clickChangeButton();
                } else {
                    obj().RequestingProviderSearchModalPage.clickCancelButton();
                    throw new RuntimeException("Fail to search Physician Provider: TIN=" + tin + " NPI=" + npi);
                }

                break;
            default:
                throw new RuntimeException("Unknown provider type: " + providerType);
        }
    }

    public void selectProvider()
    {
        obj().RequestingProviderSearchModalPage.selectFirstPhysicianSearchResult();
        obj().RequestingProviderSearchModalPage.clickChangeButton();
    }
}
