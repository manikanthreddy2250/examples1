package atdd.test.stepsets;

import atdd.test.core.AbstractStepSet;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.pageobjects.NavigationPage;
import atdd.test.pageobjects.traversalMaintenance.*;
import atdd.utils.InvalidSearchCriteriaException;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class TraversalMaintenance extends AbstractStepSet {
    private CommonPageObject obj() {
        return new CommonPageObject(scenario(), driver());
    }

    private NavigationPage np = new NavigationPage(driver());
    private TraversalMaintenancePage tmp = new TraversalMaintenancePage(driver());
    private EditTraversalModalPage etp = new EditTraversalModalPage(driver());
    private BulkChangeVariableValueModalPage bcvv = new BulkChangeVariableValueModalPage(driver());
    private BulkChangeVariableTypeModalPage bcvt = new BulkChangeVariableTypeModalPage(driver());
    private BulkEditAuthorizationDurationModalPage beav = new BulkEditAuthorizationDurationModalPage(driver());
    private BulkDeleteModalPage bd = new BulkDeleteModalPage(driver());

    public TraversalMaintenance(Scenario scenario, WebDriver webDriver) {
        super(scenario, webDriver);
    }

    /**
     * Assumption: Admin user login and Dashboard page is displayed.
     * Search Traversals according to the criteria.
     *
     * @param criteria
     * @throws InvalidSearchCriteriaException
     */
    public void search(Map<String, String> criteria) throws InvalidSearchCriteriaException {
        if (!driver().getTitle().contains("Traversal Maintenance")) {
            np.expandClickPrimaryNav("Tools");
            np.clickOptionFromTopNavMenu("Traversal Maintenance");
            obj().CommonPage.waitForNOTBusyIndicator();
        }
        if (criteria.containsKey("Traversal Id")) {
            tmp.enterDataIntoTraversalIDOnTraversalMaintenancePage(criteria.get("Traversal Id"));
        }
        if (criteria.containsKey("Cancer Type")) {
            tmp.selectCancerTypeOnTraversalMaintenancePage(criteria.get("Cancer Type"));
        }
        if (criteria.containsKey("Clinical Variable Type")) {
            String typeOption = criteria.get("Clinical Variable Type");
            if (tmp.clinicalVariableTypeContainsOption(typeOption)) {
                tmp.selectClinicalVariableTypeOnTraversalMaintenancePage(typeOption);
            } else {
                Map<String, String> details = new HashMap<String, String>();
                details.put("Clinical Variable Type", criteria.get("Clinical Variable Type"));
                throw new InvalidSearchCriteriaException("No such value option: " + typeOption, details);
            }
        }
        if (criteria.containsKey("Clinical Variable Value")) {
            String valueOption = criteria.get("Clinical Variable Value");
            if (tmp.clinicalVariableValueContainsOption(valueOption)) {
                tmp.selectClinicalVariableValueOnTraversalMaintenancePage(valueOption);
            } else {
                Map<String, String> details = new HashMap<String, String>();
                details.put("Clinical Variable Value", criteria.get("Clinical Variable Value"));
                throw new InvalidSearchCriteriaException("No such value option: " + valueOption, details);
            }
        }
        TestUtils.demoBreakPoint(scenario(), driver(), "searching for traversal");
        tmp.clickSearchButton();
    }

    /**
     * Assumption: the target traversal is displayed in the search result grid on Traversal Maintenance page.
     * Edit Traversal using the Map parameter "updates"
     *
     * @param traversalId
     * @param updates
     */
    public void editTraversalById(String traversalId, Map<String, String> updates) {
        this.driver().findElement(By.xpath("//td[.='" + traversalId + "']/preceding-sibling::td[1]/span[@title='Edit Traversal']")).click();
        for (String key : updates.keySet()) {
            if ("duration".equals(key)) {
                etp.enterAuthorizationDuration(updates.get(key));
            }
        }
        etp.clickSaveButton();
        TestUtils.wait(3);
    }

    /**
     * Assumption: the target traversal is displayed in the search result grid on Traversal Maintenance page.
     * Extract Traversal information and return it as a Map object.
     *
     * @param traversalId
     * @return
     */
    public Map<String, String> extractTraversalById(String traversalId) {
        Map<String, String> object = new LinkedHashMap<>();
        String Description = this.driver().findElement(By.xpath("//td[.='" + traversalId + "']/following-sibling::td[2]")).getText();
        object.put("description", Description);
        this.driver().findElement(By.xpath("//td[.='" + traversalId + "']/preceding-sibling::td[1]/span[@title='Edit Traversal']")).click();
        object.put("cancerType", etp.getCancerType());
        object.put("duration", etp.getAuthorizationDuration());

        List<List<String>> clinicalVariblesList = TestUtils.tableAsLists(this.driver(), "//table[@id='traversalAddEditClinicalVariableSelectionsTable']", 30);
        for (List<String> clinicalVaribles : clinicalVariblesList) {
            String type = clinicalVaribles.get(1);
            String value = clinicalVaribles.get(3);
            object.put(type, value);

        }
        etp.clickCancelLink();
        TestUtils.wait(1);
        return object;
    }

    /**
     * Assumption: Traversal Maintenance page is displayed.
     * Add Traversals and its Clinical Variables specified in the maps:
     * Given user add below traversals on the Traversal Maintenance page
     * | Cancer Type   | Start Date | End Date | Authorization Duration | Variable Type  | Variable Value      |
     * | <Cancer Type> | ${today}   | -        | 12                     | <Marker Type>  | <Marker Value>      |
     * |               |            |          |                        | <Common Type>  | T1V0-<Common Type>  |
     * |               |            |          |                        | <T1 Only Type> | T1V0-<T1 Only Type> |
     * | <Cancer Type> | ${today}   | -        | 12                     | <Marker Type>  | <Marker Value>      |
     * |               |            |          |                        | <Common Type>  | T2V0-<Common Type>  |
     * |               |            |          |                        | <T2 Only Type> | T2V0-<T2 Only Type> |
     *
     * @param maps
     */
    public void add(List<Map<String, String>> maps) {
        Map<String, String> map = null;
        for (Map<String, String> m : maps) {
            map = m;
            if (!map.get("Cancer Type").isEmpty()) {
                try {
                    TestUtils.demoBreakPoint(scenario(), driver(), "saving the traversal");
                    etp.clickSaveButton();
                    TestUtils.wait(2);
                } catch (Exception e) {
                    //do nothing
                }
                TestUtils.demoBreakPoint(scenario(), driver(), "adding the traversal");
                tmp.clickAddTraversal();
                etp.selectCancerType(map.get("Cancer Type"));
                etp.enterStartDate(map.get("Start Date"));
                if (!"-".equals(map.get("End Date"))) {
                    etp.enterEndDate(map.get("End Date"));
                }
                etp.enterAuthorizationDurationAdd(map.get("Authorization Duration"));
            }
            TestUtils.wait(2);
            etp.selectVariableType(map.get("Variable Type"));
            TestUtils.wait(2);
            etp.enterVariableValue(map.get("Variable Value"));
            TestUtils.wait(2);
            etp.clickAddClinicalVariable();
            if (map.containsKey("Add Error")) {
                String errmsg = map.get("Add Error");
                Assert.assertTrue(obj().CommonPage.isErrorMessageVisible(errmsg));
            }
        }
        TestUtils.demoBreakPoint(scenario(), driver(), "saving the traversal");
        etp.clickSaveButton();
        if (map.containsKey("Save Error")) {
            String errmsg = map.get("Save Error");
            Assert.assertTrue(obj().CommonPage.isErrorMessageVisible(errmsg));
            etp.clickCancelLink();
        }
        TestUtils.wait(2);
    }

    /**
     * Assumption: Traversal Maintenance page is displayed.
     * bulkChangeVariableErrorCheck
     *
     * @param maps
     */
    public void bulkChangeVariableErrorCheck(List<Map<String, String>> maps) {
        for (Map<String, String> map : maps) {
            bcvv.enterVariableTypeInBulkChangeVariableValue(map.get("Variable Type"));

            bcvv.clickApplyButton();
            TestUtils.wait(3);
            bcvv.verifyingInvalidcharacterErrorMessage();
            TestUtils.wait(3);
            bcvv.clicksOn_X_InvalidcharacterErrorPopup();

        }
    }

    /**
     * Assumption: Traversal Maintenance page is displayed.
     * Click Select All.
     */
    public void selectAll() {
        tmp.clickSelectAllCheckBox2();
    }

    /**
     * Assumption: Traversal Maintenance page is displayed.
     * Apply Bulk Action.
     */
    public void applyBulkAction(String action) {
        TestUtils.wait(2);
        tmp.selectBulkAction(action);
        TestUtils.wait(2);
        tmp.clickApplyToSelectedLink();
        TestUtils.wait(2);
    }

    /**
     * Assumption: Bulk Change Variable Value page is displayed.
     * Verify Bulk Change Variable Value UI
     */
    public void verifyBulkChangeVariableValueUI() {
        Assert.assertEquals("Bulk Change Variable Value", bcvv.getTitle());
        Assert.assertEquals("Please select the type from the Variable Type drop down and add a value from the Variable Value drop down, then click Apply.", bcvv.getBulkEditDescription());
        Assert.assertEquals("Variable Type", bcvv.getVariableTypeLabel());
        Assert.assertEquals("", bcvv.getSelectedVariableType());
        Assert.assertEquals("Variable Value", bcvv.getVariableValueLabel());
        Assert.assertEquals("", bcvv.getVariableValue());
    }

    /**
     * Assumption: Bulk Change Variable Value page is displayed.
     * Bulk Change Variable Value using map.
     *
     * @param map
     */
    public void bulkChangeVariableValue(Map<String, String> map) {
        String type = map.get("Variable Type");
        String value = map.get("Variable Value");
        bcvv.enterVariableType(type);
        bcvv.enterVariableValue(value);
        TestUtils.demoBreakPoint(scenario(), driver(), "Bulk Change Variable Value: " + type + "=" + value);
        bcvv.clickApplyButton();
        if (map.containsKey("Apply Error")) {
            String errmsg = map.get("Apply Error");
            Assert.assertTrue(obj().CommonPage.isErrorMessageVisible(errmsg));
            bcvv.clickCancelLink();
        }
    }

    /**
     * Assumption: Bulk Change Variable Value page is displayed.
     * Bulk change Variable type. Data from Datatable.
     *
     * @param map
     */
    public void bulkChangeVariableType(Map<String, String> map) {
        String typeFrom = map.get("From Variable Type");
        String typeTo = map.get("To Variable Type");
        bcvt.selectFromType(typeFrom);
        bcvt.selectToType(typeTo);
        TestUtils.demoBreakPoint(scenario(), driver(), "Bulk Change Variable Type From: " + typeFrom + ", To: " + typeTo);
        bcvt.clickApply();
        if (map.containsKey("Apply Error")) {
            String errmsg = map.get("Apply Error");
            Assert.assertTrue(obj().CommonPage.isErrorMessageVisible(errmsg));
            bcvv.clickCancelLink();
        }
    }

    /**
     * Assumption: Bulk Edit Authorization page is displayed.
     * verifyBulkEditAuthorizationUI
     */
    public void verifyBulkEditAuthorizationUI() {
        Assert.assertEquals("Bulk Edit Authorization Duration", beav.getTitle());
        Assert.assertEquals("If you apply any changes into the field below this will replace the existing value for the selected Traversals with the new added value.", beav.getBulkEditDescription());
        Assert.assertEquals("Authorization Duration", beav.getDurationLabel());
        Assert.assertEquals("", beav.getEditDurationType());
        obj().CommonPage.checkNotElementByText("Must be greater than 0");
    }

    /**
     * Assumption: Bulk Edit Authorization page is displayed.
     * verifyBulkEditAuthorization
     *
     * @param value
     */
    public void verifyBulkEditAuthorization(String value) {
        beav.enterVariableValue(value);
        if (value.equals("0")) {
            obj().CommonPage.checkElementByText("Must be greater than 0");
        } else {
            obj().CommonPage.checkNotElementByText("Must be greater than 0");
        }
        beav.clickApplyButton();
    }

    /**
     * Assumption: Bulk Delete page is displayed.
     * verifyBulkDeleteUI
     */
    public void verifyBulkDeleteUI() {
        Assert.assertEquals("Bulk Delete Traversals", bd.getTitle());
        Assert.assertEquals("Are you sure you want to delete these traversals?", bd.getBulkDeleteDescription());
    }

    /**
     * bulkChangeVariableValueDuplicateErrorCheck
     *
     * @param maps
     */
    public void bulkChangeVariableDuplicateErrorCheck(List<Map<String, String>> maps) {
        for (Map<String, String> m : maps) {
            bcvv.enterVariableTypeInBulkChangeVariableValue(m.get("Variable Type"));
            bcvv.enterVariableValue(m.get("Variable Value"));
            bcvv.clickApplyButton();
            bcvv.verifyingBulkEditVariableDuplicateCheckErrorMessagefor3Traversals();
        }
    }

    /**
     * Entering Variable value with leading and trailing spaces
     *
     * @param maps
     */
    public void EnterBulkChangeVariableLeadingandTrailingSpace(List<Map<String, String>> maps) {
        for (Map<String, String> m : maps) {
            bcvv.enterVariableTypeInBulkChangeVariableValue(m.get("Variable Type"));
            bcvv.enterVariableValueWithLeadingAndTrailingSpaces(m.get("Variable Value"));
            bcvv.clickApplyButton();
        }

    }

    /**
     * varifying checkClinicalVariable
     */
    public void checkClinicalVariable(String val) {
        TestUtils.wait(3);
        bcvv.clicksOncuxIconCaretrRight();
        TestUtils.wait(3);
        String actualVal = bcvv.getActualVariabeVal();
        Assert.assertTrue("Variable value not match as expected", val.equals(actualVal));
    }

    /**
     * BulkChangeVariableTypeDuplicateErrorCheckfor3Traversals
     *
     * @param maps
     */
    public void bulkChangeVariableTypeDuplicateErrorCheckfor3Traversals(List<Map<String, String>> maps) {
        for (Map<String, String> m : maps) {
            bcvt.selectFromType(m.get("Variable Type"));
            bcvt.selectToType(m.get("VariableType Value"));
            bcvt.clickApply();
            bcvv.verifyingBulkEditVariableDuplicateCheckErrorMessagefor3Traversals();
        }
    }

    /**
     * BulkChangeVariablevalueDuplicateErrorCheckfor2Traversals
     *
     * @param maps
     */
    public void bulkChangeVariableDuplicateErrorCheckWithtwoTraversals(List<Map<String, String>> maps) {
        for (Map<String, String> m : maps) {
            bcvv.enterVariableTypeInBulkChangeVariableValue(m.get("Variable Type"));
            bcvv.enterVariableValue(m.get("Variable Value"));
            bcvv.clickApplyButton();
            bcvv.verifyingBulkEditVariableTypeDuplicateCheckErrorMessage();

        }
    }

    /**
     * BulkChangeVariabTypeDuplicateErrorCheckfor2Traversals
     *
     * @param maps
     */
    public void bulkChangeVariableTypeDuplicateErrorCheckfor2Traversals(List<Map<String, String>> maps) {
        for (Map<String, String> m : maps) {
            bcvt.selectFromType(m.get("Variable Type"));
            bcvt.selectToType(m.get("VariableType Value"));
            bcvt.clickApply();
            bcvv.verifyingBulkEditVariableDuplicateCheckErrorMessagefor2Traversals();
        }
    }


    /**
     * Assumption: Admin user login and Dashboard page is displayed.
     * Search Traversals according to the criteria.
     *
     * @param maps
     * @throws InvalidSearchCriteriaException
     */
    public void searchFilter(List<Map<String, String>> maps) {
        if (!driver().getTitle().contains("Traversal Maintenance")) {
            np.expandClickPrimaryNav("Tools");
            np.clickOptionFromTopNavMenu("Traversals & Regimens");
            np.clickOptionFromTopNavMenu("Traversal Maintenance");

            obj().CommonPage.waitForNOTBusyIndicator();
        }

        Map<String, String> map = null;
        for (Map<String, String> m : maps) {
            map = m;
            if (!map.get("Cancer Type").isEmpty()) {
                try {
                    TestUtils.demoBreakPoint(scenario(), driver(), "searching the traversal");
                    tmp.clickSearchButton();

                    TestUtils.wait(2);
                } catch (Exception e) {
                    //do nothing
                }

                tmp.selectCancerTypeOnTraversalMaintenancePage(map.get("Cancer Type"));
            }

            tmp.selectStatusOnTraversalMaintenancePage(map.get("Status"));

            tmp.selectNestedClinicalVariables(map.get("Clinical Variables"));


            if (map.containsKey("Nested Values")) {
                tmp.selectNestedClinicalVariables(map.get("Nested Values"));
            }

            TestUtils.demoBreakPoint(scenario(), driver(), "searching for traversal");

        }

        tmp.clickSearchButton();
    }
}