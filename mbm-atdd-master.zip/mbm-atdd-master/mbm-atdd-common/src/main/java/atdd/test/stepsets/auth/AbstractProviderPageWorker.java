package atdd.test.stepsets.auth;

import atdd.test.core.PageWorkerCommon;
import atdd.test.stepsets.ServicingOrRequestingProviderSearchModal;
import cucumber.api.Scenario;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import java.util.Map;

public abstract class AbstractProviderPageWorker extends PageWorkerCommon {

    final private String prefix; // "rp" or "sp"

    public AbstractProviderPageWorker(Scenario scenario, WebDriver webDriver, Map<String, String> pf, String prefix) {
        super(scenario, webDriver, pf);
        Assert.assertTrue("Unknown prefix: " + prefix, "rp".equals(prefix) || "sp".equals(prefix));
        this.prefix = prefix;
    }

    protected void searchAndSelectProvider() {
        ServicingOrRequestingProviderSearchModal modal = new ServicingOrRequestingProviderSearchModal(scenario(),driver(), prefix);
        modal.search(pf);
    }
}
