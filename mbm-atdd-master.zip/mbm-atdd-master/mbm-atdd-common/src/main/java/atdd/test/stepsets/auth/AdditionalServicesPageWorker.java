package atdd.test.stepsets.auth;

import atdd.test.core.PageWorkerCommon;
import atdd.utils.MBM;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.openqa.selenium.WebDriver;

import java.util.Map;

public class AdditionalServicesPageWorker extends PageWorkerCommon {

    public AdditionalServicesPageWorker(Scenario scenario, WebDriver webDriver, Map<String, String> pf) {
        super(scenario, webDriver, pf);
    }

    @Override
    public boolean accept() {
        TestUtils.waitForAngularRequestsToFinish(driver());
        return obj().CommonPage.waitHeader("Additional Services", 30);

    }

    @Override
    public void work() {

        String authAuthorizationType = pf.get(MBM.AUTH_AUTHORIZATION_TYPE);

        //additional services
        obj().CommonPage.verifyHeader("Additional Services");
        obj().AdditionalServicesPage.enterNumberOfFractionForExternalBeamTechnique(pf.get(MBM.AS_NUMBER_OF_FRACTION_EXTERNAL_BEAM));
       //obj().AdditionalServicesPage.selectDropDownRequestedIGRTCode(pf.get(MBM.AS_IGRT_CODE));
        obj().AdditionalServicesPage.selectSpecialCodes(pf.get(MBM.AS_IGRT_CODE));

        obj().AdditionalServicesPage.enterNumberOfIGRTUnits(pf.get(MBM.AS_IGRT_UNITS));
        obj().AdditionalServicesPage.selectSpecialCodes(pf.get(MBM.AS_SPECIAL_CODES));

       if ((pf.get(MBM.AS_RECORDS_FOR_77470)!= null)); {
            obj().AdditionalServicesPage.selectmedicalRecordDocumentation77470(pf.get(MBM.AS_RECORDS_FOR_77470));
        }
        if ((pf.get(MBM.AS_OTHER_CLINICAL_JUSTIFICATION_77470)!= null)); {
            obj().AdditionalServicesPage.enterOtherclinicalJustificationFor77470(pf.get(MBM.AS_OTHER_CLINICAL_JUSTIFICATION_77470));
        }
        /*
       if ((pf.get(MBM.AS_RECORDS_FOR_77370)!= null)); {
           obj().AdditionalServicesPage.selectmedicalRecordDocumentation77370(pf.get(MBM.AS_RECORDS_FOR_77370));
        }

        if (!(pf.get(MBM.AS_OTHER_CLINICAL_JUSTIFICATION_77370)!= null)); {
            obj().AdditionalServicesPage.enterOtherclinicalJustificationFor77370(pf.get(MBM.AS_OTHER_CLINICAL_JUSTIFICATION_77370));
         }
        if ((pf.get(MBM.AS_FREQUENCY_77331)!= null)); {
            obj().AdditionalServicesPage.selectFrequencyFor77331(pf.get(MBM.AS_FREQUENCY_77331));
        }
        if ((pf.get(MBM.AS_CLINICAL_JUSTIFICATION_77331)!= null)); {
           obj().AdditionalServicesPage.enterclinicalJustificationFor77331(pf.get(MBM.AS_CLINICAL_JUSTIFICATION_77331));
        }
        if ((pf.get(MBM.AS_CLINICAL_JUSTIFICATION_77399)!= null)); {
            obj().AdditionalServicesPage.enterclinicalJustificationFor77399(pf.get(MBM.AS_CLINICAL_JUSTIFICATION_77399));
        }
        if ((pf.get(MBM.AS_SPACER_USED)!= null)); {
            obj().AdditionalServicesPage.selectSpacerUsed(pf.get(MBM.AS_SPACER_USED));
        }*/
    }

    protected void myWork() {
        obj().AdditionalServicesPage.clickContinueButton();
    }

    @Override
    protected void handOff() {

        obj().AdditionalServicesPage.clickContinueButton();
        TestUtils.wait(3);
    }

    @Override
    protected String getPageName() {
        return AdditionalServicesPageWorker.class.getName();
    }

}