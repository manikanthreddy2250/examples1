package atdd.test.stepsets.auth;

import atdd.test.core.PageWorkerCommon;
import atdd.utils.MBM;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.openqa.selenium.WebDriver;

import java.util.Map;

public class AdditionalServicesPageWorkerTraversalOutcomeBTIN extends PageWorkerCommon {

    public AdditionalServicesPageWorkerTraversalOutcomeBTIN(Scenario scenario, WebDriver webDriver, Map<String, String> pf) {
        super(scenario, webDriver, pf);
    }

    @Override
    public boolean accept() {
        TestUtils.waitForAngularRequestsToFinish(driver());
        return obj().CommonPage.waitHeader("Additional Services", 30);

    }

    @Override
    public void work() {

        String authAuthorizationType = pf.get(MBM.AUTH_AUTHORIZATION_TYPE);

        //additional services
        obj().CommonPage.verifyHeader("Additional Services");
        obj().AdditionalServicesPage.enterNumberOfFractionForExternalBeamTechnique(pf.get(MBM.AS_NUMBER_OF_FRACTION_EXTERNAL_BEAM));
        obj().AdditionalServicesPage.selectSpecialCodes(pf.get(MBM.AS_IGRT_CODE));
        obj().AdditionalServicesPage.enterNumberOfIGRTUnits(pf.get(MBM.AS_IGRT_UNITS));
        obj().AdditionalServicesPage.selectSpecialCodes(pf.get(MBM.AS_SPECIAL_CODES));
        obj().AdditionalServicesPage.selectmedicalRecordDocumentation77470(pf.get(MBM.AS_RECORDS_FOR_77470));
        obj().AdditionalServicesPage.enterOtherclinicalJustificationFor77470(pf.get(MBM.AS_OTHER_CLINICAL_JUSTIFICATION_77470));
        obj().AdditionalServicesPage.enterclinicalJustificationFor77399(pf.get(MBM.AS_CLINICAL_JUSTIFICATION_77399));
 //       obj().AdditionalServicesPage.selectSpacerUsed(pf.get(MBM.AS_SPACER_USED));




        if ((pf.get(MBM.AS_CLINICAL_JUSTIFICATION_77399)!= null)) {
            obj().AdditionalServicesPage.enterclinicalJustificationFor77399(pf.get(MBM.AS_CLINICAL_JUSTIFICATION_77399));
        }
    }

    protected void myWork() {
        obj().AdditionalServicesPage.clickContinueButton();
    }

    @Override
    protected void handOff() {

        obj().AdditionalServicesPage.clickContinueButton();
        TestUtils.wait(3);
    }

    @Override
    protected String getPageName() {
        return AdditionalServicesPageWorkerTraversalOutcomeBTIN.class.getName();
    }

}