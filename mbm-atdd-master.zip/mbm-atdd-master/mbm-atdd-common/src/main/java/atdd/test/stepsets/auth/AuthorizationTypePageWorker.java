package atdd.test.stepsets.auth;

import atdd.test.core.PageWorkerCommon;
import atdd.test.pageobjects.authorization.AuthorizationTypePage;
import atdd.utils.MBM;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.openqa.selenium.WebDriver;

import java.util.Map;

public class AuthorizationTypePageWorker extends PageWorkerCommon {

    public AuthorizationTypePageWorker(Scenario scenario, WebDriver webDriver, Map<String, String> pf) {
        super(scenario, webDriver, pf);
    }

    @Override
    public boolean accept() {
        TestUtils.waitForAngularRequestsToFinish(driver());
        return obj().CommonPage.waitHeader("Authorization Type", 15);

    }


    @Override
    public void work() {

        String authAuthorizationType = pf.get(MBM.AUTH_AUTHORIZATION_TYPE);

        //select auth type
        obj().AuthorizationTypePage.selectAuthorizationType(authAuthorizationType);


    }

    @Override
    protected void handOff() {

        obj().AuthorizationTypePage.clickContinueButton();
        boolean present = obj().CommonPage.verifyHeader("Product Is Not Eligible for Auto-approval");
        if(present){
            obj().CommonPage.userClicksContinueButtonPreferredPopUp();
        }



    }

    @Override
    protected String getPageName() {
        return AuthorizationTypePage.class.getName();
    }

}
