package atdd.test.stepsets.auth;

import atdd.utils.MBM;
import cucumber.api.Scenario;
import org.openqa.selenium.WebDriver;

import java.util.Map;

public class AuthorizationTypeSpecialtyPharmaPageWorker extends AuthorizationTypePageWorker {

    public AuthorizationTypeSpecialtyPharmaPageWorker(Scenario scenario, WebDriver webDriver, Map<String, String> pf) {
        super(scenario, webDriver, pf);
    }

    @Override
    public void work() {
        String authAuthorizationType = pf.get(MBM.AUTH_AUTHORIZATION_TYPE);
        obj().AuthorizationTypePage.selectAuthorizationType(authAuthorizationType);
        obj().AuthorizationTypePage.selectSpecialtyPharmaDrugClass(pf.get(MBM.RDCD_SPECIALTY_PHARMADRUG_CLASS));
        obj().AuthorizationTypePage.enterSepcialtyPharmaDrugCode(pf.get(MBM.RDCD_SPECIALTY_PHARMA_DRUG_CODE));


        try {
            if(pf.get(MBM.AUTH_TOOLTIP_CHECK).equalsIgnoreCase("true"))
                obj().AuthorizationTypePage.userValidatesPOSToolTipText();
            if(pf.get(MBM.USER_TITLE).contains("provider"))
                obj().AuthorizationTypePage.selectDropDownValueInplaceofServiceTypeSelForProvider(pf.get(MBM.RDSD_PLACE_OF_SERVICE));
            else
                obj().AuthorizationTypePage.selectDropDownValueInplaceofServiceTypeSel(pf.get(MBM.RDSD_PLACE_OF_SERVICE));

        } catch (Exception e) {
            //Do nothing
        }

    }

}
