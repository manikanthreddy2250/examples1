package atdd.test.stepsets.auth;

import atdd.utils.MBM;
import cucumber.api.Scenario;
import org.openqa.selenium.WebDriver;

import java.util.Map;

public class AuthorizationTypeSpecialtyPharmaPageWorkerMSEUnder6 extends AuthorizationTypePageWorker {

    public AuthorizationTypeSpecialtyPharmaPageWorkerMSEUnder6(Scenario scenario, WebDriver webDriver, Map<String, String> pf) {
        super(scenario, webDriver, pf);
    }

    @Override
    public void work() {
        String authAuthorizationType = pf.get(MBM.AUTH_AUTHORIZATION_TYPE);
        obj().AuthorizationTypePage.selectAuthorizationType(authAuthorizationType);
        obj().AuthorizationTypePage.selectSpecialtyPharmaDrugClass(pf.get(MBM.RDCD_SPECIALTY_PHARMADRUG_CLASS));
//        obj().AuthorizationTypePage.enterDrugCode(pf.get(MBM.RDCD_SPECIALTY_PHARMA_DRUG_CODE));
        obj().AuthorizationTypePage.enterSpecialtyDrugCode(pf.get(MBM.RDCD_SPECIALTY_PHARMA_DRUG_CODE));
        obj().AuthorizationTypePage.selectDropDownValueInplaceofServiceTypeSel(pf.get(MBM.RDSD_PLACE_OF_SERVICE));

    }

}
