package atdd.test.stepsets.auth;

import atdd.test.pageobjects.authorization.AuthorizationTypePage;
import atdd.utils.MBM;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.Map;

public class AuthorizationTypeSpecialtyPharmaPageWorkerUHC extends AuthorizationTypePageWorker {

    public AuthorizationTypeSpecialtyPharmaPageWorkerUHC(Scenario scenario, WebDriver webDriver, Map<String, String> pf) {
        super(scenario, webDriver, pf);
    }

    @Override
    public void work() {
        String authAuthorizationType = pf.get(MBM.AUTH_AUTHORIZATION_TYPE);
        obj().AuthorizationTypePage.selectAuthorizationType(authAuthorizationType);
        obj().AuthorizationTypePage.selectSpecialtyPharmaDrugClass(pf.get(MBM.RDCD_SPECIALTY_PHARMADRUG_CLASS));
        obj().AuthorizationTypePage.enterSepcialtyPharmaDrugCode(pf.get(MBM.RDCD_SPECIALTY_PHARMA_DRUG_CODE));

        TestUtils.wait(5);
        if (TestUtils.isElementVisible(driver(), AuthorizationTypePage.SelfadministeredDropdown)) {
            obj().AuthorizationTypePage.selectsgpType(pf.get(MBM.AUTH_SPECIALTY_SELFADMIN));
        }
        //       obj().AuthorizationTypePage.enterDrugCode(pf.get(MBM.RDCD_SPECIALTY_PHARMA_DRUG_CODE));
        obj().AuthorizationTypePage.selectDropDownValueInplaceofServiceTypeSel(pf.get(MBM.RDSD_PLACE_OF_SERVICE));
        obj().AuthorizationTypePage.clickContinueButton();
        obj().AuthorizationTypePage.clickContinueButtonOnDrugException();
    }

}
