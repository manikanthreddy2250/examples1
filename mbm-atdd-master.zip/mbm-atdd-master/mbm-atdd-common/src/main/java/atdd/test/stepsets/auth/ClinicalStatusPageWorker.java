package atdd.test.stepsets.auth;

import atdd.common.ImmediateAbortException;
import atdd.test.core.CsqaManager;
import atdd.test.core.PageWorkerCommon;
import atdd.test.core.Qa;
import atdd.test.pageobjects.authorization.ClinicalStatusPage;
import atdd.utils.*;
import cucumber.api.Scenario;
import org.openqa.selenium.WebDriver;

import java.util.Map;

public class ClinicalStatusPageWorker extends PageWorkerCommon {
    public ClinicalStatusPageWorker(Scenario scenario, WebDriver webDriver, Map<String, String> pf) {
        super(scenario, webDriver, pf);
    }

    @Override
    public boolean accept() {
        TestUtils.waitForAngularRequestsToFinish(driver());
        return obj().CommonPage.waitHeader("Clinical Status", 15);
    }

    @Override
    public void work() {
        String csqaManagerEnabled = Conf.getInstance().getProperty("csqa_manager_enabled");
        if (Boolean.parseBoolean(csqaManagerEnabled)) {
            Qa qa = CsqaManager.getInstance().getQa(pf);
            if (null == qa) {
                throw new ImmediateAbortException("No Clinical Status Questions and Answers found for profile: " + pf.get(MBM.AUTH_TITLE));
            } else {
                try {
                    logger.warn("Qa's provided by: " + qa.getSource());
                    if (null == qa.getQas() || 0 == qa.getQas().size()) {
                        throw new ImmediateAbortException("No Clinical Status Questions and Answers found: " + qa.getSource());
                    }
                    for (String q : qa.getQas().keySet()) {
                        logger.warn("q=" + q);
                        String a = qa.getQas().get(q);
                        logger.warn("a=" + a);
                        if (!obj().ClinicalStatusPage.inputAnswer(a, q)) {
                            String msg = "Unable to input csqa.";
                            scenarioLogger.warn(msg);
                            scenarioLogger.warn("q=" + q);
                            scenarioLogger.warn("a=" + a);
                            throw new ImmediateAbortException(msg);
                        }
                    }
                    return;
                } catch (ImmediateAbortException e) {
                    throw e;
                } catch (Exception e) {
                    //do nothing to try profile csqa's
                }
            }
        }

        //try profile csqa's
        //clinical status
        Map<String, String> qas = ExcelLib.allQa(pf);
        //loop for questions
        for (String q : qas.keySet()) {
            String a = qas.get(q);
            // if a is null, empty or - from excel still it will continue
            if (StringUtils.isEmpty(a)) {
                continue;
            }
            String label = MBM.getCsqaLabel(pf.get(MBM.AUTH_AUTHORIZATION_TYPE), q);

            TestUtils.wait(1);
            obj().ClinicalStatusPage.chooseClinicalStatus(a, label);
            TestUtils.wait(1);
        }


    }

    @Override
    protected void handOff() {
        if (TestUtils.isElementVisible(driver(), ClinicalStatusPage.continueButton)) {
            obj().ClinicalStatusPage.clickContinueButton();
        }
    }

    @Override
    protected String getPageName() {
        return ClinicalStatusPage.class.getName();
    }
}
