package atdd.test.stepsets.auth;

import atdd.test.core.PageWorkerCommon;
import atdd.test.pageobjects.authorization.MemberSearchPage;
import atdd.utils.MBM;
import atdd.utils.StringUtils;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.Map;

public class MemberSearchPageWorker extends PageWorkerCommon {

    public MemberSearchPageWorker(Scenario scenario, WebDriver webDriver, Map<String, String> pf) {
        super(scenario, webDriver, pf);
    }

    @Override
    public boolean accept() {
        TestUtils.waitForAngularRequestsToFinish(driver());
        return obj().CommonPage.waitHeader("Members", 15);
    }

    @Override
    public void work() {

        String payer = pf.get(MBM.PAYER);
        if (!StringUtils.isEmpty(payer)) {
            obj().MemberSearchPage.selectPayer(payer);
        }

        //member search
        obj().MemberSearchPage.enterSubscriberID(pf.get(MBM.MEMB_SUBSCRIBER_ID));
        obj().MemberSearchPage.enterLastName(pf.get(MBM.MEMB_LAST_NAME));
//        obj().MemberSearchPage.enterFirstName(pf.get(MBM.MEMB_FIRST_NAME).trim().split(" ", 2)[0]);
        obj().MemberSearchPage.enterDOB(pf.get(MBM.MEMB_DATE_OF_BIRTH));

    }

    @Override
    protected void handOff() {

        obj().MemberSearchPage.clickSearchButton();
        String membIndex = pf.get(MBM.MEMB_INDEX);
        if (!StringUtils.isEmpty(membIndex)) {
            TestUtils.click(driver(), By.xpath("(//span[@ng-click='memberSearchTable.selectRecord(record)'])[" + membIndex + "]"));
        }
        obj().CommonPage.waitForNOTBusyIndicator();

    }

    @Override
    protected String getPageName() {
        return MemberSearchPage.class.getName();
    }

}
