package atdd.test.stepsets.auth.PhysicalHealth;


import atdd.common.ImmediateAbortException;
import atdd.test.core.FomsQa;
import atdd.test.core.FomsQaManager;
import atdd.test.core.PageWorkerCommon;
import atdd.test.pageobjects.authorization.physicalHealth.FOMsPage;
import atdd.utils.MBM;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.openqa.selenium.WebDriver;

import java.util.Map;

public class FOMsPageWorker extends PageWorkerCommon {
    public FOMsPageWorker(Scenario scenario, WebDriver webDriver, Map<String, String> pf) {
        super(scenario, webDriver, pf);
    }

    @Override
    public boolean accept() {
        TestUtils.waitForAngularRequestsToFinish(driver());
        return obj().CommonPage.waitHeader("Functional Outcome Measures", 30);
    }


    @Override
    public void work() {
        FomsQa qa = FomsQaManager.getInstance().getFomsQa(pf);
        if (null == qa) {
            throw new ImmediateAbortException("No Foms Questions and Answers found for profile: " + pf.get(MBM.AUTH_TITLE));
        } else {
            //By default it will select the first one MSK SBST fom
            selectQandA(qa.getMskqas(), qa.getSource());

            switch (pf.get(MBM.FOMS_TYPE)) {
                //on the case 1 it will select all options forms with profile Manual Entry, Skip & Start Assessment
                case "1":
                    //get the
                    obj().FOMsPage.selectAssessment(pf.get(MBM.FOMS_BACKINDEX));
                    selectQandA(qa.getBackindexqas(), qa.getSource());
                    obj().FOMsPage.selectAssessment(pf.get(MBM.FOMS_NECKINDEX));
                    selectQandA(qa.getNeckindexqas(), qa.getSource());
                    obj().FOMsPage.selectAssessment(pf.get(MBM.FOMS_DASH));
                    selectQandA(qa.getDashqas(), qa.getSource());
                    obj().FOMsPage.selectAssessment(pf.get(MBM.FOMS_LEFS));
                    selectQandA(qa.getLefsqas(), qa.getSource());
                    obj().FOMsPage.selectAssessment(pf.get(MBM.FOMS_OTHER));
                    selectQandA(qa.getOtherqas(), qa.getSource());
                    break;
                //on the case 2 it will select all options forms expect  Other, with profile Start Assessment only
                case "2":
                    obj().FOMsPage.selectAssessment(pf.get(MBM.FOMS_BACKINDEX));
                    selectQandA(qa.getBackindexqas(), qa.getSource());
                    //ignoring below code as profile is not updated with below answers
                    /*
                    obj().FOMsPage.selectAssessment(pf.get(MBM.FOMS_NECKINDEX));
                    selectQandA(qa.getNeckindexqas(), qa.getSource());
                    obj().FOMsPage.selectAssessment(pf.get(MBM.FOMS_DASH));
                    selectQandA(qa.getDashqas(), qa.getSource());
                    obj().FOMsPage.selectAssessment(pf.get(MBM.FOMS_LEFS));
                    selectQandA(qa.getLefsqas(), qa.getSource());
                     */
                    break;

            }
        }
    }

    private void selectQandA(Map<String, String> qas, String source) {
        try {
            logger.warn("Qa's provided by: " + source);
            if (null == qas || 0 == qas.size()) {
                throw new ImmediateAbortException("No Clinical Status Questions " +
                        "and Answers found: " + source);
            }
            for (String q : qas.keySet()) {
                logger.warn("q=" + q);
                String a = qas.get(q);
                logger.warn("a=" + a);
                if (!obj().FOMsPage.inputAnswer(a, q)) {
                    String msg = "Unable to input csqa.";
                    scenarioLogger.warn(msg);
                    scenarioLogger.warn("q=" + q);
                    scenarioLogger.warn("a=" + a);
                    throw new ImmediateAbortException(msg);
                }
            }

        } catch (ImmediateAbortException e) {
            throw e;
        } catch (Exception e) {
            //do nothing to try profile csqa's
        }

    }


    @Override
    protected void handOff() {
        obj().FOMsPage.clickContinueButton();

    }

    @Override
    protected String getPageName() {
        return FOMsPage.class.getName();
    }

}