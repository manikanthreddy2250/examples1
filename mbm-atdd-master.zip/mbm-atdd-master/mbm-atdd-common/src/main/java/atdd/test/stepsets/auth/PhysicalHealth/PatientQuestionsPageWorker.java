package atdd.test.stepsets.auth.PhysicalHealth;

import atdd.test.core.PageWorkerCommon;
import atdd.test.pageobjects.authorization.physicalHealth.PatientQuestionsPage;
import atdd.utils.MBM;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.openqa.selenium.WebDriver;

import java.util.Map;



public class PatientQuestionsPageWorker extends PageWorkerCommon {

    public PatientQuestionsPageWorker(Scenario scenario, WebDriver webDriver, Map<String, String> pf) {
        super(scenario, webDriver, pf);
    }


    @Override
    public boolean accept() {
        return obj().CommonPage.waitHeader("Patient Questions", 30);
    }



    @Override
    public void work() {

        String authAuthorizationType = pf.get(MBM.AUTH_AUTHORIZATION_TYPE);

        //Patient Questions
        obj().CommonPage.verifyHeader("Patient Questions");

        obj().PatientQuestionsPage.enterDateSymtompsBegan(pf.get(MBM.PQ_DATE_SYMPTOMS_BEGAN));
        obj().PatientQuestionsPage.enterBrieflyDescribeYourSymptoms(pf.get(MBM.PQ_BRIEFLY_DESCRIBE_YOUR_SYMPTOMS));
        obj().PatientQuestionsPage.enterHowDidYourSymptomsStart(pf.get(MBM.PQ_HOW_DID_YOUR_SYMPTOMS_START));
        obj().PatientQuestionsPage.clickPainInLast24Hours(pf.get(MBM.PQ_PAIN_IN_LAST_24_HOURS));
        obj().PatientQuestionsPage.clickPainInLastWeek(pf.get(MBM.PQ_PAIN_IN_LAST_WEEK_1_7_DAYS));
        obj().PatientQuestionsPage.selectDropDownValueInHowOftenDoYouFeelYourSymptoms(pf.get(MBM.PQ_HOW_OFTEN_DO_YOU_FEEL_YOUR_SYMPTOMS));
        obj().PatientQuestionsPage.selectDropDownValueInHowMuchHaveYourSymptomsInterferedWithYourDailyActivities(pf.
                get(MBM.PQ_HOW_MUCH_HAVE_YOUR_SYMPTOMS_INTERFERED_WITH_YOUR_DAILY_ACTIVITIES));
        obj().PatientQuestionsPage.selectDropDownValueInHowIsYourConditionChanging(pf.get(MBM.PQ_HOW_IS_YOUR_CONDITION_CHANGING_SINCE_CARE_AT_THIS_FACILITY));
        obj().PatientQuestionsPage.selectDropDownValueInOverallHealthRightNow(pf.get(MBM.PQ_IN_GENERAL_WOULD_YOU_SAY_YOUR_OVERALL_HEALTH_RIGHT_NOW_IS));
        obj().PatientQuestionsPage.enterdatePatientCompletedQuestions(pf.get(MBM.PQ_DATE_PATIENT_COMPLETED_QUESTIONS));


        myWork();

    }
    protected void myWork(){

    }

    @Override
    protected void handOff() {
        obj().PatientQuestionsPage.clickContinueButton();
        TestUtils.wait(3);
    }

    @Override
    protected String getPageName() {

        return PatientQuestionsPage.class.getName();
    }

}