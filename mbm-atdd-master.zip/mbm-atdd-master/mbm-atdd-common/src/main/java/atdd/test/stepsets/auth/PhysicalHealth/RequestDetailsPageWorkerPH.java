package atdd.test.stepsets.auth.PhysicalHealth;

import atdd.test.core.PageWorkerCommon;
import atdd.test.pageobjects.authorization.DupTermPopupPage;
import atdd.test.pageobjects.authorization.physicalHealth.RequestDetailsPagePH;
import atdd.utils.MBM;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.openqa.selenium.WebDriver;

import java.util.Map;
import java.util.Random;

public class RequestDetailsPageWorkerPH extends PageWorkerCommon {

    public RequestDetailsPageWorkerPH(Scenario scenario, WebDriver webDriver, Map<String, String> pf) {
        super(scenario, webDriver, pf);
    }

    @Override
    public boolean accept() {
        return obj().CommonPage.waitHeader("Request Details", 30);
    }

    @Override
    public void work() {
        if (pf.get("customFields").equals("true"))
            workCustom();
        else if (pf.get("denied").equalsIgnoreCase("yes"))
            workDenied();
        else {
            String authAuthorizationType = pf.get(MBM.AUTH_AUTHORIZATION_TYPE);
            //request details
            obj().CommonPage.verifyHeader("Request Details");
            if (!((pf.get(MBM.USER_TITLE).contains("PAAN")))) {
                obj().RequestDetailsPagePH.enterImageNumber("", pf);
                obj().RequestDetailsPagePH.enterDateReceived(pf.get(MBM.RDPT_DATE_RECEIVED));
            }
            obj().RequestDetailsPagePH.enterTextInDateYouWantTheTreatmentToStart(pf.get(MBM.RDPT_DATE_YOU_WANT_THIS_TREATMENT_TO_BEGIN));
            obj().RequestDetailsPagePH.selectDropDownValueInPrimaryProviderCredential(pf.get(MBM.RDPT_PRIMARY_PROVIDER_CREDENTIAL));
            obj().RequestDetailsPagePH.selectDropDownValueInPlaceofServicePT(pf.get(MBM.RDPT_PLACE_OF_SERVICE));
            obj().RequestDetailsPagePH.selectDropDownValueInPatientType(pf.get(MBM.RDPT_PATIENT_TYPE));
            obj().RequestDetailsPagePH.selectDropDownValueInNatureOfCondition(pf.get(MBM.RDPT_NATURE_OF_CONDITION));
            //Checking if Primary Cause of Current Episode is equal to Post Surgical
            String curentEpisodeTitle = pf.get(MBM.RDPT_PRIMARY_CAUSE_OF_CURRENT_EPISODE);
            if (curentEpisodeTitle.equals("Post Surgical")) {
                obj().RequestDetailsPagePH.selectDropDownValueInPrimaryCauseOfCurrentEpisode(curentEpisodeTitle);
                obj().RequestDetailsPagePH.enteringSurgeryDate(pf.get(MBM.RDPT_SURGERY_DATE));
                obj().RequestDetailsPagePH.selectDropDownValueInTypeOfSurgery(pf.get(MBM.RDPT_TYPE_OF_SURGERY));
            } else {
                obj().RequestDetailsPagePH.selectDropDownValueInPrimaryCauseOfCurrentEpisode(curentEpisodeTitle);
            }
            obj().RequestDetailsPagePH.selectDropDownValueInNatureTreatment(pf.get(MBM.RDPT_NATURE_OF_TREATMENT));
            obj().RequestDetailsPagePH.enterPrimaryIcdCodeAndClickAddCode(pf.get(MBM.RDPT_PRYMARY_DIAGNOSIS_CODE));
        }
        if(pf.get("adminDenialReview").equalsIgnoreCase("yes")){
            obj().RequestDetailsPagePH.selectCheckBoxForAdminDenialReview(pf.get(MBM.RDPT_ADMIN_DENIAL_REVIEW));
            obj().RequestDetailsPagePH.enterAdminDenialReviewComment(pf.get(MBM.RDPT_ADMIN_DENIAL_REVIEW_COMMENT));
        }
    }

    /**
     * Denial Flow
     */
    public void workDenied() {
        String authAuthorizationType = pf.get(MBM.AUTH_AUTHORIZATION_TYPE);

        //request details
        try {
            obj().CommonPage.verifyHeader("Request Details");

            obj().RequestDetailsPagePH.enterImageNumber("", pf);
            obj().RequestDetailsPagePH.enterDateReceived(pf.get(MBM.RDPT_DATE_RECEIVED));
            TestUtils.wait(5);
            obj().RequestDetailsPagePH.enterTextInDateYouWantTheTreatmentToStart("");
            obj().RequestDetailsPagePH.selectDropDownValueLateSubmissionNoteIncluded(pf.get(MBM.RDPT_LATE_SUBMISSION_NOTE_INCLUDED));

            obj().RequestDetailsPagePH.selectDropDownValueInPrimaryProviderCredential(pf.get(MBM.RDPT_PRIMARY_PROVIDER_CREDENTIAL));
            obj().RequestDetailsPagePH.selectDropDownValueInPlaceofServicePT(pf.get(MBM.RDPT_PLACE_OF_SERVICE));
            obj().RequestDetailsPagePH.enterPrimaryIcdCodeAndClickAddCode(pf.get(MBM.RDPT_PRYMARY_DIAGNOSIS_CODE));
            obj().RequestDetailsPagePH.selectDropDownValueInPatientType(pf.get(MBM.RDPT_PATIENT_TYPE));
            obj().RequestDetailsPagePH.selectDropDownValueInNatureOfCondition(pf.get(MBM.RDPT_NATURE_OF_CONDITION));

            //Checking if Primary Cause of Current Episode is equal to Post Surgical
            String curentEpisodeTitle = pf.get(MBM.RDPT_PRIMARY_CAUSE_OF_CURRENT_EPISODE);
            if (curentEpisodeTitle.equals("Post Surgical")) {
                obj().RequestDetailsPagePH.selectDropDownValueInPrimaryCauseOfCurrentEpisode(curentEpisodeTitle);
                obj().RequestDetailsPagePH.enteringSurgeryDate(pf.get(MBM.RDPT_SURGERY_DATE));
                String surgeryType = pf.get(MBM.RDPT_TYPE_OF_SURGERY);
                obj().RequestDetailsPagePH.selectDropDownValueInTypeOfSurgery(pf.get(MBM.RDPT_TYPE_OF_SURGERY));
                if (surgeryType.equals("6 - Other"))
                    obj().RequestDetailsPagePH.enterOtherSurgeryType(pf.get(MBM.RDPT_TYPE_OF_SURGERY_OTHER));
            } else
                obj().RequestDetailsPagePH.selectDropDownValueInPrimaryCauseOfCurrentEpisode(curentEpisodeTitle);
            obj().RequestDetailsPagePH.selectDropDownValueInNatureTreatment(pf.get(MBM.RDPT_NATURE_OF_TREATMENT));
        } catch (Exception ex) {
        }
    }

    /**
     * Custom Fields and Pending Authorization flow
     */
    public void workCustom() {

        String authAuthorizationType = pf.get(MBM.AUTH_AUTHORIZATION_TYPE);

        //request details
        try {
            obj().CommonPage.verifyHeader("Request Details");

            if (!((pf.get(MBM.USER_TITLE).contains("PAAN")))) {
                obj().RequestDetailsPagePH.enterImageNumber("", pf);

                obj().RequestDetailsPagePH.enterDateReceived(TestUtils.getDaysLaterFromToday(Integer.toString(new Random().nextInt(10) + 7)));
                TestUtils.wait(5);
                obj().RequestDetailsPagePH.enterTextInDateYouWantTheTreatmentToStart(TestUtils.getDaysLaterFromToday(Integer.toString(new Random().nextInt(20) + 16)));
                TestUtils.wait(3);
                obj().RequestDetailsPagePH.selectDropDownValueInReasonForLateSubmission(pf.get(MBM.RDPT_REASON_FOR_LATE_SUBMISSION));
            } else {
                String date = pf.get(MBM.RDPT_DATE_YOU_WANT_THIS_TREATMENT_TO_BEGIN);
                obj().RequestDetailsPagePH.enterTextInDateYouWantTheTreatmentToStart(TestUtils.getPastDateFromGivenDate(TestUtils.getTodayDate(), 18));
                TestUtils.wait(5);
                obj().RequestDetailsPagePH.selectDropDownValueInTimelyFilingReason(pf.get(MBM.RDPT_TIMELY_FILING_REASON));
                TestUtils.wait(5);
                obj().RequestDetailsPagePH.selectDropDownValueInTimelyFilingLateReason(pf.get(MBM.RDPT_TIMELY_FILING_LATE_REASON));
            }
            obj().RequestDetailsPagePH.selectDropDownValueInPrimaryProviderCredential(pf.get(MBM.RDPT_PRIMARY_PROVIDER_CREDENTIAL));
            obj().RequestDetailsPagePH.selectDropDownValueInSecondaryProviderCredentil(pf.get(MBM.RDPT_SECONDARY_PROVIDER_CREDENTIAL));
            obj().RequestDetailsPagePH.selectDropDownValueInPlaceofServicePT(pf.get(MBM.RDPT_PLACE_OF_SERVICE));
            obj().RequestDetailsPagePH.enterPrimaryIcdCodeAndClickAddCode(pf.get(MBM.RDPT_PRYMARY_DIAGNOSIS_CODE));
            String patientType = pf.get(MBM.RDPT_PATIENT_TYPE);
            obj().RequestDetailsPagePH.selectDropDownValueInPatientType(pf.get(MBM.RDPT_PATIENT_TYPE));
            if (((pf.get(MBM.USER_TITLE).contains("PAAN"))) && !patientType.equalsIgnoreCase("1 - New to your office")) {
                obj().RequestDetailsPagePH.enterDateOfInitialEvaluation(TestUtils.getPastDateFromGivenDate(TestUtils.getTodayDate(), 1));
                obj().RequestDetailsPagePH.enterNumberOfVisits90Days(pf.get(MBM.RDPT_NUMBER_OF_VISITS_90_DAYS));
                obj().RequestDetailsPagePH.enterScheduledNumberOfVisits(pf.get(MBM.RDPT_SCHEDULED_FREQUENCY_VISITS));
            }
            obj().RequestDetailsPagePH.selectDropDownValueInNatureOfCondition(pf.get(MBM.RDPT_NATURE_OF_CONDITION));

            //Checking if Primary Cause of Current Episode is equal to Post Surgical
            String curentEpisodeTitle = pf.get(MBM.RDPT_PRIMARY_CAUSE_OF_CURRENT_EPISODE);
            if (curentEpisodeTitle.equals("Post Surgical")) {
                obj().RequestDetailsPagePH.selectDropDownValueInPrimaryCauseOfCurrentEpisode(curentEpisodeTitle);
                obj().RequestDetailsPagePH.enteringSurgeryDate(pf.get(MBM.RDPT_SURGERY_DATE));
                String surgeryType = pf.get(MBM.RDPT_TYPE_OF_SURGERY);
                obj().RequestDetailsPagePH.selectDropDownValueInTypeOfSurgery(pf.get(MBM.RDPT_TYPE_OF_SURGERY));
                if (surgeryType.equals("6 - Other"))
                    obj().RequestDetailsPagePH.enterOtherSurgeryType(pf.get(MBM.RDPT_TYPE_OF_SURGERY_OTHER));
            } else
                obj().RequestDetailsPagePH.selectDropDownValueInPrimaryCauseOfCurrentEpisode(curentEpisodeTitle);
            //Checking if Secondary Cause of Current Episode is equal to Post Surgical
            String secondaryEpisodeTitle = pf.get(MBM.RDPT_SECONDARY_COUSE_OF_CURRENT_EPISODE);
            if (secondaryEpisodeTitle.equals("Post Surgical")) {
                obj().RequestDetailsPagePH.selectDropDownValueInSecondaryCauseOfCurrentEpisode(secondaryEpisodeTitle);
                obj().RequestDetailsPagePH.enteringSecondarySurgeryDate(TestUtils.getTodayDate());
                TestUtils.wait(5);
                String surgeryType = pf.get(MBM.RDPT_TYPE_OF_SURGERY);
                obj().RequestDetailsPagePH.selectDropDownValueInSecondaryTypeOfSurgery(pf.get(MBM.RDPT_TYPE_OF_SURGERY));
                if (surgeryType.equals("6 - Other"))
                    obj().RequestDetailsPagePH.enterSecondaryOtherSurgeryType(pf.get(MBM.RDPT_TYPE_OF_SURGERY_OTHER));
            } else
                obj().RequestDetailsPagePH.selectDropDownValueInSecondaryCauseOfCurrentEpisode(secondaryEpisodeTitle);
            obj().RequestDetailsPagePH.selectDropDownValueInNatureTreatment(pf.get(MBM.RDPT_NATURE_OF_TREATMENT));
        } catch (Exception ex) {
        }
    }

    @Override
    protected void handOff() {
        obj().RequestDetailsPagePH.clickContinueButton();
        TestUtils.wait(3);
        if (TestUtils.isElementVisible(driver(), DupTermPopupPage.continueButtonXpath)) {
            obj().DupTermPopupPage.clickContinue();
        }
    }

    @Override
    protected String getPageName() {

        return RequestDetailsPagePH.class.getName();
    }
}