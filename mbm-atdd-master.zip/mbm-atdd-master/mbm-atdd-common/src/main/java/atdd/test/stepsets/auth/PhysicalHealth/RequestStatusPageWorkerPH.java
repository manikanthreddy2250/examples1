package atdd.test.stepsets.auth.PhysicalHealth;

import atdd.test.core.PageWorkerCommon;
import atdd.test.pageobjects.authorization.physicalHealth.RequestStatusPagePH;
import atdd.test.stepsets.AuthorizationRequest;
import atdd.utils.Conf;
import atdd.utils.RequestStatusCollector;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.openqa.selenium.WebDriver;

import java.util.LinkedHashMap;
import java.util.Map;

public class RequestStatusPageWorkerPH extends PageWorkerCommon {
    public RequestStatusPageWorkerPH(Scenario scenario, WebDriver webDriver, Map<String, String> pf) {
        super(scenario, webDriver, pf);
    }

    @Override
    public boolean accept() {
        TestUtils.waitForAngularRequestsToFinish(driver());
        return obj().CommonPage.waitHeader("Request Status", 90);
    }

    @Override
    public void work() {

        Map<String, String> requestStatusPH = new LinkedHashMap<>();


        String s = Conf.getInstance().getProperty("stopCollectionOnPages");
        scenarioLogger.warn("stopCollectionOnPages=" + s);
        scenarioLogger.warn("getShortPageName()=" + getShortPageName());
        if (null == s || !s.contains(getShortPageName())) {
            logger.warn("Collecting on page: " + getShortPageName());
            requestStatusPH.putAll(RequestStatusCollector.collect3(driver(), pf));
        } else {
            logger.warn("Stop collecting on page: " + getShortPageName());
        }
        outcome = new LinkedHashMap<>();
        outcome.put(AuthorizationRequest.OUTCOME_REQUEST_STATUS_PH, requestStatusPH);
    }

    @Override
    protected void handOff() {
        // do nothing
    }

    @Override
    protected String getPageName() {
        return RequestStatusPagePH.class.getName();
    }
}
