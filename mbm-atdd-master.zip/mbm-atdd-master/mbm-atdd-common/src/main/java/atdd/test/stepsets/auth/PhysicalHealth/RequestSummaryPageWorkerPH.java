package atdd.test.stepsets.auth.PhysicalHealth;

import atdd.test.core.PageWorkerCommon;
import atdd.test.pageobjects.authorization.RequestSummaryPage;
import atdd.test.pageobjects.authorization.physicalHealth.RequestSummaryPagePH;
import atdd.test.stepsets.AuthorizationRequest;
import atdd.utils.*;
import cucumber.api.Scenario;
import org.openqa.selenium.WebDriver;

import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.LinkedHashMap;
import java.util.Map;

public class RequestSummaryPageWorkerPH extends PageWorkerCommon {
    public RequestSummaryPageWorkerPH(Scenario scenario, WebDriver webDriver, Map<String, String> pf) {
        super(scenario, webDriver, pf);
    }

    @Override
    public boolean accept() {
        TestUtils.waitForAngularRequestsToFinish(driver());
        return obj().CommonPage.waitHeader("Request Summary", 90);
    }

    @Override
    public void work() {

        Map<String, String> requestSummaryPH = new LinkedHashMap<>();


        String s = Conf.getInstance().getProperty("stopCollectionOnPages");
        scenarioLogger.warn("stopCollectionOnPages=" + s);
        scenarioLogger.warn("getShortPageName()=" + getShortPageName());
        if (null == s || !s.contains(getShortPageName())) {
            logger.warn("Collecting on page: " + getShortPageName());
            requestSummaryPH.putAll(RequestSummaryCollector.collect(driver(),pf));
        } else {
            logger.warn("Stop collecting on page: " + getShortPageName());
        }
        outcome = new LinkedHashMap<>();
        outcome.put(AuthorizationRequest.OUTCOME_REQUEST_SUMMARY_PH, requestSummaryPH);
    }

    @Override
    protected void handOff() {

        obj().RequestSummaryPage.clickSubmitButton();
        TestUtils.wait(10);

    }

    @Override
    protected String getPageName() {
        return RequestSummaryPagePH.class.getName();
    }
}
