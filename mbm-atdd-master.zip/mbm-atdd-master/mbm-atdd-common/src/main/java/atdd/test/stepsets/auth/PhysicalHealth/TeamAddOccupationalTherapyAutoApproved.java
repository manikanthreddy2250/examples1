package atdd.test.stepsets.auth.PhysicalHealth;

import atdd.common.ImmediateAbortException;
import atdd.test.core.PageWorkerBase;
import atdd.test.core.TeamAdd;
import atdd.test.stepsets.LostBrowserException;
import atdd.test.stepsets.auth.*;
import cucumber.api.Scenario;

import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;


public class TeamAddOccupationalTherapyAutoApproved extends TeamAdd {

    public TeamAddOccupationalTherapyAutoApproved(Scenario scenario, Map<String, String> pf) throws ImmediateAbortException, LostBrowserException {
        super(scenario, pf);
    }

    @Override
    protected Queue<PageWorkerBase> buildMyTeam(Map<String, String> pf) {
        LinkedList<PageWorkerBase> workers = new LinkedList<PageWorkerBase>();
        workers.add(new MemberSearchPageWorker(scenario(), driver(), pf));
        workers.add(new AuthorizationTypePageWorker(scenario(), driver(), pf));
        workers.add(new RequestingProviderPageWorker(scenario(), driver(), pf));
        workers.add(new RequestDetailsPageWorkerPH(scenario(), driver(), pf));
        if(pf.get("denial").equalsIgnoreCase("no")) {
            workers.add(new PatientQuestionsPageWorker(scenario(), driver(), pf));
            workers.add(new FOMsPageWorker(scenario(), driver(), pf));
        }
        workers.add(new RequestSummaryPageWorker(scenario(), driver(), pf));
        workers.add(new RequestStatusPageWorker(scenario(), driver(), pf));
        return workers;
    }

}