package atdd.test.stepsets.auth;

import atdd.common.ICondition;
import atdd.test.core.PageWorkerCommon;
import atdd.test.pageobjects.authorization.RegimensPage;
import atdd.utils.*;
import cucumber.api.Scenario;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import java.util.Map;

public abstract class RegimensPageWorker extends PageWorkerCommon {
    public RegimensPageWorker(Scenario scenario, WebDriver webDriver, Map<String, String> pf) {
        super(scenario, webDriver, pf);
    }

    @Override
    public boolean accept() {
        TestUtils.waitForAngularRequestsToFinish(driver());

        if (ExcelLib.AUTH_TYPE_CHEMO.equals(pf.get(MBM.AUTH_AUTHORIZATION_TYPE)) &&
                ExcelLib.CANCER_OTHER.equals(pf.get(MBM.RDCD_PRIMARY_CANCER))) {
            return obj().CommonPage.waitHeader("Custom Regimen", 30);
        } else {
            return obj().CommonPage.waitHeader("Regimens", 30);
        }

    }

    protected void handOffCustomRegimen() {

        obj().RegimensPage.clickContinueButtonInCustomRegimenPage();
        if (TestUtils.waitElementVisible(driver(), RegimensPage.customEpaFinalizePopupModelFormXpath, 3)) {
            By ok = By.xpath(RegimensPage.customEpaFinalizePopupModelFormFinalizeButtonXpath);
            boolean okSuccess = TestUtils.clickUntil(driver(), ok, new ICondition() {
                @Override
                public boolean evaluate() throws Exception {
                    return !TestUtils.isElementVisible(driver(), ok);
                }
            });
            if (!okSuccess) {
                By cancel = By.xpath(RegimensPage.customEpaFinalizePopupModelFormCancelButtonXpath);
                boolean cancelSuccess = TestUtils.clickUntil(driver(), cancel, new ICondition() {
                    @Override
                    public boolean evaluate() throws Exception {
                        return !TestUtils.isElementVisible(driver(), cancel);
                    }
                });
                if (!cancelSuccess) {
                    throw new RuntimeException("Unknown issue trying to close popup module: " + RegimensPage.customEpaFinalizePopupModelFormXpath);
                }
            }
        }
        if (TestUtils.waitElementVisible(driver(), RegimensPage.mixedRegimenNoPharmacyBenefitPopupModelFormXpath, 3)) {
            By ok = By.xpath(RegimensPage.mixedRegimenNoPharmacyBenefitPopupModelFormOkButtonXpath);
            boolean okSuccess = TestUtils.clickUntil(driver(), ok, new ICondition() {
                @Override
                public boolean evaluate() throws Exception {
                    return !TestUtils.isElementVisible(driver(), ok);
                }
            });
            if (!okSuccess) {
                By cancel = By.xpath(RegimensPage.mixedRegimenNoPharmacyBenefitPopupModelFormCancelButtonXpath);
                boolean cancelSuccess = TestUtils.clickUntil(driver(), cancel, new ICondition() {
                    @Override
                    public boolean evaluate() throws Exception {
                        return !TestUtils.isElementVisible(driver(), cancel);
                    }
                });
                if (!cancelSuccess) {
                    throw new RuntimeException("Unknown issue trying to close popup module: " + RegimensPage.mixedRegimenNoPharmacyBenefitPopupModelFormXpath);
                }
            }
        }
        ///sgarg
        if (TestUtils.waitElementVisible(driver(), RegimensPage.offPathwayRegimenReasonPopupModelFormXpath, 3)) {
            By selectRegimenReason = By.xpath(RegimensPage.selectedRegimenNotPartofPathwayProgramXpathexpr);
            boolean selectSuccess = TestUtils.select(driver(),selectRegimenReason, pf.get(MBM.RG_REASONOGCHOOSINGREGIMEN));
            By continuePathwayExcept = By.xpath(RegimensPage.offPathwayRegimenReasonPopupModelFormContinueXpath);
            boolean continuePathwayExceptSuccess = TestUtils.clickUntil(driver(), continuePathwayExcept, new ICondition() {
                @Override
                public boolean evaluate() throws Exception {
                    return !TestUtils.isElementVisible(driver(), continuePathwayExcept);
                }
            });

            if (!selectSuccess || !continuePathwayExceptSuccess) {
                By cancel = By.xpath(RegimensPage.offPathwayRegimenReasonPopupModelFormCancelXpath);
                boolean cancelSuccess = TestUtils.clickUntil(driver(), cancel, new ICondition() {
                    @Override
                    public boolean evaluate() throws Exception {
                        return !TestUtils.isElementVisible(driver(), cancel);
                    }
                });
                if (!cancelSuccess) {
                    throw new RuntimeException("Unknown issue trying to close popup module: " + RegimensPage.offPathwayRegimenReasonPopupModelFormXpath);
                }
            }
        }

    }

    protected void handOffAutoApprovedRegimen() {

        obj().RegimensPage.clickContinueButton();
        if (TestUtils.waitElementVisible(driver(), RegimensPage.pharmacyBenefitsNotificationMixedRegimen, 1)) {
            obj().RegimensPage.OkPharmacyBenefitNotification();
            TestUtils.wait(3);
        }
        if (TestUtils.waitElementVisible(driver(), RegimensPage.reasonforchoosingregimen, 1)) {
            obj().RegimensPage.fillreasonforchoosingthisregimendropdown("Continuation of ongoing therapy");
            obj().RegimensPage.ContinueRegimenReasonPopUp();
            TestUtils.wait(3);
            if (TestUtils.waitElementVisible(driver(), RegimensPage.pharmacyBenefitNotification, 1)) {
                obj().RegimensPage.OkPharmacyBenefitNotification();
            }

        }

    }



    @Override
    protected String getPageName() {
        return RegimensPage.class.getName();
    }

    //selecting regimen by index or label
    protected void selectRegimens() {
        String rgIndexS = pf.get(MBM.RG_INDEX);
        if (StringUtils.isEmpty(rgIndexS)) {
            String rgLabel = pf.get(MBM.RG_LABEL);
            if (StringUtils.isEmpty(rgLabel)) {
                obj().RegimensPage.selectRegimen(1);
            } else {
                obj().RegimensPage.selectRegimen(rgLabel);
            }
        } else {
            obj().RegimensPage.selectRegimen(getRgIndex());
        }

    }

    /**
     * Select Oral Drug Strength
     */
    protected void selectDrugStrength() {
        obj().RegimensPage.selectDrugName(pf.get(MBM.RGDR_DRUG_Strength_0));
    }


    private int getRgIndex() {
        String rgIndex = pf.get(MBM.RG_INDEX);
        try {
            return Integer.parseInt(rgIndex.trim());
        } catch (Exception e) {
            return 1;
        }
    }

    /**
     * Assumption: Custom Regimens page is displayed.
     * Input Custom Regimens page according to the profile.
     * Support 10 drugs at most.
     * Example:
     * Given profile is "chemo custom profile" with below changes
     * | rgdrDrugName1                    | rgdrDrugCode1 | rgdrAuthorizationStatus1 | rgdrDrugNameincludingPackagingOptions1 | rgdrDrugRoute1       | rgdrDosage1                                      | rgdrDaysofCycletobeAdministered1 | rgdrLengthofCyclesDaysorweeks1 |
     * | Goserelin Acetate Implant 3.6 Mg | J9202         | Approved                 | Goserelin Acetate Implant 3.6 Mg       | Subcutaneous Implant | 3.6 mg (28 day cycle) OR 10.8 mg (3 month cycle) | Day 1                            | 28 day cycle OR 3 month cycle  |
     * When user adds an authorization request "auth2"
     */
    protected void addDrugs(By addDrugLink) {
        int drugIndex = 0;
        boolean nextDrug = pf.containsKey(MBM.RGDR_DRUG_CODE_0);
        Assert.assertTrue("There should be at least one drug.", nextDrug);
        while (nextDrug) {
            //if cancel link is not present click addDrugLink.
            if (!TestUtils.isClickable(driver(), RegimensPage.cancelLink)) {
                ((JavascriptExecutor)driver()).executeScript("arguments[0].click();",driver().findElement(addDrugLink));
                TestUtils.clickUntil(driver(), addDrugLink, new ICondition() {
                    @Override
                    public boolean evaluate() throws Exception {
                        if (TestUtils.isElementVisible(driver(), RegimensPage.cancelLink)) {
                            return true;
                        } else {
                            MbmUtils.immediateRecover(driver());
                            return false;
                        }
                    }
                });
            }

            //if Drug code text box is visible enter drug code else getting drug code and doing assert
            if (TestUtils.isElementVisible(driver(), RegimensPage.drugCodeTextBox)) {
                obj().RegimensPage.enterTextInDrugCodeTextBox(pf.get(reIndex(MBM.RGDR_DRUG_CODE_0, drugIndex)));
            } else {
                String displayedDrugCode = driver().findElement(RegimensPage.drugCodeValue).getText();
                Assert.assertEquals(pf.get(reIndex(MBM.RGDR_DRUG_CODE_0, drugIndex)), displayedDrugCode);
            }
            obj().RegimensPage.selectDrugName(pf.get(reIndex(MBM.RGDR_DRUG_NAME_0, drugIndex)));
            obj().RegimensPage.selectdrugrouteinregimen(pf.get(reIndex(MBM.RGDR_DRUG_ROUTE_0, drugIndex)));
            obj().RegimensPage.enterTextInDosageTextBox(pf.get(reIndex(MBM.RGDR_DOSAGE_0, drugIndex)));
            obj().RegimensPage.enterTextInDaysofAdministrationTextBox(pf.get(reIndex(MBM.RGDR_DAY_S_OF_CYCLE_TO_BE_ADMINISTERED_0, drugIndex)));
            obj().RegimensPage.enterTextInLengthofCyclesTextBox(pf.get(reIndex(MBM.RGDR_LENGTH_OF_CYCLES_DAYS_OR_WEEKS_0, drugIndex)));
            obj().RegimensPage.clickAddButton();
//            if (TestUtils.waitElementVisible(driver(), RegimensPage.customDrugExceptionPopupModelFormContinueButtonXpath, 3)) {
//                TestUtils.click(driver(), By.xpath(RegimensPage.customDrugExceptionPopupModelFormContinueButtonXpath));
//            }

            drugIndex++;
            nextDrug = pf.containsKey(reIndex(MBM.RGDR_DRUG_CODE_0, drugIndex));
        }
    }

    public String reIndex(String key_0, int index) {
        return key_0.substring(0, key_0.length() - 1) + index;
    }

    /**
     * Assumption: Custom Regimens page is displayed
     * Make the Custom Regimens as urgent if applicable.
     */
    protected void makeUrgent() {
        String dateOfBirth = "";
        int age = 0;
        if(pf.get(MBM.USER_TITLE).contains("provider")) {
            dateOfBirth = TestUtils.text(driver(), By.xpath("//span[contains(.,'Age')]/parent::td"));
            String[] memberAge = dateOfBirth.trim().split(" ");
            age = Integer.parseInt(memberAge[1]);
        }else
        {
            dateOfBirth = TestUtils.text(driver(), By.xpath("//span[contains(text(),'DOB')]/following-sibling::span"));
            age = DateUtils.getAge(dateOfBirth);
        }
        System.out.println("DOB of the current member is" + dateOfBirth + " age is : " + age);


        if(age>=19){
            if ("Yes".equals(pf.get(MBM.RGID_IS_IT_AN_URGENT_REQUEST))) {
                System.out.println("age is >19, make case Urgent");
                Assert.assertTrue("Urgent Checbox is not visible",TestUtils.isElementVisible(driver(), RegimensPage.urgentRequestCheckbox));
                TestUtils.clickUntil(driver(), RegimensPage.urgentRequestCheckbox, new ICondition() {
                    @Override
                    public boolean evaluate() throws Exception {
                        return TestUtils.isElementVisible(driver(), RegimensPage.urgentRequestOutcome);
                    }
                });
                String urgentOutcome = pf.get(MBM.RGID_URGENT_REQUEST_OUTCOME);
                obj().RegimensPage.selectUrgentOutcome(urgentOutcome);
            }

        }else if(age<19){
            Assert.assertFalse("Urgent Checkbox is visible",TestUtils.isElementVisible(driver(), RegimensPage.urgentRequestCheckbox));

            Assert.assertFalse("Urgent Outcome is visible",TestUtils.isElementVisible(driver(), RegimensPage.urgentRequestCheckbox));
        }

    }
}
