package atdd.test.stepsets.auth;

import atdd.utils.*;
import cucumber.api.*;
import org.openqa.selenium.*;

import java.util.*;

public class RegimensPageWorkerChemoAutoApprove extends RegimensPageWorker {
    public RegimensPageWorkerChemoAutoApprove(Scenario scenario, WebDriver webDriver, Map<String, String> pf) {
        super(scenario, webDriver, pf);
    }

    @Override
    public void work() {

        selectRegimens();

        if (pf.containsKey(MBM.RGDR_DRUG_Strength_0)){
            selectDrugStrength();
        }
    }

    @Override
    protected void handOff() {

        super.handOffAutoApprovedRegimen();

        obj().CommonPage.waitForNOTBusyIndicator();

        if (obj().RegimensPage.isPopupOralDrug()) {
            obj().RegimensPage.clickOralDrugOK();
            this.driver().findElement(By.xpath("//form[@name='oralDrugIncludeRegimenPopupModelForm']//input[@value='OK']")).click();
        }
    }

}
