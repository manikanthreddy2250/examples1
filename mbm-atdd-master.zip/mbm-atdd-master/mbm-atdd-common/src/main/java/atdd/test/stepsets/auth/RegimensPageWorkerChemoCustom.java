package atdd.test.stepsets.auth;

import atdd.common.ICondition;
import atdd.common.ImmediateAbortException;
import atdd.test.pageobjects.authorization.RegimensPage;
import atdd.utils.MBM;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.openqa.selenium.WebDriver;

import java.util.Map;

public class RegimensPageWorkerChemoCustom extends RegimensPageWorker {
    public RegimensPageWorkerChemoCustom(Scenario scenario, WebDriver webDriver, Map<String, String> pf) {
        super(scenario, webDriver, pf);
    }

    @Override
    public void work() {

        if (pf.get(MBM.RGDR_REGIMENEXCEPTION) == null || pf.get(MBM.RGDR_REGIMENEXCEPTION).equalsIgnoreCase("FALSE")) {

            boolean success = TestUtils.clickUntil(driver(), RegimensPage.createCustomRegimenLink, new ICondition() {
                @Override
                public boolean evaluate() throws Exception {
                    return obj().CommonPage.verifyHeader("Custom Regimen");
                }
            });

            if (!success) {
                throw new RuntimeException("Failed: Chemo Custom Regimen");
            }

            addDrugs(RegimensPage.addDrugLink);
            obj().RegimensPage.enterRegimenJustification(pf.get(MBM.RGID_REGIMEN_JUSTIFICATION_0));
            if (!obj().RegimensPage.addClinicalDocumentation(pf.get(MBM.RGID_CLINICAL_DOCUMENTATION))) {
                throw new ImmediateAbortException("Upload fail.");
            }
            makeUrgent();
        }
        else {
            obj().RegimensPage.selectRegimen(pf.get(MBM.RG_LABEL));
        }

    }

    @Override
    protected void handOff() {

        super.handOffCustomRegimen();

    }

}
