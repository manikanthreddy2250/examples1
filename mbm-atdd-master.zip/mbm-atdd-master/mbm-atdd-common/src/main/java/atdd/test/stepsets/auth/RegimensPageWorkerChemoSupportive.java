package atdd.test.stepsets.auth;
import atdd.utils.*;
import cucumber.api.*;
import org.openqa.selenium.*;
import java.util.*;
public class RegimensPageWorkerChemoSupportive extends RegimensPageWorker {
    public RegimensPageWorkerChemoSupportive(Scenario scenario, WebDriver webDriver, Map<String, String> pf) {
        super(scenario, webDriver, pf);
    }
    @Override
    public void work() {
        selectRegimens();
        obj().RegimensPage.clickContinueButton();
        obj().RegimensPage.selectOptionAndClickContinueButton(pf.get("supportivePopup"));
      //  obj().RegimensPage.selectRegimen(pf.get("rgLabel1"));
        if(pf.get("rgPreferred").equals("Yes"))
        {
            obj().RegimensPage.selectRegimen(pf.get("rgLabel1"));
        }
        else
        {
            obj().RegimensPage.showOtherOptionsRequiringClinicalReviewhyperlink();
            obj().RegimensPage.clickContinueButtononPopup();
            obj().RegimensPage.selectRegimen(pf.get("rgLabel2"));
            obj().RegimensPage.clickContinueButton();
            obj().RegimensPage.enterRegimenJustification("Custom Regimen Justification");
        }
        if (pf.containsKey(MBM.RGDR_DRUG_Strength_0)){
            selectDrugStrength();
        }
    }
    @Override
    protected void handOff() {
       super.handOffAutoApprovedRegimen();
       obj().CommonPage.waitForNOTBusyIndicator();
        if (obj().RegimensPage.isPopupOralDrug()) {
            obj().RegimensPage.clickOralDrugOK();
            this.driver().findElement(By.xpath("//form[@name='oralDrugIncludeRegimenPopupModelForm']//input[@value='OK']")).click();
        }
    }
}