package atdd.test.stepsets.auth;

import atdd.common.ImmediateAbortException;
import atdd.common.Retry;
import atdd.test.pageobjects.authorization.RegimensPage;
import atdd.utils.MBM;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import java.util.Map;

public class RegimensPageWorkerRadioA9699Custom extends RegimensPageWorker {
    public RegimensPageWorkerRadioA9699Custom(Scenario scenario, WebDriver webDriver, Map<String, String> pf) {
        super(scenario, webDriver, pf);
    }

    @Override
    public boolean accept() {
        TestUtils.waitForAngularRequestsToFinish(driver());
        return obj().CommonPage.waitHeader("Medical Review Request", 30);

    }

    @Override
    public void work() {
        TestUtils.wait(1);
        addDrugRadiopharmaA9699();
        obj().RegimensPage.enterRegimenJustification(pf.get(MBM.RGID_REGIMEN_JUSTIFICATION_0));
        if (!obj().RegimensPage.addClinicalDocumentation(pf.get(MBM.RGID_CLINICAL_DOCUMENTATION))) {
            throw new ImmediateAbortException("Upload fail.");
        }
        makeUrgent();

    }

    @Override
    protected void handOff() {

        super.handOffCustomRegimen();

        if (TestUtils.waitElementVisible(driver(), RegimensPage.radioPharmaDrugNotificationPopupContinueButton)) {
            //clicking radiopharma notification drug pop up button when it is Azedra drug.
            obj().RegimensPage.clickContinueButtonOnRadioPharmaNotificationDrugPopUp();
        } else {
            Assert.fail("Radiopharma Drug Notification popup not displayed.");
        }

    }

    /**
     * Assumption: Custom Regimens page is displayed for radiopharma flow.
     * Input Custom Regimens page according to the profile
     */
    private void addDrugRadiopharmaA9699() {
        if(!new Retry("addDrugRadiopharmaA9699") {

            @Override
            protected void tryOnce() throws Exception {
                TestUtils.click(driver(), RegimensPage.addDrugLink);
            }

            @Override
            protected boolean until() throws Exception {
                return TestUtils.isElementVisible(driver(), RegimensPage.cancelLink);
            }
        }.execute()){
            throw new RuntimeException("Failed: Add Drug Radiopharma A9699.");
        }

        String displayedDrugCode = driver().findElement(RegimensPage.drugCodeValue).getText();
        Assert.assertEquals(displayedDrugCode, pf.get(MBM.RGDR_DRUG_CODE_0));
        obj().RegimensPage.enterTextInDosageTextBox(pf.get(MBM.RGDR_DOSAGE_0));
        obj().RegimensPage.enterTextInDaysofAdministrationTextBox(pf.get(MBM.RGDR_DAY_S_OF_CYCLE_TO_BE_ADMINISTERED_0));
        obj().RegimensPage.enterTextInLengthofCyclesTextBox(pf.get(MBM.RGDR_LENGTH_OF_CYCLES_DAYS_OR_WEEKS_0));

        obj().RegimensPage.clickAddButton();
        TestUtils.wait(1);

    }

}
