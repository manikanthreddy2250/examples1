package atdd.test.stepsets.auth;

import atdd.common.ImmediateAbortException;
import atdd.common.Retry;
import atdd.test.pageobjects.authorization.RegimensPage;
import atdd.utils.MBM;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.openqa.selenium.WebDriver;

import java.util.Map;

public class RegimensPageWorkerRadioCustom extends RegimensPageWorker {
    public RegimensPageWorkerRadioCustom(Scenario scenario, WebDriver webDriver, Map<String, String> pf) {
        super(scenario, webDriver, pf);
    }

    @Override
    public boolean accept() {
        TestUtils.waitForAngularRequestsToFinish(driver());
        return obj().CommonPage.waitHeader("Medical Review Request", 30);
    }

    @Override
    public void work() {
        TestUtils.wait(1);
        addDrugRadiopharma();
        obj().RegimensPage.enterRegimenJustification(pf.get(MBM.RGID_REGIMEN_JUSTIFICATION_0));
        if (!obj().RegimensPage.addClinicalDocumentation(pf.get(MBM.RGID_CLINICAL_DOCUMENTATION))) {
            throw new ImmediateAbortException("Upload fail.");
        }
        makeUrgent();

    }

    @Override
    protected void handOff() {

        super.handOffCustomRegimen();

    }

    /**
     * Assumption: Custom Regimens page is displayed for radiopharma flow.
     * Input Custom Regimens page according to the profile
     */
    private void addDrugRadiopharma() {
        if (!new Retry("addDrugRadiopharma") {

            @Override
            protected void tryOnce() throws Exception {
                TestUtils.click(driver(), RegimensPage.addDrugLink);
            }

            @Override
            protected boolean until() throws Exception {
                return TestUtils.isElementVisible(driver(), RegimensPage.cancelLink);
            }
        }.execute()) {
            throw new RuntimeException("Failed: Add Drug Radiopharma.");
        }

        obj().RegimensPage.clickAddButton();
        TestUtils.wait(1);

    }

}
