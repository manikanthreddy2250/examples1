package atdd.test.stepsets.auth;

import atdd.common.ImmediateAbortException;
import atdd.utils.MBM;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.openqa.selenium.WebDriver;

import java.util.Map;

public class RegimensPageWorkerSpecialtyPharmaCustom extends RegimensPageWorker {
    public RegimensPageWorkerSpecialtyPharmaCustom(Scenario scenario, WebDriver webDriver, Map<String, String> pf) {
        super(scenario, webDriver, pf);
    }

    @Override
    public boolean accept() {
        TestUtils.waitForAngularRequestsToFinish(driver());
        return obj().CommonPage.waitHeader("Custom Specialty Pharmacy", 30);
    }

    @Override
    public void work() {
        obj().RegimensPage.enterRegimenJustification(pf.get(MBM.RGID_REGIMEN_JUSTIFICATION_0));
        if (!obj().RegimensPage.addClinicalDocumentation(pf.get(MBM.RGID_CLINICAL_DOCUMENTATION))) {
            throw new ImmediateAbortException("Upload fail.");
        }
        makeUrgent();
    }

    @Override
    protected void handOff() {
        super.handOffCustomRegimen();
    }

}
