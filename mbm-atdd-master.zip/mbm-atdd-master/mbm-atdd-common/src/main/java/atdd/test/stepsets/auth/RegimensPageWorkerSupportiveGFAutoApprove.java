package atdd.test.stepsets.auth;

import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.openqa.selenium.WebDriver;

import java.util.Map;

/**
 * Works the Regimens page for an auto-approved Growth Factors end-to-end flow.
 */
public class RegimensPageWorkerSupportiveGFAutoApprove extends RegimensPageWorker {

    public RegimensPageWorkerSupportiveGFAutoApprove(Scenario scenario, WebDriver webDriver, Map<String, String> pf) {
        super(scenario, webDriver, pf);
    }

    @Override
    public boolean accept() {
        TestUtils.waitForAngularRequestsToFinish(driver());
        return obj().CommonPage.waitHeader("Available Growth Factors for Auto-Approval", 30);
    }

    @Override
    public void work() {

        //selecting the regimen when drug type is white blood cell growth factors
        selectRegimens();

    }

    @Override
    protected void handOff() {
        super.handOffAutoApprovedRegimen();
    }

}
