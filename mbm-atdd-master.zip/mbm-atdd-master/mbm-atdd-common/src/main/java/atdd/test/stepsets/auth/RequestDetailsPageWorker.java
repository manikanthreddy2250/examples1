package atdd.test.stepsets.auth;

import atdd.test.core.PageWorkerCommon;
import atdd.test.pageobjects.authorization.DupTermPopupPage;
import atdd.test.pageobjects.authorization.RequestDetailsPage;
import atdd.test.stepsets.AuthorizationRequest;
import atdd.utils.ExcelLib;
import atdd.utils.MBM;
import atdd.utils.StringUtils;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import java.util.Map;

public abstract class RequestDetailsPageWorker extends PageWorkerCommon {

    public RequestDetailsPageWorker(Scenario scenario, WebDriver webDriver, Map<String, String> pf) {
        super(scenario, webDriver, pf);
    }

    @Override
    public boolean accept() {
        TestUtils.waitForAngularRequestsToFinish(driver());
        return obj().CommonPage.waitHeader("Request Details", 30);

    }

    @Override
    public void work() {

        String authAuthorizationType = pf.get(MBM.AUTH_AUTHORIZATION_TYPE);

        //request details
        obj().CommonPage.verifyHeader("Request Details");
        obj().RequestDetailsPage.enterTextInHeightOfThePatient(pf.get(MBM.RDPD_HEIGHT_OF_THE_PATIENT));
        obj().RequestDetailsPage.enterTextInWeightOfThePatient(pf.get(MBM.RDPD_WEIGHT_OF_THE_PATIENT));
        obj().RequestDetailsPage.enterTextInPatientContactNumber(pf.get(MBM.RDPD_PATIENT_CONTACT_NUMBER));
        obj().RequestDetailsPage.enterTextInInitialDiagnosisDate(pf.get(MBM.RDSD_INITIAL_DIAGNOSIS_DATE));
        obj().RequestDetailsPage.selectDropDownValueInplaceofServiceTypeSel(pf.get(MBM.RDSD_PLACE_OF_SERVICE));
        if (pf.get(MBM.PAYER) == "BCBS" || pf.get("rpTitle").equals("an MSK Provider")){
            obj().RequestDetailsPage.enterTextInAnticipatedTreatmentTextBox(pf.get(MBM.RDSD_ANTICIPATED_TREATMENT_START_DATE));
        }
        //obj().RequestDetailsPage.enterTextInAnticipatedTreatmentTextBox(pf.get(MBM.RDSD_ANTICIPATED_TREATMENT_START_DATE));


        String rpTitle = pf.get(MBM.RP_TITLE);
        //Checking the condition if it contains user title as  PAAN and rp title as MSK
        if (!pf.get(MBM.USER_TITLE).contains("PAAN") && !rpTitle.toLowerCase().contains("msk")) {
            obj().RequestDetailsPage.enterTextInBackDatingTextBox(pf.get(MBM.RDSD_BACKDATING_START_DATE), pf.get(MBM.RDSD_JUSTIFICATION_FOR_BACKDATING_OF_START_DATE));
        }
        obj().RequestDetailsPage.enterTextinIcdCode(pf.get(MBM.RDSD_ICD_10_CODE));
        obj().RequestDetailsPage.selectDropDownPerformanceScale(pf.get(MBM.RDSD_PERFORMANCE_SCALE));
        obj().RequestDetailsPage.selectDropDownPerformanceStatus(pf.get(MBM.RDSD_PERFORMANCE_STATUS));

        try {
            obj().RequestDetailsPage.enterTextinprimaryCancer(pf.get(MBM.RDCD_PRIMARY_CANCER));
        } catch (Exception e) {
            if (!ExcelLib.AUTH_TYPE_CHEMO.equals(pf.get(AuthorizationRequest.CLONE_TO_AUTHORIZATION_TYPE))) {
                throw e;
            }
        }
        //checking the primary cancer as other
        if (ExcelLib.CANCER_OTHER.equals(pf.get(MBM.RDCD_PRIMARY_CANCER))) {
            obj().RequestDetailsPage.enterOtherDecription(pf.get(MBM.RDCD_OTHER_DECRIPTION));
        }

        myWork();

    }

    protected void myWork() {
        //do nothing
    }

    @Override
    protected void handOff() {

        obj().RequestDetailsPage.clickContinueButton();
        TestUtils.wait(3);
        if (TestUtils.isElementVisible(driver(), DupTermPopupPage.continueButtonXpath)) {
            obj().DupTermPopupPage.clickContinue();
        }

    }

    @Override
    protected String getPageName() {
        return RequestDetailsPage.class.getName();
    }

    /**
     * Selecting treatment type on the request details page
     */
    protected void selectTreatment() {
        String treatment = pf.get(MBM.RDCD_INITIAL_OR_CHANGING_TREATMENT);
        obj().RequestDetailsPage.selectDropDownValueInChangingTreatmentTypeSel(treatment);
        TestUtils.wait(2);

        //switching between intital treatment and continuation of treatment
        switch (treatment) {
            case ExcelLib.RDCD_TREATMENT_INITIAL:
                // do nothing
                break;
            case ExcelLib.RDCD_TREATMENT_CHANGING:
                String[] justifications = ExcelLib.splitJustifications(pf.get(MBM.RDCD_CHANGING_TREATMENT_JUSTIFICATION));
                TestUtils.wait(2);
                for (String justification : justifications) {
                    obj().RequestDetailsPage.changeTreatmentJustificationSelection(justification);
                }
                break;
            default:
                throw new RuntimeException("Unknown treatment: " + treatment);
        }
    }

    protected void selectDiseaseProgressed() {
        String rdcdHasDiseaseProgressedorRelapsed = pf.get(MBM.RDCD_HAS_DISEASE_PROGRESSED_OR_RELAPSED);
        if ("Yes".equalsIgnoreCase(rdcdHasDiseaseProgressedorRelapsed)) {
            obj().RequestDetailsPage.selectDropDownValueInDiseaseProgressedTypeSel("Yes");
            String rdcdInitialDateofProgression = pf.get(MBM.RDCD_INITIAL_DATE_OF_PROGRESSION);
            Assert.assertTrue(!StringUtils.isEmpty(rdcdInitialDateofProgression));
            obj().RequestDetailsPage.enterTextInInitialDateofProgression(rdcdInitialDateofProgression);
        } else {
            obj().RequestDetailsPage.selectDropDownValueInDiseaseProgressedTypeSel("No");
        }
    }
}