package atdd.test.stepsets.auth;

import atdd.utils.MBM;
import cucumber.api.Scenario;
import org.openqa.selenium.WebDriver;

import java.util.Map;

public class RequestDetailsPageWorkerChemo extends RequestDetailsPageWorker {
    public RequestDetailsPageWorkerChemo(Scenario scenario, WebDriver webDriver, Map<String, String> pf) {
        super(scenario, webDriver, pf);
    }

    @Override
    public void myWork() {

        try {
            obj().RequestDetailsPage.selectDropDownValueInChemotherapyTrialCancerTypeSel(pf.get(MBM.RDCD_CHEMOTHERAPY_CLINICAL_TRIAL));
        } catch (Exception e) {
            // do nothing
        }

        selectDiseaseProgressed();
        selectTreatment();

    }

}
