package atdd.test.stepsets.auth;

import atdd.test.stepsets.AuthorizationRequest;
import atdd.utils.ExcelLib;
import atdd.utils.MBM;
import cucumber.api.Scenario;
import org.openqa.selenium.WebDriver;

import java.util.Map;

public class RequestDetailsPageWorkerRadOnc extends RequestDetailsPageWorker {
    public RequestDetailsPageWorkerRadOnc(Scenario scenario, WebDriver webDriver, Map<String, String> pf) {
        super(scenario, webDriver, pf);
    }

    @Override
    public void work() {

      /*  TestUtils.wait(90);
        boolean present = TestUtils.isElementVisible(driver(), RequestingProviderPage.pendoContinueBtn);
        if (present) {
            obj().RequestDetailsPage.clickPendoButton();
        }
*/
    	obj().CommonPage.verifyHeader("Request Details");
        obj().RequestDetailsPage.enterTextInPatientContactNumber(pf.get(MBM.RDPD_PATIENT_CONTACT_NUMBER));
        obj().RequestDetailsPage.enterTextInInitialDiagnosisDate(pf.get(MBM.RDSD_INITIAL_DIAGNOSIS_DATE));
        String rpTitle = pf.get(MBM.RP_TITLE);
//        //Checking the condition if it contains user title as  PAAN and rp title as MSK
//        if (!pf.get(MBM.USER_TITLE).contains("PAAN") && !rpTitle.toLowerCase().contains("msk") && !pf.get(MBM.USER_TITLE).contains("provider")) {
//            obj().RequestDetailsPage.enterTextInBackDatingTextBox(pf.get(MBM.RDSD_BACKDATING_START_DATE), pf.get(MBM.RDSD_JUSTIFICATION_FOR_BACKDATING_OF_START_DATE));
//        }
        obj().RequestDetailsPage.enterPrimaryIcdCodeAndClickAddCode(pf.get(MBM.RDSD_ICD_10_CODE));
        obj().RequestDetailsPage.addAdditionalIcd10Code(pf.get(MBM.RDSD_ADDITIONAL_ICD_10_CODE0));
        obj().RequestDetailsPage.addAdditionalIcd10Code(pf.get(MBM.RDSD_ADDITIONAL_ICD_10_CODE1));
        obj().RequestDetailsPage.selectDropDownPerformanceScale(pf.get(MBM.RDSD_PERFORMANCE_SCALE));
        obj().RequestDetailsPage.selectDropDownPerformanceStatus(pf.get(MBM.RDSD_PERFORMANCE_STATUS));
        try {
            obj().RequestDetailsPage.enterTextinprimaryCancer(pf.get(MBM.RDCD_PRIMARY_CANCER));
        } catch (Exception e) {
            if (!ExcelLib.AUTH_TYPE_CHEMO.equals(pf.get(AuthorizationRequest.CLONE_TO_AUTHORIZATION_TYPE))) {
                throw e;
            }
        }
        //checking the primary diagnosis as other
        if (ExcelLib.CANCER_OTHER.equals(pf.get(MBM.RDCD_PRIMARY_CANCER))) {
            obj().RequestDetailsPage.enterOtherDecription(pf.get(MBM.RDCD_OTHER_DECRIPTION));
        }
        //handling the condition for Metatastic Popups
        if (!ExcelLib.CANCER_SECONDARY_META_BRAIN.equals(pf.get(MBM.RDCD_PRIMARY_CANCER)) && !ExcelLib.CANCER_SECONDARY_META_CRANIAL.equals(pf.get(MBM.RDCD_PRIMARY_CANCER))) {
            obj().RequestDetailsPage.selectDropDownValueForDistantMetatasticDisease(pf.get(MBM.RDCD_DIFFERENT_METATASTIC_DISEASE));
            if (!pf.get(MBM.RDCD_DIFFERENT_METATASTIC_DISEASE).contains("No")) {
                obj().RequestDetailsPage.selectDropDownValueForPrimarySecondaryMetatasticSite(pf.get(MBM.RDCD_PRIMARY_OR_SECONDARY_SITE));
                if (pf.get(MBM.RDCD_PRIMARY_OR_SECONDARY_SITE).contains("Secondary")) {
                    obj().RequestDetailsPage.changePrimaryDiagnoseMessage(pf.get(MBM.RDCD_CHANGE_PRIMARYDIAGNOSIS_MESSAGE));
                    obj().RequestDetailsPage.selectDropDownValueForPrimarySecondaryMetatasticSite("Primary");
                }
            }
        }

        obj().RequestDetailsPage.selectDropDownValueInChemotherapyTrialCancerTypeSel(pf.get(MBM.RDCD_CHEMOTHERAPY_CLINICAL_TRIAL));
        if (pf.get(MBM.RDCD_CHEMOTHERAPY_CLINICAL_TRIAL).contains("Yes")) {
            obj().RequestDetailsPage.validateAndChangeClinicalTrialValue(pf.get(MBM.RDCD_CLINICAL_TRIAL_MESSAGE));
        }
        obj().RequestDetailsPage.selectDropDownValueInplaceofServiceTypeSel(pf.get(MBM.RDSD_PLACE_OF_SERVICE));
    }


}
