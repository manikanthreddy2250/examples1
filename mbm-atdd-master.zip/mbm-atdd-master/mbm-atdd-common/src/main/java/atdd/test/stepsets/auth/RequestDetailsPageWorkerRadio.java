package atdd.test.stepsets.auth;

import atdd.utils.MBM;
import cucumber.api.Scenario;
import org.openqa.selenium.WebDriver;

import java.util.Map;

public abstract class RequestDetailsPageWorkerRadio extends RequestDetailsPageWorker {
    public RequestDetailsPageWorkerRadio(Scenario scenario, WebDriver webDriver, Map<String, String> pf) {
        super(scenario, webDriver, pf);
    }

    @Override
    public void myWork() {

        obj().RequestDetailsPage.selectDropDownValueInChemotherapyTrialCancerTypeSel(pf.get(MBM.RDCD_CANCER_CLINICAL_TRIAL));

        selectDiseaseProgressed();
        selectTreatment();

    }

}
