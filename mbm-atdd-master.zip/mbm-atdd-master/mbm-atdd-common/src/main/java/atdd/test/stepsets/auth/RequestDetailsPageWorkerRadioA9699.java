package atdd.test.stepsets.auth;

import atdd.utils.ExcelLib;
import cucumber.api.Scenario;
import org.openqa.selenium.WebDriver;

import java.util.Map;

public class RequestDetailsPageWorkerRadioA9699 extends RequestDetailsPageWorkerRadio {
    public RequestDetailsPageWorkerRadioA9699(Scenario scenario, WebDriver webDriver, Map<String, String> pf) {
        super(scenario, webDriver, pf);
    }

    @Override
    public void myWork() {

        super.myWork();
        obj().RequestDetailsPage.selectDropDownValueInRadiopharmaceuticalRequestTypeSel(ExcelLib.RDCD_WHICH_RADIOPHARMACEUTICAL_ARE_YOU_REQUESTING_AZEDRA);

    }

}
