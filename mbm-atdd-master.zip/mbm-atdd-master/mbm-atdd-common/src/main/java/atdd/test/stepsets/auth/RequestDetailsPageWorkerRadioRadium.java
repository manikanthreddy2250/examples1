package atdd.test.stepsets.auth;

import atdd.utils.ExcelLib;
import atdd.utils.MBM;
import cucumber.api.Scenario;
import org.openqa.selenium.WebDriver;

import java.util.Map;

public class RequestDetailsPageWorkerRadioRadium extends RequestDetailsPageWorkerRadio {
    public RequestDetailsPageWorkerRadioRadium(Scenario scenario, WebDriver webDriver, Map<String, String> pf) {
        super(scenario, webDriver, pf);
    }

    @Override
    public void myWork() {

        super.myWork();
        obj().RequestDetailsPage.selectDropDownValueInRadiopharmaceuticalRequestTypeSel(ExcelLib.RDCD_WHICH_RADIOPHARMACEUTICAL_ARE_YOU_REQUESTING_RADIUM);
        obj().RequestDetailsPage.selectDropDownValueInCurrentMedicineTypeSel(pf.get(MBM.RDCD_IS_PATIENT_CURRENTLY_TAKING_LEUPROLIDEACETATE));

    }

}
