package atdd.test.stepsets.auth;

import atdd.utils.MBM;
import cucumber.api.Scenario;
import org.openqa.selenium.WebDriver;

import java.util.Map;

public class RequestDetailsPageWorkerSpecialtyPharmaMSE extends RequestDetailsPageWorker {
    public RequestDetailsPageWorkerSpecialtyPharmaMSE(Scenario scenario, WebDriver webDriver, Map<String, String> pf) {
        super(scenario, webDriver, pf);
    }

    @Override
    public void work() {

        obj().RequestDetailsPage.enterTextInHeightOfThePatient(pf.get(MBM.RDPD_HEIGHT_OF_THE_PATIENT));

        obj().RequestDetailsPage.enterTextInWeightOfThePatient(pf.get(MBM.RDPD_WEIGHT_OF_THE_PATIENT));

        obj().RequestDetailsPage.enterTextInPatientContactNumber(pf.get(MBM.RDPD_PATIENT_CONTACT_NUMBER));

        obj().RequestDetailsPage.enterTextInInitialDiagnosisDate(pf.get(MBM.RDSD_INITIAL_DIAGNOSIS_DATE));

        obj().RequestDetailsPage.enterTextInBackDatingTextBox(pf.get(MBM.RDSD_BACKDATING_START_DATE), pf.get(MBM.RDSD_JUSTIFICATION_FOR_BACKDATING_OF_START_DATE));

        obj().RequestDetailsPage.enterPrimaryIcdCodeAndClickAddCode(pf.get(MBM.RDSD_ICD_10_CODE));

        obj().RequestDetailsPage.addAdditionalIcd10Code(pf.get(MBM.RDSD_ADDITIONAL_ICD_10_CODE0));
        obj().RequestDetailsPage.addAdditionalIcd10Code(pf.get(MBM.RDSD_ADDITIONAL_ICD_10_CODE1));

        obj().RequestDetailsPage.selectDropDownValueInChangingTreatmentTypeSel(pf.get(MBM.RDCD_INITIAL_OR_CHANGING_TREATMENT));

        obj().RequestDetailsPage.enterTextInDiseaseState(pf.get(MBM.RDCD_SPECIALTY_DISEASE_STATE));

        obj().RequestDetailsPage.selectSpecialtyDiagnosis(pf.get(MBM.RDCD_SPECIALTY_PHARMA_DIAGNOSIS));
 //       obj().RequestDetailsPage.selectDropDownValueInplaceofServiceTypeSel(pf.get(MBM.RDSD_PLACE_OF_SERVICE));

        obj().RequestDetailsPage.addSpecialtyDosage(pf);

    }

    @Override
    protected void handOff() {
        obj().RequestDetailsPage.specialtyPharmaclickContinueButton();
        obj().RequestDetailsPage.clickDoseConfirmationPopupContinueButton();
    }
}





