package atdd.test.stepsets.auth;

import atdd.utils.MBM;
import cucumber.api.Scenario;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import java.util.Map;

/**
 * Works the Request Details page for a Cancer Supportive Drugs end-to-end flow.
 */
public class RequestDetailsPageWorkerSupportive extends RequestDetailsPageWorker {

    public RequestDetailsPageWorkerSupportive(Scenario scenario, WebDriver webDriver, Map<String, String> pf) {
        super(scenario, webDriver, pf);
    }

    @Override
    public void myWork() {

        final String drugCategory = pf.get(MBM.RDCD_WHAT_IS_THE_DRUG_CATEGORY);
        obj().RequestDetailsPage.selectDropdownDrugCategory(drugCategory);

        // Input and select the drug name
        if (pf.containsKey(MBM.RDCD_SUPPORTIVE_DRUG_NAME)) {
            obj().RequestDetailsPage.selectSupportiveDrug(pf.get(MBM.RDCD_SUPPORTIVE_DRUG_NAME));
        }

        // Input the selected drug dosage
        if (pf.containsKey(MBM.RDCD_WHAT_IS_THE_DOSAGE)) {
            obj().RequestDetailsPage.selectDropdownDosage(pf.get(MBM.RDCD_WHAT_IS_THE_DOSAGE));
        }

        // Input the custom regimen justification
        if (pf.containsKey(MBM.RG_TYPE) && pf.get(MBM.RG_TYPE).equals("Custom")) {
            obj().RequestDetailsPage.clickContinueButton();
            Assert.assertTrue(pf.containsKey(MBM.RGID_REGIMEN_JUSTIFICATION_0));
            obj().RequestDetailsPage.inputCustomSupportiveDrugJustification(pf.get(MBM.RGID_REGIMEN_JUSTIFICATION_0));
        }

    }

}
