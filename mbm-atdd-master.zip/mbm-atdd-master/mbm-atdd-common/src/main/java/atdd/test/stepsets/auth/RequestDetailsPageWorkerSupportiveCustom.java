package atdd.test.stepsets.auth;

import atdd.utils.MBM;
import cucumber.api.Scenario;
import org.openqa.selenium.WebDriver;

import java.util.Map;

public class RequestDetailsPageWorkerSupportiveCustom extends RequestDetailsPageWorker {
    public RequestDetailsPageWorkerSupportiveCustom(Scenario scenario, WebDriver webDriver, Map<String, String> pf) {
        super(scenario, webDriver, pf);
    }

    @Override
    public void myWork() {

        obj().RequestDetailsPage.selectDropdownDrugCategory(pf.get(MBM.RDCD_WHAT_IS_THE_DRUG_CATEGORY));

    }

}
