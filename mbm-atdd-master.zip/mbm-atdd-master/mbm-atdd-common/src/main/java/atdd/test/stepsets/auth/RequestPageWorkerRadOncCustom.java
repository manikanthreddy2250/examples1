package atdd.test.stepsets.auth;

import atdd.common.ICondition;
import atdd.common.ImmediateAbortException;
import atdd.test.pageobjects.authorization.RegimensPage;
import atdd.utils.ExcelLib;
import atdd.utils.MBM;
import atdd.utils.MbmUtils;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.Map;

public class RequestPageWorkerRadOncCustom extends RegimensPageWorker {
    public RequestPageWorkerRadOncCustom(Scenario scenario, WebDriver webDriver, Map<String, String> pf) {
        super(scenario, webDriver, pf);
    }

    @Override
    public boolean accept() {
        TestUtils.waitForAngularRequestsToFinish(driver());

        if (ExcelLib.AUTH_TYPE_RADONC.equals(pf.get(MBM.AUTH_AUTHORIZATION_TYPE)) &&
                ExcelLib.CANCER_OTHER.equals(pf.get(MBM.RDCD_PRIMARY_CANCER))) {
            return obj().CommonPage.waitHeader("Custom Request", 30);
        } else {
            return obj().CommonPage.waitHeader("Technique", 30);
        }

    }

    @Override
    public void work() {
        boolean success = TestUtils.clickUntil(driver(), RegimensPage.createCustomRequestLink, new ICondition() {
            public boolean evaluate() throws Exception {
                return obj().CommonPage.verifyHeader("Custom Request");
            }
        });

        if (!success) {
            throw new RuntimeException("Failed: RadOnc Custom Request");
        }
        TestUtils.wait(1);
        addCustomTechnique(RegimensPage.addTechniqueLink);
        obj().RegimensPage.enterRegimenJustification(pf.get(MBM.RGID_REGIMEN_JUSTIFICATION_0));
        if (!obj().RegimensPage.addClinicalDocumentation(pf.get(MBM.RGID_CLINICAL_DOCUMENTATION))) {
            throw new ImmediateAbortException("Upload fail.");

        }
        makeUrgentRadonc();

    }

    @Override
    protected void handOff() {

        obj().RegimensPage.clickContinueButtonInCustomRegimenPage();
         if (pf.get(MBM.USER_TITLE).contains("provider") && ("Yes".equals(pf.get(MBM.RGID_IS_IT_AN_URGENT_REQUEST)))) {
            obj().RegimensPage.PriorityReviewNextStep(pf.get(MBM.RG_PRIORITY_REVIEW_MSG));
        }
        }



    /**
     * Assumption: Custom Regimens page is displayed for radiopharma flow.
     * Input Custom Regimens page according to the profile
     */
    protected void addCustomTechnique(By addTechniqueLink) {
        int techIndex = 0;
        boolean nextTech = pf.containsKey(MBM.TQ_NAME_0);
        Assert.assertTrue("There should be at least one technique.", nextTech);
        while (nextTech) {
            TestUtils.clickUntil(driver(), addTechniqueLink, new ICondition() {
                    @Override
                    public boolean evaluate() throws Exception {
                        if (TestUtils.isElementVisible(driver(), RegimensPage.tehniquecancelLink)) {
                            return true;
                        } else {
                            MbmUtils.immediateRecover(driver());
                            return false;
                        }
                    }
                });

            obj().RegimensPage.selectTechniqueCodeType(pf.get(reIndex(MBM.TQ_TYPE, techIndex)));
            //if Drug code text box is visible enter drug code else getting drug code and doing assert
            if (TestUtils.isElementVisible(driver(), RegimensPage.drugCodeTextBox)) {
                obj().RegimensPage.enterTextInDrugCodeTextBox(pf.get(reIndex(MBM.TQ_CODE_0, techIndex)));
            } else {
                String displayedDrugCode = driver().findElement(RegimensPage.drugCodeValue).getText();
                Assert.assertEquals(pf.get(reIndex(MBM.TQ_CODE_0, techIndex)), displayedDrugCode);
            }
            obj().RegimensPage.selectDrugName(pf.get(reIndex(MBM.TQ_NAME_0, techIndex)));
            obj().RegimensPage.enterTextInUnitsTextBox(pf.get(reIndex(MBM.TQ_UNITS, techIndex)));
            obj().RegimensPage.specialtyPharmaclickAddButton();
            techIndex++;
            nextTech = pf.containsKey(reIndex(MBM.TQ_UNITS, techIndex));
        }
    }

    protected void makeUrgentRadonc() {
        if(pf.get(MBM.USER_TITLE).contains("provider")){
            if ("Yes".equals(pf.get(MBM.RGID_IS_IT_AN_URGENT_REQUEST))) {
                System.out.println("age is >19 or <19 and Yes is selected");
                Assert.assertTrue(TestUtils.isElementVisible(driver(), RegimensPage.urgentRequestCheckbox));
                TestUtils.click(driver(), RegimensPage.urgentRequestCheckbox);
                ;
            }
        }if(!pf.get(MBM.USER_TITLE).contains("provider")){
            if ("Yes".equals(pf.get(MBM.RGID_IS_IT_AN_URGENT_REQUEST))) {
                System.out.println("age is >19 or <19 and Yes is selected");
                Assert.assertTrue(TestUtils.isElementVisible(driver(), RegimensPage.urgentRequestCheckbox));
                TestUtils.clickUntil(driver(), RegimensPage.urgentRequestCheckbox, new ICondition() {
                    @Override
                    public boolean evaluate() throws Exception {
                        return TestUtils.isElementVisible(driver(), RegimensPage.urgentRequestOutcome);
                    }
                });
                String urgentOutcome = pf.get(MBM.RGID_URGENT_REQUEST_OUTCOME);
                obj().RegimensPage.selectUrgentOutcome(urgentOutcome);
            }
            }
        }

    }


