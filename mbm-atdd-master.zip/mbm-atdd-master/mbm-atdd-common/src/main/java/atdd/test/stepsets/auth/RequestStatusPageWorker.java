package atdd.test.stepsets.auth;

import atdd.test.core.PageWorkerCommon;
import atdd.test.pageobjects.authorization.RequestStatusPage;
import atdd.test.stepsets.AuthorizationRequest;
import atdd.utils.Conf;
import atdd.utils.RequestStatusCollector;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.openqa.selenium.WebDriver;

import java.util.List;
import java.util.Map;

public class RequestStatusPageWorker extends PageWorkerCommon {
    public RequestStatusPageWorker(Scenario scenario, WebDriver webDriver, Map<String, String> pf) {
        super(scenario, webDriver, pf);
    }

    @Override
    public boolean accept() {
        TestUtils.waitForAngularRequestsToFinish(driver());
        obj().NavigationPage.closeAnalytics();
        TestUtils.waitForAngularRequestsToFinish(driver());
        return obj().CommonPage.waitHeader("Request Status", 90);
    }

    @Override
    public void work() {
        //request status
        outcome.put(AuthorizationRequest.OUTCOME_PROFILE, this.pf);
        String s = Conf.getInstance().getProperty("stopCollectionOnPages");
        scenarioLogger.warn("stopCollectionOnPages=" + s);
        scenarioLogger.warn("getPageName()=" + getPageName());
        if (null == s || !s.contains(TestUtils.shortName(getPageName()))) {
            try {
                List<String> modes = RequestStatusCollector.getModes(pf);
                outcome.putAll(RequestStatusCollector.collect(-1, driver(), scenario(), modes, pf));
            } catch (Exception e) {
                TestUtils.demoBreakPoint(scenario(), driver(), "Requesting Status page collection issue: " + e.getMessage());
                throw e;
            }
        }
    }


    @Override
    protected void handOff() {
        // do nothing
    }

    @Override
    protected String getPageName() {
        return RequestStatusPage.class.getName();
    }
}
