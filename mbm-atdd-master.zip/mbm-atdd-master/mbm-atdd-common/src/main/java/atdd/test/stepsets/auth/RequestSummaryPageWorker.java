package atdd.test.stepsets.auth;

import atdd.test.core.PageWorkerCommon;
import atdd.test.pageobjects.authorization.RequestSummaryPage;
import atdd.test.stepsets.AuthorizationRequest;
import atdd.utils.*;
import cucumber.api.Scenario;
import org.openqa.selenium.WebDriver;

import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.LinkedHashMap;
import java.util.Map;

public class RequestSummaryPageWorker extends PageWorkerCommon {
    public RequestSummaryPageWorker(Scenario scenario, WebDriver webDriver, Map<String, String> pf) {
        super(scenario, webDriver, pf);
    }

    @Override
    public boolean accept() {
        TestUtils.waitForAngularRequestsToFinish(driver());
        return obj().CommonPage.waitHeader("Request Summary", 90);
    }

    @Override
    public void work() {

        ZonedDateTime now = ZonedDateTime.now();

        //request summary
        Map<String, String> requestSummary = new LinkedHashMap<>();

        //SUBMIT_TIME
        {
            String nowString = ZonedDateUtils.calcFormat(now, 0, ChronoUnit.DAYS, ZonedDateUtils.mmDdYyyyHMmA);
            String nowPlus24HoursString = ZonedDateUtils.calcFormat(now, 1, ChronoUnit.DAYS, ZonedDateUtils.mmDdYyyyHMmA);
            String HHmm = ZonedDateUtils.calcFormat(now, 0, ChronoUnit.DAYS, "HHmm");
            String[] p = nowString.split(" ");
            requestSummary.put(MBM.SUBMIT_DATE, p[0].replace("-", "")); //mmddyyyy
            String ts = p[1].replace(":", "");
            if (3 == ts.length()) {
                ts = "0" + ts;
            }
            requestSummary.put(MBM.SUBMIT_TIMESTAMP, nowString);//MM-dd-yyyy h:mm a
            requestSummary.put(MBM.SUBMIT_TIMESTAMP_PLUS_24_HOURS, nowPlus24HoursString);//MM-dd-yyyy h:mm a
            requestSummary.put(MBM.SUBMIT_TIME, ts);//hhmm
            requestSummary.put(MBM.SUBMIT_TIME_HHmm, HHmm); //HHmm
            requestSummary.put(MBM.SUBMIT_AMPM, p[2]);//PM or AM
        }

        //SUBMIT_TIME_ICUE
        {
            ZonedDateTime icueNow = now.plus(MBM.SUBMIT_TIME_ICUE_OFFSET_HOUR, ChronoUnit.HOURS);
            String nowString = ZonedDateUtils.calcFormat(icueNow, 0, ChronoUnit.DAYS, ZonedDateUtils.mmDdYyyyHMmA);
            String HHmm = ZonedDateUtils.calcFormat(icueNow, 0, ChronoUnit.DAYS, "HHmm");
            String[] p = nowString.split(" ");
            requestSummary.put(MBM.SUBMIT_DATE_ICUE, p[0].replace("-", "")); //mmddyyyy
            String ts = p[1].replace(":", "");
            if (3 == ts.length()) {
                ts = "0" + ts;
            }
            requestSummary.put(MBM.SUBMIT_TIME_ICUE, ts);//hhmm
            requestSummary.put(MBM.SUBMIT_TIME_HHmm_ICUE, HHmm); //HHmm
            requestSummary.put(MBM.SUBMIT_AMPM_ICUE, p[2]);//PM or AM
        }

        String s = Conf.getInstance().getProperty("stopCollectionOnPages");
        scenarioLogger.warn("stopCollectionOnPages=" + s);
        scenarioLogger.warn("getShortPageName()=" + getShortPageName());
        if (null == s || !s.contains(getShortPageName())) {
            logger.warn("Collecting on page: " + getShortPageName());
            requestSummary.putAll(RequestSummaryCollector.collect(driver(), pf));
        } else {
            logger.warn("Stop collecting on page: " + getShortPageName());
        }
        outcome = new LinkedHashMap<>();
        outcome.put(AuthorizationRequest.OUTCOME_REQUEST_SUMMARY, requestSummary);
    }

    @Override
    protected void handOff() {

        obj().RequestSummaryPage.clickSubmitButton();
        TestUtils.wait(10);

    }

    @Override
    protected String getPageName() {
        return RequestSummaryPage.class.getName();
    }
}
