package atdd.test.stepsets.auth;

import atdd.common.ICondition;
import atdd.test.pageobjects.authorization.RequestingProviderPage;
import atdd.test.pageobjects.authorization.RequestingProviderSearchModalPage;
import atdd.utils.MBM;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import java.util.Map;

public class RequestingProviderPageWorker extends AbstractProviderPageWorker {
    public RequestingProviderPageWorker(Scenario scenario, WebDriver webDriver, Map<String, String> pf) {
        super(scenario, webDriver, pf, "rp");
    }

    @Override
    public boolean accept() {
        TestUtils.waitForNotBusy(driver());
        return obj().CommonPage.waitHeader("Requesting Provider", 15);
    }

    @Override
    public void work() {

        //requesting provider
        Assert.assertTrue(TestUtils.clickUntil(driver(),
                RequestingProviderPage.selectaRequestingProvider,
                new ICondition() {
                    @Override
                    public boolean evaluate() throws Exception {
                        if (((pf.get(MBM.AUTH_AUTHORIZATION_TYPE).equals("Speech Therapy")) ||
                                (pf.get(MBM.AUTH_AUTHORIZATION_TYPE).equals("Occupational Therapy")) ||
                                (pf.get(MBM.AUTH_AUTHORIZATION_TYPE).equals("Physical Therapy")))
                                && (pf.get(MBM.USER_TITLE).equals("a PAAN provider"))) {
                            return true;
                        } else if (pf.get(MBM.PAYER).equals("OptumRx")) {
                            TestUtils.click(driver(), RequestingProviderPage.selectaRequestingProvider);
                            return true;
                        }
                        else{
                            return TestUtils.isElementVisible(driver(), RequestingProviderSearchModalPage.searchButton);
                        }
                    }
                }
        ));

        if (!(pf.get(MBM.USER_TITLE).contains("PAAN"))) {
            searchAndSelectProvider();
        }

        obj().RequestingProviderPage.enterTextInProvPhoneNbrTextBox(pf.get(MBM.RPPD_PROVIDER_PHONE_NUMBER));
        obj().RequestingProviderPage.enterTextInProvFaxNbrTextBox(pf.get(MBM.RPPD_PROVIDER_FAX_NUMBER));
        obj().RequestingProviderPage.enterTextInContactNameTextBox(pf.get(MBM.RPPC_FULL_NAME));
        obj().RequestingProviderPage.enterTextInContactPhoneNumberTextBox(pf.get(MBM.RPPC_PHONE_NUMBER));
        obj().RequestingProviderPage.enterTextInContactFaxNumberTextBox(pf.get(MBM.RPPC_FAX_NUMBER));
        if (!pf.get(MBM.USER_TITLE).contains("PAAN") && !pf.get(MBM.USER_TITLE).equals("a bcbs provider")
                && !pf.get(MBM.AUTH_AUTHORIZATION_TYPE).equals("Physical Therapy")
                && !pf.get(MBM.AUTH_AUTHORIZATION_TYPE).equals("Speech Therapy")
                && !pf.get(MBM.AUTH_AUTHORIZATION_TYPE).equals("Occupational Therapy")) {
            obj().RequestingProviderPage.selectRequestReceivedBy(pf.get(MBM.RPPC_REQUEST_RECEIVED_BY));
        }

    }

    @Override
    protected void handOff() {
        TestUtils.wait(2);
        TestUtils.safeClick(driver(), RequestingProviderPage.continueButton);
    }

    @Override
    protected String getPageName() {
        return RequestingProviderPage.class.getName();
    }
}
