package atdd.test.stepsets.auth;

import atdd.common.ImmediateAbortException;
import atdd.test.pageobjects.authorization.ServicingProviderPage;
import atdd.utils.ExcelLib;
import atdd.utils.MBM;
import atdd.utils.StringUtils;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.Map;

public class ServicingProviderPageWorker extends AbstractProviderPageWorker {

    private enum Mode {
        ANY, LIMITED_SUPPLIER, PREFERRED_SUPPLIER
    }

    private Mode mode;

    public ServicingProviderPageWorker(Scenario scenario, WebDriver webDriver, Map<String, String> pf) {
        super(scenario, webDriver, pf, "sp");
    }

    @Override
    public boolean accept() {
        TestUtils.waitForAngularRequestsToFinish(driver());
        boolean accept = TestUtils.waitElementVisible(driver(), "//h2[.='Servicing Provider' or .='Servicing Provider/Pharmacy']", 15)
                || TestUtils.waitElementVisible(driver(), "//h2/span[contains(.,'Servicing Provider') or contains(.,'Servicing Provider/Pharmacy')]", 15);

        if (accept) {
            this.mode = Mode.ANY;
            String payer = pf.get(MBM.PAYER);
            if (TestUtils.isElementVisible(driver(), ServicingProviderPage.selectALimitedSupplierDropdownXpath)) {
                this.mode = Mode.LIMITED_SUPPLIER;
            } else if (payer.equals("BlueCross BlueShield of South Carolina") && pf.get(MBM.AUTH_AUTHORIZATION_TYPE).equalsIgnoreCase("Specialty Pharmacy")
                    && pf.get(MBM.SPPD_PREFERRED_SUPPLIER).equalsIgnoreCase("true")
                    && TestUtils.isElementVisible(driver(), ServicingProviderPage.selectPreferredSupplierRadioButton)) {
                this.mode = Mode.PREFERRED_SUPPLIER;
            } else {
                this.mode = Mode.ANY;
            }
        }

        return accept;
    }

    @Override
    public void work() {
        switch (this.mode) {
            case ANY:
                workForAny();
                break;
            case LIMITED_SUPPLIER:
                workForLimitedSupplier();
                break;
            case PREFERRED_SUPPLIER:
                workForPreferredSupplier();
                break;
            default:
                throw new ImmediateAbortException("Unknown mode: " + this.mode);
        }

    }

    private void workForPreferredSupplier() {
        obj().ServicingProviderPage.clickSelectPreferredSupplierRadioButton();
        TestUtils.wait(5);
        if (TestUtils.isElementVisible(driver(), ServicingProviderPage.selectPreferredSupplierDropdown)) {
            obj().ServicingProviderPage.selectPreferredSupplierFromDropdown();
        } else {
            throw new ImmediateAbortException("Preferred Supplier must be a available for Selected Drug. " + pf.get(MBM.RDCD_SPECIALTY_PHARMA_DRUG_CODE));
        }
    }

    private void workForLimitedSupplier() {
        String providerType = pf.get("spType");
        if (providerType.equalsIgnoreCase("facility")) {
            String facilityName = pf.get(MBM.SPPD_FACILITY_NAME);
            obj().ServicingProviderPage.selectALimitedSupplier(facilityName);
        } else {
            throw new ImmediateAbortException("Limited Supplier must be a facility.");
        }
    }

    private void workForAny() {
        if (pf.containsKey("Clone To Authorization Type")) {
            if (pf.get("Clone To").startsWith("specialtypharma")) {
                //Do nothing
            }
        } else {
            if (isRpSameAsSp(pf)) {
                if (pf.get(MBM.AUTH_AUTHORIZATION_TYPE).equalsIgnoreCase("Specialty Pharmacy")
                        && TestUtils.isElementVisible(driver(), ServicingProviderPage.newDrugSupplierGrid))
                    obj().ServicingProviderPage.clickSameAsTheRequestingProviderRadioButton();
                else
                    obj().ServicingProviderPage.clickYesButton();
                TestUtils.waitElementVisible(driver(), By.xpath("(//span[.='" + pf.get(MBM.RPPD_PROVIDER_NPI) + "'])[1]"));
            } else {
                if (pf.get(MBM.AUTH_AUTHORIZATION_TYPE).equalsIgnoreCase("Specialty Pharmacy")
                        && TestUtils.isElementVisible(driver(), ServicingProviderPage.newDrugSupplierGrid))
                    obj().ServicingProviderPage.clickSearchOtherProviderRadioButton();
                else
                    obj().ServicingProviderPage.clickAddServicingProvider();
                searchAndSelectProvider();
            }
        }
    }

    @Override
    protected void handOff() {
        obj().ServicingProviderPage.clicKContinueButton();
        obj().CommonPage.waitForNOTBusyIndicator();

    }

    @Override
    protected String getPageName() {
        return ServicingProviderPage.class.getName();
    }

    /**
     * checking requesting provider is same as sercvicing provider
     *
     * @param pf
     * @return
     */
    private boolean isRpSameAsSp(Map<String, String> pf) {
        String spTitle = pf.get(MBM.SP_TITLE);
        if (StringUtils.isEmpty(spTitle)) {
            return true;
        }
        String spType = pf.get(MBM.SP_TYPE);
        String rpType = pf.get(MBM.RP_TYPE);
        if (spType.equals(rpType)) {
            if (ExcelLib.RP_TYPE_PHYSICIAN.equals(spType)) {
                String spFn = pf.get(MBM.SPPD_PROVIDER_FIRST_NAME);
                String spLn = pf.get(MBM.SPPD_PROVIDER_LAST_NAME);
                String rpFn = pf.get(MBM.RPPD_PROVIDER_FIRST_NAME);
                String rpLn = pf.get(MBM.RPPD_PROVIDER_LAST_NAME);
                return spFn.equalsIgnoreCase(rpFn) && spLn.equalsIgnoreCase(rpLn);
            } else if (ExcelLib.RP_TYPE_FACILITY.equals(spType)) {
                String spName = pf.get(MBM.SPPD_FACILITY_NAME);
                String rpName = pf.get(MBM.RPPD_FACILITY_NAME);
                return spName.equalsIgnoreCase(rpName);
            } else {
                Assert.fail("No such provider type: " + spType);
            }
        }
        return false;
    }
}
