package atdd.test.stepsets.auth;

import atdd.common.ImmediateAbortException;
import atdd.test.core.PageWorkerBase;
import atdd.test.core.TeamAdd;
import atdd.test.stepsets.LostBrowserException;
import atdd.utils.ExcelLib;
import atdd.utils.MBM;
import cucumber.api.Scenario;

import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;

public class TeamAddRadOncPendingHypoExceeded extends TeamAdd {

    public TeamAddRadOncPendingHypoExceeded(Scenario scenario, Map<String, String> pf) throws ImmediateAbortException, LostBrowserException {
        super(scenario, pf);
    }

    @Override
    protected Queue<PageWorkerBase> buildMyTeam(Map<String, String> pf) {
        LinkedList<PageWorkerBase> workers = new LinkedList<PageWorkerBase>();
        workers.add(new MemberSearchPageWorker(scenario(), driver(), pf));
        workers.add(new AuthorizationTypePageWorker(scenario(), driver(), pf));
        workers.add(new RequestingProviderPageWorker(scenario(), driver(), pf));
        workers.add(new ServicingProviderPageWorker(scenario(), driver(), pf));
        workers.add(new RequestDetailsPageWorkerRadOnc(scenario(), driver(), pf));

        if (!ExcelLib.CANCER_OTHER.equals(pf.get(MBM.RDCD_PRIMARY_CANCER))) {
            workers.add(new ClinicalStatusPageWorker(scenario(), driver(), pf));
        }
        workers.add(new TechniquePageWorkerAutoApprove(scenario(), driver(), pf));
        workers.add(new AdditionalServicesPageWorkerHypoExceeded(scenario(), driver(), pf));
        workers.add(new RequestSummaryPageWorker(scenario(), driver(), pf));
        workers.add(new RequestStatusPageWorker(scenario(), driver(), pf));
        return workers;
    }

}
