package atdd.test.stepsets.auth;

import atdd.common.ImmediateAbortException;
import atdd.test.core.PageWorkerBase;
import atdd.test.core.TeamAdd;
import atdd.test.stepsets.LostBrowserException;
import atdd.utils.DateUtils;
import atdd.utils.MBM;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;

import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;

public class TeamAddSpecialityPharmaSOC extends TeamAdd {

    public TeamAddSpecialityPharmaSOC(Scenario scenario, Map<String, String> pf) throws ImmediateAbortException, LostBrowserException {
        super(scenario, pf);
    }

    @Override
    protected Queue<PageWorkerBase> buildMyTeam(Map<String, String> pf) {
        LinkedList<PageWorkerBase> workers = new LinkedList<PageWorkerBase>();
        workers.add(new MemberSearchPageWorker(scenario(), driver(), pf));
        workers.add(new AuthorizationTypeSpecialtyPharmaPageWorker(scenario(), driver(), pf));
        workers.add(new RequestingProviderPageWorker(scenario(), driver(), pf));
        workers.add(new ServicingProviderPageWorker(scenario(), driver(), pf));
        workers.add(new RequestDetailsPageWorkerSpecialtyPharma(scenario(), driver(), pf));
        workers.add(new ClinicalStatusPageWorker(scenario(), driver(), pf));
        workers.add(new RegimensPageWorkerSpecialtyPharmaCustom(scenario(), driver(), pf));
        workers.add(new RequestSummaryPageWorker(scenario(), driver(), pf));
        workers.add(new RequestStatusPageWorker(scenario(),driver(), pf));


        return workers;
    }


}
