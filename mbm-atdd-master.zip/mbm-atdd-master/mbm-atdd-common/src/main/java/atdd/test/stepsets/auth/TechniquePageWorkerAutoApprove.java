package atdd.test.stepsets.auth;

import atdd.utils.MBM;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.openqa.selenium.WebDriver;

import java.util.Map;

public class TechniquePageWorkerAutoApprove extends RegimensPageWorker {
    public TechniquePageWorkerAutoApprove(Scenario scenario, WebDriver webDriver, Map<String, String> pf) {
        super(scenario, webDriver, pf);
    }

    @Override
    public boolean accept() {
        TestUtils.waitForAngularRequestsToFinish(driver());
        return obj().CommonPage.waitHeader("Technique", 30);
    }

    @Override
    public void work() {
        TestUtils.wait(1);
        obj().TechniquePage.clickSaveDraftButtonTechnique();
        obj().TechniquePage.selectTechniqueRadioButton(pf.get(MBM.TENM_TECHNIQUE_NAME));
        obj().TechniquePage.selectCptcodeTechnique(pf.get(MBM.TENM_CPCT_CODE));
    }


    @Override
    protected void handOff() {
        obj().TechniquePage.clickContinueButtonTechnique();
    }

}
