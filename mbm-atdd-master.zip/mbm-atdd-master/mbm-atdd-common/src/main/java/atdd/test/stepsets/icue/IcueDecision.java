package atdd.test.stepsets.icue;

import atdd.test.core.AbstractStepSet;
import atdd.test.pageobjects.CommonPageObject;
import atdd.utils.Conf;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class IcueDecision extends AbstractStepSet {
    public IcueDecision(Scenario scenario, WebDriver webDriver) {
        super(scenario, webDriver);
    }

    private CommonPageObject obj() {
        return new CommonPageObject(scenario(), driver());
    }

    /**
     * Assumption: ICUE search completed.
     * Approve an authorization from ICUE system.
     */
    public void approve() {
        obj().IcueServiceDecision.showDecisions(1);
        obj().IcueServiceDecision.selectDecisionOutcomeType("Covered/Approved");
        obj().IcueServiceDecision.selectDecisionSubType("2 - Clinical");
        obj().IcueServiceDecision.selectDecisionReasonType("31 - Treatment is consistent with published clinical evidence");
        obj().IcueServiceDecision.selectDecisionSourceType1SRC("CMS");
        this.saveServiceDecisionWithReason("AS - Authorized Service");

        this.closeWithReason("Managed and Complete");

    }

    /**
     * Assumption: ICUE search completed.
     * Deny an authorization from ICUE system.
     */
    public void deny() {
        obj().IcueServiceDecision.showDecisions(1);
        obj().IcueServiceDecision.selectDecisionOutcomeType("Not Covered/Not Appr");
        obj().IcueServiceDecision.selectDecisionSubType("2 - Clinical");
        obj().IcueServiceDecision.selectDecisionReasonType("58 - Services are not covered due to specific exclusions or limitations in member's benefit document");
        obj().IcueServiceDecision.selectDecisionSourceType1SRC("CMS");
        obj().IcueServiceDecision.inputDecisionSourceComment("Test Deny Comment");
        this.saveServiceDecisionWithReason("SS - Special Sit Cmt Req");

        obj().Icue.clickTabOnNotificationPage("6. Cont&Act");

        String dt = Conf.getInstance().getProperty("yesterday").replace("-", "");
        String tm = "103000";

        // Activity Type 1: Decision Communication
        obj().IcueContAndAct.inputActivityType("Decision Communication");
        obj().IcueContAndAct.inputActivityResolutionOutcomeType("Coverage determination");
        obj().IcueContAndAct.inputCommunicationDateTimeCOMM(dt);
        obj().IcueContAndAct.inputTIME_communicationDateTimeCOMM(tm);
        obj().IcueContAndAct.clickServiceSeqNum1();
        obj().IcueContAndAct.performAction(scenario(), "Save");

        // Activity Type 2: Manual Letter Sent
        obj().IcueContAndAct.inputActivityType("Manual Letter Sent");
        obj().IcueContAndAct.inputActivityResolutionOutcomeType("Coverage Determination- Denial Letter");
        obj().IcueContAndAct.inputCommunicationDateTimeCOMM(dt);
        obj().IcueContAndAct.inputTIME_communicationDateTimeCOMM(tm);
        obj().IcueContAndAct.clickServiceSeqNum1();
        obj().IcueContAndAct.performAction(scenario(), "Save");

        // Activity Type 3: Decision Communication
        obj().IcueContAndAct.inputActivityType("Decision Communication");
        obj().IcueContAndAct.inputActivityResolutionOutcomeType("Coverage determination");
        obj().IcueContAndAct.selectChannelSourceTypeCOMM("OCM MBM CGP");
        obj().IcueContAndAct.selectCommunicationTypeCOMM("Outbound");
        obj().IcueContAndAct.selectContactRoleTypeCOMM("Servicing Provider");
        obj().IcueContAndAct.inputCommunicationDateTimeCOMM(dt);
        obj().IcueContAndAct.inputTIME_communicationDateTimeCOMM(tm);
        obj().IcueContAndAct.clickServiceSeqNum1();
        obj().IcueContAndAct.performAction(scenario(), "Save");

        this.closeWithReason("Managed and Complete");

    }

    /**
     * Assumption: ICUE search completed.
     * Cancel an authorization from ICUE system.
     */
    public void cancel() {
        obj().IcueServiceDecision.showDecisions(1);
        obj().IcueServiceDecision.selectDecisionOutcomeType("Cancelled");
        obj().IcueServiceDecision.selectDecisionSubType("2 - Clinical");
        obj().IcueServiceDecision.selectDecisionReasonType("73 - Entered on wrong member");
        obj().IcueServiceDecision.selectDecisionSourceType1SRC("CMS");
        obj().IcueServiceDecision.inputDecisionSourceComment("Test Deny Comment");
        obj().IcueServiceDecision.performAction(scenario(), "Save");
        driver().switchTo().alert().accept();

        this.validateNotificationTabStatus("Cancelled");

    }


    private void closeWithReason(String s) {
        obj().Icue.clickTabOnNotificationPage("1. Notification");
        //Click on Continue Action in "navigating away" pop-up
        obj().Icue.tryClickContinueAction();
        obj().IcueNotification.performAction(scenario(), "Close HSC");
        obj().IcueNotification.selectHscStatusReasonType(s);
        obj().IcueNotification.performAction(scenario(), "Close HSC");

        this.validateNotificationTabStatus("Closed");
    }

    private void validateNotificationTabStatus(String expectedStatus) {
        obj().Icue.clickTabOnNotificationPage("1. Notification");
        TestUtils.demoBreakPoint(scenario(), driver(), "Validate Notification Tab Status: " + expectedStatus);
        String hscStatus = TestUtils.text(driver(), By.xpath("//td[.='HSC Status:']/following-sibling::td[1]")).trim();
        Assert.assertEquals(expectedStatus, hscStatus);
    }

    private void saveServiceDecisionWithReason(String s) {
        obj().IcueServiceDecision.performAction(scenario(), "Save");
        if (TestUtils.isElementVisible(this.driver(), By.xpath("//span[.='2. Override Claim Remark Code ']"))) {
            obj().IcueServiceDecision.selectOverrideClaimRemarkCode(s);
            obj().IcueServiceDecision.inputClaimComments("Test Deny Comment");
            obj().IcueServiceDecision.performAction(scenario(), "Override Claim Remark Code");
        }
    }

    /**
     * Assumption: ICUE search completed.
     * underAppeals an authorization from ICUE system.
     */
    public void underAppeals() {
        this.deny();
        obj().Icue.clickTabOnNotificationPage("1. Notification");
        //Click on Continue Action in "navigating away" pop-up
        obj().Icue.tryClickContinueAction();
        obj().IcueNotification.performAction(scenario(), "Re-Open HSC");
        obj().IcueNotification.selectHscStatusReasonType("Pre-Service Appeal");
        obj().IcueNotification.performAction(scenario(), "Re-Open HSC");
        this.validateNotificationTabStatus("Open");


    }

    /**
     * Assumption: ICUE search completed.
     * underAppeals an authorization from ICUE system.
     */
    public void reconsideration() {
        this.deny();
        obj().Icue.clickTabOnNotificationPage("1. Notification");
        //Click on Continue Action in "navigating away" pop-up
        obj().Icue.tryClickContinueAction();
        obj().IcueNotification.performAction(scenario(), "Re-Open HSC");
        obj().IcueNotification.selectHscStatusReasonType("Reconsideration");
        obj().IcueNotification.performAction(scenario(), "Re-Open HSC");
        this.validateNotificationTabStatus("Open");


    }

    public void overridingApprovedToDenied() {
        obj().IcueServiceDecision.showDecisions(1);
        obj().IcueServiceDecision.performAction(scenario(), "Override Decision");
        obj().IcueServiceDecision.selectDecisionOutcomeType("Not Covered/Not Appr");
        obj().IcueServiceDecision.selectDecisionSubType("2 - Clinical");
        obj().IcueServiceDecision.selectDecisionReasonType("58 - Services are not covered due to specific exclusions or limitations in member's benefit document");
        obj().IcueServiceDecision.selectDecisionSourceType1SRC("CMS");
        obj().IcueServiceDecision.inputDecisionSourceComment("Test Deny Comment");
        this.saveServiceDecisionWithReason("SS - Special Sit Cmt Req");

    }
}
