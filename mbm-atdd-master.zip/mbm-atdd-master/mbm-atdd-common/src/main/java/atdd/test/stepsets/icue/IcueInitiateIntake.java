package atdd.test.stepsets.icue;


import atdd.common.Retry;
import atdd.test.core.AbstractStepSet;
import atdd.test.pageobjects.CommonPageObject;
import atdd.utils.MBM;
import atdd.utils.TestUtils;
import atdd.utils.WhiteBoard;
import cucumber.api.Scenario;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.Map;

public class IcueInitiateIntake extends AbstractStepSet {
    public IcueInitiateIntake(Scenario scenario, WebDriver webDriver) {
        super(scenario, webDriver);
    }

    private CommonPageObject obj() {
        return new CommonPageObject(scenario(), driver());
    }

    /**
     * Assumption: ICUE login completed.
     * Initiate HSC intake in ICUE system.
     */
    public void initiateIntake(Map<String, String> pf) {
        boolean success = new Retry("initiateIntake") {

            @Override
            protected void tryOnce() {

                String subscriberId = pf.get(MBM.MEMB_SUBSCRIBER_ID);

                obj().Icue.clickNavdropDown("Home");
                obj().Icue.selectNavdropDownOption("Initiate HSC Intake");
                obj().Icue.tryClickContinueAction();

                Assert.assertTrue("User is not on correct ICUE page", driver().getTitle().contains("Initiate HSC Intake"));
                obj().IcueInitiateHSCIntake.selectSource("CareCore");
                obj().IcueInitiateHSCIntake.selectCommunicationDate();
                obj().IcueInitiateHSCIntake.selectServiceSetting("Outpatient");
                obj().IcueInitiateHSCIntake.selectServiceStartDate();

                obj().IcueInitiateHSCIntake.searchByMemberId(subscriberId);

                TestUtils.demoBreakPoint(scenario(), driver(), "Initiate HSC Intake");
            }

            @Override
            protected long getTimeoutMillis() {
                return 5 * 60 * 1000;
            }

        }.execute();
        obj().IcueNotification.performAction(scenario(), "Next");
        Assert.assertTrue("Initiate Intake is not successful.", success);
    }


    public void shortForm(Map<String, String> pf) {
        boolean success = new Retry("shortForm") {

            @Override
            protected void tryOnce() {
                String taxId = pf.get(MBM.RPPD_PROVIDER_TIN);
                String providerLastName = pf.get(MBM.RPPD_PROVIDER_LAST_NAME);

                Assert.assertTrue("User is not on Short Form ICUE page", driver().getTitle().contains("Short Form"));
                obj().IcueIntakeShortForm.selectPlaceOfService("Office");
                obj().IcueIntakeShortForm.selectServiceDescription("Scheduled");
                obj().IcueIntakeShortForm.selectServiceDetail("Infusion Services");
                if (pf.get(MBM.MEMB_TYPE).equals("C&S")) {
                    obj().IcueIntakeShortForm.selectSubcategory("Medical");
                }
                obj().IcueIntakeShortForm.enterTaxIdNum(taxId);
                obj().IcueIntakeShortForm.providerIndicator();
                obj().IcueIntakeShortForm.searchTin(providerLastName);

                TestUtils.demoBreakPoint(scenario(), driver(), "HSC Intake short form");
            }

            @Override
            protected long getTimeoutMillis() {
                return 5 * 60 * 1000;
            }

        }.execute();

        obj().IcueNotification.performAction(scenario(), "Next");
        Assert.assertTrue("Short Form is not successful", success);

        this.potentialDuplicates();

        this.shortFormCleanUp();

    }


    public Map<String, String> longForm(String jcode) {
        //setVendorCaseID
        Assert.assertTrue("User is not on Notification ICUE page with Vendor ID", driver().getTitle().contains("Notification"));
        String vendorCaseID = WhiteBoard.resolve(null, "ONF" + "${random10}");
        obj().IcueIntakeLongForm.setVendorCaseId(vendorCaseID);
        obj().IcueNotification.performAction(scenario(), "Next");

        //Set Primary Diagnosis
        Assert.assertTrue("User is not on correct Diagnosis ICUE page", driver().getTitle().contains("Diagnoses"));
        obj().IcueIntakeLongForm.setPrimaryDiagnosis("C00.4");
        obj().IcueNotification.performAction(scenario(), "Next");

        //Continue past Providers Page
        Assert.assertTrue("User is not on correct Provider ICUE page", driver().getTitle().contains("Providers"));
        obj().IcueNotification.performAction(scenario(), "Next");

        //Services
        Assert.assertTrue("User is not on correct Services ICUE page", driver().getTitle().contains("Services"));
        obj().IcueIntakeLongForm.setProcedureTypeCode("HCPCS", jcode);
        obj().IcueIntakeLongForm.setProcedureTotal("1");
        obj().IcueIntakeLongForm.setProcedureCount("1");
        obj().IcueIntakeLongForm.setProcedureFrequency("Time(s)");
        return this.completeIntake();
    }


    public void potentialDuplicates() {
        if (driver().getTitle().contains("Potential Duplicates")) {
            obj().IcueNotification.performAction(scenario(), "Next");
        }
    }

    public void shortFormCleanUp() {
        if (driver().getTitle().contains("Short Form Clean Up")) {
            if (TestUtils.isElementVisible(driver(), By.xpath("//*[@id='error'][contains(text(),'Alternate Fax')]"))) {
                obj().IcueIntakeShortForm.manualLetterOption();
            }

            if (TestUtils.isElementVisible(driver(), By.xpath("//*[@id='error'][contains(text(),'Steerage')]"))) {
                obj().IcueIntakeShortForm.networkSteerageOption();
            }
            obj().IcueNotification.performAction(scenario(), "Complete CleanUp");
        }
    }

    public Map<String, String> completeIntake() {
        obj().IcueNotification.performAction(scenario(), "Complete Intake");
        Assert.assertTrue("User is not on correct ICUE page", driver().getTitle().contains("Complete"));
        Map<String, String> authNumICUE = obj().IcueNotification.storeIcueSRN();
        obj().IcueNotification.performAction(scenario(), "Save");
        return authNumICUE;
    }


    public Map<String, String> getOutcome(String page) {

        Map<String, String> icueSummary = null;
        switch (page) {
            case "Notification":
                obj().Icue.clickTabOnNotificationPage("1. Notification");
                icueSummary = obj().IcueNotification.storeIcueSRN();
                break;
            case "Services":
                obj().Icue.clickTabOnNotificationPage("4. Services");
                icueSummary = obj().IcueService.storeIcueServiceInfo();
                break;
            default:
                Assert.fail("Invalid page: " + page);
        }

        return icueSummary;
    }
}
