package atdd.test.stepsets.icue;

import atdd.test.core.AbstractStepSet;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.pageobjects.icue.Icue;
import atdd.utils.TestUtils;
import cucumber.api.Scenario;
import org.openqa.selenium.WebDriver;

public class IcueSearch extends AbstractStepSet {
    public IcueSearch(Scenario scenario, WebDriver webDriver) {
        super(scenario, webDriver);
    }

    private CommonPageObject obj() {
        return new CommonPageObject(scenario(), driver());
    }

    /**
     * Assumption: ICUE login completed.
     * Search an authorization from ICUE system.
     */
    public void search(String authNumber) {
        obj().Icue.clickNavdropDown("Search");
        obj().Icue.selectNavdropDownOption("Health Service Case");
        obj().Icue.tryClickContinueAction();

        obj().Icue.enterVendorCaseId(authNumber);
        obj().Icue.clickSearchHealthService();
        TestUtils.wait(3);
        TestUtils.waitElementVisible(driver(), Icue.notificationTabLink);
        TestUtils.demoBreakPoint(scenario(), driver(), "Search Health Service Case " + authNumber);
    }
}
