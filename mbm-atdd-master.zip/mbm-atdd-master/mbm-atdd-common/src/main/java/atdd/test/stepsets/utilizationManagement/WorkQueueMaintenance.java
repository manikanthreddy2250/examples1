package atdd.test.stepsets.utilizationManagement;

import atdd.test.core.AbstractStepSet;
import atdd.test.pageobjects.CommonPageObject;
import atdd.test.pageobjects.NavigationPage;
import atdd.test.pageobjects.utilizationManagement.AddWorkQueuePage;
import atdd.test.pageobjects.utilizationManagement.WorkQueueMaintenancePage;
import cucumber.api.Scenario;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class WorkQueueMaintenance extends AbstractStepSet {
    private CommonPageObject obj() {
        return new CommonPageObject(scenario(), driver());
    }

    private static Logger log = Logger.getLogger(AddWorkQueuePage.class);
    private NavigationPage np = obj().NavigationPage;
    private WorkQueueMaintenancePage wqmp = obj().WorkQueueMaintenancePage;
    private AddWorkQueuePage awqp = obj().AddWorkQueuePage;


    public WorkQueueMaintenance(Scenario scenario, WebDriver webDriver) {
        super(scenario, webDriver);
    }


    /*
     * Assumption: User already logged in and navigates to Work Queue
     * and adds a work queue according to
     * the provided details
     * @param name, description, status
     * */
    public void addWorkQueue(String name, String description, String status) {
        if (!driver().getTitle().contains("Work Queue Maintenance")) {
            np.expandClickPrimaryNav("Tools");
            np.clickOptionFromTopNavMenu("Work Queue Maintenance");
            obj().CommonPage.waitForNOTBusyIndicator();
        }
        wqmp.validateBreadcrum();
        //click on add work queue
        wqmp.clickOnAddWorkQueue();
        //add detail for work queue
        awqp.enterDetailsToAddWorkQueue(name, description, status);
        awqp.clickSaveButton();

//        TestUtils.wait(3);
//
//        WorkQueueDao workQueueDao = new WorkQueueDao(MyBatisConnectionFactoryWorkflow.getSqlSessionFactory());
//        List<Map<String, Object>> queues = workQueueDao.selectByWorkQueueName(name);
//        Assert.assertTrue("Unable to add Work Queue " + name, null != queues && 1 == queues.size());
    }

    /*
     * Assumption: User already logged in and navigates to Work Queue
     * and  validates header
     * @param expectedValue
     * */
    public void validateAddedWorkQueue(List<String> expectedValue) {
        if (!driver().getTitle().contains("Work Queue Maintenance")) {
            np.expandClickPrimaryNav("Tools");
            np.clickOptionFromTopNavMenu("Work Queue Maintenance");
            obj().CommonPage.waitForNOTBusyIndicator();
        }
        wqmp.validateBreadcrum();
        wqmp.tablePageNavigation("last");
        List<String> actualValue = wqmp.getLastRecordOnWorkQueuePage();
        //validate the expected with actual
        for (int i = 0; i < expectedValue.size(); i++) {
            Assert.assertTrue("Actual and Expected value at " + i + " doesnot match", actualValue.get(i).equalsIgnoreCase(expectedValue.get(i)));
        }
    }

    /*
     * Assumption: User already logged in and navigates to Work Queue
     * and  validates header
     * @param expectedHeader
     * */
    public void validateWorkQueueTableHeader(List expectedHeader) {
        if (!driver().getTitle().contains("Work Queue Maintenance")) {
            np.expandClickPrimaryNav("Tools");
            np.clickOptionFromTopNavMenu("Work Queue Maintenance");
            obj().CommonPage.waitForNOTBusyIndicator();
        }
        wqmp.validateBreadcrum();
        //validate work queue header
        wqmp.validateTableHeader(expectedHeader);
    }

    /*
     * Assumption: User already logged in and navigates to Work Queue
     * and validates records per page dropdown
     * @param defaultValue, dropDownOptions
     * */
    public void validatePaginationHeader(String defaultValue, List dropDownOptions) {
        if (!driver().getTitle().contains("Work Queue Maintenance")) {
            np.expandClickPrimaryNav("Tools");
            np.clickOptionFromTopNavMenu("Work Queue Maintenance");
            obj().CommonPage.waitForNOTBusyIndicator();
        }
        wqmp.validateBreadcrum();
        //validate records per page dropdown
        wqmp.validateRecordsPerPageDropDown(defaultValue, dropDownOptions);
    }

    public void editWorkQueueAndValidateOnTable() {
        if (!driver().getTitle().contains("Work Queue Maintenance")) {
            np.expandClickPrimaryNav("Tools");
            np.clickOptionFromTopNavMenu("Work Queue Maintenance");
        }
        //navigate to last page
        wqmp.tablePageNavigation("last");
        //get the last record on UI list (lastValueOnTable)
        List<String> lastValueOnTable = wqmp.getLastRecordOnWorkQueuePage();
        log.warn("Values on Table " + lastValueOnTable);
        //click on edit last edit icon
        wqmp.clickOnLastEditIcon();
        //get the attribute values from edit work queue(List valueOnEditWorkQueue)
        List<String> valueOnEditWorkQueue = awqp.getAttributesWorkQueue();
        log.warn("Value on edit work queue " + valueOnEditWorkQueue);
        //generate a new value to edit and keep in List<String> expectedValue
        List<String> expectedValue = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            expectedValue.add(valueOnEditWorkQueue.get(i) + "Testing");
        }
        expectedValue.add(valueOnEditWorkQueue.get(2));
        log.warn("Expected value on " + expectedValue);
        //enter the expected value in work queue and save
        awqp.editWorkQueue(expectedValue);
        //get the last record on UI list (lastValueOnTable)
        List<String> actualValue = wqmp.getLastRecordOnWorkQueuePage();
        log.warn("New value on Table " + actualValue);
        //validate the expectedValue and actualValue
        for (String value : expectedValue) {
            log.warn("Validating " + expectedValue + "==" + actualValue);
            Assert.assertTrue("Value at doesnot match", expectedValue.equals(actualValue));
        }
    }

    /*Assumption: User already logged in to MBM, navigates to
     * Add work queue and validates the error message
     * @param errorMessage
     * */
    public void navigateToWorkQueueValidateErrorMessage(String errorMessage) {
        if (!driver().getTitle().contains("Work Queue Maintenance")) {
            np.expandClickPrimaryNav("Tools");
            np.clickOptionFromTopNavMenu("Work Queue Maintenance");
        }
        //validate error message on add work queue
        wqmp.clickOnAddWorkQueue();
        awqp.validateErrorMessage(errorMessage);
        //validate error message on edit work queue
        awqp.closeAddWorkQueueModal();
        wqmp.clickOnLastEditIcon();
        awqp.clearEditWorkQueue();
        awqp.validateErrorMessage(errorMessage);
    }

    /*
     * User search for an entry and validates the table content
     * */
    public void validateSearchFunctionality(HashMap<String, String> maps) {
        wqmp.searchWorkQueue(maps);
        wqmp.validateTable(maps);

    }
}
