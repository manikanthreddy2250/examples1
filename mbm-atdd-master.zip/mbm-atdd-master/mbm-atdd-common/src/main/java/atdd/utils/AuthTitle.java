package atdd.utils;

import java.util.Map;


public class AuthTitle {

    /**
     * Make suggestion of AUTH_AUTHORIZATION_TYPE based on the profile
     *
     * @param pf
     * @return
     */
    public static String suggestTitle(Map<String, String> pf) {
        if (pf.containsKey(MBM.AUTH_AUTHORIZATION_TYPE)) {
            switch (pf.get(MBM.AUTH_AUTHORIZATION_TYPE)) {
                case ExcelLib.AUTH_TYPE_CHEMO:
                    return chemoProfileTitle(pf);
                case ExcelLib.AUTH_TYPE_SUPP:
                    return suppProfileTitle(pf);
                case ExcelLib.AUTH_TYPE_RADIO:
                    return radioProfileTitle(pf);
                case ExcelLib.AUTH_TYPE_SPECIALTY_PHARMA:
                    return specialtyPharmaProfileTitle(pf);
                default:
                    throw new RuntimeException("Unknown authorization type:" + pf.get(MBM.AUTH_AUTHORIZATION_TYPE));
            }
        } else {
            return ExcelLib.TITLE_DEFAULT;
        }
    }


    private static String radioProfileTitle(Map<String, String> pf) {
        return "radiopharma radium approved profile";
    }

    private static String suppProfileTitle(Map<String, String> pf) {
        String drugType = pf.get(MBM.RDCD_SUPPORTIVE_DRUG_NAME);
        String rgType = pf.get(MBM.RG_TYPE);
        if (CsqaSupportive.DRUG_TYPE_WHITE_BLOOD_CELL_GROWTH_FACTORS.equals(drugType)) {
            if (ExcelLib.RG_TYPE_CUSTOM.equals(rgType)) {
                return "supportive GF custom profile";
            } else if (ExcelLib.RG_TYPE_AUTO_APPROVE.equals(rgType)) {
                return "supportive GF approved profile";
            } else {
                return "supportive GF approved profile";
            }

        } else {
            if (ExcelLib.RG_TYPE_CUSTOM.equals(rgType)) {
                return "supportive custom profile";
            } else if (ExcelLib.RG_TYPE_AUTO_APPROVE.equals(rgType)) {
                return "supportive approved profile";
            } else {
                return "supportive approved profile";
            }
        }
    }

    private static String chemoProfileTitle(Map<String, String> pf) {
        String rgType = pf.get(MBM.RG_TYPE);
        if (ExcelLib.RG_TYPE_CUSTOM.equals(rgType)) {
            return "chemo custom profile";
        } else if (ExcelLib.RG_TYPE_AUTO_APPROVE.equals(rgType)) {
            return "chemo approved profile";
        } else {
            return "chemo approved profile";
        }
    }

    private static String specialtyPharmaProfileTitle(Map<String, String> pf) {
        return "specialtypharma custom profile";
    }
}
