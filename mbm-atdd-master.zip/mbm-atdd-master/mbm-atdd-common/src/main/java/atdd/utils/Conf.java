package atdd.utils;


public class Conf extends ConfBase {
    private static ConfBase instance = new Conf();

    private Conf() {
        super("mbm-atdd-common", "config", "common_config");

        loadTunnelProperties(DATA);
    }

    public static ConfBase getInstance() {
        return instance;
    }
}
