package atdd.utils;

import java.util.LinkedHashMap;
import java.util.Map;


/**
 * Make suggestion for Chemo CSQA's
 */
public class CsqaChemo {

    /**
     * Make suggestion for Chemo CSQA's based on Cancer
     * @param cancer
     * @return
     */
    public static Map<String, String> suggestCsqasByCancer(String cancer) {
        Map<String, String> result = new LinkedHashMap<>();

        switch (cancer) {
            case ExcelLib.CANCER_PROSTATE_CANCER:
                result.put(MBM.CSQA_WHAT_IS_THE_HISTOLOGY, "Adenocarcinoma");
                result.put(MBM.CSQA_WHAT_WHAT_WAS_THE_STAGE_AT_INITIAL_DIAGNOSIS, "Stage I");
                result.put(MBM.CSQA_WHAT_IS_THE_TREATMENT_INDICATION_OR_DISEASE_STATUS, "Adjuvant");
                result.put(MBM.CSQA_WHAT_IS_THE_MMR_MSI_STATUS, "High/Deficient");
                result.put(MBM.CSQA_WHAT_IS_THE_LINE_OF_THERAPY, "Initial");
                return result;
            case ExcelLib.CANCER_ANAL_CARCINOMA:
                result.put(MBM.CSQA_WHAT_WHAT_WAS_THE_STAGE_AT_INITIAL_DIAGNOSIS, "Stage I");
                result.put(MBM.CSQA_WHAT_IS_THE_TREATMENT_INDICATION_OR_DISEASE_STATUS, "Localized");
                result.put(MBM.CSQA_WHAT_IS_THE_LINE_OF_THERAPY, "Initial therapy with radiation");
                return result;
            case ExcelLib.CANCER_BREAST_CANCER:
                result.put(MBM.CSQA_WHAT_IS_THE_HISTOLOGY, "Ductal");
                result.put(MBM.CSQA_WHAT_WHAT_WAS_THE_STAGE_AT_INITIAL_DIAGNOSIS, "Stage II");
                result.put(MBM.CSQA_WHAT_IS_THE_TREATMENT_INDICATION_OR_DISEASE_STATUS, "Neoadjuvant");
                result.put(MBM.CSQA_WHAT_IS_THE_HER2_STATUS, "Negative");
                result.put(MBM.CSQA_WHAT_IS_THE_ER_PR_STATUS, "Positive");
                result.put(MBM.CSQA_WHAT_IS_THE_PDL1_EXPRESSION_STATUS, "Positive");
                result.put(MBM.CSQA_WHAT_IS_THE_BRCA_1_2_STATUS, "Positive");
                result.put(MBM.CSQA_WHAT_IS_THE_LINE_OF_THERAPY, "1");
                result.put(MBM.RG_INDEX, "3");
                return result;
            case ExcelLib.CANCER_COLON_CANCER:
                result.put(MBM.CSQA_WHAT_WHAT_WAS_THE_STAGE_AT_INITIAL_DIAGNOSIS, "Stage III");
                result.put(MBM.CSQA_WHAT_IS_THE_TREATMENT_INDICATION_OR_DISEASE_STATUS, "Adjuvant");
                result.put(MBM.CSQA_WHAT_IS_THE_KRAS_NRAS_STATUS, "Positive");
                result.put(MBM.CSQA_WHAT_IS_THE_MSI_MMR_STATUS, "High/Deficient");
                result.put(MBM.CSQA_WHAT_IS_THE_BRAF_V600E_Mutation_Status, "Positive");
                result.put(MBM.CSQA_WHAT_IS_THE_LINE_OF_THERAPY, "Initial");
                result.put(MBM.CSQA_Previous_adjuvant_FOLFOX_CAPEOX_within_past_12_months,"No");
                return result;
            case ExcelLib.CANCER_OTHER:
                return result;
            case ExcelLib.CANCER_T_Cell_Lymphomas_CANCER:
                result.put(MBM.CSQA_WHAT_IS_THE_HISTOLOGY, "Adult T-Cell Leukemia/Lymphoma (ATLL)");
                result.put(MBM.CSQA_WHAT_IS_THE_CANCER_SUBTYPE, "T Cell Lymphoma");
                result.put(MBM.CSQA_WHAT_WHAT_WAS_THE_STAGE_AT_INITIAL_DIAGNOSIS, "Stage I");
                result.put(MBM.CSQA_WHAT_IS_THE_TREATMENT_INDICATION_OR_DISEASE_STATUS, "Initial");
                result.put(MBM.CSQA_WHAT_IS_THE_CD30_STATUS, "Negative");
                result.put(MBM.CSQA_WHAT_IS_THE_ALK_REARRANGEMENT_STATUS, "Positive");
                result.put(MBM.CSQA_Is_THERE_A_PALN_FOR_TRANSPLANT, "No");
                result.put(MBM.CSQA_WHAT_IS_THE_LINE_OF_THERAPY, "1");
            return result;

            case ExcelLib.CANCER_THYMOMAS_and_THYMIC_CARCINOMAS_CANCER:
                result.put(MBM.CSQA_WHAT_IS_THE_HISTOLOGY, "Thymic Carcinoma");
                result.put(MBM.CSQA_WHAT_IS_THE_TREATMENT_INDICATION_OR_DISEASE_STATUS, "Recurrent Disease");
                result.put(MBM.CSQA_WHAT_IS_THE_LINE_OF_THERAPY, "2nd line");
                return result;
            case ExcelLib.CANCER_MYELODSPLASTIC_SYNDROMES:
                result.put(MBM.CSQA_WHAT_IS_THE_HISTOLOGY, "Lower Risk");
                result.put(MBM.CSQA_WHAT_IS_THE_TREATMENT_INDICATION_OR_DISEASE_STATUS, "Neutropenia, Increased Marrow Blasts");
                result.put(MBM.CSQA_WHAT_IS_THE_EPO_STATUS, "Epo Greater Than 500");
                result.put(MBM.CSQA_IS_DEL_5Q_PRESENT, "Yes");
                result.put(MBM.CSQA_WHAT_IS_THE_LINE_OF_THERAPY, "1");
                return result;

            default:
                return null;
        }
    }
}
