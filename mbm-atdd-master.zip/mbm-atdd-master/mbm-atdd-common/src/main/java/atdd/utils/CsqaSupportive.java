package atdd.utils;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Make suggestion for Supportive CSQA's
 */
public class CsqaSupportive {

    public static final String DRUG_TYPE_DENOSUMAB_PROLIA = "Denosumab (Prolia)";
    public static final String DRUG_TYPE_DENOSUMAB_XGEVA = "Denosumab (Xgeva)";
    public static final String DRUG_TYPE_WHITE_BLOOD_CELL_GROWTH_FACTORS = "White Blood Cell Growth Factors";

    /**
     * Make suggestion for Supportive CSQA's based on drug type and regimens type (AutoApproved or Custom)
     */
    public static Map<String, String> suggestCsqasByDrugType(String dtDrugType, String dtRgType) {
        Map<String, String> result = new LinkedHashMap<>();

        if (ExcelLib.RG_TYPE_CUSTOM.equals(dtRgType)) {
            if (dtDrugType.equals(DRUG_TYPE_DENOSUMAB_XGEVA)) {
                result.put(MBM.CSQA_SELECT_DIAGNOSIS, "Other cancer type");
            } else if (dtDrugType.equals(DRUG_TYPE_WHITE_BLOOD_CELL_GROWTH_FACTORS)) {
                result.put(MBM.CSQA_WHAT_IS_THE_INDICATION, "Myelodysplastic syndrome");
                result.put(MBM.CSQA_IS_THE_ABSOLUTE_ENEUTROPHIL_COUNT_500, "No");
            }
            return result;
        } else if (ExcelLib.RG_TYPE_AUTO_APPROVE.equals(dtRgType)) {
            if (dtDrugType.equals(DRUG_TYPE_DENOSUMAB_XGEVA)) {
                result.put(MBM.CSQA_SELECT_DIAGNOSIS, "Multiple Myeloma");
                result.put(MBM.CSQA_I_ATTEST_THAT, "Yes");
            } else if (dtDrugType.equals(DRUG_TYPE_WHITE_BLOOD_CELL_GROWTH_FACTORS)) {
                result.put(MBM.CSQA_WHAT_IS_THE_INDICATION, "Myelodysplastic syndrome");
                result.put(MBM.CSQA_IS_THE_ABSOLUTE_ENEUTROPHIL_COUNT_500, "Yes");
            }
            return result;
        }

        return null;
    }
}
