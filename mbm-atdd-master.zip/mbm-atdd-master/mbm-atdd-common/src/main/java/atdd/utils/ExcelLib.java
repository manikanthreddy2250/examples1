package atdd.utils;

import org.apache.log4j.Logger;
import org.junit.Assert;

import java.io.File;
import java.util.*;

public abstract class ExcelLib {
    private static final Logger log = Logger.getLogger(ExcelLib.class.getName());

    // the profile keys
    public static final String THE_USER = "theUser";
    public static final String THE_MEMBER = "theMember";
    public static final String THE_REQUESTING_PROVIDER = "theRequestingProvider";
    public static final String THE_SERVICING_PROVIDER = "theServicingProvider";
    public static final String THE_AUTH_PROFILE = "theAuthProfile";
    public static final String THE_PAAN_PROVIDER = "thePaanProvider";

    public static final String TITLE_DEFAULT = "default";

    //user options
    public static final String LIB_USER = "LIB_USER";
    public static final String USER_LOGIN_METHOD_SSO = "SSO";
    public static final String USER_LOGIN_METHOD_PAAN = "PAAN";
    public static final String USER_LOGIN_METHOD_ICUE = "ICUE";

    //paan provider options
    public static final String LIB_PP = "LIB_PP";
    public static final String PP_TYPE_PHYSICIAN = "physician";
    public static final String PP_TYPE_FACILITY = "facility";
    public static final String PP_MEMBER_PRODUCT_TYPE_MEDICAID = "Medicaid";

    //member options
    public static final String LIB_MEMB = "LIB_MEMB";
    public static final String MEMB_TYPE_C_AND_S = "C&S";
    public static final String MEMB_TYPE_E_AND_I = "E&I";
    public static final String MEMB_TYPE_BCBS = "BCBS";

    /**
     * Titles for reserved members.
     * These member titles shouldn't be appear in any of the LIB_MEMB Excel files.
     */
    public static final String MEMB_TITLE_A_C_S_MEMBER_FOR_DUP_TERM_CHECK = "a C&S member for Dup Term Check";
    public static final String MEMB_TITLE_AN_E_I_MEMBER_FOR_DUP_TERM_CHECK = "an E&I member for Dup Term Check";
    public static final String MEMB_TITLE_A_MEMBER_FOR_DUP_TERM_CHECK = "a member for Dup Term Check";
    public static final String MEMB_TITLE_A_MEMBER_FOR_WORKFLOW = "a member for workflow";


    //requesting provider options
    public static final String LIB_RP = "LIB_RP";
    public static final String RP_TYPE_PHYSICIAN = "physician";
    public static final String RP_TYPE_FACILITY = "facility";

    //regimen options
    public static final String RG_TYPE_CUSTOM = "Custom";
    public static final String RG_TYPE_AUTO_APPROVE = "Auto Approve";
    public static final Object RGID_IS_IT_AN_URGENT_REQUEST_YES = "Yes";
    public static final Object RGID_IS_IT_AN_URGENT_REQUEST_NO = "No";

    //servicing provider options
    public static final String LIB_SP = "LIB_SP";
    public static final String SP_TYPE_PHYSICIAN = "physician";
    public static final String SP_TYPE_FACILITY = "facility";

    //auth profile options
    public static final String LIB_AUTH_PROFILE = "LIB_AUTH_PROFILE";
    public static final String AUTH_TYPE_CHEMO = "Outpatient Chemotherapy";
    public static final String AUTH_TYPE_SUPP = "Cancer Supportive Drug Only";
    public static final String AUTH_TYPE_RADIO = "Therapeutic Radiopharmaceuticals";
    public static final String AUTH_TYPE_SPECIALTY_PHARMA = "Specialty Pharmacy";
    public static final String AUTH_TYPE_RADONC = "Radiation Oncology";

    //request detail options
    public static final String RDCD_TREATMENT_INITIAL = "New Treatment";
    public static final String RDCD_TREATMENT_CHANGING = "Continuation of Treatment";

    public static final String CANCER_PROSTATE_CANCER = "Prostate Cancer";
    public static final String CANCER_BREAST_CANCER = "Breast Cancer";
    public static final String CANCER_T_Cell_Lymphomas_CANCER = "T-Cell Lymphomas";
    public static final String CANCER_ANAL_CARCINOMA = "Anal Carcinoma";
    public static final String CANCER_COLON_CANCER = "Colon Cancer";
    public static final String CANCER_OTHER = "Other";
    public static final String CANCER_THYMOMAS_and_THYMIC_CARCINOMAS_CANCER = "Thymomas and Thymic Carcinomas";
    public static final String CANCER_MYELODSPLASTIC_SYNDROMES = "Myelodysplastic Syndromes";
    public static final String CANCER_SECONDARY_META_BRAIN = "Secondary Metastatic Disease: Brain Metastasis";
    public static final String CANCER_SECONDARY_META_CRANIAL = "Secondary Metastatic Disease: Extra-Cranial (Including bone metastasis, oligometastasis, and other)";


    public static final String RDCD_WHICH_RADIOPHARMACEUTICAL_ARE_YOU_REQUESTING_RADIUM = "Radium 223 (Xofigo)";
    public static final String RDCD_WHICH_RADIOPHARMACEUTICAL_ARE_YOU_REQUESTING_LUTATHERA = "Lutetium Lu 177 Dotatate (Lutathera)";
    public static final String RDCD_WHICH_RADIOPHARMACEUTICAL_ARE_YOU_REQUESTING_AZEDRA = "iobenguane I-131 (Azedra)";

    //request detail options for Speciality
    public static final String RDCD_THERAPY_INITIAL = "New To Therapy";
    public static final String RDCD_THERAPY_CHANGING = "Continuation Therapy";

    //page control options
    public static final String STOP_AT_PAGE_BEGIN = "stopAtPageBegin";
    public static final String STOP_AT_PAGE = "stopAtPage";
    public static final String STOP_AT_NEXT_PAGE_BEGIN = "stopAtNextPageBegin";
    public static final String CONTINUE_FROM_PAGE = "continueFromPage";

    private static final Map<String, ExcelLib> LIBS = new HashMap<>();

    protected ExcelLib() {
        //Singleton
    }

    /**
     * Get the singleton instance for each libType.
     *
     * @param libType [LIB_USER|LIB_PP|LIB_MEMB|LIB_RP|LIB_SP|LIB_AUTH_PROFILE]
     * @return
     */
    public static synchronized ExcelLib instance(String libType) {
        if (!LIBS.containsKey(libType)) {
            try {
                //pull relativePath of excel lib from config.properties (base)
                String relativePathsString = Conf.getInstance().getProperty(libType);
                String[] relativePaths = relativePathsString.split(",");
                String[] paths = new String[relativePaths.length];
                for (int i = 0; i < paths.length; i++) {
                    File path = TestUtils.projectFile(relativePaths[i]);
                    paths[i] = path.getAbsolutePath();
                }
                ExcelLib lib = setExcelLibPaths(libType, paths);
                for (String title : lib.getTitles()) {
                    WhiteBoard.getInstance().putMap(WhiteBoard.OWNER_GLOBAL, libType + "_" + title, lib.getObjectByTitle(title));
                }
            } catch (Exception e) {
                Assert.fail(e.getMessage());
            }


        }
        return LIBS.get(libType);
    }

    /**
     * Get an Iterable instance for all titles.
     * @return
     */
    public abstract Iterable<? extends String> getTitles();

    private static ExcelLib setExcelLibPaths(String libType, String... paths) {
        ExcelLib lib = null;
        switch (libType) {
            case LIB_USER:
                lib = new ExcelLibImpl(paths);
                break;
            case LIB_PP:
                lib = new ExcelLibImpl(paths);
                break;
            case LIB_MEMB:
                lib = new ExcelLibMember(paths);
                break;
            case LIB_RP:
                lib = new ExcelLibImpl(true, paths);
                break;
            case LIB_SP:
                lib = new ExcelLibImpl(paths);
                break;
            case LIB_AUTH_PROFILE:
                lib = new ExcelLibImpl(true, paths);
                break;
            default:
                throw new RuntimeException("No such library: " + libType);
        }
        LIBS.put(libType, lib);
        return lib;
    }

    /**
     * Extract all Clinical Status Questions and Answers from a authorization profile.
     * NOTE: deprecated. Use CsqaManager solution instead.
     *
     * @param pf
     * @return
     */
    @Deprecated
    public static Map<String, String> allQa(Map<String, String> pf) {
        Map<String, String> result = new LinkedHashMap<>();
        for (String key : pf.keySet()) {
            if (key.startsWith(MBM.CSQA_PREFIX)) {
                result.put(key, pf.get(key));
            }
        }
        return result;
    }

    public static String[] splitJustifications(String s) {
        return s.split(MBM.RDCD_CHANGING_TREATMENT_JUSTIFICATION_SPLIT_BY);
    }

    /**
     * Reads the complete profile from Excel Libraries
     *
     * @param owner
     * @param map
     * @return
     */
    public static Map<String, String> completeProfile(String owner, Map<String, String> map) {

        String myProject = Conf.getInstance().getProperty(ConfBase.PROJECT_KEY);
        log.debug("project=" + myProject);


        log.debug("owner=" + owner);
        if (null == map) {
            map = new HashMap<>();
        }
        map = WhiteBoard.resolve(owner, map);
        log.debug("map=" + WhiteBoard.getInstance().protect(map));

        Map<String, String> pf = new LinkedHashMap<>(map);

        String authTitle = pf.get(MBM.AUTH_TITLE);
        if (StringUtils.isEmpty(authTitle)) {
            map.remove(MBM.AUTH_TITLE);
            pf.remove(MBM.AUTH_TITLE);
            if (WhiteBoard.getInstance().containsMap(owner, ExcelLib.THE_AUTH_PROFILE)) {
                pf.putAll(WhiteBoard.getInstance().getMap(owner, ExcelLib.THE_AUTH_PROFILE));
            }
            authTitle = pf.get(MBM.AUTH_TITLE);
            if (StringUtils.isEmpty(authTitle)) {
                String suggestedAuthTitle = AuthTitle.suggestTitle(pf);
                pf.put(MBM.AUTH_TITLE, suggestedAuthTitle);
            }
        }
        authTitle = pf.get(MBM.AUTH_TITLE);
        Map<String, String> tryPf = ExcelLib.instance(LIB_AUTH_PROFILE).getObjectByTitle(authTitle);
        if (tryPf.containsKey(MBM.PROTOTYPE)) {
            Map<String, String> prototypePf = ExcelLib.instance(LIB_AUTH_PROFILE).getObjectByTitle(tryPf.get(MBM.PROTOTYPE));
            tryPf.remove(MBM.AUTH_TITLE);
            tryPf.remove(MBM.PROTOTYPE);
            prototypePf.putAll(tryPf);
            pf.remove(MBM.AUTH_TITLE);
            pf.remove(MBM.PROTOTYPE);
            prototypePf.putAll(pf);
            pf = prototypePf;
            map.remove(MBM.AUTH_TITLE);
            map.remove(MBM.PROTOTYPE);
            log.debug("map=" + WhiteBoard.getInstance().protect(map));
        } else {
            System.out.print("no prototype");
        }

        appendObject(owner, pf, MBM.AUTH_TITLE, THE_AUTH_PROFILE, ExcelLib.LIB_AUTH_PROFILE);
        pf.putAll(map);

//        csqaUpdate(map, pf);

        appendObject(owner, pf, MBM.USER_TITLE, THE_USER, ExcelLib.LIB_USER);


        /**
         * checks if user is running test in common or base - if true then do not search for this lib as it only exists in UHC
         */
        if (myProject.equals(ConfBase.COMMON_PROJECT) || myProject.equals(ConfBase.BASE_PROJECT)) {
            log.warn("Running common test - no paan provider library");
        } else if (Conf.getInstance().getProperty("envset").contains("uhc")) {
            log.warn("envset is uhc - checking PAAN Provider");
            appendObject(owner, pf, MBM.PP_TITLE, THE_PAAN_PROVIDER, ExcelLib.LIB_PP);
        }else{
            log.warn("envset is not uhc - no PAAN Provider needed");
        }


        /**
         * checks if user is running test in common or base - if true then do not search for this lib as it only exists payer modules
         */
        if (myProject.equals(ConfBase.COMMON_PROJECT) || myProject.equals(ConfBase.BASE_PROJECT)) {
            log.warn("Running common test - no member library");
        }else{
             appendObject(owner, pf, MBM.MEMB_TITLE, THE_MEMBER, ExcelLib.LIB_MEMB);
        }

        appendObject(owner, pf, MBM.RP_TITLE, THE_REQUESTING_PROVIDER, ExcelLib.LIB_RP);

        String spTitle = pf.get(MBM.SP_TITLE);
        if (null != spTitle && spTitle.trim().matches("-*")) {
            copyRPToSP(pf);
        } else {
            appendObject(owner, pf, MBM.SP_TITLE, THE_SERVICING_PROVIDER, ExcelLib.LIB_SP);
        }

        pf = WhiteBoard.resolve(owner, pf);

        try {
            String value = pf.get("Payer").isEmpty() ? Conf.getInstance().getProperty("payer") : pf.get("Payer");
            pf.put(MBM.PAYER, value);
        }catch(NullPointerException e) {
            pf.put(MBM.PAYER, Conf.getInstance().getProperty("payer"));
        }

            if (pf.containsKey(Conf.TEST_ENDPOINT_KEY)) {
            Map<String, String> theUserPf = WhiteBoard.getInstance().getMap(owner, ExcelLib.THE_USER);
            if (null != theUserPf) {
                theUserPf.put(Conf.TEST_ENDPOINT_KEY, pf.get(Conf.TEST_ENDPOINT_KEY));
            }
        }

        log.debug("pf=" + WhiteBoard.getInstance().protect(pf));
        return pf;
    }

    private static void copyRPToSP(Map<String, String> pf) {
        Map<String, String> spProfile = new LinkedHashMap<>();
        for (String key : pf.keySet()) {
            if (key.startsWith("rp")) {
                spProfile.put("s" + key.substring(1), pf.get(key));
            }
        }
        pf.putAll(spProfile);
    }

    /**
     * Calculate Clinical Status Questions and Answers based on the authorization profile content.
     * NOTE: deprecated. Use CsqaManager solution instead.
     *
     * @param map
     * @param pf
     */
    @Deprecated
    public static void csqaUpdate(Map<String, String> map, Map<String, String> pf) {
        Map<String, String> libPf = ExcelLib.instance(ExcelLib.LIB_AUTH_PROFILE).getObjectByTitle(pf.get(MBM.AUTH_TITLE));
        String libAuthType = libPf.get(MBM.AUTH_AUTHORIZATION_TYPE);
        String libCancer = libPf.get(MBM.RDCD_PRIMARY_CANCER);
        String libDrugType = libPf.get(MBM.RDCD_SUPPORTIVE_DRUG_NAME);
        String libRgType = libPf.get(MBM.RG_TYPE);
        String libRadioType = libPf.get(MBM.RDCD_WHICH_RADIOPHARMACEUTICAL_ARE_YOU_REQUESTING);
        Map<String, String> libCsqas = allQa(libPf);

        String dtAuthType = pf.get(MBM.AUTH_AUTHORIZATION_TYPE);
        String dtCancer = pf.get(MBM.RDCD_PRIMARY_CANCER);
        String dtDrugType = pf.get(MBM.RDCD_SUPPORTIVE_DRUG_NAME);
        String dtRgType = pf.get(MBM.RG_TYPE);
        String dtRadioType = pf.get(MBM.RDCD_WHICH_RADIOPHARMACEUTICAL_ARE_YOU_REQUESTING);
        Map<String, String> dtCsqas = allQa(map);

        if (dtCsqas.size() > 0) {
            log.debug("using CSQA's from feature file");
            DataTableUtils.removeAll(pf, libCsqas.keySet());
            DataTableUtils.removeAll(pf, dtCsqas.keySet());
            pf.putAll(dtCsqas);
        } else {
            log.debug("use suggested CSQA's only when feature file has nothing specific");
            Map<String, String> suggestedCsqas = new LinkedHashMap<>();
            List<String> reasonTrace = new LinkedList<>();
            if (!dtAuthType.equals(libAuthType)) {
                log.debug("feature file is specifying an authorization type that is different than the profile");
                reasonTrace.add(MBM.AUTH_AUTHORIZATION_TYPE);
            } else {
                log.debug("feature file has the same authorization type as the profile");
                if (ExcelLib.AUTH_TYPE_CHEMO.equals(dtAuthType)) {
                    log.debug("the authorization type is Chemo");
                    if (!dtCancer.equals(libCancer)) {
                        log.debug("feature file is specifying a different cancer than the profile");
                        suggestedCsqas = CsqaChemo.suggestCsqasByCancer(dtCancer);
                        reasonTrace.add(MBM.AUTH_AUTHORIZATION_TYPE);
                        reasonTrace.add(MBM.RDCD_PRIMARY_CANCER);
                    }
                } else if (ExcelLib.AUTH_TYPE_SUPP.equals(dtAuthType)) {
                    log.debug("the authorization type is Supportive");
                    if (!dtDrugType.equals(libDrugType)) {
                        log.debug("feature file is specifying a different drug type than the profile");
                        suggestedCsqas = CsqaSupportive.suggestCsqasByDrugType(dtDrugType, dtRgType);
                        reasonTrace.add(MBM.AUTH_AUTHORIZATION_TYPE);
                        reasonTrace.add(MBM.RDCD_SUPPORTIVE_DRUG_NAME);
                    } else {
                        log.debug("feature file has the same drug type as the profile");
                        if (!dtRgType.equals(libRgType)) {
                            //TODO: need suggestion
                            reasonTrace.add(MBM.AUTH_AUTHORIZATION_TYPE);
                            reasonTrace.add(MBM.RDCD_SUPPORTIVE_DRUG_NAME);
                            reasonTrace.add(MBM.RG_TYPE);
                        }
                    }
                } else if (ExcelLib.AUTH_TYPE_RADIO.equals(dtAuthType)) {
                    log.debug("the authorization type is Radio");
                    if (!dtRadioType.equals(libRadioType)) {
                        //TODO: need suggestion
                        reasonTrace.add(MBM.AUTH_AUTHORIZATION_TYPE);
                        reasonTrace.add(MBM.RDCD_WHICH_RADIOPHARMACEUTICAL_ARE_YOU_REQUESTING);
                    } else {
                        if (!dtRgType.equals(libRgType)) {
                            //TODO: need suggestion
                            reasonTrace.add(MBM.AUTH_AUTHORIZATION_TYPE);
                            reasonTrace.add(MBM.RDCD_WHICH_RADIOPHARMACEUTICAL_ARE_YOU_REQUESTING);
                            reasonTrace.add(MBM.RG_TYPE);
                        }
                    }
                }
            }
            if (reasonTrace.size() > 0) {
                if (null == suggestedCsqas) {
                    String msg = "Incompatible CSQA's based on below profile differences:";
                    for (String key : reasonTrace) {
                        msg += "\n\t" + key + "(" + map.get(key) + ":" + pf.get(key) + ")";
                    }
                    log.error(msg);
                    Assert.fail(msg);
                } else {
                    log.debug("suggestedCsqas=" + suggestedCsqas.toString());
                    DataTableUtils.removeAll(pf, libCsqas.keySet());
                    DataTableUtils.removeAll(pf, dtCsqas.keySet());
                    pf.putAll(suggestedCsqas);
                }
            }
        }
    }

    /**
     * Appends the object based on profile , Title and library
     *
     * @param owner
     * @param pf
     * @param titleKey
     * @param theProfile
     * @param lib
     * @return
     */
    public static Map<String, String> appendObject(String owner, Map<String, String> pf, String titleKey, String theProfile, String lib) {
        log.debug("appendObject(");
        log.debug("titleKey=" + titleKey);
        log.debug("pf.get(titleKey)=" + pf.get(titleKey));
        log.debug("theProfile=" + theProfile);
        log.debug("lib=" + lib);

        Map<String, String> srcPf = null;

        String title = pf.get(titleKey);
        if (null == title || title.trim().isEmpty()) {
            if (WhiteBoard.getInstance().containsMap(owner, theProfile)) {
                srcPf = WhiteBoard.getInstance().getMap(owner, theProfile);
//                pf.putAll(WhiteBoard.resolve(owner, WhiteBoard.getInstance().getMap(owner, theProfile)));
                appendOneByOne(pf, WhiteBoard.resolve(owner, WhiteBoard.getInstance().getMap(owner, theProfile)));
            } else {
                srcPf = ExcelLib.instance(lib).getObjectByTitle(ExcelLib.TITLE_DEFAULT);
            }
        } else if ("-".equals(title.trim())) {
            // ignore title with value "-"
        } else {
            srcPf = ExcelLib.instance(lib).getObjectByTitle(pf.get(titleKey));
            Assert.assertNotNull(srcPf);
        }

        if (null != srcPf) {
            appendOneByOne(pf, WhiteBoard.resolve(owner, srcPf));
        }
        log.debug("appendObject)");
        return srcPf;
    }

    private static void appendOneByOne(Map<String, String> pf, Map<String, String> update) {
        for (String key : update.keySet()) {
            if (!pf.containsKey(key)) {
                pf.put(key, update.get(key));
            }
        }
    }

    /**
     * Reset all singleton ExcelLib instances.
     */
    public static void reset() {
        LIBS.clear();
        WhiteBoard.getInstance().removeMap(WhiteBoard.OWNER_GLOBAL, THE_USER);
        WhiteBoard.getInstance().removeMap(WhiteBoard.OWNER_GLOBAL, THE_MEMBER);
        WhiteBoard.getInstance().removeMap(WhiteBoard.OWNER_GLOBAL, THE_REQUESTING_PROVIDER);
        WhiteBoard.getInstance().removeMap(WhiteBoard.OWNER_GLOBAL, THE_SERVICING_PROVIDER);
        WhiteBoard.getInstance().removeMap(WhiteBoard.OWNER_GLOBAL, THE_AUTH_PROFILE);
        WhiteBoard.getInstance().removeMap(WhiteBoard.OWNER_GLOBAL, THE_PAAN_PROVIDER);
    }

    abstract public Map<String, String> getObjectByTitle(String title, String... options);

}
