package atdd.utils;

import cucumber.api.DataTable;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Assert;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Function:
 * - Load all profiles from all resources specified by "paths".
 * - A profile is any number of key-value pairs represented by a Map<String, String> object.
 * - A profile must have a valid value for key "authTitle" so that it can be referenced by the client code.
 * - A valid "authTitle" is a Sting defined in the ExcelLib.AUTH_TITLES array.
 * -
 * --- When path represent a file, it has to be an Excel document with below assumptions:
 * ----- It must have a sheet named "view".
 * ----- This sheet has the first row as header row or the first column as header column if it's transposed.
 * ----- The first header must be "authTitle".
 * --- When path represent a directory, all json files will be loaded including sub folders.
 * ----- Any json file must be able to read as a Map<String, String> object.
 * ----- Convention: keep the json file name the same as the "authTitle" value.
 */
public class ExcelLibImpl extends ExcelLib {
    private static final Logger log = Logger.getLogger(ExcelLibImpl.class.getName());

    public static final String SHEET_VIEW = "view";

    private Map<String, Map<String, String>> indexedMaps = new LinkedHashMap<>();

    /**
     * Constructor:
     * No transpose by default
     * <p>
     * Protected for singleton instance provided by super class.
     *
     * @param paths
     */
    protected ExcelLibImpl(String... paths) {
        this(false, paths);
    }

    /**
     * Constructor:
     * Transpose aware
     * <p>
     * Protected for singleton instance provided by super class
     *
     * @param transpose
     * @param paths
     */
    protected ExcelLibImpl(boolean transpose, String... paths) {
        for (String path : paths) {
            File tryFile = TestUtils.projectFile(path);
            if (!tryFile.exists()) {
                Assert.fail("Invalid path: " + path);
            }

            if (tryFile.isFile()) {
                loadExcelFile(tryFile, transpose);
            } else if (tryFile.isDirectory()) {
                loadJsonFiles(tryFile);
            } else {
                Assert.fail("Unsupported source: " + tryFile.getAbsolutePath());
            }
        }
    }

    private void loadJsonFiles(File rootFolder) {
        for (File file : FileUtils.listFiles(rootFolder, new String[]{"json"}, true)) {
            try {
                Map<String, String> map = QuickJson.readMap(FileUtils.readFileToString(file));
                String authTitle = map.get(MBM.AUTH_TITLE);
                if (StringUtils.isEmpty(authTitle)) {
                    Assert.fail("Missing authTitle in file " + file.getAbsolutePath());
                }
                this.indexedMaps.put(authTitle, map);
            } catch (IOException e) {
                Assert.fail("Cannot read file: " + file.getAbsolutePath());
            }
        }
    }

    private void loadExcelFile(File excelFile, boolean transpose) {

        XSSFWorkbook workbook = null;
        try {
            workbook = new XSSFWorkbook(new FileInputStream(excelFile));
            XSSFSheet sheet = workbook.getSheet(SHEET_VIEW);
            if (null == sheet) {
                throw new RuntimeException("Missing sheet: [" + SHEET_VIEW + "]");
            }
            List<Map<String, String>> maps = ExcelUtils.asMaps(workbook.getSheet(SHEET_VIEW));
            if (null == maps || 0 == maps.size()) {
                throw new RuntimeException("Empty sheet: " + SHEET_VIEW);
            }

            if (transpose) {
                DataTable dataTable = DataTable.create(maps);
                maps = DataTableUtils.asMutableMapsTranspose(dataTable);
            } else {
                maps = maps;
            }

            //Sheet("view").A1 contains the keyHeader, doesn't matter it's transposed or not
            String keyHeader = maps.get(0).keySet().iterator().next();
            this.indexedMaps.putAll(DataTableUtils.dataTableAsMapsIndexedByKeyHeader(keyHeader, maps));

        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage());
            throw new RuntimeException("Cannot load Excel file: " + excelFile.getAbsolutePath());
        } finally {
            try {
                if (null != workbook) {
                    workbook.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
                log.error(e.getMessage());
                // do nothing
            }
        }
    }

    @Override
    public Iterable<? extends String> getTitles() {
        return this.indexedMaps.keySet();
    }

    /**
     * Get an object by title.
     * Not used: options
     *
     * @param title
     * @param options
     * @return
     */
    @Override
    public Map<String, String> getObjectByTitle(String title, String... options) {
        if (this.indexedMaps.containsKey(title)) {
            return new LinkedHashMap<>(this.indexedMaps.get(title));
        } else {
            return null;
        }
    }
}