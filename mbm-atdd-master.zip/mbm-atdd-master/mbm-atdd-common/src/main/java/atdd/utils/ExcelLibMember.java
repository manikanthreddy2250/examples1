package atdd.utils;

import java.util.Map;

public class ExcelLibMember extends ExcelLibImpl {

    protected ExcelLibMember(String... fullPath) {
        super(fullPath);
    }

    protected ExcelLibMember(boolean transpose, String... fullPaths) {
        super(transpose, fullPaths);
    }

    /**
     * Return which ever is not null:
     * 1. Get a member object from super class
     * 2. Get a member from MemberKeeper with specified options (title and inMinutes)
     *
     * @param title
     * @param options
     * @return
     */
    @Override
    public Map<String, String> getObjectByTitle(String title, String... options) {
        Map<String, String> member = super.getObjectByTitle(title);
        if (null == member) {
            if (null == options || 0 == options.length) {
                return null;
            }
            try {
                String owner = options[0];
                int inMinutes = Integer.parseInt(options[1]);
                Map<String, Object> mbr = MemberKeeper.getInstance().reserve(owner, title, inMinutes);
                member = DataTableUtils.asMapOfStrings(mbr);
                return member;
            } catch (Exception e) {
                e.printStackTrace();
                throw new RuntimeException("Unable to reserve member " + title);
            }
        } else {
            return member;
        }
    }


}
