package atdd.utils;

public class FileIntake {
    private String memberID;
    private String groupID;
    private String lastName;
    private String firstName;
    private String middleInitial;
    private String address1;
    private String address2;
    private String city;
    private String state;
    private String postalCode;
    private String birthDate;
    private String gender;
    private String phone;
    private String relationship;
    private String subscriberMemberID;
    private String subscriberLastName;
    private String subscriberFirstName;
    private String subscriberMiddleInitial;
    private String coverageEligibilityStatus;
    private String coverageEligibilityStartDate;
    private String coverageEligibilityEndDate;

    public FileIntake(String memberID, String groupID, String lastName, String firstName, String middleInitial, String address1, String address2, String city, String state, String postalCode, String birthDate, String gender, String phone, String relationship, String subscriberMemberID, String subscriberLastName, String subscriberFirstName, String subscriberMiddleInitial, String coverageEligibilityStatus, String coverageEligibilityStartDate, String coverageEligibilityEndDate) {
        this.memberID = memberID;
        this.groupID = groupID;
        this.lastName = lastName;
        this.firstName = firstName;
        this.middleInitial = middleInitial;
        this.address1 = address1;
        this.address2 = address2;
        this.city = city;
        this.state = state;
        this.postalCode = postalCode;
        this.birthDate = birthDate;
        this.gender = gender;
        this.phone = phone;
        this.relationship = relationship;
        this.subscriberMemberID = subscriberMemberID;
        this.subscriberLastName = subscriberLastName;
        this.subscriberFirstName = subscriberFirstName;
        this.subscriberMiddleInitial = subscriberMiddleInitial;
        this.coverageEligibilityStatus = coverageEligibilityStatus;
        this.coverageEligibilityStartDate = coverageEligibilityStartDate;
        this.coverageEligibilityEndDate = coverageEligibilityEndDate;
    }


    public String getMemberID() {
        return memberID;
    }

    public void setMemberID(String memberID) {
        this.memberID = memberID;
    }

    public String getGroupID() {
        return groupID;
    }

    public void setGroupID(String groupID) {
        this.groupID = groupID;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleInitial() {
        return middleInitial;
    }

    public void setMiddleInitial(String middleInitial) {
        this.middleInitial = middleInitial;
    }

    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(String birthDate) {
        this.birthDate = birthDate;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getRelationship() {
        return relationship;
    }

    public void setRelationship(String relationship) {
        this.relationship = relationship;
    }

    public String getSubscriberMemberID() {
        return subscriberMemberID;
    }

    public void setSubscriberMemberID(String subscriberMemberID) {
        this.subscriberMemberID = subscriberMemberID;
    }

    public String getSubscriberLastName() {
        return subscriberLastName;
    }

    public void setSubscriberLastName(String subscriberLastName) {
        this.subscriberLastName = subscriberLastName;
    }

    public String getSubscriberFirstName() {
        return subscriberFirstName;
    }

    public void setSubscriberFirstName(String subscriberFirstName) {
        this.subscriberFirstName = subscriberFirstName;
    }

    public String getSubscriberMiddleInitial() {
        return subscriberMiddleInitial;
    }

    public void setSubscriberMiddleInitial(String subscriberMiddleInitial) {
        this.subscriberMiddleInitial = subscriberMiddleInitial;
    }

    public String getCoverageEligibilityStatus() {
        return coverageEligibilityStatus;
    }

    public void setCoverageEligibilityStatus(String coverageEligibilityStatus) {
        this.coverageEligibilityStatus = coverageEligibilityStatus;
    }

    public String getCoverageEligibilityStartDate() {
        return coverageEligibilityStartDate;
    }

    public void setCoverageEligibilityStartDate(String coverageEligibilityStartDate) {
        this.coverageEligibilityStartDate = coverageEligibilityStartDate;
    }

    public String getCoverageEligibilityEndDate() {
        return coverageEligibilityEndDate;
    }

    public void setCoverageEligibilityEndDate(String coverageEligibilityEndDate) {
        this.coverageEligibilityEndDate = coverageEligibilityEndDate;
    }
}
