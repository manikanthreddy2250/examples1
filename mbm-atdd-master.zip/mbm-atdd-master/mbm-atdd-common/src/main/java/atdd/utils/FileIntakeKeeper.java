package atdd.utils;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class FileIntakeKeeper {

    public static FileIntakeKeeper getInstance() {
        return instance;
    }

    private FileIntakeKeeper() {
    }

    private static FileIntakeKeeper instance = new FileIntakeKeeper();
    private Map<String, Map<String, List<FileIntake>>> mapListVars = new LinkedHashMap<>();

    public List<FileIntake> putFileIntakeListMap(String owner, String key, List<FileIntake> value) {
        if (!this.mapListVars.containsKey(owner)) {
            this.mapListVars.put(owner, new LinkedHashMap<String, List<FileIntake>>());
        }
        return this.mapListVars.get(owner).put(key, value);
    }

    public List<FileIntake> getFileIntakeMap(String owner, String key) {
        return this.mapListVars.containsKey(owner) ? this.mapListVars.get(owner).get(key) : null;
    }

}
