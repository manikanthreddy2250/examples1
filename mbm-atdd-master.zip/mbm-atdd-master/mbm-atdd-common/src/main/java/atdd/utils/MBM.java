package atdd.utils;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Constants within MBM domain
 */
public class MBM {

    /**
     * Below constants are used by Requesting Summary page collection.
     */
    public static final String SUBMIT_TIMESTAMP = "submitTimestamp";
    public static final String SUBMIT_TIMESTAMP_PLUS_24_HOURS = "submitTimestampPlus24Hours";
    public static final String SUBMIT_DATE = "submitDate";
    public static final String SUBMIT_TIME = "submitTime";
    public static final String SUBMIT_TIME_HHmm = "submitTimeHHmm";
    public static final String SUBMIT_AMPM = "submitAMPM";

    public static final int SUBMIT_TIME_ICUE_OFFSET_HOUR = -1;
    public static final String SUBMIT_DATE_ICUE = "submitDateIcue";
    public static final String SUBMIT_TIME_ICUE = "submitTimeIcue";
    public static final String SUBMIT_TIME_HHmm_ICUE = "submitTimeHHmmIcue";
    public static final String SUBMIT_AMPM_ICUE = "submitAMPMIcue";

    /**
     * Below constants are used by collectin information from ICUE pages.
     */
    public static final String ICUE_EVICORE_SRN = "icueEvicoreSrn";
    public static final String ICUE_EVICORE_SERVICE_START_DATE = "icueEvicoreServiceStartDate";
    public static final String ICUE_EVICORE_SERVICE_END_DATE = "icueEvicoreServiceEndDate";

    /**
     * Below constants are used by ... ???
     */
    public static final String NAS_LOCATION = "NAS_LOCATION";
    public static final String NAS_USER = "NAS_USER";
    public static final String NAS_PASS = "NAS_PASS";
    public static final String MS = "ms";
    public static final String SHARED_LOCATION = "SHARED_LOCATION";
    public static final String NAS_SUBFOLDER = "NAS_SUBFOLDER";
    public static final String TEMP_PATH = "./tmp/";

    public static final String PAYER = "payer";

    /**
     * Below constants are used by user profiles.
     */
    public static final String USER_PREFIX = "user";
    public static final String USER_TITLE = "userTitle";
    public static final String USER_LOGIN_METHOD = "userLoginMethod";
    public static final String USER_USERNAME = "userUsername";
    public static final String USER_PASSWORD = "userPassword";
    public static final String USER_FAVORITE_COLOR = "userFavoriteColor";
    public static final String USER_FAVORITE_SPORTS_TEAM = "userFavoriteSportsTeam";
    public static final String USER_FIRST_PET = "userFirstPet";
    public static final String USER_BEST_FRIEND = "userBestFriend";
    public static final String USER_FIRST_PHONE_NUMBER = "userFirstPhoneNumber";
    public static final String USER_USERUID = "userUID";
    public static final String USER_FULLNAME = "fullName";
    public static final String[] USER_KEYS = new String[]{
            USER_TITLE,
            Conf.TEST_ENDPOINT_KEY,
            USER_LOGIN_METHOD,
            USER_USERNAME,
            USER_PASSWORD,
            USER_FAVORITE_COLOR,
            USER_FAVORITE_SPORTS_TEAM,
            USER_FIRST_PET,
            USER_FIRST_PHONE_NUMBER,
            USER_USERUID,
            USER_FULLNAME,
            USER_BEST_FRIEND,
    };

    /**
     * Below constants are used by PAAN Provider profiles.
     */
    public final static String PP_TITLE = "ppTitle";
    public final static String PP_TYPE = "ppType";
    public static final String PP_CORPORATE_TAX_ID_OWNER = "ppCorporateTaxIdOwner";
    public static final String PP_TIN = "ppTin";
    public static final String PP_FIRST_NAME = "ppFirstName";
    public static final String PP_LAST_NAME = "ppLastName";
    public static final String PP_BUSINESS_NAME = "ppBusinessName";
    public static final String PP_CARE_PROVIDER = "ppCareProvider";
    public static final String PP_CHEMO_SERVICE_TYPE = "ppChemoServiceType";
    public static final String PP_MEMBER_PRODUCT_TYPE = "ppMemberProductType";
    public static final String PP_STATE = "ppState";
    public static final String PP_PROVIDER_NAME="ppname";
    public static final String PP_SPECIALTY_TRANSACTION_TYPE = "ppSpecialtyTransactionType";
    public static final String PP_SPECIALTY_DRUG_CLASS = "ppDrugClass";
    /**
     * Below constants are used by Member profiles.
     */
    public static final String MEMB_TITLE = "membTitle";
    public static final String MEMB_FULL_NAME = "membFullName";
    public static final String MEMB_LAST_NAME = "membLastName";
    public static final String MEMB_FIRST_NAME = "membFirstName";
    public static final String MEMB_MIDDLE_NAME = "membMiddleName";
    public static final String MEMB_GENDER = "membGender";
    public static final String MEMB_DATE_OF_BIRTH = "membDateofBirth";
    public static final String MEMB_SUBSCRIBER_ID = "membSubscriberID";
    public static final String MEMB_GROUP_ID = "membGroupID";
    public static final String MEMB_RELATIONSHIP = "membRelationship";
    public static final String MEMB_TYPE = "membType";
    public static final String MEMB_INDEX = "membIndex";

    /**
     * Below constants are shared by Requesting Provider profiles and Servicing Provider profiles.
     * PD=Provider Details
     * PC=Point of Contact
     */
    public static final String PD_PROVIDER_FIRST_NAME = "pdProviderFirstName";
    public static final String PD_PROVIDER_LAST_NAME = "pdProviderLastName";
    public static final String PD_PROVIDER_NPI = "pdProviderNPI";
    public static final String PD_PROVIDER_TIN = "pdProviderTIN";
    public static final String PD_PROVIDER_ADDRESS = "pdProviderAddress";
    public static final String PD_PROVIDER_PHONE_NUMBER = "pdProviderPhoneNumber";
    public static final String PD_PROVIDER_FAX_NUMBER = "pdProviderFaxNumber";
    public static final String PD_PROVIDER_EMAIL = "pdProviderEmail";
    public static final String PD_PROVIDER_CELL_PHONE = "pdProviderCellPhone";
    public static final String PD_FACILITY_NAME = "pdFacilityName";
    public static final String PD_FACILITY_ADDRESS = "pdFacilityAddress";
    public static final String PD_FACILITY_PHONE_NUMBER = "pdFacilityPhoneNumber";
    public static final String PD_FACILITY_FAX_NUMBER = "pdFacilityFaxNumber";
    public static final String PD_STATE = "pdState";
    public static final String PD_ZIP = "pdZip";
    public static final String PD_NATIONAL_REGISTRATION = "pdNationalRegistration";
    public static final String PC_FULL_NAME = "pcFullName";
    public static final String PC_PHONE_NUMBER = "pcPhoneNumber";
    public static final String PC_FAX_NUMBER = "pcFaxNumber";
    public static final String PC_EMAIL = "pcEmail";
    public static final String PC_REQUEST_RECEIVED_BY = "pcRequestReceivedby";

    /**
     * Below constants are used by Requesting Provider profiles.
     * SP=Servicing Provider
     */
    public final static String RP = "rp";
    public final static String RP_TITLE = RP + "Title";
    public final static String RP_TYPE = RP + "Type";
    public static final String RPPD_PROVIDER_FIRST_NAME = RP + PD_PROVIDER_FIRST_NAME;
    public static final String RPPD_PROVIDER_LAST_NAME = RP + PD_PROVIDER_LAST_NAME;
    public static final String RPPD_PROVIDER_NPI = RP + PD_PROVIDER_NPI;
    public static final String RPPD_PROVIDER_TIN = RP + PD_PROVIDER_TIN;
    public static final String RPPD_PROVIDER_ADDRESS = RP + PD_PROVIDER_ADDRESS;
    public static final String RPPD_PROVIDER_PHONE_NUMBER = RP + PD_PROVIDER_PHONE_NUMBER;
    public static final String RPPD_PROVIDER_FAX_NUMBER = RP + PD_PROVIDER_FAX_NUMBER;
    public static final String RPPD_PROVIDER_EMAIL = RP + PD_PROVIDER_EMAIL;
    public static final String RPPD_PROVIDER_CELL_PHONE = RP + PD_PROVIDER_CELL_PHONE;
    public static final String RPPD_FACILITY_NAME = RP + PD_FACILITY_NAME;
    public static final String RPPD_FACILITY_ADDRESS = RP + PD_FACILITY_ADDRESS;
    public static final String RPPD_FACILITY_PHONE_NUMBER = RP + PD_FACILITY_PHONE_NUMBER;
    public static final String RPPD_FACILITY_FAX_NUMBER = RP + PD_FACILITY_FAX_NUMBER;
    public static final String RPPD_STATE = RP + PD_STATE;
    public static final String RPPD_ZIP = RP + PD_ZIP;
    public static final String RPPD_NATIONAL_REGISTRATION = RP + PD_NATIONAL_REGISTRATION;
    public static final String RPPC_FULL_NAME = RP + PC_FULL_NAME;
    public static final String RPPC_PHONE_NUMBER = RP + PC_PHONE_NUMBER;
    public static final String RPPC_FAX_NUMBER = RP + PC_FAX_NUMBER;
    public static final String RPPC_EMAIL = RP + PC_EMAIL;
    public static final String RPPC_REQUEST_RECEIVED_BY = RP + PC_REQUEST_RECEIVED_BY;

    /**
     * Below constants are used by Servicing Provider profiles.
     * RP=Requesting Provider
     */
    public final static String SP = "sp";
    public final static String SP_TITLE = SP + "Title";
    public final static String SP_TYPE = SP + "Type";
    public static final String SPPD_PROVIDER_FIRST_NAME = SP + PD_PROVIDER_FIRST_NAME;
    public static final String SPPD_PROVIDER_LAST_NAME = SP + PD_PROVIDER_LAST_NAME;
    public static final String SPPD_PROVIDER_NPI = SP + PD_PROVIDER_NPI;
    public static final String SPPD_PROVIDER_TIN = SP + PD_PROVIDER_TIN;
    public static final String SPPD_PROVIDER_ADDRESS = SP + PD_PROVIDER_ADDRESS;
    public static final String SPPD_PROVIDER_PHONE_NUMBER = SP + PD_PROVIDER_PHONE_NUMBER;
    public static final String SPPD_PROVIDER_FAX_NUMBER = SP + PD_PROVIDER_FAX_NUMBER;
    public static final String SPPD_PROVIDER_EMAIL = SP + PD_PROVIDER_EMAIL;
    public static final String SPPD_PROVIDER_CELL_PHONE = SP + PD_PROVIDER_CELL_PHONE;
    public static final String SPPD_FACILITY_NAME = SP + PD_FACILITY_NAME;
    public static final String SPPD_FACILITY_ADDRESS = SP + PD_FACILITY_ADDRESS;
    public static final String SPPD_FACILITY_PHONE_NUMBER = SP + PD_FACILITY_PHONE_NUMBER;
    public static final String SPPD_FACILITY_FAX_NUMBER = SP + PD_FACILITY_FAX_NUMBER;
    public static final String SPPD_STATE = SP + PD_STATE;
    public static final String SPPD_ZIP = SP + PD_ZIP;
    public static final String SPPD_NATIONAL_REGISTRATION = SP + PD_NATIONAL_REGISTRATION;
    public static final String SPPC_FULL_NAME = SP + PC_FULL_NAME;
    public static final String SPPC_PHONE_NUMBER = SP + PC_PHONE_NUMBER;
    public static final String SPPC_FAX_NUMBER = SP + PC_FAX_NUMBER;
    public static final String SPPC_EMAIL = SP + PC_EMAIL;
    public static final String SPPC_REQUEST_RECEIVED_BY = SP + PC_REQUEST_RECEIVED_BY;
    public static final String SPPD_PREFERRED_SUPPLIER = "spPreferredSupplier";

    /**
     * Below constants are used by Authorization profiles.
     * AUTH=Authorization
     */
    public static final String PROTOTYPE = "prototype";
    public static final String AUTH_TITLE = "authTitle";
    public static final String AUTH_HAS_CSQA = "authHasCsqa"; //[Yes]|No
    public static final String AUTH_AUTHORIZATION_TYPE = "authAuthorizationType";
    public static final String AUTH_SPECIALTY_SELFADMIN = "authSpecialtyPharmaSelfAdministered";
    public static final String AUTH_AUTHORIZATION_STATUS = "authAuthorizationStatus";
    public static final String AUTH_AUTHORIZATION_NUMBER = "authAuthorizationNumber";
    public static final String AUTH_REQUEST_NUMBER = "authRequestNumber";
    public static final String AUTH_REQUEST_STATUS = "authRequestStatus";
    public static final String AUTH_TOOLTIP_CHECK = "authVerifyToolTip";
    public static final String AUTH_AUTHORIZATION_START_DATE = "authAuthorizationStartDate";
    public static final String AUTH_AUTHORIZATION_END_DATE = "authAuthorizationEndDate";

    /**
     * RD=Request Details
     * PD=Patient Details
     * SD=Service Details
     * CD=Clinical Details
     */
    public static final String RDPD_HEIGHT_OF_THE_PATIENT = "rdpdHeightofthePatient";
    public static final String RDPD_WEIGHT_OF_THE_PATIENT = "rdpdWeightofthePatient";
    public static final String RDPD_PATIENT_CONTACT_NUMBER = "rdpdPatientContactNumber";
    public static final String RDSD_INITIAL_DIAGNOSIS_DATE = "rdsdInitialDiagnosisDate";
    public static final String RDSD_PLACE_OF_SERVICE = "rdsdPlaceofService";
    public static final String RDSD_BACKDATING_START_DATE = "rdsdBackdatingStartDate";
    public static final String RDSD_JUSTIFICATION_FOR_BACKDATING_OF_START_DATE = "rdsdJustificationforBackdatingofStartDate";
    public static final String RDSD_ANTICIPATED_TREATMENT_START_DATE = "rdsdAnticipatedTreatmentStartDate";
    public static final String RDSD_ICD_10_CODE = "rdsdICD10Code";
    public static final String RDSD_ADDITIONAL_ICD_10_CODE0 = "rdsdAdditionalICD10Code0";
    public static final String RDSD_ADDITIONAL_ICD_10_CODE1 = "rdsdAdditionalICD10Code1";
    public static final String RDSD_PERFORMANCE_SCALE = "rdsdPerformanceScale";
    public static final String RDSD_PERFORMANCE_STATUS = "rdsdPerformanceStatus";
    public static final String RDCD_PRIMARY_CANCER = "rdcdPrimaryCancer";
    public static final String RDCD_OTHER_DECRIPTION = "rdcdOtherDescription";
    public static final String RDCD_SUPPORTIVE_CARE_ONLY_REQUEST = "rdcdSupportiveCareOnlyRequest";
    public static final String RDCD_CHEMOTHERAPY_CLINICAL_TRIAL = "rdcdChemotherapyClinicalTrial";
    public static final String RDCD_DIFFERENT_METATASTIC_DISEASE = "rdcddifferentMetatasticDisease";
    public static final String RDCD_PRIMARY_OR_SECONDARY_SITE = "primaryOrSecondarySite";
    public static final String RDCD_CHANGE_PRIMARYDIAGNOSIS_MESSAGE = "changeprimarydiagnosismessage";
    public static final String RDCD_CLINICAL_TRIAL_MESSAGE = "clinicaltrialmessage";
    public static final String RDCD_HAS_DISEASE_PROGRESSED_OR_RELAPSED = "rdcdHasDiseaseProgressedorRelapsed";
    public static final String RDCD_INITIAL_DATE_OF_PROGRESSION = "rdcdInitialDateofProgression";
    public static final String RDCD_INITIAL_OR_CHANGING_TREATMENT = "rdcdNewOrContinuationofTreatment";
    public static final String RDCD_SUPPORTIVE_DRUG_NAME = "rdcdSupportiveDrugName";

    public static final String RDCD_CHANGING_TREATMENT_JUSTIFICATION = "rdcdChangingTreatmentJustification";
    public static final String RDCD_CHANGING_TREATMENT_JUSTIFICATION_SPLIT_BY = ">";
    public static final String RDCD_WHAT_IS_THE_DRUG_CATEGORY = "rdcdWhatistheDrugCategory";
    public static final String RDCD_WHAT_IS_THE_DOSAGE = "rdcdWhatistheDosage";
    public static final String RDCD_WHICH_RADIOPHARMACEUTICAL_ARE_YOU_REQUESTING = "rdcdWhichRadiopharmaceuticalareyourequesting";

    public static final String RDCD_CANCER_CLINICAL_TRIAL = "rdcdCancerClinicalTrial";
    public static final String RDCD_IS_PATIENT_CURRENTLY_TAKING_LEUPROLIDEACETATE = "rdcdIspatientcurrentlytakingLeuprolideAcetate";
    public static final String RDCD_IS_PATIENT_CURRENTLY_TAKING_Octreotide = "rdcdIspatientcurrentlytakingOctreotide";
    public static final String RDCD_SPECIALTY_PHARMADRUG_CLASS = "rdcdSpecialtyPharmaDrugClass";
    public static final String RDCD_SPECIALTY_PHARMA_DRUG_CODE = "rdcdSpecialtyPharmaDrugCode";
    public static final String RDCD_SPECIALTY_PHARMA_DIAGNOSIS = "rdcdSpecialtyPharmaDiagnosis";
    public static final String RDCD_SPECIALTY_DISEASE_STATE = "rdcdSpecialtyDiseaseState";
    public static final String RDSD_Specialty_Initial_Infusion_Member = "rdsdSpecialtyInitialInfusionMember";

    /**
     * RG=Regimens
     * DR=Drug
     * ID=Indication
     */
    public static final String RG_INDEX = "rgIndex";
    public static final String RG_LABEL = "rgLabel";
    public static final String RG_TYPE = "rgType";
    public static final String RGDR_DRUG_NAME_0 = "rgdrDrugName0";
    public static final String RGDR_DRUG_CODE_0 = "rgdrDrugCode0";
    public static final String RGDR_DRUG_Strength_0 = "rgdrDrugStrength0";
    public static final String RGDR_AUTHORIZATION_STATUS_0 = "rgdrAuthorizationStatus0";
    public static final String RGDR_DRUG_NAME_INCLUDING_PACKAGING_OPTIONS_0 = "rgdrDrugNameincludingPackagingOptions0";
    public static final String RGDR_DRUG_ROUTE_0 = "rgdrDrugRoute0";
    public static final String RGDR_DRUG_DOSAGE_0 = "rgdrDrugDosage0";
    public static final String RGDR_DOSAGE_0 = "rgdrDosage0";
    public static final String RGDR_REGIMENEXCEPTION = "rgdrRegimenDrugException";
    public static final String RG_REASONOGCHOOSINGREGIMEN = "rgReasonForChoosingRegimen";
    public static final String RG_PRIORITY_REVIEW_MSG = "rgpriorityreviewmsg";

    /**
     * TQ=Technique
     */
    public static final String TQ_INDEX = "tqIndex";
    public static final String TQ_LABEL = "tqLabel";
    public static final String TQ_TYPE = "tqType0";
    public static final String TQ_NAME_0 = "tqName0";
    public static final String TQ_CODE_0 = "tqCode0";
    public static final String TQ_DESCRIPTION_0 = "tqdescription0";
    public static final String TQ_UNITS = "tqunits0";

    /**
     * TE=Technique
     * NM=Name
     * Radioation Oncology Authorization Technique details - Technique Screen
     */

    public static final String TENM_TECHNIQUE_NAME = "tenmTechniqueName";
    public static final String TENM_CPCT_CODE = "tenmCpctCode";

    /**
     * AS=Additional Services
     */
    public static final String AS_NUMBER_OF_FRACTION_EXTERNAL_BEAM = "asNumberoffractionexternalbeam";
    public static final String AS_IGRT_CODE = "asIGRTCode";
    public static final String AS_IGRT_UNITS = "asIGRTUnits";
    public static final String AS_SPECIAL_CODES = "asSpecialCodes";
    public static final String AS_RECORDS_FOR_77470 = "as77470records";
    public static final String AS_RECORDS_FOR_77370 = "as77370records";
    public static final String AS_FREQUENCY_77331 = "as77331frequency";
    public static final String AS_CLINICAL_JUSTIFICATION_77331 = "as77331clinicalJustification";
    public static final String AS_CLINICAL_JUSTIFICATION_77399 = "as77399clinicalJustification";
    public static final String AS_OTHER_CLINICAL_JUSTIFICATION_77470 = "as77470OtherclinicalJustification";
    public static final String AS_OTHER_CLINICAL_JUSTIFICATION_77370 = "as77370OtherclinicalJustification";
    public static final String AS_SPACER_USED = "asSpacerUsed";


    /**
     * RG=Regimens
     * DR=Drug
     * Specialty Authorization Dosage details - Requesting Provider Screen
     */
    public static final String RGDR_NUMBER_OF_DOSES_0 = "rgdrNumberofDoses0";
    public static final String RGDR_DOSE_0 = "rgdrDose0";
    public static final String RGDR_FREQUENCY_OF_ADMINISTRATION_0 = "rgdrFrequencyofAdministration0";
    public static final String RGDR_TOTAL_NUMBER_OF_DOSES_0 = "rgdrTotalNumberofDoses0";
    public static final String RGDR_NUMBER_OF_JOINTS_0 = "rgdrNumberofJoints0";

    //</Specialty>

    public static final String RGDR_DAY_S_OF_CYCLE_TO_BE_ADMINISTERED_0 = "rgdrDaysofCycletobeAdministered0";
    public static final String RGDR_LENGTH_OF_CYCLES_DAYS_OR_WEEKS_0 = "rgdrLengthofCyclesDaysorweeks0";
    public static final String RGDR_REQUEST_STATUS_0 = "rgdrRequestStatus0";
    public static final String RGID_THERAPY_DURATION_MONTHS_0 = "rgidTherapyDurationmonths0";
    public static final String RGID_ADMITTED_0 = "rgidAdmitted0";
    public static final String RGID_THERAPY_COST_0 = "rgidTherapyCost0";
    public static final String RGID_TREATMENT_FREQUENCY_0 = "rgidTreatmentFrequency0";
    public static final String RGID_FEBRILE_NEUTROPENIA_RISK_0 = "rgidFebrileNeutropeniaRisk0";
    public static final String RGID_EMETIC_RISK_0 = "rgidEmeticRisk0";
    public static final String RGID_AUTHORIZATION_DURATION_0 = "rgidAuthorizationDuration0";
    public static final String RGID_TREATMENT_END_DATE = "rgidTreatmentEndDate";
    public static final String RGID_IS_IT_AN_URGENT_REQUEST = "rgidIsitanUrgentRequest";
    public static final String RGID_URGENT_REQUEST_OUTCOME = "rgidUrgentRequestOutcome";
    public static final String RGID_REGIMEN_JUSTIFICATION_0 = "rgidRegimenJustification0";
    public static final String RGID_CLINICAL_DOCUMENTATION = "rgidClinicalDocumentation";

    /**
     * Obsolete Authorization profile keys related to Clinical Status Questions and Answers.
     */
    public static final String CSQA_PREFIX = "csqa";

    public static final String CSQA_WHAT_IS_THE_HISTOLOGY = "csqaWhatisthehistology";
    public static final String CSQA_WHAT_IS_THE_STAGE = "csqaWhatisthestage";
    public static final String CSQA_WHAT_IS_THE_TREATMENT_INDICATION_OR_DISEASE_STATUS = "csqaWhatisthetreatmentindicationordiseasestatus";
    public static final String CSQA_WHAT_WHAT_WAS_THE_STAGE_AT_INITIAL_DIAGNOSIS = "csqaWhatwasthestageatinitialdiagnosis";
    public static final String CSQA_WHAT_IS_THE_MMR_MSI_STATUS = "csqaWhatistheMMRMSIStatus";
    public static final String CSQA_WHAT_IS_THE_LINE_OF_THERAPY = "csqaWhatisthelineoftherapy";
    public static final String CSQA_WHAT_IS_THE_CURRENT_STAGE_OF_CANCER = "csqaWhatisthecurrentstageofcancer";
    public static final String CSQA_WHAT_IS_THE_HER2_STATUS = "csqaWhatistheHER2status";
    public static final String CSQA_WHAT_IS_THE_ER_PR_STATUS = "csqaWhatistheERPRstatus";
    public static final String CSQA_WHAT_IS_THE_MULTI_GENE_ASSAY_RISK_STATUS = "csqaWhatisthemultigeneassayriskstatus";
    public static final String CSQA_WHAT_IS_THE_INDICATION = "csqaWhatistheindication";
    public static final String CSQA_IS_THE_ABSOLUTE_ENEUTROPHIL_COUNT_500 = "csqaIstheabsoluteneutrophilcount_500";
    public static final String CSQA_I_ATTEST_THAT = "csqaIAttestThat";
    public static final String CSQA_SELECT_DIAGNOSIS = "csqaSelectdiagnosis";
    public static final String CSQA_SELECT_THE_DIAGNOSIS = "csqaSelectthediagnosis";
    public static final String CSQA_WHAT_IS_THE_CANCER_SUBTYPE = "csqaWhatisthecancersubtype";
    public static final String CSQA_WHAT_IS_THE_CD30_STATUS = "csqaWhatistheCD30status";
    public static final String CSQA_WHAT_IS_THE_ALK_REARRANGEMENT_STATUS = "csqaWhatistheALKrearrangementstatus";
    public static final String CSQA_Is_THERE_A_PALN_FOR_TRANSPLANT = "csqaIsthereaPlanforTransplant";
    public static final String CSQA_WHAT_IS_THE_BRCA_1_2_STATUS = "csqaWhatisthebrca1_2status";
    public static final String CSQA_WHAT_IS_THE_PDL1_EXPRESSION_STATUS = "csqaWhatisthepdl1expressionstatus";
    public static final String CSQA_WHAT_IS_THE_KRAS_NRAS_STATUS = "csqaWhatistheKRASNRASstatus";
    public static final String CSQA_WHAT_IS_THE_BRAF_V600E_Mutation_Status = "csqaWhatistheBRAFV600EMutationStatus";
    public static final String CSQA_Previous_adjuvant_FOLFOX_CAPEOX_within_past_12_months = "csqaPreviousAdjuvantFOLFOXCAPEOXWithinpast12months";
    public static final String CSQA_WHAT_IS_THE_EPO_STATUS = "csqaWhatistheEpostatus";
    public static final String CSQA_IS_DEL_5Q_PRESENT = "csqaIsDel5qpresent";

    public static final String CSQA_DOES_THE_MEMBER_HAVE_CORE_MEDICAL_NECESSITY = "csqaDoesthememberhaveCoreMedicalNecessity";
    public static final String CSQA_WHAT_WAS_THE_STAGE_AT_DIAGNOSIS = "csqaWhatWasTheStageAtDiagnosis";
    public static final String CSQA_DOES_INDIVIDUAL_HAVE_BONE_METASTASIS = "csqaDoesIndividualHaveBoneMetastasis";
    public static final String CSQA_IS_BONE_METASTASIS_DOCUMENTE_DONIMAGING = "csqaIsBoneMetastasisDocumentedOnImaging";
    public static final String CSQA_IS_PATIENT_RECEIVING_OR_EXPECTED_TO_RECEIVE_CONCURRENT_CHEMOTHERAPY_BIOLOGIC_THERAPY_OR_IMMUNOTHERAPY = "csqaIsPatientReceivingOrExpectedToReceiveConcurrentChemotherapyBiologicTherapyOrImmunotherapy";
    public static final String CSQA_DOES_PATIENT_HAVE_CURRENT_VISCERAL_METASTATIC_DISEASE = "csqaDoesPatientHaveCurrentVisceralMetastaticDisease";
    public static final String CSQA_WHAT_IS_THE_MSI_MMR_STATUS = "csqaWhatistheMSIMMRStatus";
    public static final String CSQA_DOES_PATIENT_HAVE_SOMATOSTATIN_RECEPTORPOSITIVE_METASTATIC_OR_UNRESECTABLE_LOCALLY_ADVANCED = "csqaDoesPatientHaveSomatostatinReceptorPositiveMetastaticOrUnresectableLocallyAdvanced";
    public static final String CSQA_HAS_PATIENT_PROGRESSED_ON_A_HIGH_DOSE_SOMATOSTATIN_ANALOG = "csqaHasPatientProgressedOnAHighDoseSomatostatinAnalog";

    //specialty auto approved
    public static final String CSQA_IS_THE_REQUESTED_DRUG_BEING_USED_IN_A_PRE_MENOPAUSAL_WOMAN = "csqaIstherequesteddrugbeingusedinapremenopausalwoman";
    public static final String CSQA_IS_THE_MEMBER_RECEIVING_A_CYTOTOXIC_AGENT_THAT_IS_ASSOCIATED = "csqaIsthememberreceivingacytotoxicagentthatisassociated";

    //Patient Questions for PH
    public static final String PQ_DATE_SYMPTOMS_BEGAN = "pqDateSymptomsBegan";
    public static final String PQ_BRIEFLY_DESCRIBE_YOUR_SYMPTOMS = "pqBrieflydescribeyoursymptoms";
    public static final String PQ_HOW_DID_YOUR_SYMPTOMS_START = "pqHowdidyoursymptomsstart?";
    public static final String PQ_AVERAGE_PAIN_SYMPTOM_INTENSITY = "pqAveragepain/symptomintensity";
    public static final String PQ_PAIN_IN_LAST_24_HOURS = "pqPaininlast24hours";
    public static final String PQ_PAIN_IN_LAST_WEEK_1_7_DAYS = "pqPaininlastweek(1-7days)";
    public static final String PQ_HOW_OFTEN_DO_YOU_FEEL_YOUR_SYMPTOMS = "pqHowoftendoyoufeelyoursymptoms";
    public static final String PQ_HOW_MUCH_HAVE_YOUR_SYMPTOMS_INTERFERED_WITH_YOUR_DAILY_ACTIVITIES = "pqHowmuchhaveyoursymptomsinterferedwithyourdailyactivities";
    public static final String PQ_HOW_IS_YOUR_CONDITION_CHANGING_SINCE_CARE_AT_THIS_FACILITY = "pqHowisyourconditionchanging,sincecareatthisfacility? ";
    public static final String PQ_IN_GENERAL_WOULD_YOU_SAY_YOUR_OVERALL_HEALTH_RIGHT_NOW_IS = "pqIngeneral,wouldyousayyouroverallhealthrightnowis...";
    public static final String PQ_DATE_PATIENT_COMPLETED_QUESTIONS = "pqDatePatientCompletedQuestions";

    public static final String FOMS_BACKINDEX = "fomsBackIndex";
    public static final String FOMS_TYPE = "fomsType";
    public static final String FOMS_DASH = "fomsDash";
    public static final String FOMS_LEFS = "fomsLefs";
    public static final String FOMS_NECKINDEX = "fomsNeckIndex";
    public static final String FOMS_OTHER = "fomsOther";
    //public static final String SBST_Has_your_back_pain_spread_down_your_leg_s__at_some_time_in_the_last_2_weeks = "Hasyourbackpainspreaddownyourleg(s)atsometimeinthelast2weeks?";

    /*
  Request Details-PT,OT,ST
   */
    public static final String RDPT_DATE_RECEIVED = "rdptDateReceived";
    public static final String RDPT_IMAGE_NUMBER = "rdptImageNumber";
    public static final String RDPT_DATE_YOU_WANT_THIS_TREATMENT_TO_BEGIN = "rdptDateYouWantThisSubmissionToBegin";
    public static final String RDPT_PRIMARY_PROVIDER_CREDENTIAL = "rdptPrimaryProviderCredential";
    public static final String RDPT_PLACE_OF_SERVICE = "rdptPlaceOfService";
    public static final String RDPT_PRYMARY_DIAGNOSIS_CODE = "rdptPrimaryDiagnosisCode";
    public static final String RDPT_PATIENT_TYPE = "rdptPatientType";
    public static final String RDPT_NATURE_OF_CONDITION = "rdptNatureOfCondition";
    public static final String RDPT_PRIMARY_CAUSE_OF_CURRENT_EPISODE = "rdptPrimaryCauseOfCurrentEpisode";
    public static final String RDPT_NATURE_OF_TREATMENT = "rdptNatureOfTreatment";
    public static final String RDPT_REASON_FOR_LATE_SUBMISSION = "rdptReasonForLateSubmission";
    public static final String RDPT_LATE_SUBMISSION_NOTE_INCLUDED = "rdptLateSubmissionNoteIncluded";
    public static final String RDPT_ADMIN_DENIAL_REVIEW_COMMENT = "rdptadminDenialReviewComment";
    public static final String RDPT_ADMIN_DENIAL_REVIEW= "rdptadminDenialReview";
    public static final String RDPT_SURGERY_DATE = "rdptSurgeryDate";
    public static final String RDPT_TYPE_OF_SURGERY = "rdptTypeOfSurgery";
    public static final String RDPT_DATE_OF_INITIAL_EVALUATION = "rdptDateOfInitialEvaluation";
    public static final String RDPT_NUMBER_OF_VISITS_90_DAYS = "rdptNumberOfVisits90Days";
    public static final String RDPT_SCHEDULED_FREQUENCY_VISITS = "rdptScheduledFrequencyofVisits";
    public static final String RDPT_TYPE_OF_SURGERY_OTHER = "rdptTypeOfSurgeryOther";
    public static final String RDPT_SECONDARY_PROVIDER_CREDENTIAL = "rdptSecondaryProviderCredential";
    public static final String RDPT_ADDITIONAL_DIAGNOSIS_CODE = "rdptAdditionalDiagnosisCode";
    public static final String RDPT_SECONDARY_COUSE_OF_CURRENT_EPISODE = "rdptSecondaryCauseOfCurrentEpisode";
    public static final String RDPT_TIMELY_FILING_REASON = "rdptTimelyFilingReason";
    public static final String RDPT_TIMELY_FILING_LATE_REASON = "rdptLateSubmission";



    private static final String[][] CSQA_LABELS = new String[][]{
            {CSQA_WHAT_IS_THE_HISTOLOGY, "What is the histology?"},
            {CSQA_WHAT_IS_THE_STAGE, "What is the stage?"},
            {CSQA_WHAT_IS_THE_TREATMENT_INDICATION_OR_DISEASE_STATUS, "What is the treatment indication or disease status?"},
            {CSQA_WHAT_WHAT_WAS_THE_STAGE_AT_INITIAL_DIAGNOSIS, "What was the stage at initial diagnosis?"},
            {CSQA_WHAT_IS_THE_MMR_MSI_STATUS, "What is the MMR/MSI status?"},
            {CSQA_WHAT_IS_THE_LINE_OF_THERAPY, "What is the line of therapy?"},
            {CSQA_WHAT_IS_THE_CURRENT_STAGE_OF_CANCER, "What is the current stage of cancer?"},
            {CSQA_WHAT_IS_THE_HER2_STATUS, "What is the HER2 status?"},
            {CSQA_WHAT_IS_THE_ER_PR_STATUS, "What is the ER/PR status?"},
            {CSQA_WHAT_IS_THE_MULTI_GENE_ASSAY_RISK_STATUS, "What is the multi-gene assay risk status?"},
            {CSQA_WHAT_IS_THE_INDICATION, "What is the indication?"},
            {CSQA_IS_THE_ABSOLUTE_ENEUTROPHIL_COUNT_500, "Is the absolute neutrophil count <500?"},
            {CSQA_WHAT_WAS_THE_STAGE_AT_DIAGNOSIS, "What was the stage at Diagnosis?"},
            {CSQA_DOES_INDIVIDUAL_HAVE_BONE_METASTASIS, "Does individual have bone metastasis?"},
            {CSQA_IS_BONE_METASTASIS_DOCUMENTE_DONIMAGING, "Is bone metastasis documented on imaging?"},
            {CSQA_IS_PATIENT_RECEIVING_OR_EXPECTED_TO_RECEIVE_CONCURRENT_CHEMOTHERAPY_BIOLOGIC_THERAPY_OR_IMMUNOTHERAPY, "Is patient receiving, or expected to receive concurrent, chemotherapy, biologic therapy or immunotherapy?"},
            {CSQA_DOES_PATIENT_HAVE_CURRENT_VISCERAL_METASTATIC_DISEASE, "Does patient have current visceral metastatic disease?"},
            {CSQA_SELECT_DIAGNOSIS, "Select diagnosis"},
            {CSQA_SELECT_THE_DIAGNOSIS, "Select the diagnosis"},
            {CSQA_WHAT_IS_THE_MSI_MMR_STATUS, "What is the MSI/MMR Status?"},
            {CSQA_DOES_PATIENT_HAVE_SOMATOSTATIN_RECEPTORPOSITIVE_METASTATIC_OR_UNRESECTABLE_LOCALLY_ADVANCED, "Does patient have somatostatin receptor-positive metastatic or unresectable locally advanced"},
            {CSQA_HAS_PATIENT_PROGRESSED_ON_A_HIGH_DOSE_SOMATOSTATIN_ANALOG, "Has patient progressed on a high doseInput somatostatin analog"},
            {CSQA_I_ATTEST_THAT, "I attest that..."},
            {CSQA_DOES_THE_MEMBER_HAVE_CORE_MEDICAL_NECESSITY, "Does the member have Core Medical Necessity?"},
            {CSQA_WHAT_IS_THE_CANCER_SUBTYPE, "What is the cancer subtype?"},
            {CSQA_WHAT_IS_THE_CD30_STATUS, "What is the CD30 status?"},
            {CSQA_WHAT_IS_THE_ALK_REARRANGEMENT_STATUS, "What is the ALK rearrangement status?"},
            {CSQA_Is_THERE_A_PALN_FOR_TRANSPLANT, "Is there a Plan for Transplant?"},
            {CSQA_WHAT_IS_THE_BRCA_1_2_STATUS, "What is the BRCA1/2 status?"},
            {CSQA_WHAT_IS_THE_PDL1_EXPRESSION_STATUS, "What is the PD-L1 expression status?"},
            {CSQA_WHAT_IS_THE_KRAS_NRAS_STATUS, "What is the KRAS/NRAS status?"},
            {CSQA_WHAT_IS_THE_BRAF_V600E_Mutation_Status, "What is the BRAF V600E Mutation status?"},
            {CSQA_Previous_adjuvant_FOLFOX_CAPEOX_within_past_12_months, "Previous adjuvant FOLFOX/CAPEOX within past 12 months?"},
            {CSQA_IS_THE_REQUESTED_DRUG_BEING_USED_IN_A_PRE_MENOPAUSAL_WOMAN, "Is the requested drug being used in a pre-menopausal woman?"},
            {CSQA_IS_THE_MEMBER_RECEIVING_A_CYTOTOXIC_AGENT_THAT_IS_ASSOCIATED, "Is the member receiving a cytotoxic agent that is associated with causing primary ovarian insufficiency (premature ovarian failure) [Such as Cytoxan (cyclophosphamide), procarbazine, vinblastine, cisplatin]?"}

    };

    private static final String[][] CSQA_LABELS_RADIO = new String[][]{
            {CSQA_WHAT_IS_THE_HISTOLOGY, "What is the Histology?"},
            {CSQA_WHAT_IS_THE_TREATMENT_INDICATION_OR_DISEASE_STATUS, "What is the treatment Indication or Disease Status?"},
            {CSQA_WHAT_IS_THE_MSI_MMR_STATUS, "What is the MSI/MMR Status?"},
            {CSQA_DOES_INDIVIDUAL_HAVE_BONE_METASTASIS, "Does individual have bone metastasis?"},
            {CSQA_IS_BONE_METASTASIS_DOCUMENTE_DONIMAGING, "Is bone metastasis documented on imaging?"},
            {CSQA_IS_PATIENT_RECEIVING_OR_EXPECTED_TO_RECEIVE_CONCURRENT_CHEMOTHERAPY_BIOLOGIC_THERAPY_OR_IMMUNOTHERAPY, "Is patient receiving, or expected to receive concurrent, chemotherapy, biologic therapy or immunotherapy? (excluding Gnrh therapy)"},
            {CSQA_DOES_PATIENT_HAVE_CURRENT_VISCERAL_METASTATIC_DISEASE, "Does patient have current visceral metastatic disease?"},
    };

    public static final Map<String, String> CSQA_LABEL_MAPS;

    static {
        CSQA_LABEL_MAPS = new LinkedHashMap<>(CSQA_LABELS.length);
        for (String[] pair : CSQA_LABELS) {
            CSQA_LABEL_MAPS.put(pair[0], pair[1]);
        }
    }

    public static final Map<String, String> CSQA_LABEL_MAPS_RADIO;

    static {
        CSQA_LABEL_MAPS_RADIO = new LinkedHashMap<>(CSQA_LABELS.length);
        for (String[] pair : CSQA_LABELS) {
            CSQA_LABEL_MAPS_RADIO.put(pair[0], pair[1]);
        }
        for (String[] pair : CSQA_LABELS_RADIO) {
            CSQA_LABEL_MAPS_RADIO.put(pair[0], pair[1]);
        }
    }

    public static String getCsqaLabel(String authType, String q) {
        switch (authType) {
            case ExcelLib.AUTH_TYPE_RADIO:
                return CSQA_LABEL_MAPS_RADIO.get(q);
            default:
                return CSQA_LABEL_MAPS.get(q);
        }
    }

}