package atdd.utils;

import atdd.common.Retry;
import atdd.dao.mbm.MbrDao;
import atdd.dao.mbm.MyBatisConnectionFactory;
import org.apache.log4j.Logger;
import org.junit.Assert;

import java.util.*;

public class MemberKeeper {
    private static final Logger log = Logger.getLogger(MemberKeeper.class.getName());
    private static final Map<String, Map<String, Map<String, Object>>> reservedMembersByOwner = new HashMap<>();
    private static final MemberKeeper ourInstance = new MemberKeeper();

    /**
     * Singleton
     *
     * @return
     */
    public static MemberKeeper getInstance() {
        return ourInstance;
    }

    private MemberKeeper() {
    }

    /**
     * For specified owner, reserve a member by title for the duration specified my inMinutes.
     * Retry for 1 hour if no available members.
     *
     * @param owner
     * @param title
     * @param inMinutes
     * @return
     */
    public Map<String, Object> reserve(String owner, String title, int inMinutes) {
        log.warn("owner=" + owner);
        log.warn("title=" + title);
        log.warn("inMinutes=" + inMinutes);

        if (reservedMembersByOwner.containsKey(owner)) {
            log.warn("Memory hit");
            Map<String, Map<String, Object>> myMembers = reservedMembersByOwner.get(owner);
            if (myMembers.containsKey(title)) {
                Map<String, Object> myMember = myMembers.get(title);
                return myMember;
            }
        }

        final List<Map<String, Object>> mbrContainer = new ArrayList<>(1);
        boolean success = new Retry("MemberKeeper.reserve") {

            @Override
            protected void tryOnce() {
                MbrDao mbrDao = new MbrDao(MyBatisConnectionFactory.getSqlSessionFactory());
                Map<String, Object> mbr = null;
                switch (title) {
                    case ExcelLib.MEMB_TITLE_A_C_S_MEMBER_FOR_DUP_TERM_CHECK:
                        //TODO
//                        mbrList.addAll(mbrDao.getNextAvailableCASMemberForDupTermCheck());
                        break;
                    case ExcelLib.MEMB_TITLE_AN_E_I_MEMBER_FOR_DUP_TERM_CHECK:
                    case ExcelLib.MEMB_TITLE_A_MEMBER_FOR_DUP_TERM_CHECK:
                        mbr = mbrDao.reserveNextAvailableEAIMemberForDupTermCheck(inMinutes);
                        break;
                    case ExcelLib.MEMB_TITLE_A_MEMBER_FOR_WORKFLOW:
                        mbr = mbrDao.reserveNextAvailableEAIMemberForDupTermCheck(inMinutes);
                        break;
                    default:
                        Assert.fail("Unknown title: " + title);
                }
                if (null == mbr) {
                    throw new RuntimeException(">>>>>No available member found.<<<<<");
                } else {
                    mbrContainer.add(mbr);
                }
            }

            @Override
            protected boolean until() {
                if (1 == mbrContainer.size()) {
                    return true;
                } else {
                    mbrContainer.clear();
                    return false;
                }
            }

            @Override
            protected long getTimeoutMillis() {
                return 60 * 60 * 1000;
            }

            @Override
            protected long getSleepMillis() {
                // retry every 1 minute
                return 60 * 1000;
            }

        }.execute();

        if (success) {
            if (!reservedMembersByOwner.containsKey(owner)) {
                reservedMembersByOwner.put(owner, new LinkedHashMap<>());
            }
            reservedMembersByOwner.get(owner).put(title, mbrContainer.get(0));
            return mbrContainer.get(0);
        } else {
            throw new RuntimeException("Timeout trying to get next available member: " + title);
        }
    }

    /**
     * Release all members reserved for the specified owner.
     *
     * @param owner
     */
    public void releaseByOwner(String owner) {
        log.warn("owner=" + owner);

        if (reservedMembersByOwner.containsKey(owner)) {
            MbrDao mbrDao = new MbrDao(MyBatisConnectionFactory.getSqlSessionFactory());
            for (String title : reservedMembersByOwner.get(owner).keySet()) {
                Map<String, Object> mbr = reservedMembersByOwner.get(owner).get(title);
                Map<String, String> member = DataTableUtils.asMapOfStrings(mbr);
                try {
                    log.warn("Trying to release member " + member.toString());
                    long mbrId = (Long) mbr.get("mbr_id");
                    mbrDao.releaseMemberByMemberId(mbrId);
                    log.warn("Released");
                } catch (Exception e) {
                    e.printStackTrace();
                    log.error("Fail to release member " + member.toString());
                }
            }
            log.warn("Remove owner " + owner + " from memory.");
            reservedMembersByOwner.remove(owner);
        } else {
            log.warn("No members reserved for " + owner);
        }

    }
}
