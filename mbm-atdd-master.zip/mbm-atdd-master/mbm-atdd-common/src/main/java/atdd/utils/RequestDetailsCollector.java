package atdd.utils;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.*;

public class RequestDetailsCollector {
    private static final Logger log = Logger.getLogger(RequestDetailsCollector.class);

    public static List<String> collect(WebDriver d) {
        new WebDriverWait(d, 20).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2/span[.='Request Details']")));
        Set<String> keyList = new HashSet<>();
        List<String> list = new ArrayList<>();

        if (1 == d.findElements(By.xpath("//h2/span[.='Request Details']")).size()) {
            Map<String, List<List<String>>> namedLists = new LinkedHashMap<String, List<List<String>>>();
            List<List<String>> ls = new ArrayList<>();


            //Patient Details
            List<List<String>> patient_Details = TestUtils.tableAsLists(d, "//table[@class='wrapper-table ng-scope']//table[@id='patientDetailsSection']", 10);


            //Service Details
            List<List<String>> service_Details = TestUtils.tableAsLists(d, "//table[@class='wrapper-table ng-scope']//table[@id='serviceDetailsSection']", 10);

            //Clinical Details


            List<List<String>> clinical_Details = TestUtils.tableAsLists(d, "//table[@class='wrapper-table ng-scope']//table[@id='clinicalDetailsSection']", 10);


            namedLists.put("rdpd", patient_Details);
            namedLists.put("rdsd", service_Details);
            namedLists.put("rdcd", clinical_Details);

            for (String name : namedLists.keySet()) {
                String label = null;
                List<List<String>> lists = namedLists.get(name);
                for (int j = 0; j < lists.size(); j++) {
                    if (lists.get(j).size() == 0)
                        break;
                    if (lists.get(j).get(0).contains("\n"))
                        label = lists.get(j).get(0).substring(0, lists.get(j).get(0).indexOf("\n"));
                    list.add(label);


                }

            }


        }
        return list;
    }
}