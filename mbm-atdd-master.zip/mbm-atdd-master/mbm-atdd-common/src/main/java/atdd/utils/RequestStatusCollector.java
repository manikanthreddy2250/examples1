package atdd.utils;

import atdd.dao.mbm.HscDao;
import atdd.dao.mbm.MyBatisConnectionFactory;
import atdd.test.stepsets.AuthorizationRequest;
import cucumber.api.Scenario;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class RequestStatusCollector {
    private static final Logger log = Logger.getLogger(RequestStatusCollector.class);
    public static final String MODE = "RequestStatusCollector_mode";

    public static List<String> getModes(Map<String, String> pf) {
        String sMode = null != pf && pf.containsKey(RequestStatusCollector.MODE)
                ? pf.get(RequestStatusCollector.MODE)
                : Conf.getInstance().getProperty(RequestStatusCollector.MODE);
        List<String> modes = Arrays.asList(sMode.split(","));
        return modes;
    }

    public static Map<String, Map<String, String>> collect(long hscID, WebDriver d, Scenario scenario, List<String> modes, Map<String, String> pf) {
        Map<String, Map<String, String>> outcome = new LinkedHashMap<>();

        if (modes.contains("db")) {
            outcome.put(AuthorizationRequest.OUTCOME_HSC_SNAPSHOT, collectDb(hscID, d, scenario, false));
        }
        if (modes.contains("simpleDb")) {
            outcome.put(AuthorizationRequest.OUTCOME_HSC_SNAPSHOT, collectDb(hscID, d, scenario, true));
        }
        if (modes.contains("page") && null != d) {
            outcome.put(AuthorizationRequest.OUTCOME_REQUEST_STATUS, collect2(d, pf));
        }
        if (modes.contains("simplePage") && null != d) {
            outcome.put(AuthorizationRequest.OUTCOME_REQUEST_STATUS, collect3(d, pf));
        }

        return outcome;
    }

    private static Map<String, String> collectDb(long hscID, WebDriver d, Scenario scenario, boolean simple) {
        if (hscID < 0) {
            hscID = TestUtils.getHscIdFromURL(d.getCurrentUrl());
        }

        SqlSessionFactory sqlSession = null;
        try {
            sqlSession = MyBatisConnectionFactory.getSqlSessionFactory();
        } catch (Exception e) {
            Assert.fail("Unable to connect to MBM database");
        }

        if (null != d) {
            Map<String, Object> hsc = new HscDao(sqlSession).selectById(hscID).get(0);
            log.warn("hsc collected: " + hsc.toString());
            boolean resendIgnore = Boolean.parseBoolean(Conf.getInstance().getProperty("resendIgnore"));
            if (!hsc.containsKey("pri_srvc_ref_nbr") && !resendIgnore) {
                boolean success = AuthorizationRequest.retryResend(scenario, d, hscID);
                if (!success) {
                    throw new RuntimeException("Timeout trying to resend request hsc_id=" + hscID);
                }
                TestUtils.refreshPage(d);
            }
        }

        Map<String, Map<String, String>> dbGroup = new LinkedHashMap<>();
        AuthorizationRequest.appendDbInfo(dbGroup, hscID, simple);
        Map<String, String> hscSnapshot = WhiteBoard.snapshot(dbGroup);

        return hscSnapshot;
    }

    public static Map<String, String> collect3(WebDriver d, Map<String, String> pf) {
        new WebDriverWait(d, 20).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span/span[.='Request Status']")));
        if (1 == d.findElements(By.xpath("//span/span[.='Request Status']")).size()) {
            Map<String, List<List<String>>> namedLists = new LinkedHashMap<String, List<List<String>>>();

            List<List<String>> auth1 = TestUtils.tableAsLists(d, "((//table[@class='wrapper-table detail'])[2]//table[@class='panelTable'])[1]", 30);
            auth1.add(Arrays.asList("HscID", "" + TestUtils.getHscIdFromURL(d.getCurrentUrl())));
            namedLists.put("auth", auth1);
            String status = auth1.get(0).get(1);
            log.warn("status=" + status);
            if (status.toLowerCase().contains("approved")) {
                List<List<String>> auth2 = TestUtils.tableAsLists(d, "((//table[@class='wrapper-table detail'])[2]//table[@class='panelTable'])[2]", 10);
                namedLists.get("auth").addAll(auth2);
            }

            switch (pf.get(MBM.AUTH_AUTHORIZATION_TYPE)) {
                case "Occupational Therapy":
                    collectPHAuth(d, namedLists);
                    break;
                case "Speech Therapy":
                    collectPHAuth(d, namedLists);
                    break;
                case "Physical Therapy":
                    collectPHAuth(d, namedLists);
                    break;
                default:
                    break;
            }

            Map<String, String> profile = new LinkedHashMap<>();
            for (String name : namedLists.keySet()) {
                List<List<String>> lists = namedLists.get(name);
                for (List<String> list : lists) {
                    if (2 == list.size()) {
                        profile.put(name + "_" + TestUtils.makeName(list.get(0)), v(list.get(1)));
                    }
                }
            }

            Map<String, String> result = new LinkedHashMap<>(profile.size());
            for (String key : profile.keySet()) {
                String newKey = key.replace("_", "");
                if ((newKey.equals("authAuthorizationNumber") || newKey.equals("authRequestNumber")) && profile.get(key).length() == 6) {
                    String s = "000" + profile.get(key);
                    result.put(newKey, s);
                    log.warn(newKey + "=" + s);
                } else {
                    result.put(newKey, profile.get(key));
                }
                log.warn(newKey + "=" + profile.get(key));
            }

            return result;
        }
        return null;
    }

    private static void collectPHAuth(WebDriver d, Map<String, List<List<String>>> namedLists) {
        //Request Details for Physical Health
        List<List<String>> requestDetailsPH = TestUtils.tableAsLists(d,"(//div[@id='requestDetailsSection']//table)[2]", 10);
        namedLists.put("rdph", requestDetailsPH);
        //patient_Questions for Physical Health
        List<List<String>> patient_Questions1 = TestUtils.tableAsLists(d, "(//div[@id='patientHealthSection\"']//table)[2]", 10);
        List<List<String>> patient_Question2 = TestUtils.tableAsLists(d, "(//div[@id='patientHealthSection\"']//table)[4]", 10);

        //Current Functional Measure Scores for Physical Health
        List<List<String>> foms = TestUtils.tableAsLists(d, "(//div[@id='clinicalStatusSection']//table)[2]", 10);

        namedLists.put("foms", foms);

        namedLists.put("pq1", patient_Questions1);
        namedLists.put("pq2", patient_Question2);
    }

    private static void collect1NonPHAuth(WebDriver d, Map<String, List<List<String>>> namedLists) {
        //patient_Questions for Physical Health
        List<List<String>> rp_pd = TestUtils.tableAsLists(d, "//table[@id='requestingProviderDetailsSection']", 10);
        List<List<String>> rp_pc_ct = TestUtils.tableAsLists(d, "//table[@id='contactPersonDetailsSection']", 10);

        //Request Details
        List<List<String>> rd_pd = TestUtils.tableAsLists(d, "(//div[@id='requestDetailsSection']/table//table)[1]", 10);
        List<List<String>> rd_sd = TestUtils.tableAsLists(d, "(//div[@id='requestDetailsSection']/table//table)[2]", 10);
        List<List<String>> rd_cd = TestUtils.tableAsLists(d, "(//div[@id='requestDetailsSection']/table//table)[3]", 10);
        namedLists.put("rppd", rp_pd);
        namedLists.put("rppc", rp_pc_ct);
        namedLists.put("rdpd", rd_pd);
        namedLists.put("rdsd", rd_sd);
        namedLists.put("rdcd", rd_cd);
    }

    public static Map<String, String> collect2(WebDriver d, Map<String, String> pf) {
        new WebDriverWait(d, 20).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span/span[.='Request Status']")));
        if (1 == d.findElements(By.xpath("//span/span[.='Request Status']")).size()) {
            Map<String, List<List<String>>> namedLists = new LinkedHashMap<String, List<List<String>>>();

            List<List<String>> auth1 = TestUtils.tableAsLists(d, "((//table[@class='wrapper-table detail'])[2]//table[@class='panelTable'])[1]", 30);
            namedLists.put("auth", auth1);
            String status = auth1.get(0).get(1);
            log.warn("status=" + status);
            if (status.toLowerCase().contains("approved")) {
                List<List<String>> auth2 = TestUtils.tableAsLists(d, "((//table[@class='wrapper-table detail'])[2]//table[@class='panelTable'])[2]", 10);
                namedLists.get("auth").addAll(auth2);
            }

            switch (pf.get(MBM.AUTH_AUTHORIZATION_TYPE)) {
                case "Outpatient Chemotherapy":
                case "Specialty Pharmacy":
                case "Cancer Supportive Drug Only":
                case "Therapeutic Radiopharmaceuticals":
                    collect2NonPHAuth(d, namedLists);
                    break;
                case "Occupational Therapy":
                case "Speech Therapy":
                case "Physical Therapy":
                    collectPHAuth(d, namedLists);

                    break;

            }
            Map<String, String> raw = new LinkedHashMap<>();
            Map<String, String> profile = new LinkedHashMap<>();
            for (String name : namedLists.keySet()) {
                List<List<String>> lists = namedLists.get(name);
                for (List<String> list : lists) {
                    if (2 == list.size()) {
                        raw.put(name + "::" + list.get(0), list.get(1));
                        profile.put(name + "_" + TestUtils.makeName(list.get(0)), v(list.get(1)));
                    }
                }
            }

            Map<String, String> result = new LinkedHashMap<>(profile.size());
            for (String key : profile.keySet()) {
                String newKey = key.replace("_", "");
                result.put(newKey, profile.get(key));
                log.warn(newKey + "=" + profile.get(key));
            }

            return result;
        }
        return null;
    }

    private static void collect2NonPHAuth(WebDriver d, Map<String, List<List<String>>> namedLists) {
        //Requesting Provider
        List<List<String>> rp_pd = TestUtils.tableAsLists(d, "(//div[@id='requestingProviderSection']/table[2]/tbody//table)[1]", 10);
        List<List<String>> rp_pc_ct = TestUtils.tableAsLists(d, "(//div[@id='requestingProviderSection']/table[2]/tbody//table)[2]", 10);
        namedLists.put("rppd", rp_pd);
        namedLists.put("rppc", rp_pc_ct);

        //Member
        List<List<String>> member1 = TestUtils.tableAsLists(d, "(//div[@id='memberInformationSection']/table[2]/tbody//table)[1]", 10);
        List<List<String>> member2 = TestUtils.tableAsLists(d, "(//div[@id='memberInformationSection']/table[2]/tbody//table)[2]", 10);
        namedLists.put("memb", member1);
        namedLists.get("memb").addAll(member2);

        //Request Details
        List<List<String>> rd_pd = TestUtils.tableAsLists(d, "(//div[@id='requestDetailsSection']/table//table)[1]", 10);
        List<List<String>> rd_sd = TestUtils.tableAsLists(d, "(//div[@id='requestDetailsSection']/table//table)[2]", 10);
        List<List<String>> rd_cd = TestUtils.tableAsLists(d, "(//div[@id='requestDetailsSection']/table//table)[3]", 10);
        namedLists.put("rdpd", rd_pd);
        namedLists.put("rdsd", rd_sd);
        namedLists.put("rdcd", rd_cd);
    }

    public static Map<String, String> collect1(WebDriver d) {
        new WebDriverWait(d, 20).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span/span[.='Request Status']")));
        if (1 == d.findElements(By.xpath("//span/span[.='Request Status']")).size()) {
            List<List<String>> auth1 = TestUtils.tableAsLists(d, "((//table[@class='wrapper-table detail'])[2]//table[@class='panelTable'])[1]", 30);
            List<List<String>> auth2 = TestUtils.tableAsLists(d, "((//table[@class='wrapper-table detail'])[2]//table[@class='panelTable'])[2]", 10);

            List<List<String>> member1 = TestUtils.tableAsLists(d, "(//div[@id='memberInformationSection']/table[2]/tbody//table)[1]", 10);
            List<List<String>> member2 = TestUtils.tableAsLists(d, "(//div[@id='memberInformationSection']/table[2]/tbody//table)[2]", 10);

            List<List<String>> rp_pd = TestUtils.tableAsLists(d, "(//div[@id='requestingProviderSection']/table[2]/tbody//table)[1]", 10);
            List<List<String>> rp_pc_ct = TestUtils.tableAsLists(d, "(//div[@id='requestingProviderSection']/table[2]/tbody//table)[2]", 10);

            List<List<String>> sp_pd = TestUtils.tableAsLists(d, "//div[@id='servicingProviderSection']/table//table", 10);

            List<List<String>> rd_pd = TestUtils.tableAsLists(d, "(//div[@id='requestDetailsSection']/table//table)[1]", 10);
            List<List<String>> rd_sd = TestUtils.tableAsLists(d, "(//div[@id='requestDetailsSection']/table//table)[2]", 10);
            List<List<String>> rd_cd = TestUtils.tableAsLists(d, "(//div[@id='requestDetailsSection']/table//table)[3]", 10);

            List<List<String>> cs_qa = TestUtils.asLists(d, "//form[@name='ocmAssessmentConductorForm']//div[contains(@class, 'question-wrapper')]", "span[1]", "span[2]");

            List<Map<String, String>> rgDrugs0 = TestUtils.tableAsMaps(d, "//div[@class='regimen-div']//table", 10);
            List<Map<String, String>> rgAutoDrugs1 = null;
            List<Map<String, String>> rgAutoDrugs2 = null;
            List<Map<String, String>> rgAutoDrugs3 = null;
            List<Map<String, String>> rgCustomDrugs2 = null;
            List<Map<String, String>> rgCustomDrugs3 = null;
            List<List<String>> rgCustomDrugs4 = null;
            boolean isSupportive = false;
            boolean isCustomRegimen = false;
            if (d.findElements(By.id("supportiveDrugSection")).size() > 0) {
                isSupportive = true;
                //TODO
            } else {
                if (1 == d.findElements(By.id("customRegimenHeaderWrapper")).size()) {
                    isCustomRegimen = true;
                    rgCustomDrugs2 = TestUtils.tableAsMaps(d, "(//div[@id='regimenSection']/table[2]//table)[2]", 10);
                    rgCustomDrugs3 = TestUtils.tableAsMaps(d, "(//div[@id='regimenSection']/table[2]//table)[3]", 10);
                    rgCustomDrugs4 = TestUtils.tableAsLists(d, "(//div[@id='regimenSection']/table[2]//table)[4]", 10);
                } else {
                    rgAutoDrugs1 = TestUtils.tableAsMaps(d, "(//div[@id='regimenSection']/table[2]//table)[1]", 10);
                    rgAutoDrugs2 = TestUtils.tableAsMaps(d, "(//div[@id='regimenSection']/table[2]//table)[2]", 10);
                    rgAutoDrugs3 = TestUtils.tableAsMaps(d, "(//div[@id='regimenSection']/table[2]//table)[3]", 10);
                }
            }
            Map<String, List<List<String>>> namedLists = new LinkedHashMap<String, List<List<String>>>();
            namedLists.put("auth", auth1);
            namedLists.get("auth").addAll(auth2);
            namedLists.put("memb", member1);
            namedLists.get("memb").addAll(member2);
            namedLists.put("rppd", rp_pd);
            namedLists.put("rppc", rp_pc_ct);
            namedLists.put("sppd", sp_pd);
            namedLists.put("rdpd", rd_pd);
            namedLists.put("rdsd", rd_sd);
            namedLists.put("rdcd", rd_cd);
            namedLists.put("csqa", cs_qa);

            Map<String, Map<String, Map<String, String>>> namedMaps = new LinkedHashMap<String, Map<String, Map<String, String>>>();
            if (isCustomRegimen) {
                namedMaps.put("rgdr", DataTableUtils.merge(false, "Drug Code", rgDrugs0, rgCustomDrugs2));
                namedMaps.put("rgid", DataTableUtils.merge(false, null, rgCustomDrugs3));
                namedLists.put("rgid", rgCustomDrugs4);

            } else {
                namedMaps.put("rgdr", DataTableUtils.merge(false, "Drug Code", rgDrugs0, rgAutoDrugs3));
                namedMaps.put("rgid", DataTableUtils.merge(false, null, rgAutoDrugs1, rgAutoDrugs2));
            }

            Map<String, String> raw = new LinkedHashMap<>();
            Map<String, String> profile = new LinkedHashMap<>();
            for (String name : namedLists.keySet()) {
                List<List<String>> lists = namedLists.get(name);
                for (List<String> list : lists) {
                    if (2 == list.size()) {
                        raw.put(name + "::" + list.get(0), list.get(1));
                        profile.put(name + "_" + TestUtils.makeName(list.get(0)), v(list.get(1)));
                    }
                }
            }
            String memb_Full_Name = profile.get("memb_Full_Name");
            String[] p = memb_Full_Name.split("\\s+");
            raw.put("memb::" + "Last Name", p[p.length - 1]);
            profile.put("memb_Last_Name", p[p.length - 1]);
            raw.put("memb::" + "Last Name", p[0]);
            profile.put("memb_First_Name", p[0]);
            if (p.length > 2) {
                raw.put("memb::" + "Middle Name", p[1]);
                profile.put("memb_Middle_Name", p[1]);
            }

            for (String name : namedMaps.keySet()) {
                Map<String, Map<String, String>> mapsIndexedByKeyHeader = namedMaps.get(name);
                if (null == mapsIndexedByKeyHeader) {
                    log.warn("Not collected: " + name);
                    continue;
                }
                int i = 0;
                for (String key : mapsIndexedByKeyHeader.keySet()) {
                    Map<String, String> row = mapsIndexedByKeyHeader.get(key);
                    for (String header : row.keySet()) {
                        raw.put(name + "::" + header, row.get(header));
                        profile.put(name + "_" + TestUtils.makeName(header) + "_" + i, v(row.get(header)));
                    }
                    i++;
                }
            }

            Map<String, String> result = new LinkedHashMap<>(profile.size());
            for (String key : profile.keySet()) {
                String newKey = key.replace("_", "");
                result.put(newKey, profile.get(key));
                log.warn(newKey + "=" + profile.get(key));
            }

            return result;

        }
        return null;
    }


    private static String v(String s) {
        return s.replace('\n', '>').trim();
    }

}
