package atdd.utils;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class RequestSummaryCollector {
    private static final Logger log = Logger.getLogger( RequestSummaryCollector.class);

    public static Map<String, String> collect(WebDriver d, Map<String, String> pf) {
        new WebDriverWait(d, 20).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2//span[.='Request Summary']")));
        if (1 == d.findElements(By.xpath("//h2//span[.='Request Summary']")).size()) {
            Map<String, List<List<String>>> namedLists = new LinkedHashMap<String, List<List<String>>>();


            switch (pf.get(MBM.AUTH_AUTHORIZATION_TYPE)) {
                case "Occupational Therapy":
                    break;
                case "Speech Therapy":
                    break;
                case "Physical Therapy":
                    collectPHAuth(d, namedLists);
                    break;
                default:
                    break;
            }


            Map<String, String> raw = new LinkedHashMap<>();
            Map<String, String> profile = new LinkedHashMap<>();
            for (String name : namedLists.keySet()) {
                List<List<String>> lists = namedLists.get(name);
                for (List<String> list : lists) {
                    if (2 == list.size()) {
                        raw.put(name + "::" + list.get(0), list.get(1));
                        profile.put(name + "_" + TestUtils.makeName(list.get(0)), v(list.get(1)));
                    }
                }
            }

            Map<String, String> result = new LinkedHashMap<>(profile.size());
            for (String key : profile.keySet()) {
                String newKey = key.replace("_", "");
                result.put(newKey, profile.get(key));
                log.warn(newKey + "=" + profile.get(key));
            }

            return result;
        }
        return null;
    }
    private static void collectPHAuth(WebDriver d, Map<String, List<List<String>>> namedLists) {
        //Request Details for Physical Health
        List<List<String>> requestDetailsPH = TestUtils.tableAsLists(d,"(//div[@id='requestDetailsSection']//table)[2]", 10);
        namedLists.put("rdph", requestDetailsPH);
        //patient_Questions for Physical Health
        List<List<String>> patient_Questions1 = TestUtils.tableAsLists(d, "(//div[@id='patientHealthSection\"']//table)[2]", 10);
        List<List<String>> patient_Question2 = TestUtils.tableAsLists(d, "(//div[@id='patientHealthSection\"']//table)[4]", 10);

        //Current Functional Measure Scores for Physical Health
        List<List<String>> foms = TestUtils.tableAsLists(d, "(//div[@id='clinicalStatusSection']//table)[2]", 10);

        namedLists.put("foms", foms);

        namedLists.put("pq1", patient_Questions1);
        namedLists.put("pq2", patient_Question2);
    }

    private static void collect1NonPHAuth(WebDriver d, Map<String, List<List<String>>> namedLists) {
        List<List<String>> rp_pd = TestUtils.tableAsLists(d, "//table[@id='requestingProviderDetailsSection']", 10);
        List<List<String>> rp_pc_ct = TestUtils.tableAsLists(d, "//table[@id='contactPersonDetailsSection']", 10);

        //Request Details
        List<List<String>> rd_pd = TestUtils.tableAsLists(d, "(//div[@id='requestDetailsSection']/table//table)[1]", 10);
        List<List<String>> rd_sd = TestUtils.tableAsLists(d, "(//div[@id='requestDetailsSection']/table//table)[2]", 10);
        List<List<String>> rd_cd = TestUtils.tableAsLists(d, "(//div[@id='requestDetailsSection']/table//table)[3]", 10);
        namedLists.put("rppd", rp_pd);
        namedLists.put("rppc", rp_pc_ct);
        namedLists.put("rdpd", rd_pd);
        namedLists.put("rdsd", rd_sd);
        namedLists.put("rdcd", rd_cd);
    }
    private static String v(String s) {
        return s.replace('\n', '>').trim();
    }
}
