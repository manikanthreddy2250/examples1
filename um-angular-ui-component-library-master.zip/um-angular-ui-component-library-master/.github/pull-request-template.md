# Required Checks

- [ ] Ready to merge
- [ ] Validated in local, if yes please attach screen shot
- [ ] Completed self review of my own code
- [ ] Documented complex code logic
- [ ] I have added unit tests that proves my fix is effective or that my feature works

# Informational checks before merging

- [ ] Any dependency PR to merge before, if yes PR# 
- [ ] Any dependency PR to merge after, if yes PR#
