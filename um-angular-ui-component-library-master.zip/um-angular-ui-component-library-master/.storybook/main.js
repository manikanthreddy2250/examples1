
module.exports = {
  stories: [
    "../stories/**/*.stories.mdx",
    "../stories/**/*.stories.@(js|jsx|ts|tsx)"
  ],
  addons: [
    "@uitk/storybook-addon-themes",
    "@storybook/addon-links",
    "@storybook/addon-essentials",
  ]
};
