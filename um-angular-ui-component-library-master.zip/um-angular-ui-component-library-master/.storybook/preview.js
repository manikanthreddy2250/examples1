
import { setCompodocJson } from "@storybook/addon-docs/angular";
import docJson from "../documentation.json";
import '!style-loader!css-loader!sass-loader!./local-styles.scss';

setCompodocJson(docJson);

let themeList = [
  { name: 'Optum Gold', class: 'optum-gold-theme', color: '#F2b411', default: true },
  { name: 'Optum Dark', class: 'optum-dark-theme', color: '#333333' },
  { name: 'UHC Blue', class: 'uhc-blue-theme', color: '#1E3D6A' }
];

export const decorators = [
  (storyFunc) => {
    const story = storyFunc();
    const frame = document.getElementsByClassName('sb-show-main');

    let template = `<div id="theme-div" class="">${story.template}</div>`;

    if (frame[0].classList?.length < 3) {
      template = `<div id="theme-div" class="optum-gold-theme">${story.template}</div>`;
    }

    return {
      ...story,
      template: template,
    };
  },
];


export const parameters = {
  actions: { argTypesRegex: "^on[A-Z].*" },
  controls: {
    matchers: {
      color: /(background|color)$/i,
      date: /Date$/,
    },
  },
  layout: "fullscreen",
  themes: themeList,
  angularLegacyRendering: true
};
