# um-angular-ui-component-library

This is an Angular Project that created from the OCM Platform. Product family libraries create components with specific business logic that is reusable by other products. These components are created with the atoms and molecules from 
[@ecp/angular-ui-component-library](https://github.optum.com/ecp/angular-ui-component-library)

[Getting Started as a Product Family](https://github.optum.com/pages/ecp/angular-ui-component-library/?path=/story/getting-started-product-family-introduction--page)

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 11.2.9.

#### Badges

[![Storybook](https://cdn.jsdelivr.net/gh/storybookjs/brand@master/badge/badge-storybook.svg)](https://github.optum.com/pages/ecp/um-angular-ui-component-library/)
[![Master Build Status](https://jenkins-ecp-jenkins.origin-ctc-core.optum.com/buildStatus/icon?job=ecp%2Fum-angular-ui-component-library%2Fmaster&subject=Master%20Branch)](https://jenkins-ecp-jenkins.origin-ctc-core.optum.com/job/ecp/job/um-angular-ui-component-library/job/master/)
[![Fortify Build Status](https://jenkins-ecp-jenkins.origin-ctc-core.optum.com/buildStatus/icon?job=um-angular-ui-component-library%2Ffortify-um-angular-ui-component-library&subject=Fortify%20Scan)](https://jenkins-ecp-jenkins.origin-ctc-core.optum.com/view/Fortify/job/um-angular-ui-component-library/job/fortify-um-angular-ui-component-library/)
[![Sonar Build Status](https://jenkins-ecp-jenkins.origin-ctc-core.optum.com/buildStatus/icon?job=um-angular-ui-component-library%2Fsonar-um-angular-ui-component-library&subject=Sonar%20Scan)](https://jenkins-ecp-jenkins.origin-ctc-core.optum.com/view/Fortify/job/um-angular-ui-component-library/job/sonar-um-angular-ui-component-library/)


## Installation

To get started with the library, please be sure to have `npm` installed on your machine, and an Angular project initialized.

### Library installation

Run `npm install --save @ecp/um-angular-ui-component-library` to install the library as a dependency to another project and have it added to your package.json.

### Style and Design Token installation

This project uses a style dictionary and design tokens for styling. For more information checkout [ecp/style-dictionary-ui-component-library](https://github.optum.com/ecp/style-dictionary-ui-component-library)

### NPM Scripts

Task automation is based on [NPM scripts](https://docs.npmjs.com/misc/scripts).

| Task                                | Description                                                                                          |
| ------------------------------------| -----------------------------------------------------------------------------------------------------|
| `ng`                                | Pass-through to run an `ng` (Angular CLI) command                                                    |
| `start`                             | Shorthand for `storybook`                                                                            |
| `build`                             | Build web app for production in `dist/` folder                                                       |
| `test`                              | Jenkins - Run unit tests with Karma, one time test run                                               |
| `test:dev`                          | Local unit tests watching for code changes                                                           |
| `e2e`                               | Run cypress UI tests that generate cucumber reports                                                  |  
| `cypress:open`                      | Start local cypress instance for development work                                                    |
| `cypress:ci`                        | Jenkins - Cypress command used                                                                       |
| `storybook`                         | Start local storybook instance for development work                                                  |
| `packagr`                           | Jenkins - Package command                                                                            |
| `deploy-archive`                    | Jenkins - Deploy package command                                                                     |
| `build-pages`                       | Jenkins - Build github pages command                                                                 |
| `publish-pages`                     | Jenkins - Publish github command                                                                     |

## 🚀 Local Development

### ⌨️ Local Development - Running Storybook

0. Prerequisite is having npm installed:

   Install Node.js via the [app store for pc](http://appstore.uhc.com/AppInfo/AppVersionId/17515?BackToList=/AppList/AppList) or [download online for mac](https://nodejs.org/en/)

1. Go to project folder and install dependencies:

```sh
npm install
```

2. Launch development server, and then localhost should open in your browser:

```sh
npm run storybook
```

3. [Setup Intellij IDEA Auto Linting](https://github.optum.com/clinical/ocm-advisor-ui/blob/master/docs/lint_plugins.md)

4. Optional Steps: 
  - [Setup Intellij IDEA to debug .ts code](https://github.optum.com/clinical/ocm-advisor-ui/blob/master/docs/npm_in_idea.md)

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

Component in this library should start with `ecp-um`

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `--prod` flag for a production build.

### Unit Testing with Karma

- Unit tests are the same as other angular projects, located in src/lib/**/*.spec.ts
- Run locally with ```npm run test:dev```

### UI Testing with Cypress and Cucumber

1. Start storybook locally with ```npm run storybook```
2. Start cypress locally with ```npm run cypress:open```
3. Select the specs you want to run in Chromium / Electron / Edge

#### Cypress Resources

- [Cucumber Preprocessor for Cypress](https://www.npmjs.com/package/cypress-cucumber-preprocessor)
- [Step definition creation instructions](https://www.npmjs.com/package/cypress-cucumber-preprocessor#step-definitions-creation)
- Shared common steps located in ```cypress/integration/common/**```

#### More Info

- Jenkins will use command ```npm run cypress:ci``` to start storybook and run UI tests against it and then close

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI Overview and Command Reference](https://angular.io/cli) page.
