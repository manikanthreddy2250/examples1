import {Given, Then, When} from 'cypress-cucumber-preprocessor/steps.js';

/**
 * reserved for common alias action steps
 */

// click
When(`I click alias {string}`, (alias) => {
  cy.get(`@${alias}`).click();
})

When('Component alias {string} is clicked', (alias) => {
  cy.get(`@${alias}`).click();
});

When('Trigger {string} event on alias {string}', (eventName, alias) => {
  cy.get(`@${alias}`).trigger(eventName);
});

Then('Alias {string} can scroll to {string}', (alias, position) => {
  cy.get(`@${alias}`).scrollTo(position)
})
