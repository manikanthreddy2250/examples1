import {Given, Then, When} from 'cypress-cucumber-preprocessor/steps.js';

/**
 * reserved for common alias steps around 'has', 'does not have', 'is'
 */

Then(`Alias {string} has text {string}`, (alias, text) => {
  cy.get(`@${alias}`).contains(text).should('be.visible', text)
})

Then(`Alias {string} has element {string}`, (alias, element) => {
  cy.get(`@${alias}`).find(`${element}`).should('be.visible')
})

Then(`Alias {string} does not have element {string}`, (alias, element) => {
  cy.get(`@${alias}`).find(`${element}`).should('not.be.visible')
})

// has class
Then(`Alias {string} has class {string}`, (alias, className) => {
  cy.get(`@${alias}`).should('have.class', className)
})

Then(`Alias {string} does not have class {string}`, (alias, className) => {
  cy.get(`@${alias}`).should('not.have.class', className)
})

// is disabled
Then(`Alias {string} is disabled`, (alias) => {
  cy.get(`@${alias}`).should('be.disabled')
})

// css
Then(`Alias {string} has css attribute {string} with value {string}`, (alias, attr, value) => {
  if(value.startsWith('#')) {
    cy.get(`@${alias}`).should('have.css', attr, hexToRGB(value))
  } else {
    cy.get(`@${alias}`).should('have.css', attr, value)
  }
})

// converts hex to rgba for color attributes
// source - https://stackoverflow.com/questions/21646738/convert-hex-to-rgba
function hexToRGB(hex, alpha) {
  var r = parseInt(hex.slice(1, 3), 16),
    g = parseInt(hex.slice(3, 5), 16),
    b = parseInt(hex.slice(5, 7), 16);

  if (alpha) {
    return "rgba(" + r + ", " + g + ", " + b + ", " + alpha + ")";
  } else {
    return "rgb(" + r + ", " + g + ", " + b + ")";
  }
}
