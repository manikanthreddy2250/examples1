import { Given } from 'cypress-cucumber-preprocessor/steps';

export function goToElementStory(component, storyId) {
  const url = `/iframe.html?id=design-system-elements-${component}--${storyId}&viewMode=story`;
  return cy.visit(url);
}

export function goToComponentsStory(component, storyId) {
  const url = `/iframe.html?id=design-system-components-${component}--${storyId}&viewMode=story`;
  return cy.visit(url);
}

Given('Navigate to element story {string} for component {string} and get {string} as {string}', (storyId, component, elements, as) => {
  goToElementStory(component, storyId).get(elements).as(as);
});

Given('Navigate to component story {string} for component {string} and get {string} as {string}', (storyId, component, elements, as) => {
  goToComponentsStory(component, storyId).get(elements).as(as);
});

Given('I navigate to story {string} for component {string}', (storyId, component) => {
  goToElementStory(component, storyId);
});
