import { Given, Then, When } from 'cypress-cucumber-preprocessor/steps';

/**
 * reserved for common setup steps
 */

const getIframeDocument = () =>
  cy.get("#storybook-preview-iframe").its("0.contentDocument").should("exist");

const getIframeBody = () =>
  getIframeDocument().its("body").should("not.be.undefined").then(cy.wrap);

Given('Storybook Loads', () => {
  cy.visit("/");
  getIframeDocument();
  getIframeBody();
})

Then(`I open page {string}`, (pageID) => {
  cy.visit(`/iframe.html?id=${pageID}&viewMode=story`);
});

Given('Component {string} exists, set alias {string}', (selector, alias) => {
  cy.get(selector)
    .should('exist')
    .as(alias);
});

Given('Component {string} index number {int} exists, set alias {string}', (selector, index, alias) => {
  cy.get(selector).eq(index)
    .should('exist')
    .as(alias);
});


//exists
Then(`Element {string} exists`, (element) => {
  cy.get(element).should('exist');
});

Then(`Element {string} not exists`, (element) => {
  cy.get(element).should('not.exist');
});
