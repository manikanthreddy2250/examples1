# Code Standards and Guide

## Component Naming

### General Rules
All components should be saved in their own directory under a shared library directory `lib`.
All components files should be self-contained in a directory. 
Follow `kebab-case` for file naming followed by type of file:

* Typescript/Javascript - `<component-name>.component.ts/js`
* Spec - `<component-name>.spec.ts`
* Module - `<component-name>.module.ts`
* Style - `<component-name>.component.scss`
* Stories - `<component-name>.stories.ts`


### Selector

For component selectors use the project name prefix (TBD). Selectors will also use `kebab-case`.
The naming will follow `<project-name>-<component-name>`

*Example:*
```
<project-name-button></project-name-button>
<project-name-card></project-name-card>
<project-name-card></project-name-modal>
```

### Component Class

We will opt to drop component from class name for a more clean and less verbose naming. 
All components should be called by name in Typescript or Javascript. 

For instance, instead of `export class ButtonComponent` we can use `export class Button`.

#### Variables, Properties and Methods

All `variables`, `properties` and `methods` stand alone or in classes and functions will use `camelCase`
-- meaning all words after the first will have capital first letter with no space or symbols.

#### Interfaces and Classes

All `Interface` and `Classes` will follow `PascalCase` -- meaning all words will have capital first letter with no space or symbols.

### Modules

All `modules` must follow `camelCase` be sure to keep it short but descriptive. 

**Do not over burden the module file.** 

In other words, only add declarations, imports, providers etc. as needed for the component.

## CSS (Styling)

### General Rules

All CSS classes should follow the project name prefix (TBD). The names should also be `kebab-case`. Using the hyphen in-between each word.

Naming should follow structure of [BEM – Block Element Modifier](http://getbem.com/naming/). Each element should follow structure of block, element and modifier.

The first element in the HTML would be the parent block, the inner html would be elements and modifiers are changes to elements based on needs. All class names should be descriptive and short as possible.

The naming should follow the structure described below:

#### Block:

Blocks are no more than sections. These would be the flex boxes, grids and etc. Use any CSS for layout of an element in a block. This html must follow the class naming of `<project-name>-<block-name>`

*While not always needed but try to encase all elements in a block.*

*Example:*
```
<div class="block">{Elements}</div>
```

#### Elements:

Elements are the individual pieces in a section. They can be anything buttons, cards, lists or even made of other sections. These elements should follow the class naming of `<project-name>-<block-name>-<element-name>`

*Example:*
```
<div class="project-block">
    <div class="project-block-element"></div>
</div>
```


####	Modifiers:
Modifiers are applied to elements. These control how the element looks and behaves apart from their normal behavior.

Take for instance a button. We can have element styling of our button which looks and feels a certain way each time; 
however, in one instance we need to use the primary styling and the secondary styling in another. We can achieve this using the modifiers.

The naming of these classes will be `<project-name>-<block-name>-<element-name--<modifier>>`

*This does not restrict us from using elements with or without modifiers. The choice and flexibility is in the coder.*

*Example:*
```
<div class="project-block">
    <div class="project-block-element"></div>
    <div class="project-block-element--modifier-one"></div>
    <div class="project-block-element--modifier-two"></div>
</div>
```

