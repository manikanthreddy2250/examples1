# Contribution Guide

If you are looking to contribute to our core components, follow the guidelines below:

* For code change on existing component
  * Be sure to not remove any existing features
    * if needed, please specify reasoning and alternatives
* For new components, please refer to [Angular Material](https://material.angular.io/) as starting off point. 


## Submitting PR

Before you submit a PR, follow the checklist below:

* The code must pass Sonar with unit test on all new code.
* All components must also have behavior driven UI tests. Refer to the [README](README.md) for more details.
* Add stories for your component or feature
* Add the proper documentation on how to implement the new code.

1. Make changes on a new branch:
   ```git checkout -b <branchName> master```
   
2. Commit your changes using a descriptive commit message.
Specify the changes and if any new dependencies were added.
 ```
 git commit -a
 ```
   
3. Push your branch to GitHub:
```
git push <branchName>
```

4. In GitHub, send a pull request to components:master.

5. If we suggest changes then make the required updates.

6. Rebase your branch and force push to your GitHub repository (this will update your Pull Request):
```
git rebase master -i
git push -f
```
