export const ECP_DOMAIN = 'ecp';

// env variable url paths
export const INDIVIDUAL_DOMAIN_URL_PATH = 'ecp.api.indv_domain_url';
export const GET_CONFIG_URL_PATH = 'ecp.api.get_config_url';
export const CASE_WF_API_URL_PATH = 'ecp.api.case_wf_api_url';
export const HEALTH_SERVICE_DOMAIN_URL_PATH = 'ecp.api.health_service_domain_url';
export const GET_REF_NEW_URL_PATH = 'ecp.api.get_ref_new_url';
export const GET_CASE_HEADER_URL_PATH = 'ecp.api.get_case_header_url';
export const GET_MEMBER_DETAILS_URL_PATH = 'ecp.api.get_member_details_url';
export const GET_MEDICAL_REVIEW_URL = 'ecp.api.get_medical_review_url';
export const GUIDELINES_FUNCTION_URL = 'ecp.api.guidelines_function_url';
export const GUIDELINES_FUNCTION_API_URL = 'ecp.api.guidelines_function_api_url';
export const GET_HSC_AUTH_DETAILS_GRAPHQL_FUNC_HTTP_URL = 'ecp.api.get_hsc_auth_details_graphql_func_http_url';
export const GET_QUESTIONS_URL = 'ecp.api.get_questions_url';
export const GET_GUIDELINES_URL = 'ecp.api.get_guidelines_url';
export const GET_HSC_AUTH_DETAILS_URL = 'ecp.api.get_hsc_auth_details_url';
export const MEMBERSHIP_DOMAIN_URL_PATH = 'ecp.api.membership_domain_url';
export const GET_TASK_ASSIGNMENT_URL = 'ecp.api.get_task_assignment_url';
export const GET_IP_DMN_RULE_URL_PATH = 'ecp.api.get_ip_dmn_rule_url_path';
export const SERVICE_ETA_URL_PATH = 'ecp.api.get_service_eta_url_path';
export const USER_ATTRIBUTES_URL_PATH = 'ecp.api.user_attr_url';
export const PROVIDER_SERVICE_DOMAIN_URL_PATH = 'ecp.api.provider_service_domain_url';
export const UTILIZATION_MGMNT_FUNCS_URL = 'ecp.api.utilization_mgmnt_funcs_url';
export const UM_RULES_SERVICE_URL = 'ecp.api.um_rules_service_url';
export const CASE_MANAGEMENT_BPM_SERVICE_URL = 'ecp.api.case_management_bpm_service_url';
//config keys
export const MYTASKS_LIST_TABLE_HEADERS = 'my_tasks_config_table_headers';
export const MY_TASKS_STATUS_ACTION_CONFIG = 'my_tasks_status_action_config';
export const CASE_HEADER_DETAILS = 'case_header_details';
export const ROLE_MD = 'case_wf_mgmt_ui_md';
export const ROLE_NURSE = 'case_wf_mgmt_ui_nurse';
export const CLIENT_REF_DISPLAY_DMN = 'ClientRefDisplay';
export const GUIDELINES_BPMN_URL = 'ecp.api.guidelines_bpmn_url';
export const GUIDELINES_DRAFT_DMN_URL = 'ecp.api.guidelines_draft_dmn_url';
export const GUIDELINES_IP_DMN_URL = 'ecp.api.guidelines_ip_dmn_url';
export const SECURE_EMAIL_URL = 'ecp.api.secure_email_url';
export const LOG_HISTORY_TABLE_HEADERS_CONFIG = 'log_history_config';
export const REQUEST_CLINICAL_TYPE_ECP = 'request_clinical_type_ecp';
export const REQUEST_CLINICAL_TYPE_UHC = 'request_clinical_type_uhc';
export const CASE_TYPE_CONFIG = 'case_type_config';


