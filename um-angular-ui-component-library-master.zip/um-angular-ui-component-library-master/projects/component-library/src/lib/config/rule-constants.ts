export const RulesConstants = {
  BPM_APP_NAME : 'umcasemgmt',
  BPM_RULE : 'dmngrp',
  X_BPM_EXTERNAL_REF_ID : 'case_mgmt_rule_evaluation',
};
