export const WorkFlowConstants = {
  X_BPM_EXTERNAL_REF_ID: 'case_mgmt_workflow_execution',
  BPM_PROCESS : 'bpmgrp',
};
