import { Injectable } from '@angular/core';

@Injectable()
export class Constants {
  static readonly UM_CLINICAL_GUIDELINES_APP_NAME = 'clinical_guidelines_ui';
  static readonly 'SUBJECT_ID_TYPE_HSC_ID_REF_ID'=20047;
  static readonly MEMBER_COMMUNICATION_CHANNEL_EMAIL_REF_ID = 17272;
  static readonly MEMBER_COMMUNICATION_CHANNEL_FAX_REF_ID = 17271;
  static readonly SUBJECT_ID_TYPE_ASSIGNMENT_ID_REF_ID = 74005;
  static readonly MEMBER_COMMUNICATION_PENDING_STATUS_REF_ID = 20065;
  static readonly MEMBER_COMMUNICATION_OUTBOUND_DIRECTION_REF_ID = 25010;
  static readonly MEMBER_COMMUNICATION_MANUAL_TYPE_REF_ID = 60080;
  static readonly MEMBER_COMMUNICATION_CATEGORY_UTILIZATION_MGMT_REF_ID = 25050;
  static readonly ACTIVITY_TYPE_REQUEST_CLINICAL_REF_ID = 73569;
  static readonly TRACKING_DISABLED = false;
}
