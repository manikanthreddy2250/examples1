export interface ActiveButton {
  name: string;
  active: boolean;
}
