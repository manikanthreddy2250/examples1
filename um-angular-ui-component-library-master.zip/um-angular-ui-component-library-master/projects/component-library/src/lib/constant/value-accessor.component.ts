import { Input } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';


/**
 * Allows a component to become a reactive form element.
 *
 * @export
 * @abstract
 * @class AccessorComponent
 * @implements {ControlValueAccessor}
 */
export abstract class ValueAccessor<T extends unknown> implements ControlValueAccessor {
  /**
   * set the item as disabled.
   *
   * @memberof AccessorComponent
   */
  @Input() public disabled = false;
  /**
   * Whether or not this component is required.
   *
   * @type {boolean}
   * @memberof AccessorComponent
   */
  @Input() public required: boolean = false;
  /**
   * The name of the component.
   *
   * @type {string}
   * @memberof AccessorComponent
   */
  @Input() public name: string = '';
  /**
   * The components value.
   *
   * @protected
   * @type {string|number|object}
   * @memberof AccessorComponent
   */
  protected _value: T;
  /**
   * Gets the components value.
   *
   * @memberof AccessorComponent
   */
  public get value() {
    return this._value;
  }
  /**
   * Sets the components value.
   *
   * @memberof AccessorComponent
   */
  public set value(value: T) {
    this._value = value;
    this.onChange(value);
    this.onTouched();
    if (typeof this.valueUpdated == 'function') {
      this.valueUpdated(value);
    }
  }
  /**
   * Triggered when the select box is changed.
   *
   * @protected
   * @memberof AccessorComponent
   */
  protected onChange = (_: T) => { };
  /**
   * Triggered when the select box is blurred.
   *
   * @protected
   * @memberof AccessorComponent
   */
  protected onTouched = () => { };
  /**
   * Registers the change event.
   *
   * @param {*} fn
   * @memberof AccessorComponent
   */
  public registerOnChange(fn: () => T): void {
    this.onChange = fn;
  }
  /**
   * Registers the touch event.
   *
   * @param {()=>void} fn
   * @memberof AccessorComponent
   */
  public registerOnTouched(fn: () => T): void {
    this.onTouched = fn;
  }
  /**
   * Sets a new value for the select box.
   *
   * @param {AccessorType} value The new value.
   * @memberof AccessorComponent
   */
  public writeValue(value: T): void {
    if (value !== undefined) {
      this.value = value;
    }
  }
  /**
   * Sets the disabled state of the select box.
   *
   * @param {boolean} isDisabled The new state.
   * @memberof AccessorComponent
   */
  public setDisabledState(isDisabled: boolean): void {
    this.disabled = isDisabled;
  }
  /**
   * Empty function that can be overridden in your component.
   */
  valueUpdated(value: T): void { };
}
