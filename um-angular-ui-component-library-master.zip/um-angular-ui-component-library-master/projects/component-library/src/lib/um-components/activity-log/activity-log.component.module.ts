import {NgModule} from "@angular/core";
import {ActivityLogComponent} from "./activity-log.component";
import {CommonModule} from "@angular/common";
import {BrowserModule} from "@angular/platform-browser";
import {BrowserAnimationsModule} from "@angular/platform-browser/animations";
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import {HttpClientModule} from "@angular/common/http";
import {MatGridListModule} from "@angular/material/grid-list";
import {MatIconModule} from "@angular/material/icon";
import {TableModule} from "@ecp/angular-ui-component-library/table";
import {ButtonModule} from "@ecp/angular-ui-component-library/button";
import {TabsModule} from "@ecp/angular-ui-component-library/tabs";
import {IconsModule} from "@ecp/angular-ui-component-library/icons";
import {SortModule} from "@ecp/angular-ui-component-library/sort";
import {LinkModule} from "@ecp/angular-ui-component-library/link";
import {PaginatorModule} from "@ecp/angular-ui-component-library/paginator";
import {ProgressSpinnerModule} from "@ecp/angular-ui-component-library/progress-spinner";
import {AuthLibraryModule} from "@ecp/auth-library";
import {ButtonGroupModule} from "@ecp/angular-ui-component-library/button-group";
import {RadioButtonModule} from "@ecp/angular-ui-component-library/radio-button";
import {CardModule} from "@ecp/angular-ui-component-library/card";
import {InputModule} from "@ecp/angular-ui-component-library/input";
import {UserAuthService} from "../services/auth/user.service";
import {TagsModule} from "@ecp/angular-ui-component-library/tags";
import {AccordianModule} from "@ecp/angular-ui-component-library/accordian";
import {MatExpansionModule} from "@angular/material/expansion";

@NgModule({
  declarations: [
    ActivityLogComponent
  ],
  imports: [
    AccordianModule,
    CommonModule,
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    MatGridListModule,
    MatIconModule,
    TableModule,
    ButtonModule,
    TabsModule,
    IconsModule,
    SortModule,
    LinkModule,
    PaginatorModule,
    ProgressSpinnerModule,
    AuthLibraryModule,
    ButtonGroupModule,
    RadioButtonModule,
    CardModule,
    InputModule,
    TagsModule,
    MatExpansionModule
  ],
  exports: [
    ActivityLogComponent
  ],
  providers: [UserAuthService]
})
export class ActivityLogComponentModule { }
