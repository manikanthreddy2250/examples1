import {ActivityLogComponent} from "./activity-log.component";
import {async, ComponentFixture, TestBed} from "@angular/core/testing";
import {HttpClientTestingModule} from "@angular/common/http/testing";
import {RouterTestingModule} from "@angular/router/testing";
import {ActivityLogComponentModule} from "./activity-log.component.module";
import {CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA} from "@angular/core";
import {of} from "rxjs";
import {UmcasewfGraphqlService} from "../services/um/service/casewf/umcasewf-graphql.service";

describe('ActivityLogComponent', () => {
  let component: ActivityLogComponent;
  let fixture: ComponentFixture<ActivityLogComponent>;
  let mockConfigService: any;
  let umcaseService: UmcasewfGraphqlService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule, ActivityLogComponentModule],
      declarations: [],
      providers: [],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]

    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivityLogComponent);
    component = fixture.componentInstance;
    component.hscID = 11186;
    mockConfigService = jasmine.createSpyObj('mockConfigService', ['readConfig']);
    umcaseService = TestBed.inject(UmcasewfGraphqlService);
  });

  it('should create ngOnInit', () => {
    const configData = [
      {
        key: 'log_history_config',
        value: '{"taskHeader":[{"key":"description","label":"Description"},{"key":"type","label":"Type"},{"key":"date","label":"Date"},{"key":"status","label":"Status"}],"communicationHeader":[{"key":"description","label":"Description"},{"key":"date","label":"Date"}]}'
      }
    ];
    const userspy = spyOn(umcaseService, 'getMyTasksListDetailsByHscId').and.returnValue(Promise.resolve({data:{getTaskListByHscId:{hsr_asgn:[{asgn_typ_ref_cd:{ref_dspl:'Admission Review'},asgn_sts_ref_cd:{ref_dspl:'Active'}, asgn_to_user_id:'test', creat_dttm:'2021-06-23T21:10:02.683'}]}}}));
    const userspy2 = spyOn(umcaseService, 'getCommunicationActivities').and.returnValue(Promise.resolve({data:{getActivities:{communication_activities:[{mbr_cmnct_chnl_ref_dspl:'Fax',mbr_cmnct_sts_ref_dspl:'Sent', creat_dttm:'07/12/2021 11:30:11'}]}}}));
    mockConfigService.readConfig.and.returnValue(of(configData).toPromise());
    component.configService = mockConfigService;
    component.ngOnInit();
    expect(userspy).toHaveBeenCalled();
    expect(userspy2).toHaveBeenCalled();
  });
});
