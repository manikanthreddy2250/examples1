import {Component, OnInit, Input, ViewChild, ChangeDetectorRef, AfterViewInit} from '@angular/core';
import {EcpUclPaginator} from '@ecp/angular-ui-component-library/paginator';
import {EcpUclTableDataSource} from "@ecp/angular-ui-component-library/table";
import {UmcasewfGraphqlService} from "../services/um/service/casewf/umcasewf-graphql.service";
import {
  GET_CONFIG_URL_PATH, LOG_HISTORY_TABLE_HEADERS_CONFIG
} from "../../config/config-constants";
import {getEnvVar} from "../services/environment/envVarUtil";
import {ConfigService} from "../services/config/config.service";
import {HttpClient} from "@angular/common/http";
import {EcpUclSort} from "@ecp/angular-ui-component-library/sort";

@Component({
  selector: 'um-activity-log',
  templateUrl: './activity-log.component.html',
  styleUrls: ['./activity-log.component.scss']
})
export class ActivityLogComponent implements OnInit, AfterViewInit {

  constructor(private umcaseService: UmcasewfGraphqlService,
              private readonly httpClient: HttpClient) { }

  @Input() hscID: any;
  @Input() application = '';
  @Input() version = '';
  configService: any;
  currentBtnValue = 'tasks';
  componentHeader = 'Activity Log';
  expanded = true;
  taskListTableHeaders = [];
  taskListDataSource: EcpUclTableDataSource<any>;
  tasksList = [];
  @ViewChild('taskPaginator', { read: EcpUclPaginator}) taskListPaginator: EcpUclPaginator;
  @ViewChild('communicationPaginator', { read: EcpUclPaginator}) communicationListPaginator: EcpUclPaginator;
  @ViewChild('taskTable', { read: EcpUclSort }) taskListSort: EcpUclSort;
  @ViewChild('communicationTable', { read: EcpUclSort }) communicationListSort: EcpUclSort;
  taskListErrorMsg = '';
  communicationListErrorMsg = '';
  configErrorMsg = '';
  showTaskSpinner = true;
  showCommunicationSpinner = true;
  pageSize = 5;
  hidePageSize = true;

  communicationListTableHeaders = [];
  communicationListDataSource: EcpUclTableDataSource<any>;
  communicationList = [];


  ngOnInit(): void {
    this.initGraphqlService();
    this.getConfigHeaders();
    this.getTaskListData();
    this.getCommunicationListData();
  }

  private getCommunicationListData() {
    this.umcaseService.getCommunicationActivities(this.application, this.hscID).then(
      response => {
        response?.data?.getActivities?.communication_activities?.forEach(communication => {
          this.communicationList.push({
            Description: communication.mbr_cmnct_chnl_ref_dspl + ' ' + communication.mbr_cmnct_sts_ref_dspl,
            Date: communication.creat_dttm
          });
          this.communicationListDataSource = new EcpUclTableDataSource(this.communicationList);
          this.communicationListDataSource.paginator = this.communicationListPaginator;
          this.communicationListDataSource.sort = this.communicationListSort;
          this.showCommunicationSpinner = false;
        });
      }, error => {
        this.showCommunicationSpinner = false;
        this.communicationListErrorMsg = 'Error occurred when retrieving my communication data';
        console.log('Error occurred when retrieving communication data: ', error);
      });
  }

  private getTaskListData() {
    this.umcaseService.getMyTasksListDetailsByHscId(this.application, this.hscID).then(
      response => {
        response?.data?.getTaskListByHscId?.hsr_asgn?.forEach(task => {
          this.tasksList.push({
            Description: task.asgn_typ_ref_cd.ref_dspl,
            Status: task.asgn_sts_ref_cd.ref_dspl,
            Type: task.asgn_to_user_id,
            Date: task.creat_dttm.substring(5, 7) + '/' + task.creat_dttm.substring(8, 10) + '/' + task.creat_dttm.substring(0, 4) +
              ' ' + task.creat_dttm.substring(11, 13) + ':' + task.creat_dttm.substring(14, 16) + ':' + task.creat_dttm.substring(17, 19)
          });
        });
        this.taskListDataSource = new EcpUclTableDataSource(this.tasksList);
        this.taskListDataSource.paginator = this.taskListPaginator;
        this.taskListDataSource.sort = this.taskListSort;
        this.showTaskSpinner = false;
      }, error => {
        this.showTaskSpinner = false;
        this.taskListErrorMsg = 'Error occurred when retrieving my tasks data';
        console.log('Error occurred when retrieving member data: ', error);
      });
  }

  private getConfigHeaders() {
    this.configService.readConfig(this.application, this.version, LOG_HISTORY_TABLE_HEADERS_CONFIG).then(
      response => {
        const taskHeaders = JSON.parse(response[0]?.value).taskHeader;
        taskHeaders.forEach(header => {
          this.taskListTableHeaders.push(header.label);
        });
        const communicationHeaders = JSON.parse(response[0]?.value).communicationHeader;
        communicationHeaders.forEach(header => {
          this.communicationListTableHeaders.push(header.label);
        });

      }, error => {
        this.showTaskSpinner = false;
        this.showCommunicationSpinner = false;
        this.configErrorMsg = 'Error occurred when retrieving configuration data';
        console.log('Error occurred when retrieving config data: ', error);
      });
  }

  ngAfterViewInit() {
  }

  public initGraphqlService(): void {
    const configUrl = getEnvVar(GET_CONFIG_URL_PATH);
    this.configService = new ConfigService(this.httpClient, configUrl, this.umcaseService);
  }


}
