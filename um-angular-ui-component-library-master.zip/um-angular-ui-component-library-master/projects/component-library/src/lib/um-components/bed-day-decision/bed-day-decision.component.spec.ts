import {async, ComponentFixture, fakeAsync, TestBed, tick} from '@angular/core/testing';
import { BedDayDecisionService } from '../services/um/service/bed-day-decision-service/bed-day-decision.service';
import {BedDayDecisionComponent} from './bed-day-decision.component';
import {NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA, ChangeDetectorRef, Injectable} from '@angular/core';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import {HttpClient, HttpHandler} from '@angular/common/http';
import { of, Observable } from 'rxjs';
import {MicroProductAuthService} from '@ecp/auth-library';
import {LoggerConfig, NGXLogger, NGXLoggerHttpService, NGXMapperService} from 'ngx-logger';
import {DatePipe} from '@angular/common';
import {OAuthLogger, OAuthService, UrlHelperService} from 'angular-oauth2-oidc';
import {RouterTestingModule} from '@angular/router/testing';
import { BedDayDecisionModule } from './bed-day-decision.module';
import { UserAuthService } from '../services/auth/user.service';


@Injectable()
class MockBedDayDecisionService {
  getBedDayNotes(): Observable<any> {
    return of({
      data: {
      }
    });
  }

  saveBeddayNotes(): Observable<any> {
    return of({
      data: {
      }
    });
  }

  saveBedDayDecisionInfo(): Observable<any> {
    return of({
      data: {
        updateHsc: {
          hsc: [{
            hsc_decns: []
          }]
        }
      }
    });
  }
}

const ecpClaims = {
  'x-ecp-claims': {
    'x-ecp-attrs': {},
    'x-ecp-alt-user-id': '',
    'x-ecp-cli-orgs': [{
      'org-id': 'ecp',
      'func-roles': [{
        'role-name': 'rules_admin',
        'appl-roles': ['autoapproval-dmn_deploy', 'autorouting-dmn_deploy', 'bpm_execute_all', 'case_wf_mgmt_ui_read', 'configuration-dmn_deploy', 'example_dmn_grp_deploy', 'health_srvc_delete', 'icuerules-dmn_deploy', 'memberblocking-dmn_deploy', 'obsderivation-dmn_deploy', 'programs-dmn_deploy', 'rules_authoring_write', 'siteofservice-dmn_deploy', 'system_mgmt_user', 'testharness-dmn_deploy', 'um_intake_ui_read', 'umintake_sos_mbr_elig_dmn_grp_deploy', 'umintake_sos_prov_elig_dmn_grp_deploy']
      }]
    }],
    'x-ecp-first-name': 'Sahithya',
    'x-ecp-type': 'PASSWORD',
    'x-ecp-user-id': '001173408',
    'x-ecp-email': 'sahithya_sivaraju@optum.com',
    'x-ecp-last-name': 'Pachipulusu Sivaraju',
    'x-ecp-source': 'msid'
  },
  'https://hasura.io/jwt/claims': {
    'x-hasura-default-role': 'autoapproval-dmn_deploy',
    'x-hasura-attrs': '{ }',
    'x-hasura-cli-org': 'ecp',
    'x-hasura-user-id': '001173408',
    'x-hasura-func-role': 'rules_admin',
    'x-hasura-allowed-roles': ['autoapproval-dmn_deploy', 'autorouting-dmn_deploy', 'bpm_execute_all', 'case_wf_mgmt_ui_read', 'configuration-dmn_deploy', 'example_dmn_grp_deploy', 'health_srvc_delete', 'icuerules-dmn_deploy', 'memberblocking-dmn_deploy', 'obsderivation-dmn_deploy', 'programs-dmn_deploy', 'rules_authoring_write', 'siteofservice-dmn_deploy', 'system_mgmt_user', 'testharness-dmn_deploy', 'um_intake_ui_read', 'umintake_sos_mbr_elig_dmn_grp_deploy', 'umintake_sos_prov_elig_dmn_grp_deploy']
  },
  scope: 'openid',
  iss: 'ecp-dev',
  exp: 1603473684,
  client_id: 'ecp_platform'
};

@Injectable()
class MicroProductAuthServiceStub {
  getEcpClaims() {
    return {
      'x-ecp-claims': {
        'x-ecp-attrs': {},
        'x-ecp-alt-user-id': '',
        'x-ecp-cli-orgs': [{
          'org-id': 'ecp',
          'func-roles': [{
            'role-name': 'rules_admin',
            'appl-roles': ['autoapproval-dmn_deploy', 'clinical_guidelines_md', 'bpm_execute_all', 'case_wf_mgmt_ui_read', 'configuration-dmn_deploy', 'example_dmn_grp_deploy', 'health_srvc_delete', 'icuerules-dmn_deploy', 'memberblocking-dmn_deploy', 'obsderivation-dmn_deploy', 'programs-dmn_deploy', 'rules_authoring_write', 'siteofservice-dmn_deploy', 'system_mgmt_user', 'testharness-dmn_deploy', 'um_intake_ui_read', 'umintake_sos_mbr_elig_dmn_grp_deploy', 'umintake_sos_prov_elig_dmn_grp_deploy']
          }]
        }],
        'x-ecp-first-name': 'Sahithya',
        'x-ecp-type': 'PASSWORD',
        'x-ecp-user-id': '001173408',
        'x-ecp-email': 'sahithya_sivaraju@optum.com',
        'x-ecp-last-name': 'Pachipulusu Sivaraju',
        'x-ecp-source': 'msid'
      },
      'https://hasura.io/jwt/claims': {
        'x-hasura-default-role': 'autoapproval-dmn_deploy',
        'x-hasura-attrs': '{ }',
        'x-hasura-cli-org': 'ecp',
        'x-hasura-user-id': '001173408',
        'x-hasura-func-role': 'rules_admin',
        'x-hasura-allowed-roles': ['autoapproval-dmn_deploy', 'autorouting-dmn_deploy', 'bpm_execute_all', 'case_wf_mgmt_ui_read', 'configuration-dmn_deploy', 'example_dmn_grp_deploy', 'health_srvc_delete', 'icuerules-dmn_deploy', 'memberblocking-dmn_deploy', 'obsderivation-dmn_deploy', 'programs-dmn_deploy', 'rules_authoring_write', 'siteofservice-dmn_deploy', 'system_mgmt_user', 'testharness-dmn_deploy', 'um_intake_ui_read', 'umintake_sos_mbr_elig_dmn_grp_deploy', 'umintake_sos_prov_elig_dmn_grp_deploy']
      },
      scope: 'openid',
      iss: 'ecp-dev',
      exp: 1603473684,
      client_id: 'ecp_platform'
    };
  }

  getUserRoles() {
    return 'Provider';
  }

  getEcpOrgId() {
    return 'TESTUSERID';
  }

  getEcpToken() {
    return 'testToken';
  }

  isLocalHost() {
    return false;
  }

  getHasuraRole() {
    return 'clinical_guidelines_md';
  }
}

// @Injectable()
// class MockBedDayDecisionService {
//   completeBpmBedDaySignal(taskExecutionID: string, reqBody: any): Observable<any> {
//     return of({
//       data: {
//       }
//     });
//   }
// }

// @Injectable()
// class MockBedDayDecisionService {
//   getBedDayNotes(): Observable<any> {
//     return of({
//       data: {
//       }
//     });
//   }

//   saveBeddayNotes(): Observable<any> {
//     return of({
//       data: {
//       }
//     });
//   }

//   saveBedDayDecisionInfo(): Observable<any> {
//     return of({
//       data: {
//         updateHsc: {
//           hsc: [{
//             hsc_decns: []
//           }]
//         }
//       }
//     });
//   }
// }

describe('BedDayDecisionComponent', () => {
  let component: BedDayDecisionComponent;
  let bedDayDecisionService: BedDayDecisionService;
  let userAuthService: UserAuthService;
  let fixture: ComponentFixture<BedDayDecisionComponent>;
  let httpClient: HttpClient;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule, BedDayDecisionModule],
      declarations: [],
      providers: [BedDayDecisionService,
        {provide: MicroProductAuthService, useClass: MicroProductAuthServiceStub},
        // {provide: BedDayDecisionService, useClass: MockBedDayDecisionService},
        OAuthService, OAuthService, UrlHelperService, OAuthLogger,
        NGXLogger, NGXMapperService, NGXLoggerHttpService, LoggerConfig, DatePipe],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]

    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BedDayDecisionComponent);
    httpClient = TestBed.inject(HttpClient);
    bedDayDecisionService = TestBed.inject(BedDayDecisionService);
    userAuthService = TestBed.inject(UserAuthService);
    component = fixture.componentInstance;
    // spyOn(component, 'filterCurrentIndexDecisionId').and.returnValue(72121);
    fixture.detectChanges();
  });

  xit('should create', () => {
    expect(component).toBeTruthy();
  });


  xit('should call getBedDayNotes method', (done) => {
    const res: any = {
      data: {
        getBedDayNotes: {
          data: {
            hsr_note_sbj: [
              {
                hsr_note_id: 4253,
                note_sbj_rec_id: '1727',
                hsr_note: {
                  note_txt_lobj: 'test sample Mahesh 1'
                }
              }
            ]
          }
        }
      }
    };
    spyOn(bedDayDecisionService, 'getBedDayNotes').and.returnValue(of(res));
    const bedDayReq =
      {
        hsc_id: 11186,
        hsc_clin_guid_id: '1727'
      };
    component.getBedDayNotes();
    expect(component.getBedDayNotes).toBeTruthy();
    done();
  });


  it('should be call getRole', (done) => {
    const spy = spyOn(userAuthService, 'getUserHasuraRole').and.returnValue('case_wf_mgmt_ui_nurse');
    expect(spy).toBeDefined();
    done();

  });
  xit('should be call editBedDayCount', (done) => {
    component.editBedDayCount();
    expect(component.inputBedDayCell).toBeTruthy();
    done();

  });

  xit('should be call getBedDayData', (done) => {
    component.getBedDayData();
    expect(component.getBedDayData).toBeDefined();
    done();
  });

  xit('should save update review when decision is escalated', (done) => {
    const bedDayReponse: any = {
      data: {
        saveBedDay: {
          beddayRes: [
            {
              updateClinicalGuidResponse: {
                beddayRes: {
                  update_hsc_clin_guid_by_pk: {
                    clin_rev_sts_ref_id: 72755,
                    hsc_clin_guid_id: 1668,
                    chg_dttm: '2021-04-29T21:07:03.929'
                  }
                }
              }
            },
            {
              hscDecnResponse: {
                beddayRes: {}
              }
            },
            {
              hscDecnBedDayResponse: {
                beddayRes: {}
              }
            }
          ]
        }
      }
    };

    spyOn(bedDayDecisionService, 'saveBedDayDecisionInfo').and.returnValue(of(bedDayReponse));
    const bedDayData = {
      BedDayCount: '1',
      date: new Date(),
      Decision: 'Escalate',
      hscID: 11186,
      hscClinGuidID: 1727
    };

    component.saveHscDecision('','','','','');
    // expect(bedDayDecisionService.saveBedDayDecisionInfo).toHaveBeenCalledWith(bedDayData);
    expect(component.saveHscDecision).toBeTruthy();
    done();
  });


  xit('should save Bed Day decision when decision is approved', (done) => {
    const bedDayReponse: any = {
      data: {
        saveBedDay: {
          beddayRes: [
            {
              updateClinicalGuidResponse: {
                beddayRes: {}
              }
            },
            {
              hscDecnResponse: {
                res: {
                  insert_hsc_decn: {
                    affected_rows: 1,
                    returning: [
                      {
                        hsc_decn_id: 1076,
                        creat_dttm: '2021-05-03T21:52:31.091',
                        decn_typ_ref_id: null,
                        decn_otcome_ref_id: 72765,
                        decn_rsn_ref_id: null,
                        decn_made_by_user_id: null,
                        decn_made_by_user_org_desc: null,
                        hsc_id: 11186
                      }
                    ]
                  }
                }
              }
            },
            {
              hscDecnBedDayResponse: {
                res: {
                  insert_hsc_decn_bed_day: {
                    affected_rows: 1,
                    returning: [
                      {
                        hsc_decn_id: 1076,
                        strt_bed_dt: '2021-05-01',
                        bed_typ_ref_id: null,
                        accum_bed_day_cnt: 1,
                        decn_rndr_dttm_facl_lcl_txt: null,
                        decn_facl_cmnct_dttm: null
                      }
                    ]
                  }
                }
              }
            }
          ]
        }
      }
    };

    spyOn(bedDayDecisionService, 'saveBedDayDecisionInfo').and.returnValue(of(bedDayReponse));
    const bedDayData = {
      BedDayCount: '1',
      date: new Date(),
      Decision: 'Escalate',
      hscID: 11186,
      hscClinGuidID: 1727
    };
    component.saveHscDecision('','','','','');
    expect(component.saveHscDecision).toBeTruthy();
    done();
  });

  xit('should not save Bed Day decision when error', (done) => {
    const bedDayReponse: any = {
      errors: [{
        message: 'error'
      }]
    };
    spyOn(bedDayDecisionService, 'saveBedDayDecisionInfo').and.returnValue(of(bedDayReponse));
    const bedDayData = {
      BedDayCount: '1',
      date: new Date(),
      Decision: 'Approve',
      hscID: 11186,
      hscClinGuidID: 1727
    };

    component.saveHscDecision('','','','','');
    // expect(bedDayDecisionService.saveBedDayDecisionInfo).toHaveBeenCalledWith(bedDayData);
    expect(component.saveHscDecision).toBeTruthy();
    done();
  });

  // it('should call getClinicalReviewDescription method', () => {
  //   const clinicalReviewDescription: any = {
  //     data: {
  //       hsc_clin_guid: [{
  //         clin_rev_desc: 'Infection: General Initial review'
  //       }]
  //     }
  //   };
  //   spyOn(bedDayDecisionService, 'getClinicalReviewDescription').and.returnValue(of(clinicalReviewDescription));
  //   component.hscID = '11186';
  //   component.getClinicalReviewDetails();
  //   expect(component.getClinicalReviewDetails).toBeTruthy();
  // });

  // it('should call getClinicalReviewDescription method - error', () => {
  //   const clinicalReviewDescription: any = {
  //     errors: [{
  //       message: 'error'
  //     }]
  //   };
  //   spyOn(bedDayDecisionService, 'getClinicalReviewDescription').and.returnValue(of(clinicalReviewDescription));
  //   component.hscID = '11186';
  //   component.getClinicalReviewDetails();
  //   expect(component.getClinicalReviewDetails).toBeTruthy();
  // });

  it('should call intializeDateRangeForm()', async (done) => {
    component.intializeDateRangeForm();
    expect(component.intializeDateRangeForm).toBeDefined();
    done();
  });

  // it('should call filterCurrentIndexDecisionId()', async () => {
  //   const data = [{
  //     hsc_decn_bed_days: [{
  //       strt_bed_dt: '10/10/2021',
  //       hsc_clin_guid_id: 121
  //     }]
  //   }]
  //   component.filterCurrentIndexDecisionId(data, '10/10/2021', 121);
  //   expect(component.filterCurrentIndexDecisionId).toBeDefined();
  // });

  it('should call filterCurrentIndexDecisionId()', async (done) => {
    component.selectedStartDate = '10/10/2021';
    component.decisionId = '121';
    const e = {
      decision: 72151
    };
    const data = [{
      hsc_decn_bed_days: [{
        strt_bed_dt: '10/10/2021',
        hsc_clin_guid_id: 121
      }]
    }]
    component.filterCurrentIndexDecisionId(data, '10/10/2021',121 );
    expect(component.filterCurrentIndexDecisionId).toBeDefined();
    done();
  });
  it('should call getIndividualDaysRecords()', async (done) => {
    spyOn(component, 'updateBedTableWithExistingDecisions').and.callFake(() => {});
    const configuredDays = 10;
    component.selectedStartDate = '10/10/2021';
    component.getIndividualDaysRecords();
    expect(component.getIndividualDaysRecords).toBeDefined();
    done();
  });

  it('should call getNoOfDateRangeDays()', async (done) => {
    component.selectedStartDate = new Date();
    component.selectedEndDate = new Date();
    component.getNoOfDateRangeDays();
    expect(component.getNoOfDateRangeDays).toBeDefined();
    done();
  });

  it('should call updateBedTableWithExistingDecisions()', async (done) => {
    component.existingDecisionReviews = [
      {
        strt_bed_dt : '10/10/2021',
        hsc_decn : {
          decn_otcome_ref_id: '',
          hsc_decn_id: '',
          decn_bed_day_cnt: 2
        }
      },
      {
        strt_bed_dt : '10/11/2021',
        hsc_decn : {
        decn_otcome_ref_id: '',
        hsc_decn_id: '',
        decn_bed_day_cnt: 2
      }
      }
    ];

    component.individualBedDayData = [
      {
        date: '10/10/2021',
        decision: '',
        disabled: '',
        decisionId: ''

      },
      {
        date: '10/12/2021',
        decision: '',
        disabled: '',
        decisionId: ''
      },
      {
        date: '10/12/2021',
        decision: '',
        disabled: '',
        decisionId: ''
      }
    ];
    component.updateBedTableWithExistingDecisions();
    expect(component.updateBedTableWithExistingDecisions).toBeDefined();
    done();
  });

  it('should call decisionTypeSelect()', async (done) => {
    component.decisionTypeSelect(1);
    expect(component.decisionTypeSelect).toBeDefined();
    done();
  });

  it('should call datePickerOnChange()', async (done) => {
    component.selectedStartDate = new Date('10/12/2021');
    component.selectedEndDate = new Date('10/10/2021');
    component.datePickerOnChange('');
    expect(component.datePickerOnChange).toBeDefined();
    done();
  });
  it('should call formatDate()', async (done) => {
    component.formatDate('10/12/2021');
    expect(component.formatDate).toBeDefined();
    done();
  });
  it('should call saveHscBedDayNotes()', async (done) => {
    component.saveHscBedDayNotes();
    expect(component.saveHscBedDayNotes).toBeDefined();
    done();
  });

  it('should call saveHscDecision()', async (done) => {
    spyOn(component, 'filterCurrentIndexDecisionId').and.returnValue(72121);

    component.individualBedDayData = [
      {
        date: '10/10/2021',
        decision: '',
        disabled: '',
        decisionId: ''

      },
      {
        date: '10/12/2021',
        decision: '',
        disabled: '',
        decisionId: ''
      },
      {
        date: '10/12/2021',
        decision: '',
        disabled: '',
        decisionId: ''
      }
    ];

    component.saveHscDecision('', '', '', '', 0);
    expect(component.saveHscDecision).toBeDefined();
    done();
  });

  it('should call selectedDateRangeRadio()', async (done) => {
    component.selectedStartDate = '10/10/2021';
    component.decisionId = '121';
    const e = {
      decision: 72151
    };
    component.selectedDateRangeRadio(e);
    expect(component.filterCurrentIndexDecisionId).toBeDefined();
    done();
  });

  it('should call individualRadioSelect()', async (done) => {
    component.selectedStartDate = '10/10/2021';
    component.decisionId = '121';
    const e = {
      decision: 72151
    };
    component.individualRadioSelect('10/10/2021', 72151, 1, 121);
    expect(component.individualRadioSelect).toBeDefined();
    done();
  });

  it('should call getIndividualDecisionOtcomeId() with escalte', async (done) => {
    component.individualBedDayData = [
      {
        decision: 72755
      }
    ];
    component.isRoleNurse = true;
    component.getIndividualDecisionOtcomeId();
    expect(component.getIndividualDecisionOtcomeId).toBeDefined();
    done();
  });

  it('should call getIndividualDecisionOtcomeId() with approve', async (done) => {
    component.individualBedDayData = [
      {
        decision: 72151
      }
    ];
    component.isRoleNurse = false;
    component.getIndividualDecisionOtcomeId();
    expect(component.getIndividualDecisionOtcomeId).toBeDefined();
    done();
  });

  it('should call getDecisionOutcomeId()', async (done) => {
    component.bedDayDecisionType = 1;
    component.selectedDateRangeDecision = 72151;
    component.getDecisionOutcomeId();
    expect(component.getDecisionOutcomeId).toBeDefined();
    done();
  });

  it('should call getDecisionOutcomeId()', async (done) => {
    spyOn(component, 'getIndividualDecisionOtcomeId').and.returnValue(72121);
    component.bedDayDecisionType = 2;
    component.selectedDateRangeDecision = 72151;
    component.getDecisionOutcomeId();
    expect(component.getDecisionOutcomeId).toBeDefined();
    done();
  });


});

