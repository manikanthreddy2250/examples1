import { Component,
         OnInit, Output, EventEmitter, ViewChild, AfterViewInit, Input, AfterContentChecked, ChangeDetectorRef, ViewEncapsulation } from '@angular/core';
import {MicroProductAuthService} from '@ecp/auth-library';
import {ROLE_MD, ROLE_NURSE} from '../../config/config-constants';
import { EcpUclTableDataSource } from '@ecp/angular-ui-component-library/table';
import { EcpUclSort } from '@ecp/angular-ui-component-library/sort';
import { BedDayDecisionService } from '../services/um/service/bed-day-decision-service/bed-day-decision.service';
import { UserAuthService } from '../services/auth/user.service';
import {ReferenceConstants} from '../../config/reference-constants';
import { FormControl, FormGroup, Validators, FormBuilder } from '@angular/forms';
import * as moment from 'moment';
import { EcpUclPaginator } from '@ecp/angular-ui-component-library/paginator';
import { DatePipe } from '@angular/common';

@Component({
  // tslint:disable-next-line: component-selector
  selector: 'um-bed-day-decision',
  templateUrl: './bed-day-decision.component.html',
  styleUrls: ['./bed-day-decision.component.scss'],
  providers: [DatePipe]
})
export class BedDayDecisionComponent implements OnInit, AfterViewInit, AfterContentChecked {
  headers = ['date', 'decision'];
  noteText: string;

  @Input() hscID: any;
  @Input() processTaskExecutionID: string;
  @Input() decisionId: string;
  @Input() hsrAsgnId: any;
  @Input() hscClinGuidID: any;
  @Input() reviewDecisions: any;
  @Input() existingDecisionReviews: any;


  @Input() hscClinicalGuidelineID: string; // change it to reviewId
  @Input() application: string;
  @Input() version: string;
  @Input() showNotes = true;
  @Input() editBedDay = false;
  @Input() isEscaltedTask: any;

  @Input() selectedStartDate: any;
  @Input() selectedEndDate: any;
  disableIndividualRadio = false;
  @Input() disableIndvRadio: boolean;

  dateFormat = 'MM-dd-yyyy';

  inputBedDayCell = false;
  selectedDateRangeDecision: any;
  loadTablePagination = false;


  selectedDecision: any;
  isRoleMD = false;
  isRoleNurse = false;
  decisions = [];
  bedDayData = [
    {
      bedDay: '1',
      date: new Date(),
      Decision: ''
    }
  ];

  individualBedDayData: any  = [

  ];
  pageOptions = [5, 10, 25];
  variant;
  hidePageSize = true;
  pageSize = 5;
  minStartDate: any;
  minEndDate: any;
  bedDayDecisionType: any;
  dateRangeForm: FormGroup;
  decisionType =  [
    { label: 'Date Range', value: 1, disabled: false},
    { label: 'Individual Bed Days', value: 2, disabled: false}
  ];
  dataSource: EcpUclTableDataSource<any>;
  @ViewChild(EcpUclPaginator) paginator: EcpUclPaginator;
  @ViewChild(EcpUclSort) sort: EcpUclSort;

  constructor(private readonly cdref: ChangeDetectorRef, private readonly bedDayDecisionService: BedDayDecisionService,
              private datePipe: DatePipe,
              private readonly userService: UserAuthService, private fb: FormBuilder) {

  }

  ngOnInit(): void {
    this.variant = 'primary';
    this.intializeDateRangeForm();
    // this.getAccumulatedBedDay();
    // this.getClinicalReviewDetails();
    this.getBedDayNotes();
    this.getRole();
    this.decisions =  [
      { label: 'Approve', value: ReferenceConstants.DECISION_OUTCOME_REFID_APPROVE }
    ];
    if (this.isRoleNurse) {
      this.decisions.push({ label: 'Escalate', value: ReferenceConstants.CLINICAL_REVIEW_STATUS_ESCALATE});
    } else {
      this.decisions.push({ label: 'Deny', value: ReferenceConstants.DECISION_OUTCOME_REFID_DENY});
    }
    this.getIndividualDaysRecords();
    this.getDisableIndvRadioVal();
  }

  intializeDateRangeForm(): any {
    this.dateRangeForm = this.fb.group({
      startDate: ['', Validators.required],
      endDate: ['', Validators.required],
  });
  }

  getDisableIndvRadioVal(): any {
    this.decisionType[1].disabled = this.disableIndvRadio;
  }

  getIndividualDaysRecords(): any {
    const records = [];
    const admsnDate = this.selectedStartDate;
    const configuredDays = 10;
    for (let index = 0; index < configuredDays; index++) {
       records.push({
         date: moment(admsnDate).add(index, 'days').format('L'),
         decision: '',
         decisionId: '',
         disabled: true
       });
    }
    records[0].disabled = false;
    this.individualBedDayData = records;
    this.updateBedTableWithExistingDecisions();
  }

  getNoOfDateRangeDays(): any {
    if (this.selectedStartDate && this.selectedEndDate) {
      const start: any = new Date(this.selectedStartDate);
      const end: any  = new Date(this.selectedEndDate);
      return  Math.floor((end - start) / (1000 * 60 * 60 * 24)) + 1;
    }
  }

  updateBedTableWithExistingDecisions() {
    console.log('existingDecisionReviews', this.existingDecisionReviews);
    if (this.existingDecisionReviews && this.existingDecisionReviews.length > 0) {
      this.existingDecisionReviews.forEach(ele => {
        this.individualBedDayData.forEach(val => {
          if (this.formatDate(ele.strt_bed_dt) === this.formatDate(val.date)) {
            val.decision = ele?.hsc_decn?.decn_otcome_ref_id;
            val.decisionId = ele?.hsc_decn?.hsc_decn_id;
            val.bedCnt = ele?.hsc_decn?.decn_bed_day_cnt;
            val.disabled = false;
          }
        });
      });
      if(this.existingDecisionReviews.length > 1) {
        this.bedDayDecisionType = 2;
      } else {
        this.selectedDateRangeDecision = this.existingDecisionReviews[0]?.hsc_decn?.decn_otcome_ref_id;
        this.decisionType[1].disabled = this.isEscaltedTask;
        console.log('isEscaltedTask', this.isEscaltedTask);
        console.log('decisionType', this.decisionType);
        this.bedDayDecisionType = 1;
      }

      if (this.existingDecisionReviews.length < this.individualBedDayData.length) {
        this.individualBedDayData[this.existingDecisionReviews.length].disabled = false;
      }
      console.log('individualBedDayData', this.individualBedDayData);
    } else {
      this.individualBedDayData[0].decisionId = this.decisionId;
    }
  }

  decisionTypeSelect(val): any {
    this.bedDayDecisionType = val;
  }

  addEndDateError(): any {
    this.dateRangeForm.controls.endDate.setErrors({ minDateError: true });
  }

  addStartDateError(): any {
    this.dateRangeForm.controls.startDate.setErrors({ minDateError: true });
  }

  datePickerOnChange(e): any {
    const startDate = this.formatDate(this.selectedStartDate);
    const endDate = this.formatDate(this.selectedEndDate);
    if (new Date(endDate) < new Date(startDate)) {
      this.addEndDateError();
    }
  }

  formatDate(date): any {
    if (date) {
      return this.datePipe.transform(date ?? null, this.dateFormat);
    }
  }




  ngAfterViewInit() {
    this.cdref.detectChanges();
  }


  ngAfterContentChecked(): any {
    this.loadTablePagination = true;
    setTimeout(() => {
      this.dataSource = new EcpUclTableDataSource(this.individualBedDayData);
      this.dataSource.sort = this.sort;
      // this.dataSource.paginator = this.paginator;
    }, 0);
    this.cdref.detectChanges();
  }

  //  getAccumulatedBedDay(): any {
  //   this.bedDayDecisionService.getAccumulatedBedDay(this.hscID, this.application).subscribe(res => {
  //     if (res?.data != null) {
  //       this.bedDayData[0].bedDay = res?.data?.hsc_decn_aggregate?.aggregate?.sum?.aprv_bed_day_cnt + 1;
  //     } else if (res?.errors !== null) {
  //       console.log('getAccumulatedBedDay error....' + JSON.stringify(res?.errors[0]?.message));
  //     }
  //   });
  // }

  getBedDayNotes(): any {
    const bedDayNotesData = {
      hscID: Number(this.hscID),
      hscClinGuidID: this.hscClinGuidID,
      decisionId: this.decisionId
    };
    this.bedDayDecisionService.getBedDayNotes(bedDayNotesData, this.application).subscribe(res => {
      this.noteText = res?.data?.hsr_note_sbj[0]?.hsr_note?.note_txt_lobj;
      return res;
    });
  }

  // how to get clinicalguid?
  // getClinicalReviewDetails(): any {
  //   this.bedDayDecisionService.getClinicalReviewDescription(this.hscID, this.application).subscribe(res => {
  //     if (res?.data != null) {
  //       this.hscClinicalGuidelineID = res?.data?.hsc_clin_guid[0]?.hsc_clin_guid_id;
  //       console.log('clinicalReviewDescription result....' + JSON.stringify(res));
  //       this.getBedDayNotes();
  //     } else if (res?.errors !== null) {
  //       console.log('clinicalReviewDescription error....' + JSON.stringify(res?.errors[0]?.message));
  //     }
  //   });
  // }

  saveHscBedDayNotes(): any {
    const bedDayNotesData = {
      hscID: Number(this.hscID),
      hscClinGuidID: this.hscClinGuidID,
      decisionId: this.decisionId,
      noteText: this.noteText
    };
    this.bedDayDecisionService.saveBeddayNotes(bedDayNotesData, this.application).subscribe(res => {
      console.log('saveHscBedDayNotes response is ' + JSON.stringify(res));
    });
  }

  async saveHscDecision(decision, count, date, decisionID, index?): Promise<any> {
    const bedDayData = {
      bedDayCount: count,
      date,
      decisionOutcome: Number(decision),
      hscID: Number(this.hscID),
      hscClinGuidID: Number(this.hscClinGuidID),
      hsrAsgnId: Number(this.hsrAsgnId)
    };
    if (decisionID) {
      // tslint:disable-next-line: no-string-literal
      bedDayData['decisionId'] = Number(decisionID);
    }
    this.bedDayDecisionService.saveBedDayDecisionInfo(bedDayData, this.application).subscribe(async (res) => {
      const hscData = await res?.data?.updateHsc?.hsc;
      if (hscData && hscData.length > 0 && index >= 0 ) {
        const hscDecision = hscData[0]?.hsc_decns;
        const decisionId = this.filterCurrentIndexDecisionId(hscDecision, date, Number(this.hscClinGuidID));
        this.individualBedDayData[index].decisionId = decisionId;
        this.individualBedDayData[index].decision = decision;
        if (index < this.individualBedDayData.length - 1) {
          this.individualBedDayData[index + 1].disabled = false;
        }
      }
      console.log('individualBedDayData', this.individualBedDayData);
    });
  }

  filterCurrentIndexDecisionId(hscDecision, date, clinGuid) {
    return hscDecision.find((ele) => ((this.formatDate(ele.hsc_decn_bed_days[0].strt_bed_dt) === this.formatDate(date))
                               && (ele.hsc_decn_bed_days[0].hsc_clin_guid_id === clinGuid))).hsc_decn_id;
  }

  getRole(): any {
    const role = this.userService.getUserHasuraRole(this.application);
    if (role === ROLE_MD) {
      return  this.isRoleMD = true;
       }else if (role === ROLE_NURSE){
      return this.isRoleNurse = true;
    }

  }

  getBedDayData(): any {
    return {
      bedDay: this.bedDayData[0]?.bedDay,
      decision: this.selectedDecision,
      noteText: this.noteText
    };
  }

  selectedDateRangeRadio(e) {
    if (e) {
      this.selectedDateRangeDecision = e;
      this.saveHscDecision(e, this.getNoOfDateRangeDays(), this.selectedStartDate, this.decisionId, -1);
    }
  }

  individualRadioSelect(date, decision, index, decisionId) {
    if (decision) {
      this.saveHscDecision(decision, 1, this.formatDate(date), decisionId, index);
    }

  }

  editBedDayCount(): any {
    this.inputBedDayCell = true;
  }

  onBlur(noteText): any{
    this.saveHscBedDayNotes();
  }

  getIndividualDecisionOtcomeId() {
    const signalDecisionRefId = this.isRoleNurse ?
    ReferenceConstants.CLINICAL_REVIEW_STATUS_ESCALATE : ReferenceConstants.DECISION_OUTCOME_REFID_DENY;
    const decisionOtcome = this.individualBedDayData.find((ele) => ele.decision === signalDecisionRefId)?.decision;
    if (decisionOtcome) {
      return decisionOtcome;
    } else {
      return this.individualBedDayData[0].decision;
    }
  }

  getDecisionOutcomeId() {
    if (this.bedDayDecisionType === 1) {
      return this.selectedDateRangeDecision;
    } else {
      return this.getIndividualDecisionOtcomeId();
    }
  }

}
