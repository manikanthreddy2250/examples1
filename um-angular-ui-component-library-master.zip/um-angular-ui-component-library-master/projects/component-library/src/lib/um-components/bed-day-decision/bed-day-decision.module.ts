import { CUSTOM_ELEMENTS_SCHEMA, NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { CommonModule} from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';
import { BedDayDecisionComponent } from './bed-day-decision.component';
import { TabsModule} from '@ecp/angular-ui-component-library/tabs';
import {MatGridListModule} from '@angular/material/grid-list';
import { ButtonModule} from '@ecp/angular-ui-component-library/button';
import { IconsModule} from '@ecp/angular-ui-component-library/icons';
import {MatIconModule} from '@angular/material/icon';
import {TableModule} from '@ecp/angular-ui-component-library/table';
import {SortModule} from '@ecp/angular-ui-component-library/sort';
import {LinkModule} from '@ecp/angular-ui-component-library/link';
import {PaginatorModule} from '@ecp/angular-ui-component-library/paginator';
import { ProgressSpinnerModule} from '@ecp/angular-ui-component-library/progress-spinner';
import { AuthLibraryModule } from '@ecp/auth-library';
import { UserAuthService } from '../services/auth/user.service';
import {ButtonGroupModule} from '@ecp/angular-ui-component-library/button-group';
import {RadioButtonModule} from '@ecp/angular-ui-component-library/radio-button';
import { CardModule } from '@ecp/angular-ui-component-library/card';
import { InputModule } from '@ecp/angular-ui-component-library/input';
import { DatepickerInputModule, DatepickerModule } from '@ecp/angular-ui-component-library/datepicker';
import { FormFieldModule } from '@ecp/angular-ui-component-library/form-field';


@NgModule({
  declarations: [
    BedDayDecisionComponent
  ],
  imports: [
    CommonModule,
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    MatGridListModule,
    MatIconModule,
    TableModule,
    ButtonModule,
    TabsModule,
    IconsModule,
    SortModule,
    LinkModule,
    PaginatorModule,
    ProgressSpinnerModule,
    AuthLibraryModule,
    ButtonGroupModule,
    RadioButtonModule,
    CardModule,
    InputModule,
    DatepickerInputModule,
    DatepickerModule,
    FormFieldModule
  ],
  exports: [
    BedDayDecisionComponent
  ],
  providers: [UserAuthService]
})
export class BedDayDecisionModule { }
