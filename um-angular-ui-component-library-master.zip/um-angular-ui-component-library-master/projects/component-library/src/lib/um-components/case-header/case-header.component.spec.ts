import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {CaseHeaderDetails} from './case-header.details';
import { CaseHeaderComponent } from './case-header.component';
import {Injectable, NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {Observable, of} from 'rxjs';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import {HttpClient} from '@angular/common/http';
import {AuthLibraryModule, MicroProductAuthService, AuthService, OAuthInitService} from '@ecp/auth-library';
import {UmcasewfGraphqlService} from '../services/um/service/casewf/umcasewf-graphql.service';
import {CaseHeaderService} from '../services/um/service/case-header/case-header.service';
import { CaseHeaderModule } from './case-header.module';
import { ConfigService } from '../services/config/config.service';
import { UserAuthService } from '../services/auth/user.service';
import { compileComponentFromMetadata } from '@angular/compiler';


@Injectable()
class UserAuthServiceMock {

  getUserID() {
    return 'TESTUSERID';
  }

  isLocalHost() {
    return false;
  }

  getActiveClientOrg() {
    return 'ecp';
  }

  getActiveUserRole() {
    return 'sys_admin';
  }

  getAltUserID() {
    return 'test';
  }

  getUserHasuraRole() {
    return 'test';
  }
}

// @Injectable()
// class MockHttpClient {
//   get(url: string, body: any | null, options?: any) {
//     return of([
//       {
//         id: 'um_intake_ui_1.0.0_ecp_authorization_type_2021-02-12',
//         createDateTime: '2021-02-12T21:12:29.235+00:00',
//         creatUserId: null,
//         changeDateTime: '2021-02-12T21:12:29.235+00:00',
//         changeUserId: null
//       }
//     ]);
//   }
//   post(url: string, body: any | null, options?: any) {
//     return of([
//       {
//         id: 'um_intake_ui_1.0.0_ecp_authorization_type_2021-02-12',
//         createDateTime: '2021-02-12T21:12:29.235+00:00',
//         creatUserId: null,
//         changeDateTime: '2021-02-12T21:12:29.235+00:00',
//         changeUserId: null
//       }
//     ]);
//   }

// }

// @Injectable()
// class MockCaseHeaderService {
//   static records = [];

//   getCaseHeaderDetails(hscId: string): Promise<any> {
//     const resp =
//       {
//         "requestType": "Inpatient",
//         "caseId": "12908",
//         "serviceType": "Scheduled",
//         "caseType": "Medical",
//         "admitDate": "2021-02-16T00:00:00",
//         "dischargeDate": "2021-02-18T00:00:00",
//         "diagnosis": "J42-UNSPECIFIED CHRONIC BRONCHITIS",
//         "tatDueDate": "12-31-9999",
//         "facility": "JENNIE STUART MEDICAL CENTER",
//         "planCode": "Medical",
//         "indv_id": "503926748"
//       }
//     return of({
//       resp
//     }).toPromise();
//   }

//   getConfigDetails(envId: any): Observable<any> {
//     const resp =
//       [
//         {
//           "id": "case_wf_mgmt_ui_1.0.0_ecp_case_header_details_2021-03-05",
//           "createDateTime": "2021-03-05T15:18:10.589+00:00",
//           "creatUserId": null,
//           "changeDateTime": "2021-03-05T15:18:10.589+00:00",
//           "changeUserId": null,
//           "updateVersionNumber": "0",
//           "createSystemReferenceId": null,
//           "changeSystemReferenceId": null,
//           "dataSecureRuleList": null,
//           "dataGltyIssList": null,
//           "application": "case_wf_mgmt_ui",
//           "version": "1.0.0",
//           "org": "ecp",
//           "role": null,
//           "key": "case_header_details",
//           "value": "{\"caseHeaderDetails\":[{\"caseType\":[{\"IP\":[{\"value\":\"\",\"key\":\"client\",\"label\":\"Client / Payer\"},{\"value\":\"\",\"key\":\"tatDueDate\",\"label\":\"TAT Due Date\"},{\"value\":\"\",\"key\":\"requestType\",\"label\":\"Request Type\"},{\"value\":\"\",\"key\":\"caseType\",\"label\":\"Case Type\"},{\"value\":\"\",\"key\":\"caseId\",\"label\":\"Case ID\"},{\"value\":\"\",\"key\":\"serviceType\",\"label\":\"Service Type\"},{\"value\":\"\",\"key\":\"admitDate\",\"label\":\"Admit Date\"},{\"value\":\"\",\"key\":\"dischargeDate\",\"label\":\"Discharge Date\"},{\"value\":\"\",\"key\":\"facility\",\"label\":\"Facility\"},{\"value\":\"\",\"key\":\"primaryDiagnosis\",\"label\":\"Primary Diagnosis\"},{\"value\":\"\",\"key\":\"planCode\",\"label\":\"Plan Code\"}],\"OP\":[{\"value\":\"\",\"key\":\"client\",\"label\":\"Client / Payer\"},{\"value\":\"\",\"key\":\"tatDueDate\",\"label\":\"TAT Due Date\"},{\"value\":\"\",\"key\":\"requestType\",\"label\":\"Request Type\"},{\"value\":\"\",\"key\":\"caseType\",\"label\":\"Case Type\"},{\"value\":\"\",\"key\":\"caseId\",\"label\":\"Case ID\"},{\"value\":\"\",\"key\":\"serviceType\",\"label\":\"Service Type\"},{\"value\":\"\",\"key\":\"facility\",\"label\":\"Facility\"},{\"value\":\"\",\"key\":\"primaryDiagnosis\",\"label\":\"Primary Diagnosis\"},{\"value\":\"\",\"key\":\"serviceStartDate\",\"label\":\"Service Start Date\"},{\"value\":\"\",\"key\":\"serviceEndDate\",\"label\":\"Service End Date\"},{\"value\":\"\",\"key\":\"planCode\",\"label\":\"Plan Code\"}]}]}]}",
//           "startDate": "2021-03-05T00:00:00.000+00:00",
//           "endDate": null,
//           "inactivityIndicator": "0"
//         }
//       ]
//     return of({
//       resp
//     });
//   }


//   getRefDesc(refIds: any): Observable<any> {
//     return of({data: {ref: [{ref_dspl: 'Draft'}]}});
//   }

//   getMemberDetails(refIds: any): Observable<any> {
//     return of({
//       indv: [{
//         fst_nm: 'Matt',
//         lst_nm: 'Meyer',
//         bth_dt: '1978-07-26',
//         gdr_ref_id: 2109,
//         indv_adrs: [{
//           adr_ln_1_txt: '2127 W Balmoral Ave',
//           adr_ln_2_txt: null,
//           cty_nm: 'Chicago',
//           st_ref_id: 1079
//         }]
//       }],
//       ref: {
//         0: {}
//       }

//     });
//   }
// }

describe('CaseHeaderComponent', () => {
  let component: CaseHeaderComponent;
  let fixture: ComponentFixture<CaseHeaderComponent>;
  let mockConfigService: any;
  let httpClient: HttpClient;
  let umcaseService: UmcasewfGraphqlService;
  let caseHeaderService: CaseHeaderService;

  beforeEach(async(() => {
    mockConfigService = jasmine.createSpyObj('mockConfigService', ['readConfig']);
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        AuthLibraryModule,
        CaseHeaderModule
      ],
      providers: [{ provide : UserAuthService, useClass: UserAuthServiceMock },
        MicroProductAuthService,
        UmcasewfGraphqlService,
        CaseHeaderService,
        AuthService,
        OAuthInitService,
        { provide: CaseHeaderService}
      ],
      declarations: [],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaseHeaderComponent);
    component = fixture.componentInstance;
    component.application = 'dummyName';
    component.version = 'dummyVersion';
    umcaseService = TestBed.inject(UmcasewfGraphqlService);
    httpClient =  TestBed.inject(HttpClient);
    caseHeaderService = TestBed.inject(CaseHeaderService);
    const inputDetails = new CaseHeaderDetails();
    inputDetails.caseId = '1234';
    component.caseHeaderInput = inputDetails;
    fixture.detectChanges();
  });

  // it('should create', () => {
  //   expect(component).toBeTruthy();
  // });

  it('called ngOnInit', () => {
    const configData = [
      {
          key: "admitDischargeDate",
          value: {
            admitted: 'Admitted'
          }
      },
      {
          key: "test",
          value: {
            admitted: 'test'
          }
      }
    ]
    let caseHeaderDetailsResponse = {"data":{"getCaseHeaderDetails":{"requestType":"Inpatient","caseId":12916,"serviceType":"Scheduled","caseType":"Hospice","admitDate":"2021-02-16T00:00:00","dischargeDate":"2021-02-25","primaryDiagnosis":"S81.0-OPEN WOUND OF KNEE","tatDueDate":"12-31-9999","facility":null,"planCode":"Medical","indv_id":503926748,"srvc_set_ref_id":3737}}}
    const caseHeaderspy = spyOn(umcaseService, 'getCaseHeaderDetails').and.returnValue(Promise.resolve(caseHeaderDetailsResponse));
    mockConfigService.readConfig.and.returnValue(of(configData).toPromise());
    component.configService = mockConfigService;
    component.caseHeaderInput ={};
    component.ngOnInit()
    expect(caseHeaderspy).toHaveBeenCalled();
  });

  it('should initGraphqlService()', () => {
    component.configService = new ConfigService(httpClient, 'https://dev-config', umcaseService);
    component.initGraphqlService();
    expect(component.configService).toBeDefined();
  });

  it('should mapCaseHeaderDetails', () => {
    const caseHeaderDetails = new CaseHeaderDetails();
    const caseHeaderResponseData = {data: {getCaseHeaderDetails: {
      hsc_id: 'test'
    }}};
    caseHeaderDetails.caseId = 'test';
    caseHeaderDetails.indId = '2109';
    component.mapCaseHeaderDetails(caseHeaderResponseData);
    expect(component.caseHeaderDetails.caseId).toEqual('test');
  });

  it(' should populateSnapshotViewHeaderConfig', () => {
    component.snapshotViewHeaderConfig = [
      {
          key: 'memberName',
          value: {
            admitted: 'Admitted'
          }
      },
      {
          key: 'test',
          value: {
            admitted: 'test'
          }
      }
    ];
    component.populateSnapshotViewHeaderConfig();
  });

  it(' should populateConfiguredCaseHeader', () => {
    component.caseHeaderConfig = [
      {
        key: 'admitDischargeDate',
        value: ''

      }
    ];
    component.caseHeaderDetails.admitDate = '04-05-2021';
    component.caseHeaderDetails.dischargeDate = '11-09-2021';
    component.populateConfiguredCaseHeader();
    expect(component.caseHeaderConfig[0].value).toEqual('04-05-2021 - 11-09-2021');
    component.caseHeaderConfig = [
      {
        key: 'serviceType',
        value: {}

      }
    ];
    component.populateConfiguredCaseHeader();
    expect(component.caseHeaderConfig[0].value).toEqual('N/A - N/A');
    component.caseHeaderConfig = [
      {
        key: 'test',
        value: {}
      }
    ];
    component.populateConfiguredCaseHeader();
    expect(component.caseHeaderConfig[0].value).toEqual('N/A');

  });

  it('should caseHeaderToggle()', () => {
    component.showCollapseView = true;
    component.caseHeaderToggle();
    expect(component.showCollapseView).toBe(true);
  });

  it('should call showCoverageActiveValidation()', () => {
    const covEffDt = '02-01-2020';
    const covEndDt = '12-31-9999';
    expect(component.showCoverageActiveValidation(covEffDt , covEndDt)).toEqual(true);
  });


});

