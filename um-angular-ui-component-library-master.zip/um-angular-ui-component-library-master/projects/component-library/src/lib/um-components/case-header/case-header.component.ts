import {Component, Input, OnInit, Output, EventEmitter} from '@angular/core';
import {CaseHeaderDetails} from './case-header.details';
import {CaseHeaderService} from '../services/um/service/case-header/case-header.service';
import {
  CASE_HEADER_DETAILS,
  GET_CONFIG_URL_PATH
} from '../../config/config-constants';
import {ReferenceConstants} from '../../config/reference-constants';
import {HttpClient} from '@angular/common/http';
import {UmcasewfGraphqlService} from '../services/um/service/casewf/umcasewf-graphql.service';
import {ConfigService} from '../services/config/config.service';
import {DatePipe} from '@angular/common';
import { getEnvVar } from '../services/environment/envVarUtil';
//@ts-ignore
import { caseHeaderImg } from './case-header-image';
import { UmintakeGraphqlService } from '../services/um/service/um-intake/umintake-graphql.service';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'um-case-header',
  templateUrl: './case-header.component.html',
  styleUrls: ['./case-header.component.scss']
})
export class CaseHeaderComponent implements OnInit {
  @Input() application: string;
  @Input() version: string;
  @Input() hscId: number;
  @Input() caseHeaderInput: CaseHeaderDetails;
  @Input() showCollapseView: boolean;
  @Output() collapseViewEvent: EventEmitter<boolean> = new EventEmitter();

  caseHeaderDetails = new CaseHeaderDetails();
  snapshotViewHeaderConfig: any;
  caseHeaderConfig: any;
  showSpinner = false;
  mbrAge: any;
  image = caseHeaderImg;
  dateFormat : string = 'MM/dd/yyyy';
  showCoverageActive = false;
  tempCaseType: any;
  configService: any;
  noRecordsFound = '';
  caseHeaderDetailView :boolean = true;

  constructor(private readonly httpClient: HttpClient,
              private umcaseService: UmcasewfGraphqlService,
              private caseHeaderService: CaseHeaderService,
              public umintakeGraphqlService: UmintakeGraphqlService,
              public datepipe: DatePipe) { }

  ngOnInit() {
    this.initGraphqlService();
    this.showSpinner = true;
    const caseHeaderPromises: Promise<any>[] = this.getCaseHeader();
    this.mapCaseHeader(caseHeaderPromises);
  }

  public initGraphqlService(): void {
    const configUrl = getEnvVar(GET_CONFIG_URL_PATH);
    this.configService = new ConfigService(this.httpClient, configUrl, this.umcaseService);
  }

  public getCaseHeader(): Promise<any>[] {
    const caseHeaderData = this.caseHeaderInput.caseId ?
                           this.caseHeaderInput : this.umcaseService.getCaseHeaderDetails(this.hscId , this.application);
    const caseHeaderConfig = this.configService.readConfig(this.application, this.version, CASE_HEADER_DETAILS);
    return [caseHeaderData, caseHeaderConfig];
  }

  mapCaseHeader(promises: any) {
    Promise.all(promises).then(
      response => {
        this.showSpinner = false;
        this.mapCaseHeaderDetails(response[0]);
        this.mapCaseHeaderConfig(response[1]);
      }, error => {
        this.showSpinner = false;
        this.noRecordsFound = 'Error occurred when retrieving CaseHeader details and configuration data:';
        console.log('Error occurred when retrieving member and config data: ', error);
      });
  }

  async mapCaseHeaderDetails(caseHeaderResponseData) {
    const caseHeaderData = caseHeaderResponseData?.data?.getCaseHeaderDetails || {};
    if (caseHeaderData){
      const stateCode = caseHeaderData.st_ref_cd ? caseHeaderData.st_ref_cd : this.getStateCode([caseHeaderData.st_ref_id]);
      this.caseHeaderDetails.admitDate = this.datepipe.transform(caseHeaderData.admitDate ?? null, this.dateFormat);
      this.caseHeaderDetails.caseId = caseHeaderData.hsc_id;
      this.caseHeaderDetails.caseType = caseHeaderData.srvc_dtl_ref_dspl;
      this.caseHeaderDetails.dischargeDate = this.datepipe.transform(caseHeaderData.dischargeDate ?? null, this.dateFormat);
      this.caseHeaderDetails.facility = caseHeaderData.bus_nm;
      this.caseHeaderDetails.contractPaperTypeCode = caseHeaderData.contractPaperTypeCode;
      this.caseHeaderDetails.addressLine = caseHeaderData.addressLine;
      this.caseHeaderDetails.stRefCd = stateCode;
      this.caseHeaderDetails.covEffDt = this.datepipe.transform(caseHeaderData.cov_eff_dt ?? null, this.dateFormat);
      this.caseHeaderDetails.covEndDt =  this.datepipe.transform(caseHeaderData.cov_end_dt ?? null, this.dateFormat);
      this.showCoverageActive = this.showCoverageActiveValidation( this.caseHeaderDetails.covEffDt, this.caseHeaderDetails.covEndDt);
      this.caseHeaderDetails.planCode = caseHeaderData.planCode;
      this.caseHeaderDetails.primaryDiagnosis = caseHeaderData.primaryDiagnosis;
      this.caseHeaderDetails.requestType = caseHeaderData.srvc_set_ref_dspl;
      this.caseHeaderDetails.serviceEndDate = this.datepipe.transform(caseHeaderData.srvc_end_dt ?? null, this.dateFormat);
      this.caseHeaderDetails.serviceStartDate = this.datepipe.transform(caseHeaderData.srvc_strt_dt ??
        null, this.dateFormat);
      this.caseHeaderDetails.serviceType = caseHeaderData.srvc_desc_ref_dspl;
      this.caseHeaderDetails.tatDueDate = '00:00:00';
      this.caseHeaderDetails.hscStsRefDspl = caseHeaderData.hsc_sts_ref_dspl;
      this.caseHeaderDetails.plsrvRefDspl = caseHeaderData.plsrv_ref_dspl ?? 'N/A';
      this.tempCaseType = caseHeaderData.srvc_dtl_ref_dspl;
      this.caseHeaderDetails.caseType = this.caseHeaderDetails.caseType ?
        (this.caseHeaderDetails.requestType + ' - ' + (this.caseHeaderDetails.plsrvRefDspl)) : this.caseHeaderDetails.requestType;
      this.mapMemberDetails(caseHeaderData);
    }
  }

  async getStateCode(stateId: any[]) {
    const response = await this.umintakeGraphqlService.loadRefDataByRefIds(this.application, [1106]);
    const stateCode = response?.data?.hsr_ref?.[0]?.ref_cd;
    return stateCode;
  }

  mapCaseHeaderConfig(caseHeaderConfigData) {
    const configList = caseHeaderConfigData;
    const configuredList = configList.find((element: any) => element.role != null);
    this.caseHeaderConfig = configuredList ? configuredList.value : configList[0].value;
    this.caseHeaderConfig = JSON.parse(this.caseHeaderConfig);
    if (this.caseHeaderConfig?.srvcSetRefId === ReferenceConstants.SERVICE_SETTING_TYPE_OUTPATIENT) {
      this.caseHeaderConfig = this.caseHeaderConfig.caseHeaderDetails[0].caseType[0].OP;
    }else{
      this.snapshotViewHeaderConfig = this.caseHeaderConfig.caseHeaderDetails[0].caseType[0].IP.IPSnapshotView;
      this.caseHeaderConfig = this.caseHeaderConfig.caseHeaderDetails[0].caseType[0].IP.IPDetailView;
    }
    this.populateConfiguredCaseHeader();
    this.populateSnapshotViewHeaderConfig();
  }

  populateSnapshotViewHeaderConfig(){
    this.snapshotViewHeaderConfig?.forEach((field: any) => {
      const keyName: string = field.key;
      field.value = this.caseHeaderDetails[keyName] ?? 'N/A';
    });
  }

  populateConfiguredCaseHeader(){
    this.caseHeaderConfig?.forEach((field: any) => {
      const keyName: string = field.key;
      if (keyName === 'admitDischargeDate') {
        field.value = (this.caseHeaderDetails.admitDate ?? 'N/A') + ' - ' + (this.caseHeaderDetails.dischargeDate ?? 'N/A');
      }else if (keyName === 'serviceType'){
        field.value = (this.tempCaseType ?? 'N/A') + ' - ' + (this.caseHeaderDetails.serviceType ?? 'N/A');
      }else{
        field.value = this.caseHeaderDetails[keyName] ?? 'N/A';
      }
    });
  }

  mapMemberDetails(caseHeaderData) {
    this.ageCalculation(caseHeaderData.bth_dt);
    this.caseHeaderDetails.memberName = caseHeaderData.fst_nm + ' ' + caseHeaderData.lst_nm;
    this.caseHeaderDetails.mbrGender = caseHeaderData.gdr_ref_dspl;
  }

  ageCalculation(bthDt: any) {
    this.caseHeaderDetails.mbrDob = bthDt;
    const newDate = new Date(bthDt);
    const timeDiff = Math.abs(Date.now() - new Date(newDate).getTime());
    const daysDiff = timeDiff / (1000 * 3600 * 24);
    if (daysDiff === 0) {
      this.mbrAge = Math.floor(daysDiff);
      this.caseHeaderDetails.ageDisplay = this.mbrAge + ' Days';
    } else if (daysDiff > 0 && daysDiff < 30) {
      this.mbrAge = Math.floor(daysDiff);
      this.caseHeaderDetails.ageDisplay = this.mbrAge + ' Days';
    } else if (daysDiff > 30 && daysDiff < 720) {
      this.mbrAge = Math.floor(daysDiff / 30);
      this.caseHeaderDetails.ageDisplay = this.mbrAge + ' Months';
    } else if (daysDiff > 720) {
      this.mbrAge = Math.floor(timeDiff / (1000 * 3600 * 24) / 365.25);
      this.caseHeaderDetails.ageDisplay = this.mbrAge + ' Years';
    }
  }

  caseHeaderToggle(){
    this.caseHeaderDetailView =!this.caseHeaderDetailView
    this.collapseViewEvent.emit(this.caseHeaderDetailView);
    console.log("emitted emit" );
  }
  showCoverageActiveValidation(covEffDt , covEndDt){
    const today =  new Date().getTime();
    covEffDt = new Date(covEffDt).getTime();
    covEndDt = new Date(covEndDt).getTime();
    return ((covEffDt <= today) && (today <= covEndDt)) ;
  }
}
