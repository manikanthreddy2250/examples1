export class CaseHeaderDetails {
  indId?: any;
  client?: any;
  tatDueDate?: any;
  requestType?: any;
  plsrvRefDspl?: any;
  caseType?: string;
  caseId?: string;
  serviceType?: any;
  facility?: any;
  contractPaperTypeCode?: any;
  addressLine?: any;
  stRefCd?: any;
  covEffDt?: any;
  covEndDt?: any;
  primaryDiagnosis?: any;
  planCode?: any;
  serviceStartDate?: any;
  serviceEndDate?: any;
  admitDate?: any;
  dischargeDate?: any;
  srvcSetRefId?: any;
  hscStsRefDspl?: any;
  memberName?:any;
  mbrGender?:any;
  mbrDob?:any;
  ageDisplay?:any;
}
