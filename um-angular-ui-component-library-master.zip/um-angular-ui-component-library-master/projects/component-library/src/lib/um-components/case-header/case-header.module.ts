import { BrowserModule } from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { TabsModule } from '@ecp/angular-ui-component-library/tabs';
import {MatGridListModule} from '@angular/material/grid-list';
import { ButtonModule } from '@ecp/angular-ui-component-library/button';
import { IconsModule } from '@ecp/angular-ui-component-library/icons';
import {MatIconModule} from '@angular/material/icon';
import {CaseHeaderComponent} from './case-header.component';
import {CardModule} from '@ecp/angular-ui-component-library/card';
import {A11yModule} from '@angular/cdk/a11y';
import { FlexLayoutModule } from '@angular/flex-layout';
import {HttpClientModule} from '@angular/common/http';
import { ProgressSpinnerModule } from '@ecp/angular-ui-component-library/progress-spinner';
import {CaseHeaderService} from '../services/um/service/case-header/case-header.service';
import {AuthLibraryModule} from '@ecp/auth-library';
import {APP_BASE_HREF} from '@angular/common';
import {UserAuthService} from '../services/auth/user.service';
import {CUSTOM_ELEMENTS_SCHEMA, NgModule} from '@angular/core';
import {LinkModule} from '@ecp/angular-ui-component-library/link';


@NgModule({
  declarations: [
    CaseHeaderComponent
  ],
    imports: [
        CardModule,
        BrowserModule,
        BrowserAnimationsModule,
        FlexLayoutModule,
        MatGridListModule,
        MatIconModule,
        ButtonModule,
        TabsModule,
        IconsModule,
        A11yModule,
        HttpClientModule,
        ProgressSpinnerModule,
        AuthLibraryModule,
        LinkModule,
        
    ],

  exports: [
    CaseHeaderComponent
  ],
  providers: [
    UserAuthService,
    CaseHeaderService, {provide: APP_BASE_HREF, useValue: '/'}
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class CaseHeaderModule { }
