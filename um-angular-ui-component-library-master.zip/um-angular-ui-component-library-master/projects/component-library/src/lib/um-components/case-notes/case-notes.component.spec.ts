import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaseNotesComponent } from './case-notes.component';
import {ChangeDetectorRef, Injectable} from '@angular/core';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import {CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA} from '@angular/compiler';
import {AuthLibraryModule, MicroProductAuthService} from '@ecp/auth-library';
import {HscAuthDetailService} from '../services/um/service/clinical-guidelines/medical-reviews/hsc-auth-detail.service';
import {HscGraphqlService} from '../services/um/service/hsc-update/hsc-graphql.service';
import {CaseNotesModule} from './case-notes.module';
import {of} from 'rxjs';

const subject = 'Unit Test Subject';
const body = 'Unit Test Note Body';

@Injectable()
class MockHscAuthDetailService{
  getHscAuthDetails(request: any) {
    return of({
      data: {
        getHscAuthDetails: {
          hsc: [
            {
              hsc_id: 11,
              hsr_notes: [
                {
                  note_titl_txt: subject,
                  note_txt_lobj: body,
                  src_user_nm: 'Test',
                  creat_dttm: '2021-05-10T13:51:14.282'
                }
              ]
            }
          ]
        }
      }
    }).toPromise();
  }
}

@Injectable()
class MockHscGraphqlService {
  updateHsc(hscId: number, hscRecord: any, application: string) {
    const mockupResults = of({
      data: {
        hsc: [{
          "hsc_id": 2134,
        }]
      }
    });
    return mockupResults.toPromise();
  }
}

describe('CaseNotesComponent', () => {
  let component: CaseNotesComponent;
  let fixture: ComponentFixture<CaseNotesComponent>;
  let cdrf: ChangeDetectorRef;
  let microProductAuth: MicroProductAuthService;
  let authDetailService: HscAuthDetailService;
  let hscGraphqlService: HscGraphqlService;

  const notesData = [
    {
      creat_dttm: '2021-05-14',
      note_titl_txt: 'Testing123',
      note_txt_lobj: 'Lorem ipsum',
      src_user_nm: 'John Smith'
    },
    {
      creat_dttm: '2021-05-14',
      note_titl_txt: 'Testing998',
      note_txt_lobj: 'Lorem ipsum dolor sit amet',
      src_user_nm: 'John Smith'
    }
  ];


  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        AuthLibraryModule,
        CaseNotesModule
      ],
      declarations: [],
      providers: [MicroProductAuthService, ChangeDetectorRef,{
        provide: HscGraphqlService,
        useClass: MockHscGraphqlService
      }, {
        provide: HscAuthDetailService,
        useClass: MockHscAuthDetailService
      }],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
    fixture = TestBed.createComponent(CaseNotesComponent);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaseNotesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it ('should call ngOnInit', () => {
    component.ngOnInit();
    expect(component.ngOnInit).toBeTruthy();
  });

  it ('should call ngOnInit with JSON', () => {
    component.notesJSON = notesData;
    component.ngOnInit();
    expect(component.ngOnInit).toBeTruthy();
    expect(component.noteDetails[0].subject).toEqual(notesData[0].note_titl_txt);
  });

  it ('adds note', () => {
    component.userName = 'Test User';
    component.notesForm.get('noteSubject').setValue(subject);
    component.notesForm.get('noteText').setValue(body);
    component.hscId = 1;
    component.addNote();
  });

  it ('should call resetForm', () => {
    component.resetForm();
    expect(component.clearButton).toBe(true);
  });

  it ('should call resetForm', () => {
    component.enableClearButton(event);
    expect(component.clearButton).toBe(false);
  });
});
