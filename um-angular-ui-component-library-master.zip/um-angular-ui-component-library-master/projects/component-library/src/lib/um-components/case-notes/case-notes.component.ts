import {AfterContentChecked, AfterViewInit, ChangeDetectorRef, Component, Input, OnInit, ViewChild} from '@angular/core';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import {EcpUclTableDataSource} from '@ecp/angular-ui-component-library/table';
import {EcpUclSort} from '@ecp/angular-ui-component-library/sort'
import {HscAuthDetailService} from '../services/um/service/clinical-guidelines/medical-reviews/hsc-auth-detail.service';
import {MicroProductAuthService} from '@ecp/auth-library';
import {HscGraphqlService} from '../services/um/service/hsc-update/hsc-graphql.service';
import { NotesConstants } from './case-notes.constants';

@Component({
  selector: 'app-case-notes',
  templateUrl: './case-notes.component.html',
  styleUrls: ['./case-notes.component.scss']
})
export class CaseNotesComponent implements OnInit, AfterContentChecked, AfterViewInit {
  @Input() application = '';
  @Input() hscId: number;
  @Input() readOnly: boolean;
  @Input() summaryViewOnly: boolean;
  @Input() notesJSON: any;
  notesForm: FormGroup;
  clearButton: boolean;
  noteDetails: any;
  userName: string;
  headers = ['date', 'subject', 'note', 'name'];
  dataSource: EcpUclTableDataSource<any>;
  @ViewChild(EcpUclSort) sort: EcpUclSort;

  constructor(private readonly cdref: ChangeDetectorRef, private readonly hscService: HscAuthDetailService,
              private readonly microProductAuthService: MicroProductAuthService, private readonly hscGraphqlService: HscGraphqlService) {
  }

  async ngOnInit() {
    this.clearButton = true
    this.notesForm = new FormGroup({
      noteSubject: new FormControl(null, Validators.required),
      noteText: new FormControl(null, Validators.required),
    });
    if (this.notesJSON && this.notesJSON.length > 0) {
      this.noteDetails = [];
      this.notesJSON.forEach(note => {
        this.noteDetails.push(this.mapHsrNote(note));
      });
    } else if (this.hscId) {
      await this.initGraphqlService();
    }
    this.dataSource = new EcpUclTableDataSource(this.noteDetails);
  }

  ngAfterViewInit() {
    this.cdref.detectChanges();
  }

  ngAfterContentChecked() {​​
    this.dataSource = new EcpUclTableDataSource(this.noteDetails);
    this.dataSource.sort = this.sort;
    this.cdref.detectChanges();
  }

  async getUserName() {
    if (!this.userName) {
      const claims: any = this.microProductAuthService.getEcpClaims()['x-ecp-claims'];
      const firstName: any = claims['x-ecp-first-name'];
      const lastName: any = claims['x-ecp-last-name'];
      this.userName = firstName + ' ' + lastName;
    }
    return this.userName;
  }

  mapHsrNote(hsrNote) {
    return {
      date: new Date(hsrNote.creat_dttm),
      subject: hsrNote.note_titl_txt,
      note: hsrNote.note_txt_lobj,
      name: hsrNote.src_user_nm
    };
  }

  async initGraphqlService() {
    const hscID = this.hscId;
    const hsc = {
      hsc: {
        hsc_id: hscID
      }
    };
    const res = await this.hscService.getHscAuthDetails(hsc).toPromise();
    const notes = res.data.getHscAuthDetails.hsc[0].hsr_notes;
    this.noteDetails = [];
    notes.forEach(note => {
      this.noteDetails.push(this.mapHsrNote(note));
    });
  }

  async addNote() {
    const subject = this.notesForm.get('noteSubject').value;
    const note = this.notesForm.get('noteText').value;

    if(subject && note){
          const noteDetail = {
            note_titl_txt: subject,
            note_txt_lobj: note,
            src_user_nm: await this.getUserName(),
            note_catgy_ref_id: NotesConstants.NOTES_CATGY_TYPE_REFID,
            note_typ_ref_id: NotesConstants.NOTES_TYPE_REFID,
          };

          const updateHscRequest = {
            updateHscRequest: {
              hsc_id: this.hscId,
              hsr_notes: noteDetail
            }
          };
          this.hscGraphqlService.updateHsc(this.hscId, updateHscRequest, this.application).then(resp => {
              this.notesForm.reset();
              this.initGraphqlService().then(r => {
                  this.dataSource = new EcpUclTableDataSource(this.noteDetails);
                });
            });
    }
    else{
      //need to add error pop up
      console.error("Please Enter Subject and Note");
    }
  }

  async enableClearButton(event: Event) {
    console.log(event);
    this.clearButton = false;
  }

  resetForm(){
    this.notesForm.reset()
    this.clearButton = true;
  }
}
