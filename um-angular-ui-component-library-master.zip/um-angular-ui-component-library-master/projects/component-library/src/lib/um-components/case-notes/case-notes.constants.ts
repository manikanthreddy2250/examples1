export const NotesConstants = {
    NOTES_CATGY_TYPE_REFID : 80,
    NOTES_TYPE_REFID : 17,
};