import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import {CaseNotesComponent} from './case-notes.component';
import {BrowserAnimationsModule, NoopAnimationsModule} from '@angular/platform-browser/animations';
import {IconsModule} from '@ecp/angular-ui-component-library/icons';
import {TableModule} from '@ecp/angular-ui-component-library/table';
import {CardModule} from '@ecp/angular-ui-component-library/card';
import {SortModule} from '@ecp/angular-ui-component-library/sort';
import {HttpClientModule} from '@angular/common/http';
import {BrowserModule} from '@angular/platform-browser';
import {ButtonModule} from '@ecp/angular-ui-component-library/button';
import {TabsModule} from '@ecp/angular-ui-component-library/tabs';
import {MatIconModule} from '@angular/material/icon';
import {MatGridListModule} from '@angular/material/grid-list';
import {AuthLibraryModule} from '@ecp/auth-library';
import {SelectModule} from '@ecp/angular-ui-component-library/select';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {FormFieldModule} from '@ecp/angular-ui-component-library/form-field';
import {OptionModule} from '@ecp/angular-ui-component-library/option';
import {PaginatorModule} from '@ecp/angular-ui-component-library/paginator';
import {InputModule} from '@ecp/angular-ui-component-library/input';



@NgModule({
  declarations: [
    CaseNotesComponent
  ],
  imports: [
    CardModule,
    CommonModule,
    BrowserModule,
    BrowserAnimationsModule,
    MatGridListModule,
    MatIconModule,
    TableModule,
    ButtonModule,
    TabsModule,
    IconsModule,
    SortModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    AuthLibraryModule,
    SelectModule,
    OptionModule,
    FormFieldModule,
    PaginatorModule,
    InputModule,
    NoopAnimationsModule
  ],
  exports: [
    CaseNotesComponent
  ]
})
export class CaseNotesModule { }
