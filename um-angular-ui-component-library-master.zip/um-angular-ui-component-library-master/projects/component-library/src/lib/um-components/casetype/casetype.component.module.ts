import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import {
  BrowserAnimationsModule,
  NoopAnimationsModule,
} from '@angular/platform-browser/animations';
import { TableModule } from '@ecp/angular-ui-component-library/table';
import { SortModule } from '@ecp/angular-ui-component-library/sort';
import { TabsModule } from '@ecp/angular-ui-component-library/tabs';
import { MatGridListModule } from '@angular/material/grid-list';
import { ButtonModule } from '@ecp/angular-ui-component-library/button';
import { IconsModule } from '@ecp/angular-ui-component-library/icons';
import { MatIconModule } from '@angular/material/icon';
import { CardModule } from '@ecp/angular-ui-component-library/card';
import { CasetypeComponent } from './casetype.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AuthLibraryModule } from '@ecp/auth-library';
import { SelectModule } from '@ecp/angular-ui-component-library/select';
import { FormFieldModule } from '@ecp/angular-ui-component-library/form-field';
import { OptionModule } from '@ecp/angular-ui-component-library/option';
import { DatepickerModule, DatepickerInputModule } from '@ecp/angular-ui-component-library/datepicker';
import {AccordianModule} from "@ecp/angular-ui-component-library/accordian";
import {LinkModule} from "@ecp/angular-ui-component-library/link";
import {ModalModule} from "@ecp/angular-ui-component-library/modal";

@NgModule({
  declarations: [
    CasetypeComponent
  ],
  imports: [
    CommonModule,
    BrowserModule,
    BrowserAnimationsModule,
    CardModule,
    MatGridListModule,
    MatIconModule,
    TableModule,
    ButtonModule,
    TabsModule,
    IconsModule,
    SortModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    AuthLibraryModule,
    SelectModule,
    OptionModule,
    NoopAnimationsModule,
    FormFieldModule,
    DatepickerModule,
    DatepickerInputModule,
    AccordianModule,
    LinkModule,
    ModalModule
  ],
  exports: [
    CasetypeComponent
  ],
  providers: []
})

export class CasetypeModule { }
