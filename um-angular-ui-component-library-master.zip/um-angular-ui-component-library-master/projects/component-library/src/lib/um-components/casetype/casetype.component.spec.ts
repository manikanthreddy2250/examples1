import {
  async,
  ComponentFixture,
  inject,
  TestBed,
} from '@angular/core/testing';

import { CasetypeComponent } from './casetype.component';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import {
  BrowserAnimationsModule,
  NoopAnimationsModule,
} from '@angular/platform-browser/animations';
import { SortModule } from '@ecp/angular-ui-component-library/sort';
import { ButtonModule } from '@ecp/angular-ui-component-library/button';
import { IconsModule } from '@ecp/angular-ui-component-library/icons';
import { CardModule } from '@ecp/angular-ui-component-library/card';
import {
  HttpClient,
  HttpClientModule,
  HttpHeaders,
} from '@angular/common/http';
import {
  FormControl,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { AuthLibraryModule } from '@ecp/auth-library';
import { SelectModule } from '@ecp/angular-ui-component-library/select';
import { FormFieldModule } from '@ecp/angular-ui-component-library/form-field';
import { OptionModule } from '@ecp/angular-ui-component-library/option';
import { of } from 'rxjs/internal/observable/of';
import {
  HttpClientTestingModule,
  HttpTestingController,
} from '@angular/common/http/testing';
import { RouterModule } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { UmintakeGraphqlService } from '../services/um/service/um-intake/umintake-graphql.service';
import { Injectable } from '@angular/core';
import { CasetypeModule } from './casetype.component.module';

@Injectable()
class MockMedicalReviewNotesCitationService {
  loadRefChildDisplayDataInRef(app:any,ref:any){
    return of(refChildData).toPromise();
  }
  loadBaseRefNameDisplayData(app:any,ref:any){
    return of(refData).toPromise();
  }

  getApiHeaders(app:any){
    return new HttpHeaders();
  }

  getCaseTypeDetailsByHscId(hscId:any,app:any){
    return of(OpCaseTypeDataByhscId).toPromise();
  }

  updateHsc(updateHscRequest: any, app: any) {
    return of(updateHsc).toPromise();
  }
}


let refData : any= {
  data: {
    ref: [
      {
        ref_id: 1234,
        ref_desc: 'TestBed',
        ref_dspl: 'Behavorial',
        inac_ind: '12',
        ref_cd: 'ABCD',
      },
    ],
  },
};

let refChildData:any = {
  data: {
    ref_chld: [
      {
        refSetByChldRefIdChldRefNm:{
          ref:{
            ref_id: '1234',
            ref_desc: 'TestBed',
            ref_dspl: 'Behavorial',
            inac_ind: '12',
            ref_cd: 'ABCD',
          }
        }
      },
    ],
  },
};

let ipOpfCaseTypeDataByhscId:any = {
  data: {
    getCaseTypeDetails: {
      hsc_id: 19006,
      hsc_sts_ref_id: null,
      rev_prr_ref_id: 3754,
      rev_prr_ref_cd: {
        ref_id: 3754,
        ref_dspl: 'Routine',
      },
      srvc_set_ref_id: 3737,
      srvc_set_ref_cd: {
        ref_id: 3737,
        ref_dspl: 'Inpatient',
      },
      hsc_facls: [
        {
          plsrv_ref_id: 3743,
          plsrv_ref_cd: {
            ref_id: 3743,
            ref_dspl: 'Acute Hospital',
          },
          srvc_desc_ref_id: 4347,
          srvc_desc_ref_cd: {
            ref_id: 4347,
            ref_dspl: 'Scheduled',
          },
          srvc_dtl_ref_id: 4296,
          srvc_dtl_ref_cd: {
            ref_id: 4296,
            ref_dspl: 'Medical',
          },
          actul_admis_dttm: '2021-03-21T00:00:00',
          actul_dschrg_dttm: '2021-03-22T00:00:00',
          expt_admis_dt: '2021-03-02',
          expt_dschrg_dt: '2021-03-04',
        },
      ],
    },
  },
};

let OpCaseTypeDataByhscId:any = {
  data: {
    getCaseTypeDetails: {
      hsc_id: 18936,
      hsc_sts_ref_id: 19274,
      hsc_sts_ref_cd: {
        ref_dspl: 'Draft',
      },
      rev_prr_ref_id: 3755,
      rev_prr_ref_cd: {
        ref_id: 3755,
        ref_dspl: 'Urgent',
      },
      srvc_set_ref_id: 3738,
      srvc_set_ref_cd: {
        ref_id: 3738,
        ref_dspl: 'Outpatient',
      },
      hsc_srvcs: [
        {
          hsc_srvc_non_facls: [
            {
              plsrv_ref_id: 3746,
              plsrv_ref_cd: {
                ref_id: 3746,
                ref_dspl: 'Ambul Surgical Centr',
              },
              srvc_desc_ref_id: 4348,
              srvc_desc_ref_cd: {
                ref_id: 4348,
                ref_dspl: 'Urgent',
              },
            },
          ],
        },
      ],
    },
  },
};

const updateHsc:any =  {
  data: {
    updateHsc: {
      hsc: [
        {
          hsc_id: 12845,
        }
      ]
    }
  }
};

let opCaseTypeDetails:any = {
  hsc_id: 14254,
  hsc_sts_ref_id: 19274,
  rev_prr_ref_id: 3754,
  rev_prr_ref_cd: {
    ref_id: 3754,
    ref_dspl: 'Routine',
  },
  srvc_set_ref_id: 3737,
  srvc_set_ref_cd: {
    ref_id: 3737,
    ref_dspl: 'Inpatient',
  },
  hsc_facls: [
    {
      plsrv_ref_id: 3743,
      plsrv_ref_cd: {
        ref_id: 3743,
        ref_dspl: 'Acute Hospital',
      },
      srvc_desc_ref_id: 4347,
      srvc_desc_ref_cd: {
        ref_id: 4347,
        ref_dspl: 'Scheduled',
      },
      srvc_dtl_ref_id: 4296,
      srvc_dtl_ref_cd: {
        ref_id: 4296,
        ref_dspl: 'Medical',
      },
      actul_admis_dttm: '2021-03-21T00:00:00',
      actul_dschrg_dttm: '2021-03-22T00:00:00',
      expt_admis_dt: '2021-03-02',
      expt_dschrg_dt: '2021-03-04',
    },
  ],
};

let ipOpfCaseTypeDetails:any = {
  hsc_id: 19006,
  hsc_sts_ref_id: 19274,
  rev_prr_ref_id: 3754,
  rev_prr_ref_cd: {
    ref_id: 3754,
    ref_dspl: 'Routine',
  },
  srvc_set_ref_id: 3737,
  srvc_set_ref_cd: {
    ref_id: 3737,
    ref_dspl: 'Inpatient',
  },
  hsc_facls: [
    {
      plsrv_ref_id: 3743,
      plsrv_ref_cd: {
        ref_id: 3743,
        ref_dspl: 'Acute Hospital',
      },
      srvc_desc_ref_id: 4347,
      srvc_desc_ref_cd: {
        ref_id: 4347,
        ref_dspl: 'Scheduled',
      },
      srvc_dtl_ref_id: 4296,
      srvc_dtl_ref_cd: {
        ref_id: 4296,
        ref_dspl: 'Medical',
      },
      actul_admis_dttm: '2021-03-21T00:00:00',
      actul_dschrg_dttm: '2021-03-22T00:00:00',
      expt_admis_dt: '2021-03-02',
      expt_dschrg_dt: '2021-03-04',
    },
  ],
};


describe('CasetypeComponent', () => {
  let component: CasetypeComponent;
  let fixture: ComponentFixture<CasetypeComponent>;
  let httpTestCtrl: HttpTestingController;
  let httpClient: HttpClient;
  let umintakeGraphqlService: UmintakeGraphqlService;
  const serviceSettings = [];
  const placeOfServices = [];
  const priorityTypes = [];
  const serviceDetailTypes = [];
  const serviceDescriptionTypes = [];
  const IP = 'Inpatient';
  const OP = 'Outpatient';
  const OPF = 'Outpatient Facility';

  beforeEach(async(() => {
    const initialState = {
      ref_chld: [
        {
          ref_id: 1,
          chld_ref_id: 2,
        },
      ],
    };

    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        BrowserModule,
        CardModule,
        AuthLibraryModule,
        OptionModule,
        NoopAnimationsModule,
        FormFieldModule,
        ButtonModule,
        IconsModule,
        SortModule,
        BrowserAnimationsModule,
        HttpClientTestingModule,
        CommonModule,
        SelectModule,
        ButtonModule,
        FormFieldModule,
        RouterModule,
        RouterTestingModule,
        CasetypeModule
      ],
      declarations: [],
      providers: [HttpClient,{provide: UmintakeGraphqlService, useClass: MockMedicalReviewNotesCitationService}],
    }).compileComponents();

    serviceSettings[0] = {
      id: 0,
      label: 'Inpatient',
      value: 'Inpatient',
    };
    serviceSettings[1] = {
      id: 1,
      label: 'Outpatient',
      value: 'Outpatient',
    };
    serviceSettings[2] = {
      id: 2,
      label: 'Outpatient Facility',
      value: 'Outpatient Facility',
    };

    priorityTypes[0] = {
      id: 0,
      label: 'Routine',
      value: 'Routine',
    };
    priorityTypes[1] = {
      id: 1,
      label: 'Urgent',
      value: 'Urgent',
    };
    priorityTypes[2] = {
      id: 2,
      label: 'Time Sensitive',
      value: 'Time Sensitive',
    };

    serviceDescriptionTypes[0] = {
      id: 0,
      label: 'Surgical',
      values: 'Surgical',
    };

    placeOfServices[0] = {
      id: 0,
      label: 'Ambulatory Surgical Center',
      value: 'Ambulatory Surgical Center',
    };

    serviceDetailTypes[0] = {
      id: 0,
      label: 'Diagnostic Testing',
      value: 'Diagnostic Testing',
    };
  }));

  beforeEach(async(async () => {
    fixture = TestBed.createComponent(CasetypeComponent);
    component = fixture.componentInstance;
    component.caseTypeDetails = ipOpfCaseTypeDetails;
    httpTestCtrl = TestBed.get(HttpTestingController);
    umintakeGraphqlService = TestBed.inject(UmintakeGraphqlService);
    httpClient = TestBed.inject(HttpClient);
    component.caseTypeForm = new FormGroup({
      serviceSetting: new FormControl([IP]),
      placeOfService: new FormControl([placeOfServices]),
      serviceDetail: new FormControl([serviceDetailTypes]),
      serviceDescription: new FormControl([serviceDescriptionTypes]),
      priority: new FormControl([priorityTypes]),
    });
    component.serviceSettings = serviceSettings;
    component.placeOfServices = placeOfServices;
    await component.getServiceSettings();
    await component.getPlaceOfServices(ipOpfCaseTypeDetails.hsc_facls[0].plsrv_ref_cd.ref_id);
    component.priorityTypes = priorityTypes;
    await component.getPriorities();
    component.serviceDetailTypes = serviceDetailTypes;
    component.serviceDescriptionTypes = serviceDescriptionTypes;
    await component.getServiceDescriptions();
    await fixture.componentInstance.ngOnInit();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should get the PlaceOfServices', () => {
    component.getPlaceOfServices(157);
  });

  it('should get the serviceDetailTypes', () => {
    component.application = "test";
    component.getServiceDetailTypes(3741);
  });

  it('should set the formFields based on requestCategory IP', () => {
    component.caseTypeForm.get('serviceSetting').setValue({ value: IP ,name: "Inpatient"});
    component.getUpdatedCaseTypeForm();
    component.isServiceDetail = true;
    component.isOpfDates = false;
    component.isIpDates = true;
    expect(component.caseTypeForm.get('expectedAdmissionDate')?.validator != null);
    expect(component.caseTypeForm.get('actualAdmissionDate')?.validator != null);
    expect(component.caseTypeForm.get('expectedDischargeDate')?.validator != null);
    expect(component.caseTypeForm.get('actualDischargeDate')?.validator != null);
    expect(component.caseTypeForm.get('startDate')).toBeNull();
    expect(component.caseTypeForm.get('endDate')).toBeNull();
  });

  it('should set the formFields based on requestCategory OPF', () => {
    component.caseTypeForm.get('serviceSetting').setValue({ value: OP,name: "Outpatient" });
    component.getUpdatedCaseTypeForm();

    component.caseTypeForm.get('serviceSetting').setValue({ value: OPF,name: "Outpatient Facility" });
    component.getUpdatedCaseTypeForm();
  });

  it('should set the formFields based on requestCategory OP', () => {
    component.caseTypeForm.get('serviceSetting').setValue({ value: OP,name: "Outpatient" });
    component.getUpdatedCaseTypeForm();
  });

  it('should call getDefaultAuthorizationForm', () => {
    expect(component.getDefaultAuthorizationForm()).toBeTruthy();
  });

  it('should set build the forms based input json data for IP/OPF', () => {
    component.serviceSettings = serviceSettings;
    component.placeOfServices = placeOfServices;
    component.serviceDescriptionTypes = serviceDescriptionTypes;
    component.priorityTypes = priorityTypes;
    component.serviceDetailTypes = serviceDetailTypes;
    component.caseTypeDetails = ipOpfCaseTypeDetails;
    component.buildIpOpfCaseTypeForm(component.caseTypeDetails);
    expect(component.buildIpOpfCaseTypeForm).toBeTruthy();
    component.buildOpfDateFormFields();
  });

  it('should call getCaseTypeDataByHscId for IP/OPF', () => {
    component.getCaseTypeDataByHscId();
    expect(component.getCaseTypeDataByHscId()).toBeTruthy();
  });

  it('should format the date', () => {
    component.formatDate( '2021-10-21T00:00:00');
    expect(component.formatDate( '2021-10-21T00:00:00')).toBeTruthy();
  });

  it('should format the date test 1', () => {
    component.formatDate( '2021-01-01T00:00:00');
    expect(component.formatDate( '2021-01-01T00:00:00')).toBeTruthy();
  });

  it('should call onSaveCaseDetails', () => {
    component.caseTypeForm.setValue({
      serviceSetting: {
        name: 'Inpatient',
        value: 3737
      },
      placeOfService: {
        name: 'Acute Hospital',
        value: 3743
      },
      serviceDescription: {
        name: 'Urgent',
        value: 4348
      },
      priority: {
        name: 'Urgent',
        value: 3755
      },
      serviceDetail: {
        name: 'Medical',
        value: 4296
      },
      expectedAdmissionDate: '03/10/2021',
      expectedDischargeDate: '02/13/2021',
      actualAdmissionDate: '07/10/2020',
      actualDischargeDate: '07/28/2021'
    });
    component.onSaveCaseDetails();
    spyOn(umintakeGraphqlService, 'updateHsc').and.returnValue(Promise.resolve(updateHsc));
    expect(component.caseTypeForm.status).toBe('VALID');
  });

});
