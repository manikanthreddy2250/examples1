import {Component, Input, OnInit, Output, EventEmitter, ViewChild} from '@angular/core';
import {
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { UmintakeGraphqlService } from '../services/um/service/um-intake/umintake-graphql.service';
import * as moment from 'moment';
import { IntakeFormValidationService } from '../services/intake-form/intake-form-validation.service';
import {getEnvVar} from "../services/environment/envVarUtil";
import {CASE_TYPE_CONFIG, GET_CONFIG_URL_PATH} from "../../config/config-constants";
import {ConfigService} from "../services/config/config.service";
import {HttpClient} from "@angular/common/http";
import {UmcasewfGraphqlService} from "../services/um/service/casewf/umcasewf-graphql.service";
import {EcpUclModal} from "@ecp/angular-ui-component-library/modal";

export enum requestInfo {
  REQUESTTYPE = 'serviceSettingType',
  PRIORITY = 'riskLevelType',
  SERVICEDESC = 'serviceDescriptionType',
}

export interface CaseTypeDataObj {
  serviceSetting: string;
  placeOfService: string;
  serviceDetail: string;
  serviceDescription: string;
  priority: string;
  expectedAdmissionDate?: Date;
  expectedDischargeDate?: Date;
  actualAdmissionDate?: Date;
  actualDischargeDate?: Date;
  startDate?: Date;
  endDate?: Date;
}

@Component({
  selector: 'app-casetype-component',
  templateUrl: './casetype.component.html',
  styleUrls: ['./casetype.component.scss'],
})
export class CasetypeComponent implements OnInit {
  @Input() application = '';
  @Input() version: string;
  @Input() readOnly = false;
  @Input() caseTypeDetails: any;
  @Input() hscID: number;
  @Input() isSummary = false;
  @Input() showDetailsView = true;
  @Output() onInValidate = new EventEmitter();
  caseTypeForm: FormGroup;
  public serviceSettings = [];
  public placeOfServices = [];
  public priorityTypes = [];
  public serviceDetailTypes = [];
  public serviceDescriptionTypes = [];
  public IP = 'Inpatient';
  public OP = 'Outpatient';
  public OPF = 'Outpatient Facility';

  onSaveClicked = false;
  string;
  required: boolean;
  selected: string;
  isServiceDetail = false;
  isOpfDates = false;
  isIpDates = false;
  ipOpfCaseTypeData: any;
  configService: any;
  configErrorMsg = '';
  expanded = true;
  componentHeader = 'Case Type';
  caseTypeHeaders = [];
  @ViewChild('viewUpdate') modal: EcpUclModal;

  constructor(public umintakeGraphqlService: UmintakeGraphqlService, private readonly intakeValidationService: IntakeFormValidationService,
              private umcaseService: UmcasewfGraphqlService, private readonly httpClient: HttpClient) { }

  public async getUpdatedCaseTypeForm() {
    const serviceSetting = this.caseTypeForm.get('serviceSetting').value;
    this.selected = serviceSetting.name;
    await this.getPlaceOfServices(serviceSetting.value);
    if (serviceSetting.name === this.IP) {
      this.caseTypeForm = new FormGroup({
        serviceSetting: new FormControl(this.serviceSettings[0], Validators.required),
        placeOfService: new FormControl(null, Validators.required),
        serviceDetail: new FormControl(null),
        serviceDescription: new FormControl(null, Validators.required),
        priority: new FormControl(null, Validators.required),
        expectedAdmissionDate: new FormControl(null, Validators.compose(
          [this.intakeValidationService.isDateInPastValidator(1),
          ])),
        expectedDischargeDate: new FormControl(null, Validators.compose(
          [Validators.required,
          ])),
        actualAdmissionDate: new FormControl(null, Validators.compose(
          [
          this.intakeValidationService.isFutureDateValidator(),
         ])
        ),
        actualDischargeDate: new FormControl(null, Validators.compose(
          [
          this.intakeValidationService.isFutureDateValidator(),
          ])),
      },
        {
          validators: [this.intakeValidationService.priorDateValidator('expectedAdmissionDate', 'expectedDischargeDate'),
          this.intakeValidationService.priorDateValidator('actualAdmissionDate', 'actualDischargeDate')]

        });
      this.isServiceDetail = true;
      this.isOpfDates = false;
      this.isIpDates = true;
    } else if (this.caseTypeForm.get('serviceSetting').value.name === this.OP) {
      this.isServiceDetail = false;
      this.isOpfDates = false;
      this.isIpDates = false;
      this.caseTypeForm = new FormGroup({
        serviceSetting: new FormControl(this.serviceSettings[1], Validators.required),
        placeOfService: new FormControl(null, Validators.required),
        serviceDescription: new FormControl(null, Validators.required),
        priority: new FormControl(null, Validators.required),
      });
    } else if (this.caseTypeForm.get('serviceSetting').value.name === this.OPF) {
      this.caseTypeForm = new FormGroup({
        serviceSetting: new FormControl(this.serviceSettings[2], Validators.required),
        placeOfService: new FormControl(null, Validators.required),
        serviceDetail: new FormControl(null, Validators.required),
        serviceDescription: new FormControl(null, Validators.required),
        priority: new FormControl(null, Validators.required),
        startDate: new FormControl(null, Validators.required),
        endDate: new FormControl(null, Validators.required),
      });
      this.isServiceDetail = true;
      this.isOpfDates = true;
      this.isIpDates = false;
    } else {
      this.caseTypeForm =this.getDefaultAuthorizationForm()
    }
    this.emitValidationStatus();
    this.trackForm();
  }

  trackForm() {
    this.caseTypeForm.valueChanges.subscribe(res => {
      this.emitValidationStatus();
    })
  }

  emitValidationStatus(status = false) {
    this.onInValidate.emit({ invalidate: status ? status : this.caseTypeForm.invalid });
  }

  /*
    Returns ExpectedDischargeDate error message if exists else returns null
   */
  getExpectedDischargeDateErrorMsg() {
    if(this.caseTypeForm.controls.expectedAdmissionDate.value && !this.caseTypeForm.controls.expectedDischargeDate.value){
      this.caseTypeForm.controls['expectedDischargeDate'].setErrors({ 'invalidDate': true });
      this.emitValidationStatus(true);
    }
    return this.caseTypeForm && this.caseTypeForm.errors && this.caseTypeForm.errors.expectedDischargeDateisPrior ? 'Date cannot be prior to admission date' : null;
  }

  /*
    Returns ActualDischargeDate error message if exists else returns null
   */
  getActualDischargeDateErrorMsg() {
    return this.caseTypeForm && this.caseTypeForm.errors && this.caseTypeForm.errors.actualDischargeDateisPrior ? 'Date cannot be prior to admission date' : null;
  }

  // Get serviceSetting drop down menu
  async getServiceSettings() {
    await this.umintakeGraphqlService
      .loadBaseRefNameDisplayData(this.application, requestInfo.REQUESTTYPE)
      .then((res) => {
        res.data.ref.forEach(
          (item: { ref_id: number; ref_dspl: string; ref_desc: string }) => {
            const serviceSettingObj = {
              name: item.ref_dspl,
              value: item.ref_id,
            };
            this.serviceSettings.push(serviceSettingObj);
          }
        );
      });
  }

  // Get Priority drop down menu
  async getPriorities() {
    this.priorityTypes = [];
    await this.umintakeGraphqlService
      .loadBaseRefNameDisplayData(this.application, requestInfo.PRIORITY)
      .then((res) => {
        res.data.ref.forEach(
          (item: { ref_id: number; ref_dspl: string; ref_desc: string }) => {
            const priorityTypeObj = {
              name: item.ref_dspl,
              value: item.ref_id,
            };
            this.priorityTypes.push(priorityTypeObj);
          }
        );
      });
  }

  // Get Service Description drop down menu
  async getServiceDescriptions() {
    this.serviceDescriptionTypes = [];
    await this.umintakeGraphqlService
      .loadBaseRefNameDisplayData(this.application, requestInfo.SERVICEDESC)
      .then((res) => {
        res.data.ref.forEach(
          (item: { ref_id: number; ref_dspl: string; ref_desc: string }) => {
            const serviceDescriptionTypeObj = {
              name: item.ref_dspl,
              value: item.ref_id,
            };
            this.serviceDescriptionTypes.push(serviceDescriptionTypeObj);
          }
        );
      });
  }

  // Get PlaceOfService drop down menu
  async getPlaceOfServices(refId: number) {
    this.placeOfServices = [];
    await this.umintakeGraphqlService
      .loadRefChildDisplayDataInRef(this.application, refId)
      .then((res) => {
        res.data.ref_chld.forEach((item) => {
          const placeOfServiceObj = {
            name: item.refSetByChldRefIdChldRefNm.ref.ref_dspl,
            value: item.refSetByChldRefIdChldRefNm.ref.ref_id,
          };
          this.placeOfServices.push(placeOfServiceObj);
        });
      });
  }

  // Get service Detail Type drop down menu
  async getServiceDetailTypes(refId: number) {
    this.serviceDetailTypes = [];
    await this.umintakeGraphqlService
      .loadRefChildDisplayDataInRef(this.application, refId)
      .then((res) => {
        res.data.ref_chld.forEach((item) => {
          const serviceDetailTypeObj = {
            name: item.refSetByChldRefIdChldRefNm.ref.ref_dspl,
            value: item.refSetByChldRefIdChldRefNm.ref.ref_id,
          };
          this.serviceDetailTypes.push(serviceDetailTypeObj);
        });
      });
    await this.getServiceDescriptions();
    await this.getPriorities();
  }

  getDefaultAuthorizationForm(): FormGroup {
    return new FormGroup({
      serviceSetting: new FormControl(null, Validators.required),
      placeOfService: new FormControl(null, Validators.required),
      serviceDetail: new FormControl(null, Validators.required),
      serviceDescription: new FormControl(null, Validators.required),
      priority: new FormControl(null, Validators.required),
      expectedAdmissionDate: new FormControl(null, Validators.required),
      expectedDischargeDate: new FormControl(null, Validators.required),
      actualAdmissionDate: new FormControl(null, Validators.required),
      actualDischargeDate: new FormControl(null, Validators.required),
    });
  }

  async ngOnInit() {
    this.initGraphqlService();
    this.getConfigHeaders();
    this.getServiceSettings().then(async () => {
      if (this.hscID) {
        await this.getCaseTypeDataByHscId();
      } else {
        if (!this.caseTypeDetails) {
          this.caseTypeForm = this.getDefaultAuthorizationForm();
          this.emitValidationStatus();
        } else if (this.caseTypeDetails) {
          if (this.caseTypeDetails.srvc_set_ref_cd.ref_dspl !== this.OP) {
            await this.buildIpOpfCaseTypeForm(this.caseTypeDetails);
          } else {
            await this.buildOpCaseTypeForm(this.caseTypeDetails);
          }
        }
      }
    });
  }

  private getConfigHeaders() {
    this.configService.readConfig(this.application, this.version, CASE_TYPE_CONFIG).then(
      response => {
        const configFields = JSON.parse(response[0]?.value).caseTypeFields;
        configFields.forEach(field => {
          this.caseTypeHeaders.push(field.label);
        });
      }, error => {
        this.configErrorMsg = 'Error occurred when retrieving configuration data';
        console.log('Error occurred when retrieving config data: ', error);
      });
  }

  async getCaseTypeDataByHscId() {
    await this.umintakeGraphqlService.getCaseTypeDetailsByHscId(this.hscID, this.application).then(async (data: any) => {
      if (data.data.getCaseTypeDetails.srvc_set_ref_cd && data.data.getCaseTypeDetails.srvc_set_ref_cd.ref_dspl !== this.OP) {
        if (data.data.getCaseTypeDetails.hsc_facls.length > 0) {
          await this.buildIpOpfCaseTypeForm(data.data.getCaseTypeDetails);
        } else {
          await this.buildOpCaseTypeForm(data.data.getCaseTypeDetails);
        }
      } else {
        this.caseTypeForm = this.getDefaultAuthorizationForm();
        this.emitValidationStatus();
      }
    });
  }

  async buildOpCaseTypeForm(data: any) {
    const hscSrvcNonFacl = data.hsc_srvcs.find((value) =>
      value.hsc_srvc_non_facls && value.hsc_srvc_non_facls.length > 0).hsc_srvc_non_facls[0];
    await this.getPlaceOfServices(data.srvc_set_ref_cd.ref_id).then(async () => {
      await this.getServiceDescriptions();
      await this.getPriorities();
    });
    this.selected = data.srvc_set_ref_cd.ref_dspl;
    this.caseTypeForm = new FormGroup({
      serviceSetting: new FormControl(data.srvc_set_ref_cd ?
        this.serviceSettings[this.serviceSettings.findIndex(
          (arr) => arr.name === data.srvc_set_ref_cd.ref_dspl
        )
        ] : null, Validators.required),
      placeOfService: new FormControl(hscSrvcNonFacl.plsrv_ref_cd ?
        this.placeOfServices[this.placeOfServices.findIndex(
          (arr) => arr.name === hscSrvcNonFacl.plsrv_ref_cd.ref_dspl
        )
        ] : null, Validators.required),
      serviceDescription: new FormControl(hscSrvcNonFacl.srvc_desc_ref_cd ?
        this.serviceDescriptionTypes[this.serviceDescriptionTypes.findIndex(
          (arr) => arr.name === hscSrvcNonFacl.srvc_desc_ref_cd.ref_dspl
        )
        ] : null, Validators.required),
      priority: new FormControl(data.rev_prr_ref_cd ?
        this.priorityTypes[this.priorityTypes.findIndex(
          (arr) => arr.name === data.rev_prr_ref_cd.ref_dspl
        )
        ] : null, Validators.required),
    });
    this.emitValidationStatus();
    this.isServiceDetail = false;
    this.isOpfDates = false;
    this.isIpDates = false;
  }

  async buildIpOpfCaseTypeForm(caseTypeFormData: any) {
    this.ipOpfCaseTypeData = caseTypeFormData.hsc_facls[0];
    await this.getPlaceOfServices(caseTypeFormData.srvc_set_ref_cd.ref_id).then(async () => {
      await this.getServiceDetailTypes(this.ipOpfCaseTypeData.plsrv_ref_cd.ref_id);
    });
    this.selected = caseTypeFormData.srvc_set_ref_cd.ref_dspl;
    this.caseTypeForm = new FormGroup({
      serviceSetting: new FormControl(
        this.serviceSettings[this.serviceSettings.findIndex(
          (arr) => arr.name === caseTypeFormData.srvc_set_ref_cd.ref_dspl
        )
        ], Validators.required),
      placeOfService: new FormControl(
        this.placeOfServices[this.placeOfServices.findIndex(
          (arr) => arr.name === this.ipOpfCaseTypeData.plsrv_ref_cd.ref_dspl
        )
        ], Validators.required),
      serviceDescription: new FormControl(
        this.serviceDescriptionTypes[this.serviceDescriptionTypes.findIndex(
          (arr) => arr.name === this.ipOpfCaseTypeData.srvc_desc_ref_cd.ref_dspl
        )
        ], Validators.required),
      priority: new FormControl(
        this.priorityTypes[this.priorityTypes.findIndex(
          (arr) => arr.name === caseTypeFormData.rev_prr_ref_cd.ref_dspl
        )
        ], Validators.required),
      serviceDetail: new FormControl(
        this.serviceDetailTypes[this.serviceDetailTypes.findIndex(
          (arr) => arr.name === this.ipOpfCaseTypeData.srvc_dtl_ref_cd.ref_dspl
        )
        ], Validators.required)
    });
    this.emitValidationStatus();
    if (caseTypeFormData.srvc_set_ref_cd.ref_dspl === this.IP) {
      this.buildIpDateFormFields();
    }
    if (caseTypeFormData.srvc_set_ref_cd.ref_dspl === this.OPF) {
      this.buildOpfDateFormFields();
    }
  }


  datePickerOnChange(data, controlName) {
    const dateFormat = "DD/MM/YYYY";
    if (!moment(data.target.value, dateFormat, true).isValid()) {
      this.emitValidationStatus(true);
      this.caseTypeForm.controls[controlName].setErrors({ 'invalidDate': true });
    }

  }

  buildOpfDateFormFields() {
    this.caseTypeForm.addControl(
      'startDate',
      new FormControl(this.ipOpfCaseTypeData.actul_admis_dttm ? this.formatDate(this.ipOpfCaseTypeData.actul_admis_dttm) : null, Validators.required)
    );
    this.caseTypeForm.addControl(
      'endDate',
      new FormControl(this.ipOpfCaseTypeData.actul_dschrg_dttm ? this.formatDate(this.ipOpfCaseTypeData.actul_dschrg_dttm) : null, Validators.required)
    );
    this.isServiceDetail = true;
    this.isOpfDates = true;
    this.isIpDates = false;
  }

  buildIpDateFormFields() {
    this.caseTypeForm.addControl(
      'expectedAdmissionDate',
      new FormControl(this.ipOpfCaseTypeData?.expt_admis_dt ? this.formatDate(this.ipOpfCaseTypeData.expt_admis_dt) : null,
        Validators.required)
    );
    this.caseTypeForm.addControl(
      'expectedDischargeDate',
      new FormControl(this.ipOpfCaseTypeData?.expt_dschrg_dt ? this.formatDate(this.ipOpfCaseTypeData.expt_dschrg_dt) : null,
        Validators.required)
    );

    this.caseTypeForm.addControl(
      'actualAdmissionDate',
      new FormControl(this.ipOpfCaseTypeData?.actul_admis_dttm ? this.formatDate(this.ipOpfCaseTypeData.actul_admis_dttm) : null)
    );
    this.caseTypeForm.addControl(
      'actualDischargeDate',
      new FormControl(this.ipOpfCaseTypeData?.actul_dschrg_dttm ? this.formatDate(this.ipOpfCaseTypeData.actul_dschrg_dttm) : null)
    );
    this.isServiceDetail = true;
    this.isOpfDates = false;
    this.isIpDates = true;
  }

  formatDate(date) {
    const d = new Date(date);
    let month = '' + (d.getMonth() + 1);
    let day = '' + d.getDate();
    const year = d.getFullYear();

    if (month.length < 2) {
      month = '0' + month;
    }
    if (day.length < 2) {
      day = '0' + day;
    }

    return [month, day, year].join('/');
  }

  public initGraphqlService(): void {
    const configUrl = getEnvVar(GET_CONFIG_URL_PATH);
    this.configService = new ConfigService(this.httpClient, configUrl, this.umcaseService);
  }

  onSaveCaseDetails(): void {
    if (!this.caseTypeForm.invalid) {
      this.onSaveClicked = true;
      const caseTypeObj = this.getCaseTypeObject(this.caseTypeForm.value);
      this.umintakeGraphqlService.updateHsc(caseTypeObj, this.application).then(async (response: any) => {
        this.onSaveClicked = false;
        this.modal.close();
      });
    }
  }

  getCaseTypeObject(caseTypeFormValues: any) {
    const hscStatusRefId = null;
    return {
      hsc_id: this.hscID,
      srvc_set_ref_id: caseTypeFormValues.serviceSetting?.value,
      hsc: {
        ...(hscStatusRefId) && { hsc_sts_ref_id: hscStatusRefId },
        rev_prr_ref_id: caseTypeFormValues?.priority?.value,
        indv_id: null
      },
      hsc_facl: {
        plsrv_ref_id: caseTypeFormValues?.placeOfService?.value,
        srvc_desc_ref_id: caseTypeFormValues?.serviceDescription?.value,
        srvc_dtl_ref_id: caseTypeFormValues?.serviceDetail?.value,
        actul_admis_dttm: this.formatDate(
          caseTypeFormValues.actualAdmissionDate
        ),
        actul_dschrg_dttm: this.formatDate(
          caseTypeFormValues.actualDischargeDate
        ),
        expt_admis_dt: this.formatDate(
          caseTypeFormValues.expectedAdmissionDate
        ),
        expt_dschrg_dt: this.formatDate(
          caseTypeFormValues.expectedDischargeDate
        ),
      },
    };
  }

}
