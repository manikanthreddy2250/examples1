import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA, ChangeDetectorRef, Injectable } from '@angular/core';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Observable, of, empty } from 'rxjs';
import { MedicalReviewTreeService } from '../../services/um/service/clinical-guidelines/medical-review-tree/medical-review-tree.service';
import { HttpClient, HttpClientModule, HttpHandler } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import * as NDT_Response_draft from 'stories/assets/NDT_Response_draft.json';
import * as NDT_Response from 'stories/assets/NDT_Response.json';
import * as NDT_Discharge from 'stories/assets/NDT_Discharge.json';
import * as NDT_List from 'stories/assets/NDT_List.json';
import { SelectModule } from '@ecp/angular-ui-component-library/select';
import { InputModule } from '@ecp/angular-ui-component-library/input';
import { OptionModule } from '@ecp/angular-ui-component-library/option';
import { CheckboxModule } from '@ecp/angular-ui-component-library/checkbox';
import { MedicalReviewGraphqlServiceService } from '../../services/um/service/clinical-guidelines/medical-review-graphql-service/medical-review-graphql-service.service';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { TabsModule } from '@ecp/angular-ui-component-library/tabs';
import { MatGridListModule } from '@angular/material/grid-list';
import { ButtonModule } from '@ecp/angular-ui-component-library/button';
import { IconsModule } from '@ecp/angular-ui-component-library/icons';
import { CardModule } from '@ecp/angular-ui-component-library/card';
import { MatIconModule } from '@angular/material/icon';
import { AuthLibraryModule } from '@ecp/auth-library';
import { ModalModule } from '@ecp/angular-ui-component-library/modal';
import {FormFieldModule} from '@ecp/angular-ui-component-library/form-field';
import { AutoReviewTreeComponent } from './auto-review-tree.component';
@Injectable()
class MockHttpClient {
  put(url: string, body: any | null, options?: any) {
    return of({
      resourceType: 'QuestionnaireResponse',
      identifier: {
        use: 'official',
        value: 'd9fb2c05-ea95-4180-9b06-b01b15c5c261'
      },
      meta: {
        lastUpdated: '2021-01-21T11:50:32.436Z',
        tag: [
          {
            code: 'product_id',
            display: 'AISD'
          },
          {
            code: 'version_id',
            display: 'RM20'
          },
          {
            code: 'subset_id',
            display: 'AISD0153'
          },
          {
            code: 'review_type',
            display: 'NDT'
          },
          {
            code: 'autoSave',
            display: 'true'
          },
          {
            code: 'review_revision',
            display: 1
          },
          {
            code: 'review_version',
            display: 3
          }
        ]
      },
      questionnaire: 353625,
      item: [
        {
          linkId: 'AISD015304010201',
          answer: [
            {
              valueBoolean: 'true'
            }
          ]
        },
        {
          linkId: 'AISD01530401020201',
          answer: [
            {
              valueBoolean: 'true'
            }
          ]
        }
      ],
      contained: [
        {
          resourceType: 'Parameters',
          id: 'lastUserAction',
          parameter: [
            {
              name: 'step_response.id',
              valueString: 'RC3::AISD015304'
            },
            {
              name: 'selections.id',
              valueString: 'AISD01530401020201'
            },
            {
              name: 'clear_lower_loc',
              valueBoolean: 'true'
            }
          ]
        }
      ]
    });
  }
}
describe('AutoReviewTreeComponent', () => {
  let component: AutoReviewTreeComponent;
  let fixture: ComponentFixture<AutoReviewTreeComponent>;
  let medicalReviewTreeService;
  let medicalReviewGraphqlServiceService: MedicalReviewGraphqlServiceService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        CommonModule,
        BrowserModule,
        SelectModule,
        OptionModule,
        BrowserAnimationsModule,
        MatGridListModule,
        MatIconModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientTestingModule,
        ButtonModule,
        CardModule,
        TabsModule,
        IconsModule,
        AuthLibraryModule,
        HttpClientModule,
        CheckboxModule,
        ModalModule,
        FormFieldModule
    ],
      declarations: [AutoReviewTreeComponent],
      providers: [HttpClient, HttpHandler, MedicalReviewTreeService, MedicalReviewGraphqlServiceService],

      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AutoReviewTreeComponent);
    medicalReviewGraphqlServiceService = TestBed.inject(MedicalReviewGraphqlServiceService);
    component = fixture.componentInstance;

  });

  afterEach(() => {
    fixture.destroy();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should ngOnInit', () => {
    component.ngOnInit();
    expect(component.ngOnInit).toBeTruthy();
  });

  it('should collapseAll', () => {
    component.list = [
    {
        linkId: 'AISD0153040102',
        text: '<b>OBSERVATION,</b> <b>Both:</b>',
        definition: '/caas/content/notes?subset_unique_id=353625&id=AISD0153040102&note_type=ALL_NOTES',
        type: 'group',
        repeats: false,
        readOnly: true,
        item: [
          {
            linkId: 'AISD0153040101',
            text: '(From arrival in ED through decision to admit)',
            type: 'display'
          },
          {
            linkId: 'AISD015304010201',
            text: 'Short−acting beta−agonist administered prior to admission by licensed medical professional ≥ 2 doses',
            definition: '/caas/content/notes?subset_unique_id=353625&id=AISD015304010201&note_type=ALL_NOTES',
            type: 'boolean',
            repeats: false,
            readOnly: true,
            item: [{
              linkId: 'AISD01530401020201',
              text: 'O<sub>2 </sub>sat 90−91%(0.90−0.91) and &lt;&nbsp;baseline',
              definition: '/caas/content/notes?subset_unique_id=371360&id=AISD01530401020201&note_type=ALL_NOTES',
              type: 'boolean',
              repeats: false,
              readOnly: true,
              item: []
            }, {
              linkId: 'AISD01530401020202',
              text: 'Arterial Po<sub>2</sub> 56−60&nbsp;mmHg(7.4−8.0&nbsp;kPa) and &lt; baseline',
              definition: '/caas/content/notes?subset_unique_id=371360&id=AISD01530401020202&note_type=ALL_NOTES',
              type: 'boolean',
              repeats: false,
              readOnly: true,
              item: []
            }]
          }
        ]
      }
    ];
    component.collapseAll();
    expect(component.collapseAll).toBeTruthy();
  });

  it('should expandAll', () => {
    component.list = [
    {
        linkId: 'AISD0153040102',
        text: '<b>OBSERVATION,</b> <b>Both:</b>',
        definition: '/caas/content/notes?subset_unique_id=353625&id=AISD0153040102&note_type=ALL_NOTES',
        type: 'group',
        repeats: false,
        readOnly: true,
        item: [
          {
            linkId: 'AISD0153040101',
            text: '(From arrival in ED through decision to admit)',
            type: 'display'
          },
          {
            linkId: 'AISD015304010201',
            text: 'Short−acting beta−agonist administered prior to admission by licensed medical professional ≥ 2 doses',
            definition: '/caas/content/notes?subset_unique_id=353625&id=AISD015304010201&note_type=ALL_NOTES',
            type: 'boolean',
            repeats: false,
            readOnly: true,
            item: [{
              linkId: 'AISD01530401020201',
              text: 'O<sub>2 </sub>sat 90−91%(0.90−0.91) and &lt;&nbsp;baseline',
              definition: '/caas/content/notes?subset_unique_id=371360&id=AISD01530401020201&note_type=ALL_NOTES',
              type: 'boolean',
              repeats: false,
              readOnly: true,
              item: []
            }, {
              linkId: 'AISD01530401020202',
              text: 'Arterial Po<sub>2</sub> 56−60&nbsp;mmHg(7.4−8.0&nbsp;kPa) and &lt; baseline',
              definition: '/caas/content/notes?subset_unique_id=371360&id=AISD01530401020202&note_type=ALL_NOTES',
              type: 'boolean',
              repeats: false,
              readOnly: true,
              item: []
            }]
          }
        ]
      }
    ];
    component.expandAll();
    expect(component.expandAll).toBeTruthy();
  });

  it('should getIndex', () => {
    component.subsetUniqueId = 353625;
    component.containedTree = NDT_Response.data.getGuidelineReview.reviewResponse.contained;
    component.ndtResponse = NDT_Response.data.getGuidelineReview.reviewResponse;
    component.getIndex('Episode Day 1');
    expect(component.getIndex).toBeTruthy();
  });

  it('should registerControls', () => {
    component.primaryClinicalID = 1170;
    const idsArray = [
      {
        linkId: 'AISD015301',
        text: '(Symptom or finding within 24h)',
        type: 'display'
      },
      {
        linkId: 'AISD015302',
        text: '(Excludes PO medications unless noted)',
        type: 'display'
      },
      {
        linkId: 'AISD0153040102',
        text: '<b>OBSERVATION,</b> <b>Both:</b>',
        definition: '/caas/content/notes?subset_unique_id=353625&id=AISD0153040102&note_type=ALL_NOTES',
        type: 'group',
        repeats: false,
        readOnly: true,
        item: [
          {
            linkId: 'AISD0153040101',
            text: '(From arrival in ED through decision to admit)',
            type: 'display'
          },
          {
            linkId: 'AISD015304010201',
            text: 'Short−acting beta−agonist administered prior to admission by licensed medical professional ≥ 2 doses',
            definition: '/caas/content/notes?subset_unique_id=353625&id=AISD015304010201&note_type=ALL_NOTES',
            type: 'boolean',
            repeats: false,
            readOnly: true,
            item: []
          }
        ]
      }
    ];
    component.registerControls('AISD01530401020202');
    expect(component.registerControls).toBeTruthy();
  });

  it('should getIds', () => {

    const nestedJsonObj = [
      {
        resourceType: 'Questionnaire',
        id: 'AISD01530402',
        name: '<b>Episode Day 1</b>',
        item: [
          {
            linkId: 'AISD015301',
            text: '(Symptom or finding within 24h)',
            type: 'display'
          },
          {
            linkId: 'AISD015302',
            text: '(Excludes PO medications unless noted)',
            type: 'display'
          },
          {
            linkId: 'AISD0153040201',
            text: '<b>OBSERVATION,</b> <b>All:</b>',
            definition: '/caas/content/notes?subset_unique_id=353625&id=AISD0153040201&note_type=ALL_NOTES',
            type: 'group',
            repeats: false,
            readOnly: true,
            item: [
              {
                linkId: 'AISD015304020101',
                text: 'Short−acting beta−agonist administered prior to admission by licensed medical professional ≥ 2 doses',
                definition: '/caas/content/notes?subset_unique_id=353625&id=AISD015304020101&note_type=ALL_NOTES',
                type: 'boolean',
                repeats: false,
                readOnly: true,
                item: []
              },
              {
                linkId: 'AISD015304020102',
                text: 'Post treatment finding, <b>≥ One:</b>',
                type: 'group',
                repeats: false,
                readOnly: true,
                item: [
                  {
                    linkId: 'AISD01530402010201',
                    text: 'O<sub>2 </sub>sat 90−91%(0.90−0.91) and &lt;&nbsp;baseline',
                    definition: '/caas/content/notes?subset_unique_id=353625&id=AISD01530402010201&note_type=ALL_NOTES',
                    type: 'boolean',
                    repeats: false,
                    readOnly: true,
                    item: []
                  },
                  {
                    linkId: 'AISD01530402010202',
                    text: 'Arterial Po<sub>2</sub> 56−60&nbsp;mmHg(7.4−8.0&nbsp;kPa) and &lt; baseline',
                    definition: '/caas/content/notes?subset_unique_id=353625&id=AISD01530402010202&note_type=ALL_NOTES',
                    type: 'boolean',
                    repeats: false,
                    readOnly: true,
                    item: []
                  }
                ]
              }
            ]
          }
        ]
      }
    ];
    const childId = {
      linkId: 'AISD0153040601010202',
      text: 'No change in oxygen requirements last 2d',
      type: 'boolean',
      repeats: false,
      readOnly: true
    };

    component.allCheckedSelections = [
      {
        linkId: 'AISD0153040601010202',
        answer: [
          {
            valueBoolean: 'true'
          }
        ]
      }];

    component.savedReviewSelectionList = [
        {
          linkId: 'AISD0153040601010202',
          definition: '/medicalreviews/50906d70-1c86-48d5-86c0-89a4eff6a33c/emrdata/28a2074e-4462-4589-b7a1-9e0709e86eb5',
          text: 'CHECKED',
          answer: [
            {
              valueBoolean: 'true',
              valueString: 'A',
              valueUri: 'true'
            }
          ]
        },
        {
          linkId: 'AISD0153040601010202',
          definition: '/medicalreviews/50906d70-1c86-48d5-86c0-89a4eff6a33c/emrdata/8bce2e33-78e1-4745-8222-ca1fd6740bb6',
          text: 'UNCHECKED',
          answer: [
            {
              valueBoolean: 'false',
              valueString: 'J',
              valueUri: 'false'
            }
          ]
        }];
    component.getIds(nestedJsonObj);
    expect(childId.linkId).toEqual(component.allCheckedSelections[0].linkId);
    expect(childId.linkId).toEqual(component.savedReviewSelectionList[0].linkId);
    expect(component.savedReviewSelectionList[0].answer[0].valueString).toEqual('A');
    expect(component.savedReviewSelectionList[0].answer[0].valueUri).toEqual('true');

    component.changeBgColor = true;
    component.nodeIsChecked = true;
    component.plusFolderIcon = true;
    component.dotsFolderIcon = true;

    expect(component.getIds).toBeTruthy();
  });

  it('should  openCommentModal if ele is Reviewer Comments', () => {
    const cp = {
      id: 'AISD01530401',
      text: '<b>Initial review,</b> <b>One:</b>',
      toc_text: '<b>Initial review</b>',
      can_be_met: true,
      navigation_level: 2
    };
    component.commentsArray = [{
      name: 'AISD0153040102',
      valueId: 'TestingUser1, TestingUser1',
      valueDateTime: '2021-02-22T16:04:05.148Z',
      valueString: 'test'
    }, {
      name: 'AISD0153040102',
      valueId: 'TestingUser1, TestingUser1',
      valueDateTime: '2021-02-22T16:04:22.078Z',
      valueString: 'test3'
    }];
    component.commentModal = {
      cp,
      show: true
    };
    const ele = 'Reviewer Comments';
    component.showcp = cp;
    component.openCommentModal(ele , cp);
    expect(component.openCommentModal).toBeTruthy();
  });

  it('should  openCommentModal if ele is Reviewer Notes', () => {
    const cp = {
      id: 'AISD01530401',
      text: '<b>Initial review,</b> <b>One:</b>',
      toc_text: '<b>Initial review</b>',
      can_be_met: true,
      navigation_level: 2
    };
    component.commentsArray = [{
      name: 'AISD0153040102',
      valueId: 'TestingUser1, TestingUser1',
      valueDateTime: '2021-02-22T16:04:05.148Z',
      valueString: 'test'
    }, {
      name: 'AISD0153040102',
      valueId: 'TestingUser1, TestingUser1',
      valueDateTime: '2021-02-22T16:04:22.078Z',
      valueString: 'test3'
    }];
    component.notesModel = {
      subset_unique_id: '353625',
      id : 'AISD01530401',
      note_type: 'ALL_NOTES',
      parent_id: '',
      show: true
    };
    const ele = 'Reviewer Notes';
    component.showcp = cp;
    component.openCommentModal(ele , cp);
    expect(component.openCommentModal).toBeTruthy();
  });

  it('should create medical review tree from UUID', () => {
    const medRes = {
        data: {
            getMedicalReviewDetails: {
                reviewRes: {
                    resourceType: 'QuestionnaireResponse',
                    id: 353625,
                    meta: {
                        lastUpdated: '2021-05-17T15:01:07-05:00',
                        tag: [{
                            code: 'product_id',
                            display: 'AISD'
                        }, {
                            code: 'version_id',
                            display: 'RM20'
                        }, {
                            code: 'subset_id',
                            display: 'AISD0153'
                        }, {
                            code: 'review_type',
                            display: 'NDT'
                        }, {
                            code: 'autoSave',
                            display: false
                        }, {
                            code: 'reviewCreatedDate',
                            display: '2021-04-06T09:34:00-05:00'
                        }, {
                            code: 'reviewUserDescription',
                            display: 'TestingUser1, TestingUser1'
                        }, {
                            code: 'reviewUser',
                            display: 'UHGApuser1'
                        }, {
                            code: 'reviewUserOrganization',
                            display: 'UnitedHealthcare'
                        }, {
                            code: 'review_user_facility',
                            display: 'United Health Group'
                        }, {
                            code: 'source',
                            display: 'MR'
                        }, {
                            code: 'phase',
                            display: 'Initial'
                        }, {
                            code: 'review_revision',
                            display: 1
                        }, {
                            code: 'review_version',
                            display: 5
                        }, {
                            code: 'lockedDate',
                            display: '2021-05-17T15:01:07-05:00'
                        }, {
                            code: 'skipUI',
                            display: false
                        }]
                    },
                    status: 6,
                    questionnaire: 353625,
                    item: [{
                        linkId: 'AISD01530401030202',
                        answer: [{
                            valueBoolean: true
                        }]
                    }, {
                        linkId: 'AISD015304010201',
                        answer: [{
                            valueBoolean: false
                        }]
                    }, {
                        linkId: 'AISD01530401020201',
                        answer: [{
                            valueBoolean: false
                        }]
                    }, {
                        linkId: 'AISD01530401030201',
                        answer: [{
                            valueBoolean: true
                        }]
                    }, {
                        linkId: 'AISD015304010301',
                        answer: [{
                            valueBoolean: true
                        }]
                    }],
                    contained: [{
                        resourceType: 'Parameters',
                        id: 'lastUserAction',
                        parameter: [{
                            name: 'step_response.id',
                            valueString: 'RC3::AISD015304'
                        }, {
                            name: 'selections.id',
                            valueString: null
                        }, {
                            name: 'selections.choice',
                            valueString: 'UNCHECKED'
                        }, {
                            name: 'clear_lower_loc',
                            valueBoolean: false
                        }]
                    }, {
                        resourceType: 'Parameters',
                        id: 'comments',
                        parameter: []
                    }],
                    text: '<p class=tightSpacing><b>Introduction:</b>'
                }
            }
        }
    };

    const questionReq = {
        resourceType: 'QuestionnaireResponse',
        id: 353625,
        meta: {
            lastUpdated: '2021-05-17T15:01:07-05:00',
            tag: [{
                code: 'product_id',
                display: 'AISD'
            }, {
                code: 'version_id',
                display: 'RM20'
            }, {
                code: 'subset_id',
                display: 'AISD0153'
            }, {
                code: 'review_type',
                display: 'NDT'
            }, {
                code: 'autoSave',
                display: false
            }, {
                code: 'reviewCreatedDate',
                display: '2021-04-06T09:34:00-05:00'
            }, {
                code: 'reviewUserDescription',
                display: 'TestingUser1, TestingUser1'
            }, {
                code: 'reviewUser',
                display: 'UHGApuser1'
            }, {
                code: 'reviewUserOrganization',
                display: 'UnitedHealthcare'
            }, {
                code: 'review_user_facility',
                display: 'United Health Group'
            }, {
                code: 'source',
                display: 'MR'
            }, {
                code: 'phase',
                display: 'Initial'
            }, {
                code: 'review_revision',
                display: 1
            }, {
                code: 'review_version',
                display: 5
            }, {
                code: 'lockedDate',
                display: '2021-05-17T15:01:07-05:00'
            }, {
                code: 'skipUI',
                display: false
            }]
        },
        status: 6,
        questionnaire: 353625,
        item: [{
            linkId: 'AISD01530401030202',
            answer: [{
                valueBoolean: true
            }]
        }, {
            linkId: 'AISD015304010201',
            answer: [{
                valueBoolean: false
            }]
        }, {
            linkId: 'AISD01530401020201',
            answer: [{
                valueBoolean: false
            }]
        }, {
            linkId: 'AISD01530401030201',
            answer: [{
                valueBoolean: true
            }]
        }, {
            linkId: 'AISD015304010301',
            answer: [{
                valueBoolean: true
            }]
        }],
        contained: [{
            resourceType: 'Parameters',
            id: 'lastUserAction',
            parameter: [{
                name: 'step_response.id',
                valueString: 'RC3::AISD015304'
            }, {
                name: 'selections.id',
                valueString: null
            }, {
                name: 'selections.choice',
                valueString: 'UNCHECKED'
            }, {
                name: 'clear_lower_loc',
                valueBoolean: false
            }]
        }, {
            resourceType: 'Parameters',
            id: 'comments',
            parameter: []
        }],
        text: '<p class=tightSpacing><b>Introduction:</b>'
    };

    component.savedReviewSelectionList = [
        {
          linkId: 'AISD01530401020203',
          answer: [
            {
              valueBoolean: true
            }
          ]
        }];
    const userspy = spyOn(medicalReviewGraphqlServiceService, 'getMedicalReviewDataFromIQ').and.returnValue(medRes);
    component.getMedicalReviewTreeForUUID('6dd485ab-08c3-45b4-88b7-2d0918a7a988');
    expect(userspy).toHaveBeenCalled();
    component.getNextItemAPICallInFhirDraft(questionReq);
    expect(component.getMedicalReviewTreeForUUID).toBeTruthy();
    });

  it('should create getNextItemAPI call in FHIR Draft', () => {
        const reviewDetails = '';
        const questionReq = {
            resourceType: 'QuestionnaireResponse',
            id: 353625,
            meta: {
                lastUpdated: '2021-05-17T15:01:07-05:00',
                tag: [{
                    code: 'product_id',
                    display: 'AISD'
                }, {
                    code: 'version_id',
                    display: 'RM20'
                }, {
                    code: 'subset_id',
                    display: 'AISD0153'
                }, {
                    code: 'review_type',
                    display: 'NDT'
                }, {
                    code: 'autoSave',
                    display: false
                }, {
                    code: 'reviewCreatedDate',
                    display: '2021-04-06T09:34:00-05:00'
                }, {
                    code: 'reviewUserDescription',
                    display: 'TestingUser1, TestingUser1'
                }, {
                    code: 'reviewUser',
                    display: 'UHGApuser1'
                }, {
                    code: 'reviewUserOrganization',
                    display: 'UnitedHealthcare'
                }, {
                    code: 'review_user_facility',
                    display: 'United Health Group'
                }, {
                    code: 'source',
                    display: 'MR'
                }, {
                    code: 'phase',
                    display: 'Initial'
                }, {
                    code: 'review_revision',
                    display: 1
                }, {
                    code: 'review_version',
                    display: 5
                }, {
                    code: 'lockedDate',
                    display: '2021-05-17T15:01:07-05:00'
                }, {
                    code: 'skipUI',
                    display: false
                }]
            },
            status: 6,
            questionnaire: 353625,
            item: [{
                linkId: 'AISD01530401030202',
                answer: [{
                    valueBoolean: true
                }]
            }, {
                linkId: 'AISD015304010201',
                answer: [{
                    valueBoolean: false
                }]
            }, {
                linkId: 'AISD01530401020201',
                answer: [{
                    valueBoolean: false
                }]
            }, {
                linkId: 'AISD01530401030201',
                answer: [{
                    valueBoolean: true
                }]
            }, {
                linkId: 'AISD015304010301',
                answer: [{
                    valueBoolean: true
                }]
            }],
            contained: [{
                resourceType: 'Parameters',
                id: 'lastUserAction',
                parameter: [{
                    name: 'step_response.id',
                    valueString: 'RC3::AISD015304'
                }, {
                    name: 'selections.id',
                    valueString: null
                }, {
                    name: 'selections.choice',
                    valueString: 'UNCHECKED'
                }, {
                    name: 'clear_lower_loc',
                    valueBoolean: false
                }]
            }, {
                resourceType: 'Parameters',
                id: 'comments',
                parameter: []
            }],
            text: '<p class=tightSpacing><b>Introduction:</b>'
        };

        const statusRes = {
            data: {
                getQuestionnaireDetails: {
                    questionRes: {
                        resourceType: 'QuestionnaireResponse',
                        text: '<p class=tightSpacing><b>Introduction:</b>',
                        meta: {
                            lastUpdated: '2021-05-17T15:01:07-05:00',
                            tag: [{
                                code: 'product_id',
                                display: 'AISD'
                            }, {
                                code: 'version_id',
                                display: 'RM20'
                            }, {
                                code: 'subset_id',
                                display: 'AISD0153'
                            }, {
                                code: 'review_type',
                                display: 'NDT'
                            }, {
                                code: 'autoSave',
                                display: false
                            }, {
                                code: 'reviewCreatedDate',
                                display: '2021-04-06T09:34:00-05:00'
                            }, {
                                code: 'reviewUserDescription',
                                display: 'TestingUser1, TestingUser1'
                            }, {
                                code: 'reviewUser',
                                display: 'UHGApuser1'
                            }, {
                                code: 'reviewUserOrganization',
                                display: 'UnitedHealthcare'
                            }, {
                                code: 'review_user_facility',
                                display: 'United Health Group'
                            }, {
                                code: 'source',
                                display: 'MR'
                            }, {
                                code: 'phase',
                                display: 'Initial'
                            }, {
                                code: 'review_revision',
                                display: 1
                            }, {
                                code: 'review_version',
                                display: 5
                            }, {
                                code: 'lockedDate',
                                display: '2021-05-17T15:01:07-05:00'
                            }, {
                                code: 'skipUI',
                                display: false
                            }]
                        },
                        item: [{
                            id: 'AISD01530401030201',
                            answer: [{
                                valueBoolean: true
                            }]
                        }, {
                            id: 'AISD01530401',
                            answer: [{
                                valueBoolean: true
                            }]
                        }, {
                            id: 'AISD01530401030202',
                            answer: [{
                                valueBoolean: true
                            }]
                        }, {
                            id: 'AISD015304010302',
                            answer: [{
                                valueBoolean: true
                            }]
                        }, {
                            id: 'AISD015304',
                            answer: [{
                                valueBoolean: true
                            }]
                        }, {
                            id: 'AISD015304010301',
                            answer: [{
                                valueBoolean: true
                            }]
                        }, {
                            id: 'AISD0153040103',
                            answer: [{
                                valueBoolean: true
                            }]
                        }],
                        contained: [{
                                resourceType: 'Parameters',
                                id: 'outputParameters',
                                parameter: [{
                                    name: 'is_met',
                                    valueBoolean: true
                                }, {
                                    name: 'criteria_met',
                                    valueString: 'Acute Met'
                                }, {
                                    name: 'met_level_of_care.id',
                                    valueString: 'ACUTE'
                                }, {
                                    name: 'met_level_of_care.desc',
                                    valueString: 'Acute'
                                }, {
                                    name: 'exceeded_rule.higher_loc_met'
                                }, {
                                    name: 'next_button_text',
                                    valueString: ''
                                }, {
                                    name: 'responder_type',
                                    valueString: 'None'
                                }, {
                                    name: 'responder_met_id'
                                }, {
                                    name: 'episode_day_met',
                                    valueString: '<b>Initial review</b>'
                                }, {
                                    name: 'disposition_description'
                                }]
                            }, {
                                resourceType: 'Parameters',
                                id: 'responseMessages',
                                parameter: []
                            }, {
                                resourceType: 'Parameters',
                                id: 'cp_tree',
                                parameter: [{
                                    resourceType: 'Questionnaire',
                                    id: 'AISD01530401',
                                    name: '<b>Initial review</b>',
                                    item: [{
                                        linkId: 'AISD015301',
                                        text: '(Symptom or finding within 24h)',
                                        type: 'display'
                                    }, {
                                        linkId: 'AISD015302',
                                        text: '(Excludes PO medications unless noted)',
                                        type: 'display'
                                    }, {}, {}, {}, {
                                        linkId: 'AISD0153040105',
                                        text: '<b>CRITICAL,</b> <b>≥ One:</b>',
                                        definition: '/caas/content/notes?subset_unique_id=353625&id=AISD0153040105&note_type=ALL_NOTES',
                                        type: 'group',
                                        repeats: true,
                                        readOnly: false,
                                        item: [{
                                            linkId: 'AISD015304010501',
                                            text: 'Respiratory failure, <b>≥ One:</b>',
                                            type: 'group',
                                            repeats: true,
                                            readOnly: false,
                                            item: [{
                                                linkId: 'AISD01530401050101',
                                                text: 'Arterial Po<sub>2</sub> ≤&nbsp;39 mmHg(5.2 kPa)',
                                                definition: '/caas/content/notes?subset_unique_id=353625&id=AISD01530401050101&note_type=ALL_NOTES',
                                                type: 'boolean',
                                                repeats: false,
                                                readOnly: true,
                                                item: []
                                            }, {
                                                linkId: 'AISD01530401050102',
                                                text: 'Arterial or venous Pco<sub>2</sub> ≥ 60 mmHg(8.0 kPa) and pH&nbsp;≤&nbsp;7.24',
                                                definition: '/caas/content/notes?subset_unique_id=353625&id=AISD01530401050102&note_type=ALL_NOTES',
                                                type: 'boolean',
                                                repeats: false,
                                                readOnly: true,
                                                item: []
                                            }, {
                                                linkId: 'AISD01530401050103',
                                                text: 'Arterial or venous pH&nbsp;≤&nbsp;7.24',
                                                definition: '/caas/content/notes?subset_unique_id=353625&id=AISD01530401050103&note_type=ALL_NOTES',
                                                type: 'boolean',
                                                repeats: false,
                                                readOnly: true,
                                                item: []
                                            }, {
                                                linkId: 'AISD01530401050104',
                                                text: 'Coma, stupor, obtundation, or GCS ≤ 8',
                                                type: 'boolean',
                                                repeats: false,
                                                readOnly: true,
                                                item: []
                                            }]
                                        }, {
                                            linkId: 'AISD015304010502',
                                            text: 'Hemodynamic instability, <b>Both:</b>',
                                            type: 'group',
                                            repeats: true,
                                            readOnly: false,
                                            item: [{
                                                linkId: 'AISD01530401050201',
                                                text: 'Finding, <b>≥ One:</b>',
                                                type: 'group',
                                                repeats: true,
                                                readOnly: false,
                                                item: [{
                                                    linkId: 'AISD0153040105020101',
                                                    text: 'Heart rate &gt;&nbsp;120/min, sustained',
                                                    definition: '/caas/content/notes?subset_unique_id=353625&id=AISD0153040105020101&note_type=ALL_NOTES',
                                                    type: 'boolean',
                                                    repeats: false,
                                                    readOnly: true,
                                                    item: []
                                                }, {
                                                    linkId: 'AISD0153040105020102',
                                                    text: 'Systolic blood pressure, <b>≥ One:</b>',
                                                    type: 'group',
                                                    repeats: true,
                                                    readOnly: false,
                                                    item: [{
                                                        linkId: 'AISD015304010502010201',
                                                        text: '&lt; 90 mmHg',
                                                        type: 'boolean',
                                                        repeats: false,
                                                        readOnly: true,
                                                        item: []
                                                    }, {
                                                        linkId: 'AISD015304010502010202',
                                                        text: '&lt; 110 mmHg with chronic hypertension',
                                                        type: 'boolean',
                                                        repeats: false,
                                                        readOnly: true,
                                                        item: []
                                                    }, {
                                                        linkId: 'AISD015304010502010203',
                                                        text: '&gt; 30 mmHg decrease from baseline',
                                                        definition: '/caas/content/notes?subset_unique_id=353625&id=AISD015304010502010203&note_type=ALL_NOTES',
                                                        type: 'boolean',
                                                        repeats: false,
                                                        readOnly: true,
                                                        item: []
                                                    }, {
                                                        linkId: 'AISD015304010502010204',
                                                        text: 'Labile',
                                                        definition: '/caas/content/notes?subset_unique_id=353625&id=AISD015304010502010204&note_type=ALL_NOTES',
                                                        type: 'boolean',
                                                        repeats: false,
                                                        readOnly: true,
                                                        item: []
                                                    }]
                                                }, {
                                                    linkId: 'AISD0153040105020103',
                                                    text: 'MAP &lt;&nbsp;65&nbsp;mmHg',
                                                    type: 'boolean',
                                                    repeats: false,
                                                    readOnly: true,
                                                    item: []
                                                }]
                                            }, {
                                                linkId: 'AISD01530401050202',
                                                text: 'IV fluid resuscitation ≤ 2d',
                                                definition: '/caas/content/notes?subset_unique_id=353625&id=AISD01530401050202&note_type=ALL_NOTES',
                                                type: 'boolean',
                                                repeats: false,
                                                readOnly: true,
                                                item: []
                                            }]
                                        }, {
                                            linkId: 'AISD015304010503',
                                            text: 'Mechanical ventilation',
                                            type: 'boolean',
                                            repeats: false,
                                            readOnly: true,
                                            item: []
                                        }, {
                                            linkId: 'AISD015304010504',
                                            text: 'Vasopressor, vasodilator, or inotrope, continuous (excludes low or fixed dose for end stage heart failure)',
                                            type: 'boolean',
                                            repeats: false,
                                            readOnly: true,
                                            item: []
                                        }]
                                    }]
                                }, {}, {}, {}, {}, {}]
                            },
                            {
                                resourceType: 'Parameters',
                                id: 'redirectSubset',
                                parameter: [{
                                    name: 'type'
                                }, {
                                    name: 'id'
                                }, {
                                    name: 'uniqueId'
                                }, {
                                    name: 'latestSubsetId'
                                }, {
                                    name: 'subsetIdentifierId'
                                }, {
                                    name: 'desc'
                                }, {
                                    name: 'productId'
                                }, {
                                    name: 'productDesc'
                                }, {
                                    name: 'productHasSmartSheets'
                                }, {
                                    name: 'versionId'
                                }, {
                                    name: 'versionDesc'
                                }, {
                                    name: 'minorVersion'
                                }, {
                                    name: 'desc'
                                }, {
                                    name: 'revision'
                                }, {
                                    name: 'subsetType'
                                }, {
                                    name: 'current'
                                }, {
                                    name: 'rel'
                                }, {
                                    name: 'title'
                                }, {
                                    name: 'href'
                                }, {
                                    name: 'desc'
                                }, {
                                    name: 'revision'
                                }, {
                                    name: 'subsetType'
                                }, {
                                    name: 'custom'
                                }, {
                                    name: 'hasMedicalCodes'
                                }, {
                                    name: 'manifestReleaseDate'
                                }, {
                                    name: 'supportsCriteriaView'
                                }, {
                                    name: 'linksrel'
                                }, {
                                    name: 'linkstitle'
                                }, {
                                    name: 'link_href'
                                }, {
                                    name: 'target_id'
                                }]
                            }
                        ]
                    }
                }
            }
        };

        const title = '<b>Initial review</b>';
        const resText = 'Initial review';
        const text = 'Initial review';
        const titleObj = { id: 0, label: 'INITIAL REVIEW', isSelected: true, value: 'INITIAL REVIEW' };
        component.titlearray.push(titleObj);
        component.titlearray = [{
          id: 0,
          label: 'INITIAL REVIEW',
          isSelected: true,
          value: 'INITIAL REVIEW'
        }, { id: 1, label: 'EPISODE DAY 1', isSelected: false, value: 'EPISODE DAY 1' }, {
          id: 2,
          label: 'EPISODE DAY 2',
          isSelected: false,
          value: 'EPISODE DAY 2'
        }, { id: 3, label: 'EPISODE DAY 3', isSelected: false, value: 'EPISODE DAY 3' }, {
          id: 4,
          label: 'EPISODE DAY 4-6',
          isSelected: false,
          value: 'EPISODE DAY 4-6'
        }];
        expect(component.titlearray).toEqual([{
          id: 0,
          label: 'INITIAL REVIEW',
          isSelected: true,
          value: 'INITIAL REVIEW'
        }, { id: 1, label: 'EPISODE DAY 1', isSelected: false, value: 'EPISODE DAY 1' }, {
          id: 2,
          label: 'EPISODE DAY 2',
          isSelected: false,
          value: 'EPISODE DAY 2'
        }, { id: 3, label: 'EPISODE DAY 3', isSelected: false, value: 'EPISODE DAY 3' }, {
          id: 4,
          label: 'EPISODE DAY 4-6',
          isSelected: false,
          value: 'EPISODE DAY 4-6'
        }]);
        component.isLoading = false;
        component.reviewUUID = 'f0a465e5-d883-4985-a8ca-146a1c191709';
        component.stepResponseId = 'RC3::AISD015304';
        component.subsetUniqueId = 353625;
        component.reviewVersion = 1;
        component.reviewRevision = 2;
        expect(component.isLoading).toEqual(false);
        expect(component.reviewUUID).toEqual('f0a465e5-d883-4985-a8ca-146a1c191709');
        expect(component.stepResponseId).toEqual('RC3::AISD015304');
        expect(component.subsetUniqueId).toEqual(353625);
        expect(component.reviewVersion).toEqual(1);
        expect(component.reviewRevision).toEqual(2);
       // component.onChangeforDraft(0);
        component.primaryClinicalID = '1170';
        // expect(component.onChangeforDraft).toBeTruthy();
        component.response = statusRes.data.getQuestionnaireDetails.questionRes;
        const userspy = spyOn(medicalReviewGraphqlServiceService, 'getExistingQuestionnaireData').and.returnValue(statusRes);
        component.getNextItemAPICallInFhirDraft(questionReq);
        expect(userspy).toHaveBeenCalled();
        expect(component.getNextItemAPICallInFhirDraft).toBeTruthy();
      });

  it('should callWhenChecked', () => {
        const res = {
          resourceType: 'QuestionnaireResponse',
          meta: {
            lastUpdated: '2021-01-19T05:59:11.489Z',
            tag: [{ code: 'product_id', display: 353625 }, {
              code: 'version_id',
              display: 'RM20'
            }, { code: 'subset_id', display: 'AISD0153' }, { code: 'review_type', display: 'NDT' }, {
              code: 'autoSave',
              display: 'false'
            }]
          },
          item: [{ id: 'AISD01530401020202', answer: [{ valueBoolean: true }] }, {
            id: 'AISD015304020101',
            answer: [{ valueBoolean: true }]
          }, { id: 'AISD015304010202', answer: [{ valueBoolean: true }] }],
          contained: [{
            resourceType: 'Parameters',
            id: 'outputParameters',
            parameter: [{ name: 'is_met', valueBoolean: false }, {
              name: 'criteria_met',
              valueString: 'Criteria Not Met'
            }, { name: 'met_level_of_care.id' }, { name: 'met_level_of_care.desc' }, {
              name: 'episode_day_met',
              valueString: ''
            }, { name: 'disposition_description' }]
          }, { resourceType: 'Parameters', id: 'responseMessages', parameter: [] }]
        };
        component.callWhenChecked(res);
        expect(component.callWhenChecked).toBeTruthy();
      });

  it('should getIcon', () => {
        const item = {
          linkId: 'AISD015304020103',
          text: 'Intervention, <b>Both:</b>',
          type: 'group',
          repeats: false,
          readOnly: true,
          item: [{
            linkId: 'AISD01530402010301',
            text: 'Bronchodilator ≥&nbsp;4x/24h (includes inhaled)',
            definition: '/caas/content/notes?subset_unique_id=353625&id=AISD01530402010301&note_type=ALL_NOTES',
            type: 'boolean',
            repeats: false,
            readOnly: true,
            item: []
          }, {
            linkId: 'AISD01530402010302',
            text: 'Corticosteroid (includes PO or inhaled)',
            definition: '/caas/content/notes?subset_unique_id=353625&id=AISD01530402010302&note_type=ALL_NOTES',
            type: 'boolean',
            repeats: false,
            readOnly: true,
            item: []
          }]
        };
        component.getIcon(item);
        expect(component.getIcon).toBeTruthy();
      });

  it('should get commentChangedHandler', () => {
        const e = [{
          nodeCid: 'AISD0153040102',
          text: 'test8',
          user: 'TestingUser1, TestingUser1',
          date: '2021-01-12T09:49:44-06:00'
        }, {
          nodeCid: 'AISD015304010202',
          text: 'post',
          user: 'TestingUser1, TestingUser1',
          date: '2021-01-12T09:49:44-06:00'
        }];
        component.commentsArray = [{
          nodeCid: 'AISD0153040102',
          text: 'test8',
          user: 'TestingUser1, TestingUser1',
          date: '2021-01-12T09:49:44-06:00'
        }, {
          nodeCid: 'AISD015304010202',
          text: 'post',
          user: 'TestingUser1, TestingUser1',
          date: '2021-01-12T09:49:44-06:00'
        }];
        component.showcp = {
          id: 'AISD0153040102',
          text: '<b>Initial review,</b> <b>One:</b>',
          toc_text: '<b>Initial review</b>',
          can_be_met: true,
          navigation_level: 2
        };
        component.showcp.alertCommentAdded = false;
        component.commentChangedHandler(e);
        expect(component.commentChangedHandler).toBeTruthy();

      });

  it('should get getcompare', () => {
        const commentArray = [{
          nodeCid: 'AISD0153040102',
          text: 'test8',
          user: 'TestingUser1, TestingUser1',
          date: '2021-01-12T09:49:44-06:00'
        }, {
          nodeCid: 'AISD015304010202',
          text: 'post',
          user: 'TestingUser1, TestingUser1',
          date: '2021-01-12T09:49:44-06:00'
        }];
        const item = {
          nodeCid: 'AISD0153040102',
          text: 'test8',
          user: 'TestingUser1, TestingUser1',
          date: '2021-01-12T09:49:44-06:00'
        };
        component.returnComment = true;
        component.getcompare(commentArray, item);
        expect(component.getcompare).toBeTruthy();

      });

  it('should editButton()', () => {
        component.editButton();
        expect(component.editButton).toBeTruthy();

      });

  it('should onChange', () => {
        const event = 'Initial review';
        const containedDraft = [{
          resourceType: 'Questionnaire',
          id: 'AISD01530401',
          name: '<b>Initial review</b>',
          item: [{
            linkId: 'AISD015301',
            text: '(Symptom or finding within 24h)',
            type: 'display'
          }, {
            linkId: 'AISD015302',
            text: '(Excludes PO medications unless noted)',
            type: 'display'
          }, {}, {}, {}, {
            linkId: 'AISD0153040105',
            text: '<b>CRITICAL,</b> <b>≥ One:</b>',
            definition: '/caas/content/notes?subset_unique_id=353625&id=AISD0153040105&note_type=ALL_NOTES',
            type: 'group',
            repeats: true,
            readOnly: false,
            item: [{
              linkId: 'AISD015304010501',
              text: 'Respiratory failure, <b>≥ One:</b>',
              type: 'group',
              repeats: true,
              readOnly: false,
              item: [{
                linkId: 'AISD01530401050101',
                text: 'Arterial Po<sub>2</sub> ≤&nbsp;39 mmHg(5.2 kPa)',
                definition: '/caas/content/notes?subset_unique_id=353625&id=AISD01530401050101&note_type=ALL_NOTES',
                type: 'boolean',
                repeats: false,
                readOnly: true,
                item: []
              }, {
                linkId: 'AISD01530401050102',
                text: 'Arterial or venous Pco<sub>2</sub> ≥ 60 mmHg(8.0 kPa) and pH&nbsp;≤&nbsp;7.24',
                definition: '/caas/content/notes?subset_unique_id=353625&id=AISD01530401050102&note_type=ALL_NOTES',
                type: 'boolean',
                repeats: false,
                readOnly: true,
                item: []
              }, {
                linkId: 'AISD01530401050103',
                text: 'Arterial or venous pH&nbsp;≤&nbsp;7.24',
                definition: '/caas/content/notes?subset_unique_id=353625&id=AISD01530401050103&note_type=ALL_NOTES',
                type: 'boolean',
                repeats: false,
                readOnly: true,
                item: []
              }, {
                linkId: 'AISD01530401050104',
                text: 'Coma, stupor, obtundation, or GCS ≤ 8',
                type: 'boolean',
                repeats: false,
                readOnly: true,
                item: []
              }]
            }, {
              linkId: 'AISD015304010502',
              text: 'Hemodynamic instability, <b>Both:</b>',
              type: 'group',
              repeats: true,
              readOnly: false,
              item: [{
                linkId: 'AISD01530401050201',
                text: 'Finding, <b>≥ One:</b>',
                type: 'group',
                repeats: true,
                readOnly: false,
                item: [{
                  linkId: 'AISD0153040105020101',
                  text: 'Heart rate &gt;&nbsp;120/min, sustained',
                  definition: '/caas/content/notes?subset_unique_id=353625&id=AISD0153040105020101&note_type=ALL_NOTES',
                  type: 'boolean',
                  repeats: false,
                  readOnly: true,
                  item: []
                }, {
                  linkId: 'AISD0153040105020102',
                  text: 'Systolic blood pressure, <b>≥ One:</b>',
                  type: 'group',
                  repeats: true,
                  readOnly: false,
                  item: [{
                    linkId: 'AISD015304010502010201',
                    text: '&lt; 90 mmHg',
                    type: 'boolean',
                    repeats: false,
                    readOnly: true,
                    item: []
                  }, {
                    linkId: 'AISD015304010502010202',
                    text: '&lt; 110 mmHg with chronic hypertension',
                    type: 'boolean',
                    repeats: false,
                    readOnly: true,
                    item: []
                  }, {
                    linkId: 'AISD015304010502010203',
                    text: '&gt; 30 mmHg decrease from baseline',
                    definition: '/caas/content/notes?subset_unique_id=353625&id=AISD015304010502010203&note_type=ALL_NOTES',
                    type: 'boolean',
                    repeats: false,
                    readOnly: true,
                    item: []
                  }, {
                    linkId: 'AISD015304010502010204',
                    text: 'Labile',
                    definition: '/caas/content/notes?subset_unique_id=353625&id=AISD015304010502010204&note_type=ALL_NOTES',
                    type: 'boolean',
                    repeats: false,
                    readOnly: true,
                    item: []
                  }]
                }, {
                  linkId: 'AISD0153040105020103',
                  text: 'MAP &lt;&nbsp;65&nbsp;mmHg',
                  type: 'boolean',
                  repeats: false,
                  readOnly: true,
                  item: []
                }]
              }, {
                linkId: 'AISD01530401050202',
                text: 'IV fluid resuscitation ≤ 2d',
                definition: '/caas/content/notes?subset_unique_id=353625&id=AISD01530401050202&note_type=ALL_NOTES',
                type: 'boolean',
                repeats: false,
                readOnly: true,
                item: []
              }]
            }, {
              linkId: 'AISD015304010503',
              text: 'Mechanical ventilation',
              type: 'boolean',
              repeats: false,
              readOnly: true,
              item: []
            }, {
              linkId: 'AISD015304010504',
              text: 'Vasopressor, vasodilator, or inotrope, continuous (excludes low or fixed dose for end stage heart failure)',
              type: 'boolean',
              repeats: false,
              readOnly: true,
              item: []
            }]
          }]
        }, {}, {}, {}, {}, {}];
        component.ndtResponse = NDT_Response.data.getGuidelineReview.reviewResponse;
        component.containedTree = component.ndtResponse.contained;
        component.onChange(event);
        expect(event).toEqual('Initial review');
        expect(component.ndtResponse).toEqual(NDT_Response.data.getGuidelineReview.reviewResponse);
        expect(component.onChange).toBeTruthy();

      });

  it('should call getEhrData', () => {
    const res = {
      data: {
        getEhrData: {
          emrdataresponse:
          {
            resourceType: 'Parameters',
            parameter: [{
              name: 'OrderResultImpression',
              part: [{
                name: 'Classifications',
                part: [{
                  name: 'Classification',
                  valueParameterDefinition: {},
                  valueString: 'Chest X-ray',
                  valueAttachment: {},
                  valueCode: null
                }]
              }, {
                name: 'Medical Codes',
                part: [{
                  name: 'Epic.EAP.ID',
                  valueParameterDefinition: {},
                  valueString: '180347',
                  valueAttachment: {},
                  valueCode: null
                }]
              }, {
                name: 'Narrative',
                part: [{
                  name: 'AI_CONFIRMED',
                  valueParameterDefinition: {},
                  valueString: 'See attachment',
                  valueAttachment: {
                    contentType: 'text/plain',
                    language: 'QUJEMjAwMDMwNTMyNzlcblxuXG5QUk9DFsbHkgU2lnbmVkIGJ5OiBUb2RkIFJhZGlvbG9naXN0XG4=',
                    data: 'ABD20003053279\\n\\n\\nPROCEDURE: XR CHEST PORTABLE\\n\\nHISTORY: Other\\n'
                  },
                  valueCode: 'chest,findings,infiltrate,infiltrates,lung,mid,no,normal,patchy,significant,within'
                }]
              }]
            }]
          }
        }
      }
    };
    component.savedReviewSelectionList = [
      {
        linkId: 'AISD014704020101',
        definition: '/medicalreviews/50906d70-1c86-48d5-86c0-89a4eff6a33c/emrdata/28a2074e-4462-4589-b7a1-9e0709e86eb5',
        text: 'CHECKED',
        answer: [
          {
            valueBoolean: 'true',
            valueString: 'A',
            valueUri: 'true'
          }
        ]
      },
      {
        linkId: 'AISD0153040601010202',
        definition: '/medicalreviews/50906d70-1c86-48d5-86c0-89a4eff6a33c/emrdata/8bce2e33-78e1-4745-8222-ca1fd6740bb6',
        text: 'UNCHECKED',
        answer: [
          {
            valueBoolean: 'false',
            valueString: 'J',
            valueUri: 'false'
          }
        ]
      }];

    const item = {
      linkId: 'AISD014704020101',
      text: 'Pneumonia confirmed by imaging',
      definition: '/caas/content/notes?subset_unique_id=353623&id=AISD014704020101&note_type=ALL_NOTES',
      type: 'boolean',
      repeats: false
    };
    const ehrdataresponse = {
      resourceType: 'Parameters',
      parameter: [{
        name: 'OrderResultImpression',
        part: [{
          name: 'Classifications',
          part: [{
            name: 'Classification',
            valueParameterDefinition: {},
            valueString: 'Chest X-ray',
            valueAttachment: {},
            valueCode: null
          }]
        }, {
          name: 'Medical Codes',
          part: [{
            name: 'Epic.EAP.ID',
            valueParameterDefinition: {},
            valueString: '180347',
            valueAttachment: {},
            valueCode: null
          }]
        }, {
          name: 'Narrative',
          part: [{
            name: 'AI_CONFIRMED',
            valueParameterDefinition: {},
            valueString: 'See attachment',
            valueAttachment: {
              contentType: 'text/plain',
              language: 'QUJEMjAwMDMwNTMyNzlcblxuXG5QUk9DFsbHkgU2lnbmVkIGJ5OiBUb2RkIFJhZGlvbG9naXN0XG4=',
              data: 'ABD20003053279\\n\\n\\nPROCEDURE: XR CHEST PORTABLE\\n\\nHISTORY: Other\\n'
            },
            valueCode: 'chest,findings,infiltrate,infiltrates,lung,mid,no,normal,patchy,significant,within'
          }]
        }]
      }]
    };
    component.expandtext = false;
    component.ehrdataresponse = ehrdataresponse;
    expect(item.linkId).toEqual(component.savedReviewSelectionList[0].linkId);
    const iquuid = '50906d70-1c86-48d5-86c0-89a4eff6a33c';
    const emruuid = '28a2074e-4462-4589-b7a1-9e0709e86eb5';
    component.reviewId = iquuid;
    expect(iquuid).toEqual(component.reviewId);
    const userspy = spyOn(medicalReviewGraphqlServiceService, 'getEhrData').and.returnValue(res);
    expect(ehrdataresponse.resourceType).toEqual(component.ehrdataresponse.resourceType);
    component.getEhrData(item);
    expect(component.getEhrData).toBeTruthy();
  });

  it('should call closeCard', () => {
    component.closecard = true;
    component.closeCard();
    expect(component.closeCard).toBeTruthy();
  });

  it('should call getAllFolderNode', () => {
    component.savedReviewSelectionList = [
      {
        linkId: 'AISD0153040601010202',
        definition: '/medicalreviews/50906d70-1c86-48d5-86c0-89a4eff6a33c/emrdata/28a2074e-4462-4589-b7a1-9e0709e86eb5',
        text: 'CHECKED',
        answer: [
          {
            valueBoolean: 'true',
            valueString: 'A',
            valueUri: 'true'
          }
        ]
      },
      {
        linkId: 'AISD0153040601010202',
        definition: '/medicalreviews/50906d70-1c86-48d5-86c0-89a4eff6a33c/emrdata/8bce2e33-78e1-4745-8222-ca1fd6740bb6',
        text: 'UNCHECKED',
        answer: [
          {
            valueBoolean: 'false',
            valueString: 'J',
            valueUri: 'false'
          }
        ]
      }];
    component.allCheckedSelections = [
      {
        linkId: 'AISD0153040601010202',
        answer: [
          {
            valueBoolean: 'true'
          }
        ]
      }];
    component.getAllFolderNode();
    expect(component.getAllFolderNode).toBeTruthy();
  });

  it('should call showPartialMetSelection', () => {
    const childId = {
      linkId: 'AISD0153040601010202',
      text: 'No change in oxygen requirements last 2d',
      type: 'boolean',
      repeats: false,
      readOnly: true
    };
    component.partialMetSelections = [
      {
        linkId: 'AISD0153040601010202',
        definition: '/medicalreviews/50906d70-1c86-48d5-86c0-89a4eff6a33c/emrdata/28a2074e-4462-4589-b7a1-9e0709e86eb5',
        text: 'CHECKED',
        answer: [
          {
            valueBoolean: 'true',
            valueString: 'A',
            valueUri: 'true'
          }
        ]
      },
      {
        linkId: 'AISD0153040601010202',
        definition: '/medicalreviews/50906d70-1c86-48d5-86c0-89a4eff6a33c/emrdata/8bce2e33-78e1-4745-8222-ca1fd6740bb6',
        text: 'UNCHECKED',
        answer: [
          {
            valueBoolean: 'false',
            valueString: 'J',
            valueUri: 'false'
          }
        ]
      }];
    expect(childId.linkId).toEqual(component.partialMetSelections[0].linkId);
    component.showPartialMetSelection(childId);
    expect(component.showPartialMetSelection).toBeTruthy();
  });
});
