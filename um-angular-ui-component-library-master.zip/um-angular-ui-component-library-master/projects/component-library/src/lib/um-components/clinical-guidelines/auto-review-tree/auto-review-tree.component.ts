
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators, FormsModule, NumberValueAccessor } from '@angular/forms';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { MicroProductAuthService } from '@ecp/auth-library';
import { ThemePalette } from '@angular/material/core';
import { MedicalReviewGraphqlServiceService } from '../../services/um/service/clinical-guidelines/medical-review-graphql-service/medical-review-graphql-service.service';
import { MedicalReviewTreeService } from '../../services/um/service/clinical-guidelines/medical-review-tree/medical-review-tree.service';
import { getEnvVar } from '../../services/environment/envVarUtil';
import { ViewChild } from '@angular/core';
import { EcpUclModal } from '@ecp/angular-ui-component-library/modal';
import { GuidelinesConstants } from '../../../constant/guidelines-constants';
@Component({
  selector: 'um-auto-review-tree',
  templateUrl: './auto-review-tree.component.html',
  styleUrls: ['./auto-review-tree.component.scss']
})
export class AutoReviewTreeComponent implements OnInit {

  @Input() hscId: number;
  @Input() guidelineId: string;
  @Input() version: string;
  @Input() processTaskExecutionID: string;
  @ViewChild(EcpUclModal, { static: true })
  modal: EcpUclModal;
  @Output() editReview: EventEmitter<boolean> = new EventEmitter();
  icon = 'arrow_down';
  productId = '';
  versionVal = '';
  selectEpisode = 'Select Medical Review';
  task: Task = {
    name: 'Indeterminate',
    completed: false,
    color: 'primary',
    subtasks: [
      {
        name: 'Primary', completed: false, color: 'primary',
      }
      ,
      { name: 'Accent', completed: false, color: 'accent' },
      { name: 'Warn', completed: false, color: 'warn' }
    ]
  };
  commentsFhir: any = [];
  containedDraft: any;
  reviewRes: any;
  reviewRevision = 0;
  reviewVersion = 0;
  metstat: any;
  @Input() primaryClinicalID: any;
  @Input() metStat: any;
  reviewDesc: any;
  draftFlag = false;
  primaryClinicalId = null;
  reviewUUID = null;
  containedTree = [];
  isSelected: any;
  medReviewTreeForm: FormGroup = this.fb.group({});
  medReviewTypeForm: FormGroup = new FormGroup({
    medReviewType: new FormControl(null),
  });
  selected: any;
  savedReviewSelectionList: any = [];
  allCheckedSlectionItems: any = [];
  show: any;
  idsArray: any = [];
  showMyContainer = false;
  criteriaMet = GuidelinesConstants.CRITERIA_DESC;
  expandAllBtn = GuidelinesConstants.EXPAND_ALL;
  collapseAllBtn = GuidelinesConstants.COLLAPSE_ALL;
  dischargeReviewBtn = GuidelinesConstants.DISCHARGE_REVIEW;
  public list: any = [];
  public ndtResponse: any = [];
  public titlearray: any = [];
  ndtSelectionList: any = [];
  FormBuilder: any;
  count = 0;
  choices: Choice[] = [];
  checkedIds: Selection[] = [];
  checkedIdsFhir: SelectionFhir[] = [];
  allCheckedSelections: SelectionFhir[] = [];
  stepResponseId: any;
  subsetUniqueId: any;
  @Input() reviewId: any;
  isLoading = false;
  response: any;
  identifiers: any = [];
  reviewDetails: any;
  clearLowerLoc: any;
  commentsArray: any = [];
  guideLineID: any;
  subsetUniqueIdValue: any;
  commentsDraftFhir = [];
  returnComment: any;
  selectCriteriaWarn = false;
  label: 'Label';
  labelPosition = 'after';
  checkboxState = 'default';
  alertCommentAdded = true;
  commentsList: Map<string, Comment[]> = new Map();
  commeText = 'Reviewer Comments';
  showcp: any;
  dischargeReview = '';
  dischargeReviewFlag = false;
  dischargeIdsArray = [];
  changeBgColor = false;
  nodeIsChecked = false;
  plusFolderIcon = false;
  dotsFolderIcon = false;
  ehrdataresponse: any;
  emrdatalink: any;
  itemText: any;
  expandtext = false;
  showcomment = false;
  showNotes = false;
  closecard = false;
  showemrdata = false;
  checkPartialMet = false;
  partialMetSelections: any = [];
  nodeIspartialChecked = false;

  commentModal: any = {
    show: false
  };

  notesModel: any = {
    show: false
  };

  selectedValue: string;
  overviewText: any;
  items = [
    this.commeText
  ];

  // For Notes
  itemsNote = [
    this.commeText,
    'Reviewer Notes'
  ];
  editBtn = GuidelinesConstants.EDIT;
  ndtTreeRes;
  ndtReviewDetails;
  soursceData = [];
  narrativeData: any;
  dividedtext: any;
  constructor(private readonly fb: FormBuilder,
    private readonly http: HttpClient,
    private readonly medicalReviewTreeService: MedicalReviewTreeService,
    private readonly medicalReviewGraphqlServiceService: MedicalReviewGraphqlServiceService,
    private readonly microProductAuthService: MicroProductAuthService) {
  }

  ngOnInit(): void {
    this.isLoading = true;
    this.medReviewTreeForm = this.fb.group({});
    this.medReviewTypeForm = new FormGroup({
      medReviewType: new FormControl(null),
    });
    if (this.reviewId !== '' || this.reviewId !== null) {
      this.getMedicalReviewTreeForUUID(this.reviewId);
    }
  }



  collapseAll() {
    this.list.forEach((node: any) => {
      this.expandCollapseChild(node, false);
    });
  }

  expandAll() {
    this.list.forEach((node: any) => {
      this.expandCollapseChild(node, true);
    });
  }

  expandCollapseChild(node: any, isExpand: boolean) {
    node.showMyContainer = isExpand;
    if (node.item) {
      node.item.forEach(childNode => {
        this.expandCollapseChild(childNode, isExpand);
      });
    }
  }

  onChange(event: string) {
    this.dischargeReviewFlag = false;
    let idVal: number;
    let index: number = null;
    if (event !== null && (this.ndtResponse !== null)) {
      // this.containedTree = this.ndtResponse['contained'];
      if (this.containedDraft === null || this.containedDraft === undefined) {
        this.containedTree = this.ndtResponse.contained;
      } else {
        this.containedTree = this.containedDraft;
        this.draftFlag = true;
      }
      const eventVal = event;
      index = this.getIndex(event);
      this.list = Array.of(this.containedTree[index]);
      const reviewDescription = this.list[0].name;
      this.reviewDesc = reviewDescription.substring(3, reviewDescription.length - 4);
      this.getIds(this.list);
      if (index !== undefined && index !== null) {
        idVal = this.containedTree[index].id;
      }
      this.registerControls(idVal);
    }
  }


  getIndex(event) {
    let text: string = null;
    let index: number = null;
    if (this.containedTree !== null && this.containedTree !== undefined && this.containedTree.length > 0) {
      for (let i = 0; i < this.containedTree.length; i++) {
        const title = this.containedTree[i].name;
        if (title !== null && title !== undefined && this.draftFlag === false) {
          text = title.substring(3, title.length - 4);
        }
        if (title !== null && title !== undefined && this.draftFlag === true) {
          text = title.substring(3, title.length - 17);
        }
        console.log('text..' + text);
        if (text === event) {
          console.log('...');
          console.log('text' + text);
          console.log(event);
          index = i;
          break;
        }
      }
    }
    return index;
  }

  /** Add controls based on the id's in the nested json structure */
  registerControls(id: any) {
    this.medReviewTreeForm.addControl(id, this.fb.control('', [Validators.required]));
    if (this.idsArray !== null && this.idsArray !== undefined && this.idsArray.length > 0) {
      for (const value of this.idsArray) {
        if (value !== undefined) {
          this.medReviewTreeForm.addControl(value.linkId, this.fb.control('', [Validators.required]));
        }
      }
    }

  }

  // Fetching id's from Nested JSON object and storing it in a idsArray array to register controls
  getIds(nestedJsonObj: any) {
    for (const value of nestedJsonObj) {
      const childId = value;
      childId.changeBgColor = false;
      childId.nodeIsChecked = false;
      childId.plusFolderIcon = false;
      childId.dotsFolderIcon = false;
      childId.checkPartialMet = false;
      childId.nodeIspartialChecked = false;
      for (let l = 0; l < this.allCheckedSelections.length; l++) {
        if (childId.linkId === this.allCheckedSelections[l].linkId || childId.id === this.allCheckedSelections[l].linkId) {
          childId.changeBgColor = true;
          childId.nodeIsChecked = true;
        }
      }
      this.showPartialMetSelection(childId);
      for (let l = 0; l < this.savedReviewSelectionList.length; l++) {
        if (childId.linkId === this.savedReviewSelectionList[l].linkId || childId.id === this.savedReviewSelectionList[l].linkId) {
          if (this.savedReviewSelectionList[l].answer[0].valueString !== null) {
            if (this.savedReviewSelectionList[l].answer[0].valueUri === true && this.savedReviewSelectionList[l].answer[0].valueString) {
              childId.dotsFolderIcon = true;
            } else if (this.savedReviewSelectionList[l].answer[0].valueUri === false && this.savedReviewSelectionList[l].answer[0].valueString) {
              childId.plusFolderIcon = true;
            }
          }
        }
      }
      if (childId !== undefined && childId.hasOwnProperty('item')) {
        if (childId.linkId !== undefined && childId.type !== 'display') {
          this.idsArray.push(childId);
        }
        this.getIds(childId.item);
      } else {
        this.idsArray.push(childId);
      }
    }
  }




  openCommentModal(ele, cp: any) {
    const list = [];
    const commentText = '';
    const comments: Comment[] = [];
    for (let k = 0; k < this.commentsArray.length; k++) {
      if (cp.linkId === this.commentsArray[k].nodeCid || cp.id === this.commentsArray[k].nodeCid) {
        comments.push({
          text: commentText + this.commentsArray[k].text,
          userName: this.commentsArray[k].user ? this.commentsArray[k].user : '',
          dateTime: this.commentsArray[k].date ? this.commentsArray[k].date : ''

        });
        this.commentsList.set(cp.linkId || cp.id, comments);
      }
    }
    console.log(ele);
    console.log(cp);
    if (ele === this.commeText) {
      this.closecard = true;
      this.showcomment = true;
      this.showNotes = false;
      this.showemrdata = false;
      this.showcp = cp;
      this.commentModal = {
        commentsList: this.commentsList,
        cp,
        show: true
      };
    }
    else if (ele === 'Reviewer Notes') {
      this.closecard = true;
      this.showcomment = false;
      this.showNotes = true;
      this.showemrdata = false;
      this.notesModel = {
        subset_unique_id: String(this.subsetUniqueId),
        id: cp.linkId || cp.id,
        note_type: 'ALL_NOTES',
        parent_id: '',
        show: true
      };
      console.log(this.notesModel);
    }
  }





  async getMedicalReviewTreeForUUID(uuid: string) {
    const savedReviewCommentsList = [];
    const medRes = await this.medicalReviewGraphqlServiceService.getMedicalReviewDataFromIQ(uuid);
    console.log('review data existing' + JSON.stringify(medRes));
    const questionReq = medRes.data.getMedicalReviewDetails.reviewRes;
    this.subsetUniqueId = questionReq.id;
    const obj = {
      name: 'next',
      valueBoolean: false
    };
    questionReq.contained[0].parameter.push(obj);
    console.log('review data existing' + JSON.stringify(questionReq));
    this.savedReviewSelectionList = questionReq.item;
    for (let j = 0; j < this.savedReviewSelectionList.length; j++) {
      if (this.savedReviewSelectionList[j].answer[0].valueBoolean === true) {
        this.checkedIdsFhir.push({
          linkId: this.savedReviewSelectionList[j].linkId,
          answer: [{ valueBoolean: 'true' }]
        });
      }
    }
    questionReq.contained[1].parameter.forEach(element => {
      const commentObj = {
        nodeCid: element.name,
        text: element.valueString,
        user: element.valueId,
        date: element.valueDateTime,
      };
      this.commentsArray.push(commentObj);
    });
    this.overviewText = questionReq.text;
    this.getNextItemAPICallInFhirDraft(questionReq);
  }

  async getNextItemAPICallInFhirDraft(questionReq) {
    const statusRes = await this.medicalReviewGraphqlServiceService.getExistingQuestionnaireData(questionReq);
    console.log('questionnaire response data existing' + JSON.stringify(statusRes));
    this.response = statusRes.data.getQuestionnaireDetails.questionRes;
    console.log('questionnaire response Fhir' + JSON.stringify(this.response));
    this.reviewDetails = statusRes.data.getQuestionnaireDetails.questionRes;
    this.criteriaMet = this.response.contained[0].parameter[1].valueString;
    this.containedDraft = this.response.contained[2].parameter;
    console.log('questionnaire response data existing' + JSON.stringify(this.containedDraft));
    this.allCheckedSlectionItems = this.response.item;
    for (let j = 0; j < this.allCheckedSlectionItems.length; j++) {
      if (this.allCheckedSlectionItems[j].answer[0].valueBoolean === true) {
        this.allCheckedSelections.push({
          linkId: this.allCheckedSlectionItems[j].id,
          answer: [{ valueBoolean: 'true' }]
        });
      }
    }
    console.log(this.allCheckedSelections);
    this.getAllFolderNode();
    for (let i = 0; i < this.containedDraft.length; i++) {
      const title = this.containedDraft[i].name;
      const episodeDay = this.response.contained[0].parameter.filter(param => param.name === 'episode_day_met');
      const episodeValue = episodeDay[0].valueString.substring(3, title.length - 17);
      if (title !== null && title !== undefined) {
        const text: string = title.substring(3, title.length - 17);
        const titleObj = {
          name: text,
          value: text
        };
        const getSelectedEpisode = {
          id: i,
          label: text
        };
        this.selectEpisode = episodeValue;
        this.selectedValue = episodeValue;
        this.titlearray.push(titleObj);
        if (episodeValue === getSelectedEpisode.label) {
          this.onChangeforDraft(getSelectedEpisode.id);
        }
      }
    }
  }



  onChangeforDraft(id) {
    this.show = undefined;
    this.ndtResponse = this.containedDraft;
    if (id >= 0 && this.ndtResponse != null) {
      const contained = this.ndtResponse;
      console.log(`contained in onChange...${JSON.stringify(contained)}`);
      this.list = Array.of(contained[id]);
      console.log(`contained.id...${contained[id].id}`);
      this.show = id;
      console.log(`this.list.....${JSON.stringify(this.list)}`);
      this.getIds(this.list);
      this.registerControls(contained[id].id);
      if (this.reviewId !== '' && this.reviewId !== undefined) {
        this.callWhenChecked(this.response);
      }
    }
  }


  callWhenChecked(res: any) {
    this.checkboxState = 'active';
    let parameters = [];
    parameters = res.contained[0].parameter;
    const containedParameters = res.contained;
    for (let j = 0; j < containedParameters.length; j++) {
      if (containedParameters[j].id === 'outputParameters') {
        for (let k = 0; k < containedParameters[j].parameter.length; k++) {
          if (containedParameters[j].parameter[k].name === 'criteria_met') {
            this.criteriaMet = containedParameters[j].parameter[k].valueString;
          }
        }
      }
    }
    let selected = [];
    selected = res.item;
    this.choices = [];
    this.updateUiWithSelection(selected);
  }

  updateUiWithSelection(selected: any) {
    if (selected !== null && selected !== undefined && selected.length > 0) {
      for (let k = 0; k < selected.length; k++) {
        if (selected[k].hasOwnProperty('answer')) {
          this.choices.push({ id: selected[k].id, value: selected[k].answer[0].valueBoolean, frequency: 0 });
          if (this.medReviewTreeForm.get(selected[k].id) !== null) {
            this.medReviewTreeForm.get(selected[k].id)?.patchValue(selected[k].answer[0].valueBoolean);
          }
        }
      }
    }
  }


  getIcon(item) {
    item.showMyContainer = !item.showMyContainer;
    if (item.showMyContainer) {
      this.icon = 'arrow_up';
    } else {
      this.icon = 'arrow_down';
    }
    return this.icon;
  }

  commentChangedHandler(e: any) {
    console.log(JSON.stringify(e));
    e.forEach(item => {
      console.log(this.getcompare(this.commentsArray, item));
      if (this.getcompare(this.commentsArray, item) === 0) {
        this.commentsArray.push(item);
      }
    });
    console.log(this.commentsArray);
    console.log(`commentChangedHandler`);
    console.log(e);
    for (let l = 0; l < this.commentsArray.length; l++) {
      if (this.showcp.linkId === this.commentsArray[l].nodeCid || this.showcp.id === this.commentsArray[l].nodeCid) {
        this.showcp.alertCommentAdded = false;
      }
    }
  }


  onSubmit() {
  }

  getcompare(ca: any, item): any {
    this.returnComment = 0;
    ca.forEach(comment => {
      if (item.nodeCid === comment.nodeCid && item.date === comment.date && item.text === comment.text) {
        console.log(item);
        this.returnComment = 1;
      }
    });
    return this.returnComment;
  }

  editButton() {
    this.editReview.emit(true);
  }

  async getEhrData(item) {
    this.expandtext = false;
    const iquuid = this.reviewId;
    console.log(this.savedReviewSelectionList);
    console.log(item);
    this.savedReviewSelectionList.forEach(node => {
      if (node.linkId === item.linkId || node.linkId === item.id) {
        this.emrdatalink = node?.definition;
        this.itemText = item.text || item.name;
      }
    });
    const emruuid = this.emrdatalink.substring(this.emrdatalink.indexOf('/emrdata/') + 9, this.emrdatalink.length - 0);
    console.log(emruuid + 'text-' + this.itemText);
    if (iquuid) {
     const emrResponse = await this.medicalReviewGraphqlServiceService.getEhrData(iquuid, emruuid);
     this.ehrdataresponse = emrResponse?.data?.getEhrData?.emrdataresponse;
     if (this.ehrdataresponse?.resourceType){
          console.log(JSON.stringify(this.ehrdataresponse));
          this.ehrdatainformation(this.ehrdataresponse);
          this.closecard = true;
          this.showcomment = false;
          this.showNotes = false;
          this.showemrdata = true;
        }
    }
  }

  ehrdatainformation(ehrdataresponse) {
    this.soursceData = [];
    ehrdataresponse.parameter.forEach(datagrp => {
      this.soursceData.push(datagrp);
      datagrp.part.forEach(datadtl => {
        datadtl.part.forEach(field => {
          if (field?.valueAttachment?.data) {
            const text = field?.valueAttachment?.data.replaceAll('\\n', '<br>');
            this.dividedtext = text.substring(0, text.indexOf('<br>'));
            this.narrativeData = text.substring(text.indexOf('<br>'), text.length);
            console.log(field?.valueAttachment?.data.replaceAll('\\n', '<br>'));
          }
        });
      });
    });
  }

  closeCard(): any{
    this.closecard = !this.closecard;
  }

  getAllFolderNode(): any{
    let notchecked: boolean;
    this.savedReviewSelectionList.forEach(node => {
      if (node.answer[0].valueString) {
        notchecked = true;
        this.allCheckedSelections.forEach(item => {
          if (node.linkId === item.linkId) {
            notchecked = false;
          }
        });
        if (notchecked){
          this.partialMetSelections.push(node);
        }
      }
    });
    console.log(this.partialMetSelections);
  }

  showPartialMetSelection(childId): any{
    for (let l = 0; l < this.partialMetSelections.length; l++) {
      if (childId.linkId === this.partialMetSelections[l].linkId || childId.id === this.partialMetSelections[l].linkId) {
        childId.checkPartialMet = true;
        childId.nodeIspartialChecked = true;
      }
    }
  }



}

interface Choice {
  id: string;
  value: string;
  frequency: number;

}

interface PartiallyMet {
  id: string;
  value: boolean;
  partiallyMetIdValue: boolean;

}

interface Selection {
  id: string;
  choice: string;
}

interface SelectionFhir {
  linkId: string;
  answer: [{
    valueBoolean: string
  }];
}

interface Comment {
  text: string;
  userName: string;
  dateTime: string;
}

interface SubsetRedirectParameters {
  name: string;
  valueString: any;
}

export interface Task {
  name: string;
  completed: boolean;
  color: ThemePalette;
  subtasks?: Task[];
}
