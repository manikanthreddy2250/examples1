import { APP_BASE_HREF, CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { TabsModule } from '@ecp/angular-ui-component-library/tabs';
import { MatGridListModule } from '@angular/material/grid-list';
import { ButtonModule } from '@ecp/angular-ui-component-library/button';
import { IconsModule } from '@ecp/angular-ui-component-library/icons';
import { CardModule } from '@ecp/angular-ui-component-library/card';
import { MatIconModule } from '@angular/material/icon';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { HttpClientModule } from "@angular/common/http";
import { CheckboxModule } from '@ecp/angular-ui-component-library/checkbox';
import { AuthLibraryModule } from "@ecp/auth-library";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SelectModule } from '@ecp/angular-ui-component-library/select';
import { InputModule } from '@ecp/angular-ui-component-library/input';
import { OptionModule } from '@ecp/angular-ui-component-library/option';
import { ModalModule } from '@ecp/angular-ui-component-library/modal';
import {MenuPopupModule } from '@ecp/angular-ui-component-library/menu-popup';
import {FormFieldModule} from '@ecp/angular-ui-component-library/form-field';
import { LinkModule } from '@ecp/angular-ui-component-library/link';
import {MedicalReviewCommentsModule} from '../medical-review-comments/medical-review-comments.module';
import {MedicalReviewNotesModule} from '../medical-review-notes/medical-review-notes.module';
import {MedicalReviewCitationsModule} from '../medical-review-citations/medical-review-citations.module';
import {Popup} from '@ecp/angular-ui-component-library/utilities';
import { GuidelineSummaryModule } from '../guideline-summary/guideline-summary.module';
import { AutoReviewTreeComponent } from './auto-review-tree.component';
import { ScrollbarModule } from '@ecp/angular-ui-component-library/scrollbar';

@NgModule({
    declarations: [AutoReviewTreeComponent],
    imports: [
      CommonModule,
      BrowserModule,
      ModalModule,
      SelectModule,
      InputModule,
      OptionModule,
      BrowserAnimationsModule,
      MatGridListModule,
      MatIconModule,
      FormsModule,
      ReactiveFormsModule,
      ButtonModule,
      CardModule,
      TabsModule,
      IconsModule,
      AuthLibraryModule,
      HttpClientModule,
      CheckboxModule,
      FormFieldModule,
      LinkModule,
      MenuPopupModule,
      MedicalReviewCommentsModule,
      MedicalReviewNotesModule,
      MedicalReviewCitationsModule,
      GuidelineSummaryModule,
      ScrollbarModule
    ],
    exports: [
        AutoReviewTreeComponent
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA],
    providers: [Popup]
})
export class AutoReviewTreeModule { }
