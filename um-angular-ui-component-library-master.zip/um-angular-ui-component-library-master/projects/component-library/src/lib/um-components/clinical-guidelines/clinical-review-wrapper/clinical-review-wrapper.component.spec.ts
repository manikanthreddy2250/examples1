import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ClinicalReviewWrapperComponent } from './clinical-review-wrapper.component';
import {BedDayDecisionService} from '../../services/um/service/clinical-guidelines/guideline-bed-day-decision-service/bed-day-decision.service';
import {MicroProductAuthService} from '@ecp/auth-library';
import {GuidelinesUtils} from '../shared/guidelines-utils';
import {OAuthLogger, OAuthService, UrlHelperService} from 'angular-oauth2-oidc';
import {LoggerConfig, NGXLogger, NGXLoggerHttpService, NGXMapperService} from 'ngx-logger';
import {DatePipe} from '@angular/common';
import {CUSTOM_ELEMENTS_SCHEMA, Injectable, NO_ERRORS_SCHEMA} from '@angular/core';
import {ClinicalReviewWrapperModule} from './clinical-review-wrapper.module';
import {SubsetSearchModule} from '../subset-search/subset-search.component.module';
import { MedicalReviewGraphqlServiceService } from '../../services/um/service/clinical-guidelines/medical-review-graphql-service/medical-review-graphql-service.service';

@Injectable()
class MicroProductAuthServiceStub {
  getEcpClaims(): any {
    return {
      'x-ecp-claims': {
        'x-ecp-attrs': {},
        'x-ecp-alt-user-id': '',
        'x-ecp-cli-orgs': [{
          'org-id': 'ecp',
          'func-roles': [{
            'role-name': 'rules_admin',
            'appl-roles': ['autoapproval-dmn_deploy', 'autorouting-dmn_deploy', 'bpm_execute_all', 'case_wf_mgmt_ui_read', 'configuration-dmn_deploy', 'example_dmn_grp_deploy', 'health_srvc_delete', 'icuerules-dmn_deploy', 'memberblocking-dmn_deploy', 'obsderivation-dmn_deploy', 'programs-dmn_deploy', 'rules_authoring_write', 'siteofservice-dmn_deploy', 'system_mgmt_user', 'testharness-dmn_deploy', 'um_intake_ui_read', 'umintake_sos_mbr_elig_dmn_grp_deploy', 'umintake_sos_prov_elig_dmn_grp_deploy']
          }]
        }],
        'x-ecp-first-name': 'Sahithya',
        'x-ecp-type': 'PASSWORD',
        'x-ecp-user-id': '001173408',
        'x-ecp-email': 'sahithya_sivaraju@optum.com',
        'x-ecp-last-name': 'Pachipulusu Sivaraju',
        'x-ecp-source': 'msid'
      },
      'https://hasura.io/jwt/claims': {
        'x-hasura-default-role': 'autoapproval-dmn_deploy',
        'x-hasura-attrs': '{ }',
        'x-hasura-cli-org': 'ecp',
        'x-hasura-user-id': '001173408',
        'x-hasura-func-role': 'rules_admin',
        'x-hasura-allowed-roles': ['autoapproval-dmn_deploy', 'autorouting-dmn_deploy', 'bpm_execute_all', 'case_wf_mgmt_ui_read', 'configuration-dmn_deploy', 'example_dmn_grp_deploy', 'health_srvc_delete', 'icuerules-dmn_deploy', 'memberblocking-dmn_deploy', 'obsderivation-dmn_deploy', 'programs-dmn_deploy', 'rules_authoring_write', 'siteofservice-dmn_deploy', 'system_mgmt_user', 'testharness-dmn_deploy', 'um_intake_ui_read', 'umintake_sos_mbr_elig_dmn_grp_deploy', 'umintake_sos_prov_elig_dmn_grp_deploy']
      },
      scope: 'openid',
      iss: 'ecp-dev',
      exp: 1603473684,
      client_id: 'ecp_platform'
    };
  }

  getUserRoles(): any {
    return 'Provider';
  }

  getEcpOrgId(): any {
    return 'TESTUSERID';
  }

  getEcpToken(): any {
    return 'testToken';
  }

  isLocalHost(): any{
    return false;
  }
  getHasuraRole(): any {
    return 'clinical_guidelines_md';
  }
  getUserID(): any{
    return 'ngopi2';
  }
}

describe('ClinicalReviewWrapperComponent', () => {
  let component: ClinicalReviewWrapperComponent;
  let medicalReviewGraphqlServiceService: MedicalReviewGraphqlServiceService;
  let fixture: ComponentFixture<ClinicalReviewWrapperComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ClinicalReviewWrapperModule],
      declarations: [],
      // tslint:disable-next-line:max-line-length
      providers: [BedDayDecisionService, {provide: MicroProductAuthService, useClass: MicroProductAuthServiceStub},  GuidelinesUtils, OAuthService, OAuthService, UrlHelperService, OAuthLogger,
        NGXLogger, NGXMapperService, NGXLoggerHttpService, LoggerConfig, DatePipe, MedicalReviewGraphqlServiceService],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicalReviewWrapperComponent);
    medicalReviewGraphqlServiceService = TestBed.inject(MedicalReviewGraphqlServiceService);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should previousPage', () => {
    component.previousPage('');
    const pageOrder = 1;
    const isLastPage = false;
    const isFirstPage = true;
    expect(component).toBeTruthy();
  });

  it('should nextPage()', () => {
    // component.nextPage();
    expect(component).toBeTruthy();
  });
  it('should ngOnit()', () => {
    component.isTransitionPlan = true;
    component.ngOnInit();
    expect(component.ngOnInit).toBeTruthy();
  });

  /*it('should showReadOnlyOnBedday()', () => {
    component.pageOrder = 2;
    component.isLastPage = true;
    component.showReadOnlyOnBedday();
    expect(component.showReadOnlyOnBedday).toBeTruthy();
  });*/

  it('should getPageOrder()', () => {
    component.getPageOrder();
    expect(component.getPageOrder()).toBe('SUBSET_SEARCH');
  });

  it('should getPageOrder() for draft flow', () => {
   // component.enableNewReview = true;
    component.pageOrder = 0;
    component.getPageOrder();
   // expect(component.enableNewReview).toEqual(true);
    expect(component.getPageOrder()).toBeTruthy('SUBSET_SEARCH');
  });

  it('should getPageOrder() for draft flow subset search', () => {
   // component.enableNewReview = true;
    component.pageOrder = 1;
    component.getPageOrder();
   // expect(component.enableNewReview).toEqual(true);
    expect(component.getPageOrder()).toBeTruthy('SUBSET_SEARCH');
  });

  it('should getPageOrder() for draft flow guideline summary', () => {
   // component.enableNewReview = true;
    component.pageOrder = 2;
    component.getPageOrder();
   // expect(component.enableNewReview).toEqual(true);
    expect(component.getPageOrder()).toBeTruthy('GUIDELINE_SUMMARY');
  });
  it('should getPageOrder() for draft flow medical review page', () => {
    // component.enableNewReview = true;
    component.pageOrder = 3;
    component.getPageOrder();
   // expect(component.enableNewReview).toEqual(true);
    expect(component.getPageOrder()).toBeTruthy('MEDICAL_REVIEW_TREE');
  });
  it('should getPageOrder() for draft flow bed day pge', () => {
   // component.enableNewReview = true;
    component.pageOrder = 4;
    component.getPageOrder();
   // expect(component.enableNewReview).toEqual(true);
    expect(component.getPageOrder()).toBeTruthy('BED_DAY_DECISION');
  });
  it('should getPageOrder() when review id not null for first page', () => {
    // component.enableNewReview = true;
    component.reviewId = '0bdd7028-e568-4157-be9a-5877a6de9013';
    component.pageOrder = 0;
    component.getPageOrder();
    // expect(component.enableNewReview).toEqual(true);
    expect(component.getPageOrder()).toBeTruthy('MEDICAL_REVIEW_TREE');
  });

  it('should getPageOrder() when review id not null for default page', () => {
    // component.enableNewReview = true;
    component.reviewId = '0bdd7028-e568-4157-be9a-5877a6de9013';
    component.pageOrder = 1;
    component.getPageOrder();
    // expect(component.enableNewReview).toEqual(true);
    expect(component.getPageOrder()).toBeTruthy('MEDICAL_REVIEW_TREE');
  });

  function isLoggedInUserMD(): any {
    return true;
  }

  it('should getPageOrder() when logged in user MD', () => {
    component.isLoggedInUserMD();
    component.pageOrder = 2;
    component.isLastPage = true;
    component.getPageOrder();
    // expect(component.isLoggedInUserMD).toEqual(true);
    expect(component.pageOrder).toEqual(2);
    expect(component.isLastPage).toEqual(true);
    expect(component.isLoggedInUserMD).toBeTruthy();
    expect(component.getPageOrder()).toBeTruthy('MEDICAL_REVIEW_TREE');
  });

  it('should getLoggedInUserAppRoles()', () => {
    component.getLoggedInUserAppRoles();
    expect(component.getLoggedInUserAppRoles).toBeTruthy();
  });

  it('should isLoggedInUserMD()', () => {
    component.isLoggedInUserMD();
    expect(component.isLoggedInUserMD).toBeTruthy();
  });

  it('should getDefaultStartPage()', () => {
    component.pageOrder = 0;
    component.getPageOrder();
    expect(component.getPageOrder()).toBe('SUBSET_SEARCH');
  });

  it('should getSubsetSearchPage()', () => {
    component.pageOrder = 2;
    component.getPageOrder();
    expect(component.getPageOrder()).toBe('GUIDELINE_SUMMARY');
  });

  it('should getGuidelineSummary()', () => {
    component.pageOrder = 3;
    component.getPageOrder();
    expect(component.getPageOrder()).toBe('MEDICAL_REVIEW_TREE');
  });

 /* Failing .. please check and uncomment
  it('should getMedicalReviewPage()', () => {
    component.pageOrder = 4;
    component.getPageOrder();
    expect(component.getPageOrder()).toBe('SUBSET_SEARCH');
  }); */

  it('should getBedDayPage()', () => {
    component.pageOrder = 5;
    component.getPageOrder();
    expect(component.getPageOrder()).toBe('SUBSET_SEARCH');
  });

  it('should nextPage()', () => {
    // @ts-ignore
    component.getPageOrder();
    expect(component.getPageOrder()).toBe('SUBSET_SEARCH');
    component.nextPage('');
    expect(component.nextPage).toBeTruthy();

  });

  // it('should nextPage() when review id not null', () => {
  //   // @ts-ignore
  //   component.reviewId = '0bdd7028-e568-4157-be9a-5877a6de9013';
  //   component.pageOrder = 1;
  //   component.isFirstPage = true;
  //   /*expect(component.isLastPage).toEqual(true);
  //   expect(component.pageOrder).toEqual(1);*/
  //   component.getPageOrder();
  //   expect(component.getPageOrder()).toBe('MEDICAL_REVIEW_TREE');
  //   component.nextPage('');
  //   expect(component.nextPage).toBeTruthy();

  // });

  it('should newReviewFlow()', () => {
    // @ts-ignore
    const event = {
      guidelineId: 'AISD',
      version: 'RM20'
    };
    component.pageOrder = 1;
    component.getPageOrder();
    expect(component.getPageOrder()).toBe('SUBSET_SEARCH');
    component.pageOrder = 3;
    component.getPageOrder();
    expect(component.getPageOrder()).toBe('MEDICAL_REVIEW_TREE');
    component.pageOrder = 2;
    component.getPageOrder();
    expect(component.getPageOrder()).toBe('GUIDELINE_SUMMARY');
    component.newReviewFlow(event);
    expect(component.newReviewFlow).toBeTruthy();

  });


  it('should editReview()', () => {
    component.pageOrder = 1;
    component.isLastPage = false;
    component.isFirstPage = true;
    component.editReview(true);
    expect(component.editReview).toBeTruthy();
  });

  it('should getMedicalReviewSummaryDetails()', () => {
    const medRes = {data: {getMedicalReviewDetails: {reviewRes: {resourceType: 'QuestionnaireResponse', id: 353625, meta: {lastUpdated: '2021-05-17T15:01:07-05:00', tag: [{code: 'product_id', display: 'AISD'}, {code: 'version_id', display: 'RM20'}, {code: 'subset_id', display: 'AISD0153'}, {code: 'review_type', display: 'NDT'}, {code: 'autoSave', display: false}, {code: 'reviewCreatedDate', display: '2021-04-06T09:34:00-05:00'}, {code: 'reviewUserDescription', display: 'TestingUser1, TestingUser1'}, {code: 'reviewUser', display: 'UHGApuser1'}, {code: 'reviewUserOrganization', display: 'UnitedHealthcare'}, {code: 'review_user_facility', display: 'United Health Group'}, {code: 'source', display: 'MR'}, {code: 'phase', display: 'Initial'}, {code: 'review_revision', display: 1}, {code: 'review_version', display: 5}, {code: 'lockedDate', display: '2021-05-17T15:01:07-05:00'}, {code: 'skipUI', display: false}]}, status: 6, questionnaire: 353625, item: [{linkId: 'AISD01530401030202', answer: [{valueBoolean: true}]}, {linkId: 'AISD015304010201', answer: [{valueBoolean: false}]}, {linkId: 'AISD01530401020201', answer: [{valueBoolean: false}]}, {linkId: 'AISD01530401030201', answer: [{valueBoolean: true}]}, {linkId: 'AISD015304010301', answer: [{valueBoolean: true}]}], contained: [{resourceType: 'Parameters', id: 'lastUserAction', parameter: [{name: 'step_response.id', valueString: 'RC3::AISD015304'}, {name: 'selections.id', valueString: null}, {name: 'selections.choice', valueString: 'UNCHECKED'}, {name: 'clear_lower_loc', valueBoolean: false}]}, {resourceType: 'Parameters', id: 'comments', parameter: []}], text: '<p class=tightSpacing><b>Introduction:</b> &nbsp;&nbsp;&nbsp;&nbsp;</p> <p class=tightSpacing>Chronic obstructive pulmonary disease (COPD) is a progressive condition characterized by persistent respiratory symptoms and chronic airflow limitation. The airflow limitation, determined by spirometric abnormality, is not fully reversible and is associated with an increased inflammatory response to noxious gases or particles. A COPD exacerbation is an acute change from baseline dyspnea, cough, or sputum production that requires a change in the medication regimen. &nbsp;&nbsp;&nbsp;&nbsp;</p> <p class=tightSpacing>When the patient is diagnosed with COPD, the severity of the airflow limitation is classified into 4 stages based on the forced expiratory volume (FEV1) measurement post bronchodilator administration as follows: &nbsp;&nbsp;&nbsp;&nbsp;</p> <p class=tightSpacing>GOLD 1 Mild: FEV1 80% predicted &nbsp;&nbsp;&nbsp;&nbsp;</p> <p class=tightSpacing>GOLD 2 Moderate: FEV1 50−79% predicted &nbsp;&nbsp;&nbsp;&nbsp;</p> <p class=tightSpacing>GOLD 3 Severe: FEV1 30−49% predicted GOLD 4 Very severe: FEV1 &lt; 30% predicted &nbsp;&nbsp;&nbsp;&nbsp;</p> <p class=tightSpacing>Although several studies have shown a strong correlation between the Global Initiative for Chronic Obstructive Lung Disease (GOLD) classification system and an increased risk of COPD exacerbation, the Combined COPD Assessment provides a more accurate assessment of the patient\'s level of risk than the GOLD classification alone (<bib rel=citation title=Mapel et al., Int J Chron Obstruct Pulmon Dis 2015, 10: 1477-86 href=/caas/citations/17834 id=17834>Mapel et al., Int J Chron Obstruct Pulmon Dis 2015, 10: 1477-86</bib>). The Combined COPD Assessment includes several factors, the patient\'s GOLD Classification (GOLD 1−4), the patient\'s perception of breathlessness (using the Modified Medial Research Council (mMRC) questionnaire with mMRC Grades 0−4 or the COPD Assessment Test (CAT) with a scale of 0−40, and their comorbidities. &nbsp;&nbsp;&nbsp;&nbsp;</p> <p class=tightSpacing>These factors are used to assign the patient with COPD to one of 4 patient groups (<bib rel=citation title=Global Initiative for Chronic Obstructive Lung Disease (GOLD), Global Strategy for the Diagnosis, Management and Prevention of COPD. 2020 href=/caas/citations/1460287 id=1460287>Global Initiative for Chronic Obstructive Lung Disease (GOLD), Global Strategy for the Diagnosis, Management and Prevention of COPD. 2020</bib>): &nbsp;&nbsp;&nbsp;&nbsp;</p> <p class=tightSpacing>Patient Group A &nbsp;&nbsp;&nbsp;&nbsp;</p> <table cellspacing=0 cellpadding=0 class=displaynobordernoback><tbody><tr><td valign=top><p class=tightSpacing>&nbsp;&nbsp;&nbsp;&nbsp;</p> </td> <td valign=top>Low Risk, Less Symptoms &nbsp;&nbsp;&nbsp;&nbsp;</td> </tr> <tr><td valign=top><p class=tightSpacing>&nbsp;&nbsp;&nbsp;&nbsp;</p> </td> <td valign=top>Typically GOLD 1 or GOLD 2 &nbsp;&nbsp;&nbsp;&nbsp;</td> </tr> <tr><td valign=top><p class=tightSpacing>&nbsp;&nbsp;&nbsp;&nbsp;</p> </td> <td valign=top>0−1 exacerbation per year and no hospitalization for exacerbation &nbsp;&nbsp;&nbsp;&nbsp;</td> </tr> <tr><td valign=top><p class=tightSpacing>&nbsp;&nbsp;&nbsp;&nbsp;</p> </td> <td valign=top>CAT score &lt; 10 or mMRC grade 0−1 Patient Group B &nbsp;&nbsp;&nbsp;&nbsp;</td> </tr> <tr><td valign=top><p class=tightSpacing>&nbsp;&nbsp;&nbsp;&nbsp;</p> </td> <td valign=top>Low Risk, More Symptoms &nbsp;&nbsp;&nbsp;&nbsp;</td> </tr> <tr><td valign=top><p class=tightSpacing>&nbsp;&nbsp;&nbsp;&nbsp;</p> </td> <td valign=top>Typically GOLD 1 or GOLD 2 &nbsp;&nbsp;&nbsp;&nbsp;</td> </tr> <tr><td valign=top><p class=tightSpacing>&nbsp;&nbsp;&nbsp;&nbsp;</p> </td> <td valign=top>0−1 exacerbation per year and no hospitalization for exacerbation &nbsp;&nbsp;&nbsp;&nbsp;</td> </tr> <tr><td valign=top><p class=tightSpacing>&nbsp;&nbsp;&nbsp;&nbsp;</p> </td> <td valign=top>CAT score 10 or mMRC grade 2 Patient Group C &nbsp;&nbsp;&nbsp;&nbsp;</td> </tr> <tr><td valign=top><p class=tightSpacing>&nbsp;&nbsp;&nbsp;&nbsp;</p> </td> <td valign=top>High Risk, Less Symptom &nbsp;&nbsp;&nbsp;&nbsp;</td> </tr> <tr><td valign=top><p class=tightSpacing>&nbsp;&nbsp;&nbsp;&nbsp;</p> </td> <td valign=top>Typically GOLD 3 or GOLD 4 &nbsp;&nbsp;&nbsp;&nbsp;</td> </tr> <tr><td valign=top><p class=tightSpacing>&nbsp;&nbsp;&nbsp;&nbsp;</p> </td> <td valign=top>2 exacerbations per year or 1 with hospitalization for exacerbation &nbsp;&nbsp;&nbsp;&nbsp;</td> </tr> <tr><td valign=top><p class=tightSpacing>&nbsp;&nbsp;&nbsp;&nbsp;</p> </td> <td valign=top>CAT score &lt; 10 or mMRC grade 0−1 Patient Group D &nbsp;&nbsp;&nbsp;&nbsp;</td> </tr> <tr><td valign=top><p class=tightSpacing>&nbsp;&nbsp;&nbsp;&nbsp;</p> </td> <td valign=top>High Risk, More Symptoms &nbsp;&nbsp;&nbsp;&nbsp;</td> </tr> <tr><td valign=top><p class=tightSpacing>&nbsp;&nbsp;&nbsp;&nbsp;</p> </td> <td valign=top>Typically GOLD 3 or GOLD 4 &nbsp;&nbsp;&nbsp;&nbsp;</td> </tr> <tr><td valign=top><p class=tightSpacing>&nbsp;&nbsp;&nbsp;&nbsp;</p> </td> <td valign=top>2 exacerbations per year or 1 with hospitalization for exacerbation &nbsp;&nbsp;&nbsp;&nbsp;</td> </tr> <tr><td valign=top><p class=tightSpacing>&nbsp;&nbsp;&nbsp;&nbsp;</p> </td> <td valign=top>CAT score 10 or mMRC grade 2 &nbsp;&nbsp;&nbsp;&nbsp;</td> </tr> </tbody></table> <p class=tightSpacing>Most COPD exacerbations can be attributed to either infection or exposure to pollutants, but for many exacerbations the cause is never identified. For patients with unexplained exacerbations, pulmonary embolism should be ruled out as a cause. A meta−analysis involving 880 patients found that 16.1% had a pulmonary embolism (PE) confirmed by computed tomography pulmonary angiography (<bib rel=citation title=Aleva et al., Chest 2016 href=/caas/citations/17846 id=17846>Aleva et al., Chest 2016</bib>).&nbsp;&nbsp;&nbsp;&nbsp;</p><br /><p class=tightSpacing><b>Evaluation and Treatment:</b> &nbsp;&nbsp;&nbsp;&nbsp;</p> <p class=tightSpacing>A severe chronic obstructive pulmonary disease (COPD) exacerbation may be indicated by the following signs (<bib rel=citation title=Global Initiative for Chronic Obstructive Lung Disease (GOLD), Global Strategy for the Diagnosis, Management and Prevention of COPD. 2020 href=/caas/citations/1460287 id=1460287>Global Initiative for Chronic Obstructive Lung Disease (GOLD), Global Strategy for the Diagnosis, Management and Prevention of COPD. 2020</bib>): &nbsp;&nbsp;&nbsp;&nbsp;</p> <table cellspacing=0 cellpadding=0 class=displaynobordernoback><tbody><tr><td valign=top><p class=I2Tight>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p> </td> <td valign=top>Accessory respiratory muscle use &nbsp;&nbsp;&nbsp;&nbsp;</td> </tr> <tr><td valign=top><p class=I2Tight>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p> </td> <td valign=top>Cyanosis, new onset or worsening &nbsp;&nbsp;&nbsp;&nbsp;</td> </tr> <tr><td valign=top><p class=I2Tight>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p> </td> <td valign=top>Paradoxical motion of the abdomen &nbsp;&nbsp;&nbsp;&nbsp;</td> </tr> <tr><td valign=top><p class=I2Tight>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p> </td> <td valign=top>Retraction of the intercostal spaces &nbsp;&nbsp;&nbsp;&nbsp;</td> </tr> </tbody></table> <p class=tightSpacing>Short−term management goals of an exacerbation include minimizing the impact of the current exacerbation and preventing the development of subsequent occurrences. Long−term goals include improving exercise tolerance, decreasing mortality, relieving symptoms, preventing disease progression, and decreasing the number of exacerbations. Although a chest radiograph is not always helpful in establishing a diagnosis, it can be a useful tool in ruling out other conditions. Other diagnostic testing may include electrocardiogram, oxygen saturation, arterial or venous blood gas analysis, complete blood count, blood glucose, and electrolytes. During an acute exacerbation, measures of pulmonary function (e.g., FEV , spirometry) are not recommended. &nbsp;&nbsp;&nbsp;&nbsp;</p> <p class=tightSpacing>Oxygen administration may be required to treat hypoxia in an acute exacerbation. However, in COPD patients who retain carbon dioxide (CO ), oxygen administration may worsen CO retention and lead to respiratory arrest. Oxygen delivered via high flow nasal cannula (HFNC) has been found to be useful for some patients with COPD. For a small cohort of hospitalized patients, one study found that its use decreased the patient effort required to maintain adequate oxygenation determined by the measurement of respiratory rate, Pco, tidal volume, and patient comfort (<bib rel=citation title=Braunlich et al., Int J Chron Obstruct Pulmon Dis 2016, 11: 1077-85 href=/caas/citations/17826 id=17826>Braunlich et al., Int J Chron Obstruct Pulmon Dis 2016, 11: 1077-85</bib>). &nbsp;&nbsp;&nbsp;&nbsp;</p> <p class=tightSpacing>Pharmacological management of an acute exacerbation should include a systemic corticosteroid and a short−acting inhaled −agonist, with or without a short−acting anticholinergic. Therapy with intravenous methylxanthines (e.g., aminophylline or theophylline) is no longer recommended for those patients who have failed first line treatment due to severe side effects. Although the use of anti− infectives remains controversial, administration is indicated when there is an increase in dyspnea, sputum volume, sputum purulence, or if mechanical ventilation is required. If there is no response to standard COPD treatment, anti−infectives and a sputum culture and sensitivity is recommended. Additional guideline recommendations include: &nbsp;&nbsp;&nbsp;&nbsp;</p> <table cellspacing=0 cellpadding=0 class=displaynobordernoback><tbody><tr><td valign=top><p class=I2Tight>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p> </td> <td valign=top>Pulmonary rehabilitation program, initiated during the acute hospitalization if possible and provided at least 6−8 weeks in duration. &nbsp;&nbsp;&nbsp;&nbsp;</td> </tr> <tr><td valign=top><p class=I2Tight>•&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p> </td> <td valign=top>Disease management program &nbsp;&nbsp;&nbsp;&nbsp;</td> </tr> </tbody></table> <p class=tightSpacing>(<bib rel=citation title=Global Initiative for Chronic Obstructive Lung Disease (GOLD), Global Strategy for the Diagnosis, Management and Prevention of COPD. 2020 href=/caas/citations/1460287 id=1460287>Global Initiative for Chronic Obstructive Lung Disease (GOLD), Global Strategy for the Diagnosis, Management and Prevention of COPD. 2020</bib>) &nbsp;&nbsp;&nbsp;&nbsp;</p> <p class=tightSpacing><i>Many COPD patients are at high risk for readmission, and careful attention to discharge planning is essential.</i>&nbsp;&nbsp;&nbsp;&nbsp;</p><br /><p class=tightSpacing>InterQual<sup>®</sup> criteria are derived from the systematic, continuous review and critical appraisal of the most current evidence−based literature and include input from our independent panel of clinical experts. To generate the most appropriate recommendations, a comprehensive literature review of the clinical evidence was conducted. Sources searched included PubMed, AHRQ Comparative Effectiveness Reviews, National Institute for Health and Care Excellence (NICE), the Centers for Medicare and Medicaid Services (CMS), The Cochrane Library, and The Joint Commission. Other medical literature databases, medical content providers, data sources, regulatory body websites, and specialty society resources may also have been utilized. Relevant studies were assessed for risk of bias following principles described in the Cochrane Handbook. The resulting evidence was assessed for consistency, directness, precision, effect size, and publication bias. Observational trials were also evaluated for the presence of a dose−response gradient and the likely effect of plausible confounders. The majority of the content in this subset is based on a limited number of key sources (<bib rel=citation title=Global Initiative for Chronic Obstructive Lung Disease (GOLD), Global Strategy for the Diagnosis, Management and Prevention of COPD. 2020 href=/caas/citations/1460287 id=1460287>Global Initiative for Chronic Obstructive Lung Disease (GOLD), Global Strategy for the Diagnosis, Management and Prevention of COPD. 2020</bib>).&nbsp;&nbsp;&nbsp;&nbsp;</p><br /><br/> Origination date :null<br/> Release date :null'}}}};
    const userspy = spyOn(medicalReviewGraphqlServiceService, 'getMedicalReviewDataFromIQ').and.returnValue(medRes);
    component.getMedicalReviewSummaryDetails();
    expect(component.getMedicalReviewSummaryDetails).toBeTruthy();
  });

  it('should getLoggedInUserId()', () => {
    component.getLoggedInUserId();
    expect(component.getLoggedInUserId).toBeTruthy();
  });


  it('should isLoggedInUserMD()', () => {
    component.isLoggedInUserMD();
    expect(component.isLoggedInUserMD).toBeTruthy();
  });
  it('should getLoggedInUserAppRoles()', () => {
    component.getLoggedInUserAppRoles();
    expect(component.getLoggedInUserAppRoles).toBeTruthy();
  });
});

