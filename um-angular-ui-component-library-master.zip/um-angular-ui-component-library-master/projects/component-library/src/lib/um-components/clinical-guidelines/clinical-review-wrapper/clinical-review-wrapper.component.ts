import { Component, OnInit, Output, EventEmitter, Input, ViewChild } from '@angular/core';
import { MedicalReviewTreeComponent } from '../../clinical-guidelines/medical-review-tree/medical-review-tree.component';
import { GuidelineSummaryComponent } from '../../clinical-guidelines/guideline-summary/guideline-summary.component';
import { GuidelinesBedDayDecisionComponent } from '../../clinical-guidelines/guidelines-bed-day-decision/guidelines-bed-day-decision.component';
import { GuidelinesUtils } from '../shared/guidelines-utils';
import { GuidelinesConstants } from '../../../constant/guidelines-constants';
import { MicroProductAuthService } from '@ecp/auth-library';
import { MedicalReviewsComponent } from '../../clinical-guidelines/medical-reviews/medical-reviews.component';
import { MedicalReviewGraphqlServiceService } from '../../services/um/service/clinical-guidelines/medical-review-graphql-service/medical-review-graphql-service.service';
import {ReviewData} from './review-data';
import {J} from "@angular/cdk/keycodes";

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'ecp-ucl-clinical-review-wrapper',
  templateUrl: './clinical-review-wrapper.component.html',
  styleUrls: ['./clinical-review-wrapper.component.scss']
})
export class ClinicalReviewWrapperComponent implements OnInit {
  @Input() application: string;
  @Input() reviewData: ReviewData;
  @Input() reviewId: string;
  @Input() hscId: number;
 // @Input() isTransitionPlan: any;
  @ViewChild(GuidelineSummaryComponent) guidelineSummaryComponent: GuidelineSummaryComponent;
  @ViewChild(MedicalReviewTreeComponent) medicalReviewTreeComponent: MedicalReviewTreeComponent;
  @ViewChild(GuidelinesBedDayDecisionComponent) bedDayDecisionComponent: GuidelinesBedDayDecisionComponent;
  @ViewChild(MedicalReviewsComponent) medicalReviewsComponent: MedicalReviewsComponent;
  @Output() previous: EventEmitter<any> = new EventEmitter();
  @Output() next: EventEmitter<any> = new EventEmitter();
  pageOrder = 1;
  isLastPage = false;
  isFirstPage = true;
  isFooterDisplayed = 'show-footer';
  guidelineId: string;
  isTransitionPlan = false;
  isCompleteReviewFlag: boolean;
  primaryClinicalID: any;
  metStat: any;
  existingReview: any;
  newReviewData: any;
  version: string;
  reviewSummaryDesc: any;
  summaryGuidelineId: any;
  createNewReview: boolean;
  summaryVersion: any;
  completeReviewData: any;
  source: any;
  reviewStatusCode: any;
  isAutoReview: boolean = false;
  questionReq: any;

  constructor(private readonly guideLineUtils: GuidelinesUtils, private readonly microProductAuthService: MicroProductAuthService,
              private readonly medicalReviewGraphqlServiceService: MedicalReviewGraphqlServiceService) { }

  async ngOnInit(): Promise<any> {
    this.isCompleteReviewFlag = this.reviewData?.isReadOnly ? true : false;
    if(this.reviewId !== '' && this.reviewId !== undefined){
      await this.getMedicalReviewSummaryDetails();
    }
  }
  // Add function with input
  previousPage(e: any): any {
    this.pageOrder = this.pageOrder - 1;
    this.isFirstPage = this.pageOrder === 1 ? true : false;
    this.isLastPage = false;
    this.previous.next();
  }
  async nextPage(e): Promise<any> {
    console.log(e);
    if (this.reviewId !== '' && this.reviewId !== undefined) {
      this.pageOrder = 1;
      this.isFirstPage = true;
      if (this.getPageOrder() === 'MEDICAL_REVIEW_TREE') {
        await this.medicalReviewTreeComponent.saveDraft();
        this.reviewId = this.medicalReviewTreeComponent.reviewId;
        this.metStat = this.medicalReviewTreeComponent.metstat;
        this.isCompleteReviewFlag = this.reviewData?.isReadOnly ? true : false;
      }
    } else {
      await this.newReviewFlow(e);
    }
  }
  async getMedicalReviewSummaryDetails(): Promise<any> {
    const medRes = await this.medicalReviewGraphqlServiceService.getMedicalReviewDataFromIQ(this.reviewId);
    console.log('review data existing' + JSON.stringify(medRes));
    this.questionReq = medRes.data.getMedicalReviewDetails.reviewRes;
    this.guidelineId =  this.questionReq.meta.tag.filter(i => i.code === 'subset_id')[0].display;
    this.version = this.questionReq.meta.tag.filter(i => i.code === 'version_id')[0].display;
    this.source = this.questionReq.meta.tag.filter(i => i.code === 'source')[0].display;
    this.reviewStatusCode = this.questionReq.status;
    if (this.source === 'AR') {
      this.isAutoReview = true;
    }
  }

  async newReviewFlow(e): Promise<any> {
    if (this.getPageOrder() === 'SUBSET_SEARCH') {
      this.guidelineId = e.guidelineId;
      this.version = e.version;
    } else if (this.getPageOrder() === 'MEDICAL_REVIEW_TREE') {
      await this.medicalReviewTreeComponent.saveDraft();
      this.reviewId = this.medicalReviewTreeComponent.reviewUUID;
      this.primaryClinicalID = this.medicalReviewTreeComponent.primaryClinicalId;
      this.metStat = this.medicalReviewTreeComponent.metstat;
      this.newReviewData = {
        reviewId: this.reviewId,
        guidelineID: this.primaryClinicalID
      };
      this.next.emit(this.newReviewData);
    }

    this.pageOrder = this.pageOrder + 1;
    if (this.getPageOrder() === 'GUIDELINE_SUMMARY') {
      this.summaryVersion = e.version;
      this.summaryGuidelineId = e.guidelineId;
    }
    this.isFirstPage = false;

  }
  getPageOrder(){
    if (this.isLoggedInUserMD()){
      this.pageOrder = 1;
      this.isLastPage = true;
    }
    if ((this.reviewId === '' || this.reviewId === undefined)) {
      switch (this.pageOrder) {
        case 1:
          return 'SUBSET_SEARCH';
        case 2:
          return 'GUIDELINE_SUMMARY';
        case 3:
          return 'MEDICAL_REVIEW_TREE';
        default:
          return 'SUBSET_SEARCH';
      }
    } else {
      switch (this.pageOrder) {
        case 1:
          return 'MEDICAL_REVIEW_TREE';
        default:
          return 'MEDICAL_REVIEW_TREE';
      }
    }
  }

  getLoggedInUserId(): string {
    let createUserid = 'SYSTEM';
    const token = this.microProductAuthService.getEcpToken();
    const claimsObj = this.microProductAuthService.getEcpClaims();
    if (this.microProductAuthService.isLocalHost()) {
      createUserid = 'SYSTEM';
    } else if (token != null && claimsObj != null) {
      createUserid = this.microProductAuthService.getUserID();
    }
    return createUserid;
  }

  getLoggedInUserAppRoles(): string[] {
    const ecpClaims = this.microProductAuthService.getEcpClaims();
    const roles = ecpClaims?.['x-ecp-claims']?.['x-ecp-cli-orgs']?.[0]['func-roles'][0]['appl-roles'];
    return roles;
  }

  isLoggedInUserMD(): boolean {
    const roles = this.getLoggedInUserAppRoles();
    if (roles?.includes(GuidelinesConstants.CLINICAL_GUIDELINES_MD)) {
      return true;
    }
    return null;
  }

  editReview(toBeEdited): any {
    if (toBeEdited) {
      this.pageOrder = 1;
      this.isLastPage = false;
      this.isFirstPage = true;
    }
  }
}
