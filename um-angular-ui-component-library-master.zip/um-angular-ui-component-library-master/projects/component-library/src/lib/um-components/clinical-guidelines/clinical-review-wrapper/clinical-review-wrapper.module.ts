import {CUSTOM_ELEMENTS_SCHEMA, NgModule, NO_ERRORS_SCHEMA} from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { TableModule } from '@ecp/angular-ui-component-library/table';
import { SortModule } from '@ecp/angular-ui-component-library/sort';
import { TabsModule } from '@ecp/angular-ui-component-library/tabs';
import { MatGridListModule } from '@angular/material/grid-list';
import { ButtonModule } from '@ecp/angular-ui-component-library/button';
import { IconsModule } from '@ecp/angular-ui-component-library/icons';
import { MatIconModule } from '@angular/material/icon';
import { CardModule } from '@ecp/angular-ui-component-library/card';
import { PaginatorModule } from '@ecp/angular-ui-component-library/paginator';
import { HttpClientModule } from '@angular/common/http';
import { FooterModule } from '../footer/footer.module';
import { MedicalReviewTreeModule } from '../medical-review-tree/medical-review-tree.module';
import { ClinicalReviewWrapperComponent } from './clinical-review-wrapper.component';
import { SubsetSearchModule } from '../subset-search/subset-search.component.module';
import { GuidelineSummaryModule } from '../guideline-summary/guideline-summary.module';
import {GuidelinesBedDayModule} from '../guidelines-bed-day-decision/guidelines-bed-day.module';
import {MedicalReviewsModule} from '../medical-reviews/medical-reviews.module';
import {MicroProductAuthService} from '@ecp/auth-library';
// import { GuidelineSummaryModule } from '../guideline-summary/guideline-summary.module';

@NgModule({
  declarations: [
    ClinicalReviewWrapperComponent,
  ],
  imports: [
    CommonModule,
    BrowserModule,
    BrowserAnimationsModule,
    CardModule,
    MatIconModule,
    TableModule,
    ButtonModule,
    TabsModule,
    IconsModule,
    SortModule,
    HttpClientModule,
    PaginatorModule,
    FooterModule,
    MedicalReviewTreeModule,
    GuidelinesBedDayModule,
    SubsetSearchModule,
    GuidelineSummaryModule,
    MedicalReviewsModule
  ],
  exports: [
    ClinicalReviewWrapperComponent
  ],
  providers: [MicroProductAuthService],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class ClinicalReviewWrapperModule { }
