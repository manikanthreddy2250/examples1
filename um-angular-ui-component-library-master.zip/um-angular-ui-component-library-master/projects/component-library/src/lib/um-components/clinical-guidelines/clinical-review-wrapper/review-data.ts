export class ReviewData {
  isReadOnly?: any;
  isTransitionPlan?: any;
}
