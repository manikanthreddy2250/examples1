import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DocumentUtilityComponent } from './document-utility.component';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA, Injectable } from '@angular/core';

describe('DocumentUtilityComponent', () => {
  let component: DocumentUtilityComponent;
  let fixture: ComponentFixture<DocumentUtilityComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DocumentUtilityComponent ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentUtilityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it ('should call ngOnInit ', () => {
    component.ngOnInit();
    expect(component.ngOnInit).toBeTruthy();
  });
});
