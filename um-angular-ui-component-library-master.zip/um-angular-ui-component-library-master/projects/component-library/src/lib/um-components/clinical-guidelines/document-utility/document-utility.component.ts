import { Component, OnInit, Input } from '@angular/core';
import { Constants } from '../../../constant/constants';

@Component({
  selector: 'ecp-um-document-utility',
  templateUrl: './document-utility.component.html',
  styleUrls: ['./document-utility.component.scss']
})
export class DocumentUtilityComponent implements OnInit {

  @Input() hscId: any;
  showDocProcess = false;
  documentConfig: any;

  constructor() { }

  ngOnInit(): void {
    console.log('Docuemt Utility')
    this.documentConfig = {
      subjectId: '11186', //hsc ID
      subjecTypeId: Constants.SUBJECT_ID_TYPE_HSC_ID_REF_ID,
      // subjecTypeId: 20047,
      configAppName: Constants.UM_CLINICAL_GUIDELINES_APP_NAME,
      envID: 'dev'
    };
  }

}
