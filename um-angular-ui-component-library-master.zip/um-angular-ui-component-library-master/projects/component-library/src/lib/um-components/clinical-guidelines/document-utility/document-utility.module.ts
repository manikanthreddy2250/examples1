import {CUSTOM_ELEMENTS_SCHEMA, NgModule, NO_ERRORS_SCHEMA} from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { TableModule } from '@ecp/angular-ui-component-library/table';
import { SortModule } from '@ecp/angular-ui-component-library/sort';
import { TabsModule } from '@ecp/angular-ui-component-library/tabs';
import { MatGridListModule } from '@angular/material/grid-list';
import { ButtonModule } from '@ecp/angular-ui-component-library/button';
import { IconsModule } from '@ecp/angular-ui-component-library/icons';
import { MatIconModule } from '@angular/material/icon';
import { CardModule } from '@ecp/angular-ui-component-library/card';
import { PaginatorModule } from '@ecp/angular-ui-component-library/paginator';
import { HttpClientModule } from '@angular/common/http';
import { DocumentUtilityComponent } from './document-utility.component';
import {DocProcessModule} from "@ecp/common-angular-ui-component-library";
import {MatSidenavModule, MatDrawerContainer} from '@angular/material/sidenav';
import { FooterModule } from '../footer/footer.module';

@NgModule({
  declarations: [
    DocumentUtilityComponent,
  ],
  imports: [
    CommonModule,
    BrowserModule,
    BrowserAnimationsModule,
    CardModule,
    MatIconModule,
    TableModule,
    ButtonModule,
    TabsModule,
    IconsModule,
    SortModule,
    HttpClientModule,
    PaginatorModule,
    FooterModule,
    DocProcessModule,
    MatSidenavModule,

  ],
  exports: [
    DocumentUtilityComponent
  ],
  providers: [],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class DocumentUtilityModule { }
