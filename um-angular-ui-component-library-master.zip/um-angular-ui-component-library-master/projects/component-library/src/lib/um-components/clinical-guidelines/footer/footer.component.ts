import { Component, OnInit, Input, Output, EventEmitter, ChangeDetectorRef, OnChanges } from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent implements OnInit, OnChanges {

  private _initialized: boolean;
  constructor(private _changeDetectorRef: ChangeDetectorRef) { }


  @Input() isLastPage: boolean;
  @Output() previous: EventEmitter<any> = new EventEmitter()
  @Output() next: EventEmitter<any> = new EventEmitter()
  @Output() complete: EventEmitter<any> = new EventEmitter()


  //Add function for event emitter

  ngOnInit(): void {
  }

  ngOnChanges() {
    this._changeDetectorRef.detectChanges();
  }

  onPrevious() {

    console.log('Previous in footer')
    this.previous.emit(true)
  }

  onNext() {
    console.log("Next in Footer")
    this.next.emit(true);
  }

  onComplete() {
    console.log('Complete in footer')
    this.complete.emit(true)
  }

}

