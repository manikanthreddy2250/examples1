import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatIconModule } from '@angular/material/icon';
import { FooterComponent } from './footer.component';
import { ButtonModule } from '@ecp/angular-ui-component-library/button'
import { CardModule } from '@ecp/angular-ui-component-library/card';
import { PaginatorModule } from '@ecp/angular-ui-component-library/paginator';
import { IconsModule } from '@ecp/angular-ui-component-library/icons';


@NgModule({
  declarations: [
    FooterComponent
  ],
  imports: [
    CommonModule,
    BrowserModule,
    BrowserAnimationsModule,
    MatGridListModule,
    MatIconModule,
    ButtonModule,
    CardModule,
    PaginatorModule,
    IconsModule
  ],
  exports: [
    FooterComponent
  ],
  providers: []
})
export class FooterModule { }
