import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA, Injectable } from '@angular/core';
import { GuidelineSummaryComponent } from './guideline-summary.component';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { HttpClient } from '@angular/common/http';
import { GuidelineSummaryService } from '../../services/um/service/clinical-guidelines/guideline-summary/guideline-summary.service';
import { AuthService, MicroProductAuthService, AuthLibraryModule } from "@ecp/auth-library";
import { UserAuthService } from "../../services/auth/user.service";
import { of } from 'rxjs';
import { LoggerConfig, NGXLogger, NGXLoggerHttpService, NGXMapperService } from 'ngx-logger';
import { DatePipe } from '@angular/common';
import { OAuthLogger, OAuthService, UrlHelperService } from 'angular-oauth2-oidc';

@Injectable()
class MicroProductAuthServiceStub {
  getEcpClaims() {
    return {
      'x-ecp-claims': {
        'x-ecp-attrs': {},
        'x-ecp-alt-user-id': '',
        'x-ecp-cli-orgs': [{
          'org-id': 'ecp',
          'func-roles': [{
            'role-name': 'rules_admin',
            'appl-roles': ['autoapproval-dmn_deploy', 'clinical_guidelines_nurse', 'bpm_execute_all', 'case_wf_mgmt_ui_read', 'configuration-dmn_deploy', 'example_dmn_grp_deploy', 'health_srvc_delete', 'icuerules-dmn_deploy', 'memberblocking-dmn_deploy', 'obsderivation-dmn_deploy', 'programs-dmn_deploy', 'rules_authoring_write', 'siteofservice-dmn_deploy', 'system_mgmt_user', 'testharness-dmn_deploy', 'um_intake_ui_read', 'umintake_sos_mbr_elig_dmn_grp_deploy', 'umintake_sos_prov_elig_dmn_grp_deploy']
          }]
        }],
        'x-ecp-first-name': 'Sahithya',
        'x-ecp-type': 'PASSWORD',
        'x-ecp-user-id': '001173408',
        'x-ecp-email': 'sahithya_sivaraju@optum.com',
        'x-ecp-last-name': 'Pachipulusu Sivaraju',
        'x-ecp-source': 'msid'
      },
      'https://hasura.io/jwt/claims': {
        'x-hasura-default-role': 'autoapproval-dmn_deploy',
        'x-hasura-attrs': '{ }',
        'x-hasura-cli-org': 'ecp',
        'x-hasura-user-id': '001173408',
        'x-hasura-func-role': 'rules_admin',
        'x-hasura-allowed-roles': ['autoapproval-dmn_deploy', 'autorouting-dmn_deploy', 'bpm_execute_all', 'case_wf_mgmt_ui_read', 'configuration-dmn_deploy', 'example_dmn_grp_deploy', 'health_srvc_delete', 'icuerules-dmn_deploy', 'memberblocking-dmn_deploy', 'obsderivation-dmn_deploy', 'programs-dmn_deploy', 'rules_authoring_write', 'siteofservice-dmn_deploy', 'system_mgmt_user', 'testharness-dmn_deploy', 'um_intake_ui_read', 'umintake_sos_mbr_elig_dmn_grp_deploy', 'umintake_sos_prov_elig_dmn_grp_deploy']
      },
      scope: 'openid',
      iss: 'ecp-dev',
      exp: 1603473684,
      client_id: 'ecp_platform'
    };
  }

  getUserRoles() {
    return 'Provider';
  }

  getEcpOrgId() {
    return 'TESTUSERID';
  }

  getEcpToken() {
    return 'testToken';
  }

  isLocalHost() {
    return false;
  }

  getHasuraRole() {
    return 'clinical_guidelines_md';
  }
}

describe('GuidelineSummaryComponent', () => {
  let component: GuidelineSummaryComponent;
  let guidelineSummaryService: GuidelineSummaryService;
  let fixture: ComponentFixture<GuidelineSummaryComponent>;
  let httpClient: HttpClient;
  let service: UserAuthService;
  let authService: AuthService;
  let microProductAuth: MicroProductAuthService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, AuthLibraryModule],
      declarations: [GuidelineSummaryComponent],
      providers: [UserAuthService, GuidelineSummaryService, { provide: MicroProductAuthService, useClass: MicroProductAuthServiceStub }],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
    service = TestBed.inject(UserAuthService);
    authService = TestBed.inject(AuthService);
    microProductAuth = TestBed.inject(MicroProductAuthService);
    httpClient = TestBed.inject(HttpClient);
    guidelineSummaryService = TestBed.inject(GuidelineSummaryService);
  }));
  const response = {
    "data": {
      "getGuidelineReview": {
        "reviewResponse": {
          "resourceType": "Questionnaire",
          "id": 353625,
          "version": "RM20",
          "identifier": [{
            "use": "official",
            "value": 353625
          }, {
            "use": "usual",
            "value": "RC3::AISD015304"
          }],
          "name": "COPD",
          "title": "LOC:Acute Adult InterQual® 2020, Apr. 2020 Release",
          "status": "active",
          "publisher": "Change Helathcare",
          "meta": {
            "tag": [{
              "code": "product_id",
              "display": "AISD"
            }, {
              "code": "version_id",
              "display": "RM20"
            }, {
              "code": "subset_id",
              "display": "AISD0153"
            }, {
              "code": "review_type",
              "display": "NDT"
            }]
          },
          "code": [],
          "contained": [{
            "resourceType": "Questionnaire",
            "id": "AISD01530401",
            "name": "<b>Initial review</b>",
            "item": [{
              "linkId": "AISD0153040101",
              "text": "(From arrival in ED through decision to admit)",
              "type": "display",
              "repeats": false,
              "readOnly": false,
              "item": []
            }, {
              "linkId": "AISD0153040102",
              "text": "<b>OBSERVATION,</b> <b>Both:</b>",
              "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040102&note_type=ALL_NOTES",
              "type": "group",
              "repeats": true,
              "readOnly": false,
              "item": [{
                "linkId": "AISD015304010201",
                "text": "Short−acting beta−agonist administered prior to admission by licensed medical professional ≥ 2 doses",
                "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304010201&note_type=ALL_NOTES",
                "type": "boolean",
                "repeats": false,
                "readOnly": true,
                "item": []
              }, {
                "linkId": "AISD015304010202",
                "text": "Post treatment finding, <b>≥ One:</b>",
                "type": "group",
                "repeats": true,
                "readOnly": false,
                "item": [{
                  "linkId": "AISD01530401020201",
                  "text": "O<sub>2 </sub>sat 90−91%(0.90−0.91) and &lt;&nbsp;baseline",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530401020201&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530401020202",
                  "text": "Arterial Po<sub>2</sub> 56−60&nbsp;mmHg(7.4−8.0&nbsp;kPa) and &lt; baseline",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530401020202&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530401020203",
                  "text": "Arterial or venous Pco<sub>2</sub> 41−44&nbsp;mmHg(5.5−5.9&nbsp;kPa) and &gt; baseline",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530401020203&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530401020204",
                  "text": "Increased work of breathing, <b>≥ One:</b>",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530401020204&note_type=ALL_NOTES",
                  "type": "group",
                  "repeats": true,
                  "readOnly": false,
                  "item": [{
                    "linkId": "AISD0153040102020401",
                    "text": "Difficulty taking PO",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040102020402",
                    "text": "Prefers sitting",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040102020402&note_type=ALL_NOTES",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040102020403",
                    "text": "Talks in phrases",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }]
                }]
              }]
            }, {
              "linkId": "AISD0153040103",
              "text": "<b>ACUTE,</b> <b>Both:</b>",
              "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040103&note_type=ALL_NOTES",
              "type": "group",
              "repeats": true,
              "readOnly": false,
              "item": [{
                "linkId": "AISD015304010301",
                "text": "Short−acting beta−agonist administered prior to admission by licensed medical professional ≥ 2 doses",
                "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304010301&note_type=ALL_NOTES",
                "type": "boolean",
                "repeats": false,
                "readOnly": true,
                "item": []
              }, {
                "linkId": "AISD015304010302",
                "text": "Post treatment finding, <b>≥ One:</b>",
                "type": "group",
                "repeats": true,
                "readOnly": false,
                "item": [{
                  "linkId": "AISD01530401030201",
                  "text": "O<sub>2 </sub>sat ≤&nbsp;89%(0.89) and &lt; baseline",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530401030201&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530401030202",
                  "text": "Arterial Po<sub>2</sub> 40−55 mmHg(5.3−7.3 kPa) and pH 7.45−7.49",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530401030202&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530401030203",
                  "text": "Arterial or venous Pco<sub>2</sub> 45−54 mmHg(6.0−7.2 kPa) and pH 7.31−7.35",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530401030203&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530401030204",
                  "text": "Increased work of breathing, <b>≥ One:</b>",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530401030204&note_type=ALL_NOTES",
                  "type": "group",
                  "repeats": true,
                  "readOnly": false,
                  "item": [{
                    "linkId": "AISD0153040103020401",
                    "text": "Unable to take PO",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040103020402",
                    "text": "Hunched over position",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040103020403",
                    "text": "Talks in words",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040103020404",
                    "text": "Use of accessory respiratory muscles",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }]
                }, {
                  "linkId": "AISD01530401030205",
                  "text": "High risk for adverse event, <b>Both:</b>",
                  "type": "group",
                  "repeats": true,
                  "readOnly": false,
                  "item": [{
                    "linkId": "AISD0153040103020501",
                    "text": "Post treatment finding, <b>≥ One:</b>",
                    "type": "group",
                    "repeats": true,
                    "readOnly": false,
                    "item": [{
                      "linkId": "AISD015304010302050101",
                      "text": "O<sub>2 </sub>sat 90−91%(0.90−0.91) and &lt;&nbsp;baseline",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304010302050101&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304010302050102",
                      "text": "Arterial Po<sub>2</sub> 56−60&nbsp;mmHg(7.4−8.0&nbsp;kPa) and &lt; baseline",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304010302050102&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304010302050103",
                      "text": "Arterial or venous Pco<sub>2</sub> 41−44&nbsp;mmHg(5.5−5.9&nbsp;kPa) and &gt; baseline",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304010302050103&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304010302050104",
                      "text": "Increased work of breathing, <b>≥ One:</b>",
                      "type": "group",
                      "repeats": true,
                      "readOnly": false,
                      "item": [{
                        "linkId": "AISD01530401030205010401",
                        "text": "Difficulty taking PO",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }, {
                        "linkId": "AISD01530401030205010402",
                        "text": "Prefers sitting",
                        "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530401030205010402&note_type=ALL_NOTES",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }, {
                        "linkId": "AISD01530401030205010403",
                        "text": "Talks in phrases",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }]
                    }]
                  }, {
                    "linkId": "AISD0153040103020502",
                    "text": "Clinical risk factor, <b>≥ One:</b>",
                    "type": "group",
                    "repeats": true,
                    "readOnly": false,
                    "item": [{
                      "linkId": "AISD015304010302050201",
                      "text": "Age ≥&nbsp;65&nbsp;yrs and, <b>≥ One:</b>",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304010302050201&note_type=ALL_NOTES",
                      "type": "group",
                      "repeats": true,
                      "readOnly": true,
                      "item": [{
                        "linkId": "AISD01530401030205020101",
                        "text": "Blood urea nitrogen (BUN) &gt;&nbsp;25.0&nbsp;mg/dL(8.9&nbsp;mmol/L)",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }, {
                        "linkId": "AISD01530401030205020102",
                        "text": "Heart rate ≥&nbsp;110/min, sustained",
                        "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530401030205020102&note_type=ALL_NOTES",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }, {
                        "linkId": "AISD01530401030205020103",
                        "text": "Mental status changes (excludes coma, stupor, or obtundation) or GCS 9−14",
                        "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530401030205020103&note_type=ALL_NOTES",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }]
                    }, {
                      "linkId": "AISD015304010302050202",
                      "text": "Post−bronchodilator FEV<sub>1</sub> &lt;&nbsp;50%(0.50) predicted",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304010302050202&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304010302050203",
                      "text": "Home oxygen therapy ≥&nbsp;15&nbsp;h/24h",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304010302050203&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304010302050204",
                      "text": "Prior endotracheal intubation for respiratory distress within last 12&nbsp;mos",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304010302050204&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304010302050205",
                      "text": "Cor pulmonale",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304010302050205&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304010302050206",
                      "text": "Diabetes mellitus and blood sugar&nbsp;&gt;&nbsp;300&nbsp;mg/dL(16.7&nbsp;mmol/L)",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304010302050206&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304010302050207",
                      "text": "Heart failure, NYHA Class III or Class IV",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304010302050207&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304010302050208",
                      "text": "Cancer of lung, upper gastrointestinal tract, or metastatic cancer",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304010302050208&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304010302050209",
                      "text": "Pneumonia actual or suspected and, <b>≥ One:</b>",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304010302050209&note_type=ALL_NOTES",
                      "type": "group",
                      "repeats": true,
                      "readOnly": true,
                      "item": [{
                        "linkId": "AISD01530401030205020901",
                        "text": "Temperature, <b>≥ One:</b>",
                        "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530401030205020901&note_type=ALL_NOTES",
                        "type": "group",
                        "repeats": true,
                        "readOnly": false,
                        "item": [{
                          "linkId": "AISD0153040103020502090101",
                          "text": "&gt;&nbsp;99.4°F(37.4°C) PO",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        }, {
                          "linkId": "AISD0153040103020502090102",
                          "text": "&gt; 100.4°F(38.0°C) PR",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        }]
                      }, {
                        "linkId": "AISD01530401030205020902",
                        "text": "WBC ≥&nbsp;12,000/cu.mm(12x10<sup>9</sup>/L)",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }, {
                        "linkId": "AISD01530401030205020903",
                        "text": "WBC ≤&nbsp;4,000/cu.mm(4 x10<sup>9</sup>/L)",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }, {
                        "linkId": "AISD01530401030205020904",
                        "text": "Bands &gt;&nbsp;10%(0.10)",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }]
                    }, {
                      "linkId": "AISD015304010302050210",
                      "text": "Severe and persistent mental illness, cognitive impairment, or substance use disorder and, <b>Both:</b>",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304010302050210&note_type=ALL_NOTES",
                      "type": "group",
                      "repeats": true,
                      "readOnly": true,
                      "item": [{
                        "linkId": "AISD01530401030205021001",
                        "text": "Patient unreliable and unable to adhere to outpatient instructions or treatment",
                        "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530401030205021001&note_type=ALL_NOTES",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }, {
                        "linkId": "AISD01530401030205021002",
                        "text": "Caregiver unavailable or unable to manage care",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }]
                    }, {
                      "linkId": "AISD015304010302050211",
                      "text": "Stable angina, Class III or IV",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304010302050211&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }]
                  }]
                }]
              }]
            }, {
              "linkId": "AISD0153040104",
              "text": "<b>INTERMEDIATE,</b> <b>All:</b>",
              "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040104&note_type=ALL_NOTES",
              "type": "group",
              "repeats": true,
              "readOnly": false,
              "item": [{
                "linkId": "AISD015304010401",
                "text": "Short−acting beta−agonist administered prior to admission by licensed medical professional ≥ 2 doses",
                "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304010401&note_type=ALL_NOTES",
                "type": "boolean",
                "repeats": false,
                "readOnly": true,
                "item": []
              }, {
                "linkId": "AISD015304010402",
                "text": "Post treatment finding, <b>≥ One:</b>",
                "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304010402&note_type=ALL_NOTES",
                "type": "group",
                "repeats": true,
                "readOnly": false,
                "item": [{
                  "linkId": "AISD01530401040201",
                  "text": "Arterial Po<sub>2</sub> 40−55 mmHg(5.3−7.3 kPa) and pH 7.50−7.55",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530401040201&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530401040202",
                  "text": "Arterial or venous Pco<sub>2</sub> 55−59&nbsp;mmHg(7.3−7.9&nbsp;kPa) and pH 7.25−7.30",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530401040202&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530401040203",
                  "text": "Cyanosis, new onset or worsening",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530401040203&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530401040204",
                  "text": "Paradoxical chest wall motion",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530401040205",
                  "text": "O<sub>2 </sub> sat, <b>One:</b>",
                  "type": "group",
                  "repeats": true,
                  "readOnly": false,
                  "item": [{
                    "linkId": "AISD0153040104020501",
                    "text": "&lt; 89%(0.89) and &lt; baseline",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040104020501&note_type=ALL_NOTES",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040104020502",
                    "text": "Room air assessment not clinically appropriate",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040104020502&note_type=ALL_NOTES",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }]
                }]
              }, {
                "linkId": "AISD015304010403",
                "text": "Intervention, <b>≥ One:</b>",
                "type": "group",
                "repeats": true,
                "readOnly": false,
                "item": [{
                  "linkId": "AISD01530401040301",
                  "text": "Oxygen ≥&nbsp;40%(0.40)",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530401040301&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530401040302",
                  "text": "NIPPV",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530401040302&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }]
              }]
            }, {
              "linkId": "AISD0153040105",
              "text": "<b>CRITICAL,</b> <b>≥ One:</b>",
              "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040105&note_type=ALL_NOTES",
              "type": "group",
              "repeats": true,
              "readOnly": false,
              "item": [{
                "linkId": "AISD015304010501",
                "text": "Respiratory failure, <b>≥ One:</b>",
                "type": "group",
                "repeats": true,
                "readOnly": false,
                "item": [{
                  "linkId": "AISD01530401050101",
                  "text": "Arterial Po<sub>2</sub> ≤&nbsp;39 mmHg(5.2 kPa)",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530401050101&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530401050102",
                  "text": "Arterial or venous Pco<sub>2</sub> ≥ 60 mmHg(8.0 kPa) and pH&nbsp;≤&nbsp;7.24",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530401050102&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530401050103",
                  "text": "Arterial or venous pH&nbsp;≤&nbsp;7.24",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530401050103&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530401050104",
                  "text": "Coma, stupor, obtundation, or GCS ≤ 8",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }]
              }, {
                "linkId": "AISD015304010502",
                "text": "Hemodynamic instability, <b>Both:</b>",
                "type": "group",
                "repeats": true,
                "readOnly": false,
                "item": [{
                  "linkId": "AISD01530401050201",
                  "text": "Finding, <b>≥ One:</b>",
                  "type": "group",
                  "repeats": true,
                  "readOnly": false,
                  "item": [{
                    "linkId": "AISD0153040105020101",
                    "text": "Heart rate &gt;&nbsp;120/min, sustained",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040105020101&note_type=ALL_NOTES",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040105020102",
                    "text": "Systolic blood pressure, <b>≥ One:</b>",
                    "type": "group",
                    "repeats": true,
                    "readOnly": false,
                    "item": [{
                      "linkId": "AISD015304010502010201",
                      "text": "&lt; 90 mmHg",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304010502010202",
                      "text": "&lt; 110 mmHg with chronic hypertension",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304010502010203",
                      "text": "&gt; 30 mmHg decrease from baseline",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304010502010203&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304010502010204",
                      "text": "Labile",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304010502010204&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }]
                  }, {
                    "linkId": "AISD0153040105020103",
                    "text": "MAP &lt;&nbsp;65&nbsp;mmHg",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }]
                }, {
                  "linkId": "AISD01530401050202",
                  "text": "IV fluid resuscitation ≤ 2d",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530401050202&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }]
              }, {
                "linkId": "AISD015304010503",
                "text": "Mechanical ventilation",
                "type": "boolean",
                "repeats": false,
                "readOnly": true,
                "item": []
              }, {
                "linkId": "AISD015304010504",
                "text": "Vasopressor, vasodilator, or inotrope, continuous (excludes low or fixed dose for end stage heart failure)",
                "type": "boolean",
                "repeats": false,
                "readOnly": true,
                "item": []
              }]
            }]
          }, {
            "resourceType": "Questionnaire",
            "id": "AISD01530402",
            "name": "<b>Episode Day 1</b>",
            "item": [{
              "linkId": "AISD0153040201",
              "text": "<b>OBSERVATION,</b> <b>All:</b>",
              "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040201&note_type=ALL_NOTES",
              "type": "group",
              "repeats": true,
              "readOnly": false,
              "item": [{
                "linkId": "AISD015304020101",
                "text": "Short−acting beta−agonist administered prior to admission by licensed medical professional ≥ 2 doses",
                "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304020101&note_type=ALL_NOTES",
                "type": "boolean",
                "repeats": false,
                "readOnly": true,
                "item": []
              }, {
                "linkId": "AISD015304020102",
                "text": "Post treatment finding, <b>≥ One:</b>",
                "type": "group",
                "repeats": true,
                "readOnly": false,
                "item": [{
                  "linkId": "AISD01530402010201",
                  "text": "O<sub>2 </sub>sat 90−91%(0.90−0.91) and &lt;&nbsp;baseline",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530402010201&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530402010202",
                  "text": "Arterial Po<sub>2</sub> 56−60&nbsp;mmHg(7.4−8.0&nbsp;kPa) and &lt; baseline",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530402010202&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530402010203",
                  "text": "Arterial or venous Pco<sub>2</sub> 41−44&nbsp;mmHg(5.5−5.9&nbsp;kPa) and &gt; baseline",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530402010203&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530402010204",
                  "text": "Increased work of breathing, <b>≥ One:</b>",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530402010204&note_type=ALL_NOTES",
                  "type": "group",
                  "repeats": true,
                  "readOnly": false,
                  "item": [{
                    "linkId": "AISD0153040201020401",
                    "text": "Difficulty taking PO",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040201020402",
                    "text": "Prefers sitting",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040201020402&note_type=ALL_NOTES",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040201020403",
                    "text": "Talks in phrases",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }]
                }]
              }, {
                "linkId": "AISD015304020103",
                "text": "Intervention, <b>Both:</b>",
                "type": "group",
                "repeats": true,
                "readOnly": false,
                "item": [{
                  "linkId": "AISD01530402010301",
                  "text": "Bronchodilator ≥&nbsp;4x/24h (includes inhaled)",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530402010301&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530402010302",
                  "text": "Corticosteroid (includes PO or inhaled)",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530402010302&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }]
              }]
            }, {
              "linkId": "AISD0153040202",
              "text": "<b>ACUTE,</b> <b>All:</b>",
              "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040202&note_type=ALL_NOTES",
              "type": "group",
              "repeats": true,
              "readOnly": false,
              "item": [{
                "linkId": "AISD015304020201",
                "text": "Short−acting beta−agonist administered prior to admission by licensed medical professional ≥ 2 doses",
                "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304020201&note_type=ALL_NOTES",
                "type": "boolean",
                "repeats": false,
                "readOnly": true,
                "item": []
              }, {
                "linkId": "AISD015304020202",
                "text": "Post treatment finding, <b>≥ One:</b>",
                "type": "group",
                "repeats": true,
                "readOnly": false,
                "item": [{
                  "linkId": "AISD01530402020201",
                  "text": "O<sub>2 </sub>sat ≤&nbsp;89%(0.89) and &lt; baseline",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530402020201&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530402020202",
                  "text": "Arterial Po<sub>2</sub> 40−55 mmHg(5.3−7.3 kPa) and pH 7.45−7.49",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530402020202&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530402020203",
                  "text": "Arterial or venous Pco<sub>2</sub> 45−54 mmHg(6.0−7.2 kPa) and pH 7.31−7.35",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530402020203&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530402020204",
                  "text": "Increased work of breathing, <b>≥ One:</b>",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530402020204&note_type=ALL_NOTES",
                  "type": "group",
                  "repeats": true,
                  "readOnly": false,
                  "item": [{
                    "linkId": "AISD0153040202020401",
                    "text": "Unable to take PO",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040202020402",
                    "text": "Hunched over position",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040202020403",
                    "text": "Talks in words",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040202020404",
                    "text": "Use of accessory respiratory muscles",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }]
                }, {
                  "linkId": "AISD01530402020205",
                  "text": "High risk for adverse event, <b>Both:</b>",
                  "type": "group",
                  "repeats": true,
                  "readOnly": false,
                  "item": [{
                    "linkId": "AISD0153040202020501",
                    "text": "Post treatment finding, <b>≥ One:</b>",
                    "type": "group",
                    "repeats": true,
                    "readOnly": false,
                    "item": [{
                      "linkId": "AISD015304020202050101",
                      "text": "O<sub>2 </sub>sat 90−91%(0.90−0.91) and &lt;&nbsp;baseline",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304020202050101&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304020202050102",
                      "text": "Arterial Po<sub>2</sub> 56−60&nbsp;mmHg(7.4−8.0&nbsp;kPa) and &lt; baseline",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304020202050102&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304020202050103",
                      "text": "Arterial or venous Pco<sub>2</sub> 41−44&nbsp;mmHg(5.5−5.9&nbsp;kPa) and &gt; baseline",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304020202050103&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304020202050104",
                      "text": "Increased work of breathing, <b>≥ One:</b>",
                      "type": "group",
                      "repeats": true,
                      "readOnly": false,
                      "item": [{
                        "linkId": "AISD01530402020205010401",
                        "text": "Difficulty taking PO",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }, {
                        "linkId": "AISD01530402020205010402",
                        "text": "Prefers sitting",
                        "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530402020205010402&note_type=ALL_NOTES",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }, {
                        "linkId": "AISD01530402020205010403",
                        "text": "Talks in phrases",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }]
                    }]
                  }, {
                    "linkId": "AISD0153040202020502",
                    "text": "Clinical risk factor, <b>≥ One:</b>",
                    "type": "group",
                    "repeats": true,
                    "readOnly": false,
                    "item": [{
                      "linkId": "AISD015304020202050201",
                      "text": "Age ≥&nbsp;65&nbsp;yrs and, <b>≥ One:</b>",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304020202050201&note_type=ALL_NOTES",
                      "type": "group",
                      "repeats": true,
                      "readOnly": true,
                      "item": [{
                        "linkId": "AISD01530402020205020101",
                        "text": "Blood urea nitrogen (BUN) &gt;&nbsp;25.0&nbsp;mg/dL(8.9&nbsp;mmol/L)",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }, {
                        "linkId": "AISD01530402020205020102",
                        "text": "Heart rate ≥&nbsp;110/min, sustained",
                        "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530402020205020102&note_type=ALL_NOTES",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }, {
                        "linkId": "AISD01530402020205020103",
                        "text": "Mental status changes (excludes coma, stupor, or obtundation) or GCS 9−14",
                        "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530402020205020103&note_type=ALL_NOTES",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }]
                    }, {
                      "linkId": "AISD015304020202050202",
                      "text": "Post−bronchodilator FEV<sub>1</sub> &lt;&nbsp;50%(0.50) predicted",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304020202050202&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304020202050203",
                      "text": "Home oxygen therapy ≥&nbsp;15&nbsp;h/24h",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304020202050203&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304020202050204",
                      "text": "Prior endotracheal intubation for respiratory distress within last 12&nbsp;mos",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304020202050204&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304020202050205",
                      "text": "Cor pulmonale",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304020202050205&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304020202050206",
                      "text": "Diabetes mellitus and blood sugar&nbsp;&gt;&nbsp;300&nbsp;mg/dL(16.7&nbsp;mmol/L)",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304020202050206&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304020202050207",
                      "text": "Heart failure, NYHA Class III or Class IV",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304020202050207&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304020202050208",
                      "text": "Cancer of lung, upper gastrointestinal tract, or metastatic cancer",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304020202050208&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304020202050209",
                      "text": "Pneumonia actual or suspected and, <b>≥ One:</b>",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304020202050209&note_type=ALL_NOTES",
                      "type": "group",
                      "repeats": true,
                      "readOnly": true,
                      "item": [{
                        "linkId": "AISD01530402020205020901",
                        "text": "Temperature, <b>≥ One:</b>",
                        "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530402020205020901&note_type=ALL_NOTES",
                        "type": "group",
                        "repeats": true,
                        "readOnly": false,
                        "item": [{
                          "linkId": "AISD0153040202020502090101",
                          "text": "&gt;&nbsp;99.4°F(37.4°C) PO",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        }, {
                          "linkId": "AISD0153040202020502090102",
                          "text": "&gt; 100.4°F(38.0°C) PR",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        }]
                      }, {
                        "linkId": "AISD01530402020205020902",
                        "text": "WBC ≥&nbsp;12,000/cu.mm(12x10<sup>9</sup>/L)",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }, {
                        "linkId": "AISD01530402020205020903",
                        "text": "WBC ≤&nbsp;4,000/cu.mm(4 x10<sup>9</sup>/L)",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }, {
                        "linkId": "AISD01530402020205020904",
                        "text": "Bands &gt;&nbsp;10%(0.10)",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }]
                    }, {
                      "linkId": "AISD015304020202050210",
                      "text": "Severe and persistent mental illness, cognitive impairment, or substance use disorder and, <b>Both:</b>",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304020202050210&note_type=ALL_NOTES",
                      "type": "group",
                      "repeats": true,
                      "readOnly": true,
                      "item": [{
                        "linkId": "AISD01530402020205021001",
                        "text": "Patient unreliable and unable to adhere to outpatient instructions or treatment",
                        "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530402020205021001&note_type=ALL_NOTES",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }, {
                        "linkId": "AISD01530402020205021002",
                        "text": "Caregiver unavailable or unable to manage care",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }]
                    }, {
                      "linkId": "AISD015304020202050211",
                      "text": "Stable angina, Class III or IV",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304020202050211&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }]
                  }]
                }]
              }, {
                "linkId": "AISD015304020203",
                "text": "Intervention, <b>Both:</b>",
                "type": "group",
                "repeats": true,
                "readOnly": false,
                "item": [{
                  "linkId": "AISD01530402020301",
                  "text": "Bronchodilator ≥&nbsp;4x/24h (includes inhaled)",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530402020301&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530402020302",
                  "text": "Corticosteroid (includes PO or inhaled)",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530402020302&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }]
              }]
            }, {
              "linkId": "AISD0153040203",
              "text": "<b>INTERMEDIATE,</b> <b>All:</b>",
              "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040203&note_type=ALL_NOTES",
              "type": "group",
              "repeats": true,
              "readOnly": false,
              "item": [{
                "linkId": "AISD015304020301",
                "text": "Short−acting beta−agonist administered prior to admission by licensed medical professional ≥ 2 doses",
                "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304020301&note_type=ALL_NOTES",
                "type": "boolean",
                "repeats": false,
                "readOnly": true,
                "item": []
              }, {
                "linkId": "AISD015304020302",
                "text": "Post treatment finding, <b>≥ One:</b>",
                "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304020302&note_type=ALL_NOTES",
                "type": "group",
                "repeats": true,
                "readOnly": false,
                "item": [{
                  "linkId": "AISD01530402030201",
                  "text": "Arterial Po<sub>2</sub> 40−55 mmHg(5.3−7.3 kPa) and pH 7.50−7.55",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530402030201&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530402030202",
                  "text": "Arterial or venous Pco<sub>2</sub> 55−59&nbsp;mmHg(7.3−7.9&nbsp;kPa) and pH 7.25−7.30",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530402030202&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530402030203",
                  "text": "Cyanosis, new onset or worsening",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530402030203&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530402030204",
                  "text": "Paradoxical chest wall motion",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530402030205",
                  "text": "O<sub>2 </sub> sat, <b>One:</b>",
                  "type": "group",
                  "repeats": true,
                  "readOnly": false,
                  "item": [{
                    "linkId": "AISD0153040203020501",
                    "text": "&lt; 89%(0.89) and &lt; baseline",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040203020501&note_type=ALL_NOTES",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040203020502",
                    "text": "Room air assessment not clinically appropriate",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040203020502&note_type=ALL_NOTES",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }]
                }]
              }, {
                "linkId": "AISD015304020303",
                "text": "Intervention, <b>All:</b>",
                "type": "group",
                "repeats": true,
                "readOnly": false,
                "item": [{
                  "linkId": "AISD01530402030301",
                  "text": "Bronchodilator ≥&nbsp;4x/24h (includes inhaled)",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530402030301&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530402030302",
                  "text": "Corticosteroid (includes PO or inhaled)",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530402030302&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530402030303",
                  "text": "Oxygenation, <b>≥ One:</b>",
                  "type": "group",
                  "repeats": true,
                  "readOnly": false,
                  "item": [{
                    "linkId": "AISD0153040203030301",
                    "text": "Oxygen ≥&nbsp;40%(0.40)",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040203030301&note_type=ALL_NOTES",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040203030302",
                    "text": "NIPPV",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040203030302&note_type=ALL_NOTES",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }]
                }]
              }]
            }, {
              "linkId": "AISD0153040204",
              "text": "<b>CRITICAL,</b> <b>≥ One:</b>",
              "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040204&note_type=ALL_NOTES",
              "type": "group",
              "repeats": true,
              "readOnly": false,
              "item": [{
                "linkId": "AISD015304020401",
                "text": "Respiratory failure, <b>Both:</b>",
                "type": "group",
                "repeats": true,
                "readOnly": false,
                "item": [{
                  "linkId": "AISD01530402040101",
                  "text": "Finding, <b>≥ One:</b>",
                  "type": "group",
                  "repeats": true,
                  "readOnly": false,
                  "item": [{
                    "linkId": "AISD0153040204010101",
                    "text": "Arterial Po<sub>2</sub> ≤&nbsp;39 mmHg(5.2 kPa)",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040204010101&note_type=ALL_NOTES",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040204010102",
                    "text": "Arterial or venous Pco<sub>2</sub> ≥ 60 mmHg(8.0 kPa) and pH&nbsp;≤&nbsp;7.24",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040204010102&note_type=ALL_NOTES",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040204010103",
                    "text": "Arterial or venous pH&nbsp;≤&nbsp;7.24",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040204010103&note_type=ALL_NOTES",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040204010104",
                    "text": "Coma, stupor, obtundation, or GCS ≤ 8",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }]
                }, {
                  "linkId": "AISD01530402040102",
                  "text": "Intervention, <b>≥ One:</b>",
                  "type": "group",
                  "repeats": true,
                  "readOnly": false,
                  "item": [{
                    "linkId": "AISD0153040204010201",
                    "text": "Bronchodilator every 1−2h (includes inhaled)",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040204010201&note_type=ALL_NOTES",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040204010202",
                    "text": "NIPPV",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040204010202&note_type=ALL_NOTES",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }]
                }]
              }, {
                "linkId": "AISD015304020402",
                "text": "Hemodynamic instability, <b>Both:</b>",
                "type": "group",
                "repeats": true,
                "readOnly": false,
                "item": [{
                  "linkId": "AISD01530402040201",
                  "text": "Finding, <b>≥ One:</b>",
                  "type": "group",
                  "repeats": true,
                  "readOnly": false,
                  "item": [{
                    "linkId": "AISD0153040204020101",
                    "text": "Heart rate &gt;&nbsp;120/min, sustained",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040204020101&note_type=ALL_NOTES",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040204020102",
                    "text": "Systolic blood pressure, <b>≥ One:</b>",
                    "type": "group",
                    "repeats": true,
                    "readOnly": false,
                    "item": [{
                      "linkId": "AISD015304020402010201",
                      "text": "&lt; 90 mmHg",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304020402010202",
                      "text": "&lt; 110 mmHg with chronic hypertension",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304020402010203",
                      "text": "&gt; 30 mmHg decrease from baseline",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304020402010203&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304020402010204",
                      "text": "Labile",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304020402010204&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }]
                  }, {
                    "linkId": "AISD0153040204020103",
                    "text": "MAP &lt;&nbsp;65&nbsp;mmHg",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }]
                }, {
                  "linkId": "AISD01530402040202",
                  "text": "IV fluid resuscitation ≤ 2d",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530402040202&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }]
              }, {
                "linkId": "AISD015304020403",
                "text": "Hemodynamic monitoring, invasive",
                "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304020403&note_type=ALL_NOTES",
                "type": "boolean",
                "repeats": false,
                "readOnly": true,
                "item": []
              }, {
                "linkId": "AISD015304020404",
                "text": "Mechanical ventilation and respiratory interventions every 1−2h",
                "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304020404&note_type=ALL_NOTES",
                "type": "boolean",
                "repeats": false,
                "readOnly": true,
                "item": []
              }, {
                "linkId": "AISD015304020405",
                "text": "Vasopressor, vasodilator, or inotrope, continuous (excludes low or fixed dose for end stage heart failure)",
                "type": "boolean",
                "repeats": false,
                "readOnly": true,
                "item": []
              }]
            }]
          }, {
            "resourceType": "Questionnaire",
            "id": "AISD01530403",
            "name": "<b>Episode Day 2</b>",
            "item": [{
              "linkId": "AISD0153040301",
              "text": "<b>OBSERVATION,</b> <b>One:</b>",
              "type": "group",
              "repeats": true,
              "readOnly": false,
              "item": [{
                "linkId": "AISD015304030101",
                "text": "<b>Responder</b>, discharge expected today if clinically stable last 12h, <b>Both:</b>",
                "type": "group",
                "repeats": true,
                "readOnly": false,
                "item": [{
                  "linkId": "AISD01530403010101",
                  "text": "Oxygenation, <b>≥ One:</b>",
                  "type": "group",
                  "repeats": true,
                  "readOnly": false,
                  "item": [{
                    "linkId": "AISD0153040301010101",
                    "text": "O<sub>2 </sub>sat ≥&nbsp;92%(0.92) or within acceptable limits",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040301010101&note_type=ALL_NOTES",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040301010102",
                    "text": "No change in oxygen requirements last 24h",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }]
                }, {
                  "linkId": "AISD01530403010102",
                  "text": "Dyspnea improving",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }]
              }, {
                "linkId": "AISD015304030102",
                "text": "<b>Partial responder</b>, not clinically stable for discharge and requires continued stay, <b>Both:</b>",
                "type": "group",
                "repeats": true,
                "readOnly": false,
                "item": [{
                  "linkId": "AISD01530403010201",
                  "text": "Persistent dyspnea and, <b>≥ One:</b>",
                  "type": "group",
                  "repeats": true,
                  "readOnly": true,
                  "item": [{
                    "linkId": "AISD0153040301020101",
                    "text": "Arterial Po<sub>2</sub> &lt; baseline",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040301020101&note_type=ALL_NOTES",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040301020102",
                    "text": "Arterial or venous Pco<sub>2 </sub>&gt; baseline",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040301020102&note_type=ALL_NOTES",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040301020103",
                    "text": "O<sub>2 </sub>sat ≤&nbsp;91%(0.91) and &lt; baseline",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040301020103&note_type=ALL_NOTES",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040301020104",
                    "text": "Increased work of breathing, <b>≥ One:</b>",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040301020104&note_type=ALL_NOTES",
                    "type": "group",
                    "repeats": true,
                    "readOnly": false,
                    "item": [{
                      "linkId": "AISD015304030102010401",
                      "text": "Difficulty taking PO",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304030102010402",
                      "text": "Prefers sitting",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304030102010402&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304030102010403",
                      "text": "Talks in phrases",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }]
                  }]
                }, {
                  "linkId": "AISD01530403010202",
                  "text": "Intervention, <b>Both:</b>",
                  "type": "group",
                  "repeats": true,
                  "readOnly": false,
                  "item": [{
                    "linkId": "AISD0153040301020201",
                    "text": "Bronchodilator ≥&nbsp;4x/24h (includes inhaled)",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040301020201&note_type=ALL_NOTES",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040301020202",
                    "text": "Corticosteroid (includes PO or inhaled)",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040301020202&note_type=ALL_NOTES",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }]
                }]
              }]
            }, {
              "linkId": "AISD0153040302",
              "text": "<b>ACUTE,</b> <b>One:</b>",
              "type": "group",
              "repeats": true,
              "readOnly": false,
              "item": [{
                "linkId": "AISD015304030201",
                "text": "<b>Early responder,</b> discharge expected today if clinically stable last 12h, <b>All:</b>",
                "type": "group",
                "repeats": true,
                "readOnly": false,
                "item": [{
                  "linkId": "AISD01530403020101",
                  "text": "Afebrile",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530403020101&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530403020102",
                  "text": "Oxygenation, <b>≥ One:</b>",
                  "type": "group",
                  "repeats": true,
                  "readOnly": false,
                  "item": [{
                    "linkId": "AISD0153040302010201",
                    "text": "O<sub>2 </sub>sat ≥&nbsp;92%(0.92) or within acceptable limits",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040302010201&note_type=ALL_NOTES",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040302010202",
                    "text": "No change in oxygen requirements last 2d",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }]
                }, {
                  "linkId": "AISD01530403020103",
                  "text": "Dyspnea improving",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530403020104",
                  "text": "No complication or active comorbidity relevant to this episode of care",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530403020104&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }]
              }, {
                "linkId": "AISD015304030202",
                "text": "<b>Partial Responder</b>, not clinically stable for discharge and requires continued stay, <b>≥ One:</b>",
                "type": "group",
                "repeats": true,
                "readOnly": false,
                "item": [{
                  "linkId": "AISD01530403020201",
                  "text": "Pulmonary embolism (<b>use Pulmonary Embolism subset</b>)",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530403020202",
                  "text": "COPD exacerbation unresolved and, <b>Both:</b>",
                  "type": "group",
                  "repeats": true,
                  "readOnly": false,
                  "item": [{
                    "linkId": "AISD0153040302020201",
                    "text": "Persistent dyspnea, <b>≥ One:</b>",
                    "type": "group",
                    "repeats": true,
                    "readOnly": false,
                    "item": [{
                      "linkId": "AISD015304030202020101",
                      "text": "Arterial Po<sub>2</sub> &lt; baseline",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304030202020101&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304030202020102",
                      "text": "Arterial or venous Pco<sub>2 </sub>&gt; baseline",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304030202020102&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304030202020103",
                      "text": "O<sub>2 </sub>sat ≤&nbsp;91%(0.91) and &lt; baseline",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304030202020103&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304030202020104",
                      "text": "Increased work of breathing, <b>≥ One:</b>",
                      "type": "group",
                      "repeats": true,
                      "readOnly": false,
                      "item": [{
                        "linkId": "AISD01530403020202010401",
                        "text": "Difficulty taking PO",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }, {
                        "linkId": "AISD01530403020202010402",
                        "text": "Prefers sitting",
                        "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530403020202010402&note_type=ALL_NOTES",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }, {
                        "linkId": "AISD01530403020202010403",
                        "text": "Talks in phrases",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }, {
                        "linkId": "AISD01530403020202010404",
                        "text": "Use of accessory muscles",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }]
                    }]
                  }, {
                    "linkId": "AISD0153040302020202",
                    "text": "Intervention, <b>Both:</b>",
                    "type": "group",
                    "repeats": true,
                    "readOnly": false,
                    "item": [{
                      "linkId": "AISD015304030202020201",
                      "text": "Bronchodilator ≥&nbsp;4x/24h (includes inhaled)",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304030202020201&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304030202020202",
                      "text": "Corticosteroid (includes PO or inhaled)",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304030202020202&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }]
                  }]
                }, {
                  "linkId": "AISD01530403020203",
                  "text": "Blood sugar ≤&nbsp;24h, <b>All:</b>",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530403020203&note_type=ALL_NOTES",
                  "type": "group",
                  "repeats": true,
                  "readOnly": false,
                  "item": [{
                    "linkId": "AISD0153040302020301",
                    "text": "Finding, <b>≥ One:</b>",
                    "type": "group",
                    "repeats": true,
                    "readOnly": false,
                    "item": [{
                      "linkId": "AISD015304030202030101",
                      "text": "&gt; 250&nbsp;mg/dL(13.9&nbsp;mmol/L)",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304030202030102",
                      "text": "&lt; 70&nbsp;mg/dL(3.9&nbsp;mmol/L)",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }]
                  }, {
                    "linkId": "AISD0153040302020302",
                    "text": "Blood sugar monitoring",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040302020303",
                    "text": "Insulin adjustment or dose held",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040302020303&note_type=ALL_NOTES",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }]
                }, {
                  "linkId": "AISD01530403020204",
                  "text": "Functional impairment (new) and rehabilitation initiation ≤ 24h",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530403020204&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530403020205",
                  "text": "Heart failure and, <b>Both:</b>",
                  "type": "group",
                  "repeats": true,
                  "readOnly": true,
                  "item": [{
                    "linkId": "AISD0153040302020501",
                    "text": "Dyspnea &gt; baseline and, <b>≥ One:</b>",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040302020501&note_type=ALL_NOTES",
                    "type": "group",
                    "repeats": true,
                    "readOnly": true,
                    "item": [{
                      "linkId": "AISD015304030202050101",
                      "text": "O<sub>2</sub> sat ≤ 91%(0.91) and &lt; baseline",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304030202050101&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304030202050102",
                      "text": "Worsening peripheral edema",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304030202050103",
                      "text": "Heart failure confirmed by imaging",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304030202050103&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }]
                  }, {
                    "linkId": "AISD0153040302020502",
                    "text": "Intervention, <b>≥ One:</b>",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040302020502&note_type=ALL_NOTES",
                    "type": "group",
                    "repeats": true,
                    "readOnly": false,
                    "item": [{
                      "linkId": "AISD015304030202050201",
                      "text": "Diuretic, <b>One:</b>",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304030202050201&note_type=ALL_NOTES",
                      "type": "group",
                      "repeats": true,
                      "readOnly": false,
                      "item": [{
                        "linkId": "AISD01530403020205020101",
                        "text": "≥ 2x/24h (includes PO)",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }, {
                        "linkId": "AISD01530403020205020102",
                        "text": "At least 1x/24h and requires daily medication adjustment (includes PO) and, <b>≥ One:</b>",
                        "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530403020205020102&note_type=ALL_NOTES",
                        "type": "group",
                        "repeats": true,
                        "readOnly": true,
                        "item": [{
                          "linkId": "AISD0153040302020502010201",
                          "text": "Blood urea nitrogen (BUN) increased from baseline",
                          "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040302020502010201&note_type=ALL_NOTES",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        }, {
                          "linkId": "AISD0153040302020502010202",
                          "text": "Creatinine increased from baseline",
                          "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040302020502010202&note_type=ALL_NOTES",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        }]
                      }]
                    }, {
                      "linkId": "AISD015304030202050202",
                      "text": "Dialysis",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }]
                  }]
                }, {
                  "linkId": "AISD01530403020206",
                  "text": "New onset infection actual or suspected and, <b>Both:</b>",
                  "type": "group",
                  "repeats": true,
                  "readOnly": true,
                  "item": [{
                    "linkId": "AISD0153040302020601",
                    "text": "Finding, <b>≥ One:</b>",
                    "type": "group",
                    "repeats": true,
                    "readOnly": false,
                    "item": [{
                      "linkId": "AISD015304030202060101",
                      "text": "Temperature &gt;&nbsp;99.4°F(37.4°C) PO or &gt; 100.4°F(38.0°C) PR",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304030202060101&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304030202060102",
                      "text": "WBC ≥&nbsp;12,000/cu.mm(12x10<sup>9</sup>/L)",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304030202060103",
                      "text": "WBC ≤&nbsp;4,000/cu.mm(4 x10<sup>9</sup>/L)",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304030202060104",
                      "text": "Bands &gt;&nbsp;10%(0.10)",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304030202060105",
                      "text": "ANC &lt; 500/cu.mm(500x10<sup>6</sup>/L)",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304030202060105&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }]
                  }, {
                    "linkId": "AISD0153040302020602",
                    "text": "Intervention, <b>≥ One:</b>",
                    "type": "group",
                    "repeats": true,
                    "readOnly": false,
                    "item": [{
                      "linkId": "AISD015304030202060201",
                      "text": "Culture pending ≤ 2d",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304030202060202",
                      "text": "Drug−induced fever suspected and precipitating drug discontinued ≤&nbsp;3d",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304030202060202&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304030202060203",
                      "text": "Imaging study ≤ 24h",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }]
                  }]
                }, {
                  "linkId": "AISD01530403020207",
                  "text": "Pneumonia confirmed by imaging and, <b>Both:</b>",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530403020207&note_type=ALL_NOTES",
                  "type": "group",
                  "repeats": true,
                  "readOnly": true,
                  "item": [{
                    "linkId": "AISD0153040302020701",
                    "text": "Finding, <b>≥ One:</b>",
                    "type": "group",
                    "repeats": true,
                    "readOnly": false,
                    "item": [{
                      "linkId": "AISD015304030202070101",
                      "text": "Temperature, <b>≥ One:</b>",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304030202070101&note_type=ALL_NOTES",
                      "type": "group",
                      "repeats": true,
                      "readOnly": false,
                      "item": [{
                        "linkId": "AISD01530403020207010101",
                        "text": "&gt;&nbsp;99.4°F(37.4°C) PO",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }, {
                        "linkId": "AISD01530403020207010102",
                        "text": "&gt; 100.4°F(38.0°C) PR",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }]
                    }, {
                      "linkId": "AISD015304030202070102",
                      "text": "Mental status change (excludes coma, stupor, or obtundation) or GCS 9−14",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304030202070102&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304030202070103",
                      "text": "O<sub>2</sub> sat ≤ 91%(0.91) and &lt; baseline",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304030202070103&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304030202070104",
                      "text": "WBC ≥&nbsp;12,000/cu.mm(12x10<sup>9</sup>/L)",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304030202070105",
                      "text": "WBC ≤&nbsp;4,000/cu.mm(4 x10<sup>9</sup>/L)",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304030202070106",
                      "text": "Bands &gt;&nbsp;10%(0.10)",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }]
                  }, {
                    "linkId": "AISD0153040302020702",
                    "text": "Intervention, <b>≥ One:</b>",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040302020702&note_type=ALL_NOTES",
                    "type": "group",
                    "repeats": true,
                    "readOnly": false,
                    "item": [{
                      "linkId": "AISD015304030202070201",
                      "text": "Requiring supplemental oxygen",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304030202070201&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304030202070202",
                      "text": "Anti−infective (includes PO)",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304030202070203",
                      "text": "Respiratory interventions at least 6x/24h",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304030202070203&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }]
                  }]
                }, {
                  "linkId": "AISD01530403020208",
                  "text": "Post Critical care ≤ 24h",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }]
              }]
            }, {
              "linkId": "AISD0153040303",
              "text": "<b>INTERMEDIATE,</b> <b>≥ One:</b>",
              "type": "group",
              "repeats": true,
              "readOnly": false,
              "item": [{
                "linkId": "AISD015304030301",
                "text": "Troponin positive and acute coronary syndrome suspected (<b>use Acute Coronary Syndrome subset</b>)",
                "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304030301&note_type=ALL_NOTES",
                "type": "boolean",
                "repeats": false,
                "readOnly": true,
                "item": []
              }, {
                "linkId": "AISD015304030302",
                "text": "Mechanical ventilation and, <b>One:</b>",
                "type": "group",
                "repeats": true,
                "readOnly": true,
                "item": [{
                  "linkId": "AISD01530403030201",
                  "text": "Respiratory intervention every 3−4h",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530403030201&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530403030202",
                  "text": "Weaning ≤ 2d",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530403030202&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }]
              }, {
                "linkId": "AISD015304030303",
                "text": "NIPPV and, <b>One:</b>",
                "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304030303&note_type=ALL_NOTES",
                "type": "group",
                "repeats": true,
                "readOnly": true,
                "item": [{
                  "linkId": "AISD01530403030301",
                  "text": "Respiratory intervention every 3−4h",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530403030301&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530403030302",
                  "text": "Weaning ≤ 2d",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530403030302&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }]
              }, {
                "linkId": "AISD015304030304",
                "text": "Oxygen ≥ 40%(0.40) ≤ 2d",
                "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304030304&note_type=ALL_NOTES",
                "type": "boolean",
                "repeats": false,
                "readOnly": true,
                "item": []
              }]
            }, {
              "linkId": "AISD0153040304",
              "text": "<b>CRITICAL,</b> <b>≥ One:</b>",
              "type": "group",
              "repeats": true,
              "readOnly": false,
              "item": [{
                "linkId": "AISD015304030401",
                "text": "Troponin positive and acute coronary syndrome suspected (<b>use Acute Coronary Syndrome subset</b>)",
                "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304030401&note_type=ALL_NOTES",
                "type": "boolean",
                "repeats": false,
                "readOnly": true,
                "item": []
              }, {
                "linkId": "AISD015304030402",
                "text": "Atrial fibrillation or atrial flutter <b>≥ One:</b>",
                "type": "group",
                "repeats": true,
                "readOnly": false,
                "item": [{
                  "linkId": "AISD01530403040201",
                  "text": "Urgent electrical cardioversion performed within last 24h",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530403040202",
                  "text": "Symptomatic recurrent or refractory arrhythmia requiring antiarrhythmic and, <b>≥ One:</b>",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530403040202&note_type=ALL_NOTES",
                  "type": "group",
                  "repeats": true,
                  "readOnly": true,
                  "item": [{
                    "linkId": "AISD0153040304020201",
                    "text": "Chest pain",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040304020202",
                    "text": "Heart failure and, <b>≥ One:</b>",
                    "type": "group",
                    "repeats": true,
                    "readOnly": true,
                    "item": [{
                      "linkId": "AISD015304030402020201",
                      "text": "Arterial Po<sub>2</sub> &lt; 56 mmHg(7.4 kPa)",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304030402020202",
                      "text": "O<sub>2</sub> sat &lt; 89%(0.89) and &lt; baseline",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }]
                  }, {
                    "linkId": "AISD0153040304020203",
                    "text": "Hemodynamic instability, <b>≥ One:</b>",
                    "type": "group",
                    "repeats": true,
                    "readOnly": false,
                    "item": [{
                      "linkId": "AISD015304030402020301",
                      "text": "Heart rate &gt;&nbsp;120/min, sustained",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304030402020301&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304030402020302",
                      "text": "Systolic blood pressure, <b>≥ One:</b>",
                      "type": "group",
                      "repeats": true,
                      "readOnly": false,
                      "item": [{
                        "linkId": "AISD01530403040202030201",
                        "text": "&lt; 90 mmHg",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }, {
                        "linkId": "AISD01530403040202030202",
                        "text": "&lt; 110 mmHg with chronic hypertension",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }, {
                        "linkId": "AISD01530403040202030203",
                        "text": "&gt; 30 mmHg decrease from baseline",
                        "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530403040202030203&note_type=ALL_NOTES",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }, {
                        "linkId": "AISD01530403040202030204",
                        "text": "Labile",
                        "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530403040202030204&note_type=ALL_NOTES",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }]
                    }, {
                      "linkId": "AISD015304030402020303",
                      "text": "MAP &lt;&nbsp;65&nbsp;mmHg",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }]
                  }]
                }]
              }, {
                "linkId": "AISD015304030403",
                "text": "Bronchodilator every 1−2h (includes inhaled)",
                "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304030403&note_type=ALL_NOTES",
                "type": "boolean",
                "repeats": false,
                "readOnly": true,
                "item": []
              }, {
                "linkId": "AISD015304030404",
                "text": "ECMO or ECLS",
                "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304030404&note_type=ALL_NOTES",
                "type": "boolean",
                "repeats": false,
                "readOnly": true,
                "item": []
              }, {
                "linkId": "AISD015304030405",
                "text": "Hemodynamic instability, <b>Both:</b>",
                "type": "group",
                "repeats": true,
                "readOnly": false,
                "item": [{
                  "linkId": "AISD01530403040501",
                  "text": "Finding, <b>≥ One:</b>",
                  "type": "group",
                  "repeats": true,
                  "readOnly": false,
                  "item": [{
                    "linkId": "AISD0153040304050101",
                    "text": "Heart rate &gt;&nbsp;120/min, sustained",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040304050101&note_type=ALL_NOTES",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040304050102",
                    "text": "Systolic blood pressure, <b>≥ One:</b>",
                    "type": "group",
                    "repeats": true,
                    "readOnly": false,
                    "item": [{
                      "linkId": "AISD015304030405010201",
                      "text": "&lt; 90 mmHg",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304030405010202",
                      "text": "&lt; 110 mmHg with chronic hypertension",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304030405010203",
                      "text": "&gt; 30 mmHg decrease from baseline",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304030405010203&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304030405010204",
                      "text": "Labile",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304030405010204&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }]
                  }, {
                    "linkId": "AISD0153040304050103",
                    "text": "MAP &lt;&nbsp;65&nbsp;mmHg",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }]
                }, {
                  "linkId": "AISD01530403040502",
                  "text": "Intervention, <b>≥ One:</b>",
                  "type": "group",
                  "repeats": true,
                  "readOnly": false,
                  "item": [{
                    "linkId": "AISD0153040304050201",
                    "text": "Blood product transfusion",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040304050202",
                    "text": "IV fluid resuscitation ≤ 2d",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040304050202&note_type=ALL_NOTES",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }]
                }]
              }, {
                "linkId": "AISD015304030406",
                "text": "Hemodynamic monitoring, invasive",
                "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304030406&note_type=ALL_NOTES",
                "type": "boolean",
                "repeats": false,
                "readOnly": true,
                "item": []
              }, {
                "linkId": "AISD015304030407",
                "text": "Mechanical ventilation and, <b>≥ One:</b>",
                "type": "group",
                "repeats": true,
                "readOnly": true,
                "item": [{
                  "linkId": "AISD01530403040701",
                  "text": "&lt; 3 weaning attempts",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530403040701&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530403040702",
                  "text": "Airway protection",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530403040702&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530403040703",
                  "text": "FiO<sub>2</sub> &gt; 50%(0.50)",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530403040704",
                  "text": "PEEP &gt; 10 cm H<sub>2</sub>O",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530403040705",
                  "text": "Neuromuscular blocker",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530403040706",
                  "text": "Respiratory intervention every 1−2h",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530403040706&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }]
              }, {
                "linkId": "AISD015304030408",
                "text": "NIPPV and, <b>One:</b>",
                "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304030408&note_type=ALL_NOTES",
                "type": "group",
                "repeats": true,
                "readOnly": true,
                "item": [{
                  "linkId": "AISD01530403040801",
                  "text": "Continued intervention required, <b>≥ One:</b>",
                  "type": "group",
                  "repeats": true,
                  "readOnly": false,
                  "item": [{
                    "linkId": "AISD0153040304080101",
                    "text": "FiO<sub>2</sub> &gt; 50%(0.50)",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040304080102",
                    "text": "PEEP &gt; 10 cm H<sub>2</sub>O",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040304080103",
                    "text": "Respiratory intervention every 1−2h",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040304080103&note_type=ALL_NOTES",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }]
                }, {
                  "linkId": "AISD01530403040802",
                  "text": "Weaning ≤ 24h",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530403040802&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }]
              }, {
                "linkId": "AISD015304030409",
                "text": "Vasopressor, vasodilator, or inotrope, continuous (excludes low or fixed dose for end stage heart failure)",
                "type": "boolean",
                "repeats": false,
                "readOnly": true,
                "item": []
              }]
            }]
          }, {
            "resourceType": "Questionnaire",
            "id": "AISD01530404",
            "name": "<b>Episode Day 3</b>",
            "item": [{
              "linkId": "AISD0153040401",
              "text": "<b>OBSERVATION,</b> <b>One:</b>",
              "type": "group",
              "repeats": true,
              "readOnly": false,
              "item": [{
                "linkId": "AISD015304040101",
                "text": "<b>Responder</b>, discharge expected today if clinically stable last 12h, <b>Both:</b>",
                "type": "group",
                "repeats": true,
                "readOnly": false,
                "item": [{
                  "linkId": "AISD01530404010101",
                  "text": "Oxygenation, <b>≥ One:</b>",
                  "type": "group",
                  "repeats": true,
                  "readOnly": false,
                  "item": [{
                    "linkId": "AISD0153040401010101",
                    "text": "O<sub>2 </sub>sat ≥&nbsp;92%(0.92) or within acceptable limits",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040401010101&note_type=ALL_NOTES",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040401010102",
                    "text": "No change in oxygen requirements last 24h",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }]
                }, {
                  "linkId": "AISD01530404010102",
                  "text": "Dyspnea improving",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }]
              }, {
                "linkId": "AISD015304040102",
                "text": "<b>Non−responder</b>, not clinically stable for discharge and exceeds episode days at the Observation level of care for this condition, <b>One:</b>",
                "type": "group",
                "repeats": true,
                "readOnly": false,
                "item": [{
                  "linkId": "AISD01530404010201",
                  "text": "For COPD<b> </b>use Episode Day 3 at a higher level of care",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530404010202",
                  "text": "For a condition other than COPD use appropriate subset (Episode Day 1) based on clinical findings",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530404010203",
                  "text": "Refer for secondary review",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }]
              }]
            }, {
              "linkId": "AISD0153040402",
              "text": "<b>ACUTE,</b> <b>One:</b>",
              "type": "group",
              "repeats": true,
              "readOnly": false,
              "item": [{
                "linkId": "AISD015304040201",
                "text": "<b>Responder,</b> discharge expected today if clinically stable last 12h, <b>All:</b>",
                "type": "group",
                "repeats": true,
                "readOnly": false,
                "item": [{
                  "linkId": "AISD01530404020101",
                  "text": "Afebrile",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530404020101&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530404020102",
                  "text": "Oxygenation, <b>≥ One:</b>",
                  "type": "group",
                  "repeats": true,
                  "readOnly": false,
                  "item": [{
                    "linkId": "AISD0153040402010201",
                    "text": "O<sub>2 </sub>sat ≥&nbsp;92%(0.92) or within acceptable limits",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040402010201&note_type=ALL_NOTES",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040402010202",
                    "text": "No change in oxygen requirements last 2d",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }]
                }, {
                  "linkId": "AISD01530404020103",
                  "text": "Dyspnea improving",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530404020104",
                  "text": "Complication or comorbidity, <b>One:</b>",
                  "type": "group",
                  "repeats": true,
                  "readOnly": false,
                  "item": [{
                    "linkId": "AISD0153040402010401",
                    "text": "No complication or active comorbidity relevant to this episode of care",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040402010401&note_type=ALL_NOTES",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040402010402",
                    "text": "Complication or comorbidity and clinically stable for discharge, <b>≥ One:</b>",
                    "type": "group",
                    "repeats": true,
                    "readOnly": false,
                    "item": [{
                      "linkId": "AISD015304040201040201",
                      "text": "ANC ≥&nbsp;500/cu.mm(500x10<sup>6</sup>/L)",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304040201040201&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304040201040202",
                      "text": "Blood sugar within acceptable limits",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304040201040202&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304040201040203",
                      "text": "Functional evaluation complete",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304040201040203&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304040201040204",
                      "text": "WBC within acceptable limits",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304040201040204&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }]
                  }]
                }]
              }, {
                "linkId": "AISD015304040202",
                "text": "<b>Partial Responder</b>, not clinically stable for discharge and requires continued stay, <b>≥ One:</b>",
                "type": "group",
                "repeats": true,
                "readOnly": false,
                "item": [{
                  "linkId": "AISD01530404020201",
                  "text": "Pulmonary embolism (<b>use Pulmonary Embolism subset</b>)",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530404020202",
                  "text": "COPD exacerbation unresolved and, <b>Both:</b>",
                  "type": "group",
                  "repeats": true,
                  "readOnly": true,
                  "item": [{
                    "linkId": "AISD0153040402020201",
                    "text": "Persistent dyspnea, <b>≥ One:</b>",
                    "type": "group",
                    "repeats": true,
                    "readOnly": false,
                    "item": [{
                      "linkId": "AISD015304040202020101",
                      "text": "Arterial Po<sub>2</sub> &lt; baseline",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304040202020101&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304040202020102",
                      "text": "Arterial or venous Pco<sub>2 </sub>&gt; baseline",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304040202020102&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304040202020103",
                      "text": "O<sub>2 </sub>sat ≤&nbsp;91%(0.91) and &lt; baseline",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304040202020103&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304040202020104",
                      "text": "Increased work of breathing, <b>≥ One:</b>",
                      "type": "group",
                      "repeats": true,
                      "readOnly": false,
                      "item": [{
                        "linkId": "AISD01530404020202010401",
                        "text": "Difficulty taking PO",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }, {
                        "linkId": "AISD01530404020202010402",
                        "text": "Prefers sitting",
                        "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530404020202010402&note_type=ALL_NOTES",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }, {
                        "linkId": "AISD01530404020202010403",
                        "text": "Talks in phrases",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }, {
                        "linkId": "AISD01530404020202010404",
                        "text": "Use of accessory muscles",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }]
                    }]
                  }, {
                    "linkId": "AISD0153040402020202",
                    "text": "Intervention, <b>Both:</b>",
                    "type": "group",
                    "repeats": true,
                    "readOnly": false,
                    "item": [{
                      "linkId": "AISD015304040202020201",
                      "text": "Bronchodilator ≥&nbsp;4x/24h (includes inhaled)",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304040202020201&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304040202020202",
                      "text": "Corticosteroid (includes PO or inhaled)",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304040202020202&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }]
                  }]
                }, {
                  "linkId": "AISD01530404020203",
                  "text": "Blood sugar ≤&nbsp;24h, <b>All:</b>",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530404020203&note_type=ALL_NOTES",
                  "type": "group",
                  "repeats": true,
                  "readOnly": false,
                  "item": [{
                    "linkId": "AISD0153040402020301",
                    "text": "Finding, <b>≥ One:</b>",
                    "type": "group",
                    "repeats": true,
                    "readOnly": false,
                    "item": [{
                      "linkId": "AISD015304040202030101",
                      "text": "&gt; 250&nbsp;mg/dL(13.9&nbsp;mmol/L)",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304040202030102",
                      "text": "&lt; 70&nbsp;mg/dL(3.9&nbsp;mmol/L)",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }]
                  }, {
                    "linkId": "AISD0153040402020302",
                    "text": "Blood sugar monitoring",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040402020303",
                    "text": "Insulin adjustment or dose held",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040402020303&note_type=ALL_NOTES",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }]
                }, {
                  "linkId": "AISD01530404020204",
                  "text": "Functional impairment (new) and rehabilitation initiation ≤ 24h",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530404020204&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530404020205",
                  "text": "Heart failure and, <b>Both:</b>",
                  "type": "group",
                  "repeats": true,
                  "readOnly": true,
                  "item": [{
                    "linkId": "AISD0153040402020501",
                    "text": "Dyspnea &gt; baseline and, <b>≥ One:</b>",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040402020501&note_type=ALL_NOTES",
                    "type": "group",
                    "repeats": true,
                    "readOnly": true,
                    "item": [{
                      "linkId": "AISD015304040202050101",
                      "text": "O<sub>2</sub> sat ≤ 91%(0.91) and &lt; baseline",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304040202050101&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304040202050102",
                      "text": "Worsening peripheral edema",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304040202050103",
                      "text": "Heart failure confirmed by imaging",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304040202050103&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }]
                  }, {
                    "linkId": "AISD0153040402020502",
                    "text": "Intervention, <b>≥ One:</b>",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040402020502&note_type=ALL_NOTES",
                    "type": "group",
                    "repeats": true,
                    "readOnly": false,
                    "item": [{
                      "linkId": "AISD015304040202050201",
                      "text": "Diuretic, <b>One:</b>",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304040202050201&note_type=ALL_NOTES",
                      "type": "group",
                      "repeats": true,
                      "readOnly": false,
                      "item": [{
                        "linkId": "AISD01530404020205020101",
                        "text": "≥ 2x/24h (includes PO)",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }, {
                        "linkId": "AISD01530404020205020102",
                        "text": "At least 1x/24h and requires daily medication adjustment (includes PO) and, <b>≥ One:</b>",
                        "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530404020205020102&note_type=ALL_NOTES",
                        "type": "group",
                        "repeats": true,
                        "readOnly": true,
                        "item": [{
                          "linkId": "AISD0153040402020502010201",
                          "text": "Blood urea nitrogen (BUN) increased from baseline",
                          "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040402020502010201&note_type=ALL_NOTES",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        }, {
                          "linkId": "AISD0153040402020502010202",
                          "text": "Creatinine increased from baseline",
                          "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040402020502010202&note_type=ALL_NOTES",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        }]
                      }]
                    }, {
                      "linkId": "AISD015304040202050202",
                      "text": "Dialysis",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }]
                  }]
                }, {
                  "linkId": "AISD01530404020206",
                  "text": "New onset infection, actual or suspected and, <b>Both:</b>",
                  "type": "group",
                  "repeats": true,
                  "readOnly": true,
                  "item": [{
                    "linkId": "AISD0153040402020601",
                    "text": "Finding, <b>≥ One:</b>",
                    "type": "group",
                    "repeats": true,
                    "readOnly": false,
                    "item": [{
                      "linkId": "AISD015304040202060101",
                      "text": "Temperature &gt;&nbsp;99.4°F(37.4°C) PO or &gt; 100.4°F(38.0°C) PR",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304040202060101&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304040202060102",
                      "text": "WBC ≥&nbsp;12,000/cu.mm(12x10<sup>9</sup>/L)",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304040202060103",
                      "text": "WBC ≤&nbsp;4,000/cu.mm(4 x10<sup>9</sup>/L)",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304040202060104",
                      "text": "Bands &gt;&nbsp;10%(0.10)",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304040202060105",
                      "text": "ANC &lt; 500/cu.mm(500x10<sup>6</sup>/L)",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304040202060105&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }]
                  }, {
                    "linkId": "AISD0153040402020602",
                    "text": "Intervention, <b>≥ One:</b>",
                    "type": "group",
                    "repeats": true,
                    "readOnly": false,
                    "item": [{
                      "linkId": "AISD015304040202060201",
                      "text": "Culture pending ≤ 2d",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304040202060202",
                      "text": "Drug−induced fever suspected and precipitating drug discontinued ≤&nbsp;3d",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304040202060202&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304040202060203",
                      "text": "Imaging study ≤ 24h",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }]
                  }]
                }, {
                  "linkId": "AISD01530404020207",
                  "text": "Pneumonia confirmed by imaging and, <b>Both:</b>",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530404020207&note_type=ALL_NOTES",
                  "type": "group",
                  "repeats": true,
                  "readOnly": true,
                  "item": [{
                    "linkId": "AISD0153040402020701",
                    "text": "Finding, <b>≥ One:</b>",
                    "type": "group",
                    "repeats": true,
                    "readOnly": false,
                    "item": [{
                      "linkId": "AISD015304040202070101",
                      "text": "Temperature, <b>≥ One:</b>",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304040202070101&note_type=ALL_NOTES",
                      "type": "group",
                      "repeats": true,
                      "readOnly": false,
                      "item": [{
                        "linkId": "AISD01530404020207010101",
                        "text": "&gt;&nbsp;99.4°F(37.4°C) PO",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }, {
                        "linkId": "AISD01530404020207010102",
                        "text": "&gt; 100.4°F(38.0°C) PR",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }]
                    }, {
                      "linkId": "AISD015304040202070102",
                      "text": "Mental status change (excludes coma, stupor, or obtundation) or GCS 9−14",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304040202070102&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304040202070103",
                      "text": "O<sub>2</sub> sat ≤ 91%(0.91) and &lt; baseline",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304040202070103&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304040202070104",
                      "text": "WBC ≥&nbsp;12,000/cu.mm(12x10<sup>9</sup>/L)",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304040202070105",
                      "text": "WBC ≤&nbsp;4,000/cu.mm(4 x10<sup>9</sup>/L)",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304040202070106",
                      "text": "Bands &gt;&nbsp;10%(0.10)",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }]
                  }, {
                    "linkId": "AISD0153040402020702",
                    "text": "Intervention, <b>≥ One:</b>",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040402020702&note_type=ALL_NOTES",
                    "type": "group",
                    "repeats": true,
                    "readOnly": false,
                    "item": [{
                      "linkId": "AISD015304040202070201",
                      "text": "Requiring supplemental oxygen",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304040202070201&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304040202070202",
                      "text": "Anti−infective (includes PO)",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304040202070203",
                      "text": "Respiratory interventions at least 6x/24h",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304040202070203&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }]
                  }]
                }, {
                  "linkId": "AISD01530404020208",
                  "text": "Post Critical care ≤ 24h",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }]
              }]
            }, {
              "linkId": "AISD0153040403",
              "text": "<b>INTERMEDIATE,</b> <b>≥ One:</b>",
              "type": "group",
              "repeats": true,
              "readOnly": false,
              "item": [{
                "linkId": "AISD015304040301",
                "text": "Troponin positive and acute coronary syndrome suspected (<b>use ACS subset</b>)",
                "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304040301&note_type=ALL_NOTES",
                "type": "boolean",
                "repeats": false,
                "readOnly": true,
                "item": []
              }, {
                "linkId": "AISD015304040302",
                "text": "Atrial fibrillation or atrial flutter, <b>≥ One:</b>",
                "type": "group",
                "repeats": true,
                "readOnly": false,
                "item": [{
                  "linkId": "AISD01530404030201",
                  "text": "Antiarrhythmic, continuous and hemodynamically stable",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530404030202",
                  "text": "Conversion from IV to PO antiarrhythmic and no proarrhythmic risk ≤ 24h",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530404030203",
                  "text": "Initiation of PO antiarrhythmic with proarrhythmic risk ≤ 3d and, <b>Both:</b>",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530404030203&note_type=ALL_NOTES",
                  "type": "group",
                  "repeats": true,
                  "readOnly": true,
                  "item": [{
                    "linkId": "AISD0153040403020301",
                    "text": "Continuous cardiac monitoring (excludes Holter)",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040403020301&note_type=ALL_NOTES",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040403020302",
                    "text": "Medication, <b>≥ One:</b>",
                    "type": "group",
                    "repeats": true,
                    "readOnly": false,
                    "item": [{
                      "linkId": "AISD015304040302030201",
                      "text": "Amiodarone",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304040302030201&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304040302030202",
                      "text": "Disopyramide",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304040302030203",
                      "text": "Dofetilide",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304040302030203&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304040302030204",
                      "text": "Dronedarone",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304040302030204&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304040302030205",
                      "text": "Propafenone",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304040302030206",
                      "text": "Quinidine",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304040302030207",
                      "text": "Sotalol",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }]
                  }]
                }]
              }, {
                "linkId": "AISD015304040303",
                "text": "Mechanical ventilation and, <b>One:</b>",
                "type": "group",
                "repeats": true,
                "readOnly": true,
                "item": [{
                  "linkId": "AISD01530404030301",
                  "text": "Respiratory intervention every 3−4h",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530404030301&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530404030302",
                  "text": "Weaning ≤ 2d",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530404030302&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }]
              }, {
                "linkId": "AISD015304040304",
                "text": "NIPPV and, <b>One:</b>",
                "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304040304&note_type=ALL_NOTES",
                "type": "group",
                "repeats": true,
                "readOnly": true,
                "item": [{
                  "linkId": "AISD01530404030401",
                  "text": "Respiratory intervention every 3−4h",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530404030401&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530404030402",
                  "text": "Weaning ≤ 2d",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530404030402&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }]
              }, {
                "linkId": "AISD015304040305",
                "text": "Oxygen ≥ 40%(0.40) ≤ 2d",
                "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304040305&note_type=ALL_NOTES",
                "type": "boolean",
                "repeats": false,
                "readOnly": true,
                "item": []
              }]
            }, {
              "linkId": "AISD0153040404",
              "text": "<b>CRITICAL,</b> <b>≥ One:</b>",
              "type": "group",
              "repeats": true,
              "readOnly": false,
              "item": [{
                "linkId": "AISD015304040401",
                "text": "Troponin positive and acute coronary syndrome suspected (<b>use ACS subset</b>)",
                "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304040401&note_type=ALL_NOTES",
                "type": "boolean",
                "repeats": false,
                "readOnly": true,
                "item": []
              }, {
                "linkId": "AISD015304040402",
                "text": "Atrial fibrillation or atrial flutter, <b>≥ One:</b>",
                "type": "group",
                "repeats": true,
                "readOnly": false,
                "item": [{
                  "linkId": "AISD01530404040201",
                  "text": "Urgent electrical cardioversion performed within last 24h",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530404040202",
                  "text": "Symptomatic recurrent or refractory arrhythmia requiring antiarrhythmic and, <b>≥ One:</b>",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530404040202&note_type=ALL_NOTES",
                  "type": "group",
                  "repeats": true,
                  "readOnly": true,
                  "item": [{
                    "linkId": "AISD0153040404020201",
                    "text": "Chest pain",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040404020202",
                    "text": "Heart failure and, <b>≥ One:</b>",
                    "type": "group",
                    "repeats": true,
                    "readOnly": true,
                    "item": [{
                      "linkId": "AISD015304040402020201",
                      "text": "Arterial Po<sub>2</sub> &lt; 56 mmHg(7.4 kPa)",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304040402020202",
                      "text": "O<sub>2</sub> sat &lt; 89%(0.89) and &lt; baseline",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }]
                  }, {
                    "linkId": "AISD0153040404020203",
                    "text": "Hemodynamic instability, <b>≥ One:</b>",
                    "type": "group",
                    "repeats": true,
                    "readOnly": false,
                    "item": [{
                      "linkId": "AISD015304040402020301",
                      "text": "Heart rate &gt;&nbsp;120/min, sustained",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304040402020301&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304040402020302",
                      "text": "Systolic blood pressure, <b>≥ One:</b>",
                      "type": "group",
                      "repeats": true,
                      "readOnly": false,
                      "item": [{
                        "linkId": "AISD01530404040202030201",
                        "text": "&lt; 90 mmHg",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }, {
                        "linkId": "AISD01530404040202030202",
                        "text": "&lt; 110 mmHg with chronic hypertension",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }, {
                        "linkId": "AISD01530404040202030203",
                        "text": "&gt; 30 mmHg decrease from baseline",
                        "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530404040202030203&note_type=ALL_NOTES",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }, {
                        "linkId": "AISD01530404040202030204",
                        "text": "Labile",
                        "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530404040202030204&note_type=ALL_NOTES",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }]
                    }, {
                      "linkId": "AISD015304040402020303",
                      "text": "MAP &lt;&nbsp;65&nbsp;mmHg",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }]
                  }]
                }]
              }, {
                "linkId": "AISD015304040403",
                "text": "Bronchodilator every 1−2h (includes inhaled)",
                "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304040403&note_type=ALL_NOTES",
                "type": "boolean",
                "repeats": false,
                "readOnly": true,
                "item": []
              }, {
                "linkId": "AISD015304040404",
                "text": "ECMO or ECLS",
                "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304040404&note_type=ALL_NOTES",
                "type": "boolean",
                "repeats": false,
                "readOnly": true,
                "item": []
              }, {
                "linkId": "AISD015304040405",
                "text": "Hemodynamic instability, <b>Both:</b>",
                "type": "group",
                "repeats": true,
                "readOnly": false,
                "item": [{
                  "linkId": "AISD01530404040501",
                  "text": "Finding, <b>≥ One:</b>",
                  "type": "group",
                  "repeats": true,
                  "readOnly": false,
                  "item": [{
                    "linkId": "AISD0153040404050101",
                    "text": "Heart rate &gt;&nbsp;120/min, sustained",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040404050101&note_type=ALL_NOTES",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040404050102",
                    "text": "Systolic blood pressure, <b>≥ One:</b>",
                    "type": "group",
                    "repeats": true,
                    "readOnly": false,
                    "item": [{
                      "linkId": "AISD015304040405010201",
                      "text": "&lt; 90 mmHg",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304040405010202",
                      "text": "&lt; 110 mmHg with chronic hypertension",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304040405010203",
                      "text": "&gt; 30 mmHg decrease from baseline",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304040405010203&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304040405010204",
                      "text": "Labile",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304040405010204&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }]
                  }, {
                    "linkId": "AISD0153040404050103",
                    "text": "MAP &lt;&nbsp;65&nbsp;mmHg",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }]
                }, {
                  "linkId": "AISD01530404040502",
                  "text": "Intervention, <b>≥ One:</b>",
                  "type": "group",
                  "repeats": true,
                  "readOnly": false,
                  "item": [{
                    "linkId": "AISD0153040404050201",
                    "text": "Blood product transfusion",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040404050202",
                    "text": "IV fluid resuscitation ≤ 2d",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040404050202&note_type=ALL_NOTES",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }]
                }]
              }, {
                "linkId": "AISD015304040406",
                "text": "Hemodynamic monitoring, invasive",
                "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304040406&note_type=ALL_NOTES",
                "type": "boolean",
                "repeats": false,
                "readOnly": true,
                "item": []
              }, {
                "linkId": "AISD015304040407",
                "text": "Mechanical ventilation and, <b>≥ One:</b>",
                "type": "group",
                "repeats": true,
                "readOnly": true,
                "item": [{
                  "linkId": "AISD01530404040701",
                  "text": "&lt; 3 weaning attempts",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530404040701&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530404040702",
                  "text": "Airway protection",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530404040702&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530404040703",
                  "text": "FiO<sub>2</sub> &gt; 50%(0.50)",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530404040704",
                  "text": "PEEP &gt; 10 cm H<sub>2</sub>O",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530404040705",
                  "text": "Neuromuscular blocker",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530404040706",
                  "text": "Respiratory intervention every 1−2h",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530404040706&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }]
              }, {
                "linkId": "AISD015304040408",
                "text": "NIPPV and, <b>One:</b>",
                "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304040408&note_type=ALL_NOTES",
                "type": "group",
                "repeats": true,
                "readOnly": true,
                "item": [{
                  "linkId": "AISD01530404040801",
                  "text": "Continued intervention required, <b>≥ One:</b>",
                  "type": "group",
                  "repeats": true,
                  "readOnly": false,
                  "item": [{
                    "linkId": "AISD0153040404080101",
                    "text": "FiO<sub>2</sub> &gt; 50%(0.50)",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040404080102",
                    "text": "PEEP &gt; 10 cm H<sub>2</sub>O",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040404080103",
                    "text": "Respiratory intervention every 1−2h",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040404080103&note_type=ALL_NOTES",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }]
                }, {
                  "linkId": "AISD01530404040802",
                  "text": "Weaning ≤ 24h",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530404040802&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }]
              }, {
                "linkId": "AISD015304040409",
                "text": "Vasopressor, vasodilator, or inotrope, continuous (excludes low or fixed dose for end stage heart failure)",
                "type": "boolean",
                "repeats": false,
                "readOnly": true,
                "item": []
              }]
            }]
          }, {
            "resourceType": "Questionnaire",
            "id": "AISD01530405",
            "name": "<b>Episode Day 4-6</b>",
            "item": [{
              "linkId": "AISD0153040501",
              "text": "<b>ACUTE,</b> <b>One:</b>",
              "type": "group",
              "repeats": true,
              "readOnly": false,
              "item": [{
                "linkId": "AISD015304050101",
                "text": "<b>Responder,</b> discharge expected today if clinically stable last 12h, <b>All:</b>",
                "type": "group",
                "repeats": true,
                "readOnly": false,
                "item": [{
                  "linkId": "AISD01530405010101",
                  "text": "Afebrile",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530405010101&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530405010102",
                  "text": "Oxygenation, <b>≥ One:</b>",
                  "type": "group",
                  "repeats": true,
                  "readOnly": false,
                  "item": [{
                    "linkId": "AISD0153040501010201",
                    "text": "O<sub>2 </sub>sat ≥&nbsp;92%(0.92) or within acceptable limits",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040501010201&note_type=ALL_NOTES",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040501010202",
                    "text": "No change in oxygen requirements last 2d",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }]
                }, {
                  "linkId": "AISD01530405010103",
                  "text": "Dyspnea improving",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530405010104",
                  "text": "Complication or comorbidity, <b>One:</b>",
                  "type": "group",
                  "repeats": true,
                  "readOnly": false,
                  "item": [{
                    "linkId": "AISD0153040501010401",
                    "text": "No complication or active comorbidity relevant to this episode of care",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040501010401&note_type=ALL_NOTES",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040501010402",
                    "text": "Complication or comorbidity and clinically stable for discharge, <b>≥ One:</b>",
                    "type": "group",
                    "repeats": true,
                    "readOnly": false,
                    "item": [{
                      "linkId": "AISD015304050101040201",
                      "text": "ANC ≥&nbsp;500/cu.mm(500x10<sup>6</sup>/L)",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304050101040201&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304050101040202",
                      "text": "Blood sugar within acceptable limits",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304050101040202&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304050101040203",
                      "text": "Functional evaluation complete",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304050101040203&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304050101040204",
                      "text": "WBC within acceptable limits",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304050101040204&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }]
                  }]
                }]
              }, {
                "linkId": "AISD015304050102",
                "text": "<b>Partial Responder</b>, not clinically stable for discharge and requires continued stay, <b>≥ One:</b>",
                "type": "group",
                "repeats": true,
                "readOnly": false,
                "item": [{
                  "linkId": "AISD01530405010201",
                  "text": "Pulmonary embolism (<b>use Pulmonary Embolism subset</b>)",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530405010202",
                  "text": "COPD exacerbation unresolved and, <b>Both:</b>",
                  "type": "group",
                  "repeats": true,
                  "readOnly": true,
                  "item": [{
                    "linkId": "AISD0153040501020201",
                    "text": "Finding, <b>≥ One:</b>",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040501020201&note_type=ALL_NOTES",
                    "type": "group",
                    "repeats": true,
                    "readOnly": false,
                    "item": [{
                      "linkId": "AISD015304050102020101",
                      "text": "Arterial Po<sub>2</sub> &lt; baseline",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304050102020101&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304050102020102",
                      "text": "Arterial or venous Pco<sub>2 </sub>&gt; baseline",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304050102020102&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304050102020103",
                      "text": "O<sub>2 </sub>sat ≤&nbsp;91%(0.91) and &lt; baseline",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304050102020103&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304050102020104",
                      "text": "Increased work of breathing, <b>≥ One:</b>",
                      "type": "group",
                      "repeats": true,
                      "readOnly": false,
                      "item": [{
                        "linkId": "AISD01530405010202010401",
                        "text": "Difficulty taking PO",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }, {
                        "linkId": "AISD01530405010202010402",
                        "text": "Prefers sitting",
                        "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530405010202010402&note_type=ALL_NOTES",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }, {
                        "linkId": "AISD01530405010202010403",
                        "text": "Talks in phrases",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }, {
                        "linkId": "AISD01530405010202010404",
                        "text": "Use of accessory muscles",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }]
                    }]
                  }, {
                    "linkId": "AISD0153040501020202",
                    "text": "Intervention, <b>Both:</b>",
                    "type": "group",
                    "repeats": true,
                    "readOnly": false,
                    "item": [{
                      "linkId": "AISD015304050102020201",
                      "text": "Bronchodilator ≥&nbsp;4x/24h (includes inhaled)",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304050102020201&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304050102020202",
                      "text": "Corticosteroid (includes PO or inhaled)",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304050102020202&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }]
                  }]
                }, {
                  "linkId": "AISD01530405010203",
                  "text": "Blood sugar ≤&nbsp;24h, <b>All:</b>",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530405010203&note_type=ALL_NOTES",
                  "type": "group",
                  "repeats": true,
                  "readOnly": false,
                  "item": [{
                    "linkId": "AISD0153040501020301",
                    "text": "Finding, <b>≥ One:</b>",
                    "type": "group",
                    "repeats": true,
                    "readOnly": false,
                    "item": [{
                      "linkId": "AISD015304050102030101",
                      "text": "&gt; 250&nbsp;mg/dL(13.9&nbsp;mmol/L)",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304050102030102",
                      "text": "&lt; 70&nbsp;mg/dL(3.9&nbsp;mmol/L)",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }]
                  }, {
                    "linkId": "AISD0153040501020302",
                    "text": "Blood sugar monitoring",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040501020303",
                    "text": "Insulin adjustment or dose held",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040501020303&note_type=ALL_NOTES",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }]
                }, {
                  "linkId": "AISD01530405010204",
                  "text": "Functional impairment (new) and rehabilitation initiation ≤ 24h",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530405010204&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530405010205",
                  "text": "Heart failure and, <b>Both:</b>",
                  "type": "group",
                  "repeats": true,
                  "readOnly": true,
                  "item": [{
                    "linkId": "AISD0153040501020501",
                    "text": "Dyspnea &gt; baseline and, <b>≥ One:</b>",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040501020501&note_type=ALL_NOTES",
                    "type": "group",
                    "repeats": true,
                    "readOnly": true,
                    "item": [{
                      "linkId": "AISD015304050102050101",
                      "text": "O<sub>2</sub> sat ≤ 91%(0.91) and &lt; baseline",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304050102050101&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304050102050102",
                      "text": "Worsening peripheral edema",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304050102050103",
                      "text": "Heart failure confirmed by imaging",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304050102050103&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }]
                  }, {
                    "linkId": "AISD0153040501020502",
                    "text": "Intervention, <b>≥ One:</b>",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040501020502&note_type=ALL_NOTES",
                    "type": "group",
                    "repeats": true,
                    "readOnly": false,
                    "item": [{
                      "linkId": "AISD015304050102050201",
                      "text": "Diuretic, <b>One:</b>",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304050102050201&note_type=ALL_NOTES",
                      "type": "group",
                      "repeats": true,
                      "readOnly": false,
                      "item": [{
                        "linkId": "AISD01530405010205020101",
                        "text": "≥ 2x/24h (includes PO)",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }, {
                        "linkId": "AISD01530405010205020102",
                        "text": "At least 1x/24h and requires daily medication adjustment (includes PO) and, <b>≥ One:</b>",
                        "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530405010205020102&note_type=ALL_NOTES",
                        "type": "group",
                        "repeats": true,
                        "readOnly": true,
                        "item": [{
                          "linkId": "AISD0153040501020502010201",
                          "text": "Blood urea nitrogen (BUN) increased from baseline",
                          "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040501020502010201&note_type=ALL_NOTES",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        }, {
                          "linkId": "AISD0153040501020502010202",
                          "text": "Creatinine increased from baseline",
                          "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040501020502010202&note_type=ALL_NOTES",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        }]
                      }]
                    }, {
                      "linkId": "AISD015304050102050202",
                      "text": "Dialysis",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }]
                  }]
                }, {
                  "linkId": "AISD01530405010206",
                  "text": "New onset infection, actual or suspected and, <b>Both:</b>",
                  "type": "group",
                  "repeats": true,
                  "readOnly": true,
                  "item": [{
                    "linkId": "AISD0153040501020601",
                    "text": "Finding, <b>≥ One:</b>",
                    "type": "group",
                    "repeats": true,
                    "readOnly": false,
                    "item": [{
                      "linkId": "AISD015304050102060101",
                      "text": "Temperature &gt;&nbsp;99.4°F(37.4°C) PO or &gt; 100.4°F(38.0°C) PR",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304050102060101&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304050102060102",
                      "text": "WBC ≥&nbsp;12,000/cu.mm(12x10<sup>9</sup>/L)",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304050102060103",
                      "text": "WBC ≤&nbsp;4,000/cu.mm(4 x10<sup>9</sup>/L)",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304050102060104",
                      "text": "Bands &gt;&nbsp;10%(0.10)",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304050102060105",
                      "text": "ANC &lt; 500/cu.mm(500x10<sup>6</sup>/L)",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304050102060105&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }]
                  }, {
                    "linkId": "AISD0153040501020602",
                    "text": "Intervention, <b>≥ One:</b>",
                    "type": "group",
                    "repeats": true,
                    "readOnly": false,
                    "item": [{
                      "linkId": "AISD015304050102060201",
                      "text": "Culture pending ≤ 2d",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304050102060202",
                      "text": "Drug−induced fever suspected and precipitating drug discontinued ≤&nbsp;3d",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304050102060202&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304050102060203",
                      "text": "Imaging study ≤ 24h",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }]
                  }]
                }, {
                  "linkId": "AISD01530405010207",
                  "text": "Pneumonia confirmed by imaging and, <b>Both:</b>",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530405010207&note_type=ALL_NOTES",
                  "type": "group",
                  "repeats": true,
                  "readOnly": true,
                  "item": [{
                    "linkId": "AISD0153040501020701",
                    "text": "Finding, <b>≥ One:</b>",
                    "type": "group",
                    "repeats": true,
                    "readOnly": false,
                    "item": [{
                      "linkId": "AISD015304050102070101",
                      "text": "Temperature, <b>≥ One:</b>",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304050102070101&note_type=ALL_NOTES",
                      "type": "group",
                      "repeats": true,
                      "readOnly": false,
                      "item": [{
                        "linkId": "AISD01530405010207010101",
                        "text": "&gt;&nbsp;99.4°F(37.4°C) PO",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }, {
                        "linkId": "AISD01530405010207010102",
                        "text": "&gt; 100.4°F(38.0°C) PR",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }]
                    }, {
                      "linkId": "AISD015304050102070102",
                      "text": "Mental status change (excludes coma, stupor, or obtundation) or GCS 9−14",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304050102070102&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304050102070103",
                      "text": "O<sub>2</sub> sat ≤ 91%(0.91) and &lt; baseline",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304050102070103&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304050102070104",
                      "text": "WBC ≥&nbsp;12,000/cu.mm(12x10<sup>9</sup>/L)",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304050102070105",
                      "text": "WBC ≤&nbsp;4,000/cu.mm(4 x10<sup>9</sup>/L)",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304050102070106",
                      "text": "Bands &gt;&nbsp;10%(0.10)",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }]
                  }, {
                    "linkId": "AISD0153040501020702",
                    "text": "Intervention, <b>≥ One:</b>",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040501020702&note_type=ALL_NOTES",
                    "type": "group",
                    "repeats": true,
                    "readOnly": false,
                    "item": [{
                      "linkId": "AISD015304050102070201",
                      "text": "Requiring supplemental oxygen",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304050102070201&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304050102070202",
                      "text": "Anti−infective (includes PO)",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304050102070203",
                      "text": "Respiratory interventions at least 6x/24h",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304050102070203&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }]
                  }]
                }, {
                  "linkId": "AISD01530405010208",
                  "text": "Post Critical care ≤ 24h",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }]
              }]
            }, {
              "linkId": "AISD0153040502",
              "text": "<b>INTERMEDIATE,</b> <b>≥ One:</b>",
              "type": "group",
              "repeats": true,
              "readOnly": false,
              "item": [{
                "linkId": "AISD015304050201",
                "text": "Troponin positive and acute coronary syndrome suspected (<b>use ACS subset</b>)",
                "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304050201&note_type=ALL_NOTES",
                "type": "boolean",
                "repeats": false,
                "readOnly": true,
                "item": []
              }, {
                "linkId": "AISD015304050202",
                "text": "Atrial fibrillation or atrial flutter, <b>≥ One:</b>",
                "type": "group",
                "repeats": true,
                "readOnly": false,
                "item": [{
                  "linkId": "AISD01530405020201",
                  "text": "Antiarrhythmic, continuous and hemodynamically stable",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530405020202",
                  "text": "Conversion from IV to PO antiarrhythmic and no proarrhythmic risk ≤ 24h",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530405020203",
                  "text": "Initiation of PO antiarrhythmic with proarrhythmic risk ≤ 3d and, <b>Both:</b>",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530405020203&note_type=ALL_NOTES",
                  "type": "group",
                  "repeats": true,
                  "readOnly": true,
                  "item": [{
                    "linkId": "AISD0153040502020301",
                    "text": "Continuous cardiac monitoring (excludes Holter)",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040502020301&note_type=ALL_NOTES",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040502020302",
                    "text": "Medication, <b>≥ One:</b>",
                    "type": "group",
                    "repeats": true,
                    "readOnly": false,
                    "item": [{
                      "linkId": "AISD015304050202030201",
                      "text": "Amiodarone",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304050202030201&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304050202030202",
                      "text": "Disopyramide",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304050202030203",
                      "text": "Dofetilide",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304050202030203&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304050202030204",
                      "text": "Dronedarone",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304050202030204&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304050202030205",
                      "text": "Propafenone",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304050202030206",
                      "text": "Quinidine",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304050202030207",
                      "text": "Sotalol",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }]
                  }]
                }]
              }, {
                "linkId": "AISD015304050203",
                "text": "Mechanical ventilation and, <b>One:</b>",
                "type": "group",
                "repeats": true,
                "readOnly": true,
                "item": [{
                  "linkId": "AISD01530405020301",
                  "text": "Respiratory intervention every 3−4h",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530405020301&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530405020302",
                  "text": "Weaning ≤ 2d",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530405020302&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }]
              }, {
                "linkId": "AISD015304050204",
                "text": "NIPPV and, <b>One:</b>",
                "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304050204&note_type=ALL_NOTES",
                "type": "group",
                "repeats": true,
                "readOnly": true,
                "item": [{
                  "linkId": "AISD01530405020401",
                  "text": "Respiratory intervention every 3−4h",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530405020401&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530405020402",
                  "text": "Weaning ≤ 2d",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530405020402&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }]
              }, {
                "linkId": "AISD015304050205",
                "text": "Oxygen ≥ 40%(0.40) ≤ 2d",
                "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304050205&note_type=ALL_NOTES",
                "type": "boolean",
                "repeats": false,
                "readOnly": true,
                "item": []
              }]
            }, {
              "linkId": "AISD0153040503",
              "text": "<b>CRITICAL,</b> <b>≥ One:</b>",
              "type": "group",
              "repeats": true,
              "readOnly": false,
              "item": [{
                "linkId": "AISD015304050301",
                "text": "Troponin positive and acute coronary syndrome suspected (<b>use ACS subset</b>)",
                "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304050301&note_type=ALL_NOTES",
                "type": "boolean",
                "repeats": false,
                "readOnly": true,
                "item": []
              }, {
                "linkId": "AISD015304050302",
                "text": "Atrial fibrillation or atrial flutter, <b>≥ One:</b>",
                "type": "group",
                "repeats": true,
                "readOnly": false,
                "item": [{
                  "linkId": "AISD01530405030201",
                  "text": "Urgent electrical cardioversion performed within last 24h",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530405030202",
                  "text": "Symptomatic recurrent or refractory arrhythmia requiring antiarrhythmic and, <b>≥ One:</b>",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530405030202&note_type=ALL_NOTES",
                  "type": "group",
                  "repeats": true,
                  "readOnly": true,
                  "item": [{
                    "linkId": "AISD0153040503020201",
                    "text": "Chest pain",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040503020202",
                    "text": "Heart failure and, <b>≥ One:</b>",
                    "type": "group",
                    "repeats": true,
                    "readOnly": true,
                    "item": [{
                      "linkId": "AISD015304050302020201",
                      "text": "Arterial Po<sub>2</sub> &lt; 56 mmHg(7.4 kPa)",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304050302020202",
                      "text": "O<sub>2</sub> sat &lt; 89%(0.89) and &lt; baseline",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }]
                  }, {
                    "linkId": "AISD0153040503020203",
                    "text": "Hemodynamic instability, <b>≥ One:</b>",
                    "type": "group",
                    "repeats": true,
                    "readOnly": false,
                    "item": [{
                      "linkId": "AISD015304050302020301",
                      "text": "Heart rate &gt;&nbsp;120/min, sustained",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304050302020301&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304050302020302",
                      "text": "Systolic blood pressure, <b>≥ One:</b>",
                      "type": "group",
                      "repeats": true,
                      "readOnly": false,
                      "item": [{
                        "linkId": "AISD01530405030202030201",
                        "text": "&lt; 90 mmHg",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }, {
                        "linkId": "AISD01530405030202030202",
                        "text": "&lt; 110 mmHg with chronic hypertension",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }, {
                        "linkId": "AISD01530405030202030203",
                        "text": "&gt; 30 mmHg decrease from baseline",
                        "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530405030202030203&note_type=ALL_NOTES",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }, {
                        "linkId": "AISD01530405030202030204",
                        "text": "Labile",
                        "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530405030202030204&note_type=ALL_NOTES",
                        "type": "boolean",
                        "repeats": false,
                        "readOnly": true,
                        "item": []
                      }]
                    }, {
                      "linkId": "AISD015304050302020303",
                      "text": "MAP &lt;&nbsp;65&nbsp;mmHg",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }]
                  }]
                }]
              }, {
                "linkId": "AISD015304050303",
                "text": "Bronchodilator every 1−2h (includes inhaled)",
                "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304050303&note_type=ALL_NOTES",
                "type": "boolean",
                "repeats": false,
                "readOnly": true,
                "item": []
              }, {
                "linkId": "AISD015304050304",
                "text": "ECMO or ECLS",
                "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304050304&note_type=ALL_NOTES",
                "type": "boolean",
                "repeats": false,
                "readOnly": true,
                "item": []
              }, {
                "linkId": "AISD015304050305",
                "text": "Hemodynamic instability, <b>Both:</b>",
                "type": "group",
                "repeats": true,
                "readOnly": false,
                "item": [{
                  "linkId": "AISD01530405030501",
                  "text": "Finding, <b>≥ One:</b>",
                  "type": "group",
                  "repeats": true,
                  "readOnly": false,
                  "item": [{
                    "linkId": "AISD0153040503050101",
                    "text": "Heart rate &gt;&nbsp;120/min, sustained",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040503050101&note_type=ALL_NOTES",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040503050102",
                    "text": "Systolic blood pressure, <b>≥ One:</b>",
                    "type": "group",
                    "repeats": true,
                    "readOnly": false,
                    "item": [{
                      "linkId": "AISD015304050305010201",
                      "text": "&lt; 90 mmHg",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304050305010202",
                      "text": "&lt; 110 mmHg with chronic hypertension",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304050305010203",
                      "text": "&gt; 30 mmHg decrease from baseline",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304050305010203&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304050305010204",
                      "text": "Labile",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304050305010204&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }]
                  }, {
                    "linkId": "AISD0153040503050103",
                    "text": "MAP &lt;&nbsp;65&nbsp;mmHg",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }]
                }, {
                  "linkId": "AISD01530405030502",
                  "text": "Intervention, <b>≥ One:</b>",
                  "type": "group",
                  "repeats": true,
                  "readOnly": false,
                  "item": [{
                    "linkId": "AISD0153040503050201",
                    "text": "Blood product transfusion",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040503050202",
                    "text": "IV fluid resuscitation ≤ 2d",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040503050202&note_type=ALL_NOTES",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }]
                }]
              }, {
                "linkId": "AISD015304050306",
                "text": "Hemodynamic monitoring, invasive",
                "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304050306&note_type=ALL_NOTES",
                "type": "boolean",
                "repeats": false,
                "readOnly": true,
                "item": []
              }, {
                "linkId": "AISD015304050307",
                "text": "Mechanical ventilation and, <b>≥ One:</b>",
                "type": "group",
                "repeats": true,
                "readOnly": true,
                "item": [{
                  "linkId": "AISD01530405030701",
                  "text": "&lt; 3 weaning attempts",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530405030701&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530405030702",
                  "text": "Airway protection",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530405030702&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530405030703",
                  "text": "FiO<sub>2</sub> &gt; 50%(0.50)",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530405030704",
                  "text": "PEEP &gt; 10 cm H<sub>2</sub>O",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530405030705",
                  "text": "Neuromuscular blocker",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530405030706",
                  "text": "Respiratory intervention every 1−2h",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530405030706&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }]
              }, {
                "linkId": "AISD015304050308",
                "text": "NIPPV and, <b>One:</b>",
                "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304050308&note_type=ALL_NOTES",
                "type": "group",
                "repeats": true,
                "readOnly": true,
                "item": [{
                  "linkId": "AISD01530405030801",
                  "text": "Continued intervention required, <b>≥ One:</b>",
                  "type": "group",
                  "repeats": true,
                  "readOnly": false,
                  "item": [{
                    "linkId": "AISD0153040503080101",
                    "text": "FiO<sub>2</sub> &gt; 50%(0.50)",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040503080102",
                    "text": "PEEP &gt; 10 cm H<sub>2</sub>O",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040503080103",
                    "text": "Respiratory intervention every 1−2h",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040503080103&note_type=ALL_NOTES",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }]
                }, {
                  "linkId": "AISD01530405030802",
                  "text": "Weaning ≤ 24h",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530405030802&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }]
              }, {
                "linkId": "AISD015304050309",
                "text": "Vasopressor, vasodilator, or inotrope, continuous (excludes low or fixed dose for end stage heart failure)",
                "type": "boolean",
                "repeats": false,
                "readOnly": true,
                "item": []
              }]
            }]
          }, {
            "resourceType": "Questionnaire",
            "id": "AISD01530406",
            "name": "<b>Episode Day 7</b>",
            "item": [{
              "linkId": "AISD0153040601",
              "text": "<b>ACUTE,</b> <b>One:</b>",
              "type": "group",
              "repeats": true,
              "readOnly": false,
              "item": [{
                "linkId": "AISD015304060101",
                "text": "<b>Responder,</b> discharge expected today if clinically stable last 12h, <b>All:</b>",
                "type": "group",
                "repeats": true,
                "readOnly": false,
                "item": [{
                  "linkId": "AISD01530406010101",
                  "text": "Afebrile",
                  "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD01530406010101&note_type=ALL_NOTES",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530406010102",
                  "text": "Oxygenation, <b>≥ One:</b>",
                  "type": "group",
                  "repeats": true,
                  "readOnly": false,
                  "item": [{
                    "linkId": "AISD0153040601010201",
                    "text": "O<sub>2 </sub>sat ≥&nbsp;92%(0.92) or within acceptable limits",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040601010201&note_type=ALL_NOTES",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040601010202",
                    "text": "No change in oxygen requirements last 2d",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }]
                }, {
                  "linkId": "AISD01530406010103",
                  "text": "Dyspnea improving",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530406010104",
                  "text": "Complication or comorbidity, <b>One:</b>",
                  "type": "group",
                  "repeats": true,
                  "readOnly": false,
                  "item": [{
                    "linkId": "AISD0153040601010401",
                    "text": "No complication or active comorbidity relevant to this episode of care",
                    "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD0153040601010401&note_type=ALL_NOTES",
                    "type": "boolean",
                    "repeats": false,
                    "readOnly": true,
                    "item": []
                  }, {
                    "linkId": "AISD0153040601010402",
                    "text": "Complication or comorbidity and clinically stable for discharge, <b>≥ One:</b>",
                    "type": "group",
                    "repeats": true,
                    "readOnly": false,
                    "item": [{
                      "linkId": "AISD015304060101040201",
                      "text": "ANC ≥&nbsp;500/cu.mm(500x10<sup>6</sup>/L)",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304060101040201&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304060101040202",
                      "text": "Blood sugar within acceptable limits",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304060101040202&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304060101040203",
                      "text": "Functional evaluation complete",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304060101040203&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }, {
                      "linkId": "AISD015304060101040204",
                      "text": "WBC within acceptable limits",
                      "definition": "/caas/content/notes?subset_unique_id=353625&id=AISD015304060101040204&note_type=ALL_NOTES",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }]
                  }]
                }]
              }, {
                "linkId": "AISD015304060102",
                "text": "<b>Non−responder</b>, not clinically stable for discharge and exceeds episode days at the Acute level of care for this condition, <b>One:</b>",
                "type": "group",
                "repeats": true,
                "readOnly": false,
                "item": [{
                  "linkId": "AISD01530406010201",
                  "text": "<b>Use Extended Stay subset</b>",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530406010202",
                  "text": "Refer for secondary review",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }]
              }]
            }, {
              "linkId": "AISD0153040602",
              "text": "<b>INTERMEDIATE,</b> <b>One:</b>",
              "type": "group",
              "repeats": true,
              "readOnly": false,
              "item": [{
                "linkId": "AISD015304060201",
                "text": "<b>Non−responder</b>, not clinically stable for discharge and exceeds episode days at the Intermediate level of care for this condition, <b>One:</b>",
                "type": "group",
                "repeats": true,
                "readOnly": false,
                "item": [{
                  "linkId": "AISD01530406020101",
                  "text": "<b>Use Extended Stay subset</b>",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530406020102",
                  "text": "Refer for secondary review",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }]
              }]
            }, {
              "linkId": "AISD0153040603",
              "text": "<b>CRITICAL,</b> <b>One:</b>",
              "type": "group",
              "repeats": true,
              "readOnly": false,
              "item": [{
                "linkId": "AISD015304060301",
                "text": "<b>Non−responder</b>, not clinically stable for discharge and exceeds episode days at the Critical level of care for this condition, <b>One:</b>",
                "type": "group",
                "repeats": true,
                "readOnly": false,
                "item": [{
                  "linkId": "AISD01530406030101",
                  "text": "<b>Use Extended Stay subset</b>",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }, {
                  "linkId": "AISD01530406030102",
                  "text": "Refer for secondary review",
                  "type": "boolean",
                  "repeats": false,
                  "readOnly": true,
                  "item": []
                }]
              }]
            }]
          }]
        }
      }
    }
  };
  beforeEach(() => {
    fixture = TestBed.createComponent(GuidelineSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

   
    
    
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should editButton()', () => {
    component.editButton();
    expect(component.editButton).toBeTruthy();

  });
  
  // it('should getGuidelineSummary', () => {
  //   spyOn(guidelineSummaryService, 'getGuidelineData').and.returnValue(of(response));
  //   component.getGuidelineSummary();
  //   expect(component.getGuidelineSummary).toBeTruthy();
  // });

  // it('should getGuidelineSummary exception', () => {
  //   spyOn(guidelineSummaryService, 'getGuidelineData').and.throwError(new Error)('error');
  //   component.getGuidelineSummary();
  //   // expect(component.getGuidelineSummary).toBeTruthy();
  // });

});
