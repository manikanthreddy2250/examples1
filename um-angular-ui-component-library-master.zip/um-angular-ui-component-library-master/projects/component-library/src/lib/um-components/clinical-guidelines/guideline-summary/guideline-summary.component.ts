import { Component, OnInit, Input, Output, EventEmitter, AfterViewInit, OnChanges, SimpleChanges } from '@angular/core';
import { GuidelineSummaryService } from '../../services/um/service/clinical-guidelines/guideline-summary/guideline-summary.service';
import { GuidelinesConstants } from '../../../constant/guidelines-constants';

@Component({
  selector: 'ecp-ucl-guideline-summary',
  templateUrl: './guideline-summary.component.html',
  styleUrls: ['./guideline-summary.component.scss']
})
export class GuidelineSummaryComponent implements OnInit {
  @Input() guidelineId: string;
  @Input() version: string;
  @Input() isDirectNav: boolean = true;
  @Input() expanded : boolean = true;
  @Output() start: EventEmitter<any> = new EventEmitter();
  @Output() previous: EventEmitter<any> = new EventEmitter();
  @Output() editReview: EventEmitter<boolean> = new EventEmitter();
  @Input() showDocProcess : boolean = true;
  currentBtnValue = 'Document';
  speed = '2s';
  showDoc = true;
  showSpinner = false;
  overviewTextSummary: any;
  productDescription: any;
  versionDescription: any;
  header: any;
  counter: number;
  citationData = [];
  _overlayOpen = false;
  editBtn = GuidelinesConstants.EDIT;
  returnTitle: number;
  k = 1;
  j = 1;
  contents: string;
  errorConfig = {
    id: 'error_msg',
    pageNotificationType: 'error',
    content: 'Unexpected error occurred. Please try again later.',
    triggerElementId: 'trigger-button',
  };

  constructor(
    private readonly guidelineSummaryService: GuidelineSummaryService,
  ) { }

  ngOnInit() {
    this.getGuidelineSummary();
  }

  getGuidelineSummary() {
    const guidelineId = this.guidelineId;
    const version = this.version;
    console.log(guidelineId, version);
    this.showSpinner = true;
    this.guidelineSummaryService.getGuidelineData(guidelineId, version).subscribe(
      (resp: any) => {
        const res = resp?.data?.getGuidelineReview?.reviewResponse;
        this.productDescription = res['name'];
        this.versionDescription = res['title'];
        this.overviewTextSummary = res['text'];
        this.showSpinner = false;
      }, err => {
        this.showSpinner = true;
      });
  }

  editButton() {
    this.editReview.emit(true)
  }

}
