import { NgModule } from '@angular/core';
import { APP_BASE_HREF, CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatIconModule } from '@angular/material/icon';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from "@angular/forms";
import { FooterModule } from '../footer/footer.module';
import { GuidelineSummaryComponent } from './guideline-summary.component';
import { TabsModule} from '@ecp/angular-ui-component-library/tabs';
import { ButtonModule} from '@ecp/angular-ui-component-library/button';
import { IconsModule} from '@ecp/angular-ui-component-library/icons';
import {TableModule} from '@ecp/angular-ui-component-library/table';
import {SortModule} from '@ecp/angular-ui-component-library/sort';
import {LinkModule} from '@ecp/angular-ui-component-library/link';
import {RadioButtonModule} from '@ecp/angular-ui-component-library/radio-button';
import { CardModule } from '@ecp/angular-ui-component-library/card';
import { TagsModule } from '@ecp/angular-ui-component-library/tags';
import { CheckboxModule } from '@ecp/angular-ui-component-library/checkbox';
import { AccordianModule} from '@ecp/angular-ui-component-library/accordian';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import { ProgressSpinnerModule } from '@ecp/angular-ui-component-library/progress-spinner';
import { MatSidenavModule } from '@angular/material/sidenav';
import {UserAuthService} from "../../services/auth/user.service";
import {OAuthService, UrlHelperService} from 'angular-oauth2-oidc';
import {ButtonGroupModule} from '@ecp/angular-ui-component-library/button-group';
import { IndexUtilityModule } from '../index-utility/index-utility.module';
import { DocumentUtilityModule } from '../document-utility/document-utility.module';



@NgModule({
  declarations: [
    GuidelineSummaryComponent
  ],

  imports: [
    CommonModule,
    BrowserModule,
    BrowserAnimationsModule,
    MatGridListModule,
    MatIconModule,
    TableModule,
    ButtonModule,
    ButtonGroupModule,
    TabsModule,
    IconsModule,
    TagsModule,
    SortModule,
    LinkModule,
    CardModule,
    CheckboxModule,
    HttpClientModule,
    RadioButtonModule,
    FormsModule,
    FooterModule,
    AccordianModule,
    ProgressSpinnerModule,
    MatSidenavModule,
    DocumentUtilityModule,
    IndexUtilityModule
  ],
  exports: [
    GuidelineSummaryComponent
  ],
  providers: [{ provide: APP_BASE_HREF, useValue: '/' }],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class GuidelineSummaryModule { }
