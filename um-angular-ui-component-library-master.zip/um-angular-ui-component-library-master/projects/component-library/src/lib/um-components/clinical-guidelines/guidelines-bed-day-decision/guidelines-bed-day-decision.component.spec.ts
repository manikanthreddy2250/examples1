import {async, ComponentFixture, fakeAsync, TestBed, tick} from '@angular/core/testing';
import {BedDayDecisionService} from '../../services/um/service/clinical-guidelines/guideline-bed-day-decision-service/bed-day-decision.service';
import {GuidelinesBedDayDecisionComponent} from 'projects/component-library/src/lib/um-components/clinical-guidelines/guidelines-bed-day-decision/guidelines-bed-day-decision.component';
import {NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA, ChangeDetectorRef, Injectable} from '@angular/core';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import {HttpClient, HttpHandler} from '@angular/common/http';
import {of} from 'rxjs';
import {MicroProductAuthService} from '@ecp/auth-library';
import {LoggerConfig, NGXLogger, NGXLoggerHttpService, NGXMapperService} from 'ngx-logger';
import {DatePipe} from '@angular/common';
import {GuidelinesUtils} from 'projects/component-library/src/lib/um-components/clinical-guidelines/shared/guidelines-utils';
import {OAuthLogger, OAuthService, UrlHelperService} from 'angular-oauth2-oidc';
import {RouterTestingModule} from '@angular/router/testing';
import {GuidelinesBedDayModule} from "./guidelines-bed-day.module";


@Injectable()
class MicroProductAuthServiceStub {
  getEcpClaims() {
    return {
      'x-ecp-claims': {
        'x-ecp-attrs': {},
        'x-ecp-alt-user-id': '',
        'x-ecp-cli-orgs': [{
          'org-id': 'ecp',
          'func-roles': [{
            'role-name': 'rules_admin',
            'appl-roles': ['clinical_guidelines_cds_nurse']
          }]
        }],
        'x-ecp-first-name': 'Sahithya',
        'x-ecp-type': 'PASSWORD',
        'x-ecp-user-id': '001173408',
        'x-ecp-email': 'sahithya_sivaraju@optum.com',
        'x-ecp-last-name': 'Pachipulusu Sivaraju',
        'x-ecp-source': 'msid'
      },
      'https://hasura.io/jwt/claims': {
        'x-hasura-default-role': 'autoapproval-dmn_deploy',
        'x-hasura-attrs': '{ }',
        'x-hasura-cli-org': 'ecp',
        'x-hasura-user-id': '001173408',
        'x-hasura-func-role': 'rules_admin',
        'x-hasura-allowed-roles': ['autoapproval-dmn_deploy', 'autorouting-dmn_deploy', 'bpm_execute_all', 'case_wf_mgmt_ui_read', 'configuration-dmn_deploy', 'example_dmn_grp_deploy', 'health_srvc_delete', 'icuerules-dmn_deploy', 'memberblocking-dmn_deploy', 'obsderivation-dmn_deploy', 'programs-dmn_deploy', 'rules_authoring_write', 'siteofservice-dmn_deploy', 'system_mgmt_user', 'testharness-dmn_deploy', 'um_intake_ui_read', 'umintake_sos_mbr_elig_dmn_grp_deploy', 'umintake_sos_prov_elig_dmn_grp_deploy']
      },
      scope: 'openid',
      iss: 'ecp-dev',
      exp: 1603473684,
      client_id: 'ecp_platform'
    };
  }

  getUserRoles() {
    return 'clinical_guidelines_cds_nurse';
  }

  getEcpOrgId() {
    return 'TESTUSERID';
  }

  getEcpToken() {
    return 'testToken';
  }

  isLocalHost() {
    return false;
  }

  getHasuraRole() {
    return 'clinical_guidelines_md';
  }

}
describe('BedDayDecisionComponent', () => {
  let component: GuidelinesBedDayDecisionComponent;
  let bedDayDecisionService: BedDayDecisionService;
  let fixture: ComponentFixture<GuidelinesBedDayDecisionComponent>;
  let httpClient: HttpClient;


  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [GuidelinesBedDayModule],
      declarations: [],
      providers: [BedDayDecisionService, { provide: MicroProductAuthService, useClass: MicroProductAuthServiceStub }],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]

    })
      .compileComponents();
  }));
  beforeEach(() => {
    fixture = TestBed.createComponent(GuidelinesBedDayDecisionComponent);
    httpClient = TestBed.inject(HttpClient);
    bedDayDecisionService = TestBed.inject(BedDayDecisionService);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call ngOnInit', () => {
    component.isAutoReviewFlag = true
    component.isAutoReview = true
    component.ngOnInit()
    expect(component.ngOnInit).toBeTruthy();
  });

  // it('should save update review when decision is escalated', () => {
  //   const bedDayReponse: any = {
  //     data: {
  //       saveBedDay: {
  //         beddayRes: [
  //           {
  //             updateClinicalGuidResponse: {
  //               beddayRes: {
  //                 update_hsc_clin_guid_by_pk: {
  //                   clin_rev_sts_ref_id: 72755,
  //                   hsc_clin_guid_id: 1668,
  //                   chg_dttm: '2021-04-29T21:07:03.929'
  //                 }
  //               }
  //             }
  //           },
  //           {
  //             hscDecnResponse: {
  //               beddayRes: {}
  //             }
  //           },
  //           {
  //             hscDecnBedDayResponse: {
  //               beddayRes: {}
  //             }
  //           }
  //         ]
  //       }
  //     }
  //   };

  //   // spyOn(bedDayDecisionService, 'saveBedDayDecisionInfo').and.returnValue(of(bedDayReponse));
  //   const userspy = spyOn(bedDayDecisionService, 'saveBedDayDecisionInfo').and.returnValue(bedDayReponse);
  //   const bedDayData = {
  //     BedDayCount: '1',
  //     date: new Date(),
  //     Decision: 'Escalate',
  //     hscID: 11186,
  //     hscClinGuidID: 1727
  //   };

  //   component.saveDecision();
  //   // expect(bedDayDecisionService.saveBedDayDecisionInfo).toHaveBeenCalledWith(bedDayData);
  //   expect(component.saveDecision).toBeTruthy();
  // });


  xit('should save Bed Day decision when decision is approved', () => {
    const bedDayReponse: any = {
      data: {
        saveBedDay: {
          beddayRes: [
            {
              updateClinicalGuidResponse: {
                beddayRes: {}
              }
            },
            {
              hscDecnResponse: {
                res: {
                  insert_hsc_decn: {
                    affected_rows: 1,
                    returning: [
                      {
                        hsc_decn_id: 1076,
                        creat_dttm: '2021-05-03T21:52:31.091',
                        decn_typ_ref_id: null,
                        decn_otcome_ref_id: 72765,
                        decn_rsn_ref_id: null,
                        decn_made_by_user_id: null,
                        decn_made_by_user_org_desc: null,
                        hsc_id: 11186
                      }
                    ]
                  }
                }
              }
            },
            {
              hscDecnBedDayResponse: {
                res: {
                  insert_hsc_decn_bed_day: {
                    affected_rows: 1,
                    returning: [
                      {
                        hsc_decn_id: 1076,
                        strt_bed_dt: '2021-05-01',
                        bed_typ_ref_id: null,
                        accum_bed_day_cnt: 1,
                        decn_rndr_dttm_facl_lcl_txt: null,
                        decn_facl_cmnct_dttm: null
                      }
                    ]
                  }
                }
              }
            }
          ]
        }
      }
    };

   // spyOn(bedDayDecisionService, 'saveBedDayDecisionInfo').and.returnValue(of(bedDayReponse));
    const userspy = spyOn(bedDayDecisionService, 'saveBedDayDecisionInfo').and.returnValue(bedDayReponse);
    const bedDayData = {
      BedDayCount: '1',
      date: new Date(),
      Decision: 'Escalate',
      hscID: 11186,
      hscClinGuidID: 1727
    };
    component.saveDecision();
    expect(component.saveDecision).toBeTruthy();
  });

  // it('should not save Bed Day decision when error', () => {
  //   const bedDayReponse: any = {
  //     errors: [{
  //       message: 'error'
  //     }]
  //   };
  //  // spyOn(bedDayDecisionService, 'saveBedDayDecisionInfo').and.returnValue(of(bedDayReponse));
  //   const userspy = spyOn(bedDayDecisionService, 'saveBedDayDecisionInfo').and.returnValue(bedDayReponse);
  //   const bedDayData = {
  //     BedDayCount: '1',
  //     date: new Date(),
  //     Decision: 'Approve',
  //     hscID: 11186,
  //     hscClinGuidID: 1727
  //   };

  //   component.saveDecision();
  //   // expect(bedDayDecisionService.saveBedDayDecisionInfo).toHaveBeenCalledWith(bedDayData);
  //   expect(component.saveDecision).toBeTruthy();
  // });

  it('should call getAccumulatedBedDay method', () => {
    const accumulatedBedDay: any = {
      errors: [{
        message: 'error'
      }]
    };
    component.hscID = '11186';
   // spyOn(bedDayDecisionService, 'getAccumulatedBedDay').and.returnValue(of(accumulatedBedDay));
    const userspy = spyOn(bedDayDecisionService, 'getAccumulatedBedDay').and.returnValue(accumulatedBedDay);
    component.getAccumulatedBedDay();
    expect(component.getAccumulatedBedDay).toBeTruthy();
  });
  it('should call getHscClinGuidID method', () => {
    component.loadMedicalReviewTree = true;
    component.hscClinGuidID = '2819';
    component.primaryClinicalID = '2819';
    component.hscID = '11186';
    component.getHscClinGuidID();
    expect(component.getHscClinGuidID).toBeTruthy();
  });

  xit('should call getLatestEscalatedClinGuidID method', () => {
    const escalatedGuidData: any = {
      "data": {
        "hsc_clin_guid": [{
          "hsc_clin_guid_id": 2819,
          "clin_rev_desc": "TIA Initial review",
          "clin_rev_otcome_ref_id": 3,
          "clin_rev_sys_rec_id": "20922cad-8d70-4869-be42-8fbb8c352e6a",
          "clin_rev_sys_ref_id": null,
          "clin_rev_sts_ref_id": 72755,
          "clin_rev_sts_ref_cd": {
            "ref_desc": "Escalated"
          },
          "hsc_srvc_id": null,
          "med_nec_ind": 1,
          "updt_ver_nbr": 0
        }]
      }
    };
    component.hscID = '11186';
    // spyOn(bedDayDecisionService, 'getAccumulatedBedDay').and.returnValue(of(accumulatedBedDay));
    const userspy = spyOn(bedDayDecisionService, 'getLatestEscalatedGuidID').and.returnValue(escalatedGuidData);
    component.getLatestEscalatedClinGuidID();
    expect(component.getLatestEscalatedClinGuidID).toBeTruthy();
  });


  it('should call getAccumulatedBedDay method - error', () => {
    const accumulatedBedDay: any = {
      data: {
        hsc_decn_aggregate: {
          aggregate: {
            sum: {
              decn_bed_day_cnt: 217
            }
          }
        }
      }
    };
    component.hscID = '11186';
   // spyOn(bedDayDecisionService, 'getAccumulatedBedDay').and.returnValue(of(accumulatedBedDay));
    const userspy = spyOn(bedDayDecisionService, 'getAccumulatedBedDay').and.returnValue(accumulatedBedDay);
    component.getAccumulatedBedDay();
    expect(component.getAccumulatedBedDay).toBeTruthy();
  });

  it('should call getClinicalReviewDescription method', () => {
    const clinicalReviewDescription: any = {
      data: {
        hsc_clin_guid: [{
          clin_rev_desc: 'Infection: General Initial review',
          creat_user_id: '001349337',
          clin_guid_id: 'AISD0153',
          chg_dttm: '2021-06-07T16:05:38.543'
        }]
      }
    };
   // spyOn(bedDayDecisionService, 'getClinicalReviewDescription').and.returnValue(of(clinicalReviewDescription));
    const userspy = spyOn(bedDayDecisionService, 'getClinicalReviewDescription').and.returnValue(clinicalReviewDescription);
    component.hscClinGuidID = '2731';
    component.clinicalReviewDescription();
    expect(component.clinicalReviewDescription).toBeTruthy();
  });

  it('should call getClinicalReviewDescription method - error', () => {
    const clinicalReviewDescription: any = {
      errors: [{
        message: 'error'
      }]
    };
   // spyOn(bedDayDecisionService, 'getClinicalReviewDescription').and.returnValue(of(clinicalReviewDescription));
    const userspy = spyOn(bedDayDecisionService, 'getClinicalReviewDescription').and.returnValue(clinicalReviewDescription);
    component.hscID = '11186';
    component.clinicalReviewDescription();
    expect(component.clinicalReviewDescription).toBeTruthy();
  });

  it('should saveBedDayNotes', () => {
    const res: any = {
      data: {
        saveBedDayNotes: {
          data: {
            insert_hsr_note_sbj: {
              affected_rows: 2,
              returning: [
                {
                  hsr_note: {
                    hsc_id: 11186,
                    note_txt_lobj: 'Testing sample',
                    hsr_note_id: 4266
                  }
                }
              ]
            }
          }
        }
      }
    };
   // spyOn(bedDayDecisionService, 'saveBeddayNotes').and.returnValue(of(res));
    const userspy = spyOn(bedDayDecisionService, 'saveBeddayNotes').and.returnValue(res);
    const bedDayData = {
      hscID: 11186,
      hscClinGuidID: '1727',
      noteText: 'Testing Notes'
    };
    component.saveBedDayNotes();
    expect(component.saveBedDayNotes).toBeTruthy();
  });

  it('should call getBedDayNotes method', () => {
    const res: any = {
      data: {
        getBedDayNotes: {
          data: {
            hsr_note_sbj: [
              {
                hsr_note_id: 4253,
                note_sbj_rec_id: '1727',
                hsr_note: {
                  note_txt_lobj: 'Testing Notes'
                }
              }
            ]
          }
        }
      }
    };
   // spyOn(bedDayDecisionService, 'getBedDayNotes').and.returnValue(of(res));
    const userspy = spyOn(bedDayDecisionService, 'getBedDayNotes').and.returnValue(res);
    const bedDayReq =
      {
        hsc_id: 11186,
        hsc_clin_guid_id: '1727'
      };
    component.getBedDayNotes();
    expect(component.getBedDayNotes).toBeTruthy();
  });


  xit('should completeReview()', () => {
    component.completeReview('$event');
    expect(component).toBeTruthy();
  });

  /*it('should previousComponent()', () => {
    component.previousComponent('$event');
    expect(component).toBeTruthy();
  });*/

  /*it('should be call getRole', () => {
    expect(component.getRole()).toBeTruthy();

  });*/

  it('should getError()', () => {
    const e = true;
    component.error = e;
    component.getError(e);
    expect(component.getError).toBeTruthy();
  });

  it('should showErrorMessage()', () => {
    const error = true;
    component.showErrorMessage(error);
    expect(component.showErrorMessage).toBeTruthy();
  });

  it('should saveBedDayNotes when error', () => {
    const res: any = {errors: [{message: 'Token is Invalid.'}], data: null};
   // spyOn(bedDayDecisionService, 'saveBeddayNotes').and.returnValue(of(res));
    const userspy = spyOn(bedDayDecisionService, 'saveBeddayNotes').and.returnValue(res);
    const bedDayData = {
      hscID: 11186,
      hscClinGuidID: '1727',
      noteText: 'Testing Notes'
    };
    component.saveBedDayNotes();
    expect(component.saveBedDayNotes).toBeTruthy();
  });

});

