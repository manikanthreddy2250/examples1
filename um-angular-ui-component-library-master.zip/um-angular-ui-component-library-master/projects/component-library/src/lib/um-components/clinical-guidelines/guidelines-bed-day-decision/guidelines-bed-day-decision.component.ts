import { Component, OnInit, Output, EventEmitter, ViewChild, AfterViewInit, Input, AfterContentChecked, ChangeDetectorRef, ViewEncapsulation } from '@angular/core';
import { EcpUclTableDataSource } from '@ecp/angular-ui-component-library/table';
import { EcpUclSort } from '@ecp/angular-ui-component-library/sort';
import { BedDayDecisionService } from '../../services/um/service/clinical-guidelines/guideline-bed-day-decision-service/bed-day-decision.service';
import {MicroProductAuthService} from '@ecp/auth-library';
import {MedicalReviewTreeComponent} from '../medical-review-tree/medical-review-tree.component';
import {ROLE_MD, ROLE_NURSE} from '../../../config/config-constants';
import {EcpUclModal} from '@ecp/angular-ui-component-library/modal';

@Component({
  selector: 'ecp-ucl-bed-day-decision',
  templateUrl: './guidelines-bed-day-decision.component.html',
  styleUrls: ['./guidelines-bed-day-decision.component.scss']
})
export class GuidelinesBedDayDecisionComponent implements OnInit, AfterContentChecked, AfterViewInit {

  bedDayLable = 'BedDay';
  headers = ['BedDay', 'Date', 'Decision'];
  episode: any;
  bedDayModel: any;
  @ViewChild(EcpUclModal, {static: true})
  modal: EcpUclModal;
  error = false;
  errorConfig = {
    id: 'error_msg',
    pageNotificationType: 'error',
    content: 'Unexpected error occurred. Please try again later.',
    triggerElementId: 'trigger-button',
  };

  @Input() hscID: any;
  @Input() hscClinGuidID: string;
  @Input() processTaskExecutionID: string;
  @Input() application: string;
  @Input() version: string;
  @Input() guidelineId: string;
  @Input() noteText: string;
  @Input() reviewId: string;
  @Input() primaryClinicalID: any;
  @Input() metStat: any;
  @ViewChild(MedicalReviewTreeComponent) medicalReviewTreeComponent: MedicalReviewTreeComponent;

  @Input() isDirectNav = true;
  @Input() isCompleteReviewFlag:boolean
  @Input() isAutoReviewFlag:boolean
  @Output() complete: EventEmitter<any> = new EventEmitter();
  @Output() previous: EventEmitter<any> = new EventEmitter();
  @Output() editReview: EventEmitter<boolean> = new EventEmitter();
  isLastPage  = true;
  text: any;

  isRoleMD = false;
  isRoleNurse = false;
  loadMedicalReviewTree = false;
  ecpClaimsVal = 'x-ecp-claims';
  ecpCliOrgsVal = 'x-ecp-cli-orgs';
 // hscClinicalGuidelineID: any;

  disableTextArea = false;
  bedDayData = [
    {
      BedDay: '1',
      date: new Date(),
      Decision: 'Approved'
    }
  ];

  dataSource: EcpUclTableDataSource<any>;
  @ViewChild(EcpUclSort) sort: EcpUclSort;
  //isCompleteReview: boolean = false ;
  isAutoReview: boolean = false;

  constructor(private readonly cdref: ChangeDetectorRef, private readonly bedDayDecisionService: BedDayDecisionService,
              private readonly microProductAuthService: MicroProductAuthService) {
  }

 async ngOnInit(): Promise<any> {
   if(this.isAutoReviewFlag === true){
     this.isAutoReview = true
   }
    this.disableTextArea = false;
    this.bedDayLable = `${this.bedDayData.length} BedDay`;
    this.dataSource = new EcpUclTableDataSource(this.bedDayData);
    this.bedDayModel = {
      decision: ' '
    };
   await this.getAccumulatedBedDay();
   await this.clinicalReviewDescription();
    this.getRole();
  }

  ngAfterContentChecked() {
    this.cdref.detectChanges();
  }

  ngAfterViewInit() {
    this.dataSource.sort = this.sort;
  }

  async getHscClinGuidID(): Promise<any>{
    if (this.hscClinGuidID != null) {
      this.hscClinGuidID = this.hscClinGuidID;
      this.loadMedicalReviewTree = true;
    } else if (this.primaryClinicalID != null) {
      this.hscClinGuidID = this.primaryClinicalID;
      this.loadMedicalReviewTree = true;
    } else {
      await this.getLatestEscalatedClinGuidID();
      this.loadMedicalReviewTree = true;
    }
  }

  async getLatestEscalatedClinGuidID(): Promise<any> {
    console.log('getLatestEscalatedClinGuidID');
    const res = await this.bedDayDecisionService.getLatestEscalatedGuidID(this.hscID);
    console.log("latest escalated guid:"+ JSON.stringify(res));
    this.hscClinGuidID = res.data.hsc_clin_guid[0].hsc_clin_guid_id;
    this.reviewId = res.data.hsc_clin_guid[0].clin_rev_sys_rec_id;
    this.episode = res.data.hsc_clin_guid[0]?.clin_rev_desc;
    console.log(' this.hscClinGuidID ' +  this.hscClinGuidID + ' this.reviewId ' + this.reviewId );
  }

  async saveDecision(): Promise<any> {
    const bedDayData = {
      BedDayCount: '1',
      date: new Date(),
      Decision: this.bedDayModel?.decision,
      hscID: parseInt(this.hscID),
      hscClinGuidID: parseInt(this.hscClinGuidID),
      processTaskExecutionID: this.processTaskExecutionID
    };
    const res = await this.bedDayDecisionService.saveBedDayDecisionInfo(bedDayData);
      if (res !== null && res?.data?.saveBedDay?.beddayRes[0]?.updateClinicalGuidResponse?.beddayRes?.update_hsc_clin_guid_by_pk !== undefined){
        console.log('Bed Day Decision has been Escalated .....' + JSON.stringify(res?.data?.saveBedDay?.beddayRes[0]?.updateClinicalGuidResponse));
      } else if (res !== null &&  res?.data?.saveBedDay?.beddayRes[1]?.hscDecnResponse?.res?.insert_hsc_decn !== undefined) {
        console.log('Bed Day Decision Approved and Saved .....' + JSON.stringify(res?.data?.saveBedDay?.beddayRes[1]?.hscDecnResponse));

      } else if (res?.errors){
        console.log('Bed Day Decision error....' + JSON.stringify(res?.errors[0]?.message));
        this.error = true;
        this.showErrorMessage(this.error);
      }
    if (!this.text && !res?.errors && this.noteText !== undefined){
       await this.saveBedDayNotes();
      }else if ((this.text && !res?.errors) || (this.noteText === undefined && !res?.errors)){
        await this.medicalReviewTreeComponent.onSave();
      }
  }

 async getAccumulatedBedDay(): Promise<any> {
   const res = await this.bedDayDecisionService.getAccumulatedBedDay(this.hscID);
      if (res?.data != null) {
        this.bedDayData[0].BedDay = res?.data?.hsc_decn_aggregate?.aggregate?.sum?.decn_bed_day_cnt + 1;
        console.log('AccumulatedBedDay result....' + JSON.stringify(res));
      } else if (res?.errors !== null) {
        console.log('getAccumulatedBedDay error....' + JSON.stringify(res?.errors[0]?.message));
      }
  }

  async clinicalReviewDescription(): Promise<any> {
    await this.getHscClinGuidID();
    const res = await this.bedDayDecisionService.getClinicalReviewDescription(parseInt(this.hscClinGuidID));
      if (res?.data != null) {
         this.episode = res?.data?.hsc_clin_guid[0]?.clin_rev_desc;
       //  this.hscClinGuidID = this.primaryClinicalID;
         console.log('clinicalReviewDescription result....' + JSON.stringify(res));
         await this.getBedDayNotes();
      } else if (res?.errors !== null) {
        console.log('clinicalReviewDescription error....' + JSON.stringify(res?.errors[0]?.message));
      }
  }

 async saveBedDayNotes(): Promise<any> {
    console.log('calling saveBedDayNotes...');
    const bedDayNotesData = {
      hscID: parseInt(this.hscID),
      hscClinGuidID: this.primaryClinicalID ? this.primaryClinicalID : this.hscClinGuidID,
      noteText: this.noteText
    };
   const res = await this.bedDayDecisionService.saveBeddayNotes(bedDayNotesData);
      console.log('saveBedDayNotes response is ' + JSON.stringify(res));
      if (res?.errors){
        this.error = true;
        this.showErrorMessage(this.error);
      }
      else{
        await this.medicalReviewTreeComponent.onSave();
      }
  }

  async getBedDayNotes(): Promise<any>{
    console.log('calling getBedDayNotes...');
    const bedDayNotesData = {
      hscID: parseInt(this.hscID),
      hscClinGuidID: this.hscClinGuidID,
    };
    const res = await this.bedDayDecisionService.getBedDayNotes(bedDayNotesData);
      console.log('res for getBedDayNotes is ' + JSON.stringify(res));
      this.text = res?.data?.getBedDayNotes?.data?.hsr_note_sbj[0]?.hsr_note?.note_txt_lobj;
      if (this.text !== null && this.text !== undefined) {
        this.disableTextArea = true;
      }
      console.log('res for getBedDayNotes is ' + this.text);
      if (this.text){
        this.noteText = this.text;
      }
      return res;
  }

  getRole() {
    const ecpClaims = this.microProductAuthService.getEcpClaims()[this.ecpClaimsVal];
    const orgs = ecpClaims[this.ecpCliOrgsVal];
    const role = orgs[0]['func-roles'][0]['appl-roles'][1];
    console.log('Your Roles is' + JSON.stringify(role));
    if (role === ROLE_MD) {
      return  this.isRoleMD = true;
    }else if (role === ROLE_NURSE){
      return this.isRoleNurse = true;
    }
  }

  async completeReview(e): Promise<any> {
    await this.saveDecision();
    console.log("save decision success");
    this.complete.next(e);
  }

  previousComponent(e){
    this.previous.next(e);
  }

  getError(e): any{
    console.log(e);
    this.error = e;
    this.showErrorMessage(this.error);
  }
  showErrorMessage(error): any{
    if (error === true && this.modal && this.modal !== undefined) {
      // this.modal.open();
    }
  }
  editButton() {
    this.editReview.emit(true);
  }
}
