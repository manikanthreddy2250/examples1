import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IndexUtilityComponent } from './index-utility.component';

describe('IndexUtilityComponent', () => {
  let component: IndexUtilityComponent;
  let fixture: ComponentFixture<IndexUtilityComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IndexUtilityComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(IndexUtilityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
