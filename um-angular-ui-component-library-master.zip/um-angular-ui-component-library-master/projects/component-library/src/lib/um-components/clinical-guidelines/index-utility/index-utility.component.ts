import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ecp-um-index-utility',
  templateUrl: './index-utility.component.html',
  styleUrls: ['./index-utility.component.scss']
})
export class IndexUtilityComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
