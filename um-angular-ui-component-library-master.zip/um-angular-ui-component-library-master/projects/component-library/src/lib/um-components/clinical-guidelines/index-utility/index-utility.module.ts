import {CUSTOM_ELEMENTS_SCHEMA, NgModule, NO_ERRORS_SCHEMA} from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ButtonModule } from '@ecp/angular-ui-component-library/button';
import { MatIconModule } from '@angular/material/icon';
import { CardModule } from '@ecp/angular-ui-component-library/card';
import { HttpClientModule } from '@angular/common/http';
import {MatSidenavModule, MatDrawerContainer} from '@angular/material/sidenav';
import { IndexUtilityComponent } from './index-utility.component';
import { ButtonGroupModule } from '@ecp/angular-ui-component-library/button-group';

@NgModule({
  declarations: [
    IndexUtilityComponent,
  ],
  imports: [
    CommonModule,
    BrowserModule,
    BrowserAnimationsModule,
    CardModule,
    MatIconModule,
    ButtonModule,
    ButtonGroupModule,
    HttpClientModule,
    MatSidenavModule,
  ],
  exports: [
    IndexUtilityComponent
  ],
  providers: [],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class IndexUtilityModule { }
