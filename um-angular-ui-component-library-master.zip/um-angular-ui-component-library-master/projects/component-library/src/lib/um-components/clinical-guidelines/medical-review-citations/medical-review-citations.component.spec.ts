import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MedicalReviewCitationsComponent } from './medical-review-citations.component';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { HttpHandler } from '@angular/common/http';
import { HttpClient } from '@angular/common/http';
import {MedicalReviewGraphqlServiceService} from '../../services/um/service/clinical-guidelines/medical-review-graphql-service/medical-review-graphql-service.service';


@Injectable()
class MockMedicalReviewNotesCitationService {
  getCitationData(id: string): Observable<any> {
    return of({
      resourceType: 'Parameters',
      meta: {
        source: '/caas/citations/21142',
        tag: [{
          code: 'rel',
          display: 'self'
        }, {
          code: 'title',
          display: 'Allison and Winters, Emerg Med Clin North Am 2016, 34: 51-62'
        }]
      },
      parameter: [{
        name: 'abstract',
        valueString: 'Noninvasive ventilation (NIV) improves oxygenation and ventilation.'
      }, {
        name: 'ebm_classification',
        valueString: 'V'
      }, {
        name: 'ebm_classification_text',
        valueString: 'Expert opinion, panel consensus, literature review, text'
      }, {
        name: 'desc',
        valueString: 'Allison and Winters. Noninvasive Ventilation for the Emergency Physician.'
      }, {
        name: 'short_desc',
        valueString: 'Allison and Winters, Emerg Med Clin North Am 2016, 34: 51-62'
      }, {
        name: 'comparative_effectiveness',
        valueBoolean: false
      }, {
        name: 'cer_url',
        valueString: null
      }, {
        name: 'ebm_url',
        valueString: '/caas/en/us/clinical_evidence_classification.html'
      }, {
        name: 'cer_response'
      }, {
        name: 'emb_response',
        valueString: '<strong>Change Healthcare Clinical Evidence Classification</strong>\r\n<p>References cited in the clinical content are classified according</p>\r\n'
      }]
    });
  }

}

describe('MedicalReviewCitationsComponent', () => {
  let component: MedicalReviewCitationsComponent;
  let fixture: ComponentFixture<MedicalReviewCitationsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [MedicalReviewCitationsComponent],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      providers: [HttpHandler, HttpClient,
        { provide: MedicalReviewGraphqlServiceService, useClass: MockMedicalReviewNotesCitationService }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MedicalReviewCitationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should ngOnInit', () => {
    component.ngOnInit();
    expect(component.ngOnInit).toBeTruthy();
  });

  it('should ngOnChanges', () => {
    component.ngOnChanges();
    expect(component.ngOnChanges).toBeTruthy();
  });

  it('should ngOnChanges if cp available', () => {
    const data = { id: '21142', show: true };
    component.citationModelData = data;
    expect(component.citationModelData).toEqual(data);
    component.citationModelData.id = data.id;
    component.ngOnChanges();
    expect(component.ngOnChanges).toBeTruthy();
  });

  it('should showData if val is 1', () => {
    const val = 1;
    component.showEmb = true;
    component.showData(val);
    expect(component.showData).toBeTruthy();
  });

  it('should showData if val is 2', () => {
    const val = 2;
    component.showCer = true;
    component.showData(val);
    expect(component.showData).toBeTruthy();
  });
});
