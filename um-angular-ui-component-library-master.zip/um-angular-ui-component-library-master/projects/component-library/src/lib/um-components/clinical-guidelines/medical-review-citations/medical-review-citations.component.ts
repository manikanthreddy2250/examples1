import { Component, OnChanges, OnInit, ViewChild } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Input } from '@angular/core';
import {MedicalReviewGraphqlServiceService} from '../../services/um/service/clinical-guidelines/medical-review-graphql-service/medical-review-graphql-service.service';


@Component({
  selector: 'lib-medical-review-citations',
  templateUrl: './medical-review-citations.component.html',
  styleUrls: ['./medical-review-citations.component.scss']
})
export class MedicalReviewCitationsComponent implements OnInit, OnChanges {
  @Input() citationModelData: any = {};
  @Input() processTaskExecutionID: string;
  showEmb = false;
  showCer = false;
  citationResponse: any;
  errorConfig = {
    id: 'error_msg',
    pageNotificationType: 'error',
    content: 'Unexpected error occurred. Please try again later.',
    triggerElementId: 'trigger-button',
  };
  constructor(private readonly httpClient: HttpClient,
              private readonly medicalReviewGraphqlServiceService: MedicalReviewGraphqlServiceService
              ) { }

  ngOnInit(): void {
  }

  ngOnChanges(): void {
    this.citationResponse = null;
    console.log(JSON.stringify(this.citationModelData));
    if (this.citationModelData.id) {
      this.medicalReviewGraphqlServiceService.getCitationData(this.citationModelData.id).subscribe(
        (res: any) => {
          this.citationResponse = res?.data?.getCitationInfo?.citationResponse;
          this.showEmb = false;
          this.showCer = false;
        });
    }
  }


  showData(val: any): any {
    if (val === 1) {
      this.showEmb = !this.showEmb;
    }
    else if (val === 2) {
      this.showCer = !this.showCer;
    }

  }

}
