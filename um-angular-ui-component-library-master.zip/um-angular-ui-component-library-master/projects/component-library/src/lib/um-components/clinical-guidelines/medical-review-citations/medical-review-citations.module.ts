import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule, NoopAnimationsModule } from '@angular/platform-browser/animations';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatIconModule } from '@angular/material/icon';
import { FormsModule, NG_VALUE_ACCESSOR, ReactiveFormsModule } from '@angular/forms';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { NgReversePipeModule } from 'angular-pipes';
import { HttpClientModule } from '@angular/common/http';
import { MedicalReviewCitationsComponent } from './medical-review-citations.component';
import {BreadcrumbsModule} from '@ecp/angular-ui-component-library/breadcrumbs';
import {InputModule} from '@ecp/angular-ui-component-library/input';
import {ModalModule} from '@ecp/angular-ui-component-library/modal';
import {CardModule} from '@ecp/angular-ui-component-library/card';
import {TableModule} from '@ecp/angular-ui-component-library/table';
import {ButtonModule} from '@ecp/angular-ui-component-library/button';
import {SortModule} from '@ecp/angular-ui-component-library/sort';
import {TabsModule} from '@ecp/angular-ui-component-library/tabs';
import {IconsModule} from '@ecp/angular-ui-component-library/icons';



@NgModule({
  declarations: [
    MedicalReviewCitationsComponent
  ],
  imports: [
    BreadcrumbsModule,
    NgReversePipeModule,
    NoopAnimationsModule,
    InputModule,
    ModalModule,
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    BrowserModule,
    BrowserAnimationsModule,
    CardModule,
    MatGridListModule,
    MatIconModule,
    TableModule,
    ButtonModule,
    TabsModule,
    IconsModule,
    SortModule,
    HttpClientModule
  ],
  exports: [
    MedicalReviewCitationsComponent
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  providers: []
})
export class MedicalReviewCitationsModule { }
