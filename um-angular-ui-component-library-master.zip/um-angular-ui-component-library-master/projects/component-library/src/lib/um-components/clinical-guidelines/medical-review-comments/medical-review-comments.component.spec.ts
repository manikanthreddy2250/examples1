import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA , ViewChild} from '@angular/core';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MedicalReviewCommentsComponent } from './medical-review-comments.component';
import { NgReversePipeModule } from 'angular-pipes';
import {ModalModule} from '@ecp/angular-ui-component-library/modal';


describe('MedicalReviewCommentsComponent', () => {
  let component: MedicalReviewCommentsComponent;
  let fixture: ComponentFixture<MedicalReviewCommentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [FormsModule, ReactiveFormsModule, NgReversePipeModule, ModalModule],
      declarations: [MedicalReviewCommentsComponent],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MedicalReviewCommentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  afterEach(() => {
    fixture.destroy();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should returnComments', () => {
    const data = {
      cp: {}, show: true
    };
    component.comemntsAdded = [];
    component.commentModalData = data;
    component.returnComments();
    expect(component.returnComments).toBeTruthy();
  });

  it('should returnComments if cp.id available', () => {
    const data = {
      cp: {
        id: 'AISD01530401',
        text: '<b>Initial review,</b> <b>One:</b>',
        toc_text: '<b>Initial review</b>',
        can_be_met: true,
        navigation_level: 2
      }, show: true
    };
    const commentAdded = [{
      text: 'test1',
      dateTime: '2021-04-30T07:45:51.976Z',
      userName: 'TestingUser1, TestingUser1'
    }, {
      text: 'test2',
      dateTime: '2021-04-30T07:46:06.665Z',
      userName: 'TestingUser1, TestingUser1'
    }];
    component.commentModalData = data;
    component.comemntsAdded = commentAdded;
    if (component.commentModalData.cp) {
      component.commentsList.get(component.commentModalData.cp.id);
    }
    component.returnComments();
    expect(component.returnComments).toBeTruthy();
  });

  it('should returnComments if cp.linkId available', () => {
    const data = {
      cp: {
        linkId: 'AISD0153040102020401',
        text: 'Difficulty taking PO',
        type: 'boolean',
        repeats: false,
        readOnly: true,
        item: []
      }, show: true
    };
    const commentAdded = [{
      text: 'test1',
      dateTime: '2021-04-30T07:45:51.976Z',
      userName: 'TestingUser1, TestingUser1'
    }, {
      text: 'test2',
      dateTime: '2021-04-30T07:46:06.665Z',
      userName: 'TestingUser1, TestingUser1'
    }];
    component.commentModalData = data;
    component.comemntsAdded = commentAdded;
    if (component.commentModalData.linkId) {
      component.commentsList.get(component.commentModalData.cp.linkId);
    }
    component.returnComments();
    expect(component.returnComments).toBeTruthy();
  });

  it('should addComment', () => {
    const commentForm = new FormGroup({
      textarea: new FormControl('hello'),
    });
    component.commentForm = commentForm;
    expect(component.commentForm.get('textarea').value).toEqual('hello');
    const data = {
      cp: {
        id: 'AISD01530401',
        text: '<b>Initial review,</b> <b>One:</b>',
        toc_text: '<b>Initial review</b>',
        can_be_met: true,
        navigation_level: 2
      }, show: true
    };
    const com = [{
      text: 'Hey I am working on NDT Display',
      dateTime: '2020-12-16T16:07:43.215Z',
      userName: 'TestingUser1, TestingUser1'
    }];
    component.commentModalData = data;
    expect(component.commentModalData).toEqual(data);
    const cp = component.commentModalData.cp;
    component.addComment();
    expect(component.addComment).toBeTruthy();
  });

  it('should ngOnInit', () => {
    const data = {
      cp: {
        id: 'AISD01530401',
        text: '<b>Initial review,</b> <b>One:</b>',
        toc_text: '<b>Initial review</b>',
        can_be_met: true,
        navigation_level: 2
      }, show: true
    };
    component.commentModalData = data;
    component.addCommentDisabled = true;
    component.ngOnInit();
    expect(component.ngOnInit).toBeTruthy();
  });


  it('should ngOnChanges', () => {
    component.ngOnChanges();
    expect(component.ngOnChanges).toBeTruthy();
  });

  it('should ngOnChanges if cp.text is  available', () => {
    const data = {
      commentsList: {
        key: 'AISD0153040102020401',
        value: { text: 'test00', userName: 'TestingUser1, TestingUser1', dateTime: '2021-01-12T09:49:44-06:00' }
      },
      cp: {
        linkId: 'AISD0153040102020401',
        text: 'Difficulty taking PO',
        type: 'boolean',
        repeats: false,
        readOnly: true,
        item: []
      },
      show: true
    };
    component.commentModalData = data;
    expect(component.commentModalData).toEqual(data);
    component.cpText = component.commentModalData.cp.text;
    expect(component.cpText).toBe(component.commentModalData.cp.text);
    component.ngOnChanges();
    expect(component.ngOnChanges).toBeTruthy();
  });

  it('should ngOnChanges if cp.name available', () => {
    const data = {
      commentsList: {
        key: 'AISD0153040102020401',
        value: { text: 'test00', userName: 'TestingUser1, TestingUser1', dateTime: '2021-01-12T09:49:44-06:00' }
      },
      cp: { resourceType: 'Questionnaire', id: 'AISD01530401', name: '<b>Initial review</b>', showMyContainer: true },
      show: true
    };
    component.commentModalData = data;
    expect(component.commentModalData).toEqual(data);
    component.cpText = component.commentModalData.cp.name;
    expect(component.cpText).toBe(component.commentModalData.cp.name);
    component.ngOnChanges();
    expect(component.ngOnChanges).toBeTruthy();
  });

  it('should getCommentList', () => {
    const commentModalData = {
      commentsList: {
        key: 'AISD0153040102020401',
        value: { text: 'test00', userName: 'TestingUser1, TestingUser1', dateTime: '2021-01-12T09:49:44-06:00' }
      },
      cp: {
        linkId: 'AISD0153040102020401',
        text: 'Difficulty taking PO',
        type: 'boolean',
        repeats: false,
        readOnly: true,
        item: []
      },
      show: true
    };
    component.getCommentList(commentModalData);
    expect(component.getCommentList).toBeTruthy();
  });


});
