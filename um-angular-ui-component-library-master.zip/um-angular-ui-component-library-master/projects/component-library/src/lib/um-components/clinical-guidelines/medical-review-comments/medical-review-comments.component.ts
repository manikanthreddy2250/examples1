import { Component, EventEmitter, Input, OnChanges, OnInit, Output, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import {EcpUclModal} from '@ecp/angular-ui-component-library/modal';




@Component({
  selector: 'lib-comments-component',
  templateUrl: './medical-review-comments.component.html',
  styleUrls: ['./medical-review-comments.component.scss']
})
export class MedicalReviewCommentsComponent implements OnInit, OnChanges {
  @Input() commentModalData: any = {};
  @Input() processTaskExecutionID: string;
  @Output() commentChanged: EventEmitter<CommentDetails[]> = new EventEmitter();
  commentsList: Map<string, Comment[]> = new Map();
  cpText = '';
  comemntsAdded = [];
  addCommentDisabled = true;
  errorConfig = {
    id: 'error_msg',
    pageNotificationType: 'error',
    content: 'Unexpected error occurred. Please try again later.',
    triggerElementId: 'trigger-button',
  };
  commentDetails: CommentDetails[] = [];
  commentForm = new FormGroup({
    textarea: new FormControl(''),
  });


  constructor() {
  }

  ngOnInit(): void {
    this.commentForm.get('textarea').valueChanges.subscribe(value => {
      this.addCommentDisabled = !value;
    });
  }

  ngOnChanges(): void {
    this.commentForm.get('textarea').setValue('');
    if (this.commentModalData.cp) {
      if (this.commentModalData.cp.text) {
        this.cpText = this.commentModalData.cp.text;
        if (this.commentModalData.commentsList) {
          this.commentsList = this.commentModalData.commentsList;
        }
      } else if (this.commentModalData.cp.name) {
        this.cpText = this.commentModalData.cp.name;
        this.getCommentList(this.commentModalData);
      }
      if (this.commentModalData.selectedQNA) {
        this.commentModalData.cp.item.forEach(item => {
          const isQnASelected = this.commentModalData.selectedQNA[item.linkId];
          if (isQnASelected) {
            this.cpText = this.cpText.concat('<br><ecp-ucl-icons name="confirm"></ecp-ucl-icons>', item.text);
          }
        });
      }
    } else {
      this.cpText = '';
    }
  }


  getCommentList(commentModalData: any): any {
    if (commentModalData.commentsList) {
      this.commentsList = commentModalData.commentsList;
    }
  }
  addComment(): any {
    if ((this.commentForm.get('textarea').value !== '') && (this.commentForm.get('textarea').value.trim().length)){
      const cp = this.commentModalData.cp;
      console.log(this.commentModalData);
      let comments: Comment[] = [];

      if (this.commentsList && this.commentsList.has(cp.linkId)) {
        comments = comments.concat(this.commentsList.get(cp.linkId));
      }

      if (this.commentsList && this.commentsList.has(cp.id)) {
        comments = comments.concat(this.commentsList.get(cp.id));
      }
      comments.push({
        text: this.commentForm.get('textarea').value.trimStart(),
        dateTime: new Date(),
        userName: 'TestingUser1, TestingUser1'
      });
      if (cp.linkId) {
        this.commentsList.set(cp.linkId, comments);
      } else if (cp.id) {
        this.commentsList.set(cp.id, comments);
      }
      this.commentForm.get('textarea').setValue('');
      this.commentDetails = [];
      console.log('commentsList.....' + this.commentsList);
      this.commentsList.forEach((value: Comment[], key: string) => {
        console.log(key, value);
        for (let k = 0; k < value.length; k++) {
          this.commentDetails.push({
            nodeCid: key,
            text: value[k].text,
            user: value[k].userName,
            date: value[k].dateTime
          });
        }
      });
      console.log('commentDetails....' + JSON.stringify(this.commentDetails));
      this.commentChanged.emit(this.commentDetails);
    }
  }

  returnComments(): any {
    if (this.commentModalData.cp) {
      if (this.commentModalData.cp.linkId) {
        return this.commentsList.get(this.commentModalData.cp.linkId) ? this.commentsList.get(this.commentModalData.cp.linkId) : [];
      } else if (this.commentModalData.cp.id) {
        return this.commentsList.get(this.commentModalData.cp.id);
      } else {
        return [];
      }
    }
  }
}

interface Comment {
  text: string;
  userName: string;
  dateTime: Date;
}


interface CommentDetails {
  nodeCid: string;
  text: string;
  user: string;
  date: Date;
}


