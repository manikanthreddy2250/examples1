import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule, NoopAnimationsModule } from '@angular/platform-browser/animations';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatIconModule } from '@angular/material/icon';
import { MedicalReviewCommentsComponent } from './medical-review-comments.component';
import { FormsModule, NG_VALUE_ACCESSOR, ReactiveFormsModule } from '@angular/forms';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { NgReversePipeModule } from 'angular-pipes';
import {TableModule} from '@ecp/angular-ui-component-library/table';
import {InputModule} from '@ecp/angular-ui-component-library/input';
import {ModalModule} from '@ecp/angular-ui-component-library/modal';
import {CardModule} from '@ecp/angular-ui-component-library/card';
import {ButtonModule} from '@ecp/angular-ui-component-library/button';
import {SortModule} from '@ecp/angular-ui-component-library/sort';
import {TabsModule} from '@ecp/angular-ui-component-library/tabs';
import {IconsModule} from '@ecp/angular-ui-component-library/icons';
import { ScrollbarModule } from '@ecp/angular-ui-component-library/scrollbar';



@NgModule({
  declarations: [
    MedicalReviewCommentsComponent
  ],
  imports: [
    NgReversePipeModule,
    NoopAnimationsModule,
    InputModule,
    ModalModule,
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    BrowserModule,
    BrowserAnimationsModule,
    CardModule,
    MatGridListModule,
    MatIconModule,
    TableModule,
    ButtonModule,
    TabsModule,
    IconsModule,
    SortModule,
    ScrollbarModule
  ],
  exports: [
    MedicalReviewCommentsComponent
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  providers: []
})
export class MedicalReviewCommentsModule { }
