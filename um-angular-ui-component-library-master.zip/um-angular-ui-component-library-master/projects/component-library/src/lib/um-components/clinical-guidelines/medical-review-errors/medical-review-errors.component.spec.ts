import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { HttpHandler } from '@angular/common/http';
import { HttpClient } from '@angular/common/http';
import {OAuthLogger, OAuthService, UrlHelperService} from 'angular-oauth2-oidc';
import { MedicalReviewErrorsComponent } from './medical-review-errors.component';

describe('MedicalReviewErrorsComponent', () => {
  let component: MedicalReviewErrorsComponent;
  let fixture: ComponentFixture<MedicalReviewErrorsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MedicalReviewErrorsComponent ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      providers: [HttpHandler, HttpClient, OAuthLogger, OAuthService, UrlHelperService,
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MedicalReviewErrorsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should ngOnInit', () => {
    const data = { status: '400', message: 'Bad Request', show: true};
    component.errorModel = data;
    component.ngOnInit();
    expect(component.ngOnInit).toBeTruthy();
  });

  it('should ngOnChanges', () => {
    component.ngOnChanges();
    expect(component.ngOnChanges).toBeTruthy();
  });

  it('should ngOnChanges if cp available', () => {
    const data = { status: '400', message: 'Bad Request', show: true};
    component.errorModel = data;
    expect(component.errorModel).toEqual(data);
    component.errorModel.message = data.message;
    component.errorModel.show = data.show ;
    component.ngOnChanges();
    expect(component.ngOnChanges).toBeTruthy();
  });

});
