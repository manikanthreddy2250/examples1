import { Component, Input, OnInit, ViewChild } from '@angular/core';
import {EcpUclModal} from '@ecp/angular-ui-component-library/modal';

@Component({
  selector: 'um-medical-review-errors',
  templateUrl: './medical-review-errors.component.html',
  styleUrls: ['./medical-review-errors.component.scss']
})
export class MedicalReviewErrorsComponent implements OnInit {
  @ViewChild(EcpUclModal, {static: true})
  modal: EcpUclModal;
  @Input() errorModel: any = {};
  @Input() processTaskExecutionID: string;
  status='';
  message='';
  
  constructor() { }

  ngOnInit(): void {

  }

  ngOnChanges(): void {
     this.status = this.errorModel.status;
     this.message = this.errorModel.message;
    if (this.errorModel.show === true && this.modal && this.modal !== undefined){
      this.modal.open();
    }
  }

}
