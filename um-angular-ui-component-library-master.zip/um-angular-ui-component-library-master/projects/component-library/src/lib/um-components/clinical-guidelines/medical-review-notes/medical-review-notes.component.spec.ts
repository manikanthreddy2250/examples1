import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MedicalReviewNotesComponent } from './medical-review-notes.component';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { HttpHandler } from '@angular/common/http';
import { HttpClient } from '@angular/common/http';
import {OAuthLogger, OAuthService, UrlHelperService} from 'angular-oauth2-oidc';
import {MedicalReviewGraphqlServiceService} from '../../services/um/service/clinical-guidelines/medical-review-graphql-service/medical-review-graphql-service.service';

@Injectable()
class MockMedicalReviewNotesCitationService {
  getNotes(subsetUniqueId: string, id: string, noteType: string, parentId: string): Observable<any> {
    return of({
      resourceType: 'Parameters',
      id: 'AISD01530402',
      meta: {
        tag: [
          {
            code: 'title',
            display: 'General Notes'
          },
          {
            code: 'type',
            display: 'ALL_NOTES'
          }
        ]
      },
      parameter: [
        {
          name: 'Transition Plan Note',
          valueId: 'TRANSITION_PLAN_NOTE',
          valueString: '<p class="tightSpacing"><b>Transition Plan: </b></p>'
        },
        {
          name: 'CMS Two-Midnight Rule Note',
          valueId: 'CMS_TWO_MIDNIGHT_RULE_NOTE',
          valueString: '<p class="tightSpacing">For Medicare beneficiaries</p>'
        }
      ]
    });
  }

}

describe('MedicalReviewNotesComponent', () => {
  let component: MedicalReviewNotesComponent;
  let fixture: ComponentFixture<MedicalReviewNotesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [MedicalReviewNotesComponent],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      providers: [HttpHandler, HttpClient, OAuthLogger, OAuthService, UrlHelperService,
        { provide: MedicalReviewGraphqlServiceService, useClass: MockMedicalReviewNotesCitationService }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MedicalReviewNotesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should ngOnInit', () => {
    const data = { subset_unique_id: '353625', id: 'AISD01530401', note_type: 'ALL_NOTES', parent_id: '' , show: true};
    component.notesModel = data;
    component.ngOnInit();
    expect(component.ngOnInit).toBeTruthy();
  });

  it('should ngOnChanges', () => {
    component.ngOnChanges();
    expect(component.ngOnChanges).toBeTruthy();
  });

  it('should ngOnChanges if cp available', () => {
    const data = { subset_unique_id: '353625', id: 'AISD01530401', note_type: 'ALL_NOTES', parent_id: '' , show: true};
    component.notesModel = data;
    expect(component.notesModel).toEqual(data);
    component.notesModel.id = data.id;
    component.notesModel.show = data.show ;
    component.ngOnChanges();
    expect(component.ngOnChanges).toBeTruthy();
  });

  it('should get getcompare', () => {
    const citationData = [{ seq: 1, id: '24177', title: 'Halpin et al., Int J Chron Obstruct Pulmon Dis 2017, 12: 2891-908' },
      { seq: 2, id: '24179', title: 'Lau et al., Int J Chron Obstruct Pulmon Dis 2017, 12: 1891-902' },
      { seq: 3, id: '17833', title: 'Tsui et al., Int J Tuberc Lung Dis 2016, 20: 396-401' }];
    const title = 'Tsui et al., Int J Tuberc Lung Dis 2016, 20: 396-401';
    component.returntitleSeq = 0;
    component.getcompare(citationData, title);
    expect(component.getcompare).toBeTruthy();

  });

  it('should notesInformation', () => {
    const notesResposne = {
      resourceType: 'Parameters',
      id: 'AISD01530402',
      meta: {
        tag: [
          {
            code: 'title',
            display: 'General Notes'
          },
          {
            code: 'type',
            display: 'ALL_NOTES'
          }
        ]
      },
      parameter: [
        {
          name: 'Transition Plan Note',
          valueId: 'TRANSITION_PLAN_NOTE',
          valueString: '<p class="tightSpacing"><b>Transition Plan: </b></p>'
        },
        {
          name: 'CMS Two-Midnight Rule Note',
          valueId: 'CMS_TWO_MIDNIGHT_RULE_NOTE',
          valueString: '<p class="tightSpacing">For Medicare beneficiaries</p>'
        }
      ]
    };
    component.citationData = [{ seq: 1, id: '24177', title: 'Halpin et al., Int J Chron Obstruct Pulmon Dis 2017, 12: 2891-908' },
      { seq: 2, id: '24179', title: 'Lau et al., Int J Chron Obstruct Pulmon Dis 2017, 12: 1891-902' },
      { seq: 3, id: '17833', title: 'Tsui et al., Int J Tuberc Lung Dis 2016, 20: 396-401' }];
    component.notesData = [{ title: 'Transition Plan Note', data: '<p><b>Transition Plan: </b></p>' },
      { title: 'CMS Two-Midnight Rule Note', data: '<p>For Medicare beneficiaries</p>' }];
    component.notesInformation(notesResposne);
    expect(component.notesInformation).toBeTruthy();
  });

  it('should getCitationLink', () => {
    const data = '<p><b>Transition Plan: </b>InterQual® Transition Plan identifies patients at high risk for readmission</b></p>';
    component.citationData = [{ seq: 1, id: '24177', title: 'Halpin et al., Int J Chron Obstruct Pulmon Dis 2017, 12: 2891-908' },
      { seq: 2, id: '24179', title: 'Lau et al., Int J Chron Obstruct Pulmon Dis 2017, 12: 1891-902' },
      { seq: 3, id: '17833', title: 'Tsui et al., Int J Tuberc Lung Dis 2016, 20: 396-401' }];
    component.getCitationLink(data);
    expect(component.getCitationLink).toBeTruthy();
  });

  it('should getRouterLink', () => {
    const id = '21142';
    component.citataionModelData = { id: '21142', show: true };
    component.getRouterLink(id);
    expect(component.getRouterLink).toBeTruthy();
  });

  it('should navigate', () => {
    const url = '/';
    component.location = url;
    component.showNavigation = false;
    component.showNotesData = true;
    component.navigate(url);
    expect(component.navigate).toBeTruthy();
  });

  it('should onPrevious', () => {
    component.showNavigation = false;
    component.showNotesData = true;
    component.onPrevious();
    expect(component.onPrevious).toBeTruthy();
  });

});
