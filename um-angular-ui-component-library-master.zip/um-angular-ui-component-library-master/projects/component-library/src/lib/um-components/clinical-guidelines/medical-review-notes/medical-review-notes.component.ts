import { Component, OnInit, Input, OnChanges, ViewChild } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {EcpUclModal} from '@ecp/angular-ui-component-library/modal';
import {MedicalReviewGraphqlServiceService} from '../../services/um/service/clinical-guidelines/medical-review-graphql-service/medical-review-graphql-service.service';


@Component({
  selector: 'lib-medical-review-notes',
  templateUrl: './medical-review-notes.component.html',
  styleUrls: ['./medical-review-notes.component.scss']
})
export class MedicalReviewNotesComponent implements OnInit, OnChanges {
  @Input() notesModel: any = {};
  @Input() processTaskExecutionID: string;
  notesResposne: any;
  showNavigation = false;
  showNotesData = true;
  notesData = [];
  countbib: any;
  citationData = [];
  errorConfig = {
    id: 'error_msg',
    pageNotificationType: 'error',
    content: 'Unexpected error occurred. Please try again later.',
    triggerElementId: 'trigger-button',
  };
  citationlinkIndex = 1;
  citationSeqNo = 1;
  citataionModelData: any = {
    show: false
  };
  returntitleSeq: any;
  locations = [
    { label: 'Notes', uri: '/' },
    { label: 'Citation', uri: '/citation' }
  ];
  location: any;

  constructor(private readonly httpClient: HttpClient,
              private readonly medicalReviewGraphqlServiceService: MedicalReviewGraphqlServiceService
              ) { }

  ngOnInit(): void {
  }

  ngOnChanges(): void {
    const subsetUniqueId = this.notesModel.subset_unique_id;
    const id = this.notesModel.id;
    const noteType = this.notesModel.note_type;
    const parentId = this.notesModel.parent_id;
    this.notesResposne = null;
    if (this.notesModel.id) {
      this.medicalReviewGraphqlServiceService.getNotes(subsetUniqueId, id, noteType, parentId).subscribe(
        (res: any) => {
          this.notesResposne = res?.data?.getNotesData?.notesRes;
          this.citationData = [];
          this.notesData = [];
          this.citationlinkIndex = 1;
          this.citationSeqNo = 1;
          this.notesInformation(this.notesResposne);
          this.showNotesData = true;
          this.showNavigation = false;
        });
    }
  }
  getcompare(citationData: any, citTitle): any {
    this.returntitleSeq = 0;
    citationData.forEach(item => {
      if (citTitle === item.title) {
        this.returntitleSeq = item.seq;
      }
    });
    return this.returntitleSeq;
  }
  notesInformation(notesResposne: any): any{
    notesResposne?.parameter?.forEach(element => {
      this.countbib = (element.valueString.match(/<bib/g) || []).length;
      for (let i = this.countbib; i > 0; i--) {
        const citationtitle = element.valueString.substring(element.valueString.indexOf('title'), element.valueString.indexOf('href'));
        const returnSeqNo = this.getcompare(this.citationData, citationtitle.substring(7, citationtitle.length - 2));
        if (returnSeqNo === 0) {
          this.getCitationLink(element.valueString);
          element.valueString = element.valueString.replace(element.valueString.substring(element.valueString.indexOf('<bib'), element.valueString.indexOf('</bib>') + 6), this.citationlinkIndex++);
        } else {
          element.valueString = element.valueString.replace(element.valueString.substring(element.valueString.indexOf('<bib'), element.valueString.indexOf('</bib>') + 6), returnSeqNo);
        }
      }
      const notesDetails = {
        title: (element.name !== 'Answer Note' && element.name !== 'Question Note' && element.name !== 'Tool Tip Note') ? element.name : 'Informational Note',
        data: element.valueString
      };
      this.notesData.push(notesDetails);
    });
  }

  getCitationLink(citationdata: any): any {
    const citationtitle = citationdata.substring(citationdata.indexOf('title'), citationdata.indexOf('href'));
    const citationLink = citationdata.substring(citationdata.indexOf('href'), citationdata.indexOf('id='));
    console.log(citationtitle.substring(7, citationtitle.length - 2));
    console.log(citationLink.substring(22, citationLink.length - 2));
    const citationData = {
      seq: this.citationSeqNo++,
      id: citationLink.substring(22, citationLink.length - 2),
      title: citationtitle.substring(7, citationtitle.length - 2),
    };
    this.citationData.push(citationData);

  }

  getRouterLink(id): any {
    this.showNavigation = true;
    this.showNotesData = false;
    this.citataionModelData = {
      id,
      show: true
    };
  }

  navigate(url): any {
    if (typeof url === 'string') {
      this.location = url;
      console.log((this.location));
      if (this.location === '/') {
        this.showNavigation = false;
        this.showNotesData = true;

      }
    }
  }

  onPrevious(): any {
    this.showNavigation = false;
    this.showNotesData = true;
  }


}
