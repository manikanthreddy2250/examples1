import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule, NoopAnimationsModule } from '@angular/platform-browser/animations';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatIconModule } from '@angular/material/icon';
import { FormsModule, NG_VALUE_ACCESSOR, ReactiveFormsModule } from '@angular/forms';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { NgReversePipeModule } from 'angular-pipes';
import { MedicalReviewNotesComponent } from './medical-review-notes.component';
import { HttpClientModule } from '@angular/common/http';
import {BreadcrumbsModule} from '@ecp/angular-ui-component-library/breadcrumbs';
import {InputModule} from '@ecp/angular-ui-component-library/input';
import {ModalModule} from '@ecp/angular-ui-component-library/modal';
import {CardModule} from '@ecp/angular-ui-component-library/card';
import {TableModule} from '@ecp/angular-ui-component-library/table';
import {ButtonModule} from '@ecp/angular-ui-component-library/button';
import {SortModule} from '@ecp/angular-ui-component-library/sort';
import {IconsModule} from '@ecp/angular-ui-component-library/icons';
import {TabsModule} from '@ecp/angular-ui-component-library/tabs';
import {MedicalReviewCitationsModule} from '../medical-review-citations/medical-review-citations.module';
import {OAuthService, UrlHelperService} from 'angular-oauth2-oidc';
import {NGXLogger, NGXMapperService, NGXLoggerHttpService, LoggerConfig} from 'ngx-logger';
import {DatePipe} from '@angular/common';
import { ScrollbarModule } from '@ecp/angular-ui-component-library/scrollbar';



@NgModule({
  declarations: [
    MedicalReviewNotesComponent
  ],
  imports: [
    BreadcrumbsModule,
    NgReversePipeModule,
    NoopAnimationsModule,
    InputModule,
    ModalModule,
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    BrowserModule,
    BrowserAnimationsModule,
    CardModule,
    MatGridListModule,
    MatIconModule,
    TableModule,
    ButtonModule,
    TabsModule,
    IconsModule,
    SortModule,
    HttpClientModule,
    MedicalReviewCitationsModule,
    ScrollbarModule
  ],
  exports: [
    MedicalReviewNotesComponent
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  providers: [OAuthService, UrlHelperService , NGXLogger, NGXMapperService, NGXLoggerHttpService, LoggerConfig, DatePipe]
})
export class MedicalReviewNotesModule { }
