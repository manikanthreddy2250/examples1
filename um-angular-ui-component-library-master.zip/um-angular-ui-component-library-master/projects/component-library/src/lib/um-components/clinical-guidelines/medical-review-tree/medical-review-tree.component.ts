
import {Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators, FormsModule, NumberValueAccessor } from '@angular/forms';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { MicroProductAuthService } from '@ecp/auth-library';
import { ThemePalette } from '@angular/material/core';
import { MedicalReviewGraphqlServiceService } from '../../services/um/service/clinical-guidelines/medical-review-graphql-service/medical-review-graphql-service.service';
import { MedicalReviewTreeService } from '../../services/um/service/clinical-guidelines/medical-review-tree/medical-review-tree.service';
import { getEnvVar } from '../../services/environment/envVarUtil';
import { ViewChild } from '@angular/core';
import { EcpUclModal } from '@ecp/angular-ui-component-library/modal';
import { GuidelinesConstants } from '../../../constant/guidelines-constants';
import {ConfigService} from '../../services/config/config.service';
import {GuidelinesUtils} from '../shared/guidelines-utils';
import {UmcasewfGraphqlService} from '../../services/um/service/casewf/umcasewf-graphql.service';
import { GuidelineSummaryService } from '../../services/um/service/clinical-guidelines/guideline-summary/guideline-summary.service';
import {GET_CONFIG_URL_PATH} from '../../../config/config-constants';
import {SysConfigService} from '../../services/um/service/clinical-guidelines/sysconfig-service/sys-config.service';
import { BedDayDecisionService } from '../../services/um/service/clinical-guidelines/guideline-bed-day-decision-service/bed-day-decision.service';
@Component({
  selector: 'um-medical-review-tree',
  templateUrl: './medical-review-tree.component.html',
  styleUrls: ['./medical-review-tree.component.scss']
})
export class MedicalReviewTreeComponent implements OnInit {


  @Input() hscId: number;
  @Input() guidelineId: string;
  @Input() version: string;
  @Input() reviewId: any;
  @Input() primaryClinicalID: any;
  @Input() metStat: any;
  @Input() isAutoReview: any;
  @Input() isCompleteReviewFlag: boolean;
  @Input() processTaskExecutionID: string;
  @ViewChild(EcpUclModal, { static: true })
  modal: EcpUclModal;
  @Output() saveReview: EventEmitter<string> = new EventEmitter();
  @Output() editReview: EventEmitter<boolean> = new EventEmitter();
  @Output() error1: EventEmitter<any> = new EventEmitter();
  @Input() isDirectNav = true;
  @Input() expanded = false;
  @Output() start: EventEmitter<any> = new EventEmitter();
  @Output() previous: EventEmitter<any> = new EventEmitter();
  @Input() showDocProcess = true;
  currentBtnValue = 'Document';
  speed = '2s';
  showDoc = true;
  showSpinner = false;
  overviewTextSummary: any;
  productDescription: any;
  versionDescription: any;
  mdHscClinGuid: any;
  header: any;
  saveCompletedReview = false;
  higherLocMet;
  icon = 'arrow_down';
  productId = '';
  versionVal = '';
  selectEpisode = 'Select Medical Review';
  task: Task = {
    name: 'Indeterminate',
    completed: false,
    color: 'primary',
    subtasks: [
      {
        name: 'Primary', completed: false, color: 'primary',
      }
      ,
      { name: 'Accent', completed: false, color: 'accent' },
      { name: 'Warn', completed: false, color: 'warn' }
    ]
  };

  chkids: any;
  chkVal: any;
  reviewSaveRes = null;
  commentsFhir: any = [];
  containedDraft: any;
  reviewRes: any;
  reviewRevision = 0;
  reviewVersion = 0;
  previousEventValue: any;
  metstat: any;
  event: any;
  state: any;
  saveOCMResult: any;
  size: any;
  reviewDesc: any;
  disabled: any;
  draftFlag = false;
  variant: any;
  primaryClinicalId = null;
  reviewUUID = null;
  containedTree = [];
  nameDraft: any;
  titleDraft: any;
  allCheckedSlectionItems: any = [];
  allCheckedSelections: SelectionFhir[] = [];
  isSelected: any;
  hscData: any = [];
  cristat: any;
  body1: any;
  disablereview: any = false;
  medReviewTreeForm: FormGroup = this.fb.group({});
  medReviewTypeForm: FormGroup = new FormGroup({
    medReviewType: new FormControl(null),
  });
  selected: any;
  public WARNING = 'WARNING';
  headerType = 'Content-Type';
  savedReviewSelectionList: any = [];
  show: any;
  idsArray: any = [];
  showMyContainer = false;
  criteriaMet = GuidelinesConstants.CRITERIA_DESC;
  expandAllBtn = GuidelinesConstants.EXPAND_ALL;
  clearAllBtn = GuidelinesConstants.CLEAR_ALL;
  collapseAllBtn = GuidelinesConstants.COLLAPSE_ALL;
  dischargeReviewBtn = GuidelinesConstants.DISCHARGE_REVIEW;
  previousBtn = GuidelinesConstants.PREVIOUS;
  public list: any = [];
  public ndtResponse: any = [];
  cpsArrayValue: any = [];
  public titlearray: any = [];
  ndtSelectionList: any = [];
  FormBuilder: any;
  count = 0;
  choices: Choice[] = [];
  checkedIds: Selection[] = [];
  checkedIdsFhir: SelectionFhir[] = [];
  stepResponseId: any;
  subsetUniqueId: any;
  headerValue = 'application/vnd.mck.dm.review-workflow-state-v1+json';
  isLoading = false;
  response: any;
  identifiers: any = [];
  reviewDetails: any;
  clearLowerLoc: any;
  getNextItemResponseBody: any;
  responseMessage = '';
  updateTree = false;
  infoInsideError = false;
  getNextItemIdsBeforeOK: any = [];
  getNextItemIdsAfterOK: any = [];
  resMessageType = '';
  getNextItemBody: any;
  commentsArray: any = [];
  guideLineID: any;
  subsetUniqueIdValue: any;
  commentsDraftFhir = [];
  returnComment: any;
  selectCriteriaWarn = false;
  partiallyMetId = false;
  partiallyMetIds: PartiallyMet[] = [];
   criteriaStatusFlag = false;
  checkableRuleMessage = 'Select the criteria point above and relevant underlying criteria to satisfy the rule.';
  subsetRedirectParameters = [];
  extendedStayId: any;
  extendedStayValue: any;
  redirectSubsetFlag = false;
  containedRedirectSubset = [];
  containedTreeOld = [];
  label: 'Label';
  labelPosition = 'after';
  checkboxState = 'default';
  alertCommentAdded = true;
  commentsList: Map<string, Comment[]> = new Map();
  commeText = 'Reviewer Comments';
  showcp: any;
  dischargeReview = '';
  dischargeReviewFlag = false;
  previousFlag = false;
  previousInd = false;
  public prevList: any = [];
  titleArrayPrev = [];
  prevSelectedValue = '';
  dischargeIdsArray = [];
  hideDischarge = false;
  selectCriteriaWarnDialogModal = {
    display: false,
  };

showcomment = false;
showNotes = false;
closecard = false;
  commentModal: any = {
    show: false
  };

  notesModel: any = {
    show: false
  };

 errorModel: any = {
    show: false
  };

  warningDialogModal = {
    show: false,
  };
  selectedValue: string;
  // Submit button
  normalDialogModal = {
    display: false,
  };

  // for Draft
  statusDialogModal = {
    show: false,
  };
  overviewText: any;
  counter = 0;
  citationData: any = [];
  returnTitle = 0;
  k = 1;
  j = 1;
  citationModalData: any = {
    show: false
  };

  items = [
    this.commeText
  ];

  // For Notes
  itemsNote = [
    this.commeText,
    'Reviewer Notes'
  ];
  editBtn = GuidelinesConstants.EDIT;
  ndtTreeRes;
  ndtReviewDetails;
  userRole;
  roles = [];
  ecpClaimsVal = 'x-ecp-claims';
  ecpCliOrgsVal = 'x-ecp-cli-orgs';
  configService: any;
  showDischargeReview = false;
  constructor(private readonly fb: FormBuilder,
              private readonly http: HttpClient,
              private readonly medicalReviewTreeService: MedicalReviewTreeService,
              private readonly medicalReviewGraphqlServiceService: MedicalReviewGraphqlServiceService,
              private readonly microProductAuthService: MicroProductAuthService,
              private readonly guidelineSummaryService: GuidelineSummaryService,
              private readonly bedDayDecisionService: BedDayDecisionService,
              private readonly umcaseService: UmcasewfGraphqlService,
              private readonly sysConfigService: SysConfigService) {
  }

  ngOnInit(): void {
    this.checkRoleForCriteriaStatus();
    this.checkRoleForDischargeReview();
    this.isLoading = true;
    this.medReviewTreeForm = this.fb.group({});
    this.getGuidelineSummary();
    this.medReviewTypeForm = new FormGroup({
      medReviewType: new FormControl(null),
    });
    if (this.reviewId === '' || this.reviewId == null) {
      this.getInitialNDTTree();
    } else {
      this.getMedicalReviewTreeForUUID(this.reviewId);
    }
  }

  getGuidelineSummary() {
    const guidelineId = this.guidelineId ? this.guidelineId : this.guideLineID;
    const version = this.version ? this.version : this.versionVal;
    console.log(guidelineId, version);
    this.showSpinner = true;
    this.guidelineSummaryService.getGuidelineData(guidelineId, version).subscribe(
      (resp: any) => {
        const res = resp?.data?.getGuidelineReview?.reviewResponse;
        this.productDescription = res.name;
        this.versionDescription = res.title;
        this.overviewTextSummary = res.text;
        this.showSpinner = false;
      }, err => {
        this.showSpinner = true;
      });
  }


  checkRoleForCriteriaStatus() {
    this.userRole = this.getUserRoles();
    console.log('ecp user role is - ' + JSON.stringify(this.userRole));
    const configUrl = getEnvVar(GET_CONFIG_URL_PATH);
    this.sysConfigService.getClientConfigByKey(GuidelinesConstants.CRITERIA_STATUS_ROLE).then((res: any) => {
      this.roles = res ? JSON.parse(res[0].value) : [];
      if (this.roles.includes(this.userRole)) {
        this.criteriaStatusFlag = true;
      }
    });
  }

  getUserRoles() {
    const ecpClaims = this.microProductAuthService.getEcpClaims()[this.ecpClaimsVal];
    const orgs = ecpClaims[this.ecpCliOrgsVal];
    const roles = orgs[0]['func-roles'][0]['appl-roles'];
    console.log('ecp roles are' + JSON.stringify(roles));
    if (roles.includes(GuidelinesConstants.NURSE)) {
      return GuidelinesConstants.NURSE;
    }
  }

  checkRoleForDischargeReview() {
    const orgs = this.getOrgId();
    console.log('org-Id - ' + JSON.stringify(orgs));
    this.sysConfigService.getClientConfigByKey(GuidelinesConstants.DISCHARGE_REVIEW_ROLE).then((res: any) => {
      this.roles = res ? JSON.parse(res[0].value) : [];
      if (this.roles.includes(orgs)) {
        this.showDischargeReview = true;
      }
    });
  }

  getOrgId() {
    const ecpClaims = this.microProductAuthService.getEcpClaims()[this.ecpClaimsVal];
    const orgs = ecpClaims[this.ecpCliOrgsVal][0]['org-id'];
    console.log('org-Id - ' + JSON.stringify(orgs));
    console.log('org-Id - ' + JSON.stringify(orgs));
    console.log('org-Id - ' + JSON.stringify(orgs));
    if (orgs.includes(GuidelinesConstants.ECP)) {
      return GuidelinesConstants.ECP;
    }
  }

  getInitialNDTTree() {
    const guideline = this.guidelineId;
    const versionVal = this.version;
    console.log(guideline, versionVal);
    this.medicalReviewGraphqlServiceService.getNdtData(guideline , versionVal ).subscribe(
      (resp: any) => {
       this.getTree(resp);
      }, err => {
      });
  }

  getTree(resp){
    console.log('resp...' + JSON.stringify(resp));
    if (resp?.errors){
      this.prepareErrorModel('', resp?.errors[0].message, true);
    }else{
    const res = resp?.data?.getGuidelineReview?.reviewResponse;
    if (res?.message && res?.status){
      this.prepareErrorModel(res?.status, res?.message, true);
    }
    else{
    this.gettingNdtTreeResp(res);
    this.subsetUniqueId = res.id;
    this.nameDraft = res.name;
    this.ndtResponse = res;
    this.identifiers = res.identifier;
    const meta = res.meta.tag;
    this.setProductAndVersion(meta);
    const contained = res.contained;
    this.getTitleArray(contained);
    this.isLoading = false;
    this.overviewText = res.text;
  }}
  }

  prepareErrorModel(status, message, show){
    this.errorModel = {
      status,
      message,
      show
    };
  }

  collapseAll() {
    this.list.forEach((node: any) => {
      this.expandCollapseChild(node, false);
    });
  }

  clearAll() {
    this.dischargeReviewFlag = false;
    this.criteriaMet = GuidelinesConstants.CRITERIA_DESC;
    this.checkedIdsFhir = [];
    const selectedItems = this.getNextItemResponseBody.item;
    console.log('selectedItems' + JSON.stringify(selectedItems));
    if (selectedItems) {
      selectedItems.forEach(item => {
      this.clearSelection(item);
      });
    }
  }

  clearSelection(item){
    if (item && this.medReviewTreeForm?.get(item.id) !== null) {
      this.medReviewTreeForm?.get(item.id)?.patchValue(false);
    }
  }

  expandAll() {
    this.list.forEach((node: any) => {
      this.expandCollapseChild(node, true);
    });
  }
  expandCollapseChild(node: any, isExpand: boolean) {
    node.showMyContainer = isExpand;
    if (node.item) {
      node.item.forEach(childNode => {
        this.expandCollapseChild(childNode, isExpand);
      });
    }
  }

  setProductAndVersion(meta){
    console.log('meta....' + JSON.stringify(meta));
    console.log('identifiers....' + JSON.stringify(this.identifiers));
    for (let k = 0; k < meta.length; k++) {
      if (meta[k].code === 'product_id') {
        this.productId = meta[k].display;
      }
      if (meta[k].code === 'version_id') {
        this.versionVal = meta[k].display;
      }
    }
    for (let k = 0; k < this.identifiers.length; k++) {
      if (this.identifiers[k].use === 'usual') {
        this.stepResponseId = this.identifiers[k].value;
      }
    }
  }

  getTitleArray(contained) {
    for (let i = 0; i < contained.length; i++) {
      const title = contained[i].name;
      if (title !== null && title !== undefined) {
        const text: string = title.substring(3, title.length - 4);
        const titleObj = {
          name: text,
          value: text
        };
        this.titlearray.push(titleObj);
      }
    }
  }

  onChange(event: string) {
    this.medicalReviewTreeService.setDropDownEvent(event);
    this.dischargeReviewFlag = false;
    let idVal: number;
    let index: number = null;
    if (event !== null && (this.ndtResponse != null)) {
     // this.containedTree = this.ndtResponse['contained'];
      if (this.containedDraft === null || this.containedDraft === undefined) {
        this.containedTree = this.ndtResponse.contained;
      } else {
        this.containedTree = this.containedDraft;
        this.draftFlag = true;
      }
      const eventVal = event;
      this.previousEventValue = eventVal;
      index = this.getIndex(event);
      this.list = Array.of(this.containedTree[index]);
      const reviewDescription = this.list[0].name;
      this.reviewDesc = reviewDescription.substring(3, reviewDescription.length - 4);
      this.getIds(this.list);
      if (index !== undefined && index !== null) {
        idVal = this.containedTree[index].id;
      }
      this.registerControls(idVal);
    }
  }


  getIndex(event) {
    let text: string = null;
    let index: number = null;
    if (this.containedTree !== null && this.containedTree !== undefined && this.containedTree.length > 0) {
      for (let i = 0; i < this.containedTree.length; i++) {
        const title = this.containedTree[i].name;
        if (title !== null && title !== undefined && this.draftFlag === false) {
          text = title.substring(3, title.length - 4);
        }
        if (title !== null && title !== undefined && this.draftFlag === true) {
          text = title.substring(3, title.length - 17);
        }
        console.log('text..' + text);
        if (text === event) {
          console.log('...');
          console.log('text' + text);
          console.log(event);
          index = i;
          break;
        }
      }
    }
    return index;
  }

  /** Add controls based on the id's in the nested json structure */
  registerControls(id: any) {
    this.medReviewTreeForm.addControl(id, this.fb.control('', [Validators.required]));
    if (this.idsArray !== null && this.idsArray !== undefined && this.idsArray.length > 0) {
      for (const value of this.idsArray) {
        if (value !== undefined) {
          this.medReviewTreeForm.addControl(value.linkId, this.fb.control('', [Validators.required]));
        }
      }
    }
    this.registerDischargeControls();
  }

  registerDischargeControls() {
    if (this.dischargeIdsArray !== null && this.dischargeIdsArray !== undefined && this.dischargeIdsArray.length > 0) {
      for (const value of this.dischargeIdsArray) {
        if (value !== undefined) {
          this.medReviewTreeForm.addControl(value, this.fb.control('', [Validators.required]));
        }
      }
    }
  }
  // Fetching id's from Nested JSON object and storing it in a idsArray array to register controls
  getIds(nestedJsonObj: any) {
    for (const value of nestedJsonObj) {
      const childId = value;
      if (childId !== undefined && childId.hasOwnProperty('item')) {
        if (childId.linkId !== undefined && childId.type !== 'display') {
          this.idsArray.push(childId);
        }
        this.getIds(childId.item);
      } else {
        this.idsArray.push(childId);
      }
    }
  }

  checkForRedirectSubset(contained: any, id: string, checkedValue: string) {
    for (let j = 0; j < contained.length; j++) {
      if (contained[j].id === 'redirectSubset') {
        this.setRedirectFlagTrue(contained[j], id, checkedValue);
      } else {
        this.redirectSubsetFlag = false;
      }
    }
  }

  setRedirectFlagTrue(contained: any, id: string, checkedValue: string) {
    if (contained.parameter !== null && contained.parameter !== undefined && contained.parameter.length > 0) {
      this.subsetRedirectParameters = contained.parameter;
      for (let k = 0; k < this.subsetRedirectParameters.length; k++) {
        if (this.subsetRedirectParameters[k].name === 'uniqueId' && this.subsetRedirectParameters[k].hasOwnProperty('valueString')) {
          this.redirectSubsetFlag = true;
        }
      }
      this.extendedStayId = id;
      this.extendedStayValue = checkedValue;
    }
  }

  openCommentModal(ele, cp: any) {
    const list = [];
    const commentText = '';
    const comments: Comment[] = [];
    for (let k = 0; k < this.commentsArray.length; k++) {
      if (cp.linkId === this.commentsArray[k].nodeCid || cp.id === this.commentsArray[k].nodeCid) {
        comments.push({
          text: commentText + this.commentsArray[k].text,
          userName: this.commentsArray[k].user ? this.commentsArray[k].user : '',
          dateTime: this.commentsArray[k].date ? this.commentsArray[k].date : ''

        });
        this.commentsList.set(cp.linkId || cp.id, comments);
      }
    }
    console.log(ele);
    console.log(cp);
    if (ele === this.commeText){
      this.closecard = true;
      this.showcomment = true;
      this.showNotes = false;
      this.showcp = cp;
      this.commentModal = {
        commentsList: this.commentsList,
        cp,
        show: true
      };
    }
    else if (ele === 'Reviewer Notes'){
      this.closecard = true;
      this.showcomment = false;
      this.showNotes = true;
      this.notesModel = {
        subset_unique_id: String(this.subsetUniqueId),
        id : cp.linkId || cp.id,
        note_type: 'ALL_NOTES',
        parent_id: '',
        show: true
      };
     console.log(this.notesModel);
    }
  }

  onCheck(list, item, title, id, event) {
    let checkedValue;
    this.changePartiallyMetIds(id);
    if (event) {
      this.ndtSelectionList.push(id);
      this.checkedIdsFhir.push({ linkId: id, answer: [{ valueBoolean: 'true' }] });
      checkedValue = 'CHECKED';
    } else {
      this.ndtSelectionList = this.ndtSelectionList.filter(item => item !== id);
      for (let k = 0; k < this.checkedIdsFhir.length; k++) {
        const objIndex = this.checkedIdsFhir.findIndex((obj => obj.linkId === id));
        if (objIndex !== -1) {
          this.checkedIdsFhir.splice(objIndex, 1);
          checkedValue = 'UNCHECKED';
        }
      }
    }
    this.clearLowerLoc = false;
    this.getSelectedNextItem(id, checkedValue, this.checkedIdsFhir, this.commentsArray, this.guideLineID, this.clearLowerLoc).subscribe(
      resp => {
        const res = resp.data.getQuestionnaireDetails.questionRes;
        this.handleOnCheck(res,checkedValue,id,event);
      },
      error => {

      }
    );
  }

  handleOnCheck(res,checkedValue,id,event){
    this.getNextItemResponseBody = res;
        let contained = [];
        contained = res.contained;
        if (!this.hideDischarge){
        this.checkForDischargeReview(contained);
        }else{
          this.checkForDischarge(contained);
        }
        this.checkForRedirectSubset(contained, id, checkedValue);
        console.log(`res getSelectedNextItem.....${JSON.stringify(res)}`);
        const frequency = 1;
        let items = [];
        items = res.item;
        this.setPartiallyMetIds(items);
        if (event) {
          let parameters = [];
          parameters = res.contained[0].parameter;
          const containedParameters = res.contained;
          this.setResponseMessageAndType(containedParameters, res);
        } else {
          this.callWhenUnchecked(res, id);
        }
        this.chkids = id;
        this.chkVal = checkedValue;
        this.reviewRes = res;
  }

  checkForDischarge(contained){
      for (let j = 0; j < contained.length; j++) {
        if (contained[j].id === 'outputParameters') {
          for (let k = 0; k < contained[j].parameter.length; k++) {
            if (contained[j].parameter[k].name === 'next_button_text') {
              this.dischargeReview = contained[j].parameter[k].valueString;
            }
          }
        }
      }
    }

  async onSave(): Promise<any> {
    const reviewReqBodyData = [];
    const reviewReqBodyDataObj = {
      id: this.chkids,
      checkValue: this.chkVal,
      reviewUUID: this.reviewUUID,
      stepResponseId: this.stepResponseId,
      subsetUniqueId: this.subsetUniqueId,
      reviewVersion: this.reviewVersion,
      reviewRevision: this.reviewRevision,
      lockedDate: new Date(),
      status: 6,
      guideLineID: this.guideLineID,
      productId: this.productId,
      version: this.versionVal
    };
    reviewReqBodyData.push(reviewReqBodyDataObj);
    this.disablereview = true;
    const metstat = this.metStat;
    console.log(metstat);
    this.cristat =  await this.getCriteriaStatus();
    console.log(this.cristat);
    this.commentsFhir = this.getCommentsFhir(this.commentsArray);
    await this.getRviewDataFromIQForComplete(this.checkedIdsFhir, this.reviewUUID, reviewReqBodyData, this.commentsFhir, metstat);
  }



  async saveReviewToOCM(uuid, revstat, cristat, metstat, primaryClinicalId, guideLineID): Promise<any> {
    console.log(guideLineID);
    const headers = new HttpHeaders().set(this.headerType, this.headerValue)
      .set('authorization', this.microProductAuthService.getEcpToken());
    const name = this.medicalReviewTreeService.getUserName();
    this.medicalReviewTreeService.getHscServices().forEach(item => {
      const hscDetails = {
        hsc_id: item.hsc_id,
        hsc_srvc_id: item.hsc_srvc_id
      };
      this.hscData.push(hscDetails);
    });
    const hscId = this.medicalReviewTreeService.getHscId();
    if (primaryClinicalId === null) {
      this.body1 = {
        hsc_id: this.hscId,
        hsc_srvc_id: this.hscData[0] ? this.hscData[0].hsc_srvc_id : null,
        clin_rev_sys_rec_id: uuid,
        creat_user_id: name,
        clin_rev_sts_ref_id: revstat,
        clin_guid_id: guideLineID,
        clin_rev_otcome_ref_id: cristat,
        med_nec_ind: metstat,
        creat_dttm: new Date(),
        clin_rev_dtl: this.ndtReviewDetails,
        clin_rev_desc: this.nameDraft + ' ' + this.reviewDesc
      };
    } else if (primaryClinicalId !== null) {
      this.body1 = {
        hsc_id: this.hscId,
        hsc_srvc_id: this.hscData[0] ? this.hscData[0].hsc_srvc_id : null,
        clin_rev_sys_rec_id: uuid,
        clin_rev_sts_ref_id: revstat,
        hsc_clin_guid_id: primaryClinicalId,
        creat_user_id: name,
        clin_guid_id: guideLineID,
        clin_rev_otcome_ref_id: cristat,
        med_nec_ind: metstat,
        creat_dttm: new Date(),
        clin_rev_dtl: '',
        clin_rev_desc: this.nameDraft + ' ' + this.reviewDesc
      };
    }
    const res = await this.medicalReviewGraphqlServiceService.saveMedicalReviewDataToOCMDb(this.body1);
    if (res !== undefined && res !== null && !res.errors) {
      console.log(`Data save successfully to DB......${JSON.stringify(res)}`);
      this.primaryClinicalId = res?.data?.saveMedicalReviewDetails?.data?.insert_hsc_clin_guid?.returning[0]?.hsc_clin_guid_id;
    } else{
      console.log(res?.errors);
      if (this.saveCompletedReview === true){
        this.error1.emit(true);
      }
    }
  }

  async saveDraft(): Promise<any> {
    const reviewReqBodyData = [];
    const reviewReqBodyDataObj = {
      id: this.chkids,
      checkValue: this.chkVal,
      reviewUUID: this.reviewUUID,
      stepResponseId: this.stepResponseId,
      subsetUniqueId: this.subsetUniqueId,
      reviewVersion: this.reviewVersion,
      reviewRevision: this.reviewRevision,
      lockedDate: '',
      status: 2,
      guideLineID: this.guideLineID,
      productId: this.productId,
      version: this.versionVal
    };
    reviewReqBodyData.push(reviewReqBodyDataObj);
    this.metstat = this.reviewRes?.contained[0]?.parameter[0]?.valueBoolean === true ? 1 : 0;
    this.cristat = await this.getCriteriaStatus();
    this.commentsFhir = this.getCommentsFhir(this.commentsArray);
    await this.getRviewDataFromIQ(this.checkedIdsFhir, this.reviewUUID, reviewReqBodyData, this.commentsFhir, this.metstat);
  }

  async getRviewDataFromIQ(checkedIds, reviewUUID, reviewReqBodyData, comments, metstat): Promise<any> {
    const headers = new HttpHeaders().set(this.headerType, this.headerValue)
      .set('authorization', this.microProductAuthService.getEcpToken());
    const body = this.medicalReviewTreeService.prepareNDTbodyToSave(checkedIds, reviewUUID, reviewReqBodyData, comments);
    this.ndtReviewDetails = this.medicalReviewTreeService.saveNdtReviewDetails(this.ndtTreeRes, checkedIds, comments);
    console.log(JSON.stringify(body));
    const iqData = await this.medicalReviewGraphqlServiceService.saveMedicalReviewDataToIQ(body);
    if (!iqData?.errors){
      this.reviewDetails = iqData;
      this.reviewRevision = 1;
      this.reviewVersion++;
      this.reviewUUID = iqData?.data?.saveReviewData?.questionRes?.identifier?.value;
      console.log(this.reviewUUID);
      /*this.callOCMDB(metstat, 19274);*/
      await this.saveReviewToOCM(this.reviewUUID, 19274, this.cristat, metstat, this.primaryClinicalId, this.guideLineID);
    } else {
      console.log(iqData?.errors);
    }
  }
  async getLatestEscalatedClinGuidID(): Promise<any> {
    console.log('getLatestEscalatedClinGuidID');
    const res = await this.bedDayDecisionService.getLatestEscalatedGuidID(this.hscId);
    this.mdHscClinGuid = res.data.hsc_clin_guid[0].hsc_clin_guid_id;
    console.log(' this.hscClinGuidID ' +  this.mdHscClinGuid );
  }
  async getRviewDataFromIQForComplete(checkedIds, reviewUUID, reviewReqBodyData, comments, metstat): Promise<any> {
    const headers = new HttpHeaders().set(this.headerType, this.headerValue)
      .set('authorization', this.microProductAuthService.getEcpToken());
    const body = this.medicalReviewTreeService.prepareNDTbodyToSave(checkedIds, reviewUUID, reviewReqBodyData, comments);
    this.ndtReviewDetails = this.medicalReviewTreeService.saveNdtReviewDetails(this.ndtTreeRes, checkedIds, comments);
    console.log(JSON.stringify(body));
    const iqData = await this.medicalReviewGraphqlServiceService.saveMedicalReviewDataToIQ(body);
    if (!iqData?.errors) {
      console.log(`Review_ID......${iqData}`);
      this.reviewDetails = iqData;
      this.reviewRevision = 1;
      this.reviewVersion++;
      this.reviewUUID = this.reviewId;
      await this.getLatestEscalatedClinGuidID();
      this.primaryClinicalId = this.primaryClinicalID ? this.primaryClinicalID : this.mdHscClinGuid;
      console.log(this.reviewUUID);
      this.saveCompletedReview = true;
      await this.saveReviewToOCM(this.reviewUUID, 70107, this.cristat, metstat, this.primaryClinicalId, this.guideLineID);
    }else {
      console.log(iqData?.errors);
      this.error1.emit(true);
    }
  }

  async getCriteriaStatus(): Promise<any> {
    if (this.criteriaMet === 'Criteria Met') {
      return 1;
    } else if (this.criteriaMet === 'Criteria Not Met') {
      return 2;
    } else if (this.criteriaMet === 'Observation Met') {
      return 3;
    } else if (this.criteriaMet === 'Acute Met') {
      return 4;
    } else if (this.criteriaMet === 'Intermediate Met') {
      return 5;
    } else if (this.criteriaMet === 'Critical Met') {
      return 6;
    }
  }

  async getMedicalReviewTreeForUUID(uuid: string): Promise<any> {
    const savedReviewCommentsList = [];
    const medRes = await this.medicalReviewGraphqlServiceService.getMedicalReviewDataFromIQ(uuid);
    console.log('review data existing' + JSON.stringify(medRes));
    const questionReq = medRes.data.getMedicalReviewDetails.reviewRes;
    const obj = {
      name: 'next',
      valueBoolean: false
      };
    questionReq.contained[0].parameter.push(obj);
    console.log('review data existing' + JSON.stringify(questionReq));
    this.savedReviewSelectionList = questionReq.item;
    for (let j = 0; j < this.savedReviewSelectionList.length; j++) {
        if (this.savedReviewSelectionList[j].answer[0].valueBoolean === true) {
          this.checkedIdsFhir.push({
            linkId: this.savedReviewSelectionList[j].linkId,
            answer: [{ valueBoolean: 'true' }]
          });
        }
      }
    questionReq.contained[1].parameter.forEach(element => {
        const commentObj = {
          nodeCid: element.name,
          text: element.valueString,
          user: element.valueId,
          date: element.valueDateTime,
        };
        this.commentsArray.push(commentObj);
      });
    this.overviewText = questionReq.text;
    await this.getNextItemAPICallInFhirDraft(questionReq);
  }

  async getNextItemAPICallInFhirDraft(questionReq): Promise<any> {
    const statusRes = await this.medicalReviewGraphqlServiceService.getExistingQuestionnaireData(questionReq);
    console.log('questionnaire response data existing' + JSON.stringify(statusRes));
    this.response = statusRes.data.getQuestionnaireDetails.questionRes;
    console.log('questionnaire response Fhir' + JSON.stringify(this.response));
    this.reviewDetails = statusRes.data.getQuestionnaireDetails.questionRes;
    this.criteriaMet = this.response.contained[0].parameter[1].valueString;
    this.containedDraft = this.response.contained[2].parameter;
    console.log('questionnaire response data existing' + JSON.stringify(this.containedDraft));
    this.allCheckedSlectionItems = this.response.item;
    for (let j = 0; j < this.allCheckedSlectionItems.length; j++) {
      if (this.allCheckedSlectionItems[j].answer[0].valueBoolean === true) {
        this.allCheckedSelections.push({
          linkId: this.allCheckedSlectionItems[j].id,
          answer: [{ valueBoolean: 'true' }]
        });
      }
    }
    console.log(this.allCheckedSelections);
    for (let i = 0; i < this.containedDraft.length; i++) {
      const title = this.containedDraft[i].name;
      const episodeDay = this.response.contained[0].parameter.filter(param => param.name === 'episode_day_met');
      const episodeValue = this.getDisplayValue(episodeDay[0].valueString);
      if (title !== null && title !== undefined) {
       const text=this.getDisplayValue(title);
        const titleObj = {
          name: text,
          value: text
        };
        const getSelectedEpisode = {
          id: i,
          label: text
        };
        const episode =  this.medicalReviewTreeService.getDropDownEvent();
        console.log(episode);
        if (episodeValue === ''){
          this.selectEpisode = episode;
          this.selectedValue = episode;
        } else {
          this.selectEpisode = episodeValue;
          this.selectedValue = episodeValue;
        }
        this.titlearray.push(titleObj);
        if (episodeValue === getSelectedEpisode.label) {
          await this.onChangeforDraft(getSelectedEpisode.label);
        }
        if (this.criteriaMet === 'Criteria Not Met'){
          await this.onChangeforDraft(this.selectEpisode);
        }
      }
    }
    this.isLoading = false;
    this.reviewUUID = this.reviewId;
    this.stepResponseId = questionReq.contained[0].parameter[0].valueString;
    this.subsetUniqueId = questionReq.questionnaire;
    this.reviewVersion = questionReq.meta.tag[13].display;
    this.reviewRevision = questionReq.meta.tag[12].display;
    this.guideLineID = this.response.meta.tag[2].display;
    this.productId = this.response.meta.tag[0].display;
    this.versionVal = this.response.meta.tag[1].display;
    this.reviewRes = questionReq;
    this.getGuidelineSummary();
  }

  getDisplayValue(title:any){
    let removeBr = title.match(/<b>(.*?)<\/b>/g).map(function(val){
      return val.replace(/<\/?b>/g,'');
    });
   let displayVal = removeBr[0].replace(/,\s*$/, "");
   return displayVal;
  }

  async onChangeforDraft(event: any): Promise<any> {
    let idVal: number;
    let index: number = null;
    if (event !== null && (this.ndtResponse != null)) {
      // this.containedTree = this.ndtResponse['contained'];
      if (this.containedDraft === null || this.containedDraft === undefined) {
        this.containedTree = this.ndtResponse.contained;
      } else {
        this.containedTree = this.containedDraft;
        this.draftFlag = true;
      }
      index = this.getIndex(event);
      this.list = Array.of(this.containedTree[index]);
      const reviewDescription = this.list[0].name;
      this.reviewDesc = reviewDescription.substring(3, reviewDescription.length - 4);
      this.getIds(this.list);
      if (index !== undefined && index !== null) {
        idVal = this.containedTree[index].id;
      }
      this.registerControls(idVal);
      if (this.reviewId !== '' && this.reviewId !== undefined) {
        this.callWhenChecked(this.response);
      }
    }
  }

  changePartiallyMetIds(id: any) {
    if (this.partiallyMetIds && this.partiallyMetIds.length > 0) {
      for (let k = 0; k < this.partiallyMetIds.length; k++) {
        if (this.partiallyMetIds[k].id === id) {
          this.partiallyMetIds[k].partiallyMetIdValue = false;
        }
      }
    }
  }

  setPartiallyMetIds(items: any) {
    this.partiallyMetIds = [];
    for (let i = 0; i < items.length; i++) {
      if (items[i].answer[0].valueBoolean === false) {
        this.partiallyMetIds.push({ id: items[i].id, value: items[i].answer[0].valueBoolean, partiallyMetIdValue: true });
      }
    }
  }

  setResponseMessageAndType(containedParameters, res) {
    console.log('containedParameters setResponseMessageAndType..' + JSON.stringify(containedParameters));
    console.log('res..' + JSON.stringify(res));
    let parameters = [];
    parameters = res.contained[0].parameter;
    for (let j = 0; j < containedParameters.length; j++) {
      if (containedParameters[j].id === 'responseMessages') {
        if (containedParameters[j].parameter !== null && containedParameters[j].parameter !== undefined && containedParameters[j].parameter.length > 0) {
          this.setResponseMsgType(containedParameters[j], parameters);
        } else {
          this.callWhenChecked(res);
        }
      }
    }
  }

  setResponseMsgType(containedParameters, parameters) {
    console.log(`parameters setResponseMsgType....${JSON.stringify(parameters)}`);
    for (let k = 0; k < parameters.length; k++) {
      if (parameters[k].name === 'exceeded_rule.higher_loc_met' && parameters[k].hasOwnProperty('valueString')) {
        this.higherLocMet = parameters[k].valueString;
      }
    }
    console.log(`Higher Loc Met.${this.higherLocMet}`);
    for (let k = 0; k < containedParameters.parameter.length; k++) {
      if (containedParameters.parameter[k].valueString !== null) {
        this.responseMessage = containedParameters.parameter[k].valueString;
        this.resMessageType = containedParameters.parameter[k].name;
        console.log(`this.resMessageType...... ${this.resMessageType}`);
        // this.warningDialogModal.show = true;
        if (this.modal && this.modal !== undefined){
        this.modal.open();
        }
        this.infoInsideError = false;
        console.log(`responseMessage....${JSON.stringify(this.responseMessage)}`);
      }
    }
  }

  clickYes() {
    let subsetUniqueIdVal = '';
    let subsetId = '';
    this.selectedValue = '';
    this.criteriaMet = 'Criteria Not Met';
    for (let j = 0; j < this.subsetRedirectParameters.length; j++) {
      if (this.subsetRedirectParameters[j].name === 'uniqueId') {
        subsetUniqueIdVal = this.subsetRedirectParameters[j].valueString;
      }
      if (this.subsetRedirectParameters[j].name === 'id') {
        subsetId = this.subsetRedirectParameters[j].valueString;
      }
    }
    this.guidelineId = subsetId;
    this.subsetUniqueIdValue = subsetId;
    console.log(`this.subsetUniqueIdValue in clickYes...${JSON.stringify(this.subsetUniqueIdValue)}`);
    this.titlearray = [];
    this.list = [];
    this.isLoading = true;
    this.getInitialNDTTree();
    const stepresponseid = 'RC3::' + subsetId;
    this.checkedIdsFhir = [];
    const headers = { 'Content-Type': this.headerValue, authorization: this.microProductAuthService.getEcpToken() };
    const requestParams = {
      id: this.extendedStayId, checkedValue: this.extendedStayValue, checkedIds: [], stepResponseId: stepresponseid,
      subsetUniqueId: subsetUniqueIdVal, guidelineId: subsetId, clearLowerLoc: false, productId: this.productId, versionVal: this.versionVal
      , dischargeReviewFlag: this.dischargeReviewFlag
    };
    const body = this.medicalReviewTreeService.prepareJsonToCallGetNextItemFhir(requestParams);
    console.log(`body...${JSON.stringify(body)}`);
    // this.warningDialogModal.show = false;
  }

  clickOkInfo() {
    this.warningDialogModal.show = false;
    const containedParameters = this.getNextItemResponseBody.contained;
    this.checkForDischargeReview(containedParameters);
    if (!this.infoInsideError) {
      this.callWhenChecked(this.getNextItemResponseBody);
    }
  }

  clickCancelError() {
    if (this.redirectSubsetFlag) {
      this.redirectSubsetFlag = false;
    }
    const lastSelectedId = this.checkedIdsFhir.pop()?.linkId;
    if (lastSelectedId && this.medReviewTreeForm?.get(lastSelectedId) !== null) {
      this.medReviewTreeForm?.get(lastSelectedId)?.patchValue(false);
    }
    this.warningDialogModal.show = false;
  }

  checkForDischargeReview(containedParameters){
    console.log('containedParameters checkForDischargeReview..' + JSON.stringify(containedParameters));
    for (let j = 0; j < containedParameters.length; j++) {
      if (containedParameters[j].id === 'outputParameters') {
        for (let k = 0; k < containedParameters[j].parameter.length; k++) {
          if (containedParameters[j].parameter[k].name === 'next_button_text') {
            this.dischargeReview = containedParameters[j].parameter[k].valueString;
          }
        }
      }
    }
    if (this.dischargeReview === 'Discharge Review'){
      this.dischargeReviewFlag = true;
    }else{
      this.dischargeReviewFlag = false;
    }
  }

  handleGetNextItemIdsBeforeOk() {
    for (let j = 0; j < this.getNextItemResponseBody.item.length; j++) {
      this.getNextItemIdsBeforeOK.push(this.getNextItemResponseBody.item[j].id);
    }
  }

  handleGetNextItemIdsAfterOk(res: any) {
    for (let j = 0; j < res.item.length; j++) {
      this.getNextItemIdsAfterOK.push({ id: res.item[j].id, value: res.item[j].answer[0].valueBoolean });
    }
    for (let j = 0; j < res.item.length; j++) {
      if (this.medReviewTreeForm.get(this.getNextItemIdsAfterOK[j].id) !== null && this.getNextItemIdsAfterOK[j].value === false) {
        const objIndex = this.checkedIdsFhir.findIndex((obj => obj.linkId === this.getNextItemIdsAfterOK[j].id));
        this.checkedIdsFhir.splice(objIndex, 1);
      }
    }
  }

  updateUiForDifferentVal(differentElements: any) {
    this.choices = [];
    for (let j = 0; j < differentElements.length; j++) {
      if (this.medReviewTreeForm.get(differentElements[j]) !== null) {
        this.choices.push({ id: differentElements[j], value: 'CHECKED', frequency: 0 });
        this.medReviewTreeForm.get(differentElements[j])?.patchValue(false);
      }
    }
  }

  clickOkErrorFalse() {
    console.log(`clickOkErrorFalse`);
    const lastSelectedId = this.checkedIdsFhir.pop().linkId;
    if (this.medReviewTreeForm.get(lastSelectedId) !== null) {
      this.medReviewTreeForm.get(lastSelectedId).patchValue(false);
    }
    this.warningDialogModal.show = false;
    console.log(`this.checkIdsFhir after. clickOkErrorFalse. ${JSON.stringify(this.checkedIdsFhir)}`);
  }

  updateUiForAfterOkRes() {
    for (let j = 0; j < this.getNextItemIdsAfterOK.length; j++) {
      if (this.medReviewTreeForm.get(this.getNextItemIdsAfterOK[j].id) !== null) {
        this.choices.push({ id: this.getNextItemIdsAfterOK[j].id, value: 'CHECKED', frequency: 0 });
        this.medReviewTreeForm.get(this.getNextItemIdsAfterOK[j].id)?.patchValue(this.getNextItemIdsAfterOK[j].value);
      }
    }
  }

  clickOkError() {
    this.warningDialogModal.show = false;
    this.updateTree = true;
    this.getNextItemIdsBeforeOK = [];
    this.handleGetNextItemIdsBeforeOk();
    let differentElements = [];
    this.getNextItemIdsAfterOK = [];
    this.getNextItem().subscribe(
      (resp: any) => {
        const res = resp.data.getQuestionnaireDetails.questionRes;
        this.handleDifferentElements(differentElements,res);
      });
  }

  handleDifferentElements(differentElements,res){
    console.log("differentElements.."+JSON.stringify(differentElements));
    console.log("res.."+JSON.stringify(res));
    this.handleGetNextItemIdsAfterOk(res);
    /*Getting ids which are present in response before clicking ok and not present after clicking ok */
    differentElements = this.getNextItemIdsBeforeOK.filter((x: any) => !this.getNextItemIdsAfterOK.includes(x));
    this.updateUiForDifferentVal(differentElements);
    this.updateUiForAfterOkRes();
    let parameters = [];
    parameters = res.contained[0].parameter;
    const containedParameters = res.contained;
    this.setResMsgAndType(containedParameters);
    this.setCriteriaMetVal(parameters);
  }

  setCriteriaMetVal(parameters: any) {
    for (let k = 0; k < parameters.length; k++) {
      if (parameters[k].name === 'criteria_met') {
        this.criteriaMet = parameters[k].valueString;
      }
    }
  }

  setResponseMsg(containedParameters: any) {
    for (let k = 0; k < containedParameters.parameter.length; k++) {
      if (containedParameters.parameter[k].name === 'INFO' && containedParameters.parameter[k].valueString !== null) {
        this.responseMessage = containedParameters.parameter[k].valueString;
        this.resMessageType = containedParameters.parameter[k].name;
        // this.warningDialogModal.show = true;
        if (this.modal && this.modal !== undefined){
        this.modal.open();
        }
        this.infoInsideError = true;
      }
    }
  }

  setResMsgAndType(containedParameters: any) {
    for (let j = 0; j < containedParameters.length; j++) {
      if (containedParameters[j].id === 'responseMessages') {
        if (containedParameters[j].parameter !== null && containedParameters[j].parameter !== undefined && containedParameters[j].parameter.length > 0) {
          this.setResponseMsg(containedParameters[j]);
        }
      }
    }
  }

  getNextItem() {
    let arr = [];
    arr = this.getNextItemBody.contained[0].parameter;
    for (let j = 0; j < arr.length; j++) {
      if (arr[j].name === 'clear_lower_loc') {
        this.getNextItemBody.contained[0].parameter[j].valueBoolean = true;
      }
    }
    const headers: any = { 'Content-Type': this.headerValue, authorization: this.microProductAuthService.getEcpToken() };
    return this.medicalReviewGraphqlServiceService.getSelectionData(this.getNextItemBody);
  }

  callWhenChecked(res: any) {
    this.checkboxState = 'active';
    let parameters = [];
    parameters = res.contained[0].parameter;
    const containedParameters = res.contained;
    for (let j = 0; j < containedParameters.length; j++) {
      if (containedParameters[j].id === 'outputParameters') {
        for (let k = 0; k < containedParameters[j].parameter.length; k++) {
          if (containedParameters[j].parameter[k].name === 'criteria_met') {
            this.criteriaMet = containedParameters[j].parameter[k].valueString;
          }
        }
      }
    }
    let selected = [];
    selected = res.item;
    this.choices = [];
    this.updateUiWithSelection(selected);
  }

  updateUiWithSelection(selected: any) {
    if (selected !== null && selected !== undefined && selected.length > 0) {
      for (let k = 0; k < selected.length; k++) {
        if (selected[k].hasOwnProperty('answer')) {
          this.choices.push({ id: selected[k].id, value: selected[k].answer[0].valueBoolean, frequency: 0 });
          if (this.medReviewTreeForm.get(selected[k].id) !== null) {
            this.medReviewTreeForm.get(selected[k].id)?.patchValue(selected[k].answer[0].valueBoolean);
          }
        }
      }
    }
  }

  callWhenUnchecked(res: any, id: any) {
    this.checkboxState = 'default';
    let selected = [];
    let parameters = [];
    parameters = res.contained[0].parameter;
    for (let k = 0; k < parameters.length; k++) {
      if (parameters[k].name === 'criteria_met') {
        this.criteriaMet = parameters[k].valueString;
      }
    }
    selected = res.item;
    for (let j = 0; j < this.choices.length; j++) {
      if (this.medReviewTreeForm.get(this.choices[j].id) !== null) {
        this.medReviewTreeForm.get(this.choices[j].id)?.patchValue(false);
      }
    }
    this.choices = [];
    for (let j = 0; j < selected.length; j++) {
      if (this.medReviewTreeForm.get(selected[j].id) !== null) {
        this.medReviewTreeForm.get(selected[j].id)?.patchValue(true);
      }
      this.choices.push({ id: selected[j].id, value: selected[j].choice, frequency: 0 });
    }
  }

  getSelectedNextItem(id, checkedValue, checkedIds, commentsArray, guideLineID, clearLowerLoc): Observable<any> {
    const headers = { 'Content-Type': this.headerValue, authorization: this.microProductAuthService.getEcpToken() };
    console.log(`checkedIds before...${JSON.stringify(checkedIds)}`);
    console.log(`checkedIds after...${JSON.stringify(checkedIds)}`);
    console.log(`commentsArray....${JSON.stringify(commentsArray)}`);
    const requestParams = {
      id, checkedValue, checkedIds, stepResponseId: this.stepResponseId,
      subsetUniqueId: this.subsetUniqueId, guidelineId: guideLineID, clearLowerLoc, productId: this.productId,
      versionVal: this.versionVal, dischargeReviewFlag: this.dischargeReviewFlag
    };
    const body = this.medicalReviewTreeService.prepareJsonToCallGetNextItemFhir(requestParams);
    this.getNextItemBody = body;
    console.log('getSelectedNextItem body in getSelectedNextItem.....' + JSON.stringify(this.getNextItemBody));
    return this.medicalReviewGraphqlServiceService.getSelectionData(body);
  }

  clickDischargePrev(){
    this.titlearray = [];
    this.selectedValue = this.prevSelectedValue;
    this.titlearray = this.titleArrayPrev;
    this.previousInd = false;
    this.list = this.prevList;
    this.dischargeReviewFlag = true;
  }


  clickDischarge() {
    this.hideDischarge = true;
    this.prevSelectedValue = this.selectedValue;
    this.selectedValue = '';
    this.selectEpisode = 'Discharge';
    console.log('discharge review');
    this.titleArrayPrev = this.titlearray;
    this.titlearray = [];
    this.dischargeReviewFlag = false;
    console.log('dischargeflag' + this.dischargeReviewFlag);
    console.log('clickDischarge body..' + JSON.stringify(this.getNextItemBody));
    const parameters = this.getNextItemBody.contained[0].parameter;
    console.log('parameters..' + JSON.stringify(parameters));
    this.prevList = this.list;
    for (let k = 0; k < parameters.length; k++) {
      if (parameters[k].name === 'next') {
        this.getNextItemBody.contained[0].parameter[k].valueString = 'true';
      }
    }
    this.getNextItem().subscribe(
      (resp: any) => {
        const res = resp.data.getQuestionnaireDetails.questionRes;
        console.log('response...' + JSON.stringify(res));
        const containedParameters = res.contained;
        this.getDischargeTree(containedParameters);
        this.previousInd = true;
      });
  }

  clickPrevious(){
    this.hideDischarge = false;
    this.list = [];
    this.titlearray = [];
    let idVal: number;
    let index: number = null;
    this.selectEpisode = '';
    if (this.previousEventValue !== null && (this.ndtResponse != null)) {
      console.log(this.previousEventValue);
      console.log(JSON.stringify(this.ndtResponse));
      console.log(JSON.stringify(this.containedDraft));
      if (this.containedDraft === null || this.containedDraft === undefined) {
        this.containedTree = this.ndtResponse.contained;
      } else {
        this.containedTree = this.containedDraft;
        this.draftFlag = true;
      }
      const eventVal = this.previousEventValue;
      index = this.getIndex(this.previousEventValue);
      this.list = Array.of(this.containedTree[index]);
      const reviewDescription = this.list[0]?.name;
      this.getTitleArray(this.containedTree);
      this.reviewDesc = reviewDescription?.substring(3, reviewDescription.length - 4);
      this.selectEpisode = this.reviewDesc;
      this.getIds(this.list);
      if (index !== undefined && index !== null) {
        idVal = this.containedTree[index].id;
      }
      this.registerControls(idVal);
    }
    this.previousFlag = false;
  }

  getDischargeTree(containedParameters) {
    console.log('containedParameters..' + JSON.stringify(containedParameters));
    for (let j = 0; j < containedParameters.length; j++) {
      if (containedParameters[j].id === 'discharge_cp_tree') {
        this.list = containedParameters[j].parameter;
        console.log('this.list.. clickdischarge' + JSON.stringify(this.list));
        for (let k = 0; k < this.list.length; k++) {
          this.dischargeIdsArray.push(this.list[k].id);
        }
      }
    }
    console.log('this.dischargeIdsArray..' + JSON.stringify(this.dischargeIdsArray));
    const idVal = '';
    this.getIds(this.list);
    this.registerControls(idVal);
    console.log('idval' + idVal);
  }

  getIcon(item) {
    item.showMyContainer = !item.showMyContainer;
    if (item.showMyContainer) {
      this.icon = 'arrow_up';
    } else {
      this.icon = 'arrow_down';
    }
    return this.icon;
  }

  commentChangedHandler(e: any) {
    console.log(JSON.stringify(e));
    e.forEach(item => {
      console.log(this.getcompare(this.commentsArray, item));
      if (this.getcompare(this.commentsArray, item) === 0) {
        this.commentsArray.push(item);
      }
    });
    console.log(this.commentsArray);
    console.log(`commentChangedHandler`);
    console.log(e);
    for (let l = 0; l < this.commentsArray.length; l++) {
      if (this.showcp.linkId === this.commentsArray[l].nodeCid || this.showcp.id === this.commentsArray[l].nodeCid) {
        this.showcp.alertCommentAdded = false;
      }
    }
  }

  getCommentsFhir(commentsArray: any) {
    const commentFhir: any = [];
    commentsArray.forEach((item: any) => {
      const fhircommentObj = {
        name: item.nodeCid,
        valueId: item.user,
        valueDateTime: item.date,
        valueString: item.text
      };
      commentFhir.push(fhircommentObj);
    });
    return commentFhir;
  }

  getcompare(ca: any, item): any {
    this.returnComment = 0;
    ca.forEach(comment => {
      if (item.nodeCid === comment.nodeCid && item.date === comment.date && item.text === comment.text) {
        console.log(item);
        this.returnComment = 1;
      }
    });
    return this.returnComment;
  }

  editButton(){
    this.editReview.emit(true);
  }

  gettingNdtTreeResp(res){
    console.log('calling gettingNdtTreeResp...');
    this.ndtTreeRes = res;
  }

  closeCard(): any{
    this.closecard = !this.closecard;
  }
}

interface Choice {
  id: string;
  value: string;
  frequency: number;

}

interface PartiallyMet {
  id: string;
  value: boolean;
  partiallyMetIdValue: boolean;

}

interface Selection {
  id: string;
  choice: string;
}

interface SelectionFhir {
  linkId: string;
  answer: [{
    valueBoolean: string
  }];
}

interface Comment {
  text: string;
  userName: string;
  dateTime: string;
}

interface SubsetRedirectParameters {
  name: string;
  valueString: any;
}

export interface Task {
  name: string;
  completed: boolean;
  color: ThemePalette;
  subtasks?: Task[];
}
