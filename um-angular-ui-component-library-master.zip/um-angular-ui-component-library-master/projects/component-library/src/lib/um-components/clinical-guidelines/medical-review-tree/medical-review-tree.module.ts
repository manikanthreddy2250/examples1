import { APP_BASE_HREF, CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { TabsModule } from '@ecp/angular-ui-component-library/tabs';
import { MatGridListModule } from '@angular/material/grid-list';
import { ButtonModule } from '@ecp/angular-ui-component-library/button';
import { IconsModule } from '@ecp/angular-ui-component-library/icons';
import { CardModule } from '@ecp/angular-ui-component-library/card';
import { MatIconModule } from '@angular/material/icon';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { HttpClientModule } from "@angular/common/http";
import { CheckboxModule } from '@ecp/angular-ui-component-library/checkbox';
import { AuthLibraryModule } from "@ecp/auth-library";
import { MedicalReviewTreeComponent } from './medical-review-tree.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SelectModule } from '@ecp/angular-ui-component-library/select';
import { InputModule } from '@ecp/angular-ui-component-library/input';
import { OptionModule } from '@ecp/angular-ui-component-library/option';
import { ModalModule } from '@ecp/angular-ui-component-library/modal';
import {MenuPopupModule } from '@ecp/angular-ui-component-library/menu-popup';
import {FormFieldModule} from '@ecp/angular-ui-component-library/form-field';
import { LinkModule } from '@ecp/angular-ui-component-library/link';
import {MedicalReviewCommentsModule} from '../medical-review-comments/medical-review-comments.module';
import {MedicalReviewNotesModule} from '../medical-review-notes/medical-review-notes.module';
import {MedicalReviewCitationsModule} from '../medical-review-citations/medical-review-citations.module';
import {Popup} from '@ecp/angular-ui-component-library/utilities';
import { GuidelineSummaryModule } from '../guideline-summary/guideline-summary.module';
import { MatSidenavModule } from '@angular/material/sidenav';
import { AccordianModule } from '@ecp/angular-ui-component-library/accordian';
import {ScrollbarModule} from "@ecp/angular-ui-component-library/scrollbar";
import { MedicalReviewErrorsModule } from '../medical-review-errors/medical-review-errors.module';
import {ButtonGroupModule} from '@ecp/angular-ui-component-library/button-group';
import { IndexUtilityModule } from '../index-utility/index-utility.module';
import { DocumentUtilityModule } from '../document-utility/document-utility.module';
import {AutoReviewTreeModule} from "../auto-review-tree/auto-review-tree.module";
import {ProgressSpinnerModule} from "@ecp/angular-ui-component-library/progress-spinner";


@NgModule({
    declarations: [MedicalReviewTreeComponent],
    imports: [
        CommonModule,
        BrowserModule,
        ModalModule,
        SelectModule,
        InputModule,
        OptionModule,
        BrowserAnimationsModule,
        MatGridListModule,
        MatIconModule,
        FormsModule,
        ReactiveFormsModule,
        ButtonModule,
        ButtonGroupModule,
        CardModule,
        TabsModule,
        IconsModule,
        AuthLibraryModule,
        HttpClientModule,
        CheckboxModule,
        FormFieldModule,
        LinkModule,
        MenuPopupModule,
        MedicalReviewCommentsModule,
        MedicalReviewNotesModule,
        MedicalReviewErrorsModule,
        MedicalReviewCitationsModule,
        GuidelineSummaryModule,
        MatSidenavModule,
        AccordianModule,
        DocumentUtilityModule,
        ScrollbarModule,
        IndexUtilityModule,
        AutoReviewTreeModule,
        ProgressSpinnerModule
    ],
    exports: [
        MedicalReviewTreeComponent
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA],
    providers: [Popup]
})
export class MedicalReviewTreeModule { }
