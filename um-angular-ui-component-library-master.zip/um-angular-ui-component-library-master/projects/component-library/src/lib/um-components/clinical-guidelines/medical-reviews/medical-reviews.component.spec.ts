/*
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MedicalReviewsComponent } from './medical-reviews.component';
import {ChangeDetectorRef, CUSTOM_ELEMENTS_SCHEMA, Injectable, NO_ERRORS_SCHEMA} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import {MedicalReviewsModule} from './medical-reviews.module';
import {of} from 'rxjs';
import { MedicalReviewGraphqlServiceService } from '../../services/um/service/clinical-guidelines/medical-review-graphql-service/medical-review-graphql-service.service';

describe('MedicalReviewsComponent', () => {
  let component: MedicalReviewsComponent;
  let httpClient: HttpClient;
  let medicalReviewGraphqlServiceService: MedicalReviewGraphqlServiceService;
  let fixture: ComponentFixture<MedicalReviewsComponent>;
  const reviewList = {
    "data": {
      "getMedicalReviewGridDetails": {
        "medicalReviewGridDetailsRes": {
          "resourceType": "Bundle",
          "entry": [
            {
              "resourceType": "Questionnaire",
              "id": 3398,
              "description": "COPD Episode Day 1",
              "meta": {
                "lastUpdated": "2021-07-01T06:28:37.574",
                "tag": [
                  {
                    "code": "reviewStatus",
                    "display": "Draft"
                  },
                  {
                    "code": "reviewId",
                    "display": "9672544f-2837-4096-a4fd-7921ed3f4d72"
                  },
                  {
                    "code": "createdBy",
                    "display": "Lakshmana Kumar Veerla"
                  },
                  {
                    "code": "reviewDesc",
                    "display": "COPD Episode Day 1"
                  },
                  {
                    "code": "decisionOtCm"
                  },
                  {
                    "code": "accumbedday"
                  },
                  {
                    "code": "recommendation",
                    "display": "Not Met"
                  },
                  {
                    "code": "createDate",
                    "display": "2021-07-01T06:28:37.574"
                  }
                ]
              }
            },
            {
              "resourceType": "Questionnaire",
              "id": 3397,
              "description": "COPD Episode Day 1",
              "meta": {
                "lastUpdated": "2021-07-01T06:28:20.28",
                "tag": [
                  {
                    "code": "reviewStatus",
                    "display": "Draft"
                  },
                  {
                    "code": "reviewId",
                    "display": "9672544f-2837-4096-a4fd-7921ed3f4d72"
                  },
                  {
                    "code": "createdBy",
                    "display": "Lakshmana Kumar Veerla"
                  },
                  {
                    "code": "reviewDesc",
                    "display": "COPD Episode Day 1"
                  },
                  {
                    "code": "decisionOtCm"
                  },
                  {
                    "code": "accumbedday"
                  },
                  {
                    "code": "recommendation",
                    "display": "Not Met"
                  },
                  {
                    "code": "createDate",
                    "display": "2021-07-01T06:28:20.28"
                  }
                ]
              }
            }
          ],
          "type": "searchset",
          "total": 2
        }
      }
    }
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [],
      providers: [
      ],
      imports: [HttpClientTestingModule, MedicalReviewsModule],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MedicalReviewsComponent);
    component = fixture.componentInstance;
    httpClient =  TestBed.inject(HttpClient);
    medicalReviewGraphqlServiceService =  TestBed.inject(MedicalReviewGraphqlServiceService);
    fixture.detectChanges();
  });

  xit('should create', () => {
    expect(component).toBeTruthy();
  });

  xit('should create getMedicalReviewList', () => {
    const reviewData = spyOn(medicalReviewGraphqlServiceService, 'getMedicalReviewGridData').and.returnValue(of(reviewList));
    component.ngOnInit();
    expect(reviewData).toHaveBeenCalled();
    expect(component.getMedicalReviewList).toBeTruthy();
  });
   it('should  getDisplayDate', () => {
     component.getDisplayDate('2021-05-07T16:56:25.658');
     expect(component.getDisplayDate).toBeTruthy();
   });
  xit('should getRecommendation', () => {
    component.getRecommendation(1);
    expect(component.getRecommendation).toBeTruthy();
  });
  it('should createNewReview', () => {
    component.createNewReview(1);
    expect(component.createNewReview).toBeTruthy();
  });

  it('should openCompletedReview', () => {
    component.openCompletedReview('1', 2134);
    expect(component.openCompletedReview).toBeTruthy();
  });

  xit('should getRecommendation 0', () => {
    component.getRecommendation(0);
    expect(component.getRecommendation).toBeTruthy();
  });
  xit('should getRecommendation default', () => {
    component.getRecommendation(5);
    expect(component.getRecommendation).toBeTruthy();
  });

  it('should openDraftReview', () => {
    component.openDraftReview('a2cb9d11-7ddf-4def-8651-1c99c8bb5759', 1243);
    expect(component.openDraftReview).toBeTruthy();
  });
  it('should openCompletedReview', () => {
      component.openCompletedReview('a2cb9d11-7ddf-4def-8651-1c99c8bb5759', 1234);
      expect(component.openCompletedReview).toBeTruthy();
    });

});
*/
