import {
  ViewChild,
  OnInit,
  AfterViewInit,
  Component,
  Input,
  AfterContentChecked,
  ChangeDetectorRef,
  EventEmitter, Output
} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Observable} from 'rxjs';
import { EcpUclPaginator } from '@ecp/angular-ui-component-library/paginator';
import { EcpUclTableDataSource } from '@ecp/angular-ui-component-library/table';
import { EcpUclSort } from '@ecp/angular-ui-component-library/sort';
import { CaseHeaderService } from '../../services/um/service/case-header/case-header.service';
import { MedicalReviewGraphqlServiceService } from '../../services/um/service/clinical-guidelines/medical-review-graphql-service/medical-review-graphql-service.service';



@Component({
  // tslint:disable-next-line:component-selector
  selector: 'app-medical-reviews-component',
  templateUrl: './medical-reviews.component.html',
  styleUrls: ['./medical-reviews.component.scss']
})
export class MedicalReviewsComponent implements OnInit, AfterViewInit, AfterContentChecked {
  @Input() hscId: any;
  @Input() application: any;
  @Input() processTaskExecutionID: string;
  @Input() hideCreateButton: boolean;
  @ViewChild(EcpUclPaginator) paginator: EcpUclPaginator;
  @ViewChild(EcpUclSort) sort: EcpUclSort;
  @Output() action: EventEmitter<any> = new EventEmitter();
  @Output() nurseFlowStart: EventEmitter<any> = new EventEmitter();
  @Output() isCompleteReviewEvent: EventEmitter<any> = new EventEmitter();
  data: EcpUclTableDataSource<any>;
  medicalReviewList: Array<ReviewSummaryData> = [];
  subsetSearchDetailsJSON =  [];
  showReviews = true;

  showTree = false;
  newReviewData: any;
  draftReviewData; any;
  completeReviewData: any;
  enableNewReview = false;
  pageOptions = [5, 10, 25];
   headers = ['reviewDesc', 'createdBy', 'createDate', 'reviewStatus', 'recommendation', 'bedDays', 'decisions', 'actions'];
  // TODO replace below declarations once the nestjs api is ready

  readonly httpUrl: string = 'https://dev-ecp-api.optum.com/health-service/v1/graphql';
  clinParams: any = {};
  clinHeaderParams: any = {};
  private readonly staticParams: any = {'content-type': 'application/json'};
  isCompleteReviewFlag: boolean = false;
  reviewId:string

  constructor(private readonly http: HttpClient, private readonly caseHeaderService: CaseHeaderService, private cdref: ChangeDetectorRef, private readonly medicalReviewGraphqlServiceService: MedicalReviewGraphqlServiceService) {
    this.clinHeaderParams = {'x-hasura-admin-secret': 'healthservicesecretkey'};
    this.clinParams = {headers: {...this.staticParams, ...this.clinHeaderParams}};
  }

  ngOnInit() {
    this.getMedicalReviewList(this.hscId);
  }

  ngAfterViewInit() {
     this.cdref.detectChanges();
  }
  ngAfterContentChecked() {
    this.cdref.detectChanges();
  }

  async getMedicalReviewList(hscId): Promise<any> {
     this.medicalReviewList = [];
     const reviewList = await this.medicalReviewGraphqlServiceService.getMedicalReviewGridData(hscId).toPromise();
     reviewList.data.getMedicalReviewGridDetails.medicalReviewGridDetailsRes.entry?.forEach( ( async (item) => {
       const medicalReviewObj: ReviewSummaryData = {
         reviewStatus: item['meta']['tag'].filter(i=>i.code==='reviewStatus')[0].display,
         reviewId: item['meta']['tag'].filter(i=>i.code==='reviewId')[0].display,
         hscClinGuid: item.id,
         recommendation: item['meta']['tag'].filter(i=>i.code==='recommendation')[0].display,
         createdBy: item['meta']['tag'].filter(i=>i.code==='createdBy')[0].display,
         createDate: this.getDisplayDate(item['meta'].lastUpdated),
         reviewDesc: item.description,
         decisions: {
           decisionOtCm:  item['meta']['tag'].filter(i=>i.code==='decisionOtCm')[0].display,
           decisionOtCmRefID:  item['meta']['tag'].filter(i=>i.code==='decisionOtCmRefID')[0].display,
           accumbedday: item['meta']['tag'].filter(i=>i.code==='accumbedday')[0].display},
       };
       this.medicalReviewList.push(medicalReviewObj);
     }));
     console.log(this.medicalReviewList);
     this.data = new EcpUclTableDataSource(this.medicalReviewList);
     this.data.sort = this.sort;
     this.data.paginator = this.paginator;
  }
  getDisplayDate(dateStr): any {​​​​​​​​
    if (dateStr) {​​​​​​​​
       const date = new Date(dateStr);
       return date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate();
    }​​​​​​​​
  }​​​​​​​​
  createNewReview(e: any): any{
    this.newReviewData = {
     enableNewReview: true
   };
    this.action.emit(this.newReviewData);
  };

  openCompletedReview(reviewId: any, hscClinGuid: any): any {
    this.isCompleteReviewFlag = true;
    this.completeReviewData = {
      reviewId,
      hscClinGuid,
      isCompleteReviewFlag: this.isCompleteReviewFlag
    };
    this.isCompleteReviewEvent.emit(this.completeReviewData);
  }

  openDraftReview(reviewId: any, hscClinGuid: any): any{
     this.draftReviewData = {
       reviewId,
       hscClinGuid
    };
   // this.reviewId = reviewId;
    this.showTree = true;
    this.nurseFlowStart.emit(this.draftReviewData);
  }

  getRecommendation(value): any {
    switch (value) {
      case 1: return 'Met';
      case 0: return 'Not Met';
      default: return value;
    }
  }
​​​
}

interface ReviewSummaryData {
  reviewStatus: any;
  recommendation: any;
  createdBy: any;
  createDate: any;
  reviewDesc: any;
  decisions: Decision;
  reviewId: any;
  hscClinGuid: any;
  // bedday: any;
}

interface Decision {
  decisionOtCm: any;
  accumbedday: any;
  decisionOtCmRefID: any;
}
