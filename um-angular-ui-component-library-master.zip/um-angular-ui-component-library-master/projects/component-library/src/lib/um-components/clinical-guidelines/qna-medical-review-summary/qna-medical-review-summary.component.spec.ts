import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {QnaMedicalReviewService} from '../../services/um/service/clinical-guidelines/qna-medical-review-service/qna-medical-review.service';
import {AccordianModule} from '@ecp/angular-ui-component-library/accordian';
import {BrowserModule} from '@angular/platform-browser';
import {SelectModule} from '@ecp/angular-ui-component-library/select';
import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA} from '@angular/core';
import {ModalModule} from '@ecp/angular-ui-component-library/modal';
import {HttpClientModule} from '@angular/common/http';
import {TabsModule} from '@ecp/angular-ui-component-library/tabs';
import {CheckboxModule} from '@ecp/angular-ui-component-library/checkbox';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {IconsModule} from '@ecp/angular-ui-component-library/icons';
import {of} from 'rxjs';
import {OptionModule} from '@ecp/angular-ui-component-library/option';
import {CommonModule} from '@angular/common';
import {CardModule} from '@ecp/angular-ui-component-library/card';
import {MatIconModule} from '@angular/material/icon';
import {ButtonModule} from '@ecp/angular-ui-component-library/button';
import {FormFieldModule} from '@ecp/angular-ui-component-library/form-field';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import {AuthLibraryModule} from '@ecp/auth-library';
import {MatGridListModule} from '@angular/material/grid-list';
import {QnaMedicalReviewSummaryComponent} from './qna-medical-review-summary.component';

describe('QnaMedicalReviewSummaryComponent', () => {
  let component: QnaMedicalReviewSummaryComponent;
  let fixture: ComponentFixture<QnaMedicalReviewSummaryComponent>;
  let qnaMedicalReviewService: QnaMedicalReviewService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        CommonModule,
        BrowserModule,
        SelectModule,
        OptionModule,
        BrowserAnimationsModule,
        MatGridListModule,
        MatIconModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientTestingModule,
        ButtonModule,
        CardModule,
        TabsModule,
        IconsModule,
        AuthLibraryModule,
        HttpClientModule,
        CheckboxModule,
        ModalModule,
        FormFieldModule,
        AccordianModule,
      ],
      declarations: [QnaMedicalReviewSummaryComponent],
      providers: [QnaMedicalReviewService, {
        provide: QnaMedicalReviewService,
        useClass: QnaMedicalReviewService
      }],

      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QnaMedicalReviewSummaryComponent);
    qnaMedicalReviewService = TestBed.inject(QnaMedicalReviewService);
    component = fixture.componentInstance;

  });

  afterEach(() => {
    fixture.destroy();
  });

  it('Should test getQnaMedicalReviewForUUID', () => {
    const test = {
      data: {
        getMedicalReviewDetails: {
          reviewRes: {
            resourceType: 'QuestionnaireResponse',
            id: 354001,
            status: 2,
            questionnaire: 354001,
            text: '<p>I/O Setting: Inpatient</p><br/><p>These criteria include the following procedure:&nbsp;&nbsp;&nbsp;&nbsp;</p> <p>Fusion, Ankle&nbsp;&nbsp;&nbsp;&nbsp;</p><br/><p><b>Def:</b> Arthrodesis is the surgical fusion of a joint. The procedure relieves joint pain and achieves joint stability; joint motion is lost when an arthrodesis is performed.&nbsp;&nbsp;&nbsp;&nbsp;</p><br/><p>Because arthrodesis results in transmission of force to adjacent joints, it is performed when there is little degenerative disease in the adjacent joints and is preferred for patients placing heavy physical demands on the joint.&nbsp;&nbsp;&nbsp;&nbsp;</p><br/><p>A patient\'s body mass index (BMI) must be considered prior to ankle arthrodesis or total joint replacement (TJR) because several large cohort studies showed that being overweight or obese increased the risk for venous thromboembolism and other complications, especially in the presence of comorbid conditions (e.g., diabetes, metabolic syndrome, cardiovascular disease) (<bib rel=citation title=Werner et al., Foot &amp; ankle international 2015: href=/caas/citations/14413 id=14413>Werner et al., Foot &amp; ankle international 2015:</bib>; <bib rel=citation title=Mihalko et al., The Journal of the American Academy of Orthopaedic Surgeons 2014, 22: 683-90 href=/caas/citations/14403 id=14403>Mihalko et al., The Journal of the American Academy of Orthopaedic Surgeons 2014, 22: 683-90</bib>; <bib rel=citation title=Pakzad et al., The Journal of bone and joint surgery. American volume 2014, 96: 32-9 href=/caas/citations/14406 id=14406>Pakzad et al., The Journal of bone and joint surgery. American volume 2014, 96: 32-9</bib>). </p><br/><p>Cigarette smoking is associated with multiple complications (e.g., slowed wound healing, increased risk for infection, delayed bone union, inhibited healing after autologous chondrocyte implantation, the development of avascular necrosis). For this reason, foot and ankle surgeons should encourage patients to abstain from smoking prior to and after orthopedic procedures to promote optimal recovery (<bib rel=citation title=Scolaro et al., The Journal of bone and joint surgery. American volume 2014, 96: 674-81 href=/caas/citations/14371 id=14371>Scolaro et al., The Journal of bone and joint surgery. American volume 2014, 96: 674-81</bib>; <bib rel=citation title=Malay, The Journal of foot and ankle surgery: official publication of the American College of Foot and Ankle Surgeons 2011, 50: 515-6 href=/caas/citations/1464248 id=1464248>Malay, The Journal of foot and ankle surgery: official publication of the American College of Foot and Ankle Surgeons 2011, 50: 515-6</bib>; <bib rel=citation title=Mills et al., The American journal of medicine 2011, 124: 144-54 e8 href=/caas/citations/14362 id=14362>Mills et al., The American journal of medicine 2011, 124: 144-54 e8</bib>; <bib rel=citation title=Myers et al., Archives of internal medicine 2011, 171: 983-9 href=/caas/citations/14373 id=14373>Myers et al., Archives of internal medicine 2011, 171: 983-9</bib>). </p><br/><p>InterQual® Procedures criteria are derived from the systematic, continuous review and critical appraisal of the most current evidence-based literature and include input from our independent panel of clinical experts. To generate the most appropriate recommendations, a comprehensive literature review of the clinical evidence was conducted. Sources searched included PubMed, Agency for Healthcare Research and Quality (AHRQ) Comparative Effectiveness Reviews, the Cochrane Library, Choosing Wisely, Centers for Medicare &amp; Medicaid Services (CMS) National Coverage Determinations, the National Institute of Health and Care Excellence (NICE), and the National Guideline Clearinghouse. Other medical literature databases, medical content providers, data sources, regulatory body websites, and specialty society resources may also have been used. Relevant studies were assessed for risk of bias following principles described in the Cochrane Handbook. The resulting evidence was assessed for consistency, directness, precision, effect size, and publication bias. Observational trials were also evaluated for the presence of a dose-response gradient and the likely effect of plausible confounders.</p><br/><br/> Origination date :2009-03-31<br/> Release date :2020-04-17',
            meta: {
              tag: [{
                code: 'subset_id',
                display: 'ISP6701'
              }, {
                code: 'product_id',
                display: 'undefined'
              }, {
                code: 'version_id',
                display: 'RM20'
              }, {
                code: 'subsetType',
                display: 'QNA'
              }, {
                code: 'reviewCreatedDate',
                display: '2021-02-21T12:25:26-06:00'
              }, {
                code: 'lockedDate'
              }, {
                code: 'reviewUserDescription',
                display: 'TestingUser1, TestingUser1'
              }, {
                code: 'review_user_facility',
                display: 'UnitedHealthcare Content Master'
              }, {
                code: 'ProductDescription',
                display: 'CP:Procedures'
              }, {
                code: 'subsetTypeDescription',
                display: 'Arthrodesis, Ankle (Talotibial Joint)'
              }, {
                code: 'review_revision',
                display: 1
              }, {
                code: 'review_version',
                display: 9
              }, {
                code: 'source',
                display: 'MR'
              }]
            },
            contained: [{
              resourceType: 'Parameters',
              id: 'availableRecommendations',
              parameter: [],
              contained: []
            }, {
              resourceType: 'Parameters',
              id: 'selectedRecommendations',
              parameter: [],
              contained: []
            }, {
              resourceType: 'Parameters',
              id: 'comments',
              parameter: [{
                name: '26119',
                valueId: 'TestingUser1, TestingUser1',
                valueDateTime: '2021-01-12T09:49:44-06:00',
                valueString: 'a1'
              }, {
                name: '26119',
                valueId: 'TestingUser1, TestingUser1',
                valueDateTime: '2021-01-12T09:49:44-06:00',
                valueString: 'a2'
              }, {
                name: '3',
                valueId: 'TestingUser1, TestingUser1',
                valueDateTime: '2021-01-12T09:49:44-06:00',
                valueString: 'a1'
              }, {
                name: '3',
                valueId: 'TestingUser1, TestingUser1',
                valueDateTime: '2021-01-12T09:49:44-06:00',
                valueString: 'a2'
              }]
            }],
            item: [{
              linkId: '1514551|1|RADIO',
              text: 'Choose one:',
              answer: [{
                valueString: '1'
              }],
              item: [{
                linkId: '2733464|1',
                text: 'Age&nbsp;≥ 18'
              }, {
                linkId: '2733465|2',
                text: 'Age&nbsp;&lt;&nbsp;18'
              }]
            }, {
              linkId: '1514552|2|RADIO',
              text: 'Choose one:',
              answer: [{
                valueString: '1'
              }],
              item: [{
                linkId: '2733484|1',
                text: 'Osteoarthritis or posttraumatic arthritis'
              }, {
                linkId: '2733485|2',
                text: 'Rheumatoid arthritis'
              }, {
                linkId: '2733486|3',
                text: 'Nonunion or malunion, articular fracture by imaging'
              }, {
                linkId: '2733487|4',
                text: 'Failed total joint replacement (TJR)'
              }, {
                linkId: '2733488|5',
                text: 'None of the above'
              }]
            }, {
              linkId: '1514553|3|MULT',
              text: 'Choose all that apply:',
              answer: [{
                valueString: '1,2'
              }],
              item: [{
                linkId: '2733459|1',
                text: 'Pain increased with initiation of activity'
              }, {
                linkId: '2733460|2',
                text: 'Pain increased with weight bearing'
              }, {
                linkId: '2733461|3',
                text: 'Pain interferes with ADLs'
              }, {
                linkId: '2733462|4',
                text: 'Pain with ROM'
              }, {
                text: 'Or'
              }, {
                linkId: '2733463|5',
                text: 'Other clinical information (add comment)'
              }]
            }, {
              linkId: '1514554|26119|MULT',
              text: 'Choose all that apply:',
              answer: [{
                valueString: '1,2'
              }],
              item: [{
                linkId: '2733435|1',
                text: 'Limited ROM'
              }, {
                linkId: '2733436|2',
                text: 'Crepitus'
              }, {
                text: 'Or'
              }, {
                linkId: '2733437|3',
                text: 'Other clinical information (add comment)'
              }]
            }, {
              linkId: '1514555|26164|YN',
              text: 'Bone-on-bone contact by imaging',
              answer: [{
                valueString: 'Y'
              }],
              item: [{
                linkId: '2733457|Y',
                text: 'Yes'
              }, {
                linkId: '2733458|N',
                text: 'No'
              }]
            }]
          }
        }
      }
    };
    spyOn(qnaMedicalReviewService, 'getMedicalReviewDataFromIQ').and.returnValue(test);
    component.getQnaMedicalReviewForUUID('bf042bee-46e7-4b85-b652-cc3041d5f6c9');
    expect(component.getQnaMedicalReviewForUUID).toBeTruthy();
  });

  it('decodeHTMLEntities method', () => {
    component.decodeHTMLEntities('2774554|1');
    expect(component.decodeHTMLEntities).toBeTruthy();
  });

  it('isLastQuestion method', () => {
    const questionsList = [{
      linkId: '1572903|455',
      text: 'Choose one:',
      type: 'group',
      definition: false,
      prefix: 'RADIO',
      item: [{
        linkId: 2824280,
        text: 'Age ≥ 18',
        definition: false,
        type: 'boolean',
        prefix: '1'
      }, {
        linkId: 2824281,
        text: 'Age&nbsp;&lt;&nbsp;18',
        definition: false,
        type: 'boolean',
        prefix: '2'
      }],
      showRecommdations: false,
      enableMultiBtn: false
    }, {
      linkId: '1572904|68',
      text: 'Choose one: ',
      type: 'group',
      definition: false,
      prefix: 'RADIO',
      item: [{
        linkId: 2824242,
        text: 'Suspected fracture',
        definition: false,
        type: 'boolean',
        prefix: '1'
      }, {
        linkId: 2824243,
        text: 'Avascular necrosis (osteonecrosis)',
        definition: true,
        type: 'boolean',
        prefix: '2'
      }, {
        linkId: 2824244,
        text: 'Osteomyelitis',
        definition: true,
        type: 'boolean',
        prefix: '3'
      }, {
        linkId: 2824245,
        text: 'Suspected bone tumor',
        definition: false,
        type: 'boolean',
        prefix: '4'
      }, {
        linkId: 2824246,
        text: 'Bone metastases evaluation',
        definition: true,
        type: 'boolean',
        prefix: '5'
      }, {
        linkId: 2824247,
        text: 'Suspected loosening of total joint replacement (TJR) prosthesis&nbsp;or cement',
        definition: false,
        type: 'boolean',
        prefix: '6'
      }, {
        linkId: 2824248,
        text: 'Suspected complex regional pain syndrome (CRPS)',
        definition: true,
        type: 'boolean',
        prefix: '7'
      }, {
        linkId: 2824249,
        text: 'Paget disease of bone',
        definition: true,
        type: 'boolean',
        prefix: '8'
      }, {
        linkId: 2824250,
        text: 'None of the above',
        definition: false,
        type: 'boolean',
        prefix: '9'
      }],
      showRecommdations: false,
      enableMultiBtn: false
    }, {
      linkId: '1572905|71',
      text: 'Choose one: ',
      type: 'group',
      definition: false,
      prefix: 'RADIO',
      item: [{
        linkId: 2824251,
        text: 'Long bone fracture',
        definition: true,
        type: 'boolean',
        prefix: '1'
      }, {
        linkId: 2824252,
        text: 'Hip fracture',
        definition: true,
        type: 'boolean',
        prefix: '2'
      }, {
        linkId: 2824253,
        text: 'Stress fracture',
        definition: true,
        type: 'boolean',
        prefix: '3'
      }, {
        linkId: 2824254,
        text: 'Other clinical information (add comment)',
        definition: false,
        type: 'boolean',
        prefix: '4'
      }],
      showRecommdations: false,
      enableMultiBtn: false
    }, {
      linkId: '1572906|882',
      text: 'Choose all that apply: [&ge; Two, except Other clinical information (add comment)]',
      type: 'group',
      definition: false,
      prefix: 'MULT',
      item: [{
        linkId: 2824122,
        text: 'Pain at site',
        definition: false,
        type: 'boolean',
        prefix: '1'
      }, {
        linkId: 2824123,
        text: 'Pain with ROM',
        definition: true,
        type: 'boolean',
        prefix: '2'
      }, {
        text: 'Or ',
        type: 'display'
      }, {
        linkId: 2824124,
        text: 'Other clinical information (add comment)',
        definition: false,
        type: 'boolean',
        prefix: '3'
      }],
      enableMultiBtn: false,
      showRecommdations: false
    }, {
      linkId: '1572907|760',
      text: 'Initial x-ray diagnostic for fracture ',
      type: 'group',
      definition: true,
      prefix: 'YN',
      item: [{
        linkId: 2824120,
        text: 'Yes',
        definition: false,
        type: 'boolean',
        prefix: 'Y'
      }, {
        linkId: 2824121,
        text: 'No',
        definition: false,
        type: 'boolean',
        prefix: 'N'
      }],
      showRecommdations: true,
      enableMultiBtn: false
    }];
    component.isLastQuestion('1572907|760', questionsList);
    expect(component.isLastQuestion).toBeTruthy();
  });

  it('isChecked method', () => {
    const test = {
      linkId: '1514552|2|RADIO',
      text: 'Choose one:',
      answer: [{
        valueString: '1'
      }],
      item: [{
        linkId: '2733484|1',
        text: 'Osteoarthritis or posttraumatic arthritis'
      }, {
        linkId: '2733485|2',
        text: 'Rheumatoid arthritis'
      }, {
        linkId: '2733486|3',
        text: 'Nonunion or malunion, articular fracture by imaging'
      }, {
        linkId: '2733487|4',
        text: 'Failed total joint replacement (TJR)'
      }, {
        linkId: '2733488|5',
        text: 'None of the above'
      }]
    };
    component.isChecked('2', '1514552|2|RADIO', test);
    expect(component.isChecked).toBeTruthy();
  });

  it('getComments method', () => {
    const test = {
            resourceType: 'QuestionnaireResponse',
            id: 354001,
            status: 2,
            questionnaire: 354001,
            text: '<p>I/O Setting: Inpatient</p><br/><p>These criteria include the following procedure:&nbsp;&nbsp;&nbsp;&nbsp;</p> <p>Fusion, Ankle&nbsp;&nbsp;&nbsp;&nbsp;</p><br/><p><b>Def:</b> Arthrodesis is the surgical fusion of a joint. The procedure relieves joint pain and achieves joint stability; joint motion is lost when an arthrodesis is performed.&nbsp;&nbsp;&nbsp;&nbsp;</p><br/><p>Because arthrodesis results in transmission of force to adjacent joints, it is performed when there is little degenerative disease in the adjacent joints and is preferred for patients placing heavy physical demands on the joint.&nbsp;&nbsp;&nbsp;&nbsp;</p><br/><p>A patient\'s body mass index (BMI) must be considered prior to ankle arthrodesis or total joint replacement (TJR) because several large cohort studies showed that being overweight or obese increased the risk for venous thromboembolism and other complications, especially in the presence of comorbid conditions (e.g., diabetes, metabolic syndrome, cardiovascular disease) (<bib rel=citation title=Werner et al., Foot &amp; ankle international 2015: href=/caas/citations/14413 id=14413>Werner et al., Foot &amp; ankle international 2015:</bib>; <bib rel=citation title=Mihalko et al., The Journal of the American Academy of Orthopaedic Surgeons 2014, 22: 683-90 href=/caas/citations/14403 id=14403>Mihalko et al., The Journal of the American Academy of Orthopaedic Surgeons 2014, 22: 683-90</bib>; <bib rel=citation title=Pakzad et al., The Journal of bone and joint surgery. American volume 2014, 96: 32-9 href=/caas/citations/14406 id=14406>Pakzad et al., The Journal of bone and joint surgery. American volume 2014, 96: 32-9</bib>). </p><br/><p>Cigarette smoking is associated with multiple complications (e.g., slowed wound healing, increased risk for infection, delayed bone union, inhibited healing after autologous chondrocyte implantation, the development of avascular necrosis). For this reason, foot and ankle surgeons should encourage patients to abstain from smoking prior to and after orthopedic procedures to promote optimal recovery (<bib rel=citation title=Scolaro et al., The Journal of bone and joint surgery. American volume 2014, 96: 674-81 href=/caas/citations/14371 id=14371>Scolaro et al., The Journal of bone and joint surgery. American volume 2014, 96: 674-81</bib>; <bib rel=citation title=Malay, The Journal of foot and ankle surgery: official publication of the American College of Foot and Ankle Surgeons 2011, 50: 515-6 href=/caas/citations/1464248 id=1464248>Malay, The Journal of foot and ankle surgery: official publication of the American College of Foot and Ankle Surgeons 2011, 50: 515-6</bib>; <bib rel=citation title=Mills et al., The American journal of medicine 2011, 124: 144-54 e8 href=/caas/citations/14362 id=14362>Mills et al., The American journal of medicine 2011, 124: 144-54 e8</bib>; <bib rel=citation title=Myers et al., Archives of internal medicine 2011, 171: 983-9 href=/caas/citations/14373 id=14373>Myers et al., Archives of internal medicine 2011, 171: 983-9</bib>). </p><br/><p>InterQual® Procedures criteria are derived from the systematic, continuous review and critical appraisal of the most current evidence-based literature and include input from our independent panel of clinical experts. To generate the most appropriate recommendations, a comprehensive literature review of the clinical evidence was conducted. Sources searched included PubMed, Agency for Healthcare Research and Quality (AHRQ) Comparative Effectiveness Reviews, the Cochrane Library, Choosing Wisely, Centers for Medicare &amp; Medicaid Services (CMS) National Coverage Determinations, the National Institute of Health and Care Excellence (NICE), and the National Guideline Clearinghouse. Other medical literature databases, medical content providers, data sources, regulatory body websites, and specialty society resources may also have been used. Relevant studies were assessed for risk of bias following principles described in the Cochrane Handbook. The resulting evidence was assessed for consistency, directness, precision, effect size, and publication bias. Observational trials were also evaluated for the presence of a dose-response gradient and the likely effect of plausible confounders.</p><br/><br/> Origination date :2009-03-31<br/> Release date :2020-04-17',
            meta: {
              tag: [{
                code: 'subset_id',
                display: 'ISP6701'
              }, {
                code: 'product_id',
                display: 'undefined'
              }, {
                code: 'version_id',
                display: 'RM20'
              }, {
                code: 'subsetType',
                display: 'QNA'
              }, {
                code: 'reviewCreatedDate',
                display: '2021-02-21T12:25:26-06:00'
              }, {
                code: 'lockedDate'
              }, {
                code: 'reviewUserDescription',
                display: 'TestingUser1, TestingUser1'
              }, {
                code: 'review_user_facility',
                display: 'UnitedHealthcare Content Master'
              }, {
                code: 'ProductDescription',
                display: 'CP:Procedures'
              }, {
                code: 'subsetTypeDescription',
                display: 'Arthrodesis, Ankle (Talotibial Joint)'
              }, {
                code: 'review_revision',
                display: 1
              }, {
                code: 'review_version',
                display: 9
              }, {
                code: 'source',
                display: 'MR'
              }]
            },
            contained: [{
              resourceType: 'Parameters',
              id: 'availableRecommendations',
              parameter: [],
              contained: []
            }, {
              resourceType: 'Parameters',
              id: 'selectedRecommendations',
              parameter: [],
              contained: []
            }, {
              resourceType: 'Parameters',
              id: 'comments',
              parameter: [{
                name: '26119',
                valueId: 'TestingUser1, TestingUser1',
                valueDateTime: '2021-01-12T09:49:44-06:00',
                valueString: 'a1'
              }, {
                name: '26119',
                valueId: 'TestingUser1, TestingUser1',
                valueDateTime: '2021-01-12T09:49:44-06:00',
                valueString: 'a2'
              }, {
                name: '3',
                valueId: 'TestingUser1, TestingUser1',
                valueDateTime: '2021-01-12T09:49:44-06:00',
                valueString: 'a1'
              }, {
                name: '3',
                valueId: 'TestingUser1, TestingUser1',
                valueDateTime: '2021-01-12T09:49:44-06:00',
                valueString: 'a2'
              }]
            }],
            item: [{
              linkId: '1514551|1|RADIO',
              text: 'Choose one:',
              answer: [{
                valueString: '1'
              }],
              item: [{
                linkId: '2733464|1',
                text: 'Age&nbsp;≥ 18'
              }, {
                linkId: '2733465|2',
                text: 'Age&nbsp;&lt;&nbsp;18'
              }]
            }, {
              linkId: '1514552|2|RADIO',
              text: 'Choose one:',
              answer: [{
                valueString: '1'
              }],
              item: [{
                linkId: '2733484|1',
                text: 'Osteoarthritis or posttraumatic arthritis'
              }, {
                linkId: '2733485|2',
                text: 'Rheumatoid arthritis'
              }, {
                linkId: '2733486|3',
                text: 'Nonunion or malunion, articular fracture by imaging'
              }, {
                linkId: '2733487|4',
                text: 'Failed total joint replacement (TJR)'
              }, {
                linkId: '2733488|5',
                text: 'None of the above'
              }]
            }, {
              linkId: '1514553|3|MULT',
              text: 'Choose all that apply:',
              answer: [{
                valueString: '1,2'
              }],
              item: [{
                linkId: '2733459|1',
                text: 'Pain increased with initiation of activity'
              }, {
                linkId: '2733460|2',
                text: 'Pain increased with weight bearing'
              }, {
                linkId: '2733461|3',
                text: 'Pain interferes with ADLs'
              }, {
                linkId: '2733462|4',
                text: 'Pain with ROM'
              }, {
                text: 'Or'
              }, {
                linkId: '2733463|5',
                text: 'Other clinical information (add comment)'
              }]
            }, {
              linkId: '1514554|26119|MULT',
              text: 'Choose all that apply:',
              answer: [{
                valueString: '1,2'
              }],
              item: [{
                linkId: '2733435|1',
                text: 'Limited ROM'
              }, {
                linkId: '2733436|2',
                text: 'Crepitus'
              }, {
                text: 'Or'
              }, {
                linkId: '2733437|3',
                text: 'Other clinical information (add comment)'
              }]
            }, {
              linkId: '1514555|26164|YN',
              text: 'Bone-on-bone contact by imaging',
              answer: [{
                valueString: 'Y'
              }],
              item: [{
                linkId: '2733457|Y',
                text: 'Yes'
              }, {
                linkId: '2733458|N',
                text: 'No'
              }]
            }]
    };
    component.medRevData = test;
    component.getComments('26119');
    expect(component.getComments).toBeTruthy();
  });
  it('should call printReviewSummary', () => {
    const questionReq = {
      comments: [],
      questions: [{
        unique_id: 2035890341,
        question_id: '204',
        answer: '1',
        answer_text: null,
        branch_questions: null,
        recommendation_query_params: null
      }, {
        unique_id: 2035890342,
        question_id: '8',
        answer: '1',
        answer_text: null,
        branch_questions: null,
        recommendation_query_params: null
      }, {
        unique_id: 2035890343,
        question_id: '992',
        answer: '1',
        answer_text: null,
        branch_questions: null,
        recommendation_query_params: null
      }, {
        unique_id: 2035890344,
        question_id: '985',
        answer: 'N',
        answer_text: null,
        branch_questions: null,
        recommendation_query_params: null
      }],
      review_requested_codes: [],
      review_type: 'QNA',
      product_id: 'ISX',
      version_id: 'RM21',
      subset_id: '~IQ6.01A_3661',
      subset_unique_id: 375759,
      subset_description: 'Imaging, Ankle',
      review_date: '2021-07-26T06:24:11.428Z',
      review_user: 'mahesh_pilli2@optum.com',
      review_user_description: 'Pilli, Mahesh',
      review_user_facility: 'UnitedHealthcare Content Master',
      review_user_organization: 'UnitedHealthcare',
      review_status_code: 2,
      selected_benchmark_los: null,
      questions_completed: true,
      qna_review_ready_for_criteria_calc: true,
      recommendation_selections: [],
      non_recommendation_selections: [],
      non_matched_review_requested_codes: null,
      recommendations_tracked: [],
      pdf_options: {
        include_criteria_view_selections: true,
        include_notes: false,
        hide_criteria_status: false
      },
      review_outcomes: [],
      outcome_comments: [],
      is_integrated_environment: false
    };
    spyOn(component, 'prepareReviewRequest').and.returnValue(questionReq);
    component.printReviewSummary();
    expect(component.printReviewSummary).toBeTruthy();
  });

  it('should get prepareCommentsForPDF', () => {
    const commentArray = [{
      nodeCid: 'AISD0153040102',
      text: 'test8',
      user: 'TestingUser1, TestingUser1',
      date: '2021-01-12T09:49:44-06:00'
    }, {
      nodeCid: 'AISD015304010202',
      text: 'post',
      user: 'TestingUser1, TestingUser1',
      date: '2021-01-12T09:49:44-06:00'
    }];
    const item = {
      nodeCid: 'AISD0153040102',
      text: 'test8',
      user: 'TestingUser1, TestingUser1',
      date: '2021-01-12T09:49:44-06:00'
    };
    component.prepareCommentsForPDF(commentArray);
    expect(component.prepareCommentsForPDF).toBeTruthy();

  });

  it('should get prepareAnswer', () => {
    const reviewRes = {
      resourceType: 'QuestionnaireResponse',
      id: 354809,
      status: 2,
      questionnaire: 354809,
      text: '<p>These criteria are appropriate for adults requiring intermittent home care services. The High-risk OB and Postpartum Newborn criteria may also be used for adolescents.&nbsp;Delivery of skilled services in the home requires the following:</p> <ul> <li>Patient clinically stable (no anticipated worsening in severity)</li> <li>Medical practitioner orders or approved plan of care at least every 60 days</li> <li>Reasonable expectation for clinical or functional improvement or prevention of further decline</li> <li>PO fluid tolerated or nutritional route established (e.g., IV, enteral feeding tube)</li> <li>Home care agency can safely deliver the required care at home</li> <li>Home environment is safe, accessible, and can be modified to accommodate the home care plan</li> </ul> <p>In addition to the above, the following conditions should also be met if the patient is receiving high technology services:</p> <ul> <li>Emergency medical services available</li> <li>Lab and pharmacy services available</li> <li>Supplies of fluid, medications, and home medical equipment</li> <li>Nursing specialization in chemotherapy and/or infusion therapy for home infusion therapy</li> </ul><br/><p>InterQual® content contains numerous references to gender. Depending on the context, these references may refer to either genotypic or phenotypic gender. At the individual patient level, a variety of factors, including but not limited to gender identity and gender reassignment via surgery or hormonal manipulation, may affect the applicability of some InterQual criteria. This is most often the case with genetic testing and procedures that assume the presence of gender-specific anatomy. With these considerations in mind, all references to gender in InterQual have been reviewed and modified when appropriate. InterQual users should carefully consider issues related to patient genotype and anatomy, especially for transgender individuals, when appropriate.</p><br/><p>InterQual® criteria are derived from the systematic, continuous review and critical appraisal of the most current evidence-based literature and include input from our independent panel of clinical experts. The content is based on a variety of references which are cited at specific criteria points throughout the subset.</p><br/><br/> Origination date :2015-03-31<br/> Release date :2019-10-04',
      meta: {
        tag: [{
          code: 'subset_id',
          display: '~IQ6.01A_17056'
        }, {
          code: 'product_id',
          display: 'IQ-HC'
        }, {
          code: 'version_id',
          display: 'RM20'
        }, {
          code: 'subsetType',
          display: 'QNA'
        }, {
          code: 'reviewCreatedDate',
          display: '2021-01-26T16:11:17-06:00'
        }, {
          code: 'lockedDate'
        }, {
          code: 'reviewUserDescription',
          display: 'TestingUser1, TestingUser1'
        }, {
          code: 'review_user_facility',
          display: 'UnitedHealthcare Content Master'
        }, {
          code: 'ProductDescription',
          display: 'LOC:Home Care Q & A'
        }, {
          code: 'subsetTypeDescription',
          display: 'Home Care Services, Adult'
        }, {
          code: 'review_revision',
          display: 1
        }, {
          code: 'review_version',
          display: 1
        }, {
          code: 'source',
          display: 'MR'
        }]
      },
      contained: [{
        resourceType: 'Parameters',
        id: 'availableRecommendations',
        parameter: [{
          name: 'groupId',
          valueString: 'ZF851|ZF852'
        }, {
          name: 'mutually_required',
          valueBoolean: null
        }],
        contained: [{
          resourceType: 'Parameters',
          parameter: [{
            name: 'recommendationId',
            valueString: '1056360'
          }, {
            name: 'description',
            valueString: 'Home Physical Therapy'
          }, {
            name: 'recommendation_indicators',
            valueString: '1 visit'
          }, {
            name: 'criteria_met',
            valueString: 'Criteria Not Met'
          }, {
            name: 'disposition_description',
            valueString: 'Evidence supports services as medically necessary.'
          }]
        }]
      }, {
        resourceType: 'Parameters',
        id: 'selectedRecommendations',
        parameter: [{
          name: 'groupId',
          valueString: 'ZF851|ZF852'
        }, {
          name: 'mutually_required',
          valueBoolean: null
        }],
        contained: [{
          resourceType: 'Parameters',
          parameter: [{
            name: 'recommendationId',
            valueString: '1056358'
          }, {
            name: 'description',
            valueString: 'Home Skilled Nursing'
          }, {
            name: 'recommendation_indicators',
            valueString: '168 visits within 12 weeks'
          }, {
            name: 'criteria_met',
            valueString: 'Criteria Not Met'
          }, {
            name: 'disposition_description',
            valueString: 'Evidence supports services as medically necessary.'
          }]
        }]
      }, {
        resourceType: 'Parameters',
        id: 'comments',
        parameter: []
      }],
      item: [
        {
          linkId: '1539500|400|RADIO',
          text: 'Patient and/or caregiver agree and are willing to participate in a home care program:',
          answer: [{
            valueString: '1'
          }],
          item: [{
            linkId: '2774554|1',
            text: 'Yes'
          }, {
            linkId: '2774555|2',
            text: 'No'
          }, {
            linkId: '2774556|3',
            text: 'Unknown'
          }]
        },
        {
          linkId: '1539502|1776|YN',
          text: 'Patient homebound',
          answer: [{
            valueString: 'Y'
          }],
          item: [{
            linkId: '2774552|Y',
            text: 'Yes'
          }, {
            linkId: '2774553|N',
            text: 'No'
          }]
        }, {
          linkId: '1539501|599|MULT',
          text: 'Normal inability to leave the home, Choose all that apply:',
          answer: [{
            valueString: '1,2'
          }],
          item: [{
            linkId: '2773694|1',
            text: 'Requires the use of an assistive device (e.g., crutches, cane, walker, or wheelchair)'
          }, {
            linkId: '2773695|2',
            text: 'Requires special transportation (e.g., ambulance or chair car)'
          }, {
            linkId: '2773696|3',
            text: 'Requires the assistance of another person'
          }, {
            linkId: '2773697|4',
            text: 'Medical contraindication to leaving the home'
          }, {
            text: 'Or'
          }, {
            linkId: '2773698|5',
            text: 'Other clinical information (add comment)'
          }]
        }, {
          linkId: '1539505|611|MULT',
          text: 'Requiring a considerable and taxing effort to leave the home, Choose all that apply:',
          answer: [{
            valueString: '1,2'
          }],
          item: [{
            linkId: '2773992|1',
            text: 'Requiring significant assistance'
          }, {
            linkId: '2773993|2',
            text: 'Requiring high energy demand'
          }, {
            text: 'Or'
          }, {
            linkId: '2773994|3',
            text: 'Other clinical information (add comment)'
          }]
        }, {
          linkId: '1539507|1786|MULT',
          text: 'Choose all that apply:',
          answer: [{
            valueString: '1,2'
          }],
          item: [{
            linkId: '2773870|1',
            text: 'Illness, injury, exacerbation, or surgery ≤ 30 days'
          }, {
            linkId: '2773871|2',
            text: 'Discharged from inpatient facility'
          }, {
            linkId: '2773872|3',
            text: 'End-stage disease, hospice, or palliative care'
          }, {
            linkId: '2773873|4',
            text: 'High risk for complications or functional decline'
          }, {
            linkId: '2773874|5',
            text: 'Continued need for skilled assessment or intervention'
          }, {
            text: 'Or'
          }, {
            linkId: '2773875|6',
            text: 'Other clinical information (add comment)'
          }]
        }, {
          linkId: '1539508|1587|MULT',
          text: 'Patient or caregiver unable to manage care, Choose all that apply:',
          answer: [{
            valueString: '1,2'
          }],
          item: [{
            linkId: '2773977|1',
            text: 'Cognitive deficit'
          }, {
            linkId: '2773978|2',
            text: 'Knowledge deficit'
          }, {
            linkId: '2773979|3',
            text: 'Physical deficit'
          }, {
            linkId: '2773980|4',
            text: 'Early discharge mother and/or baby'
          }, {
            text: 'Or'
          }, {
            linkId: '2773981|5',
            text: 'Other clinical information (add comment)'
          }]
        }, {
          linkId: '1539509|1994|MULT',
          text: 'Disciplines, Choose all that apply:',
          answer: [{
            valueString: '1,2'
          }],
          item: [{
            linkId: '2774159|1',
            text: 'Skilled nursing'
          }, {
            linkId: '2774160|2',
            text: 'Physical therapy'
          }, {
            linkId: '2774161|3',
            text: 'Occupational therapy'
          }, {
            linkId: '2774162|4',
            text: 'Speech-language therapy'
          }, {
            linkId: '2774163|5',
            text: 'Home health aide'
          }, {
            linkId: '2774164|6',
            text: 'Medical social services'
          }, {
            linkId: '2774165|7',
            text: 'Nutrition consult'
          }, {
            text: 'Or'
          }, {
            linkId: '2774166|8',
            text: 'Other clinical information (add comment)'
          }]
        }, {
          linkId: '1539510|776|RADIO',
          text: 'Skilled nursing, Choose one:',
          answer: [{
            valueString: '1'
          }],
          item: [{
            linkId: '2774000|1',
            text: 'Clinical assessment'
          }, {
            linkId: '2774001|2',
            text: 'High-risk obstetrics'
          }, {
            linkId: '2774002|3',
            text: 'High technology'
          }, {
            linkId: '2774003|4',
            text: 'Wound'
          }, {
            linkId: '2774004|5',
            text: 'Postpartum or newborn'
          }, {
            linkId: '2774005|6',
            text: 'Other clinical information (add comment)'
          }]
        }, {
          linkId: '1539511|69|RADIO',
          text: 'Clinical assessment, Choose one:',
          answer: [{
            valueString: '4'
          }],
          item: [{
            linkId: '2774480|1',
            text: 'Evaluation&nbsp;visit only'
          }, {
            linkId: '2774481|2',
            text: 'Initial home care visits (first 2 weeks)'
          }, {
            linkId: '2774482|3',
            text: 'Ongoing&nbsp;home care visits (&lt; 60 days from start of care)'
          }, {
            linkId: '2774483|4',
            text: 'Long term care (≥ 60 days from start of care)'
          }, {
            linkId: '2774484|5',
            text: 'Other clinical information (add comment)'
          }]
        }, {
          linkId: '1539649|1314|MULT',
          text: 'Patient or patient and caregiver unable to manage care, Choose all that apply:',
          answer: [{
            valueString: '1,2'
          }],
          item: [{
            linkId: '2773926|1',
            text: 'Memory deficit(s) prevents managing care tasks'
          }, {
            linkId: '2773927|2',
            text: 'Unable to learn despite efforts to teach injection, procedure, or care management'
          }, {
            linkId: '2773928|3',
            text: 'Lacks dexterity to manage care'
          }, {
            linkId: '2773929|4',
            text: 'Symptoms or conditions interfere with care management'
          }, {
            text: 'Or'
          }, {
            linkId: '2773930|5',
            text: 'Other clinical information (add comment)'
          }]
        }, {
          linkId: '1539650|2704|MULT',
          text: 'Continuation of care, Choose all that apply:',
          answer: [{
            valueString: '1,2'
          }],
          item: [{
            linkId: '2774351|1',
            text: 'Vascular access device management'
          }, {
            linkId: '2774352|2',
            text: 'Dressing changes (excluding DSD) for delayed wound healing'
          }, {
            linkId: '2774353|3',
            text: 'End­stage disease requiring hospice or palliative care'
          }, {
            linkId: '2774354|4',
            text: 'High-risk OB on bedrest'
          }, {
            linkId: '2774355|5',
            text: 'Indwelling urinary catheter'
          }, {
            linkId: '2774356|6',
            text: 'Unable to perform injections and measures to achieve independence or identify alternative caregiver exhausted'
          }, {
            linkId: '2774357|7',
            text: 'Infusion pump (implanted or external) management'
          }, {
            linkId: '2774358|8',
            text: 'Intravenous medication administration'
          }, {
            linkId: '2774359|9',
            text: 'Nonadherence with medication regimen requiring medication pre­fill'
          }, {
            text: 'Or'
          }, {
            linkId: '2774360|10',
            text: 'Other clinical information (add comment)'
          }]
        }, {
          linkId: '1539651|2714|MULT',
          text: 'Treatments or monitoring, Choose all that apply:',
          answer: [{
            valueString: '1,2'
          }],
          item: [{
            linkId: '2774391|1',
            text: 'Insulin injections daily'
          }, {
            linkId: '2774392|2',
            text: 'Insulin injections twice daily'
          }, {
            linkId: '2774393|3',
            text: 'NPWT ≤ 4 months'
          }, {
            linkId: '2774394|4',
            text: 'Dressing changes for wound with heavy exudate'
          }, {
            linkId: '2774395|5',
            text: 'Dressing changes for wound with moderate exudate'
          }, {
            linkId: '2774396|6',
            text: 'Dressing changes for wound with no, scant or small exudate'
          }, {
            linkId: '2774397|7',
            text: 'Medication prefill'
          }, {
            linkId: '2774398|8',
            text: 'Psychotropic medication injection every 2 weeks'
          }, {
            linkId: '2774399|9',
            text: 'Psychotropic medication injection every 4 weeks'
          }, {
            text: 'Or'
          }, {
            linkId: '2774400|10',
            text: 'More choices'
          }]
        }, {
          linkId: '1539579|903|RADIO',
          text: 'Physical therapy, Choose one:',
          answer: [{
            valueString: '1'
          }],
          item: [{
            linkId: '2774167|1',
            text: 'Evaluation&nbsp;visit only'
          }, {
            linkId: '2774168|2',
            text: 'Initial home care visits (first 2 weeks)'
          }, {
            linkId: '2774169|3',
            text: 'Ongoing&nbsp;home care visits (&lt; 60 days from start of care)'
          }, {
            linkId: '2774170|4',
            text: 'Maintenance therapy'
          }, {
            linkId: '2774171|5',
            text: 'Other clinical information (add comment)'
          }]
        }]
    };
    component.prepareAnswer(reviewRes);
    expect(component.prepareAnswer).toBeTruthy();

  });

});
