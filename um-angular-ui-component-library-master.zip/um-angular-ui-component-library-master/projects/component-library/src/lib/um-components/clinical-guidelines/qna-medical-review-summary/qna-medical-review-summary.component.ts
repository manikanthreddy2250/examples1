import {Component, ComponentFactoryResolver, Input, OnInit} from '@angular/core';
import {FormBuilder, FormControl, FormGroup} from '@angular/forms';
import {MicroProductAuthService} from '@ecp/auth-library';
import {QnaMedicalReviewService} from '../../services/um/service/clinical-guidelines/qna-medical-review-service/qna-medical-review.service';
import {UITKPageNotificationService} from '@uitk/angular';
import {ActivatedRoute, Router} from '@angular/router';
import {HttpClient} from '@angular/common/http';
import {CommonConstants} from '../shared/common-constants';
import {Item} from '../shared/models/Item';
import {Contained} from '../shared/models/Contained';
import {Meta} from '../shared/models/Meta';
import {Tag} from '../shared/models/Tag';
import {QuestionChoices} from '../shared/models/QuestionChoices';
import {QnaReview} from '../shared/models/QnaReview';
import {GUIDELINES_FUNCTION_API_URL} from '../../../config/config-constants';
import {getEnvVar} from '../../services/environment/envVarUtil';

@Component({
  selector: 'guidelines-qna-medical-review-summary',
  templateUrl: './qna-medical-review-summary.component.html',
  styleUrls: ['./qna-medical-review-summary.component.scss']
})
export class QnaMedicalReviewSummaryComponent implements OnInit {

  @Input() reviewID: string;
  commentsArray = [];
  QuestionnaireList = [];
  createdBy: string;
  createdDate: any;
  status: string;
  completedDate: any;
  criteriaProduct: string;
  version: string;
  criteriaSubset: string;
  facility: string;
  criteriaStatus: string;
  medRevData: any;
  qnaReview = {
    resourceType: 'Questionnaire',
    identifier: {
      use: 'official',
      value: ''
    },
    meta: {
      lastUpdated: null,
      tag: []
    },
    questionnaire: '',
    text: '',
    status: '',
    item: [],
    contained: [{
      resourceType: 'Parameters',
      id: 'availableRecommendations',
      parameter: [{
        name: 'groupId',
        valueString: ' '
      }, {
        name: 'recommendationId',
        valueString: null
      },
        {
          name: 'disposition_notes',
          valueString: null
        }],
      contained: []
    },
      {
        resourceType: 'Parameters',
        id: 'comments',
        parameter: [],
        contained: []
      }
    ],
    questionsList: ''
  } as QnaReview;

  Questionnaire: any = null;
  questionId: string;
  meta: Meta;
  checkedIds = [];
  answer = [];
  reviewRevision = 0;
  reviewVersion = 0;
  subsetId = null;
  uniqueId = null;
  latestSubsetId = null;
  commentsList: Map<string, Comment[]> = new Map();
  subsetIdentifierId = null;
  criteriaMet = null;
  guideLineID: any;
  comments = [];
  commentModal: any = {
    show: false
  };
  reviewId: any;
  errorConfig = {
    id: 'error_msg',
    pageNotificationType: 'error',
    content: 'Unexpected error occurred. Please try again later.',
    triggerElementId: 'trigger-button',
  };
  overviewText: any;
  isLoading: boolean;
  counter: number;
  citationData = [];
  returnTitle: number;
  k = 1;
  j = 1;
  citationModalData: any = {
    show: false
  };
  notesModal: any = {
    show: false
  };

  reviewRes: any;

  constructor(private readonly fb: FormBuilder, private readonly activatedRoute: ActivatedRoute, private readonly qnaMedicalReviewService: QnaMedicalReviewService,
              private readonly http: HttpClient, private readonly microProductAuthService: MicroProductAuthService, private readonly router: Router,
              private readonly componentFactoryResolver: ComponentFactoryResolver, private readonly messageService: UITKPageNotificationService) {

  }

  ngOnInit(): void {
    this.getQnaMedicalReviewForUUID(this.reviewID);
  }

  async getQnaMedicalReviewForUUID(reviewID) {
    const response = await this.qnaMedicalReviewService.getMedicalReviewDataFromIQ(reviewID);
    console.log('qna review summary response: ' + JSON.stringify(response));
    this.reviewRes = response.data.getMedicalReviewDetails.reviewRes;
    this.medRevData = response?.data?.getMedicalReviewDetails?.reviewRes;
    this.questionId = this.medRevData.id;
    this.medRevData.item.forEach(item => {
      this.populatePrefix(item);
      this.QuestionnaireList.push(item);
    });
    this.setQnaHeaderForUUID(this.medRevData);
  }

  populatePrefix(item: Item) {
    item.prefix = item.linkId.split('|')[2];
    item.item.forEach((questionItem, index) => {
      questionItem.prefix = (index + 1).toString();
    });
  }

  populateComments(nodeId: string, contained: Contained, item: any) {
    const comments = contained.parameter.filter(par => par.name === nodeId);
    comments.forEach(comment => {
      const fhircommentObj = {
        name: item.linkId,
        valueId: comment.valueId,
        valueDateTime: comment.valueDateTime,
        valueString: comment.valueString
      };
      this.commentsArray.push(fhircommentObj);
    });
  }

  setQnaHeaderForUUID(qnaReview) {
    for (let k = 0; k < qnaReview.meta.tag.length; k++) {
      if (qnaReview.meta.tag[k].code === 'reviewUserDescription') {
        this.createdBy = this.getUserName();
      } else if (qnaReview.meta.tag[k].code === 'review_user_facility') {
        this.facility = qnaReview.meta.tag[k].display;
      } else if (qnaReview.meta.tag[k].code === 'lockedDate') {
        this.completedDate = qnaReview.meta.tag[k].display;
      } else if (qnaReview.meta.tag[k].code === 'reviewCreatedDate') {
        this.createdDate = qnaReview.meta.tag[k].display;
      } else if (qnaReview.meta.tag[k].code === 'ProductDescription') {
        this.criteriaProduct = qnaReview.meta.tag[k].display;
      } else if (qnaReview.meta.tag[k].code === 'subsetTypeDescription') {
        this.criteriaSubset = qnaReview.meta.tag[k].display;
      }
    }
    this.settingStatus(qnaReview);
    this.setCriteriaMetVal(qnaReview);
    this.version = 'InterQual® 2020, Apr. 2020 Release';
  }

  settingStatus(qnaReview) {
    if (qnaReview.status === 2) {
      this.status = 'Draft';
    } else if (qnaReview.status === 6) {
      this.status = 'Completed';
    }
  }

  setCriteriaMetVal(qnaReview) {
    let contained = [];
    let recomendationContained = [];
    contained = qnaReview.contained;
    for (let k = 0; k < contained.length; k++) {
      if (contained[k].id === 'recommendations') {
        recomendationContained = contained[k].contained;
        this.getParam(recomendationContained);
      }
    }
  }

  getParam(recomendationContained) {
    let recomendationParam = [];
    if (recomendationContained && recomendationContained.length > 0) {
      recomendationParam = recomendationContained[0].parameter;
      if (recomendationParam && recomendationParam.length > 0) {
        for (let j = 0; j < recomendationParam.length; j++) {
          if (recomendationParam[j].name === 'criteria_met') {
            this.criteriaStatus = recomendationParam[j].valueString;
          }
        }
      }
    }
  }

  getUserName() {
    if (this.microProductAuthService.isLocalHost()) { // to avoid adding a token in storage while working in local
      return 'SYSTEM';
    } else {
      const  EcpClaims = this.microProductAuthService.getEcpClaims();
      const FIRST_NAME = EcpClaims['x-ecp-claims']['x-ecp-first-name'];
      const LAST_NAME = EcpClaims['x-ecp-claims']['x-ecp-last-name'];
      return FIRST_NAME + ', ' + LAST_NAME;
    }
  }

  isChecked(questionAns: string, linkId: string, question): boolean {
    let checked = false;
    for (let i = 0; i < question?.answer?.length; i++) {
      if (question?.answer[i]?.valueString === 'Y' && questionAns === '1') {
        checked = true;
      } else if (question?.answer[i]?.valueString === 'N' && questionAns === '2') {
        checked = true;
      }
      else if (question?.answer[i]?.valueString?.includes(questionAns)) {
        checked = true;
      }
    }
    return checked;
  }


  decodeHTMLEntities(str) {
    const e = document.createElement('textarea');
    e.innerHTML = str;
    return e.childNodes.length === 0 ? '' : e.childNodes[0].nodeValue;
  }

  isLastQuestion(question: string, questionList: any): boolean {
    let lastQuestion = false;
    if (questionList !== undefined && question !== null) {
      if (question === questionList[questionList.length - 1]) {
        lastQuestion = true;
      }
    }
    return lastQuestion;
  }

  getComments(nodeCid): any{
    const commentsList = [];
    this.medRevData?.[CommonConstants.CONTAINED][CommonConstants.TWO][CommonConstants.PARAMETER].forEach(item => {
      if (item?.name === nodeCid){
        commentsList.push(item);
      }
    });
    return commentsList;
  }
  printReviewSummary() {
    const request = this.prepareReviewRequest();
    const httpOptions: any = {
      headers: {
        Accept: 'application/pdf',
      },
      responseType: 'arraybuffer'
    };
    this.http
      .post(
        `${getEnvVar(GUIDELINES_FUNCTION_API_URL)}/qna/summary`,
        request,
        httpOptions
      )
      .subscribe((res: any) => {
        const blob = new Blob([res], {type: 'application/pdf'});
        if (blob && blob.size > 0) {
          const blobURL = URL.createObjectURL(blob);
          window.open(blobURL);
        }
      });
  }

  prepareReviewRequest() {
    const request: any = {};
    request.comments = this.prepareCommentsForPDF(this.reviewRes.contained[2].parameter),
      request.questions = this.populateQuestions(),
      request.review_requested_codes = [],
      request.review_type = this.reviewRes.meta.tag.filter(n => n.code === 'subsetType')[0].display,
      request.product_id = this.reviewRes.meta.tag.filter(l => l.code === 'product_id')[0].display,
      request.version_id = this.reviewRes.meta.tag.filter(m => m.code === 'version_id')[0].display,
      request.subset_id = this.reviewRes.meta.tag.filter(n => n.code === 'subsetTypeDescription')[0].display,
      request.subset_unique_id = this.reviewRes.questionnaire,
      request.subset_description = this.reviewRes.meta.tag.filter(n => n.code === 'subsetTypeDescription')[0].display,
      request.review_date = this.reviewRes.meta.tag.filter(k => k.code === 'reviewCreatedDate')[0].display,
      request.review_user = this.createdBy,
      request.review_user_description = this.reviewRes.meta.tag.filter(o => o.code === 'reviewUserDescription')[0].display,
      request.review_user_facility = this.reviewRes.meta.tag.filter(q => q.code === 'review_user_facility')[0].display,
      request.review_user_organization = 'UnitedHealthcare',
      request.review_status_code = this.reviewRes.status,
      request.selected_benchmark_los = null,
      request.questions_completed = true,
      request.qna_review_ready_for_criteria_calc = true,
      request.recommendation_selections = [],
      request.non_recommendation_selections = [],
      request.non_matched_review_requested_codes = null,
      request.recommendations_tracked = [],
      request.pdf_options = {
        include_criteria_view_selections: true,
        include_notes: true,
        hide_criteria_status: false
      },
      request.review_outcomes = [],
      request.outcome_comment = [],
      request.is_integrated_environment = false;
    return request;
  }

  populateQuestions() {
    const questions = [];
    for (let i = 0; i < this.reviewRes.item.length; i++) {
      questions.push(
        {
          unique_id: this.reviewRes.item[i]?.linkId.split('|', 3)[0],
          question_id: this.reviewRes.item[i]?.linkId?.split('|', 3)[1],
          answer: this.prepareAnswer(this.reviewRes.item[i].answer),
          answer_text: null,
          branch_questions: null,
          recommendation_query_params: null
        }
      );
    }
    return questions;
  }

  prepareAnswer(answer){
    for (let i = 0; i < answer.length; i++) {
      return answer[i].valueString;
    }
  }


  prepareCommentsForPDF(comment) {
    const comments = [];
    for (let i = 0; i < comment?.length; i++) {
      comments.push({
        nodeCid: comment[i]?.name,
        user: comment[i]?.valueId,
        date: comment[i]?.valueDateTime,
        text: comment[i]?.valueString
      });
    }
    return comments;
  }
}
