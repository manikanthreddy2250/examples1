import {QnaMedicalReviewSummaryComponent} from './qna-medical-review-summary.component';
import {CommonModule} from '@angular/common';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {CardModule} from '@ecp/angular-ui-component-library/card';
import {MatGridListModule} from '@angular/material/grid-list';
import {MatIconModule} from '@angular/material/icon';
import {ButtonModule} from '@ecp/angular-ui-component-library/button';
import {HttpClient, HttpClientModule} from '@angular/common/http';
import {AuthLibraryModule} from '@ecp/auth-library';
import {IconsModule} from '@ecp/angular-ui-component-library/icons';
import {TabsModule} from '@ecp/angular-ui-component-library/tabs';
import {UserAuthService} from '../../services/um/service/auth/user.service';
import {NgModule, NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {ModalModule} from '@ecp/angular-ui-component-library/modal';
import {MatSidenavModule} from '@angular/material/sidenav';
import {SelectModule} from '@ecp/angular-ui-component-library/select';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {OptionModule} from '@ecp/angular-ui-component-library/option';
import {LinkModule} from '@ecp/angular-ui-component-library/link';
import {MedicalReviewErrorsModule} from '../medical-review-errors/medical-review-errors.module';
import {FormFieldModule} from '@ecp/angular-ui-component-library/form-field';
import {MedicalReviewCitationsModule} from '../medical-review-citations/medical-review-citations.module';
import {GuidelineSummaryModule} from '../guideline-summary/guideline-summary.module';
import {CheckboxModule} from '@ecp/angular-ui-component-library/checkbox';
import {MedicalReviewNotesModule} from '../medical-review-notes/medical-review-notes.module';
import {MenuPopupModule} from '@ecp/angular-ui-component-library/menu-popup';
import {AccordianModule} from '@ecp/angular-ui-component-library/accordian';
import {MedicalReviewCommentsModule} from '../medical-review-comments/medical-review-comments.module';
import {ScrollbarModule} from '@ecp/angular-ui-component-library/scrollbar';
import {InputModule} from '@ecp/angular-ui-component-library/input';
import { DocumentUtilityModule } from '../document-utility/document-utility.module';

@NgModule({
  declarations: [
    QnaMedicalReviewSummaryComponent
  ],
  imports: [
    CommonModule,
    BrowserModule,
    ModalModule,
    SelectModule,
    InputModule,
    OptionModule,
    BrowserAnimationsModule,
    MatGridListModule,
    MatIconModule,
    FormsModule,
    ReactiveFormsModule,
    ButtonModule,
    CardModule,
    TabsModule,
    IconsModule,
    AuthLibraryModule,
    HttpClientModule,
    CheckboxModule,
    FormFieldModule,
    LinkModule,
    MenuPopupModule,
    MedicalReviewCommentsModule,
    MedicalReviewNotesModule,
    MedicalReviewErrorsModule,
    MedicalReviewCitationsModule,
    GuidelineSummaryModule,
    MatSidenavModule,
    AccordianModule,
    DocumentUtilityModule,
    ScrollbarModule
  ],

  exports: [
    QnaMedicalReviewSummaryComponent
  ],
  providers: [UserAuthService, HttpClient],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class QnaMedicalReviewSummaryModule { }
