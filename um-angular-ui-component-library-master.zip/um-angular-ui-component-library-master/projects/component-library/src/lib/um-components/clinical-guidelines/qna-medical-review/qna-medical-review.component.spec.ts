
import {ModalModule} from '@ecp/angular-ui-component-library/modal';
import {CUSTOM_ELEMENTS_SCHEMA, Injectable, NO_ERRORS_SCHEMA} from '@angular/core';
import {HttpClientModule} from '@angular/common/http';
import {MatGridListModule} from '@angular/material/grid-list';
import {TabsModule} from '@ecp/angular-ui-component-library/tabs';
import {AuthLibraryModule, MicroProductAuthService} from '@ecp/auth-library';
import {SelectModule} from '@ecp/angular-ui-component-library/select';
import {FormControl, FormsModule, ReactiveFormsModule} from '@angular/forms';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {BedDayDecisionService} from '../../services/um/service/clinical-guidelines/guideline-bed-day-decision-service/bed-day-decision.service';
import {MedicalReviewGraphqlServiceService} from '../../services/um/service/clinical-guidelines/medical-review-graphql-service/medical-review-graphql-service.service';
import {IconsModule} from '@ecp/angular-ui-component-library/icons';
import {MedicalReviewTreeService} from '../../services/um/service/clinical-guidelines/medical-review-tree/medical-review-tree.service';
import {BrowserModule} from '@angular/platform-browser';
import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {OptionModule} from '@ecp/angular-ui-component-library/option';
import {CommonModule} from '@angular/common';
import {MatIconModule} from '@angular/material/icon';
import {CardModule} from '@ecp/angular-ui-component-library/card';
import {ButtonModule} from '@ecp/angular-ui-component-library/button';
import {FormFieldModule} from '@ecp/angular-ui-component-library/form-field';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import {CheckboxModule} from '@ecp/angular-ui-component-library/checkbox';
import {AccordianModule} from '@ecp/angular-ui-component-library/accordian';
import {MedicalReviewTreeComponent} from '../medical-review-tree/medical-review-tree.component';
import {QnaMedicalReviewComponent} from './qna-medical-review.component';
import {QnaMedicalReviewService} from '../../services/um/service/clinical-guidelines/qna-medical-review-service/qna-medical-review.service';
import {of} from 'rxjs';
import {QuestionChoices} from '../shared/models/QuestionChoices';
import {Item} from '../shared/models/Item';
import {QuestionnaireResponse} from '../shared/models/QuestionnaireResponse';
import { Meta } from '../../models/Meta';

@Injectable()
class MicroProductAuthServiceStub {
  getEcpClaims() {
    return {
      'x-ecp-claims': {
        'x-ecp-attrs': {},
        'x-ecp-alt-user-id': '',
        'x-ecp-cli-orgs': [{
          'org-id': 'ecp',
          'func-roles': [{
            'role-name': 'rules_admin',
            'appl-roles': ['clinical_guidelines_cds_nurse']
          }]
        }],
        'x-ecp-first-name': 'Sahithya',
        'x-ecp-type': 'PASSWORD',
        'x-ecp-user-id': '001173408',
        'x-ecp-email': 'sahithya_sivaraju@optum.com',
        'x-ecp-last-name': 'Pachipulusu Sivaraju',
        'x-ecp-source': 'msid'
      },
      'https://hasura.io/jwt/claims': {
        'x-hasura-default-role': 'autoapproval-dmn_deploy',
        'x-hasura-attrs': '{ }',
        'x-hasura-cli-org': 'ecp',
        'x-hasura-user-id': '001173408',
        'x-hasura-func-role': 'rules_admin',
        'x-hasura-allowed-roles': ['autoapproval-dmn_deploy', 'autorouting-dmn_deploy', 'bpm_execute_all', 'case_wf_mgmt_ui_read', 'configuration-dmn_deploy', 'example_dmn_grp_deploy', 'health_srvc_delete', 'icuerules-dmn_deploy', 'memberblocking-dmn_deploy', 'obsderivation-dmn_deploy', 'programs-dmn_deploy', 'rules_authoring_write', 'siteofservice-dmn_deploy', 'system_mgmt_user', 'testharness-dmn_deploy', 'um_intake_ui_read', 'umintake_sos_mbr_elig_dmn_grp_deploy', 'umintake_sos_prov_elig_dmn_grp_deploy']
      },
      scope: 'openid',
      iss: 'ecp-dev',
      exp: 1603473684,
      client_id: 'ecp_platform'
    };
  }

  getUserRoles() {
    return 'clinical_guidelines_cds_nurse';
  }

  getEcpOrgId() {
    return 'TESTUSERID';
  }

  getEcpToken() {
    return 'testToken';
  }

  isLocalHost() {
    return false;
  }

  getHasuraRole() {
    return 'clinical_guidelines_md';
  }
}

let questionChoices = {
  'resourceType': 'test',
  'id': '123',
  "title": "CP:Procedures InterQual® 2020, Apr. 2020 Release",
  'meta': {
    'tag': [
      {
        "code": "subset_id",
        "display": "ISP6701"
      },
      {
        "code": "product_id",
        "display": "PROCEDURES"
      },
      {
        'code': 'autoSave',
        'display': 'false'
      },
      {
        "code": "version_id",
        "display": "RM20"
      },
      {
        "code": "subsetType",
        "display": "QNA"
      },
      {
        "code": "reviewCreatedDate",
        "display": "2021-02-17T15:28:26-06:00"
      },
      {
        "code": "lockedDate"
      },
      {
        "code": "reviewUserDescription",
        "display": "TestingUser1, TestingUser1"
      },
      {
        "code": "review_user_facility",
        "display": "United Health Group"
      },
      {
        "code": "ProductDescription",
        "display": "CP:Procedures"
      },
      {
        "code": "subsetTypeDescription",
        "display": "Arthrodesis, Ankle (Talotibial Joint)"
      },
      {
        "code": "review_revision",
        "display": 1
      },
      {
        "code": "review_version",
        "display": 13
      },
      {
        "code": "source",
        "display": "MR"
      }
    ]
  },
  'item': [
    {
      'linkId': '302126|2',
      'text': 'Choose one: ',
      'type': 'group',
      'definition': 'true',
      'prefix': 'RADIO',
      'item': [
        {
          'linkId': '658945',
          'text': 'Osteoarthritis or posttraumatic arthritis',
          'definition': 'true',
          'type': 'boolean',
          'prefix': '1'
        },
        {
          'linkId': '658946',
          'text': 'COrona',
          'definition': 'true',
          'type': 'boolean',
          'prefix': '2'
        }
      ]
    }
  ],
  "contained": [
    {
      "resourceType": "Parameters",
      "id": "availableRecommendations",
      "parameter": [
        {
          "name": "groupId",
          "valueString": "ZF851|ZF852"
        },
        {
          "name": "mutually_required",
          "valueBoolean": null
        },
        {
          "name": "disposition_notes",
          "valueString": "<p>There is no convincing evidence for the use of acupuncture for pain relief in patients with fibromyalgia. Study design flaws presently prohibit assessing acupuncture’s utility for improving health outcomes. Acupuncture is not considered reasonable and necessary for the treatment of fibromyalgia.</p>"
        }
      ],
      "contained": [
        {
          "resourceType": "Parameters",
          "parameter": [
            {
              "name": "recommendationId",
              "valueString": "1056360"
            },
            {
              "name": "description",
              "valueString": "Home Physical Therapy"
            },
            {
              "name": "recommendation_indicators",
              "valueString": "1 visit"
            },
            {
              "name": "criteria_met",
              "valueString": "Criteria Not Met"
            },
            {
              "name": "disposition_description",
              "valueString": "Evidence supports services as medically necessary."
            }
          ]
        }
      ]
    }]
} as any;

let recommendations = {
  'resourceType': 'Parameters',
  'id': 'recommendations',
  'name': '',
  'text': '',
  "title": '',
  'meta': {
    'lastUpdated': null,
    'tag': []
  },
  "parameter": [{
    "name": "groupId",
    "valueString": "ZZ131"
    }, {
    "name": "mutually_required",
    "valueBoolean": null
    },
    {
      "name": "disposition_notes",
      "valueString": "<p>There is no convincing evidence for the use of acupuncture for pain relief in patients with fibromyalgia. Study design flaws presently prohibit assessing acupuncture’s utility for improving health outcomes. Acupuncture is not considered reasonable and necessary for the treatment of fibromyalgia.</p>"
    }],
    "item":[],
  'contained': [
    {
      'resourceType': 'Parameters',
      'id': '',
      'parameter': [
        {
          'name':'recommendationId',
          'valueString': '1050980',
          'valueId': '',
          'valueDateTime':''
        },
        {
          'name': 'description',
          'valueString': 'Arthrodesis, Ankle (Talotibial Joint)'
        },
        {
          'name': 'recommendation_indicators',
          'valueString': 'Inpatient'
        },
        {
          'name': 'criteria_met',
          'valueString': 'Criteria Not Met'
        },
        {
          'name': 'disposition_description',
          'valueString': 'Evidence supports services as medically necessary.'
        }
      ],
      'contained':[]
    }
  ]
} as QuestionChoices;

let test = {
    "data": {
      "getGuidelineReview": {
        "reviewResponse": {
          "resourceType": "Questionnaire",
          "id": 353638,
          "version": "RM20",
          "identifier": [
            {
              "use": "official",
              "value": 353638
            },
            {
              "use": "usual",
              "value": "RC3::AISD029604"
            }
          ],
          "name": "Infection: General",
          "title": "LOC:Acute Adult InterQual® 2020, Apr. 2020 Release",
          "status": "active",
          "publisher": "Change Helathcare",
          "text": "<p class=\"tightSpacing\"><b>Instruction:</b> This subset is for the review of infections that are not included in condition−specific infection subsets. This includes criteria for patients with infections that have failed outpatient management and for patients with the following specific infections: &nbsp;&nbsp;&nbsp;&nbsp;</p> <p class=\"I2Tight\">•&nbsp;Central venous catheter infection &nbsp;&nbsp;&nbsp;&nbsp;</p> <p class=\"I2Tight\">•&nbsp;Dengue &nbsp;&nbsp;&nbsp;&nbsp;</p> <p class=\"I2Tight\">•&nbsp;Ebola virus disease &nbsp;&nbsp;&nbsp;&nbsp;</p> <p class=\"I2Tight\">•&nbsp;Epiglottitis &nbsp;&nbsp;&nbsp;&nbsp;</p> <p class=\"I2Tight\">•&nbsp;Fever of unknown origin &nbsp;&nbsp;&nbsp;&nbsp;</p> <p class=\"I2Tight\">•&nbsp;Influenza &nbsp;&nbsp;&nbsp;&nbsp;</p> <p class=\"I2Tight\">•&nbsp;Intraocular infection &nbsp;&nbsp;&nbsp;&nbsp;</p> <p class=\"I2Tight\">•&nbsp;Laboratory test indicative of infection &nbsp;&nbsp;&nbsp;&nbsp;</p> <p class=\"I2Tight\">•&nbsp;Mastoiditis &nbsp;&nbsp;&nbsp;&nbsp;</p> <p class=\"I2Tight\">•&nbsp;Mononucleosis &nbsp;&nbsp;&nbsp;&nbsp;</p> <p class=\"I2Tight\">•&nbsp;Neutropenia &nbsp;&nbsp;&nbsp;&nbsp;</p> <p class=\"I2Tight\">•&nbsp;Peritonsillar abscess &nbsp;&nbsp;&nbsp;&nbsp;</p> <p class=\"I2Tight\">•&nbsp;Pregnancy with a suspected infection &nbsp;&nbsp;&nbsp;&nbsp;</p> <p class=\"I2Tight\">•&nbsp;Retropharyngeal abscess &nbsp;&nbsp;&nbsp;&nbsp;</p> <p class=\"I2Tight\">•&nbsp;Sickle cell disease with a suspected infection &nbsp;&nbsp;&nbsp;&nbsp;</p> <p class=\"I2Tight\">•&nbsp;Tuberculosis &nbsp;&nbsp;&nbsp;&nbsp;</p> <p class=\"I2Tight\">•&nbsp;Typhoid &nbsp;&nbsp;&nbsp;&nbsp;</p> <p class=\"tightSpacing\">Links to condition−specific subsets have been added where applicable.&nbsp;&nbsp;&nbsp;&nbsp;</p><br /><p class=\"tightSpacing\">InterQual<sup>®</sup> criteria are derived from the systematic, continuous review and critical appraisal of the most current evidence−based literature and include input from our independent panel of clinical experts. To generate the most appropriate recommendations, a comprehensive literature review of the clinical evidence was conducted. Sources searched included PubMed, Agency for Healthcare Research and Quality (AHRQ) Comparative Effectiveness Reviews, National Institute for Health and Care Excellence (NICE), the Centers for Medicare and Medicaid Services (CMS), The Cochrane Library, and The Joint Commission. Other medical literature databases, medical content providers, data sources, regulatory body websites, and specialty society resources may also have been utilized. Relevant studies were assessed for risk of bias following principles described in the <i>Cochrane Handbook</i>. The resulting evidence was assessed for consistency, directness, precision, effect size, and publication bias. Observational trials were also evaluated for the presence of a dose−response gradient and the likely effect of plausible confounders. The content is based on a variety of references which are cited at specific criteria points throughout the subset.&nbsp;&nbsp;&nbsp;&nbsp;</p><br />",
          "meta": {
            "tag": [
              {
                "code": "product_id",
                "display": "AISD"
              },
              {
                "code": "version_id",
                "display": "RM20"
              },
              {
                "code": "subset_id",
                "display": "AISD0296"
              },
              {
                "code": "review_type",
                "display": "NDT"
              }
            ]
          },
          "code": [],
              "item": [
                {
                  "linkId": "AISD029604020101",
                  "text": "Diagnosis actual or suspected and addressed in a condition specific subset, <b>One:</b>",
                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604020101&note_type=ALL_NOTES",
                  "type": "group",
                  "repeats": true,
                  "readOnly": false,
                  "item": [
                    {
                      "linkId": "AISD02960402010101",
                      "text": "Abscess, cutaneous (<b>use Infection: Skin subset</b>)",
                      "type": "boolean",
                      "repeats": false,
                      "readOnly": true,
                      "item": []
                    }
              
                  ]
                }]},
          
          "contained": [
            {
              "resourceType": "Questionnaire",
              "id": "AISD02960402",
              "name": "<b>Episode Day 1</b>",
              "title": "group",
              "item": [
                {
                  "linkId": "AISD0296040201",
                  "text": "<b>OBSERVATION,</b> <b>One:</b>",
                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD0296040201&note_type=ALL_NOTES",
                  "type": "group",
                  "repeats": true,
                  "readOnly": false,
                  "item": [
                    {
                      "linkId": "AISD029604020101",
                      "text": "Diagnosis actual or suspected and addressed in a condition specific subset, <b>One:</b>",
                      "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604020101&note_type=ALL_NOTES",
                      "type": "group",
                      "repeats": true,
                      "readOnly": false,
                      "item": [
                        {
                          "linkId": "AISD02960402010101",
                          "text": "Abscess, cutaneous (<b>use Infection: Skin subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402010102",
                          "text": "<i>C. difficile</i> infection (<b>use Infection: GI/GYN subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402010103",
                          "text": "Cellulitis (<b>use Infection: Skin subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402010104",
                          "text": "Gastroenteritis (<b>use Dehydration or Gastroenteritis subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402010105",
                          "text": "Herpes zoster (<b>use Infection: Skin subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402010106",
                          "text": "Meningitis (<b>use Infection: CNS</b><b> subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402010107",
                          "text": "Pelvic inflammatory disease (<b>use Infection: GI/GYN subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402010108",
                          "text": "Pneumonia (<b>use Infection: Pneumonia subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402010109",
                          "text": "Pyelonephritis (<b>use Infection: Pyelonephritis subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402010110",
                          "text": "Wound infection (<b>use Infection: Skin subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        }
                      ]
                    },
                    {
                      "linkId": "AISD029604020102",
                      "text": "Other infection actual or suspected, <b>≥ One:</b>",
                      "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604020102&note_type=ALL_NOTES",
                      "type": "group",
                      "repeats": true,
                      "readOnly": false,
                      "item": [
                        {
                          "linkId": "AISD02960402010201",
                          "text": "Dengue actual or suspected and, <b>Both:</b>",
                          "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD02960402010201&note_type=ALL_NOTES",
                          "type": "group",
                          "repeats": true,
                          "readOnly": true,
                          "item": [
                            {
                              "linkId": "AISD0296040201020101",
                              "text": "Finding, <b>≥ One:</b>",
                              "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD0296040201020101&note_type=ALL_NOTES",
                              "type": "group",
                              "repeats": true,
                              "readOnly": false,
                              "item": [
                                {
                                  "linkId": "AISD029604020102010101",
                                  "text": "Inadequate oral intake",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604020102010101&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020102010102",
                                  "text": "Age &gt; 65 yrs",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020102010103",
                                  "text": "Comorbidity, <b>≥ One:</b>",
                                  "type": "group",
                                  "repeats": true,
                                  "readOnly": false,
                                  "item": [
                                    {
                                      "linkId": "AISD02960402010201010301",
                                      "text": "Diabetes mellitus",
                                      "type": "boolean",
                                      "repeats": false,
                                      "readOnly": true,
                                      "item": []
                                    },
                                    {
                                      "linkId": "AISD02960402010201010302",
                                      "text": "Chronic renal disease",
                                      "type": "boolean",
                                      "repeats": false,
                                      "readOnly": true,
                                      "item": []
                                    },
                                    {
                                      "linkId": "AISD02960402010201010303",
                                      "text": "Hemolytic disease",
                                      "type": "boolean",
                                      "repeats": false,
                                      "readOnly": true,
                                      "item": []
                                    },
                                    {
                                      "linkId": "AISD02960402010201010304",
                                      "text": "Obesity",
                                      "type": "boolean",
                                      "repeats": false,
                                      "readOnly": true,
                                      "item": []
                                    }
                                  ]
                                },
                                {
                                  "linkId": "AISD029604020102010104",
                                  "text": "Emergency services remote",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020102010105",
                                  "text": "Unable to obtain follow−up care within 24h",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604020102010105&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            },
                            {
                              "linkId": "AISD0296040201020102",
                              "text": "Intervention, <b>All:</b>",
                              "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD0296040201020102&note_type=ALL_NOTES",
                              "type": "group",
                              "repeats": true,
                              "readOnly": false,
                              "item": [
                                {
                                  "linkId": "AISD029604020102010201",
                                  "text": "Hct monitoring at least 2x/24h",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604020102010201&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020102010202",
                                  "text": "IV fluid",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604020102010202&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020102010203",
                                  "text": "Vital sign monitoring at least 4x/24h",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            }
                          ]
                        },
                        {
                          "linkId": "AISD02960402010202",
                          "text": "Mononucleosis and, <b>Both:</b>",
                          "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD02960402010202&note_type=ALL_NOTES",
                          "type": "group",
                          "repeats": true,
                          "readOnly": true,
                          "item": [
                            {
                              "linkId": "AISD0296040201020201",
                              "text": "Finding, <b>Both:</b>",
                              "type": "group",
                              "repeats": true,
                              "readOnly": false,
                              "item": [
                                {
                                  "linkId": "AISD029604020102020101",
                                  "text": "Impaired swallowing",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020102020102",
                                  "text": "Inadequate oral intake",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604020102020102&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            },
                            {
                              "linkId": "AISD0296040201020202",
                              "text": "IV fluid, <b>One:</b>",
                              "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD0296040201020202&note_type=ALL_NOTES",
                              "type": "group",
                              "repeats": true,
                              "readOnly": false,
                              "item": [
                                {
                                  "linkId": "AISD029604020102020201",
                                  "text": "≥ 75 mL/h and, <b>≥ One:</b>",
                                  "type": "group",
                                  "repeats": true,
                                  "readOnly": true,
                                  "item": [
                                    {
                                      "linkId": "AISD02960402010202020101",
                                      "text": "Weight &lt;&nbsp;60 kg",
                                      "type": "boolean",
                                      "repeats": false,
                                      "readOnly": true,
                                      "item": []
                                    },
                                    {
                                      "linkId": "AISD02960402010202020102",
                                      "text": "Age ≥ 65",
                                      "type": "boolean",
                                      "repeats": false,
                                      "readOnly": true,
                                      "item": []
                                    },
                                    {
                                      "linkId": "AISD02960402010202020103",
                                      "text": "Renal insufficiency",
                                      "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD02960402010202020103&note_type=ALL_NOTES",
                                      "type": "boolean",
                                      "repeats": false,
                                      "readOnly": true,
                                      "item": []
                                    },
                                    {
                                      "linkId": "AISD02960402010202020104",
                                      "text": "Heart failure, chronic",
                                      "type": "boolean",
                                      "repeats": false,
                                      "readOnly": true,
                                      "item": []
                                    }
                                  ]
                                },
                                {
                                  "linkId": "AISD029604020102020202",
                                  "text": "≥ 100 mL/h and weight ≥ 60 kg",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            }
                          ]
                        },
                        {
                          "linkId": "AISD02960402010203",
                          "text": "Peritonsillar abscess actual or suspected and, <b>Both:</b>",
                          "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD02960402010203&note_type=ALL_NOTES",
                          "type": "group",
                          "repeats": true,
                          "readOnly": true,
                          "item": [
                            {
                              "linkId": "AISD0296040201020301",
                              "text": "Drainage, surgical and, <b>One:</b>",
                              "type": "group",
                              "repeats": true,
                              "readOnly": true,
                              "item": [
                                {
                                  "linkId": "AISD029604020102030101",
                                  "text": "Performed within last 24h",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020102030102",
                                  "text": "Anticipated within the next 24h",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604020102030102&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            },
                            {
                              "linkId": "AISD0296040201020302",
                              "text": "Anti−infective",
                              "type": "boolean",
                              "repeats": false,
                              "readOnly": true,
                              "item": []
                            }
                          ]
                        },
                        {
                          "linkId": "AISD02960402010204",
                          "text": "Viral respiratory infection, actual or suspected, <b>All:</b>",
                          "type": "group",
                          "repeats": true,
                          "readOnly": false,
                          "item": [
                            {
                              "linkId": "AISD0296040201020401",
                              "text": "Dyspnea",
                              "type": "boolean",
                              "repeats": false,
                              "readOnly": true,
                              "item": []
                            },
                            {
                              "linkId": "AISD0296040201020402",
                              "text": "Oxygenation, <b>≥ One:</b>",
                              "type": "group",
                              "repeats": true,
                              "readOnly": false,
                              "item": [
                                {
                                  "linkId": "AISD029604020102040201",
                                  "text": "Arterial Po<sub>2&nbsp;</sub>56−60&nbsp;mmHg(7.4−8.0&nbsp;kPa) and &lt; baseline",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604020102040201&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020102040202",
                                  "text": "O<sub>2</sub> sat&nbsp;90−91%(0.90−0.91) and &lt; baseline",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604020102040202&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            },
                            {
                              "linkId": "AISD0296040201020403",
                              "text": "Requiring supplemental oxygen",
                              "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD0296040201020403&note_type=ALL_NOTES",
                              "type": "boolean",
                              "repeats": false,
                              "readOnly": true,
                              "item": []
                            }
                          ]
                        }
                      ]
                    }
                  ]
                },
                {
                  "linkId": "AISD0296040202",
                  "text": "<b>ACUTE,</b> <b>One:</b>",
                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD0296040202&note_type=ALL_NOTES",
                  "type": "group",
                  "repeats": true,
                  "readOnly": false,
                  "item": [
                    {
                      "linkId": "AISD029604020201",
                      "text": "Diagnosis actual or suspected and addressed in a condition specific subset, <b>One:</b>",
                      "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604020201&note_type=ALL_NOTES",
                      "type": "group",
                      "repeats": true,
                      "readOnly": false,
                      "item": [
                        {
                          "linkId": "AISD02960402020101",
                          "text": "Abscess cutaneous (<b>use Infection: Skin</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402020102",
                          "text": "Ascending cholangitis (<b>use Infection: GI/GYN subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402020103",
                          "text": "Brain abscess (<b>use Infection: CNS</b><b> subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402020104",
                          "text": "Cellulitis (<b>use Infection: Cellulitis subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402020105",
                          "text": "<i>C. difficile</i> infection (<b>use Infection: GI/GYN subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402020106",
                          "text": "Diabetic foot ulcer (<b>use Infection: Skin subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402020107",
                          "text": "Diverticulitis (<b>use Infection: GI/GYN subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402020108",
                          "text": "Encephalitis (<b>use Infection: CNS</b><b> subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402020109",
                          "text": "Endocarditis (<b>use Infection: Endocarditis subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402020110",
                          "text": "Gastroenteritis (<b>use Dehydration or Gastroenteritis subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402020111",
                          "text": "Herpes zoster (<b>use Infection: Skin subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402020112",
                          "text": "Intra−abdominal abscess (<b>use Infection: GI/GYN subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402020113",
                          "text": "Meningitis (<b>use Infection: CNS</b><b> subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402020114",
                          "text": "Osteomyelitis (<b>use Infection: Musculoskeletal subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402020115",
                          "text": "Pelvic abscess (<b>use Infection: GI/GYN subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402020116",
                          "text": "Pelvic inflammatory disease (<b>use Infection: GI/GYN subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402020117",
                          "text": "Pneumonia (<b>use Infection: Pneumonia subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402020118",
                          "text": "Pyelonephritis (<b>use Infection: Pyelonephritis subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402020119",
                          "text": "Septic arthritis (<b>use Infection: Musculoskeletal subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402020120",
                          "text": "Spontaneous bacterial peritonitis (<b>use Infection: GI/GYN subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402020121",
                          "text": "Systemic infection unknown source (<b>use Infection: Sepsis subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402020122",
                          "text": "Wound infection (<b>use Infection: Skin subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        }
                      ]
                    },
                    {
                      "linkId": "AISD029604020202",
                      "text": "Other infection actual or suspected, <b>≥ One:</b>",
                      "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604020202&note_type=ALL_NOTES",
                      "type": "group",
                      "repeats": true,
                      "readOnly": false,
                      "item": [
                        {
                          "linkId": "AISD02960402020201",
                          "text": "Central venous catheter and, <b>Both:</b>",
                          "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD02960402020201&note_type=ALL_NOTES",
                          "type": "group",
                          "repeats": true,
                          "readOnly": true,
                          "item": [
                            {
                              "linkId": "AISD0296040202020101",
                              "text": "Finding, <b>≥ One:</b>",
                              "type": "group",
                              "repeats": true,
                              "readOnly": false,
                              "item": [
                                {
                                  "linkId": "AISD029604020202010101",
                                  "text": "Temperature, <b>≥ One:</b>",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604020202010101&note_type=ALL_NOTES",
                                  "type": "group",
                                  "repeats": true,
                                  "readOnly": false,
                                  "item": [
                                    {
                                      "linkId": "AISD02960402020201010101",
                                      "text": "&gt;&nbsp;99.4°F(37.4°C) PO",
                                      "type": "boolean",
                                      "repeats": false,
                                      "readOnly": true,
                                      "item": []
                                    },
                                    {
                                      "linkId": "AISD02960402020201010102",
                                      "text": "&gt; 100.4°F(38.0°C) PR",
                                      "type": "boolean",
                                      "repeats": false,
                                      "readOnly": true,
                                      "item": []
                                    }
                                  ]
                                },
                                {
                                  "linkId": "AISD029604020202010102",
                                  "text": "Outpatient blood culture positive",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202010103",
                                  "text": "Purulent drainage at exit site",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604020202010103&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            },
                            {
                              "linkId": "AISD0296040202020102",
                              "text": "Anti−infective",
                              "type": "boolean",
                              "repeats": false,
                              "readOnly": true,
                              "item": []
                            }
                          ]
                        },
                        {
                          "linkId": "AISD02960402020202",
                          "text": "Dengue actual or suspected and, <b>Both:</b>",
                          "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD02960402020202&note_type=ALL_NOTES",
                          "type": "group",
                          "repeats": true,
                          "readOnly": true,
                          "item": [
                            {
                              "linkId": "AISD0296040202020201",
                              "text": "Finding, <b>≥ One:</b>",
                              "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD0296040202020201&note_type=ALL_NOTES",
                              "type": "group",
                              "repeats": true,
                              "readOnly": false,
                              "item": [
                                {
                                  "linkId": "AISD029604020202020101",
                                  "text": "Abdominal pain",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202020102",
                                  "text": "Ascites",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202020103",
                                  "text": "Hct &gt;&nbsp;10%(0.10) increase from baseline",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202020104",
                                  "text": "Hepatomegaly &gt;&nbsp;2&nbsp;cm",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202020105",
                                  "text": "Mental status changes (excludes coma, stupor, or obtundation) or GCS 9−14",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604020202020105&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202020106",
                                  "text": "Mucosal bleeding",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202020107",
                                  "text": "Platelet count &lt;&nbsp;100,000/cu.mm(100x10<sup>9</sup>/L)",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202020108",
                                  "text": "Petechiae",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604020202020108&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202020109",
                                  "text": "Pleural effusion",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202020110",
                                  "text": "Pregnancy",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202020111",
                                  "text": "Vomiting, protracted",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604020202020111&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            },
                            {
                              "linkId": "AISD0296040202020202",
                              "text": "Intervention, <b>All:</b>",
                              "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD0296040202020202&note_type=ALL_NOTES",
                              "type": "group",
                              "repeats": true,
                              "readOnly": false,
                              "item": [
                                {
                                  "linkId": "AISD029604020202020201",
                                  "text": "Hct monitoring at least 2x/24h",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604020202020201&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202020202",
                                  "text": "IV fluid",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604020202020202&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202020203",
                                  "text": "Vital sign monitoring at least 6x/24h",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            }
                          ]
                        },
                        {
                          "linkId": "AISD02960402020203",
                          "text": "Ebola virus disease actual or suspected and, <b>All:</b>",
                          "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD02960402020203&note_type=ALL_NOTES",
                          "type": "group",
                          "repeats": true,
                          "readOnly": true,
                          "item": [
                            {
                              "linkId": "AISD0296040202020301",
                              "text": "Risk factor, <b>≥ One:</b>",
                              "type": "group",
                              "repeats": true,
                              "readOnly": false,
                              "item": [
                                {
                                  "linkId": "AISD029604020202030101",
                                  "text": "Recent contact with known symptomatic patient",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604020202030101&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202030102",
                                  "text": "Recent residence in country with transmission",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604020202030102&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202030103",
                                  "text": "Recent travel to country with transmission",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604020202030103&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            },
                            {
                              "linkId": "AISD0296040202020302",
                              "text": "Finding, <b>≥ One:</b>",
                              "type": "group",
                              "repeats": true,
                              "readOnly": false,
                              "item": [
                                {
                                  "linkId": "AISD029604020202030201",
                                  "text": "Temperature, <b>≥ One:</b>",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604020202030201&note_type=ALL_NOTES",
                                  "type": "group",
                                  "repeats": true,
                                  "readOnly": false,
                                  "item": [
                                    {
                                      "linkId": "AISD02960402020203020101",
                                      "text": "&gt;&nbsp;99.4°F(37.4°C) PO",
                                      "type": "boolean",
                                      "repeats": false,
                                      "readOnly": true,
                                      "item": []
                                    },
                                    {
                                      "linkId": "AISD02960402020203020102",
                                      "text": "&gt; 100.4°F(38.0°C) PR",
                                      "type": "boolean",
                                      "repeats": false,
                                      "readOnly": true,
                                      "item": []
                                    }
                                  ]
                                },
                                {
                                  "linkId": "AISD029604020202030202",
                                  "text": "Abdominal pain",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202030203",
                                  "text": "Diarrhea",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202030204",
                                  "text": "Fatigue",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202030205",
                                  "text": "Muscle pain",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202030206",
                                  "text": "Severe headache",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202030207",
                                  "text": "Unexplained bleeding",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202030208",
                                  "text": "Unexplained bruising",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202030209",
                                  "text": "Vomiting",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            },
                            {
                              "linkId": "AISD0296040202020303",
                              "text": "Intervention, <b>All:</b>",
                              "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD0296040202020303&note_type=ALL_NOTES",
                              "type": "group",
                              "repeats": true,
                              "readOnly": false,
                              "item": [
                                {
                                  "linkId": "AISD029604020202030301",
                                  "text": "Isolation",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604020202030301&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202030302",
                                  "text": "IV fluid",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202030303",
                                  "text": "Lab confirmation, pending or confirmed",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604020202030303&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202030304",
                                  "text": "Respiratory monitoring at least every 4h or continuous",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            }
                          ]
                        },
                        {
                          "linkId": "AISD02960402020204",
                          "text": "Fever of unknown origin and, <b>All:</b>",
                          "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD02960402020204&note_type=ALL_NOTES",
                          "type": "group",
                          "repeats": true,
                          "readOnly": true,
                          "item": [
                            {
                              "linkId": "AISD0296040202020401",
                              "text": "Temperature, <b>≥ One:</b>",
                              "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD0296040202020401&note_type=ALL_NOTES",
                              "type": "group",
                              "repeats": true,
                              "readOnly": false,
                              "item": [
                                {
                                  "linkId": "AISD029604020202040101",
                                  "text": "&gt;&nbsp;101.0°F(38.3°C)&nbsp;PO&nbsp;≥&nbsp;3 wks",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202040102",
                                  "text": "&gt;&nbsp;102.0°F(38.9°C)&nbsp;PR&nbsp;≥&nbsp;3 wks",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            },
                            {
                              "linkId": "AISD0296040202020402",
                              "text": "Outpatient work−up non−diagnostic",
                              "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD0296040202020402&note_type=ALL_NOTES",
                              "type": "boolean",
                              "repeats": false,
                              "readOnly": true,
                              "item": []
                            },
                            {
                              "linkId": "AISD0296040202020403",
                              "text": "Secondary evaluation ≤ 3d",
                              "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD0296040202020403&note_type=ALL_NOTES",
                              "type": "boolean",
                              "repeats": false,
                              "readOnly": true,
                              "item": []
                            }
                          ]
                        },
                        {
                          "linkId": "AISD02960402020205",
                          "text": "Intraocular infection and anti−infective",
                          "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD02960402020205&note_type=ALL_NOTES",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402020206",
                          "text": "Laboratory result indicative of infection and, <b>All:</b>",
                          "type": "group",
                          "repeats": true,
                          "readOnly": true,
                          "item": [
                            {
                              "linkId": "AISD0296040202020601",
                              "text": "Test, <b>≥ One:</b>",
                              "type": "group",
                              "repeats": true,
                              "readOnly": false,
                              "item": [
                                {
                                  "linkId": "AISD029604020202060101",
                                  "text": "Positive culture for bacteria",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202060102",
                                  "text": "Positive smear for bacteria",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202060103",
                                  "text": "Positive antigen for bacteria",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202060104",
                                  "text": "Positive latex agglutination for bacteria",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202060105",
                                  "text": "Positive culture for fungi",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202060106",
                                  "text": "Positive smear for fungi",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202060107",
                                  "text": "Positive antigen for fungi",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202060108",
                                  "text": "Positive latex agglutination for fungi",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202060109",
                                  "text": "Positive culture for protozoa",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202060110",
                                  "text": "Positive smear for protozoa",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202060111",
                                  "text": "Positive antigen for protozoa",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202060112",
                                  "text": "Positive latex agglutination for protozoa",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            },
                            {
                              "linkId": "AISD0296040202020602",
                              "text": "Source, <b>≥ One:</b>",
                              "type": "group",
                              "repeats": true,
                              "readOnly": false,
                              "item": [
                                {
                                  "linkId": "AISD029604020202060201",
                                  "text": "Biopsy, surgical (excludes skin)<sup> </sup>",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604020202060201&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202060202",
                                  "text": "Blood",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202060203",
                                  "text": "Bone marrow",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202060204",
                                  "text": "Effluent smear<sup> </sup>",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604020202060204&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            },
                            {
                              "linkId": "AISD0296040202020603",
                              "text": "Anti−infective",
                              "type": "boolean",
                              "repeats": false,
                              "readOnly": true,
                              "item": []
                            }
                          ]
                        },
                        {
                          "linkId": "AISD02960402020207",
                          "text": "Mastoiditis and, <b>All:</b>",
                          "type": "group",
                          "repeats": true,
                          "readOnly": true,
                          "item": [
                            {
                              "linkId": "AISD0296040202020701",
                              "text": "Temperature, <b>≥ One:</b>",
                              "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD0296040202020701&note_type=ALL_NOTES",
                              "type": "group",
                              "repeats": true,
                              "readOnly": false,
                              "item": [
                                {
                                  "linkId": "AISD029604020202070101",
                                  "text": "&gt;&nbsp;99.4°F(37.4°C) PO",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202070102",
                                  "text": "&gt; 100.4°F(38.0°C) PR",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            },
                            {
                              "linkId": "AISD0296040202020702",
                              "text": "Confirmed by x−ray or CT",
                              "type": "boolean",
                              "repeats": false,
                              "readOnly": true,
                              "item": []
                            },
                            {
                              "linkId": "AISD0296040202020703",
                              "text": "Erythema or pain over mastoid area",
                              "type": "boolean",
                              "repeats": false,
                              "readOnly": true,
                              "item": []
                            },
                            {
                              "linkId": "AISD0296040202020704",
                              "text": "Anti−infective",
                              "type": "boolean",
                              "repeats": false,
                              "readOnly": true,
                              "item": []
                            }
                          ]
                        },
                        {
                          "linkId": "AISD02960402020208",
                          "text": "Neutropenia, <b>All:</b>",
                          "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD02960402020208&note_type=ALL_NOTES",
                          "type": "group",
                          "repeats": true,
                          "readOnly": false,
                          "item": [
                            {
                              "linkId": "AISD0296040202020801",
                              "text": "Temperature, <b>≥ One:</b>",
                              "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD0296040202020801&note_type=ALL_NOTES",
                              "type": "group",
                              "repeats": true,
                              "readOnly": false,
                              "item": [
                                {
                                  "linkId": "AISD029604020202080101",
                                  "text": "&gt;&nbsp;99.4°F(37.4°C) PO",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202080102",
                                  "text": "&gt; 100.4°F(38.0°C) PR",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            },
                            {
                              "linkId": "AISD0296040202020802",
                              "text": "ANC, <b>One:</b>",
                              "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD0296040202020802&note_type=ALL_NOTES",
                              "type": "group",
                              "repeats": true,
                              "readOnly": false,
                              "item": [
                                {
                                  "linkId": "AISD029604020202080201",
                                  "text": "&lt;&nbsp;500/cu.mm(500x10<sup>6</sup>/L)",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202080202",
                                  "text": "&lt;&nbsp;1000/cu.mm(1000x10<sup>6</sup>/L) with documented decline",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604020202080202&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            },
                            {
                              "linkId": "AISD0296040202020803",
                              "text": "Anti−infective",
                              "type": "boolean",
                              "repeats": false,
                              "readOnly": true,
                              "item": []
                            }
                          ]
                        },
                        {
                          "linkId": "AISD02960402020209",
                          "text": "Pregnancy and suspected infection and, <b>All:</b>",
                          "type": "group",
                          "repeats": true,
                          "readOnly": true,
                          "item": [
                            {
                              "linkId": "AISD0296040202020901",
                              "text": "Temperature, <b>≥ One:</b>",
                              "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD0296040202020901&note_type=ALL_NOTES",
                              "type": "group",
                              "repeats": true,
                              "readOnly": false,
                              "item": [
                                {
                                  "linkId": "AISD029604020202090101",
                                  "text": "&gt;&nbsp;99.4°F(37.4°C) PO",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202090102",
                                  "text": "&gt; 100.4°F(38.0°C) PR",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            },
                            {
                              "linkId": "AISD0296040202020902",
                              "text": "WBC, <b>≥ One:</b>",
                              "type": "group",
                              "repeats": true,
                              "readOnly": false,
                              "item": [
                                {
                                  "linkId": "AISD029604020202090201",
                                  "text": "&gt; 18,000/cu.mm(18x10<sup>9</sup>/L)",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202090202",
                                  "text": "&gt; 15,000/cu.mm(15x10<sup>9</sup>/L) and bands &gt; 7%(0.07)",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            },
                            {
                              "linkId": "AISD0296040202020903",
                              "text": "Anti−infective",
                              "type": "boolean",
                              "repeats": false,
                              "readOnly": true,
                              "item": []
                            }
                          ]
                        },
                        {
                          "linkId": "AISD02960402020210",
                          "text": "Retropharyngeal abscess actual or suspected and, <b>Both:</b>",
                          "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD02960402020210&note_type=ALL_NOTES",
                          "type": "group",
                          "repeats": true,
                          "readOnly": true,
                          "item": [
                            {
                              "linkId": "AISD0296040202021001",
                              "text": "Surgical evaluation and, <b>One:</b>",
                              "type": "group",
                              "repeats": true,
                              "readOnly": true,
                              "item": [
                                {
                                  "linkId": "AISD029604020202100101",
                                  "text": "Performed within 24h",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202100102",
                                  "text": "Scheduled within 24h",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            },
                            {
                              "linkId": "AISD0296040202021002",
                              "text": "Anti−infective",
                              "type": "boolean",
                              "repeats": false,
                              "readOnly": true,
                              "item": []
                            }
                          ]
                        },
                        {
                          "linkId": "AISD02960402020211",
                          "text": "Sickle cell disease and suspected infection and, <b>All:</b>",
                          "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD02960402020211&note_type=ALL_NOTES",
                          "type": "group",
                          "repeats": true,
                          "readOnly": true,
                          "item": [
                            {
                              "linkId": "AISD0296040202021101",
                              "text": "Temperature, <b>≥ One:</b>",
                              "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD0296040202021101&note_type=ALL_NOTES",
                              "type": "group",
                              "repeats": true,
                              "readOnly": false,
                              "item": [
                                {
                                  "linkId": "AISD029604020202110101",
                                  "text": "≥&nbsp;103.1°F(39.5°C)&nbsp;PO",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202110102",
                                  "text": "≥&nbsp;104.1°F(40.0°C)&nbsp;PR",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            },
                            {
                              "linkId": "AISD0296040202021102",
                              "text": "Cultures pending, <b>Both:</b>",
                              "type": "group",
                              "repeats": true,
                              "readOnly": false,
                              "item": [
                                {
                                  "linkId": "AISD029604020202110201",
                                  "text": "Blood",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202110202",
                                  "text": "Urine",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            },
                            {
                              "linkId": "AISD0296040202021103",
                              "text": "Anti−infective",
                              "type": "boolean",
                              "repeats": false,
                              "readOnly": true,
                              "item": []
                            }
                          ]
                        },
                        {
                          "linkId": "AISD02960402020212",
                          "text": "TB actual or suspected and, <b>Both:</b>",
                          "type": "group",
                          "repeats": true,
                          "readOnly": true,
                          "item": [
                            {
                              "linkId": "AISD0296040202021201",
                              "text": "Negative airflow isolation",
                              "type": "boolean",
                              "repeats": false,
                              "readOnly": true,
                              "item": []
                            },
                            {
                              "linkId": "AISD0296040202021202",
                              "text": "Finding, <b>One:</b>",
                              "type": "group",
                              "repeats": true,
                              "readOnly": false,
                              "item": [
                                {
                                  "linkId": "AISD029604020202120201",
                                  "text": "Public health risk and anti−infective (includes PO)",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604020202120201&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202120202",
                                  "text": "&lt; 3 consecutive negative AFB sputum smears",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604020202120202&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202120203",
                                  "text": "Positive AFB sputum smear and anti−infective (includes PO)",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            }
                          ]
                        },
                        {
                          "linkId": "AISD02960402020213",
                          "text": "Typhoid fever actual or suspected and, <b>All:</b>",
                          "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD02960402020213&note_type=ALL_NOTES",
                          "type": "group",
                          "repeats": true,
                          "readOnly": true,
                          "item": [
                            {
                              "linkId": "AISD0296040202021301",
                              "text": "Temperature, <b>≥ One:</b>",
                              "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD0296040202021301&note_type=ALL_NOTES",
                              "type": "group",
                              "repeats": true,
                              "readOnly": false,
                              "item": [
                                {
                                  "linkId": "AISD029604020202130101",
                                  "text": "&gt;&nbsp;99.4°F(37.4°C) PO",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202130102",
                                  "text": "&gt; 100.4°F(38.0°C) PR",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            },
                            {
                              "linkId": "AISD0296040202021302",
                              "text": "Finding, <b>≥ One:</b>",
                              "type": "group",
                              "repeats": true,
                              "readOnly": false,
                              "item": [
                                {
                                  "linkId": "AISD029604020202130201",
                                  "text": "Abdominal distention",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202130202",
                                  "text": "Abdominal pain",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202130203",
                                  "text": "Inadequate oral intake",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604020202130203&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202130204",
                                  "text": "Mental status changes (excludes coma, stupor, or obtundation) or GCS 9−14",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            },
                            {
                              "linkId": "AISD0296040202021303",
                              "text": "Anti−infective",
                              "type": "boolean",
                              "repeats": false,
                              "readOnly": true,
                              "item": []
                            }
                          ]
                        },
                        {
                          "linkId": "AISD02960402020214",
                          "text": "Viral respiratory infection, actual or suspected, <b>All:</b>",
                          "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD02960402020214&note_type=ALL_NOTES",
                          "type": "group",
                          "repeats": true,
                          "readOnly": false,
                          "item": [
                            {
                              "linkId": "AISD0296040202021401",
                              "text": "Dyspnea",
                              "type": "boolean",
                              "repeats": false,
                              "readOnly": true,
                              "item": []
                            },
                            {
                              "linkId": "AISD0296040202021402",
                              "text": "Oxygenation, <b>≥ One:</b>",
                              "type": "group",
                              "repeats": true,
                              "readOnly": false,
                              "item": [
                                {
                                  "linkId": "AISD029604020202140201",
                                  "text": "Arterial Po<sub>2 </sub>&lt; 56 mmHg(7.4 kPa) and &lt; baseline",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604020202140201&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020202140202",
                                  "text": "O<sub>2</sub> sat ≤ 89%(0.89) and &lt; baseline",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604020202140202&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            },
                            {
                              "linkId": "AISD0296040202021403",
                              "text": "Requiring supplemental oxygen",
                              "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD0296040202021403&note_type=ALL_NOTES",
                              "type": "boolean",
                              "repeats": false,
                              "readOnly": true,
                              "item": []
                            }
                          ]
                        }
                      ]
                    }
                  ]
                },
                {
                  "linkId": "AISD0296040203",
                  "text": "<b>INTERMEDIATE</b>, <b>One:</b>",
                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD0296040203&note_type=ALL_NOTES",
                  "type": "group",
                  "repeats": true,
                  "readOnly": false,
                  "item": [
                    {
                      "linkId": "AISD029604020301",
                      "text": "Diagnosis actual or suspected, and addressed in a condition specific subset, <b>One:</b>",
                      "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604020301&note_type=ALL_NOTES",
                      "type": "group",
                      "repeats": true,
                      "readOnly": false,
                      "item": [
                        {
                          "linkId": "AISD02960402030101",
                          "text": "Ascending cholangitis (<b>use Infection: GI/GYN subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402030102",
                          "text": "Brain abscess (<b>use Infection: CNS</b><b> subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402030103",
                          "text": "<i>C. difficile</i> infection (<b>use Infection: GI/GYN subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402030104",
                          "text": "Diverticulitis (<b>use Infection: GI/GYN subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402030105",
                          "text": "Encephalitis (<b>use Infection: CNS</b><b> subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402030106",
                          "text": "Endocarditis (<b>use Infection: Endocarditis subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402030107",
                          "text": "Gastroenteritis (<b>use Dehydration or Gastroenteritis subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402030108",
                          "text": "Intra−abdominal abscess (<b>use Infection: GI/GYN subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402030109",
                          "text": "Meningitis (<b>use Infection: CNS</b><b> subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402030110",
                          "text": "Pelvic abscess (<b>use Infection: GI/GYN subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402030111",
                          "text": "Pelvic inflammatory disease (<b>use Infection: GI/GYN subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402030112",
                          "text": "Pneumonia (<b>use Infection: Pneumonia subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402030113",
                          "text": "Pyelonephritis (<b>use Infection: Pyelonephritis subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402030114",
                          "text": "Sepsis (<b>use Infection: Sepsis subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402030115",
                          "text": "Spontaneous bacterial peritonitis (<b>use Infection: GI/GYN subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        }
                      ]
                    },
                    {
                      "linkId": "AISD029604020302",
                      "text": "Other infection actual or suspected, <b>≥ One:</b>",
                      "type": "group",
                      "repeats": true,
                      "readOnly": false,
                      "item": [
                        {
                          "linkId": "AISD02960402030201",
                          "text": "Hypovolemia, <b>Both:</b>",
                          "type": "group",
                          "repeats": true,
                          "readOnly": false,
                          "item": [
                            {
                              "linkId": "AISD0296040203020101",
                              "text": "Systolic blood pressure 90−99&nbsp;mmHg",
                              "type": "boolean",
                              "repeats": false,
                              "readOnly": true,
                              "item": []
                            },
                            {
                              "linkId": "AISD0296040203020102",
                              "text": "Volume expander ≤&nbsp;2d",
                              "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD0296040203020102&note_type=ALL_NOTES",
                              "type": "boolean",
                              "repeats": false,
                              "readOnly": true,
                              "item": []
                            }
                          ]
                        },
                        {
                          "linkId": "AISD02960402030202",
                          "text": "NIPPV and, <b>≥ One:</b>",
                          "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD02960402030202&note_type=ALL_NOTES",
                          "type": "group",
                          "repeats": true,
                          "readOnly": true,
                          "item": [
                            {
                              "linkId": "AISD0296040203020201",
                              "text": "O<sub>2</sub> sat, <b>One:</b>",
                              "type": "group",
                              "repeats": true,
                              "readOnly": false,
                              "item": [
                                {
                                  "linkId": "AISD029604020302020101",
                                  "text": "&lt; 89%(0.89) and &lt; baseline",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604020302020101&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020302020102",
                                  "text": "Room air assessment not clinically appropriate",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604020302020102&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            },
                            {
                              "linkId": "AISD0296040203020202",
                              "text": "Arterial PO<sub>2</sub> 40−55 mmHg(5.3−7.3 kPa) and pH 7.50−7.55",
                              "type": "boolean",
                              "repeats": false,
                              "readOnly": true,
                              "item": []
                            },
                            {
                              "linkId": "AISD0296040203020203",
                              "text": "Arterial Pco<sub>2</sub> 55−59 mmHg(7.3−7.9 kPa) and pH 7.25−7.30",
                              "type": "boolean",
                              "repeats": false,
                              "readOnly": true,
                              "item": []
                            },
                            {
                              "linkId": "AISD0296040203020204",
                              "text": "Venous Pco<sub>2</sub> 55−59 mmHg(7.3−7.9 kPa) and pH 7.25−7.30",
                              "type": "boolean",
                              "repeats": false,
                              "readOnly": true,
                              "item": []
                            }
                          ]
                        },
                        {
                          "linkId": "AISD02960402030203",
                          "text": "Oxygen, <b>≥ One:</b>",
                          "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD02960402030203&note_type=ALL_NOTES",
                          "type": "group",
                          "repeats": true,
                          "readOnly": false,
                          "item": [
                            {
                              "linkId": "AISD0296040203020301",
                              "text": "HFNC and respiratory monitoring every 3−4h",
                              "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD0296040203020301&note_type=ALL_NOTES",
                              "type": "boolean",
                              "repeats": false,
                              "readOnly": true,
                              "item": []
                            },
                            {
                              "linkId": "AISD0296040203020302",
                              "text": "Oxygen&nbsp;≥&nbsp;40%(0.40) ≤ 2d",
                              "type": "boolean",
                              "repeats": false,
                              "readOnly": true,
                              "item": []
                            }
                          ]
                        }
                      ]
                    }
                  ]
                },
                {
                  "linkId": "AISD0296040204",
                  "text": "<b>CRITICAL,</b> <b>One:</b>",
                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD0296040204&note_type=ALL_NOTES",
                  "type": "group",
                  "repeats": true,
                  "readOnly": false,
                  "item": [
                    {
                      "linkId": "AISD029604020401",
                      "text": "Diagnosis actual or suspected and addressed in a condition specific subset, <b>One:</b>",
                      "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604020401&note_type=ALL_NOTES",
                      "type": "group",
                      "repeats": true,
                      "readOnly": false,
                      "item": [
                        {
                          "linkId": "AISD02960402040101",
                          "text": "Ascending cholangitis (<b>use Infection: GI/GYN subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402040102",
                          "text": "Brain abscess (<b>use Infection: CNS</b><b> subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402040103",
                          "text": "<i>C. difficile</i> infection (<b>use Infection: GI/GYN subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402040104",
                          "text": "Diverticulitis (<b>use Infection: GI/GYN subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402040105",
                          "text": "Encephalitis (<b>use Infection: CNS</b><b> subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402040106",
                          "text": "Endocarditis (<b>use Infection: Endocarditis subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402040107",
                          "text": "Gastroenteritis (<b>use Dehydration or Gastroenteritis subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402040108",
                          "text": "Intra−abdominal abscess (<b>use Infection: GI/GYN subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402040109",
                          "text": "Meningitis (<b>use Infection: CNS</b><b> subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402040110",
                          "text": "Pelvic abscess (<b>use Infection: GI/GYN subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402040111",
                          "text": "Pelvic inflammatory disease (<b>use Infection: GI/GYN subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402040112",
                          "text": "Pneumonia (<b>use Infection: Pneumonia subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402040113",
                          "text": "Pyelonephritis (<b>use Infection: Pyelonephritis subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402040114",
                          "text": "Sepsis (<b>use Infection: Sepsis subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402040115",
                          "text": "Spontaneous bacterial peritonitis (<b>use Infection: GI/GYN subset</b>)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        }
                      ]
                    },
                    {
                      "linkId": "AISD029604020402",
                      "text": "Other infection actual or suspected, <b>≥ One:</b>",
                      "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604020402&note_type=ALL_NOTES",
                      "type": "group",
                      "repeats": true,
                      "readOnly": false,
                      "item": [
                        {
                          "linkId": "AISD02960402040201",
                          "text": "Epiglottitis actual or suspected and, <b>All:</b>",
                          "type": "group",
                          "repeats": true,
                          "readOnly": true,
                          "item": [
                            {
                              "linkId": "AISD0296040204020101",
                              "text": "Risk of airway compromise",
                              "type": "boolean",
                              "repeats": false,
                              "readOnly": true,
                              "item": []
                            },
                            {
                              "linkId": "AISD0296040204020102",
                              "text": "Finding, <b>≥ One:</b>",
                              "type": "group",
                              "repeats": true,
                              "readOnly": false,
                              "item": [
                                {
                                  "linkId": "AISD029604020402010201",
                                  "text": "Confirmed by x−ray",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020402010202",
                                  "text": "Difficulty swallowing",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020402010203",
                                  "text": "Drooling",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            },
                            {
                              "linkId": "AISD0296040204020103",
                              "text": "Oximetry",
                              "type": "boolean",
                              "repeats": false,
                              "readOnly": true,
                              "item": []
                            }
                          ]
                        },
                        {
                          "linkId": "AISD02960402040202",
                          "text": "Peritonsillar abscess actual or suspected and, <b>All:</b>",
                          "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD02960402040202&note_type=ALL_NOTES",
                          "type": "group",
                          "repeats": true,
                          "readOnly": true,
                          "item": [
                            {
                              "linkId": "AISD0296040204020201",
                              "text": "Risk of airway compromise",
                              "type": "boolean",
                              "repeats": false,
                              "readOnly": true,
                              "item": []
                            },
                            {
                              "linkId": "AISD0296040204020202",
                              "text": "Finding, <b>≥ One:</b>",
                              "type": "group",
                              "repeats": true,
                              "readOnly": false,
                              "item": [
                                {
                                  "linkId": "AISD029604020402020201",
                                  "text": "Confirmed by x−ray or CT",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020402020202",
                                  "text": "Difficulty swallowing",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020402020203",
                                  "text": "Drooling",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            },
                            {
                              "linkId": "AISD0296040204020203",
                              "text": "Intervention, <b>Both:</b>",
                              "type": "group",
                              "repeats": true,
                              "readOnly": false,
                              "item": [
                                {
                                  "linkId": "AISD029604020402020301",
                                  "text": "Oximetry",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020402020302",
                                  "text": "Surgical evaluation and, <b>One:</b>",
                                  "type": "group",
                                  "repeats": true,
                                  "readOnly": true,
                                  "item": [
                                    {
                                      "linkId": "AISD02960402040202030201",
                                      "text": "Performed within 24h",
                                      "type": "boolean",
                                      "repeats": false,
                                      "readOnly": true,
                                      "item": []
                                    },
                                    {
                                      "linkId": "AISD02960402040202030202",
                                      "text": "Scheduled within 24h",
                                      "type": "boolean",
                                      "repeats": false,
                                      "readOnly": true,
                                      "item": []
                                    }
                                  ]
                                }
                              ]
                            }
                          ]
                        },
                        {
                          "linkId": "AISD02960402040203",
                          "text": "Retropharyngeal abscess actual or suspected and, <b>All:</b>",
                          "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD02960402040203&note_type=ALL_NOTES",
                          "type": "group",
                          "repeats": true,
                          "readOnly": true,
                          "item": [
                            {
                              "linkId": "AISD0296040204020301",
                              "text": "Risk of airway compromise",
                              "type": "boolean",
                              "repeats": false,
                              "readOnly": true,
                              "item": []
                            },
                            {
                              "linkId": "AISD0296040204020302",
                              "text": "Finding, <b>≥ One:</b>",
                              "type": "group",
                              "repeats": true,
                              "readOnly": false,
                              "item": [
                                {
                                  "linkId": "AISD029604020402030201",
                                  "text": "Confirmed by x−ray or CT",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020402030202",
                                  "text": "Difficulty swallowing",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020402030203",
                                  "text": "Drooling",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            },
                            {
                              "linkId": "AISD0296040204020303",
                              "text": "Intervention, <b>Both:</b>",
                              "type": "group",
                              "repeats": true,
                              "readOnly": false,
                              "item": [
                                {
                                  "linkId": "AISD029604020402030301",
                                  "text": "Oximetry",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020402030302",
                                  "text": "Surgical evaluation and, <b>One:</b>",
                                  "type": "group",
                                  "repeats": true,
                                  "readOnly": true,
                                  "item": [
                                    {
                                      "linkId": "AISD02960402040203030201",
                                      "text": "Performed within 24h",
                                      "type": "boolean",
                                      "repeats": false,
                                      "readOnly": true,
                                      "item": []
                                    },
                                    {
                                      "linkId": "AISD02960402040203030202",
                                      "text": "Scheduled within 24h",
                                      "type": "boolean",
                                      "repeats": false,
                                      "readOnly": true,
                                      "item": []
                                    }
                                  ]
                                }
                              ]
                            }
                          ]
                        },
                        {
                          "linkId": "AISD02960402040204",
                          "text": "Typhoid fever actual or suspected and, <b>≥ One:</b>",
                          "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD02960402040204&note_type=ALL_NOTES",
                          "type": "group",
                          "repeats": true,
                          "readOnly": true,
                          "item": [
                            {
                              "linkId": "AISD0296040204020401",
                              "text": "Gastrointestinal bleeding and, <b>One:</b>",
                              "type": "group",
                              "repeats": true,
                              "readOnly": true,
                              "item": [
                                {
                                  "linkId": "AISD029604020402040101",
                                  "text": "Blood product transfusion ≤&nbsp;24h",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            },
                            {
                              "linkId": "AISD0296040204020402",
                              "text": "Mental status change, <b>Both:</b>",
                              "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD0296040204020402&note_type=ALL_NOTES",
                              "type": "group",
                              "repeats": true,
                              "readOnly": false,
                              "item": [
                                {
                                  "linkId": "AISD029604020402040201",
                                  "text": "Finding, <b>≥ One:</b>",
                                  "type": "group",
                                  "repeats": true,
                                  "readOnly": false,
                                  "item": [
                                    {
                                      "linkId": "AISD02960402040204020101",
                                      "text": "Coma",
                                      "type": "boolean",
                                      "repeats": false,
                                      "readOnly": true,
                                      "item": []
                                    },
                                    {
                                      "linkId": "AISD02960402040204020102",
                                      "text": "Delirium",
                                      "type": "boolean",
                                      "repeats": false,
                                      "readOnly": true,
                                      "item": []
                                    },
                                    {
                                      "linkId": "AISD02960402040204020103",
                                      "text": "Obtundation",
                                      "type": "boolean",
                                      "repeats": false,
                                      "readOnly": true,
                                      "item": []
                                    },
                                    {
                                      "linkId": "AISD02960402040204020104",
                                      "text": "Stupor",
                                      "type": "boolean",
                                      "repeats": false,
                                      "readOnly": true,
                                      "item": []
                                    },
                                    {
                                      "linkId": "AISD02960402040204020105",
                                      "text": "GCS&nbsp;≤&nbsp;8",
                                      "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD02960402040204020105&note_type=ALL_NOTES",
                                      "type": "boolean",
                                      "repeats": false,
                                      "readOnly": true,
                                      "item": []
                                    }
                                  ]
                                },
                                {
                                  "linkId": "AISD029604020402040202",
                                  "text": "Neurological assessment every 1−2h",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604020402040202&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            }
                          ]
                        },
                        {
                          "linkId": "AISD02960402040205",
                          "text": "Hemodynamic instability, <b>Both:</b>",
                          "type": "group",
                          "repeats": true,
                          "readOnly": false,
                          "item": [
                            {
                              "linkId": "AISD0296040204020501",
                              "text": "Finding, <b>≥ One:</b>",
                              "type": "group",
                              "repeats": true,
                              "readOnly": false,
                              "item": [
                                {
                                  "linkId": "AISD029604020402050101",
                                  "text": "Heart rate &gt;&nbsp;120/min, sustained",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604020402050101&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020402050102",
                                  "text": "Systolic blood pressure, <b>≥ One:</b>",
                                  "type": "group",
                                  "repeats": true,
                                  "readOnly": false,
                                  "item": [
                                    {
                                      "linkId": "AISD02960402040205010201",
                                      "text": "&lt; 90 mmHg",
                                      "type": "boolean",
                                      "repeats": false,
                                      "readOnly": true,
                                      "item": []
                                    },
                                    {
                                      "linkId": "AISD02960402040205010202",
                                      "text": "&lt; 110 mmHg with chronic hypertension",
                                      "type": "boolean",
                                      "repeats": false,
                                      "readOnly": true,
                                      "item": []
                                    },
                                    {
                                      "linkId": "AISD02960402040205010203",
                                      "text": "&gt; 30 mmHg decrease from baseline",
                                      "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD02960402040205010203&note_type=ALL_NOTES",
                                      "type": "boolean",
                                      "repeats": false,
                                      "readOnly": true,
                                      "item": []
                                    },
                                    {
                                      "linkId": "AISD02960402040205010204",
                                      "text": "Labile",
                                      "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD02960402040205010204&note_type=ALL_NOTES",
                                      "type": "boolean",
                                      "repeats": false,
                                      "readOnly": true,
                                      "item": []
                                    }
                                  ]
                                },
                                {
                                  "linkId": "AISD029604020402050103",
                                  "text": "MAP &lt;&nbsp;65&nbsp;mmHg",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            },
                            {
                              "linkId": "AISD0296040204020502",
                              "text": "Intervention, <b>≥ One:</b>",
                              "type": "group",
                              "repeats": true,
                              "readOnly": false,
                              "item": [
                                {
                                  "linkId": "AISD029604020402050201",
                                  "text": "Blood product transfusion",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604020402050202",
                                  "text": "IV fluid resuscitation ≤ 2d",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604020402050202&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            }
                          ]
                        },
                        {
                          "linkId": "AISD02960402040206",
                          "text": "Hemodynamic monitoring, invasive",
                          "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD02960402040206&note_type=ALL_NOTES",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402040207",
                          "text": "Mechanical ventilation",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960402040208",
                          "text": "NIPPV and, <b>≥ One:</b>",
                          "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD02960402040208&note_type=ALL_NOTES",
                          "type": "group",
                          "repeats": true,
                          "readOnly": true,
                          "item": [
                            {
                              "linkId": "AISD0296040204020801",
                              "text": "Arterial Po<sub>2</sub> ≤ 39 mmHg(5.2 kPa)",
                              "type": "boolean",
                              "repeats": false,
                              "readOnly": true,
                              "item": []
                            },
                            {
                              "linkId": "AISD0296040204020802",
                              "text": "Arterial Pco<sub>2</sub> ≥ 60 mmHg(8.0 kPa) and pH ≤ 7.24",
                              "type": "boolean",
                              "repeats": false,
                              "readOnly": true,
                              "item": []
                            },
                            {
                              "linkId": "AISD0296040204020803",
                              "text": "Venous Pco<sub>2</sub> ≥ 60 mmHg(8.0 kPa) and pH ≤ 7.24",
                              "type": "boolean",
                              "repeats": false,
                              "readOnly": true,
                              "item": []
                            },
                            {
                              "linkId": "AISD0296040204020804",
                              "text": "Arterial or venous pH ≤ 7.24",
                              "type": "boolean",
                              "repeats": false,
                              "readOnly": true,
                              "item": []
                            }
                          ]
                        },
                        {
                          "linkId": "AISD02960402040209",
                          "text": "Oxygen, <b>Both:</b>",
                          "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD02960402040209&note_type=ALL_NOTES",
                          "type": "group",
                          "repeats": true,
                          "readOnly": false,
                          "item": [
                            {
                              "linkId": "AISD0296040204020901",
                              "text": "HFNC",
                              "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD0296040204020901&note_type=ALL_NOTES",
                              "type": "boolean",
                              "repeats": false,
                              "readOnly": true,
                              "item": []
                            },
                            {
                              "linkId": "AISD0296040204020902",
                              "text": "Respiratory monitoring every 1−2h",
                              "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD0296040204020902&note_type=ALL_NOTES",
                              "type": "boolean",
                              "repeats": false,
                              "readOnly": true,
                              "item": []
                            }
                          ]
                        },
                        {
                          "linkId": "AISD02960402040210",
                          "text": "Vasopressor, vasodilator, or inotrope, continuous (excludes low or fixed dose for end stage heart failure)",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        }
                      ]
                    }
                  ]
                }
              ]
            },
            {
              "resourceType": "Questionnaire",
              "id": "AISD02960406",
              "name": "<b>Episode Day 7</b>",
              "title": "group",
              "item": [
                {
                  "linkId": "AISD0296040601",
                  "text": "<b>ACUTE,</b> <b>One:</b>",
                  "type": "group",
                  "repeats": true,
                  "readOnly": false,
                  "item": [
                    {
                      "linkId": "AISD029604060101",
                      "text": "<b>Responder</b>, discharge expected today if clinically stable last 12h, <b>All:</b>",
                      "type": "group",
                      "repeats": true,
                      "readOnly": false,
                      "item": [
                        {
                          "linkId": "AISD02960406010101",
                          "text": "Temperature, <b>≥ One:</b>",
                          "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD02960406010101&note_type=ALL_NOTES",
                          "type": "group",
                          "repeats": true,
                          "readOnly": false,
                          "item": [
                            {
                              "linkId": "AISD0296040601010101",
                              "text": "≤&nbsp;99.4°F(37.4°C) PO",
                              "type": "boolean",
                              "repeats": false,
                              "readOnly": true,
                              "item": []
                            },
                            {
                              "linkId": "AISD0296040601010102",
                              "text": "≤ 100.4°F(38.0°C) PR",
                              "type": "boolean",
                              "repeats": false,
                              "readOnly": true,
                              "item": []
                            }
                          ]
                        },
                        {
                          "linkId": "AISD02960406010102",
                          "text": "Clinical stability, <b>≥ One:</b>",
                          "type": "group",
                          "repeats": true,
                          "readOnly": false,
                          "item": [
                            {
                              "linkId": "AISD0296040601010201",
                              "text": "Infection resolving, <b>≥ One:</b>",
                              "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD0296040601010201&note_type=ALL_NOTES",
                              "type": "group",
                              "repeats": true,
                              "readOnly": false,
                              "item": [
                                {
                                  "linkId": "AISD029604060101020101",
                                  "text": "Anti−infective regimen established and tolerated",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604060101020102",
                                  "text": "Symptoms resolving",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            },
                            {
                              "linkId": "AISD0296040601010202",
                              "text": "Dengue and, <b>All:</b>",
                              "type": "group",
                              "repeats": true,
                              "readOnly": true,
                              "item": [
                                {
                                  "linkId": "AISD029604060101020201",
                                  "text": "Lab values within acceptable limits",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604060101020201&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604060101020202",
                                  "text": "Pain controlled or manageable",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604060101020202&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604060101020203",
                                  "text": "Tolerating PO",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604060101020203&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604060101020204",
                                  "text": "Urine output within acceptable limits",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604060101020204&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            },
                            {
                              "linkId": "AISD0296040601010203",
                              "text": "Ebola virus disease and, <b>All:</b>",
                              "type": "group",
                              "repeats": true,
                              "readOnly": true,
                              "item": [
                                {
                                  "linkId": "AISD029604060101020301",
                                  "text": "Symptoms resolved",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604060101020302",
                                  "text": "Tolerating PO",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604060101020302&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604060101020303",
                                  "text": "≥ 2 negative polymerase chain reaction (PCR) results",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604060101020303&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            },
                            {
                              "linkId": "AISD0296040601010204",
                              "text": "Epiglottitis and, <b>Both:</b>",
                              "type": "group",
                              "repeats": true,
                              "readOnly": true,
                              "item": [
                                {
                                  "linkId": "AISD029604060101020401",
                                  "text": "Airway patent",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604060101020402",
                                  "text": "Tolerating PO",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604060101020402&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            },
                            {
                              "linkId": "AISD0296040601010205",
                              "text": "Intraocular infection and, <b>Both:</b>",
                              "type": "group",
                              "repeats": true,
                              "readOnly": true,
                              "item": [
                                {
                                  "linkId": "AISD029604060101020501",
                                  "text": "Infection resolving",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604060101020501&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604060101020502",
                                  "text": "Vision normal, improving, or stable",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            },
                            {
                              "linkId": "AISD0296040601010206",
                              "text": "Mastoiditis and, <b>All:</b>",
                              "type": "group",
                              "repeats": true,
                              "readOnly": true,
                              "item": [
                                {
                                  "linkId": "AISD029604060101020601",
                                  "text": "Pain controlled or manageable",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604060101020601&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604060101020602",
                                  "text": "Swelling decreased",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604060101020603",
                                  "text": "Anti−infective regimen established and tolerated",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            },
                            {
                              "linkId": "AISD0296040601010207",
                              "text": "Mononucleosis and, <b>Both:</b>",
                              "type": "group",
                              "repeats": true,
                              "readOnly": true,
                              "item": [
                                {
                                  "linkId": "AISD029604060101020701",
                                  "text": "Airway patent",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604060101020702",
                                  "text": "Tolerating PO",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604060101020702&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            },
                            {
                              "linkId": "AISD0296040601010208",
                              "text": "Neutropenia and ANC&nbsp;≥&nbsp;500/cu.mm(500x10<sup>6</sup>/L)",
                              "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD0296040601010208&note_type=ALL_NOTES",
                              "type": "boolean",
                              "repeats": false,
                              "readOnly": true,
                              "item": []
                            },
                            {
                              "linkId": "AISD0296040601010209",
                              "text": "Peritonsillar abscess resolving and, <b>Both:</b>",
                              "type": "group",
                              "repeats": true,
                              "readOnly": true,
                              "item": [
                                {
                                  "linkId": "AISD029604060101020901",
                                  "text": "Airway patent",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604060101020902",
                                  "text": "Tolerating PO",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604060101020902&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            },
                            {
                              "linkId": "AISD0296040601010210",
                              "text": "Retropharyngeal abscess resolving and, <b>Both:</b>",
                              "type": "group",
                              "repeats": true,
                              "readOnly": true,
                              "item": [
                                {
                                  "linkId": "AISD029604060101021001",
                                  "text": "Airway patent",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604060101021002",
                                  "text": "Tolerating PO",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604060101021002&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            },
                            {
                              "linkId": "AISD0296040601010211",
                              "text": "TB and, <b>Both:</b>",
                              "type": "group",
                              "repeats": true,
                              "readOnly": true,
                              "item": [
                                {
                                  "linkId": "AISD029604060101021101",
                                  "text": "AFB sputum smear negative",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604060101021102",
                                  "text": "Safe for discharge",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604060101021102&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            },
                            {
                              "linkId": "AISD0296040601010212",
                              "text": "Typhoid fever and, <b>All:</b>",
                              "type": "group",
                              "repeats": true,
                              "readOnly": true,
                              "item": [
                                {
                                  "linkId": "AISD029604060101021201",
                                  "text": "Lab values within acceptable limits",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604060101021201&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604060101021202",
                                  "text": "Pain controlled or manageable",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604060101021202&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604060101021203",
                                  "text": "Neurological stability",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604060101021203&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604060101021204",
                                  "text": "Tolerating PO",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604060101021204&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            },
                            {
                              "linkId": "AISD0296040601010213",
                              "text": "Viral respiratory infection and O<sub>2 </sub>sat ≥&nbsp;92%(0.92) or within acceptable limits",
                              "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD0296040601010213&note_type=ALL_NOTES",
                              "type": "boolean",
                              "repeats": false,
                              "readOnly": true,
                              "item": []
                            }
                          ]
                        },
                        {
                          "linkId": "AISD02960406010103",
                          "text": "Complication or comorbidity, <b>One:</b>",
                          "type": "group",
                          "repeats": true,
                          "readOnly": false,
                          "item": [
                            {
                              "linkId": "AISD0296040601010301",
                              "text": "No complication or active comorbidity relevant to this episode of care",
                              "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD0296040601010301&note_type=ALL_NOTES",
                              "type": "boolean",
                              "repeats": false,
                              "readOnly": true,
                              "item": []
                            },
                            {
                              "linkId": "AISD0296040601010302",
                              "text": "Complication or comorbidity and clinically stable for discharge, <b>≥ One:</b>",
                              "type": "group",
                              "repeats": true,
                              "readOnly": false,
                              "item": [
                                {
                                  "linkId": "AISD029604060101030201",
                                  "text": "Adverse drug reaction resolving",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604060101030202",
                                  "text": "Blood sugar 70−250 mg/dL(3.9−13.9&nbsp;mmol/L) or within acceptable limits",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604060101030202&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                },
                                {
                                  "linkId": "AISD029604060101030203",
                                  "text": "<i>C. difficile</i> infection and<i>,</i> <b>Both:</b>",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604060101030203&note_type=ALL_NOTES",
                                  "type": "group",
                                  "repeats": true,
                                  "readOnly": true,
                                  "item": [
                                    {
                                      "linkId": "AISD02960406010103020301",
                                      "text": "Decrease in frequency and severity of diarrhea",
                                      "type": "boolean",
                                      "repeats": false,
                                      "readOnly": true,
                                      "item": []
                                    },
                                    {
                                      "linkId": "AISD02960406010103020302",
                                      "text": "Tolerating PO",
                                      "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD02960406010103020302&note_type=ALL_NOTES",
                                      "type": "boolean",
                                      "repeats": false,
                                      "readOnly": true,
                                      "item": []
                                    }
                                  ]
                                },
                                {
                                  "linkId": "AISD029604060101030204",
                                  "text": "Tolerating PO",
                                  "definition": "/caas/content/notes?subset_unique_id=353638&id=AISD029604060101030204&note_type=ALL_NOTES",
                                  "type": "boolean",
                                  "repeats": false,
                                  "readOnly": true,
                                  "item": []
                                }
                              ]
                            }
                          ]
                        }
                      ]
                    },
                    {
                      "linkId": "AISD029604060102",
                      "text": "<b>Non−responder</b>, not clinically stable for discharge and exceeds episode days at the Acute level of care for this condition, <b>One:</b>",
                      "type": "group",
                      "repeats": true,
                      "readOnly": false,
                      "item": [
                        {
                          "linkId": "AISD02960406010201",
                          "text": "<b>Use Extended Stay subset</b>",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960406010202",
                          "text": "Refer for secondary review",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        }
                      ]
                    }
                  ]
                },
                {
                  "linkId": "AISD0296040602",
                  "text": "<b>INTERMEDIATE</b>, <b>One:</b>",
                  "type": "group",
                  "repeats": true,
                  "readOnly": false,
                  "item": [
                    {
                      "linkId": "AISD029604060201",
                      "text": "<b>Non−responder</b>, not clinically stable for discharge and exceeds episode days at the Intermediate level of care for this condition, <b>One:</b>",
                      "type": "group",
                      "repeats": true,
                      "readOnly": false,
                      "item": [
                        {
                          "linkId": "AISD02960406020101",
                          "text": "<b>Use Extended Stay subset</b>",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960406020102",
                          "text": "Refer for secondary review",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        }
                      ]
                    }
                  ]
                },
                {
                  "linkId": "AISD0296040603",
                  "text": "<b>CRITICAL,</b> <b>One:</b>",
                  "type": "group",
                  "repeats": true,
                  "readOnly": false,
                  "item": [
                    {
                      "linkId": "AISD029604060301",
                      "text": "<b>Non−responder</b>, not clinically stable for discharge and exceeds episode days at the Critical level of care for this condition, <b>One:</b>",
                      "type": "group",
                      "repeats": true,
                      "readOnly": false,
                      "item": [
                        {
                          "linkId": "AISD02960406030101",
                          "text": "<b>Use Extended Stay subset</b>",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        },
                        {
                          "linkId": "AISD02960406030102",
                          "text": "Refer for secondary review",
                          "type": "boolean",
                          "repeats": false,
                          "readOnly": true,
                          "item": []
                        }
                      ]
                    }
                  ]
                }
              ]
            }
          ]
        }
      }
    
};

describe('QnaMedicalReviewComponent', () => {
  let component: QnaMedicalReviewComponent;
  let fixture: ComponentFixture<QnaMedicalReviewComponent>;
  let qnaMedicalReviewService: QnaMedicalReviewService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        CommonModule,
        BrowserModule,
        SelectModule,
        OptionModule,
        BrowserAnimationsModule,
        MatGridListModule,
        MatIconModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientTestingModule,
        ButtonModule,
        CardModule,
        TabsModule,
        IconsModule,
        AuthLibraryModule,
        HttpClientModule,
        CheckboxModule,
        ModalModule,
        FormFieldModule,
        AccordianModule,
      ],
      declarations: [QnaMedicalReviewComponent],
      providers: [QnaMedicalReviewService, {
        provide: QnaMedicalReviewService,
        useClass: QnaMedicalReviewService
      }, { provide: MicroProductAuthService, useClass: MicroProductAuthServiceStub }],

      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QnaMedicalReviewComponent);
    qnaMedicalReviewService = TestBed.inject(QnaMedicalReviewService);
    component = fixture.componentInstance;

  });

  // it('should create', () => {
  //   expect(component).toBeTruthy();
  // });

  it('should ngOnInit', () => {
    component.ngOnInit();
    expect(component.ngOnInit).toBeTruthy();
  });


  // afterEach(() => {
  //   fixture.destroy();
  // });

  it('Should test getGuidelineOverview', () => {
     spyOn(qnaMedicalReviewService, 'getQNAForGuidelines').and.returnValue(of(test));
     component.getGuidelineOverview();
    // expect(component.getGuidelineOverview).toBeTruthy;
  });

  xit('Should test  call question service', () => {
    spyOn(qnaMedicalReviewService, 'getQNAForGuidelines').and.returnValue(of(test));
    const questionnairBody = {
      "resourceType": "QuestionnaireResponse",
      "questionnaire": {},
      "meta": {},
      "item": []
    } as QuestionnaireResponse;
    const item = {
      linkId: "1514551|1|RADIO",
      text: 'Yes',
      type: '',
      definition: '',
      prefix: '',
      answer: [{
        "valueString": "2"
      }],
      item: [{
        "linkId": "1514551|1|RADIO",
        "answer": [{
          "valueString": "1"
        }]
      }],
      enableMultiBtn: true,
      showRecommdations: true
    } as Item;
    spyOn(qnaMedicalReviewService, 'getNextQuestionId').and.returnValue(of(questionChoices));
    component.callQuestionService(questionnairBody, item);
    expect(component.callQuestionService).toBeTruthy;
    
  });

//  it('call  question service', () => {
//     spyOn(qnaMedicalReviewService, 'getNextQuestionId').and.returnValue(of(questionChoices));
//     questionChoices.item[0].prefix = 'MULT';
//     component.ngOnInit();
//     let multiSelectForm1 = new FormControl();
//     component.multiSelectForm.addControl('658945',multiSelectForm1);
//     component.multiSelectForm.controls['658945'].setValue(true);
//     let questionnairBody = {
//       "resourceType": "QuestionnaireResponse",
//       "questionnaire": {},
//       "meta": {},
//       "item": [
//         {
//           "answer": [
//             { "valueString": '1' }
//           ]
//         }
//       ]
//     } as QuestionnaireResponse;

//     component.callQuestionService(questionnairBody, questionChoices.item[0]);
//     expect(component.callQuestionService).toBeTruthy();
//   });

  xit('call  question service recommendations', () => {
    spyOn(qnaMedicalReviewService, 'getNextQuestionId').and.returnValue(of(recommendations));
    spyOn(qnaMedicalReviewService, 'getQNAForGuidelines').and.returnValue(of(test));
    component.ngOnInit();
    let questionnairBody = {
      "resourceType": "QuestionnaireResponse",
      "questionnaire": {}, 
      "meta": {},
      "item": [
        {
          "answer": [
            { "valueString": '1' }
          ]
        }
      ]
    } as QuestionnaireResponse;

    component.callQuestionService(questionnairBody, questionChoices.item[0]);
    expect(component.callQuestionService).toBeTruthy();
  });


 //!* failing.. Please check and uncomment
  // it('Should test  call question service', () => {
  //   const questionnairBody = {
  //     "resourceType": "QuestionnaireResponse",
  //     "questionnaire": {},
  //     "meta": {},
  //     "item": [],
  //     "id": "recommendations"
  //   } as any;
  //   const item = {
  //     linkId: "1514551|1|RADIO",
  //     text: 'Yes',
  //     type: '',
  //     definition: '',
  //     prefix: '',
  //     answer: [{
  //       "valueString": "2"
  //     }],
  //     item: [{
  //       "linkId": "1514551|1|RADIO",
  //       "answer": [{
  //         "valueString": "1"
  //       }]
  //     }],
  //     enableMultiBtn: true,
  //     showRecommdations: true
  //   } as Item;
  //   const test = {
  //     "data": {
  //       "getQuestionnaireDetails": {
  //         "questionRes": {
  //           "resourceType": "Questionnaire",
  //           "meta": {
  //             "tag": [
  //               {
  //                 "code": "subset_id",
  //                 "display": "~IQ6.01A_17056"
  //               },
  //               {
  //                 "code": "uniqueId",
  //                 "display": 370187
  //               },
  //               {
  //                 "code": "latestSubsetId",
  //                 "display": 370187
  //               },
  //               {
  //                 "code": "subsetIdentifierId",
  //                 "display": 1194665
  //               },
  //               {
  //                 "code": "product_id",
  //                 "display": "IQ-HC"
  //               },
  //               {
  //                 "code": "version_id",
  //                 "display": "RM21"
  //               },
  //               {
  //                 "code": "subsetType",
  //                 "display": "QNA"
  //               },
  //               {
  //                 "code": "autoSave",
  //                 "display": "false"
  //               }
  //             ],
  //             "lastUpdated": "2021-07-12T09:30:51.914Z"
  //           },
  //           "item": [
  //             {
  //               "linkId": "1913779|3410",
  //               "text": "Homebound status required ",
  //               "type": "group",
  //               "definition": true,
  //               "prefix": "YN",
  //               "item": [
  //                 {
  //                   "linkId": 3391813,
  //                   "text": "Yes",
  //                   "definition": false,
  //                   "type": "boolean",
  //                   "prefix": "Y"
  //                 },
  //                 {
  //                   "linkId": 3391814,
  //                   "text": "No",
  //                   "definition": false,
  //                   "type": "boolean",
  //                   "prefix": "N"
  //                 }
  //               ]
  //             }
  //           ]
  //         }
  //       }
  //     }
  //   } as any;
  //   spyOn(qnaMedicalReviewService, 'getNextQuestionId').and.returnValue(of(questionChoices));
  //   spyOn(qnaMedicalReviewService, 'getQNAForGuidelines').and.returnValue(of(test));
  //   component.callQuestionService(test, item);
  // });

  it('Should test populateMetaData', () => {
    const metaData: Meta = {
      "lastUpdated": new Date(),
      "tag": [{
        "code": "subset_id",
        "display": "ISP6701"
      }, {
        "code": "uniqueId",
        "display": "RM20"
      }]
    };
    component.meta = metaData;
    component.meta.lastUpdated = new Date();
    component.populateMetaAfterQuestion(metaData);
  });

  it('should call prepareCitationLink', () => {
    spyOn(qnaMedicalReviewService, 'getNextQuestionId').and.returnValue(of(questionChoices));
    spyOn(qnaMedicalReviewService, 'getQNAForGuidelines').and.returnValue(of(test));
    const overviewText = '<p>These criteria&nbsp;include the following imaging studies:<br>Bone or Joint Scan, Limited Area<br>Bone or Joint Scan, Multiple Areas<br>Bone or Joint Scan, 3-Phase Study<br>Bone or Joint Scan, Whole Body<br>Bone or Joint&nbsp;Scan with Single-Photon Emission Computed Tomography (SPECT)&nbsp;<br>Bone Scintigraphy<br>Nuclear Medicine Scan<br>Radionuclide Scan</p><br/><p>Bone scan is appropriate in the diagnosis, evaluation, and follow up of multiple clinical conditions (e.g., bone neoplasms, trauma, stress fracture, bone viability, evaluation of implanted hardware, avascular necrosis, osteomyelitis) and has been shown to be safe in both pediatric and adult patients, with the only contraindication being pregnancy (<bib rel=citation title=American College of Radiology and Society of Pediatric Radiology, ACR-SPR practice parameter for the performance and interpretation of skeletal scintigraphy (bone scan). 2017 href=/caas/citations/1472997 id=1472997>American College of Radiology and Society of Pediatric Radiology, ACR-SPR practice parameter for the performance and interpretation of skeletal scintigraphy (bone scan). 2017</bib>; <bib rel=citation title=Van den Wyngaert et al., Eur J Nucl Med Mol Imaging 2016, 43: 1723-38 href=/caas/citations/1473021 id=1473021>Van den Wyngaert et al., Eur J Nucl Med Mol Imaging 2016, 43: 1723-38</bib>). </p><br/><p>InterQual® Imaging criteria are derived from the systematic, continuous review and critical appraisal of the most current evidence-based literature and include input from our independent panel of clinical experts. To generate the most appropriate recommendations, a comprehensive literature review of the clinical evidence was conducted. Sources searched included PubMed, Agency for Healthcare Research and Quality (AHRQ) Comparative Effectiveness Reviews, the Cochrane Library, Choosing Wisely, Centers for Medicare &amp; Medicaid Services (CMS) National Coverage Determinations, and the National Institute of Health and Care Excellence (NICE). Other medical literature databases, medical content providers, data sources, regulatory body websites, and specialty society resources may also have been used. Relevant studies were assessed for risk of bias following principles described in the Cochrane Handbook. The resulting evidence was assessed for consistency, directness, precision, effect size, and publication bias. Observational trials were also evaluated for the presence of a dose-response gradient and the likely effect of plausible confounders.</p><br/><br/> Origination date :2009-03-31<br/> Release date :2020-04-17'

    // const citation1 = [{
    // index1 : "question next link",
    // index2  : "question next link",
    // index3  : "question next link",
    // strng1 : "/caas/questions/2035863077/next?answers=3",
    // strng2 : "2035863077"
    // }];
    //component.overviewText = '<p>These criteria&nbsp;include the following imaging studies:<br>Bone or Joint Scan, Limited Area<br>Bone or Joint Scan, Multiple Areas<br>Bone or Joint Scan, 3-Phase Study<br>Bone or Joint Scan, Whole Body<br>Bone or Joint&nbsp;Scan with Single-Photon Emission Computed Tomography (SPECT)&nbsp;<br>Bone Scintigraphy<br>Nuclear Medicine Scan<br>Radionuclide Scan</p><br/><p>Bone scan is appropriate in the diagnosis, evaluation, and follow up of multiple clinical conditions (e.g., bone neoplasms, trauma, stress fracture, bone viability, evaluation of implanted hardware, avascular necrosis, osteomyelitis) and has been shown to be safe in both pediatric and adult patients, with the only contraindication being pregnancy (<bib rel=citation title=American College of Radiology and Society of Pediatric Radiology, ACR-SPR practice parameter for the performance and interpretation of skeletal scintigraphy (bone scan). 2017 href=/caas/citations/1472997 id=1472997>American College of Radiology and Society of Pediatric Radiology, ACR-SPR practice parameter for the performance and interpretation of skeletal scintigraphy (bone scan). 2017</bib>; <bib rel=citation title=Van den Wyngaert et al., Eur J Nucl Med Mol Imaging 2016, 43: 1723-38 href=/caas/citations/1473021 id=1473021>Van den Wyngaert et al., Eur J Nucl Med Mol Imaging 2016, 43: 1723-38</bib>). </p><br/><p>InterQual® Imaging criteria are derived from the systematic, continuous review and critical appraisal of the most current evidence-based literature and include input from our independent panel of clinical experts. To generate the most appropriate recommendations, a comprehensive literature review of the clinical evidence was conducted. Sources searched included PubMed, Agency for Healthcare Research and Quality (AHRQ) Comparative Effectiveness Reviews, the Cochrane Library, Choosing Wisely, Centers for Medicare &amp; Medicaid Services (CMS) National Coverage Determinations, and the National Institute of Health and Care Excellence (NICE). Other medical literature databases, medical content providers, data sources, regulatory body websites, and specialty society resources may also have been used. Relevant studies were assessed for risk of bias following principles described in the Cochrane Handbook. The resulting evidence was assessed for consistency, directness, precision, effect size, and publication bias. Observational trials were also evaluated for the presence of a dose-response gradient and the likely effect of plausible confounders.</p><br/><br/> Origination date :2009-03-31<br/> Release date :2020-04-17'
    component.prepareCitationLink(overviewText);
    expect(component.prepareCitationLink).toBeTruthy();
  });

 //!*failing.. Please check and uncomment
  // it('Should test  call question service - second scenario', () => {
  //   // spyOn(qnaMedicalReviewService, 'getNextQuestionId').and.returnValue(of(questionChoices));
  //   spyOn(qnaMedicalReviewService, 'getQNAForGuidelines').and.returnValue(of(test));
  //   const questionnairBody = {
  //     "resourceType": "QuestionnaireResponse",
  //     "questionnaire": {},
  //     "meta": {},
  //     "item": [],
  //     "id": "recommendations"
  //   } as any;
  //   const item = {
  //     linkId: "1514551|1|RADIO",
  //     text: 'Yes',
  //     type: '',
  //     definition: '',
  //     prefix: '',
  //     answer: [{
  //       "valueString": "2"
  //     }],
  //     item: [{
  //       "linkId": "1514551|1|RADIO",
  //       "answer": [{
  //         "valueString": "1"
  //       }]
  //     }],
  //     enableMultiBtn: true,
  //     showRecommdations: true
  //   } as Item;
  //   const test1 = {
  //     "data": {
  //       "getQuestionnaireDetails": {
  //         "questionRes": {
  //           "resourceType": "Questionnaire",
  //           "id": "recommendations",
  //           "meta": {
  //             "tag": [
  //               {
  //                 "code": "subset_id",
  //                 "display": "~IQ6.01A_17056"
  //               },
  //               {
  //                 "code": "uniqueId",
  //                 "display": 370187
  //               },
  //               {
  //                 "code": "latestSubsetId",
  //                 "display": 370187
  //               },
  //               {
  //                 "code": "subsetIdentifierId",
  //                 "display": 1194665
  //               },
  //               {
  //                 "code": "product_id",
  //                 "display": "IQ-HC"
  //               },
  //               {
  //                 "code": "version_id",
  //                 "display": "RM21"
  //               },
  //               {
  //                 "code": "subsetType",
  //                 "display": "QNA"
  //               },
  //               {
  //                 "code": "autoSave",
  //                 "display": "false"
  //               }
  //             ],
  //             "lastUpdated": "2021-07-12T09:30:51.914Z"
  //           },
  //           "item": [
  //             {
  //               "linkId": "1913779|3410",
  //               "text": "Homebound status required ",
  //               "type": "group",
  //               "definition": true,
  //               "prefix": "YN",
  //               "item": [
  //                 {
  //                   "linkId": 3391813,
  //                   "text": "Yes",
  //                   "definition": false,
  //                   "type": "boolean",
  //                   "prefix": "Y"
  //                 },
  //                 {
  //                   "linkId": 3391814,
  //                   "text": "No",
  //                   "definition": false,
  //                   "type": "boolean",
  //                   "prefix": "N"
  //                 }
  //               ]
  //             }
  //           ]
  //         }
  //       }
  //     }
  //   } as any;
  //   spyOn(qnaMedicalReviewService, 'getNextQuestionId').and.returnValue(of(questionChoices));
  //   component.callQuestionService(test1, item);
  // });

  it('oncheck method', () => {
    const event = { target: { checked: true } };
    spyOn(qnaMedicalReviewService, 'getNextQuestionId').and.returnValue(of(questionChoices));
    spyOn(qnaMedicalReviewService, 'getQNAForGuidelines').and.returnValue(of(test));
    let multiSelectForm1 = new FormControl();
    component.multiSelectForm.addControl('658945',multiSelectForm1);
    component.multiSelectForm.controls['658945'].setValue(true);
    component.multiSelectForm.addControl('658946',multiSelectForm1);
    component.multiSelectForm.controls['658946'].setValue(true);
    component.onCheck(questionChoices?.item[0]?.item, questionChoices?.item[0], '658945', '123', 1, event);
    expect(component.onCheck).toBeTruthy();
  });

  it('shoul call criteria method', () => {
    spyOn(qnaMedicalReviewService, 'getNextQuestionId').and.returnValue(of(questionChoices));
    spyOn(qnaMedicalReviewService, 'getQNAForGuidelines').and.returnValue(of(test));
    component.userRole = 'clinical_guidelines_cds_nurse';
    component.checkRoleForRecommendations();
    expect(component.checkRoleForRecommendations).toBeTruthy();
  });

  it('no option elected', () => {
    spyOn(qnaMedicalReviewService, 'getNextQuestionId').and.returnValue(of(questionChoices));
    spyOn(qnaMedicalReviewService, 'getQNAForGuidelines').and.returnValue(of(test));
    const qItem: any = { enableMultiBtn: true }
    const choice = 1
    const list: any = [{
      "text": "Or ",
      "type": "display"
    }]
    component.checkorUnCheckMulti(qItem, choice, list);
    expect(component.checkorUnCheckMulti).toBeTruthy()

  });

  it('multiple choice selected before or', () => {
    spyOn(qnaMedicalReviewService, 'getQNAForGuidelines').and.returnValue(of(test));
    const qItem: any = { enableMultiBtn: true }
    const choice = 1
    const list: any = [{
      "text": "Typhoid",
      "type": "display"
    }]
    component.checkorUnCheckMulti(qItem, choice, list);
    expect(component.checkorUnCheckMulti).toBeTruthy()

  });

  it('should populate comments', () => {
    spyOn(qnaMedicalReviewService, 'getNextQuestionId').and.returnValue(of(questionChoices));
    spyOn(qnaMedicalReviewService, 'getQNAForGuidelines').and.returnValue(of(test));
    component.commentsArray.push({
      "name" : "1514551|1|RADIO",
      "valueString" :"fsdf",
      "valueDateTime" : "hhkhkj",
      "valueId" : "value"
    });
    const commnets = [{
      "nodeCid":"fasf",
      "user": "sfa",
      "date": "fass",
      "text": "fsdf"
    }];
    component.commentChangedHandler(commnets);
   component.openCommentModal(questionChoices.item[0]);
  //  expect(component.commentsArray.length).toBeGreaterThan(0);
   expect(component.commentChangedHandler).toBeTruthy;
  });

  it('Should test populateComments function', () => {
    spyOn(qnaMedicalReviewService, 'getQNAForGuidelines').and.returnValue(of(test));
    const nodeId = '1514551|1|RADIO';
    const item = { linkId: 5 };
    const contained = {
      "resourceType": "Parameters",
      "id": "comments",
      "parameter": [{
        "name": "1514551|1|RADIO",
        "valueId": "TestingUser1, TestingUser1",
        "valueDateTime": "2021-01-12T09:49:44-06:00",
        "valueString": "test1111"}],
      "contained":[],
    };
    component.populateComments(nodeId, contained, item);
    expect(component.populateComments).toBeTruthy;
  });

  it('Should test   openCommentModal(', () => {
    spyOn(qnaMedicalReviewService, 'getNextQuestionId').and.returnValue(of(questionChoices));
    spyOn(qnaMedicalReviewService, 'getQNAForGuidelines').and.returnValue(of(test));
    const cp = { linkId: '23' };
    component.commentsArray = [{
      name: "recommendationId",
      valueString: "1050956",
      valueId: '',
      valueDateTime: ''
    }];
    component.commentsList.set('id', []);
    component.openCommentModal(cp);
  })

  it('should getComments', () => {
    spyOn(qnaMedicalReviewService, 'getNextQuestionId').and.returnValue(of(questionChoices));
    spyOn(qnaMedicalReviewService, 'getQNAForGuidelines').and.returnValue(of(test));
    const comments = [{
      'name': '1513469|11',
      'valueId': 'TestingUser1, TestingUser1',
      'valueDateTime': '2021-02-05T14:09:02.296Z',
      'valueString': 'test comment'
    }];
    component.getComments(comments);
    expect(component.getComments).toBeTruthy();
  });

  it('openNotesModel method', () => {
    spyOn(qnaMedicalReviewService, 'getNextQuestionId').and.returnValue(of(questionChoices));
    spyOn(qnaMedicalReviewService, 'getQNAForGuidelines').and.returnValue(of(test));
    component.openNotesModel(12345, '12|3', 'QUESTION_NOTE', '12|3');
    expect(component.openNotesModel).toBeTruthy();
  });


  it('should call closeCard', () => {
    spyOn(qnaMedicalReviewService, 'getQNAForGuidelines').and.returnValue(of(test));
    component.closecard = true;
    component.closeCard();
    expect(component.closeCard).toBeTruthy();
  });

  it('should call viewRecommendation', () => {
    spyOn(qnaMedicalReviewService, 'getQNAForGuidelines').and.returnValue(of(test));
    component.displayRecommendation = true;
    component.viewRecommendation();
    expect(component.viewRecommendation).toBeTruthy();
  });

  it('should get getcompare', () => {
    spyOn(qnaMedicalReviewService, 'getQNAForGuidelines').and.returnValue(of(test));
    const citationData = [{ seq: 1, id: '24177', title: 'Halpin et al., Int J Chron Obstruct Pulmon Dis 2017, 12: 2891-908' },
      { seq: 2, id: '24179', title: 'Lau et al., Int J Chron Obstruct Pulmon Dis 2017, 12: 1891-902' },
      { seq: 3, id: '17833', title: 'Tsui et al., Int J Tuberc Lung Dis 2016, 20: 396-401' }];
    const title = 'Tsui et al., Int J Tuberc Lung Dis 2016, 20: 396-401';
    component.returnTitle = 0;
    component.compareCitationData(citationData, title);
    // expect(component.compareCitationData).toBeTruthy();

  });

  // it('shoul call criteria method', () => {
  //   component.userRole = 'clinical_guidelines_cds_nurse';
  //   component.checkRoleForRecommendations();
  //   expect(component.checkRoleForRecommendations).toBeTruthy();
  // });
});
