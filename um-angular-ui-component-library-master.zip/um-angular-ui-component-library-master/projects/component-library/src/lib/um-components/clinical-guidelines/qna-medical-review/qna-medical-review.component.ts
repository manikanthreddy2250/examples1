import {MicroProductAuthService} from '@ecp/auth-library';
import {
  Component,
  OnInit,
  OnChanges,
  SimpleChanges,
  ComponentFactoryResolver,
  ViewChild,
  ViewContainerRef, Input
} from '@angular/core';
import {QnaMedicalReviewService} from '../../services/um/service/clinical-guidelines/qna-medical-review-service/qna-medical-review.service';
import {map} from 'rxjs/operators';
import {BehaviorSubject, Observable, of} from 'rxjs';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {FormControl, FormGroup, ReactiveFormsModule, FormBuilder} from '@angular/forms';
import {QuestionChoices} from '../shared/models/QuestionChoices';
import {QnaReview} from '../shared/models/QnaReview';
import {Item} from '../shared/models/Item';
import {Meta} from '../shared/models/Meta';
import {Tag} from '../shared/models/Tag';
import {QuestionnaireResponse} from '../shared/models/QuestionnaireResponse';
import {QItem} from '../shared/models/QItem';
import {ActivatedRoute, Router} from '@angular/router';
import {Contained} from '../shared/models/Contained';
import {CommonConstants} from '../shared/common-constants';
import {UITKPageNotificationService} from '@uitk/angular';
import {GET_CONFIG_URL_PATH, ROLE_NURSE} from '../../../config/config-constants';
import {getEnvVar} from "../../services/environment/envVarUtil";
import {GuidelinesConstants} from "../../../constant/guidelines-constants";

@Component({
  selector: 'guidelines-qna-medical-review',
  templateUrl: './qna-medical-review.component.html',
  styleUrls: ['./qna-medical-review.component.scss']
})
export class QnaMedicalReviewComponent implements OnInit, OnChanges {
  QuestionnaireList = [];

  @ViewChild('qnaMedicalReviewRecom', { read: ViewContainerRef }) qnaMedicalRevieRecommendations
  qnaReview = {
    'resourceType': 'Questionnaire',
    'identifier': {
      'use': 'official',
      'value': ''
    },
    'meta': {
      'lastUpdated': null,
      'tag': []
    },
    'questionnaire': '',
    'text': '',
    'status': '',
    'item': [],
    'contained': [{
      'resourceType': 'Parameters',
      'id': 'availableRecommendations',
      'parameter': [{
        'name': 'groupId',
        'valueString': " "
      }, {
        'name': 'recommendationId',
        'valueString': null
      },
        {
          'name': 'disposition_notes',
          'valueString': null
        }],
      'contained': []
    },
      {
        'resourceType': 'Parameters',
        'id': 'comments',
        'parameter': [],
        'contained': []
      }
    ],
    'questionsList': ''
  } as QnaReview

  displayRecommendation = true;
  recommendationsMet = 0;
  componentRef: any;
  viewContainerRef: any = null
  qnaReviewSelected = true;
  nextButtonDisabled = true;
  Questionnaire: any = null;
  guidelineName: string;
  questionId: string;
  disableRecommendations = true;
  questionChoices: QuestionChoices;
  meta: Meta;
  checkedIds = [];
  answer = [];
  reviewRevision = 0;
  reviewVersion = 0;
  reviewUuid = null;
  reviewSaveRes = null;
  primaryClinId = null;
  subsetId = null;
  uniqueId = null;
  latestSubsetId = null;
  commentsList: Map<string, Comment[]> = new Map();
  subsetIdentifierId = null;
  criteriaMet = null;
  guideLineID: any;
  version: any;
  showReview: any = false;
  comments = [];
  multiSelectForm: FormGroup = new FormGroup({
    subsetType: new FormControl(null),
  });
  showcomment = false;
  showNotes = false;
  closecard = false;
  currentlySelectedCommentId = null;
  commentModal: any = {
    show: false
  };
  reviewId: any;
  errorConfig = {
    id: 'error_msg',
    pageNotificationType: 'error',
    content: 'Unexpected error occurred. Please try again later.',
    triggerElementId: 'trigger-button',
  };
  overviewText: any;
  isLoading: boolean;
  counter: number;
  citationData = [];
  returnTitle: number;
  k = 1;
  j = 1;
  citationModalData: any = {
    show: false
  };
  notesModal: any = {
    show: false
  };
  @Input() guidelineId: string;
  @Input() ver: string;
  @Input() commentModalData: any = {};
  @Input() processTaskExecutionID: string;
  recommended: boolean = false;
  alertCommentAdded = true;

  isRoleNurse = false;
  ecpClaimsVal = 'x-ecp-claims';
  ecpCliOrgsVal = 'x-ecp-cli-orgs';
  userRole;

  constructor(private readonly fb: FormBuilder, private readonly activatedRoute: ActivatedRoute, private readonly qnaMedicalReviewService: QnaMedicalReviewService,
              private readonly http: HttpClient, private readonly microProductAuthService: MicroProductAuthService, private readonly router: Router,
              private readonly componentFactoryResolver: ComponentFactoryResolver, private readonly messageService: UITKPageNotificationService) {

  }

  ngOnInit(): void {
      this.getGuidelineOverview();
      this.checkRoleForRecommendations();
  }

  ngOnChanges(changes: SimpleChanges) {
  }

  getGuidelineOverview() {
    this.qnaMedicalReviewService.getQNAForGuidelines(this.guidelineId, this.ver).subscribe((res: any) => {
        console.log('RES', res);
        const resp = res?.data?.getGuidelineReview?.reviewResponse;
        this.meta = resp?.meta;
        let selItem: Item;
        for (const value of resp?.item) {
          for (const item of value?.item) {
              this.multiSelectForm.addControl(item.linkId, this.fb.control(''));
          }
        }
        this.meta.lastUpdated = new Date();
        const tag = {
          'code': 'autoSave',
          'display': 'false'
        } as Tag;
        this.meta.tag.push(tag);
        this.questionId = resp?.id;
        this.qnaReview.questionnaire = resp?.id;
        this.guidelineName = resp?.name;
        this.QuestionnaireList.push(resp?.item[0]);
        console.log('over view text : ', resp?.text);
        this.overviewText = resp?.text;
        this.qnaReview.text = this.overviewText;
      },
      error => {
        this.messageService.add(this.errorConfig);
      });
  }

  statusDialogModal = {
    show: false,
  };

  normalDialogModal = {
    display: false,
  };


  nextQuestion(qItem: Item) {
    const answer = [];
    qItem.item.forEach(e => {
      if (e.linkId && this.multiSelectForm.controls[e.linkId].value) {
        answer.push({
          'valueString': e.prefix
        });
      }
    });
    const item = [
      {
        'answer': answer,
        'linkId': qItem?.linkId
      }
    ] as QItem[];
    const questionnairBody = {
      'resourceType': CommonConstants.QUESTIONNAIRE_RESPONSE,
      'questionnaire': this.questionId,
      'text': this.overviewText,
      'meta': this.meta,
      'item': item
    } as QuestionnaireResponse;
    this.nextButtonDisabled = true;
    this.callQuestionService(questionnairBody, qItem);
  }

  callQuestionService(questionnairBody: QuestionnaireResponse, item: Item) {
    console.log('QNA questionnairBody: ' + JSON.stringify(questionnairBody));
    this.qnaMedicalReviewService.getNextQuestionId(questionnairBody).subscribe((res: any) => {
        item.enableMultiBtn = false;
        item.showRecommdations = false;
        this.disableRecommendations = true;
        this.recommended = false;
        console.log('RES', res);
        const resp = res?.data?.getQuestionnaireDetails?.questionRes;
        if (resp.id === CommonConstants.SELECTEDRECOMMEDATIONS) {
          this.isRecommended(resp);
          item.showRecommdations = true;
          this.disableRecommendations = false;
          item.enableMultiBtn = false;
          this.criteriaMet = resp?.contained?.[0]?.parameter?.[3]?.valueString;
          this.populateMetaAfterQuestion(resp);
        } else {
          for (const value of resp.item) {
            for (const item of value.item) {
              if (item.linkId) {
                this.multiSelectForm.removeControl(item.linkId);
                this.multiSelectForm.addControl(item.linkId, this.fb.control(''));
              }
            }
          }
          this.QuestionnaireList.push(resp.item[0]);
          this.Questionnaire = (this.QuestionnaireList.length) - 1
          if (this.QuestionnaireList[this.Questionnaire]?.prefix === CommonConstants.MULT && resp?.item[0]) {
            resp.item[0].enableMultiBtn = true;
          }
          this.populateMetaAfterQuestion(resp);
        }
      },
      err => {
        item.showRecommdations = true;
        item.enableMultiBtn = false;
        this.messageService.add(this.errorConfig);
      }
    );
  }

  commentsArray = [];
  openCommentModal(cp: any) {
    const id = cp.linkId;
    this.currentlySelectedCommentId = id;
    const commentText = '';
    const comments: Comment[] = [];
    for (let k = 0; k < this.commentsArray.length; k++) {
      if (id === this.commentsArray[k].name) {
        comments.push({
          text: commentText + this.commentsArray[k].valueString,
          dateTime: this.commentsArray[k].valueDateTime ? this.commentsArray[k].valueDateTime : '',
          userName: this.commentsArray[k].valueId ? this.commentsArray[k].valueId : ''
        });
        this.commentsList.set(id, comments);
      }
    }
    this.commentModal = {
      commentsList: this.commentsList,
      cp,
      selectedQNA: this.multiSelectForm.value,
      show: true
    };
    this.showcomment = true;
    this.showNotes = false
    this.closecard = true;
  }

  commentChangedHandler(e) {
    this.commentsArray = [];
    e.forEach(comment => {
      const fhircommentObj = {
        'name': comment.nodeCid,
        'valueId': comment.user,
        'valueDateTime': comment.date,
        'valueString': comment.text
      };
      this.commentsArray.push(fhircommentObj);
    });
    console.log(`commentChangedHandler`);
    console.log(e);
  }

  getComments(commentsArray) {
    const commentFhir = [];
    commentsArray.forEach(item => {
      const fhircommentObj = {
        'name': item.name,
        'valueId': item.valueId,
        'valueDateTime': item.valueDateTime,
        'valueString': item.valueString
      };
      commentFhir.push(fhircommentObj);
    });
    return commentFhir;
  }

  populateComments(nodeId: string, contained: Contained, item: any) {
    const comments = contained.parameter.filter(par => par.name === nodeId);
    comments.forEach(comment => {
      const fhircommentObj = {
        'name': item.linkId,
        'valueId': comment.valueId,
        'valueDateTime': comment.valueDateTime,
        'valueString': comment.valueString
      };
      this.commentsArray.push(fhircommentObj);
    });
  }

  openNotesModel(subsetUniqueId, id, noteType, parentId){
    parentId = parentId?.includes('|') ? parentId.split('|')[1] : '';
    id = id?.toString();
    if (id?.includes('|')){
        id = id.split('|')[1];
    }
    this.notesModal = {
      subset_unique_id: subsetUniqueId?.toString(),
      id: id,
      note_type: noteType,
      parent_id: parentId,
      show: true
    };
    this.showNotes = true;
    this.showcomment = false;
    this.closecard = true;
}

// prepareUniqueIdForNotes(tag): string{
//     let uniqueId = '';
//     if (tag !== null && tag !== undefined) {
//       tag.forEach(item => {
//         if ('uniqueId' === item.code) {
//           uniqueId =  item.display;
//         }
//       });
//     }
//     return uniqueId;
//   }

  compareCitationData(citationData: any, title): any {
    this.returnTitle = 0;
    if (citationData !== '' && citationData !== undefined) {
      citationData.forEach(item => {
        if (title === item.title) {
          this.returnTitle = item.seq;
        }
      });
    }
    return this.returnTitle;
  }

  prepareCitationLink(overviewTextString) {
    const index1 = overviewTextString.indexOf('title');
    const index2 = overviewTextString.indexOf('href');
    const index3 = overviewTextString.indexOf('id=');
    const strng1 = overviewTextString.substring(overviewTextString.indexOf('title'), overviewTextString.indexOf('href'));
    const strng2 = overviewTextString.substring(overviewTextString.indexOf('href'), overviewTextString.indexOf('id='));
    const citationData = {
      seq: this.k++,
      id: strng2.substring(21, strng2.length - 1),
      title: strng1.substring(6, strng1.length - 1)
    };
    this.citationData.push(citationData);
  }

  isRecommended(res: any) {
    if (res.contained.length > 0) {
      this.recommended = true;
    }
  }
  
  populateMetaAfterQuestion(res: any) {
    this.criteriaMet = res?.contained?.[0]?.parameter?.[3]?.valueString;
    this.qnaReview.meta.tag.length = 0;
    this.qnaReview.meta.lastUpdated = new Date();
    this.qnaReview.meta.tag.push(
      {
        'code': 'subset_id',
        'display': res?.meta?.tag[0]?.display
      }
    )

    this.qnaReview.meta.tag.push(
      {
        'code': 'latestSubsetId',
        'display': res?.meta?.tag[2]?.display
      }
    )

    this.qnaReview.meta.tag.push(
      {
        'code': 'subsetIdentifierId',
        'display': res?.meta?.tag[3]?.display
      }
    )

    this.qnaReview.meta.tag.push(
      {
        'code': 'product_id',
        'display': res?.meta?.tag[4]?.display
      }
    )
    this.qnaReview.meta.tag.push(
      {
        'code': 'version_id',
        'display': 'RM20'
      }
    )
    this.qnaReview.meta.tag.push(
      {
        'code': 'subsetType',
        'display': 'QNA'
      }
    )
    this.qnaReview.meta.tag.push(
      {
        'code': 'autoSave',
        'display': 'true'
      }
    )

    this.qnaReview.meta.tag.push(
      {
        'code': CommonConstants.REVIEW_REVISION,
        'display': '1'
      }
    )

    this.qnaReview.meta.tag.push(
      {
        'code': CommonConstants.REVIEW_VERSION,
        'display': this.reviewVersion.toString()
      }
    )

    this.qnaReview.meta.tag.push(
      {
        'code': 'lockedDate',
        'display': ''
      }
    )
  }

  onCheck(list: Array<Item>, qItem: Item, id, prefix, index, event) {
    const choice = list.findIndex(e => e.linkId === id) + 1;
    const newlist = list.filter(item => item.linkId !== id);
    const arr = qItem?.linkId?.split('|');
    const tick = arr[0] + '|' + arr[1];
    this.qnaReviewSelected = false;
    this.displayRecommendation = true;
    qItem.showRecommdations = false;
    this.disableRecommendations = true;
    this.recommendationsMet = 0;
    this.QuestionnaireList.splice(index + 1, this.QuestionnaireList.length);
    if (!this.multiSelectForm.controls[id]?.value) {
      this.disableRecommendations = true;
      this.recommendationsMet = 0;
      if (index === 0) {
        this.qnaReviewSelected = true;
      }
      if (qItem.prefix === CommonConstants.MULT) {
        qItem.enableMultiBtn = true;
        this.nextButtonDisabled = true;
        list.forEach(e => {
          if (this.multiSelectForm.controls[e.linkId].value) {
            qItem.enableMultiBtn = true;
            this.nextButtonDisabled = false;
          }
        });
      }
      return;
    }

    console.log('TYPE', qItem.prefix);
    if (qItem.prefix !== CommonConstants.MULT) {
      newlist.forEach(element => {
        console.log('Linkid', element.linkId);
        this.multiSelectForm.controls[element.linkId].setValue(false);
      });
    } else if (qItem.prefix === CommonConstants.MULT) {
      this.checkorUnCheckMulti(qItem, choice, list);
      return;
    }
    this.nextQuestion(qItem);
  }

  viewRecommendation() {
    this.displayRecommendation = true;
  }

  checkorUnCheckMulti(qItem: Item, choice: number, list: Array<Item>) {
    qItem.enableMultiBtn = true;
    this.nextButtonDisabled = false;
    const orIndex = list.findIndex(e => e.text.trim() === 'Or');
    if (orIndex < 0) {
      return;
    }
    if (orIndex >= choice) {
      for (let i = orIndex + 1; i < list.length; i++) {
        this.multiSelectForm.controls[list[i].linkId].setValue(false);
      }
    } else {
      for (let i = 0; i < orIndex; i++) {
        this.multiSelectForm.controls[list[i].linkId].setValue(false);
      }
    }
  }

  checkRoleForRecommendations() {
    this.userRole = this.getUserRoles();
    console.log('ecp user role is - ' + JSON.stringify(this.userRole));
    if (this.userRole === GuidelinesConstants.NURSE) {
        this.isRoleNurse = true;
      }
  }

  getUserRoles() {
    const ecpClaims = this.microProductAuthService.getEcpClaims()[this.ecpClaimsVal];
    const orgs = ecpClaims[this.ecpCliOrgsVal];
    const roles = orgs[0]['func-roles'][0]['appl-roles'];
    console.log('ecp roles ' + JSON.stringify(roles));
    if (roles.includes(GuidelinesConstants.NURSE)) {
      return GuidelinesConstants.NURSE;
    }
  }

  closeCard(): any{
    this.closecard = !this.closecard;
  }
}

interface Comment {
  text: string;
  userName: string;
  dateTime: Date;
}

