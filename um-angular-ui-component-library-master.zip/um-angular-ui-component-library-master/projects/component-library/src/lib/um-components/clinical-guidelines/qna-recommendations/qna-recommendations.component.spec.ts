import { ComponentFixture, TestBed, async } from '@angular/core/testing';
import { QnaRecommendationsComponent } from './qna-recommendations.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { RouterModule } from '@angular/router';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/compiler';
import { QnaReview } from '../../models/QnaReview';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { QnaReviewSummaryService } from '../../services/um/service/clinical-guidelines/qna-review-summary/qna-review-summary.service';

describe('QnaMedicalReviewRecommendationsComponent', () => {
  let component: QnaRecommendationsComponent;
  let fixture: ComponentFixture<QnaRecommendationsComponent>;
  let qnaReview =
  {
    "resourceType": "QuestionnaireResponse",
    "meta": {
      "lastUpdated": null,
      "tag": [
        {
          "code": "subset_id",
          "display": "ISP5302"
        },
        {
          "code": "uniqueId",
          "display": "353919"
        },
        {
          "code": "latestSubsetId",
          "display": "353919"
        },
        {
          "code": "subsetIdentifierId",
          "display": "1183431"
        },
        {
          "code": "product_id",
          "display": "PROCEDURES"
        },
        {
          "code": "version_id",
          "display": "RM20"
        },
        {
          "code": "subsetType",
          "display": "QNA"
        },
        {
          "code": "autoSave",
          "display": "true"
        }
      ]
    },
    "questionnaire": "353919",
    "item": [
      {
        "linkId": "1513463|1",
        "answer": [
          {
            "valueString": "1"
          }
        ]
      },
      {
        "linkId": "1513464|3",
        "answer": [
          {
            "valueString": "2"
          }
        ]
      },
      {
        "linkId": "1513468|29039",
        "answer": [
          {
            "valueString": "Y"
          }
        ]
      },
      {
        "linkId": "1513469|11",
        "answer": [
          {
            "valueString": "1"
          }
        ]
      },
      {
        "linkId": "1513470|29056",
        "answer": [
          {
            "valueString": "1"
          }
        ]
      }
    ],
    "contained": [
      {
        "resourceType": "Parameters",
        "id": "availableRecommendations",
        "parameter": [
          {
            "name": "recommendationId",
            "valueString": "1050747|1050748"
          },
          {
            "name": "groupId",
            "valueString": "ZP500|ZP502"
          },
          {
            "name": "disposition_notes",
            "valueString": "<p>There is no convincing evidence for the use of acupuncture for pain relief in patients with fibromyalgia. Study design flaws presently prohibit assessing acupuncture’s utility for improving health outcomes. Acupuncture is not considered reasonable and necessary for the treatment of fibromyalgia.</p>"
          }
        ]
      },
      {
        "resourceType": "Parameters",
        "id": "comments",
        "parameter": [
          {
            "name": "1",
            "valueId": "TestingUser1, TestingUser1",
            "valueDateTime": "2021-01-12T09:49:44-06:00",
            "valueString": "test xyzn"
          },
          {
            "name": "26164",
            "valueId": "TestingUser1, TestingUser1",
            "valueDateTime": "2021-01-12T09:49:44-06:00",
            "valueString": "test comments 3"
          },
          {
            "name": "1",
            "valueId": "TestingUser1, TestingUser1",
            "valueDateTime": "2021-01-12T09:49:44-06:00",
            "valueString": "test comment 3"
          },
          {
            "name": "26164",
            "valueId": "TestingUser1, TestingUser1",
            "valueDateTime": "2021-01-12T09:49:44-06:00",
            "valueString": "test comments 4"
          },
          {
            "name": "1",
            "valueId": "TestingUser1, TestingUser1",
            "valueDateTime": "2021-01-12T09:49:44-06:00",
            "valueString": "abcd"
          },
          {
            "name": "2",
            "valueId": "TestingUser1, TestingUser1",
            "valueDateTime": "2021-01-12T09:49:44-06:00",
            "valueString": "test comments 2"
          },
          {
            "name": "1",
            "valueId": "TestingUser1, TestingUser1",
            "valueDateTime": "2021-01-12T09:49:44-06:00",
            "valueString": "testage 1 comments test"
          },
          {
            "name": "2",
            "valueId": "TestingUser1, TestingUser1",
            "valueDateTime": "2021-01-12T09:49:44-06:00",
            "valueString": "test comments 2 phasw"
          },
          {
            "name": "1",
            "valueId": "TestingUser1, TestingUser1",
            "valueDateTime": "2021-01-12T09:49:44-06:00",
            "valueString": "testage comment"
          }
        ]
      }
    ],
    "identifier": {
      "use": "official",
      "value": "9a59e426-3938-49fb-97b8-dd2dca432c17"
    },
    "status":""
  } as QnaReview;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [FormsModule, ReactiveFormsModule, HttpClientTestingModule, RouterTestingModule.withRoutes([]), RouterModule],
      declarations: [ QnaRecommendationsComponent ],
      providers: [QnaReviewSummaryService],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]

    })
    .overrideModule(BrowserDynamicTestingModule, { set: { entryComponents: [QnaRecommendationsComponent] } })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QnaRecommendationsComponent);
    component = fixture.componentInstance;
    component.qnaReview = qnaReview;
    fixture.detectChanges();
  });

  afterEach(() => {
    fixture.destroy();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  xit(' previous emit event', () => {
    spyOn(component.previous, 'emit');
    const nativeElement = fixture.nativeElement;
    const button = fixture.debugElement.nativeElement.querySelector('[previous_button]');
    button.dispatchEvent(new Event('click'));


    fixture.detectChanges();
    expect(component.previous.emit).toHaveBeenCalled();
  });

  xit('save event', () => {
    spyOn(component.saveQnaReview,'emit').and.callThrough();

    const nativeElement = fixture.nativeElement;
    const button = fixture.debugElement.nativeElement.querySelector('[save-button]');
    button.dispatchEvent(new Event('click'));

    component.saveQnaReview.emit;
    component.selectRecommendation();
    // component.reviewSummary();
    fixture.detectChanges();
    expect(component.saveQnaReview.emit).toHaveBeenCalled();
  });

  xit('complete event', () => {
    spyOn(component.completeQnaReview, 'emit');

    const nativeElement = fixture.nativeElement;
    const button = fixture.debugElement.nativeElement.querySelector('[complete-button]');
    button.dispatchEvent(new Event('click'));

    fixture.detectChanges();
    expect(component.completeQnaReview.emit).toHaveBeenCalled();
  });

});
