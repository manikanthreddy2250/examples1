import { Component, OnInit, OnChanges, EventEmitter, Output, Input } from '@angular/core';
import { Router } from '@angular/router';
import { GuidelinesConstants } from '../../../constant/guidelines-constants';
import { QnaReviewSummaryService } from '../../services/um/service/clinical-guidelines/qna-review-summary/qna-review-summary.service';
import { QnaReview } from '../../models/QnaReview';

@Component({
  selector: 'ecp-um-qna-recommendations',
  templateUrl: './qna-recommendations.component.html',
  styleUrls: ['./qna-recommendations.component.scss']
})
export class QnaRecommendationsComponent implements OnInit,OnChanges {

  constructor(private readonly router: Router,
    private readonly reviewSummaryQnaService: QnaReviewSummaryService) {
  }

  @Input() qnaReview: QnaReview
  @Input() recommended = false;
  @Output() previous: EventEmitter<any> = new EventEmitter()
  @Output() hideButtons: EventEmitter<any> = new EventEmitter()
  @Output() saveQnaReview: EventEmitter<any> = new EventEmitter()
  @Output() completeQnaReview: EventEmitter<any> = new EventEmitter()
  @Output() showQnaRecommendation: EventEmitter<any> = new EventEmitter()
  notesModal: any = {
    show: false
  };
  selectedRecommendation: any = false;
  recommendationsId: any;
  groupId: any;
  showQNAReviewSummary: any = false;


  notRecommendedNotes = [];


  ngOnInit(): void {
  this.showQNAReviewSummary =  false;
    // if (this.qnaReview?.contained.length > 0) {
    //   for (let k = 0; k < this.qnaReview?.contained.length; k++) {
    //     if (this.qnaReview.contained[k].id === GuidelinesConstants.AVIALABLERECOMMENDATIONS) {
    //       this.groupId = this.qnaReview.contained[k].parameter[0].valueString;
    //       this.recommendationsId = this.qnaReview.contained[k].parameter[2].valueString;
    //       this.notRecommendedNotes = this.qnaReview.contained[k]?.parameter[1]?.valueString?.split('|');
    //     }
    //   }
    // }

    this.notesModal = {
      subset_unique_id: '',
      id: this.recommendationsId,
      note_type: GuidelinesConstants.RECOMMENDATION_NOTE,
      parent_id: '',
      show: false

    }
    this.modfiyNotesText();

  }
  ngOnChanges(): void {
  }
  modfiyNotesText (){
    for(let i = 0; i < this.notRecommendedNotes?.length ;i ++){
      this.notRecommendedNotes[i]= this.notRecommendedNotes[i].replace(/(<([^>]+)>)/gi, "")
        }
  }


  selectRecommendation() {
    this.selectedRecommendation = !this.selectedRecommendation
  }

  returnFrmRvwSmry(reviewSumry: boolean) {
    this.showQNAReviewSummary = reviewSumry
  }


}
