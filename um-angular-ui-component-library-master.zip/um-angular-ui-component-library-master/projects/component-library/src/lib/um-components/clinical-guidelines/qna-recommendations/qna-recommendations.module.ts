import {NgModule, NO_ERRORS_SCHEMA} from '@angular/core';
import {APP_BASE_HREF, CommonModule} from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { TableModule } from '@ecp/angular-ui-component-library/table';
import { SortModule } from '@ecp/angular-ui-component-library/sort';
import { TabsModule } from '@ecp/angular-ui-component-library/tabs';
import { MatGridListModule } from '@angular/material/grid-list';
import { ButtonModule } from '@ecp/angular-ui-component-library/button';
import { IconsModule } from '@ecp/angular-ui-component-library/icons';
import { MatIconModule } from '@angular/material/icon';
import { CardModule} from '@ecp/angular-ui-component-library/card';
import { PaginatorModule} from '@ecp/angular-ui-component-library/paginator';
import {HttpClientModule} from '@angular/common/http';
import {TagsModule} from '@ecp/angular-ui-component-library/tags';
import {UserAuthService} from "../../services/auth/user.service";
import {AuthLibraryModule} from "@ecp/auth-library";
import {MedicalReviewTreeModule} from "../medical-review-tree/medical-review-tree.module";
import { GuidelinesBedDayModule } from '../guidelines-bed-day-decision/guidelines-bed-day.module';
import { QnaRecommendationsComponent } from './qna-recommendations.component';
import { QnaReviewSummaryService } from '../../services/um/service/clinical-guidelines/qna-review-summary/qna-review-summary.service';


@NgModule({
  declarations: [
    QnaRecommendationsComponent,
  ],

    imports: [
        CommonModule,
        BrowserModule,
        BrowserAnimationsModule,
        CardModule,
        MatIconModule,
        TableModule,
        ButtonModule,
        TabsModule,
        IconsModule,
        SortModule,
        HttpClientModule,
        PaginatorModule,
        TagsModule,
        AuthLibraryModule,
        MedicalReviewTreeModule,
        GuidelinesBedDayModule
    ],
  exports: [
    QnaRecommendationsComponent
  ],
  providers: [QnaReviewSummaryService,UserAuthService, {provide: APP_BASE_HREF, useValue: '/'}]
})
export class QnaRecommendationsModule { }
