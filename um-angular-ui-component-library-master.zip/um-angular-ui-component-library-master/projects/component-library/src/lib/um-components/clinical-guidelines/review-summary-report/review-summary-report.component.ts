import { Component, OnInit, Input, Output, EventEmitter, ViewChild, ChangeDetectorRef, AfterContentChecked } from '@angular/core';
import { MedicalReviewGraphqlServiceService } from '../../services/um/service/clinical-guidelines/medical-review-graphql-service/medical-review-graphql-service.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import {MicroProductAuthService} from "@ecp/auth-library";
import {getEnvVar} from "../../services/environment/envVarUtil";
import { GUIDELINES_FUNCTION_API_URL} from "../../../config/config-constants";
import {GuidelinesConstants} from "../../../constant/guidelines-constants";
import {UmcasewfGraphqlService} from "../../services/um/service/casewf/umcasewf-graphql.service";
import {HttpClient} from "@angular/common/http";
import {SysConfigService} from '../../services/um/service/clinical-guidelines/sysconfig-service/sys-config.service';
import { EcpUclModal } from '@ecp/angular-ui-component-library/modal';

@Component({
  selector: 'ecp-ucl-review-summary-report',
  templateUrl: './review-summary-report.component.html',
  styleUrls: ['./review-summary-report.component.scss']
})
export class ReviewSummaryReportComponent implements OnInit, AfterContentChecked {
  @Input() reviewId: string
  @Output() editReview: EventEmitter<boolean> = new EventEmitter();
  @ViewChild(EcpUclModal, {static: true})
  modal: EcpUclModal;
  savedReviewSelectionList: any = []
  checkedIdsFhir: any = [];
  commentsArray: any = [];
  criteriaMet: any;
  list: any = [];
  isSelected: boolean;
  isLoading: boolean;
  reviewUUID: string;
  stepResponseId: any;
  subsetUniqueId: any;
  reviewVersion: any;
  reviewRevision: any;
  guideLineID: any;
  productId: any;
  versionVal: any;
  reviewRes: any;
  selectedValue: string;
  selectedView: any;
  medReviewTreeForm: FormGroup = this.fb.group({});
  reviewViewTypeForm: FormGroup = new FormGroup({
    reviewViewType: new FormControl(null),
  });

  options = [
    { name: 'Selected Criteria in Context', value: '2' },
    { name: 'All Criteria', value: '3' }
  ];
  idsArray: any = [];
  labelPosition = 'before';
  checkboxState = 'default';
  ndtSelectionList: any = [];
  reviewCreatedDate: any;
  reviewUserDescription: any;
  reviewUserFacility: any;
  subsetName: any;
  productName: any;
  selectedCriteriaContext: string;
  questionnaireDetailsList
  episodeDayMet: any;
  commentsFhir = [];
  versionDesc: any;
  responderMetId: any;
  criteriaStatusFlag = false;
  userRole;
  roles = [];
  constructor(private readonly fb: FormBuilder, private readonly medicalReviewGraphqlServiceService: MedicalReviewGraphqlServiceService,
    private readonly microProductAuthService: MicroProductAuthService,
    private readonly umcaseService: UmcasewfGraphqlService,
    private readonly http: HttpClient,
    private readonly sysConfigService: SysConfigService, private readonly cdf: ChangeDetectorRef) { }

  ngOnInit(): void {
    this.checkRoleForCriteriaStatus();
    this.selectedView = this.options[0].value;
    this.medReviewTreeForm = this.fb.group({});
    this.reviewViewTypeForm = new FormGroup({
      reviewViewType: new FormControl(this.selectedView),
    });
    this.getMedicalReviewTreeWithUUID(this.reviewId);
  }

  ngAfterContentChecked(): void {
    this.cdf.detectChanges();
  }

  checkRoleForCriteriaStatus() {
    this.userRole = this.getUserRoles();
    console.log('ecp user role is - ' + JSON.stringify(this.userRole));
    this.sysConfigService.getClientConfigByKey(GuidelinesConstants.CRITERIA_STATUS_ROLE).then((res: any) => {
      this.roles = res ? JSON.parse(res[0].value) : [];
      console.log('SysConfig Roles for Criteria Status from Report Page - ' + JSON.stringify(this.roles));
      if (this.roles.includes(this.userRole)) {
        this.criteriaStatusFlag = true;
      }
    });
  }

  getUserRoles() {
    const ecpClaims = this.microProductAuthService.getEcpClaims()['x-ecp-claims'];
    const orgs = ecpClaims['x-ecp-cli-orgs'];
    const ecpOrg = orgs.find((org) => org['org-id'] === 'ecp');
    const roles = ecpOrg['func-roles'][0]['appl-roles'];
    console.log('ecp roles are' + JSON.stringify(roles));
    if (roles.includes(GuidelinesConstants.NURSE)) {
      return GuidelinesConstants.NURSE;
    }
  }

  onChange(event) {
    console.log('select onChange event ' + JSON.stringify(event));
    this.selectedView = event
    this.settingDropdownDataforUUID()
  }
  settingDropdownDataforUUID() {
    if (this.selectedView === "2") {
      if (this.responderMetId !== undefined) {
        this.list = this.questionnaireDetailsList['contained'][3]['parameter'];
      } else {
        this.list = this.questionnaireDetailsList['contained'][2]['parameter']?.filter(param => param.name.substring(3, param.name.length - 17) === this.episodeDayMet.substring(3, this.episodeDayMet.length - 4))
        //this.list = this.questionnaireDetailsList['contained'][2]['parameter']
      }

      this.setIdsAndRegisterControls(this.list, this.questionnaireDetailsList["item"])
      console.log('selectedView === "2" list' + JSON.stringify(this.list));

    }

    if (this.selectedView === "3") {
      this.list = this.questionnaireDetailsList['contained'][2]['parameter']
      this.setIdsAndRegisterControls(this.list, this.questionnaireDetailsList["item"])
      console.log('selectedView === "3" list ==>' + JSON.stringify(this.list));
    }
  }
  setIdsAndRegisterControls(list, ndtSelectionList) {
    this.getIds(list);
    for (let i = 0; i < this.list.length; i++) {
      this.registerControls(this.list[i].id)
    }

    this.ndtSelectionList = ndtSelectionList
    for (let k = 0; k < this.ndtSelectionList.length; k++) {
      if (this.medReviewTreeForm.get(this.ndtSelectionList[k].id) !== null) {
        this.medReviewTreeForm.get(this.ndtSelectionList[k].id).patchValue(true);
      }
      this.isLoading = false;
    }
  }

  async getMedicalReviewTreeWithUUID(uuid: string) {
    const medRevData = await this.medicalReviewGraphqlServiceService.getMedicalReviewDataFromIQ(uuid)
    console.log("existing review data" + JSON.stringify(medRevData));
    const questionReq = medRevData.data.getMedicalReviewDetails.reviewRes;
    console.log("review data existing" + JSON.stringify(questionReq));
    this.savedReviewSelectionList = questionReq['item'];
    for (let j = 0; j < this.savedReviewSelectionList.length; j++) {
      if (this.savedReviewSelectionList[j]['answer'][0]['valueBoolean'] === true) {
        this.checkedIdsFhir.push({
          linkId: this.savedReviewSelectionList[j]['linkId'],
          answer: [{ valueBoolean: 'true' }]
        });
      }
    }
    questionReq.contained[1].parameter.forEach(element => {
      const commentObj = {
        "nodeCid": element.name,
        "text": element.valueString,
        "user": element.valueId,
        "date": element.valueDateTime,
      };
      this.commentsArray.push(commentObj);
    });
    questionReq.contained[0]['parameter'].push({
      "name": "next",
      "valueBoolean": "false",
      "valueString": "true"
    })
    this.commentsFhir = this.getCommentsFhir(this.commentsArray);
    await this.getNextItemAPICallInFhirDraftData(questionReq);
  }

  async getNextItemAPICallInFhirDraftData(questionReq) {
    const existingQuestionnaireRes = await this.medicalReviewGraphqlServiceService.getExistingQuestionnaireData(questionReq)
    console.log("questionnaire response data existing ==>" + JSON.stringify(existingQuestionnaireRes));
    const questionnaireDetails = existingQuestionnaireRes.data.getQuestionnaireDetails.questionRes;
    this.questionnaireDetailsList = questionnaireDetails;
    console.log("questionnaire response Fhir" + JSON.stringify(questionnaireDetails));
    this.criteriaMet = questionnaireDetails['contained'][0]['parameter'][1]['valueString'];
    this.episodeDayMet = questionnaireDetails['contained'][0]['parameter'].filter(param => param.name === 'episode_day_met')[0]['valueString']
    this.responderMetId = questionnaireDetails['contained'][0]['parameter'].filter(param => param.name === 'responder_met_id')[0]['valueString']

    if (this.responderMetId !== undefined) {
      this.list = questionnaireDetails['contained'][3]['parameter'];
    }
    else if (this.episodeDayMet === null || this.episodeDayMet === '') {
      this.list = questionnaireDetails['contained'][2]['parameter'];
    }
    else {
      this.list = questionnaireDetails['contained'][2]['parameter']?.filter(param => 
        param.name.substring(3, param.name.length - 17) === this.episodeDayMet.substring(3, this.episodeDayMet.length - 4))
    }

    this.setIdsAndRegisterControls(this.list, questionnaireDetails["item"])
    for (let i = 0; i < this.list.length; i++) {
      const title = this.list[i]['name'];
      const episodeDay = questionnaireDetails['contained'][0]['parameter'].filter(param => param.name === 'episode_day_met');
      const resText = episodeDay[0]['valueString'].substring(3, title.length - 4);
      const text = title.substring(3, title.length - 4);
    }
    this.isLoading = false;
    this.reviewUUID = this.reviewId;
    this.stepResponseId = questionReq['contained'][0]['parameter'][0]['valueString'];
    this.subsetUniqueId = questionReq['questionnaire'];
    this.reviewVersion = questionReq['meta']['tag'][13]['display'];
    this.reviewRevision = questionReq['meta']['tag'][12]['display'];
    this.guideLineID = questionnaireDetails['meta']['tag'][2]['display'];
    this.productId = questionnaireDetails['meta']['tag'][0]['display'];
    this.versionVal = questionnaireDetails['meta']['tag'][1]['display'];
    this.reviewCreatedDate = questionnaireDetails['meta']['tag'][5]['display'];
    this.reviewUserDescription = questionnaireDetails['meta']['tag'][6]['display'];
    this.reviewUserFacility = questionnaireDetails['meta']['tag'][9]['display'];
    this.subsetName = questionnaireDetails['meta']['tag'][16]['display'];
    this.productName = questionnaireDetails['meta']['tag'][18]['display'];
    this.versionDesc = questionnaireDetails['meta']['tag'][17]['display'];
    this.reviewRes = questionReq;
  }

  getTextObjectsForTooltip(item: any) {
    const textObjects = [];
    let textObject: any = {}
    const text = item.text;
    let newStartingIndex = 0;
    if (!item.terms) {
      textObject = {
        value: item.text,
        type: 'text'
      };
      textObjects.push(textObject);
      return textObjects;
    }
    for (const term of item.terms) {
      if (newStartingIndex < (Number(term.start) - 1)) {
        textObject = {
          value: item.text.substring(newStartingIndex, Number(term.start) - 1),
          type: 'text'
        };
        textObjects.push(textObject)
      }
      textObject = {
        value: term.term,
        type: 'link',
        desc: term.desc
      };
      textObjects.push(textObject);
      newStartingIndex = Number(term.start) - 1 + term.term.length;
    }
    if (newStartingIndex < item.text.length) {
      textObject = {
        value: item.text.substring(newStartingIndex, item.text.length),
        type: 'text'
      };
      textObjects.push(textObject)
    }
    return textObjects;
  }
  /** Add controls based on the id's in the nested json structure */
  registerControls(id: any) {
    this.medReviewTreeForm.addControl(id, this.fb.control('', [Validators.required]))
    if (this.idsArray !== null && this.idsArray !== undefined && this.idsArray.length > 0) {
      for (const value of this.idsArray) {
        if (value !== undefined) {
          this.medReviewTreeForm.addControl(value.linkId, this.fb.control('', [Validators.required]))
        }
      }
    }
  }

  // Fetching id's from Nested JSON object and storing it in a idsArray array to register controls
  getIds(nestedJsonObj: any) {
    for (const value of nestedJsonObj) {
      const childId = value;
      if (childId !== undefined && childId.hasOwnProperty('item')) {
        if (childId.linkId !== undefined && childId.type !== 'display') {
          this.idsArray.push(childId);
        }
        this.getIds(childId.item);
      } else {
        this.idsArray.push(childId);
      }
    }
  }

  getCommentsFhir(commentsArray) {
    const commentFhir = [];
    commentsArray.forEach(item => {
      const fhircommentObj = {
        name: item.nodeCid,
        valueId: item.user,
        valueDateTime: item.date,
        valueString: item.text
      };
      commentFhir.push(fhircommentObj);
    });
    return commentFhir;
  }

  editButton() {
    this.editReview.emit(true);
  }

  prepareReviewRequest(): any {
    const request: any = {};

    request["step_responses"] = [{
      "id": this.stepResponseId,
      "skip_ui": this.reviewRes['meta']['tag']?.filter(x => x.code === 'skipUI')[0]?.display,
      "type": "EVALUATE_CRITERIA",
      "selections": []
    }];

    for (var i = 0; i < this.reviewRes['item'].length; i++) {

      request["step_responses"][0]["selections"].push(
        {
          "links": [],
          "id": this.reviewRes['item'][i]['linkId'],
          "choice": (this.reviewRes['item'][i]['answer'][0]['valueBoolean'] ? "CHECKED" : "UNCHECKED"),
          "hide_selection": false,
          "error": false
        }
      )
    }

    request["source"] = this.reviewRes['meta']['tag'].filter(i => i.code === 'source')[0].display;
    request["phase"] = this.reviewRes['meta']['tag'].filter(j => j.code === 'phase')[0].display;
    request["review_date"] = this.reviewRes['meta']['tag'].filter(k => k.code === 'reviewCreatedDate')[0].display;
    request["review_status_code"] = this.reviewRes['status'];
    request["product_id"] = this.reviewRes['meta']['tag'].filter(l => l.code === 'product_id')[0].display;
    request["version_id"] = this.reviewRes['meta']['tag'].filter(m => m.code === 'version_id')[0].display;
    request["subset_id"] = this.reviewRes['meta']['tag'].filter(n => n.code === 'subset_id')[0].display;
    request["subset_unique_id"] = this.reviewRes['questionnaire'];
    request["review_user"] = this.reviewRes['meta']['tag'].filter(o => o.code === 'reviewUser')[0].display;
    request["review_user_description"] = this.reviewRes['meta']['tag'].filter(p => p.code === 'reviewUserDescription')[0].display;
    request["review_user_facility"] = this.reviewRes['meta']['tag'].filter(q => q.code === 'review_user_facility')[0].display;
    request["review_user_organization"] = this.reviewRes['meta']['tag'].filter(r => r.code === 'reviewUserOrganization')[0].display;
    request["is_integrated_environment"] = true;
    request["comments"] = this.prepareCommentsForPDF(this.reviewRes['contained']?.[1]?.['parameter']);

    request["pdf_options"] = {
      "include_notes": true,
      "hide_criteria_status": !this.criteriaStatusFlag,
      "selected_criteria": this.selectedView,
      "manual_review": true,
      "hide_emr_data": false
    }

    return request;
  }

  printReviewSummary(){
    this.modal.open();
    const request = this.prepareReviewRequest();

    const httpOptions: any = {
      headers: {
        'Accept': 'application/pdf',
      },
      responseType: 'arraybuffer'
    };
    this.http
      .post(
        `${getEnvVar(GUIDELINES_FUNCTION_API_URL)}/ndt/summary`,
        request,
        httpOptions
      )
      .subscribe((res: any) => {
        var blob = new Blob([res], { type: 'application/pdf' });
        if (blob && blob.size > 0) {
          var blobURL = URL.createObjectURL(blob);
          window.open(blobURL);
        }
        this.modal.close();
      });
  }

  prepareCommentsForPDF(comments) {
    const commentsArray = [];
    for (let i = 0; i < comments?.length; i++) {
      commentsArray.push({
        nodeCid: comments[i]?.name,
        user: comments[i]?.valueId,
        date: comments[i]?.valueDateTime,
        text: comments[i]?.valueString
      });
    }
    return commentsArray;
  }

}
