import { NgModule, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { APP_BASE_HREF, CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { TabsModule } from '@ecp/angular-ui-component-library/tabs';
import { MatGridListModule } from '@angular/material/grid-list';
import { ButtonModule } from '@ecp/angular-ui-component-library/button';
import { IconsModule } from '@ecp/angular-ui-component-library/icons';
import { CardModule } from '@ecp/angular-ui-component-library/card';
import { MatIconModule } from '@angular/material/icon';
import { HttpClientModule } from "@angular/common/http";
import { CheckboxModule } from '@ecp/angular-ui-component-library/checkbox';
import { AuthLibraryModule } from "@ecp/auth-library";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SelectModule } from '@ecp/angular-ui-component-library/select';
import { InputModule } from '@ecp/angular-ui-component-library/input';
import { OptionModule } from '@ecp/angular-ui-component-library/option';
import { FormFieldModule } from '@ecp/angular-ui-component-library/form-field';
import { ReviewSummaryReportComponent } from './review-summary-report.component';
import { LinkModule } from '@ecp/angular-ui-component-library/link';
import { MatCheckboxClickAction, MAT_CHECKBOX_DEFAULT_OPTIONS } from '@angular/material/checkbox';
import { GuidelineSummaryModule } from '../guideline-summary/guideline-summary.module';
import { ProgressSpinnerModule } from '@ecp/angular-ui-component-library/progress-spinner';
import { ModalModule } from '@ecp/angular-ui-component-library/modal';

@NgModule({
  declarations: [ReviewSummaryReportComponent],
  imports: [
    CommonModule,
    BrowserModule,
    SelectModule,
    InputModule,
    OptionModule,
    BrowserAnimationsModule,
    MatGridListModule,
    MatIconModule,
    FormsModule,
    ReactiveFormsModule,
    ButtonModule,
    CardModule,
    TabsModule,
    IconsModule,
    ModalModule,
    ProgressSpinnerModule,
    AuthLibraryModule,
    HttpClientModule,
    CheckboxModule,
    FormFieldModule,
    LinkModule,
    GuidelineSummaryModule
  ],
  exports: [
    ReviewSummaryReportComponent,
  ],
  providers: [{ provide: APP_BASE_HREF, useValue: '/' }, { provide: MAT_CHECKBOX_DEFAULT_OPTIONS, useValue: 'check' }],
  schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA]

})
export class ReviewSummaryReportModule { }
