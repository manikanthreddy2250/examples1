import {HttpHeaders} from '@angular/common/http';
import {MicroProductAuthService} from '@ecp/auth-library';
import {UserAuthService} from '../../services/auth/user.service';
import {Injectable} from '@angular/core';
import {GuidelinesConstants} from '../../../constant/guidelines-constants';


@Injectable({
  providedIn: 'root'
})
export class GuidelinesUtils {

  constructor(private readonly microProductAuthService: MicroProductAuthService, private readonly userAuthService: UserAuthService) {
  }

  application = 'case_wf_mgmt_ui';

  getApiHeaders(): HttpHeaders {
   return this.getApiHeadersWithAppName(this.application);
  }

  getApiHeadersWithAppName(applicationName: string): HttpHeaders {
    const userHasuraRole = this.userAuthService.getUserHasuraRole(applicationName);
    const ecpClaims = this.microProductAuthService.getEcpClaims();
    const orgId = ecpClaims?.['x-ecp-claims']?.['x-ecp-cli-orgs']?.[0]?.['org-id'];
    let tenantId = '';

    if (orgId === 'ecp') {
      tenantId = 'ecpumcasemgmtbasebpmgrp';
    } else if (orgId === 'uhc') {
      tenantId = 'uhcumcasemgmtuhcbpmgrp';
    }
    return new HttpHeaders()
      .set('Content-Type', 'application/json')
      .set('Authorization', 'Bearer ' + this.microProductAuthService.getEcpToken())
      .set('x-bpm-cli-org-id', orgId)
      .set('x-bpm-func-role', ecpClaims?.['x-ecp-claims']?.['x-ecp-cli-orgs']?.[0]?.['func-roles']?.[0]?.['role-name'])
      .set('x-bpm-tenant-id', tenantId)
      .set('x-hasura-role', userHasuraRole);
  }

}
