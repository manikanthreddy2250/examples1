

export class Answer{
    public valueString: string;
}
