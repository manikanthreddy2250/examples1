export class Identifier {
    public use: string;
    public value: string;
}
