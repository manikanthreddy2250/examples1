import {Answer} from './Answer';

export class QItem{
    public linkId: string;
    public answer: Answer[];
}
