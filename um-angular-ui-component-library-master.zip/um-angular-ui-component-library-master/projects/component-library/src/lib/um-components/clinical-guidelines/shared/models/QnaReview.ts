import {Identifier} from './Identifier';
import {Meta} from './Meta';
import {Item} from './Item';
import {Contained} from './Contained';

export class QnaReview {
    public resourceType: string;
    public identifier: Identifier;
    public meta: Meta;
    public questionnaire: string;
    public status: string
    public item: Item[];
    public text: string;
  public contained: Contained[];
  public questionsList: any;
}
