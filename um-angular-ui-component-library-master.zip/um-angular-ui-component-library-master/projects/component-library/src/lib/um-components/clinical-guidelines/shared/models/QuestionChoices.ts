import {Meta} from './Meta';
import {Item} from './Item';
import {Contained} from './Contained';

export class QuestionChoices {
  public resourceType: string;
  public id: string;
  public name: string;
  public text: string;
  public meta: Meta;
  public item: Item[];
  public contained: Contained[];
  public title: string;
}
