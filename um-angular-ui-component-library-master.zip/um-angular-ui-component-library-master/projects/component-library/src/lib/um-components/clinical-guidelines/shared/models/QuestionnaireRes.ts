import {Meta} from './Meta';
import {QItem} from './QItem';
import {Contained} from './Contained';

export class QuestionnaireRes {
  public resourceType: string;
  public meta: Meta;
  public item: QItem[];
  public contained: Contained;

}
