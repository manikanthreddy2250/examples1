import { Meta } from "./Meta";
import { QItem } from "./QItem";

export class QuestionnaireResponse {
    public resourceType: string;
    public meta: Meta;
    public guidelineName: string;
    public text: string;
    public questionnaire: string;
    public item: QItem[];
}
