export class Tag{
    public code: string;
    public display: string;
}
