import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SmartsheetComponent } from './smartsheet.component';
import {AuthService, OAuthInitService, MicroProductAuthService, AuthLibraryModule} from "@ecp/auth-library";
import {HttpClientModule, HttpClient, HttpHeaders, HttpHandler} from "@angular/common/http";
import {Injectable, ChangeDetectorRef, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA} from "@angular/core";
import * as moment from 'moment';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import {TableModule} from "@ecp/angular-ui-component-library/table";
import {SortModule} from "@ecp/angular-ui-component-library/sort";
import {CommonModule} from "@angular/common";
import {Observable, of} from "rxjs";
import {OAuthLogger, OAuthService, UrlHelperService} from 'angular-oauth2-oidc';
import { MedicalReviewGraphqlServiceService } from '../../services/um/service/clinical-guidelines/medical-review-graphql-service/medical-review-graphql-service.service';
import { StringValueNode } from 'graphql/language/ast';
import {RadioButtonModule} from '@ecp/angular-ui-component-library/radio-button';
import { BrowserModule } from '@angular/platform-browser';
import {
  BrowserAnimationsModule,
  NoopAnimationsModule,
} from '@angular/platform-browser/animations';
import {
  FormControl,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { SelectModule } from '@ecp/angular-ui-component-library/select';
import { FormFieldModule } from '@ecp/angular-ui-component-library/form-field';
import { OptionModule } from '@ecp/angular-ui-component-library/option';

@Injectable()
class MockSmartSheetService {
  getSmartSheetData(subsetId: StringValueNode): Observable<any> {
    return of({"data":{"getSmartSheet":{"smartSheetRes":{"resourceType":"Bundle","entry":[{"resourceType":"Questionnaire","id":524571,"description":"Angiogram, Coronary +/- Left Heart Catheterization (Imaging)","meta":{"tag":[{"code":"recommendation_cid","display":"~IQ6.01A_41908"},{"code":"name","display":"IMG Angio, Coronary +/- LHC"},{"code":"edns","display":"N"},{"code":"display_alt_flag","display":false},{"code":"criteria_met","display":null},{"code":"plain_text","display":"Angiogram, Coronary +/- Left Heart Catheterization (Imaging)"},{"code":"service_cid","display":"CERM_11730"},{"code":"service_description","display":null},{"code":"test_code","display":"ZZ140"},{"code":"test_code2","display":"ZZ140"},{"code":"type","display":"SERVICE"},{"code":"version_cid","display":"RM21"},{"code":"selected","display":false},{"code":"title","display":"IMG Angio, Coronary +/- LHC"},{"code":"medical_codes_rel","display":"self"},{"code":"medical_codes_title","display":"medical codes for this recommendation"},{"code":"medical_codes_href","display":"/caas/recommendationdefinitions/524571/medicalcodes"}]}}],"type":"searchset","total":1}}}}
    );
  }

  getSmartSheetQuestionData(recommendationDefId: StringValueNode): Observable<any> {
    return of({"data":{"getSmartSheetQuestion":{"smartSheetQuestionRes":{"resourceType":"Questionnaire","meta":{"tag":[{"code":"rel","display":"recommendation definition"},{"code":"title","display":"recommendation definition"},{"code":"href","display":"/caas/recommendationdefinitions/524571"}]},"item":[{"item":[{"text":"Age&nbsp;≥ 18","type":"display"},{"linkId":"3382014|1","text":"Age&nbsp;≥ 18|choice_to_next_question","type":"group","definition":false,"item":[]},{"linkId":"1906909|4","text":"Choose one:|next_question|","type":"group","definition":false,"prefix":"RADIO","item":[{"linkId":3382016,"text":"ST-elevation&nbsp;myocardial infarction (STEMI) (urgent)","definition":true,"type":"boolean","prefix":"1"},{"linkId":3382017,"text":"Non-ST-elevation myocardial infarction (NSTEMI) or unstable angina by history (urgent)","definition":true,"type":"boolean","prefix":"2"},{"linkId":3382018,"text":"High-risk findings&nbsp;by stress testing","definition":true,"type":"boolean","prefix":"3"},{"linkId":3382019,"text":"Canadian Cardiovascular Society (CCS) Class III or IV angina by history","definition":true,"type":"boolean","prefix":"4"},{"linkId":3382020,"text":"Canadian Cardiovascular Society (CCS)&nbsp;Class II angina by history or New York Heart Association Class II heart failure (HF) by history or physical examination","definition":true,"type":"boolean","prefix":"5"},{"linkId":3382021,"text":"Post myocardial infarction (MI)&nbsp;angina or ischemia","definition":false,"type":"boolean","prefix":"6"},{"linkId":3382022,"text":"Post revascularization","definition":true,"type":"boolean","prefix":"7"},{"linkId":3382023,"text":"Ventricular arrhythmia","definition":false,"type":"boolean","prefix":"8"},{"linkId":3382024,"text":"New onset acute&nbsp;heart failure (HF) by physical examination or CXR","definition":true,"type":"boolean","prefix":"9"},{"linkId":3382025,"text":"Newly discovered left ventricular (LV) systolic dysfunction","definition":true,"type":"boolean","prefix":"10"},{"linkId":3382026,"text":"Valvular heart disease","definition":true,"type":"boolean","prefix":"11"},{"linkId":3382027,"text":"Constrictive pericarditis","definition":true,"type":"boolean","prefix":"12"},{"linkId":3382028,"text":"Congenital heart disease","definition":true,"type":"boolean","prefix":"13"},{"linkId":3382029,"text":"None of the above","definition":false,"type":"boolean","prefix":"14"}]},{"text":"next_question_choices","item":[{"linkId":3382019,"text":"Canadian Cardiovascular Society (CCS) Class III or IV angina by history","definition":false,"type":"boolean","prefix":"4"},{"linkId":3382020,"text":"Canadian Cardiovascular Society (CCS)&nbsp;Class II angina by history or New York Heart Association Class II heart failure (HF) by history or physical examination","definition":false,"type":"boolean","prefix":"5"},{"linkId":3382028,"text":"Congenital heart disease","definition":false,"type":"boolean","prefix":"13"},{"linkId":3382027,"text":"Constrictive pericarditis","definition":false,"type":"boolean","prefix":"12"},{"linkId":3382018,"text":"High-risk findings&nbsp;by stress testing","definition":false,"type":"boolean","prefix":"3"},{"linkId":3382024,"text":"New onset acute&nbsp;heart failure (HF) by physical examination or CXR","definition":false,"type":"boolean","prefix":"9"},{"linkId":3382025,"text":"Newly discovered left ventricular (LV) systolic dysfunction","definition":false,"type":"boolean","prefix":"10"},{"linkId":3382017,"text":"Non-ST-elevation myocardial infarction (NSTEMI) or unstable angina by history (urgent)","definition":false,"type":"boolean","prefix":"2"},{"linkId":3382021,"text":"Post myocardial infarction (MI)&nbsp;angina or ischemia","definition":false,"type":"boolean","prefix":"6"},{"linkId":3382022,"text":"Post revascularization","definition":false,"type":"boolean","prefix":"7"},{"linkId":3382016,"text":"ST-elevation&nbsp;myocardial infarction (STEMI) (urgent)","definition":false,"type":"boolean","prefix":"1"},{"linkId":3382026,"text":"Valvular heart disease","definition":false,"type":"boolean","prefix":"11"},{"linkId":3382023,"text":"Ventricular arrhythmia","definition":false,"type":"boolean","prefix":"8"}]}]},{"linkId":"1906908|2","text":"Choose one:|current_question|","type":"group","definition":true,"prefix":"RADIO","item":[{"linkId":3382014,"text":"Age&nbsp;≥ 18","definition":false,"type":"boolean","prefix":"1"},{"linkId":3382015,"text":"Age&nbsp;&lt;&nbsp;18","definition":false,"type":"boolean","prefix":"2"}]}]}}}}
  );
  }
}

describe('SmartsheetComponent', () => {
  let component: SmartsheetComponent;
  let fixture: ComponentFixture<SmartsheetComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SmartsheetComponent ],
      imports: [HttpClientTestingModule, FormsModule,
        ReactiveFormsModule, AuthLibraryModule, CommonModule, TableModule,SelectModule,BrowserAnimationsModule,NoopAnimationsModule,
         BrowserModule,SortModule,RadioButtonModule,OptionModule,FormFieldModule],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      providers: [HttpHandler, HttpClient, OAuthLogger, OAuthService, UrlHelperService,
        { provide: MedicalReviewGraphqlServiceService, useClass: MockSmartSheetService }
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SmartsheetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should ngOnInit', () => {
    component.enableDownloadbtn=false;
    component.getSmartSheet();
    component.ngOnInit();
    expect(component.ngOnInit).toBeTruthy();
  });

  xit('should prepareAgeDropDown', () => {
    let selectedValue=525038
    component.selectedChoice=525038
    component.ageArray = [];
    component.indicationArray = [];
    component.recommendationIds=[{"id":525038,"response":{"data":{"getSmartSheetQuestion":{"smartSheetQuestionRes":{"resourceType":"Questionnaire","meta":{"tag":[{"code":"rel","display":"recommendation definition"},{"code":"title","display":"recommendation definition"},{"code":"href","display":"/caas/recommendationdefinitions/525038"}]},"item":[{"item":[{"text":"Age&nbsp;≥ 18","type":"display"},{"linkId":"3384732|1","text":"Age&nbsp;≥ 18|choice_to_next_question","type":"group","definition":false,"item":[]},{"linkId":"1908437|58","text":"Choose one:|next_question|","type":"group","definition":false,"prefix":"RADIO","item":[{"linkId":3384696,"text":"Abdominal Aortic Aneurysm (AAA)","definition":false,"type":"boolean","prefix":"1"},{"linkId":3384697,"text":"Abdominal Pain or Mass","definition":true,"type":"boolean","prefix":"2"},{"linkId":3384698,"text":"Abscess","definition":true,"type":"boolean","prefix":"3"},{"linkId":3384699,"text":"Adrenal Gland","definition":false,"type":"boolean","prefix":"4"},{"linkId":3384700,"text":"Ankylosing spondylitis (AS)","definition":false,"type":"boolean","prefix":"5"},{"linkId":3384701,"text":"Appendix","definition":false,"type":"boolean","prefix":"6"},{"linkId":3384702,"text":"Cryptorchidism","definition":false,"type":"boolean","prefix":"7"},{"linkId":3384703,"text":"Fever of Unknown Origin","definition":false,"type":"boolean","prefix":"8"},{"linkId":3384704,"text":"Gallbladder and Biliary System","definition":true,"type":"boolean","prefix":"9"},{"linkId":3384705,"text":"Gastrointestinal (GI) Tract, Upper and Lower","definition":false,"type":"boolean","prefix":"10"},{"linkId":3384706,"text":"Gynecological","definition":false,"type":"boolean","prefix":"11"},{"linkId":3384707,"text":"Hemorrhage or Trauma","definition":false,"type":"boolean","prefix":"12"},{"linkId":3384708,"text":"Hernia","definition":false,"type":"boolean","prefix":"13"},{"linkId":3384709,"text":"Known Cancer","definition":true,"type":"boolean","prefix":"14"},{"linkId":3384710,"text":"Liver and Hepatic System","definition":false,"type":"boolean","prefix":"15"},{"linkId":3384711,"text":"Pancreas","definition":false,"type":"boolean","prefix":"16"},{"linkId":3384712,"text":"Renal and Prostate and Genitourinary Tract","definition":false,"type":"boolean","prefix":"17"},{"linkId":3384713,"text":"Spleen","definition":false,"type":"boolean","prefix":"18"},{"linkId":3384714,"text":"None of the above","definition":false,"type":"boolean","prefix":"19"}]},{"text":"next_question_choices","item":[{"linkId":3384705,"text":"Gastrointestinal (GI) Tract, Upper and Lower","definition":false,"type":"boolean","prefix":"10"}]}]},{"linkId":"1908436|3","text":"Choose one:|current_question|","type":"group","definition":false,"prefix":"RADIO","item":[{"linkId":3384732,"text":"Age&nbsp;≥ 18","definition":false,"type":"boolean","prefix":"1"},{"linkId":3384733,"text":"Age&nbsp;&lt;&nbsp;18","definition":false,"type":"boolean","prefix":"2"}]}]}}}}}]
    component.prepareAgeDropDown(selectedValue);
    expect(component.prepareAgeDropDown).toBeTruthy();
  });

  it('should radioSelect', () => {
    component.enableDownloadbtn=true;
    component.recommendationIds = [];
    component.ageArray = [];
    let selectedValue=524571
    component.selectedChoice = 524571;
    component.recommendationIds=[{"id":524571,"response":{"data":{"getSmartSheetQuestion":{"smartSheetQuestionRes":{"resourceType":"Questionnaire","meta":{"tag":[{"code":"rel","display":"recommendation definition"},{"code":"title","display":"recommendation definition"},{"code":"href","display":"/caas/recommendationdefinitions/524571"}]},"item":[{"item":[{"text":"Age&nbsp;≥ 18","type":"display"},{"linkId":"3382014|1","text":"Age&nbsp;≥ 18|choice_to_next_question","type":"group","definition":false,"item":[]},{"linkId":"1906909|4","text":"Choose one:|next_question|","type":"group","definition":false,"prefix":"RADIO","item":[{"linkId":3382016,"text":"ST-elevation&nbsp;myocardial infarction (STEMI) (urgent)","definition":true,"type":"boolean","prefix":"1"},{"linkId":3382017,"text":"Non-ST-elevation myocardial infarction (NSTEMI) or unstable angina by history (urgent)","definition":true,"type":"boolean","prefix":"2"},{"linkId":3382018,"text":"High-risk findings&nbsp;by stress testing","definition":true,"type":"boolean","prefix":"3"},{"linkId":3382019,"text":"Canadian Cardiovascular Society (CCS) Class III or IV angina by history","definition":true,"type":"boolean","prefix":"4"},{"linkId":3382020,"text":"Canadian Cardiovascular Society (CCS)&nbsp;Class II angina by history or New York Heart Association Class II heart failure (HF) by history or physical examination","definition":true,"type":"boolean","prefix":"5"},{"linkId":3382021,"text":"Post myocardial infarction (MI)&nbsp;angina or ischemia","definition":false,"type":"boolean","prefix":"6"},{"linkId":3382022,"text":"Post revascularization","definition":true,"type":"boolean","prefix":"7"},{"linkId":3382023,"text":"Ventricular arrhythmia","definition":false,"type":"boolean","prefix":"8"},{"linkId":3382024,"text":"New onset acute&nbsp;heart failure (HF) by physical examination or CXR","definition":true,"type":"boolean","prefix":"9"},{"linkId":3382025,"text":"Newly discovered left ventricular (LV) systolic dysfunction","definition":true,"type":"boolean","prefix":"10"},{"linkId":3382026,"text":"Valvular heart disease","definition":true,"type":"boolean","prefix":"11"},{"linkId":3382027,"text":"Constrictive pericarditis","definition":true,"type":"boolean","prefix":"12"},{"linkId":3382028,"text":"Congenital heart disease","definition":true,"type":"boolean","prefix":"13"},{"linkId":3382029,"text":"None of the above","definition":false,"type":"boolean","prefix":"14"}]},{"text":"next_question_choices","item":[{"linkId":3382019,"text":"Canadian Cardiovascular Society (CCS) Class III or IV angina by history","definition":false,"type":"boolean","prefix":"4"},{"linkId":3382020,"text":"Canadian Cardiovascular Society (CCS)&nbsp;Class II angina by history or New York Heart Association Class II heart failure (HF) by history or physical examination","definition":false,"type":"boolean","prefix":"5"},{"linkId":3382028,"text":"Congenital heart disease","definition":false,"type":"boolean","prefix":"13"},{"linkId":3382027,"text":"Constrictive pericarditis","definition":false,"type":"boolean","prefix":"12"},{"linkId":3382018,"text":"High-risk findings&nbsp;by stress testing","definition":false,"type":"boolean","prefix":"3"},{"linkId":3382024,"text":"New onset acute&nbsp;heart failure (HF) by physical examination or CXR","definition":false,"type":"boolean","prefix":"9"},{"linkId":3382025,"text":"Newly discovered left ventricular (LV) systolic dysfunction","definition":false,"type":"boolean","prefix":"10"},{"linkId":3382017,"text":"Non-ST-elevation myocardial infarction (NSTEMI) or unstable angina by history (urgent)","definition":false,"type":"boolean","prefix":"2"},{"linkId":3382021,"text":"Post myocardial infarction (MI)&nbsp;angina or ischemia","definition":false,"type":"boolean","prefix":"6"},{"linkId":3382022,"text":"Post revascularization","definition":false,"type":"boolean","prefix":"7"},{"linkId":3382016,"text":"ST-elevation&nbsp;myocardial infarction (STEMI) (urgent)","definition":false,"type":"boolean","prefix":"1"},{"linkId":3382026,"text":"Valvular heart disease","definition":false,"type":"boolean","prefix":"11"},{"linkId":3382023,"text":"Ventricular arrhythmia","definition":false,"type":"boolean","prefix":"8"}]}]},{"linkId":"1906908|2","text":"Choose one:|current_question|","type":"group","definition":true,"prefix":"RADIO","item":[{"linkId":3382014,"text":"Age&nbsp;≥ 18","definition":false,"type":"boolean","prefix":"1"},{"linkId":3382015,"text":"Age&nbsp;&lt;&nbsp;18","definition":false,"type":"boolean","prefix":"2"}]}]}}}}}]
    component.radioSelect(selectedValue);
    expect(component.radioSelect).toBeTruthy();
  });

  it('should onIndicationChange', () => {
    let event='3382027'
    let rowId=524571
    component.onIndicationChange(event,rowId);
    expect(component.onIndicationChange).toBeTruthy();
  });
  
  it('should call printSmartSheet', () => {
    let myObject: any = { recommendation_def_id: '530793', product_cid: 'ISX', organization: 'UnitedHealthcare'
     , age: '3458260', selected_indication: '3458248'};
    component.printSmartSheet();
    expect(component.printSmartSheet).toBeTruthy();
  });

});
