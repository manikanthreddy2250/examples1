import { AfterContentChecked, AfterViewInit, Component, Input, OnInit, ViewChild } from '@angular/core';
import { EcpUclTableDataSource } from '@ecp/angular-ui-component-library/table';
import { EcpUclSort } from '@ecp/angular-ui-component-library/sort';
import { EcpUclModal } from '@ecp/angular-ui-component-library/modal';
import { getEnvVar } from "../../services/environment/envVarUtil";
import { GUIDELINES_FUNCTION_API_URL } from "../../../config/config-constants";
import { HttpClient, HttpHeaders, HttpParams, HttpParamsOptions } from "@angular/common/http";
import { MedicalReviewGraphqlServiceService } from '../../services/um/service/clinical-guidelines/medical-review-graphql-service/medical-review-graphql-service.service';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'um-smartsheet',
  templateUrl: './smartsheet.component.html',
  styleUrls: ['./smartsheet.component.scss']
})
export class SmartsheetComponent implements OnInit, AfterContentChecked {
  ecpData: EcpUclTableDataSource<any>;
  @ViewChild(EcpUclSort) sort: EcpUclSort;
  @Input() subsetId: number;
  @Input() processTaskExecutionID
  sticky: boolean;
  smartSheetForm: FormGroup = new FormGroup({
    age: new FormControl(null),
    indication: new FormControl(null),
  });
  data = [];
  selectIndication = 'ALL INDICATIONS';
  recommendationIds = [];
  selectedValue: string;
  selectedIndication: string;
  selectEpisode = 'Select Medical Review';
  ageArray = [];
  age: string;
  selectedDecision: string;
  headers = ['printSelect', 'requestedService', 'age', 'indication'];
  selectedChoice: number;
  indicationArray = [];
  indication: string = '';
  @ViewChild(EcpUclModal, { static: true })
  modal: EcpUclModal;
  count: number;
  enableDownloadbtn = false;
  downloadPDF='Download PDF'

  constructor(private readonly medicalReviewGraphqlServiceService: MedicalReviewGraphqlServiceService,
    private readonly http: HttpClient,) {
    this.sticky = false;
  }

  ngOnInit() {
    this.enableDownloadbtn = false;
    this.getSmartSheet();
  }

  ngAfterContentChecked() {
    this.ecpData = new EcpUclTableDataSource(this.data);
    this.ecpData.sort = this.sort;
  }

  getSmartSheet() {
    const subsetId = 370893
    this.recommendationIds = [];
    this.medicalReviewGraphqlServiceService.getSmartSheetData(this.subsetId ? this.subsetId : subsetId).subscribe(
      (resp: any) => {
        const res = resp.data.getSmartSheet.smartSheetRes;
        this.count = resp.data.getSmartSheet.smartSheetRes.total;
        const entry = res.entry;
        entry.forEach((element: any) => {
          this.data.push({
            "id": element.id,
            "requestedService": element.description, value: element.description, disabled: false
          })
          let response: any;
        });
        console.log("resp..." + JSON.stringify(resp));
      }, err => {
      });
  }

  prepareAgeDropDown(selectedValue){
    this.ageArray = [];
    this.indicationArray = [];
    console.log("this.selectedChoice.."+JSON.stringify(this.selectedChoice));
    console.log("this.selectedValue.."+JSON.stringify(selectedValue));
    this.recommendationIds.forEach((element: any) => {
      if (this.selectedChoice === element.id) {
        const item = element?.response?.data?.getSmartSheetQuestion?.smartSheetQuestionRes?.item;
        console.log("item in onChange..." + JSON.stringify(item))
        item.forEach((element: any) => {
          if (!element.linkId) {
            const itemArr = element?.item
            for (let k = 0; k < itemArr.length; k++) {
              if (itemArr[k]?.text && itemArr[k].text.includes('choice_to_next_question')) {
                const textArr = itemArr[k].text?.split('|');
                const text = textArr[0] ;
                const linkIdArr = itemArr[k].linkId?.split('|');
                const linkId = linkIdArr[0] ;
                this.ageArray.push({ name: text, value: linkId });
              }
            }
          }
        });
      }
    });
    this.onChange(this.ageArray[0].value, selectedValue);
    this.smartSheetForm = new FormGroup({
      age: new FormControl(this.ageArray[0].value),
      indication: new FormControl(null),
    });
  }

  radioSelect(selectedValue) {
    this.enableDownloadbtn = true;
    this.recommendationIds = [];
    this.ageArray = [];
    this.selectedChoice = selectedValue;
    console.log("selectedValue" + selectedValue);
    let response;
    this.medicalReviewGraphqlServiceService.getSmartSheetQuestionData(selectedValue).subscribe(
      (resp: any) => {
        response = resp;
        console.log("question response" + JSON.stringify(resp));
        const recommendationResponse = resp.data.getSmartSheetQuestion.smartSheetQuestionRes;
        this.recommendationIds.push({ id: selectedValue, response: response });
        this.prepareAgeDropDown(this.selectedChoice);
      }, err => {
      });
  }

  onIndicationChange(event: string, rowId: number) {
    this.indication = event;
    console.log("event....onIndicationChange" + JSON.stringify(event));
    console.log("rowId..onIndicationChange.." + JSON.stringify(rowId));
  }


  onChange(event: string, rowId: number) {
    this.age = event;
    this.indicationArray = [];
    this.selectIndication = 'ALL INDICATIONS';
    console.log("rowId.onChange..." + JSON.stringify(rowId));
    console.log("this.selectedChoice..." + JSON.stringify(this.selectedChoice));
    console.log("event.." + JSON.stringify(event));
    this.recommendationIds.forEach((element: any) => {
      if (this.selectedChoice === element.id) {
        const item = element?.response?.data?.getSmartSheetQuestion?.smartSheetQuestionRes?.item;
        console.log("item in onChange..." + JSON.stringify(item))
        item.forEach((element: any) => {
          if (!element.linkId) {
            const itemArr = element?.item
            for (let k = 0; k < itemArr.length; k++) {
              if (itemArr[k]?.linkId && itemArr[k].linkId.includes(event)) {
                this.prepareIndicationDropDown(itemArr);
              }
            }
          }
        });
      }
    });

  }

  prepareIndicationDropDown(itemArr) {
    this.indicationArray = [];
    let indicationChoices = [];
    this.indication = '';
    console.log("itemArr...prepareIndicationDropDown " + JSON.stringify(itemArr));
    for (let k = 0; k < itemArr.length; k++) {
      if (itemArr[k]?.text && itemArr[k]?.text.includes('next_question_choices')) {
        indicationChoices = itemArr[k]?.item;
      }
    }
    console.log("indicationChoices.." + JSON.stringify(indicationChoices));
    this.indicationArray.push({ name: 'All Indications', value: 0 });
    for (let k = 0; k < indicationChoices.length; k++) {
      this.indicationArray.push({ name: indicationChoices[k].text, value: indicationChoices[k].linkId });
    }

  }

  printSmartSheet() {
    const myObject: any = {
      recommendation_def_id: this.selectedChoice, product_cid: 'ISX', organization: 'UnitedHealthcare'
      , age: this.age, selected_indication: this.indication
    };
    const httpParams: HttpParamsOptions = { fromObject: myObject } as HttpParamsOptions;
    const httpOptions: any = {
      headers: {
        'Accept': 'application/pdf',
      },
      params: new HttpParams(httpParams),
      responseType: 'arraybuffer'
    };
    this.http
      .get(
        `${getEnvVar(GUIDELINES_FUNCTION_API_URL)}/smartsheet/report`,
        httpOptions
      )
      .subscribe((res: any) => {
        var blob = new Blob([res], { type: 'application/pdf' });
        if (blob && blob.size > 0) {
          var blobURL = URL.createObjectURL(blob);
          window.open(blobURL);
        }
      });
  }

}
