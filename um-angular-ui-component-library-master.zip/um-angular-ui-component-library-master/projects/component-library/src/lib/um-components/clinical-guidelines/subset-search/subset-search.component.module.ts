import {NgModule, NO_ERRORS_SCHEMA,CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { TableModule } from '@ecp/angular-ui-component-library/table';
import { SortModule } from '@ecp/angular-ui-component-library/sort';
import { TabsModule } from '@ecp/angular-ui-component-library/tabs';
import { MatGridListModule } from '@angular/material/grid-list';
import { ButtonModule } from '@ecp/angular-ui-component-library/button';
import { IconsModule } from '@ecp/angular-ui-component-library/icons';
import { MatIconModule } from '@angular/material/icon';
import {  SubsetSearchComponent } from './subset-search.component'
import { CardModule} from '@ecp/angular-ui-component-library/card';
import { PaginatorModule } from '@ecp/angular-ui-component-library/paginator';
import {HttpClient, HttpClientModule} from '@angular/common/http';
// import { ProgressModule } from '@ecp/angular-ui-component-library/progress';
import {AuthLibraryModule} from '@ecp/auth-library';
import {APP_BASE_HREF} from '@angular/common';
import {UserAuthService} from '../../services/auth/user.service';
import {MedicalReviewTreeModule} from "../medical-review-tree/medical-review-tree.module";
import {ProgressSpinnerModule} from "@ecp/angular-ui-component-library/progress-spinner";

@NgModule({
  declarations: [
    SubsetSearchComponent
  ],
    imports: [
        CommonModule,
        BrowserModule,
        BrowserAnimationsModule,
        CardModule,
        MatGridListModule,
        MatIconModule,
        TableModule,
        ButtonModule,
        TabsModule,
        IconsModule,
        SortModule,
        PaginatorModule,
        HttpClientModule,
        AuthLibraryModule,
        MedicalReviewTreeModule,
        ProgressSpinnerModule,
    ],

  exports: [
    SubsetSearchComponent
  ],
  providers: [UserAuthService, HttpClient],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class SubsetSearchModule { }
