/*
 import { async, ComponentFixture, TestBed } from '@angular/core/testing';

 import { SubsetSearchComponent } from './subset-search.component';
 import { HttpClient, HttpHandler, HttpClientModule } from "@angular/common/http";
 import {BpmnStartProcessService} from "../../services/um/service/clinical-guidelines/medical-reviews/bpmn-start-process.service";
 import { HttpClientTestingModule } from "@angular/common/http/testing";
 import {NO_ERRORS_SCHEMA, Injectable, CUSTOM_ELEMENTS_SCHEMA, ChangeDetectorRef} from '@angular/core';
 import { MembersearchGraphqlService } from 'projects/component-library/src/lib/um-components/services/um/service/clinical-guidelines/member-search/membersearch-graphql.service';
 import { MedicalReviewGraphqlServiceService } from '../../services/um/service/clinical-guidelines/medical-review-graphql-service/medical-review-graphql-service.service';
 import { AuthLibraryModule, MicroProductAuthService, AuthService, OAuthInitService } from "@ecp/auth-library";
 import { UserAuthService } from '../../services/auth/user.service';
 import { of, Observable } from 'rxjs';
 import {SubsetSearchModule} from "./subset-search.component.module";

 const subsetItems = [{ "id": "AISD0296", "description": "Infection: General", "versionDesc": "InterQual 2020", "productDesc": "LOC:Acute Adult", "uniqueId": 362768, "productId": "AISD", "versionId": "RM20", "subsetType": "NDT" }, { "id": "AISD0285", "description": "Electrolyte or Mineral Imbalance", "versionDesc": "InterQual 2020", "productDesc": "LOC:Acute Adult", "uniqueId": 353650, "productId": "AISD", "versionId": "RM20", "subsetType": "QNA" }]
 const tag = [{
   "code": "productHasSmartSheets",
   "display": false
 },
   {
     "code": "versionDesc",
     "display": "InterQual 2020"
   }]
 const subsetResponse = {
  "data": {
      "getSubsetSearch": {
          "subsetSearchRes": {
              "resourceType": "Bundle",
              "entry": [
                  {
                      "resourceType": "Questionnaire",
                      "id": "~IQ6.01A_7997",
                      "description": "Total Joint Replacement (TJR), Hip",
                      "meta": {
                          "tag": [
                              {
                                  "code": "productHasSmartSheets",
                                  "display": false
                              },
                              {
                                  "code": "versionDesc",
                                  "display": "InterQual 2020"
                              },
                              {
                                  "code": "minorVersion",
                                  "display": 3
                              },
                              {
                                  "code": "revision",
                                  "display": null
                              },
                              {
                                  "code": "current",
                                  "display": false
                              },
                              {
                                  "code": "reviewClassID",
                                  "display": null
                              },
                              {
                                  "code": "productDesc",
                                  "display": "CP:Procedures"
                              },
                              {
                                  "code": "uniqueId",
                                  "display": 366764
                              },
                              {
                                  "code": "productId",
                                  "display": "PROCEDURES"
                              },
                              {
                                  "code": "versionId",
                                  "display": "RM20"
                              },
                              {
                                  "code": "subsetType",
                                  "display": "QNA"
                              }
                          ]
                      }
                  },
                  {
                      "resourceType": "Questionnaire",
                      "id": "ISP6743",
                      "description": "Removal and Replacement, Total Joint Replacement (TJR), Hip",
                      "meta": {
                          "tag": [
                              {
                                  "code": "productHasSmartSheets",
                                  "display": false
                              },
                              {
                                  "code": "versionDesc",
                                  "display": "InterQual 2020"
                              },
                              {
                                  "code": "minorVersion",
                                  "display": 0
                              },
                              {
                                  "code": "revision",
                                  "display": null
                              },
                              {
                                  "code": "current",
                                  "display": false
                              },
                              {
                                  "code": "reviewClassID",
                                  "display": null
                              },
                              {
                                  "code": "productDesc",
                                  "display": "CP:Procedures"
                              },
                              {
                                  "code": "uniqueId",
                                  "display": 354022
                              },
                              {
                                  "code": "productId",
                                  "display": "PROCEDURES"
                              },
                              {
                                  "code": "versionId",
                                  "display": "RM20"
                              },
                              {
                                  "code": "subsetType",
                                  "display": "QNA"
                              }
                          ]
                      }
                  }
              ],
              "type": "searchset",
              "total": 2
          }
      }
  }
}

 @Injectable()
 class UserAuthServiceMock {

   getUserID() {
     return 'TESTUSERID';
   }

   isLocalHost() {
     return false;
   }

   getActiveClientOrg() {
     return 'ecp'
   }

   getActiveUserRole() {
     return 'sys_admin'
   }

   getAltUserID() {
     return 'test';
   }

   getUserHasuraRole() {
     return 'test'
   }
 }

 @Injectable()
  class MedicalReviewGraphqlServiceServiceMock {
    getSubsetSearchData(productCids,version,codes){
      return of(subsetResponse)
    }

  }

 @Injectable()
 class MockHttpClient {
   post(url: string, body: any | null, options?: any) {
     return of({
       "data": {
         "getHscAuthDetails": {
           "hsc": [
             {
               "hsc_id": 11186,
               "creat_dttm": "2021-01-11T13:56:32.764",
               "creat_user_id": "000732160",
               "indv_id": 503926748,
               "indv_key_typ_ref_id": 2757,
               "indv_key_val": "16440436900",
               "mbr_cov_dtl": {
                 "indv_id": 503926748,
                 "pol_nbr": "0128855",
                 "cov_eff_dt": "2013-01-01",
                 "cov_end_dt": "9999-12-31",
                 "mbr_cov_id": 96963692,
                 "productCode": 214,
                 "indv_key_val": "16440436900",
                 "productCatgyTpe": null,
                 "coverageTypeDesc": "Medical",
                 "indv_key_typ_ref_id": 2757,
                 "claim_platform_ref_Id": 363
               },
               "hsc_sts_ref_id": 19275,
               "flwup_cntc_dtl": {
                 "Primary_Cntct": {
                   "department": "Admitting",
                   "email": null,
                   "phone": "232-998-9898",
                   "fax": null,
                   "creat_dttm": "2021-01-11T13:56:33.024Z",
                   "chg_dttm": "2021-01-11T13:58:08.875Z",
                   "creat_user_id": "000732160",
                   "role": "Member",
                   "name": "dfs"
                 }
               },
               "rev_prr_ref_id": 3754,
               "rev_prr_ref_cd": {
                 "ref_id": 3754,
                 "ref_cd": "1",
                 "ref_desc": "Routine",
                 "ref_dspl": "Routine"
               },
               "srvc_set_ref_id": 3737,
               "srvc_set_ref_cd": {
                 "ref_id": 3737,
                 "ref_cd": "1",
                 "ref_desc": "Inpatient",
                 "ref_dspl": "Inpatient"
               },
               "hsc_keys": [
                 {
                   "hsc_id": 11186,
                   "hsc_key_val": "cfc5ae0c-5414-11eb-b2ca-66042b9aa086",
                   "hsc_key_typ_ref_id": 19517
                 }
               ],
               "hsc_srvcs": [],
               "hsc_facls": [
                 {
                   "actul_admis_dttm": null,
                   "actul_dschrg_dttm": null,
                   "expt_admis_dt": "2021-01-12",
                   "expt_dschrg_dt": "2021-01-20",
                   "plsrv_ref_id": 3743,
                   "plsrv_ref_cd": {
                     "ref_id": 3743,
                     "ref_cd": "21",
                     "ref_desc": "Acute Hospital",
                     "ref_dspl": "Acute Hospital"
                   },
                   "srvc_desc_ref_id": 4347,
                   "srvc_desc_ref_cd": {
                     "ref_id": 4347,
                     "ref_cd": "1",
                     "ref_desc": "Scheduled",
                     "ref_dspl": "Scheduled"
                   },
                   "srvc_dtl_ref_id": 4296,
                   "srvc_dtl_ref_cd": {
                     "ref_id": 4296,
                     "ref_cd": "1",
                     "ref_desc": "Medical",
                     "ref_dspl": "Medical"
                   }
                 }
               ],
               "hsc_diags": [
                 {
                   "hsc_diag_id": 3089,
                   "diag_cd": "R51",
                   "inac_ind": 0,
                   "diag_desc": "HEADACHE"
                 }
               ],
               "hsr_notes": [],
               "hsc_provs": [
                 {
                   "auto_aprv_ltr_ind": null,
                   "hsc_prov_id": 3695,
                   "chg_sys_ref_id": null,
                   "chg_user_id": "000732160",
                   "creat_sys_ref_id": null,
                   "creat_user_id": "000732160",
                   "data_qlty_iss_list": null,
                   "data_secur_rule_list": null,
                   "end_dt": null,
                   "hsc_prov_end_rsn_ref_id": null,
                   "ltr_opt_out_cc_ind": null,
                   "med_rec_nbr": null,
                   "ntwk_strg_rsn_ref_id": null,
                   "ntwk_sts_ref_id": null,
                   "prov_loc_affil_dtl": {
                     "providerDetails": {
                       "prov_id": 125,
                       "prov_key": [
                         {
                           "prov_key_val": "1699732990",
                           "prov_key_typ_ref_id": 2782
                         },
                         {
                           "prov_key_val": "123456",
                           "prov_key_typ_ref_id": 16333
                         },
                         {
                           "prov_key_typ_ref_id": 2783
                         }
                       ],
                       "prov_adr_id": 88538913
                     }
                   },
                   "prov_loc_affil_id": null,
                   "spcl_ref_id": 16696,
                   "strt_dt": null,
                   "telcom_adr_id": "3044424466",
                   "updt_ver_nbr": 0,
                   "hsc_prov_roles": [
                     {
                       "hsc_prov_id": 3695,
                       "prov_role_ref_id": 3764
                     }
                   ]
                 },
                 {
                   "auto_aprv_ltr_ind": null,
                   "hsc_prov_id": 3696,
                   "chg_sys_ref_id": null,
                   "chg_user_id": "000732160",
                   "creat_sys_ref_id": null,
                   "creat_user_id": "000732160",
                   "data_qlty_iss_list": null,
                   "data_secur_rule_list": null,
                   "end_dt": null,
                   "hsc_prov_end_rsn_ref_id": null,
                   "ltr_opt_out_cc_ind": null,
                   "med_rec_nbr": null,
                   "ntwk_strg_rsn_ref_id": null,
                   "ntwk_sts_ref_id": null,
                   "prov_loc_affil_dtl": {
                     "providerDetails": {
                       "prov_id": 125,
                       "prov_key": [
                         {
                           "prov_key_val": "1699732990",
                           "prov_key_typ_ref_id": 2782
                         },
                         {
                           "prov_key_val": "123456",
                           "prov_key_typ_ref_id": 16333
                         },
                         {
                           "prov_key_typ_ref_id": 2783
                         }
                       ],
                       "prov_adr_id": 88538913
                     }
                   },
                   "prov_loc_affil_id": null,
                   "spcl_ref_id": 16696,
                   "strt_dt": null,
                   "telcom_adr_id": "3044424466",
                   "updt_ver_nbr": 0,
                   "hsc_prov_roles": [
                     {
                       "hsc_prov_id": 3696,
                       "prov_role_ref_id": 3765
                     }
                   ]
                 }
               ]
             }
           ]
         }
       }
     });
   }

   get(url: string, options?: any) {
     return of(subsetResponse)
   }
 }

@Injectable()
 class MembersearchGraphqlServiceMock {

   getMemberDetailsData(indv_key_val: any, appName: string, dataDomain?: string) : Observable<any> {
     return of({ data: { v_indv_srch: [{ lst_nm: 'Hello', fst_nm: 'Mark' }] } })
   }

   getMemberCoverageDetailsData(mbrcovid: any, appName: string, dataDomain?: string): Observable<any> {
     const coverage = {
       "data": {
         "mbr_cov": [
           {
             "cov_eff_dt": "2019-04-01",
             "cov_end_dt": "2019-05-31",
             "lob_ref_id": 19973,
             "pol_nbr": "0905050",
             "pol_nm": null,
             "prdct_catgy_ref_id": null
           }
         ]
       }
     }
     return of(coverage)
   }
   getRefDescData(mbrcovid: any, appName: string, dataDomain?: string): Observable<any> {
     return of({ data: { ref: [{ ref_id: '1', ref_desc: 'IP', ref_dspl: 'Inpatient', ref_cd: 'Inpatient' }] } })
   }
 /!*  getIpFlowDMNRules(hscData: any, appName: any): Observable<any> {
     return of([{ "productCID": "PISD" }])
   }*!/
 }

 @Injectable()
 class MicroProductAuthServiceStub {
   getEcpClaims() {
     return {
       "x-ecp-claims": {
         "x-ecp-attrs": {},
         "x-ecp-alt-user-id": "",
         "x-ecp-cli-orgs": [{
           "org-id": "ecp",
           "func-roles": [{
             "role-name": "rules_admin",
             "appl-roles": ["autoapproval-dmn_deploy", "autorouting-dmn_deploy", "bpm_execute_all", "case_wf_mgmt_ui_read", "configuration-dmn_deploy", "example_dmn_grp_deploy", "health_srvc_delete", "icuerules-dmn_deploy", "memberblocking-dmn_deploy", "obsderivation-dmn_deploy", "programs-dmn_deploy", "rules_authoring_write", "siteofservice-dmn_deploy", "system_mgmt_user", "testharness-dmn_deploy", "um_intake_ui_read", "umintake_sos_mbr_elig_dmn_grp_deploy", "umintake_sos_prov_elig_dmn_grp_deploy"]
           }]
         }],
         "x-ecp-first-name": "Sahithya",
         "x-ecp-type": "PASSWORD",
         "x-ecp-user-id": "001173408",
         "x-ecp-email": "sahithya_sivaraju@optum.com",
         "x-ecp-last-name": "Pachipulusu Sivaraju",
         "x-ecp-source": "msid"
       },
       "https://hasura.io/jwt/claims": {
         "x-hasura-default-role": "autoapproval-dmn_deploy",
         "x-hasura-attrs": "{ }",
         "x-hasura-cli-org": "ecp",
         "x-hasura-user-id": "001173408",
         "x-hasura-func-role": "rules_admin",
         "x-hasura-allowed-roles": ["autoapproval-dmn_deploy", "autorouting-dmn_deploy", "bpm_execute_all", "case_wf_mgmt_ui_read", "configuration-dmn_deploy", "example_dmn_grp_deploy", "health_srvc_delete", "icuerules-dmn_deploy", "memberblocking-dmn_deploy", "obsderivation-dmn_deploy", "programs-dmn_deploy", "rules_authoring_write", "siteofservice-dmn_deploy", "system_mgmt_user", "testharness-dmn_deploy", "um_intake_ui_read", "umintake_sos_mbr_elig_dmn_grp_deploy", "umintake_sos_prov_elig_dmn_grp_deploy"]
       },
       "scope": "openid",
       "iss": "ecp-dev",
       "exp": 1603473684,
       "client_id": "ecp_platform"
     };
   }

   getUserRoles() {
     return 'Provider';
   }

   getEcpOrgId() {
     return 'TESTUSERID';
   }

   getEcpToken() {
     return 'testToken';
   }

   isLocalHost() {
     return false;
   }

   getHasuraRole() {
    return 'clinical_guidelines_md';
  }

 }

 describe('SubsetSearchComponent', () => {
   let component: SubsetSearchComponent;
   let fixture: ComponentFixture<SubsetSearchComponent>;

   beforeEach(async(() => {
     TestBed.configureTestingModule({
       declarations: [],
       imports: [HttpClientTestingModule, AuthLibraryModule, SubsetSearchModule],
       providers: [BpmnStartProcessService, ChangeDetectorRef,
         AuthService, OAuthInitService, { provide: HttpClient, useClass: MockHttpClient },
         { provide: MembersearchGraphqlService, useClass: MembersearchGraphqlServiceMock }, { provide: MicroProductAuthService, useClass: MicroProductAuthServiceStub },
         { provide: MedicalReviewGraphqlServiceService, useClass: MedicalReviewGraphqlServiceServiceMock }],
       schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
     })
       .compileComponents();
   }));

   beforeEach(() => {
     fixture = TestBed.createComponent(SubsetSearchComponent);
     component = fixture.componentInstance;
     /!*component.application = 'dummyName';
     component.hscId = '1186';*!/
    // component.envID = '1.0.0';
     component.subsetSearchDetailsJSON = [{
       "versionDesc": "InterQual 2020",
       "productDesc": "LOC:Acute Adult",
       "description": "Infection: General"
     }]
     fixture.detectChanges();
   });

   it('should create', () => {
     expect(component).toBeTruthy();
   });
   it('should call prepareMetaTagsObjects', () => {
     const item = {
       "resourceType": "Questionnaire",
       "id": "AISD0303",
       "description": "Hospital in the Home",
       "meta": {
         "tag": [
           {
             "code": "productHasSmartSheets",
             "display": false
           },
           {
             "code": "versionDesc",
             "display": "InterQual 2020"
           },
           {
             "code": "minorVersion",
             "display": 0
           },
           {
             "code": "revision",
             "display": null
           },
           {
             "code": "current",
             "display": true
           },
           {
             "code": "reviewClassID",
             "display": null
           },
           {
             "code": "productDesc",
             "display": "LOC:Acute Adult"
           },
           {
             "code": "uniqueId",
             "display": 353663
           },
           {
             "code": "productId",
             "display": "AISD"
           },
           {
             "code": "versionId",
             "display": "RM20"
           },
           {
             "code": "subsetType",
             "display": "NDT"
           }
         ]
       }
     }
     component.prepareMetaTagsObjects(item);
     expect(component.prepareMetaTagsObjects).toBeTruthy()
   });
/!*   failing please check and uncomment
  it('should ngOnInit', () => {
      component.subsetSearchDetailsJSON = [];
      component.srvcSetRefId = "3737";
      component.IP = "3737";
      expect(component.srvcSetRefId).toEqual(component.IP)
      expect(component.subsetSearchDetailsJSON).toBeDefined()
      component.ngOnInit();
      expect(component.ngOnInit).toBeTruthy()
    }); *!/

   it('should getCamundaDmnIpWorkFlow', () => {
     component.indvKeyVal = "1695373000"
     component.mbrcovid = "3737";
     component.subsetItems = subsetItems
     component.getCamundaDmnIpWorkFlow();
     expect(component.getCamundaDmnIpWorkFlow).toBeTruthy()
   });
   it('should getMemberCoverageDetails', () => {
     component.mbrcovid = "3737";
     component.getMemberCoverageDetails(component.mbrcovid);
     expect(component.getMemberCoverageDetails).toBeTruthy()
   });

  it('should call getCamundaDmnIpWorkFlow', async () => {
    component.indvKeyVal = "1695373000"
    component.mbrcovid = "3737";
    component.subsetItems = subsetItems
    const diagList = [{
      "hsc_diag_id": 3089,
      "diag_cd": "R51",
      "inac_ind": 0,
      "hscDiagDiagCdRef": [
        {
          "shrt_desc": "HEADACHE",
          "full_desc": "Headache",
          "cd_desc": "HEADACHE"
        }
      ]
    }];
    component.diagnosisDetails = diagList
    expect(component.diagnosisDetails).toEqual(diagList)
    component.getCamundaDmnIpWorkFlow();
    expect(component.getCamundaDmnIpWorkFlow).toBeTruthy()
  });
  it('should getLineOfBusinessTypeDesc', () => {
    component.getLineOfBusinessTypeDesc(65765);
    expect(component.getLineOfBusinessTypeDesc).toBeTruthy()
  });
  it('should getProductCID', () => {
    component.getProductCID(65765);
    expect(component.getProductCID).toBeTruthy()
  });
  it('should onStartReview', () => {
    const guidelineId = 'ASID0153';
    const version = 'RM20';
    component.showGuidelines = true;
    expect(component.showGuidelines).toEqual(true);
    component.onStartReview(guidelineId,version);
    expect(component.onStartReview).toBeTruthy()
  });

  it('should call getApiHeaders', () => {
    component.getApiHeaders('appName')
      expect(component.getApiHeaders).toBeTruthy();
    });

  it('should call getIpFlowDMNRules', () => {
      const dmnIpFlowReq = {
        "hsc": {
          "member": {
            "lineOfBusiness":"UHC E&I",
            "age": 31
          },
          "hscFacls": {
            "plsrvRefCd": "Acute Hospital"
          },
          "serviceSettingRef": "Inpatient",
          "submissionType": "Admission Review",
          "tenant": "UHC"
        }
      };
      component.getIpFlowDMNRules(dmnIpFlowReq,'appName')
      expect(component.getIpFlowDMNRules).toBeTruthy();
    });
});
*/
