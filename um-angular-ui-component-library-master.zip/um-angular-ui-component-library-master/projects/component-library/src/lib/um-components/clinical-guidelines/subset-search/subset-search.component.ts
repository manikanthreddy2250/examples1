import { Component, OnInit,Output,EventEmitter, Input, ViewChild, ChangeDetectorRef, AfterContentChecked, AfterViewInit } from '@angular/core';
import { EcpUclTableDataSource } from '@ecp/angular-ui-component-library/table';
import { EcpUclPaginator } from '@ecp/angular-ui-component-library/paginator';
import { getEnvVar } from '../../services/environment/envVarUtil';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import * as moment from 'moment';
import { MedicalReviewGraphqlServiceService } from '../../services/um/service/clinical-guidelines/medical-review-graphql-service/medical-review-graphql-service.service';
import { EcpUclSort } from '@ecp/angular-ui-component-library/sort';
import {HscAuthDetailService} from "../../services/um/service/clinical-guidelines/medical-reviews/hsc-auth-detail.service";
import {MembersearchGraphqlService} from '../../services/um/service/clinical-guidelines/member-search/membersearch-graphql.service';
import { Observable } from 'rxjs';
import { GET_IP_DMN_RULE_URL_PATH } from '../../../config/config-constants';
import { map } from 'rxjs/operators';
import { UserAuthService } from '../../services/um/service/auth/user.service';
import { MicroProductAuthService } from '@ecp/auth-library';
@Component({
  selector: 'guidelines-subset-search',
  templateUrl: './subset-search.component.html',
  styleUrls: ['./subset-search.component.scss']
})
export class SubsetSearchComponent implements OnInit, AfterContentChecked, AfterViewInit {
  subsetSearchValue = [];
  @Input() hscId: any;
  @Input() application: any;
  @Input() processTaskExecutionID: string;
  @Input() subsetSearchDetailsJSON: any;
  @Input() isTransitionPlan = false;
  guidelineId: any;
  version: any;
  showSpinner = false;
  speed = '2s';
  showGuidelines = true;
  tableHeaders = ['description', 'productDesc', 'versionDesc', 'customize'];
  subsetSearchData = [];
  subsetItemListResponse = [];
  dataSource: EcpUclTableDataSource<any>;
  @ViewChild(EcpUclPaginator) paginator: EcpUclPaginator;
  @ViewChild(EcpUclSort) sort: EcpUclSort;
  @Output() start: EventEmitter<any> = new EventEmitter();
  pageOptions: number[];
  memberCoverageDetails: any;
  srvcSetRefId: any;
  primary: any;
  diagnosisDetails: any;
  procedureDetails: any;
  hscAuthDetailsResponse: any;
  isLoading: boolean;
  memberDetails = {};
  mbrCovDetails = {};
  age: number;
  subsetItemList = [];
  subsetItems = [];
  subsetObject = {};
  metaTags = [];
  indvKeyVal
  mbrcovid
  public IP = "3737";
  appName = 'case_wf_mgmt_ui';

  constructor(private cdref: ChangeDetectorRef, private readonly httpClient: HttpClient, private readonly hscAuthDetailService: HscAuthDetailService, private readonly membersearchGraphqlService: MembersearchGraphqlService,
    private readonly medicalReviewGraphqlServiceService: MedicalReviewGraphqlServiceService,private readonly userAuthService: UserAuthService,
    private readonly microProductAuth: MicroProductAuthService,) {
    this.pageOptions = [5, 10, 25];
  }

  ngOnInit() {
    this.showSpinner = true;
    if (this.subsetSearchDetailsJSON && this.subsetSearchDetailsJSON.length > 0) {
      this.subsetItems = this.subsetSearchDetailsJSON;
    } else {
      const hsc = {};
      hsc['hsc_id'] = parseInt(this.hscId);
      return  this.hscAuthDetailService.getHscAuthDetails({ 'hsc': hsc })
        .subscribe(
          res => {
            this.hscAuthDetailsResponse = res.data.getHscAuthDetails;
            this.memberCoverageDetails = this.hscAuthDetailsResponse['hsc'][0]['mbr_cov_dtl']
            this.srvcSetRefId = this.hscAuthDetailsResponse['hsc'][0]['srvc_set_ref_id']
            this.indvKeyVal = this.hscAuthDetailsResponse['hsc'][0]['indv_key_val']
            this.mbrcovid = this.hscAuthDetailsResponse.hsc[0].mbr_cov_dtl.mbr_cov_id
            this.diagnosisDetails = this.hscAuthDetailsResponse['hsc'][0]['hsc_diags']
            this.procedureDetails = this.hscAuthDetailsResponse['hsc'][0]['hsc_srvcs']
            this.isLoading = false;
            if (this.srvcSetRefId == this.IP) {
              this.getCamundaDmnIpWorkFlow()
            } else {
              this.dataSource = new EcpUclTableDataSource(this.subsetItems);
            }
            this.showSpinner = false;
          }
        );
    }
  }

  ngAfterContentChecked() {
    this.cdref.detectChanges();
  }

  ngAfterViewInit() {
    this.cdref.detectChanges();
  }

  async getMemberDetails(indv_key_val) {
    const memberDetailsData = await this.membersearchGraphqlService.getMemberDetailsData(indv_key_val, this.appName).toPromise();
    // this.memberDetails = memberDetailsData.data.v_indv_srch[0];
    return memberDetailsData.data.v_indv_srch[0];
  }

  async getMemberCoverageDetails(mbrcovid) {
    const mbrCovDetailsData = await this.membersearchGraphqlService.getMemberCoverageDetailsData(mbrcovid, this.appName).toPromise();
    //this.mbrCovDetails = mbrCovDetailsData.data.mbr_cov[0];
    return mbrCovDetailsData.data.mbr_cov[0];
  }

  async getLineOfBusinessTypeDesc(lob_ref_id) {
    const lineOfBusinessRes = await this.membersearchGraphqlService.getRefDescData(Number(lob_ref_id), this.appName).toPromise();
    return lineOfBusinessRes.data.ref[0].ref_dspl;
  }

  async getProductCID(dmnIpFlowReq) {
    try {
      const productCIDRes = await this.getIpFlowDMNRules(dmnIpFlowReq, this.appName).toPromise();
      return productCIDRes[0] ? productCIDRes[0]["productCID"] : '';
    } catch (error) {
      //  this.messageService.add(this.errorConfig); remove
    }
  }

  getApiHeaders(appName): HttpHeaders {
    const ecpClaims = this.microProductAuth.getEcpClaims();
    const orgId = ecpClaims?.['x-ecp-claims']?.['x-ecp-cli-orgs']?.[0]?.['org-id'];
    return new HttpHeaders()
      .set('Content-Type', 'application/json')
      .set('x-hasura-role', this.userAuthService.getUserHasuraRole(appName))
      .set('x-bpm-cli-org-id', this.userAuthService.getActiveClientOrg())
      .set('x-bpm-func-role', this.userAuthService.getActiveUserRole())
      .set('x-bpm-tenant-id', orgId + 'clinicalguidelinesuhcdmngrp')
      .set('Authorization', 'Bearer ' + this.microProductAuth.getEcpToken());
  }


  getIpFlowDMNRules(hscData: any, appName: any): Observable<any> {
    const httpIpDmnUrl = getEnvVar(GET_IP_DMN_RULE_URL_PATH);
    return this.httpClient.post(httpIpDmnUrl, hscData, { headers: this.getApiHeaders(appName) }).pipe(map((res) => res));
  }

  async getCamundaDmnIpWorkFlow() {
    this.memberDetails = await this.getMemberDetails(this.indvKeyVal)
    this.mbrCovDetails = await this.getMemberCoverageDetails(this.mbrcovid)
    this.isLoading = true
    const diagList = [];
    if (((this.diagnosisDetails) && (this.diagnosisDetails !== undefined) && (this.diagnosisDetails.length > 0))) {
      this.diagnosisDetails.forEach((item) => {
        if (item.diag_cd !== null) {
          diagList.push(item.diag_cd);
        }
      });
    }
    const lineOfBusiness = await this.getLineOfBusinessTypeDesc(this.mbrCovDetails['lob_ref_id']);
    this.age = moment().diff(this.memberDetails['bth_dt'], 'years');

    const dmnIpFlowReq = {
      "hsc": {
        "member": {
          lineOfBusiness,
          "age": this.age
        },
        "hscFacls": {
          "plsrvRefCd": this.hscAuthDetailsResponse?.hsc[0]?.hsc_facls[0]?.plsrv_ref_cd?.ref_dspl
        },
        "serviceSettingRef": this.hscAuthDetailsResponse?.hsc[0]?.srvc_set_ref_cd?.ref_dspl,
        "submissionType": "Admission Review",
        "tenant": "UHC"
      }
    };
    const productCidOutput = await this.getProductCID(dmnIpFlowReq)

    const productCid = productCidOutput ? productCidOutput : '';
    const version = "RM20";
    const codes = diagList ? diagList[0] : '';


    this.medicalReviewGraphqlServiceService.getSubsetSearchData(productCid, version, codes, this.isTransitionPlan).subscribe(res => {
      this.subsetItemListResponse = res.data.getSubsetSearch.subsetSearchRes
      this.subsetItemList = this.subsetItemListResponse["entry"];
      this.subsetItemList.forEach(item => {
        this.prepareMetaTagsObjects(item);
      });
      this.dataSource = new EcpUclTableDataSource(this.subsetItems);
      this.dataSource.sort = this.sort;
      this.dataSource.paginator = this.paginator;
    })
  }
  prepareMetaTagsObjects(metaObj) {
    this.subsetObject = {}
    const id = metaObj.id
    this.subsetObject["id"] = id
    const description = metaObj.description
    this.subsetObject["description"] = description
    this.metaTags = metaObj["meta"]["tag"]
    this.metaTags.forEach(itemtag => {
      if (itemtag["code"] === "versionDesc") {
        this.subsetObject["versionDesc"] = itemtag["display"]
      }
      if (itemtag["code"] === "productDesc") {
        this.subsetObject["productDesc"] = itemtag["display"]
      }
      if (itemtag["code"] === "uniqueId") {
        this.subsetObject["uniqueId"] = itemtag["display"]
      }
      if (itemtag["code"] === "productId") {
        this.subsetObject["productId"] = itemtag["display"]
      }
      if (itemtag["code"] === "versionId") {
        this.subsetObject["versionId"] = itemtag["display"]
      }
      if (itemtag["code"] === "subsetType") {
        this.subsetObject["subsetType"] = itemtag["display"]
      }
    })
    this.subsetItems.push(this.subsetObject);
  }

  onStartReview(guidelineId, version){
    this.showGuidelines = false;
    const medicalReviewTreeInput = {
      guidelineId,
      version
    };
    this.start.emit(medicalReviewTreeInput);
  }
}
