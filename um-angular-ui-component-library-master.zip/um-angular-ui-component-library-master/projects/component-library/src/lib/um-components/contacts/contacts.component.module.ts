import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import {BrowserAnimationsModule, NoopAnimationsModule} from '@angular/platform-browser/animations';
import { TableModule } from '@ecp/angular-ui-component-library/table';
import { SortModule } from '@ecp/angular-ui-component-library/sort';
import { TabsModule } from '@ecp/angular-ui-component-library/tabs';
import { MatGridListModule } from '@angular/material/grid-list';
import { ButtonModule } from '@ecp/angular-ui-component-library/button';
import { IconsModule } from '@ecp/angular-ui-component-library/icons';
import { MatIconModule } from '@angular/material/icon';
import { CardModule} from '@ecp/angular-ui-component-library/card';
import {HttpClientModule} from '@angular/common/http';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {AuthLibraryModule} from '@ecp/auth-library';
import { SelectModule } from '@ecp/angular-ui-component-library/select';
import { FormFieldModule } from '@ecp/angular-ui-component-library/form-field';
import { OptionModule } from '@ecp/angular-ui-component-library/option';
import {ContactsComponent} from "./contacts.component";
import {InputModule} from '@ecp/angular-ui-component-library/input';
import {RadioButtonModule} from "@ecp/angular-ui-component-library/radio-button";
import {ButtonGroupModule} from '@ecp/angular-ui-component-library/button-group';

@NgModule({
  declarations: [
    ContactsComponent,
  ],
  imports: [
    CommonModule,
    BrowserModule,
    BrowserAnimationsModule,
    CardModule,
    MatGridListModule,
    MatIconModule,
    TableModule,
    ButtonModule,
    TabsModule,
    IconsModule,
    SortModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    AuthLibraryModule,
    SelectModule,
    OptionModule,
    NoopAnimationsModule,
    FormFieldModule,
    InputModule,
    RadioButtonModule,
    ButtonGroupModule
  ],
  exports: [
    ContactsComponent
  ],
  providers: []
})

export class ContactsModule { }
