import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {Injectable, ChangeDetectorRef} from '@angular/core';
import {CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA} from '@angular/compiler';
import {ContactsComponent} from './contacts.component';
import {HscGraphqlService} from '../services/um/service/hsc-update/hsc-graphql.service';
import {of} from 'rxjs';
import {UmintakeGraphqlService} from '../services/um/service/um-intake/umintake-graphql.service';
import {HscAuthDetailService} from '../services/um/service/clinical-guidelines/medical-reviews/hsc-auth-detail.service';
import {AuthLibraryModule} from '@ecp/auth-library';
import {ContactsModule} from './contacts.component.module';
import {FormControl, FormGroup, Validators} from '@angular/forms';

@Injectable()
class MockUmintakeGraphqlService {
  loadBaseRefNameDisplayData(baseRefName: string){
    const mockupResults = of({data: {ref: [{
          ref_id: '1234',
          ref_desc: 'TestBed',
          ref_dspl: 'Behavorial',
          inac_ind: '12',
          ref_cd: 'ABCD',
        }]}});
    return mockupResults.toPromise();
  }
}

@Injectable()
class MockHscAuthDetailService {
  getHscAuthDetails(hscAuthRequest: any) {
    const mockupResults = of({
      data: {
        hsc: [{
          flwup_cntc_dtl: [{
            department: '18677',
            phone: '123-456-7890',
            creat_user_id: 'ecp_engineer',
            fax: '323-555-1234',
            email: 'test@gmail.com',
            role: '2575',
            name: 'MJ contact',
            primaryContact: true
          }]
        }]
      }
    });
    return mockupResults.toPromise();
  }
}

@Injectable()
class MockHscGraphqlService {
  updateHsc(hscId: number, hscRecord: any, application: string) {
    const mockupResults = of({
      data: {
        hsc: [{
          hsc_id: 2134,
        }]
      }
    });
    return mockupResults.toPromise();
  }
}

describe('ContactsComponent', () => {
  let component: ContactsComponent;
  let fixture: ComponentFixture<ContactsComponent>;
  let cdref: ChangeDetectorRef;
  let authService: HscAuthDetailService;
  let hscService: HscGraphqlService;

  const contacts = [{
    department: '18677',
    phone: '123-456-7890',
    creat_user_id: 'ecp_engineer',
    fax: '323-555-1234',
    email: 'test@gmail.com',
    role: '2575',
    name: 'MJ contact',
    primaryContact: true
  },
    {
      department: '18680',
      phone: '123-456-7890',
      creat_user_id: 'ecp_engineer',
      fax: '323-555-9999',
      email: 'test@gmail.com',
      role: '2579',
      name: 'KB contact',
      primaryContact: false
    }];

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [],
      imports: [AuthLibraryModule, ContactsModule],
      providers: [ChangeDetectorRef,
        {provide: UmintakeGraphqlService, useClass: MockUmintakeGraphqlService},
        {provide: HscAuthDetailService, useClass: MockHscAuthDetailService},
        {provide: HscGraphqlService, useClass: MockHscGraphqlService}],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContactsComponent);
    component = fixture.componentInstance;
    cdref = TestBed.inject(ChangeDetectorRef);
    authService = TestBed.inject(HscAuthDetailService);
    hscService = TestBed.inject(HscGraphqlService);
    fixture.detectChanges();
  });

  it ('should create', () => {
    expect(component).toBeTruthy();
  });

  it ('should call ngOnInit with provided JSON', () => {
    component.contactDetailsJSON = contacts;
    component.readOnly = true;
    const spy = spyOn(component, 'setContactCounters');
    component.ngOnInit();
    expect(spy).toHaveBeenCalled();
    expect(component.ngOnInit).toBeTruthy();
  });

  it ('should call ngOnInit with hscID', () => {
    component.contactDetailsJSON = [];
    component.hscId = 123455;
    component.ngOnInit();
    expect(component.ngOnInit).toBeTruthy();
  });

  it ('initialize table', () => {
    component.contacts = contacts;
    const spy = spyOn(component, 'setContactCounters');
    component.initializeTable();
    expect(component).toBeTruthy();
    expect(spy).toHaveBeenCalled();
    console.log('availableRecords::' + component.availableRecords);
    expect(component.availableRecords === 2).toBeTruthy();
    expect(component.disallowFurtherContacts).toBeFalse();

  });


  it ('should call Get hsc Details', () => {
    component.initGraphqlService();
    expect(component).toBeTruthy();
  });

  // it ('initGraphqlService2', () => {
  //   const spy = spyOn(component, 'initGraphqlService');
  //   component.initGraphqlService();
  //   expect(spy).toHaveBeenCalled();
  //   expect(component.contacts.length > 1);
  //   expect(component).toBeTruthy();
  //
  // });

  it ( 'add contact', () => {
    component.hscId = 12345;
    component.contacts = contacts;
    component.application = 'test-app';
    component.contactsForm = new FormGroup({
      fullName: new FormControl(['testName']),
      email: new FormControl(['test@this.com']),
      phone: new FormControl(['123-456-7789']),
      fax: new FormControl('123-456-9963'),
      role: new FormControl([1322]),
      department: new FormControl([1233]),
    });
    // const spy = spyOn(component, 'updateContact');
    component.updateFollowUpContact();
    // expect(spy).toHaveBeenCalled();
    expect(component.contactsForm.get('name') === null);
    expect(component.contactsForm.get('email') === null);
    expect(component.contactsForm.get('phone') === null);
    expect(component.contactsForm.get('fax') === null);
    expect(component.contactsForm.get('role') === null);
    expect(component.contactsForm.get('department') === null);
    expect(component).toBeTruthy();
  });

  it ( 'delete contact', () => {
    const record = {
      department: '18677',
      phone: '123-456-7890',
      creat_user_id: 'ecp_engineer',
      fax: '323-555-1234',
      email: 'test@gmail.com',
      role: '2575',
      name: 'MJ contact',
      primaryContact: true
    };
    component.contacts = contacts;
    const spy = spyOn(component, 'updateContact');
    console.log('beforeDelete::' + JSON.stringify(component.contacts));
    component.deleteContact(record);
    console.log('afterDelete::' + JSON.stringify(component.contacts));
    expect(component.contacts.length === 1);
    expect(component.contacts[0].primaryContact === true);
    expect(spy).toHaveBeenCalled();
    expect(component).toBeTruthy();
  });

  it ( 'update primary', () => {
    const record = {
      department: '18680',
      phone: '123-456-7890',
      creat_user_id: 'ecp_engineer',
      fax: '323-555-9999',
      email: 'test@gmail.com',
      role: '2579',
      name: 'KB contact',
      primaryContact: false
    };
    component.updatePrimary(record, true);
    expect(component).toBeTruthy();
  });

  it ('should call clear contacts', () => {
    component.clearContact();
    expect(component).toBeTruthy();
    expect(component.contactsForm.get('name') === null);
    expect(component.contactsForm.get('email') === null);
    expect(component.contactsForm.get('phone') === null);
    expect(component.contactsForm.get('fax') === null);
    expect(component.contactsForm.get('role') === null);
    expect(component.contactsForm.get('department') === null);
  });

  it ('setContactCounters', () => {
    component.contacts = contacts;
    component.setContactCounters();
    expect(component.availableRecords === 0).toBeTruthy();
    expect(component.disallowFurtherContacts).toBeTruthy();
  });

  it ('setContactCounters2', () => {
    component.contacts = [];
    component.setContactCounters();
    expect(component.availableRecords === 2).toBeTruthy();
    expect(component.disallowFurtherContacts).toBeFalse();
  });

  it ('setContactCounters3', () => {
    component.contacts = null;
    component.setContactCounters();
    expect(component.availableRecords === 2).toBeTruthy();
    expect(component.disallowFurtherContacts).toBeFalse();
  });

});
