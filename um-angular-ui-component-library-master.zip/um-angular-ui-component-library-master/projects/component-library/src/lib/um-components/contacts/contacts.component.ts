import {
  AfterContentChecked, AfterViewInit,
  ChangeDetectorRef,
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ViewChild
} from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { UmintakeGraphqlService } from '../services/um/service/um-intake/umintake-graphql.service';
import { EcpUclTableDataSource } from '@ecp/angular-ui-component-library/table';
import { EcpUclSort } from '@ecp/angular-ui-component-library/sort';
import { HscAuthDetailService } from '../services/um/service/clinical-guidelines/medical-reviews/hsc-auth-detail.service';
import { HscGraphqlService } from '../services/um/service/hsc-update/hsc-graphql.service';

@Component({
  selector: 'app-contacts-component',
  templateUrl: './contacts.component.html',
  styleUrls: ['./contacts.component.scss']
})
export class ContactsComponent implements OnInit, AfterContentChecked, AfterViewInit {
  @Input() readOnly: boolean;
  @Input() summaryViewOnly: boolean;
  @Input() contactDetailsJSON = [];
  @Input() hscId: number;
  @Input() application: string;
  contacts = [];
  maxAvailableRecords = 2;
  availableRecords;
  disallowFurtherContacts = false;
  required?: boolean;
  placeholder: string;
  disabled: boolean;
  type = 'text';
  variant?: 'primary' | 'secondary';
  validators = [];
  contactsForm: FormGroup;
  public roleTypes = [];
  public departmentTypes = [];
  private ROLE = 'functionRoleType';
  private DEPARTMENT = 'departmentType';
  isLoading: boolean;

  tableHeaders = ['name', 'phone', 'email', 'fax', 'role', 'department', 'primaryContact', 'delete'];

  configHeader = {
    name: 'Name',
    phone: 'Phone',
    fax: 'Fax',
    email: 'Email',
    role: 'Role',
    department: 'Department',
    primaryContact: '',
    delete: ''
  };

  dataSource: EcpUclTableDataSource<any>;
  @ViewChild(EcpUclSort) sort: EcpUclSort;

  constructor(public umintakeGraphqlService: UmintakeGraphqlService, private cdref: ChangeDetectorRef,
    private hscService: HscAuthDetailService, private hscGraphqlService: HscGraphqlService) {
    if (this.required) {
      this.validators.push(Validators.required)
    }
  }

  @Output() submitForm: EventEmitter<object> = new EventEmitter<object>();

  async ngOnInit(): Promise<void> {
    this.contactsForm = this.getDefaultAuthorizationForm();
    this.populateRole();
    this.populateDepartment();
    if (this.readOnly) {
      this.tableHeaders = ['name', 'phone', 'email', 'fax', 'role', 'department', 'primaryContact'];
    } else {
      this.tableHeaders = ['name', 'phone', 'email', 'fax', 'role', 'department', 'primaryContact', 'delete'];
    }
    if (this.contactDetailsJSON && this.contactDetailsJSON.length > 0) {
      this.contacts = this.contactDetailsJSON;
    } else {
      if (this.hscId) {
        await this.initGraphqlService();
      }
    }
    this.setContactCounters();
  }

  ngAfterViewInit() {
    this.initializeTable();
    this.cdref.detectChanges();
  }

  initializeTable() {
    try {
      if (this.contacts === null) {
        this.contacts = [];
      }
      console.log('initalizeTable::' + JSON.stringify(this.contacts));
      this.isLoading = false;
      this.dataSource = new EcpUclTableDataSource(this.contacts);
      this.dataSource.sort = this.sort;
    } catch (e) {
      console.error(`Error initializing contacts`);
    }
    this.setContactCounters();
  }

  async initGraphqlService(): Promise<void> {
    const hscID = this.hscId;
    const hsc = {
      hsc: {
        hsc_id: hscID
      }
    };

    this.hscService.getHscAuthDetails(hsc).toPromise()
      .then((response) => {
        if (response.data != null && response.data.getHscAuthDetails != null) {
          this.contacts = response.data.getHscAuthDetails.hsc[0].flwup_cntc_dtl;
        } else {
          this.contacts = [];
        }
        this.initializeTable();
      },
        (error) => {
          console.error(`Unable to load HSC Details`);
          this.contacts = [];
        });
  }

  ngAfterContentChecked() {
    // this.dataSource = new EcpUclTableDataSource(this.contacts);
    // this.dataSource.sort = this.sort;
    // this.cdref.detectChanges();
  }


  setContactCounters(): void {
    console.log('setContactCounters1::' + JSON.stringify(this.contacts));
    if (this.contacts != null) {
      this.availableRecords = this.maxAvailableRecords - this.contacts.length;
    } else {
      this.availableRecords = this.maxAvailableRecords;
    }
    this.disallowFurtherContacts = this.availableRecords <= 0;
  }

  populateRole() {
    this.roleTypes = [];
    this.umintakeGraphqlService.loadBaseRefNameDisplayData(this.application, this.ROLE).then((res) => {
      res.data.ref.forEach((item: { ref_id: number; ref_dspl: string; ref_desc: string; }) => {
        const roleTypeObj = {
          id: item.ref_id,
          name: item.ref_dspl,
          value: item.ref_id,
        };
        this.roleTypes.push(roleTypeObj);
      });
    });
  }

  populateDepartment() {
    this.departmentTypes = [];
    this.umintakeGraphqlService.loadBaseRefNameDisplayData(this.application, this.DEPARTMENT).then((res) => {
      res.data.ref.forEach((item: { ref_id: number; ref_dspl: string; ref_desc: string; }) => {
        const departmentTypeObj = {
          id: item.ref_id,
          name: item.ref_dspl,
          value: item.ref_id,
        };
        this.departmentTypes.push(departmentTypeObj);
      });
    });
  }

  async updateFollowUpContact() {
    try {
      const contact = {
        name: this.contactsForm.get('name').value,
        phone: this.contactsForm.get('phone').value.formattedString,
        fax: this.contactsForm.get('fax').value ? this.contactsForm.get('fax').value.formattedString : null,
        email: this.contactsForm.get('email').value ? this.contactsForm.get('email').value : null,
        role: this.contactsForm.get('role').value ? this.contactsForm.get('role').value.id.toString() : null,
        department: this.contactsForm.get('department').value ? this.contactsForm.get('department').value.id.toString() : null,
        primaryContact: !this.contacts || this.contacts.length == 0
      };

      let contactsToUpdate = [contact];
      if (this.contacts) {
        contactsToUpdate = JSON.parse(JSON.stringify(this.contacts));
        contactsToUpdate.push(contact);
      }
      await this.updateContact(contactsToUpdate);
    } catch (e) {
      console.log("Error in adding contact", e)
    }
  }

  private getDefaultAuthorizationForm(): FormGroup {
    return new FormGroup({
      name: new FormControl(null, Validators.required),
      email: new FormControl(null, Validators.pattern('^[^\\s@]+@[^\\s@]+\\.[^\\s@]{2,}$')),
      phone: new FormControl(null, Validators.compose([Validators.required])),
      fax: new FormControl(null),
      role: new FormControl(null),
      department: new FormControl(null),
    });
  }

  checknumber(number) {
    if (number) {
      const type = new RegExp('[0-9]{3}-[0-9]{3}-[0-9]{4}');
      return type.test(number);
    }
    return true;
  }

  private clearForm(): void {
    this.contactsForm.reset();
  }

  clearContact(): void {
    this.clearForm();
  }

  async deleteContact(record: any) {
    try {
      let contactsToUpdate = [];
      const contactsToUpdateTemp = this.contacts.filter(obj => obj !== record);
      if (contactsToUpdateTemp.length > 0) {
        contactsToUpdate = JSON.parse(JSON.stringify(contactsToUpdateTemp));
        contactsToUpdate[0].primaryContact = true;
      }
      await this.updateContact(contactsToUpdate);
    } catch (e) {
      console.log("Error in deleting contact", e);
    }
  }

  async updatePrimary(record: any, primaryInd: boolean) {
    try {
      this.contacts.forEach(ele => {
        ele.primaryContact = !primaryInd;
      })
      this.dataSource = new EcpUclTableDataSource(this.contacts);
      this.dataSource.sort = this.sort;
      record.primaryContact = primaryInd;
      await this.updateData();
    } catch (e) {
      console.log("Error in updating primary field in contact", e)
    }
  }

  async updateData() {
    this.updateContact(this.contacts);
  }

  async updateContact(contactsToUpdate: any): Promise<void> {
    const updateHscRequest = {
      updateHscRequest: {
        hsc_id: this.hscId,
        flwup_cntc_dtl: contactsToUpdate
      }
    };
    await this.hscGraphqlService.updateHsc(this.hscId, updateHscRequest, this.application);
    await this.initGraphqlService();
    // this.contactsForm = this.getDefaultAuthorizationForm();
    this.clearForm();
    console.log('from db on update: ', JSON.stringify(this.contacts));
  }
}
