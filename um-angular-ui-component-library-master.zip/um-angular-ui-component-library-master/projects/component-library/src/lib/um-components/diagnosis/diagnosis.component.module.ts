import {NgModule, NO_ERRORS_SCHEMA} from '@angular/core';
import {APP_BASE_HREF, CommonModule} from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { TableModule, EcpUclTableDataSource } from '@ecp/angular-ui-component-library/table';
import { SortModule } from '@ecp/angular-ui-component-library/sort';
import { TabsModule } from '@ecp/angular-ui-component-library/tabs';
import { MatGridListModule } from '@angular/material/grid-list';
import { ButtonModule } from '@ecp/angular-ui-component-library/button';
import { IconsModule } from '@ecp/angular-ui-component-library/icons';
import { MatIconModule } from '@angular/material/icon';
import { DiagnosisComponent } from './diagnosis.component';
import { CardModule} from '@ecp/angular-ui-component-library/card';
import {AuthLibraryModule} from '@ecp/auth-library';
import {HttpClientModule} from '@angular/common/http';
import {UserAuthService} from '../services/auth/user.service';
import {LinkModule} from '@ecp/angular-ui-component-library/link';
import { FormsModule, ReactiveFormsModule} from '@angular/forms';
import { CheckboxModule } from '@ecp/angular-ui-component-library/checkbox';
import { TagsModule } from '@ecp/angular-ui-component-library/tags';
import { PaginatorModule, EcpUclPaginator } from '@ecp/angular-ui-component-library/paginator';
import { SelectModule } from '@ecp/angular-ui-component-library/select';
import { InputModule } from '@ecp/angular-ui-component-library/input';
import { OptionModule } from '@ecp/angular-ui-component-library/option';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';

@NgModule({
  declarations: [
    DiagnosisComponent
  ],
  imports: [
    CommonModule,
    BrowserModule,
    BrowserAnimationsModule,
    CardModule,
    MatGridListModule,
    MatIconModule,
    TableModule,
    ButtonModule,
    TabsModule,
    IconsModule,
    SortModule,
    HttpClientModule,
    AuthLibraryModule,
    LinkModule,
    FormsModule,
    ReactiveFormsModule,
    CheckboxModule,
    TagsModule,
    PaginatorModule,
    NoopAnimationsModule,
    SelectModule,
    InputModule,
    OptionModule
  ],
  exports: [
    DiagnosisComponent
  ],
  providers: [UserAuthService]
})
export class DiagnosisModule { }
