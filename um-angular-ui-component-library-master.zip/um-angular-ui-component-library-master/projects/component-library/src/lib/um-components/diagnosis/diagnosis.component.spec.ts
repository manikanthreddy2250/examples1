import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DiagnosisComponent } from './diagnosis.component';
import {ChangeDetectorRef, CUSTOM_ELEMENTS_SCHEMA, Injectable, NO_ERRORS_SCHEMA} from "@angular/core";
import {UserAuthService} from "../services/auth/user.service";
import {AuthLibraryModule, AuthService, MicroProductAuthService, OAuthInitService} from "@ecp/auth-library";
import {UmcasewfGraphqlService} from "../services/um/service/casewf/umcasewf-graphql.service";
import {HttpClientTestingModule} from "@angular/common/http/testing";
import {DiagnosisModule} from "../diagnosis/diagnosis.component.module";
import {EcpUclTableDataSource} from "@ecp/angular-ui-component-library/table";
import {Observable, of} from "rxjs";
import {DiagnosisModel} from "../models/diagnosis.model";
import {UmintakeGraphqlService} from '../services/um/service/um-intake/umintake-graphql.service';

@Injectable()
class UserAuthServiceMock {

  getUserID() {
    return 'TESTUSERID';
  }

  isLocalHost() {
    return false;
  }

  getActiveClientOrg() {
    return 'ecp'
  }

  getActiveUserRole() {
    return 'sys_admin'
  }

  getAltUserID() {
    return 'test';
  }

  getUserHasuraRole() {
    return 'test'
  }
}

@Injectable()
class MockUmCaseWFGraphqlService {

  getDiagDetailsByHscId(hscId, appName): Promise<any>{
    return of({data: {hsc_diag: [{"diag_cd": 123, "diagnosis": []}]}}).toPromise();
  }

  getDiagnosisCode(hscId, appName): Promise<any>{
    return of({data: {hsc_diag: [{"diag_cd": 123}]}}).toPromise();
  }

  getDiagnosisSearch(search, appName): Promise<any>{
    return of({"data":{"icd10_search":[{"cd_desc":"COVID-19","diag_cd":"U07.1","full_desc":"COVID-19","shrt_desc":"COVID-19"}]}}).toPromise();
  }

  deleteDiagnosis(hscId, diag_cd, application): Observable<any>{
    return of({"data":{"delete_hsc_diag":{"affected_rows" : 1, "returning" : [{"diag_cd":"E09"}]}}});
  }
}

@Injectable()
class MockUmintakeGraphqlService {
  saveDiagnosis(hscId, record, appName): Promise<any>{
    return of({"data":{"updateHsc":{"hsc":[{"hsc_id":12916,"hsc_srvcs":[{"hsc_srvc_id":11482,"proc_cd":"27415","proc_othr_txt":"OSTEOCHONDRAL ALLOGRAFT KNEE OPEN","proc_cd_schm_ref_id":2,"inac_ind":0,"srvc_hsc_prov_id":4512},{"hsc_srvc_id":16506,"proc_cd":"61526","proc_othr_txt":null,"proc_cd_schm_ref_id":3767,"inac_ind":0,"srvc_hsc_prov_id":null}]}]}}}).toPromise();
  }

}

describe('DiagnosisComponent', () => {
  let component: DiagnosisComponent;
  let fixture: ComponentFixture<DiagnosisComponent>;
  let cdrf: ChangeDetectorRef;

  const diagnosisDetailsData = {
    "hsc_diag" : [
      {
        hsc_diag_id: 3089,
        diag_cd: "R51",
        diag_desc: "HEADACHE",
        diag_cd_schm_ref_id :  3330,
        diag_cd_schm_ref_cd :  {
          ref_dspl: "ICD10"
        }
      }
    ]
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [],
      providers: [
        ChangeDetectorRef,
        { provide : UserAuthService, useClass: UserAuthServiceMock },
        MicroProductAuthService,
        { provide : UmcasewfGraphqlService, useClass: MockUmCaseWFGraphqlService },
        { provide : UmintakeGraphqlService, useClass: MockUmintakeGraphqlService },
        AuthService,
        OAuthInitService
      ],
      imports: [HttpClientTestingModule, DiagnosisModule, AuthLibraryModule],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DiagnosisComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
   // component.application = 'dummyName';
    cdrf = TestBed.inject(ChangeDetectorRef);
    component.diagnosisDetailsJSON =  {
      "hsc_diag" : [
        {
          hsc_diag_id: 3089,
          diag_cd: "R51",
          diag_desc: "HEADACHE",
          diag_cd_schm_ref_id :  3330,
          diag_cd_schm_ref_cd :  {
            ref_dspl: "ICD10"
          }
        }
      ]
    };
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should ngAfterContentChecked()', () => {
    let diagnosisValue = [];
    component.dataSource = new EcpUclTableDataSource(diagnosisValue);
    component.ngAfterContentChecked();
    expect(component.dataSource).toBeDefined();
  });

  it('should getDiagnosisDateTime()', () => {
   let chg_dttm = "2021-02-11T11:18:39.9";
   let ddatetime = component.getDiagnosisDateTime(chg_dttm);
   expect(ddatetime).toBe("02/11/2021 11:18 am")

  });

  it('should fetchDiagnosis()', () => {
    component.diagnosisData = [];
    component.fetchDiagnosis();
  });

  it('should call getDiagDetails()', async () => {
    component.diagnosisCaseDataDisplay = [];
    await component.getDiagDetails();
    expect(component.diagnosisCaseDataDisplay.length).toEqual(1);
  });


  it('should call saveDiagnosis()', () => {
   component.saveDiagnosis({diag_cd: 123});
   component.loadCaseDiagnosis({diag_cd: 123});
   expect(component).toBeTruthy();
  });


  it('diagnosisData fetchDiagnosis()', () => {
    let data = new DiagnosisModel()
    data.name = "Tes";
    data.updated = "Desc Test";
    let diagnosisValue = [data];

    component.diagnosisData = diagnosisValue;

    component.fetchDiagnosis();
    expect(component.diagnosisData.length).toBe(1);
  });

  it('should call viewAndUpdateButtonOnClick', () => {
    component.viewAndUpdateButtonOnClick();
    expect(component).toBeTruthy();
  });

  it('should call reset(),', () => {
    component.reset();
    expect(component).toBeTruthy();
  });

  it('should call applyFilter()', () => {
    let diagnosisCaseData = [];
    component.applyFilter({});
    component.dataSource = new EcpUclTableDataSource(diagnosisCaseData);
    expect(component.dataSource).toBeDefined();
    expect(component).toBeTruthy();
  });

  it('should call removeDiagnosis', () => {
    component.removeDiagnosis({diag_cd: 123});
    component.deselectDiag('diag_cd');
    expect(component).toBeTruthy();
  });

  it('should call updateDiagnosisRecord()', () => {
    let isChecked = true;
    component.updateDiagnosisRecord({diag_cd: 123}, isChecked);
    component.saveDiagnosis({diag_cd: 123});
    expect(component.saveDiagnosis).toBeTruthy();
  });

  it('should call loadCaseDiagnosis()', () => {
    let record = {};
    component.loadCaseDiagnosis({diag_cd: 123});
    expect(component).toBeTruthy();
  });

  it('it should call deselectDiag()', () => {
    component.deselectDiag('diag_cd');
    expect(component).toBeTruthy();
  });

  it('should call ngOnInit with provided diagnosisDetailsJSON', () => {
    component.diagnosisDetailsJSON = diagnosisDetailsData;
    component.readOnly = true;
    component.ngOnInit();
    expect(component).toBeTruthy();
    expect(component.diagnosisDetailsJSON).toBeTruthy();
    expect(component.readOnly).toBeTruthy();
    expect(component.caseDiagHeader).toBeTruthy();
  });

  it('should call ngOnInit with hscID', () => {
    component.diagnosisDetailsJSON = [];
    component.hscId = 123454;
    component.ngOnInit();
    component.getDiagDetails();
    expect(component.ngOnInit).toBeTruthy();
    expect(component.getDiagDetails).toBeTruthy();
  });
});
