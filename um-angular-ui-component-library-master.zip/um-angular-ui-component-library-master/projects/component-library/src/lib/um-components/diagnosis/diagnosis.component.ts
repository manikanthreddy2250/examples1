import {
  Component,
  Input,
  ChangeDetectorRef,
  OnInit,
  AfterContentChecked,
  Output,
  EventEmitter,
  ViewChild,
} from '@angular/core';
import { EcpUclTableDataSource } from '@ecp/angular-ui-component-library/table';
import { EcpUclSort } from '@ecp/angular-ui-component-library/sort';
import { UmcasewfGraphqlService } from '../services/um/service/casewf/umcasewf-graphql.service';
import { DiagnosisModel } from '../models/diagnosis.model';
import { EcpUclPaginator } from '@ecp/angular-ui-component-library/paginator';
import { HttpClient } from '@angular/common/http';
import { FormGroup, FormControl } from '@angular/forms';
import { UmintakeGraphqlService } from '../services/um/service/um-intake/umintake-graphql.service';

@Component({
  selector: 'app-diagnosis-component',
  templateUrl: './diagnosis.component.html',
  styleUrls: ['./diagnosis.component.scss']
})
export class DiagnosisComponent implements OnInit, AfterContentChecked {
  diagnosisValue = [];
  diagnosisCaseData = [];
  diagnosisCaseDataDisplay = [];
  diagnosisFav = [];
  diagnosisSearchForm: FormGroup;
  public diagnosisCodes = [];

  @Input() application = '';
  @Input() version;
  @Input() hscId: number;
  @Input() showDetailsView: boolean;
  @Input() typeAheadSearch: boolean;
  @Input() diagnosisData = [];
  @Input() diagnosisDetailsJSON: any;
  @Input() readOnly: boolean;
  @Input() summaryView: boolean;
  @Output() viewAndUpdateButtonClicked = new EventEmitter();

  pageOptions: number[];
  pageSize = 5;
  showSpinner: boolean = false;
  isChecked: boolean;
  length: number;
  diagnosisTable = 'Diagnosis';
  yourCaseDiagnosisTable = 'Diag';
  tableHeaders = ['favorite', 'type', 'code', 'description', 'use'];
  caseDiagHeader;
  favHeaders = ['favorite', 'type', 'code', 'description', 'order', 'remove'];
  configHeader = {
    favorite: 'Fav',
    type: 'Type',
    code: 'Code',
    description: 'Description',
    use: 'Use'
  };
  diagConfigHeader = {
    favorite: 'Favorite',
    type: 'Type',
    code: 'Code',
    description: 'Description',
    order: 'Order',
    remove: 'Remove'
  };

  dataSource: EcpUclTableDataSource<any>;
  dataDiagSource: EcpUclTableDataSource<any>;
  selectedData: EcpUclTableDataSource<any>;
  favoriteDiag: EcpUclTableDataSource<any>;
  @ViewChild(EcpUclSort) sort: EcpUclSort;
  @ViewChild(EcpUclPaginator) typeAheadPaginator: EcpUclPaginator;
  showAddCodesError: boolean = false;

  constructor(private umcaseService: UmcasewfGraphqlService,
    private httpClient: HttpClient,
    private umintakeGraphqlService: UmintakeGraphqlService,
    private cdref: ChangeDetectorRef) {
    this.pageOptions = [5, 10, 25];
    this.isChecked = false;
  }
  ngOnInit(): void {
    if (this.diagnosisDetailsJSON && this.diagnosisDetailsJSON.length > 0){
      this.diagnosisCaseDataDisplay = this.diagnosisDetailsJSON;
    } else {
      if (this.hscId) {
        this.getDiagDetails();
      }
    }

    if (this.readOnly) {
      this.caseDiagHeader = ['code', 'description'];
    } else {
      this.caseDiagHeader = ['favorite', 'type', 'code', 'description', 'order', 'remove'];
    }
    this.fetchDiagnosis();
    this.diagnosisSearchForm = new FormGroup({
      diagnosisCode: new FormControl(this.diagnosisCodes[0]),
      diagnosisValue: new FormControl(null)
    });

    this.diagnosisTable = `${this.diagnosisCaseData.length}`;
    this.dataDiagSource = new EcpUclTableDataSource(this.diagnosisCaseData);

    this.diagnosisFav = [
      {
        type: "HCPCS",
        code: "78202",
        description: "Heartfailure, unspecified"
      }
    ];
  }
  ngAfterContentChecked() {
    this.dataSource = new EcpUclTableDataSource(this.diagnosisValue);
    // this.dataDiagSource = new EcpUclTableDataSource(this.diagnosisCaseData);
    this.selectedData = new EcpUclTableDataSource(this.diagnosisCaseDataDisplay);
    this.favoriteDiag = new EcpUclTableDataSource(this.diagnosisFav);
    this.dataSource.sort = this.sort;
    // this.dataDiagSource.sort = this.sort;
    this.selectedData.sort = this.sort;
    this.favoriteDiag.sort = this.sort;
    this.cdref.detectChanges();

  }

  async getDiagDetails() {
    this.diagnosisCaseDataDisplay = [];
    const res: any = await this.umcaseService.getDiagDetailsByHscId(this.hscId, this.application);
    const diagData = res.data.hsc_diag;
    await diagData.forEach(element => {
      if (element.diagnosis[0] == null) {
        element.diagnosis[0] = '';
      }
      const diagObj = {
        hsc_diag_id: element.hsc_diag_id,
        diag_cd: element.diag_cd,
        diag_desc: element.diagnosis[0].shrt_desc ? element.diagnosis[0].shrt_desc : null,
        diag_cd_schm_ref_id: element.diag_cd_schm_ref_id ? element.diag_cd_schm_ref_id : null,
        diag_cd_schm_ref_cd: element.diag_cd_schm_ref_cd ? element.diag_cd_schm_ref_cd : null,
        pri_ind: element.pri_ind
      }
      this.diagnosisCaseDataDisplay.push(diagObj);
    });
  }

  fetchDiagnosis() {
    if (this.diagnosisData && this.diagnosisData.length > 0) {
      this.diagnosisValue = this.diagnosisData;
    } else {
      this.umcaseService.getDiagnosisCode(this.hscId, this.application).then(res => {
        this.diagnosisValue = res.data.hsc_diag.map(d => {
          const diag = new DiagnosisModel();
          if(d.pri_ind == 0) {
            diag.name = d.diag_cd + ' - ' + d.diagnosis[0].shrt_desc;
            diag.updated = this.getDiagnosisDateTime(d.chg_dttm);
          }
          return diag;
        });
      });
    }
  }

  getDiagnosisDateTime(changeDateTime) {
    const updated = changeDateTime.replace("/-/g", "/").replace("T", " ");
    var dateUpdated = new Date(updated);
    const updatedDate = ("0" + (dateUpdated.getMonth() + 1)).slice(-2) + '/' + ("0" + dateUpdated.getDate()).slice(-2) + '/' + dateUpdated.getFullYear() + ' ' + ("0" + dateUpdated.getHours() % 12).slice(-2) + ':' + dateUpdated.getMinutes();
    const updatedTime = dateUpdated.getHours() >= 12 ? 'pm' : 'am';
    return updatedDate + " " + updatedTime;
  }

  async applyFilter(event: any) {
    const filterSearch = (event?.target as HTMLInputElement)?.value;
    await this.umcaseService.getDiagnosisSearch(filterSearch, this.application).then((res) => {
      this.diagnosisCaseData = [];
      this.dataDiagSource.paginator = this.typeAheadPaginator;
      res.data.icd10_search.forEach(item => {
        this.diagnosisCaseData.push({
          diag_cd: item.diag_cd,
          diag_desc: item.shrt_desc
        });
      });
      this.dataDiagSource = new EcpUclTableDataSource(this.diagnosisCaseData);
      this.dataDiagSource.sort = this.sort;
      this.dataDiagSource.paginator = this.typeAheadPaginator;
    });
  }

  reset() {
    this.diagnosisSearchForm = new FormGroup({
      diagnosisCode: new FormControl(this.diagnosisCodes[0]),
      diagnosisValue: new FormControl(null)
    });
    this.diagnosisCaseData = [];
    this.dataDiagSource = new EcpUclTableDataSource(this.diagnosisCaseData);
    this.dataDiagSource.sort = this.sort;
  }

  updateDiagnosisRecord(record: any, isChecked: boolean) {
    if (isChecked) {
      this.saveDiagnosis(record);
    }
  }

  saveDiagnosis(record) {
    const primaryDiagExists = this.diagnosisCaseDataDisplay.find(item => item.pri_ind === 1);
    record.pri_ind = primaryDiagExists ? 0 : 1;
    this.umintakeGraphqlService.saveDiagnosis(this.hscId, record, this.application).then((res) => {
      if (res.data) {
        this.loadCaseDiagnosis(record);
      }
    });
  }

  async loadCaseDiagnosis(record) {
    this.diagnosisCaseDataDisplay.push({
      diag_cd: record.diag_cd,
      diag_desc: record.diag_desc,
      pri_ind: record.pri_ind
    });
  }

  removeDiagnosis(record) {
    this.umcaseService.deleteDiagnosis(this.hscId, record.diag_cd, this.application).subscribe((data) => {
      if (this.selectedData['rawData'] && this.selectedData['rawData'].length == 1) {
        this.showAddCodesError = true;
        this.viewAndUpdateButtonClicked.emit({ diagnosisCountError: true });
      }
      else {
        this.showAddCodesError = false;
      }
      this.deselectDiag(record.diag_cd);
    });
  }

  deselectDiag(diagCd) {
    for (let i = 0; i < this.diagnosisCaseDataDisplay.length; i++) {
      if (this.diagnosisCaseDataDisplay[i].diag_cd === diagCd) {
        this.diagnosisCaseDataDisplay.splice(i, 1);
        this.diagnosisCaseData.splice(i, 1);
      }
    }
  }

  viewAndUpdateButtonOnClick() {
    this.viewAndUpdateButtonClicked.emit();
  }
}
