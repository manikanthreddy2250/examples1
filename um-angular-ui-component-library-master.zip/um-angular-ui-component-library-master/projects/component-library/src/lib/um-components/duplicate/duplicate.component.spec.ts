import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {DuplicateComponent} from './duplicate.component';
import {CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA} from "@angular/core";
import {HttpClientTestingModule} from "@angular/common/http/testing";

describe('DuplicateComponent', () => {
  let component: DuplicateComponent;
  let fixture: ComponentFixture<DuplicateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [DuplicateComponent],
      providers: [],
      imports: [HttpClientTestingModule],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DuplicateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.duplicateDetailsJSON = {
        memberDetails: {
          memberName: "Meyer, Matt",
          memberDOB: "07/22/1994",
          memberID: "16440436900"
        },
        currentCase: {
          serviceDetails: {
            authorizationStart: "01/01/2021",
            authorizationEnd: "01/01/2021",
            anticipatedStart: "01/01/2021",
            admissionDate: "01/01/2021",
            dischargeDate: "01/01/2021",
            serviceDescription: "Urgent"
          },
          providerDetails: [
            {
              providerName: "Hogue Center",
              providerType: "Submitting",
              providerTaxID: "923827176"
            },
            {
              providerName: "Hogue Center",
              providerType: "Admitting",
              providerTaxID: "923827176"
            },
            {
              providerName: "Hogue Center",
              providerType: "Attending",
              providerTaxID: "923827176"
            },
            {
              providerName: "Hogue Center",
              providerType: "Servicing",
              providerTaxID: "923827176"
            },
            {
              providerName: "Hogue Center",
              providerType: "Ordering",
              providerTaxID: "923827176"
            },
            {
              providerName: "Hogue Center",
              providerType: "Facility",
              providerTaxID: "923827176"
            }
          ],
          diagnosisDetails: [
            {
              diagnosisCode: "CBA312",
              diagnosisDescription: "Description for CBA312"
            },
            {
              diagnosisCode: "312CBA",
              diagnosisDescription: "Description for 312CBA"
            }
          ],
          procedureDetails: [
            {
              procedureCode: "BCA213",
              procedureDescription: "Description for BCA213"
            },
            {
              procedureCode: "213BCA",
              procedureDescription: "Description for 213BCA"
            }
          ]
        },
        duplicateCases: [
          {
            serviceDetails: {
              authorizationStart: "01/01/2021",
              authorizationEnd: "01/01/2021",
              anticipatedStart: "01/01/2021",
              admissionDate: "01/01/2021",
              dischargeDate: "01/01/2021",
              serviceDescription: "Urgent"
            },
            providerDetails: [
              {
                providerName: "Hogue Center",
                providerType: "Submitting",
                providerTaxID: "923827176"
              },
              {
                providerName: "Hogue Center",
                providerType: "Admitting",
                providerTaxID: "923827176"
              },
              {
                providerName: "Hogue Center",
                providerType: "Attending",
                providerTaxID: "923827176"
              },
              {
                providerName: "Hogue Center",
                providerType: "Servicing",
                providerTaxID: "923827176"
              },
              {
                providerName: "Hogue Center",
                providerType: "Ordering",
                providerTaxID: "923827176"
              },
              {
                providerName: "Hogue Center",
                providerType: "Facility",
                providerTaxID: "923827176"
              }
            ],
            diagnosisDetails: [
              {
                diagnosisCode: "CBA312",
                diagnosisDescription: "Description for CBA312"
              },
              {
                diagnosisCode: "312CBA",
                diagnosisDescription: "Description for 312CBA"
              }
            ],
            procedureDetails: [
              {
                procedureCode: "BCA213",
                procedureDescription: "Description for BCA213"
              },
              {
                procedureCode: "213BCA",
                procedureDescription: "Description for 213BCA"
              }
            ]
          },
          {
            serviceDetails: {
              authorizationStart: "01/01/2021",
              authorizationEnd: "01/01/2021",
              anticipatedStart: "01/01/2021",
              admissionDate: "01/01/2021",
              dischargeDate: "01/01/2021",
              serviceDescription: "Urgent"
            },
            providerDetails: [
              {
                providerName: "Second Center",
                providerType: "Submitting",
                providerTaxID: "923827176"
              },
              {
                providerName: "Second Center",
                providerType: "Admitting",
                providerTaxID: "923827176"
              },
              {
                providerName: "Second Center",
                providerType: "Attending",
                providerTaxID: "923827176"
              },
              {
                providerName: "Second Center",
                providerType: "Servicing",
                providerTaxID: "923827176"
              },
              {
                providerName: "Second Center",
                providerType: "Ordering",
                providerTaxID: "923827176"
              },
              {
                providerName: "Second Center",
                providerType: "Facility",
                providerTaxID: "923827176"
              }
            ],
            diagnosisDetails: [
              {
                diagnosisCode: "CBA312",
                diagnosisDescription: "Description for CBA312"
              },
              {
                diagnosisCode: "312CBA",
                diagnosisDescription: "Description for 312CBA"
              }
            ],
            procedureDetails: [
              {
                procedureCode: "BCA213",
                procedureDescription: "Description for BCA213"
              },
              {
                procedureCode: "213BCA",
                procedureDescription: "Description for 213BCA"
              }
            ]
          },
          {
            serviceDetails: {
              authorizationStart: "01/01/2021",
              authorizationEnd: "01/01/2021",
              anticipatedStart: "01/01/2021",
              admissionDate: "01/01/2021",
              dischargeDate: "01/01/2021",
              serviceDescription: "Urgent"
            },
            providerDetails: [
              {
                providerName: "Third Center",
                providerType: "Submitting",
                providerTaxID: "923827176"
              },
              {
                providerName: "Third Center",
                providerType: "Admitting",
                providerTaxID: "923827176"
              },
              {
                providerName: "Third Center",
                providerType: "Attending",
                providerTaxID: "923827176"
              },
              {
                providerName: "Third Center",
                providerType: "Servicing",
                providerTaxID: "923827176"
              },
              {
                providerName: "Third Center",
                providerType: "Ordering",
                providerTaxID: "923827176"
              },
              {
                providerName: "Third Center",
                providerType: "Facility",
                providerTaxID: "923827176"
              }
            ],
            diagnosisDetails: [
              {
                diagnosisCode: "CBA312",
                diagnosisDescription: "Description for CBA312"
              },
              {
                diagnosisCode: "312CBA",
                diagnosisDescription: "Description for 312CBA"
              }
            ],
            procedureDetails: [
              {
                procedureCode: "BCA213",
                procedureDescription: "Description for BCA213"
              },
              {
                procedureCode: "213BCA",
                procedureDescription: "Description for 213BCA"
              }
            ]
          }
        ]
      };
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call page callback function', () => {
    component.page({pageIndex: "0"});
    expect(component.selectedDuplicateCase).toEqual(component.duplicateDetailsJSON.duplicateCases[0]);
  });

  it('should call continueButtonOnClick', () => {
    component.continueButtonOnClick();
    expect(component).toBeTruthy();
  });
});
