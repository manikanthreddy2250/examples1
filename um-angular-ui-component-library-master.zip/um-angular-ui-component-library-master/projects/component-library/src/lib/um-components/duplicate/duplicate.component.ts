import {Component, Input, Output, OnInit, EventEmitter, ViewEncapsulation} from '@angular/core';

@Component({
  selector: 'um-duplicate',
  templateUrl: './duplicate.component.html',
  styleUrls: ['./duplicate.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class DuplicateComponent implements OnInit {
  @Input() duplicateDetailsJSON: any;
  @Input() application: string;
  @Input() version: string;
  @Output() continueButtonClicked = new EventEmitter();
  numberOfPages: number;
  selectedDuplicateCase: any;

  scrollbarStyles = {
    height: "600px",
    width: "555px"
  };

  constructor() {}

  ngOnInit(): void {
    this.numberOfPages = this.duplicateDetailsJSON?.duplicateCases ? this.duplicateDetailsJSON?.duplicateCases?.length : 1;
    this.selectedDuplicateCase = this.duplicateDetailsJSON?.duplicateCases[0];
  }

  page(event) {
    this.selectedDuplicateCase = this.duplicateDetailsJSON?.duplicateCases[event.pageIndex];
  }

  continueButtonOnClick() {
    this.continueButtonClicked.emit();
  }
}
