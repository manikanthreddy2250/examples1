import { NgModule } from '@angular/core';
import { CommonModule, APP_BASE_HREF } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { DuplicateComponent } from './duplicate.component';
import { ButtonModule } from '@ecp/angular-ui-component-library/button';
import {HttpClientModule} from "@angular/common/http";
import {AuthLibraryModule} from "@ecp/auth-library";
import {UserAuthService} from "../services/auth/user.service";
import { ProgressSpinnerModule} from '@ecp/angular-ui-component-library/progress-spinner';
import { PaginatorModule } from '@ecp/angular-ui-component-library/paginator';
import { ScrollbarModule } from '@ecp/angular-ui-component-library/scrollbar'
import { TooltipModule } from '@ecp/angular-ui-component-library/tooltip';
import { IconsModule } from '@ecp/angular-ui-component-library/icons';

@NgModule({
  declarations: [
    DuplicateComponent
  ],
  imports: [
    CommonModule,
    BrowserModule,
    BrowserAnimationsModule,
    ButtonModule,
    HttpClientModule,
    AuthLibraryModule,
    ProgressSpinnerModule,
    PaginatorModule,
    ScrollbarModule,
    TooltipModule,
    IconsModule
  ],
  exports: [
    DuplicateComponent
  ],
  providers: [UserAuthService, {provide: APP_BASE_HREF, useValue: '/'}]
})
export class DuplicateModule {}