import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {EmailComponent} from './email.component';
import {Injectable} from '@angular/core';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import {CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA} from '@angular/compiler';
import {AuthLibraryModule, MicroProductAuthService} from '@ecp/auth-library';
import {HscAuthDetailService} from '../services/um/service/clinical-guidelines/medical-reviews/hsc-auth-detail.service';
import {HscGraphqlService} from '../services/um/service/hsc-update/hsc-graphql.service';
import {EmailModule} from './email.module';
import {of} from 'rxjs';
import {EmailService} from "../services/email/email.service";
import {HttpErrorResponse} from '@angular/common/http';
import {defer} from 'rxjs';
import {HttpClient} from '@angular/common/http';
import { UmcasewfGraphqlService } from '../services/um/service/casewf/umcasewf-graphql.service';
import { ConfigService } from '../services/config/config.service';

@Injectable()
class MockHscAuthDetailService {
  getHscAuthDetails(request: any) {
    return of({
      data: {
        getHscAuthDetails: {
          hsc: [
            {
              hsc_id: 11
            }
          ]
        }
      }
    });
  }
}

export function asyncError<T>(errorObject: any) {
  return defer(() => Promise.reject(errorObject));
}

describe('EmailComponent', () => {
  let component: EmailComponent;
  let fixture: ComponentFixture<EmailComponent>;
  let microProductAuth: MicroProductAuthService;
  let authDetailService: HscAuthDetailService;
  let emailService: EmailService;
  let httpClient: HttpClient;
  let umcaseService: UmcasewfGraphqlService;
  let mockConfigService: any;


  beforeEach(async(() => {
    mockConfigService = jasmine.createSpyObj('mockConfigService', ['readConfig']);
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        AuthLibraryModule,
        EmailModule
      ],
      declarations: [],
      providers: [MicroProductAuthService, {
        provide: HscGraphqlService
      }, {
        provide: HscAuthDetailService,
        useClass: MockHscAuthDetailService
      },
      UmcasewfGraphqlService],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
    fixture = TestBed.createComponent(EmailComponent);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmailComponent);
    component = fixture.componentInstance;
    authDetailService = TestBed.inject(HscAuthDetailService);
    microProductAuth = TestBed.inject(MicroProductAuthService);
    emailService = TestBed.inject(EmailService);
    umcaseService = TestBed.inject(UmcasewfGraphqlService);
    httpClient =  TestBed.inject(HttpClient);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call ngOnInit', () => {
    component.ngOnInit();
    expect(component).toBeTruthy();
  });

  it('should handle emailService error', () => {
    const errorResponse = new HttpErrorResponse({
      error: '404 error',
      status: 404,
      statusText: 'Not Found'
    });

    spyOn(emailService, 'sendEmail').and.returnValue(asyncError(errorResponse));

    component.sendRequestButtonOnClick();
    expect(component).toBeTruthy();
  });

  it('should call sendRequestButtonOnClick', () => {
    const response = {
      data: {}
    };
    spyOn(emailService, 'sendEmail').and.returnValue(of(response));

    component.sendRequestButtonOnClick();
    expect(component).toBeTruthy();
  });

   it('should call sendFaxRequestButtonOnClick', () => {
      component.sendRequestButtonOnClick();
      expect(component).toBeTruthy();
    });

   it('should call setRequestClinicalType', () =>{
      component.setRequestClinicalType();
      expect(component).toBeTruthy();
   });


  it('should initGraphqlService()', () => {
    component.configService = new ConfigService(httpClient, 'https://dev-config', umcaseService);
    component.initGraphqlService();
    expect(component.configService).toBeDefined();
  });


});
