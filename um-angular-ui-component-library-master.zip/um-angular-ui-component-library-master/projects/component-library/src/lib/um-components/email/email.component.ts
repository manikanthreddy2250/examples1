import {Component, OnInit, Input, Output, ViewEncapsulation, EventEmitter} from '@angular/core';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import {HscAuthDetailService} from '../services/um/service/clinical-guidelines/medical-reviews/hsc-auth-detail.service';
import {UserAuthService} from '../services/auth/user.service';
import {EmailService} from "../services/email/email.service";
import { ConfigService } from '../services/config/config.service';
import { UmcasewfGraphqlService } from '../services/um/service/casewf/umcasewf-graphql.service';
import { getEnvVar } from '../services/environment/envVarUtil';
import { HttpClient } from '@angular/common/http';
import {
  GET_CONFIG_URL_PATH,
  MYTASKS_LIST_TABLE_HEADERS,
  REQUEST_CLINICAL_TYPE_UHC,
  REQUEST_CLINICAL_TYPE_ECP
} from '../../config/config-constants';
import {Constants} from "../../constant/constants";
import {GenericCamundaService} from "../services/um/service/generic-camunda/generic-camunda.service";

@Component({
  selector: 'um-email',
  templateUrl: './email.component.html',
  styleUrls: ['./email.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class EmailComponent implements OnInit {

  @Input() application: string;
  @Input() version: string;
  @Input() hscId: number;
  @Input() subjectType: string ;
  @Input() subjectTypeValue: string;
  @Output() closeModal = new EventEmitter();
  @Input() sbjRecId: any;

  showSpinner: boolean = false;
  requestClinicalForm: FormGroup;
  showEmail: boolean = true;
  configService: any;
  requestClinicalType: any;
  configKey: any;
  orgId: any;

  constructor(private hscService: HscAuthDetailService, private emailService: EmailService,
              private userAuthService: UserAuthService,
              private readonly httpClient: HttpClient,
              private umcaseService: UmcasewfGraphqlService,private readonly genericCamundaService: GenericCamundaService) {}

  ngOnInit(): void {
    this.requestClinicalForm = new FormGroup({
      toSectionFormControl: new FormControl(null, [Validators.required, Validators.pattern(/(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\[(?:(?:(2(5[0-5]|[0-4][0-9])|1[0-9][0-9]|[1-9]?[0-9]))\.){3}(?:(2(5[0-5]|[0-4][0-9])|1[0-9][0-9]|[1-9]?[0-9])|[a-z0-9-]*[a-z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\])/)]),
      subjectSectionFormControl: new FormControl(null, null),
      messageSectionFormControl: new FormControl(null, null),
      toSectionFaxFormControl: new FormControl(null, [Validators.required,Validators.pattern(/^(\+\d{1,2}\s)?\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{4}$/)  ])
    });
    this.requestClinicalForm.controls.toSectionFormControl.markAsTouched();
    this.initGraphqlService();

    const hsc = {
      hsc: {
        hsc_id: this.hscId
      }
    };

    this.orgId = this.userAuthService.getActiveClientOrg();
    this.setRequestClinicalType();


    if (!this.subjectTypeValue) {
      this.showSpinner = true;
      this.hscService.getHscAuthDetails(hsc).toPromise().then(response => {
        this.requestClinicalForm.controls.toSectionFormControl.setValue(response?.data?.getHscAuthDetails?.hsc[0]?.flwup_cntc_dtl[0]?.email);
        this.requestClinicalForm.controls.toSectionFaxFormControl.setValue(response?.data?.getHscAuthDetails?.hsc[0]?.flwup_cntc_dtl[0]?.fax);
        this.showSpinner = false;
      });

    }
    else {
      this.requestClinicalForm.controls.toSectionFormControl.setValue(this.subjectTypeValue);
      this.requestClinicalForm.controls.toSectionFaxFormControl.setValue(this.subjectTypeValue);
    }

    this.requestClinicalForm.controls.subjectSectionFormControl.setValue("Request Clinical Information for SRN " + this.hscId);


  }

  async setRequestClinicalType(){
    if(this.orgId == 'uhc'){
        this.configKey = REQUEST_CLINICAL_TYPE_UHC;
    }
    else{
        this.configKey = REQUEST_CLINICAL_TYPE_ECP;
    }


     const res = await this.configService.readConfig(this.application, this.version, this.configKey);

     this.requestClinicalType = JSON.parse(res[0]?.value)?.availableChannel[0];


     if(this.requestClinicalType == 'fax'){
        this.subjectType = 'fax';
        this.showEmail = false;
     }
     else{
        this.subjectType = 'email';
        this.showEmail = true;
     }
  }

    public initGraphqlService(): void {
      const configUrl = getEnvVar(GET_CONFIG_URL_PATH);
      this.configService = new ConfigService(this.httpClient, configUrl, this.umcaseService);
    }


  sendRequestButtonOnClick() {
    this.emailService.sendEmail(this.requestClinicalForm.controls.toSectionFormControl.value, this.requestClinicalForm.controls.subjectSectionFormControl.value, this.requestClinicalForm.controls.messageSectionFormControl.value).toPromise().then(response => {
      console.log(response);
      this.requestClinicalForm.controls.messageSectionFormControl.setValue(null);
      this.closeModal.emit();
      this.publishActivitySignal();
    }, error => {
      console.log(error);
      this.closeModal.emit();
    });
  }

publishActivitySignal() {
  let communicationChannel;
    if(this.showEmail){
      communicationChannel= Constants.MEMBER_COMMUNICATION_CHANNEL_EMAIL_REF_ID;
    }else{
      communicationChannel= Constants.MEMBER_COMMUNICATION_CHANNEL_FAX_REF_ID;
    }
  const signalReqBody = {
    name: "sendActivitySignal-"+ this.hscId,
    variables: {
        hsc_id: {
          value: this.hscId,
          type: 'Integer'
        },
        actv_typ_ref_id: {
          value: Constants.ACTIVITY_TYPE_REQUEST_CLINICAL_REF_ID,
          type: 'Integer'
        },
        creat_user_id: {
          value: this.userAuthService.getAltUserID(),
          type: 'String'
        },
        actv_sbj_rec_id: {
          value: this.sbjRecId,
          type: 'Integer'
        },
        actv_sbj_typ_ref_id: {
          value: Constants.SUBJECT_ID_TYPE_ASSIGNMENT_ID_REF_ID,
          type: 'Integer'
        },
        rslv_otcome_typ_id: {
          value: Constants.MEMBER_COMMUNICATION_PENDING_STATUS_REF_ID,
          type: 'Integer'
        },
        mbr_cmnct_chnl_ref_id: {
          value: communicationChannel,
          type: 'Integer'
        },
        mbr_cmnct_sts_ref_id: {
          value: Constants.MEMBER_COMMUNICATION_PENDING_STATUS_REF_ID,
          type: 'Integer'
        },
        mbr_cmnct_dir_ref_id: {
          value: Constants.MEMBER_COMMUNICATION_OUTBOUND_DIRECTION_REF_ID,
          type: 'Integer'
        },
        mbr_cmnct_typ_ref_id: {
          value: Constants.MEMBER_COMMUNICATION_MANUAL_TYPE_REF_ID,
          type: 'Integer'
        },
        mbr_cmnct_catgy_ref_id: {
          value: Constants.MEMBER_COMMUNICATION_CATEGORY_UTILIZATION_MGMT_REF_ID,
          type: 'Integer'
        },
        isTrackingDisabled: {
        value: Constants.TRACKING_DISABLED,
        type: 'boolean'
      }
    }
};

  this.genericCamundaService.sentRequestClinicalSignal( signalReqBody)
    .subscribe((data: any) => {
        console.log('publishActivitySignal sent succesfully');
      },
      error => {
        console.log('Error occurred in  calling publishActivitySignal', error);
      });
}

  sendFaxRequestButtonOnClick() {
    console.log("Fax Sent");
    this.closeModal.emit();
    this.publishActivitySignal();
  }
}

