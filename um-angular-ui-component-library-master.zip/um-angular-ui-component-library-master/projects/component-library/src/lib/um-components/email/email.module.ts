import { NgModule } from '@angular/core';
import { CommonModule, APP_BASE_HREF } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { EmailComponent } from './email.component';
import { ButtonModule } from '@ecp/angular-ui-component-library/button';
import {HttpClientModule} from "@angular/common/http";
import {AuthLibraryModule} from "@ecp/auth-library";
import {UserAuthService} from "../services/auth/user.service";
import { ProgressSpinnerModule} from '@ecp/angular-ui-component-library/progress-spinner';
import { PaginatorModule } from '@ecp/angular-ui-component-library/paginator';
import { ScrollbarModule } from '@ecp/angular-ui-component-library/scrollbar'
import { TooltipModule } from '@ecp/angular-ui-component-library/tooltip';
import { IconsModule } from '@ecp/angular-ui-component-library/icons';
import { FormFieldModule } from '@ecp/angular-ui-component-library/form-field';
import { CheckboxModule } from '@ecp/angular-ui-component-library/checkbox';
import { RadioButtonModule } from '@ecp/angular-ui-component-library/radio-button';
import { OptionModule } from '@ecp/angular-ui-component-library/option';
import { SelectModule } from '@ecp/angular-ui-component-library/select';

import { InputModule } from '@ecp/angular-ui-component-library/input';
import {NoopAnimationsModule} from '@angular/platform-browser/animations';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';

@NgModule({
  declarations: [
    EmailComponent
  ],
  imports: [
    CommonModule,
    BrowserModule,
    BrowserAnimationsModule,
    ButtonModule,
    HttpClientModule,
    AuthLibraryModule,
    ProgressSpinnerModule,
    PaginatorModule,
    ScrollbarModule,
    TooltipModule,
    IconsModule,
    FormFieldModule,
    InputModule,
    NoopAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    CheckboxModule,
    RadioButtonModule,
    OptionModule,
    SelectModule
  ],
  exports: [
    EmailComponent
  ],
  providers: [{provide: APP_BASE_HREF, useValue: '/'}]
})
export class EmailModule {}