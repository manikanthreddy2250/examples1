import { MedicalReviewComponent } from './medical-review.component';
import {UserAuthService} from "../services/auth/user.service";
import {UmcasewfGraphqlService} from "../services/um/service/casewf/umcasewf-graphql.service";
import {async, ComponentFixture, TestBed} from "@angular/core/testing";
import {AuthLibraryModule, AuthService, MicroProductAuthService} from "@ecp/auth-library";
import {HttpClient} from "@angular/common/http";
import {HttpClientTestingModule} from "@angular/common/http/testing";
import {of} from "rxjs";
import {CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA} from "@angular/compiler";
import {GenericCamundaService} from "../services/um/service/generic-camunda/generic-camunda.service";

describe('LocReviewComponent', () => {
  let component: MedicalReviewComponent;
  let fixture: ComponentFixture<MedicalReviewComponent>;
  let service: UserAuthService;
  let authService: AuthService;
  let microProductAuth: MicroProductAuthService;
  let umcaseService: UmcasewfGraphqlService;
  let httpClient: HttpClient;
  let genericCamundaService: GenericCamundaService;

  const taskListData = {
    "data": {
      "getHscTaskDetails": {
        "task": [
          {
            "checklist": [{
              "asgn_to_user_id": "skonjeti",
              "chg_dttm": "2021-03-19T21:34:24.881",
              "chg_user_id": "chsss",
              "hsr_asgn_id": 3,
              "src_rec_guid": "d3f78ec7-88fa-11eb-95d5-56fd9632ea4f",
              "asgn_desc": null,
              "asgn_typ_ref_cd": {ref_dspl: "Clinical Received"},
              "asgn_typ_ref_id": 72207,
              "asgn_sts_ref_cd": {ref_dspl: "Complete"},
              "asgn_sts_ref_id": 72114
            }]
          }
        ]
      }
    }
  };

  const taskRefDsplData = [
    [
      {
        "refDspl": "Admission Review",
        "refId": 72138
      }
    ],
    [
      {
        "refDspl": "Eligibility",
        "refId": 72134
      }
    ],
    [
      {
        "refDspl": "Provider",
        "refId": 72135
      }
    ]
  ];

  const medicalReviewJson = [
    [
      {
        "refDspl": "Admission Review",
        "refId": 72138
      }
    ],
    [
      {
        "refDspl": "Eligibility",
        "refId": 72134,
        "status" : "Complete"
      }
    ],
    [
      {
        "refDspl": "Provider",
        "refId": 72135,
        "status" : "Complete"
      }
    ],
    [
      {
        "refDspl": "Concurrent Review",
        "refId": 72135,
        "status" : "Complete"
      }
    ],
    [
      {
        "refDspl": "Concurrent Review",
        "refId": 72135,
        "status" : "Complete"
      }
    ]
  ];

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MedicalReviewComponent ],
      imports: [HttpClientTestingModule, AuthLibraryModule],
      providers: [UserAuthService],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
    service = TestBed.inject(UserAuthService);
    authService = TestBed.inject(AuthService);
    microProductAuth = TestBed.inject(MicroProductAuthService);
    umcaseService = TestBed.inject(UmcasewfGraphqlService);
    httpClient =  TestBed.inject(HttpClient);
    genericCamundaService = TestBed.inject(GenericCamundaService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MedicalReviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call locStart', () => {
    const event = {};
    component.locStart(event)
    expect(component.locStart).toBeDefined();
  });

  it('should call getHscTaskDetails and return data', () => {
    const userspy = spyOn(umcaseService, 'getHscTaskDetails').and.returnValue(of(taskListData));
    component.ngOnInit();
    expect(userspy).toHaveBeenCalled();
  });

  it('should call evaluateMultipleRules and return data', () => {
    const userspy = spyOn(umcaseService, 'getHscTaskDetails').and.returnValue(of(taskListData));
    const userspy2 = spyOn(genericCamundaService, 'evaluateMultipleRules').and.returnValue(of(taskRefDsplData));
    component.ngOnInit();
    expect(userspy2).toHaveBeenCalled();
  });

  it('should call renderComponentWithJson', () => {
    component.medicalReviewJson = medicalReviewJson;
    component.ngOnInit();
  });
});
