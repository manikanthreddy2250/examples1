import {
  Component,
  OnInit,
  ViewEncapsulation,
  Input,
  Output,
  EventEmitter,
  OnChanges,
  ViewChild
} from '@angular/core';
import {UmcasewfGraphqlService} from '../services/um/service/casewf/umcasewf-graphql.service';
import {UserAuthService} from '../services/auth/user.service';
import {GenericCamundaService} from '../services/um/service/generic-camunda/generic-camunda.service';
import {CLIENT_REF_DISPLAY_DMN} from '../../config/config-constants';
import {umReferenceConstants} from '../../constant/um-reference-constants';
import {EcpUclModal} from '@ecp/angular-ui-component-library/modal';

@Component({
  selector: 'um-medical-review',
  templateUrl: './medical-review.component.html',
  styleUrls: ['./medical-review.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class MedicalReviewComponent implements OnInit, OnChanges {

  @Output() startAction: EventEmitter<any> = new EventEmitter();
  @Input() application: string;
  @Input() version: string;
  @Input() taskNameRefID: string;
  @Input() hscId: number;
  @Input() medicalReviewJson: any;

  @ViewChild(EcpUclModal)
  requestClinicalModal: EcpUclModal;


  showSpinner = false;
  MedicalReviewDataRows = [];
  taskHeaderName;
  requestClinicalRefId = umReferenceConstants.REQUEST_CLINICAL_REF_ID;

  constructor(private readonly umcaseService: UmcasewfGraphqlService,
              private readonly userAuthService: UserAuthService,
              private readonly genericCamundaService: GenericCamundaService) { }

  ngOnInit(): void {
    this.showSpinner = true;
    this.MedicalReviewDataRows = [];
    if (!this.medicalReviewJson){
      this.renderComponentWithApi();
    } else {
      if (this.medicalReviewJson?.length > 0){
        this.renderComponentWithJson();
      }
    }

  }

  ngOnChanges(): void {
    if (this.medicalReviewJson?.length > 0){
      this.renderComponentWithJson();
    }
  }

  private renderComponentWithApi() {
    this.umcaseService.getHscTaskDetails(this.application, this.hscId, this.taskNameRefID).subscribe(response => {
      const checkList = response?.data?.getHscTaskDetails?.task[0]?.checklist;
      let columnCount = 0;
      let row = [];
      const recentCheckList = checkList.slice(0);
      recentCheckList.sort((a, b) => {
        return new Date(a.chg_dttm).getTime() < new Date(b.chg_dttm).getTime() ? 1 : -1;
      });
      const uniqueCheckList = recentCheckList.filter((item, index, self) =>
        index === recentCheckList.findIndex((secondItem) => (
          item.asgn_typ_ref_id === secondItem.asgn_typ_ref_id
        ))
      );
      const refRequest = this.buildDmnRequest(uniqueCheckList, response?.data?.getHscTaskDetails?.task[0]?.asgn_typ_ref_id);
      this.genericCamundaService.evaluateMultipleRules(CLIENT_REF_DISPLAY_DMN, refRequest, this.application).subscribe(
        response2 => {
          this.taskHeaderName = response2[0][0]?.refDspl;
          this.showSpinner = false;
          let i = 1;
          uniqueCheckList.forEach(task => {
            if (columnCount === 3) {
              this.MedicalReviewDataRows.push(row);
              columnCount = 0;
              row = [];
            } else {
              columnCount++;
            }
            row.push([response2[i][0]?.refDspl, task.asgn_sts_ref_cd.ref_dspl]);
            i++;
          });

          if (row.length > 0) {
            this.MedicalReviewDataRows.push(row);
          }
        },
        error => {
          this.showSpinner = false;
          console.log('Error occurred when retrieving task reference display: ', error);
        }
      );
    });
  }

  public renderComponentWithJson() {
    this.MedicalReviewDataRows = [];
    this.taskHeaderName = this.medicalReviewJson[0][0]?.refDspl;
    this.medicalReviewJson.shift();
    this.showSpinner = false;
    let columnCount = 0;
    let row = [];
    this.medicalReviewJson.forEach(task => {
      if (columnCount === 3) {
        this.MedicalReviewDataRows.push(row);
        columnCount = 0;
        row = [];
      } else {
        columnCount++;
      }
      row.push([task[0].refDspl, task[0].status]);
    });
    if (row.length > 0) {
      this.MedicalReviewDataRows.push(row);
    }
  }

  private buildDmnRequest(uniqueCheckList, taskName) {
    const refRequest = [];
    const orgId = this.userAuthService.getActiveClientOrg();
    refRequest.push({"refId": taskName, "orgId": orgId});
    for (const task of uniqueCheckList) {
      refRequest.push({"refId": task.asgn_typ_ref_id, "orgId": orgId});
    }
    return refRequest;
  }

  locStart(e) {
    this.startAction.next(e);
  }
  closeModal($event): void{
    this.requestClinicalModal.close();
  }
}
