import { NgModule } from '@angular/core';
import {CommonModule} from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';
import { MedicalReviewComponent } from './medical-review.component';
import {MatGridListModule} from '@angular/material/grid-list';
import {MatIconModule} from '@angular/material/icon';
import {AuthLibraryModule} from '@ecp/auth-library';
import {UserAuthService} from '../services/auth/user.service';
import {APP_BASE_HREF} from '@angular/common';
import {ButtonModule} from '@ecp/angular-ui-component-library/button';
import {CardModule} from '@ecp/angular-ui-component-library/card';
import {IconsModule} from '@ecp/angular-ui-component-library/icons';
import {ProgressSpinnerModule} from '@ecp/angular-ui-component-library/progress-spinner';
import {ModalModule} from '@ecp/angular-ui-component-library/modal';
import {EmailModule} from '../email/email.module';

@NgModule({
  declarations: [
    MedicalReviewComponent
  ],
  imports: [
    CommonModule,
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    MatGridListModule,
    MatIconModule,
    ButtonModule,
    IconsModule,
    CardModule,
    AuthLibraryModule,
    ProgressSpinnerModule,
    ModalModule,
    EmailModule
  ],
  exports: [
    MedicalReviewComponent
  ],
  providers: [UserAuthService, {provide: APP_BASE_HREF, useValue: '/'}]
})
export class MedicalReviewModule { }
