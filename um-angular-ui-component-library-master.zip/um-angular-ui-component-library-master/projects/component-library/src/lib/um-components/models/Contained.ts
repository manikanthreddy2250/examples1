import { Parameter } from './Parameter';

export class Contained {
    public resourceType: string;
    public id: string;
    public parameter: Parameter[];
    public contained: Contained[];
  }
