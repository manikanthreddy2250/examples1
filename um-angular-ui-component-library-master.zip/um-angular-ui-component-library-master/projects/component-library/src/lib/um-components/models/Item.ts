import { Answer } from './Answer';

export class Item{
    public linkId : string;
    public text : string;
    public type : string;
    public definition : string;
    public prefix : string;
    public answer : Answer[];
    public item : Item[];
    public enableMultiBtn: boolean;
    public showRecommdations: boolean;
  }
