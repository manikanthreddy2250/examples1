import { Tag } from './Tag';

export class Meta{
    public lastUpdated : Date;
    public tag : Tag[];
}
