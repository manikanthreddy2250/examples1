export class Parameter {
    public name :string;
    public valueString: string;
    public valueId :string;
    public valueDateTime : string;
  }
