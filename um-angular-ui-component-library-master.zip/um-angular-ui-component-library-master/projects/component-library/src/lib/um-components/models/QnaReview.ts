import { Item } from './Item';
import { Identifier } from './Identifier';
import { Contained } from './Contained';
import { Meta } from './Meta';

export class QnaReview {
    public resourceType: string;
    public identifier: Identifier;
    public meta: Meta;
    public questionnaire: string;
    public status: string
    public item: Item[];
    public text: string;
    public contained: Contained[];
    public questionsList: any;
}
