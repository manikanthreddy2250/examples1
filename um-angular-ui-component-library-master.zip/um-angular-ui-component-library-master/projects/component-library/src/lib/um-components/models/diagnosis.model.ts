export class DiagnosisModel {
  name: string;
  dateOfProcedure: string;
  updated: string;
}
