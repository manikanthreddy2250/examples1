import {Injectable} from '@angular/core';

@Injectable({
    providedIn: 'root'
})
export class ProcedureMockData {
    private myProcedureData: any[] = [];

    constructor() {
        this.myProcedureData = [
            {
              Fav: 'true',
              Type: 'HCPCS',
              Code: '78202',
              Description: 'Short-acting beta-agonist administered prior to admission',
              ETA: '2Days 17 Hours',
              Provider:'Physician',
              DTQ: 'true',
              Remove: 'true'
            },
            {
              Fav: 'true',
              Type: 'CPT4',
              Code: 'G0156',
              Description: 'Cyanosis, new onset or worsening',
              ETA: '1 Day 3 Hours',
              Provider:'Facility',
              DTQ: 'true',
              Remove: 'true'
            }
        ];
    }

    getProcedures() {
        return this.myProcedureData;
    }
}
