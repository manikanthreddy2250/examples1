export class ProcedureList {
  name: string;
  dateOfProcedure: string;
  updated: string;
}
