import {Injectable, OnInit} from '@angular/core';

@Injectable({
    providedIn: 'root'
})
export class RecentTasksMockData {
    private myTaskslist: any[] = [];

    constructor() {
        this.myTaskslist = [];
    }

    
    getRecentTasks() {
        return this.myTaskslist;
    }
}
