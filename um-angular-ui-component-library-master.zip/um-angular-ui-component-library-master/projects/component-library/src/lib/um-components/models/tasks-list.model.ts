// mock my tasks list model
export class TaskListModal {
    admitted: string | Date;
    tat: string | Date;
    status: string;
    taskStatusRefID: number;
    member: string;
    diagnosis: string;
    facility: string;
    taskType: string;
    action: string;
    caseId?: string;
    taskId: string;
    hscId: string;
    taskNameRefID: string;
    taskExecutionID: string;
    actionStatusRefID: string;
}

export class TaskListConfigHeader {
    admitted: string;
    tat: string;
    status: string;
    member: string;
    diagnosis: string;
    facility: string;
    taskType: string;
    action: string;
}
