/*
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {ProcedureComponent} from "./procedure.component";
import {AuthService, OAuthInitService, MicroProductAuthService, AuthLibraryModule} from "@ecp/auth-library";
import {HttpClientModule, HttpClient, HttpHeaders} from "@angular/common/http";
import {UserAuthService} from "../services/auth/user.service";
import {Injectable, ChangeDetectorRef, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA} from "@angular/core";
import {UmcasewfGraphqlService} from "../services/um/service/casewf/umcasewf-graphql.service";
import * as moment from 'moment';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ProcedureModule } from './procedure.module';
import {CheckboxModule} from "@ecp/angular-ui-component-library/checkbox";
import {TableModule} from "@ecp/angular-ui-component-library/table";
import {SortModule} from "@ecp/angular-ui-component-library/sort";
import {CommonModule} from "@angular/common";
import {Observable, of} from "rxjs";
import {UmintakeGraphqlService} from "../services/um/service/um-intake/umintake-graphql.service";

@Injectable()
class UserAuthServiceMock {

  getUserID() {
    return 'TESTUSERID';
  }

  isLocalHost() {
    return false;
  }

  getActiveClientOrg() {
    return 'ecp'
  }

  getActiveUserRole() {
    return 'sys_admin'
  }

  getAltUserID() {
    return 'test';
  }

  getUserHasuraRole() {
    return 'test'
  }
}

@Injectable()
class MockUmIntakeService {
  getProcedureCode(hscId,appName): Observable<any>{
    return of({data:{hsc_srvc:[{hsc_srvc_id:14404,hsc_id:12845,proc_cd:"A4398",proc_cd_schm_ref_id:3768,creat_dttm:"2020-11-11T10:18:39.9",chg_dttm:"2021-02-11T11:18:39.9"}]}});
  }

}

const hscService =
  {
    creat_dttm: "2020-11-11T10:18:39.9" ,
    chg_dttm:"2021-02-11T11:18:39.9"
  };

const procedureJson = [
{
  shrt_desc: "NONEMERG TRNSPRT: MEALS-RECIP",
    proc_cd: "A0190",
  dateOfProcedure: "12/12/2020 11:18 am",
  updated: "04/12/2021 03:18 pm"
}
];

const procedureData = {data:{hsc_srvc:[{hsc_srvc_id:14404,hsc_id:12845,proc_cd:"A4398",proc_cd_schm_ref_id:3768,creat_dttm:"2020-11-11T10:18:39.9",chg_dttm:"2021-02-11T11:18:39.9"}]}};
const procedureList = {Code: "A4398", Description: "OSTOMY IRRIGATION SUPPLY; BAG EACH", ETA: "12 Days", Provider: "Facility", Remove: "true",  Type: "HCPCS", hscSrvcId: 14404}
const procedureDesc = {data:{hcpcs:[{proc_cd:'A4398',shrt_desc:'OSTOMY IRRIGATION SUPPLY; BAG EACH'}]}};
const hscStatus = {data:{hsc:[{hsc_sts_ref_id:19275}]}};
const procedureType = {"data":{"ref":[{"inac_ind":0,"ref_cd":"8","ref_desc":"ALL","ref_dspl":"ALL","ref_id":19889}, {"inac_ind":0,"ref_cd":"2","ref_desc":"CPT4","ref_dspl":"CPT4","ref_id":3767}, {"inac_ind":0,"ref_cd":"4","ref_desc":"HCPCS","ref_dspl":"HCPCS","ref_id":3768}, {"inac_ind":0,"ref_cd":"6","ref_desc":"NDC","ref_dspl":"NDC","ref_id":3769}, {"inac_ind":0,"ref_cd":"7","ref_desc":"Revenue Code","ref_dspl":"Revenue Code","ref_id":3770}]}};
const procedures = {"data":{"ProcedureSmartSearch":[{"code":"78130","description":"RED CELL SURVIVAL STUDY","displayText":"78130  RED CELL SURVIVAL STUDY","searchType":"cpt4_search"}, {"code":"78191","description":"PLATELET SURVIVAL STUDY","displayText":"78191  PLATELET SURVIVAL STUDY","searchType":"cpt4_search"}, {"code":"78104","description":"BONE MARROW IMAGING WHOLE BODY","displayText":"78104  BONE MARROW IMAGING WHOLE BODY","searchType":"cpt4_search"}, {"code":"78103","description":"BONE MARROW IMAGING MULTIPLE AREAS","displayText":"78103  BONE MARROW IMAGING MULTIPLE AREAS","searchType":"cpt4_search"}, {"code":"78102","description":"BONE MARROW IMAGING LIMITED AREA","displayText":"78102  BONE MARROW IMAGING LIMITED AREA","searchType":"cpt4_search"}, {"code":"78195","description":"LYMPHATICS & LYMPH NODES IMAGING","displayText":"78195  LYMPHATICS & LYMPH NODES IMAGING","searchType":"cpt4_search"}, {"code":"78185","description":"SPLEEN IMAGING ONLY W/WO VASCULAR FLOW","displayText":"78185  SPLEEN IMAGING ONLY W/WO VASCULAR FLOW","searchType":"cpt4_search"}, {"code":"78120","description":"RED CELL VOLUME DETERMINATION SPX 1 SAMPLING","displayText":"78120  RED CELL VOLUME DETERMINATION SPX 1 SAMPLING","searchType":"cpt4_search"}, {"code":"78121","description":"RED CELL VOLUME DETERMINATION SPX MULT SAMPLINGS","displayText":"78121  RED CELL VOLUME DETERMINATION SPX MULT SAMPLINGS","searchType":"cpt4_search"}, {"code":"78140","description":"LABELED RBC SEQUESTRATION DIFFERNTL ORGAN/TISSUE","displayText":"78140  LABELED RBC SEQUESTRATION DIFFERNTL ORGAN/TISSUE","searchType":"cpt4_search"}, {"code":"78110","description":"PLASMA VOL RADIOPHARM VOL DILUTION SPX 1 SAMPLE","displayText":"78110  PLASMA VOL RADIOPHARM VOL DILUTION SPX 1 SAMPLE","searchType":"cpt4_search"}, {"code":"78135","description":"RBC SURVIVAL STUDY DIFFERNTL ORGAN/TISS KINETICS","displayText":"78135  RBC SURVIVAL STUDY DIFFERNTL ORGAN/TISS KINETICS","searchType":"cpt4_search"}, {"code":"78111","description":"PLASMA VOL RADIOPHARM VOL DILUTE SPX MULT SMPLES","displayText":"78111  PLASMA VOL RADIOPHARM VOL DILUTE SPX MULT SMPLES","searchType":"cpt4_search"}, {"code":"78199","description":"UNLIS HEMATOP RET/ENDO&LYMPHATIC DX NUC MED","displayText":"78199  UNLIS HEMATOP RET/ENDO&LYMPHATIC DX NUC MED","searchType":"cpt4_search"}, {"code":"78122","description":"WHOLE BLOOD VOLUME DETERM PLASMA&RED CELL VOLU","displayText":"78122  WHOLE BLOOD VOLUME DETERM PLASMA&RED CELL VOLU","searchType":"cpt4_search"}]}};
const updateProc = {data:{update_hsc_srvc_by_pk:{hsc_srvc_id:14404}}};
const saveProcedure = {data:{"updateHsc":{"hsc":[{"hsc_id":18942,"hsc_srvcs":[{"hsc_srvc_id":15550,"proc_cd":"0001F","proc_othr_txt":null,"proc_cd_schm_ref_id":3767,"inac_ind":1},{"hsc_srvc_id":15552,"proc_cd":"L8410","proc_othr_txt":"PROSTHETIC SHEATH ABOVE KNEE EACH","proc_cd_schm_ref_id":3768,"inac_ind":1},{"hsc_srvc_id":15553,"proc_cd":"B4187","proc_othr_txt":"OMEGAVEN 10 G LIPIDS","proc_cd_schm_ref_id":3768,"inac_ind":1},{"hsc_srvc_id":15554,"proc_cd":"B4185","proc_othr_txt":"PARENTERAL NUTRITION SOL NOS 10 GRAMS LIPIDS","proc_cd_schm_ref_id":3768,"inac_ind":0}]}]}}};
const eventValue = "78130";

describe('ProcedureComponent', () => {
  let component: ProcedureComponent;
  let fixture: ComponentFixture<ProcedureComponent>;
  let mockConfigService: any;
  let httpClient: HttpClient;
  let umcaseService: UmcasewfGraphqlService;
  let umintakeGraphqlService: UmintakeGraphqlService;
  let cdrf: ChangeDetectorRef;

  beforeEach(async(() => {
    mockConfigService = jasmine.createSpyObj('mockConfigService', ['readConfig']);
    TestBed.configureTestingModule({
      declarations: [],
      providers: [
        ChangeDetectorRef,
        moment,
        { provide : UserAuthService, useClass: UserAuthServiceMock },
        MicroProductAuthService,
        UmcasewfGraphqlService,
        AuthService,
        OAuthInitService,
      ],
      imports: [HttpClientTestingModule, ProcedureModule, AuthLibraryModule, CommonModule, CheckboxModule, TableModule, SortModule],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProcedureComponent);
    component = fixture.componentInstance;
    component.procedureData = procedureJson;
    fixture.detectChanges();
    component.application = 'dummyName';
    umcaseService = TestBed.inject(UmcasewfGraphqlService);
    umintakeGraphqlService = TestBed.inject(UmintakeGraphqlService);
    httpClient = TestBed.inject(HttpClient);
    cdrf = TestBed.inject(ChangeDetectorRef);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initGraphqlService()', () => {
    component.hscId = 1234;
    spyOn(umcaseService, 'getProcedureCode').and.returnValue(of(procedureData));
    spyOn(umcaseService, 'getApiHeaders').and.returnValue(new HttpHeaders());
    spyOn(httpClient, 'post').and.returnValue(of(procedureDesc));
      component.initGraphqlService();
  });

  it('should ngOninit()', () => {
    component.procedureData = [];
    component.readOnly = true;
    component.serviceDetails = { srvc_set_ref_id: 3738,
      hsc_srvcs:[{
        "hsc_id": 18128,
        "hsc_srvc_id": 14386,
        "inac_ind": 0,
        "proc_cd": "78130",
        "proc_cd_schm_ref_id": 3767,
        "proc_othr_txt": "REDED CELL SURVIVAL STUDY",
        "srvc_hsc_prov": "IMRAN, ABASSI",
        "hsc_srvc_non_facl": {"srvc_dtl_ref_id": 1234,
          "srvc_dtl_ref_cd": {
            "ref_id": 1234,
            "ref_cd": "Testing",
            "ref_desc": "Testing",
            "ref_dspl": "Testing"
          },
          "unit_per_freq_cnt": 8,
          "proc_uom_ref_id" : 1234,
          "proc_uom_ref_cd" : {
            "ref_id": 1234,
            "ref_cd": "Hours",
            "ref_desc": "Hours",
            "ref_dspl": "Hours"
          },
          "proc_unit_cnt": 10,
          "proc_freq_ref_id":1234,
          "proc_freq_ref_cd" : {
            "ref_id": 1234,
            "ref_cd": "Hours",
            "ref_desc": "Hours",
            "ref_dspl": "Hours"
          },
          "srvc_end_dt": "05/10/2021",
          "srvc_strt_dt": "05/08/2021",
          "proc_mod_1_cd" : "00",
          "proc_mod_2_cd" : "01",
          "proc_mod_3_cd" : "02",
          "proc_mod_4_cd" : "03"
        }
      },{
        "hsc_id": 18128,
        "hsc_srvc_id": 14387,
        "inac_ind": 0,
        "proc_cd": "78130",
        "proc_cd_schm_ref_id": 3767,
        "proc_othr_txt": "RED CELL SURVIVAL STUDY",
        "srvc_hsc_prov": "IMRAN, ABASSI",
        "hsc_srvc_non_facl": {}
      }]
    };

    spyOn(umintakeGraphqlService, 'loadBaseRefNameDisplayData').and.returnValue(of(procedureType).toPromise());
    component.ngOnInit();
  });

  it('should removeProcedure()', () => {
    component.hscId = 1234;
    spyOn(umcaseService, 'getHscStatus').and.returnValue(of(hscStatus));
    spyOn(umcaseService, 'updateProcedure').and.returnValue(of(updateProc));
    component.removeProcedure(procedureList);
  });

  it('should getProcedureDateTime()', () => {
    component.getProcedureDateTime(hscService);
  });

  it('should ngAfterContentChecked()', () => {
    component.procedureDetails = [
      {
        name: 'A123 - Description needs to be added',
        dateOfProcedure: '02/03/2021 11:11 am',
        updated: '02/03/2021 11:11 am'
      },
      {
        name: 'A234 - Description needs to be added',
        dateOfProcedure: '02/04/2021 11:11 am',
        updated: '02/04/2021 11:11 am'
      }
    ];
    component.ngAfterContentChecked();
    expect(component.dataSource).toBeDefined();
  });

  it('should saveProcedure()', () => {
    component.hscId = 1234;
    const record = {
      Code: "B4185",
      Description: "PARENTERAL NUTRITION SOL NOS 10 GRAMS LIPIDS",
      Type: "HCPCS",
      TypeId: 3768
    };
    spyOn(umintakeGraphqlService, 'saveProcedure').and.returnValue(of(saveProcedure).toPromise());
    component.loadCaseProcedures(saveProcedure);
    component.saveProcedure(record, true);
  });

  it('should saveProcedure()', () => {
    component.reset();
    expect(component.reset).toBeTruthy();

  });
});
*/
