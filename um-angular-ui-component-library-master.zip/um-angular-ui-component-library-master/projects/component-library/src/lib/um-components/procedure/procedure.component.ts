import {
  Component,
  Input,
  ChangeDetectorRef,
  OnInit,
  AfterContentChecked,
  ViewChild,
  Injectable,
  Output, EventEmitter
} from '@angular/core';
import {ProcedureMockData} from "../models/procedure-mock-data";
import { EcpUclTableDataSource } from '@ecp/angular-ui-component-library/table';
import { EcpUclSort } from '@ecp/angular-ui-component-library/sort';
import {UmcasewfGraphqlService} from "../services/um/service/casewf/umcasewf-graphql.service";
import {GET_REF_NEW_URL_PATH} from "../../config/config-constants";
import {HttpClient} from "@angular/common/http";
import {ReferenceConstants} from "../../config/reference-constants";
import { getEnvVar } from '../services/environment/envVarUtil';
import {ProcedureServiceService} from "../services/um/service/procedure-service/procedure-service.service";
import {animate, state, style, transition, trigger} from "@angular/animations";
import {FormBuilder, FormControl, FormGroup, Validators} from "@angular/forms";
import {UmintakeGraphqlService} from "../services/um/service/um-intake/umintake-graphql.service";
import {EcpUclPaginator} from "@ecp/angular-ui-component-library/paginator";


export interface ProcedureElement {
  id: number;
  hscSrvcId: number;
  Type: string;
  Code: string;
  Description: string;
  ETA: string;
  Provider: string;
}

@Component({
  selector: 'um-procedure',
  templateUrl: './procedure.component.html',
  styleUrls: ['./procedure.component.scss'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({height: '0px', minHeight: '0'})),
      state('expanded', style({height: '*'})),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ]
})

export class ProcedureComponent implements OnInit, AfterContentChecked {
  @Input() hscId : number;
  @Input() showDetailsView: boolean;
  @Input() typeAheadSearch: boolean;
  @Input() application = '';
  @Input() procedureData=[];
  @Input() serviceDetails;
  @Input() readOnly: boolean;
  @Input() summaryViewOnly: boolean;
  @Output() emitProcedureData: EventEmitter<any> = new EventEmitter();
  @Output() action: EventEmitter<any> = new EventEmitter();

  pageOptions: number[];
  //primary: any;
  //variant;
  tableHeaders = ['Type', 'Code', 'Description', 'Details', 'ETA', 'Provider', 'DTQ', 'Status', 'Remove'];
  procListHeaders = ['Fav', 'Type', 'Code', 'Description', 'Use'];
  configHeader = {
    Type: 'Type',
    Code: 'Code',
    Description: 'Description',
    Details: 'Details',
    ETA: 'ETA',
    Provider: 'Provider',
    DTQ: 'DTQ',
    Status: 'Status',
    Remove: 'Remove'
  };
  procConfigHeader = {
    Fav: 'Fav',
    Type: 'Type',
    Code: 'Code',
    Description: 'Description',
    Use: 'Use'
  };
 procedureDetails = [];
 dateOfProcedureValue = [];
 updatedValue = [];
 procedureValue : ProcedureElement[]=[];
 numberOfRecords;
  isChecked: boolean;
  expandedElement: ProcedureElement | null;
  procedureForm = new FormGroup({
    serviceDetail: new FormControl(null, Validators.required),
    total: new FormControl(null, Validators.required),
    measure: new FormControl(null, Validators.required),
    count: new FormControl(null, Validators.required),
    frequency: new FormControl(null, Validators.required),
    startDate: new FormControl(null, Validators.required),
    serviceEndDate: new FormControl(null, Validators.required),
    modifier1: new FormControl(null),
    modifier2: new FormControl(null),
    modifier3: new FormControl(null),
    modifier4: new FormControl(null)
  });
  procedureSearchForm: FormGroup;
  public procedureTypes = [];
  public procFrequencyList = [];
  public procStndMeasureList = [];
  public procedureModifierList = [];
  selectedMeasure: string;
  selectedFrequency: string;
  selectedModifier1: string;
  selectedModifier2: string;
  selectedModifier3: string;
  selectedModifier4: string;
  selectedProcedureType: string;

  dataSource: EcpUclTableDataSource<any>;
  procedureList: EcpUclTableDataSource<any>;
  @ViewChild(EcpUclSort) sort: EcpUclSort;
  @ViewChild(EcpUclPaginator) typeAheadPaginator: EcpUclPaginator;
  @ViewChild('cSort') caseSort: EcpUclSort;

  constructor(private readonly mockData: ProcedureMockData,
              private cdref: ChangeDetectorRef,private umcaseService: UmcasewfGraphqlService, public umintakeGraphqlService: UmintakeGraphqlService,
              private httpClient: HttpClient, private procedureService: ProcedureServiceService) {
    this.isChecked = false;
    this.pageOptions = [5, 10, 25];
  }

  procedureListValues = [];

  async ngOnInit() {
    this.populateProcedureType();
    this.procedureSearchForm = new FormGroup({
      procedureType: new FormControl(this.procedureTypes[0]),
      procedureValue: new FormControl(null)
    });
    this.getprocFrequencyListQuery();
    this.getstandardMeasureListQuery();
    this.getprocedureModifierListQuery();
    if (this.procedureData && this.procedureData.length > 0) {
      this.procedureDetails = this.procedureData;
    } else {
      if (this.serviceDetails.hsc_srvcs && this.serviceDetails.hsc_srvcs.length > 0) {
        await this.loadProcedureData();
      } else {
        this.initGraphqlService();
      }
    }
  }

  private async loadProcedureData() {
    this.buildTableHeaders();
    if (this.serviceDetails.hsc_srvcs.length > 0) {
      for (let j = 0; j < this.serviceDetails.hsc_srvcs.length; j++) {
        if(this.serviceDetails.hsc_srvcs[j].inac_ind == 0){
          this.procedureValue.push({
            id: j,
            hscSrvcId: this.serviceDetails.hsc_srvcs[j].hsc_srvc_id,
            Type: this.serviceDetails.hsc_srvcs[j].proc_cd_schm_ref_id == ReferenceConstants.PROCEDURE_HCPCS_CODE_TYPE_REF_ID ? ReferenceConstants.PROCEDURE_HCPCS_CODE_TYPE_REF_CD : ReferenceConstants.PROCEDURE_CPT_CODE_TYPE_REF_CD,
            Code: this.serviceDetails.hsc_srvcs[j].proc_cd,
            Description: this.serviceDetails.hsc_srvcs[j].proc_othr_txt,
            ETA: '',
            Provider: this.serviceDetails.hsc_srvcs[j].srvc_hsc_prov
          });
        }
        for (let k = 0; k < this.procedureValue.length; k++) {
          await this.procedureService.getServiceETA(this.procedureValue[k]);
        }
      }
    }
  }

  private buildTableHeaders() {
    if (this.serviceDetails.srvc_set_ref_id == 3738) {
      if (this.readOnly) {
        this.tableHeaders = ['Type', 'Code', 'Description', 'Details', 'ETA', 'Provider'];
      } else {
        this.tableHeaders = ['Type', 'Code', 'Description', 'Details', 'ETA', 'Provider', 'DTQ', 'Status', 'Remove'];
      }
    } else {
      if (this.readOnly) {
        this.tableHeaders = ['Type', 'Code', 'Description', 'Details', 'ETA', 'Provider'];
      } else {
        this.tableHeaders = ['Type', 'Code', 'Description', 'Details', 'ETA', 'Provider', 'DTQ', 'Status', 'Remove'];
      }
    }
  }

  ngAfterContentChecked() {
    this.dataSource = new EcpUclTableDataSource(this.procedureValue);
    this.dataSource.sort = this.sort;
   // this.procedureList = new EcpUclTableDataSource(this.procedureListValues);
   // this.procedureList.sort = this.caseSort;
    this.cdref.detectChanges();
  }


  public async initGraphqlService(){
    await this.umintakeGraphqlService.getHscDetails(this.hscId,this.application).then((response)=>{
        for(let j=0; j<response.data.getHscAuthDetails.hsc[0].hsc_srvcs.length; j++){
            let referenceQuery;
            const proc_cd = response.data.getHscAuthDetails.hsc[0].hsc_srvcs[j].proc_cd;
             this.getProcedureDateTime(response.data.getHscAuthDetails.hsc[0].hsc_srvcs[j]);
             if (response.data.getHscAuthDetails.hsc[0].hsc_srvcs[j].proc_cd_schm_ref_id == ReferenceConstants.PROCEDURE_CPT_CODE_TYPE_REF_ID) {
              referenceQuery = this.umcaseService.getProcedureDescCPTQuery(proc_cd);
            } else if (response.data.getHscAuthDetails.hsc[0].hsc_srvcs[j].proc_cd_schm_ref_id == ReferenceConstants.PROCEDURE_HCPCS_CODE_TYPE_REF_ID) {
              referenceQuery = this.umcaseService.getProcedureDescHCPCSQuery(proc_cd);
            }
          const refUrl = getEnvVar(GET_REF_NEW_URL_PATH);
          this.httpClient.post(refUrl, JSON.stringify(referenceQuery), {headers: this.umcaseService.getApiHeaders(this.application)}).subscribe(async (icd10Response: any) => {
            this.procedureDetails.push(icd10Response.data.hcpcs ? icd10Response.data.hcpcs[0] : icd10Response.data.cpt4[0]);
            for (let i = 0; i < this.procedureDetails.length; i++) {
              this.procedureDetails[i].dateOfProcedure = this.dateOfProcedureValue[i];
              this.procedureDetails[i].updated = this.updatedValue[i];
            }
            this.getProcedureForTableView(response, j);
            for (let k = 0; k < this.procedureValue.length; k++) {
              await this.procedureService.getServiceETA(this.procedureValue[k]);
            }
            this.numberOfRecords = this.procedureValue.length;
          });

          };
    });
  }

  private getProcedureForTableView(response, j: number) {
    this.serviceDetails.hsc_srvcs = [];
      this.procedureValue.push({
        id: j,
        hscSrvcId: response.data.getHscAuthDetails.hsc[0].hsc_srvcs[j].hsc_srvc_id,
        Type: response.data.getHscAuthDetails.hsc[0].hsc_srvcs[j].proc_cd_schm_ref_id == ReferenceConstants.PROCEDURE_HCPCS_CODE_TYPE_REF_ID? ReferenceConstants.PROCEDURE_HCPCS_CODE_TYPE_REF_CD : ReferenceConstants.PROCEDURE_CPT_CODE_TYPE_REF_CD ,
        Code: response.data.getHscAuthDetails.hsc[0].hsc_srvcs[j].proc_cd,
        Description: response.data.getHscAuthDetails.hsc[0].hsc_srvcs[j].proc_othr_txt,
        ETA: '',
        Provider: 'Facility'
      });
      this.serviceDetails.hsc_srvcs.push({
        "hsc_id": this.hscId,
        "hsc_srvc_id": response.data.getHscAuthDetails.hsc[0].hsc_srvcs[j].hsc_srvc_id,
        "inac_ind": response.data.getHscAuthDetails.hsc[0].hsc_srvcs[j].inac_ind,
        "proc_cd": response.data.getHscAuthDetails.hsc[0].hsc_srvcs[j].proc_cd,
        "proc_cd_schm_ref_id": response.data.getHscAuthDetails.hsc[0].hsc_srvcs[j].proc_cd_schm_ref_id,
        "proc_othr_txt": response.data.getHscAuthDetails.hsc[0].hsc_srvcs[j].proc_othr_txt,
        "srvc_hsc_prov_id": response.data.getHscAuthDetails.hsc[0].hsc_srvcs[j].srvc_hsc_prov_id,
        "srvc_hsc_prov": "IMRAN, ABASSI",
        "hsc_srvc_non_facls": []
      });
    }

  assignFormValues(record){
    const id = record.id;
    this.procedureForm = new FormGroup({
      serviceDetail: new FormControl(this.serviceDetails.hsc_srvcs[id].hsc_srvc_non_facl?.srvc_dtl_ref_cd? this.serviceDetails.hsc_srvcs[id].hsc_srvc_non_facl.srvc_dtl_ref_cd.ref_desc :null, Validators.required),
      total: new FormControl(this.serviceDetails.hsc_srvcs[id].hsc_srvc_non_facl?.unit_per_freq_cnt? this.serviceDetails.hsc_srvcs[id].hsc_srvc_non_facl.unit_per_freq_cnt: null, Validators.required),
      measure: new FormControl(this.serviceDetails.hsc_srvcs[id].hsc_srvc_non_facl?.proc_uom_ref_cd? this.serviceDetails.hsc_srvcs[id].hsc_srvc_non_facl.proc_uom_ref_cd.ref_desc : null, Validators.required),
      count: new FormControl(this.serviceDetails.hsc_srvcs[id].hsc_srvc_non_facl?.proc_unit_cnt? this.serviceDetails.hsc_srvcs[id].hsc_srvc_non_facl.proc_unit_cnt:null, Validators.required),
      frequency: new FormControl(this.serviceDetails.hsc_srvcs[id].hsc_srvc_non_facl?.proc_freq_ref_cd? this.serviceDetails.hsc_srvcs[id].hsc_srvc_non_facl.proc_freq_ref_cd.ref_desc :null, Validators.required),
      startDate: new FormControl(this.serviceDetails.hsc_srvcs[id].hsc_srvc_non_facl?.srvc_strt_dt ? this.serviceDetails.hsc_srvcs[id].hsc_srvc_non_facl.srvc_strt_dt :null, Validators.required),
      serviceEndDate: new FormControl(this.serviceDetails.hsc_srvcs[id].hsc_srvc_non_facl?.srvc_end_dt ? this.serviceDetails.hsc_srvcs[id].hsc_srvc_non_facl.srvc_end_dt :null, Validators.required),
      modifier1: new FormControl(this.serviceDetails.hsc_srvcs[id].hsc_srvc_non_facl?.proc_mod_1_cd? this.serviceDetails.hsc_srvcs[id].hsc_srvc_non_facl.proc_mod_1_cd : null, Validators.required),
      modifier2: new FormControl(this.serviceDetails.hsc_srvcs[id].hsc_srvc_non_facl?.proc_mod_2_cd? this.serviceDetails.hsc_srvcs[id].hsc_srvc_non_facl.proc_mod_2_cd : null, Validators.required),
      modifier3: new FormControl(this.serviceDetails.hsc_srvcs[id].hsc_srvc_non_facl?.proc_mod_3_cd? this.serviceDetails.hsc_srvcs[id].hsc_srvc_non_facl.proc_mod_3_cd : null, Validators.required),
      modifier4: new FormControl(this.serviceDetails.hsc_srvcs[id].hsc_srvc_non_facl?.proc_mod_4_cd? this.serviceDetails.hsc_srvcs[id].hsc_srvc_non_facl.proc_mod_4_cd : null, Validators.required)
    });

  }

  async removeProcedure(record){
    this.umcaseService.getHscStatus(this.hscId,this.application).subscribe((response)=> {
      if (response.data.hsc[0].hsc_sts_ref_id == 19274) {
        this.umcaseService.deleteProcedure(this.hscId, record.hscSrvcId, this.application).subscribe((data)=>{
          this.procedureDetails = [];
          this.procedureValue = [];
          this.initGraphqlService()
        });

      } else {
        this.umcaseService.updateProcedure(record.hscSrvcId, this.application).subscribe((data)=>{
          this.procedureDetails = [];
          this.procedureValue = [];
          this.initGraphqlService()
        });
      }
    })

  }
  // submitForm(){
  //
  // }

  getProcedureDateTime(hscService){
    const createDateTime = hscService.creat_dttm;
    const dateOfProc = createDateTime.replace("/-/g","/").replace("T"," ");
    var procedureDate = new Date(dateOfProc);
    const dateOfProcedure = ("0" + (procedureDate.getMonth() + 1)).slice(-2) + '/' + ("0" + procedureDate.getDate()).slice(-2) + '/' + procedureDate.getFullYear() + ' ' + ("0" +procedureDate.getHours()% 12).slice(-2)+ ':' + procedureDate.getMinutes();
    const time = procedureDate.getHours() >= 12 ? 'pm' : 'am';
     this.dateOfProcedureValue.push(dateOfProcedure + " " + time);
    const changeDateTime = hscService.chg_dttm;
    const updated= changeDateTime.replace("/-/g","/").replace("T"," ");
    var dateUpdated = new Date(updated);
    const updatedDate = ("0" + (dateUpdated.getMonth() + 1)).slice(-2) + '/' +("0" + dateUpdated.getDate()).slice(-2) + '/' + dateUpdated.getFullYear() + ' ' + ("0" +dateUpdated.getHours()% 12).slice(-2)+ ':' + dateUpdated.getMinutes();
    const updatedTime = dateUpdated.getHours() >= 12 ? 'pm' : 'am';
    this.updatedValue.push(updatedDate + " " + updatedTime);

  }

  async applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    const filterType = this.procedureSearchForm.value.procedureType;
    await this.umintakeGraphqlService.getProcedures(filterValue,filterType, this.application).then((res) => {
      this.procedureListValues = [];
      res.data.ProcedureSmartSearch.forEach(item => {
        let procedureType;
        if(item.searchType == 'hcpcs_search'){
          procedureType = ReferenceConstants.PROCEDURE_HCPCS_CODE_TYPE_REF_CD;
        }else{
          procedureType = ReferenceConstants.PROCEDURE_CPT_CODE_TYPE_REF_CD;
        }
        this.procedureListValues.push(
          {
            Type: procedureType,
            Code: item.code,
            Description: item.description
          }
        );
      });
      this.procedureList = new EcpUclTableDataSource(this.procedureListValues);
      this.procedureList.sort = this.sort;
      this.procedureList.paginator = this.typeAheadPaginator;
    });
  }

  populateProcedureType() {
    this.procedureTypes = [];
    const procCodeTypeBaseRefName = 'procCodeType';
    this.umintakeGraphqlService.loadBaseRefNameDisplayData(this.application, procCodeTypeBaseRefName).then((res) => {
      res.data.ref.forEach((item: { ref_id: number; ref_dspl: string; ref_desc: string; }) => {
        const departmentTypeObj = {
          name: item.ref_dspl,
          value: item.ref_id,
        };
        this.procedureTypes.push(departmentTypeObj);
      });
    });
  }


  async saveProcedure(record: any, isChecked: boolean){
    if(isChecked){
      if(record.Type == ReferenceConstants.PROCEDURE_CPT_CODE_TYPE_REF_CD){
        record.TypeId = ReferenceConstants.PROCEDURE_CPT_CODE_TYPE_REF_ID
      }
      else{
        record.TypeId = ReferenceConstants.PROCEDURE_HCPCS_CODE_TYPE_REF_ID
      }
      this.umintakeGraphqlService.saveProcedure(this.hscId, record, this.application, this.serviceDetails.srvc_set_ref_id).then(async (res) => {
        if (res.data) {
          this.serviceDetails.hsc_srvcs = [];
          this.procedureValue = [];
          await this.loadCaseProcedures(res);
        }
      })
      }
  }

  async loadCaseProcedures(res) {
    for (let z = 0; z < res.data.updateHsc.hsc[0].hsc_srvcs.length; z++) {
      if (res.data.updateHsc.hsc[0].hsc_srvcs[z].inac_ind == 0) {
        this.serviceDetails.hsc_srvcs.push({
          "hsc_id": this.hscId,
          "hsc_srvc_id": res.data.updateHsc.hsc[0].hsc_srvcs[z].hsc_srvc_id,
          "inac_ind": res.data.updateHsc.hsc[0].hsc_srvcs[z].inac_ind,
          "proc_cd": res.data.updateHsc.hsc[0].hsc_srvcs[z].proc_cd,
          "proc_cd_schm_ref_id": res.data.updateHsc.hsc[0].hsc_srvcs[z].proc_cd_schm_ref_id,
          "proc_othr_txt": res.data.updateHsc.hsc[0].hsc_srvcs[z].proc_othr_txt,
          "srvc_hsc_prov_id": res.data.updateHsc.hsc[0].hsc_srvcs[z].srvc_hsc_prov_id,
          "srvc_hsc_prov": "IMRAN, ABASSI",
          "hsc_srvc_non_facls": []
        });
        this.procedureValue.push({
          id: z,
          hscSrvcId: res.data.updateHsc.hsc[0].hsc_srvcs[z].hsc_srvc_id,
          Type: res.data.updateHsc.hsc[0].hsc_srvcs[z].proc_cd_schm_ref_id == ReferenceConstants.PROCEDURE_HCPCS_CODE_TYPE_REF_ID ? ReferenceConstants.PROCEDURE_HCPCS_CODE_TYPE_REF_CD : ReferenceConstants.PROCEDURE_CPT_CODE_TYPE_REF_CD,
          Code: res.data.updateHsc.hsc[0].hsc_srvcs[z].proc_cd,
          Description: res.data.updateHsc.hsc[0].hsc_srvcs[z].proc_othr_txt,
          ETA: '',
          Provider: res.data.updateHsc.hsc[0].hsc_srvcs[z].srvc_hsc_prov ? res.data.updateHsc.hsc[0].hsc_srvcs[z].srvc_hsc_prov : null
        });
      }
    }

    for (let k = 0; k < this.procedureValue.length; k++) {
      await this.procedureService.getServiceETA(this.procedureValue[k]);
    }
  }

  reset(){
    this.procedureSearchForm = new FormGroup({
      procedureType: new FormControl(this.procedureTypes[0]),
      procedureValue: new FormControl(null)
    });
    this.procedureListValues = [];
    this.procedureList = new EcpUclTableDataSource(this.procedureListValues);
    // this.procedureList.sort = this.sort;
    this.procedureList.sort = this.caseSort;
  }

  //Outpatient

  getprocFrequencyListQuery() {
    const procFrequencyBaseRefName = 'actualProcedureFrequencyType';
    this.umintakeGraphqlService.loadBaseRefNameDisplayData(this.application, procFrequencyBaseRefName).then((res) => {
      res.data.ref.forEach((item: { ref_id: number; ref_dspl: string; ref_desc: string; }) => {
        const procFrequencyObj = {
          name: item.ref_dspl,
          value: item.ref_id,
        };
        this.procFrequencyList.push(procFrequencyObj);
      });
    });
  }

  getstandardMeasureListQuery() {
    const standardOfMeasureBaseRefName = 'procedureUnitOfMeasureType';
      this.umintakeGraphqlService.loadBaseRefNameDisplayData(this.application, standardOfMeasureBaseRefName).then((res) => {
        res.data.ref.forEach((item: { ref_id: number; ref_dspl: string; ref_desc: string; }) => {
          const stndMeasureResponse = {
            name: item.ref_dspl,
            value: item.ref_id,
          };
          this.procStndMeasureList.push(stndMeasureResponse);
        });
      });
  }

  getprocedureModifierListQuery() {
    const procFrequencyBaseRefName = 'procedureModifier';
    this.umintakeGraphqlService.loadBaseRefNameDisplayData(this.application, procFrequencyBaseRefName).then((res) => {
      res.data.ref.forEach((item: { ref_id: number; ref_dspl: string; ref_desc: string; }) => {
        const procFrequencyResponse = {
          name: item.ref_dspl,
          value: item.ref_id,
        };
        this.procedureModifierList.push(procFrequencyResponse);
      });
    });
  }
   viewDetails()
      {
        this.action.next();
      }
}
