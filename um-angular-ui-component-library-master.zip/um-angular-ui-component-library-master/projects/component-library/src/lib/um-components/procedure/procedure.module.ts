import { NgModule } from '@angular/core';
import {APP_BASE_HREF, CommonModule} from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import {BrowserAnimationsModule, NoopAnimationsModule} from '@angular/platform-browser/animations';
import { TabsModule } from '@ecp/angular-ui-component-library/tabs';
import {MatGridListModule} from '@angular/material/grid-list';
import { ButtonModule } from '@ecp/angular-ui-component-library/button';
import { IconsModule } from '@ecp/angular-ui-component-library/icons';
import {MatIconModule} from '@angular/material/icon';
import {TableModule} from '@ecp/angular-ui-component-library/table';
import {SortModule} from '@ecp/angular-ui-component-library/sort';
import {LinkModule} from '@ecp/angular-ui-component-library/link';
import {ProcedureComponent} from './procedure.component';
import {CardModule} from '@ecp/angular-ui-component-library/card';
import {HttpClientModule} from "@angular/common/http";
import {UserAuthService} from "../services/auth/user.service";
import {AuthLibraryModule} from "@ecp/auth-library";
import { CheckboxModule } from '@ecp/angular-ui-component-library/checkbox';
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import { SelectModule } from '@ecp/angular-ui-component-library/select';
import { FormFieldModule } from '@ecp/angular-ui-component-library/form-field';
import { OptionModule } from '@ecp/angular-ui-component-library/option';
import {InputModule} from "@ecp/angular-ui-component-library/input";
import { PaginatorModule} from '@ecp/angular-ui-component-library/paginator';
import { DatepickerModule, DatepickerInputModule } from '@ecp/angular-ui-component-library/datepicker';
import {TagsModule} from "@ecp/angular-ui-component-library/tags";

@NgModule({
  declarations: [
    ProcedureComponent
  ],
  imports: [
    CommonModule,
    BrowserModule,
    BrowserAnimationsModule,
    MatGridListModule,
    MatIconModule,
    TableModule,
    ButtonModule,
    TabsModule,
    IconsModule,
    SortModule,
    LinkModule,
    CardModule,
    AuthLibraryModule,
    HttpClientModule,
    CheckboxModule,
    NoopAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    FormFieldModule,
    SelectModule,
    OptionModule,
    InputModule,
    PaginatorModule,
    InputModule,
    DatepickerModule,
    DatepickerInputModule,
    TagsModule
  ],
  exports: [
    ProcedureComponent
  ],
  providers: [UserAuthService,{provide: APP_BASE_HREF, useValue: '/'}]
})
export class ProcedureModule { }
