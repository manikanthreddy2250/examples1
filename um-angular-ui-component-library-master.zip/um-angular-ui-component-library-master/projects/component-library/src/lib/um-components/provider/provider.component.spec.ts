import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ProviderComponent } from './provider.component';
import {AuthLibraryModule, AuthService, MicroProductAuthService} from "@ecp/auth-library";
import {HttpClientTestingModule} from "@angular/common/http/testing";
import {UserAuthService} from "../services/auth/user.service";
import {UmcasewfGraphqlService} from "../services/um/service/casewf/umcasewf-graphql.service";
import {Observable, of, throwError} from "rxjs";
import {Injectable, ChangeDetectorRef} from "@angular/core";
import {HttpClient, HttpClientModule} from "@angular/common/http";
import { CommonModule } from '@angular/common';
import { TableModule } from '@ecp/angular-ui-component-library/table';
import { PaginatorModule, EcpUclPaginatorIntl } from '@ecp/angular-ui-component-library/paginator';
import { SortModule } from '@ecp/angular-ui-component-library/sort';
import { CardModule } from '@ecp/angular-ui-component-library/card';
import { ProviderGraphqlService } from '../services/um/service/provider/provider-graphql.service';
import { ProgressSpinnerModule } from '@ecp/angular-ui-component-library/progress-spinner';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/compiler';
import { EcpUclPaginator } from '@ecp/angular-ui-component-library/paginator';
import { EcpUclSort } from '@ecp/angular-ui-component-library/sort';
import { ProviderModule } from './provider.module';
import { UmintakeGraphqlService } from '../services/um/service/um-intake/umintake-graphql.service';


@Injectable()
class UserAuthServiceMock {

  getUserID() {
    return 'TESTUSERID';
  }

  isLocalHost() {
    return false;
  }

  getActiveClientOrg() {
    return 'ecp'
  }

  getActiveUserRole() {
    return 'sys_admin'
  }

  getAltUserID() {
    return 'test';
  }

  getUserHasuraRole() {
    return 'test'
  }
}


@Injectable()
class UmIntakeServiceMock {
  loadRefDataByRefIds(appname:any, refid:any){
    return of({data : { hsr_ref: [{ref_id: 1101, ref_dspl: "AA"},{ref_id: 16309, ref_dspl: "PHYSICIAN"}]}});
  }
}

const dataRecord = {
                      adr_ln_1_txt: "10101 SE Main St Ste 1006",
                      adr_ln_2_txt: "Dr Taylor",
                      bus_nm: null,
                      cty_nm: "Portland",
                      distance: 7,
                      fst_nm: "HOWARD",
                      hsc_prov_id: 8601,
                      hsc_prov_roles: [{prov_role_ref_id: 3759, prov_role_ref_cd: {ref_dspl:"abcd"}}],
                      isFav: false,
                      lst_nm: "TAYLOR",
                      ntwk_sts_ref_cd: {ref_dspl: "In"},
                      ntwk_sts_ref_id: null,
                      prov_adr_id: 23200502,
                      prov_catgy_ref_cd: {ref_dspl: "HealthCare Practitioner"},
                      prov_catgy_ref_id: 16309,
                      prov_id: 6675410,
                      prov_key_typ_ref_cd: {ref_dspl: "NPI"},
                      prov_key_typ_ref_id: 2782,
                      prov_key_val: "1255539573",
                      spcl_ref_cd: {ref_dspl: "2084N0400X"},
                      spcl_ref_id: 16749,
                      st_ref_cd: {ref_dspl: "OREGON"},
                      st_ref_id: 1104,
                      telcom_adr_id: "5032563055",
                      zip_cd_txt: "97216"
}

describe('ProviderComponent', () => {
  let component: ProviderComponent;
  let fixture: ComponentFixture<ProviderComponent>;
  let authService: AuthService;
  let microProductAuth: MicroProductAuthService;
  let umcaseService: UmcasewfGraphqlService;
  let providerGraphQlService:ProviderGraphqlService;

  const providerListData = {
    "user_favs": [
       {
        "adr_ln_1_txt": "300 Flatbush Ave",
        "adr_ln_2_txt": null,
        "bus_nm": null,
        "cty_nm": "Brooklyn",
        "distance": 7,
        "fst_nm": "CINTIA",
        "hsc_prov_roles": [],
        "lst_nm": "ROGUIN",
        "ntwk_sts_ref_cd": {"ref_dspl": "In"},
        "ntwk_sts_ref_id": null,
        "prov_adr_id": 17788,
        "prov_catgy_ref_cd": {"ref_dspl": "HCP", "ref_desc": "HealthCare Practitioner"},
        "prov_catgy_ref_id": 16309,
        "prov_id": 167070,
        "prov_key_typ_ref_cd": {"ref_dspl": "NPI"},
        "prov_key_typ_ref_id": 2782,
        "prov_key_val": "1255539573",
        "spcl_ref_cd": {ref_dspl: "174400000X"},
        "spcl_ref_id": 16536,
        "st_ref_cd": {ref_dspl: "NEW YORK"},
        "st_ref_id": 1101,
        "telcom_adr_id": "7186222000",
        "zip_cd_txt": "11217"
       }
    ],
    "hsc_provs": [
       {
        "adr_ln_1_txt": "174 BARNWOOD DR",
        "adr_ln_2_txt": null,
        "bus_nm": "HOGUE CHIROPRACTIC CENTER PLLC",
        "cty_nm": "EDGEWOOD",
        "distance": 7,
        "fst_nm": null,
        "hsc_prov_id": 8600,
        "hsc_prov_roles":[{prov_role_ref_id: 3764, prov_role_ref_cd: {ref_dspl: "Requesting"}}],
        "isFav": false,
        "lst_nm": null,
        "ntwk_sts_ref_cd": {ref_dspl: "In"},
        "ntwk_sts_ref_id": null,
        "prov_adr_id": 29700446,
        "prov_catgy_ref_cd": {ref_dspl: "HealthCare Organization"},
        "prov_catgy_ref_id": 16310,
        "prov_id": 7268882,
        "prov_key_typ_ref_cd": {ref_dspl: "TAX"},
        "prov_key_typ_ref_id": 16333,
        "prov_key_val": "806930103",
        "spcl_ref_cd": {ref_dspl: "193400000X"},
        "spcl_ref_id": 16567,
        "st_ref_cd": {ref_dspl: "KENTUCKY"},
        "st_ref_id": 1082,
        "telcom_adr_id": "8593417746",
        "zip_cd_txt": "41017",
       }
    ]
 }
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProviderComponent ],
      imports: [HttpClientTestingModule, AuthLibraryModule,TableModule,CommonModule,
                    PaginatorModule,SortModule,CardModule,ProgressSpinnerModule],
      providers: [UserAuthService,ChangeDetectorRef,ProviderGraphqlService,EcpUclPaginator, EcpUclSort,{provide : UserAuthService, useClass: UserAuthServiceMock },
                  {provide : UmintakeGraphqlService, useClass: UmIntakeServiceMock}],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
    authService = TestBed.inject(AuthService);
    microProductAuth = TestBed.inject(MicroProductAuthService);
    umcaseService = TestBed.inject(UmcasewfGraphqlService);
    providerGraphQlService = TestBed.inject(ProviderGraphqlService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProviderComponent);
    component = fixture.componentInstance;
    fixture.autoDetectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call ngOnInit with provided JSON', () => {
    component.providerDetailsJSON = providerListData;
    component.ngOnInit();
  });

  it('should call Save Fav Provider', () => {
    component.application = "testapp"
    const record : any = {isFav: false,prov_adr_id: 123,};
    const res: any = { data: { insert_user_fav : { returning :[{user_fav_id : 123}]}}}
    const userspy = spyOn(providerGraphQlService, 'saveFavorite').and.returnValue(res);
    component.saveFavProvder(record);
    expect(userspy).toHaveBeenCalled();
  });

  it('should call Get Provider Details', () => {
    component.application = "testapp"
    const res: any = { data: { hsc : [{ hsc_provs :[{
      hsc_prov_id: 8600,
      hsc_prov_roles: [{prov_role_ref_id: 3761}],
      prov_key_typ_ref_id: 16333,
      prov_key_typ_ref_cd: {ref_dspl: "NPI"},
      prov_key_val: "806930103",
      prov_loc_affil_dtl: { providerDetails: {
                                    prov_adr_id: 29700446,
                                    prov_catgy_ref_cd:{ref_dspl: "HealthCare Practitioner"},
                                    prov_catgy_ref_id: 16309,
                                    prov_id: 6675410,
                                    prov_adr:{
                                      adr_ln_1_txt: "300 Flatbush Ave",
                                      adr_ln_2_txt: null,
                                      cty_nm: "Brooklyn",
                                      st_ref_id: 1101,
                                      zip_cd_txt: "11217"
                                    },
                                    prov_keys: [{prov_key_val: "806930103", prov_key_typ_ref_id: 16333}],
                                  }},
      spcl_ref_cd: {ref_dspl: "193400000X"},
      spcl_ref_id: 16567,
      telcom_adr_id: "8593417746"
  }]}]}}
    const userspy = spyOn(providerGraphQlService, 'getProvDetailsByHscId').and.returnValue(res);
    component.showDetailsView = true;
    component.hscID = 1234;
    component.ngOnInit();
    component.getProviderDetails();
    expect(userspy).toHaveBeenCalled();
  });

  it('should delete fav Details', () => {
    component.application = "testapp"
    const res: any = { data: { delete_user_fav : { returning :[{user_id : 123}]}}}
    const record : any = {isFav: false,prov_adr_id: 123,};
    const userspy = spyOn(providerGraphQlService, 'deleteFavorite').and.returnValue(res);
    component.deleteFavProvder(record);
    expect(userspy).toHaveBeenCalled();
  });

  it('should call has Role function ', () => {
    component.application = "testapp"
    const refId = 3761;
    const record : any = {hsc_prov_roles: [{prov_role_ref_id: 3761}]};
    expect(component.hasRole(record,refId)).toEqual(true);
  });

  it('should call Get Provider Fav Details', () => {
    component.application = "testapp"
    const res: any = { data: { user_fav : [{ user_fav_val: "29700446" },{ user_fav_val: "123456" }]}}
    const userspy = spyOn(providerGraphQlService, 'getUserFavorites').and.returnValue(res);
    const resProv: any = {data : {v_prov_srch : [{
                                              adr_ln_1_txt: "300 Flatbush Ave",
                                              adr_ln_2_txt: null,
                                              bus_nm: null,
                                              cty_nm: "Brooklyn",
                                              fst_nm: "CINTIA",
                                              lst_nm: "ROGUIN",
                                              prov_adr_id: 17788,
                                              prov_catgy_ref_cd: {ref_dspl: "HCP", ref_desc: "HealthCare Practitioner"},
                                              prov_catgy_ref_id: 16309,
                                              prov_id: 167070,
                                              prov_key_typ_ref_cd: {ref_dspl: "NPI"},
                                              prov_key_typ_ref_id: 2782,
                                              prov_key_val: "1255539573",
                                              spcl_ref_cd: {ref_dspl: "174400000X"},
                                              spcl_ref_id: 16536,
                                              st_ref_cd: null,
                                              st_ref_id: 1101,
                                              telcom_adr_id: "7186222000",
                                              zip_cd_txt: "11217"
  }]}}
    const provSpy = spyOn(providerGraphQlService,'getProvDetailsByAdrId');
    provSpy.and.returnValue((resProv));
    component.showLandingPageProviders = true;
    component.showFavouriteProviders = true;
    component.ngOnInit();
    component.getUserFavoriteProviders();
    expect(userspy).toHaveBeenCalled();
  });

  it('should Save Provider Details', () => {
    component.application = "testapp"
    const record : any = {isFav: false,prov_adr_id: 123,hsc_prov_roles: [{prov_role_ref_id: 3761}]};
    component.providerCaseData = [{prov_adr_id: 123}]
    component.saveProvider(record,3761);
  });

  it('should update new Provider Details', () => {
    component.application = "testapp";
    const record : any = {isFav: false,prov_adr_id: 123,hsc_prov_roles: [{prov_role_ref_id: 3761}]};
    component.providerCaseData = [{prov_adr_id: 123}]
    component.updateProvider(record,3761, true);
  });

  it('should remove Provider roles', () => {
    component.application = "testapp";
    const record : any = {isFav: false,prov_adr_id: 123,hsc_prov_roles: [{prov_role_ref_id: 3761}]};
    component.providerCaseData = [{prov_adr_id: 123}]
    component.updateProvider(record,3761, false);
  });

  it('should delete Provider', () => {
    component.application = "testapp";
    const record : any = {isFav: false,prov_adr_id: 123,hsc_prov_roles: [{prov_role_ref_id: 3761}]};
    component.providerCaseData = [{prov_adr_id: 123}]
    component.removeProvider(record);
  });


  it('should Save  New Provider Details', () => {
    component.application = "testapp"
    const record : any = {isFav: false,prov_adr_id: 123,hsc_prov_roles: [{prov_role_ref_id: 3762}]};
    component.providerCaseData = [{prov_adr_id: 123}]
    component.saveProvider(record,3761);
  });

  it('should Validate Provider Details', () => {
    component.providerCaseData = [{
              adr_ln_1_txt: "10101 SE Main St Ste 1006",
              adr_ln_2_txt: "Dr Taylor",
              bus_nm: null,
              cty_nm: "Portland",
              distance: 7,
              fst_nm: "HOWARD",
              hsc_prov_id: 8601,
              hsc_prov_roles: [{prov_role_ref_id: 3759, prov_role_ref_cd: {ref_dspl:"abcd"}}],
              isFav: false,
              lst_nm: "TAYLOR",
              ntwk_sts_ref_cd: {ref_dspl: "In"},
              ntwk_sts_ref_id: null,
              prov_adr_id: 23200502,
              prov_catgy_ref_cd: {ref_dspl: "HealthCare Practitioner"},
              prov_catgy_ref_id: 16309,
              prov_id: 6675410,
              prov_key_typ_ref_cd: {ref_dspl: "NPI"},
              prov_key_typ_ref_id: 2782,
              prov_key_val: "1255539573",
              spcl_ref_cd: {ref_dspl: "2084N0400X"},
              spcl_ref_id: 16749,
              st_ref_cd: {ref_dspl: "OREGON"},
              st_ref_id: 1104,
              telcom_adr_id: "5032563055",
              zip_cd_txt: "97216"
    }]
    component.provFavData = [{
      adr_ln_1_txt: "300 Flatbush Ave",
      adr_ln_2_txt: null,
      bus_nm: null,
      cty_nm: "Brooklyn",
      fst_nm: "CINTIA",
      lst_nm: "ROGUIN",
      prov_adr_id: 17788,
      prov_catgy_ref_cd: {ref_dspl: "HCP", ref_desc: "HealthCare Practitioner"},
      prov_catgy_ref_id: 16309,
      prov_id: 167070,
      prov_key_typ_ref_cd: {ref_dspl: "NPI"},
      prov_key_typ_ref_id: 2782,
      prov_key_val: "1255539573",
      spcl_ref_cd: {ref_dspl: "174400000X"},
      spcl_ref_id: 16536,
      st_ref_cd: {ref_dspl: "NEW YORK"},
      st_ref_id: 1101,
      telcom_adr_id: "7186222000",
      zip_cd_txt: "11217"
    }]
    component.validateProviders();
  });

  it('should test getProviderAddressLine Details', () => {
    component.getProviderAddressLine('My adr1','test','Newyork','1234','Hello')
    expect(component.getProviderAddressLine).toHaveBeenCalled;
  });

  it('should call Get Provider Details', () => {
    component.application = "testapp"
    const res: any = { "x-ecp-claims": { "x-ecp-attrs" : {"taxIds" : "['256556261','806930103']"} }}
    const userspy = spyOn(microProductAuth, 'getEcpClaims').and.returnValue(res);
    component.ngOnInit();
    component.getProviderDetailsForProviderRole();
    expect(userspy).toHaveBeenCalled();
  });

  it('should call select Submitting Provider function ', () => {
    component.application = "testapp"
    component.providerLaunchResultsData.push(dataRecord);
    const role = 3761;
    const record : any = {prov_adr_id: 23200502, checkValue: false ,hsc_prov_roles: [{prov_role_ref_id: 3761}]};
    component.selectSubmittingProvider(record,role);
  });

  it('should call searchTypeChange', () => {
    component.searchTypeChange();
    expect(component.searchTypeChange).toHaveBeenCalled;
  });

  it('should call searchTypeChange', () => {
    component.facilitySearch();
    expect(component.facilitySearch).toHaveBeenCalled;
  });

  it('should call searchTypeChange', () => {
    component.physicianSearch();
    expect(component.physicianSearch).toHaveBeenCalled;
  });


  it('should call buildSearchTable', () => {
    let records = [{
      adr_ln_1_txt: "10101 SE Main St Ste 1006",
      adr_ln_2_txt: "Dr Taylor",
      bus_nm: null,
      cty_nm: "Portland",
      distance: 7,
      fst_nm: "HOWARD",
      hsc_prov_id: 8601,
      hsc_prov_roles: [{prov_role_ref_id: 3759, prov_role_ref_cd: {ref_dspl:"abcd"}}],
      isFav: false,
      lst_nm: "TAYLOR",
      ntwk_sts_ref_cd: {ref_dspl: "In"},
      ntwk_sts_ref_id: null,
      prov_adr_id: 23200502,
      prov_catgy_ref_cd: {ref_dspl: "HealthCare Practitioner"},
      prov_catgy_ref_id: 16309,
      prov_id: 6675410,
      prov_key_typ_ref_cd: {ref_dspl: "NPI"},
      prov_key_typ_ref_id: 2782,
      prov_key_val: "1255539573",
      spcl_ref_cd: {ref_dspl: "2084N0400X"},
      spcl_ref_id: 16749,
      st_ref_cd: {ref_dspl: "OREGON"},
      st_ref_id: 1104,
      telcom_adr_id: "5032563055",
      zip_cd_txt: "97216"
    }];
    component.providerCaseDataDisplay = records;
    component.searchPaginator = new EcpUclPaginator(new EcpUclPaginatorIntl(), null, {
      pageSize: 5,
      pageSizeOptions: [5, 25, 50],
      hidePageSize: false
    });
    component.buildSearchTable(records);
    expect(component.physicianSearch).toHaveBeenCalled;
  });
  it('should call providerViewAndUpdateButtonOnClick', () => {
    component.providerViewAndUpdateButtonOnClick();
    expect(component).toBeTruthy();
  });
  it('should call facilityViewAndUpdateButtonOnClick', () => {
    component.facilityViewAndUpdateButtonOnClick();
    expect(component).toBeTruthy();
  });
  it('should call onStateChange', () => {
              const state='calling';
          component.onStateChange(state);
          expect(component.onStateChange(state)).toHaveBeenCalled;
      });
       it('should call onCallEndReason', () => {
              const reason='call ended';
            component.onCallEndReason(reason);
            expect(component.onCallEndReason(reason)).toHaveBeenCalled;
      });
      it('should call onEndCall', () => {
             component.onEndCall();
             expect(component.onEndCall()).toHaveBeenCalled;
       });
     it('should call onToggleMute', () => {
           component.onToggleMute();
            expect(component.onToggleMute()).toHaveBeenCalled;
      });
     it('should call onStartCall', () => {
        const data='';
         component.onStartCall(data);
          expect(component.onStartCall(data)).toHaveBeenCalled;
     });
});
