import {Component, Input, ChangeDetectorRef, OnInit, AfterContentChecked, ViewChild, ViewEncapsulation, Output, EventEmitter} from '@angular/core';
import { EcpUclTableDataSource } from '@ecp/angular-ui-component-library/table';
import { EcpUclSort } from '@ecp/angular-ui-component-library/sort';
import { UserAuthService } from '../services/auth/user.service';
import { ProviderGraphqlService } from '../services/um/service/provider/provider-graphql.service';
import { EcpUclPaginator } from '@ecp/angular-ui-component-library/paginator';
import { ProviderConstants } from './provider.constants';
import { MicroProductAuthService } from '@ecp/auth-library';
import {FormControl, FormGroup, Validators } from '@angular/forms';
import { UmintakeGraphqlService } from '../services/um/service/um-intake/umintake-graphql.service';
import {ClickToCallModule,ClickToCallComponent} from "@ecp/commn-hub-angular-ui-component-library";


@Component({
  selector: 'um-provider',
  templateUrl: './provider.component.html',
  styleUrls: ['./provider.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ProviderComponent implements OnInit, AfterContentChecked{
  @Input() showDetailsView: boolean;
  @Input() providerDetailsJSON;
  @Input() hscID: number;
  @Input() envID:string;
  @Input() application: string;
  @Input() version: string;
  @Input() showFavouriteProviders:boolean;
  @Input() showCardProvider:boolean;
  @Input() readOnly:boolean;
  @Input() showLandingPageProviders:boolean;
  @Input() showCardPhysician:boolean;
  @Input() showProviderSearch: boolean;
  @Input() openFacilitySearchFirst: boolean;
  @Output() selectedProvider: EventEmitter<any> = new EventEmitter();
  @Output() facilityViewAndUpdateButtonClicked = new EventEmitter();
  @Output() providerViewAndUpdateButtonClicked = new EventEmitter();

  dataSource: EcpUclTableDataSource<any>;
  selectedData:  EcpUclTableDataSource<any>;
  favouritesTableData: EcpUclTableDataSource<any>;
  providerLauchData: EcpUclTableDataSource<any>;
  searchResults: EcpUclTableDataSource<any>;
 @ViewChild('clickToCallComponent') clickToCallComponent: ClickToCallComponent | undefined;
    callState = '';
    clickToCallConfig:any;

  @ViewChild('phySort') physicianSort: EcpUclSort;
  @ViewChild('cSort') caseSort: EcpUclSort;
  @ViewChild('favSort') favouriteSort: EcpUclSort;
  @ViewChild('launchSort') providerLaunchSort: EcpUclSort;
  @ViewChild(EcpUclPaginator) searchPaginator: EcpUclPaginator;

  constructor( private cdref: ChangeDetectorRef, private microProductAuthService: MicroProductAuthService,
                private userAUthService: UserAuthService,private providerGraphqlService: ProviderGraphqlService,
                public umintakeGraphqlService: UmintakeGraphqlService) {}

  facilityData = [];
  physicianData = [];
  showSpinner = false;
  providerCaseData = [];
  provFavData = [];
  providerCaseDataDisplay = [];
  providerFavDataDisplay = [];
  providerLaunchResultsData = [];
  providerLaunchDataDisplay = [];
  tooltip = 'Test'; // Changes dynamically in HTML File.
  placement = 'above';

  tooltipOdr = ProviderConstants.ORDERING_PROVIDER_NAME;
  tooltipFac = ProviderConstants.FACILITY_PROVIDER_NAME;
  tooltipAdm = ProviderConstants.ADMITTING_PROVIDER_NAME;
  tooltipSub = ProviderConstants.SUBMITTING_PROVIDER_NAME;

  PROVIDER_ROLE_REF_ID_FACILITY = ProviderConstants.PROVIDER_ROLE_REF_ID_FACILITY;
  PROVIDER_ROLE_REF_ID_ADMITTING = ProviderConstants.PROVIDER_ROLE_REF_ID_ADMITTING;
  PROVIDER_ROLE_REF_ID_ORDERING = ProviderConstants.PROVIDER_ROLE_REF_ID_ORDERING;
  PROVIDER_ROLE_REF_ID_SUBMITTING = ProviderConstants.PROVIDER_ROLE_REF_ID_SUBMITTING;

  PROVIDERCATEGORY_HEALTHCARE_ORG_REFID = ProviderConstants.PROVIDERCATEGORY_HEALTHCARE_ORG_REFID;
  PROVIDERCATEGORY_HEALTHCARE_PRACTITIONER_REFID = ProviderConstants.PROVIDERCATEGORY_HEALTHCARE_PRACTITIONER_REFID;

  caseGridHeaders = ['Favorite','Type','Status','Name', 'Distance', 'Phone','TIN','Specialty','Role'];
  searchGridHeaders = ['Favorite', 'Type', 'Status', 'Name', 'Distance', 'Phone', 'TIN', 'Specialty', 'Role', 'Use'];
  physicianSearchHeaders = ['Favorite', 'Type', 'Status', 'Name', 'Distance', 'Phone', 'TIN', 'Specialty', 'Role'];
  favHeaders = ['Favorite','Type','Status','Name', 'Distance', 'Phone','TIN','Specialty','Role','Delete'];
  provLaunchHeaders = ['type','name','phone','address','tin','specialty','use'];
  selectedProviderSearchFields = [];
  selectedFacilitySearchFields = [];
  searchRolesCollection = {};
  selectedDecision = true;
  providerSearchFields = ['Address', 'City', 'Distance', 'Specialty', 'NPI', 'TIN'];
  facilitySearchFields = ['Address', 'State', 'Distance', 'Specialty', 'TIN', 'NPI'];
  rolesFields = ['ord', 'fac', 'sub', 'adm'];
  searchTypes = [
    {name: 'Physician Search' , value: 'physicianSearch'},
    {name: 'Facility Search' , value: 'facilitySearch'}
  ];
  providerSearchForm: FormGroup = new FormGroup({
    firstName: new FormControl('', Validators.required),
    lastName: new FormControl('', Validators.required),
    city: new FormControl(''),
    specialty: new FormControl(''),
    zipCode: new FormControl('', Validators.required),
    tin: new FormControl(''),
    npi: new FormControl(''),
    address: new FormControl(''),
    distance: new FormControl('')
  });
  facilitySearchForm: FormGroup = new FormGroup({
    facilityName: new FormControl('', Validators.required),
    state: new FormControl(''),
    specialty: new FormControl(''),
    zipCode: new FormControl('', Validators.required),
    tin: new FormControl(''),
    npi: new FormControl(''),
    address: new FormControl(''),
    distance: new FormControl('')
  });

  hidePageSize = false;
  pageSize = 5;
  showSearchTable = false;
  selectedSearchType = this.searchTypes[0];
  searchFieldsPlaceHolder = 'Default';
  pageOptions = [5, 10, 25];

  async ngOnInit(): Promise<void> {
    if (!this.readOnly){
      this.caseGridHeaders.push('Delete');
    }
    this.clickToCallConfig = {
      environment: this.envID,
      userId: '',
      calleePhoneNumber: '',
      calleeName: '',
      ringAudio: 'data:audio/wav;base64,' + '<base64 audio string>'
    };
    if(this.providerDetailsJSON == undefined){
      this.callProviderMethods();
    }
    else {

          if(this.providerDetailsJSON.user_favs){
            this.provFavData = this.providerDetailsJSON.user_favs;
            this.buildFavouriteTableDisplayData();
          }
          if(this.providerDetailsJSON.hsc_provs){
            this.providerCaseData = this.providerDetailsJSON.hsc_provs;
            this.buildYourCaseTableDisplayData();
            this.buildCardDisplayData();
          }
    }
    if(this.showLandingPageProviders){
      this.getProviderDetailsForProviderRole();
    }
    if(this.openFacilitySearchFirst) {
      this.selectedSearchType = this.searchTypes[1];
    } else {
      this.selectedSearchType = this.searchTypes[0];
    }
  }

  async callProviderMethods(){
    if(this.hscID && (this.showDetailsView || this.showCardProvider)){
      await this.getProviderDetails();
      if(this.providerCaseData.length>0){this.buildCardDisplayData();}
    }
    if(this.showFavouriteProviders){
      await this.getUserFavoriteProviders();
    }
  }

  ngAfterContentChecked() {
    this.favouritesTableData = new EcpUclTableDataSource(this.providerFavDataDisplay);
    this.selectedData = new EcpUclTableDataSource(this.providerCaseDataDisplay);
    this.providerLauchData = new EcpUclTableDataSource(this.providerLaunchDataDisplay);
    this.selectedData.sort = this.caseSort;
    this.favouritesTableData.sort = this.favouriteSort;
    this.providerLauchData.sort = this.providerLaunchSort;
    this.cdref.detectChanges();
  }

  searchTypeChange() {
    this.selectedProviderSearchFields = [];
    this.selectedFacilitySearchFields = [];
    this.providerSearchForm.reset();
    this.facilitySearchForm.reset();
    this.showSearchTable = false;
    this.searchResults = new EcpUclTableDataSource();
  }
  onSearchRoles(e: any[], row) {
    this.searchRolesCollection[row.phone] = e;
  }

  radioSelect(row) {
      const data = this.searchRolesCollection[row.phone];
      if (data) {
        if (data.includes('ord')) {
          this.saveProvider(row, this.PROVIDER_ROLE_REF_ID_ORDERING)
        }
        if (data.includes('fac')) {
          this.saveProvider(row, this.PROVIDER_ROLE_REF_ID_FACILITY)
        }
        if (data.includes('sub')) {
          this.saveProvider(row, this.PROVIDER_ROLE_REF_ID_SUBMITTING)
        }
        if (data.includes('adm')) {
          this.saveProvider(row, this.PROVIDER_ROLE_REF_ID_ADMITTING)
        }
      }
  }

  selectedRoles(row) {
    const arr = [];
    if (this.hasRole(row, this.PROVIDER_ROLE_REF_ID_ORDERING)) {
      arr.push('ord');
    }
    if (this.hasRole(row, this.PROVIDER_ROLE_REF_ID_FACILITY)) {
      arr.push('fac');
    }
    if (this.hasRole(row, this.PROVIDER_ROLE_REF_ID_SUBMITTING)) {
      arr.push('sub');
    }
    if (this.hasRole(row, this.PROVIDER_ROLE_REF_ID_ADMITTING)) {
      arr.push('adm');
    }
    return arr;

  }
  async physicianSearch() {
    if (!this.providerSearchForm.invalid) {
      this.showSearchTable = false;
      this.searchResults = new EcpUclTableDataSource();
      const physicianDetails: any =
        await this.providerGraphqlService.getPhysiciansBySearchParams(this.providerSearchForm.value, this.application);
      if (physicianDetails.data.v_prov_srch.length > 0) {
        this.buildSearchTable(physicianDetails.data.v_prov_srch);
      }
      else{ //to show no records table must be intailzed in "buildSearchTable" function
        const provRecords = [];
        this.buildSearchTable(provRecords);
      }
    }
  }

  buildSearchTable(results: any){
    const providerData = this.providerGraphqlService.buildProviderData(results);
    providerData.forEach(item => {
      item.isFav = false;
      item.hsc_prov_roles = [];
      if(this.providerCaseDataDisplay.length > 0){
        this.providerCaseDataDisplay.forEach(element  => {
          if(item.prov_adr_id === element.prov_adr_id){
            item.isFav = element.isFav;
            item.hsc_prov_roles = element.hsc_prov_roles;
          }
        });
      }
    });
    const resultArray = this.buildSearchDisplayData(providerData);
    this.searchResults =  new EcpUclTableDataSource(resultArray);
    this.searchResults.sort = this.physicianSort;
    this.searchResults.paginator = this.searchPaginator;
    this.showSearchTable = true;
  }

  async facilitySearch() {
    if (!this.facilitySearchForm.invalid) {
      this.showSearchTable = false;
      this.searchResults = new EcpUclTableDataSource();
      const facilityDetails: any =
        await this.providerGraphqlService.getFacilitiesBySearchParams(this.facilitySearchForm.value, this.application);
      if (facilityDetails.data.v_prov_srch.length > 0) {
        this.buildSearchTable(facilityDetails.data.v_prov_srch);
      }
      else{//to show no records table must be intailzed in "buildSearchTable" function
        const provRecords = [];
        this.buildSearchTable(provRecords);
      }
    }
  }

  buildSearchDisplayData(providerData: any){
    const provDetailsArray = [];
    providerData.forEach(element => {
      const provObj = this.buildDisplayItem(element);
      provDetailsArray.push(provObj);
    });
    return provDetailsArray;
  }

  buildCardDisplayData(){
    this.providerCaseData.forEach(item => {
      if (item.hsc_prov_roles !== undefined && item.hsc_prov_roles.length > 0) {
        const hasFacilityRole = item.hsc_prov_roles.find(role => {role.prov_role_ref_id === ProviderConstants.PROVIDER_ROLE_REF_ID_FACILITY});
        if (hasFacilityRole) {
          this.facilityData.push(item);
        }else{
          this.physicianData.push(item);
        }
      }
    });
  }

  buildDisplayItem(item){
    const provObj = {
      phone :item.telcom_adr_id?item.telcom_adr_id:null,
      specialty: item.spcl_ref_cd?.ref_dspl ? item.spcl_ref_cd.ref_dspl: null,
      address: this.getProviderAddressLine(item.adr_ln_1_txt,item.adr_ln_2_txt,item.cty_nm,item.st_ref_cd?.ref_dspl ? item.st_ref_cd.ref_dspl: null,item.zip_cd_txt),
      name: "",
      tin: null,
      type: "",
      status: "",// item.ntwk_sts_ref_cd.ref_dspl
      ...item
    }
    if(item.prov_catgy_ref_id === this.PROVIDERCATEGORY_HEALTHCARE_PRACTITIONER_REFID){
      provObj.type = "Physician"
      provObj.name = item.lst_nm + ', ' + item.fst_nm
      provObj.status = "In"
    }
    else{
      provObj.type = "Facility"
      provObj.name = item.bus_nm
      provObj.status = "Out"
      provObj.tin = item.prov_key_val
    }

    return provObj;
  }

  validateProviders(){
    if(this.providerCaseDataDisplay.length > 0){
     this.providerCaseDataDisplay.forEach(item => {
         const favProv = this.provFavData.find(x => x.prov_adr_id === item.prov_adr_id);
         if(favProv){
           item.isFav = true;
         }
         else{
           item.isFav = false;
         }
     })
    }
    if((this.providerFavDataDisplay.length > 0)){
     this.providerFavDataDisplay.forEach(element => {
       const prov = this.providerCaseData.find(x => x.prov_adr_id === element.prov_adr_id);
       if(prov){
         element.hsc_prov_roles = prov.hsc_prov_roles;
       }
     });
   }
  }

  async saveProvider(record: any, roleRefId: number){
    let roleAdded = false;
    if (this.hasRole(record, roleRefId)) {
      record.hsc_prov_roles = record.hsc_prov_roles.filter(item => item.prov_role_ref_id !== roleRefId);
    }else{
      roleAdded = true;
      record.hsc_prov_roles.push({prov_role_ref_id: roleRefId});
    }
    const existingProvider = this.providerCaseData.find(item => item.prov_adr_id === record.prov_adr_id);
    if (!existingProvider){
      this.providerCaseData.push(record);
    }
    if (roleAdded) {
      await this.providerGraphqlService.saveProvider(this.hscID, record, roleRefId, this.application).then((res) => {
        this.getProviderDetails();
      });
    }
  }

  async updateProvider(record: any, roleRefId: number, isChecked: boolean){
    if (!isChecked) {
      record.hsc_prov_roles = record.hsc_prov_roles.filter(item => item.prov_role_ref_id !== roleRefId);
    }else{
      record.hsc_prov_roles.push({prov_role_ref_id: roleRefId});
    }
    const existingProvider = this.providerCaseData.find(item => item.prov_adr_id === record.prov_adr_id);
    if (!existingProvider){
      this.providerCaseData.push(record);
    }
    await this.providerGraphqlService.saveProvider(this.hscID, record,roleRefId, this.application).then((res) => {
      this.getProviderDetails();
    });
  }

  async removeProvider(row){
    await this.providerGraphqlService.deleteProvider(this.hscID, row, this.application).then((res) => {
      this.getProviderDetails();
    });
  }

  async getUserFavoriteProviders(){
    const provAdrValues = [];
    this.provFavData = [];
    const res = await this.providerGraphqlService.getUserFavorites(ProviderConstants.USER_FAVORITE_TYPE_PROVIDER_REF_ID, this.application,this.userAUthService.getUserID());
      if (res?.data.user_fav.length > 0) {
        res?.data.user_fav.forEach(element => {
          provAdrValues.push(element.user_fav_val);
        });
      }
    const uniqueAdrArray = provAdrValues.filter(function(item, pos, self) { 
      return self.indexOf(item) === pos;
    });
    const provRes:any = await this.providerGraphqlService.getProvDetailsByAdrId(uniqueAdrArray,this.application);
    this.provFavData = this.providerGraphqlService.buildProviderDataforFavs(provRes.data.v_prov_srch, uniqueAdrArray);
    this.buildFavouriteTableDisplayData();
    this.validateProviders();
  }

  buildFavouriteTableDisplayData(){
    //builds the html display data of favorite providers
    this.providerFavDataDisplay = [];
    if(this.provFavData.length > 0){
      this.provFavData.forEach(item => {
        const provObj = this.buildDisplayItem(item);
        this.providerFavDataDisplay.push(provObj);
      });
    }
  }

  hasRole(row: any, roleRefId: number){
    let roleExists = false;
    if (row.hsc_prov_roles && row.hsc_prov_roles.length > 0){
      const provRole = row.hsc_prov_roles.find(role => role.prov_role_ref_id === roleRefId);
      roleExists = provRole ? true : false;
    }
    return roleExists;
  }

  async getProviderDetails(){
    this.providerCaseData = [];
    const res:any = await this.providerGraphqlService.getProvDetailsByHscId(this.hscID,this.application);
    const provData = res.data.hsc[0].hsc_provs;
    const refId = [];

    await provData.forEach(async element => {
      const provObj = {
        adr_ln_1_txt: element.prov_loc_affil_dtl?.providerDetails?.prov_adr?.adr_ln_1_txt,
        adr_ln_2_txt: element.prov_loc_affil_dtl?.providerDetails?.prov_adr?.adr_ln_2_txt,
        bus_nm: element.prov_loc_affil_dtl?.providerDetails?.bus_nm,
        cty_nm: element.prov_loc_affil_dtl?.providerDetails?.prov_adr?.cty_nm,
        distance: 7,
        fst_nm: element.prov_loc_affil_dtl?.providerDetails?.fst_nm,
        lst_nm: element.prov_loc_affil_dtl?.providerDetails?.lst_nm,
        ntwk_sts_ref_cd: {ref_dspl : 'In'},
        ntwk_sts_ref_id: null,
        prov_adr_id: element.prov_loc_affil_dtl?.providerDetails?.prov_adr_id,
        prov_catgy_ref_cd: null,
        prov_catgy_ref_id: element.prov_loc_affil_dtl?.providerDetails?.prov_catgy_ref_id,
        prov_id: element.prov_loc_affil_dtl?.providerDetails?.prov_id,
        prov_key_typ_ref_cd: element.prov_key_typ_ref_cd,
        prov_key_typ_ref_id: element.prov_key_typ_ref_id,
        prov_key_val: element.prov_key_val,
        spcl_ref_cd: element.spcl_ref_cd ? element.spcl_ref_cd : null,
        spcl_ref_id: element.spcl_ref_id,
        st_ref_cd: null,
        st_ref_id: element.prov_loc_affil_dtl?.providerDetails?.prov_adr?.st_ref_id,
        telcom_adr_id: element.telcom_adr_id,
        zip_cd_txt: element.prov_loc_affil_dtl?.providerDetails?.prov_adr?.zip_cd_txt,
        isFav: false,
        hsc_prov_id: element.hsc_prov_id,
        hsc_prov_roles: element.hsc_prov_roles,
      };
      refId.push(element.prov_loc_affil_dtl?.providerDetails?.prov_adr?.st_ref_id);
      refId.push(element.prov_loc_affil_dtl?.providerDetails?.prov_catgy_ref_id);
      this.providerCaseData.push(provObj);
    });

    //Build unique array for all ref ids in data and call ref table and then assig each data feasible value .
    // This will be removed once prov_catgy_ref_cd and  st_ref_cd are included in prov_loc_affil_dtl  while saving provider.
    const uniqueAdrArray = refId.filter(function(item, pos, self) { 
      return self.indexOf(item) === pos;
    });

    // Please send the Input for "loadRefDataByRefIds" functions as Int Array  and Use find method.
    let response1 = null;
    if (uniqueAdrArray.length > 0) {
       response1 = await this.umintakeGraphqlService.loadRefDataByRefIds(this.application, uniqueAdrArray);
       this.providerCaseData.forEach(async element => {
        const stateRecord = response1?.data?.hsr_ref?.find(x => x.ref_id === element.st_ref_id);
        const cagtyRecord = response1?.data?.hsr_ref?.find(x => x.ref_id === element.prov_catgy_ref_id);
        element.prov_catgy_ref_cd = { ref_dspl: cagtyRecord?.ref_dspl};
        element.st_ref_cd = { ref_dspl : stateRecord?.ref_dspl};
      });
    }else{
      console.log('Warning: Dont have refIds array to pull refData.');
    }


    this.buildYourCaseTableDisplayData();
    this.buildFavouriteTableDisplayData();
    this.validateProviders();
  }

  buildYourCaseTableDisplayData(){
    this.providerCaseDataDisplay = [];
    //builds the html display data of your case providers
    if(this.providerCaseData.length > 0){
      this.providerCaseData.forEach(item => {
        const provObj = this.buildDisplayItem(item);
        this.providerCaseDataDisplay.push(provObj);
      });
    }
  }

  async deleteFavProvder(record:any){
    try{
      const res:any = await this.providerGraphqlService.deleteFavorite(this.userAUthService.getUserID(),
      ProviderConstants.USER_FAVORITE_TYPE_PROVIDER_REF_ID,record.prov_adr_id.toString(),this.application);
      if(res.data.delete_user_fav.returning[0].user_id){
        record.isFav = false;
        await this.getUserFavoriteProviders();
      }
    }
    catch(e){
      console.log("Error in deleteing Fav Provider",e)
    }
  }

  async saveFavProvder(record:any){
    try{
    const res:any = await this.providerGraphqlService.saveFavorite(this.userAUthService.getUserID(),
    ProviderConstants.USER_FAVORITE_TYPE_PROVIDER_REF_ID,record.prov_adr_id.toString(),this.application);
      if(res.data.insert_user_fav.returning[0].user_fav_id){
        record.isFav = true;
        await this.getUserFavoriteProviders();
      }
    }
    catch(e){
      console.log("Error in Saving Fav Provider",e);
    }
  }

  async getProviderDetailsForProviderRole(){
    const claims:any = this.microProductAuthService.getEcpClaims()['x-ecp-claims'];
    const ecpAttrs:any = claims['x-ecp-attrs'];
    if(ecpAttrs.taxIds){
      const providerTaxIds:any = ecpAttrs.taxIds.slice(1,-1);
      const provTaxIdDetails = providerTaxIds.replace(/'/g, "");
      const provTaxIdArray = await provTaxIdDetails.split(",");
      const provDetails = await this.providerGraphqlService.getProviderDetailsByTaxIDs(provTaxIdArray,this.application);
      if(provDetails.data.v_prov_srch.length > 0){
        this.providerLaunchResultsData = this.providerGraphqlService.buildProviderData(provDetails.data.v_prov_srch);
      }
      this.providerLaunchResultsData.forEach(item => { item.checkValue = false});
      this.buildProviderPersonaTableDisplayData();
    }
  }

  async selectSubmittingProvider(record:any,role:any){
    const providerRecord : any = {};
    this.providerLaunchResultsData.forEach(item =>{
      if(record.prov_adr_id === item.prov_adr_id){
          if(record.checkValue){
            item.checkValue = false;
          }
          else{
            item.checkValue = true;
            providerRecord.record = item;
            providerRecord.role = role;
          }
      }
      else{
        item.checkValue = false;
      }
    });
    this.selectedProvider.next(providerRecord);
    await this.providerGraphqlService.saveProvider(this.hscID, record, role, this.application);
    this.buildProviderPersonaTableDisplayData();
  }

  buildProviderPersonaTableDisplayData(){
    //builds the html display data of persona launching providers
    this.providerLaunchDataDisplay = [];
    if(this.providerLaunchResultsData.length > 0){
      this.providerLaunchResultsData.forEach(item => {
        const provObj = this.buildDisplayItem(item);
        this.providerLaunchDataDisplay.push(provObj);
      });
    }
  }

  getProviderAddressLine(adr_ln_1_txt: string, adr_ln_2_txt: string, cty_nm: string, st_ref_cd: string, zip_cd_txt: string): string {
    let addressLine = '';
      if (adr_ln_1_txt) {
        addressLine = adr_ln_1_txt;
      }
      if (adr_ln_2_txt) {
        addressLine = this.appendAddressComponent(addressLine, adr_ln_2_txt);
      }
      if (cty_nm) {
        addressLine = this.appendAddressComponent(addressLine, cty_nm);
      }
      if (st_ref_cd) {
        addressLine = this.appendAddressComponent(addressLine, st_ref_cd);
      }
      if (zip_cd_txt) {
        addressLine = this.appendAddressComponent(addressLine, zip_cd_txt);
      }
      return addressLine;
  }

  appendAddressComponent(addressLine: string, addressComponent: string): string {
      if (addressComponent.length > 0) {
        if (addressLine && addressLine.length > 0) {
          addressLine += ', ' + addressComponent;
        } else {
          addressLine = addressComponent;
        }
      }
      return addressLine;
  }
  providerViewAndUpdateButtonOnClick() {
    this.providerViewAndUpdateButtonClicked.emit();
  }

  facilityViewAndUpdateButtonOnClick() {
    this.facilityViewAndUpdateButtonClicked.emit();
  }
  onStartCall(data:any) {
          this.callState = '';
          this.clickToCallConfig.calleePhoneNumber='+1'+data.telcom_adr_id;
          console.log(this.clickToCallConfig.calleePhoneNumber);
          this.clickToCallComponent?.placeAudioCall();
        }

        onEndCall() {
           this.clickToCallComponent?.hangUpAudioCall();
        }

        onToggleMute() {
            if (this.clickToCallComponent?.isMicrophoneMuted()) {
              this.clickToCallComponent?.unMuteMicrophone();
             } else  {
               this.clickToCallComponent?.muteMicrophone();
            }
          }

        onStateChange(state: any) {
          console.log('Call state: ' + state);
          this.callState = state;
        }

        onCallEndReason(reason: any) {
          console.log('Call ended because:');
          console.log(reason);
        }
}