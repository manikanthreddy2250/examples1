export const ProviderConstants = {
    PROVIDER_ROLE_REF_ID_SUBMITTING : 3764,
    PROVIDER_ROLE_REF_ID_FACILITY : 3761,
    PROVIDER_ROLE_REF_ID_ADMITTING : 3758,
    PROVIDER_ROLE_REF_ID_ATTENDING : 3759,
  // ordering provider ref is same as 'Attending' only for OP -- following icue here
  // Submitting provider ref is called as 'requesting' in ref domain
    PROVIDER_ROLE_REF_ID_ORDERING : 3759,
    PROVIDER_ROLE_REF_ID_SERVICING : 3765,
    PROVIDER_KEY_VALUE_TYP_REF_ID_NPI : 2782,
    PROVIDER_KEY_VALUE_TYP_REF_ID_TIN : 16333,
    PROVIDER_KEY_VALUE_TYP_REF_ID_MPIN : 2783,  // TODO - cleanup:  This is not a TIN in ref domain, below ref_id(2784) is TIN
    PHYSICIAN_CAT_ID : 16309,
    FACILITY_CAT_ID : 16310,
    USER_FAVORITE_TYPE_PROVIDER_REF_ID : 20117,
    ORDERING_PROVIDER_NAME: 'Ordering Provider',
    FACILITY_PROVIDER_NAME: 'Facility Provider',
    SUBMITTING_PROVIDER_NAME: 'Submitting Provider',
    ADMITTING_PROVIDER_NAME: 'Admitting Provider',
    PROVIDERCATEGORY_HEALTHCARE_PRACTITIONER_REFID : 16309,
    PROVIDERCATEGORY_HEALTHCARE_ORG_REFID : 16310,
};
