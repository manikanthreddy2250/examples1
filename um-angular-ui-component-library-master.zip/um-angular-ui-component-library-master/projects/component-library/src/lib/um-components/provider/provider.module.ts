import { NgModule } from '@angular/core';
import { CommonModule, APP_BASE_HREF } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { ProviderComponent } from './provider.component';
import { TabsModule } from '@ecp/angular-ui-component-library/tabs';
import {MatGridListModule} from '@angular/material/grid-list';
import { ButtonModule } from '@ecp/angular-ui-component-library/button';
import { IconsModule } from '@ecp/angular-ui-component-library/icons';
import {MatIconModule} from '@angular/material/icon';
import {TableModule} from '@ecp/angular-ui-component-library/table';
import {SortModule} from '@ecp/angular-ui-component-library/sort';
import {LinkModule} from '@ecp/angular-ui-component-library/link';
import { CardModule } from '@ecp/angular-ui-component-library/card';
import { CheckboxModule } from '@ecp/angular-ui-component-library/checkbox';
import {HttpClientModule} from "@angular/common/http";
import {AuthLibraryModule} from "@ecp/auth-library";
import {UserAuthService} from "../services/auth/user.service";
import {RouterModule} from "@angular/router";
import { ProgressSpinnerModule } from '@ecp/angular-ui-component-library/progress-spinner';
import { FormsModule } from '@angular/forms';
import { PaginatorModule } from '@ecp/angular-ui-component-library/paginator';
import { TagsModule } from '@ecp/angular-ui-component-library/tags';
import { ProviderGraphqlService } from '../services/um/service/provider/provider-graphql.service';
import { TooltipModule } from '@ecp/angular-ui-component-library/tooltip';
import { SelectModule } from '@ecp/angular-ui-component-library/select';
import { OptionModule } from '@ecp/angular-ui-component-library/option';
import { InputModule} from '@ecp/angular-ui-component-library/input';
import { FormFieldModule } from '@ecp/angular-ui-component-library/form-field';
import {ReactiveFormsModule} from '@angular/forms';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import {EcpUclTooltip} from '@ecp/angular-ui-component-library/tooltip';
import {ClickToCallModule, OvcpSvgsModule } from "@ecp/commn-hub-angular-ui-component-library";
import {ButtonGroupModule} from '@ecp/angular-ui-component-library/button-group';
import {RadioButtonModule} from '@ecp/angular-ui-component-library/radio-button';
@NgModule({
  declarations: [
    ProviderComponent
  ],
  entryComponents: [EcpUclTooltip],
  imports: [
    CommonModule,
    BrowserModule,
    BrowserAnimationsModule,
    MatGridListModule,
    MatIconModule,
    TableModule,
    ButtonModule,
    TabsModule,
    IconsModule,
    SortModule,
    LinkModule,
    CardModule,
    HttpClientModule,
    CheckboxModule,
    AuthLibraryModule,
    ProgressSpinnerModule,
    TagsModule,
    TooltipModule,
    FormsModule,
    SelectModule,
    InputModule,
    OptionModule,
    FormFieldModule,
    ReactiveFormsModule,
    PaginatorModule,
    ClickToCallModule,
    OvcpSvgsModule,
    ButtonGroupModule,
    RadioButtonModule,
      ],
  exports: [
    ProviderComponent
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  providers: [UserAuthService,ProviderGraphqlService,{provide: APP_BASE_HREF, useValue: '/'}]
})
export class ProviderModule {}
