import { Injectable } from '@angular/core';
import { AuthService, MicroProductAuthService } from '@ecp/auth-library';



@Injectable({
  providedIn: 'root'
})
export class UserAuthService {

  constructor(private readonly authService: AuthService, private readonly microProductAuth: MicroProductAuthService) { }

  public getUserHasuraRole(product: string) {
    const [org, role] = this.authService.getActiveLoginClientRole();
     const hasuraRole = this.microProductAuth.getHasuraRole(org || '', role || '', product) || null;
     return hasuraRole;
   }
 
   public getActiveUserRole() {
     const [org, role] = this.authService.getActiveLoginClientRole();
     return role;
   }
 
   public getActiveClientOrg() {
     const [org, role] = this.authService.getActiveLoginClientRole();
     return org;
   }

   getAltUserID() {
    return this.microProductAuth.getAltUserID();
   }

   getUserID() {
    return this.microProductAuth.getUserID();
    // if (this.microProductAuth.isLocalHost()) { // to avoid adding a token in storage while working in local
    //   return 'SYSTEM';
    // } else {
    //   return this.microProductAuth.getUserID();
    // }
  }
}
