import {TestBed} from '@angular/core/testing';
import {ConfigService} from './config.service';
import { HttpClientModule, HttpHeaders } from '@angular/common/http';
import { UmcasewfGraphqlService } from '../um/service/casewf/umcasewf-graphql.service';
import { TasksListViewModule } from '../../tasks-list-view/tasks-list-view.module';
import { Injectable } from '@angular/core';
import {RouterTestingModule} from '@angular/router/testing';

describe('ConfigService', () => {
  let service: ConfigService;
  let umcasewfGraphqlService: UmcasewfGraphqlService;
  let mockHttpClient: any;

  beforeEach(() => {
    mockHttpClient = jasmine.createSpyObj(['get', 'post']);
    TestBed.configureTestingModule({
      imports: [HttpClientModule, TasksListViewModule, RouterTestingModule],
      providers: []
    });
    service = new ConfigService(mockHttpClient, '', umcasewfGraphqlService);
    umcasewfGraphqlService = TestBed.inject(UmcasewfGraphqlService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  xit('should call readConfig', () => {
    spyOn<any>(umcasewfGraphqlService, 'getApiHeaders').and.returnValue({headers: {}});
    service.readConfig('app','key','1.0.0');
    expect(service.readConfig).toBeDefined();
  });
});
