import { HttpClient } from '@angular/common/http';
import { UmcasewfGraphqlService } from '../um/service/casewf/umcasewf-graphql.service';

export class ConfigService {

  constructor(private readonly httpClient: HttpClient, 
    private readonly configUrl: string,
    private umcasewfGraphqlService: UmcasewfGraphqlService) { }

  public readConfig(application: string, version: string, key: string): Promise<any> {
    return this.httpClient.get(
      '' + this.configUrl + application + '/' + version + '/' + key,
      { headers: this.umcasewfGraphqlService.getApiHeaders(application) })?.toPromise();
  }

}
