import { Injectable } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import {HttpClient, HttpClientModule} from '@angular/common/http';
import { EmailService } from './email.service';
import {HttpClientTestingModule} from "@angular/common/http/testing";
import { of } from 'rxjs';

@Injectable()
class MockHttpClient {
  post(url: string, body: any | null, options?: any) {
    return of({});
  }
}

describe('EmailService', () => {
  let service: EmailService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports :[HttpClientModule, HttpClientTestingModule],
      providers: [
        { provide: HttpClient, useClass: MockHttpClient }
      ]});
    service = TestBed.inject(EmailService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should call sendEmail', () => {
    service.sendEmail('recipient', 'subject', 'message');
    expect(service.sendEmail).toBeDefined();
  });
});
