import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {getEnvVar} from '../../services/environment/envVarUtil';
import {SECURE_EMAIL_URL} from "../../../config/config-constants";

@Injectable({
  providedIn: 'root'
})
export class EmailService {

  constructor(readonly httpClient: HttpClient) {}

  sendEmail(recipient, subject, message) {
    const body = {
      "to": [
        recipient
      ],
      "from": "no-reply@optum.com",
      "subject": subject,
      "template": "sample_template.html",
      "context": {
        "name": "",
        "emailLogoURL": "https://dev-ovc.optum.com/assets/mail_optum_logo.png",
        "emailBody": message
      }
    };
    const url = getEnvVar(SECURE_EMAIL_URL);

    return this.httpClient.post(url, body);
  }
}
