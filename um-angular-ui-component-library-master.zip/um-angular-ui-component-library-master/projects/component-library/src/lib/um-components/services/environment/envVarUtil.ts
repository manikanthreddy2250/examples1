import * as _ from 'lodash';

/**
 * This file provides local environment specific variables that point to dev, and are replaced at the micro frontend implementation level
 */
export const environment = {
  local: {
    ecp: {
      api: {
        indv_domain_url: 'https://dev-ecp-api.optum.com/indnew/v1/graphql',
        get_config_url: 'https://dev-ecp-api.optum.com/config/api/prop/',
        case_wf_api_url: 'https://dev-ecp-api.optum.com/um-case-wf-mgmt-nestjs/api/graphql',
        health_service_domain_url: 'https://dev-ecp-api.optum.com/health-service/v1/graphql',
        get_ref_new_url: 'https://dev-ecp-api.optum.com/refnew/v1/graphql',
        get_case_header_url: 'https://dev-ecp-umcasewf-function-app-79ec.azurewebsites.net/api/getCaseHeaderDetails',
        get_member_details_url: 'https://dev-ecp-umcasewf-function-app-79ec.azurewebsites.net/api/getMemberDetails',
        get_medical_review_url: 'https://dev-ecp-api.optum.com/guidelines-funcs/api/graphql',
        guidelines_function_url: 'https://dev-ecp-api.optum.com/guidelines-funcs/api/graphql',
        guidelines_function_api_url: 'https://dev-ecp-api.optum.com/guidelines-funcs/api',
        get_hsc_auth_details_graphql_func_http_url: 'https://dev-ecp-api.optum.com/util-funcs-nestjs/api/graphql',
        get_questions_url: 'https://dev-ecp-guidelines-function-app-79ec.azurewebsites.net/api/fhir/questions?code=JVe8UqS/LXXSvoY89isOryfkX/pnaQI/d8/PQMqyaykRXnFCh9QTzQ==',
        get_guidelines_url: 'https://dev-ecp-guidelines-function-app-79ec.azurewebsites.net/api/fhir/guidelines?code=JVe8UqS/LXXSvoY89isOryfkX/pnaQI/d8/PQMqyaykRXnFCh9QTzQ==',
        get_hsc_auth_details_url: 'https://dev-ecp-api.optum.com/util-funcs/api/hscAuthDetails',
        membership_domain_url: 'https://dev-ecp-api.optum.com/memnew/v1/graphql',
        get_ip_dmn_rule_url_path: 'https://dev-ecp-api.optum.com/clinical-guidelines-bpm/1.0.0/dmn/InpatientRuleFinalVersionv1/evaluate',
        get_service_eta_url_path:'https://dev-ecp-analytical-api.optum.com/paeta/api/eta',
        utilization_mgmnt_funcs_url: 'https://dev-ecp-api.optum.com/util-funcs-nestjs/api/graphql',
        provider_service_domain_url:'https://dev-ecp-api.optum.com/provnew/v1/graphql',
        user_attr_url: 'https://dev-ecp-api.optum.com/user-attributes/v1/graphql',
        get_task_assignment_url: 'https://dev-ecp-api.optum.com/task-management-funcs/api/getTaskAssignment',
        um_rules_service_url: 'https://dev-ecp-api.optum.com/um-rules/1.0.0',
        case_management_bpm_service_url: 'https://dev-ecp-api.optum.com/case-management-bpm/1.0.0',
        guidelines_bpmn_url: 'https://dev-ecp-api.optum.com/clinical-guidelines-bpm/1.0.0/bpmn/clinical_guidelines/start',
        guidelines_draft_dmn_url: 'https://dev-ecp-api.optum.com/clinical-guidelines-bpm/1.0.0/dmn/DraftReviewDurationdemov1/evaluate',
        guidelines_ip_dmn_url: 'https://dev-ecp-api.optum.com/clinical-guidelines-bpm/1.0.0/dmn/InpatientRuleFinalVersionv1/evaluate',
        secure_email_url: 'https://dev-ecp-api.optum.com/comm-hub-funcs/api/email'
      }
    }
  },
  deployed: {
    ecp: {
      api: {
        indv_domain_url: '${INDIVIDUAL_DOMAIN_URL}',
        get_hsc_auth_details_graphql_func_http_url: '${GET_HSC_AUTH_DETAILS_GRAPHQL_FUNC_HTTP_URL}',
        get_config_url: '${GET_CONFIG_URL}',
        case_wf_api_url: '${CASE_WF_API_URL}',
        health_service_domain_url: '${HEALTH_SERVICE_DOMAIN_URL}',
        get_ref_new_url: '${GET_REF_NEW_URL}',
        get_case_header_url: '${GET_CASE_HEADER_URL}',
        get_member_details_url: '${GET_MEMBER_DETAILS_URL}',
        get_medical_review_url: '${GET_MEDICAL_REVIEW_URL}',
        guidelines_function_url: '${GUIDELINES_FUNCTION_URL}',        
        guidelines_function_api_url: '${GUIDELINES_FUNCTION_API_URL}',
        get_questions_url: '${GET_QUESTIONS_URL}',
        get_guidelines_url: '${GET_GUIDELINES_URL}',
        get_hsc_auth_details_url: '${GET_HSC_AUTH_DETAILS_URL}',
        membership_domain_url: '${MEMBERSHIP_DOMAIN_URL_PATH}',
        get_ip_dmn_rule_url_path: '${GET_IP_DMN_RULE_URL_PATH}',
        get_task_assignment_url: '${GET_TASK_ASSIGNMENT_URL}',
        get_service_eta_url_path: '${SERVICE_ETA_URL}',
        utilization_mgmnt_funcs_url: '${UTILIZATION_MGMNT_FUNCS_URL}',
        provider_service_domain_url: '${PROVIDER_SERVICE_DOMAIN_URL_PATH}',
        user_attr_url: '${USER_ATTRIBUTES_URL_PATH}',
        um_rules_service_url: '${UM_RULES_SERVICE_URL}',
        case_management_bpm_service_url: '${CASE_MANAGEMENT_BPM_SERVICE_URL}',
        guidelines_bpmn_url: '${GUIDELINES_BPMN_URL}',
        guidelines_draft_dmn_url: '${GUIDELINES_DRAFT_DMN_URL}',
        guidelines_ip_dmn_url: '${GUIDELINES_IP_DMN_URL}',
        secure_email_url: '${SECURE_EMAIL_URL}'
      }
    }
  }
};

/**
 * works with nested json values, returns either local value or replaced deployed env variable
 * ex: getEnvVar('api.getMyTasksListDetailsUrl')
 */
export function getEnvVar(name): string {
  return _.get(environment, 'deployed.' + name).startsWith('$')
    ? _.get(environment, 'local.' + name)
    :  _.get(environment, 'deployed.' + name);
}
