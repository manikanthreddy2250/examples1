import { TestBed } from '@angular/core/testing';
import {FormControl, FormGroup, ValidatorFn} from '@angular/forms';
import { IntakeFormValidationService } from './intake-form-validation.service';
import * as moment from 'moment';

describe('IntakeFormValidationService', () => {
  let service: IntakeFormValidationService;
const date='08-24-2020';
const date2='12-31-2020';
  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(IntakeFormValidationService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('isFutureDateValidatorFn should return error object if the control date is in future', () => {
    const isFutureDateValidatorFn = service.isFutureDateValidator();
    const result = isFutureDateValidatorFn(new FormControl(moment().add(1, 'day')));
    expect(result.isFutureDate).toBeTrue();
  });

  it('isFutureDateValidatorFn should NOT return error object if the control date is in past', () => {
    const isFutureDateValidatorFn = service.isFutureDateValidator();
    const result = isFutureDateValidatorFn(new FormControl(moment().subtract(1, 'day')));
    expect(result).toBeNull();
  });

  it('isDateInPastValidatorFn should return error object if the control date is in past by more than specified number of days', () => {
    const isDateInPastValidatorFn = service.isDateInPastValidator(10);
    const result = isDateInPastValidatorFn(new FormControl(moment().subtract(11, 'day')));
    expect(result.isDateInPast).toBeTrue();
  });

  it('isDateInPastValidatorFn should NOT return error object if the control date is in past but NOT more than specified number of days', () => {
    const isDateInPastValidatorFn = service.isDateInPastValidator(10);
    const result = isDateInPastValidatorFn(new FormControl(moment().subtract(9, 'day')));
    expect(result).toBeNull();
  });

  it('dateWithinRangeValidatorFn should return error object if the control date is NOT within the range of specified dates', () => {
    const dateWithinRangeValidatorFn = service.dateWithinRangeValidator('01-01-2020', date2);
    const result = dateWithinRangeValidatorFn(new FormControl('01-01-2021'));
    expect(result.dateNotInRange).toBeTrue();
  });

  it('dateWithinRangeValidatorFn should NOT return error object if the control date is within the range of specified dates', () => {
    const dateWithinRangeValidatorFn = service.dateWithinRangeValidator('01-01-2020', date2);
    // in between check
    const inBetweenResult = dateWithinRangeValidatorFn(new FormControl('09-24-2020'));
    expect(inBetweenResult).toBeNull();
    // inclusive check
    const inclusiveResult = dateWithinRangeValidatorFn(new FormControl('12-31-2020'));
    expect(inclusiveResult).toBeNull();
  });

  it('priorDateValidatorFn should return error object if the specified control dateB is NOT >= dateA+1', () => {
    const sampleFormGroup = new FormGroup({controlNameA: new FormControl(date), controlNameB: new FormControl('08-24-2020')})
    const priorDateValidatorFn = service.priorDateValidator('controlNameA', 'controlNameB');
    const result = priorDateValidatorFn(sampleFormGroup);
    expect(result.controlNameBisPrior).toBeFalsy();
  });

  it('priorDateValidatorFn should NOT return error object if the specified control dateB is >= dateA+1', () => {
    const sampleFormGroup = new FormGroup({controlNameA: new FormControl(date), controlNameB: new FormControl('08-25-2020')})
    const priorDateValidatorFn = service.priorDateValidator('controlNameA', 'controlNameB');
    const result = priorDateValidatorFn(sampleFormGroup);
    expect(result.controlNameBisPrior).toBeFalsy();
  });

});