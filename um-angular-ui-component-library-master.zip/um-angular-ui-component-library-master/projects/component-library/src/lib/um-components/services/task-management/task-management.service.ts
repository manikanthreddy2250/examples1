import {HttpClient, HttpHeaders} from '@angular/common/http';
import {UserAuthService} from "../auth/user.service";
import {MicroProductAuthService} from "@ecp/auth-library";
import {getEnvVar} from "../environment/envVarUtil";
import {GET_TASK_ASSIGNMENT_URL} from '../../../config/config-constants';
import {Injectable} from "@angular/core";
import {UmcasewfGraphqlService} from "../um/service/casewf/umcasewf-graphql.service";

@Injectable({
  providedIn: 'root'
})
export class TaskManagementService {

  constructor(private readonly httpClient: HttpClient,
              private userAuthService: UserAuthService,
              private microProductAuth: MicroProductAuthService,
              private umcaseService: UmcasewfGraphqlService) { }

  public getTaskAssignment(appName: string): Promise<any> {
    const configUrl = getEnvVar(GET_TASK_ASSIGNMENT_URL);
    const request = {
      "user_id": this.microProductAuth.getAltUserID()
    }
    return this.httpClient.post(configUrl, request,
      { headers: this.umcaseService.getApiHeaders(appName)}).toPromise();

  }

}
