import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Injectable } from '@angular/core';
import { async, TestBed } from '@angular/core/testing';
import { AuthLibraryModule, MicroProductAuthService,AuthService } from '@ecp/auth-library';
import { of } from 'rxjs';
import { UserAuthService } from './user.service';

@Injectable()
class MicroProductAuthServiceMock {
  getHasuraRole() {
    return 'hasura_role';
  }

  getAltUserID() {
    return 'test'
  }

  getUserID() {
    return 'test'
  }
}

@Injectable()
class AuthServiceMock {
  getActiveLoginClientRole() {
    return ['ecp','sys_admin'];
  }
}

describe('UserAuthService', () => {
  let service: UserAuthService;
  let authService: AuthService;
  let microProductAuth: MicroProductAuthService;
  let httpSpy;


  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [AuthLibraryModule, HttpClientTestingModule],
      providers: [UserAuthService]
    });
    service = TestBed.inject(UserAuthService);
    authService = TestBed.inject(AuthService);
    microProductAuth = TestBed.inject(MicroProductAuthService);
  }));

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should call getUserHasuraRole', () => {
    spyOn(authService, 'getActiveLoginClientRole').and.returnValue(['ecp','sys_admin']);

    spyOn(microProductAuth, 'getHasuraRole').and.returnValue('hasura');
    const role = service.getUserHasuraRole('case-wf');
    expect(role).toBeDefined();
  });

  it('should call getUserHasuraRole with null', () => {
    spyOn(authService, 'getActiveLoginClientRole').and.returnValue(['ecp','sys_admin']);
    spyOn(microProductAuth, 'getHasuraRole').and.returnValue(null);
    const role = service.getUserHasuraRole('case-wf');
    expect(role).toBeDefined();
  });

  it('should call getUserHasuraRole with null', () => {
    spyOn(authService, 'getActiveLoginClientRole').and.returnValue(['','']);
    spyOn(microProductAuth, 'getHasuraRole').and.returnValue(null);
    const role = service.getUserHasuraRole('case-wf');
    expect(role).toBeDefined();
  });


  it('should call getActiveUserRole', () => {
    const spy = spyOn(microProductAuth, 'getAltUserID').and.returnValue('testid');
    spyOn(authService, 'getActiveLoginClientRole').and.returnValue(['ecp','sys_admin']);
    spyOn(microProductAuth, 'getHasuraRole').and.returnValue('hasura');
    spyOn(microProductAuth, 'getUserID').and.returnValue('001373415');
    const role = service.getActiveUserRole();
    expect(service.getActiveUserRole).toBeDefined();
  });

  it('should call getActiveClientOrg', () => {
    const spy = spyOn(microProductAuth, 'getAltUserID').and.returnValue('testid');
    spyOn(authService, 'getActiveLoginClientRole').and.returnValue(['ecp','sys_admin']);
    spyOn(microProductAuth, 'getHasuraRole').and.returnValue('hasura');
    spyOn(microProductAuth, 'getUserID').and.returnValue('001373415');
    const role = service.getActiveClientOrg();
    expect(role).toEqual('ecp');
  });

  it('should call getUserID', () => {
    const spy = spyOn(microProductAuth, 'getAltUserID').and.returnValue('testid');
    spyOn(authService, 'getActiveLoginClientRole').and.returnValue(['ecp','sys_admin']);
    spyOn(microProductAuth, 'getHasuraRole').and.returnValue('hasura');
    spyOn(microProductAuth, 'getUserID').and.returnValue('001373415');
    const id = service.getUserID();
    expect(service.getUserID).toBeDefined();
  });

  it('should call getAltUserID', () => {
    const spy = spyOn(microProductAuth, 'getAltUserID').and.returnValue('testid');
    spyOn(authService, 'getActiveLoginClientRole').and.returnValue(['ecp','sys_admin']);
    spyOn(microProductAuth, 'getHasuraRole').and.returnValue('hasura');
    spyOn(microProductAuth, 'getUserID').and.returnValue('001373415');
    const id = service.getAltUserID();
    expect(service.getAltUserID).toBeDefined();
  });

});
