import {Injectable} from '@angular/core';
import {MicroProductAuthService} from '@ecp/auth-library';
import {HttpClient} from '@angular/common/http';
import {getEnvVar} from '../../../environment/envVarUtil';
import {UTILIZATION_MGMNT_FUNCS_URL, HEALTH_SERVICE_DOMAIN_URL_PATH} from '../../../../../config/config-constants';
import {Observable} from 'rxjs';
import {map} from 'rxjs/operators';
import {
  umClinicalReviewDescriptionQuery,
  getUmAccmulatedBedDayQuery,
  updateHscMutation, getBedDayNotes
} from '../graphql/umBedDayQuery';
import {HscGraphqlService} from '../hsc-update/hsc-graphql.service';
import {ReferenceConstants} from '../../../../../config/reference-constants';


@Injectable({
  providedIn: 'root'
})
export class BedDayDecisionService {

  constructor(private readonly httpClient: HttpClient,
    private readonly hscGraphqlService: HscGraphqlService ) {
  }

  saveBedDayDecisionInfo(bedDayData: any, appName: string): Observable<any> {
    const saveBedDayDeicisionUrl = getEnvVar(UTILIZATION_MGMNT_FUNCS_URL);
    const updateHscRequest = {
      updateHscRequest: {
        hsc_id: bedDayData?.hscID,
        hsc_decn: {
          hsc_decn_id: bedDayData?.decisionId,
          decn_otcome_ref_id: bedDayData?.decisionOutcome,
          decn_bed_day_cnt: Number(bedDayData?.bedDayCount),
          hsr_asgn_id: bedDayData?.hsrAsgnId,
          hsc_decn_bed_days: [
            {
              strt_bed_dt: bedDayData?.date,
              hsc_clin_guid_id: bedDayData?.hscClinGuidID
            }
          ]
        }
      }
    };

    const saveBedDecisionBody = {
      query: updateHscMutation,
      variables: updateHscRequest
    };
    const headers = this.hscGraphqlService.getApiHeaders(appName);
    return this.httpClient.post(saveBedDayDeicisionUrl, saveBedDecisionBody,
      {headers}).pipe(map((res: any) => res));
  }

  // todo update this query
  getAccumulatedBedDay(hscId, appName): Observable<any> {
    const headers = this.hscGraphqlService.getApiHeaders(appName);
    const accumulatedBedDayBody = {
      query: getUmAccmulatedBedDayQuery,
      variables: {
        hsc_id: Number(hscId)
      }
    };
    return this.httpClient.post(getEnvVar(HEALTH_SERVICE_DOMAIN_URL_PATH), JSON.stringify(accumulatedBedDayBody),
      {headers}).pipe(map((res: any) => res));
  }

  getClinicalReviewDescription(hscId, appName): Observable<any> {
    const headers = this.hscGraphqlService.getApiHeaders(appName);
    const clinicalReviewDescriptionBody = {
      query: umClinicalReviewDescriptionQuery,
      variables: {
        hsc_id: Number(hscId)
      }
    };
    return this.httpClient.post(getEnvVar(HEALTH_SERVICE_DOMAIN_URL_PATH), JSON.stringify(clinicalReviewDescriptionBody),
      {headers}).pipe(map((res: any) => res));
  }

  saveBeddayNotes(bedDayNotesData, appName): Observable<any> {
    const saveBedDayNotesUrl = getEnvVar(UTILIZATION_MGMNT_FUNCS_URL);
    const SaveBedDayNotesRequest = {
      updateHscRequest: {
        hsc_id: bedDayNotesData?.hscID,
        hsr_notes: {
          note_txt_lobj: bedDayNotesData.noteText,
          note_typ_ref_id: ReferenceConstants.CLINICAL_REVIEW_NOTE_CATEGORY_REFID,
          note_catgy_ref_id: ReferenceConstants.CLINICAL_REVIEW_NOTE_CATEGORY_REFID,
          hsr_note_sbjs: [
            // {
            //   note_sbj_rec_id: bedDayNotesData?.hscClinGuidID ? bedDayNotesData?.reviewId?.toString() : 'undefined',
            //   note_sbj_typ_ref_id: ReferenceConstants.SUBJECT_TYPE_CLINICAL_REVIEW_REF_ID
            // },
            {
              note_sbj_rec_id: bedDayNotesData?.decisionId ? bedDayNotesData?.decisionId?.toString() : 'undefined', // hsc_decn_id
              note_sbj_typ_ref_id: ReferenceConstants.SUBJECT_TYPE_CLINICAL_DECISION_REF_ID
            }
          ]
        }
      }
    };

    const saveBeddayNotesReqBody = {
      query: updateHscMutation,
      variables: SaveBedDayNotesRequest
    };
    const headers = this.hscGraphqlService.getApiHeaders(appName);
    return this.httpClient.post(saveBedDayNotesUrl, JSON.stringify(saveBeddayNotesReqBody),
      {headers}).pipe(map((res: any) => res));
  }

  getBedDayNotes(bedDayNotesData, appName): Observable<any> {
    const getBedDayNotesUrl = getEnvVar(HEALTH_SERVICE_DOMAIN_URL_PATH);
    const getBeddayNotesReqBody = {
      query: getBedDayNotes,
      variables: {
        hsc_id: bedDayNotesData?.hscID,
        note_sbj_rec_id: bedDayNotesData?.decisionId?.toString()
      }
    };
    const headers = this.hscGraphqlService.getApiHeaders(appName);
    return this.httpClient.post(getBedDayNotesUrl, JSON.stringify(getBeddayNotesReqBody),
      {headers}).pipe(map((res: any) => res));
  }
}
