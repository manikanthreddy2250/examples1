import { TestBed } from '@angular/core/testing';

import { MicroProductAuthService } from '@ecp/auth-library';
import {HttpClient, HttpClientModule} from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Injectable } from '@angular/core';
import { of } from 'rxjs';
import {CaseHeaderService} from './case-header.service';



@Injectable()
class MockHttpClient {
  get(url: string, body: any | null, options?: any) {
    return of([
      {
        id: 'um_intake_ui_1.0.0_ecp_authorization_type_2021-02-12',
        createDateTime: '2021-02-12T21:12:29.235+00:00',
        creatUserId: null,
        changeDateTime: '2021-02-12T21:12:29.235+00:00',
        changeUserId: null
      }
    ]);
  }
  post(url: string, body: any | null, options?: any) {
    return of([
      {
        id: 'um_intake_ui_1.0.0_ecp_authorization_type_2021-02-12',
        createDateTime: '2021-02-12T21:12:29.235+00:00',
        creatUserId: null,
        changeDateTime: '2021-02-12T21:12:29.235+00:00',
        changeUserId: null
      }
    ]);
  }

}

describe('CaseHeaderService', () => {
  let service: CaseHeaderService;
  let microProductAuthService: MicroProductAuthService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [{ provide: HttpClient, useClass: MockHttpClient },
        MicroProductAuthService
      ]
    });
    service = TestBed.inject(CaseHeaderService);
    microProductAuthService = TestBed.inject(MicroProductAuthService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should called getApiHeaders', () => {
    const spy = spyOn(microProductAuthService, 'getEcpToken').and.returnValue('token');
    service.getApiHeaders();
    expect(spy).toHaveBeenCalled();
  });

  it('should called getCaseHeaderDetails', () => {
    const call = service.getCaseHeaderDetails('hscId', 'case_wf_ui');
    expect(call).toBeDefined();
  });

  it('should called getMemberDetails', () => {
   const call =  service.getMemberDetails('indId', 'case_wf_ui');
    expect(call).toBeDefined();
  });

  it('should called getRefDesc', () => {
    const call = service.getRefDesc(123, 'case_wf_ui');
    expect(call).toBeDefined();
  });
});
