import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {HttpHeaders} from '@angular/common/http';
import {GET_CASE_HEADER_URL_PATH, GET_MEMBER_DETAILS_URL_PATH, GET_REF_NEW_URL_PATH} from '../../../../../config/config-constants';
import { MicroProductAuthService } from '@ecp/auth-library';
import {Observable} from 'rxjs';
export interface RawQuery {
    query: string;
    variables: any;
}
import { getEnvVar } from '../../../environment/envVarUtil';



@Injectable({
  providedIn: 'root'
})
export class CaseHeaderService {
  constructor(private readonly httpClient: HttpClient,
    private microProductAuth: MicroProductAuthService) {}

  getApiHeaders(): HttpHeaders {
    return new HttpHeaders()
        .set('Content-Type', 'application/json')
        .set('Authorization', 'Bearer ' + this.microProductAuth.getEcpToken());
  }

  getCaseHeaderDetails(hscId: string, dataDomain?: string): Promise<any> {
    const caseHeaderUrl = getEnvVar(GET_CASE_HEADER_URL_PATH);
    const body = {
      hscid: hscId
    };
    return this.httpClient.post(caseHeaderUrl, JSON.stringify(body), {headers: this.getApiHeaders()}).toPromise();
  }

  getMemberDetails(ind_id: string, dataDomain?: string): Observable<any> {
    const memberDetailsUrl = getEnvVar(GET_MEMBER_DETAILS_URL_PATH);
    const body = {
      indId: ind_id
    };
    return this.httpClient.post(memberDetailsUrl, JSON.stringify(body), {headers: this.getApiHeaders()});
  }

  getRefDesc(refId: number, dataDomain?: string): Observable<any> {
    const refUrl =  getEnvVar(GET_REF_NEW_URL_PATH);
    return this.httpClient.post(refUrl, JSON.stringify(this.retrieveRefDescription(refId)), {headers: this.getApiHeaders()});
  }

  //TODO: need to move to query folder
  private retrieveRefDescription(refId: number): RawQuery {
    return {
      query: 'query refDesc($ref_id: Int!) {\n' +
        ' ref(where: {ref_id: {_eq: $ref_id}}){\n' +
        '    ref_desc\n' +
        '    ref_dspl\n' +
        ' } \n' +
        ' } \n',
      variables: {
        ref_id: refId
      }
    };
  }
}
