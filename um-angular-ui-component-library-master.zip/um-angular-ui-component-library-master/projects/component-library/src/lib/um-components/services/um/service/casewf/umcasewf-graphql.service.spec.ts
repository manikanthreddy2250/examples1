import { TestBed } from '@angular/core/testing';

import { UmcasewfGraphqlService } from './umcasewf-graphql.service';
import { MicroProductAuthService, AuthLibraryModule, AuthService } from '@ecp/auth-library';
import { UserAuthService } from '../../../../services/auth/user.service';
import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Injectable } from '@angular/core';
import { of } from 'rxjs';



@Injectable()
class MockHttpClient {
  get(url: string, body: any | null, options?: any) {
    return of([
      {
        id: 'um_intake_ui_1.0.0_ecp_authorization_type_2021-02-12',
        createDateTime: '2021-02-12T21:12:29.235+00:00',
        creatUserId: null,
        changeDateTime: '2021-02-12T21:12:29.235+00:00',
        changeUserId: null
      }
    ]);
  }

  post(url: string, body: any | null, options?: any) {
    if(body.includes('getHscStatusQuery')){
      return of({"data":{"hsc":[{"hsc_sts_ref_id":19275}]}});
    }else if(body.includes('updateProcedureCodeQuery')){
      return of({"data":{"update_hsc_srvc_by_pk":{"hsc_srvc_id":14404}}});
    }else if(body.includes('delMutation')){
      return of({"data":{"update_hsc_srvc_by_pk":{"hsc_srvc_id":14404}}});
    }else{
      return of([
        {
          id: 'um_intake_ui_1.0.0_ecp_authorization_type_2021-02-12',
          createDateTime: '2021-02-12T21:12:29.235+00:00',
          creatUserId: null,
          changeDateTime: '2021-02-12T21:12:29.235+00:00',
          changeUserId: null
        }
      ]);
    }
  }

}

describe('UmcasewfGraphqlService', () => {
  let service: UmcasewfGraphqlService;
  let microProductAuthService: MicroProductAuthService;
  let userAuthService: UserAuthService;
  let authService: AuthService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, AuthLibraryModule],
      providers: [{ provide: HttpClient, useClass: MockHttpClient }]
    });
    service = TestBed.inject(UmcasewfGraphqlService);
    authService = TestBed.inject(AuthService);
    microProductAuthService = TestBed.inject(MicroProductAuthService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should called getMyTasksListQuery', () => {
    const spy = spyOn(microProductAuthService, 'getAltUserID').and.returnValue('test');
    service.getMyTasksListQuery();
    expect(spy).toHaveBeenCalled();
  });

  it('should called getApiHeaders', () => {
    const spy = spyOn(microProductAuthService, 'getAltUserID').and.returnValue('testid');
    spyOn(authService, 'getActiveLoginClientRole').and.returnValue(['ecp','sys_admin']);
    spyOn(microProductAuthService, 'getHasuraRole').and.returnValue('hasura');
    spyOn(microProductAuthService, 'getUserID').and.returnValue('001373415');
    service.getApiHeaders('case_wf_ui');
    expect(spy).toBeDefined();
  });

  it('should called getDiagnosisCode', () => {
    service.getDiagnosisCode('1234', 'app');
  });

  it('should call getHscTaskDetails', () => {
    const response = service.getHscTaskDetails('case_wf_mgmt_ui', 17642, '72139');
    expect(response).toBeTruthy();
  });

  it('should call getMyTasksListQuery', () => {
    const spy = spyOn(microProductAuthService, 'getAltUserID').and.returnValue('test');
    service.getMyTasksListQuery();
    expect(spy).toHaveBeenCalled();
  });

  it('should call getCaseHeaderDetails', () => {
    service.getCaseHeaderDetails('1234', 'app');
    expect(service.getCaseHeaderDetails).toHaveBeenCalled;
  })

 /* Failing... Please check and uncomment
   it('should call getRefDesc', () => {
    service.getRefDesc(1234, 'app');
    expect(service.getCaseHeaderDetails).toHaveBeenCalled;
  })
 */


  it('should called getHscStatus', () => {
    service.getHscStatus('1234', 'app');
  });

  it('should called updateProcedure', () => {
    service.updateProcedure('1234', 'app');
  });

  it('should called deleteProcedure', () => {
    service.deleteProcedure('1234', '14356',  'app');
  });

  it('should call deleteDiagnosis', () => {
    service.deleteDiagnosis('1234', 'S80', 'app');
  });

  it('should called getDiagnosisSearch', () => {
    service.getDiagnosisSearch('1234', '14356');
  });

  it('should called getDiagDetailsByHscId', () => {
    service.getDiagDetailsByHscId('1234', '14356');
  });

  it('should called getProviderList', () => {
    service.getProviderList('1234', '14356', '123');
  });

  it('should called getProcedureCode', () => {
    service.getProcedureCode('1234', '14356');
  });

  it('should called getProcedureDescHCPCSQuery', () => {
    service.getProcedureDescHCPCSQuery('1234');
  });

  it('should called getProcedureDescCPTQuery', () => {
    service.getProcedureDescCPTQuery('1234');
  });

  it('should called deleteDiagnosisQuery', () => {
    service.deleteDiagnosisQuery('1234', 'S80');
  });
});
