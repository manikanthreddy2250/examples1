import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
export interface RawQuery {
  query: string;
  variables: any;
}
import {HttpHeaders} from '@angular/common/http';
import {
  HEALTH_SERVICE_DOMAIN_URL_PATH,
  CASE_WF_API_URL_PATH,
  UTILIZATION_MGMNT_FUNCS_URL,
  GET_REF_NEW_URL_PATH
} from '../../../../../config/config-constants';
import { MicroProductAuthService } from '@ecp/auth-library';
import { UserAuthService } from '../../../auth/user.service';
import {
  delMutationHscSrvc,
  getDiagnosisCodeQuery, getHscStatusQuery,
  getMyTasksDetailsQuery,
  getProcedureCodeQuery,
  getProcedureCPTQuery,
  getProcedureDescQuery,
  getProviderListQuery,
  getHscTaskDetailsQuery,
  getCaseHeaderDetailsQuery,
  getRefDesc, updateProcedureCodeQuery, getDiagnosisDetailsQuery, delMutationHscDiag, getCommunicationsActivitiesQuery
} from '../graphql/caseWfQuery';
import {getRefDataByBaseRefNameQuery} from '../graphql/referenceQuery';
import {Observable} from 'rxjs';
import { getEnvVar } from '../../../environment/envVarUtil';

@Injectable({
  providedIn: 'root'
})
export class UmcasewfGraphqlService {
  constructor(private readonly httpClient: HttpClient,
              private userAuthService: UserAuthService,
              private microProductAuth: MicroProductAuthService) {}
  procedureData=[];

  getMyTasksListDetails(appName: string, dataDomain?: string): Promise<any> {
    const query = this.getMyTasksListQuery();
    const envUrl = getEnvVar(CASE_WF_API_URL_PATH);
    return this.httpClient.post(envUrl, JSON.stringify(query), { headers: this.getApiHeaders(appName)}).toPromise();
  }

  getMyTasksListDetailsByHscId(appName: string, hscId: string, dataDomain?: string): Promise<any> {
    const query = this.getMyTasksListQueryByHscId(hscId);
    const envUrl = getEnvVar(CASE_WF_API_URL_PATH);
    return this.httpClient.post(envUrl, JSON.stringify(query), { headers: this.getApiHeaders(appName)}).toPromise();
  }

  getProviderList(hscId: any, appName: string, dataDomain?: string): Observable<any> {
    const query = this.getProviderDetailsQuery(parseInt(hscId));
    const envUrl = getEnvVar(CASE_WF_API_URL_PATH);

    return this.httpClient.post(envUrl, JSON.stringify(query),
      {headers: this.getApiHeaders(appName)});
  }

  getDiagDetailsByHscId(hscId:any, appName:any){
    const getDiagDetailsQuery = this.buildGetHscDetailsQuery(parseInt(hscId));
    const hscUrl = getEnvVar(HEALTH_SERVICE_DOMAIN_URL_PATH);
    return this.httpClient.post(hscUrl, JSON.stringify(getDiagDetailsQuery), { headers: this.getApiHeaders(appName)}).toPromise();
  }

  getCommunicationActivities(appName: string, hscId: string, dataDomain?: string): Promise<any> {
    const query = this.getCommunicationActivitiesByHscId(hscId);
    const envUrl = getEnvVar(CASE_WF_API_URL_PATH);
    return this.httpClient.post(envUrl, JSON.stringify(query), { headers: this.getApiHeaders(appName)}).toPromise();
  }

  buildGetHscDetailsQuery(hscId:any): RawQuery{
    return  {
      query: getDiagnosisCodeQuery,
      variables: {
        "hsc_id": hscId,
      }
    };
  }

  getMyTasksListQuery(): RawQuery {
    return  {
      query: getMyTasksDetailsQuery,
      variables: {
        taskListRequest: {
          asgn_to_user_id: this.userAuthService.getAltUserID()
        }
      }
    };
  }

  getMyTasksListQueryByHscId(hscId: any): RawQuery {
    return  {
      query: getMyTasksDetailsQuery,
      variables: {
        taskListRequest: {
          hsc_id: hscId
        }
      }
    };
  }

  getCommunicationActivitiesByHscId(hscId: any): RawQuery {
    return  {
      query: getCommunicationsActivitiesQuery,
      variables: {
        getActivitiesRequest: {
          hsc_id: hscId
        }
      }
    };
  }

  getProviderDetailsQuery(hscId: any): RawQuery {
    return {
      query: getProviderListQuery,
      variables: {
        "hscID": hscId
      }
    };
  }

  getApiHeaders(appName): HttpHeaders {
    return new HttpHeaders()
      .set('Content-Type', 'application/json')
      .set('x-hasura-role', this.userAuthService.getUserHasuraRole(appName))
      .set('x-bpm-cli-org-id', this.userAuthService.getActiveClientOrg())
      .set('x-bpm-func-role',  this.userAuthService.getActiveUserRole())
      .set('Authorization', 'Bearer ' + this.microProductAuth.getEcpToken());
  }

  public getProcedureCode(hscId, appName): Observable<any>{
    const healthQuery = this.getProcedureQuery(hscId);
    const healthUrl = getEnvVar(HEALTH_SERVICE_DOMAIN_URL_PATH);
    return this.httpClient.post(healthUrl, JSON.stringify(healthQuery),{ headers: this.getApiHeaders(appName)})
  }

  public getHscStatus(hscId, appName): Observable<any>{
    const healthQuery = this.getHscStatusQuery(hscId);
    const healthUrl = getEnvVar(HEALTH_SERVICE_DOMAIN_URL_PATH);
     return this.httpClient.post(healthUrl, JSON.stringify(healthQuery),{ headers: this.getApiHeaders(appName)})
  }

  public updateProcedure(hscSrvcId, appName): Observable<any>{
    const healthQuery = this.updateProcedureQuery(hscSrvcId);
    const healthUrl = getEnvVar(HEALTH_SERVICE_DOMAIN_URL_PATH);
    return this.httpClient.post(healthUrl, JSON.stringify(healthQuery),{ headers: this.getApiHeaders(appName)})
  }

  public deleteProcedure(hscId, hscSrvcId, appName): Observable<any>{
    const healthQuery = this.deleteProcedureQuery(hscId, hscSrvcId);
    const healthUrl = getEnvVar(HEALTH_SERVICE_DOMAIN_URL_PATH);
    return this.httpClient.post(healthUrl, JSON.stringify(healthQuery),{ headers: this.getApiHeaders(appName)})
  }

  public deleteDiagnosis(hscId, diagCd, appName): Observable<any>{
    const healthQuery = this.deleteDiagnosisQuery(hscId, diagCd);
    const healthUrl = getEnvVar(HEALTH_SERVICE_DOMAIN_URL_PATH);
    return this.httpClient.post(healthUrl, JSON.stringify(healthQuery), {headers: this.getApiHeaders(appName)})
  }


  getProcedureQuery(hscId): RawQuery {
    return  {
      query: getProcedureCodeQuery,
      variables: {
        "hsc_id": hscId
      }
    }
  };

  getHscStatusQuery(hscId): RawQuery {
    return  {
      query: getHscStatusQuery,
      variables: {
        "hsc_id": hscId
      }
    }
  };

  updateProcedureQuery(hscSrvcId): RawQuery {
    return  {
      query: updateProcedureCodeQuery,
      variables: {
        "hsc_srvc_id": hscSrvcId
      }
    }
  };

  deleteProcedureQuery(hscId, hscSrvcId): RawQuery {
    return  {
      query: delMutationHscSrvc,
      variables: {
        "hsc_srvc_id": hscSrvcId,
        "hsc_id": hscId
      }
    }
  };

  deleteDiagnosisQuery(hscId, diagCd): RawQuery {
    return {
      query: delMutationHscDiag,
      variables: {
        "diag_cd": diagCd,
        "hsc_id": hscId
      }
    }
  };


  getProcedureDescHCPCSQuery(procCode): RawQuery {
    return  {
      query: getProcedureDescQuery,
      variables: {
        "proc_cd": procCode
      }
    }
  };

  getProcedureDescCPTQuery(procCode): RawQuery {
    return  {
      query: getProcedureCPTQuery,
      variables: {
        "proc_cd": procCode
      }
    }
  };

  public getDiagnosisCode(hscId, appName): Promise<any>{
    const query = this.getDiagnosisQuery(hscId);
    const healthUrl = getEnvVar(HEALTH_SERVICE_DOMAIN_URL_PATH);
    return this.httpClient.post(healthUrl, JSON.stringify(query), { headers: this.getApiHeaders(appName)}).toPromise();
  }

  getDiagnosisQuery(hscId): RawQuery {
    return  {
      query: getDiagnosisCodeQuery,
      variables: {
        "hsc_id": hscId
      }
    }
  };

  getDiagnosisSearch(search, appName): Promise <any> {
    const diagQuery = this.getDiagnosisSearchQuery(search);
    const refUrl = getEnvVar(GET_REF_NEW_URL_PATH);
    return this.httpClient.post(refUrl, JSON.stringify(diagQuery), {
      headers: this.getApiHeaders(appName)
    }).toPromise();
  }

  getDiagnosisSearchQuery(search): RawQuery {
    return {
      query: getDiagnosisDetailsQuery,
      variables: {
        search
      }
    }
  };



  getHscTaskDetails(appName: string, hscId: number, taskNameRefID: string): Observable<any> {
    const query = this.getHscTaskQuery(hscId, parseInt(taskNameRefID));
    const envUrl = getEnvVar(CASE_WF_API_URL_PATH);
    return this.httpClient.post(envUrl, JSON.stringify(query), { headers: this.getApiHeaders(appName)});
  }

  loadBaseRefNameDisplayData(appName: string, baseRefName: string): Promise<any> {
    const healthQuery = this.getRefDataByBaseRefNameQuery(baseRefName);
    const healthUrl = getEnvVar(HEALTH_SERVICE_DOMAIN_URL_PATH);
    return this.httpClient.post(healthUrl, JSON.stringify(healthQuery), {
        headers: this.getApiHeaders(appName),
      }).toPromise();
  }

  getHscTaskQuery(hscId, taskNameRefID): RawQuery {
    return  {
      query: getHscTaskDetailsQuery,
      variables: {
        getTaskDetailsRequest: {
          hsr_asgn: {
            "hsc_id": hscId,
            "asgn_typ_ref_id": taskNameRefID
          }
        }
      }
    };
  }

  public getCaseHeaderDetails(hscId: any ,appName: string): Promise<any> {
    const query = this.getCaseHeaderDetailsQuery(hscId);
    const envUrl = getEnvVar(CASE_WF_API_URL_PATH);
    return this.httpClient.post(envUrl, JSON.stringify(query),
    {headers: this.getApiHeaders(appName)}).toPromise();
  }

  getCaseHeaderDetailsQuery(hscId): RawQuery {
    return  {
      query: getCaseHeaderDetailsQuery,
      variables: {
        getCaseHeaderDetailsRequest: {
          "hscID": {
            "hsc_id":hscId
          }
        }
      }
    };
  }

  getRefDesc(refId: number, appName: string, dataDomain?: string): Promise<any> {
    const refUrl =  getEnvVar(GET_REF_NEW_URL_PATH);
    return this.httpClient.post(refUrl, JSON.stringify(this.getRefDescriptionQuery(refId)),
    {headers: this.getApiHeaders(appName)}).toPromise();
  }

  getRefDescriptionQuery(refId: number): RawQuery {
    return {
      query: getRefDesc,
      variables: {
        ref_id: refId
      }
    };
  }
  getRefDataByBaseRefNameQuery(baseRefName: string): RawQuery {
    return {
      query: getRefDataByBaseRefNameQuery,
      variables: {
        bas_ref_nm: baseRefName,
      },
    };
  }
}
