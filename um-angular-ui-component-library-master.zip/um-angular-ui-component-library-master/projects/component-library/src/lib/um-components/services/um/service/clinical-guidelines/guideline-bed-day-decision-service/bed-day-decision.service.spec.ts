import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import { MicroProductAuthService } from '@ecp/auth-library';
import { Injectable } from '@angular/core';
import { of } from 'rxjs';
import { BedDayDecisionService } from './bed-day-decision.service';
// import {EnvironmentService} from '../../../../../services/environment/envVarUtil';
import { GuidelinesUtils } from 'projects/component-library/src/lib/um-components/clinical-guidelines/shared/guidelines-utils';
import {UserAuthService} from '../../../../auth/user.service';
import { AuthService } from '@ecp/auth-library';
import { OAuthService, UrlHelperService, OAuthLogger } from 'angular-oauth2-oidc';
import {ActivatedRoute, Router} from '@angular/router';
import {LoggerConfig, NGXLogger, NGXLoggerHttpService, NGXMapperService} from 'ngx-logger';
import {DatePipe} from '@angular/common';
import {RouterTestingModule} from '@angular/router/testing';
import {GuidelinesBedDayModule} from "projects/component-library/src/lib/um-components/clinical-guidelines/guidelines-bed-day-decision/guidelines-bed-day.module";


@Injectable({
  providedIn: 'root'
})
class MockHttpClient {
  post(url: string, body: any | null, options?: any) {
    return of([
      {
        data: {
          saveBedDay: {
            beddayRes: [
              {
                updateClinicalGuidResponse: {
                  beddayRes: {
                    update_hsc_clin_guid_by_pk: {
                      clin_rev_sts_ref_id: 72755,
                      hsc_clin_guid_id: 1668,
                      chg_dttm: '2021-04-29T21:07:03.929'
                    }
                  }
                }
              },
              {
                hscDecnResponse: {
                  res: {
                    insert_hsc_decn: {
                      affected_rows: 1,
                      returning: [
                        {
                          hsc_decn_id: 1022,
                          creat_dttm: '2021-05-03T00:56:52.98',
                          decn_typ_ref_id: null,
                          decn_otcome_ref_id: 72755,
                          decn_rsn_ref_id: null,
                          decn_made_by_user_id: null,
                          decn_made_by_user_org_desc: null,
                          hsc_id: 11186
                        }
                      ]
                    }
                  }
                }
              },
              {
                hscDecnBedDayResponse: {
                  res: {
                    insert_hsc_decn_bed_day: {
                      affected_rows: 1,
                      returning: [
                        {
                          hsc_decn_id: 1022,
                          strt_bed_dt: '2021-05-01',
                          bed_typ_ref_id: null,
                          accum_bed_day_cnt: 1,
                          decn_rndr_dttm_facl_lcl_txt: null,
                          decn_facl_cmnct_dttm: null
                        }
                      ]
                    }
                  }
                }
              }
            ]
          }
        }
      }
    ]);
  }
}

describe('BedDayDecisionService', () => {
  let service: BedDayDecisionService;
  // let environmentService: EnvironmentService;
  let util: GuidelinesUtils;
  let userAuthService: UserAuthService;
  let microProductAuthService: MicroProductAuthService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule, GuidelinesBedDayModule],
      providers: [{ provide: HttpClient, useClass: MockHttpClient }, GuidelinesUtils,
        UserAuthService, AuthService, OAuthService, UrlHelperService, OAuthLogger, NGXLogger, NGXMapperService, NGXLoggerHttpService, LoggerConfig, DatePipe,
        MicroProductAuthService]
    });
    service = TestBed.inject(BedDayDecisionService);
    //environmentService = TestBed.inject(EnvironmentService);
    util = TestBed.inject(GuidelinesUtils);
    userAuthService = TestBed.inject(UserAuthService);
  });

  const ecpClaims: any = {
    'x-ecp-claims': {
      'x-ecp-attrs': {},
      'x-ecp-alt-user-id': 'abcdefg',
      'x-ecp-cli-orgs': [{
        'org-id': 'ecp',
        'func-roles': [{
          'role-name': 'clinical_guidelines_uhc_rules_admin',
          'appl-roles': ['case_wf_mgmt_ui_system', 'clinical_guidelines_nurse', 'clinical_guidelines_uhc_dmn_grp_deploy', 'rules_authoring_write', 'system_mgmt_user', 'um_case_mgmt_uhc_dmn_grp_execute_all', 'um_intake_ui_provider']
        }]
      }],
      'x-ecp-first-name': 'John',
      'x-ecp-type': 'PASSWORD',
      'x-ecp-user-id': '1234567890',
      'x-ecp-email': 'test@test.com',
      'x-ecp-last-name': 'Doe',
      'x-ecp-source': 'msid'
    },
    'https://hasura.io/jwt/claims': {
      'x-hasura-default-role': 'case_wf_mgmt_ui_system',
      'x-hasura-attrs': '{ }',
      'x-hasura-cli-org': 'ecp',
      'x-hasura-user-id': '123456789',
      'x-hasura-func-role': 'clinical_guidelines_uhc_rules_admin',
      'x-hasura-allowed-roles': ['case_wf_mgmt_ui_system', 'clinical_guidelines_nurse', 'clinical_guidelines_uhc_dmn_grp_deploy', 'rules_authoring_write', 'system_mgmt_user', 'um_case_mgmt_uhc_dmn_grp_execute_all', 'um_intake_ui_provider']
    },
    scope: 'openid',
    iss: 'ecp-dev',
    exp: 1620898342,
    client_id: 'ecp_platform'
  };

  const headers = new HttpHeaders()
    .set('Content-Type', 'application/json')
    .set('Authorization', 'Bearer ' + 'token')
    .set('x-bpm-cli-org-id', 'ecp')
    .set('x-bpm-func-role', ecpClaims?.['x-ecp-claims']?.['x-ecp-cli-orgs']?.[0]?.['func-roles']?.[0]?.['role-name'])
    .set('x-bpm-tenant-id', 'ecpumcasemgmtbasebpmgrp')
    .set('x-hasura-role', 'case_wf_mgmt_ui_nurse');

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  // it('should called getApiHeaders', () => {
  //   const spy = spyOn(util, 'getApiHeaders').and.returnValue(headers);
  //   // const ecpClaimsObj = spyOn(microProductAuthService, 'getEcpClaims').and.returnValue(ecpClaims);
  //   // util.getApiHeaders();
  //   expect(spy).toHaveBeenCalled();
  // });

  it('should Save bed Day Decision', () => {
    const bedDayData = {
      BedDayCount: '1',
      date: new Date(),
      Decision: 'Approve',
      hscID: 11186
    };
    const ecpClaimsObj = spyOn(util, 'getApiHeaders').and.returnValue(headers);
    const call =  service.saveBedDayDecisionInfo(bedDayData);
    expect(call).toBeDefined();
  });

  it('should call getAccumulatedBedDay method', () => {
    const ecpClaimsObj = spyOn(util, 'getApiHeaders').and.returnValue(headers);
    const call = service.getAccumulatedBedDay('11186');
    expect(call).toBeDefined();
  });

  it('should call getClinicalReviewDescription method', () => {
    const ecpClaimsObj = spyOn(util, 'getApiHeaders').and.returnValue(headers);
    const call = service.getClinicalReviewDescription('11186');
    expect(call).toBeDefined();
  });

  it('should Save bed Day Notes', () => {
    const bedDayNotesData = {
      hscID: 11186,
      hscClinGuidID: '1727',
      noteText: 'Sample Text'
    };
    const ecpClaimsObj = spyOn(util, 'getApiHeaders').and.returnValue(headers);
    const call =  service.saveBeddayNotes(bedDayNotesData);
    expect(call).toBeDefined();
  });

  it('should call getBedDayNotes method', () => {
    const bedDayReq =
      {
        hsc_id: 11186,
        hsc_clin_guid_id: '1727'
      };
    const ecpClaimsObj = spyOn(util, 'getApiHeaders').and.returnValue(headers);
    const call = service.getBedDayNotes(bedDayReq);
    expect(call).toBeDefined();
  });

});
