import {Injectable} from '@angular/core';
import {MicroProductAuthService} from '@ecp/auth-library';
import {HttpClient} from '@angular/common/http';
import {getEnvVar} from '../../../../environment/envVarUtil';
import {GUIDELINES_FUNCTION_URL, HEALTH_SERVICE_DOMAIN_URL_PATH} from '../../../../../../config/config-constants';
import {Observable} from 'rxjs';
import {map} from 'rxjs/operators';
import {
  clinicalReviewDescriptionQuery,
  getAccmulatedBedDayQuery,
  saveBeddayNotes,
  saveBedDayDecisionQuery, getBedDayNotes, clinicalReviewEscalatedQuery
} from '../../graphql/medicalReviewGraphqlQuery';
import {GuidelinesUtils} from '../../../../../clinical-guidelines/shared/guidelines-utils';


@Injectable({
  providedIn: 'root'
})
export class BedDayDecisionService {

  constructor(private readonly httpClient: HttpClient, private readonly utils: GuidelinesUtils) {
  }

  saveBedDayDecisionInfo(bedDayData: any): Promise<any>{
    const saveBedDayDeicisionUrl = getEnvVar(GUIDELINES_FUNCTION_URL);
    const BeddayRequest = {
      beddayReq: {
        hsc_id: bedDayData?.hscID,
        decn_bed_day_cnt: bedDayData?.BedDayCount,
        bedDayDecnOutcomeValue: bedDayData?.Decision,
        strt_bed_dt: bedDayData?.date,
        hsc_clin_guid_id: bedDayData?.hscClinGuidID,
        processTaskExecutionID: bedDayData?.processTaskExecutionID
      }
    };

    const saveBedDecisionBody = {
      query: saveBedDayDecisionQuery,
      variables: {
        BeddayRequest
      }
    };
    const headers = this.utils.getApiHeaders();
    return this.httpClient.post(saveBedDayDeicisionUrl, JSON.stringify(saveBedDecisionBody),
      {headers}).toPromise();
  }

  getAccumulatedBedDay(hscId): Promise<any> {
    const headers = this.utils.getApiHeaders();
    const accumulatedBedDayBody = {
      query: getAccmulatedBedDayQuery,
      variables: {
        hsc_id: parseInt(hscId)
      }
    };
    return this.httpClient.post(getEnvVar(HEALTH_SERVICE_DOMAIN_URL_PATH), JSON.stringify(accumulatedBedDayBody),
      {headers}).toPromise();
  }

  getLatestEscalatedGuidID(hscID): Promise<any>{
    const headers = this.utils.getApiHeaders();
    const clinicalReviewEscalatedBoddy = {
      query: clinicalReviewEscalatedQuery,
      variables: {
        hsc_id: hscID
      }
    };
    return this.httpClient.post(getEnvVar(HEALTH_SERVICE_DOMAIN_URL_PATH), JSON.stringify(clinicalReviewEscalatedBoddy),
      {headers}).toPromise();
  }

  getClinicalReviewDescription(primaryClinicalID): Promise<any> {
    const headers = this.utils.getApiHeaders();
    const clinicalReviewDescriptionBody = {
      query: clinicalReviewDescriptionQuery,
      variables: {
        hsc_clin_guid_id: primaryClinicalID
      }
    };
    return this.httpClient.post(getEnvVar(HEALTH_SERVICE_DOMAIN_URL_PATH), JSON.stringify(clinicalReviewDescriptionBody),
      {headers}).toPromise();
  }

  saveBeddayNotes(bedDayNotesData): Promise<any> {
    const saveBedDayNotesUrl = getEnvVar(GUIDELINES_FUNCTION_URL);
    const SaveBedDayNotesRequest = {
      saveBedDayNotesRequest: {
        hsc_clin_guid_id: bedDayNotesData?.hscClinGuidID?.toString(),
        hsc_id: bedDayNotesData?.hscID,
        note_txt_lobj: bedDayNotesData.noteText,
      }
    };

    const saveBeddayNotesReqBody = {
      query: saveBeddayNotes,
      variables: {
        SaveBedDayNotesRequest
      }
    };
    const headers = this.utils.getApiHeaders();
    return this.httpClient.post(saveBedDayNotesUrl, JSON.stringify(saveBeddayNotesReqBody),
      {headers}).toPromise();
  }

  getBedDayNotes(bedDayNotesData): Promise<any> {
    const getBedDayNotesUrl = getEnvVar(GUIDELINES_FUNCTION_URL);
    const SaveBedDayNotesRequest = {
      saveBedDayNotesRequest: {
        hsc_clin_guid_id: bedDayNotesData?.hscClinGuidID?.toString(),
        hsc_id: bedDayNotesData?.hscID,
      }
    };

    const saveBeddayNotesReqBody = {
      query: getBedDayNotes,
      variables: {
        SaveBedDayNotesRequest
      }
    };
    const headers = this.utils.getApiHeaders();
    return this.httpClient.post(getBedDayNotesUrl, JSON.stringify(saveBeddayNotesReqBody),
      {headers}).toPromise();
  }
}
