import { TestBed } from '@angular/core/testing';
import { GuidelineSummaryService } from './guideline-summary.service';
import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Injectable } from '@angular/core';
import { of } from 'rxjs';
import * as NDT_Response from 'stories/assets/NDT_Response.json';
import { GuidelinesUtils } from '../../../../../clinical-guidelines/shared/guidelines-utils';
import { UserAuthService } from "../../../../auth/user.service";
import { OAuthLogger, OAuthService, UrlHelperService } from 'angular-oauth2-oidc';
import { RouterTestingModule } from '@angular/router/testing';
import { NGXLogger, NGXMapperService, NGXLoggerHttpService, LoggerConfig } from 'ngx-logger';
import { DatePipe } from "@angular/common";

@Injectable()
class MockHttpClient {
  post(url: string, body: any | null, options?: any) {
    return of(NDT_Response);
  }
}

describe('GuidelineSummaryService', () => {
  let service: GuidelineSummaryService;
  let utils: GuidelinesUtils;
  let userAuthService: UserAuthService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule],
      providers: [{ provide: HttpClient, useClass: MockHttpClient }, GuidelinesUtils, OAuthService, OAuthService, UrlHelperService, OAuthLogger,
        NGXLogger, NGXMapperService, NGXLoggerHttpService, LoggerConfig, DatePipe]
    });
    service = TestBed.inject(GuidelineSummaryService);
    utils = TestBed.inject(GuidelinesUtils);
    userAuthService = TestBed.inject(UserAuthService);
  });

  it('should be created', () => {
    expect(service.getGuidelineData).toBeDefined();
    expect(service).toBeTruthy();
  });


  it('should be run getGuidelineData ', () => {
    expect(service.getGuidelineData).toBeDefined();
    //expect(service).toBeTruthy();
    service.getGuidelineData('AISD0153', 'RM21').subscribe((res) => {
      expect(res).toBeTruthy();
    });
  });

});

// @Injectable()
// class MockHttpClient {
//   post(url: string, body: any | null, options?: any) {
//     return of(NDT_Response);
//   }
// }


// describe('MedicalReviewGraphqlServiceService', () => {
//   let service: GuidelineSummaryService;
//   let utils: GuidelinesUtils;
//   let userAuthService: UserAuthService;

//   beforeEach(() => {
//     TestBed.configureTestingModule({
//       imports: [HttpClientTestingModule, RouterTestingModule],
//       providers: [{ provide: HttpClient, useClass: MockHttpClient },  GuidelinesUtils, OAuthService, OAuthService, UrlHelperService, OAuthLogger,
//         NGXLogger, NGXMapperService, NGXLoggerHttpService, LoggerConfig, DatePipe]});
//     service = TestBed.inject(GuidelineSummaryService);
//     utils = TestBed.inject(GuidelinesUtils);
//     userAuthService = TestBed.inject(UserAuthService);
//   });


//   it('should be run getGuidelineData ', () => {
//     service.getGuidelineData('AISD0153', 'RM20').subscribe((res) => {
//       expect(res).toBeTruthy();
//     });
//  });

// });
