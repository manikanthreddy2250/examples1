import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { GUIDELINES_FUNCTION_URL } from '../../../../../../config/config-constants';
import { getEnvVar } from '../../../../environment/envVarUtil';
import { GuidelinesUtils } from '../../../../../clinical-guidelines/shared/guidelines-utils';
import { map } from 'rxjs/operators';
import { getNDTQuery } from '../../graphql/medicalReviewGraphqlQuery';


@Injectable({
  providedIn: 'root'
})
export class GuidelineSummaryService {

  constructor(private httpClient: HttpClient, private readonly utils: GuidelinesUtils) {
  }

  getGuidelineData(subsetId, version): any {
    console.log('Guideline Data....')
    const GuidelineMedicalReviewInput = {
      subsetId,
      version
    };
    const getNDTTreeQuery = {
      query: getNDTQuery,
      variables: {
        GuidelineMedicalReviewInput
      }
    };
    const headers = this.utils.getApiHeaders();
    console.log('headers are' + JSON.stringify(headers));
    return this.httpClient.post(getEnvVar(GUIDELINES_FUNCTION_URL), JSON.stringify(getNDTTreeQuery),
      { headers }).pipe(map((res: any) => res));
  }
}


