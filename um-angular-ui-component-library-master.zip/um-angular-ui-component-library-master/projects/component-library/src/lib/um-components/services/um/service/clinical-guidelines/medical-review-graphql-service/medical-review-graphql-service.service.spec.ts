import { Injectable } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { HttpClient} from '@angular/common/http';
import { of } from 'rxjs';
import * as NDT_Response from 'stories/assets/NDT_Response.json';
import { MedicalReviewGraphqlServiceService } from './medical-review-graphql-service.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import {GuidelinesUtils} from '../../../../../clinical-guidelines/shared/guidelines-utils';
import {UserAuthService} from "../../../../auth/user.service";
import {OAuthLogger, OAuthService, UrlHelperService} from 'angular-oauth2-oidc';
import {RouterTestingModule} from '@angular/router/testing';
import {NGXLogger, NGXMapperService, NGXLoggerHttpService, LoggerConfig} from 'ngx-logger';
import {DatePipe} from "@angular/common";
// import { NGXMapperService } from './mapper.service';

@Injectable()
class MockHttpClient {
  post(url: string, body: any | null, options?: any) {
    return of(NDT_Response);
  }
}


describe('MedicalReviewGraphqlServiceService', () => {
  let service: MedicalReviewGraphqlServiceService;
  let utils: GuidelinesUtils;
  let userAuthService: UserAuthService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule],
      providers: [{ provide: HttpClient, useClass: MockHttpClient },  GuidelinesUtils, OAuthService, OAuthService, UrlHelperService, OAuthLogger,
        NGXLogger, NGXMapperService, NGXLoggerHttpService, LoggerConfig, DatePipe]});
    service = TestBed.inject(MedicalReviewGraphqlServiceService);
    utils = TestBed.inject(GuidelinesUtils);
    userAuthService = TestBed.inject(UserAuthService);
  });


  it('should be run getNdtData ', () => {
    service.getNdtData('AISD0153', 'RM20').subscribe((res) => {
      expect(res).toBeTruthy();
    });
 });

  xit('should be run getCitationData ', () => {
    service.getCitationData('1537280').subscribe((res) => {
      expect(res).toBeTruthy();
    });
  });

  it('should be run getNotes ', () => {
    service.getNotes('366764', '1', 'ANSWER_NOTE', '2').subscribe((res) => {
      expect(res).toBeTruthy();
    });
  });

  it('should be run getEhrData ', () => {
    service.getEhrData('50906d70-1c86-48d5-86c0-89a4eff6a33c', '28a2074e-4462-4589-b7a1-9e0709e86eb5').then((res) => {
      expect(res).toBeTruthy();
    });
  });

});
