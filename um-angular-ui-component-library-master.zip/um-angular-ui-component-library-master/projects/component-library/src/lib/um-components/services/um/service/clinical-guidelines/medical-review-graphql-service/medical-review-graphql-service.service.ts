import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { getEnvVar } from '../../../../environment/envVarUtil';
import {GUIDELINES_FUNCTION_URL} from '../../../../../../config/config-constants';
import {map} from 'rxjs/operators';
import {GuidelinesUtils} from '../../../../../clinical-guidelines/shared/guidelines-utils';
import {
  getCitationQuery,
  getMedicalReviewQuery,
  getMedicalReviewSummaryQuery,
  getNDTQuery,
  getNDTSelectionsQuery,
  getNotesQuery,
  getSubsetSearchQuery,
  saveReviewQuery,
  saveReviewToOCMDbQuery,
  getEmrDataQuery,
  completeReviewQuery,
  getSmartSheetSubsetQuery,
  getSmartSheetQuesQuery
}
  from '../../graphql/medicalReviewGraphqlQuery';

@Injectable({
  providedIn: 'root'
})
export class MedicalReviewGraphqlServiceService {


  constructor(private readonly httpClient: HttpClient, private readonly utils: GuidelinesUtils) {
  }

  getNdtData(subsetId, version): any {
    const GuidelineMedicalReviewInput = {
      subsetId,
      version
      };
    const getNDTTreeQuery = {
      query: getNDTQuery,
      variables: {
        GuidelineMedicalReviewInput
      }
    };
    const headers = this.utils.getApiHeaders();
    console.log('headers are'  + JSON.stringify(headers));
    return this.httpClient.post(getEnvVar(GUIDELINES_FUNCTION_URL), JSON.stringify(getNDTTreeQuery),
      { headers }).pipe(map((res: any) => res));

  }

  getSelectionData(questionReq): any {
    const QuestionRequest = {
      questionReq
      };
    const getNDTTreeSelectionsQuery = {
      query: getNDTSelectionsQuery,
      variables: {
        QuestionRequest
      }
    };

    const headers = this.utils.getApiHeaders();
    return this.httpClient.post(getEnvVar(GUIDELINES_FUNCTION_URL), JSON.stringify(getNDTTreeSelectionsQuery),
      { headers }).pipe(map((res: any) => res));
  }

  getMedicalReviewGridData(hsc_id): any{
    const GetMedicalReviewGridRequest = {
      hsc_id
    };
    const getMedicalReviewGridQuery = {
      query: getMedicalReviewSummaryQuery,
      variables: {
        GetMedicalReviewGridRequest
      }
    };

    const headers = this.utils.getApiHeaders();
    console.log('Headers ' + headers.keys());
    return this.httpClient.post(getEnvVar(GUIDELINES_FUNCTION_URL), JSON.stringify(getMedicalReviewGridQuery),
      { headers }).pipe(map((res: any) => res));
  }

  getSubsetSearchData(productCids, version, codes, isTransitionPlan): any {
    const GetSubsetSearchRequest = {
      productCids,
      version,
      codes,
      isTransitionPlan
    };
    const getSubsetQuery = {
      query: getSubsetSearchQuery,
      variables: {
        GetSubsetSearchRequest
      }
    };

    const headers = this.utils.getApiHeaders();
    return this.httpClient.post(getEnvVar(GUIDELINES_FUNCTION_URL), JSON.stringify(getSubsetQuery),
      { headers }).pipe(map((res: any) => res));
  }

  getNotes(subsetUniqueId: string, id: string, noteType: string, parentId: string): any {
    const GetNotesRequest = {
      subset_unique_id: subsetUniqueId,
      id,
      note_type: noteType,
      parent_id: parentId
    };

    const getNotesInfoQuery = {
      query: getNotesQuery,
      variables: {
        GetNotesRequest
      }
    };


    const headers = this.utils.getApiHeaders();
    return this.httpClient.post(getEnvVar(GUIDELINES_FUNCTION_URL), JSON.stringify(getNotesInfoQuery),
      { headers }).pipe(map((res: any) => res));

  }

  getCitationData(id): any {
    const CitationFhirInput = {
      id
    };
    const getCitationInfoQuery = {
      query: getCitationQuery,
      variables: {
        CitationFhirInput
      }
    };

    const headers = this.utils.getApiHeaders();
    return this.httpClient.post(getEnvVar(GUIDELINES_FUNCTION_URL), JSON.stringify(getCitationInfoQuery),
      { headers }).pipe(map((res: any) => res));
  }

  saveMedicalReviewDataToIQ(questionReq): any{
    const QuestionRequest = {
      questionReq
    };
    const saveMedicalReviewDataQuery = {
      query: saveReviewQuery,
      variables: {
        QuestionRequest
      }
    };

    const headers = this.utils.getApiHeaders();
    return this.httpClient.post(getEnvVar(GUIDELINES_FUNCTION_URL), JSON.stringify(saveMedicalReviewDataQuery),
      { headers }).toPromise();
  }

  async completeMedicalReview(reviewID, decisionID, status, guidelineID): Promise<any>{
    const body = this.prepareCompleteRequest(reviewID, decisionID, status, guidelineID);
    await this.completeMedicalReviewIQ(body);
  }

  prepareCompleteRequest(reviewID, decisionID, status, guidelineID): any {
    const body = {
      resourceType: 'QuestionnaireResponse',
      identifier: {
        use: 'official',
        value: reviewID
      },
      questionnaire: decisionID,
      status,
      id: guidelineID
    };
    return body;
  }

  completeMedicalReviewIQ(questionReq): any{
    const QuestionRequest = {
      questionReq
    };
    const saveMedicalReviewDataQuery = {
      query: completeReviewQuery,
      variables: {
        QuestionRequest
      }
    };

    const headers = this.utils.getApiHeaders();
    return this.httpClient.post(getEnvVar(GUIDELINES_FUNCTION_URL), JSON.stringify(saveMedicalReviewDataQuery),
      { headers }).toPromise();
  }

  saveMedicalReviewDataToOCMDb(reviewData): any{
    const SaveMedicalReviewRequest = {
      reviewData
    };
    const saveMedicalReviewDataToOCMDbQuery = {
      query: saveReviewToOCMDbQuery,
      variables: {
        SaveMedicalReviewRequest
      }
    };

    const headers = this.utils.getApiHeaders();
    return this.httpClient.post(getEnvVar(GUIDELINES_FUNCTION_URL), JSON.stringify(saveMedicalReviewDataToOCMDbQuery),
      { headers }).toPromise();
  }

  getMedicalReviewDataFromIQ(uuid): any{
    const GetMedicalReviewRequest = {
      uuid
    };
    const getMedicalReviewDataQuery = {
      query: getMedicalReviewQuery,
      variables: {
        GetMedicalReviewRequest
      }
    };
    const headers = this.utils.getApiHeaders();
    return this.httpClient.post(getEnvVar(GUIDELINES_FUNCTION_URL), JSON.stringify(getMedicalReviewDataQuery),
      { headers }).toPromise();
  }

  getExistingQuestionnaireData(questionReq): any {
    const QuestionRequest = {
        questionReq
    };
    const getNDTTreeSelectionsQuery = {
      query: getNDTSelectionsQuery,
      variables: {
        QuestionRequest
      }
    };
    const headers = this.utils.getApiHeaders();
    return this.httpClient.post(getEnvVar(GUIDELINES_FUNCTION_URL), JSON.stringify(getNDTTreeSelectionsQuery),
      { headers }).toPromise();
  }

  getEhrData(iquuid , emruuid): any {
    const GetAutoReviewEHRDataRequest = {
      iquuid,
      emruuid
    };
    const getEmrDataInfoQuery = {
      query: getEmrDataQuery,
      variables: {
        GetAutoReviewEHRDataRequest
      }
    };
    const headers = this.utils.getApiHeaders();
    return this.httpClient.post(getEnvVar(GUIDELINES_FUNCTION_URL), JSON.stringify(getEmrDataInfoQuery),
      { headers }).toPromise();
  }

  getSmartSheetData(subsetId): any {
    const GetSmartSheetRequest = {
      subsetId
      };
    const getSmartSheetQuery = {
      query: getSmartSheetSubsetQuery,
      variables: {
        GetSmartSheetRequest
      }
    };
    const headers = this.utils.getApiHeaders();
    return this.httpClient.post(getEnvVar(GUIDELINES_FUNCTION_URL), JSON.stringify(getSmartSheetQuery),
      { headers }).pipe(map((res: any) => res));

  }

  getSmartSheetQuestionData(recommendationDefId): any {
    const GetSmartSheetQuestionRequest = {
      recommendationDefId
      };
    const getSmartSheetQuestionQuery = {
      query: getSmartSheetQuesQuery,
      variables: {
        GetSmartSheetQuestionRequest
      }
    };
    const headers = this.utils.getApiHeaders();
    return this.httpClient.post(getEnvVar(GUIDELINES_FUNCTION_URL), JSON.stringify(getSmartSheetQuestionQuery),
      { headers }).pipe(map((res: any) => res));

  }

}
