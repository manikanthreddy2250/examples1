import { TestBed } from '@angular/core/testing';
import { MicroProductAuthService } from '@ecp/auth-library';
import { MedicalReviewTreeService } from './medical-review-tree.service';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA, ChangeDetectorRef, Injectable } from '@angular/core';

@Injectable()
class MicroProductAuthServiceStub {

  getUserID() {
    return 'TESTUSERID';
  }

  isLocalHost() {
    return false;
  }
}

describe('MedicalReviewTreeService', () => {
 let service: MedicalReviewTreeService;

 beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [{ provide: MicroProductAuthService, useClass: MicroProductAuthServiceStub }],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    });
    service = TestBed.inject(MedicalReviewTreeService);
  });

 it('should be created', () => {
    const service: MedicalReviewTreeService = TestBed.get(MedicalReviewTreeService);
    expect(service).toBeTruthy();
  });
 it(' should getUserName', () => {
    expect(service.getUserName()).toEqual('TESTUSERID');
  });

 it('should  prepareNDTbodyToSave ', () => {
    const service: MedicalReviewTreeService = TestBed.get(MedicalReviewTreeService);
    const review_uuid = '9aed17b9-0350-43ac-b99b-526ba7088dcc';
    const checkedIds = [{
      linkId: 'AISD015304010201',
      answer: [{
        valueBoolean: 'true'
      }]
    }, {
      linkId: 'AISD01530401020201',
      answer: [{
        valueBoolean: 'true'
      }]
    }];
    const reviewReqBodyData = [{
      id: 'AISD01530401020201',
      checkValue: 'CHECKED',
      reviewUUID: '9aed17b9-0350-43ac-b99b-526ba7088dcc',
      stepResponseId: 'RC3::AISD015304',
      subsetUniqueId: 353625,
      reviewVersion: 0,
      reviewRevision: 0,
      lockedDate: '2021-01-13T07:06:10Z',
      status: 6
    }];
    const comments = [{
      name: 'AISD015304010202',
      valueId: 'TestingUser1, TestingUser1',
      valueDateTime: '2021-02-01T14:09:02.296Z',
      valueString: 'sab'
    }];
    expect(service.prepareNDTbodyToSave).toBeDefined();
    service.prepareNDTbodyToSave(checkedIds, review_uuid, reviewReqBodyData, comments);
    expect(service.prepareNDTbodyToSave).toBeTruthy();
  });

 it('should be setHscservice call', () => {
    service.setHscservice([{ hsc_id: '16440436900', proc_cd: '12345' }]);
    expect(service.setHscservice).toBeTruthy();
  });

 it('should be getHscServices call', () => {
    service.getHscServices();
    expect(service.getHscServices).toBeTruthy();
  });


 it('should be setHscId call', () => {
    service.setHscId('1212');
    expect(service.setHscId).toBeTruthy();
  });

 it('should be getHscId call', () => {
    service.getHscId();
    expect(service.getHscId).toBeTruthy();
  });

 it('should  saveNdtReviewDetails ', () => {
    const service: MedicalReviewTreeService = TestBed.get(MedicalReviewTreeService);
    const ndtTreeRes = {
      resourceType: 'Questionnaire',
      id: 353625,
      version: 'RM20',
      identifier: [{
        use: 'official',
        value: 353625
      }, {
        use: 'usual',
        value: 'RC3::AISD015304'
      }],
      name: 'COPD',
      title: 'LOC:Acute Adult InterQual® 2020, Apr. 2020 Release',
      status: 'active',
      publisher: 'Change Helathcare',
      meta: {
        tag: [{
          code: 'product_id',
          display: 'AISD'
        }, {
          code: 'version_id',
          display: 'RM20'
        }, {
          code: 'subset_id',
          display: 'AISD0153'
        }, {
          code: 'review_type',
          display: 'NDT'
        }]
      },
      code: [],
      contained: []
    };
    const checkedIds = [{
      linkId: 'AISD015304010201',
      answer: [{
        valueBoolean: 'true'
      }]
    }, {
      linkId: 'AISD01530401020201',
      answer: [{
        valueBoolean: 'true'
      }]
    }];
    const comments = [{
      name: 'AISD015304010202',
      valueId: 'TestingUser1, TestingUser1',
      valueDateTime: '2021-02-01T14:09:02.296Z',
      valueString: 'sab'
    }];
    expect(service.saveNdtReviewDetails).toBeDefined();
    service.saveNdtReviewDetails(ndtTreeRes, checkedIds, comments);
    expect(service.saveNdtReviewDetails).toBeTruthy();
  });

});
