import { Injectable } from '@angular/core';
import { MicroProductAuthService } from '@ecp/auth-library';
import { R4 } from '@ahryman40k/ts-fhir-types/lib';

@Injectable({
  providedIn: 'root'
})
export class MedicalReviewTreeService {

  constructor(private readonly microProductAuthService: MicroProductAuthService) { }
  questionresponse: R4.IQuestionnaire = { resourceType: "Questionnaire" };
  hscservice = [];
  hscId: any;
  event: any;
  getUserName() {
    if (this.microProductAuthService.isLocalHost()) { // to avoid adding a token in storage while working in local
      return 'SYSTEM';
    } else {
      return this.microProductAuthService.getUserID();
    }
  }
  setHscservice(value) {
    this.hscservice = value;
  }

  getHscServices() {
    return this.hscservice;
  }

  setDropDownEvent(event) {
    this.event = event;
  }

  getDropDownEvent() {
    return this.event;
  }

  setHscId(value) {
    this.hscId = value
  }

  getHscId() {
    return this.hscId
  }

  prepareJsonToCallGetNextItemFhir(requestParams) {
    console.log('clearLowerLoc.....' + requestParams.clearLowerLoc);
    const body =
    {
      resourceType: 'QuestionnaireResponse',
      meta: {
        lastUpdated: new Date(),
        tag: [{
          code: 'subset_unique_id',
          display: requestParams.subsetUniqueId
        }, {
          code: 'version_id',
          display: requestParams.versionVal
        }, {
          code: 'subset_id',
          display: requestParams.guidelineId
        }, {
          code: 'review_type',
          display: 'NDT'
        }, {
          code: 'autoSave',
          display: 'false'
        }, {
          code: 'product_id',
          display: requestParams.productId
        }
        ]
      },
      questionnaire: requestParams.subsetUniqueId,
      item: requestParams.checkedIds,
      contained: [{
        resourceType: 'Parameters',
        id: 'lastUserAction',
        parameter: [{
          name: 'step_response.id',
          valueString: requestParams.stepResponseId
        }, {
          name: 'selections.id',
          valueString: requestParams.id
        }, {
          name: 'selections.choice',
          valueString: requestParams.checkedValue
        }, {
          name: 'clear_lower_loc',
          valueBoolean: requestParams.clearLowerLoc
        }, {
          name: 'next',
          valueBoolean: requestParams.dischargeReviewFlag
        }
        ]
      }
      ]
    };
    return body;
  }

  prepareNDTbodyToSave(checkedIds, review_uuid, reviewReqBodyData, comments) {
    const body = {
      resourceType: 'QuestionnaireResponse',
      identifier: {
        use: 'official',
        value: review_uuid
      },
      meta: {
        lastUpdated: new Date(),
        tag: [
          {
            code: 'product_id',
            display: reviewReqBodyData[0].productId
          },
          {
            code: 'version_id',
            display: reviewReqBodyData[0].version
          },
          {
            code: 'subset_id',
            display: reviewReqBodyData[0].guideLineID
          },
          {
            code: 'review_type',
            display: 'NDT'
          },
          {
            code: 'autoSave',
            display: 'true'
          },
          {
            code: 'review_revision',
            display: reviewReqBodyData[0].reviewRevision
          },
          {
            code: 'review_version',
            display: reviewReqBodyData[0].reviewVersion
          },
          {
            code: 'lockedDate',
            display: reviewReqBodyData[0].lockedDate
          }, {
            code: 'skipUI',
            display: true
          }
        ]
      },
      questionnaire: reviewReqBodyData[0].subsetUniqueId,
      status: reviewReqBodyData[0].status,
      item: checkedIds,
      contained: [
        {
          resourceType: 'Parameters',
          id: 'lastUserAction',
          parameter: [
            {
              name: 'step_response.id',
              valueString: reviewReqBodyData[0].stepResponseId
            },
            {
              name: 'selections.id',
              valueString: reviewReqBodyData[0].id
            },
            {
              name: 'selections.choice',
              valueString: reviewReqBodyData[0].checkValue
            },
            {
              name: 'clear_lower_loc',
              valueBoolean: false
            }
          ]
        },
        {
          resourceType: 'Parameters',
          id: 'comments',
          parameter: comments
        }
      ]
    };
    return body;
  }

  saveNdtReviewDetails(ndtTreeRes, checkedIds, comments){
    const body = {
      resourceType: 'QuestionnaireResponse',
      identifier: {},
      meta: {},
      item: checkedIds,
      contained: [
        {
          resourceType: 'Parameters',
          id: 'cp-tree',
          parameter: ndtTreeRes
        },
        {
          resourceType: 'Parameters',
          id: 'comments',
          parameter: comments
        }
      ]
    };
    return body;
  }
}


