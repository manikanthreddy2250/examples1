import { TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA, Injectable, NO_ERRORS_SCHEMA } from '@angular/core';
import {AuthService, MicroProductAuthService, OAuthInitService} from '@ecp/auth-library';
import { BpmnStartProcessService } from './bpmn-start-process.service';
import {HttpBackend, HttpClient, HttpHandler} from "@angular/common/http";
import { of } from 'rxjs';
import {BedDayDecisionService} from "../guideline-bed-day-decision-service/bed-day-decision.service";
import {GuidelinesUtils} from "../../../../../clinical-guidelines/shared/guidelines-utils";
import {OAuthLogger, OAuthService, UrlHelperService} from "angular-oauth2-oidc";
import {LoggerConfig, NGXLogger, NGXLoggerHttpService, NGXMapperService} from "ngx-logger";
import {DatePipe} from "@angular/common";
import {RouterTestingModule} from "@angular/router/testing";
import {RouterModule} from "@angular/router";

const ecpClaims = { "x-ecp-claims": { "x-ecp-attrs": {}, "x-ecp-alt-user-id": "", "x-ecp-cli-orgs": [{ "org-id": "ecp", "func-roles": [{ "role-name": "rules_admin", "appl-roles": ["autoapproval-dmn_deploy", "autorouting-dmn_deploy", "bpm_execute_all", "case_wf_mgmt_ui_read", "configuration-dmn_deploy", "example_dmn_grp_deploy", "health_srvc_delete", "icuerules-dmn_deploy", "memberblocking-dmn_deploy", "obsderivation-dmn_deploy", "programs-dmn_deploy", "rules_authoring_write", "siteofservice-dmn_deploy", "system_mgmt_user", "testharness-dmn_deploy", "um_intake_ui_read", "umintake_sos_mbr_elig_dmn_grp_deploy", "umintake_sos_prov_elig_dmn_grp_deploy"] }] }], "x-ecp-first-name": "Sahithya", "x-ecp-type": "PASSWORD", "x-ecp-user-id": "001173408", "x-ecp-email": "sahithya_sivaraju@optum.com", "x-ecp-last-name": "Pachipulusu Sivaraju", "x-ecp-source": "msid" }, "https://hasura.io/jwt/claims": { "x-hasura-default-role": "autoapproval-dmn_deploy", "x-hasura-attrs": "{ }", "x-hasura-cli-org": "ecp", "x-hasura-user-id": "001173408", "x-hasura-func-role": "rules_admin", "x-hasura-allowed-roles": ["autoapproval-dmn_deploy", "autorouting-dmn_deploy", "bpm_execute_all", "case_wf_mgmt_ui_read", "configuration-dmn_deploy", "example_dmn_grp_deploy", "health_srvc_delete", "icuerules-dmn_deploy", "memberblocking-dmn_deploy", "obsderivation-dmn_deploy", "programs-dmn_deploy", "rules_authoring_write", "siteofservice-dmn_deploy", "system_mgmt_user", "testharness-dmn_deploy", "um_intake_ui_read", "umintake_sos_mbr_elig_dmn_grp_deploy", "umintake_sos_prov_elig_dmn_grp_deploy"] }, "scope": "openid", "iss": "ecp-dev", "exp": 1603473684, "client_id": "ecp_platform" };

@Injectable()
class MicroProductAuthServiceStub {
  getEcpClaims() {
    return {
      'x-ecp-claims': {
        'x-ecp-attrs': {},
        'x-ecp-alt-user-id': '',
        'x-ecp-cli-orgs': [{
          'org-id': 'ecp',
          'func-roles': [{
            'role-name': 'rules_admin',
            'appl-roles': ['autoapproval-dmn_deploy', 'clinical_guidelines_nurse', 'bpm_execute_all', 'case_wf_mgmt_ui_read', 'configuration-dmn_deploy', 'example_dmn_grp_deploy', 'health_srvc_delete', 'icuerules-dmn_deploy', 'memberblocking-dmn_deploy', 'obsderivation-dmn_deploy', 'programs-dmn_deploy', 'rules_authoring_write', 'siteofservice-dmn_deploy', 'system_mgmt_user', 'testharness-dmn_deploy', 'um_intake_ui_read', 'umintake_sos_mbr_elig_dmn_grp_deploy', 'umintake_sos_prov_elig_dmn_grp_deploy']
          }]
        }],
        'x-ecp-first-name': 'Sahithya',
        'x-ecp-type': 'PASSWORD',
        'x-ecp-user-id': '001173408',
        'x-ecp-email': 'sahithya_sivaraju@optum.com',
        'x-ecp-last-name': 'Pachipulusu Sivaraju',
        'x-ecp-source': 'msid'
      },
      'https://hasura.io/jwt/claims': {
        'x-hasura-default-role': 'autoapproval-dmn_deploy',
        'x-hasura-attrs': '{ }',
        'x-hasura-cli-org': 'ecp',
        'x-hasura-user-id': '001173408',
        'x-hasura-func-role': 'rules_admin',
        'x-hasura-allowed-roles': ['autoapproval-dmn_deploy', 'autorouting-dmn_deploy', 'bpm_execute_all', 'case_wf_mgmt_ui_read', 'configuration-dmn_deploy', 'example_dmn_grp_deploy', 'health_srvc_delete', 'icuerules-dmn_deploy', 'memberblocking-dmn_deploy', 'obsderivation-dmn_deploy', 'programs-dmn_deploy', 'rules_authoring_write', 'siteofservice-dmn_deploy', 'system_mgmt_user', 'testharness-dmn_deploy', 'um_intake_ui_read', 'umintake_sos_mbr_elig_dmn_grp_deploy', 'umintake_sos_prov_elig_dmn_grp_deploy']
      },
      scope: 'openid',
      iss: 'ecp-dev',
      exp: 1603473684,
      client_id: 'ecp_platform'
    };
  }

  getUserRoles() {
    return 'Provider';
  }

  getEcpOrgId() {
    return 'TESTUSERID';
  }

  getEcpToken() {
    return 'testToken';
  }

  isLocalHost() {
    return false;
  }

  getHasuraRole() {
    return 'clinical_guidelines_md';
  }
}
describe('BpmnStartProcessService', () => {
  let service: BpmnStartProcessService;
  let mockMicroProductAuthService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, RouterModule],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
     // providers: [HttpClient, HttpHandler, { provide: MicroProductAuthService, useClass: MicroProductAuthServiceStub }, AuthService, OAuthInitService],
      providers: [HttpClient, HttpHandler, {provide: MicroProductAuthService, useClass: MicroProductAuthServiceStub},  GuidelinesUtils, OAuthService, OAuthService, UrlHelperService, OAuthLogger,
        NGXLogger, NGXMapperService, NGXLoggerHttpService, LoggerConfig, DatePipe, HttpBackend],
    });
    service = TestBed.inject(BpmnStartProcessService);
  });

  afterEach(() => {
    TestBed.resetTestingModule();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should be call startProcess', () => {
    const hscData = { "withVariablesInReturn": "true", "variables": { "hsc": { "value": "{\"tenant\":\"UHC\",\"services\":[{\"epalcodes\":\"80346\"}],\"member\":{\"lineOfBusiness\":\"UHC E&I\",\"policyNumber\":\"0128855\",\"state\":\"IL\"}}", "type": "Json", "valueInfo": { "transient": true } } } }
    expect(service.startProcess(hscData)).toBeTruthy()
  });

  it('should be call getDMNRules', () => {
    const hscData = {
      hsc: {
        member: {
          lineOfBusiness: 'UHC E&I'
        },
        settingRef: 'Inpatient',
        tenant: 'UHC'
      }
    };
    expect(service.getDMNRules(hscData)).toBeTruthy()
  });

  it('should be call getIpFlowDMNRules', () => {
    const dmnIpFlowReq = {
      "hsc": {
        "member": {
          "lineOfBusiness":"UHC E&I",
          "age": 42
        },
        "hscFacls": {
           "plsrvRefCd": "Mental"
        },
        "serviceSettingRef": "Inpatient",
        "submissionType": "Admission Review",
        "tenant": "UHC"
      }
    };

    expect(service.getIpFlowDMNRules(dmnIpFlowReq)).toBeTruthy()
  });
});
