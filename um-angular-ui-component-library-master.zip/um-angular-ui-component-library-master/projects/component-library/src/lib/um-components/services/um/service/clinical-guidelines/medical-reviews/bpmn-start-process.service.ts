import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { MicroProductAuthService } from '@ecp/auth-library';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import {GuidelinesUtils} from '../../../../../clinical-guidelines/shared/guidelines-utils';
import {getEnvVar} from '../../../../environment/envVarUtil';
import {GUIDELINES_BPMN_URL,
  GUIDELINES_DRAFT_DMN_URL,
  GUIDELINES_IP_DMN_URL} from '../../../../../../config/config-constants';

@Injectable({
  providedIn: 'root'
})
export class BpmnStartProcessService {


  constructor(public httpClient: HttpClient, private microProductAuthService: MicroProductAuthService, private utils: GuidelinesUtils) {
  }

  startProcess(hscData: any): Observable<any> {
    const httpOptions = {
      headers: this.utils.getApiHeaders()
    };
    return this.httpClient.post(getEnvVar(GUIDELINES_BPMN_URL), hscData, httpOptions).pipe(map((res) => res));
  }

  getDMNRules(hscData: any): Observable<any> {
    const httpOptions = {
      headers: this.utils.getApiHeaders()
    };
    return this.httpClient.post(getEnvVar(GUIDELINES_DRAFT_DMN_URL), hscData, httpOptions).pipe(map((res) => res));
  }

  getIpFlowDMNRules(hscData: any): Observable<any> {
    const httpOptions = {
      headers: this.utils.getApiHeaders()
    };
    return this.httpClient.post(getEnvVar(GUIDELINES_IP_DMN_URL), hscData, httpOptions).pipe(map((res) => res));
  }
}
