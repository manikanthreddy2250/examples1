import {TestBed} from '@angular/core/testing';
import {HscAuthDetailService} from './hsc-auth-detail.service';
import {Injectable} from '@angular/core';
import {of} from 'rxjs';
import {HttpClient} from '@angular/common/http';
import {BpmnStartProcessService} from '../../../service/clinical-guidelines/medical-reviews/bpmn-start-process.service';
import {UserAuthService} from '../../../../auth/user.service';
import {AuthService} from '@ecp/auth-library';
import {OAuthLogger, OAuthService, UrlHelperService} from 'angular-oauth2-oidc';
import {GuidelinesUtils} from '../../../../../clinical-guidelines/shared/guidelines-utils';
import {ActivatedRoute, Router} from '@angular/router';
import {LoggerConfig, NGXLogger, NGXLoggerHttpService, NGXMapperService} from 'ngx-logger';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import {RouterTestingModule} from '@angular/router/testing';
import {DatePipe} from '@angular/common';

@Injectable()
class MockBpmnStartProcessService {
  bpmnHscData = {
    withVariablesInReturn: true,
    variables: {
      hsc: {
        value: '{\'tenant\':\'UHC\',\'services\':[{\'epalcodes\':\'80346\'}],\'member\':{\'lineOfBusiness\':\'UHC E&I\',\'policyNumber\':\'0128855\',\'state\':\'IL\'}}',
        type: 'Json',
        valueInfo: {transient: true}
      }
    }
  };

  getUserRoles() {
    return 'clinical-guidelines-user';
  }

  getEcpOrgId() {
    const mockupResults = of({
      'x-ecp-claims': {
        'x-ecp-attrs': {},
        'x-ecp-alt-user-id': '',
        'x-ecp-cli-orgs': [{
          'org-id': 'ecp',
          'func-roles': [{
            'role-name': 'rules_admin',
            'appl-roles': ['autoapproval-dmn_deploy', 'autorouting-dmn_deploy', 'bpm_execute_all', 'case_wf_mgmt_ui_read', 'configuration-dmn_deploy', 'example_dmn_grp_deploy', 'health_srvc_delete', 'icuerules-dmn_deploy', 'memberblocking-dmn_deploy', 'obsderivation-dmn_deploy', 'programs-dmn_deploy', 'rules_authoring_write', 'siteofservice-dmn_deploy', 'system_mgmt_user', 'testharness-dmn_deploy', 'um_intake_ui_read', 'umintake_sos_mbr_elig_dmn_grp_deploy', 'umintake_sos_prov_elig_dmn_grp_deploy']
          }]
        }],
        'x-ecp-first-name': 'Sahithya',
        'x-ecp-type': 'PASSWORD',
        'x-ecp-user-id': '001173408',
        'x-ecp-email': 'sahithya_sivaraju@optum.com',
        'x-ecp-last-name': 'Pachipulusu Sivaraju',
        'x-ecp-source': 'msid'
      },
      'https://hasura.io/jwt/claims': {
        'x-hasura-default-role': 'autoapproval-dmn_deploy',
        'x-hasura-attrs': '{ }',
        'x-hasura-cli-org': 'ecp',
        'x-hasura-user-id': '001173408',
        'x-hasura-func-role': 'rules_admin',
        'x-hasura-allowed-roles': ['autoapproval-dmn_deploy', 'autorouting-dmn_deploy', 'bpm_execute_all', 'case_wf_mgmt_ui_read', 'configuration-dmn_deploy', 'example_dmn_grp_deploy', 'health_srvc_delete', 'icuerules-dmn_deploy', 'memberblocking-dmn_deploy', 'obsderivation-dmn_deploy', 'programs-dmn_deploy', 'rules_authoring_write', 'siteofservice-dmn_deploy', 'system_mgmt_user', 'testharness-dmn_deploy', 'um_intake_ui_read', 'umintake_sos_mbr_elig_dmn_grp_deploy', 'umintake_sos_prov_elig_dmn_grp_deploy']
      },
      scope: 'openid',
      iss: 'ecp-dev',
      exp: 1603473684,
      client_id: 'ecp_platform'
    });
    return mockupResults;
  }

  startProcess(bpmnHscData: any) {
    const responseObj = of({
      links: [],
      id: 'aad086f9-51e7-11eb-a888-b46921716208',
      definitionId: 'clinical_guidelines:2:7358b001-51e3-11eb-bc27-b46921716208',
      businessKey: null,
      caseInstanceId: null,
      ended: true,
      suspended: false,
      tenantId: 'ecpclinicalguidelinesuhcdmngrp',
      variables: {
        hsc: {
          type: 'Json',
          value: '{\'tenant\':\'UHC\',\'services\':[{ \'epalcodes\':\'23470\'},{ \'epalcodes\':\'29834\'}], \'member\':{\'lineOfBusiness\':\'C&S\',\'policyNumber\':\'EXGN\',\'state\':\'AZ\'}}',
          valueInfo: {
            transient: true
          }
        },
        processResult: {
          type: String,
          value: '{\r\n  \'result\' : [ {\r\n    \'dtqOrIqGuidelines\' : \'IQ: ISP7592\',\r\n    \'versionId\' : \'RM20\',\r\n    \'source\' : \'IQ\'\r\n  }, {\r\n    \'dtqOrIqGuidelines\' : \'IQ:  ISP7592\',\r\n    \'versionId\' : \'RM20\',\r\n    \'source\' : \'IQ\'\r\n  } ]\r\n}',
          valueInfo: {}
        }
      }
    });
    return responseObj;
  }

  getIpFlowDMNRules(bpmnHscData: any) {
    const responseObj = of([{productCID: 'PISD'}]);
    return responseObj;
  }
}

@Injectable()
class MockHttpClient {
  post(url: string, body: any | null, options?: any) {
    if (body.includes('getHscAuthDetails')) {
      return of({
        data: {
          getHscAuthDetails: {
            hsc: [
              {
                hsc_id: 17111,
                creat_dttm: null,
                creat_user_id: 'SYSTEM',
                indv_id: 503926748,
                indv_key_typ_ref_id: 2757,
                indv_key_val: '16440436900',
                mbr_cov_dtl: {
                  indv_id: 503926748,
                  pol_nbr: '0752023',
                  cov_eff_dt: '2020-02-01',
                  cov_end_dt: '9999-12-31',
                  mbr_cov_id: 90881934,
                  productCode: 226,
                  indv_key_val: '16440436900',
                  productCatgyTpe: null,
                  coverageTypeDesc: 'Optum Behav. Health',
                  indv_key_typ_ref_id: 2757,
                  claim_platform_ref_Id: 363
                },
                hsc_sts_ref_id: 19274,
                flwup_cntc_dtl: null,
                rev_prr_ref_id: 3754,
                rev_prr_ref_cd: {
                  ref_id: 3754,
                  ref_cd: '1',
                  ref_desc: 'Routine',
                  ref_dspl: 'Routine'
                },
                srvc_set_ref_id: 3737,
                srvc_set_ref_cd: {
                  ref_id: 3737,
                  ref_cd: '1',
                  ref_desc: 'Inpatient',
                  ref_dspl: 'Inpatient'
                },
                hsc_keys: [
                  {
                    hsc_id: 16078,
                    hsc_key_val: 'ad1adf4f-96f7-11eb-a953-d6ea16ab6fef',
                    hsc_key_typ_ref_id: 19517
                  }
                ],
                hsc_srvcs: [],
                hsc_facls: [
                  {
                    actul_admis_dttm: null,
                    actul_dschrg_dttm: null,
                    expt_admis_dt: null,
                    expt_dschrg_dt: null,
                    plsrv_ref_id: 3743,
                    plsrv_ref_cd: {
                      ref_id: 3743,
                      ref_cd: '21',
                      ref_desc: 'Acute Hospital',
                      ref_dspl: 'Acute Hospital'
                    },
                    srvc_desc_ref_id: 4347,
                    srvc_desc_ref_cd: {
                      ref_id: 4347,
                      ref_cd: '1',
                      ref_desc: 'Scheduled',
                      ref_dspl: 'Scheduled'
                    },
                    srvc_dtl_ref_id: 4307,
                    srvc_dtl_ref_cd: {
                      ref_id: 4307,
                      ref_cd: '2',
                      ref_desc: 'Surgical',
                      ref_dspl: 'Surgical'
                    }
                  }
                ],
                hsc_diags: [
                  {
                    hsc_diag_id: 4969,
                    diag_cd: 'A78',
                    inac_ind: 0
                  }
                ],
                hsr_notes: [],
                hsc_provs: [
                  {
                    auto_aprv_ltr_ind: null,
                    hsc_prov_id: 6331,
                    chg_sys_ref_id: null,
                    chg_user_id: 'ecp_engineer',
                    creat_sys_ref_id: null,
                    creat_user_id: 'ecp_engineer',
                    data_qlty_iss_list: null,
                    data_secur_rule_list: null,
                    end_dt: null,
                    hsc_prov_end_rsn_ref_id: null,
                    ltr_opt_out_cc_ind: null,
                    med_rec_nbr: null,
                    ntwk_strg_rsn_ref_id: null,
                    ntwk_sts_ref_id: null,
                    prov_loc_affil_dtl: {
                      providerDetails: {
                        prov_id: 2529852,
                        prov_keys: [
                          {
                            prov_key_val: '1114122074',
                            prov_key_typ_ref_id: 2782
                          },
                          {
                            prov_key_val: null,
                            prov_key_typ_ref_id: 16333
                          },
                          {
                            prov_key_val: null,
                            prov_key_typ_ref_id: 2783
                          }
                        ],
                        prov_adr_id: 7425448,
                        prov_cat_typ_ref_id: 16309
                      }
                    },
                    prov_loc_affil_id: null,
                    spcl_ref_id: 16892,
                    strt_dt: null,
                    telcom_adr_id: '7735104726',
                    updt_ver_nbr: 0,
                    hsc_prov_roles: [
                      {
                        hsc_prov_id: 6331,
                        prov_role_ref_id: 3765
                      }
                    ]
                  }
                ]
              }
            ]
          }
        }
      });
    }
  }
}


describe('HscAuthDetailService', () => {
  let service: HscAuthDetailService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule],
      providers: [{provide: HttpClient, useClass: MockHttpClient},
        {provide: BpmnStartProcessService, useClass: MockBpmnStartProcessService}, UserAuthService, AuthService,
        OAuthService, UrlHelperService, OAuthLogger, GuidelinesUtils, NGXLogger, NGXMapperService, NGXLoggerHttpService, LoggerConfig, DatePipe]
    });
    service = TestBed.inject(HscAuthDetailService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  xit('should get Hsc Details ', () => {
    const getHscAuthRequest = {hsc: {hsc_id: 17111}};
    service.getHscAuthDetails(getHscAuthRequest).subscribe((res) => {
      expect(res.data.getHscAuthDetails.hsc[0].hsc_id).toEqual(17111);
    });
  });

});
