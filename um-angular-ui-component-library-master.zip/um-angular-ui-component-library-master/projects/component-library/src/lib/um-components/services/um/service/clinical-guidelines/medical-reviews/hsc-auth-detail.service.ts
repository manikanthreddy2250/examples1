import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { getHscAuthDetails } from '../../graphql/medicalReviewGraphqlQuery';
import {getEnvVar} from '../../../../environment/envVarUtil';
import {UTILIZATION_MGMNT_FUNCS_URL} from '../../../../../../config/config-constants';
import {GuidelinesUtils} from '../../../../../clinical-guidelines/shared/guidelines-utils';
import {map} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class HscAuthDetailService {
  constructor(private httpClient: HttpClient, private utils: GuidelinesUtils) {
  }

  getHscAuthDetails(getHscAuthRequest): any {
    const getHscAuthDetailsMutationQuery = {
      query: getHscAuthDetails,
      variables: { getHscAuthRequest }
    };
    const headers = this.utils.getApiHeaders();
    return this.httpClient.post(getEnvVar(UTILIZATION_MGMNT_FUNCS_URL), JSON.stringify(getHscAuthDetailsMutationQuery),
      { headers }).pipe(map((res: any) => res));
  }
}
