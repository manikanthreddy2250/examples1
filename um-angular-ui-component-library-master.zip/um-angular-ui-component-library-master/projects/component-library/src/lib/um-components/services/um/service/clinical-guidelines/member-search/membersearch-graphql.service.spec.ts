import { TestBed } from '@angular/core/testing';
import { MembersearchGraphqlService } from './membersearch-graphql.service';
import { HttpClient, HttpHandler,HttpClientModule } from "@angular/common/http";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { NO_ERRORS_SCHEMA, Injectable } from '@angular/core';
import { UserAuthService } from '../../auth/user.service';
import { AuthLibraryModule, MicroProductAuthService, AuthService, OAuthInitService } from "@ecp/auth-library";

@Injectable()
class UserAuthServiceMock {

  getUserID() {
    return 'TESTUSERID';
  }

  isLocalHost() {
    return false;
  }

  getActiveClientOrg() {
    return 'ecp'
  }

  getActiveUserRole() {
    return 'sys_admin'
  }

  getAltUserID() {
    return 'test';
  }

  getUserHasuraRole() {
    return 'test'
  }
}
describe('MembersearchGraphqlService', () => {
  let service: MembersearchGraphqlService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports :[HttpClientModule,HttpClientTestingModule,AuthLibraryModule],
      providers:[MembersearchGraphqlService,{ provide: UserAuthService, useClass: UserAuthServiceMock },MicroProductAuthService,AuthService, OAuthInitService],
      schemas: [NO_ERRORS_SCHEMA]
    });
    service = TestBed.inject(MembersearchGraphqlService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should call getApiHeaders', () => {
    service.getApiHeaders('appName')
    expect(service.getApiHeaders).toBeTruthy();
  });

  it('should call getMemberDetailsData', () => {
    service.getMemberDetailsData('3256712','appName')
    expect(service.getMemberDetailsData).toBeTruthy();
  });

  it('should call getMemberDetailsQuery', () => {
    service.getMemberDetailsQuery('3256712')
    expect(service.getMemberDetailsQuery).toBeTruthy();
  });

  it('should call getMemberCoverageDetailsData', () => {
    service.getMemberCoverageDetailsData('3256712','appName')
    expect(service.getMemberCoverageDetailsData).toBeTruthy();
  });

  it('should call getMemberShipDetailsQuery', () => {
    service.getMemberShipDetailsQuery('3256712')
    expect(service.getMemberShipDetailsQuery).toBeTruthy();
  });

  it('should call getRefDescData', () => {
    service.getRefDescData('3256712','appName')
    expect(service.getRefDescData).toBeTruthy();
  });

  it('should call getRefDescDetailsQuery', () => {
    service.getRefDescDetailsQuery('3256712')
    expect(service.getRefDescDetailsQuery).toBeTruthy();
  });

 /* it('should call getIpFlowDMNRules', () => {
    const dmnIpFlowReq = {
      "hsc": {
        "member": {
          "lineOfBusiness":"UHC E&I",
          "age": 31
        },
        "hscFacls": {
          "plsrvRefCd": "Acute Hospital"
        },
        "serviceSettingRef": "Inpatient",
        "submissionType": "Admission Review",
        "tenant": "UHC"
      }
    };
    service.getIpFlowDMNRules(dmnIpFlowReq,'appName')
    expect(service.getIpFlowDMNRules).toBeTruthy();
  });*/

});
