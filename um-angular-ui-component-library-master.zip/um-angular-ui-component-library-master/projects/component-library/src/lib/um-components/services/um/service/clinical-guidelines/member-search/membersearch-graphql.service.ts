import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
export interface RawQuery {
  query: string;
  variables: any;
}
// import { EnvironmentService } from '../../../environment/environment.service';
import { HttpHeaders } from '@angular/common/http';
import {
  INDIVIDUAL_DOMAIN_URL_PATH,
  HEALTH_SERVICE_DOMAIN_URL_PATH,
  GET_MEMBER_DETAILS_URL_PATH,
  MEMBERSHIP_DOMAIN_URL_PATH,
  GET_REF_NEW_URL_PATH,
  GET_IP_DMN_RULE_URL_PATH
} from '../../../../../../config/config-constants';
import { MicroProductAuthService } from '@ecp/auth-library';
import {getEnvVar} from '../../../../environment/envVarUtil';
import { UserAuthService } from '../../auth/user.service';
import { Observable } from "rxjs";
import { getMemberShipDtlsQuery, getIndividualSearchQuery, getRefDescQuery } from '../../graphql/membeSearchQuery'
import { map } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class MembersearchGraphqlService {

  constructor(private readonly httpClient: HttpClient,
    private readonly userAuthService: UserAuthService,
    private readonly microProductAuth: MicroProductAuthService,
  ) { }

  getApiHeaders(appName): HttpHeaders {
    return new HttpHeaders()
      .set('Content-Type', 'application/json')
      .set('x-hasura-role', this.userAuthService.getUserHasuraRole(appName))
      .set('x-bpm-cli-org-id', this.userAuthService.getActiveClientOrg())
      .set('x-bpm-func-role', this.userAuthService.getActiveUserRole())
      .set('x-bpm-tenant-id', 'ecpclinicalguidelinesuhcdmngrp')
      .set('Authorization', 'Bearer ' + this.microProductAuth.getEcpToken());
  }

  getMemberDetailsData(indv_key_val: any, appName: string, dataDomain?: string): Observable<any> {
    const query = this.getMemberDetailsQuery(indv_key_val);
    const indvUrl = getEnvVar(HEALTH_SERVICE_DOMAIN_URL_PATH);

    return this.httpClient.post(indvUrl, JSON.stringify(query),
      { headers: this.getApiHeaders(appName) });
  }

  getMemberDetailsQuery(indv_key_val: any): RawQuery {
    return {
      query: getIndividualSearchQuery,
      variables: {
        "indv_key_val": indv_key_val
      }
    };
  }
  // getMemberDetails(ind_id: string, appName: string, dataDomain?: string): Observable<any> {
  //   const memberDetailsUrl = getEnvVar(GET_MEMBER_DETAILS_URL_PATH);
  //   const body = {
  //     indId: ind_id
  //   };
  //   return this.httpClient.post(memberDetailsUrl, JSON.stringify(body), {headers: this.getApiHeaders(appName)});
  // }

  getMemberCoverageDetailsData(mbrcovid: any, appName: string, dataDomain?: string): Observable<any> {
    const query = this.getMemberShipDetailsQuery(mbrcovid);
    const indvUrl = getEnvVar(MEMBERSHIP_DOMAIN_URL_PATH);

    return this.httpClient.post(indvUrl, JSON.stringify(query),
      { headers: this.getApiHeaders(appName) });
  }

  getMemberShipDetailsQuery(mbrcovid: any): RawQuery {
    return {
      query: getMemberShipDtlsQuery,
      variables: {
        "mbr_cov_id": mbrcovid
      }
    };
  }

  getRefDescData(refId: any, appName: string, dataDomain?: string): Observable<any> {
    const query = this.getRefDescDetailsQuery(refId);
    const refUrl = getEnvVar(GET_REF_NEW_URL_PATH);

    return this.httpClient.post(refUrl, JSON.stringify(query),
      { headers: this.getApiHeaders(appName) });
  }

  getRefDescDetailsQuery(refId: any): RawQuery {
    return {
      query: getRefDescQuery,
      variables: {
        "ref_id": refId
      }
    };
  }
}
