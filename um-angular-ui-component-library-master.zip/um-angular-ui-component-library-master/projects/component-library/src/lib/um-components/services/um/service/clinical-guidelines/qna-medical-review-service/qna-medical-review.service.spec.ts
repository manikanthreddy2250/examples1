
import {HttpClient} from '@angular/common/http';
import {QnaMedicalReviewService} from './qna-medical-review.service';
import {GuidelinesUtils} from '../../../../../clinical-guidelines/shared/guidelines-utils';
import {UserAuthService} from '../../auth/user.service';
import {TestBed} from '@angular/core/testing';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import {RouterTestingModule} from '@angular/router/testing';
import {DatePipe} from '@angular/common';
import {of} from 'rxjs';
import {Injectable} from '@angular/core';
import {NGXLogger, NGXMapperService, NGXLoggerHttpService, LoggerConfig} from 'ngx-logger';
import {OAuthLogger, OAuthService, UrlHelperService} from 'angular-oauth2-oidc';

@Injectable()
class MockHttpClient {
  post(url: string, body: any | null, options?: any) {
    return of(QNA_Response);
  }
}

const QNA_Response = {
  "data": {
    "getQuestionnaireDetails": {
      "questionRes": {
        "resourceType": "Questionnaire",
        "meta": {
          "tag": [
            {
              "code": "subset_id",
              "display": "~IQ6.01A_17056"
            },
            {
              "code": "uniqueId",
              "display": 370187
            },
            {
              "code": "latestSubsetId",
              "display": 370187
            },
            {
              "code": "subsetIdentifierId",
              "display": 1194665
            },
            {
              "code": "product_id",
              "display": "IQ-HC"
            },
            {
              "code": "version_id",
              "display": "RM21"
            },
            {
              "code": "subsetType",
              "display": "QNA"
            },
            {
              "code": "autoSave",
              "display": "false"
            }
          ],
          "lastUpdated": "2021-07-12T09:30:51.914Z"
        },
        "item": [
          {
            "linkId": "1913779|3410",
            "text": "Homebound status required ",
            "type": "group",
            "definition": true,
            "prefix": "YN",
            "item": [
              {
                "linkId": 3391813,
                "text": "Yes",
                "definition": false,
                "type": "boolean",
                "prefix": "Y"
              },
              {
                "linkId": 3391814,
                "text": "No",
                "definition": false,
                "type": "boolean",
                "prefix": "N"
              }
            ]
          }
        ]
      }
    }
  }
};

describe('QnaMedicalReviewService', () => {
  let service: QnaMedicalReviewService;
  let utils: GuidelinesUtils;
  let userAuthService: UserAuthService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule],
      providers: [{ provide: HttpClient, useClass: MockHttpClient },  GuidelinesUtils, OAuthService, OAuthService, UrlHelperService, OAuthLogger,
        NGXLogger, NGXMapperService, NGXLoggerHttpService, LoggerConfig, DatePipe]});
    service = TestBed.inject(QnaMedicalReviewService);
    utils = TestBed.inject(GuidelinesUtils);
    userAuthService = TestBed.inject(UserAuthService);
  });

  it('should be run getQNAForGuidelines ', () => {
    service.getQNAForGuidelines('~IQ6.01A_17056', 'RM21').subscribe((res) => {
      expect(res).toBeTruthy();
    });
  });

  it('should be run getNextQuestionId ', () => {
    const request = {
      "QuestionRequest":{
        "questionReq": {
          "resourceType": "QuestionnaireResponse",
          "questionnaire": 370187,
          "text": "<p>These criteria are appropriate for adults requiring intermittent home care services. The High-risk OB and Postpartum Newborn criteria may also be used for adolescents.&nbsp;Delivery of skilled services in the home requires the following:</p> <ul> <li>Patient is clinically stable without anticipation of their condition worsening or are enrolled in hospice or palliative care</li> <li>Medical practitioner orders or approved plan of care at least every 60 days</li> <li>Reasonable expectation for clinical or functional improvement or prevention of further decline</li> <li>PO fluid tolerated or nutritional route established (e.g., IV, enteral feeding tube)</li> <li>Home care agency can safely deliver the required care at home</li> <li>Home environment is safe, accessible, and can be modified to accommodate the home care plan</li> </ul> <p>In addition to the above, the following conditions should also be met if the patient is receiving high technology services:</p> <ul> <li>Emergency medical services available</li> <li>Lab and pharmacy services available</li> <li>Supplies of fluid, medications, and home medical equipment</li> <li>Nursing specialization in chemotherapy and/or infusion therapy for home infusion therapy</li> </ul> <p>&nbsp;</p><br/><p><a href=\"https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals/Downloads/bp102c07.pdf\" target=\"_blank\" title=\"Center for Medicare &amp; Medicaid Services: Medicare Benefit Policy Manual, Chapter 7 – Home Health Services\">Center for Medicare &amp; Medicaid Services: Medicare Benefit Policy Manual, Chapter 7 – Home Health Services</a></p> <p>&nbsp;</p><br/><p>InterQual® content contains numerous references to gender. Depending on the context, these references may refer to either genotypic or phenotypic gender. At the individual patient level, a variety of factors, including but not limited to gender identity and gender reassignment via surgery or hormonal manipulation, may affect the applicability of some InterQual criteria. This is most often the case with genetic testing and procedures that assume the presence of gender-specific anatomy. With these considerations in mind, all references to gender in InterQual have been reviewed and modified when appropriate. InterQual users should carefully consider issues related to patient genotype and anatomy, especially for transgender individuals, when appropriate.</p><br/><p>InterQual® criteria are derived from the systematic, continuous review and critical appraisal of the most current evidence-based literature and include input from our independent panel of clinical experts. The content is based on a variety of references which are cited at specific criteria points throughout the subset.</p><br/>",
          "meta": {
            "tag": [{
              "code": "subset_id",
              "display": "~IQ6.01A_17056"
            }, {
              "code": "uniqueId",
              "display": 370187
            }, {
              "code": "latestSubsetId",
              "display": 370187
            }, {
              "code": "subsetIdentifierId",
              "display": 1194665
            }, {
              "code": "product_id",
              "display": "IQ-HC"
            }, {
              "code": "version_id",
              "display": "RM21"
            }, {
              "code": "subsetType",
              "display": "QNA"
            }, {
              "code": "autoSave",
              "display": "false"
            }],
            "lastUpdated": "2021-07-12T09:30:51.914Z"
          },
          "item": [{
            "answer": [{"valueString":"1"}],
            "linkId": "1913778|400"
          }]
        }
      }
    } as any;
    service.getNextQuestionId(request).subscribe((res) => {
      expect(res).toBeTruthy();
    });
  });

  it('should run getMedicalReviewDataFromIQ ', () => {
    service.getMedicalReviewDataFromIQ('bf042bee-46e7-4b85-b652-cc3041d5f6c9').then((res) => {
      expect(res).toBeTruthy();
    });
  });
});
