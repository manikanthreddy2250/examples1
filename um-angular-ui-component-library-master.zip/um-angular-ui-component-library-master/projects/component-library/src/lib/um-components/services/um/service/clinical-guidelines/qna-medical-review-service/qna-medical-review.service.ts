import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {map} from 'rxjs/operators';
import {QuestionChoices} from '../../../../../clinical-guidelines/shared/models/QuestionChoices';
import {QuestionnaireResponse} from '../../../../../clinical-guidelines/shared/models/QuestionnaireResponse';
import {MedicalReviewTreeService} from '../medical-review-tree/medical-review-tree.service';
import {MicroProductAuthService} from '@ecp/auth-library';
import {CommonConstants} from '../../../../../clinical-guidelines/shared/common-constants';
import {getEnvVar} from '../../../../environment/envVarUtil';
import {GUIDELINES_FUNCTION_URL} from '../../../../../../config/config-constants';
import {getMedicalReviewQuery, getNDTQuery, getNDTSelectionsQuery} from '../../graphql/medicalReviewGraphqlQuery';
import {GuidelinesUtils} from '../../../../../clinical-guidelines/shared/guidelines-utils';

@Injectable({
  providedIn: 'root'
})
export class QnaMedicalReviewService {

  refParams: any = {};
  age: number;
  refHeaderParams: any = {};
  private readonly staticParams: any = {'content-type': 'application/json'};
  hscData = []
  body1
  authToken = this.microProductAuthService.getEcpToken();
  headerValue = CommonConstants.CONTENT_TYPE;
  guidelinesUrl = 'https://dev-ecp-guidelines-function-app-79ec.azurewebsites.net/api/fhir/guidelines?code=JVe8UqS/LXXSvoY89isOryfkX/pnaQI/d8/PQMqyaykRXnFCh9QTzQ==';

  constructor(private readonly http: HttpClient, private readonly medicalReviewTreeService: MedicalReviewTreeService,
              private readonly microProductAuthService: MicroProductAuthService, private readonly utils: GuidelinesUtils, private readonly httpClient: HttpClient) {
    this.refHeaderParams = {'x-hasura-role': 'case_wf_mgmt_ui_system'};
    this.refParams = {headers: {...this.staticParams, ...this.refHeaderParams}};
  }
  getNextQuestionId(questionReq: QuestionnaireResponse): any {
    const QuestionRequest = {
      questionReq
    };
    const QnaNextQuestionQuery = {
      query: getNDTSelectionsQuery,
      variables: {
        QuestionRequest
      }
    };

    const headers = this.utils.getApiHeaders();
    return this.httpClient.post(getEnvVar(GUIDELINES_FUNCTION_URL), JSON.stringify(QnaNextQuestionQuery),
      { headers }).pipe(map((res: any) => res));
  }

  getQNAForGuidelines(subsetId, version): any {
    const GuidelineMedicalReviewInput = {
      subsetId,
      version
    };
    const QnaMedicalReviewQuery = {
      query: getNDTQuery,
      variables: {
        GuidelineMedicalReviewInput
      }
    };
    const headers = this.utils.getApiHeaders();
    console.log('headers are'  + JSON.stringify(headers));
    return this.httpClient.post(getEnvVar(GUIDELINES_FUNCTION_URL), JSON.stringify(QnaMedicalReviewQuery),
      { headers }).pipe(map((res: any) => res));
  }

  getMedicalReviewDataFromIQ(uuid): any{
    const GetMedicalReviewRequest = {
      uuid
    };
    const QnaMedicalReviewSummaryQuery = {
      query: getMedicalReviewQuery,
      variables: {
        GetMedicalReviewRequest
      }
    };
    const headers = this.utils.getApiHeaders();
    return this.httpClient.post(getEnvVar(GUIDELINES_FUNCTION_URL), JSON.stringify(QnaMedicalReviewSummaryQuery),
      { headers }).toPromise();
  }

}
