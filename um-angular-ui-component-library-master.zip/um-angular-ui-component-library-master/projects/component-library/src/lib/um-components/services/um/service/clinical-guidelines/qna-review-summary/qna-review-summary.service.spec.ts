import { TestBed } from '@angular/core/testing';

import { QnaReviewSummaryService } from './qna-review-summary.service';
import { Injectable, CUSTOM_ELEMENTS_SCHEMA,NO_ERRORS_SCHEMA } from '@angular/core';
import { MicroProductAuthService } from '@ecp/auth-library';

@Injectable()
class MicroProductAuthServiceStub {
getEcpClaims() {
  const ecpClaims = {
    "x-ecp-claims": {
      "x-ecp-attrs": {},
      "x-ecp-alt-user-id": "testUserId",
      "x-ecp-cli-orgs": [],
      "x-ecp-first-name": "FIRST",
      "x-ecp-type": "PASSWORD",
      "x-ecp-user-id": "123456789",
      "x-ecp-email": "abc123@optum.com",
      "x-ecp-last-name": "LAST",
      "x-ecp-source": "msid"
    },
    "https://hasura.io/jwt/claims": {},
    "scope": "openid",
    "iss": "ecp-dev",
    "exp": 1616403195,
    "client_id": "ecp_platform"
  }

  return ecpClaims
}

isLocalHost() {
  return false;
}
}
describe('ReviewSummaryQnaService', () => {
let service: QnaReviewSummaryService;

beforeEach(() => {
  TestBed.configureTestingModule({
    imports: [],
    schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
    providers: [QnaReviewSummaryService, {provide : MicroProductAuthService, useClass: MicroProductAuthServiceStub }],
  });
  service = TestBed.inject(QnaReviewSummaryService);
});

it('should be created', () => {
  expect(service).toBeTruthy();
});
it('should set QNA header for draft', () => {
  const qnaReview = {
    "resourceType": "QuestionnaireResponse",
    "id": 353955,
    "status": 2,
    "questionnaire": 353955,
    "text": "<p>I/O Setting:&nbsp;Outpatient</p>",
    "meta": {
      "tag": [{
        "code": "subset_id",
        "display": "ISP5728"
      }, {
        "code": "product_id",
        "display": "2021-03-17T08:48:03-05:00"
      }, {
        "code": "version_id",
        "display": "RM20"
      }, {
        "code": "subsetType",
        "display": "QNA"
      }, {
        "code": "reviewCreatedDate",
        "display": "2021-03-17T08:48:03-05:00"
      }, {
        "code": "lockedDate",
        "display": ''
      }, {
        "code": "reviewUserDescription",
        "display": "TestingUser1, TestingUser1"
      }, {
        "code": "review_user_facility",
        "display": "United Health Group"
      }, {
        "code": "ProductDescription",
        "display": "CP:Procedures"
      }, {
        "code": "subsetTypeDescription",
        "display": "Nerve Graft, Hand or Digit"
      }, {
        "code": "review_revision",
        "display": 1
      }, {
        "code": "review_version",
        "display": 3
      }, {
        "code": "source",
        "display": "MR"
      }, {
        "code": "autoSave",
        "display": "false"
      }],
      "lastUpdated": "2021-03-18T09:52:57.803Z"
    },
    "contained": [{
      "resourceType": "Parameters",
      "id": "availableRecommendations",
      "parameter": [],
      "contained": []
    }, {
      "resourceType": "Parameters",
      "id": "recommendations",
      "parameter": [{
        "name": "groupId",
        "valueString": "ZP285"
      }, {
        "name": "mutually_required",
        "valueBoolean": null
      }],
      "contained": [{
        "resourceType": "Parameters",
        "parameter": [{
          "name": "recommendationId",
          "valueString": "1050856"
        }, {
          "name": "description",
          "valueString": "Nerve Graft, Hand or Digit"
        }, {
          "name": "recommendation_indicators",
          "valueString": null
        }, {
          "name": "criteria_met",
          "valueString": "Criteria Not Met"
        }, {
          "name": "disposition_description",
          "valueString": "Evidence supports services as medically necessary."
        }]
      }]
    }, {
      "resourceType": "Parameters",
      "id": "comments",
      "parameter": []
    }],
    "item": []
  }
  service.setQnaHeaderForUUID(qnaReview)

  expect(service.setQnaHeaderForUUID).toBeTruthy();
});
it('should set QNA header for COMPLETED', () => {
  const qnaReview = {
    "resourceType": "QuestionnaireResponse",
    "id": 353955,
    "status": 6,
    "questionnaire": 353955,
    "text": "<p>I/O Setting:&nbsp;Outpatient</p>",
    "meta": {
      "tag": [],
      "lastUpdated": "2021-03-18T09:52:57.803Z"
    },
    "contained": [{
      "resourceType": "Parameters",
      "id": "availableRecommendations",
      "parameter": [],
      "contained": []
    }, {
      "resourceType": "Parameters",
      "id": "recommendations",
      "parameter": [],
      "contained": []
    }, {
      "resourceType": "Parameters",
      "id": "comments",
      "parameter": []
    }],
    "item": []
  }
  service.setQnaHeaderForUUID(qnaReview)

  expect(service.setQnaHeaderForUUID).toBeTruthy();
});

it('should be set Draft STATUS', () => {
  service.status = 'Draft'
  const reviewSaveRes = {
    "resourceType": "QuestionnaireResponse",
    "id": 353625,
    "meta": {
      "lastUpdated": "2021-03-15T04:19:45-05:00",
      "tag": []
    },
    "status": 2,
    "questionnaire": 353625,
    "item": [],
    "contained": [{
      "resourceType": "Parameters",
      "id": "lastUserAction",
      "parameter": []
    }, {
      "resourceType": "Parameters",
      "id": "comments",
      "parameter": []
    }],
  }
  service.setQnaHeaderForNewRewiew(reviewSaveRes)
  expect(service.setQnaHeaderForNewRewiew).toBeTruthy();
});

it('should be set Completed STATUS', () => {
  service.status = 'Completed'
  const reviewSaveRes = {
    "resourceType": "QuestionnaireResponse",
    "id": 353625,
    "meta": {
      "lastUpdated": "2021-03-15T04:19:45-05:00",
      "tag": []
    },
    "status": 6,
    "questionnaire": 353625,
    "item": [],
    "contained": [{
      "resourceType": "Parameters",
      "id": "lastUserAction",
      "parameter": []
    }, {
      "resourceType": "Parameters",
      "id": "comments",
      "parameter": []
    }],
  }
  service.setQnaHeaderForNewRewiew(reviewSaveRes)
  expect(service.setQnaHeaderForNewRewiew).toBeTruthy();
});

it('should be set Guideline Name', () => {
  const res = {
    "resourceType": "Questionnaire",
    "id": 355514,
    "version": "RM20",
    "name": "Sleep Studies (Pediatric)",
    "title": "CP:Procedures InterQual® 2020, Apr. 2020 Release",
    "status": "active",
    "publisher": "Change Helathcare",
    "text": "<p>I/O Setting:&nbsp;Outpatient</p><br/><p>These criteria include the following procedures:&nbsp;&nbsp;&nbsp;</p>",
    "meta": {
    "tag": [{
      "code": "subset_id",
      "display": "~IQ6.01A_6851"
    }, {
      "code": "uniqueId",
      "display": 355514
    }, {
      "code": "latestSubsetId",
      "display": 363140
    }, {
      "code": "subsetIdentifierId",
      "display": 1185026
    }, {
      "code": "product_id",
      "display": "PROCEDURES"
    }, {
      "code": "version_id",
      "display": "RM20"
    }, {
      "code": "subsetType",
      "display": "QNA"
    }]
  },
    "item": [{
    "linkId": "1771503|1",
    "text": "Choose one:",
    "type": "group",
    "definition": true,
    "prefix": "RADIO",
    "item": [{
      "linkId": 3155434,
      "text": "Age&nbsp;≥ 18",
      "definition": false,
      "type": "boolean",
      "prefix": "1"
    }, {
      "linkId": 3155435,
      "text": "Age&nbsp;&lt;&nbsp;18",
      "definition": false,
      "type": "boolean",
      "prefix": "2"
    }]
  }]
  }
  service.setQnaHeader(res)
  expect(service.setQnaHeader).toBeTruthy();
});

it('should get criteria status as Criteria Met', () => {
  service.setCriteriaStatus(true)
  expect(service.setCriteriaStatus).toBeTruthy()
});

it('should get criteria status as Criteria Not Met', () => {
  service.setCriteriaStatus(false)
  expect(service.setCriteriaStatus).toBeTruthy()
});

it(' should getUserName', () => {

  expect(service.getUserName()).toEqual('FIRST, LAST' );
});

it('saveReview  method', () => {
  const qnaReview = {}
  service.saveReview(qnaReview);
  expect(service.saveReview).toBeTruthy();
});

it('completeReview  method', () => {
  const qnaReview = {}
  service.completeReview(qnaReview);
  expect(service.completeReview).toBeTruthy();
});

});
