import { Injectable, Output, EventEmitter } from '@angular/core';
import { MicroProductAuthService } from '@ecp/auth-library';
import { QnaReview } from 'projects/component-library/src/lib/um-components/models/QnaReview';

@Injectable({
  providedIn: 'root'
})
export class QnaReviewSummaryService {

  createdBy: string
  createdDate: any
  status: string
  completedDate: any
  criteriaStatus: string
  criteriaProduct: string
  version: string
  criteriaSubset: string
  facility: string
  guidelineCategory: string
  criteriaVersion: string
  qnaReview: QnaReview
  @Output() invokeSave: EventEmitter<any> = new EventEmitter();
  @Output() invokeComplete: EventEmitter<any> = new EventEmitter();

  constructor(private readonly microProductAuthService: MicroProductAuthService) { }
  setQnaReview(qnaReview){
    this.qnaReview = qnaReview;
  }
 getQnaReview(){
   return this.qnaReview;
 }
  getSummaryValues() {
    const summaryValues = {
      createdBy: this.createdBy,
      createdDate: this.createdDate,
      reviewStatus: this.status,
      completedDate: this.completedDate,
      facility: this.facility,
      criteriaStatus: this.criteriaStatus,
      guidelineCategory: this.criteriaProduct,
      guidelineName: this.criteriaSubset,
      version: this.version,
    }
    return summaryValues
  }

  setQnaHeaderForUUID(qnaReview) {
    for (let k = 0; k < qnaReview.meta['tag'].length; k++) {
      if (qnaReview.meta['tag'][k].code === 'reviewUserDescription') {
        //this.createdBy = qnaReview.meta['tag'][k].display
        this.createdBy = this.getUserName()
      } else if (qnaReview.meta['tag'][k].code === 'review_user_facility') {
        this.facility = qnaReview.meta['tag'][k].display
      } else if (qnaReview.meta['tag'][k].code === 'lockedDate') {
        this.completedDate = qnaReview.meta['tag'][k].display
      } else if (qnaReview.meta['tag'][k].code === 'reviewCreatedDate') {
        this.createdDate = qnaReview.meta['tag'][k].display
      } else if (qnaReview.meta['tag'][k].code === 'ProductDescription') {
        this.criteriaProduct = qnaReview.meta['tag'][k].display
      } else if (qnaReview.meta['tag'][k].code === 'subsetTypeDescription') {
        this.criteriaSubset = qnaReview.meta['tag'][k].display
      }
    }
    this.settingStatus(qnaReview)
    this.setCriteriaMetVal(qnaReview)
    this.version = 'InterQual® 2020, Apr. 2020 Release'
  }

  settingStatus(qnaReview) {
    if (qnaReview.status === 2) {
      this.status = 'Draft'
    } else if (qnaReview.status === 6) {
      this.status = 'Completed'
    }
  }

  setCriteriaMetVal(qnaReview) {
    let contained = [];
    let recomendationContained = []
    contained = qnaReview['contained'];
    for (let k = 0; k < contained.length; k++) {
      if (contained[k].id === 'recommendations') {
        recomendationContained = contained[k].contained
        this.getParam(recomendationContained)
      }
    }
  }

  getParam(recomendationContained) {
    let recomendationParam = []
    if (recomendationContained && recomendationContained.length > 0) {
       recomendationParam = recomendationContained[0]['parameter'];
      if (recomendationParam && recomendationParam.length > 0) {
        for (let j = 0; j < recomendationParam.length; j++) {
          if (recomendationParam[j].name === 'criteria_met') {
            this.criteriaStatus = recomendationParam[j].valueString
          }
        }
      }
    }
  }

  setQnaHeader(response) {
    this.criteriaSubset = response.name
    console.log('criteriaSubset is ' + this.criteriaSubset)
    const title = response.title
    console.log('title is ' + title)
    this.criteriaProduct = title.substring(0, 13)
    console.log('criteriaProduct is ' + this.criteriaProduct)
    this.version = title.substring(14)
    console.log('version is ' + this.version)
    this.status = response.status
    console.log('status is ' + this.status)
    this.facility = 'United Health Group'
    this.createdDate = new Date()
    this.createdBy = this.getUserName()
  }

  setQnaHeaderForNewRewiew(reviewSaveRes) {
    if (reviewSaveRes.status === 2) {
      this.status = 'Draft'
    } else if (reviewSaveRes.status === 6) {
      this.status = 'Completed'
    }
    this.setCriteriaMetVal(reviewSaveRes)
  }


  setCriteriaStatus(value: Boolean) {
    switch (value) {
      case true:
        this.criteriaStatus = "Criteria Met";
        break
      case false:
        this.criteriaStatus = "Criteria Not Met";
        break
    }
  }

  getUserName() {
    if (this.microProductAuthService.isLocalHost()) { // to avoid adding a token in storage while working in local
      return 'SYSTEM'
    } else {
      const  EcpClaims= this.microProductAuthService.getEcpClaims()
      const FIRST_NAME = EcpClaims["x-ecp-claims"]["x-ecp-first-name"]
      const LAST_NAME = EcpClaims["x-ecp-claims"]["x-ecp-last-name"]
      return FIRST_NAME + ', ' + LAST_NAME
    }
  }

  saveReview(qnaReview){
    this.invokeSave.emit(qnaReview)

  }

  completeReview(qnaReview){
    this.invokeComplete.emit(qnaReview)
  }
}

