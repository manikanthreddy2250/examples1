import {TestBed} from '@angular/core/testing';
import {of} from 'rxjs';
import {CUSTOM_ELEMENTS_SCHEMA, Injectable, NO_ERRORS_SCHEMA} from '@angular/core';
import {SysConfigService} from './sys-config.service';
import {HttpClient, HttpHandler} from '@angular/common/http';
import {OAuthLogger, OAuthService, UrlHelperService} from 'angular-oauth2-oidc';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import {RouterTestingModule} from '@angular/router/testing';
import {LoggerConfig, NGXLogger, NGXLoggerHttpService, NGXMapperService} from 'ngx-logger';
import {DatePipe} from '@angular/common';

@Injectable()
class MockHttpClient {
  get(url: string, body: any | null, options?: any) {
    return of([
      {
        id: 'clinical_guidelines_1.0.0_ecp_authorization_type_2021-02-12',
        createDateTime: '2021-02-12T21:12:29.235+00:00',
        creatUserId: null,
        changeDateTime: '2021-02-12T21:12:29.235+00:00',
        changeUserId: null,
        updateVersionNumber: '0',
        createSystemReferenceId: null,
        changeSystemReferenceId: null,
        dataSecureRuleList: null,
        dataGltyIssList: null,
        application: 'clinical_guidelines',
        version: '1.0.0',
        org: 'ecp',
        role: null,
        key: 'authorization_type',
        value: '{"authorizationTypeRefIds":[20135, 20136, 20137, 20138]}',
        startDate: '2021-02-12T00:00:00.000+00:00',
        endDate: null,
        inactivityIndicator: '0'
      }
    ]);
  }
}

describe('SysConfigService', () => {
  let service: SysConfigService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      providers: [{provide: HttpClient, useClass: MockHttpClient }, OAuthService, UrlHelperService, OAuthLogger,
        NGXLogger, NGXMapperService, NGXLoggerHttpService, LoggerConfig, DatePipe],
    });
    service = TestBed.inject(SysConfigService);
  });

  it('should be created', () => {
     expect(service).toBeTruthy();
   });
});
