import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {getEnvVar} from '../../../../environment/envVarUtil';
import {GET_CONFIG_URL_PATH} from '../../../../../../config/config-constants';
import {GuidelinesUtils} from '../../../../../clinical-guidelines/shared/guidelines-utils';
import {GuidelinesConstants} from '../../../../../../constant/guidelines-constants';


@Injectable({
  providedIn: 'root'
})
export class SysConfigService {
  configUrl = getEnvVar(GET_CONFIG_URL_PATH);
  configHeaderParams: any = {};

  constructor(private readonly http: HttpClient, private readonly utils: GuidelinesUtils) {
  }

  public getClientConfigByKey(configKey: string): Promise<any>  {
    const httpOptions = {
      headers: this.utils.getApiHeaders()
    };
    return this.http.get(this.configUrl + GuidelinesConstants.APPLICATION + '/' + GuidelinesConstants.VERSION + '/' + configKey, httpOptions).toPromise();
  }

}
