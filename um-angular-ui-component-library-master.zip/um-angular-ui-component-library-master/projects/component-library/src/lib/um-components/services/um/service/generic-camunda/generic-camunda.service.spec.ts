import { Injectable } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import {HttpClient, HttpClientModule} from '@angular/common/http';
import { GenericCamundaService } from './generic-camunda.service';
import { of as observableOf } from 'rxjs';
import {AuthLibraryModule, MicroProductAuthService, AuthService} from "@ecp/auth-library";
import {UserAuthService} from "../../../auth/user.service";
import {HttpClientTestingModule} from "@angular/common/http/testing";
import { of } from 'rxjs';


@Injectable()
class MockHttpClient {
  get(url: string, body: any | null, options?: any) {
    return of({});
  }
  post(url: string, body: any | null, options?: any) {
    return of({});
  }
}

describe('GenericCamundaService', () => {
  let service: GenericCamundaService;
  let microProductAuthService: MicroProductAuthService;
  let userAuthService: UserAuthService;
  let authService: AuthService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports :[HttpClientModule,HttpClientTestingModule,AuthLibraryModule],
      providers: [
        { provide: HttpClient, useClass: MockHttpClient },
        UserAuthService
      ]});
    service = TestBed.inject(GenericCamundaService);
    authService = TestBed.inject(AuthService);
    microProductAuthService = TestBed.inject(MicroProductAuthService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should run #evaluateRule()', async () => {
    spyOn(service.httpClient, 'post').and.returnValue(observableOf({
      data: {
      }
    }));
    service.evaluateRule('test_rule', {}, "ecp");
    expect(service).toBeTruthy();
  });

  it('should run #evaluateMultipleRules()', async () => {
    service.evaluateMultipleRules('test_rule', {}, "ecp");
    expect(service.evaluateMultipleRules).toBeDefined();
  });

  it('should run #fetchTaskForAssignee()', async () => {
    service.fetchTaskForAssignee('test_rule');
    expect(service.fetchTaskForAssignee).toBeDefined();
  });

  it('should run #fetchSubTasksByTask()', async () => {
    service.fetchSubTasksByTask('test_rule');
    expect(service.fetchSubTasksByTask).toBeDefined();
  });

  it('should run #fetchCaseInstanceVariables()', async () => {
    service.fetchCaseInstanceVariables('test_rule');
    expect(service.fetchCaseInstanceVariables).toBeDefined();
  });

  it('should called getApiHeaders', () => {
    const spy = spyOn(microProductAuthService, 'getAltUserID').and.returnValue('testid');
    spyOn(authService, 'getActiveLoginClientRole').and.returnValue(['ecp','sys_admin']);
    spyOn(microProductAuthService, 'getHasuraRole').and.returnValue('hasura');
    spyOn(microProductAuthService, 'getEcpToken').and.returnValue('token');
    spyOn(microProductAuthService, 'getUserID').and.returnValue('001373415');
    service.getRuleHttpHeaders('case_wf_ui');
    expect(service.getRuleHttpHeaders).toBeDefined();
  });

  it('should called getApiHeaders', () => {
    const spy = spyOn(microProductAuthService, 'getAltUserID').and.returnValue('testid');
    spyOn(authService, 'getActiveLoginClientRole').and.returnValue(['ecp','sys_admin']);
    spyOn(microProductAuthService, 'getHasuraRole').and.returnValue('hasura');
    spyOn(microProductAuthService, 'getEcpToken').and.returnValue('token');
    spyOn(microProductAuthService, 'getUserID').and.returnValue('001373415');
    service.getWorkFlowHttpHeaders();
    expect(service.getWorkFlowHttpHeaders).toBeDefined();
  });

});
