import {Injectable} from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { take } from 'rxjs/operators';
import {RulesConstants} from '../../../../../config/rule-constants';
import {UserAuthService} from '../../../auth/user.service';
import {WorkFlowConstants} from '../../../../../config/workflow-constants';
import {getEnvVar} from '../../../environment/envVarUtil';
import {
  CASE_MANAGEMENT_BPM_SERVICE_URL,
  UM_RULES_SERVICE_URL
} from '../../../../../config/config-constants';
import {MicroProductAuthService} from "@ecp/auth-library";

@Injectable({
  providedIn: 'root'
})
export class GenericCamundaService {

  constructor(private readonly userAuthService: UserAuthService,
              readonly httpClient: HttpClient,
              private microProductAuth: MicroProductAuthService) {}

  evaluateRule(dmnKey: string, reqBody: any, appName: string): Observable<any> {
    const httpOptions = this.getRuleHttpHeaders(appName);
    const envUrl = getEnvVar(UM_RULES_SERVICE_URL);

    const url = `${envUrl}/dmn/${dmnKey}/evaluate`;
    return this.httpClient.post(url, reqBody, httpOptions).pipe(take(1));
  }

  evaluateMultipleRules(dmnKey: string, reqBody: any, appName: string): Observable<any> {
    const httpOptions = this.getRuleHttpHeaders(appName);
    const envUrl = getEnvVar(UM_RULES_SERVICE_URL);

    const url = `${envUrl}/dmn/${dmnKey}/evaluatelist`;
    //TODO: Call not liking func-role
    return this.httpClient.post(url, reqBody, httpOptions).pipe(take(1));
  }

  getRuleHttpHeaders(appName) {
    let tenantId = ''
    if(this.userAuthService.getActiveClientOrg() == "ecp"){
      tenantId = this.userAuthService.getActiveClientOrg() + RulesConstants.BPM_APP_NAME + "base" + RulesConstants.BPM_RULE;
    } else {
      tenantId = this.userAuthService.getActiveClientOrg() + RulesConstants.BPM_APP_NAME + this.userAuthService.getActiveClientOrg() + RulesConstants.BPM_RULE;
    }
    return {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'x-bpm-cli-org-id': this.userAuthService.getActiveClientOrg(),
        'x-bpm-func-role': this.userAuthService.getActiveUserRole(),
        'x-bpm-tenant-id': tenantId,
        'x-bpm-external-ref-id': RulesConstants.X_BPM_EXTERNAL_REF_ID,
        'x-bpm-source': appName,
        'Authorization': 'Bearer ' + this.microProductAuth.getEcpToken()
      })
    };
  }

  getWorkFlowHttpHeaders() {
    let tenantId = ''
    if(this.userAuthService.getActiveClientOrg() == "ecp"){
      tenantId = this.userAuthService.getActiveClientOrg() + RulesConstants.BPM_APP_NAME + "base" + WorkFlowConstants.BPM_PROCESS;
    } else {
      tenantId = this.userAuthService.getActiveClientOrg() + RulesConstants.BPM_APP_NAME + this.userAuthService.getActiveClientOrg() + WorkFlowConstants.BPM_PROCESS;
    }
    return {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'x-bpm-cli-org-id': this.userAuthService.getActiveClientOrg(),
        'x-bpm-func-role': this.userAuthService.getActiveUserRole(),
        'x-bpm-tenant-id': tenantId,
        'x-bpm-external-ref-id': WorkFlowConstants.X_BPM_EXTERNAL_REF_ID,
        'Authorization': 'Bearer ' + this.microProductAuth.getEcpToken()
      })
    };
  }

  fetchTaskForAssignee(assignee: string): Observable<any> {
    const httpOptions = this.getWorkFlowHttpHeaders();
    const envUrl = getEnvVar(CASE_MANAGEMENT_BPM_SERVICE_URL);
    const url = `${envUrl}/engine-rest/task?assignee=${assignee}`;
    return this.httpClient.get(url, httpOptions).pipe(take(1));
  }

  fetchSubTasksByTask(taskId: string) {
    const httpOptions = this.getWorkFlowHttpHeaders();
    const envUrl = getEnvVar(CASE_MANAGEMENT_BPM_SERVICE_URL);
    const url = `${envUrl}/workqueue/case/${taskId}`;
    return this.httpClient.get(url, httpOptions).pipe(take(1));
  }

  fetchCaseInstanceVariables(instanceId: string) {
    const httpOptions = this.getWorkFlowHttpHeaders();
    const envUrl = getEnvVar(CASE_MANAGEMENT_BPM_SERVICE_URL);
    const url = `${envUrl}/engine-rest/case-instance/${instanceId}/variables`;
    return this.httpClient.get(url, httpOptions).pipe(take(1));
  }

  sentRequestClinicalSignal( reqBody: any): Observable<any> {
    const httpOptions = this.getWorkFlowHttpHeaders();
    const envUrl = getEnvVar(CASE_MANAGEMENT_BPM_SERVICE_URL);
    const url = `${envUrl}/engine-rest/signal`;
    return this.httpClient.post(url, reqBody, httpOptions);
  }
}
