export const getMyTasksDetailsQuery = `query getTaskListByHscId($taskListRequest: TaskListRequest!) {
  getTaskListByHscId(taskListRequest: $taskListRequest) {
    hsr_asgn{
      hsc_id
      hsr_asgn_id
      asgn_to_user_id
      src_rec_guid
      asgn_typ_ref_id
      asgn_typ_ref_cd
      asgn_sts_ref_id
      asgn_sts_ref_cd
      asgn_catgy_ref_id
      asgn_catgy_ref_cd
      asgn_to_wrk_que_ref_id
      asgn_to_wrk_que_ref_cd
      hsc
      creat_dttm
    }
  }
}`;

export const getHscTaskDetailsQuery = `query getHscTaskDetails($getTaskDetailsRequest: GetTaskDetailsRequest!) {
getHscTaskDetails(getTaskDetailsRequest: $getTaskDetailsRequest) {
  task
}
}`;

export const getProviderListQuery = `query getProviderList($hscID : Int!){getProviderList(getProviderListRequest: {hscID:{hsc_id :$hscID}}) {
provList {
type
bus_nm
fst_nm
lst_nm
prov_id
telcom_adr_id
spcl_ref_dspl
spcl_ref_id
prov_role_ref_desc
provider_address
prov_catgy_ref_id
prov_catgy_ref_desc
providerTin
providerNpi
ntwk_sts_ref_id
    }
  }
}`

export const getProcedureCodeQuery = `query getProcedureCodeQuery($hsc_id: bigint!) {
    hsc_srvc(where: {hsc_id: {_eq: $hsc_id}, inac_ind: {_eq: "0"}}) {
    hsc_srvc_id
  hsc_id
  proc_cd
  proc_cd_schm_ref_id
  creat_dttm
  chg_dttm
}
}`;

export const getHscStatusQuery = `query getHscStatusQuery($hsc_id: bigint!) {
hsc(where: {hsc_id: {_eq: $hsc_id}}) {
  hsc_sts_ref_id
}
}`;

export const updateProcedureCodeQuery = `mutation updateProcedureCodeQuery($hsc_srvc_id: bigint!) {
update_hsc_srvc_by_pk(pk_columns: {hsc_srvc_id: $hsc_srvc_id}, _set: {inac_ind: 1}){
  hsc_srvc_id
}
}`;

export const delMutationHscSrvc = `
           mutation delMutation($hsc_srvc_id: bigint,$hsc_id: bigint) {
              delete_hsc_srvc(where: {hsc_id: {_eq: $hsc_id}, hsc_srvc_id: {_eq: $hsc_srvc_id}}) {
                affected_rows
                    returning {
                      hsc_srvc_id
                      proc_cd
                    }
                  }
                }
             `;

export const delMutationHscDiag = `
           mutation delMutation($diag_cd: String,$hsc_id: bigint) {
              delete_hsc_diag(where: {hsc_id: {_eq: $hsc_id}, diag_cd: {_eq: $diag_cd}}) {
                affected_rows
                    returning {
                      diag_cd
                    }
                  }
                }
             `;



export const getProcedureDescQuery = `query getProcedureDescQuery($proc_cd: String) {
    hcpcs(where: {proc_cd: {_eq: $proc_cd}}) {
  shrt_desc
  proc_cd
}
}`;

export const getProcedureCPTQuery = `query getProcedureDescQuery($proc_cd: String) {
    cpt4(where: {proc_cd: {_eq: $proc_cd}}) {
  shrt_desc
  proc_cd
}
}`;

export const getDiagnosisCodeQuery = `query getDiagnosisCodeQuery($hsc_id: bigint!) {
    hsc_diag (where: {hsc_id: {_eq: $hsc_id}}) {
  hsc_diag_id
  diag_cd
  pri_ind
  diagnosis {
    shrt_desc
  }
  creat_dttm
  chg_dttm
}
}`;

export const  getCaseHeaderDetailsQuery  = `query getCaseHeaderDetails($getCaseHeaderDetailsRequest: GetCaseHeaderDetailsRequest!) {
getCaseHeaderDetails(getCaseHeaderDetailsRequest: $getCaseHeaderDetailsRequest) {
srvc_set_ref_dspl
plsrv_ref_dspl
hsc_id
srvc_desc_ref_dspl
srvc_dtl_ref_dspl
admitDate
dischargeDate
primaryDiagnosis
tatDueDate
bus_nm
contractPaperTypeCode
addressLine
st_ref_cd
cov_eff_dt
cov_end_dt
planCode
indv_id
srvc_set_ref_id
hsc_sts_ref_dspl
srvc_strt_dt
srvc_end_dt
fst_nm
lst_nm
gdr_ref_dspl
gdr_ref_id
bth_dt
}
}`;


export const getRefDesc = `query refDesc($ref_id: Int!) {
ref(where: {ref_id: {_eq: $ref_id}}){
ref_desc
}
}`;


export const getDiagnosisDetailsQuery  = 'query ($search: String!) {\n' +
  '    icd10_search(args:{search: $search}) {\n' +
  '    cd_desc\n' +
  '    diag_cd\n' +
  '    full_desc\n' +
  '    shrt_desc\n' +
  ' } \n' +
  ' } \n';

export const getCommunicationsActivitiesQuery = `query getActivities($getActivitiesRequest: GetActivitiesRequest!) {
  getActivities(getActivitiesRequest: $getActivitiesRequest) {
    communication_activities{
      creat_user_id
      creat_dttm
      mbr_cmnct_chnl_ref_dspl
      mbr_cmnct_dir_ref_dspl
      mbr_cmnct_typ_ref_dspl
      mbr_cmnct_sts_ref_dspl
      mbr_cmnct_catgy_ref_dspl
    }
  }
}`;
