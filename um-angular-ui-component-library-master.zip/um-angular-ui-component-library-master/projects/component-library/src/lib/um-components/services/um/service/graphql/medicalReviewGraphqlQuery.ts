export const getNDTQuery = `
query getGuidelineReview($GuidelineMedicalReviewInput: GuidelineMedicalReviewInput!) {
    getGuidelineReview(GuidelineMedicalReviewInput: $GuidelineMedicalReviewInput) {
    reviewResponse
    }
    }`;
export const getMedicalReviewSummaryQuery = `
mutation getMedicalReviewGridDetails($GetMedicalReviewGridRequest: GetMedicalReviewGridRequest!) {
    getMedicalReviewGridDetails(GetMedicalReviewGridRequest: $GetMedicalReviewGridRequest) {
    medicalReviewGridDetailsRes
    }
    }`;
export const saveBedDayDecisionQuery =
    `mutation saveBedDay($BeddayRequest: BeddayRequest!) {
        saveBedDay(BeddayRequest: $BeddayRequest) {
        beddayRes
        }
        }`;
export const saveReviewQuery =
  `mutation saveReviewData($QuestionRequest: QuestionRequest!) {
    saveReviewData(QuestionRequest: $QuestionRequest) {
    questionRes
  }
}`;

export const completeReviewQuery =
  `mutation completeReview($QuestionRequest: QuestionRequest!) {
    completeReview(QuestionRequest: $QuestionRequest) {
    questionRes
  }
}`;

export const clinicalReviewEscalatedQuery =
  `query MyQuery($hsc_id:bigint!){
    hsc_clin_guid(where: {hsc_id: {_eq: $hsc_id}, clin_rev_sts_ref_id: {_eq: 72755}}, order_by: {creat_dttm: desc}, limit: 1) {
    hsc_clin_guid_id
    clin_rev_desc
    clin_rev_otcome_ref_id
    clin_rev_sys_rec_id
    clin_rev_sys_ref_id
    clin_rev_sts_ref_id
    clin_rev_sts_ref_cd {
        ref_desc
      }
    hsc_srvc_id
    med_nec_ind
    updt_ver_nbr
    }
  }`;

export const saveReviewToOCMDbQuery =
  `mutation saveMedicalReviewDetails($SaveMedicalReviewRequest: SaveMedicalReviewRequest!) {
    saveMedicalReviewDetails(SaveMedicalReviewRequest: $SaveMedicalReviewRequest) {
    data
}
}`;

export const getSubsetSearchQuery = `
query getSubsetSearch($GetSubsetSearchRequest: GetSubsetSearchRequest!) {
    getSubsetSearch(GetSubsetSearchRequest: $GetSubsetSearchRequest) {
    subsetSearchRes
    }
    }`;

export const getMedicalReviewQuery = `
  query getMedicalReviewDetails($GetMedicalReviewRequest: GetMedicalReviewRequest!) {
  getMedicalReviewDetails(GetMedicalReviewRequest: $GetMedicalReviewRequest) {
    reviewRes
  }
}`;
export const getNDTSelectionsQuery = `
mutation getQuestionnaireDetails($QuestionRequest: QuestionRequest!) {
    getQuestionnaireDetails(QuestionRequest: $QuestionRequest) {
    questionRes
    }
    }
     `;
export const getHscAuthDetails = `
  query getHscAuthDetails($getHscAuthRequest : GetHscAuthRequest! ){
      getHscAuthDetails(getHscAuthRequest : $getHscAuthRequest){
                                             hsc{
                                              hsc_id
                                              creat_dttm
                                              creat_user_id
                                              indv_id
                                              indv_key_typ_ref_id
                                              indv_key_val
                                              mbr_cov_dtl
                                              hsc_sts_ref_id
                                              flwup_cntc_dtl
                                              rev_prr_ref_id
                                              rev_prr_ref_cd{
                                                ref_id
                                                ref_cd
                                                ref_desc
                                                ref_dspl
                                              }
                                              srvc_set_ref_id
                                              srvc_set_ref_cd{
                                                ref_id
                                                ref_cd
                                                ref_desc
                                                ref_dspl
                                              }
                                              hsc_keys{
                                                hsc_id
                                                hsc_key_val
                                                hsc_key_typ_ref_id
                                              }
                                              hsc_srvcs{
                                                hsc_id
                                                hsc_srvc_id
                                                inac_ind
                                                proc_cd
                                                proc_cd_schm_ref_id
                                                proc_othr_txt
                                                srvc_hsc_prov_id
                                                hsc_srvc_non_facls{
                                                  proc_unit_cnt
                                                  init_trt_dt
                                                  plsrv_ref_id
                                                  plsrv_ref_cd{
                                                    ref_id
                                                    ref_cd
                                                    ref_desc
                                                    ref_dspl
                                                  }
                                                  proc_freq_ref_id
                                                  proc_freq_ref_cd{
                                                    ref_id
                                                    ref_cd
                                                    ref_desc
                                                    ref_dspl
                                                  }
                                                  proc_mod_1_cd
                                                  proc_mod_2_cd
                                                  proc_mod_3_cd
                                                  proc_mod_4_cd
                                                  proc_unit_cnt
                                                  proc_uom_ref_id
                                                  proc_uom_ref_cd{
                                                    ref_id
                                                    ref_cd
                                                    ref_desc
                                                    ref_dspl
                                                  }
                                                  srvc_desc_ref_id
                                                  srvc_desc_ref_cd{
                                                    ref_id
                                                    ref_cd
                                                    ref_desc
                                                    ref_dspl
                                                  }
                                                  srvc_dtl_ref_id
                                                  srvc_dtl_ref_cd{
                                                    ref_id
                                                    ref_cd
                                                    ref_desc
                                                    ref_dspl
                                                  }
                                                  srvc_end_dt
                                                  srvc_strt_dt
                                                  unit_per_freq_cnt
                                                  hsc_srvc_non_facl_dmes{
                                                    clin_ill_desc_txt
                                                    dme_procrmnt_typ_id
                                                    dme_tot_cst_amt
                                                    ental_fd_sngl_src_nutritn_ind
                                                    fml_nm_txt
                                                    med_cond_txt
                                                    spl_desc_txt
                                                    srvc_desc_txt
                                                  }
                                                }
                                              }
                                              hsc_facls{
                                                actul_admis_dttm
                                                actul_dschrg_dttm
                                                expt_admis_dt
                                                expt_dschrg_dt
                                                plsrv_ref_id
                                                plsrv_ref_cd{
                                                    ref_id
                                                    ref_cd
                                                    ref_desc
                                                    ref_dspl
                                                  }
                                                srvc_desc_ref_id
                                                srvc_desc_ref_cd{
                                                    ref_id
                                                    ref_cd
                                                    ref_desc
                                                    ref_dspl
                                                  }
                                                srvc_dtl_ref_id
                                                srvc_dtl_ref_cd{
                                                    ref_id
                                                    ref_cd
                                                    ref_desc
                                                    ref_dspl
                                                  }
                                              }
                                              hsc_diags{
                                                hsc_diag_id
                                                diag_cd
                                                inac_ind
                                                diag_desc
                                              }
                                              hsr_notes{
                                                hsr_note_id
                                                note_titl_txt
                                                note_txt_lobj
                                                creat_user_id
                                                note_typ_ref_id
                                                src_user_nm
                                                creat_dttm
                                              }
                                              hsc_provs{
                                                auto_aprv_ltr_ind
                                                hsc_prov_id
                                                chg_sys_ref_id
                                                chg_user_id
                                                creat_sys_ref_id
                                                creat_user_id
                                                data_qlty_iss_list
                                                data_secur_rule_list
                                                end_dt
                                                hsc_prov_end_rsn_ref_id
                                                ltr_opt_out_cc_ind
                                                med_rec_nbr
                                                ntwk_strg_rsn_ref_id
                                                ntwk_sts_ref_id
                                                prov_loc_affil_dtl
                                                prov_loc_affil_id
                                                spcl_ref_id
                                                strt_dt
                                                telcom_adr_id
                                                updt_ver_nbr
                                                hsc_prov_roles{
                                                  hsc_prov_id
                                                  prov_role_ref_id
                                                }
                                              }
                                            }
        }
      }`;

export const getNotesQuery = `
  query getNotesData($GetNotesRequest: GetNotesRequest!) {
    getNotesData(GetNotesRequest: $GetNotesRequest) {
    notesRes
    }
    }`;

export const getCitationQuery = `
query getCitationInfo($CitationFhirInput: CitationFhirInput!) {
  getCitationInfo(CitationFhirInput: $CitationFhirInput) {
  citationResponse
  }
  }`;

export const getAccmulatedBedDayQuery =
  `query MyQuery ($hsc_id:bigint!){
     hsc_decn_aggregate(where: {hsc_id: {_eq: $hsc_id}}) {
      aggregate {
      sum {
        decn_bed_day_cnt
          }
        }
      }
    }`;

export const clinicalReviewDescriptionQuery =
  `query MyQuery ($hsc_clin_guid_id:bigint!){
     hsc_clin_guid(where: {hsc_clin_guid_id: {_eq: $hsc_clin_guid_id}}) {
     clin_rev_desc
     creat_user_id
     chg_dttm
      }
    }`;

export const saveBeddayNotes =
  `mutation saveBedDayNotes($SaveBedDayNotesRequest: SaveBedDayNotesRequest!) {
   saveBedDayNotes(SaveBedDayNotesRequest: $SaveBedDayNotesRequest) {
    data
  }
}`;
export const getBedDayNotes =
`mutation getBedDayNotes($SaveBedDayNotesRequest: SaveBedDayNotesRequest!) {
  getBedDayNotes(SaveBedDayNotesRequest: $SaveBedDayNotesRequest) {
    data
  }
}`;

export const getEmrDataQuery =
`query getEhrData($GetAutoReviewEHRDataRequest: GetAutoReviewEHRDataRequest!) {
  getEhrData(GetAutoReviewEHRDataRequest: $GetAutoReviewEHRDataRequest) {
  emrdataresponse
  }
  }`;

  export const getSmartSheetQuesQuery = `
  query getSmartSheetQuestion($GetSmartSheetQuestionRequest: GetSmartSheetQuestionRequest!) {
    getSmartSheetQuestion(GetSmartSheetQuestionRequest: $GetSmartSheetQuestionRequest) {
      smartSheetQuestionRes
    }
  }`;

  export const getSmartSheetSubsetQuery = `
query getSmartSheet($GetSmartSheetRequest: GetSmartSheetRequest!) {
getSmartSheet(GetSmartSheetRequest: $GetSmartSheetRequest) {
  smartSheetRes
    }
  }`;

