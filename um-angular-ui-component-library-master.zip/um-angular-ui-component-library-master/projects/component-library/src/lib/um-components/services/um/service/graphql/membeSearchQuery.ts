export const getMemberShipDtlsQuery = `query getMemberShipQuery($mbr_cov_id: bigint) {
    mbr_cov(where: {mbr_cov_id: {_eq: $mbr_cov_id}}) {
      clm_pltfm_ref_id
      cov_eff_dt
      cov_end_dt
      cov_lvl_ref_id
      cov_typ_ref_id
      data_secur_rule_list
      elig_sys_ref_id
      lob_ref_id
      oblig_id
      oblig_ref_id
      orig_sys_cd
      orig_sys_mbr_id
      pol_iss_st_ref_id
      pol_nbr
      pol_nm
      pop_grp_nbr
      prdct_catgy_ref_id
      shr_arng_id
      shr_arng_ref_id
      site_of_srvc_elig_ref_id
      src_mbrshp_guid
      src_rec_guid
      src_rec_nd_nm
    }
  }`;

export const getIndividualSearchQuery = `query getMemberDetailsQuery($indv_key_val: String) {
    v_indv_srch(where: {indv_key_val: {_eq: $indv_key_val}}) {
      adr_ln_1_txt
      adr_ln_2_txt
      bth_dt
      cty_nm
      fst_nm
      gdr_ref_id
      indv_id
      indv_key_typ_ref_id
      indv_key_val
      lst_nm
      st_ref_id
      tel_nbr
      zip_cd_txt
    }
  }`;

export const getRefDescQuery = `query RefSmartSearch($ref_id: Int!) {
    ref(where: {ref_id: {_eq: $ref_id}}) {
      bas_ref_nm
      ref_desc
      ref_dspl
    }
  }`;
