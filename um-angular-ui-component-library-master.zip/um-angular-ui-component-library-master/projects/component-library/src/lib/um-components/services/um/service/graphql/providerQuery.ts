export const getProvidersQuery = `query getHscProvider($hscId: bigint!) {
  hsc(where: {hsc_id: {_eq: $hscId}}) {
    hsc_provs {
      hsc_prov_id
      hsc_prov_roles {
        prov_role_ref_id
        prov_role_ref_cd{
          ref_dspl
        }
      }
      prov_key_typ_ref_id
      prov_key_typ_ref_cd{
        ref_dspl
      }
      prov_key_val
      spcl_ref_id
      telcom_adr_id
      spcl_ref_cd {
        ref_dspl
      }
      prov_loc_affil_dtl
    }
  }
}`;

export const getUserFavoriteQuery = `query getUserFavorites($userId: String,$favoriteTypeId: Int  ) {
                                              user_fav(where: {user_id: {_eq: $userId}, user_fav_typ_ref_id: {_eq: $favoriteTypeId}}) {
                                              user_fav_val
                                              }
                                              }`;


export const getProviderDetailsByAdrIdQuery = `query getProviderDetailsByAdrId($provAdrId: [bigint!]){
      v_prov_srch(where: {prov_adr_id: {_is_null: false, _in: $provAdrId}, prov_key_typ_ref_id: {_in: [16333,2782]}}, distinct_on: [prov_key_val,prov_id]) {
        prov_key_val
        prov_id
        prov_adr_id
        telcom_adr_id
        prov_catgy_ref_id
        prov_catgy_ref_cd{
          ref_dspl
          ref_desc
        }
        prov_key_typ_ref_id
        prov_key_typ_ref_cd{
          ref_dspl
        }
        bus_nm
        fst_nm
        lst_nm
        adr_ln_1_txt
        adr_ln_2_txt
        st_ref_id
        st_ref_cd{
          ref_dspl
        }
        cty_nm
        zip_cd_txt
        spcl_ref_id
        spcl_ref_cd{
            ref_dspl
        }
      }
  }`;

export const saveFavoriteQuery = `mutation saveFavMutation($userId: String,$favoriteTypeId: Int,$userFavVal: String  )  {
            insert_user_fav(objects: {user_fav_val: $userFavVal, user_id: $userId, user_fav_typ_ref_id: $favoriteTypeId}) {
              returning {
                user_fav_id
              }
            }
          }`;

export const deleteFavoriteQuery = `mutation deleteFavMutation($userId: String,$favoriteTypeId: Int,$userFavVal: String){
                                      delete_user_fav(where: {user_id: {_eq: $userId},user_fav_val: {_eq: $userFavVal},user_fav_typ_ref_id: {_eq: $favoriteTypeId}}){
                                      returning {
                                          user_id
                                      }
                                      }
                                  }`;

export const updateHscMutation = `mutation updateHsc($updateHscRequest : UpdateHscRequest! ){
     updateHsc(updateHscRequest : $updateHscRequest){
                                                hsc{
                                                hsc_id
                                                  hsc_srvcs{
                                                    hsc_srvc_id
                                                    proc_cd
                                                    proc_othr_txt
                                                    proc_cd_schm_ref_id
                                                    inac_ind
                                                    srvc_hsc_prov_id
                                                  }
                                              }
}
}`;

export const getHscDetailsQuery = `query getHscAuthDetails($getHscAuthRequest : GetHscAuthRequest! ){
     getHscAuthDetails(getHscAuthRequest : $getHscAuthRequest){
                                               hsc{
                                                hsc_id
                                                hsc_srvcs{
                                                  hsc_id
                                                  creat_dttm
                                                  chg_dttm
                                                  hsc_srvc_id
                                                  inac_ind
                                                  proc_cd
                                                  proc_cd_schm_ref_id
                                                  proc_othr_txt
                                                  srvc_hsc_prov_id
                                                  hsc_srvc_non_facls{
                                                    proc_unit_cnt
                                                    init_trt_dt
                                                    plsrv_ref_id
                                                    plsrv_ref_cd{
                                                      ref_id
                                                      ref_cd
                                                      ref_desc
                                                      ref_dspl
                                                    }
                                                    proc_freq_ref_id
                                                    proc_freq_ref_cd{
                                                      ref_id
                                                      ref_cd
                                                      ref_desc
                                                      ref_dspl
                                                    }
                                                    proc_mod_1_cd
                                                    proc_mod_2_cd
                                                    proc_mod_3_cd
                                                    proc_mod_4_cd
                                                    proc_unit_cnt
                                                    proc_uom_ref_id
                                                    proc_uom_ref_cd{
                                                      ref_id
                                                      ref_cd
                                                      ref_desc
                                                      ref_dspl
                                                    }
                                                    srvc_desc_ref_id
                                                    srvc_desc_ref_cd{
                                                      ref_id
                                                      ref_cd
                                                      ref_desc
                                                      ref_dspl
                                                    }
                                                    srvc_dtl_ref_id
                                                    srvc_dtl_ref_cd{
                                                      ref_id
                                                      ref_cd
                                                      ref_desc
                                                      ref_dspl
                                                    }
                                                    srvc_end_dt
                                                    srvc_strt_dt
                                                    unit_per_freq_cnt
                                                    hsc_srvc_non_facl_dmes{
                                                      clin_ill_desc_txt
                                                      dme_procrmnt_typ_id
                                                      dme_tot_cst_amt
                                                      ental_fd_sngl_src_nutritn_ind
                                                      fml_nm_txt
                                                      med_cond_txt
                                                      spl_desc_txt
                                                      srvc_desc_txt
                                                    }
                                                  }
                                                }
                                              }
}                                            
}`;

export const getProvDetailByTaxIds = `query TaxIdSearch($provTaxIdArray: [String!]) {
                                      v_prov_srch(where: {prov_key_val: {_in: $provTaxIdArray}, prov_key_typ_ref_id: {_eq: 16333}, prov_adr_id: {_is_null: false}},distinct_on: [prov_id,prov_adr_id]) {
                                        prov_key_val
                                        prov_id
                                        prov_adr_id
                                        telcom_adr_id
                                        prov_catgy_ref_id
                                        prov_catgy_ref_cd{
                                          ref_dspl
                                          ref_desc
                                        }
                                        prov_key_typ_ref_id
                                        prov_key_typ_ref_cd{
                                          ref_dspl
                                        }
                                        bus_nm
                                        fst_nm
                                        lst_nm
                                        adr_ln_1_txt
                                        adr_ln_2_txt
                                        st_ref_id
                                        st_ref_cd{
                                          ref_dspl
                                        }
                                        cty_nm
                                        zip_cd_txt
                                        spcl_ref_id
                                        spcl_ref_cd{
                                            ref_dspl
                                        }
                                       }
                                      }`;

export const getPhysiciansBySearchParams = `query getPhysicians($address: String, $providerKeyVal : String, $providerKeyTypRefId: Int, $speciality: String, $zip: String, $fName: String, $lName: String) {
v_prov_srch(where: {adr_ln_1_txt: {_ilike: $address}, adr_ln_2_txt: {_ilike: $address}, prov_catgy_ref_id: {_eq: 16309}, prov_key_val: {_eq: $providerKeyVal}, prov_key_typ_ref_id: {_eq: $providerKeyTypRefId}, spcl_ref_cd: {ref_desc: {_ilike: $speciality}}, zip_cd_txt: {_ilike: $zip}, fst_nm: {_ilike: $fName}, lst_nm: {_ilike: $lName}}, distinct_on: prov_adr_id) {
  prov_key_val
  prov_id
  prov_adr_id
  telcom_adr_id
  prov_catgy_ref_id
  prov_catgy_ref_cd {
    ref_dspl
    ref_desc
  }
  prov_key_typ_ref_id
  prov_key_typ_ref_cd {
    ref_dspl
  }
  bus_nm
  fst_nm
  lst_nm
  adr_ln_1_txt
  adr_ln_2_txt
  st_ref_id
  st_ref_cd {
    ref_dspl
  }
  cty_nm
  zip_cd_txt
  spcl_ref_id
  spcl_ref_cd {
    ref_dspl
  }
}
}`;

export const getFacilitiesBySearchParams = `query getFacilities($address: String, $facilityName: String, $provKeyVal: String, $provKeyRefId: Int, $speciality: String, $zip: String) {
v_prov_srch(where: {adr_ln_1_txt: {_ilike: $address}, adr_ln_2_txt: {_ilike: $address}, bus_nm: {_ilike: $facilityName}, prov_catgy_ref_id: {_eq: 16310}, prov_key_val: {_eq: $provKeyVal},prov_key_typ_ref_id: {_eq: $provKeyRefId}, spcl_ref_cd: {ref_desc: {_ilike: $speciality}}, zip_cd_txt: {_ilike: $zip}}, distinct_on: prov_adr_id){
  prov_key_val
  prov_id
  prov_adr_id
  telcom_adr_id
  prov_catgy_ref_id
  prov_catgy_ref_cd{
    ref_dspl
    ref_desc
  }
  prov_key_typ_ref_id
  prov_key_typ_ref_cd {
    ref_dspl
  }
  bus_nm
  fst_nm
  lst_nm
  adr_ln_1_txt
  adr_ln_2_txt
  st_ref_id
  st_ref_cd {
    ref_dspl
  }
  cty_nm
  zip_cd_txt
  spcl_ref_id
  spcl_ref_cd {
      ref_dspl
  }
}
}`;
