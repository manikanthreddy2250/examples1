export const getRefDataByBaseRefNameQuery =  `query RefSmartSearch ( $bas_ref_nm:String ){
  ref: hsr_ref(where: {bas_ref_nm: {_eq: $bas_ref_nm}}){
  inac_ind
  ref_cd
  ref_desc
  ref_dspl
  ref_id
   }
  }`;

export const getRefChildDataByRefIDQuery = `query RefChildSearch ( $ref_id: Int!){
  ref_chld: hsr_ref_chld(where: {ref_id: {_eq: $ref_id}}){
  refSetByChldRefIdChldRefNm: hsr_ref_set{
  ref: hsr_ref{
  ref_desc
  ref_dspl
  ref_id
  }
  }
  }
  }`;

export const getRefDataByRefIDsQuery = `query RefIdSearch ( $ref_id: [Int!]!){
    hsr_ref(where: {ref_id: {_in: $ref_id}}){
      ref_id
      ref_cd
      ref_dspl
      ref_desc
    }
}`;


  export const getProcedureDetailsQuery = 'query procedureSmartSearchQuery($searchText: String!,$searchType: String!) {\n' +
  '    ProcedureSmartSearch(searchQuery: $searchText,searchType: $searchType) {\n' +
  '     code\n' +
  '    description\n' +
  '    displayText\n' +
  '    searchType\n' +
  ' } \n' +
  ' } \n';