
export const updateHscMutation =
    `mutation updateHsc($updateHscRequest: UpdateHscRequest!) {
        updateHsc(updateHscRequest: $updateHscRequest) {
        hsc{
          hsc_id
          hsc_decns {
            hsc_decn_id
            decn_otcome_ref_id
            chg_dttm
            hsc_decn_bed_days {
              hsc_decn_id
              strt_bed_dt
              hsc_clin_guid_id
            }
          }
          }
        }
        }`;
export const getUmAccmulatedBedDayQuery =
  `query MyQuery ($hsc_id:bigint!){
     hsc_decn_aggregate(where: {hsc_id: {_eq: $hsc_id}}) {
      aggregate {
      sum {
        decn_bed_day_cnt
          }
        }
      }
    }`;

export const umClinicalReviewDescriptionQuery =
      `query MyQuery ($hsc_id:bigint!){
         hsc_clin_guid(where: {hsc_id: {_eq: $hsc_id}}, order_by: {chg_dttm: desc}, limit: 1) {
         clin_rev_desc
         hsc_clin_guid_id
          }
        }`;


export const getUmBedDayNotes =
    `mutation getBedDayNotes($SaveBedDayNotesRequest: SaveBedDayNotesRequest!) {
      getBedDayNotes(SaveBedDayNotesRequest: $SaveBedDayNotesRequest) {
        data
      }
    }`;

export const getBedDayNotes = `
              query MyQuery ($note_sbj_rec_id:String!, $hsc_id:bigint!){
                        hsr_note_sbj(where: {note_sbj_rec_id: {_eq: $note_sbj_rec_id}, hsr_note: {hsc_id: {_eq: $hsc_id}}}, order_by: {chg_dttm: desc}, limit: 1) {
                          hsr_note_id
                           note_sbj_rec_id
                           hsr_note {
                             note_txt_lobj
                           }
                         }
                       }`;




