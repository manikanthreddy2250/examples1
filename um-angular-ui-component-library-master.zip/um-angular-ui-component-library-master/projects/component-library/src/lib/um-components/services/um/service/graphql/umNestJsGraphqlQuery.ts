export const getCaseTypeDetailsByHscIdQuery = `query getCaseTypeDetails($getCaseTypeDetailsRequest : HscInput! ){
    getCaseTypeDetails(getCaseTypeDetailsRequest :$getCaseTypeDetailsRequest){
    hsc_id
    hsc_sts_ref_id
    hsc_sts_ref_cd{
        ref_dspl
    }
    rev_prr_ref_id
    rev_prr_ref_cd {
        ref_id
      ref_dspl
    }
    srvc_set_ref_id
    srvc_set_ref_cd {
        ref_id
      ref_dspl
    }
    hsc_facls {
      plsrv_ref_id
      plsrv_ref_cd {
          ref_id
        ref_dspl
      }
      srvc_desc_ref_id
      srvc_desc_ref_cd {
          ref_id
        ref_dspl
      }
      srvc_dtl_ref_id
      srvc_dtl_ref_cd {
          ref_id
        ref_dspl
      }
      actul_admis_dttm
      actul_dschrg_dttm
      expt_admis_dt
      expt_dschrg_dt
    }
    hsc_srvcs{
        hsc_srvc_non_facls{
        plsrv_ref_id
        plsrv_ref_cd {
            ref_id
          ref_dspl
        }
        srvc_desc_ref_id
        srvc_desc_ref_cd {
            ref_id
          ref_dspl
        }
    }
    }
  }
}
`;

export const updateHscMutation = `mutation updateHsc($updateHscRequest: UpdateHscRequest!) {
  updateHsc(updateHscRequest: $updateHscRequest) {
    hsc {
      hsc_id
    }
  }
}
`;
