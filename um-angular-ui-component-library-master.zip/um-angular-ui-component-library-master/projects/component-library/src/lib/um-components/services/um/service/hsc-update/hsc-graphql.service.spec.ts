import { TestBed } from '@angular/core/testing';
import { HscGraphqlService } from './hsc-graphql.service';
import { Injectable } from '@angular/core';
import { of } from 'rxjs';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { AuthLibraryModule } from '@ecp/auth-library';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { UserAuthService } from '../../../../services/auth/user.service';



@Injectable()
class MockHttpClient {
  post(url: string, body: any | null, options?: any) {
    switch (url) {
      case 'https://dev-ecp-analytical-api.optum.com/paeta/api/eta':
        return of({data: {eta: 2}});
      default:
        return of({});
    }
  }
}

describe('HscGraphqlService', () => {
  let service: HscGraphqlService;
  let userAuthService: UserAuthService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, AuthLibraryModule],
      providers: [HttpHandler, { provide: HttpClient, useClass: MockHttpClient }]
    });
    service = TestBed.inject(HscGraphqlService);
  });

  it ('should be created', () => {
    expect(service).toBeTruthy();
  });

  it ('should call updateHsc()', () => {
    const appName = 'testApp';
    const hscRecord = {contacts: [{
        "department": "18677",
        "phone": "123-456-7890",
        "creat_user_id": "ecp_engineer",
        "fax": "323-555-1234",
        "email": "test@gmail.com",
        "role": "2575",
        "name": "MJ contact",
        "primaryContact": "1"
      }]};
    service.updateHsc(999123, hscRecord, appName);
    expect(service.updateHsc).toBeTruthy();
  });

});
