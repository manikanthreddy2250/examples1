import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {UserAuthService} from '../../../auth/user.service';
import {MicroProductAuthService} from '@ecp/auth-library';
import {UTILIZATION_MGMNT_FUNCS_URL} from '../../../../../config/config-constants';
import {RawQuery} from '@ecp/gql-tk';
import { getEnvVar } from '../../../environment/envVarUtil';
import {updateHscMutation} from "../graphql/providerQuery";

@Injectable({
  providedIn: 'root'
})
export class HscGraphqlService {

  constructor(private readonly httpClient: HttpClient, private userAuthService: UserAuthService, private microProductAuth: MicroProductAuthService) {
  }


  getApiHeaders(appName): HttpHeaders {
    return new HttpHeaders()
      .set('Content-Type', 'application/json')
      .set('x-hasura-role', this.userAuthService.getUserHasuraRole(appName))
      .set('x-bpm-cli-org-id', this.userAuthService.getActiveClientOrg())
      .set('x-bpm-func-role', this.userAuthService.getActiveUserRole())
      .set('Authorization', 'Bearer ' + this.microProductAuth.getEcpToken());
  }

  updateHsc(hscId: number, hscRecord: any, appName: string): Promise<any> {
    const getHscQuery = this.buildUpdateHscMutation(hscId, hscRecord);
    return this.httpClient.post(getEnvVar(UTILIZATION_MGMNT_FUNCS_URL), JSON.stringify(getHscQuery), {headers: this.getApiHeaders(appName)}).toPromise();
  }

  buildUpdateHscMutation(hscId: number, updateHscRequest: any): RawQuery {
    return {
      query: updateHscMutation,
      variables: updateHscRequest
    };
  }
}
