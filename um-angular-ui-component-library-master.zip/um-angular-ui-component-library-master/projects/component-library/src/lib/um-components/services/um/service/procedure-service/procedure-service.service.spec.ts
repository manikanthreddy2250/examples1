import { DatePipe } from '@angular/common';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import { UITKPageNotificationService } from '@uitk/angular';
import { ProcedureServiceService } from './procedure-service.service';
import {Injectable} from '@angular/core';
import {BehaviorSubject, Observable, of} from 'rxjs';

@Injectable()
class MockHttpClient {
  post(url: string, body: any | null, options?: any) {
    switch (url) {
      case 'https://dev-ecp-analytical-api.optum.com/paeta/api/eta':
        return of({eta: 2});
      default:
        return of({});
    }
  }
}

describe('ProcedureServiceService', () => {

  beforeEach(() => TestBed.configureTestingModule(
    { providers: [DatePipe, UITKPageNotificationService, HttpHandler, { provide: HttpClient, useClass: MockHttpClient }] }
  ));

  it('should be created', () => {
    const service: ProcedureServiceService = TestBed.get(ProcedureServiceService);
    expect(service).toBeTruthy();
  });


  it('should getServiceETA', () => {
    const service: ProcedureServiceService = TestBed.get(ProcedureServiceService);
    let record = {code: 1234,proc_cd_schm_ref_id: 234};
    service.getServiceETA(record);
    expect(service.getServiceETA).toBeDefined();
  });

});
