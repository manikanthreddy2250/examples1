import {HttpClient, HttpHeaders} from '@angular/common/http';
import { Injectable } from '@angular/core';
import {MicroProductAuthService} from "@ecp/auth-library";
import {Observable} from "rxjs";
import {SERVICE_ETA_URL_PATH} from "../../../../../config/config-constants";
import { getEnvVar } from '../../../environment/envVarUtil';
@Injectable({
  providedIn: 'root'
})
export class ProcedureServiceService {
  constructor(
    private microProductAuth: MicroProductAuthService, private readonly http: HttpClient){ }
  /*Returns the Service ETA (number of Days) */
 async getServiceETA(record): Promise<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Authorization': 'Bearer ' + this.microProductAuth.getEcpToken()
      })
    };
    const body = {
      DECN_SUB_TYP_ID : 'UNK',
      DECN_OTCOME_TYP_ID : 'UNK',
      SYS_CLM_RMRK_CD : 'UNK',
      DECN_MADE_BY_USER_DEPT_ID : 'UNK',
      RCIP_FAX_INTNTL_IND : 'UNK',
      DAYOFWEEK : 'UNK',
      PROC_CD : record.Code,
      PROC_TYP_ID : record.Type,
      SRVC_REV_TYP_ID : 'UNK',
      ST_CD : 'UNK',
      SPCL_TYP_ID : 'UNK',
      PROV_CATGY_TYP_ID : 'UNK',
      DIAG_CD : 'UNK',
      PRI_IND : '0',
      ADMIT_IND : 'UNK',
      COV_TYP_ID : 'UNK',
      FUND_ARNG_ID : 'UNK',
      MKT_NTWK_IND : 'UNK',
      PRDCT_CATGY_CD : 'UNK',
      CLM_PLTFM_ID : 'UNK',
      MED_NECESSITY_APPL_IND : 'UNK',
      LOB_TYP_ID : 'UNK',
      REV_PRR_TYP_ID : 'UNK',
      SPCL_PROC_TYP_ID : 'UNK',
      CORE_MED_REV_TYP_ID : 'UNK',
      SEC_SPCL_PROC_TYP_ID : 'UNK'
    };
   this.http.post(getEnvVar(SERVICE_ETA_URL_PATH), body, httpOptions).subscribe((data: any) => {
     if (data && data.eta) {
       record.ETA = data.eta + ' Days';
       return record
     }});

  }

}
