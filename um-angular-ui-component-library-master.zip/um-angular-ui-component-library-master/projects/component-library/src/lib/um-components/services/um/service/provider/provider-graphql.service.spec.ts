import { TestBed } from '@angular/core/testing';
import { ProviderGraphqlService } from './provider-graphql.service';
import { Injectable } from '@angular/core';
import { of } from 'rxjs';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { AuthLibraryModule } from '@ecp/auth-library';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { UserAuthService } from '../../../../services/auth/user.service';



@Injectable()
class MockHttpClient {
  post(url: string, body: any | null, options?: any) {
    switch (url) {
      case 'https://dev-ecp-analytical-api.optum.com/paeta/api/eta':
        return of({data: {eta: 2}});
      default:
        return of({});
    }
  }
}

describe('ProviderGraphqlService', () => {
  let service: ProviderGraphqlService;
  let userAuthService: UserAuthService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, AuthLibraryModule],
      providers: [HttpHandler, { provide: HttpClient, useClass: MockHttpClient }]
    });
    service = TestBed.inject(ProviderGraphqlService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });


  it('should call buildProviderData', () => {
    const provRecord = [{
      adr_ln_1_txt: "300 Flatbush Ave",
      adr_ln_2_txt: null,
      bus_nm: null,
      cty_nm: "Brooklyn",
      fst_nm: "CINTIA",
      lst_nm: "ROGUIN",
      prov_adr_id: 17788,
      prov_catgy_ref_cd: {ref_dspl: "HCP", ref_desc: "HealthCare Practitioner"},
      prov_catgy_ref_id: 16309,
      prov_id: 167070,
      prov_key_typ_ref_cd: {ref_dspl: "NPI"},
      prov_key_typ_ref_id: 2782,
      prov_key_val: "1255539573",
      spcl_ref_cd: {ref_dspl: "174400000X"},
      spcl_ref_id: 16536,
      st_ref_cd: {ref_dspl: "NEW YORK"},
      st_ref_id: 1101,
      telcom_adr_id: "7186222000",
      zip_cd_txt: "11217"
    }]
    const unqArray = ["17788"]
    service.buildProviderDataforFavs(provRecord, unqArray);
    expect(service.buildProviderDataforFavs).toHaveBeenCalled;
  })

  it('should call saveFavorite', () => {
    service.saveFavorite('0013660',12324, 2324,"unqArray");
    expect(service.saveFavorite).toHaveBeenCalled;
  })

  it('should call deleteFavorite', () => {
    service.deleteFavorite('0013660',12324, 2324,"unqArray");
    expect(service.deleteFavorite).toHaveBeenCalled;
  })

  it('should call getProviderDetailsByTaxIDs', () => {
    service.getProviderDetailsByTaxIDs(['0013660'],"unqArray");
    expect(service.getProviderDetailsByTaxIDs).toHaveBeenCalled;
  })

  it('should call buildProviderData', () => {
    const provRecord = [{
      adr_ln_1_txt: "300 Flatbush Ave",
      adr_ln_2_txt: null,
      bus_nm: null,
      cty_nm: "Brooklyn",
      fst_nm: "CINTIA",
      lst_nm: "ROGUIN",
      prov_adr_id: 17788,
      prov_catgy_ref_cd: {ref_dspl: "HCP", ref_desc: "HealthCare Practitioner"},
      prov_catgy_ref_id: 16309,
      prov_id: 167070,
      prov_key_typ_ref_cd: {ref_dspl: "NPI"},
      prov_key_typ_ref_id: 2782,
      prov_key_val: "1255539573",
      spcl_ref_cd: {ref_dspl: "174400000X"},
      spcl_ref_id: 16536,
      st_ref_cd: {ref_dspl: "NEW YORK"},
      st_ref_id: 1101,
      telcom_adr_id: "7186222000",
      zip_cd_txt: "11217"
    }]
    service.buildProviderData(provRecord);
    expect(service.buildProviderData).toHaveBeenCalled;
  })

  it('should call getPhysiciansBySearchParams', () => {
    service.getPhysiciansBySearchParams({firstName: 'test' }, 'unqArray');
    expect(service.getPhysiciansBySearchParams).toHaveBeenCalled;
  });

  it('should call getFacilitiesBySearchParams', () => {
    service.getFacilitiesBySearchParams({facilityName: 'test' }, 'unqArray');
    expect(service.getFacilitiesBySearchParams).toHaveBeenCalled;
  });

  it('should call buildPhysicianSearchQuery', () => {
    service.buildPhysicianSearchQuery({firstName: 'test' });
    expect(service.buildPhysicianSearchQuery).toHaveBeenCalled;
  });

  it('should call buildFacilitySearchQuery', () => {
    service.buildFacilitySearchQuery({facilityName: 'test' });
    expect(service.buildFacilitySearchQuery).toHaveBeenCalled;
  });

  it('should call deleteProvider', () => {
    service.deleteProvider(1234, {hsc_prov_id: 1234 }, 'unqArray');
    expect(service.deleteProvider).toHaveBeenCalled;
  });
});
