import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {UserAuthService} from '../../../auth/user.service';
import {MicroProductAuthService} from '@ecp/auth-library';
import {
  HEALTH_SERVICE_DOMAIN_URL_PATH,
  USER_ATTRIBUTES_URL_PATH,
  PROVIDER_SERVICE_DOMAIN_URL_PATH,
  UTILIZATION_MGMNT_FUNCS_URL,

} from '../../../../../config/config-constants';
import {RawQuery} from '@ecp/gql-tk';
import {
  getProvidersQuery, getUserFavoriteQuery, getProviderDetailsByAdrIdQuery, updateHscMutation,
  saveFavoriteQuery, deleteFavoriteQuery, getProvDetailByTaxIds,
  getPhysiciansBySearchParams, getFacilitiesBySearchParams
} from '../graphql/providerQuery';
import { getEnvVar } from '../../../environment/envVarUtil';
import { ProviderConstants } from '../../../../provider/provider.constants';


@Injectable({
  providedIn: 'root'
})
export class ProviderGraphqlService {

  constructor(private readonly httpClient: HttpClient,private userAuthService: UserAuthService,
              private microProductAuth: MicroProductAuthService) { }


  getApiHeaders(appName): HttpHeaders {
    return new HttpHeaders()
      .set('Content-Type', 'application/json')
      .set('x-hasura-role', this.userAuthService.getUserHasuraRole(appName))
      .set('x-bpm-cli-org-id', this.userAuthService.getActiveClientOrg())
      .set('x-bpm-func-role',  this.userAuthService.getActiveUserRole())
      .set('Authorization', 'Bearer ' + this.microProductAuth.getEcpToken());
  }

  getUserFavorites(favoriteTypeId,appName, userId): Promise<any> {
    const getUserFavoritesQuery = this.buildUserFavQuery(favoriteTypeId,userId);
    const userAttrUrl = getEnvVar(USER_ATTRIBUTES_URL_PATH);
    return this.httpClient.post(userAttrUrl, JSON.stringify(getUserFavoritesQuery), { headers: this.getApiHeaders(appName)}).toPromise();
  }

  buildUserFavQuery(favoriteTypeId : any,userId: any): RawQuery {
    return  {
      query: getUserFavoriteQuery,
      variables: {
        "userId": userId,
        "favoriteTypeId": favoriteTypeId
      }
    };
  }

  getProvDetailsByAdrId(provAdrId:any,appName:any){
    const getProvDetailsByAdrIdQuery = this.buildProvDetailsbyAdrQuery(provAdrId);
    const userAttrUrl = getEnvVar(PROVIDER_SERVICE_DOMAIN_URL_PATH);
    return this.httpClient.post(userAttrUrl, JSON.stringify(getProvDetailsByAdrIdQuery), { headers: this.getApiHeaders(appName)}).toPromise();
  }

  buildProvDetailsbyAdrQuery(provAdrId:any): RawQuery{
    return  {
      query: getProviderDetailsByAdrIdQuery,
      variables: {
        "provAdrId": provAdrId,
      }
    };
  }

  buildProviderDataforFavs(provData : any, uniqueAdrArray: any){
    const  providerResultData = [];
    let provider:any;
    uniqueAdrArray.forEach(prov_adr_id  => {
        let providerRecords =[]
        providerRecords = provData.filter(x => x.prov_adr_id == prov_adr_id);
        const tinRecord = providerRecords.find(x => x.prov_key_typ_ref_id === ProviderConstants.PROVIDER_KEY_VALUE_TYP_REF_ID_TIN);
        if(tinRecord){
          provider = tinRecord
        }
        else{
          provider = providerRecords.find(x => x.prov_key_typ_ref_id === ProviderConstants.PROVIDER_KEY_VALUE_TYP_REF_ID_NPI);
        }
        const provObj = this.buildProviderObject(provider);
        providerResultData.push(provObj);
      });

    providerResultData.forEach(item =>{ item.hsc_prov_roles = []});
    return providerResultData;
  }

  saveFavorite(userId:any,favoriteTypeId:any,userFavVal:any,appName:any){
  const saveFavoritesQuery = this.buildSaveFavQuery(userId,favoriteTypeId,userFavVal);
  const userAttrUrl = getEnvVar(USER_ATTRIBUTES_URL_PATH);
  return this.httpClient.post(userAttrUrl, JSON.stringify(saveFavoritesQuery), { headers: this.getApiHeaders(appName)}).toPromise();
  }

  saveProvider(hscId: number, providerRecord: any, providerRoleRefId: number, appName: string): Promise<any> {
    if( hscId && providerRecord && providerRoleRefId ){
        const getUserFavoritesQuery = this.buildSaveProviderMutation(hscId, providerRecord, providerRoleRefId);
        return this.httpClient.post(getEnvVar(UTILIZATION_MGMNT_FUNCS_URL), JSON.stringify(getUserFavoritesQuery), { headers: this.getApiHeaders(appName)}).toPromise();
    }
  }

  deleteProvider(hscId: number, providerRecord: any, appName: string): Promise<any> {
    if( hscId && providerRecord){
        const getUserFavoritesQuery = this.buildDeleteProviderMutation(hscId, providerRecord);
        return this.httpClient.post(getEnvVar(UTILIZATION_MGMNT_FUNCS_URL), JSON.stringify(getUserFavoritesQuery), { headers: this.getApiHeaders(appName)}).toPromise();
    }
  }

  buildSaveProviderMutation(hscId: number, providerRecord: any, providerRoleRefId: number): RawQuery {
    const providerInput: any = {};
    providerInput.hsc_prov_id = providerRecord.hsc_prov_id;
    if (providerRecord.hsc_prov_roles && providerRecord.hsc_prov_roles.length > 0){
      const hscProvRoles = providerRecord.hsc_prov_roles.map((role) => {
        return {prov_role_ref_id: role.prov_role_ref_id};
      });
      providerInput.hsc_prov_roles = hscProvRoles;
    }
    providerInput.fst_nm = providerRecord.fst_nm;
    providerInput.lst_nm = providerRecord.lst_nm;
    providerInput.bus_nm = providerRecord.bus_nm;
    providerInput.prov_keys = [{
      prov_key_typ_ref_id: providerRecord.prov_key_typ_ref_id,
      prov_key_val: providerRecord.prov_key_val
    }];
    providerInput.prov_adr = {
      adr_ln_1_txt: providerRecord.adr_ln_1_txt,
      adr_ln_2_txt: providerRecord.adr_ln_2_txt,
      cty_nm: providerRecord.cty_nm,
      zip_cd_txt: providerRecord.zip_cd_txt,
      st_ref_id: providerRecord.st_ref_id
    };
    return  {
      query: updateHscMutation,
      variables: {
        updateHscRequest: {
          hsc_id: hscId,
          hsc_provs: [providerInput]
        }
      }
    };
  }

  buildDeleteProviderMutation(hscId: number, providerRecord: any): RawQuery {
    const providerInput: any = {};
    providerInput.hsc_prov_id = providerRecord.hsc_prov_id;
    providerInput.delete_ind = 1;
    if (providerRecord.hsc_prov_roles && providerRecord.hsc_prov_roles.length > 0){
      const hscProvRoles = providerRecord.hsc_prov_roles.map((role) => {
        return {prov_role_ref_id: role.prov_role_ref_id};
      });
      providerInput.hsc_prov_roles = hscProvRoles;
    }
    providerInput.fst_nm = providerRecord.fst_nm;
    providerInput.lst_nm = providerRecord.lst_nm;
    providerInput.bus_nm = providerRecord.bus_nm;
    providerInput.prov_keys = [{
      prov_key_typ_ref_id: providerRecord.prov_key_typ_ref_id,
      prov_key_val: providerRecord.prov_key_val
    }];
    providerInput.prov_adr = {
      adr_ln_1_txt: providerRecord.adr_ln_1_txt,
      adr_ln_2_txt: providerRecord.adr_ln_2_txt,
      cty_nm: providerRecord.cty_nm,
      zip_cd_txt: providerRecord.zip_cd_txt,
      st_ref_id: providerRecord.st_ref_id
    };
    return  {
      query: updateHscMutation,
      variables: {
        updateHscRequest: {
          hsc_id: hscId,
          hsc_provs: [providerInput]
        }
      }
    };
  }

  buildSaveFavQuery(userId:any,favoriteTypeId:any,userFavVal:any): RawQuery{
    return  {
      query: saveFavoriteQuery,
      variables: {
        "userId": userId,
        "favoriteTypeId": favoriteTypeId,
        "userFavVal": userFavVal
      }
    };
  }

  deleteFavorite(userId:any,favoriteTypeId:any,userFavVal:any,appName:any){
    const deleteFavoritesQuery = this.buildDeleteFavQuery(userId,favoriteTypeId,userFavVal);
    const userAttrUrl = getEnvVar(USER_ATTRIBUTES_URL_PATH);
    return this.httpClient.post(userAttrUrl, JSON.stringify(deleteFavoritesQuery), { headers: this.getApiHeaders(appName)}).toPromise();
  }

  buildDeleteFavQuery(userId:any,favoriteTypeId:any,userFavVal:any): RawQuery{
    return  {
      query: deleteFavoriteQuery,
      variables: {
        "userId": userId,
        "favoriteTypeId": favoriteTypeId,
        "userFavVal": userFavVal
      }
    };
  }

  getProvDetailsByHscId(hscId:any,appName:any){
    const getProvDetailsQuery = this.buildGetHscDetailsQuery(parseInt(hscId));
    const hscUrl = getEnvVar(HEALTH_SERVICE_DOMAIN_URL_PATH);
    return this.httpClient.post(hscUrl, JSON.stringify(getProvDetailsQuery), { headers: this.getApiHeaders(appName)}).toPromise();
  }

  buildGetHscDetailsQuery(hscId:any): RawQuery{
    return  {
      query: getProvidersQuery,
      variables: {
        "hscId": hscId,
      }
    };
  }

  getProviderDetailsByTaxIDs(provTaxIdArray:any,appName:any):Promise<any>{
    const hscUrl = getEnvVar(HEALTH_SERVICE_DOMAIN_URL_PATH);
    const getDetailsByTaxIdQuery = {
      query: getProvDetailByTaxIds,
      variables: {
        provTaxIdArray
      }
    };
    return this.httpClient.post(hscUrl, JSON.stringify(getDetailsByTaxIdQuery), { headers: this.getApiHeaders(appName)}).toPromise();
  }

  buildProviderData(provData: any){
    const provDetailsArray = [];
    provData.forEach(element => {
      const provObj = this.buildProviderObject(element);
      provDetailsArray.push(provObj);
    });
    return provDetailsArray;
  }

  buildProviderObject(provRecord){
    const provObj = {
        prov_key_val: provRecord.prov_key_val,
        prov_key_typ_ref_id: provRecord.prov_key_typ_ref_id,
        prov_key_typ_ref_cd: provRecord.prov_key_typ_ref_cd,
        prov_catgy_ref_id: provRecord.prov_catgy_ref_id,
        prov_catgy_ref_cd: provRecord.prov_catgy_ref_cd,
        prov_id: provRecord.prov_id,
        prov_adr_id: provRecord.prov_adr_id,
        adr_ln_1_txt: provRecord.adr_ln_1_txt,
        adr_ln_2_txt: provRecord.adr_ln_2_txt,
        cty_nm: provRecord.cty_nm,
        zip_cd_txt: provRecord.zip_cd_txt,
        st_ref_id: provRecord.st_ref_id,
        st_ref_cd: provRecord.st_ref_cd,
        telcom_adr_id: provRecord.telcom_adr_id,
        spcl_ref_id: provRecord.spcl_ref_id,
        spcl_ref_cd: provRecord.spcl_ref_cd?provRecord.spcl_ref_cd:null,
        fst_nm: provRecord.fst_nm,
        lst_nm: provRecord.lst_nm,
        bus_nm: provRecord.bus_nm,
        ntwk_sts_ref_id: null,
        ntwk_sts_ref_cd: {ref_dspl : "In"},
        distance: 7
    }
    return provObj;
  }

  getPhysiciansBySearchParams(providerSearchFields: any, appName: any) {
    const getPhysiciansSearchQuery = this.buildPhysicianSearchQuery(providerSearchFields);
    const providerUrl = getEnvVar(PROVIDER_SERVICE_DOMAIN_URL_PATH);
    return this.httpClient.post(providerUrl, JSON.stringify(getPhysiciansSearchQuery), { headers: this.getApiHeaders(appName)}).toPromise();
  }

  buildPhysicianSearchQuery(providerSearchFields: any) {
    return  {
      query: getPhysiciansBySearchParams,
      variables: {
        "address": providerSearchFields.address ? providerSearchFields.address : null,
        "providerKeyVal": providerSearchFields.npi ? providerSearchFields.npi : null,
        "providerKeyTypRefId": ProviderConstants.PROVIDER_KEY_VALUE_TYP_REF_ID_NPI,
        "speciality": providerSearchFields.speciality ? providerSearchFields.speciality : null,
        "zip": providerSearchFields.zip ? providerSearchFields.zip : null,
        "fName": providerSearchFields.firstName ? providerSearchFields.firstName : null,
        "lName": providerSearchFields.lastName ? providerSearchFields.lastName : null
      }
    };
  }

  getFacilitiesBySearchParams(facilitySearchFields: any, appName: any) {
    const getFacilitiesSearchQuery = this.buildFacilitySearchQuery(facilitySearchFields);
    const providerUrl = getEnvVar(PROVIDER_SERVICE_DOMAIN_URL_PATH);
    return this.httpClient.post(providerUrl, JSON.stringify(getFacilitiesSearchQuery), { headers: this.getApiHeaders(appName)}).toPromise();
  }

  buildFacilitySearchQuery(facilitySearchFields: any) {
    return  {
      query: getFacilitiesBySearchParams,
      variables: {
        "address": facilitySearchFields.address ? facilitySearchFields.address : null,
        "facilityName": facilitySearchFields.facilityName ? facilitySearchFields.facilityName : null,
        "provKeyVal": facilitySearchFields.tin ? facilitySearchFields.tin : null,
        "provKeyRefId": ProviderConstants.PROVIDER_KEY_VALUE_TYP_REF_ID_TIN,
        "speciality": facilitySearchFields.speciality ? facilitySearchFields.speciality : null,
        "zip": facilitySearchFields.zip ? facilitySearchFields.zip : null
      }
    };
  }
}
