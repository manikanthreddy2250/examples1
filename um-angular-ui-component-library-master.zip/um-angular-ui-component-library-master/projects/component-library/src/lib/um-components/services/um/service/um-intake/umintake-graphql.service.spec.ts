import { TestBed } from '@angular/core/testing';

import {UmintakeGraphqlService} from './umintake-graphql.service';
import {AuthLibraryModule, AuthService, MicroProductAuthService} from '@ecp/auth-library';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {of} from 'rxjs/internal/observable/of';


@Injectable()
class MockHttpClient {
  post(url: string, body: any | null, options?: any) {
    const bodyStr = JSON.stringify(body);
    return of({data: {ref: [{ref_cd: '222', ref_desc: 'ref test desc'}]}});
  }
}

describe('UmintakeGraphqlService', () => {
  let service: UmintakeGraphqlService;
  let microProductAuthService: MicroProductAuthService;
  let authService: AuthService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, AuthLibraryModule],
      providers: [{ provide: HttpClient, useClass: MockHttpClient }]
    });
    service = TestBed.inject(UmintakeGraphqlService);
    authService = TestBed.inject(AuthService);
    microProductAuthService = TestBed.inject(MicroProductAuthService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should load Base Ref Name Display Data', () => {
    expect(service.loadBaseRefNameDisplayData).toBeDefined();
    service.loadBaseRefNameDisplayData('um_intake_ui', '1234');
  });

  it('should load Base Ref Child Display Data', () => {
    expect(service.loadRefChildDisplayDataInRef).toBeDefined();
    service.loadRefChildDisplayDataInRef('um_intake_ui', 1234);
  });

  it('should getProcedures', () => {
    expect(service.getProcedures).toBeDefined();
    service.getProcedures('78130', 'ALL', 'um_intake_ui');
  });

  it('should saveProcedures', () => {
    const procedureRecord = {
      Code: "B4185",
      Description: "PARENTERAL NUTRITION SOL NOS 10 GRAMS LIPIDS",
      Type: "HCPCS",
      TypeId: 3768
    };
    expect(service.saveProcedure).toBeDefined();
    service.saveProcedure(78130, procedureRecord, 'um_intake_ui', 3737);
  });

  it('should saveDiagnosis', () => {
    const diagnosisRecord = {
      Code: "Z67",
      Description: "BLOOD TYPE"
    };
    expect(service.saveDiagnosis).toBeDefined();
    service.saveDiagnosis(12916, diagnosisRecord, 'um_intake_ui');
  });

  it('should getHscDetails', () => {
    expect(service.getHscDetails).toBeDefined();
    service.getHscDetails(78130, 'um_intake_ui');
  });

  it('should loadRefDataByRefIds', () => {
    service.loadRefDataByRefIds("78130", 'um_intake_ui');
    expect(service.loadRefDataByRefIds).toBeDefined();
  });

  it('should getCaseTypeDetailsByHscId', () => {
    service.getCaseTypeDetailsByHscId(123, 'um_intake_ui');
    expect(service.getCaseTypeDetailsByHscId).toBeDefined();

  });

  it('should updateHsc', () => {
    const updatehsc = {
      hsc_id: 12845,
      hsc_facl: {
        plsrv_ref_id: 3743,
        srvc_desc_ref_id: 4348,
        srvc_dtl_ref_id: 4296,
        actul_admis_dttm: '07/10/2020',
        actul_dschrg_dttm: '07/28/2021',
        expt_admis_dt: '02/16/2021',
        expt_dschrg_dt: '02/18/2021'
      }
    };
    service.updateHsc(updatehsc, 'um_intake_ui');
    expect(service.getCaseTypeDetailsByHscId).toBeDefined();
  });

});
