import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { UserAuthService } from '../../../auth/user.service';
import { MicroProductAuthService } from '@ecp/auth-library';
import {
  HEALTH_SERVICE_DOMAIN_URL_PATH,
  UTILIZATION_MGMNT_FUNCS_URL,
} from '../../../../../config/config-constants';
import { RawQuery } from '@ecp/gql-tk';
import {
  getProcedureDetailsQuery,
  getRefChildDataByRefIDQuery,
  getRefDataByBaseRefNameQuery,
  getRefDataByRefIDsQuery,
} from '../graphql/referenceQuery';
import { getEnvVar } from '../../../environment/envVarUtil';
import {getHscDetailsQuery, updateHscMutation} from '../graphql/providerQuery';
import { getCaseTypeDetailsByHscIdQuery } from '../graphql/umNestJsGraphqlQuery';

@Injectable({
  providedIn: 'root',
})
export class UmintakeGraphqlService {
  constructor(
    private readonly httpClient: HttpClient,
    private readonly userAuthService: UserAuthService,
    private readonly microProductAuth: MicroProductAuthService
  ) {}

  getApiHeaders(appName): HttpHeaders {
    return new HttpHeaders()
      .set('Content-Type', 'application/json')
      .set('x-hasura-role', this.userAuthService.getUserHasuraRole(appName))
      .set('x-bpm-cli-org-id', this.userAuthService.getActiveClientOrg())
      .set('x-bpm-func-role', this.userAuthService.getActiveUserRole())
      .set('Authorization', 'Bearer ' + this.microProductAuth.getEcpToken());
  }

  loadBaseRefNameDisplayData(
    appName: string,
    baseRefName: string
  ): Promise<any> {
    const healthQuery = this.getRefDataByBaseRefNameQuery(baseRefName);
    const healthUrl = getEnvVar(HEALTH_SERVICE_DOMAIN_URL_PATH);
    return this.httpClient
      .post(healthUrl, JSON.stringify(healthQuery), {
        headers: this.getApiHeaders(appName),
      })
      .toPromise();
  }

  getRefDataByBaseRefNameQuery(baseRefName: string): RawQuery {
    return {
      query: getRefDataByBaseRefNameQuery,
      variables: {
        bas_ref_nm: baseRefName,
      },
    };
  }


  //Please send the Input for "loadRefDataByRefIds" functions as Int Array .
  loadRefDataByRefIds(appName: string, refId: any): Promise<any> {
    const healthQuery = this.getRefDataByRefIds(refId);
    const healthUrl = getEnvVar(HEALTH_SERVICE_DOMAIN_URL_PATH);
    return this.httpClient.post(healthUrl, JSON.stringify(healthQuery), {headers: this.getApiHeaders(appName)}).toPromise();
  }

  getRefDataByRefIds(refId: any): RawQuery {
    return {
      query: getRefDataByRefIDsQuery,
      variables: {
        ref_id: refId,
      },
    };
  }

  loadRefChildDisplayDataInRef(appName: string, refId: number): Promise<any> {
    const healthQuery = this.getRefChildDataByRefIDQuery(refId);
    const healthUrl = getEnvVar(HEALTH_SERVICE_DOMAIN_URL_PATH);
    return this.httpClient
      .post(healthUrl, JSON.stringify(healthQuery), {
        headers: this.getApiHeaders(appName),
      })
      .toPromise();
  }

  getRefChildDataByRefIDQuery(refId: number): RawQuery {
    return {
      query: getRefChildDataByRefIDQuery,
      variables: {
        ref_id: refId,
      },
    };
  }

  getProcedures(
    searchText: string,
    searchType: string,
    appName: string
  ): Promise<any> {
    const healthQuery = this.getProceduresQuery(searchText, searchType);
    const healthUrl = getEnvVar(HEALTH_SERVICE_DOMAIN_URL_PATH);
    return this.httpClient
      .post(healthUrl, JSON.stringify(healthQuery), {
        headers: this.getApiHeaders(appName),
      })
      .toPromise();
  }

  getProceduresQuery(searchText: string, searchType: string): RawQuery {
    return {
      query: getProcedureDetailsQuery,
      variables: {
        searchText,
        searchType,
      },
    };
  }

  saveProcedure(
    hscId: number,
    procedureRecord: any,
    appName: string,
    srvcSetRefId: number
  ): Promise<any> {
    const getSaveProcedureQuery = this.buildSaveProcedureMutation(
      hscId,
      procedureRecord,
      srvcSetRefId
    );
    return this.httpClient
      .post(
        getEnvVar(UTILIZATION_MGMNT_FUNCS_URL),
        JSON.stringify(getSaveProcedureQuery),
        { headers: this.getApiHeaders(appName) }
      )
      .toPromise();
  }

  buildSaveProcedureMutation(hscId: number, procedureRecord: any, srvcSetRefId: number): RawQuery {
    const procedureInput: any = {};
    procedureInput.proc_cd = procedureRecord.Code;
    procedureInput.proc_cd_schm_ref_id = procedureRecord.TypeId;
    procedureInput.proc_othr_txt = procedureRecord.Description;
    return {
      query: updateHscMutation,
      variables: {
        updateHscRequest: {
          hsc_id: hscId,
          srvc_set_ref_id: srvcSetRefId,
          hsc_srvcs: [procedureInput],
        },
      },
    };
  }

  saveDiagnosis(hscId: number, diagnosisRecord: any, appName: string): Promise<any> {
    const getSaveDiagnosisQuery = this.buildSaveDiagnosisMutation(hscId, diagnosisRecord);
    return this.httpClient.post(getEnvVar(UTILIZATION_MGMNT_FUNCS_URL),
      JSON.stringify(getSaveDiagnosisQuery),
      { headers: this.getApiHeaders(appName)}
    ).toPromise();
  }

  buildSaveDiagnosisMutation(hscId: number, diagnosisRecord: any): RawQuery{
    const diagnosisInput: any = {};
    diagnosisInput.diag_cd = diagnosisRecord.diag_cd;
    diagnosisInput.diag_othr_txt = diagnosisRecord.diag_dessc;
    diagnosisInput.pri_ind = diagnosisRecord.pri_ind;
    return {
      query: updateHscMutation,
      variables: {
        updateHscRequest: {
          hsc_id: hscId,
          hsc_diags: [diagnosisInput]
        },
      },
    };
  }

  getHscDetails(
    hscId: number,
    appName: string
  ): Promise<any> {
    const getHscDetailsQuery = this.buildGetHscDetailsQuery(
      hscId
    );
    return this.httpClient
      .post(
        getEnvVar(UTILIZATION_MGMNT_FUNCS_URL),
        JSON.stringify(getHscDetailsQuery),
        { headers: this.getApiHeaders(appName) }
      )
      .toPromise();
  }

  buildGetHscDetailsQuery(hscId: number): RawQuery {
    const hscDetailsInput: any = {};
    hscDetailsInput.hsc_id = hscId;
    return {
      query: getHscDetailsQuery,
      variables: {
        getHscAuthRequest: {
          hsc: hscDetailsInput
        },
      },
    };
  }


  getCaseTypeDetailsByHscId(hscId: number, appName: any) {
    const getCaseTypeDetailsByHscId = this.buildCaseTypeDetailsbyHscId(hscId);
    const umNestJsGraphqlUrl = getEnvVar(UTILIZATION_MGMNT_FUNCS_URL);
    return this.httpClient
      .post(umNestJsGraphqlUrl, JSON.stringify(getCaseTypeDetailsByHscId), {
        headers: this.getApiHeaders(appName),
      })
      .toPromise();
  }

  buildCaseTypeDetailsbyHscId(hscId: number): RawQuery {
    return {
      query: getCaseTypeDetailsByHscIdQuery,
      variables: {
        getCaseTypeDetailsRequest: {
          hsc_id: hscId,
        },
      },
    };
  }

  updateHsc(updateHscRequest: any, appName: any): Promise<any> {
    const updateHscReqObj = {
      query: updateHscMutation,
      variables: {
        updateHscRequest,
      },
    };
    const umNestJsGraphqlUrl = getEnvVar(UTILIZATION_MGMNT_FUNCS_URL);
    return this.httpClient
      .post(umNestJsGraphqlUrl, JSON.stringify(updateHscReqObj), {
        headers: this.getApiHeaders(appName),
      }).toPromise();
  };
}
