import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TasksListViewComponent } from './tasks-list-view.component';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA, ChangeDetectorRef, Injectable } from '@angular/core';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ConfigService } from '../services/config/config.service';
import {HttpClient} from '@angular/common/http';
import { of, Observable } from 'rxjs';
import { UserAuthService } from '../services/auth/user.service';
import { UmcasewfGraphqlService } from '../services/um/service/casewf/umcasewf-graphql.service';
import { AuthLibraryModule, AuthService, MicroProductAuthService, OAuthInitService } from '@ecp/auth-library';
import * as moment from 'moment';
import { TasksListViewModule } from './tasks-list-view.module';
import {TaskManagementService} from '../services/task-management/task-management.service';
import {GenericCamundaService} from '../services/um/service/generic-camunda/generic-camunda.service';

@Injectable()
class UserAuthServiceMock {

  getUserID() {
    return 'TESTUSERID';
  }

  isLocalHost() {
    return false;
  }

  getActiveClientOrg() {
    return 'ecp';
  }

  getActiveUserRole() {
    return 'sys_admin';
  }

  getAltUserID() {
    return 'test';
  }

  getUserHasuraRole() {
    return 'test';
  }

  getEcpToken() {
    return '12345';
  }
}
@Injectable()
class GenericCamundaServiceMock{
  evaluateMultipleRules(a, refRequest, c){
    return of( [
                [
                  {
                    refDspl: 'Request Clinical',
                    refId: 73432
                  }
                ],
                [
                  {
                    refDspl: 'Concurrent Review',
                    refId: 72139
                  }
                ],
                [],
                [
                  {
                    refDspl: 'Admission Review',
                    refId: 72138
                  }
                ]
              ]);
  }
}

describe('TasksListViewComponent', () => {
  let component: TasksListViewComponent;
  let fixture: ComponentFixture<TasksListViewComponent>;
  let mockConfigService: any;
  let httpClient: HttpClient;
  let umcaseService: UmcasewfGraphqlService;
  let cdrf: ChangeDetectorRef;
  let taskManagementService: TaskManagementService;

  beforeEach(async(() => {
    mockConfigService = jasmine.createSpyObj('mockConfigService', ['readConfig']);

    TestBed.configureTestingModule({
      declarations: [],
      providers: [
        ChangeDetectorRef,
        moment,
        { provide : UserAuthService, useClass: UserAuthServiceMock },
        {provide : MicroProductAuthService, useClass: UserAuthServiceMock},
        {provide : GenericCamundaService, useClass: GenericCamundaServiceMock},
        UmcasewfGraphqlService,
        AuthService,
        OAuthInitService
    ],
      imports: [HttpClientTestingModule, TasksListViewModule, AuthLibraryModule],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TasksListViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.application = 'dummyName';
    component.version = 'dummyVersion';
    umcaseService = TestBed.inject(UmcasewfGraphqlService);
    httpClient =  TestBed.inject(HttpClient);
    cdrf = TestBed.inject(ChangeDetectorRef);
    taskManagementService = TestBed.inject(TaskManagementService);
  });
  it('should create ngOnInit', () => {
    const configData = [
      {
          key: 'my_tasks_table_headers',
          value: {
            admitted: 'Admitted'
          }
      }
  ];

    const myTasksList = [
    {
      admitted: '02/10/2021',
      tat: '4 Hrs',
      status: 'Clinical Received',
      member: 'Smith, Jaimie',
      diagnosis: 'Hip Surgery',
      facility: 'Mount Sinai, Union Sq',
      taskType: 'LOC',
      action: 'Resume',
      hscId: '12905',
      taskId: '341',
      taskStatusRefID: 72113,
      taskExecutionID: '7324847832489894199'
  }
  ];
    const userspy = spyOn(umcaseService, 'getMyTasksListDetails').and.returnValue(Promise.resolve({}));
    mockConfigService.readConfig.and.returnValue(of(configData).toPromise());
    component.configService = mockConfigService;
    component.ngOnInit();
    expect(userspy).toHaveBeenCalled();
});
  it('should call buildTableData', () => {
    const myTasksList = {
      data: {
        getTaskListByHscId: {
          hsr_asgn: [
            {
              hsc_id: 22334,
              hsr_asgn_id: 1963,
              asgn_to_user_id: 'jsaicha',
              src_rec_guid: '2ceec710-cd91-11eb-8f8f-52330264d702',
              asgn_typ_ref_id: 73432,
              asgn_typ_ref_cd: {
                ref_dspl: 'Request Clinical'
              },
              asgn_sts_ref_id: 72113,
              asgn_sts_ref_cd: {
                ref_dspl: 'Active'
              },
              asgn_catgy_ref_id: 72093,
              asgn_catgy_ref_cd: {
                ref_dspl: 'Automated Clinical Case Validations'
              },
              asgn_to_wrk_que_ref_id: null,
              asgn_to_wrk_que_ref_cd: null,
              hsc: {
                indv_id: 511942199,
                individual: {
                  fst_nm: 'Whitcomb',
                  lst_nm: 'Geiger'
                },
                hsc_diags: [],
                hsc_provs: [],
                hsc_facls: [
                  {
                    actul_admis_dttm: '2021-04-26T17:00:00',
                    tat_due_dttm: -174
                  }
                ]
              }
            },
            {
              hsc_id: 12845,
              hsr_asgn_id: 1296,
              asgn_to_user_id: 'jsaicha',
              src_rec_guid: '10501582-b673-11eb-8687-acde48001122',
              asgn_typ_ref_id: 72139,
              asgn_typ_ref_cd: {
                ref_dspl: 'Concurrent Review'
              },
              asgn_sts_ref_id: 72113,
              asgn_sts_ref_cd: {
                ref_dspl: 'Active'
              },
              asgn_catgy_ref_id: 72142,
              asgn_catgy_ref_cd: {
                ref_dspl: 'Validations'
              },
              asgn_to_wrk_que_ref_id: null,
              asgn_to_wrk_que_ref_cd: null,
              hsc: {
                indv_id: 503926748,
                individual: {
                  fst_nm: 'Matt',
                  lst_nm: 'Meyer'
                },
                hsc_diags: [],
                hsc_provs: [
                  {
                    hsc_prov_id: 3761,
                    facilityProviderName: 'ADVANTA MEDICAL'
                  }
                ],
                hsc_facls: [
                  {
                    actul_admis_dttm: '2020-07-10T10:30:11',
                    tat_due_dttm: -880
                  }
                ]
              }
            },
            {
              hsc_id: 12545,
              hsr_asgn_id: 845,
              asgn_to_user_id: 'jsaicha',
              src_rec_guid: '54f69556-b286-11eb-ac44-34cff66803b1',
              asgn_typ_ref_id: 72208,
              asgn_typ_ref_cd: {
                ref_dspl: 'Risk Scoring'
              },
              asgn_sts_ref_id: 72113,
              asgn_sts_ref_cd: {
                ref_dspl: 'Active'
              },
              asgn_catgy_ref_id: 72094,
              asgn_catgy_ref_cd: {
                ref_dspl: 'Automated Clinical Review Readiness'
              },
              asgn_to_wrk_que_ref_id: null,
              asgn_to_wrk_que_ref_cd: null,
              hsc: {
                indv_id: 503926748,
                individual: {
                  fst_nm: 'Matt',
                  lst_nm: 'Meyer'
                },
                hsc_diags: [],
                hsc_provs: [
                  {
                    hsc_prov_id: 4432,
                    facilityProviderName: 'XIOMARA HOME, INC.'
                  },
                  {
                    hsc_prov_id: 4433,
                    facilityProviderName: 'XIOMARA HOME, INC.'
                  }
                ],
                hsc_facls: [
                  {
                    actul_admis_dttm: null,
                    tat_due_dttm: -1000
                  }
                ]
              }
            },
            {
              hsc_id: 12845,
              hsr_asgn_id: 2057,
              asgn_to_user_id: 'jsaicha',
              src_rec_guid: '2e5c81e5-c7b3-11eb-a4be-acde48001122',
              asgn_typ_ref_id: 72138,
              asgn_typ_ref_cd: {
                ref_dspl: 'Admission Review'
              },
              asgn_sts_ref_id: 72114,
              asgn_sts_ref_cd: {
                ref_dspl: 'Complete'
              },
              asgn_catgy_ref_id: 72142,
              asgn_catgy_ref_cd: {
                ref_dspl: 'Validations'
              },
              asgn_to_wrk_que_ref_id: null,
              asgn_to_wrk_que_ref_cd: null,
              hsc: {
                indv_id: 503926748,
                individual: {
                  fst_nm: 'Matt',
                  lst_nm: 'Meyer'
                },
                hsc_diags: [],
                hsc_provs: [
                  {
                    hsc_prov_id: 3761,
                    facilityProviderName: 'ADVANTA MEDICAL'
                  }
                ],
                hsc_facls: [
                  {
                    actul_admis_dttm: '2020-07-10T10:30:11',
                    tat_due_dttm: -353
                  }
                ]
              }
            }
          ]
        }
      }
    };

    const configData = [
      {
        id: 'case_wf_mgmt_ui_1.0.0_my_tasks_config_table_headers_2021-04-16',
        createDateTime: '2021-04-16T15:28:11.139+00:00',
        creatUserId: null,
        changeDateTime: '2021-04-16T15:28:11.139+00:00',
        changeUserId: null,
        updateVersionNumber: '0',
        createSystemReferenceId: null,
        changeSystemReferenceId: null,
        dataSecureRuleList: null,
        dataGltyIssList: null,
        application: 'case_wf_mgmt_ui',
        version: '1.0.0',
        org: null,
        role: null,
        key: 'my_tasks_config_table_headers',
        value: '{"tableHeadersColumns": [{"key":"hscId","label":"HSC Id"},{"key":"admitted","label":"Admitted"},{"key":"tat","label":"Tat"},{"key":"taskType","label":"Task Type"},{"key": "status", "label":"Status"},{"key":"member","label":"Member"},{"key":"diagnosis","label":"Diagnosis"},{"key":"facility","label":"Facility"},{"key":"action","label":"Action"}]\n}',
        startDate: '2021-04-16T00:00:00.000+00:00',
        endDate: null,
        inactivityIndicator: '0'
      }
    ];

    const actionButtonRefDataPromise = {
      data: {
        ref: [
          {
            inac_ind: 0,
            ref_cd: 'Start',
            ref_desc: 'Start',
            ref_dspl: 'Start',
            ref_id: 73532
          },
          {
            inac_ind: 0,
            ref_cd: 'View',
            ref_desc: 'View',
            ref_dspl: 'View',
            ref_id: 73533
          }
        ]
      }
    };

    const statusActionConfigPromise = [
      {
        id: 'case_wf_mgmt_ui_1.0.0_my_tasks_status_action_config_2021-06-22',
        createDateTime: '2021-06-22T20:10:38.192+00:00',
        creatUserId: null,
        changeDateTime: '2021-06-22T20:10:38.192+00:00',
        changeUserId: null,
        updateVersionNumber: '0',
        createSystemReferenceId: null,
        changeSystemReferenceId: null,
        dataSecureRuleList: null,
        dataGltyIssList: null,
        application: 'case_wf_mgmt_ui',
        version: '1.0.0',
        org: null,
        role: null,
        key: 'my_tasks_status_action_config',
        value: '{"taskStatusActionMapping": [{"taskStatus":"72113","actionButtonLabelRefId":"73532"},{"taskStatus":"72114","actionButtonLabelRefId":"73533"}]}',
        startDate: '2021-06-22T00:00:00.000+00:00',
        endDate: null,
        inactivityIndicator: '0'
      }
    ];
    spyOn(component, 'getStatusActionMappingData').and.returnValue(of([actionButtonRefDataPromise, statusActionConfigPromise]).toPromise());
    const response = [myTasksList, configData];
    // component.actionButtonRefDataResponse = actionButtonRefDataPromise;
    // component.statusActionConfigResponse = statusActionConfigPromise;
    component.getStatusActionMappingData();
    component.buildTableData(response);
    expect(component.buildTableData).toBeDefined();
  });

  it('should getPromises()', () => {
    component.configService = mockConfigService;
    // const spy = spyOn(component.configService, 'readConfig').and.returnValue(Promise.resolve([]));
    const userspy = spyOn(umcaseService, 'getMyTasksListDetails').and.returnValue(Promise.resolve({}));
    component.getPromises();
    expect(userspy).toHaveBeenCalled();
  });

  it('should initGraphqlService()', () => {
    component.configService = new ConfigService(httpClient, 'https://dev-config', umcaseService);
    component.initGraphqlService();
    expect(component.configService).toBeDefined();
  });

  it('should actionSelect()', () => {
    const row = {
      action: 'Resume',
      caseId: '12905'
    };
    component.actionSelect(row);
    expect(component.actionClick).toBeDefined();
  });

// failing.. Please check and uncomment
//   it('should ngAfterContentChecked()', () => {
//     component.myTasksList = [
//       {
//         admitted: '02/10/2021',
//         tat: '4 Hrs',
//         status: 'Clinical Received',
//         member: 'Smith, Jaimie',
//         diagnosis: 'Hip Surgery',
//         facility: 'Mount Sinai, Union Sq',
//         taskType: 'LOC',
//         action: 'Resume',
//         hscId: '12905',
//         caseId: '',
//         taskId: '341',
//         taskNameRefID: '123',
//         taskStatusRefID: 72113,
//         taskExecutionID: '7e7271b2-b335-11eb-a650-acde48001122'
//     },
//     {
//         admitted: '02/10/2021',
//         tat: '10 Hrs',
//         status: 'Clinical Received',
//         member: 'Smith, Jaimie',
//         diagnosis: 'Hip Surgery',
//         facility: 'Mount Sinai, Union Sq',
//         taskType: 'LOC',
//         action: 'Resume',
//         caseId: '',
//         hscId: '12905',
//         taskId: '341',
//         taskNameRefID: '123',
//       taskStatusRefID: 72113,
//       taskExecutionID: '7e7271b2-b335-11eb-a650-acde48001124'
//     }
//     ];
//     component.ngAfterContentChecked();
//     expect(component.dataSource).toBeDefined();
//   });

  it('should call showTaskTableGrid() return true', () => {
    component.currentBtnValue = 'mytask';
    const value = component.showTaskTableGrid();
    expect(value).toBeTrue();
  });
  it('should call onTabChanged() return false ', () => {
    component.currentBtnValue = 'teamcase';
    const value = component.showTaskTableGrid();
    expect(value).toBeFalse();
  });

  it('should call splitStatusCell()', () => {
    const data = 'In Progress,Re-Admit';
    const res = ['In Progress', 'Re-Admit'];
    const value = component.splitStatusCell(data);
    expect(value).toEqual(res);
  });

  it('should call convertDate()', () => {
    const date = '2020-07-10T10:30:11.551';
    const value = component.convertDate(date);
    expect(value).toEqual('07/10/2020');
  });

  it('should call refreshTasks()', () => {
    const spy = spyOn(component, 'ngOnInit').and.callFake(() => {});
    const spy2 = spyOn(taskManagementService, 'getTaskAssignment').and.returnValue(Promise.resolve({}));
    component.refreshTasks();
    expect(spy2).toHaveBeenCalled();
  });

  it('should call getTableKeys()', () => {
    component.tableHeaders = [
      {key: 'admitted', label: 'Admitted'},
      {key: 'tat', label: 'Tat'},
      {key: 'taskType', label: 'Task Type'},
      {key: 'status', label: 'Status'},
      {key: 'member', label: 'Member'},
      {key: 'diagnosis', label: 'Diagnosis'}
    ];
    component.getTableKeys();
    expect(component.tableHeaderKeys).toBeDefined();
  });

  it('should call getTableLabel()', () => {
    component.tableHeaders = [
      {key: 'admitted', label: 'Admitted'},
      {key: 'tat', label: 'Tat'},
      {key: 'taskType', label: 'Task Type'},
      {key: 'status', label: 'Status'},
      {key: 'member', label: 'Member'},
      {key: 'diagnosis', label: 'Diagnosis'}
    ];
    const label = component.getTableLabel('admitted');
    expect(label).toBeDefined();
  });


  it('should call mapMyTaskListDetails()', () => {
    const data = {
      data: {
        getTaskListByHscId: {
          hsr_asgn: [
            {
              hsc_id: '12905',
              hsr_asgn_id: '341',
              asgn_sts_ref_cd: {
                ref_dspl: 'start'
              },
              asgn_catgy_ref_cd: {
                ref_dspl: 'eligibility'
              },
              asgn_typ_ref_cd: {
                ref_dspl: 'eligibility'
              },
              hsc: {
                hsc_facls: [{
                  actul_admis_dttm: '2020-07-10T10:30:11.551',
                  tat_due_dttm: '2020-07-10T10:30:11.551'
                }],
                individual: [{
                  fst_nm: 'test',
                  lst_nm: 'test1'
                }],
                hsc_diags: [{
                  diag_cd: '1234',
                  diag_desc: 'desc'
                }],
                hsc_provs: [{
                  hsc_prov_id: '3456',
                  facilityProviderName: 'name'
                }]
              }
            }
          ]
        }
      }
    };
    const value = component.mapMyTaskListDetails(data);
    expect(value.length).toBeGreaterThan(0);
  });
});
