import {
  Component,
  OnInit,
  ChangeDetectorRef,
  ViewEncapsulation,
  ViewChild,
  AfterContentChecked,
  EventEmitter,
  Input,
  Output
} from '@angular/core';
import { RecentTasksMockData } from '../models/tasks-list-mock-data';
import { EcpUclSort } from '@ecp/angular-ui-component-library/sort';
import { EcpUclTableDataSource } from '@ecp/angular-ui-component-library/table';
import { TaskListModal } from '../models/tasks-list.model';
import {
  CLIENT_REF_DISPLAY_DMN,
  GET_CONFIG_URL_PATH,
  MYTASKS_LIST_TABLE_HEADERS,
  MY_TASKS_STATUS_ACTION_CONFIG
} from '../../config/config-constants';
import { ConfigService } from '../services/config/config.service';
import { HttpClient } from '@angular/common/http';
import { UmcasewfGraphqlService } from '../services/um/service/casewf/umcasewf-graphql.service';
import * as moment from 'moment';
import { getEnvVar } from '../services/environment/envVarUtil';
import {TaskManagementService} from '../services/task-management/task-management.service';
import {UserAuthService} from '../services/auth/user.service';
import {GenericCamundaService} from '../services/um/service/generic-camunda/generic-camunda.service';
import {umReferenceConstants} from '../../constant/um-reference-constants';


@Component({
  // tslint:disable-next-line:component-selector
  selector: 'um-tasks-list-view',
  templateUrl: './tasks-list-view.component.html',
  styleUrls: ['./tasks-list-view.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class TasksListViewComponent implements OnInit, AfterContentChecked {

  user = [];
  myTasksCount = 0;
  taskNameRefList = [];

  currentBtnValue = 'mytask';
  showSpinner = false;

  myTaskLabel = 'My Tasks';
  dataSource: EcpUclTableDataSource<any>;
  statusActionSource = {};
  actionButtonRefDataSource = {};
  actionButtonDataRefSource = {};
  actionButtonRefDataResponse: any;
  statusActionConfigResponse: any;



  @Input() application = '';
  @Input() version = '';
  @Output() actionClick: EventEmitter<any> = new EventEmitter();

  configService: any;


  constructor(private readonly mockData: RecentTasksMockData,
              private readonly httpClient: HttpClient,
              private umcaseService: UmcasewfGraphqlService,
              private cdref: ChangeDetectorRef,
              private readonly taskManagementService: TaskManagementService,
              private userAuthService: UserAuthService,
              private genericCamundaService: GenericCamundaService) { }

  myTasksList: TaskListModal[] = [];
  tasksCount: any = '';

  tableHeaders: any[] = [];
  tableHeaderKeys = [];

  noRecordsFound: any;
  errorMsg = '';
  // @ViewChild(EcpUclPaginator) paginator: EcpUclPaginator;
  @ViewChild(EcpUclSort) sort: EcpUclSort;

  ngOnInit(): void {
    this.initGraphqlService();
    this.showSpinner = true;
    const promises: Promise<any>[] = this.getPromises();
    Promise.all(promises).then(
      response => {
        this.showSpinner = false;
        this.buildTableData(response);
      }, error => {
        this.showSpinner = false;
        this.errorMsg = 'Error occurred when retrieving my tasks and configuration data:';
        console.log('Error occurred when retrieving member and config data: ', error);
      });
  }

  async buildTableData(response){
    const myTaskListData: any = response[0];
    const configResponse: any = response[1];
    this.tableHeaders = JSON.parse(configResponse[0]?.value)?.tableHeadersColumns;
    this.getTableKeys();
    if (this.hasTasks(myTaskListData)) {
      const res = await this.getStatusActionMappingData();
      this.actionButtonRefDataResponse = res[0].data.ref;
      this.setActionButtonRefDataSource(this.actionButtonRefDataResponse);
      this.statusActionConfigResponse = JSON.parse(res[1][0]?.value)?.taskStatusActionMapping;
      this.setStatusActionConfig(this.statusActionConfigResponse);

      const tableData = this.mapMyTaskListDetails(myTaskListData);
      this.myTasksList = tableData;
      const refRequest = this.buildDmnRequest();
      this.genericCamundaService.evaluateMultipleRules(CLIENT_REF_DISPLAY_DMN, refRequest, this.application).subscribe(
        dmnResponse => {
          this.errorMsg = '';
          this.setTableDataRefValues(this.myTasksList, dmnResponse);
          this.showSpinner = false;
        },
        error2 => {
          this.showSpinner = false;
          this.errorMsg = 'Error occurred when retrieving task reference display:';
          console.log('Error occurred when retrieving task reference display: ', error2);
        }
      );
    }else{
      this.myTasksList = [];
    }
  }

  hasTasks(myTaskListData){
    return myTaskListData?.data?.getTaskListByHscId?.hsr_asgn?.length > 0;
  }

  async getStatusActionMappingData(){
    const statusActionConfigResponse = await this.configService.readConfig(this.application,
      this.version, MY_TASKS_STATUS_ACTION_CONFIG);
    const actionButtonRefDataResponse = await this.umcaseService.loadBaseRefNameDisplayData(this.application ,
      umReferenceConstants.ACTION_BUTTON_LABEL_BASE_REF_NAME );
    return[ actionButtonRefDataResponse , statusActionConfigResponse];
  }
  setStatusActionConfig(statusActionConfigResponse): void {
    statusActionConfigResponse.forEach(config => {
      this.statusActionSource[config.taskStatus] = this.actionButtonRefDataSource[config.actionButtonLabelRefId] ?? null;
    });
  }

  setActionButtonRefDataSource(actionButtonRefDataResponse): void{
    actionButtonRefDataResponse.forEach(ref => {
      this.actionButtonRefDataSource[ref.ref_id] = ref.ref_dspl;
      this.actionButtonDataRefSource[ref.ref_dspl] = ref.ref_id;
    });
  }

  private setTableDataRefValues(tableData: TaskListModal[], dmnResponse) {
    for (const task of tableData) {
      const taskRefId = task?.taskNameRefID;
      for (const responseRefDspl of dmnResponse) {
        if (responseRefDspl[0]?.refId === taskRefId) {
          task.taskType = responseRefDspl[0].refDspl;
        }
      }
    }
  }

  private buildDmnRequest() {
    const orgId = this.userAuthService.getActiveClientOrg();
    const refRequest = [];
    for (const record of this.taskNameRefList) {
      refRequest.push({refId: record, orgId: orgId});
    }
    const uniqueRefRequest = refRequest.filter((item, index, self) =>
      index === refRequest.findIndex((secondItem) => (
        item.refId === secondItem?.refId
      ))
    );
    return uniqueRefRequest;
  }

  ngAfterContentChecked() {
    this.myTaskLabel = `My Tasks (${this.myTasksList.length})`;
    this.dataSource = new EcpUclTableDataSource(this.myTasksList);
    this.noRecordsFound = this.myTasksList.length === 0 ? 'No Records Found' : '';

    // this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;

    this.cdref.detectChanges();
  }


  actionSelect(row: any) {
    if (row) {
      this.actionClick.next(row);
    }
  }

  getTableKeys() {
    this.tableHeaderKeys = this.tableHeaders.map(ele => ele.key);
  }

  getTableLabel(key) {
    return this.tableHeaders.find(ele => ele.key === key)?.label;
  }

  public initGraphqlService(): void {
    const configUrl = getEnvVar(GET_CONFIG_URL_PATH);
    this.configService = new ConfigService(this.httpClient, configUrl, this.umcaseService);
  }

  /**
   * Creates the promises for both indv call and config, and returns them as an array
   */
  public getPromises(): Promise<any>[] {
    const myTasksList = this.umcaseService.getMyTasksListDetails(this.application);
    const configPromise = this.configService.readConfig(this.application, this.version, MYTASKS_LIST_TABLE_HEADERS);
    return [myTasksList, configPromise ];
  }

  showTaskTableGrid() {
    return this.currentBtnValue === 'mytask';
  }

  splitStatusCell(data) {
    const cellData = data.split(',');
    return cellData;
  }

  mapMyTaskListDetails(data) {
    const myTaskData: TaskListModal[] = [];
    const rawData = data?.data?.getTaskListByHscId?.hsr_asgn || [];
    for (const record of rawData) {
      const task: TaskListModal = new  TaskListModal();
      task.hscId = record?.hsc_id;
      task.taskId = record?.hsr_asgn_id;
      task.caseId = '';
      task.action = this.getActionStatus(record?.asgn_sts_ref_id) ?? 'Start' ;
      task.admitted = this.convertDate(record?.hsc?.hsc_facls[0]?.actul_admis_dttm);
      task.diagnosis = record?.hsc?.hsc_diags[0] ? record?.hsc?.hsc_diags[0]?.diag_cd : '' + ' ' +
      record?.hsc?.hsc_diags[0] ? record?.hsc?.hsc_diags[0]?.diag_desc : '';
      task.facility = record?.hsc?.hsc_provs[0]?.facilityProviderName;
      task.member = record?.hsc?.individual?.fst_nm + ' ' + record?.hsc?.individual?.lst_nm;
      task.status = record?.asgn_sts_ref_cd?.ref_dspl;
      task.taskStatusRefID = record?.asgn_sts_ref_id;
      task.tat = record?.hsc?.hsc_facls[0]?.tat_due_dttm;
      task.taskNameRefID = record?.asgn_typ_ref_id;
      task.taskExecutionID = record?.src_rec_guid;
      task.actionStatusRefID = this.actionButtonDataRefSource[task.action];
      myTaskData.push(task);
      this.taskNameRefList.push(record?.asgn_typ_ref_id);
    }

    return myTaskData;
  }

  convertDate(date) {
    if (date) {
      return moment.utc(date).local().format('MM/DD/YYYY');
    }

  }

  refreshTasks() {
    this.errorMsg = '';
    this.taskManagementService.getTaskAssignment(this.application).then(
      response => {
        this.ngOnInit();
      }, error => {
        this.showSpinner = false;
        this.errorMsg = 'Error occurred during get Task Assignment';
        console.log('Error occurred during get Task Assignment: ', error);
      }
    );
  }

  getActionStatus(taskStatusRefID): string{
    return this.statusActionSource[taskStatusRefID] ?? null;
  }

}
