import {Story, Meta, moduleMetadata} from '@storybook/angular';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { RouterModule } from '@angular/router';
import {ActivityLogComponent} from "../../projects/component-library/src/lib/um-components/activity-log/activity-log.component";
import {ActivityLogComponentModule} from "../../projects/component-library/src/lib/um-components/activity-log/activity-log.component.module";

export default {
  title: 'UM Components/Activity Log',
  component: ActivityLogComponent,
  decorators: [
    moduleMetadata({
      imports: [
        BrowserModule,
        BrowserAnimationsModule,
        ActivityLogComponentModule,
        RouterModule.forRoot([], { useHash: true })
      ],
      providers: []
    }),
  ],
  argTypes: {
    ngOnInit: {
      table: {
        disable: true
      }
    }
  },
  parameters: {
    docs: {
      description: {
        component: `Activity Log Component`
      }
    },
  }
} as Meta;


const Template: Story<ActivityLogComponent> = (args: ActivityLogComponent) => ({
  component: ActivityLogComponent,
  props: args,
  template: `
    <div style="padding: 1rem;">
       <um-activity-log
             [hscID]="hscID" [application]="application" [version]="version">
        </um-activity-log>
    </div>
  `
});

const hscID = 21611;
const application = 'case_wf_mgmt_ui';
const version = '1.0.0';

const standardCode = `
// Import ActivityLogComponentModule into your module.ts file.
import { ActivityLogComponentModule } from '@ecp/um-angular-ui-component-library';

// Add the ActivityLogComponentModule to the @NgModule({..}) imports array.

@NgModule({
  import: [
    import { ActivityLogComponentModule } from '@ecp/um-angular-ui-component-library';
    ...,
  ActivityLogComponentModule,
  ]
})

// Create a component using the <um-activity-log></um-activity-log> selector tag

<um-activity-log
             [hscID]="hscID"
             [application]="application"
             [version]="version">
</um-activity-log>
`;


export const ActivityLogView = Template.bind({});

// @ts-ignore
ActivityLogView.args = {
  hscID,
  application,
  version
};

ActivityLogView.parameters = {
  docs: {
    source: {
      code: standardCode
    }
  }
};

