import {Story, Meta, moduleMetadata} from '@storybook/angular';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { RouterModule } from '@angular/router';
import { BedDayDecisionModule } from '../../projects/component-library/src/lib/um-components/bed-day-decision/bed-day-decision.module';
// tslint:disable-next-line: max-line-length
import { BedDayDecisionComponent } from '../../projects/component-library/src/lib/um-components/bed-day-decision/bed-day-decision.component';

export default {
  title: 'UM Components/Bed Day Decision',
  component: BedDayDecisionComponent,
  decorators: [
    moduleMetadata({
      imports: [
        BrowserModule,
        BrowserAnimationsModule,
        BedDayDecisionModule,
        RouterModule.forRoot([], { useHash: true })
      ],
      providers: []
    }),
  ],
  argTypes: {
    ngOnInit: {
      table: {
        disable: true
      }
    }
  },
  parameters: {
    docs: {
      description: {
        component: `Bed Day Decision Component , Still IN PROGRESS.
        `
      }
    },
  }
} as Meta;


const Template: Story<BedDayDecisionComponent> = (args: BedDayDecisionComponent) => ({
  component: BedDayDecisionComponent,
  props: args,
  template: `
    <div style="padding: 1rem;">
       <um-bed-day-decision
             [hscID]="hscID"
             [processTaskExecutionID]="processTaskExecutionID"
             [application]="application"
             [showNotes]="showNotes"
             [editBedDay]="editBedDay"
             [selectedStartDate]="selectedStartDate"
             [version]="version"
             [reviewDecisions]="reviewDecisions"
             [hsrAsgnId]="hsrAsgnId"
             [existingDecisionReviews]="existingDecisionReviews"
             [hscClinGuidID]="hscClinGuidID"
             [decisionId]="decisionId"
             [disableIndvRadio]="disableIndvRadio"
             >
        </um-bed-day-decision>
    </div>
  `
});

const hscID = '12675';
const processTaskExecutionID = '12345';
const application = 'case_wf_mgmt_ui';
const version = '1.0.0';
const showNotes = true;
const editBedDay = false;
const selectedStartDate = '07/12/2021';
const reviewDecisions = [];
const hsrAsgnId = '2648';
const existingDecisionReviews = [];
const hscClinGuidID = '3761';
const decisionId = '7463';
const disableIndvRadio = false;
// const application = 'case_wf_mgmt_ui';
// const version = '1.0.0';

const standardCode = `
// Import BedDayDecisionModule into your module.ts file.
import { BedDayDecisionModule } from '@ecp/um-angular-ui-component-library';

// Add the BedDayDecisionModule to the @NgModule({..}) imports array.

@NgModule({
  import: [
    import { BedDayDecisionModule } from '@ecp/um-angular-ui-component-library';
    ...,
  BedDayDecisionModule,
  ]
})

// Create a component using the <um-bed-day-decision></um-bed-day-decision> selector tag

<um-bed-day-decision
             [hscID]="hscID"
             [processTaskExecutionID]="processTaskExecutionID"
             [application]="application"
             [showNotes]="showNotes"
             [version]="version">
</um-bed-day-decision>
`;


export const BedDayDecisionView = Template.bind({});

// @ts-ignore
BedDayDecisionView.args = {
  hscID,
  processTaskExecutionID,
  application,
  version,
  showNotes,
  editBedDay,
  selectedStartDate,
  reviewDecisions,
  hsrAsgnId,
  existingDecisionReviews,
  hscClinGuidID,
  decisionId,
  disableIndvRadio
};

BedDayDecisionView.parameters = {
  docs: {
    source: {
      code: standardCode
    }
  }
};

