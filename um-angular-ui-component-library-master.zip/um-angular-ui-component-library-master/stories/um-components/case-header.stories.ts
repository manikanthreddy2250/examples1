import {Story, Meta, moduleMetadata} from '@storybook/angular';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {CaseHeaderComponent} from '../../projects/component-library/src/lib/um-components/case-header/case-header.component';
import {CaseHeaderModule} from '../../projects/component-library/src/lib/um-components/case-header/case-header.module';
import { RouterModule } from '@angular/router';


export default {
  title: 'UM Components/Case Header (In Progress)',
  component: CaseHeaderComponent,
  decorators: [
    moduleMetadata({
      imports: [
        BrowserModule,
        BrowserAnimationsModule,
        CaseHeaderModule,
        RouterModule.forRoot([], { useHash: true })
      ],
      providers: []
    }),
  ],
  argTypes: {
    ngOnInit: {
      table: {
        disable: true
      }
    }
  },
  parameters: {
    docs: {
      description: {
        component: `Case Header component shows the .
        Development In Progress

        The UMCaseHeaderComponent is meant to provide a header view for basic member information. 
        The header is Divided into two separate sections Static Info and Configurable Info

       1. This component has 4 required input fields:

            1. application: name of the consuming application. used for retrieving  configurations.

            2. version: version of the consuming application. used for retrieving  configurations.

            3. hscIdInput: The HSC ID for the case record of interest.
            
            4. caseHeaderInput: caseHeader details or hscId can be input data

       2. Configurable Info

          Table section will dynamically populate fields based on the configuration saved within the system configuration table.

           Ensure configuration is present with configuration domain

            Available Table Header Config fields
            
            | Field                             | Key              |
            | --------------------------------- | -----------------|
            | IndividualId                      | indId            |
            | TAT Due Date                      | tatDueDate       |
            | Case Type                         | caseType         |
            | Service Type                      | serviceType      |
            | Facility                          | facility         |
            | PrimaryDiagnosis                  | primaryDiagnosis |
            | PlanCode                          | planCode         |
            | Client                            | client           |
            | Service Start Date                | serviceStartDate |
            | Service End Date                  | serviceEndDate   |
            | Admit Date                        | admitDate        |
            | Discharge Date                    | dischargeDate    |
            | Age                               | age              |
            | Gender                            | gender           |
            | Name                              | name             |
            | Date of Birth                     | dob              |
            | Qualification                     | qualification    |
            | Address                           | address          |
            
            Example: 
            {
              "indId":'503926748',
              "requestType": 'Inpatient',
              "tatDueDate": '00:00:00',
              "caseType": 'Hospice',
              "serviceType": 'Scheduled',
              "facility": 'JENNIE STUART MEDICAL CENTER',
              "primaryDiagnosis": 'A92.1-ONYONG-NYONG FEVER',
              "planCode": '',
              "client": '',
              "serviceStartDate": '',
              "serviceEndDate": '',
              "admitDate": '01-01-2021',
              "dischargeDate": '01-05-2021'
            }


        3. Testing (In Storybook showcase): Copy ecp_token,active_org_role,ecp_token_claims_obj from clinical app and add into local storage
        `
      }
    },
  }
} as Meta;


const Template: Story<CaseHeaderComponent> = (args: CaseHeaderComponent) => ({
  component: CaseHeaderComponent,
  props: args,
  template: `
    <div style="padding: 1rem;">
        <um-case-header  [application]="application" [version]="version" 
        [hscId]="hscId" [caseHeaderInput]="caseHeaderInput" 
        [showCollapseView]="showCollapseView" >
        </um-case-header>
    </div>
  `
});


const standardCode = `
// Import CaseHeaderModule into your module.ts file.
import { CaseHeaderModule } from '@ecp/angular-ui-component-library';

// Add the CaseHeaderModule to the @NgModule({..}) imports array.

@NgModule({
  import: [
    ...,
    TableModule,
  ]
})

// Create a component using the <um-case-header></um-case-header> selector tag

<um-case-header 
                [application]="appName"
                [version]="version"
                [hscId]="hscId"
                [caseHeaderInput]="caseHeaderInput"
                [showCollapseView]="showCollapseView" >
</um-case-header>
`;

const application = 'case_wf_mgmt_ui';
const version = '1.0.0';
const hscId = 12916;
const caseHeaderInput = {};
const showCollapseView = false;

export const CaseHeaderView = Template.bind({});

// @ts-ignore
CaseHeaderView.args = {
  showCollapseView,application,version,hscId,caseHeaderInput
};

CaseHeaderView.parameters = {
  docs: {
    source: {
      code: standardCode
    }
  }
};

