// Imports
import {Story, Meta, moduleMetadata} from '@storybook/angular';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {CaseNotesComponent} from '../../projects/component-library/src/lib/um-components/case-notes/case-notes.component';
import {CaseNotesModule} from '../../projects/component-library/src/lib/um-components/case-notes/case-notes.module';
import {RouterModule} from '@angular/router';
import { MenuPopupModule } from '@ecp/angular-ui-component-library/menu-popup';

// Default NgModule
export default {
  title: 'UM Components/Case Notes',
  component: CaseNotesComponent,
  decorators: [
    moduleMetadata({
      imports: [
        BrowserModule,
        BrowserAnimationsModule,
        CaseNotesModule,
        MenuPopupModule,
        RouterModule.forRoot([], { useHash: true })
      ],
      providers: []
    }),
  ],
  argTypes: {
    ngOnInit: {
      table: {
        disable: true
      }
    }
  },
  parameters: {
    docs: {
      description: {
        component: `Store notes on a case.

        Developers can pass in a Notes JSON object as structured below to avoid retrieving notes data, or pass in an HSC ID to allow this component to retrieve notes data.

        Notes Implementation

        The Component has 4 Inputs

        1. application: Name of the consuming application. Used for retrieving configurations.

        2. notesJSON: JSON object containing notes data to populate the UI.
                [
                    {
                      creat_dttm: '2021-05-14',
                      note_titl_txt: 'Testing123',
                      note_txt_lobj: 'Lorem ipsum',
                      src_user_nm: 'John Smith'
                    },
                    {
                      creat_dttm: '2021-05-14',
                      note_titl_txt: 'Testing998',
                      note_txt_lobj: 'Lorem ipsum dolor sit amet',
                      src_user_nm: 'John Smith'
                    }
                  ];
        3. hscId:  hscID for retrieving notes data from a exsisting case.

        4. readOnly: Which shows the Case Notes Grid associated to case or passed through JSON.

        To Implement Notes Component , Kindly follow the below steps

              1. Import CaseNotesModule into your module.ts file:

                  import { CaseNotesModule } from '@ecp/um-angular-ui-component-library';

              2. Add the CaseNotesModule to the @NgModule({..}) imports array.

              3. Create a component using the <app-case-notes></app-case-notes> selector tag.

        `
      }
    },
  }
} as Meta;

const srcCode = `
<app-case-notes [application]="application" [notesJSON]="notesJSON" [readOnly]="readOnly" [summaryViewOnly]="summaryViewOnly" [hscId]="hscId" ></app-case-notes>

`;

const Template: Story<CaseNotesComponent> = (args: CaseNotesComponent) => ({
  component: CaseNotesComponent,
  props: args,
  template: `<div style="padding: 1rem;">` + srcCode + `</div>`
});


const notesJSON = undefined
const application = 'um_intake_ui';
const hscId = 18112;
const readOnly = false;
const summaryViewOnly = false;
export const CaseNotes = Template.bind({});

CaseNotes.storyName = 'Case Notes';
CaseNotes.args = {
  application,
  notesJSON,
  readOnly,
  summaryViewOnly,
  hscId
};
CaseNotes.parameters  = {
  docs: {
    source: {
      code: srcCode
    }
  }
};
