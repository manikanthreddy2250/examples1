// Imports
import {Story, Meta, moduleMetadata} from '@storybook/angular';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {CasetypeComponent} from '../../projects/component-library/src/lib/um-components/casetype/casetype.component';
import {CasetypeModule} from '../../projects/component-library/src/lib/um-components/casetype/casetype.component.module';
import {RouterModule} from "@angular/router";
import { MenuPopupModule } from '@ecp/angular-ui-component-library/menu-popup';

// Default NgModule
export default {
  title: 'UM Components/Casetype',
  component: CasetypeComponent,
  decorators: [
    moduleMetadata({
      imports: [
        BrowserModule,
        BrowserAnimationsModule,
        CasetypeModule,
        MenuPopupModule,
        RouterModule.forRoot([], { useHash: true })
      ],
      providers: []
    }),
  ],
  argTypes: {
    ngOnInit: {
      table: {
        disable: true
      }
    }
  },
  parameters: {
    docs: {
      description: {
        component: `CaseType component shows the caseType details associated with a case (HSC ID).
        Developers can pass in a caseType JSON object to avoid retrieving caseType data, or pass in an HSC ID to allow this component to retrieve caseType data.
        Development in progress.

        CaseType Implementation

           This component has 4 input fields:

        1. caseTypeDetailsJSON: JSON object containing CaseType data to populate the UI.
            Here is a sample data structure for CaseType:
            Request for Inpatient and Outpatient Facility
              {
                  "hsc_id": 19006,
                  "hsc_sts_ref_id": 19274,
                  "rev_prr_ref_id": 3754,
                  "rev_prr_ref_cd": {
                    "ref_id": 3754,
                    "ref_dspl": "Routine"
                  },
                  "srvc_set_ref_id": 3737,
                  "srvc_set_ref_cd": {
                    "ref_id": 3737,
                    "ref_dspl": "Inpatient"
                  },
                  "hsc_facls": [
                    {
                      "plsrv_ref_id": 3743,
                      "plsrv_ref_cd": {
                        "ref_id": 3743,
                        "ref_dspl": "Acute Hospital"
                      },
                      "srvc_desc_ref_id": 4347,
                      "srvc_desc_ref_cd": {
                        "ref_id": 4347,
                        "ref_dspl": "Scheduled"
                      },
                      "srvc_dtl_ref_id": 4296,
                      "srvc_dtl_ref_cd": {
                        "ref_id": 4296,
                        "ref_dspl": "Medical"
                      },
                      "actul_admis_dttm": "2021-03-21T00:00:00",
                      "actul_dschrg_dttm": "2021-03-22T00:00:00",
                      "expt_admis_dt": "2021-03-02",
                      "expt_dschrg_dt": "2021-03-04"
                    }
                  ]
                };
                Request for OutPatient:
                {
                  "hsc_id": 18936,
                  "hsc_sts_ref_id": 19274,
                  "hsc_sts_ref_cd": {
                    "ref_dspl": "Draft"
                  },
                  "rev_prr_ref_id": 3755,
                  "rev_prr_ref_cd": {
                    "ref_id": 3755,
                    "ref_dspl": "Urgent"
                  },
                  "srvc_set_ref_id": 3738,
                  "srvc_set_ref_cd": {
                    "ref_id": 3738,
                    "ref_dspl": "Outpatient"
                  },
                  "hsc_srvcs": [
                    {
                      "hsc_srvc_non_facls": [
                        {
                          "plsrv_ref_id": 3746,
                          "plsrv_ref_cd": {
                            "ref_id": 3746,
                            "ref_dspl": "Ambul Surgical Centr"
                          },
                          "srvc_desc_ref_id": 4348,
                          "srvc_desc_ref_cd": {
                            "ref_id": 4348,
                            "ref_dspl": "Urgent"
                          }
                        }
                      ]
                    }
                  ]
                }

        2. hscID: hscID for retrieving caseType data from a case.

        3. application: Name of the consuming application. Used for retrieving configurations.

        4. version: Version of the consuming application. Used for retrieving configurations.

        5. readOnly - Will show a readOnly view for the um-intake-ui when true

        6. isSummary - Will show a summary view for the um-intake-ui when true

        7. showDetailsView: True by default, when set to false along with readOnly and isSummary it will show the um-case-wf card with modal

        Integration

        1. Import CasetypeModule into your module.ts file:

           import { CasetypeModule } from '@ecp/angular-ui-component-library';

        2. Add the CasetypeModule to the @NgModule({..}) imports array.

        3. Create a component using the <app-casetype-component></app-casetype-component> selector tag.
        `
      }
    },
  }
} as Meta;


const Template: Story<CasetypeComponent> = (args: CasetypeComponent) => ({
  component: CasetypeComponent,
  props: args,
  template: `
    <div style="padding: 1rem;">
        <app-casetype-component [application]="application"
                                [hscID]="hscID"
                                [version]="version"
                                [readOnly] = "readOnly"
                                [caseTypeDetails]="caseTypeDetails"
                                [isSummary]="isSummary"
                                [showDetailsView]="showDetailsView"
        ></app-casetype-component>
    </div>
  `
});

let hscID = null;
let isSummary = false;
const readOnly = false;
const application = 'case_wf_mgmt_ui';
const version = '1.0.0';
let caseTypeDetails = null;
let showDetailsView = true;

const standardCode = `
 <app-casetype-component [application]="application" [version]="version"
                                [hscID]="hscID"
                                [readOnly] = "readOnly"
                                [caseTypeDetails]="caseTypeDetails"
                                [isSummary]="isSummary"
                                [showDetailsView]="showDetailsView">
</app-casetype-component>
`;

export const CaseType = Template.bind({});

CaseType.storyName = 'Case Type';
CaseType.args = {
  hscID,
  caseTypeDetails,
  readOnly,
  application,
  version,
  isSummary,
  showDetailsView
};

CaseType.parameters = {
  docs: {
    source: {
      code: standardCode
    }
  }
};
