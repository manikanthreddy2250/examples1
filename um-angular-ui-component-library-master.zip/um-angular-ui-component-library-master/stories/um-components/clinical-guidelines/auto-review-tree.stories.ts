import {Story, Meta, moduleMetadata} from '@storybook/angular';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {RouterModule} from '@angular/router';
import { AutoReviewTreeComponent } from '../../../projects/component-library/src/lib/um-components/clinical-guidelines/auto-review-tree/auto-review-tree.component';
import { AutoReviewTreeModule } from '../../../projects/component-library/src/lib/um-components/clinical-guidelines/auto-review-tree/auto-review-tree.module';

export default {
  title: 'UM Components/D&G Components/Auto Review Tree Component',
  component: AutoReviewTreeComponent,
  decorators: [
    moduleMetadata({
      imports: [
        BrowserModule,
        BrowserAnimationsModule,
        AutoReviewTreeModule,
        RouterModule.forRoot([], { useHash: true })
      ],
      providers: []
    }),
  ],
  argTypes: {
    ngOnInit: {
      table: {
        disable: true
      }
    }
  },
  parameters: {
    docs: {
      description: {
        component: `Auto Review Tree `
      }
    },
  }
} as Meta;


const Template: Story<AutoReviewTreeComponent> = (args: AutoReviewTreeComponent) => ({
  component: AutoReviewTreeComponent,
  props: args,
  template: `
    <div style="padding: 1rem;">
        <um-auto-review-tree  [hscId]="hscId" [guidelineId]="guidelineId" [version]="version" [processTaskExecutionID]="processTaskExecutionID" [reviewId]="reviewId">
        </um-auto-review-tree>
    </div>
  `
});

const hscId = 12908;
const guidelineId = 'AISD0147';
const version = 'RM20';
const reviewId = '50906d70-1c86-48d5-86c0-89a4eff6a33c';
const processTaskExecutionID = '12345';
const standardCode = `
// Import AutoReviewTreeModule into your module.ts file.
import {AutoReviewTreeModule} from 'src/lib/clinical-guidelines-component/auto-review-tree/auto-review-tree.module';

@NgModule({
  import: [
    AutoReviewTreeModule,
  ]
})

// Create a component using the <um-auto-review-tree></um-auto-review-tree> selector tag

<um-auto-review-tree  [hscId]="hscId"  [guidelineId]="guidelineId" [version]="version" [processTaskExecutionID]="processTaskExecutionID" [reviewId]="reviewId">
</um-auto-review-tree>
`;

export const AutoReviewTreeView = Template.bind({});
AutoReviewTreeView.args = {
    hscId, processTaskExecutionID, reviewId , guidelineId , version
};

AutoReviewTreeView.parameters = {
  docs: {
    source: {
      code: standardCode
    }
  }
};

