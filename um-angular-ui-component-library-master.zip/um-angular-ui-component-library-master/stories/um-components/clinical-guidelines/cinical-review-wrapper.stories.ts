import {Story, Meta, moduleMetadata} from '@storybook/angular';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {RouterModule} from "@angular/router";
import { MedicalReviewTreeComponent } from '../../../projects/component-library/src/lib/um-components/clinical-guidelines/medical-review-tree/medical-review-tree.component';
import { MedicalReviewTreeModule } from 'projects/component-library/src/lib/um-components/clinical-guidelines/medical-review-tree/medical-review-tree.module';
import { GuidelinesBedDayModule } from '../../../projects/component-library/src/lib/um-components/clinical-guidelines/guidelines-bed-day-decision/guidelines-bed-day.module';
import { ClinicalReviewWrapperComponent } from '../../../projects/component-library/src/lib/um-components/clinical-guidelines/clinical-review-wrapper/clinical-review-wrapper.component';
import { FooterModule } from '../../../projects/component-library/src/lib/um-components/clinical-guidelines/footer/footer.module';
import { MedicalReviewsModule } from '../../../projects/component-library/src/lib/um-components/clinical-guidelines/medical-reviews/medical-reviews.module';
import { ClinicalReviewWrapperModule } from '../../../projects/component-library/src/lib/um-components/clinical-guidelines/clinical-review-wrapper/clinical-review-wrapper.module';
// import { GuidelineSummaryModule } from '../../projects/component-library/src/lib/um-components/guideline-summary/guideline-summary.module';

export default {
  title: 'UM Components/D&G Components',
  component: ClinicalReviewWrapperComponent,
  decorators: [
    moduleMetadata({
      imports: [
        BrowserModule,
        GuidelinesBedDayModule,
        ClinicalReviewWrapperModule,
        FooterModule,
        BrowserAnimationsModule,
        MedicalReviewTreeModule,
        RouterModule.forRoot([], { useHash: true })
      ],
      providers: []
    }),
  ],
  argTypes: {
    ngOnInit: {
      table: {
        disable: true
      }
    }
  },
  parameters: {
    docs: {
      description: {
        component: `Clinical Review Wrapper.
        `
      }
    },
  }
} as Meta;


const Template: Story<ClinicalReviewWrapperComponent> = (args: ClinicalReviewWrapperComponent) => ({
  component: ClinicalReviewWrapperComponent,
  props: args,
  template: `
    <div style="padding: 1rem;">
        <ecp-ucl-clinical-review-wrapper  [hscId]="hscId" [reviewId]="reviewId" [reviewData]="reviewData"  [application]="application">
        </ecp-ucl-clinical-review-wrapper>
    </div>
  `
});

const hscId = 11186;
const application = 'case_wf_mgmt_ui';
const reviewId = '';
const  reviewData = {
  isReadOnly: false,
  isTransitionPlan: false
};
const hscClinGuid = '1234';
const standardCode = `
// Import MedicalReviewTreeModule into your module.ts file.
import { ClinicalReviewWrapperModule } from 'src/lib/um-components/clinical-review-wrapper/clinical-review-wrapper.module';

@NgModule({
  import: [
    ClinicalReviewWrapperModule
  ]
})

// Create a component using the <app-medical-review-tree></app-medical-review-tree> selector tag

<ecp-ucl-clinical-review-wrapper  [hscId]="hscId" [reviewId]="reviewId" [reviewData]="reviewData"  [application]="application">
        </ecp-ucl-clinical-review-wrapper>
`;

export const ClinicalReview = Template.bind({});
ClinicalReview.args = {
  hscId, application, reviewId, reviewData
};

ClinicalReview.parameters = {
  docs: {
    source: {
      code: standardCode
    }
  }
};

