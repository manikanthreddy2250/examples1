import { Story, Meta, moduleMetadata } from '@storybook/angular';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { GuidelineSummaryComponent } from 'projects/component-library/src/lib/um-components/clinical-guidelines/guideline-summary/guideline-summary.component';
import { GuidelineSummaryModule } from 'projects/component-library/src/lib/um-components/clinical-guidelines/guideline-summary/guideline-summary.module';
import { DocumentUtilityComponent } from 'projects/component-library/src/lib/um-components/clinical-guidelines/document-utility/document-utility.component';
import { DocumentUtilityModule } from 'projects/component-library/src/lib/um-components/clinical-guidelines/document-utility/document-utility.module';


export default {
  title: 'UM Components/D&G Components/Document Utiity Component',
  component: DocumentUtilityComponent,
  decorators: [
    moduleMetadata({
      imports: [
        BrowserModule,
        BrowserAnimationsModule,
        DocumentUtilityModule
      ],
      providers: []
    }),
  ],
  argTypes: {
    ngOnInit: {
      table: {
        disable: true
      }
    }
  },
  parameters: {
    docs: {
      description: {
        component: `DocumentUtility component .
        `
      }
    },
  }
} as Meta;


const Template: Story<DocumentUtilityComponent> = (args: DocumentUtilityComponent) => ({
  component: DocumentUtilityComponent,
  props: args,
});

const guidelineId = 'AISD0153';
// const processTaskExecutionID = '12345';
const version = 'RM21';
const standardCode = `

import {DocumentUtilityModule} from 'src/lib/um-components/clinical-guidelines/document-utility/document-utility.module';

@NgModule({
  import: [
    DocumentUtilityModule,
  ]
})

<ecp-ucl-guideline-summary
             [guidelineId]="guidelineId"
             [version]="version">
</ecp-ucl-guideline-summary>
`;

export const DocumentUtility = Template.bind({});

DocumentUtility.args = {
    // subjectId,
    // subjecTypeId
};

DocumentUtility.parameters = {
  docs: {
    source: {
      code: standardCode
    }
  }
};

