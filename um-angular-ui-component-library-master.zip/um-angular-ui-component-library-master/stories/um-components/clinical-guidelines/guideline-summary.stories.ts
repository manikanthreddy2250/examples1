import { Story, Meta, moduleMetadata } from '@storybook/angular';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { GuidelineSummaryComponent } from 'projects/component-library/src/lib/um-components/clinical-guidelines/guideline-summary/guideline-summary.component';
import { GuidelineSummaryModule } from 'projects/component-library/src/lib/um-components/clinical-guidelines/guideline-summary/guideline-summary.module';


export default {
  title: 'UM Components/D&G Components/Guideline Summary Component',
  component: GuidelineSummaryComponent,
  decorators: [
    moduleMetadata({
      imports: [
        BrowserModule,
        BrowserAnimationsModule,
        GuidelineSummaryModule
      ],
      providers: []
    }),
  ],
  argTypes: {
    ngOnInit: {
      table: {
        disable: true
      }
    }
  },
  parameters: {
    docs: {
      description: {
        component: `Guideline Summary component shows the summary associated to a guideline.
        `
      }
    },
  }
} as Meta;


const Template: Story<GuidelineSummaryComponent> = (args: GuidelineSummaryComponent) => ({
  component: GuidelineSummaryComponent,
  props: args,
});

const guidelineId = 'AISD0153';
// const processTaskExecutionID = '12345';
const version = 'RM21';
const standardCode = `

import {GuidelineSummaryModule} from 'src/lib/clinical-guidelines-component/guideline-summary/guideline-summary.module';

@NgModule({
  import: [
    GuidelineSummaryModule,
  ]
})

<ecp-ucl-guideline-summary
             [guidelineId]="guidelineId"
             [version]="version">
</ecp-ucl-guideline-summary>
`;

export const GuidelineSummary = Template.bind({});

GuidelineSummary.args = {
  guidelineId,
  version
};

GuidelineSummary.parameters = {
  docs: {
    source: {
      code: standardCode
    }
  }
};

