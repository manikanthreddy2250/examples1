import { Story, Meta, moduleMetadata } from '@storybook/angular';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { GuidelinesBedDayDecisionComponent } from "../../../projects/component-library/src/lib/um-components/clinical-guidelines/guidelines-bed-day-decision/guidelines-bed-day-decision.component";
import {GuidelinesBedDayModule} from '../../../projects/component-library/src/lib/um-components/clinical-guidelines/guidelines-bed-day-decision/guidelines-bed-day.module';


export default {
  title: 'UM Components/D&G Components/Bed Day Component',
  component: GuidelinesBedDayDecisionComponent,
  decorators: [
    moduleMetadata({
      imports: [
        BrowserModule,
        BrowserAnimationsModule,
        GuidelinesBedDayModule
      ],
      providers: []
    }),
  ],
  argTypes: {
    ngOnInit: {
      table: {
        disable: true
      }
    }
  },
  parameters: {
    docs: {
      description: {
        component: `Bed Day Decision component shows the bed day record got associated to a case.
        `
      }
    },
  }
} as Meta;


const Template: Story<GuidelinesBedDayDecisionComponent> = (args: GuidelinesBedDayDecisionComponent) => ({
  component: GuidelinesBedDayDecisionComponent,
  props: args,
});

const bedDayDetailsJSON = {};
const hscID = '12675';
const hscClinGuidID = '1688';
const processTaskExecutionID = '12345';
const application = 'clinical_guidelines_ui';
const version = '1.0.0';
const reviewId = '0bdd7028-e568-4157-be9a-5877a6de9013';
const isCompleteReviewFlag:boolean = false
const isAutoReviewFlag:boolean = false
const standardCode = `
<ecp-ucl-bed-day-decision [bedDayDetailsJSON]="bedDayDetailsJSON"
             [hscID]="hscID"
             [hscClinGuidID]="hscClinGuidID"
             [processTaskExecutionID]="processTaskExecutionID"
             [application]="appName"
             [version]="version"
             [reviewId]="reviewId"
             [isCompleteReviewFlag]="isCompleteReviewFlag"
             [isAutoReviewFlag]="isAutoReviewFlag"
             [noteText]="'noteText">
</ecp-ucl-bed-day-decision>
`;

export const BedDay = Template.bind({});

BedDay.args = {
  // bedDayDetailsJSON,
  hscClinGuidID,
  hscID,
  processTaskExecutionID,
  application,
  version,
  reviewId,
  isCompleteReviewFlag,
  isAutoReviewFlag
};

BedDay.parameters = {
  docs: {
    source: {
      code: standardCode
    }
  }
};

