import {Story, Meta, moduleMetadata} from '@storybook/angular';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { RouterModule } from '@angular/router';
import {MedicalReviewCommentsComponent} from '../../../projects/component-library/src/lib/um-components/clinical-guidelines/medical-review-comments/medical-review-comments.component';
import {MedicalReviewCommentsModule} from '../../../projects/component-library/src/lib/um-components/clinical-guidelines/medical-review-comments/medical-review-comments.module';


export default {
  title: 'UM Components/D&G Components/Medical Review Comment',
  component: MedicalReviewCommentsComponent,
  decorators: [
    moduleMetadata({
      imports: [
        BrowserModule,
        BrowserAnimationsModule,
        MedicalReviewCommentsModule,
        RouterModule.forRoot([], { useHash: true })
      ],
      providers: []
    }),
  ],
  argTypes: {
    ngOnInit: {
      table: {
        disable: true
      }
    }
  },
  parameters: {
    docs: {
      description: {
        component: `Medical Review Comment`
      }
    },
  }
} as Meta;


const Template: Story<MedicalReviewCommentsComponent> = (args: MedicalReviewCommentsComponent) => ({
  component: MedicalReviewCommentsComponent,
  props: args,
  template: `
    <div style="padding: 1rem;">
        <lib-comments-component  [commentModalData]="commentModalData"
                [processTaskExecutionID]="processTaskExecutionID" >
        </lib-comments-component>
    </div>
  `
});


const standardCode = `
// Import MedicalReviewCommentsModule into your module.ts file.
import { MedicalReviewCommentsModule } from '@ecp/um-angular-ui-component-library';

// Add the MedicalReviewCommentsModule to the @NgModule({..}) imports array.

@NgModule({
  import: [
    ...,
    MedicalReviewCommentsModule,
  ]
})

// Create a component using the <lib-comments-component></lib-comments-component> selector tag

<lib-comments-component
                [commentModalData]="commentModalData"
                [processTaskExecutionID]="processTaskExecutionID" >
</lib-comments-component>
`;

const processTaskExecutionID = '12345';
const commentModalData = {
  cp: {
  linkId: 'AISD0153040102020401',
    text: 'Difficulty taking PO',
    type: 'boolean',
    repeats: false,
    readOnly: true,
    item: []
}, show: true
};

export const MedicalReviewCommentsView = Template.bind({});

MedicalReviewCommentsView.args = {
  commentModalData , processTaskExecutionID
};

MedicalReviewCommentsView.parameters = {
  docs: {
    source: {
      code: standardCode
    }
  }
};

