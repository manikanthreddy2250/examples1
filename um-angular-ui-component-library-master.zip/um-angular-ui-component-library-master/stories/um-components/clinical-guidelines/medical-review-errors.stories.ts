import { Story, Meta, moduleMetadata } from '@storybook/angular';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {OAuthLogger} from 'angular-oauth2-oidc';
import { MedicalReviewErrorsModule } from 'projects/component-library/src/lib/um-components/clinical-guidelines/medical-review-errors/medical-review-errors.module';
import { MedicalReviewErrorsComponent } from 'projects/component-library/src/lib/um-components/clinical-guidelines/medical-review-errors/medical-review-errors.component';


export default {
  title: 'UM Components/D&G Components/Medical Review Errors Component',
  component: MedicalReviewErrorsComponent,
  decorators: [
    moduleMetadata({
      imports: [
        FormsModule,
        ReactiveFormsModule,
        BrowserModule,
        BrowserAnimationsModule,
        MedicalReviewErrorsModule,
        RouterModule.forRoot([], { useHash: true })
      ],
      providers: [OAuthLogger]
    }),
  ],
  argTypes: {
    ngOnInit: {
      table: {
        disable: true
      }
    }
  },
  parameters: {
    docs: {
      description: {
        component: `Medical Review Errors`
      }
    },
  }
} as Meta;


const Template: Story<MedicalReviewErrorsComponent> = (args: MedicalReviewErrorsComponent) => ({
  component: MedicalReviewErrorsComponent,
  props: args,
  template: `
    <div style="padding: 1rem;">
        <um-medical-review-errors [errorModel]="errorModel" [processTaskExecutionID]="processTaskExecutionID">
        </um-medical-review-errors>
    </div>
  `
});

const errorModel = {
  status: '400',
  message: 'Bad Request',
  show: true
};
const processTaskExecutionID = '12345';

const standardCode = `
<um-medical-review-errors [errorModel]="errorModel" [processTaskExecutionID]="processTaskExecutionID">
 </um-medical-review-errors>
`;

export const MedicalReviewErrorsView = Template.bind({});
MedicalReviewErrorsView.args = {
    errorModel,
  processTaskExecutionID
};

MedicalReviewErrorsView.parameters = {
  docs: {
    source: {
      code: standardCode
    }
  }
};

