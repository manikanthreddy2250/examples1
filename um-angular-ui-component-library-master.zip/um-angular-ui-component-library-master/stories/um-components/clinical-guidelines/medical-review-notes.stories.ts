import { Story, Meta, moduleMetadata } from '@storybook/angular';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {MedicalReviewNotesComponent} from '../../../projects/component-library/src/lib/um-components/clinical-guidelines/medical-review-notes/medical-review-notes.component';
import {MedicalReviewNotesModule} from '../../../projects/component-library/src/lib/um-components/clinical-guidelines/medical-review-notes/medical-review-notes.module';
import {OAuthLogger} from 'angular-oauth2-oidc';

export default {
  title: 'UM Components/D&G Components/Medical Review Notes Component',
  component: MedicalReviewNotesComponent,
  decorators: [
    moduleMetadata({
      imports: [
        FormsModule,
        ReactiveFormsModule,
        BrowserModule,
        BrowserAnimationsModule,
        MedicalReviewNotesModule,
        RouterModule.forRoot([], { useHash: true })
      ],
      providers: [OAuthLogger]
    }),
  ],
  argTypes: {
    ngOnInit: {
      table: {
        disable: true
      }
    }
  },
  parameters: {
    docs: {
      description: {
        component: `Medical Review Notes`
      }
    },
  }
} as Meta;


const Template: Story<MedicalReviewNotesComponent> = (args: MedicalReviewNotesComponent) => ({
  component: MedicalReviewNotesComponent,
  props: args,
  template: `
    <div style="padding: 1rem;">
        <lib-medical-review-notes [notesModel]="notesModel" [processTaskExecutionID]="processTaskExecutionID">
        </lib-medical-review-notes>
    </div>
  `
});

const notesModel = {
  subset_unique_id: '353625',
  id: 'AISD01530401',
  note_type: 'ALL_NOTES',
  parent_id: '',
  show: true
};
const processTaskExecutionID = '12345';

const standardCode = `
<lib-medical-review-notes [notesModel]="notesModel" [processTaskExecutionID]="processTaskExecutionID">
 </lib-medical-review-notes>
`;

export const MedicalReviewNotesView = Template.bind({});
MedicalReviewNotesView.args = {
  notesModel,
  processTaskExecutionID
};

MedicalReviewNotesView.parameters = {
  docs: {
    source: {
      code: standardCode
    }
  }
};

