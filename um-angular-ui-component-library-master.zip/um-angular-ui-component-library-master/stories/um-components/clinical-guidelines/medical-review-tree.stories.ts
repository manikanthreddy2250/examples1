import {Story, Meta, moduleMetadata} from '@storybook/angular';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {RouterModule} from "@angular/router";
import { MedicalReviewTreeComponent } from '../../../projects/component-library/src/lib/um-components/clinical-guidelines/medical-review-tree/medical-review-tree.component';
import { MedicalReviewTreeModule } from '../../../projects/component-library/src/lib/um-components/clinical-guidelines/medical-review-tree/medical-review-tree.module';

export default {
  title: 'UM Components/D&G Components/Medical Review Tree Component',
  component: MedicalReviewTreeComponent,
  decorators: [
    moduleMetadata({
      imports: [
        BrowserModule,
        BrowserAnimationsModule,
        MedicalReviewTreeModule,
        RouterModule.forRoot([], { useHash: true })
      ],
      providers: []
    }),
  ],
  argTypes: {
    ngOnInit: {
      table: {
        disable: true
      }
    }
  },
  parameters: {
    docs: {
      description: {
        component: `For nested decision tree (NDT) scenarios:<br>
        Select the episode day or, if applicable, the review type.<br>
        Select the criteria points as indicated in the clinical scenario.<br>
        Check for the criteria status met or not based on the criteria points selected.
        `
      }
    },
  }
} as Meta;


const Template: Story<MedicalReviewTreeComponent> = (args: MedicalReviewTreeComponent) => ({
  component: MedicalReviewTreeComponent,
  props: args,
  template: `
    <div style="padding: 1rem;">
        <um-medical-review-tree  [hscId]="hscId" [guidelineId]="guidelineId" [isAutoReview]="isAutoReview" [version]="version" [processTaskExecutionID]="processTaskExecutionID" [reviewId]="reviewId" [isCompleteReviewFlag]="isCompleteReviewFlag">
        </um-medical-review-tree>
    </div>
  `
});

const hscId = 12908;
const guidelineId = 'AISD0153';
const version = 'RM21';
const reviewId = '';
const isAutoReview = false;
const processTaskExecutionID = '12345';
const isCompleteReviewFlag = false;
const standardCode = `
// Import MedicalReviewTreeModule into your module.ts file.
import {MedicalReviewTreeModule} from 'src/lib/clinical-guidelines-component/medical-review-tree/medical-review-tree.module';

@NgModule({
  import: [
    MedicalReviewTreeModule,
  ]
})

// Create a component using the <app-medical-review-tree></app-medical-review-tree> selector tag

<app-medical-review-tree  [hscId]="hscId" [guidelineId]="guidelineId" [isAutoReview]="isAutoReview" [version]="version" [processTaskExecutionID]="processTaskExecutionID" [reviewId]="reviewId" [isCompleteReviewFlag]="isCompleteReviewFlag">
</app-medical-review-tree>
`;

export const MedicalReviewTreeView = Template.bind({});
MedicalReviewTreeView.args = {
  hscId, version, guidelineId, processTaskExecutionID, reviewId, isCompleteReviewFlag, isAutoReview
};

MedicalReviewTreeView.parameters = {
  docs: {
    source: {
      code: standardCode
    }
  }
};

