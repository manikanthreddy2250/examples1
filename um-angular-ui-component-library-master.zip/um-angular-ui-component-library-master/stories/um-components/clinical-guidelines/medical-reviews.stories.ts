import {Story, Meta, moduleMetadata} from '@storybook/angular';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MedicalReviewsComponent} from '../../../projects/component-library/src/lib/um-components/clinical-guidelines/medical-reviews/medical-reviews.component';
import {MedicalReviewsModule} from '../../../projects/component-library/src/lib/um-components/clinical-guidelines/medical-reviews/medical-reviews.module';

// Default NgModule
export default {
  title: 'UM Components/D&G Components/Medical Reviews Summary Component',
  component: MedicalReviewsComponent,
  decorators: [
    moduleMetadata({
      imports: [
        BrowserModule,
        BrowserAnimationsModule,
        MedicalReviewsModule
      ],
      providers: []
    }),
  ],
  argTypes: {
    ngOnInit: {
      table: {
        disable: true
      }
    }
  },
  parameters: {
    docs: {
      description: {
        component: `medical reviews component shows the list of medical reviews.
        Development in progress.
        `
      }
    },
  }
} as Meta;

//
const Template: Story<MedicalReviewsComponent> = (args: MedicalReviewsComponent) => ({
  component: MedicalReviewsComponent,
  props: args,
  template: `
    <div style="padding: 1rem;">
        <app-medical-reviews-component [hscId]="hscId" [application]="application" [processTaskExecutionID]="processTaskExecutionID" [hideCreateButton]="hideCreateButton">
        </app-medical-reviews-component>
    </div>
  `
});

const hscId = 11186;
const application = 'case_wf_mgmt_ui';
const processTaskExecutionID = '12345';
const hideCreateButton = false;

const standardCode = `
// Import MedicalReviewsModule into your module.ts file.
import {MedicalReviewsModule} from '../../lib/um-components/medical-reviews/medical-reviews-component.module';

@NgModule({
  import: [
    MedicalReviewsModule
  ]
})

// Create a component using the <app-medical-reviews-component [hscId]="hscId" [application]="application" ></app-medical-reviews-component> selector tag

<app-medical-reviews-component [hscId]="hscId" [hideCreateButton]="hideCreateButton" >
</app-medical-reviews-component>
`;

export const MedicalReviewsView = Template.bind({});

// @ts-ignore
MedicalReviewsView.args = {
  hscId,
  application,
  processTaskExecutionID,
  hideCreateButton
};

MedicalReviewsView.parameters = {
  docs: {
    source: {
      code: standardCode
    }
  }
};
