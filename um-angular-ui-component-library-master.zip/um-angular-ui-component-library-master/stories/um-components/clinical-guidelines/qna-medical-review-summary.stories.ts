import {Story, Meta, moduleMetadata} from '@storybook/angular';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {QnaMedicalReviewSummaryModule} from '../../../projects/component-library/src/lib/um-components/clinical-guidelines/qna-medical-review-summary/qna-medical-review-summary.module';
import {RouterModule} from '@angular/router';
import {QnaMedicalReviewSummaryComponent} from '../../../projects/component-library/src/lib/um-components/clinical-guidelines/qna-medical-review-summary/qna-medical-review-summary.component';


export default {
  title: 'UM Components/D&G Components/Q&A Medical Review Summary Component',
  component: QnaMedicalReviewSummaryComponent,
  decorators: [
    moduleMetadata({
      imports: [
        BrowserModule,
        BrowserAnimationsModule,
        QnaMedicalReviewSummaryModule,
        RouterModule.forRoot([], {useHash: true})
      ],
      providers: []
    }),
  ],
  argTypes: {
    ngOnInit: {
      table: {
        disable: true
      }
    }
  },
  parameters: {
    docs: {
      description: {
        component: ``
      }
    },
  }
} as Meta;


const Template: Story<QnaMedicalReviewSummaryComponent> = (args: QnaMedicalReviewSummaryComponent) => ({
  component: QnaMedicalReviewSummaryComponent,
  props: args,
  template: `
    <div style="padding: 1rem;">
        <guidelines-qna-medical-review-summary [reviewID]="reviewID">
        </guidelines-qna-medical-review-summary>
    </div>
  `
});

const standardCode = `
// Import SubsetSearchModule into your module.ts file.
import { QnaMedicalReviewModule } from '../../lib/um-components/qna-medical-review/qna-medical-review.component.module'

@NgModule({
  import: [
    QnaMedicalReviewSummaryModule,
  ]
})

// Create a component using the <guidelines-qna-medical-review-summary></guidelines-qna-medical-review-summary> selector tag

 <guidelines-qna-medical-review-summary [reviewID]="reviewID">
 </guidelines-qna-medical-review-summary>
`;

const reviewID = 'f2f1b054-b901-40af-9c6a-00dc5378d43b';

export const QnaMedicalReviewSummaryView = Template.bind({});
QnaMedicalReviewSummaryView.args = {
  reviewID
};

QnaMedicalReviewSummaryView.parameters = {
  docs: {
    source: {
      code: standardCode
    }
  }
};
