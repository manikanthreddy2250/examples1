import {Story, Meta, moduleMetadata} from '@storybook/angular';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { QnaMedicalReviewComponent } from '../../../projects/component-library/src/lib/um-components/clinical-guidelines/qna-medical-review/qna-medical-review.component';
import { QnaMedicalReviewModule } from '../../../projects/component-library/src/lib/um-components/clinical-guidelines/qna-medical-review/qna-medical-review.module';
import {RouterModule} from '@angular/router';


export default {
  title: 'UM Components/D&G Components/Q&A Medical Review Component',
  component: QnaMedicalReviewComponent,
  decorators: [
    moduleMetadata({
      imports: [
        BrowserModule,
        BrowserAnimationsModule,
        QnaMedicalReviewModule,
        RouterModule.forRoot([], { useHash: true })
      ],
      providers: []
    }),
  ],
  argTypes: {
    ngOnInit: {
      table: {
        disable: true
      }
    }
  },
  parameters: {
    docs: {
      description: {
        component: `SubsetSearch component shows the services associated with a guideline (HSC ID).
        Developers can pass in a SubsetSearch JSON object to avoid retrieving SubsetSearch data, or pass in an HSC ID to allow this component to retrieve SubsetSearch data.

        SubsetSearch Implementation

           This component has 5 input fields:

        1. subsetSearchDetailsJSON: JSON object containing procedure data to populate the UI.

             Sample Json Structue :
             [{
              "versionDesc":"InterQual 2020",
              "productDesc":"LOC:Acute Adult",
              "description": "Infection: General"
              }]

        2. hscID: hscID for retrieving Procedure data from a case.

        3. envID: envID for consuming app (should be 'LCL', 'DEV', 'TEST', 'STG' or 'PROD').

        4. application: Name of the consuming application. Used for retrieving configurations.

        5. version: Version of the consuming application. Used for retrieving configurations.


        Integration

        1. Import SubsetSearchModule into your module.ts file:

           import { SubsetSearchModule } from '@ecp/angular-ui-component-library';

        2. Add the SubsetSearchModule to the @NgModule({..}) imports array.

        3. Create a component using the <guidelines-qna-medical-review></guidelines-qna-medical-review> selector tag.
        `
      }
    },
  }
} as Meta;


const Template: Story<QnaMedicalReviewComponent> = (args: QnaMedicalReviewComponent) => ({
  component: QnaMedicalReviewComponent,
  props: args,
  template: `
    <div style="padding: 1rem;">
        <guidelines-qna-medical-review [guidelineId]="guidelineId" [ver]="ver">
        </guidelines-qna-medical-review>
    </div>
  `
});

const standardCode = `
// Import SubsetSearchModule into your module.ts file.
import { QnaMedicalReviewModule } from '../../lib/um-components/qna-medical-review/qna-medical-review.component.module'

@NgModule({
  import: [
    QnaMedicalReviewModule,
  ]
})

// Create a component using the <guidelines-qna-medical-review></guidelines-qna-medical-review> selector tag

 <guidelines-qna-medical-review [guidelineId]="guidelineId" [ver]="ver">
 </guidelines-qna-medical-review>
`;

const guidelineId = '~IQ6.01A_17056';
const ver = 'RM21';

export const QnaMedicalReviewView = Template.bind({});
QnaMedicalReviewView.args = {
  guidelineId, ver
};

QnaMedicalReviewView.parameters = {
  docs: {
    source: {
      code: standardCode
    }
  }
};
