import { Story, Meta, moduleMetadata } from '@storybook/angular';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ReviewSummaryReportComponent } from '../../../projects/component-library/src/lib/um-components/clinical-guidelines/review-summary-report/review-summary-report.component';
import { ReviewSummaryReportModule } from '../../../projects/component-library/src/lib/um-components/clinical-guidelines/review-summary-report/review-summary-report.module';



export default {
  title: 'UM Components/D&G Components/Review Summary Report',
  component: ReviewSummaryReportComponent,
  decorators: [
    moduleMetadata({
      imports: [
        BrowserModule,
        BrowserAnimationsModule,
        ReviewSummaryReportModule
      ],
      providers: []
    }),
  ],
  argTypes: {
    ngOnInit: {
      table: {
        disable: true
      }
    }
  },
  parameters: {
    docs: {
      description: {
        component: `Review Summary Report component shows the bed day record got associated to a case.
        `
      }
    },
  }
} as Meta;


const Template: Story<ReviewSummaryReportComponent> = (args: ReviewSummaryReportComponent) => ({
  component: ReviewSummaryReportComponent,
  props: args,
});

// const bedDayDetailsJSON = {};
// const hscID = '12675';
// const hscClinGuidID = '1688';
// const processTaskExecutionID = '12345';
// const application = 'clinical_guidelines_ui';
// const version = '1.0.0';
const reviewId = '0bdd7028-e568-4157-be9a-5877a6de9013';

const standardCode = `
<ecp-ucl-review-summary-report [reviewId]="reviewId"></ecp-ucl-review-summary-report>
`;

export const ReviewSummaryReportView = Template.bind({});

ReviewSummaryReportView.args = {
  reviewId
};

ReviewSummaryReportView.parameters = {
  docs: {
    source: {
      code: standardCode
    }
  }
};
