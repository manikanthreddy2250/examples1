import {Story, Meta, moduleMetadata} from '@storybook/angular';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {RouterModule} from "@angular/router";
import { SmartsheetModule } from 'projects/component-library/src/lib/um-components/clinical-guidelines/smartsheet/smartsheet.module';
import { SmartsheetComponent } from 'projects/component-library/src/lib/um-components/clinical-guidelines/smartsheet/smartsheet.component';

export default {
  title: 'UM Components/D&G Components/SmartSheet Component',
  component: SmartsheetComponent,
  decorators: [
    moduleMetadata({
      imports: [
        BrowserModule,
        BrowserAnimationsModule,
        SmartsheetModule,
        RouterModule.forRoot([], { useHash: true })
      ],
      providers: []
    }),
  ],
  argTypes: {
    ngOnInit: {
      table: {
        disable: true
      }
    }
  },
  parameters: {
    docs: {
      description: {
        component: `SmartSheets<br>
        `
      }
    },
  }
} as Meta;


const Template: Story<SmartsheetComponent> = (args: SmartsheetComponent) => ({
  component: SmartsheetComponent,
  props: args,
  template: `
    <div style="padding: 1rem;">
        <um-smartsheet  [subsetId]="subsetId" [processTaskExecutionID]="processTaskExecutionID">
        </um-smartsheet>
    </div>
  `
});

const subsetId = 370893;
const processTaskExecutionID = '12345';
const standardCode = `
// Import SmartsheetModule into your module.ts file.
import { SmartsheetModule } from 'projects/component-library/src/lib/um-components/clinical-guidelines/smartsheet/smartsheet.module';

@NgModule({
  import: [
    SmartsheetModule,
  ]
})

// Create a component using the <um-smartsheet></um-smartsheet> selector tag

<um-smartsheet  [subsetId]="subsetId" [processTaskExecutionID]="processTaskExecutionID">
</um-smartsheet>
`;

export const SmartSheetView = Template.bind({});
SmartSheetView.args = {
    subsetId, processTaskExecutionID
};

SmartSheetView.parameters = {
  docs: {
    source: {
      code: standardCode
    }
  }
};

