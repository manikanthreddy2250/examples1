// Imports
import {Story, Meta, moduleMetadata} from '@storybook/angular';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {RouterModule} from "@angular/router";
import { MenuPopupModule } from '@ecp/angular-ui-component-library/menu-popup';
import {ContactsComponent} from "../../projects/component-library/src/lib/um-components/contacts/contacts.component";
import {ContactsModule} from "../../projects/component-library/src/lib/um-components/contacts/contacts.component.module";

// Default NgModule
export default {
  title: 'UM Components/Contacts',
  component: ContactsComponent,
  decorators: [
    moduleMetadata({
      imports: [
        BrowserModule,
        BrowserAnimationsModule,
        ContactsModule,
        MenuPopupModule,
        RouterModule.forRoot([], { useHash: true })
      ],
      providers: []
    }),
  ],
  argTypes: {
    ngOnInit: {
      table: {
        disable: true
      }
    }
  },
  parameters: {
    docs: {
      description: {
        component: `Contacts component allows user to add Contact details .
        Development in progress.
        `
      }
    },
  }
} as Meta;


const Template: Story<ContactsComponent> = (args: ContactsComponent) => ({
  component: ContactsComponent,
  props: args,
  template: `
    <div style="padding: 1rem;">
        <app-contacts-component [application]="application" [readOnly]="readOnly" [summaryViewOnly]="summaryViewOnly" [hscId]="hscId" [contactDetailsJSON]="contactDetailsJSON"></app-contacts-component>
    </div>
  `
});

const readOnly = true;
const summaryViewOnly = false;
let hscId = 22249;
const application = 'um_intake_ui';
const version = '1.0.0';
let contactDetailsJSON = [];

export const ContactsView = Template.bind({});
ContactsView.storyName = 'Contacts Component';
ContactsView.args = {
  hscId,application,readOnly, summaryViewOnly,contactDetailsJSON
};
