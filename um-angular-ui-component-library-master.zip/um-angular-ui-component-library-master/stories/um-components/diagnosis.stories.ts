// Imports
import {Story, Meta, moduleMetadata} from '@storybook/angular';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {DiagnosisComponent} from '../../projects/component-library/src/lib/um-components/diagnosis/diagnosis.component';
import {DiagnosisModule} from '../../projects/component-library/src/lib/um-components/diagnosis/diagnosis.component.module';
import {RouterModule} from "@angular/router";

// Default NgModule
export default {
  title: 'UM Components/Diagnosis',
  component: DiagnosisComponent,
  decorators: [
    moduleMetadata({
      imports: [
        BrowserModule,
        BrowserAnimationsModule,
        DiagnosisModule,
        RouterModule.forRoot([], { useHash: true })
      ],
      providers: []
    }),
  ],
  argTypes: {
    ngOnInit: {
      table: {
        disable: true
      }
    }
  },
  parameters: {
    docs: {
      description: {
        component: `Diagnosis component shows the services associated with a case (HSC ID).
        Developers can pass in a Diagnosis JSON object to avoid retrieving Diagnosis data, or pass in an HSC ID to allow this component to retrieve Diagnosis data.

        Diagnosis Implementation

           This component has 7 input fields:

        1. diagnosisDetailsJSON: JSON object containing diagnosis data to populate the UI. 
              Example: {
                "user_fav": [{}],
                "hsc_diag" : [
                      {
                          "hsc_diag_id": 3089,
                          "diag_cd": "R51",
                          "diag_desc": "HEADACHE",
                          "diag_cd_schm_ref_id" :  3330,
                          "diag_cd_schm_ref_cd" :  {
                             "ref_dspl": "ICD10"
                          }
                      }
                    ]
                }

        2. hscId: hscId for retrieving Diagnosis data from a case.

        3. application: Name of the consuming application. Used for retrieving configurations.

        4. version: Version of the consuming application. Used for retrieving configurations.
        
        5. showDetailsView: Toggle between card and grid view
        
        6. readOnly: Read Only view where additions/updates are disabled
        
        7. summaryView: Partial readOnly view where adding new entries is not allowed but removing existing entries is allowed.
        
        
        


        Integration

        1. Import DiagnosisModule into your module.ts file:

           import { DiagnosisModule } from '@ecp/angular-ui-component-library';

        2. Add the DiagnosisModule to the @NgModule({..}) imports array.

        3. Create a component using the <app-diagnosis-component></app-diagnosis-component> selector tag.
        `
      }
    },
  }
} as Meta;

//
const Template: Story<DiagnosisComponent> = (args: DiagnosisComponent) => ({
  component: DiagnosisComponent,
  props: args,
  template: `
    <div style="padding: 1rem;">
        <app-diagnosis-component  
                [application]="application"
                [version]="version"
                [hscId]="hscId"
                [showDetailsView]="showDetailsView"
                [diagnosisData] = "diagnosisData"
                [diagnosisDetailsJSON]="diagnosisDetailsJSON"
                [readOnly]="readOnly"
                [summaryView]="summaryView">
        </app-diagnosis-component>
    </div>
  `
});

const application = 'case_wf_mgmt_ui';
const version = '1.0.0';
const hscId = 12916;
const showDetailsView = true;
const readOnly = false;
let diagnosisData = [];
const summaryView = false;
let diagnosisDetailsJSON = [];

const standardCode = `
// Import DiagnosisModule into your module.ts file.
import {DiagnosisModule} from '../../lib/um-components/diagnosis/diagnosis-component.module';

@NgModule({
  import: [
    DiagnosisModule,
  ]
})

// Create a component using the <app-diagnosis-component></app-diagnosis-component> selector tag

<app-diagnosis-component
                [application]="application"
                [version]="version"
                [hscId]="hscId"
                [showDetailsView]="showDetailsView"
                [diagnosisData] = "diagnosisData"
                [diagnosisDetailsJSON]="diagnosisDetailsJSON"
                [readOnly] = "readOnly"
                [summaryView]="summaryView"
                (viewAndUpdateButtonClicked)="viewAndUpdateButtonClicked($event)">
</app-diagnosis-component>
`;

export const DiagnosisView = Template.bind({});

// @ts-ignore
DiagnosisView.args = {
  application,
  version,
  hscId,
  showDetailsView,
  diagnosisData,
  diagnosisDetailsJSON,
  readOnly,
  summaryView
};

DiagnosisView.parameters = {
  docs: {
    source: {
      code: standardCode
    }
  }
};
