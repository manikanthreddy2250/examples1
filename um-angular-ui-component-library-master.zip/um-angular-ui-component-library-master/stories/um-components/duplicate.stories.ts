import { Story, Meta, moduleMetadata } from '@storybook/angular';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DuplicateComponent } from '../../projects/component-library/src/lib/um-components/duplicate/duplicate.component';
import { DuplicateModule } from '../../projects/component-library/src/lib/um-components/duplicate/duplicate.module';
import { RouterModule } from "@angular/router";


export default {
  title: 'UM Components/Duplicate',
  component: DuplicateComponent,
  decorators: [
    moduleMetadata({
      imports: [
        BrowserModule,
        BrowserAnimationsModule,
        DuplicateModule,
        RouterModule.forRoot([], { useHash: true })
      ],
      providers: []
    }),
  ],
  argTypes: {
    ngOnInit: {
      table: {
        disable: true
      }
    }
  },
  parameters: {
    docs: {
      description: {
        component: `Duplicate component shows the current case details on the left side of the page and potential duplicate cases on the right side of the page.
        Developers can pass in a duplicateDetailsJSON JSON object to populate member details, current case details and potential duplicate case details on the UI.

        Duplicate Implementation

          This component has 3 input fields:

        1. application: Name of the consuming application. Used for retrieving configurations.

        2. version: Version of the consuming application. Used for retrieving configurations.

        3. duplicateDetailsJSON: JSON structure to populate member details, current case details and potential duplicate case details.



          This component has 1 output method:

        1. continueButtonClicked(): Event emitted when the continue button is clicked.



        Integration

        1. Import DuplicateModule into your module.ts file:

           import { DuplicateModule } from '@ecp/angular-ui-component-library';

        2. Add the DuplicateModule to the @NgModule({..}) imports array.

        3. Create a component using the <um-duplicate></um-duplicate> selector tag.
        `
      }
    },
  }
} as Meta;

const Template: Story<DuplicateComponent> = (args: DuplicateComponent) => ({
  component: DuplicateComponent,
  props: args,
  template: `
    <div style="padding: 1rem;">
        <um-duplicate [application]="application"
                      [version]="version"
                      [duplicateDetailsJSON]="duplicateDetailsJSON">
        </um-duplicate>
    </div>
  `
});

const application = 'case_wf_mgmt_ui';
const version = '1.0.0';
const duplicateDetailsJSON = {
  currentCase: {
    submittingProviderDetails: {
      providerName: "Hogue Center",
      providerTaxID: "923827176"
    },
    facilityTypeDetails: {
      facilityType: "Acute Hospital",
      serviceDescription: "Emergency"
    },
    facilityProviderDetails: {
      facilityName: "Phoneix",
      taxID: 1234,
      admitDate: "08-22-2020",
      dischargeDate: "08-30-2020"
    },
    diagnosisDetails: [
      {
        diagnosisCode: "CBA312",
        diagnosisDescription: "Description for CBA312"
      },
      {
        diagnosisCode: "312CBA",
        diagnosisDescription: "Description for 312CBA"
      }
    ],
    procedureDetails: [
      {
        procedureCode: "BCA213",
        procedureDescription: "Description for BCA213",
        servicingProvider: "Baker",
        taxID: "1234"
      },
      {
        procedureCode: "213BCA",
        procedureDescription: "Description for 213BCA",
        servicingProvider: "Baker2",
        taxID: "1234"
      }
    ],
    initialContact: {
      name: "Roger",
      phone: "602-234-0989"
    },
    caseTypeDetails: {
      caseNumber: "19368",
      caseStatus: "OPEN"
    }
  },
  duplicateCases: [
    {
      memberDetails: {
        memberName: "Meyer, Matt",
        memberDOB: "07/22/1994",
        memberID: "16440436900"
      },
      submittingProviderDetails: {
        providerName: "Mc Connel James",
        providerTaxID: "993827176"
      },
      facilityTypeDetails: {
        facilityType: "Acute Hospital",
        serviceDescription: "Emergency"
      },
      facilityProviderDetails: {
        facilityName: "Maricopa medical center",
        taxID: 66459854,
        admitDate: "08-22-2020",
        dischargeDate: "08-25-2020"
      },
      diagnosisDetails: [
        {
          diagnosisCode: "CBA312",
          diagnosisDescription: "Description for CBA312"
        },
        {
          diagnosisCode: "312CBA",
          diagnosisDescription: "Description for 312CBA"
        }
      ],
      procedureDetails: [
        {
              procedureCode: "BCA213",
              procedureDescription: "Description for BCA213",
              servicingProvider: "Baker",
              taxID: "1234"
            },
      ],
      initialContact: {
        name: "Roger",
        phone: "602-234-0989"
      },
      caseTypeDetails: {
        caseNumber: "19368",
        caseStatus: "OPEN"
      }
    },
    {
      memberDetails: {
        memberName: "Meyer, Matt",
        memberDOB: "07/22/1994",
        memberID: "16440436900"
      },
      submittingProviderDetails: {
        providerName: "Mc Connel James",
        providerTaxID: "993827176"
      },
      facilityTypeDetails: {
        facilityType: "Acute Hospital",
        serviceDescription: "Emergency"
      },
      facilityProviderDetails: {
        facilityName: "Maricopa medical center",
        taxID: 66459854,
        admitDate: "08-22-2020",
        dischargeDate: "08-25-2020"
      },
      diagnosisDetails: [
        {
          diagnosisCode: "CBA312",
          diagnosisDescription: "Description for CBA312"
        },
        {
          diagnosisCode: "312CBA",
          diagnosisDescription: "Description for 312CBA"
        }
      ],
      procedureDetails: [
        {
              procedureCode: "BCA213",
              procedureDescription: "Description for BCA213",
              servicingProvider: "Baker",
              taxID: "1234"
            },
      ],
      initialContact: {
        name: "Roger",
        phone: "602-234-0989"
      },
      caseTypeDetails: {
        caseNumber: "19368",
        caseStatus: "OPEN"
      }
    },
    {
      memberDetails: {
        memberName: "Meyer, Matt",
        memberDOB: "07/22/1994",
        memberID: "16440436900"
      },
      submittingProviderDetails: {
        providerName: "Mc Connel James",
        providerTaxID: "993827176"
      },
      facilityTypeDetails: {
        facilityType: "Acute Hospital",
        serviceDescription: "Emergency"
      },
      facilityProviderDetails: {
        facilityName: "Maricopa medical center",
        taxID: 66459854,
        admitDate: "08-22-2020",
        dischargeDate: "08-25-2020"
      },
      diagnosisDetails: [
        {
          diagnosisCode: "CBA312",
          diagnosisDescription: "Description for CBA312"
        },
        {
          diagnosisCode: "312CBA",
          diagnosisDescription: "Description for 312CBA"
        }
      ],
      procedureDetails: [
        {
              procedureCode: "BCA213",
              procedureDescription: "Description for BCA213",
              servicingProvider: "Baker",
              taxID: "1234"
            },
      ],
      initialContact: {
        name: "Roger",
        phone: "602-234-0989"
      },
      caseTypeDetails: {
        caseNumber: "19368",
        caseStatus: "OPEN"
      }
    }
  ]
};

const standardCode = `
<um-duplicate [application]="application"
              [version]="version"
              [duplicateDetailsJSON]="duplicateDetailsJSON"
              (continueButtonClicked)="continueButtonClicked($event)">
</um-duplicate>
`;

export const DuplicateView = Template.bind({});

DuplicateView.args = {
  application,
  version,
  duplicateDetailsJSON
};

DuplicateView.parameters = {
  docs: {
    source: {
      code: standardCode
    }
  }
};

