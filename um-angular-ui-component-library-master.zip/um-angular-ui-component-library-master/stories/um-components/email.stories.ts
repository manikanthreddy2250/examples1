import {Story, Meta, moduleMetadata} from '@storybook/angular';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { EmailComponent } from '../../projects/component-library/src/lib/um-components/email/email.component';
import { EmailModule } from '../../projects/component-library/src/lib/um-components/email/email.module';
import {RouterModule} from "@angular/router";

export default {
  title: 'UM Components/Request Clinical',
  component: EmailComponent,
  decorators: [
    moduleMetadata({
      imports: [
        BrowserModule,
        BrowserAnimationsModule,
        EmailModule,
        RouterModule.forRoot([], { useHash: true })
      ],
      providers: []
    }),
  ],
  argTypes: {
    ngOnInit: {
      table: {
        disable: true
      }
    }
  },
  parameters: {
    docs: {
      description: {
        component: `Email component allows users to write and submit an email through the secure email API (Development in progress).

        Email Implementation

          This component has 4 input fields:

        1. application: Name of the consuming application. Used for retrieving configurations.

        2. version: Version of the consuming application. Used for retrieving configurations.

        3. hscId: HSC ID used to populate the email subject line.

        4. subjectType: Then communication channel value through which request clinical needs to be sent. Eg: email / fax.

        5. subjectTypeValue: The email address or fax number  to which the request will be sent.
        
        6. sbjRecId: taskId value through which request clinical needs to be sent.



          This component has 1 output method:

        1. closeModal(): Event emitted when a response is received from the email service.



        Integration

        1. Import EmailModule into your module.ts file:

           import { EmailModule } from '@ecp/angular-ui-component-library';

        2. Add the EmailModule to the @NgModule({..}) imports array.

        3. Create a component using the <um-email></um-email> selector tag.
        `
      }
    },
  }
} as Meta;

const Template: Story<EmailComponent> = (args: EmailComponent) => ({
  component: EmailComponent,
  props: args,
  template: `
    <div style="padding: 1rem;">
        <um-email
                  [application]="application"
                  [version]="version"
                  [hscId]="hscId"
                  [subjectType]="subjectType"
                  [subjectTypeValue]="subjectTypeValue"
                  [sbjRecId]="sbjRecId">
        </um-email>
    </div>
  `
});

const application ='case_wf_mgmt_ui';
const version = '1.0.0';
const hscId = 9102;
const subjectType='email';
const subjectTypeValue = 'test-email@optum.com';
const sbjRecId = 2586;

const standardCode = `
<um-email [application]="appName"
          [version]="version"
          [hscId]="hscId"
          [subjectType]="subjectType"
          [subjectTypeValue]="subjectTypeValue"
          (closeModal)="closeModal($event)"
          [sbjRecId]="sbjRecId">
</um-email>
`;

export const RequestClinicalView = Template.bind({});

RequestClinicalView.args = {
  application,
  version,
  hscId,
  subjectType,
  subjectTypeValue,
  sbjRecId
};

RequestClinicalView.parameters = {
  docs: {
    source: {
      code: standardCode
    }
  }
};

