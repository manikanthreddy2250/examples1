import {Story, Meta, moduleMetadata} from '@storybook/angular';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MedicalReviewComponent} from "../../projects/component-library/src/lib/um-components/medical-review/medical-review.component";
import {MedicalReviewModule} from "../../projects/component-library/src/lib/um-components/medical-review/medical-review.module";


export default {
  title: 'UM Components/Medical Review',
  component: MedicalReviewComponent,
  decorators: [
    moduleMetadata({
      imports: [
        BrowserModule,
        BrowserAnimationsModule,
        MedicalReviewModule
      ],
      providers: []
    }),
  ],
  argTypes: {
    ngOnInit: {
      table: {
        disable: true
      }
    }
  },
  parameters: {
    docs: {
      description: {
        component: `Medical Review component.

        Medical Review Implementation

          This component has 4 input fields:

        1. application: Name of the consuming application. Used for retrieving configurations.

        2. version: Version of the consuming application. Used for retrieving configurations.

        3. taskNameRefID: Task name reference ID for retrieving task data.

        4. hscId: HSC ID for retrieving task data.

        5. medicalReviewJson: JSON input that will override API call. Example format:
            [
              [
                {
                  "refDspl": "Admission Review",
                  "refId": 72138
                }
              ],
              [
                {
                  "refDspl": "Eligibility",
                  "refId": 72134,
                  "status" : "Complete"
                }
              ],
              [
                {
                  "refDspl": "Provider",
                  "refId": 72135,
                  "status" : "Complete"
                }
              ]
            ]


        Integration

        1. Import MedicalReviewModule into your module.ts file:

           import { MedicalReviewModule } from '@ecp/angular-ui-component-library';

        2. Add the MedicalReviewModule to the @NgModule({..}) imports array.

        3. Create a component using the <um-medical-review></um-medical-review> selector tag.
        `
      }
    },
  }
} as Meta;


const Template: Story<MedicalReviewComponent> = (args: MedicalReviewComponent) => ({
  component: MedicalReviewComponent,
  props: args,
  template: `
    <div style="padding: 1rem;">
      <um-medical-review [application]="application"
                     [version]="version"
                     [taskNameRefID]="taskNameRefID"
                     [hscId]="hscId"
                     [medicalReviewJson]="medicalReviewJson">
      </um-medical-review>
    </div>
  `
});

const standardCode = `
<um-medical-review [application]="application"
               [version]="version"
               [taskNameRefID]="taskNameRefID"
               [hscId]="hscId"
               [medicalReviewJson]= "medicalReviewJson">
</um-medical-review>
`;

const application = "case_wf_mgmt_ui";
const version = "1.0.0";
const taskNameRefID = "72139";
const hscId = 12845;
const medicalReviewJson = undefined;

export const MedicalReviewView = Template.bind({});

MedicalReviewView.args = {
  application,
  version,
  taskNameRefID,
  hscId,
  medicalReviewJson
};

MedicalReviewView.parameters = {
  docs: {
    source: {
      code: standardCode
    }
  }
};

