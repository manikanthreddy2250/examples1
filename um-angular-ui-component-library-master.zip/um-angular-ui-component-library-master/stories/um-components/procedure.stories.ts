import {Story, Meta, moduleMetadata} from '@storybook/angular';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {ProcedureComponent} from "../../projects/component-library/src/lib/um-components/procedure/procedure.component";
import {ProcedureModule} from "../../projects/component-library/src/lib/um-components/procedure/procedure.module";
import {RouterModule} from "@angular/router";
import {Input} from "@angular/core";


export default {
  title: 'UM Components/Procedures View',
  component: ProcedureComponent,
  decorators: [
    moduleMetadata({
      imports: [
        BrowserModule,
        BrowserAnimationsModule,
        ProcedureModule,
        RouterModule.forRoot([], { useHash: true })
      ],
      providers: []
    }),
  ],
  argTypes: {
    ngOnInit: {
      table: {
        disable: true
      }
    }
  },
  parameters: {
    docs: {
      description: {
        component: `Procedure component shows the services associated with a case (HSC ID).
        Developers can pass in a Procedure JSON object to avoid retrieving Procedure data, or pass in an HSC ID to allow this component to retrieve Procedure data.

        Procedure Implementation

           This component has 4 input fields:

        1. procedureData: JSON object containing procedure data to populate the UI.

             Sample Json Structure :
             {
             "shrt_desc": "NONEMERG TRNSPRT: MEALS-RECIP",
             "proc_cd": "A0190",
             "dateOfProcedure": "12/12/2020 11:18 am",
             "updated": "04/12/2021 03:18 pm"
             }

        2. hscId: hscId for retrieving Procedure data from a case.


        3. application: Name of the consuming application. Used for retrieving configurations.

        4. version: Version of the consuming application. Used for retrieving configurations.        


        Integration

        1. Import ProcedureModule into your module.ts file:

           import { ProcedureModule } from '@ecp/angular-ui-component-library';

        2. Add the ProcedureModule to the @NgModule({..}) imports array.

        3. Create a component using the <um-procedure></um-procedure> selector tag.
        `
      }
    },
  }
} as Meta;


const Template: Story<ProcedureComponent> = (args: ProcedureComponent) => ({
  component: ProcedureComponent,
  props: args,
  template: `
    <div style="padding: 1rem;">
        <um-procedure [showDetailsView]="showDetailsView" [hscId]="hscId" [application]="application" [procedureData]="procedureData" [serviceDetails]="serviceDetails" [typeAheadSearch]="typeAheadSearch" [readOnly]="readOnly" [summaryViewOnly]="summaryViewOnly">
        </um-procedure>
    </div>
  `
});

const showDetailsView = true;
const typeAheadSearch = true;
const readOnly = true;
const summaryViewOnly = false;
const hscId = 19689;
const application = 'um_intake_ui';
const version = '1.0.0';
const procedureData = [];
const serviceDetails = {
  srvc_set_ref_id: 3737,
  hsc_srvcs: [
    {
      "hsc_id":19689,
      "creat_dttm":"2021-05-19T15:35:34",
      "chg_dttm":"2021-05-19T15:35:34",
      "hsc_srvc_id":15790,
      "inac_ind":0,
      "proc_cd":"78130",
      "proc_cd_schm_ref_id":3767,
      "proc_othr_txt":null,
      "srvc_hsc_prov_id":null,
      "hsc_srvc_non_facls":[
        {
          "init_trt_dt":null,
          "plsrv_ref_id":3741,
          "plsrv_ref_cd":{
            "ref_id":3741,
            "ref_desc":"Home",
            "ref_dspl":"Home"
          },
          "proc_freq_ref_id":3913,
          "proc_freq_ref_cd":{
            "ref_id":3913,
            "ref_desc":"Daily",
            "ref_dspl":"Daily"
          },
          "proc_mod_1_cd":"00",
          "proc_mod_2_cd":"00",
          "proc_mod_3_cd":"0A",
          "proc_mod_4_cd":"0A",
          "proc_unit_cnt":1,
          "proc_uom_ref_id":19884,
          "proc_uom_ref_cd":{
            "ref_id":19884,
            "ref_desc":"Days",
            "ref_dspl":"Days"
          },
          "srvc_desc_ref_id":4347,
          "srvc_desc_ref_cd":{
            "ref_id":4347,
            "ref_desc":"Scheduled",
            "ref_dspl":"Scheduled"
          },
          "srvc_dtl_ref_id":3771,
          "srvc_dtl_ref_cd":{
            "ref_id":3771,
            "ref_desc":"Medical Care",
            "ref_dspl":"Medical Care"
          },
          "srvc_end_dt":"2021-03-20",
          "srvc_strt_dt":"2021-03-19",
          "unit_per_freq_cnt":1,
          "hsc_srvc_non_facl_dmes":[
            {
              "clin_ill_desc_txt":null,
              "dme_procrmnt_typ_id":null,
              "dme_tot_cst_amt":null,
              "ental_fd_sngl_src_nutritn_ind":null,
              "fml_nm_txt":null,
              "hsc_srvc_id":15790,
              "med_cond_txt":null,
              "spl_desc_txt":null,
              "srvc_desc_txt":null
            }
          ]
        }
      ]
    },
    {
      "hsc_id":19689,
      "creat_dttm":"2021-05-19T15:35:34",
      "chg_dttm":"2021-05-19T15:35:34",
      "hsc_srvc_id":15791,
      "inac_ind":0,
      "proc_cd":"78132",
      "proc_cd_schm_ref_id":3767,
      "proc_othr_txt":"Other Text",
      "srvc_hsc_prov_id":null,
      "hsc_srvc_non_facls":[
        {
          "init_trt_dt":null,
          "plsrv_ref_id":3741,
          "plsrv_ref_cd":{
            "ref_id":3741,
            "ref_desc":"Home",
            "ref_dspl":"Home"
          },
          "proc_freq_ref_id":3913,
          "proc_freq_ref_cd":{
            "ref_id":3913,
            "ref_desc":"Daily",
            "ref_dspl":"Daily"
          },
          "proc_mod_1_cd":"00",
          "proc_mod_2_cd":"01",
          "proc_mod_3_cd":"0A",
          "proc_mod_4_cd":"0A",
          "proc_unit_cnt":1,
          "proc_uom_ref_id":19884,
          "proc_uom_ref_cd":{
            "ref_id":19884,
            "ref_desc":"Days",
            "ref_dspl":"Days"
          },
          "srvc_desc_ref_id":4347,
          "srvc_desc_ref_cd":{
            "ref_id":4347,
            "ref_desc":"Scheduled",
            "ref_dspl":"Scheduled"
          },
          "srvc_dtl_ref_id":3771,
          "srvc_dtl_ref_cd":{
            "ref_id":3771,
            "ref_desc":"Medical Care",
            "ref_dspl":"Medical Care"
          },
          "srvc_end_dt":"2021-03-20",
          "srvc_strt_dt":"2021-03-19",
          "unit_per_freq_cnt":1,
          "hsc_srvc_non_facl_dmes":[
            {
              "clin_ill_desc_txt":null,
              "dme_procrmnt_typ_id":null,
              "dme_tot_cst_amt":null,
              "ental_fd_sngl_src_nutritn_ind":null,
              "fml_nm_txt":null,
              "hsc_srvc_id":15791,
              "med_cond_txt":null,
              "spl_desc_txt":null,
              "srvc_desc_txt":null
            }
          ]
        }
      ]
    }
  ]
};

export const ProcedureView = Template.bind({});
ProcedureView.args = {
  hscId,application,showDetailsView,procedureData, typeAheadSearch, serviceDetails, readOnly, summaryViewOnly
};

