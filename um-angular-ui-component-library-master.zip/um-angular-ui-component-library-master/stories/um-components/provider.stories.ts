import {Story, Meta, moduleMetadata} from '@storybook/angular';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { ProviderComponent } from '../../projects/component-library/src/lib/um-components/provider/provider.component';
import { ProviderModule } from '../../projects/component-library/src/lib/um-components/provider/provider.module';
import {RouterModule} from "@angular/router";

export default {
  title: 'UM Components/Provider',
  component: ProviderComponent,
  decorators: [
    moduleMetadata({
      imports: [
        BrowserModule,
        BrowserAnimationsModule,
        ProviderModule,
        RouterModule.forRoot([], { useHash: true })
      ],
      providers: []
    }),
  ],
  argTypes: {
    ngOnInit: {
      table: {
        disable: true
      }
    }
  },
  parameters: {
    docs: {
      description: {
        component: `Provider component shows the facility and providers associated with a case (HSC ID).
        Developers can pass in a provider JSON object to avoid retrieving provider data, or pass in an HSC ID to allow this component to retrieve provider data.
        Development in progress.

        Provider Implementation

           This component has 6 input fields:

        1. providerDetailsJSON: JSON object containing provider data to populate the UI.
            Here is a sample data structure for Providers:
            {
              "user_favs": [
                 {
                  "adr_ln_1_txt": "300 Flatbush Ave",
                  "adr_ln_2_txt": null,
                  "bus_nm": null,
                  "cty_nm": "Brooklyn",
                  "distance": 7,
                  "fst_nm": "CINTIA",
                  "hsc_prov_roles": [],
                  "lst_nm": "ROGUIN",
                  "ntwk_sts_ref_cd": {"ref_dspl": "In"},
                  "ntwk_sts_ref_id": null,
                  "prov_adr_id": 17788,
                  "prov_catgy_ref_cd": {"ref_dspl": "HCP", "ref_desc": "HealthCare Practitioner"},
                  "prov_catgy_ref_id": 16309,
                  "prov_id": 167070,
                  "prov_key_typ_ref_cd": {"ref_dspl": "NPI"},
                  "prov_key_typ_ref_id": 2782,
                  "prov_key_val": "1255539573",
                  "spcl_ref_cd": {ref_dspl: "174400000X"},
                  "spcl_ref_id": 16536,
                  "st_ref_cd": {ref_dspl: "NEW YORK"},
                  "st_ref_id": 1101,
                  "telcom_adr_id": "7186222000",
                  "zip_cd_txt": "11217"
                 }
              ],
              "hsc_provs": [
                 {
                  "adr_ln_1_txt": "174 BARNWOOD DR",
                  "adr_ln_2_txt": null,
                  "bus_nm": "HOGUE CHIROPRACTIC CENTER PLLC",
                  "cty_nm": "EDGEWOOD",
                  "distance": 7,
                  "fst_nm": null,
                  "hsc_prov_id": 8600,
                  "hsc_prov_roles":[{prov_role_ref_id: 3764, prov_role_ref_cd: {ref_dspl: "Requesting"}}],
                  "isFav": false,
                  "lst_nm": null,
                  "ntwk_sts_ref_cd": {ref_dspl: "In"},
                  "ntwk_sts_ref_id": null,
                  "prov_adr_id": 29700446,
                  "prov_catgy_ref_cd": {ref_dspl: "HealthCare Organization"},
                  "prov_catgy_ref_id": 16310,
                  "prov_id": 7268882,
                  "prov_key_typ_ref_cd": {ref_dspl: "TAX"},
                  "prov_key_typ_ref_id": 16333,
                  "prov_key_val": "806930103",
                  "spcl_ref_cd": {ref_dspl: "193400000X"},
                  "spcl_ref_id": 16567,
                  "st_ref_cd": {ref_dspl: "KENTUCKY"},
                  "st_ref_id": 1082,
                  "telcom_adr_id": "8593417746",
                  "zip_cd_txt": "41017",
                 }
              ]
           }
        2. hscID: hscID for retrieving provider data from a case.

        3. application: Name of the consuming application. Used for retrieving configurations.

        4. version: Version of the consuming application. Used for retrieving configurations.

        Integration

        5. showFavouriteProviders: Flag Used to show Favourite Providers of user

        6. showDetailsView: Flag used to show the providers of Hsc.

        7. openFacilitySearchFirst: Flag for choosing if the provider search or facility search will appear by default

        1. Import ProviderModule into your module.ts file:

           import { ProviderModule } from '@ecp/angular-ui-component-library';

        2. Add the ProviderModule to the @NgModule({..}) imports array.

        3. Create a component using the <um-provider></um-provider> selector tag.
        `
      }
    },
  }
} as Meta;

const Template: Story<ProviderComponent> = (args: ProviderComponent) => ({
  component: ProviderComponent,
  props: args,
  template: `
    <div style="padding: 1rem;">
        <um-provider [showDetailsView]="showDetailsView"
                     [hscID]="hscID"
                     [envID]="envID"
                     [application]="application"
                     [version]="version"
                     [showCardProvider]="showCardProvider"
                     [showProviderSearch]="showProviderSearch"
                     [showCardPhysician]="showCardPhysician"
                     [showFavouriteProviders]="showFavouriteProviders"
                     [readOnly] = "readOnly"
                     [showLandingPageProviders] = "showLandingPageProviders"
                     [providerDetailsJSON]="providerDetailsJSON"
                     [openFacilitySearchFirst] = "openFacilitySearchFirst">
        </um-provider>
    </div>
  `
});

const showDetailsView = true;
const providerDetailsJSON = undefined;
const hscID = 18112; //this is provider test HscID
const envID='DEV';
const application = 'um_intake_ui';//case_wf_mgmt_ui does not have permission to get favorites from user attribute domain
const version = '1.0.0';
const showCardProvider = false;//to show card veiw
const showProviderSearch = true;
const showFavouriteProviders = true;
const showLandingPageProviders = false;//to show Landing Page Providers
const showCardPhysician = true;//to show Physician / Facility in Card Veiw
const readOnly = false;
const openFacilitySearchFirst = false;

const standardCode = `
<um-provider [showDetailsView]="showDetailsView"
             [hscID]="hscID"
             [envID]="envID"
             [application]="application"
             [version]="version"
             [showCardProvider]="showCardProvider"
             [showProviderSearch]="showProviderSearch"
             [showLandingPageProviders] = "showLandingPageProviders"
             [showCardPhysician] = "showCardPhysician"
             [readOnly] = "readOnly"
             [showFavouriteProviders]="showFavouriteProviders"
             [providerDetailsJSON]="providerDetailsJSON"
             [openFacilitySearchFirst] = "openFacilitySearchFirst"
             (providerViewAndUpdateButtonClicked)="providerViewAndUpdateButtonClicked($event)"
             (facilityViewAndUpdateButtonClicked)="facilityViewAndUpdateButtonClicked($event)">
</um-provider>
`;

export const Provider = Template.bind({});

Provider.args = {
  providerDetailsJSON,
  hscID,
  envID,
  application,
  version,
  showCardProvider,
  showProviderSearch,
  showFavouriteProviders,
  showCardPhysician,
  showDetailsView,
  showLandingPageProviders,
  readOnly
};

Provider.parameters = {
  docs: {
    source: {
      code: standardCode
    }
  }
};

