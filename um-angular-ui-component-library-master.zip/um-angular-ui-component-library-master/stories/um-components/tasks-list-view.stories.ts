import {Story, Meta, moduleMetadata} from '@storybook/angular';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { TasksListViewComponent } from '../../projects/component-library/src/lib/um-components/tasks-list-view/tasks-list-view.component';
import { TasksListViewModule } from '../../projects/component-library/src/lib/um-components/tasks-list-view/tasks-list-view.module';
import { RouterModule } from '@angular/router';

export default {
  title: 'UM Components/Tasks List View',
  component: TasksListViewComponent,
  decorators: [
    moduleMetadata({
      imports: [
        BrowserModule,
        BrowserAnimationsModule,
        TasksListViewModule,
        RouterModule.forRoot([], { useHash: true })
      ],
      providers: []
    }),
  ],
  argTypes: {
    ngOnInit: {
      table: {
        disable: true
      }
    }
  },
  parameters: {
    docs: {
      description: {
        component: `Tasks List View component shows the list of Tasks that got associated to a specific User.

        Configurable My Tasks Lists Table Implementation

       1. This component has 2 required input fields:

            1. application: name of the consuming application. used for retrieving  configurations.

            2. version: version of the consuming application. used for retrieving  configurations.

       2. Configurable Info

          Table section will dynamically populate fields based on the configuration saved within the system configuration table.

           Ensure configuration is present with configuration domain,

           This table using "my_tasks_config_table_headers" as config key.

            Available Table Header Config fields

            | Label                             | Key        |
            | --------------------------------- | -----------|
            | Admitted                          | admitted   |
            | Tat                               | tat        |
            | Status                            | status     |
            | Member                            | member     |
            | Diagnosis                         | diagnosis  |
            | Facility                          | facility   |
            | Task type                         | taskType   |
            | Action                            | action     |

            Example:
            INSERT INTO appl_ver_cnfg_key (appl_nm,appl_ver_id,cnfg_key)
            VALUES('case_wf_mgmt_ui','1.0.0','my_tasks_config_table_headers');

            INSERT INTO sys_cnfg (sys_cnfg_id, appl_nm,appl_ver_id, cnfg_key, cnfg_val, inac_ind, strt_dt)
            VALUES('case_wf_mgmt_ui_1.0.0_my_tasks_config_table_headers_2021-04-16','case_wf_mgmt_ui','1.0.0','my_tasks_config_table_headers',
            '{"tableHeadersColumns": [{"key":"admitted","label":"Admitted"},{"key":"tat","label":"Tat"},{"key":"taskType","label":"Task Type"},
            {"key": "status", "label":"Status"},{"key":"member","label":"Member"},{"key":"diagnosis","label":"Diagnosis"},{"key":"facility","label":"Facility"},
            {"key":"action","label":"Action"}]
            }', 0,'2021-04-16');

        3. Testing (In Storybook showcase): Copy ecp_token,active_org_role,ecp_token_claims_obj from clinical app and add into local storage
        `
      }
    },
  }
} as Meta;


const Template: Story<TasksListViewComponent> = (args: TasksListViewComponent) => ({
  component: TasksListViewComponent,
  props: args,
  template: `
    <div style="padding: 1rem;">
        <um-tasks-list-view [application]="application" [version]="version">
        </um-tasks-list-view>
    </div>
  `
});

const application = 'case_wf_mgmt_ui';
const version = '1.0.0';

const standardCode = `
// Import TasksListViewModule into your module.ts file.
import { TasksListViewModule } from '@ecp/angular-ui-component-library';

// Add the TasksListViewModule to the @NgModule({..}) imports array.

@NgModule({
  import: [
    ...,
    TableModule,
  ]
})

// Create a component using the <um-tasks-list-view></um-tasks-list-view> selector tag

<um-tasks-list-view
                    [application]="appName"
                    [version]="version"
                    >
</um-tasks-list-view>
`;


export const TasksListView = Template.bind({});

// @ts-ignore
TasksListView.args = {
  application,
  version
};

TasksListView.parameters = {
  docs: {
    source: {
      code: standardCode
    }
  }
};

