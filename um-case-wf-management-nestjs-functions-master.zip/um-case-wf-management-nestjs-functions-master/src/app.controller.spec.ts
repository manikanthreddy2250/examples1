import { ConfigService } from '@nestjs/config';
import { Test, TestingModule } from '@nestjs/testing';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import {ProviderContractService} from "./health-service/service/provider-contract/provider-contract.service";
import {ProviderClient} from "./health-service/shared/graphql/provider-domain/providerClient";
import {ReferenceClient} from "./health-service/shared/graphql/referenceDomain/referenceClient";
import { Injectable ,HttpService,HttpModule} from '@nestjs/common';
import {LoggerModule} from "nestjs-pino";

describe('AppController', () => {
  let appController: AppController;

  beforeEach(async () => {
    const app: TestingModule = await Test.createTestingModule({
      controllers: [AppController],
      providers: [AppService, ConfigService,ProviderContractService,ProviderClient,ReferenceClient],
      imports: [HttpModule, LoggerModule.forRoot()]
    }).compile();

    appController = app.get<AppController>(AppController);
  });

  describe('root', () => {
    it('should return "Hello World!"', () => {
      expect(appController.getHello()).toBe('Hello World!');
    });
  });
  
});
