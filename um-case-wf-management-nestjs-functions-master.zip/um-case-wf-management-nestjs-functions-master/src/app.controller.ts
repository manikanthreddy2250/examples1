import {Controller, Get, HttpCode, Post, UploadedFile, UseInterceptors} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { AppService } from './app.service';
import {FileInterceptor} from "@nestjs/platform-express";
import {Request} from 'express';
@Controller()
export class AppController {
  constructor(
    private readonly appService: AppService,
    private readonly configService: ConfigService,) {}

  @Get()
  getHello(): string {
    return this.appService.getHello();
  }

  @Get('/docasap_base_url')
  getConfig1(): string {
    return this.configService.get<string>('DOCASAP_API_BASE_URL');
  }

  @Get('/docasp_token_url')
  getConfig2(): string {
    return this.configService.get<string>('DOCASAP_TOKEN_URL');
  }

}
