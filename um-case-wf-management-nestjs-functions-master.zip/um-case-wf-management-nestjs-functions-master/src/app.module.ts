import {HttpModule, Module} from '@nestjs/common';
import { LoggerModule } from 'nestjs-pino';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { GraphQLModule } from '@nestjs/graphql';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { GraphQLError, GraphQLFormattedError } from 'graphql';
import { AuthModule } from './auth/auth.module';
import { JwtStrategy } from './auth/jwt.strategy';
import { AuthGuard } from './auth/auth.guard';
import { RolesGuard } from './auth/roles.guard';
import { PassportModule } from '@nestjs/passport';
import { JwtModule } from '@nestjs/jwt';
import { HealthServiceModule } from './health-service/health-service.module';
import { ConfigurationModule } from './configuration/configuration.module';
import GraphQLJSON from "graphql-type-json";
import {HealthServiceClient} from "./health-service/shared/graphql/healthservicedomain/healthServiceClient";
import {MulterModule} from "@nestjs/platform-express";
import {ProviderContractService} from "./health-service/service/provider-contract/provider-contract.service";
import {ProviderClient} from "./health-service/shared/graphql/provider-domain/providerClient";
import {ReferenceClient} from "./health-service/shared/graphql/referenceDomain/referenceClient";
import {ProviderContractController} from "./health-service/service/provider-contract/provider-contract-controller";

@Module({
  imports: [
      HttpModule,
    LoggerModule.forRoot(),
    ConfigModule.forRoot({
      isGlobal: true,
      ignoreEnvFile: true,
      envFilePath:['.env.dev','.env.local']
    }),
    GraphQLModule.forRoot({
      buildSchemaOptions: {
        numberScalarMode: 'integer',
      },
       resolvers: { JSON: GraphQLJSON }, // if you need to expose a JSON as a type
      playground: true,
      installSubscriptionHandlers: false,
      context: ({ req }) => ({ req }),
      autoSchemaFile: 'schema.gql',
      useGlobalPrefix: true,
      formatError: (error: GraphQLError) => {
        const graphQLFormattedError: GraphQLFormattedError = {
          message: error.message,
        };
        return graphQLFormattedError;
      },
    }),
    PassportModule,
    JwtModule.register({}),
    AuthModule,
    HealthServiceModule,
    ConfigurationModule,
      MulterModule.register({
        dest:'./upload',
      })
  ],
  controllers: [AppController,ProviderContractController],
  providers: [AppService, ConfigService, JwtStrategy, AuthGuard, RolesGuard,HealthServiceClient,ProviderContractService,ProviderClient,ReferenceClient],
})
export class AppModule {}
