import { Module } from '@nestjs/common';
import { PassportModule } from '@nestjs/passport';
import { ConfigModule, ConfigService } from '@nestjs/config'
import { JwtStrategy } from './jwt.strategy'
import { AuthGuard } from './auth.guard';
import { JwtModule } from '@nestjs/jwt';
import { ExtractJwt } from 'passport-jwt';
import { RolesGuard } from './roles.guard';

@Module({
  imports: [PassportModule, ConfigModule],
  providers: [JwtStrategy, AuthGuard, RolesGuard, ConfigService],
  exports: [JwtStrategy, AuthGuard, RolesGuard],
})
export class AuthModule {}
