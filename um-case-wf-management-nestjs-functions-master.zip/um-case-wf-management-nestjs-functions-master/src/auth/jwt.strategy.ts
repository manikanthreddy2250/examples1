import {
  ExecutionContext,
  Injectable,
  UnauthorizedException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { PassportStrategy } from '@nestjs/passport';
import { ExtractJwt, Strategy } from 'passport-jwt';

import { GqlExecutionContext } from '@nestjs/graphql';

import * as jwksClient from 'jwks-rsa';
import * as jwt from 'jsonwebtoken';
import {Logger} from "nestjs-pino";

/**
 * Singleton class.
 * Provides static properties to persist in memory
 * so jwks cache can live somewhere.
 */
class KeyProviderWithJwksCache {
  static jwksClient: jwksClient.JwksClient;
  static validationCounter = 0;

  constructor(private configService: ConfigService, private readonly logger: Logger) {
    KeyProviderWithJwksCache.jwksClient = jwksClient({
      jwksUri: this.configService.get<string>('JWK_URI'),
      cache: true,
      cacheMaxEntries: 5,
      cacheMaxAge: 36000000, // 10 hours, milliseconds
      rateLimit: true,
      jwksRequestsPerMinute: 10,
    });
  }

  async handler(req, rawJwtToken, done) {
    try {
      this.logger.log(
        'Singleton Test: ',
        JSON.stringify({
          jwtsValidatedSoFar: KeyProviderWithJwksCache.validationCounter,
        }),
      );
      KeyProviderWithJwksCache.validationCounter += 1;

      const jwtTokenKeyId = (() => {
        const decoded: any = jwt.decode(rawJwtToken as string, {
          complete: true,
        });
        return decoded.header.kid;
      })();

      const signingKey = await new Promise((resolve, reject) => {
        KeyProviderWithJwksCache.jwksClient.getSigningKey(
          jwtTokenKeyId,
          (err: Error, jwk: jwksClient.RsaSigningKey) => {
            if (err) {
              return reject(err);
            }
            return resolve(jwk.rsaPublicKey);
          },
        );
      });
      done(null, signingKey);
    } catch (err) {
      this.logger.error('KeyProviderWithJwksCache - Error :', JSON.stringify({ err }, null, 2));
      done(err, null);
    }
  }
}

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  constructor(private configService: ConfigService, private readonly logger: Logger) {
    super({
      jwtFromRequest: ExtractJwt.fromExtractors([
        ExtractJwt.fromAuthHeaderAsBearerToken(),
        ExtractJwt.fromAuthHeaderWithScheme('Bearer'),
      ]),
      secretOrKeyProvider: new KeyProviderWithJwksCache(configService, logger).handler,
      audience: '',
      issuer: configService.get<string>('ISSUER'),
      algorithms: ['RS512'],
    });
  }

  async validate(payload: any) {
    this.logger.log('payload===' + payload);
    if (!payload) {
      throw new UnauthorizedException('Invalid JWT Token');
    }
    return payload;
  }

  getRequest(context: ExecutionContext) {
    return (
      context.switchToHttp().getRequest() ||
      GqlExecutionContext.create(context).getContext().req
    );
  }
}
