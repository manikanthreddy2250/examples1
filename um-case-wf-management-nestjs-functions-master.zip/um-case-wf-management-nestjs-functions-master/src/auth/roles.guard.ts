import {
  Injectable,
  CanActivate,
  ExecutionContext,
  Logger,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { GqlExecutionContext } from '@nestjs/graphql';
import { ROLES_KEY } from '../decorators/roles.decorator';
import { Role } from '../decorators/roles';
import {ConfigService} from "@nestjs/config";
import {AuthorizationService} from "@ecp/func-tk/dist";

@Injectable()
export class RolesGuard implements CanActivate {
  constructor(private reflector: Reflector, private readonly logger: Logger, private configService: ConfigService) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const ctx = GqlExecutionContext.create(context);
    const { req } = ctx.getContext();
    const roles = this.reflector.getAllAndOverride<Role[]>(ROLES_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);

    if (!roles) return true;
    //if (!req.user) return false;
    this.logger.log('roles===>' + roles);
    const roleInRequest = req.headers['x-hasura-role'];
    const hasRole = () => roles.includes(roleInRequest);
    const user = req.user;
    this.logger.log('user===>' + JSON.stringify(user));
    // const hasRole = () =>
    //   user.roles.some(role => !!roles.find(item => item === role));
    this.logger.log('roleInRequest===>' + roleInRequest);
    this.logger.log('hasRole===>' + hasRole());
    return roleInRequest && hasRole();
    const hasRoleInToken = await AuthorizationService.hasAnyRole(req.headers.authorization, this.configService.get<string>('JWK_URI'), this.configService.get<string>('ISSUER'), roles);
    return roleInRequest && hasRole() && hasRoleInToken;
  }

  getRequest(context: ExecutionContext) {
    return (
      context.switchToHttp().getRequest() ||
      GqlExecutionContext.create(context).getContext().req
    );
  }
}
