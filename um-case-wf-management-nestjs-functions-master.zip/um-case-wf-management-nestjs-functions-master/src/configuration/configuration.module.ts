import { Module } from '@nestjs/common';
import { ConfigurationResolver } from './resolver/configuration.resolver';
import { TaskMetadataService } from './service/task-metadata/task-metadata.service';
import { UtilService } from "./service/util/util.service";
import {UtilClient} from "./../health-service/shared/graphql/utildomain/utilClient";

@Module({
  providers: [ConfigurationResolver, TaskMetadataService, UtilService, UtilClient]
})
export class ConfigurationModule {}
