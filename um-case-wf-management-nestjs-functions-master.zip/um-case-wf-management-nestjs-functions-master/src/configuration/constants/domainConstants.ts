export const DomainConstants = {
    HSC_PRIORITY_REVIEW_TYPE: 'Expedited Prospective',
    STR_YES: 'YES',
    PRIOR_AUTH: 'NA',
    LOB_TYPE_EnI:'E&I',
    LOB_TYPE_MnR:'M&R',
    LOB_TYPE_CnS: 'C&S',
    CONTENT_TYPE : 'application/json',
    TAT_GUIDELINE_SOURCE: 'Federal',
    INTAKE_CHANNEL_WEB: 'Web'
}
