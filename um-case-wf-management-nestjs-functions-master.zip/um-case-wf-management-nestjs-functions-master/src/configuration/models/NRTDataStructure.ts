export interface NRTDataStructure {
  MPIN: string;
  TAX_ID_TIN: string;
  Address_Seq_Num: string;
  Fac_Prov_Name_Primary: string;
  State_CD: any;
  LOB: string;
  Entity: string;
  Contract_Paper_Type: string;
  Eff_Dt: string;
  Term_Dt: string;
  Med_Nec_Restriction_Type_Name: string;
  Med_Nec_Restriction: string;
  Lst_Call_Dt: string;
  Insert_Dt: string;
  Action_Cd: string;
  Lst_Updt_By: string;
}
