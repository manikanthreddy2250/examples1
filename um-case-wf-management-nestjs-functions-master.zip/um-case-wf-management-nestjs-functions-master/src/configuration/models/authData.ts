import {ServicesInfo} from "./servicesInfo";
import {MemberCoverageInfo} from "./memberInfo";
import {FacilitiesInfo} from "./facilitiesInfo";
import {
    AdmittingProviderInfo,
    AttendingProviderInfo, FacilityProviderInfo, RequestingProviderInfo,
    ServicingProviderInfo
} from "./providersInfo";
import {DiagnosisInfo} from "./diagnosisInfo";



export class AuthData {
    public caseId: number;
    public caseStatusRefId: number;
    public reviewPriorityRefId: number;
    public serviceSettingRefId: number;
    public serviceSettingRefCode: number;
    public serviceSettingRefDescription: string;
    public serviceSettingRefDisplay: string;
    public reviewPriorityRefCode: number;
    public reviewPriorityRefDescription: string;
    public reviewPriorityRefDisplay: string;
    public priorAuth: string;
    public reviewType: string;
    public memberAge: number;
    public tatGuidelienSource: string;
    public intakeChannel: string;
    public primaryDiagnosisCode: string;
    public diagnosisInfo: DiagnosisInfo[];
    public servicesInfo: ServicesInfo[];
    public memberCoverageInfo: MemberCoverageInfo;
    public facilitiesInfo: FacilitiesInfo[];
    public servicingProviderInfo: ServicingProviderInfo[];
    public requestingProviderInfo: RequestingProviderInfo[];
    public attendingProviderInfo: AttendingProviderInfo[];
    public admittingProviderInfo: AdmittingProviderInfo[];
    public facilityProviderInfo: FacilityProviderInfo[];

    constructor(data?: AuthData) {
        if (data) {
            this.caseId = data.caseId;
            this.caseStatusRefId= data.caseStatusRefId;
            this.reviewPriorityRefId=data.reviewPriorityRefId;
            this.serviceSettingRefId=data.serviceSettingRefId;
            this.reviewPriorityRefCode=data.reviewPriorityRefCode;
            this.reviewPriorityRefDescription=data.reviewPriorityRefDescription;
            this.reviewPriorityRefDisplay=data.reviewPriorityRefDisplay;
            this.serviceSettingRefCode=data.serviceSettingRefCode;
            this.serviceSettingRefDescription=data.serviceSettingRefDescription;
            this.serviceSettingRefDisplay=data.serviceSettingRefDisplay;
            this.priorAuth = data.priorAuth;
            this.reviewType = data.reviewType;
            this.memberAge= data.memberAge;
            this.tatGuidelienSource= data.tatGuidelienSource;
            this.intakeChannel= data.intakeChannel;
            this.primaryDiagnosisCode = data.primaryDiagnosisCode;
            this.memberCoverageInfo = new MemberCoverageInfo(data.memberCoverageInfo);
            if (data.diagnosisInfo) {
                this.diagnosisInfo = data.diagnosisInfo
                    .map(d => {
                        return new DiagnosisInfo(d)
                    });
            }
            if (data.servicesInfo) {
                this.servicesInfo = data.servicesInfo
                    .map(s => {
                        return new ServicesInfo(s)
                    });
            }

            if (data.facilitiesInfo) {
                this.facilitiesInfo = data.facilitiesInfo
                    .map(f => {
                        return new FacilitiesInfo(f)
                    });
            }
            if (data.servicingProviderInfo) {
                this.servicingProviderInfo = data.servicingProviderInfo
                    .map(p => {
                        return new ServicingProviderInfo(p)
                    });
            }

            if (data.requestingProviderInfo) {
                this.requestingProviderInfo = data.requestingProviderInfo
                    .map(p => {
                        return new RequestingProviderInfo(p)
                    });
            }
            this.admittingProviderInfo = data.admittingProviderInfo.map(p => {return new AdmittingProviderInfo(p)});
            this.attendingProviderInfo = data.attendingProviderInfo.map(p => {return new AttendingProviderInfo(p)});
            this.facilityProviderInfo = data.facilityProviderInfo.map(p => {return new FacilityProviderInfo(p)});

         } else {
             this.diagnosisInfo = [];
             this.servicesInfo = [];
             this.facilitiesInfo = [];
             this.servicingProviderInfo = [];
             this.requestingProviderInfo = [];
             this.attendingProviderInfo = [];
             this.admittingProviderInfo = [];
             this.facilityProviderInfo = [];
        }
    }

}


