import {Field, Int, ObjectType} from "@nestjs/graphql";
import {CaseDiagnosisResponse} from "./case-diagnosis-response";
import {CaseServicesInfoResponse} from "./case-services-info-response";
import {CaseMemberCoverageInfoResponse} from "./case-member-coverage-info-response";
import {CaseProviderInfoResponse} from "./case-provider-info-response";
import {CaseFacilitiesInfoResponse} from "./case-facilities-info-response";

@ObjectType()
export class CaseDataResponse {
    @Field(type => Int)
    caseId: number;

    @Field(type => String,{nullable: true})
    intakeChannel: string;

    @Field(type => String)
    tatGuidelienSource: string;

    @Field(type => Int, {nullable: true})
    stateOfResidenceRefId:number;

    @Field(type => String, {nullable: true})
    stateOfResidenceRefDisplay: string;

    @Field(type => String, {nullable: true})
    stateOfResidenceRefCode: string;

    @Field({nullable: true})
    caseCreateDateTime? : string;

    @Field(type => Int, {nullable: true})
    caseStatusRefId: number;

    @Field(type => Int,{nullable: true})
    reviewPriorityRefId: number;

    @Field(type => Int,{nullable: true})
    serviceSettingRefId: number;

    @Field(type => Int,{nullable: true})
    serviceSettingRefCode: number;

    @Field(type => String,{nullable: true})
    serviceSettingRefDescription: string;

    @Field(type => String,{nullable: true})
    serviceSettingRefDisplay: string;

    @Field(type => Int,{nullable: true})
    reviewPriorityRefCode: number;

    @Field(type => String,{nullable: true})
    reviewPriorityRefDescription: string;

    @Field(type => String,{nullable: true})
    reviewPriorityRefDisplay: string;

    @Field(type => String,{nullable: true})
    facilityMedNecIndicator: string;

    @Field(type => String,{nullable: true})
    memberMedNecIndicator: string;

    @Field(type => String,{nullable: true})
    priorAuth: string;

   @Field(type => String,{nullable: true})
    reviewType: string;

    @Field(type => Int,{nullable: true})
    memberAge: number;

    @Field(type => String,{nullable: true})
    primaryDiagnosisCode: string;

    @Field(type => CaseMemberCoverageInfoResponse)
    memberCoverageInfo: CaseMemberCoverageInfoResponse;

    @Field(type => [CaseDiagnosisResponse])
    diagnosisInfo: CaseDiagnosisResponse[];

    @Field(type => [CaseServicesInfoResponse])
    servicesInfo: CaseServicesInfoResponse[];

    @Field(type => [CaseProviderInfoResponse])
    servicingProviderInfo: CaseProviderInfoResponse[];

    @Field(type => [CaseProviderInfoResponse])
    requestingProviderInfo: CaseProviderInfoResponse[];

    @Field(type => [CaseProviderInfoResponse])
    attendingProviderInfo: CaseProviderInfoResponse[];

    @Field(type => [CaseProviderInfoResponse])
    admittingProviderInfo: CaseProviderInfoResponse[];

    @Field(type => [CaseProviderInfoResponse])
    facilityProviderInfo: CaseProviderInfoResponse[];

    @Field(type => [CaseFacilitiesInfoResponse])
    facilitiesInfo: CaseFacilitiesInfoResponse[];
}
