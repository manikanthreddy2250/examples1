import {Field, Int, ObjectType} from "@nestjs/graphql";

@ObjectType()
export class CaseDiagnosisResponse {
    @Field(type => String,{nullable: true})
    diagnosisCode: string;

    @Field(type => String,{nullable: true})
    diagnosisDescription: string;

    @Field(type => Int,{nullable: true})
    primaryInd: number;
}
