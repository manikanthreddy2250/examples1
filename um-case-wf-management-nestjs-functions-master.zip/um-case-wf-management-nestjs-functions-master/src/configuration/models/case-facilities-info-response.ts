import {Field, Int, ObjectType} from "@nestjs/graphql";

@ObjectType()
export class CaseFacilitiesInfoResponse {
    @Field(type => String,{nullable: true})
    actualAdmissionDate: string;

    @Field(type => String,{nullable: true})
    actualDischargeDate: string;

    @Field(type => String,{nullable: true})
    expectedAdmissionDate: string;

    @Field(type => String,{nullable: true})
    expectedDischargeDate: string;

    @Field(type => Int,{nullable: true})
    placeOfServiceRefId: number;

    @Field(type => Int,{nullable: true})
    serviceDescriptionRefId: number;

    @Field(type => Int,{nullable: true})
    serviceDetailRefId: number;

    @Field(type => String,{nullable: true})
    placeOfServiceRefCode: string;

    @Field(type => String,{nullable: true})
    placeOfServiceRefDescription: string;

    @Field(type => String,{nullable: true})
    placeOfServiceRefDisplay: string;

    @Field(type => String,{nullable: true})
    serviceDescriptionRefCode: string;

    @Field(type => String,{nullable: true})
    serviceDescriptionRefDesc: string;

    @Field(type => String,{nullable: true})
    serviceDescriptionRefDisplay: string;

    @Field(type => String,{nullable: true})
    serviceDetailRefCode: string;

    @Field(type => String,{nullable: true})
    serviceDetailRefDescription: string;

    @Field(type => String,{nullable: true})
    serviceDetailRefDisplay: string;
}
