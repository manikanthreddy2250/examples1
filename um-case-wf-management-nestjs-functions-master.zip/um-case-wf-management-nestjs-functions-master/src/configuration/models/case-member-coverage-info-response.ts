import {Field, Int,Float, ObjectType} from "@nestjs/graphql";

@ObjectType()
export class CaseMemberCoverageInfoResponse {
    @Field(type => Int,{nullable: true})
    individualId: number;

    @Field(type => String,{nullable: true})
    policyNumber: string;

    @Field(type => String,{nullable: true})
    coverageEffectiveDate: string;

    @Field(type => String,{nullable: true})
    coverageEndDate: string;

    @Field(type => Float,{nullable: true})
    memberCoverageId: number;
    //todo: BigInt fields needed to update respective type instead of int

    @Field(type => Int,{nullable: true})
    productCodeRefId: number;

    @Field(type => String,{nullable: true})
    sourceSystem: string;

    @Field(type => String,{nullable: true})
    productCategoryType: string;

    @Field(type => String,{nullable: true})
    coverageTypeDescription: string;

    @Field(type => Int,{nullable: true})
    individualkeyTypeRefId: number;

    @Field(type => Int,{nullable: true})
    claimPlatformRefId: number;

    @Field(type => String,{ nullable: true })
    lob: string;

    @Field(type => String,{ nullable: true })
    stateOfIssue: string;
}

