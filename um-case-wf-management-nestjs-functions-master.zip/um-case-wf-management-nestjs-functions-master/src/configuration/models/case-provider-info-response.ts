import {Field, Int, ObjectType} from "@nestjs/graphql";
import {CaseProviderLocationAffilDetailResponse} from "./case-provider-location-affil-detail-response";

@ObjectType()
export class CaseProviderInfoResponse {
    @Field(type => Int)
    caseProviderId: number;

    @Field(type => Int,{nullable: true})
    providerRoleRefId: number;

    @Field(type => String, {nullable: true})
    providerNPI: string;

    @Field(type => String, {nullable: true})
    providerTax: string;

    @Field(type => String, {nullable: true})
    providerMPIN: string;

    @Field(type => Int, {nullable: true})
    specalityRefId: number;

    @Field(type => String, {nullable: true})
    telecomAddressId: string;

    @Field(type => Int,{nullable: true})
    networkStatusRefId: number;

    @Field(type => Int,{nullable: true})
    networkSteerageReasonRefId: number;

    @Field(type => Int,{nullable: true})
    providerLocationAffiliationId: number;

    @Field(type => CaseProviderLocationAffilDetailResponse,{nullable: true})
    providerLocationAffiliationDetail: CaseProviderLocationAffilDetailResponse;


}
