import {Field, Int, ObjectType} from "@nestjs/graphql";

@ObjectType()
export class CaseProviderLocationAffilDetailResponse {
    @Field(type => Int)
    providerId: number;

    @Field(type => Int)
    providerAddressId: number;

    @Field(type => Int,{ nullable: true })
    providerCategoryTypeRefId: number;

    @Field(type => String, { nullable: true })
    medNecRestrictionType: string;
}