import {Field, Int, ObjectType} from "@nestjs/graphql";

@ObjectType()
export class CaseServiceNonFacilityResponse {
    @Field(type => Int)
    plsrvRefId: number;

    @Field(type => Int)
    procFreqRefId: number;

    @Field(type => String)
    procedureModifier1: string;

    @Field(type => String)
    procedureModifier2: string;

    @Field(type => String)
    procedureModifier3: string;

    @Field(type => String)
    procedureModifier4: string;

    @Field(type => String)
    procedureUnitCount: string;

    @Field(type => Int)
    procUomRefId: number;

    @Field(type => String)
    procUomRefCd: string;

    @Field(type => Int)
    serviceDescRefId: number;

    @Field(type => Int)
    serviceDetailRefId: number;

    @Field(type => String)
    serviceDetailRefCd: string;
}