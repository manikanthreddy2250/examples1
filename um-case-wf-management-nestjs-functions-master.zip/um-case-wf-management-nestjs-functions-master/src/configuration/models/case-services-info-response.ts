import {Field, Int, ObjectType} from "@nestjs/graphql";
import {CaseProviderInfoResponse} from "./case-provider-info-response";
import {CaseServiceNonFacilityResponse} from "./case-service-non-facility-response";

@ObjectType()
export class CaseServicesInfoResponse {
    @Field(type => Int)
    caseId: number;

    @Field(type => Int,{nullable: true})
    serviceId: number;

    @Field(type => String,{nullable: true})
    procedureCode: string;

    @Field(type => String,{nullable: true})
    procedureDescription: string;

    @Field(type => Int,{nullable: true})
    inacInd: number;

    @Field(type => Int,{nullable: true})
    procedureCodeSchemaRefId: number;

    @Field(type => String,{nullable: true})
    procedureOtherText: string;

    @Field(type => [CaseProviderInfoResponse])
    servicingProviderInfo: CaseProviderInfoResponse[];

    @Field(type => [CaseServiceNonFacilityResponse])
    serviceNonFacility: CaseServiceNonFacilityResponse[];
}
