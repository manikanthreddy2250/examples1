import {Field, ObjectType} from "@nestjs/graphql";


@ObjectType()
export class Checklist {

    @Field({nullable: true})
    taskNameRefIds? : String;
}
