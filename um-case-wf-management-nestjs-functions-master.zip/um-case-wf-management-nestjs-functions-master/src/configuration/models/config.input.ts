import {Field, InputType} from "@nestjs/graphql";

@InputType()
export class ConfigInput {
    @Field(type => String)
    cnfg_key: string;
}