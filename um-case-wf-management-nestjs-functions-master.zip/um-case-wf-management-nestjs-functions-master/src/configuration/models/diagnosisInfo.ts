export class DiagnosisInfo{

    public diagnosisCode: string;
    public diagnosisDescription: string;
    public primaryInd: number;

    constructor(info? : DiagnosisInfo) {
        if(info) {
            this.diagnosisCode = info.diagnosisCode;
            this.diagnosisDescription = info.diagnosisDescription;
            this.primaryInd = info.primaryInd;
        }
    }
}
