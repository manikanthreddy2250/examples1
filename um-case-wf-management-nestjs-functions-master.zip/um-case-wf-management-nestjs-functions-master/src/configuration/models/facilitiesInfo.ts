export class FacilitiesInfo {

    public actualAdmissionDate: string;
    public actualDischargeDate: string;
    public expectedAdmissionDate: string;
    public expectedDischargeDate: string;
    public placeOfServiceRefId: number;
    public serviceDescriptionRefId: number;
    public serviceDetailRefId: number;
    public placeOfServiceRefCode: string;
    public placeOfServiceRefDescription: string;
    public placeOfServiceRefDisplay: string;
    public serviceDescriptionRefCode: string;
    public serviceDescriptionRefDesc: string;
    public serviceDescriptionRefDisplay: string;
    public serviceDetailRefCode: string;
    public serviceDetailRefDescription: string;
    public serviceDetailRefDisplay: string;

    constructor(info? : FacilitiesInfo) {
        if(info) {
            this.actualAdmissionDate = info.actualAdmissionDate;
            this.actualDischargeDate = info.actualDischargeDate;
            this.expectedAdmissionDate = info.expectedAdmissionDate;
            this.expectedDischargeDate = info.expectedDischargeDate;
            this.placeOfServiceRefId = info.placeOfServiceRefId;
            this.serviceDescriptionRefId = info.serviceDescriptionRefId;
            this.serviceDetailRefId = info.serviceDetailRefId;
            this.placeOfServiceRefCode = info.placeOfServiceRefCode;
            this.placeOfServiceRefDescription = info.placeOfServiceRefDescription;
            this.placeOfServiceRefDisplay = info.placeOfServiceRefDisplay;
            this.serviceDescriptionRefCode = info.serviceDescriptionRefCode;
            this.serviceDescriptionRefDesc = info.serviceDescriptionRefDesc;
            this.serviceDescriptionRefDisplay = info.serviceDescriptionRefDisplay;
            this.serviceDetailRefCode = info.serviceDetailRefCode;
            this.serviceDetailRefDescription = info.serviceDetailRefDescription;
            this.serviceDetailRefDisplay = info.serviceDetailRefDisplay;
        }
    }
}
