import {Field, InputType} from "@nestjs/graphql";
import {HscInput} from "./hsc.input";

@InputType()
export class GetCaseDataForWorkflowRequest {
    @Field()
    hsc: HscInput;
}