import {Field, ObjectType} from "@nestjs/graphql";
import {CaseDataResponse} from "./case-data-response";

@ObjectType()
export class GetCaseDataForWorkflowResponse {
    @Field(type => CaseDataResponse)
    caseData: CaseDataResponse;
}