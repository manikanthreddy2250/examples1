import {Field, InputType} from "@nestjs/graphql";
import {ConfigInput} from "./config.input";

@InputType()
export class GetWorkflowTaskMetadataRequest {
    @Field()
    config: ConfigInput;
}