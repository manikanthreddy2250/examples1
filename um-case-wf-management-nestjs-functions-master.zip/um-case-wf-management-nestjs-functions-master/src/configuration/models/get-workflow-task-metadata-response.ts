import {Field, ObjectType} from "@nestjs/graphql";
import {TaskMetadataResponse} from "./task-metadata-response";

@ObjectType()
export class GetWorkflowTaskMetadataResponse {
    @Field(type => [TaskMetadataResponse])
    taskMetadata: TaskMetadataResponse[];
}