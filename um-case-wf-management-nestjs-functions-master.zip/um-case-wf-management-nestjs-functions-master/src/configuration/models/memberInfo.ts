export class MemberCoverageInfo{
    public individualId: number;
    public policyNumber: string;
    public coverageEffectiveDate: string;
    public coverageEndDate: string;
    public memberCoverageId: number;
    public productCodeRefId: number;
    public sourceSystem: string;
    public productCategoryType: string;
    public coverageTypeDescription: string;
    public individualkeyTypeRefId: number;
    public claimPlatformRefId: number;
    public lob:string;
    public stateOfIssue:string;

    constructor(info?: MemberCoverageInfo) {
        if (info) {
            this.individualId = info.individualId;
            this.policyNumber = info.policyNumber;
            this.coverageEffectiveDate = info.coverageEffectiveDate;
            this.coverageEndDate = info.coverageEndDate;
            this.productCodeRefId = info.productCodeRefId;
            this.sourceSystem = info.sourceSystem;
            this.productCategoryType = info.productCategoryType;
            this.coverageTypeDescription = info.coverageTypeDescription;
            this.individualkeyTypeRefId = info.individualkeyTypeRefId;
            this.claimPlatformRefId = info.claimPlatformRefId;
            this.memberCoverageId = info.memberCoverageId;
            this.lob = info.lob;
            this.stateOfIssue = info.stateOfIssue;
        }
    }

}
