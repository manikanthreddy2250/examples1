export class ProvKey {
    public provKeyValue: string;
    public provKeyTypeRefId: number;

    constructor(info? : ProvKey) {
        if(info) {
            this.provKeyValue = info.provKeyValue;
            this.provKeyTypeRefId = info.provKeyTypeRefId;

        }
    }
}

export class ProviderLocAffilDetails {
    public providerId: number;
    public providerAddressId: number;
    public providerCategoryTypeRefId: number;
    public provKey: Array<ProvKey>;
    public medNecRestrictionType: string;

    constructor(info? : ProviderLocAffilDetails) {
        if(info) {
            this.providerId = info.providerId;
            this.providerAddressId = info.providerAddressId;
            this.providerCategoryTypeRefId = info.providerCategoryTypeRefId;
            this.provKey = info.provKey;
            this.medNecRestrictionType = info.medNecRestrictionType;
        }
    }
}
export class ServicingProviderInfo {

    public specialtyRefId: number;
    public telecomAddressId: string;
    public caseProviderId: number;
    public providerRoleRefId: number;
    public networkSteerageReasonRefId: number;
    public networkStatusRefId: number;
    public providerTax: number;
    public providerMPIN: number;
    public providerNPI: number;
    public providerLocationAffiliationDetail: ProviderLocAffilDetails;
    public providerLocationAffiliationId: number;

  constructor(info? : ServicingProviderInfo) {
        if(info) {
            this.specialtyRefId = info.specialtyRefId;
            this.telecomAddressId = info.telecomAddressId;
            this.caseProviderId = info.caseProviderId;
            this.providerTax = info.providerTax;
            this.providerMPIN = info.providerMPIN;
            this.providerNPI = info.providerNPI;
            this.providerRoleRefId = info.providerRoleRefId;
            this.networkSteerageReasonRefId = info.networkSteerageReasonRefId;
            this.networkStatusRefId = info.networkStatusRefId;
            this.providerLocationAffiliationId = info.providerLocationAffiliationId;
            this.providerLocationAffiliationDetail = info.providerLocationAffiliationDetail;
        }
    }
}

export class RequestingProviderInfo {

    public specialtyRefId: number;
    public telecomAddressId: string;
    public caseProviderId: number;
    public providerRoleRefId: number;
    public providerTax: number;
    public providerMPIN: number;
    public providerNPI: number;
    public networkSteerageReasonRefId: number;
    public networkStatusRefId: number;
    public providerLocationAffiliationDetail: ProviderLocAffilDetails;
    public providerLocationAffiliationId: number;

    constructor(info? : RequestingProviderInfo) {
        if(info) {
            this.specialtyRefId = info.specialtyRefId;
            this.telecomAddressId = info.telecomAddressId;
            this.caseProviderId = info.caseProviderId;
            this.providerTax = info.providerTax;
            this.providerMPIN = info.providerMPIN;
            this.providerNPI = info.providerNPI;
            this.providerRoleRefId = info.providerRoleRefId;
            this.networkSteerageReasonRefId = info.networkSteerageReasonRefId;
            this.networkStatusRefId = info.networkStatusRefId;
            this.providerLocationAffiliationId = info.providerLocationAffiliationId;
            this.providerLocationAffiliationDetail = info.providerLocationAffiliationDetail
        }
    }
}

export class AttendingProviderInfo {

    public specialtyRefId: number;
    public telecomAddressId: string;
    public caseProviderId: number;
    public providerRoleRefId: number;
    public providerTax: number;
    public providerMPIN: number;
    public providerNPI: number;
    public networkSteerageReasonRefId: number;
    public networkStatusRefId: number;
    public providerLocationAffiliationDetail: ProviderLocAffilDetails;
    public providerLocationAffiliationId: number;

    constructor(info? : AttendingProviderInfo) {
        if(info) {
            this.specialtyRefId = info.specialtyRefId;
            this.telecomAddressId = info.telecomAddressId;
            this.caseProviderId = info.caseProviderId;
            this.providerTax = info.providerTax;
            this.providerMPIN = info.providerMPIN;
            this.providerNPI = info.providerNPI;
            this.providerRoleRefId = info.providerRoleRefId;
            this.networkSteerageReasonRefId = info.networkSteerageReasonRefId;
            this.networkStatusRefId = info.networkStatusRefId;
            this.providerLocationAffiliationId = info.providerLocationAffiliationId;
            this.providerLocationAffiliationDetail = info.providerLocationAffiliationDetail
        }
    }
}

export class AdmittingProviderInfo {

    public specialtyRefId: number;
    public telecomAddressId: string;
    public caseProviderId: number;
    public providerRoleRefId: number;
    public providerTax: number;
    public providerMPIN: number;
    public providerNPI: number;
    public networkSteerageReasonRefId: number;
    public networkStatusRefId: number;
    public providerLocationAffiliationDetail: ProviderLocAffilDetails;
    public providerLocationAffiliationId: number;

    constructor(info? : AdmittingProviderInfo) {
        if(info) {
            this.specialtyRefId = info.specialtyRefId;
            this.telecomAddressId = info.telecomAddressId;
            this.caseProviderId = info.caseProviderId;
            this.providerTax = info.providerTax;
            this.providerMPIN = info.providerMPIN;
            this.providerNPI = info.providerNPI;
            this.providerRoleRefId = info.providerRoleRefId;
            this.networkSteerageReasonRefId = info.networkSteerageReasonRefId;
            this.networkStatusRefId = info.networkStatusRefId;
            this.providerLocationAffiliationId = info.providerLocationAffiliationId;
            this.providerLocationAffiliationDetail = info.providerLocationAffiliationDetail
        }
    }
}

export class FacilityProviderInfo {

    public specialtyRefId: number;
    public telecomAddressId: string;
    public caseProviderId: number;
    public providerRoleRefId: number;
    public providerTax: number;
    public providerMPIN: number;
    public providerNPI: number;
    public networkSteerageReasonRefId: number;
    public networkStatusRefId: number;
    public providerLocationAffiliationDetail: ProviderLocAffilDetails;
    public providerLocationAffiliationId: number;
    public contractDetails: string;

    constructor(info? : FacilityProviderInfo) {
        if(info) {
            this.specialtyRefId = info.specialtyRefId;
            this.telecomAddressId = info.telecomAddressId;
            this.caseProviderId = info.caseProviderId;
            this.providerTax = info.providerTax;
            this.providerMPIN = info.providerMPIN;
            this.providerNPI = info.providerNPI;
            this.providerRoleRefId = info.providerRoleRefId;
            this.networkSteerageReasonRefId = info.networkSteerageReasonRefId;
            this.networkStatusRefId = info.networkStatusRefId;
            this.providerLocationAffiliationId = info.providerLocationAffiliationId;
            this.providerLocationAffiliationDetail = info.providerLocationAffiliationDetail;
            this.contractDetails = info.contractDetails
        }
    }
}
