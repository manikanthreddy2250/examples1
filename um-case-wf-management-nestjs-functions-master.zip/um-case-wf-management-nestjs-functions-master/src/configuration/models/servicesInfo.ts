export class ServicesInfo {

    public caseId: number;
    public serviceId: number;
    public procedureCode: string;
    public procedureDescription: string;
    public inacInd: number;
    public procedureCodeSchemaRefId: number;
    public procedureOtherText: string;
    public servicingProviderInfo: string;

    public serviceNonFacility: {
        plsrvRefId: number;
        procFreqRefId: number;
        procedureModifier1: string;
        procedureModifier2: string;
        procedureModifier3: string;
        procedureModifier4: string;
        procedureUnitCount: string;
        procUomRefId: number;
        procUomRefCd: string;
        serviceDescRefId: number;
        serviceDetailRefId: number;
        serviceDetailRefCd: string;
        serviceEndDate: null,
        serviceStartDate: null,
        unitPerfrequencyCount: null,
    };

    constructor(info? : ServicesInfo) {
        if(info) {
            this.caseId = info.caseId;
            this.serviceId = info.serviceId;
            this.procedureCode = info.procedureCode;
            this.inacInd = info.inacInd;
            this.procedureCodeSchemaRefId = info.procedureCodeSchemaRefId;
            this.procedureOtherText = info.procedureOtherText;
            this.servicingProviderInfo = info.servicingProviderInfo;
            this.serviceNonFacility = info.serviceNonFacility
        }
    }
}
