import {Field, ObjectType} from "@nestjs/graphql";
import {Task} from "./task";

@ObjectType()
export class TaskMetadataResponse {
    @Field(type => String)
    taskCategoryRefId: string;

    @Field(type => String)
    isManual: string;

    @Field(type => String)
    taskCategoryName: string;

    @Field(type => [Task])
    tasks: Task[];
}