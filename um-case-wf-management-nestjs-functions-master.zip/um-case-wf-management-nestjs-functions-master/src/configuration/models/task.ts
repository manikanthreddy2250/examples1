import {Field, ObjectType} from "@nestjs/graphql";
import {Checklist} from "./checklist";
@ObjectType()
export class Task {
    @Field(type => String)
    taskName: string;

    @Field(type => String)
    isManual: string;

    @Field(type => String)
    taskDescription: string;

    @Field(type => String)
    taskNameRefId: string;

    @Field(type => String)
    taskWorkQueueRefId: string;

    @Field(type => [Checklist],{nullable: true})
    checklist: Checklist[];
}