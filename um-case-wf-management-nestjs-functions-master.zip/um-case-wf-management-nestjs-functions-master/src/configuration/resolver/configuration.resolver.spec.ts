import { Test, TestingModule } from '@nestjs/testing';
import { Injectable } from "@nestjs/common";
import { of } from "rxjs";
import { ConfigurationResolver } from "./configuration.resolver";
import {GetWorkflowTaskMetadataRequest} from "../models/get-workflow-task-metadata-request";
import {GetWorkflowTaskMetadataResponse} from "../models/get-workflow-task-metadata-response";
import {TaskMetadataService} from "../service/task-metadata/task-metadata.service";
import {GetCaseDataForWorkflowRequest} from "../models/get-case-data-for-workflow-request";
import {GetCaseDataForWorkflowResponse} from "../models/get-case-data-for-workflow-response";
import {UtilService} from "../service/util/util.service";
import {Context} from "@nestjs/graphql";
import {ConfigModule} from "@nestjs/config";
import { ExecutionContext, HttpModule, Logger } from '@nestjs/common';

@Injectable()
class MockTaskMetadataService {

    getSysConfigRefIdsByWF(getWorkflowTaskMetadataRequest: GetWorkflowTaskMetadataRequest): Promise<GetWorkflowTaskMetadataResponse> {
        const res: any  = {
            "data": [
                {
                    "Configkey": "inpatientBaseWF"
                }
            ]
        };
        return of(res).toPromise();
    }

    getSysConfigDetailsByWF(configRefResponse): Promise<GetWorkflowTaskMetadataResponse> {
        const res: any  = {
            "data": {
                "getWorkflowTaskMetadata": {
                    "taskMetadata": [
                        {
                            "taskCategoryId": "72060",
                            "isManual": "false",
                            "taskCategoryName": "Eligibility",
                            "tasks": [
                                {
                                    "taskName": "Eligibility check",
                                    "isManual": "false",
                                    "taskDescription": ""
                                },
                                {
                                    "taskName": "Update eligibility",
                                    "isManual": "false",
                                    "taskDescription": ""
                                },
                                {
                                    "taskName": "Confirm eligibility",
                                    "isManual": "false",
                                    "taskDescription": ""
                                }
                            ]
                        }
                    ]
                }
            }
        };
        return of(res).toPromise();
    }
}

@Injectable()
class MockUtilService {

    async getCaseDataForWorkflow(getCaseDataForWorkflowRequest: GetCaseDataForWorkflowRequest): Promise<GetCaseDataForWorkflowResponse>  {
        const res: any  = {
            "caseData": [
                {
                    "caseId": "13012"
                }
            ]
        };
        return of(res).toPromise();
    }
}

@Injectable()
class MockgetCaseDataForWorkflowService {
    getCaseDataForWorkflow(getCaseDataForWorkflowRequest : GetCaseDataForWorkflowRequest, @Context() context){
        const res: any  = {
            "hsc_id": '1234'
        };
        return of(res).toPromise();
    }
}

describe('ConfigurationResolver', () => {
  let resolver: ConfigurationResolver;
  let context = {req: {headers: {}}};
  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
        imports: [ ConfigModule ],
      providers: [ConfigurationResolver, Logger, { provide: TaskMetadataService, useClass: MockTaskMetadataService }, { provide: UtilService, useClass: MockUtilService }],
    }).compile();

    resolver = module.get<ConfigurationResolver>(ConfigurationResolver);
  });

  it('should be defined', () => {
    expect(resolver).toBeDefined();
  });

  it('should call getWorkflowTaskMetadata', () => {
    const getWorkflowTaskMetadataRequest: GetWorkflowTaskMetadataRequest = {config:{cnfg_key:"inpatientBaseWF"}};
    const response = resolver.getWorkflowTaskMetadata(getWorkflowTaskMetadataRequest, context.req);
    expect(response).toBeTruthy();
  });

  it('should call getCaseDataForWorkflow', () => {
    const getCaseDataForWorkflowRequest: GetCaseDataForWorkflowRequest = {hsc:{hsc_id:13012}};
    const response = resolver.getCaseDataForWorkflow(getCaseDataForWorkflowRequest, context.req);
    expect(response).toBeTruthy();
  });
});