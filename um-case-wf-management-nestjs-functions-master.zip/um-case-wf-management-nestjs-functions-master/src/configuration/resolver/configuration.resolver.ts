import { Args, Query, Resolver, Context, Mutation } from '@nestjs/graphql';
import {UseFilters, UseGuards} from "@nestjs/common";
import {TaskMetadataService} from "../service/task-metadata/task-metadata.service";
import {AuthGuard} from "../../auth/auth.guard";
import {AllExceptionsFilter} from "../../filters/graphql-exception.filter";
import {GetWorkflowTaskMetadataRequest} from "../models/get-workflow-task-metadata-request";
import {GetWorkflowTaskMetadataResponse} from "../models/get-workflow-task-metadata-response";
import {UtilService} from "../service/util/util.service";
import {GetCaseDataForWorkflowRequest} from "../models/get-case-data-for-workflow-request";
import {GetCaseDataForWorkflowResponse} from "../models/get-case-data-for-workflow-response";
import {RolesGuard} from "../../auth/roles.guard";
import {Role} from "../../decorators/roles";
import {Roles} from "../../decorators/roles.decorator";

@Resolver()
export class ConfigurationResolver {
  constructor(private taskMetadataService: TaskMetadataService, private utilService: UtilService) {}

  @Query(returns => GetWorkflowTaskMetadataResponse, {description: "Query to get workflow task metadata"})
  @UseGuards(AuthGuard, RolesGuard)
  @Roles(Role.CASE_MGMT_ADMIN, Role.CASE_MGMT_CDU, Role.CASE_MGMT_MD, Role.CASE_MGMT_NURSE, Role.CASE_MGMT_SYSTEM)
  @UseFilters(new AllExceptionsFilter())
  async getWorkflowTaskMetadata(@Args('getWorkflowTaskMetadataRequest') getWorkflowTaskMetadataRequest : GetWorkflowTaskMetadataRequest, @Context() context) {
    const configRefResponse = await this.taskMetadataService.getSysConfigRefIdsByWF(getWorkflowTaskMetadataRequest, context.req);
    return this.taskMetadataService.getSysConfigDetailsByWF(configRefResponse, context.req);
  }

  @Query(returns => GetCaseDataForWorkflowResponse, {description: "Query to get case data for workflow"})
  @UseGuards(AuthGuard, RolesGuard)
  @Roles(Role.CASE_MGMT_ADMIN, Role.CASE_MGMT_CDU, Role.CASE_MGMT_MD, Role.CASE_MGMT_NURSE, Role.CASE_MGMT_SYSTEM)
  @UseFilters(new AllExceptionsFilter())
  async getCaseDataForWorkflow(@Args('getCaseDataForWorkflowRequest') getCaseDataForWorkflowRequest : GetCaseDataForWorkflowRequest, @Context() context) {
    return this.utilService.getCaseDataForWorkflow(getCaseDataForWorkflowRequest, context.req);
  }
}
