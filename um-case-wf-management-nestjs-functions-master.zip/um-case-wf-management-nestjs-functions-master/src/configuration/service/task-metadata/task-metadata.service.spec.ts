import { Test, TestingModule } from '@nestjs/testing';
import { Injectable } from "@nestjs/common";
import { GraphQLClient } from "graphql-request/dist";
import {RequestDocument} from "graphql-request/dist/types";
import { of } from "rxjs";
import { HttpRequest } from "@azure/functions";
import { TaskMetadataService } from "./task-metadata.service";
import {GetWorkflowTaskMetadataRequest} from "../../models/get-workflow-task-metadata-request";
import {GetWorkflowTaskMetadataResponse} from "../../models/get-workflow-task-metadata-response";
import {applicationConstants} from '../../../health-service/shared/constants/applicationConstants';
import { ConfigService } from '@nestjs/config';
import axios from "axios";
import {LoggerModule} from "nestjs-pino";

@Injectable()
class MockConfigService {

  get(endpoint) {
    const res: String = "URL";
    return of(res).toPromise();
  }
}

describe('TaskMetadataService', () => {
    let service: TaskMetadataService;

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            imports: [LoggerModule.forRoot()],
            providers: [TaskMetadataService, { provide: ConfigService, useClass: MockConfigService }],
        }).compile();

        service = module.get<TaskMetadataService>(TaskMetadataService);
    });

    it('should be defined', () => {
        expect(service).toBeDefined();
    });

    it('should call getSysConfigDetailsByWF', () => {
        let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
        const configRefResponse = {"data":[{"value": "{ \"taskMetaDataCategoryRefIds\": [ 72142 ], \"taskMetaDataConfigKey\": \"ipBaseWF\" }"}]};
        service.getSysConfigDetailsByWF(configRefResponse, httpRequest).then((res) => {
            expect(res).toBeTruthy();
        });
    });

    it('should call getSysConfigRefIdsByWF', () => {
        let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
        const getWorkflowTaskMetadataRequest: GetWorkflowTaskMetadataRequest = {config:{cnfg_key:"inpatientBaseWF"}};
        service.getSysConfigRefIdsByWF(getWorkflowTaskMetadataRequest, httpRequest).then((res) => {
            expect(res).toBeTruthy();
        });
    });

    it('should call taskMetadataResponseMapping', () => {
        const configResponse = [{'value': '{"taskmetadata":{"taskCategoryRefId":"72142","isManual":"false","taskCategoryName":"Validations","task":[{"taskName":"Eligibility","taskNameRefId":"72134","isManual":"false","taskWorkQueueRefId":"72133","taskDescription":""},{"taskName":"Provider","taskNameRefId":"72135","isManual":"false","taskWorkQueueRefId":"72133","taskDescription":""},{"taskName":"Network Status","taskNameRefId":"72136","isManual":"false","taskWorkQueueRefId":"","taskDescription":""},{"taskName":"SOS","taskNameRefId":"72137","isManual":"false","taskWorkQueueRefId":"72133","taskDescription":""},{"taskName":"LOC","taskNameRefId":"72138","isManual":"true","taskWorkQueueRefId":"72133","CheckList":{"TaskNameRefIds":["4566","7777"]},"taskDescription":""},{"taskName":"LOS","taskNameRefId":"72139","isManual":"true","taskWorkQueueRefId":"72133","CheckList":{"TaskNameRefIds":["72134","72135"]},"taskDescription":""},{"taskName":"P2P Review","taskNameRefId":"72140","isManual":"false","taskWorkQueueRefId":"72133","taskDescription":""},{"taskName":"Decision","taskNameRefId":"72141","isManual":"false","taskWorkQueueRefId":"72133","taskDescription":""}]}}'}]
        service.taskMetadataResponseMapping(configResponse).then((res) => {
            expect(res).toBeTruthy();
        });
    });
});