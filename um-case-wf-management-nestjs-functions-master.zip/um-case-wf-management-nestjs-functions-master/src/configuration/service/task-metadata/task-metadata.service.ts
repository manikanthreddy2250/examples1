import { Injectable } from '@nestjs/common';
import {HttpRequest} from "@azure/functions";
import axios from "axios";
import {GetWorkflowTaskMetadataRequest} from "../../models/get-workflow-task-metadata-request";
import {GetWorkflowTaskMetadataResponse} from "../../models/get-workflow-task-metadata-response";
import {applicationConstants} from '../../../health-service/shared/constants/applicationConstants';
import { ConfigService } from '@nestjs/config';
import {TaskMetadataResponse} from "../../models/task-metadata-response";
import {Task} from "../../models/task";
import {Checklist} from "../../models/checklist";
import {Logger} from "nestjs-pino";

@Injectable()
export class TaskMetadataService {
    constructor(private readonly configService: ConfigService, private readonly logger: Logger) {}

    async getSysConfigDetailsByWF(configRefResponse, httpRequest: HttpRequest) {
        const configHttpUrl = this.configService.get<string>('CONFIGURATION_API_ENDPOINT');
        const configDetails = [];
    
        if (configRefResponse?.data && configRefResponse?.data.length > 0) {
            const configValue = JSON.parse(configRefResponse.data[0].value);
            let sysConfigDetailsResponse: any;
            const taskMetadataKey = configValue.taskMetaDataConfigKey;

            if (taskMetadataKey === undefined) {
                const result = await this.taskMetadataResponseMapping(configRefResponse.data);
                configDetails.push(result);
            } else {
                await Promise.all(configValue.taskMetaDataCategoryRefIds.map(async (Refvalue) => {
                    const cnfgKey = taskMetadataKey + '_' + Refvalue;
                    const configRequestUrl = configHttpUrl + '/' +
                    applicationConstants.CASE_WF_MGMT_UI_APP_NAME + '/' +
                    applicationConstants.CASE_WF_MGMT_UI_APP_VERSION + '/' +
                    cnfgKey;

                    const token = {
                        'x-bpm-func-role': httpRequest.headers['x-bpm-func-role'],
                        'Authorization': httpRequest.headers['authorization']
                    };
                    try {
                        sysConfigDetailsResponse = await axios.get(configRequestUrl, {headers: token});
                        const result = await this.taskMetadataResponseMapping(sysConfigDetailsResponse.data);
                        configDetails.push(result);
                    } catch (e) {
                        this.logger.error("Error while calling CaseWF TaskMetadataService getSysConfigDetailsByWF (configRefResponse: " + configRefResponse + ", httpRequest: " + httpRequest + ") " + e);
                    }
                }));
            }
        }

        const response: GetWorkflowTaskMetadataResponse = {
            "taskMetadata": configDetails
        };

        return response;
    }

    async getSysConfigRefIds(configKey,httpRequest)
    {
        const getWorkflowTaskMetadataRequest = {
                "config": {
                    "cnfg_key": configKey

            }
        };
       return this.getSysConfigRefIdsByWF(getWorkflowTaskMetadataRequest, httpRequest)
    }

    async getSysConfigRefIdsByWF(getWorkflowTaskMetadataRequest : GetWorkflowTaskMetadataRequest, httpRequest: HttpRequest) {
        const configHttpUrl = this.configService.get<string>('CONFIGURATION_API_ENDPOINT');
        let configResponse: any;
    
        const configRequestUrl = configHttpUrl + '/' +
            applicationConstants.CASE_WF_MGMT_UI_APP_NAME + '/' +
            applicationConstants.CASE_WF_MGMT_UI_APP_VERSION + '/' +
            getWorkflowTaskMetadataRequest.config.cnfg_key;

        const token = {
            'x-bpm-func-role': httpRequest.headers['x-bpm-func-role'],
            'Authorization': httpRequest.headers['authorization']
        };

        try {
            configResponse = await axios.get(configRequestUrl, {headers: token});
        } catch (e) {
            this.logger.error("Error while calling CaseWF TaskMetadataService getSysConfigRefIdsByWF (getWorkflowTaskMetadataRequest: " + getWorkflowTaskMetadataRequest + ", httpRequest: " + httpRequest + ") " + e);        }
    
        return configResponse;
    }

    async taskMetadataResponseMapping(configResponse) {
        const taskmetadata = JSON.parse(configResponse[0].value).taskmetadata;
        const response = new TaskMetadataResponse();
        response.taskCategoryRefId = taskmetadata.taskCategoryRefId;
        response.isManual = taskmetadata.isManual;
        response.taskCategoryName = taskmetadata.taskCategoryName;
        const tasks = taskmetadata.task.map(t => {
            const task = new Task();
            task.taskName = t.taskName;
            task.isManual = t.isManual;
            task.taskDescription = t.taskDescription;
            task.taskNameRefId = t.taskNameRefId;
            task.taskWorkQueueRefId = t.taskWorkQueueRefId;
            const checklist = t.CheckList?.TaskNameRefIds.map(id => {
                const clist = new Checklist();
                clist.taskNameRefIds = id;
                return clist;
            });
            task.checklist = checklist;

            return task;
        });
        response.tasks = tasks;
        return response;
    }
}
