import { Test, TestingModule } from '@nestjs/testing';
import {HttpModule, Injectable} from "@nestjs/common";
import { HttpRequest } from "@azure/functions";
import {GetCaseDataForWorkflowRequest} from "../../models/get-case-data-for-workflow-request";
import {AuthData} from "../../models/authData";
import {UtilClient} from '../../../health-service/shared/graphql/utildomain/utilClient';
import { GraphQLClient } from "graphql-request/dist";
import {ReferenceClient} from "../../../health-service/shared/graphql/referenceDomain/referenceClient";
import {UtilService} from "./util.service";
import {ConfigService} from '@nestjs/config';
import {RequestDocument} from "graphql-request/dist/types";
import {of} from "rxjs";
import {LoggerModule} from "nestjs-pino";

@Injectable()
class MockUtilClient {
    public getGraphqlClient(): GraphQLClient {
        return new MockGraphQLClient('testurl');
    }
}

class MockReferenceClient {
    public getGraphqlClient(httpRequest: HttpRequest): GraphQLClient {
        return new MockReferenceGraphQLClient('testurl');
    }
}

class MockReferenceGraphQLClient extends GraphQLClient{
    request(document: RequestDocument, variables?: any, requestHeaders?: any): Promise<any>{
        if(variables.diag_cds) {
        return of(
            {
                "icd10": [
                    {
                        "diag_cd": "J42",
                        "full_desc": "Unspecified chronic bronchitis",
                        "shrt_desc": "UNSPECIFIED CHRONIC BRONCHITIS",
                        "cd_desc": "UNSPECIFIED CHRONIC BRONCHITIS"
                    }
                ]
            }
        ).toPromise();
    }else{
            return of(
                {
                    "cpt4": [
                        {
                            "shrt_desc": "MOPATH PROCEDURE LEVEL 4",
                            "proc_cd": "81403"
                        }
                    ]
                }
            ).toPromise();
        }
    }
}

class MockGraphQLClient extends GraphQLClient{
    request(document: RequestDocument, variables?: any, requestHeaders?: any): Promise<any>{
        return of({"hsc":[{"hsc_id":13012,"creat_dttm":"2021-02-22T16:18:13.128","creat_user_id":"001559434","indv_id":503926748,"indv_key_typ_ref_id":2757,"indv_key_val":"16440436900","mbr_cov_dtl":{"indv_id":503926748,"pol_nbr":"0128855","cov_eff_dt":"2013-01-01","cov_end_dt":"9999-12-31","mbr_cov_id":96963692,"productCode":214,"indv_key_val":"16440436900","productCatgyTpe":null,"coverageTypeDesc":"Medical","indv_key_typ_ref_id":2757,"claim_platform_ref_Id":363},"hsc_sts_ref_id":19274,"flwup_cntc_dtl":{"Primary_Cntct":{"department":null,"email":null,"phone":"112-333-4444","fax":null,"creat_dttm":"2021-02-22T16:18:13.198Z","chg_dttm":"2021-02-22T16:24:07.512Z","creat_user_id":"001559434","role":null,"name":"test"}},"rev_prr_ref_id":3754,"rev_prr_ref_cd":{"ref_id":3754,"ref_cd":"1","ref_desc":"Routine","ref_dspl":"Routine"},"srvc_set_ref_id":3737,"srvc_set_ref_cd":{"ref_id":3737,"ref_cd":"1","ref_desc":"Inpatient","ref_dspl":"Inpatient"},"hsc_keys":[{"hsc_id":13012,"hsc_key_val":"8fa66e3d-7529-11eb-908f-1ef9496236e0","inac_ind":0,"hsc_key_typ_ref_id":19517}],"hsc_srvcs":[{"hsc_id":13012,"hsc_srvc_id":11528,"inac_ind":0,"proc_cd":"81403","proc_cd_schm_ref_id":3767,"proc_othr_txt":null,"srvc_hsc_prov_id":4555,"hsc_srvc_non_facls":[],"proc_desc":"MOLECULAR PATHOLOGY PROCEDURE LEVEL 4"}],"hsc_facls":[{"actul_admis_dttm":null,"actul_dschrg_dttm":null,"expt_admis_dt":"2021-02-22","expt_dschrg_dt":"2021-02-25","plsrv_ref_id":3743,"plsrv_ref_cd":{"ref_id":3743,"ref_cd":"21","ref_desc":"Acute Hospital","ref_dspl":"Acute Hospital"},"srvc_desc_ref_id":4347,"srvc_desc_ref_cd":{"ref_id":4347,"ref_cd":"1","ref_desc":"Scheduled","ref_dspl":"Scheduled"},"srvc_dtl_ref_id":4307,"srvc_dtl_ref_cd":{"ref_id":4307,"ref_cd":"2","ref_desc":"Surgical","ref_dspl":"Surgical"}}],"hsc_diags":[{"hsc_diag_id":3534,"diag_cd":"M25.14","inac_ind":0,"diag_desc":"FISTULA HAND"}],"hsr_notes":[{"hsr_note_id":1794,"note_titl_txt":"test","note_txt_lobj":"testDate","creat_user_id":"001559434","note_typ_ref_id":null,"src_user_nm":"provider","creat_dttm":"2021-02-22T16:24:33.285"}],"hsc_provs":[{"auto_aprv_ltr_ind":null,"chg_sys_ref_id":null,"chg_user_id":"001559434","creat_sys_ref_id":null,"creat_user_id":"001559434","data_qlty_iss_list":null,"data_secur_rule_list":null,"end_dt":null,"hsc_prov_end_rsn_ref_id":null,"ltr_opt_out_cc_ind":null,"med_rec_nbr":null,"ntwk_strg_rsn_ref_id":null,"ntwk_sts_ref_id":null,"prov_loc_affil_dtl":{"providerDetails":{"prov_id":10455660,"prov_key":[{"prov_key_val":"1710081369","prov_key_typ_ref_id":2782},{"prov_key_val":"288158608","prov_key_typ_ref_id":16333},{"prov_key_val":"1710081369","prov_key_typ_ref_id":2783}],"prov_adr_id":117625635,"prov_cat_typ_ref_id":16310}},"prov_loc_affil_id":null,"spcl_ref_id":16364,"strt_dt":null,"telcom_adr_id":"6628691595","updt_ver_nbr":0,"hsc_prov_roles":[{"hsc_prov_id":4553,"prov_role_ref_id":3761}]},{"auto_aprv_ltr_ind":null,"chg_sys_ref_id":null,"chg_user_id":"001559434","creat_sys_ref_id":null,"creat_user_id":"001559434","data_qlty_iss_list":null,"data_secur_rule_list":null,"end_dt":null,"hsc_prov_end_rsn_ref_id":null,"ltr_opt_out_cc_ind":null,"med_rec_nbr":null,"ntwk_strg_rsn_ref_id":null,"ntwk_sts_ref_id":null,"prov_loc_affil_dtl":{"providerDetails":{"prov_id":6675410,"prov_key":[{"prov_key_val":"1255539573","prov_key_typ_ref_id":2782},{"prov_key_val":null,"prov_key_typ_ref_id":16333},{"prov_key_val":"1255539573","prov_key_typ_ref_id":2783}],"prov_adr_id":98265064,"prov_cat_typ_ref_id":16309}},"prov_loc_affil_id":null,"spcl_ref_id":16536,"strt_dt":null,"telcom_adr_id":"7186222000","updt_ver_nbr":0,"hsc_prov_roles":[{"hsc_prov_id":4554,"prov_role_ref_id":3758}]},{"auto_aprv_ltr_ind":null,"chg_sys_ref_id":null,"chg_user_id":"001559434","creat_sys_ref_id":null,"creat_user_id":"001559434","data_qlty_iss_list":null,"data_secur_rule_list":null,"end_dt":null,"hsc_prov_end_rsn_ref_id":null,"ltr_opt_out_cc_ind":null,"med_rec_nbr":null,"ntwk_strg_rsn_ref_id":null,"ntwk_sts_ref_id":null,"prov_loc_affil_dtl":{"providerDetails":{"prov_id":6675410,"prov_key":[{"prov_key_val":"1255539573","prov_key_typ_ref_id":2782},{"prov_key_val":null,"prov_key_typ_ref_id":16333},{"prov_key_val":"1255539573","prov_key_typ_ref_id":2783}],"prov_adr_id":98265064,"prov_cat_typ_ref_id":16309}},"prov_loc_affil_id":null,"spcl_ref_id":16536,"strt_dt":null,"telcom_adr_id":"7186222000","updt_ver_nbr":0,"hsc_prov_roles":[{"hsc_prov_id":4555,"prov_role_ref_id":3765}]},{"auto_aprv_ltr_ind":null,"chg_sys_ref_id":null,"chg_user_id":"001559434","creat_sys_ref_id":null,"creat_user_id":"001559434","data_qlty_iss_list":null,"data_secur_rule_list":null,"end_dt":null,"hsc_prov_end_rsn_ref_id":null,"ltr_opt_out_cc_ind":null,"med_rec_nbr":null,"ntwk_strg_rsn_ref_id":null,"ntwk_sts_ref_id":null,"prov_loc_affil_dtl":{"providerDetails":{"prov_id":6675410,"prov_key":[{"prov_key_val":"1255539573","prov_key_typ_ref_id":2782},{"prov_key_val":null,"prov_key_typ_ref_id":16333},{"prov_key_val":"1255539573","prov_key_typ_ref_id":2783}],"prov_adr_id":98265064,"prov_cat_typ_ref_id":16309}},"prov_loc_affil_id":null,"spcl_ref_id":16536,"strt_dt":null,"telcom_adr_id":"7186222000","updt_ver_nbr":0,"hsc_prov_roles":[{"hsc_prov_id":4556,"prov_role_ref_id":3759}]}],"hsr_doc_procs":[],"indv_adr":[{"adr_ln_1_txt":"2127 W Balmoral Ave","adr_ln_2_txt":null,"adr_typ_ref_id":2118,"cntry_ref_id":845,"cnty_nm":"COOK","cty_nm":"Chicago","indv_id":503926748,"lat_deg":41.97935,"lng_deg":-87.68307,"st_ref_id":1079,"zip_cd_txt":"60625","zip_sufx_cd_txt":"1005"}]}]}).toPromise();
    }
}

class MockConfigGraphQLClient extends GraphQLClient{
    request(document: RequestDocument, variables?: any, requestHeaders?: any): Promise<any>{
        return of({
            "data": {
                "getHscCheckListItems": {
                    "task": {
                        "tsk_nm_ref_id": 72139,
                        "tsk_nm_ref_cd": {
                            "ref_dspl": "Concurrent Review"
                        },
                        "tsk_sts_ref_id": 72113,
                        "tsk_sts_ref_cd": {
                            "ref_dspl": "Start"
                        },
                        "checklist": [
                            {
                                "tsk_nm_ref_id": 72134,
                                "tsk_nm_ref_cd": {
                                    "ref_dspl": "Eligibility"
                                },
                                "tsk_sts_ref_id": 72113,
                                "tsk_sts_ref_cd": {
                                    "ref_dspl": "Start"
                                }
                            },
                            {
                                "tsk_nm_ref_id": 72135,
                                "tsk_nm_ref_cd": {
                                    "ref_dspl": "Provider"
                                },
                                "tsk_sts_ref_id": 72114,
                                "tsk_sts_ref_cd": {
                                    "ref_dspl": "Complete"
                                }
                            }
                        ]
                    }
                }
            }
        }).toPromise();
    }
}

class MockConfigClient {
    public getGraphqlClient(): GraphQLClient {
        return new MockConfigGraphQLClient('testurl');
    }
}

describe('UtilService', () => {
    let service: UtilService;

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            imports: [LoggerModule.forRoot()],
            providers: [UtilService, { provide: UtilClient, useClass: MockUtilClient },{ provide: ReferenceClient, useClass: MockReferenceClient }, { provide: ConfigService, useClass: MockConfigClient },ConfigService],
        }).compile();

        service = module.get<UtilService>(UtilService);
    });

    it('should be defined', () => {
        expect(service).toBeDefined();
    });

    it('should call getCaseDataForWorkflow', () => {
        let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
        const getCaseDataForWorkflowRequest: GetCaseDataForWorkflowRequest = {hsc:{hsc_id:13012}};
        service.getCaseDataForWorkflow(getCaseDataForWorkflowRequest, httpRequest).then((res) => {
            expect(res).toBeTruthy();
        });
    });

    it('should call prepareAuthDataResponse', () => {
        let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
        const authDataMock  = new AuthData();
        authDataMock.diagnosisInfo = [{diagnosisCode: '1', diagnosisDescription: '1',primaryInd: 1}];
        authDataMock.servicesInfo = [{caseId: 1, serviceId: 1, procedureCode: '1', procedureDescription:'1', inacInd: 1, procedureCodeSchemaRefId: 1, procedureOtherText:'1', servicingProviderInfo: '1',
            serviceNonFacility: {plsrvRefId: 1, procFreqRefId: 1, procedureModifier1: '1', procedureModifier2: '1', procedureModifier3: '1', procedureModifier4: '1', procedureUnitCount: '1', procUomRefId: 1, procUomRefCd: '1',
                serviceDescRefId: 1, serviceDetailRefCd: '1', serviceDetailRefId: 1, serviceEndDate: null, serviceStartDate: null, unitPerfrequencyCount: null}}];
        authDataMock.facilitiesInfo = [{actualAdmissionDate: '1', actualDischargeDate: '1', expectedAdmissionDate: '1', expectedDischargeDate: '1', placeOfServiceRefCode: '1', placeOfServiceRefDescription: '1', placeOfServiceRefDisplay: '1',
            placeOfServiceRefId: 1, serviceDescriptionRefCode: '1', serviceDescriptionRefDesc: '1', serviceDescriptionRefDisplay: '1', serviceDescriptionRefId: 1, serviceDetailRefCode: '1', serviceDetailRefDescription: '1', serviceDetailRefDisplay: '1', serviceDetailRefId: 1}];
        authDataMock.servicingProviderInfo = [{specialtyRefId: 1, caseProviderId: 1, networkStatusRefId: 1, networkSteerageReasonRefId: 1, providerLocationAffiliationId: 1, providerMPIN: 1, providerNPI: 1, providerRoleRefId: 1, providerTax: 1, telecomAddressId: '1', providerLocationAffiliationDetail: null}];
        authDataMock.requestingProviderInfo = [{specialtyRefId: 1, caseProviderId: 1, networkStatusRefId: 1, networkSteerageReasonRefId: 1, providerLocationAffiliationId: 1, providerMPIN: 1, providerNPI: 1, providerRoleRefId: 1, providerTax: 1, telecomAddressId: '1', providerLocationAffiliationDetail: null}];
        const authData = new AuthData(authDataMock);
        const hscResponse1 = {
            "data": {
                "getCaseDataForWorkflow": {
                    "caseData": {
                        "caseId": 13012,
                        "caseStatusRefId": 19274,
                        "reviewPriorityRefId": 3754,
                        "stateOfResidenceRefCode": "AZ",
                        "serviceSettingRefId": 3737,
                        "serviceSettingRefCode": 1,
                        "serviceSettingRefDescription": "Inpatient",
                        "serviceSettingRefDisplay": "Inpatient",
                        "reviewPriorityRefCode": 1,
                        "reviewPriorityRefDescription": "Routine",
                        "reviewPriorityRefDisplay": "Routine",
                        "memberCoverageInfo": {
                            "individualId": 503926748,
                            "sourceSystem": "16440436900",
                            "coverageEffectiveDate": "2013-01-01",
                            "coverageEndDate": "9999-12-31",
                            "memberCoverageId": 96963692,
                            "productCodeRefId": 214,
                            "coverageTypeDescription": "Medical",
                            "claimPlatformRefId": 363,
                            "policyNumber": "0128855"
                        },
                        "diagnosisInfo": [
                            {
                                "diagnosisCode": "M25.14",
                                "diagnosisDescription": "FISTULA HAND"
                            }
                        ],
                        "servicesInfo": [
                            {
                                "caseId": 13012,
                                "serviceId": 11528,
                                "procedureCodeSchemaRefId": 3767,
                                "procedureCode": "81403",
                                "procedureDescription": "MOPATH PROCEDURE LEVEL 4",
                                "servicingProviderInfo": [
                                    {
                                        "caseProviderId": 4555,
                                        "providerRoleRefId": 3765,
                                        "providerNPI": "1255539573",
                                        "providerMPIN": "1255539573",
                                        "specalityRefId": 16536,
                                        "telecomAddressId": "7186222000",
                                        "providerLocationAffiliationDetail": {
                                            "providerId": 6675410,
                                            "providerAddressId": 98265064,
                                            "providerCategoryTypeRefId": 16309
                                        }
                                    }
                                ]
                            }
                        ],
                        "servicingProviderInfo": [
                            {
                                "caseProviderId": 4555,
                                "providerRoleRefId": 3765,
                                "providerNPI": "1255539573",
                                "specalityRefId": 16536,
                                "telecomAddressId": "7186222000",
                                "providerLocationAffiliationDetail": {
                                    "providerId": 6675410,
                                    "providerAddressId": 98265064
                                }
                            }
                        ],
                        "requestingProviderInfo": [],
                        "attendingProviderInfo": [
                            {
                                "caseProviderId": 4556,
                                "providerRoleRefId": 3759,
                                "providerNPI": "1255539573",
                                "providerMPIN": "1255539573",
                                "specalityRefId": 16536,
                                "telecomAddressId": "7186222000",
                                "providerLocationAffiliationDetail": {
                                    "providerId": 6675410,
                                    "providerAddressId": 98265064,
                                    "providerCategoryTypeRefId": 16309
                                }
                            }
                        ],
                        "admittingProviderInfo": [
                            {
                                "caseProviderId": 4554,
                                "providerRoleRefId": 3758,
                                "providerNPI": "1255539573",
                                "providerMPIN": "1255539573",
                                "specalityRefId": 16536,
                                "telecomAddressId": "7186222000",
                                "providerLocationAffiliationDetail": {
                                    "providerId": 6675410,
                                    "providerAddressId": 98265064,
                                    "providerCategoryTypeRefId": 16309
                                }
                            }
                        ],
                        "facilityProviderInfo": [
                            {
                                "caseProviderId": 4553,
                                "providerRoleRefId": 3761,
                                "providerTax": null,
                                "providerNPI": "1255539573",
                                "providerMPIN": "1255539573",
                                "specalityRefId": 16364,
                                "telecomAddressId": "6628691595",
                                "providerLocationAffiliationDetail": {
                                    "providerId": 6675410,
                                    "providerAddressId": 98265064,
                                    "providerCategoryTypeRefId": 16309
                                }
                            }
                        ],
                        "facilitiesInfo": [
                            {
                                "actualAdmissionDate": null,
                                "actualDischargeDate": null,
                                "expectedAdmissionDate": "2021-02-22",
                                "expectedDischargeDate": "2021-02-25",
                                "placeOfServiceRefId": 3743,
                                "placeOfServiceRefCode": "21",
                                "placeOfServiceRefDescription": "Acute Hospital",
                                "placeOfServiceRefDisplay": "Acute Hospital",
                                "serviceDescriptionRefId": 4347,
                                "serviceDescriptionRefCode": "1",
                                "serviceDescriptionRefDesc": "Scheduled",
                                "serviceDescriptionRefDisplay": "Scheduled",
                                "serviceDetailRefDescription": "Surgical",
                                "serviceDetailRefCode": "2",
                                "serviceDetailRefId": 4307,
                                "serviceDetailRefDisplay": "Surgical"
                            }
                        ]
                    }
                }
            }
        };

        const hscResponse = {"hsc":[{"hsc_id":13012,"creat_dttm":"2021-02-22T16:18:13.128","creat_user_id":"001559434","indv_id":503926748,"individual":[{"bth_dt":"1978-07-26"}],"indv_key_typ_ref_id":2757,"indv_key_val":"16440436900","mbr_cov_dtl":{"indv_id":503926748,"pol_nbr":"0128855","cov_eff_dt":"2013-01-01","cov_end_dt":"9999-12-31","mbr_cov_id":96963692,"productCode":214,"indv_key_val":"16440436900","productCatgyTpe":null,"coverageTypeDesc":"Medical","indv_key_typ_ref_id":2757,"claim_platform_ref_Id":363},"hsc_sts_ref_id":19274,"flwup_cntc_dtl":{"Primary_Cntct":{"department":null,"email":null,"phone":"112-333-4444","fax":null,"creat_dttm":"2021-02-22T16:18:13.198Z","chg_dttm":"2021-02-22T16:24:07.512Z","creat_user_id":"001559434","role":null,"name":"test"}},"rev_prr_ref_id":3754,"rev_prr_ref_cd":{"ref_id":3754,"ref_cd":"1","ref_desc":"Routine","ref_dspl":"Routine"},"srvc_set_ref_id":3737,"srvc_set_ref_cd":{"ref_id":3737,"ref_cd":"1","ref_desc":"Inpatient","ref_dspl":"Inpatient"},"hsc_keys":[{"hsc_id":13012,"hsc_key_val":"8fa66e3d-7529-11eb-908f-1ef9496236e0","inac_ind":0,"hsc_key_typ_ref_id":19517}],"hsc_srvcs":[{"hsc_id":13012,"hsc_srvc_id":11528,"inac_ind":0,"proc_cd":"81403","proc_cd_schm_ref_id":3767,"proc_othr_txt":null,"srvc_hsc_prov_id":4555,"hsc_srvc_non_facls":[],"proc_desc":"MOLECULAR PATHOLOGY PROCEDURE LEVEL 4"}],"hsc_facls":[{"actul_admis_dttm":null,"actul_dschrg_dttm":null,"expt_admis_dt":"2021-02-22","expt_dschrg_dt":"2021-02-25","plsrv_ref_id":3743,"plsrv_ref_cd":{"ref_id":3743,"ref_cd":"21","ref_desc":"Acute Hospital","ref_dspl":"Acute Hospital"},"srvc_desc_ref_id":4347,"srvc_desc_ref_cd":{"ref_id":4347,"ref_cd":"1","ref_desc":"Scheduled","ref_dspl":"Scheduled"},"srvc_dtl_ref_id":4307,"srvc_dtl_ref_cd":{"ref_id":4307,"ref_cd":"2","ref_desc":"Surgical","ref_dspl":"Surgical"}}],"hsc_diags":[{"hsc_diag_id":3534,"diag_cd":"M25.14","inac_ind":0,"diag_desc":"FISTULA HAND"}],"hsr_notes":[{"hsr_note_id":1794,"note_titl_txt":"test","note_txt_lobj":"testDate","creat_user_id":"001559434","note_typ_ref_id":null,"src_user_nm":"provider","creat_dttm":"2021-02-22T16:24:33.285"}],"hsc_provs":[{"auto_aprv_ltr_ind":null,"chg_sys_ref_id":null,"chg_user_id":"001559434","creat_sys_ref_id":null,"creat_user_id":"001559434","data_qlty_iss_list":null,"data_secur_rule_list":null,"end_dt":null,"hsc_prov_end_rsn_ref_id":null,"ltr_opt_out_cc_ind":null,"med_rec_nbr":null,"ntwk_strg_rsn_ref_id":null,"ntwk_sts_ref_id":null,"prov_loc_affil_dtl":{"providerDetails":{"prov_id":10455660,"prov_key":[{"prov_key_val":"1710081369","prov_key_typ_ref_id":2782},{"prov_key_val":"288158608","prov_key_typ_ref_id":16333},{"prov_key_val":"1710081369","prov_key_typ_ref_id":2783}],"prov_adr_id":117625635,"prov_cat_typ_ref_id":16310}},"prov_loc_affil_id":null,"spcl_ref_id":16364,"strt_dt":null,"telcom_adr_id":"6628691595","updt_ver_nbr":0,"hsc_prov_roles":[{"hsc_prov_id":4553,"prov_role_ref_id":3761}]},{"auto_aprv_ltr_ind":null,"chg_sys_ref_id":null,"chg_user_id":"001559434","creat_sys_ref_id":null,"creat_user_id":"001559434","data_qlty_iss_list":null,"data_secur_rule_list":null,"end_dt":null,"hsc_prov_end_rsn_ref_id":null,"ltr_opt_out_cc_ind":null,"med_rec_nbr":null,"ntwk_strg_rsn_ref_id":null,"ntwk_sts_ref_id":null,"prov_loc_affil_dtl":{"providerDetails":{"prov_id":6675410,"prov_key":[{"prov_key_val":"1255539573","prov_key_typ_ref_id":2782},{"prov_key_val":null,"prov_key_typ_ref_id":16333},{"prov_key_val":"1255539573","prov_key_typ_ref_id":2783}],"prov_adr_id":98265064,"prov_cat_typ_ref_id":16309}},"prov_loc_affil_id":null,"spcl_ref_id":16536,"strt_dt":null,"telcom_adr_id":"7186222000","updt_ver_nbr":0,"hsc_prov_roles":[{"hsc_prov_id":4554,"prov_role_ref_id":3758}]},{"auto_aprv_ltr_ind":null,"chg_sys_ref_id":null,"chg_user_id":"001559434","creat_sys_ref_id":null,"creat_user_id":"001559434","data_qlty_iss_list":null,"data_secur_rule_list":null,"end_dt":null,"hsc_prov_end_rsn_ref_id":null,"ltr_opt_out_cc_ind":null,"med_rec_nbr":null,"ntwk_strg_rsn_ref_id":null,"ntwk_sts_ref_id":null,"prov_loc_affil_dtl":{"providerDetails":{"prov_id":6675410,"prov_key":[{"prov_key_val":"1255539573","prov_key_typ_ref_id":2782},{"prov_key_val":null,"prov_key_typ_ref_id":16333},{"prov_key_val":"1255539573","prov_key_typ_ref_id":2783}],"prov_adr_id":98265064,"prov_cat_typ_ref_id":16309}},"prov_loc_affil_id":null,"spcl_ref_id":16536,"strt_dt":null,"telcom_adr_id":"7186222000","updt_ver_nbr":0,"hsc_prov_roles":[{"hsc_prov_id":4555,"prov_role_ref_id":3765}]},{"auto_aprv_ltr_ind":null,"chg_sys_ref_id":null,"chg_user_id":"001559434","creat_sys_ref_id":null,"creat_user_id":"001559434","data_qlty_iss_list":null,"data_secur_rule_list":null,"end_dt":null,"hsc_prov_end_rsn_ref_id":null,"ltr_opt_out_cc_ind":null,"med_rec_nbr":null,"ntwk_strg_rsn_ref_id":null,"ntwk_sts_ref_id":null,"prov_loc_affil_dtl":{"providerDetails":{"prov_id":6675410,"prov_key":[{"prov_key_val":"1255539573","prov_key_typ_ref_id":2782},{"prov_key_val":null,"prov_key_typ_ref_id":16333},{"prov_key_val":"1255539573","prov_key_typ_ref_id":2783}],"prov_adr_id":98265064,"prov_cat_typ_ref_id":16309}},"prov_loc_affil_id":null,"spcl_ref_id":16536,"strt_dt":null,"telcom_adr_id":"7186222000","updt_ver_nbr":0,"hsc_prov_roles":[{"hsc_prov_id":4556,"prov_role_ref_id":3759}]}],"hsr_doc_procs":[],"indv_adr":[{"adr_ln_1_txt":"2127 W Balmoral Ave","adr_ln_2_txt":null,"adr_typ_ref_id":2118,"cntry_ref_id":845,"cnty_nm":"COOK","cty_nm":"Chicago","indv_id":503926748,"lat_deg":41.97935,"lng_deg":-87.68307,"st_ref_id":1079,"zip_cd_txt":"60625","zip_sufx_cd_txt":"1005"}]}]};
        // spyOn<any>(service, 'prepareAuthDataResponse').and.returnValue(hscResponse);
         service.prepareAuthDataResponse(hscResponse, authData).then((res) => {
            expect(res).toEqual(hscResponse1);
        });
    });
});
