import { Injectable } from '@nestjs/common';
import {HttpRequest} from "@azure/functions";
import {AuthData} from "../../models/authData";
import {
    AdmittingProviderInfo,
    AttendingProviderInfo,
    FacilityProviderInfo,
    ProviderLocAffilDetails,
    RequestingProviderInfo,
    ServicingProviderInfo
} from "../../models/providersInfo";
import {ServicesInfo} from "../../models/servicesInfo";
import {MemberCoverageInfo} from "../../models/memberInfo";
import {FacilitiesInfo} from "../../models/facilitiesInfo";
import {DiagnosisInfo} from "../../models/diagnosisInfo";
import {DomainConstants} from "../../constants/domainConstants";
import {caseDataConstants} from "../../constants/caseDataConstants";
import {GetCaseDataForWorkflowResponse} from "../../models/get-case-data-for-workflow-response";
import {GetCaseDataForWorkflowRequest} from "../../models/get-case-data-for-workflow-request";
import {UtilClient} from '../../../health-service/shared/graphql/utildomain/utilClient';
import {getHscAuthDetails} from '../../../health-service/shared/graphql/utildomain/utilQuery';
import {Logger} from "nestjs-pino";

@Injectable()
export class UtilService {
    constructor(private readonly utilClient: UtilClient,  private readonly logger: Logger) {}

    async getCaseDataForWorkflow(getCaseDataForWorkflowRequest: GetCaseDataForWorkflowRequest, httpRequest: HttpRequest) {
        let authDataResponse;

        try {
            const hscID = getCaseDataForWorkflowRequest.hsc.hsc_id;
            this.logger.log("getCaseDataForWorkflow - Request Params: hscId :"+ hscID);
            const hscResponse = await this.utilClient.getGraphqlClient(httpRequest).request(getHscAuthDetails, {"getHscAuthRequest": {"hsc": {"hsc_id": hscID}}});
            this.logger.log("getCaseDataForWorkflow - hscResponse :" + JSON.stringify(hscResponse));
            const authData = new AuthData();
            authDataResponse = await this.prepareAuthDataResponse(hscResponse.getHscAuthDetails, authData);
            
        } catch (e) {
            this.logger.error("Error while calling CaseWF UtilService getCaseDataForWorkflow (getCaseDataForWorkflowRequest: " + getCaseDataForWorkflowRequest + ", httpRequest: " + httpRequest + ") " + e);        
        }

        const response: GetCaseDataForWorkflowResponse = {
            "caseData": authDataResponse
        };
        this.logger.log("getCaseDataForWorkflow Response:" + JSON.stringify(response));
        return response;
    }

    async prepareAuthDataResponse(hscResponse,authData) {
        const hscData = hscResponse.hsc[0];
        authData.caseId= hscData.hsc_id;
        authData.stateOfResidenceRefId = hscData.state_ref_id;
        authData.stateOfResidenceRefDisplay = hscData.state_ref_dspl_nm;
        authData.stateOfResidenceRefCode = hscData.state_ref_cd;
        authData.caseCreateDateTime = hscData.creat_dttm;
        authData.caseStatusRefId = hscData.hsc_sts_ref_id;
        authData.reviewPriorityRefId = hscData.rev_prr_ref_id;
        authData.serviceSettingRefId = hscData.srvc_set_ref_id;
        authData.serviceSettingRefCode = hscData.srvc_set_ref_cd?.ref_cd;
        authData.serviceSettingRefDescription = hscData.srvc_set_ref_cd?.ref_desc;
        authData.serviceSettingRefDisplay = hscData.srvc_set_ref_cd?.ref_dspl;
        authData.reviewPriorityRefCode = hscData.rev_prr_ref_cd?.ref_cd;
        authData.reviewPriorityRefDescription = hscData.rev_prr_ref_cd?.ref_desc;
        authData.reviewPriorityRefDisplay = hscData.rev_prr_ref_cd?.ref_dspl;
        authData.clinicalDocumentsReceived = DomainConstants.STR_YES;
        authData.locRequired = DomainConstants.STR_YES;
        authData.cobIndicator = DomainConstants.STR_YES;
        authData.memberMedNecIndicator = DomainConstants.STR_YES;
        authData.facilityMedNecIndicator = DomainConstants.STR_YES;
        authData.riskScore = 1;
        authData.priorityReviewType = DomainConstants.HSC_PRIORITY_REVIEW_TYPE;
        authData.priorAuth = DomainConstants.PRIOR_AUTH;
        authData.tatGuidelienSource= DomainConstants.TAT_GUIDELINE_SOURCE;
        this.ageCalculation(hscData,authData);
        this.memberCoverageDetails(hscData,authData);
        this.diagnosisData(hscData,authData);
        this.providersData(hscData,authData);
        this.servicesData(hscData,authData);
        this.facilitiesData(hscData,authData);
        if(hscData.creat_sys_ref_id == null){
            authData.intakeChannel = DomainConstants.INTAKE_CHANNEL_WEB;
        }
        if(hscData.hsc_rev_typ_ref_id == caseDataConstants.REVIEW_TYPE_MEDICAL_OR_SURGICAL){
            authData.reviewType = 'M';
        }
        else if(hscData.hsc_rev_typ_ref_id == caseDataConstants.REVIEW_TYPE_SURGICAL){
            authData.reviewType = 'S';
        }
        else{
            authData.reviewType = 'M';
        }

        return authData;
    }

    ageCalculation(hscData,authData) {
        const newDate = new Date(hscData.individual[0]?.bth_dt);
        const timeDiff = Math.abs(Date.now() - new Date(newDate).getTime());
        const daysDiff = timeDiff / (1000 * 3600 * 24);
        if (daysDiff === 0) {
            const mbrAge = Math.floor(daysDiff);
            authData.memberAge = mbrAge + ' Days';
        } else if (daysDiff > 0 && daysDiff < 30) {
            const mbrAge = Math.floor(daysDiff);
            authData.memberAge = mbrAge + ' Days';
        } else if (daysDiff > 30 && daysDiff < 720) {
            const mbrAge = Math.floor(daysDiff / 30);
            authData.memberAge = mbrAge + ' Months';
        } else if (daysDiff > 720) {
            const mbrAge = Math.floor(timeDiff / (1000 * 3600 * 24) / 365.25);
            authData.memberAge = mbrAge;
        }
    }

    memberCoverageDetails(hscData,authData) {
        const memCovInfo = new MemberCoverageInfo();
        memCovInfo.individualId = hscData.mbr_cov_dtl?.indv_id;
        if(hscData.mbr_cov_dtl?.indv_key_typ_ref_id === caseDataConstants.INDIVIDUAL_KEY_TYPE_REF_ID){
            memCovInfo.sourceSystem = hscData.mbr_cov_dtl?.indv_key_val;
        }
        memCovInfo.coverageEffectiveDate = hscData.mbr_cov_dtl?.cov_eff_dt;
        memCovInfo.coverageEndDate = hscData.mbr_cov_dtl?.cov_end_dt;
        memCovInfo.memberCoverageId = hscData.mbr_cov_dtl?.mbr_cov_id;
        memCovInfo.productCodeRefId = hscData.mbr_cov_dtl?.productCode;
        memCovInfo.productCategoryType = hscData.mbr_cov_dtl?.productCatgyTpe;
        memCovInfo.coverageTypeDescription = hscData.mbr_cov_dtl?.coverageTypeDesc;
        memCovInfo.claimPlatformRefId = hscData.mbr_cov_dtl?.claim_platform_ref_Id;
        memCovInfo.policyNumber = hscData.mbr_cov_dtl?.pol_nbr;
        memCovInfo.stateOfIssue= hscData.mbr_cov_dtl?.pol_iss_st_ref_cd;
        if (caseDataConstants.LOB_TYPE_EnI_REF_IDS.indexOf(hscData.mbr_cov_dtl?.lob_ref_id) != -1) {
            memCovInfo.lob = DomainConstants.LOB_TYPE_EnI;
        }
        else if(caseDataConstants.LOB_TYPE_CnS_REF_IDS.indexOf(hscData.mbr_cov_dtl?.lob_ref_id) != -1){
            memCovInfo.lob = DomainConstants.LOB_TYPE_CnS;
        }
        else if(caseDataConstants.LOB_TYPE_MnR_REF_IDS.indexOf(hscData.mbr_cov_dtl?.lob_ref_id) != -1) {
            memCovInfo.lob = DomainConstants.LOB_TYPE_MnR;
        }
        authData.memberCoverageInfo= memCovInfo;
    }
    
    diagnosisData(hscData,authData) {
        (hscData?.hsc_diags as any).forEach((hscDiag) => {
            const diag = new DiagnosisInfo();
            diag.diagnosisDescription = hscDiag.diag_desc;
            diag.diagnosisCode = hscDiag.diag_cd;
            diag.primaryInd= hscDiag.pri_ind;
            if(diag.primaryInd == 1){
                authData.primaryDiagnosisCode = hscDiag.diag_cd;
            }
            authData.diagnosisInfo.push(diag);
        });
    }
    
    providersData(hscData,authData) {
        (hscData?.hsc_provs as any).forEach((hscProv) => {
            hscProv.hsc_prov_roles.forEach((provRole) =>{
                if(provRole.prov_role_ref_id === caseDataConstants.PROVIDER_ROLE_REF_ID_SERVICING){
                    const providers = new ServicingProviderInfo();
                    this.providerInfo(providers,hscProv);
                    authData.servicingProviderInfo.push(providers);
                }else if(provRole.prov_role_ref_id === caseDataConstants.PROVIDER_ROLE_REF_ID_REQUESTING){
                    const providers = new RequestingProviderInfo();
                    this.providerInfo(providers,hscProv);
                    authData.requestingProviderInfo.push(providers);
                }else if(provRole.prov_role_ref_id === caseDataConstants.PROVIDER_ROLE_REF_ID_ADMITTING){
                    const providers = new AdmittingProviderInfo();
                    this.providerInfo(providers,hscProv);
                    authData.admittingProviderInfo.push(providers);
                }else if(provRole.prov_role_ref_id === caseDataConstants.PROVIDER_ROLE_REF_ID_ATTENDING){
                    const providers = new AttendingProviderInfo();
                    this.providerInfo(providers,hscProv);
                    authData.attendingProviderInfo.push(providers);
                }else if(provRole.prov_role_ref_id === caseDataConstants.PROVIDER_ROLE_REF_ID_FACILITY){
                    const providers = new FacilityProviderInfo();
                    this.providerInfo(providers,hscProv);
                    authData.facilityProviderInfo.push(providers);
                }
            });
        });
    }
    
    providerInfo(providers,hscProv){
        hscProv.hsc_prov_roles.forEach((provRole) =>{
            providers.caseProviderId = provRole.hsc_prov_id;
            providers.providerRoleRefId = provRole.prov_role_ref_id;
        });
        let provKeys = null;
        if(hscProv.prov_loc_affil_dtl.providerDetails.prov_key !== undefined){
            provKeys = hscProv.prov_loc_affil_dtl.providerDetails.prov_key;
        } else {
            provKeys = hscProv.prov_loc_affil_dtl.providerDetails.prov_keys;
        }
        provKeys.forEach((provKey) => {
            if (provKey.prov_key_typ_ref_id == caseDataConstants.PROVIDER_KEY_TYPE_REF_ID_TAX){
                providers.providerTax= provKey.prov_key_val;
            }else if(provKey.prov_key_typ_ref_id == caseDataConstants.PROVIDER_KEY_TYPE_REF_ID_MPIN){
                providers.providerMPIN= provKey.prov_key_val;
            }else if(provKey.prov_key_typ_ref_id == caseDataConstants.PROVIDER_KEY_TYPE_REF_ID_NPI){
                providers.providerNPI= provKey.prov_key_val;
            }
        });
        providers.specalityRefId = hscProv.spcl_ref_id;
        providers.telecomAddressId = hscProv.telcom_adr_id;
        providers.networkStatusRefId=hscProv.ntwk_sts_ref_id;
        providers.providerLocationAffiliationId = hscProv.prov_loc_affil_id;
        providers.networkSteerageReasonRefId=hscProv.ntwk_strg_rsn_ref_id;
            const providerAfflDetails= new ProviderLocAffilDetails();
            providerAfflDetails.providerId =  hscProv.prov_loc_affil_dtl.providerDetails.prov_id? hscProv.prov_loc_affil_dtl.providerDetails.prov_id:null;
            providerAfflDetails.providerAddressId =  hscProv.prov_loc_affil_dtl.providerDetails.prov_adr_id? hscProv.prov_loc_affil_dtl.providerDetails.prov_adr_id:null;
            providerAfflDetails.providerCategoryTypeRefId =  hscProv.prov_loc_affil_dtl.providerDetails.prov_cat_typ_ref_id?hscProv.prov_loc_affil_dtl.providerDetails.prov_cat_typ_ref_id:null;
        providerAfflDetails.medNecRestrictionType = hscProv.prov_loc_affil_dtl?.providerDetails?.facilityContracts && hscProv.prov_loc_affil_dtl?.providerDetails?.facilityContracts.length > 0 ?hscProv.prov_loc_affil_dtl?.providerDetails?.facilityContracts[0].medNecClauseData?.clauseCode:null;
        providers.providerLocationAffiliationDetail=providerAfflDetails;
        providers.contractDetails= hscProv.prov_loc_affil_dtl.providerDetails.facilityContracts;
    }
    
    servicesData(hscData,authData) {
        (hscData?.hsc_srvcs as any).forEach((hscSrvc) => {
            const services = new ServicesInfo();
            services.caseId = hscSrvc.hsc_id;
            services.serviceId = hscSrvc.hsc_srvc_id;
            services.procedureCodeSchemaRefId = hscSrvc.proc_cd_schm_ref_id;
            services.procedureCode = hscSrvc.proc_cd;
            services.procedureDescription = hscSrvc.proc_desc;
            services.procedureOtherText = hscSrvc.proc_othr_txt;
            services.servicingProviderInfo =  authData.servicingProviderInfo? authData.servicingProviderInfo :null;
            services.serviceNonFacility = hscSrvc.hsc_srvc_non_facls;
            authData.servicesInfo.push(services);
        });
    }
    
    facilitiesData(hscData,authData){
        (hscData?.hsc_facls as any).forEach((hscFacl) => {
            const faclities = new FacilitiesInfo();
            faclities.actualAdmissionDate = hscFacl.actul_admis_dttm;
            faclities.actualDischargeDate = hscFacl.actul_dschrg_dttm;
            faclities.expectedAdmissionDate = hscFacl.expt_admis_dt;
            faclities.expectedDischargeDate = hscFacl.expt_dschrg_dt;
            faclities.placeOfServiceRefId = hscFacl.plsrv_ref_id;
            faclities.placeOfServiceRefCode = hscFacl.plsrv_ref_cd.ref_cd;
            faclities.placeOfServiceRefDescription = hscFacl.plsrv_ref_cd.ref_desc;
            faclities.placeOfServiceRefDisplay = hscFacl.plsrv_ref_cd.ref_dspl;
            faclities.serviceDescriptionRefId = hscFacl.srvc_desc_ref_id;
            faclities.serviceDescriptionRefCode = hscFacl.srvc_desc_ref_cd.ref_cd;
            faclities.serviceDescriptionRefDesc = hscFacl.srvc_desc_ref_cd.ref_desc;
            faclities.serviceDescriptionRefDisplay = hscFacl.srvc_desc_ref_cd.ref_dspl;
            faclities.serviceDetailRefDescription = hscFacl.srvc_dtl_ref_cd.ref_desc;
            faclities.serviceDetailRefCode = hscFacl.srvc_dtl_ref_cd.ref_cd;
            faclities.serviceDetailRefId = hscFacl.srvc_dtl_ref_id;
            faclities.serviceDetailRefDisplay = hscFacl.srvc_dtl_ref_cd.ref_dspl;
    
            authData.facilitiesInfo.push(faclities);
        });
    }
}
