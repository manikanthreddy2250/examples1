export enum Role {
  User = 'system_mgmt_user',
  Admin = 'system_mgmt_admin',
  ClientAdmin = 'system_mgmt_client',
  Patient = 'patient',
  Provider = 'provider',
  CASE_MGMT_ADMIN = 'case_wf_mgmt_ui_admin',
  CASE_MGMT_CDU = 'case_wf_mgmt_ui_cdu',
  CASE_MGMT_MD = 'case_wf_mgmt_ui_md',
  CASE_MGMT_NURSE = 'case_wf_mgmt_ui_nurse',
  CASE_MGMT_SYSTEM = 'case_wf_mgmt_ui_system',
}
