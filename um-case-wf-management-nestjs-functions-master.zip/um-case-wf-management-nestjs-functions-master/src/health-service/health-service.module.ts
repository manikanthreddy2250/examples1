import { Module,HttpModule } from '@nestjs/common';
import { HealthServiceResolver } from './resolver/health-service.resolver';
import { HealthService } from './service/health-service/health-service.service';
import { CaseValidationService } from "./service/case-validation/caseValidation.service";
import { ProviderContractService } from "./service/provider-contract/provider-contract.service";
import { GetTaskDetailsService } from "./service/getTaskDetails/getTaskDetails.service";
import {HealthServiceClient} from "./shared/graphql/healthservicedomain/healthServiceClient";
import {DocumentServiceClient} from "./shared/graphql/documentservicedomain/documentServiceClient";
import {ReferenceClient} from "./shared/graphql/referenceDomain/referenceClient";
import {ProviderClient} from "./shared/graphql/provider-domain/providerClient";
import {TaskMetadataService} from "../configuration/service/task-metadata/task-metadata.service";
import {CamundaSignalService} from './service/signal-service/camunda.signal.service';
import { HscLetterEventService } from './service/health-service/hsc-letter-event.service';
import { MemberServiceClient} from "./shared/graphql/memberdomain/memberServiceClient";

import {RulesService} from "./service/rules/rules.service";

@Module({
  imports: [HttpModule],
  providers: [HscLetterEventService,HealthServiceResolver, HealthService, HealthServiceClient, CaseValidationService, 
    GetTaskDetailsService,DocumentServiceClient, ReferenceClient, ProviderContractService, ProviderClient,TaskMetadataService, RulesService,
    CamundaSignalService,MemberServiceClient]
})
export class HealthServiceModule {}
