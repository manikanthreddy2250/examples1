import {Field, InputType} from "@nestjs/graphql";
@InputType()
export class CaseValidationRequest {
    @Field()
    hsc_id: string;
    @Field({ nullable: true })
    validateEligibility: boolean;
    @Field({ nullable: true })
    validateProvider: boolean;
    @Field({ nullable: true })
    validateContract: boolean;
    @Field({ nullable: true })
    validateSOS: boolean;
    @Field({ nullable: true })
    validateLOCReview: boolean;
    @Field({ nullable: true })
    validateLOSReview: boolean;
    @Field({ nullable: true })
    validateDuplicateCase: boolean;
    @Field({ nullable: true })
    validateFacilityOutOfNetwork: boolean;
    @Field({ nullable: true })
    validateDxCode: boolean;
    @Field({ nullable: true })
    validateClinicalDocument: boolean;
    @Field({ nullable: true })
    validateReadmission: boolean;

}
