import {Field, ObjectType} from "@nestjs/graphql";
@ObjectType()
export class CaseValidationResponse {
    @Field()
    hsc_id: string;
    @Field({ nullable: true })
    eligibilityCheck: boolean;
    @Field({ nullable: true })
    providerCheck: boolean;
    @Field({ nullable: true })
    contractCheck: boolean;
    @Field({ nullable: true })
    sOSCheck: boolean;
    @Field({ nullable: true })
    lOCReviewCheck: boolean;
    @Field({ nullable: true })
    lOSReviewCheck: boolean;
    @Field({ nullable: true })
    duplicateCaseCheck: boolean;
    @Field({ nullable: true })
    facilityOutOfNetworkCheck: boolean;
    @Field({ nullable: true })
    dxCodeCheck: boolean;
    @Field({ nullable: true })
    clinicalDocumentCheck: boolean;
    @Field({nullable:true})
    readmissionCheck: boolean;
}
