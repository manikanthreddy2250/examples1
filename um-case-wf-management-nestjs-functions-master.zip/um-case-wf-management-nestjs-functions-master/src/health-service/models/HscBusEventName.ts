export const enum HscBusEventName {
  HSC_LETTER_NOTIFICATION_EVENT = 'letter.utility.event'
}

