
export class LetterEventRequest {
    requestHeader: RequestHeader;
    letterEventIdentifier: LettereventIdentifier;

}
export class LettereventIdentifier {
    requestID: number;
    idType: string;
    letterContext: LetterContext[];
}
export class RequestHeader {
    appUserID: string;
    appName: string;
    appVersion: string;
}

export class LetterContext {
    decisionID: string;
    decisionCategory: string;
}
