export interface NRTData {
  MPIN: string;
  Tax_ID_TIN: string;
  Address_Seq_Num: string;
  Fac_Prov_Name_Primary: string;
  State_CD: any;
  LOB: number;
  Entity: string;
  Contract_Paper_Type: number;
  Eff_Dt: string;
  Term_Dt: string;
  Med_Nec_Restriction_Type_Name: number;
  Med_Nec_Restriction: string;
  Lst_Call_Dt: string;
  Insert_Dt: string;
  Action_CD: string;
  Lst_Updt_By: string;
}