import {Field, InputType, Int} from "@nestjs/graphql";

@InputType()
export class TaskListRequest {
    @Field(type => Int,{ nullable: true })
    hsc_id: number;

    @Field(type => String,{ nullable: true })
    asgn_to_user_id: string;
}

