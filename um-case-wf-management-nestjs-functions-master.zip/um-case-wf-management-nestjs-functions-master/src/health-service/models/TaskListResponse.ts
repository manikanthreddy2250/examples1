import {Field, Int, ObjectType} from "@nestjs/graphql";
import {HsrAssign} from "./hsrAssign";


@ObjectType()
export class TaskListResponse {
    @Field(type => [HsrAssign])
    hsr_asgn: HsrAssign[];
}


