
export class BusinessEventRequest {
    event_name: string;
    event_date_time: string;
    event_source: string;
    event_channel: string;
    event_id: number;
    payload: any;
}
