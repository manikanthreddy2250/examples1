import {Field, Int, ObjectType} from "@nestjs/graphql";
import GraphQLJSON from "graphql-type-json";

@ObjectType()
export class CommunicationActivity {
    @Field(type => String,{ nullable: true })
    creat_user_id: string;

    @Field(type => String,{ nullable: true })
    creat_dttm: string;

    @Field(type => String,{ nullable: true })
    mbr_cmnct_chnl_ref_dspl: string;

    @Field(type => String,{ nullable: true })
    mbr_cmnct_dir_ref_dspl: string;

    @Field(type => String,{ nullable: true })
    mbr_cmnct_typ_ref_dspl: string;

    @Field(type => String,{ nullable: true })
    mbr_cmnct_sts_ref_dspl: string;

    @Field(type => String,{ nullable: true })
    mbr_cmnct_catgy_ref_dspl: string;
}
