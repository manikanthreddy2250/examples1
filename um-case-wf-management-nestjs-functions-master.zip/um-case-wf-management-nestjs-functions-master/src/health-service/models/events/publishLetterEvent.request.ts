import {Field, Int, InputType} from "@nestjs/graphql";


@InputType()
export class PublishLetterEventRequest {
    @Field(type => Int)
    hsc_id: number;
    
    @Field(type => String ,{nullable: true})
    client: string;

    @Field(type => [Int])
    decisionIds: number[];

    @Field(type => String ,{nullable: true})
    eventChannel: string;

    @Field(type => String ,{nullable: true})
    appUserId: string;

}
