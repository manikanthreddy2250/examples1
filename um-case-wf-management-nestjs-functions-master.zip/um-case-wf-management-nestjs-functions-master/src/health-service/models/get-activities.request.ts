import {Field, Int, InputType} from "@nestjs/graphql";

@InputType()
export class GetActivitiesRequest {
    @Field(type => Int,{ nullable: true })
    hsc_id: number;
}
