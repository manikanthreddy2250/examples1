import {Field, ObjectType} from "@nestjs/graphql";
import {CommunicationActivity} from "./communication-activity";

@ObjectType()
export class GetActivitiesResponse {
    @Field(type => [CommunicationActivity])
    communication_activities: CommunicationActivity[];
}