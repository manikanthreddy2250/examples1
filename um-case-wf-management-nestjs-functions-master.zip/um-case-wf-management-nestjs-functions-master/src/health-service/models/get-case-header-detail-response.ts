import {Field, Int, ObjectType} from "@nestjs/graphql";

@ObjectType()
export class GetCaseHeaderDetailResponse {
    @Field(type => Int, { nullable: true })
    srvc_set_ref_id: number;

    @Field(type => String, { nullable: true })
    srvc_set_ref_dspl: any;

    @Field(type => Int, { nullable: true })
    plsrv_ref_id: number;

    @Field(type => String, { nullable: true })
    plsrv_ref_dspl: any;

    @Field(type => Int, { nullable: true })
    hsc_id: number;

    @Field(type => Int, { nullable: true })
    srvc_desc_ref_id: number;

    @Field(type => String, { nullable: true })
    srvc_desc_ref_dspl: any;

    @Field(type => Int, { nullable: true })
    srvc_dtl_ref_id: number;

    @Field(type => String, { nullable: true })
    srvc_dtl_ref_dspl: any;

    @Field(type => String, { nullable: true })
    admitDate: any;

    @Field(type => String, { nullable: true })
    dischargeDate: any;

    @Field(type => String, { nullable: true })
    primaryDiagnosis: any;

    @Field(type => String, { nullable: true })
    tatDueDate: any;

    @Field(type => String, { nullable: true })
    bus_nm: any;

    @Field(type => String, { nullable: true })
    contractPaperTypeCode: any;

    @Field(type => String, { nullable: true })
    addressLine: any;

    @Field(type => String, { nullable: true })
    st_ref_cd: any;

    @Field(type => String, { nullable: true })
    cov_eff_dt: any;

    @Field(type => String, { nullable: true })
    cov_end_dt: any;

    @Field(type => String, { nullable: true })
    planCode: any;

    @Field(type => Int, { nullable: true })
    indv_id: number;

    @Field(type => Int, { nullable: true })
    hsc_sts_ref_id: number;

    @Field(type => String, { nullable: true })
    hsc_sts_ref_dspl: any;

    @Field(type => String, { nullable: true })
    srvc_strt_dt: any;

    @Field(type => String, { nullable: true })
    srvc_end_dt: any;

    @Field(type => String, { nullable: true })
    fst_nm: any;

    @Field(type => String, { nullable: true })
    lst_nm: any;

    @Field(type => String, { nullable: true })
    bth_dt: any;

    @Field(type => Int, { nullable: true })
    gdr_ref_id: number;

    @Field(type => String, { nullable: true })
    gdr_ref_dspl: any;
}
