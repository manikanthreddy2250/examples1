import {Field, InputType, Int} from "@nestjs/graphql";

@InputType()
export class GetNextReviewDateRequest {
    @Field(type => Int)
    hsc_id : number;
    @Field(type => Int)
    task_name_ref_id : number;
}
