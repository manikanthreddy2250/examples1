import {Field, Int, ObjectType} from "@nestjs/graphql";

@ObjectType()
export class GetNextReviewDateResponse {
 

    @Field(type => String, { nullable: true })
    configured_days?: any;

    @Field(type => String, { nullable: true })
    next_review_date?: any;

    }
