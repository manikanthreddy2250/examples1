import {Field, InputType} from "@nestjs/graphql";
import {HscProvInput} from "./hsc-prov.input";

@InputType()
export class GetProviderDetailsRequest {
    @Field()
    hscProv: HscProvInput;
}