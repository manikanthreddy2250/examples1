import {Field, ObjectType} from "@nestjs/graphql";
import {HscProv} from "./hsc-prov";

@ObjectType()
export class GetProviderDetailsResponse {
    @Field(type => [HscProv])
    hscProv: HscProv[];
}