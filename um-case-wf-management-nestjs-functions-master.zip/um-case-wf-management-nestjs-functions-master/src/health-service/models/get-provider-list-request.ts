import {Field, InputType} from "@nestjs/graphql";
import {HscProvListInput} from "./hsc-prov-list.input";

@InputType()
export class GetProviderListRequest {
    @Field()
    hscID: HscProvListInput;
}
