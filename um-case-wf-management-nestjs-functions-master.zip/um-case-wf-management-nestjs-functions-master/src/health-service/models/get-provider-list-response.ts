import {Field, ObjectType} from "@nestjs/graphql";
import {ProvList} from "./prov-list";

@ObjectType()
export class GetProviderListResponse {
    @Field(type => [ProvList])
    provList: ProvList[];
}
