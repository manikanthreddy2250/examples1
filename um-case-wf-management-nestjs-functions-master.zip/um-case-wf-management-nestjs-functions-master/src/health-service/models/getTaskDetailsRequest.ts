import {Field, InputType} from "@nestjs/graphql";
import {HsrAssignInput} from "./hsrAssign.input";



@InputType()
export class GetTaskDetailsRequest {
    @Field()
    hsr_asgn: HsrAssignInput;
}

