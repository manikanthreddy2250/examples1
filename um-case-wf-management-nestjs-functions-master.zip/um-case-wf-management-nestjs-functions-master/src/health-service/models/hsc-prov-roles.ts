import {Field, Int, ObjectType} from "@nestjs/graphql";

@ObjectType()
export class HscProvRoles {
    @Field(type => Int, { nullable: true })
    prov_role_ref_id: number;
    @Field(type => Int, { nullable: true })
    hsc_prov_id: number;
}
