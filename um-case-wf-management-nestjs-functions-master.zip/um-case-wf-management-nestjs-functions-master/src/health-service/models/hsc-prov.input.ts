import {Field, InputType, Int} from "@nestjs/graphql";

@InputType()
export class HscProvInput {
    @Field(type => Int)
    hsc_prov_id : number;
}
