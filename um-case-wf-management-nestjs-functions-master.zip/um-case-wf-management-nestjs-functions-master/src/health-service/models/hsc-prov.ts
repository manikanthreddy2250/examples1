import {Field, Int, ObjectType} from "@nestjs/graphql";
import GraphQLJSON from 'graphql-type-json';
import {HscProvRoles} from "./hsc-prov-roles";

@ObjectType()
export class HscProv {
    @Field(type => Int)
    hsc_id: number;

    @Field(type => Int, { nullable: true })
    prov_key_typ_ref_id: number;

    @Field(type => Int, { nullable: true })
    prov_loc_affil_id: any;

    @Field(type => [HscProvRoles])
    hsc_prov_roles: HscProvRoles[];

    @Field(type => GraphQLJSON)
    prov_loc_affil_dtl: any;

}
