import {Field, Int, InputType} from "@nestjs/graphql";

@InputType()
export class HsrAssignInput {

    @Field(type => Int)
    hsc_id: number;

    @Field(type => Int)
    asgn_typ_ref_id: number;

    @Field(type => String,{nullable: true})
    workFlow_cnfg_key: string;
}
