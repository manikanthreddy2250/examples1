import {Field, Int, ObjectType} from "@nestjs/graphql";
import GraphQLJSON from "graphql-type-json";

@ObjectType()
export class HsrAssign {
    @Field(type => Int)
    hsc_id: number;

    @Field(type => Int)
    hsr_asgn_id: number;

    @Field(type => String,{ nullable: true })
    asgn_to_user_id: string;

    @Field(type => String,{ nullable: true })
    src_rec_guid: string;

    @Field(type => String,{ nullable: true })
    creat_user_id: string;

    @Field(type => String,{ nullable: true })
    creat_dttm: string;

    @Field(type => Int,{ nullable: true })
    asgn_catgy_ref_id: number;

    @Field(type => Int,{ nullable: true })
    asgn_typ_ref_id: number;

    @Field(type => Int,{ nullable: true })
    asgn_sts_ref_id: number;

    @Field(type => Int,{ nullable: true })
    asgn_to_wrk_que_ref_id: number;

    @Field(type => GraphQLJSON,{ nullable: true })
    asgn_catgy_ref_cd: any;

    @Field(type => GraphQLJSON,{ nullable: true })
    asgn_typ_ref_cd: any;

    @Field(type => GraphQLJSON,{ nullable: true })
    asgn_sts_ref_cd: any;

    @Field(type => GraphQLJSON,{ nullable: true })
    asgn_to_wrk_que_ref_cd: any;

    @Field(type => GraphQLJSON,{ nullable: true })
    hsc: any;
}
