 import {Field, InputType,ArgsType} from "@nestjs/graphql";

 @ArgsType()
 export class NRTRequest {
     @Field()
     lst_call_dt: string;
 }