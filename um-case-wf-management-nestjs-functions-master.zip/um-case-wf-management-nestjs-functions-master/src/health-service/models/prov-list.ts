import {Field, Int, ObjectType} from "@nestjs/graphql";
import GraphQLJSON from 'graphql-type-json';
import {HscProvRoles} from "./hsc-prov-roles";

@ObjectType()
export class ProvList {
    @Field(type => String, { nullable: true })
    type: any;

    @Field(type => String, { nullable: true })
    bus_nm: any;

    @Field(type => String, { nullable: true })
    fst_nm: any;

    @Field(type => String, { nullable: true })
    lst_nm: any;

    @Field(type => Int, { nullable: true })
    prov_id: number;

    @Field(type => String, { nullable: true })
    telcom_adr_id: any;

    @Field(type => String, { nullable: true })
    spcl_ref_dspl: any;

    @Field(type => Int, { nullable: true })
    spcl_ref_id: number;

    @Field(type => String, { nullable: true })
    prov_role_ref_desc: any;

    @Field(type => String, { nullable: true })
    provider_address: any;

    @Field(type => Int, { nullable: true })
    prov_catgy_ref_id: number;

    @Field(type => String, { nullable: true })
    prov_catgy_ref_desc: any;

    @Field(type => String, { nullable: true })
    providerTin: any;

    @Field(type => String, { nullable: true })
    providerNpi: any;

    @Field(type => Int, { nullable: true })
    ntwk_sts_ref_id: number;

}
