import {Field, InputType} from "@nestjs/graphql";
import GraphQLJSON from "graphql-type-json";
@InputType()
export class ProviderContractRequest {
    @Field()
    mpin: string ;
    @Field()
    tin: string ;
    @Field()
    addressSeqNum: string ;
    @Field()
    facilityName: string ;
    @Field()
    stateCode: string ;
    @Field(type => GraphQLJSON)
    lobRefId: any ;
    @Field()
    entityCode: string ;
    @Field(type => GraphQLJSON)
    contractPaperTypRefId: any ;
    @Field()
    effDate: string ;
    @Field()
    termDate: string ;
    @Field(type => GraphQLJSON)
    medNecRestrictionTypRefId: any ;
    @Field()
    medNecRestriction: string ;
    @Field()
    lastCallDttm: string ;
    @Field()
    insertDttm: string ;
    @Field()
    actionCode: string ;
    @Field()
    lastUpdatedBy: string ;

}