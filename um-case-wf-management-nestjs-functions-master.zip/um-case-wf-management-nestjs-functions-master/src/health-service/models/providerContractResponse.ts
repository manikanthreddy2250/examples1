import {Field, ObjectType} from "@nestjs/graphql";

@ObjectType()
export class ProviderContractResponse {
    @Field(type => [String])
    responseMessage: string[] = [];
}