import {Field, Int, InputType} from "@nestjs/graphql";

@InputType()
export class RequestClinicalEventInput {
    @Field(type => Int, {nullable: true})
    hsc_id: number;
    
    @Field(type => Int ,{nullable: true})
    client_id: number;

    @Field(type => String ,{nullable: true})
    channel: string;

    @Field(type => Int ,{nullable: true})
    fax_num: number;

    @Field(type => String ,{nullable: true})
    email_id: string;

    @Field(type => String ,{nullable: true})
    requesterId: string;
}