import {Field, Int, InputType} from "@nestjs/graphql";


@InputType()
export class DischargeSignalRequest {
    @Field(type => Int, {nullable: true})
    hsc_id: number;
    
    @Field(type => String ,{nullable: true})
    client: string;
}
