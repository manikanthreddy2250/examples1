import {Field, Int, InputType} from "@nestjs/graphql";
import { DischargeSignalRequest } from "./dischargeSignal.request";


@InputType()
export class DocumentReceivedSignalRequest extends DischargeSignalRequest {

}