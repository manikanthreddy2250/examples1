import { Test, TestingModule } from '@nestjs/testing';
import { HealthServiceResolver } from './health-service.resolver';
import { HealthService } from '../service/health-service/health-service.service';
import { GetProviderDetailsRequest } from "../models/get-provider-details-request";
import { GetProviderDetailsResponse } from "../models/get-provider-details-response";
import { HttpModule, HttpService, Injectable, Logger } from '@nestjs/common';
import { CaseValidationService } from "../service/case-validation/caseValidation.service";
import { CaseValidationRequest } from "../model/CaseValidationRequest";
import { GetTaskDetailsRequest } from "../models/getTaskDetailsRequest";
import { of } from "rxjs/internal/observable/of";
import { GetTaskDetailsResponse } from "../models/getTaskDetailsResponse";
import { TaskListRequest } from "../models/TaskListRequest";
import { TaskListResponse } from "../models/TaskListResponse";
import { CaseValidationResponse } from "../model/CaseValidationResponse";
import { ProviderContractRequest } from "../models/providerContractRequest";
import { ProviderContractResponse } from "../models/providerContractResponse";
import { ProviderContractService } from "../service/provider-contract/provider-contract.service";
import { ConfigModule } from "@nestjs/config";
import { GetProviderListRequest } from "../models/get-provider-list-request";
import { GetCaseHeaderDetailsRequest } from "../models/get-case-header-details-request";
import { NRTRequest } from "../models/nrtRequest";
import { AxiosResponse } from "axios";
import { CamundaSignalService } from '../service/signal-service/camunda.signal.service';
import { DischargeSignalRequest } from '../models/signal/dischargeSignal.request';
import { DischargeSignalResponse } from '../models/signal/dischargeSignal.response';
import { GetTaskDetailsService } from "../service/getTaskDetails/getTaskDetails.service";
import { RequestClinicalEventInput } from '../models/request-clinical-event-input';
import { PublishLetterEventRequest } from '../models/events/publishLetterEvent.request';
import { PublishLetterEventResponse } from '../models/events/publishLetterEvent.response';
import { GetNextReviewDateRequest } from '../models/get-next-review-date-request';
@Injectable()
class MockHealthServiceService {

    getProviderDetails(getProviderDetailsRequest: GetProviderDetailsRequest): Promise<GetProviderDetailsResponse> {
        const res: any = {
            "hscProv": [
                {
                    "hsc_id": 68
                }
            ]
        };
        return of(res).toPromise();
    }

    publishLetterEvent(publishLetterEventRequest: any, context: any): Promise<PublishLetterEventResponse> {

        const publishLetterEventResponse: PublishLetterEventResponse = {
            "publishLetterEventResponse": "Letter Sent Successfully"
        };
        return of(publishLetterEventResponse).toPromise();
    }
}

@Injectable()
class MockGetTaskDetailsService {

    getHscTaskDetails(getTaskDetailsRequest: GetTaskDetailsRequest): Promise<GetTaskDetailsResponse> {
        const sampleRes: any = {
            "data": {
                "getHscTaskDetails": {
                    "hsr_asgn": {
                        "hsc_id": 12845,
                        "hsr_asgn_id": 1,
                        "asgn_to_user_id": "skonjeti",
                        "asgn_typ_ref_id": null,
                        "tsk_nm_ref_cd": null,
                        "asgn_sts_ref_id": null,
                        "tsk_sts_ref_cd": null,
                        "asgn_catgy_ref_id": 72060,
                        "tsk_catgy_ref_cd": {
                            "ref_dspl": "Eligibility",
                            "ref_desc": "eligibility",
                            "ref_id": 72060
                        },
                        "asgn_to_wrk_que_ref_id": null,
                        "asgn_to_wrk_que_ref_cd": null
                    }
                }
            }
        };
        return of(sampleRes).toPromise();
    }

    getTaskListByHscId(taskListRequest: TaskListRequest): Promise<TaskListResponse> {
        const taskListResponse: any = {
            "data": {
                "getTaskListByHscId": {
                    "hsr_asgn": [
                        {
                            "hsc_id": 12345,
                            "hsr_asgn_id": 1,
                            "asgn_to_user_id": "cchint1",
                            "asgn_typ_ref_id": 72064,
                            "tsk_nm_ref_cd": {
                                "ref_dspl": "LOC"
                            },
                            "asgn_sts_ref_id": null,
                            "tsk_sts_ref_cd": null,
                            "asgn_catgy_ref_id": 72060,
                            "tsk_catgy_ref_cd": {
                                "ref_dspl": "Eligibility"
                            },
                            "asgn_to_wrk_que_ref_id": null,
                            "asgn_to_wrk_que_ref_cd": null
                        }]
                }
            }
        };
        return of(taskListResponse).toPromise();
    }
}

class MockCaseValidationService {

    CaseValidationService(caseValidationRequest: CaseValidationService): Promise<CaseValidationResponse> {
        const sampleRes: any = {
            "data": {
                "caseValidation": {
                    "hsc_id": "12908",
                    "eligibilityCheck": true,
                    "providerCheck": true,
                    "contractCheck": true,
                    "sOSCheck": true,
                    "lOCReviewCheck": true,
                    "lOSReviewCheck": true,
                    "duplicateCaseCheck": true,
                    "facilityOutOfNetworkCheck": false,
                    "dxCodeCheck": true,
                    "validateClinicalDocument": true
                }
            }
        };
        return of(sampleRes).toPromise();
    }
}

@Injectable()
class MockProviderContractService {

    saveContract(providerContractRequest: ProviderContractRequest): Promise<ProviderContractResponse> {
        const res: ProviderContractResponse = {
            responseMessage: ["success"]
        };
        return of(res).toPromise();
    }
    getProviderContractData(nrtRequest: NRTRequest): Promise<ProviderContractResponse> {
        const res: ProviderContractResponse = {
            responseMessage: ["success"]
        };
        return of(res).toPromise();
    }
}

@Injectable()
class MockCamundaSignalService {

    sendSignal(req: DischargeSignalRequest): Promise<DischargeSignalResponse> {
        const res: DischargeSignalResponse = {
            dischargeSignalResponse: ["success"]
        };
        return of(res).toPromise();
    }
}

describe('HealthServiceResolver', () => {
    let resolver: HealthServiceResolver;
    let httpService: HttpService;
    let context = { req: { headers: {} } };
    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            imports: [ConfigModule, HttpModule],
            providers: [HealthServiceResolver, Logger, { provide: HealthService, useClass: MockHealthServiceService },
                CaseValidationService, { provide: GetTaskDetailsService, useClass: MockGetTaskDetailsService },
                { provide: CaseValidationService, useClass: MockCaseValidationService },
                { provide: ProviderContractService, useClass: MockProviderContractService },
                { provide: CamundaSignalService, useClass: MockCamundaSignalService }],
        }).compile();

        resolver = module.get<HealthServiceResolver>(HealthServiceResolver);
        httpService = module.get<HttpService>(HttpService);
    });

    it('should be defined', () => {
        expect(resolver).toBeDefined();
    });

    it('should call getProviderDetails', () => {
        const getProviderDetailsRequest: GetProviderDetailsRequest = { hscProv: { hsc_prov_id: 7 } };
        const response = resolver.getProviderDetails(getProviderDetailsRequest, context.req);
        expect(response).toBeTruthy();
    });

    it('should call getProviderList', () => {
        const getProviderListRequest: GetProviderListRequest = { hscID: { hsc_id: 7 } };
        const response = resolver.getProviderList(getProviderListRequest, context.req);
        expect(response).toBeTruthy();
    });

    it('should call getCaseHeaderDetails', () => {
        const getCaseHeaderDetailsRequest: GetCaseHeaderDetailsRequest = { hscID: { hsc_id: 7 } };
        const response = resolver.getCaseHeaderDetails(getCaseHeaderDetailsRequest, context.req);
        expect(response).toBeTruthy();
    });

    it('should call get task details', () => {
        const getTaskDetailsRequest: GetTaskDetailsRequest = {
            "hsr_asgn": {
                "hsc_id": 12845,
                "asgn_typ_ref_id": 72064,
                "workFlow_cnfg_key": "inpatientBaseWF"
            }
        };
        resolver.getHscTaskDetails(getTaskDetailsRequest, context.req).then((res) => {
            expect(res.task.hsc_id).toEqual(12845);
            expect(res.task.tsk_nm_ref_id).toEqual(72064);
        });
    });

    it('should call case validation', () => {
        const caseValidationRequest: CaseValidationRequest = { hsc_id: "12908", validateEligibility: false, validateProvider: true, validateContract: true, validateSOS: true, validateLOCReview: true, validateLOSReview: true, validateDuplicateCase: true, validateFacilityOutOfNetwork: true, validateDxCode: true, validateClinicalDocument: true, validateReadmission: true };
        resolver.caseValidation(caseValidationRequest, context.req).then((res) => {
            expect(res.hsc_id).toEqual(12908);
        });
    });

    it('should call get taskList', () => {
        const request: TaskListRequest = {
            "hsc_id": 12345,
            "asgn_to_user_id": "skonjeti"
        };
        resolver.getTaskListByHscId(request, context.req).then((res) => {
            expect(res.hsr_asgn[0].hsc_id).toEqual(12345);
            expect(res.hsr_asgn[0].asgn_to_user_id).toEqual("skonjeti");
        });
    });
    it('should call getProviderContractData', async () => {
        const tokenResult: AxiosResponse = {
            data: {
                access_token: '123445566777asdsfdgfgf'
            },
            status: 200,
            statusText: 'OK',
            headers: {},
            config: {},
        };
        const lst_call_dt = "2021-04-03T22:02:41.697";
        const url = 'https://gateway-stage.optum.com/api/dev/ext/nrt/mednecrestriction/v1/MedNecRestriction/get?lst_call_dt=2021-03-02T22:02:41.697';
        const responseResult: AxiosResponse = {
            data: [{
                "MPIN": "302922",
                "Tax_ID_TIN": "561303855",
                "Address_Seq_Num": "13",
                "Fac_Prov_Name_Primary": "FAYETTEVILLE VAMC",
                "State_CD": "NC",
                "LOB": 0,
                "Entity": "CIP\r\n",
                "Contract_Paper_Type": 0,
                "Eff_Dt": "2020-10-02T00:00:00",
                "Term_Dt": "0001-01-01T00:00:00",
                "Med_Nec_Restriction_Type_Name": 0,
                "Med_Nec_Restriction": "Y",
                "Lst_Call_Dt": "2021-04-02",
                "Insert_Dt": "2021-04-02",
                "Action_CD": "I",
                "Lst_Updt_By": "cstove2"
            }],
            status: 200,
            statusText: 'OK',
            headers: {},
            config: {}
        };
        jest.spyOn(httpService, 'post').mockImplementationOnce(() => of(tokenResult));
        jest.spyOn(httpService, 'get').mockImplementationOnce(() => of(responseResult));
        await resolver.getProviderContractData(context.req).then((res) => {
            expect(res.responseMessage[0]).toEqual("success");
        });
    });

    it('should call generateLetterEvent', () => {
        const requestClinicalEventInput: RequestClinicalEventInput = {
            "hsc_id": 13596,
            "client_id": 1,
            "channel": 'WEB',
            "fax_num": 1234,
            "email_id": 'test@optum.com',
            "requesterId": 'system'
        };
        const response = resolver.generateLetterEvent(requestClinicalEventInput, context.req);
        expect(response).toBeTruthy();
    });

    it('should call sendLetterEvent', async () => {
        const publishLetterEventRequest: PublishLetterEventRequest = {
            "hsc_id": 13596,
            "client": "1",
            "decisionIds": [1, 2, 3],
            "eventChannel": "testWorkflow",
            "appUserId": "system"
        };

        //spyOn(healthService,'publishLetterEvent').and.returnValue(publishLetterEventResponse);
        await resolver.sendLetterEvent(publishLetterEventRequest, context.req).then((res) => expect(res).toBeTruthy());
    });
    it('should call hsc getNextLReviewDate', () => {
       // let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
        const getNextReviewDateRequest: GetNextReviewDateRequest = {hsc_id : 7,task_name_ref_id: 72138};
        const response = resolver.getNextReviewDate(getNextReviewDateRequest, context).then((res) => {
            expect(res).toBeDefined();
        });
    });
});
