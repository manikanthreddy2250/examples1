import {Args, Query, Resolver, Context, Mutation} from '@nestjs/graphql';
import {HealthService} from '../service/health-service/health-service.service';
import {GetProviderDetailsRequest} from "../models/get-provider-details-request";
import {GetProviderDetailsResponse} from "../models/get-provider-details-response";
import {CaseValidationService} from "../service/case-validation/caseValidation.service";
import {ProviderContractService} from "../service/provider-contract/provider-contract.service";
import {ProviderContractRequest} from "../models/providerContractRequest";
import {ProviderContractResponse} from "../models/providerContractResponse";
import {CaseValidationRequest} from "../model/CaseValidationRequest";
import {CaseValidationResponse} from "../model/CaseValidationResponse";
import {GetTaskDetailsResponse} from "../models/getTaskDetailsResponse";
import {GetTaskDetailsRequest} from "../models/getTaskDetailsRequest";
import {GetTaskDetailsService} from "../service/getTaskDetails/getTaskDetails.service";
import {UseFilters, UseGuards} from "@nestjs/common";
import {AuthGuard} from "../../auth/auth.guard";
import {NotFoundException} from '@nestjs/common';
import {AllExceptionsFilter} from "../../filters/graphql-exception.filter";
import {TaskListResponse} from "../models/TaskListResponse";
import {TaskListRequest} from "../models/TaskListRequest";
import {GetProviderListRequest} from "../models/get-provider-list-request";
import {GetCaseHeaderDetailsRequest} from "../models/get-case-header-details-request";
import {GetCaseHeaderDetailResponse} from "../models/get-case-header-detail-response";
import {GetProviderListResponse} from "../models/get-provider-list-response";
import {Role} from "../../decorators/roles";
import {Roles} from "../../decorators/roles.decorator";
import {RolesGuard} from "../../auth/roles.guard";
import {NRTRequest} from "../models/nrtRequest";
import {DischargeSignalRequest} from '../models/signal/dischargeSignal.request';
import {CamundaSignalService} from '../service/signal-service/camunda.signal.service';
import {DischargeSignalResponse} from '../models/signal/dischargeSignal.response';
import { DocumentReceivedSignalRequest } from '../models/signal/documentRecievedSignal.request';
import { DocumentReceivedSignalResponse } from '../models/signal/documentReceivedSignal.response';
import { RequestClinicalEventOutput } from '../models/request-clinical-event-output';
import { RequestClinicalEventInput } from '../models/request-clinical-event-input';
import { GetActivitiesRequest } from '../models/get-activities.request';
import { GetActivitiesResponse } from '../models/get-activities.response';
import {PublishLetterEventRequest} from '../models/events/publishLetterEvent.request';
import {PublishLetterEventResponse} from '../models/events/publishLetterEvent.response';
import { GetNextReviewDateRequest } from '../models/get-next-review-date-request';
import { GetNextReviewDateResponse } from '../models/get-next-review-date-response';


@Resolver()
export class HealthServiceResolver {

    constructor(private healthService: HealthService,
                private caseValidationService: CaseValidationService,
                private getTaskDetailsService: GetTaskDetailsService,
                private providerContractService: ProviderContractService,
                private camundaSignalService: CamundaSignalService) {
    }

    @Query(returns => GetProviderDetailsResponse, {description: "Query to get provider details"})
    @UseGuards(AuthGuard, RolesGuard)
    @Roles(Role.CASE_MGMT_ADMIN, Role.CASE_MGMT_CDU, Role.CASE_MGMT_MD, Role.CASE_MGMT_NURSE, Role.CASE_MGMT_SYSTEM)
    @UseFilters(new AllExceptionsFilter())
    async getProviderDetails(@Args('getProviderDetailsRequest') getProviderDetailsRequest: GetProviderDetailsRequest, @Context() context) {
        return this.healthService.getProviderDetails(getProviderDetailsRequest, context.req);
    }

    @Query(returns => GetProviderListResponse, {description: "Query to get provider list"})
    @UseGuards(AuthGuard, RolesGuard)
    @Roles(Role.CASE_MGMT_ADMIN, Role.CASE_MGMT_CDU, Role.CASE_MGMT_MD, Role.CASE_MGMT_NURSE, Role.CASE_MGMT_SYSTEM)
    @UseFilters(new AllExceptionsFilter())
    async getProviderList(@Args('getProviderListRequest') getProviderListRequest: GetProviderListRequest, @Context() context) {
        return this.healthService.getProviderList(getProviderListRequest, context.req);

    }

    @Query(returns => GetCaseHeaderDetailResponse, {description: "Query to get Case header details"})
    @UseGuards(AuthGuard, RolesGuard)
    @Roles(Role.CASE_MGMT_ADMIN, Role.CASE_MGMT_CDU, Role.CASE_MGMT_MD, Role.CASE_MGMT_NURSE, Role.CASE_MGMT_SYSTEM)
    @UseFilters(new AllExceptionsFilter())
    async getCaseHeaderDetails(@Args('getCaseHeaderDetailsRequest') getCaseHeaderDetailsRequest: GetCaseHeaderDetailsRequest, @Context() context) {
        return this.healthService.getCaseHeaderDetails(getCaseHeaderDetailsRequest, context.req);

    }

    @Query(returns => GetTaskDetailsResponse, {description: "Query to get existing hsr task details"})
    @UseGuards(AuthGuard, RolesGuard)
    @Roles(Role.CASE_MGMT_ADMIN, Role.CASE_MGMT_CDU, Role.CASE_MGMT_MD, Role.CASE_MGMT_NURSE, Role.CASE_MGMT_SYSTEM)
    @UseFilters(new AllExceptionsFilter())
    async getHscTaskDetails(@Args('getTaskDetailsRequest') getTaskDetailsRequest: GetTaskDetailsRequest, @Context() context) {
        return this.getTaskDetailsService.getTaskDetails(getTaskDetailsRequest, context.req);
    }

    @Query(returns => TaskListResponse, {description: "Query to get list of tasks by hscId"})
    @UseGuards(AuthGuard, RolesGuard)
    @Roles(Role.CASE_MGMT_ADMIN, Role.CASE_MGMT_CDU, Role.CASE_MGMT_MD, Role.CASE_MGMT_NURSE, Role.CASE_MGMT_SYSTEM)
    @UseFilters(new AllExceptionsFilter())
    async getTaskListByHscId(@Args('taskListRequest') taskListRequest: TaskListRequest, @Context() context) {
        return this.getTaskDetailsService.getTaskListByHscId(taskListRequest, context.req);
    }

    @Query(returns => CaseValidationResponse)
    @UseGuards(AuthGuard, RolesGuard)
    @Roles(Role.CASE_MGMT_ADMIN, Role.CASE_MGMT_CDU, Role.CASE_MGMT_MD, Role.CASE_MGMT_NURSE, Role.CASE_MGMT_SYSTEM)
    @UseFilters(new AllExceptionsFilter())
    async caseValidation(@Args('caseValidationRequest') caseValidationRequest: CaseValidationRequest, @Context() context) {
        return this.caseValidationService.caseValidation(caseValidationRequest, context.req);
    }

    @Query(returns => ProviderContractResponse, {description: "Query to save provider"})
    @UseGuards(AuthGuard, RolesGuard)
    @Roles(Role.CASE_MGMT_ADMIN, Role.CASE_MGMT_CDU, Role.CASE_MGMT_MD, Role.CASE_MGMT_NURSE, Role.CASE_MGMT_SYSTEM)
    @UseFilters(new AllExceptionsFilter())
    async saveProviderContracts(@Args({
        name: 'providerContractRequest',
        type: () => [ProviderContractRequest]
    }) providerContractRequest: ProviderContractRequest[], @Context() context) {
        return this.providerContractService.saveContract(providerContractRequest, context.req);
    }

    @Query((returns) => ProviderContractResponse)
    async getProviderContractData(@Context() context) {
        return this.providerContractService.getProviderContractData(context.req);
    }

    @Query(returns => DischargeSignalResponse)
    @UseGuards(AuthGuard, RolesGuard)
    @Roles(Role.CASE_MGMT_SYSTEM)
    @UseFilters(new AllExceptionsFilter())
    async sendDischargeSignal(@Args('dischargeSignalRequest') dischargeSignalRequest: DischargeSignalRequest, @Context() context) {
        return this.camundaSignalService.sendDischargeNotificationSignal(dischargeSignalRequest, context);
    }

    @Query(returns => DocumentReceivedSignalResponse)
    @UseGuards(AuthGuard, RolesGuard)
    @Roles(Role.CASE_MGMT_SYSTEM)
    @UseFilters(new AllExceptionsFilter())
    async sendDocumentReceivedSignal(@Args('documentReceivedSignalRequest') documentReceivedSignalRequest: DocumentReceivedSignalRequest, @Context() context) {
          return this.camundaSignalService.sendDocumentReceivedSignal(documentReceivedSignalRequest, context);
      }

    @Query(returns => RequestClinicalEventOutput, { description: "Query to get provider details" })
    @UseGuards(AuthGuard, RolesGuard)
    @Roles(Role.CASE_MGMT_ADMIN, Role.CASE_MGMT_CDU, Role.CASE_MGMT_MD, Role.CASE_MGMT_NURSE, Role.CASE_MGMT_SYSTEM) //role ?
    @UseFilters(new AllExceptionsFilter())
    async generateLetterEvent(@Args('requestClinicalEventInput') requestClinicalEventInput: RequestClinicalEventInput, @Context() context) {
      return this.healthService.requestForClinical(requestClinicalEventInput, context.req);
      }
  @Query(returns => GetActivitiesResponse)
  @UseGuards(AuthGuard, RolesGuard)
  @Roles(Role.CASE_MGMT_ADMIN, Role.CASE_MGMT_CDU, Role.CASE_MGMT_MD, Role.CASE_MGMT_NURSE, Role.CASE_MGMT_SYSTEM)
  @UseFilters(new AllExceptionsFilter())
  async getActivities(@Args('getActivitiesRequest') getActivitiesRequest: GetActivitiesRequest, @Context() context) {
    return this.getTaskDetailsService.getActivitiesByHscId(getActivitiesRequest, context.req);
  }

    @Query(returns => PublishLetterEventResponse)
    @UseGuards(AuthGuard, RolesGuard)
    @Roles(Role.CASE_MGMT_ADMIN, Role.CASE_MGMT_CDU, Role.CASE_MGMT_MD, Role.CASE_MGMT_NURSE, Role.CASE_MGMT_SYSTEM)
    @UseFilters(new AllExceptionsFilter())
    async sendLetterEvent(@Args('publishLetterEventRequest') publishLetterEventRequest: PublishLetterEventRequest, @Context() context) {
        return this.healthService.publishLetterEvent(publishLetterEventRequest, context.req);
    }
  @Query(returns => GetNextReviewDateResponse, {description: "Query to save provider"})
  @UseGuards(AuthGuard, RolesGuard)
  @Roles(Role.CASE_MGMT_ADMIN, Role.CASE_MGMT_CDU, Role.CASE_MGMT_MD, Role.CASE_MGMT_NURSE, Role.CASE_MGMT_SYSTEM)
  @UseFilters(new AllExceptionsFilter())
  async getNextReviewDate(@Args('getNextReviewDateRequest') getNextReviewDateRequest: GetNextReviewDateRequest, @Context() context) {
    return this.healthService.getNextReviewDate(getNextReviewDateRequest, context.req);
  }
}
