import {CaseValidationResponse} from "../../model/CaseValidationResponse";
import {CaseValidationRequest} from "../../model/CaseValidationRequest";
import {
    getHscProviderRolesByHscId,
    hscDuplicateCheckMutation,
    getReviewIdByHscId,
    getCoverageDetailsByHscId,
    getHscFaclByHscId,
    getAmissionDateByHscId, getDischargedHscCount,
} from '../../shared/graphql/healthservicedomain/healthServiceQuery';
import {
    applicationConstants,
    ConfigServiceConstants,
    healthServiceConstants
} from '../../shared/constants/applicationConstants';
import {getDocumentsByDocId} from '../../shared/graphql/documentservicedomain/documentServiceQuery';
import axios from "axios";
import { GraphQLClient } from 'graphql-request/dist';
import { ConfigService } from '@nestjs/config';
import {DomainConstants} from "../../../configuration/constants/domainConstants";
import {EcpClaim} from '@ecp/func-tk/src/lib/authorization-services/models/EcpClaim';
import {AuthorizationService} from "@ecp/func-tk/dist";
import {EcpTokenFeilds} from '@ecp/func-tk/src/lib/authorization-services/models/EcpTokenFeilds';
import moment = require('moment');
import {HttpRequest} from "@azure/functions";
import {ConfigurationDomainService} from "../../../service/configuration-domain/configuration-domain.service";
import {Injectable} from '@nestjs/common';

var HscGraphqlClient;
var DocGraphqlClient;
var DuplicateGraphqlClient;
let configService : ConfigService;
let configurationDomainService:ConfigurationDomainService;
@Injectable()
export class DuplicateCheckServiceClient {
    private duplicateCheckClient;
    constructor() {
               this.duplicateCheckClient = new GraphQLClient(applicationConstants.DUPLICATE_CHECK_VALIDATION);
           }
    public getGraphqlClient(req: HttpRequest): GraphQLClient {
                const headers = {
                        'content-type': req.headers['content-type'],
                       Authorization: req.headers['authorization'],
                        'x-hasura-role': req.headers['x-hasura-role'],
                    };
                this.duplicateCheckClient.setHeaders(headers);
                return this.duplicateCheckClient;
            }

}
async function caseValidation(caseValidationRequest,httpRequest,hscGraphqlClient,docGraphqlClient,duplicateCheckClient) {
    HscGraphqlClient = hscGraphqlClient;
    DocGraphqlClient = docGraphqlClient;
    DuplicateGraphqlClient = duplicateCheckClient;
    configService = new ConfigService();
    configurationDomainService = new ConfigurationDomainService(configService);
    const response = new CaseValidationResponse();
        response.hsc_id = caseValidationRequest.hsc_id;
    const CONTENT_TYPE = DomainConstants.CONTENT_TYPE;
    const headerParams = {
        'Content-Type': DomainConstants.CONTENT_TYPE,
        'Accept': DomainConstants.CONTENT_TYPE,
        'Authorization': httpRequest.headers['authorization']
    };

    response.eligibilityCheck = await eligibilityCheck(caseValidationRequest,httpRequest);

    if (caseValidationRequest.validateProvider) {
        response.providerCheck = await providerCheck(caseValidationRequest, httpRequest);
    }
    else{
        response.providerCheck = true;
    }

    response.contractCheck = mockContractCheck(caseValidationRequest,headerParams);

    response.sOSCheck = mockSOSCheck(caseValidationRequest,headerParams);

    response.lOCReviewCheck =await locReviewCheck(caseValidationRequest,headerParams);

    response.lOSReviewCheck = await lOSCheck(caseValidationRequest,httpRequest);

    response.dxCodeCheck = mockDxCode(caseValidationRequest,headerParams);

    response.duplicateCaseCheck = await duplicateCaseCheck(caseValidationRequest,httpRequest,duplicateCheckClient);

    response.facilityOutOfNetworkCheck = mockFacilityOutOfNetworkCheck(caseValidationRequest,headerParams);

    response.clinicalDocumentCheck = await documentCheck(caseValidationRequest,headerParams);
    response.readmissionCheck= await readmissionValidation(caseValidationRequest,httpRequest);
    return response;
}

async function eligibilityCheck(caseValidationRequest: CaseValidationRequest, headerParams:any ) {
if(caseValidationRequest.validateEligibility) {
    const body = {
        hscId: caseValidationRequest.hsc_id
    };

    const data = await HscGraphqlClient.request(getCoverageDetailsByHscId, body );
    const memCovType = data.hsc[0]?.mbr_cov_dtl?.coverageTypeDesc;

    if(memCovType?.length > 0){
       //Fetching coverage values
        const memCovStartDt = data.hsc[0].mbr_cov_dtl?.cov_eff_dt;
        const memCovEndDt = data.hsc[0].mbr_cov_dtl?.cov_end_dt;

        //Fetching current date
        const currentDate = new Date();

        //Setting the date string as date object
        const covEndDate = new Date(memCovEndDt);
        const covStartDate= new Date(memCovStartDt);

        //getting caseType
        const hscData = await HscGraphqlClient.request(getHscFaclByHscId, body );
        var memAdmitdt = hscData.hsc[0].hsc_facls[0]?.actul_admis_dttm;
        memAdmitdt= new Date(memAdmitdt);
        const caseType = hscData.hsc[0]?.srvc_set_ref_id;

        const configBody = {
            "serviceSettingTypeRefID" : caseType
        }
        const configVal = await getConfigFromDmn(headerParams, configBody, "RequiredProviderRole");
        const config = configVal[0]?.requiredDateChecks;
        var result;

        switch(config){
            case "currentdate":
                  result = checkCoverage(currentDate,covStartDate,covEndDate);
                  return result;
                    break;

            case "admitdate":
                  result = checkCoverage(memAdmitdt,covStartDate,covEndDate);
                  return result;
                    break;
            default:
                    return false;
        }
    }
    return false;
    }
    else
    {
       return true;
    }
}

function checkCoverage(reqCheckDate:any,startDate:any,endDate:any  ){
    if(( reqCheckDate < startDate) || (reqCheckDate > endDate)){
        //when is policy is inactive or coverage dates are expired
        return false;
    }
    else if( (reqCheckDate >= startDate) && (reqCheckDate <= endDate) ){
        //when policy is active that is current date is in between coverage start and end date
        return true;
    }
	return false;
}

async function providerCheck(caseValidationRequest: CaseValidationRequest, headerParams: any) {
    var providerCheck = true;

        //Get hsc provider list
        const body = {
            hscId: caseValidationRequest.hsc_id
        };
        // Get list of providers associated with HSC
        const hscData = await HscGraphqlClient.request(getHscProviderRolesByHscId, body);
        const hscProviders = hscData.hsc[0].hsc_provs;

        //get required provider list for serviceSettingType from DMN
        const caseType = hscData.hsc[0].srvc_set_ref_id;
        const configBody = {
            "serviceSettingTypeRefID": caseType
        };
        const config = await getConfigFromDmn(headerParams, configBody, "RequiredProviderRole");
        const requiredProviderList = config;

        //Check if all the required providers exist in HSC
        requiredProviderList?.forEach(function (requiredProviderRole) {
            if (requiredProviderRole.requiredProviders) {
                let roleExist = false;
                for(const provider of hscProviders) {
                    roleExist = provider.hsc_prov_roles.find((element: any) => element.prov_role_ref_id == requiredProviderRole.requiredProviders) ? true : false;
                    if (roleExist) {
                        break;
                    }
                }
                if (!roleExist) {
                    providerCheck = false;
                }
            }
        });

    return providerCheck;
}

function mockContractCheck(caseValidationRequest: CaseValidationRequest,headerParams:any) {
    if(caseValidationRequest.validateContract) {
        return false;
    }
    else{
        return true;
    }

}

function mockSOSCheck(caseValidationRequest: CaseValidationRequest,headerParams:any) {
    if(caseValidationRequest.validateSOS) {
        return false;
    }
    else{
        return true;
    }


}

async function locReviewCheck(caseValidationRequest: CaseValidationRequest,headerParams:any) {
    if(caseValidationRequest.validateLOCReview) {
	 const body = {
         hscId: caseValidationRequest.hsc_id
     };
     const data = await HscGraphqlClient.request(getReviewIdByHscId, body );
     const reviewIds = data.hsc_clin_guid[0]?.clin_rev_sys_rec_id;
     if(reviewIds?.length > 0){
           return true;
     }
     else{
         return false;
     }
     }
    else {
        return true;
    }
}
async function lOSCheck(caseValidationRequest: CaseValidationRequest,headerParams:any) {
    if(caseValidationRequest.validateLOSReview) {
    var losCheck=true;
    const body = {
        hscId: caseValidationRequest.hsc_id
    };
    const losdata = await HscGraphqlClient.request(getHscFaclByHscId,body);
    const actdate = losdata.hsc[0].hsc_facls[0]?.actul_dschrg_dttm;
    const ref=losdata.hsc[0]?.srvc_set_ref_id;

    const configBody = {
            "serviceSettingTypeRefID" : ref
        };
    const configVal = await getConfigFromDmn(headerParams, configBody, "RequiredProviderRole");
    let val = "";
        if(configVal){
            val =configVal[0]?.LosCheck;}
    switch(val)
        {
           case "actualDischargeDate":
                 if(ref === healthServiceConstants.SERVICE_SETTING_REF_ID_INPATIENT && actdate === null)
                     {
                        return true;
                     }
                 break;
           default:
               return false;
        }
   return false;    }
    else {
        return true;
    }
}
async function documentCheck(caseValidationRequest: CaseValidationRequest,headerParams:any) {
    if(caseValidationRequest.validateClinicalDocument) {
    const body = {
        docRecId: caseValidationRequest.hsc_id
    };
    const docdata = await DocGraphqlClient.request(getDocumentsByDocId,body);
    const docId=docdata.doc_sbj[0]?.doc_id;
    if(docId)
    {
      return true;
    }
    else
    {
      return false;
    }
    }
    else{
        return true;
    }
}

async function duplicateCaseCheck(caseValidationRequest: CaseValidationRequest,httpRequest:any,duplicateCheckClient: GraphQLClient) {
if(caseValidationRequest.validateDuplicateCase) {
    var duplicateCaseCheck = true;
    try {
        const hsc_id = Number(caseValidationRequest.hsc_id);
        const headerParams  =  {
                'Content-Type': DomainConstants.CONTENT_TYPE,
                'x-bpm-cli-org-id': httpRequest.headers['x-bpm-cli-org-id'],
                'x-bpm-func-role': httpRequest.headers['x-bpm-func-role'],
                'x-bpm-tenant-id': 'ecpumcasemgmtbasedmngrp',
                'Authorization' : httpRequest.headers['authorization']
            };
        const duplicateCheckRequestInput = {
            "duplicateCheckRequestInput": {
                "hsc": {
                    "hsc_id": hsc_id
                }
            }
        };
        const hscDuplicatCheckResponse = await duplicateCheckClient.request(hscDuplicateCheckMutation,duplicateCheckRequestInput,headerParams);
        if (hscDuplicatCheckResponse && hscDuplicatCheckResponse.duplicateCheck.hsc_duplicates) {
            if(hscDuplicatCheckResponse.duplicateCheck.hsc_duplicates?.length>0) {
                duplicateCaseCheck = false;
                return duplicateCaseCheck;
            }
        }
        return duplicateCaseCheck;
    }
    catch (err) {
        console.error(`Error while executing CaseValidation ${err}`);
        return duplicateCaseCheck;
    }
    }
    else {
        return true;
    }

}

async function readmissionValidation(caseValidationRequest: CaseValidationRequest,httpRequest:any){
    if(caseValidationRequest.validateReadmission){
        const requestBody = {
            hscId: caseValidationRequest.hsc_id
        };
        const queryResponse = await HscGraphqlClient.request(getAmissionDateByHscId, requestBody );
        const actul_admis_dttm = queryResponse.hsc[0].hsc_facls[0].actul_admis_dttm;
        const indv_id =queryResponse.hsc[0].indv_id;
        const cnfgKey = ConfigServiceConstants.READMISSION_CONFIG_KEY;
        const configResponse = await configurationDomainService.getConfigJson(cnfgKey,httpRequest)
        const configValue =JSON.parse(configResponse?.length ? configResponse[0].value:"");
        const readmissionCriteriaValue=configValue?.days;
        const admisMinusReadmissionConfig= moment(actul_admis_dttm).subtract(readmissionCriteriaValue,'day').format('YYYY-MM-DD');
        /*
        Readmission logic: caluclatedDate = actualAdmissionDate - readmissionConfigValue(ex:30 days)
        calling db to get dischargedHscCount : dischargeDate >= caluclatedDate
         */
        const body = {
            indv_id: indv_id,
            admisMinusReadmissionConfig: admisMinusReadmissionConfig
        };
        const response = await HscGraphqlClient.request(getDischargedHscCount, body );
        if(response.hsc_facl_aggregate?.aggregate?.count >0){
            return true;
        }
        return false;
    }
    else{
        return false;
    }
}

function mockFacilityOutOfNetworkCheck(caseValidationRequest: CaseValidationRequest,headerParams:any) {
    if(caseValidationRequest.validateFacilityOutOfNetwork) {
        return false;
    }
    else{
    return true;
    }
}

function mockDxCode(caseValidationRequest: CaseValidationRequest,headerParams:any) {
    if(caseValidationRequest.validateDxCode) {
        return false;
    }
    else{
    return true;
    }
}

function getErrorResponse(statusCode: Number, mesg: String) {
    return {
        status: statusCode,
        body: mesg
    }
}

async function getConfigFromDmn(httpRequest : any , body : any, dmnId : any): Promise<any> {
    let configResponse;

    const rulesUri = configService.get<string>('UM_RULES_ENDPOINT');
    const configHttpUrl = rulesUri + dmnId +  "/evaluate";

    const orgId = httpRequest.headers['x-bpm-cli-org-id'];
    const authorizationHeader = httpRequest.headers['authorization'];
    const token = authorizationHeader.replace("Bearer " , "");

    const bpmFunctionalRole = await getFunctionalRole(token);

    var tenentId = "";
    if(orgId == "ecp"){
        tenentId = applicationConstants.ECP_BASE_DMN_TENENT_ID;
    }
    else {
        // TenentId is combination of orgId + 'umcasemgmt' + orgId + 'dmngrp'. ex - uhcumcasemgmtuhcdmngrp
        tenentId = orgId +  applicationConstants.UM_CASE_MGMT + orgId + applicationConstants.DMN_GRP
    }

    const headerParams  = { 'headers' : {
        'Content-Type': 'application/json',
        'x-bpm-cli-org-id': orgId,
        'x-bpm-func-role': bpmFunctionalRole,
        'x-bpm-tenant-id': tenentId,
        'x-bpm-external-ref-id': 'case_mgmt_rule_evaluation',
        'x-bpm-source': 'case_wf_mgmt_ui',
        'Authorization' : httpRequest.headers['authorization']
    }};
    await axios.post(configHttpUrl, body, headerParams).then(function (response) {
            configResponse = response.data;
        })
        .catch(function (error) {
            console.log(error);
        });
    //console.log("rule resp ++++ "+ JSON.stringify(configResponse));
    return configResponse;

}

 async function getFunctionalRole(ecptoken: any): Promise<string> {
        const ecpClaim: EcpClaim = await AuthorizationService.getEcpClaim(ecptoken, configService.get<string>('JWK_URI'), configService.get<string>('ISSUER'));
        // Status of the decoded token will tell us if token is valid
        const authenticated: boolean = ecpClaim[EcpTokenFeilds.STATUS] === 'success' ? true : false;
        // Check for role only if token is valid
        if (authenticated) {
            const orgs: any[] = ecpClaim.message[EcpTokenFeilds.ECP_CLI_ORGS] || [];
            //console.log(":::: Bpm functional role: " + orgs[0][EcpTokenFeilds.FUNC_ROLES][0][EcpTokenFeilds.ROLE_NAME]);
            return orgs[0][EcpTokenFeilds.FUNC_ROLES][0][EcpTokenFeilds.ROLE_NAME];

        } else {
            //console.log(":::: Failed to derive Bpm functional role from token");
            return ""
        }
    }

export  { caseValidation, getErrorResponse };
