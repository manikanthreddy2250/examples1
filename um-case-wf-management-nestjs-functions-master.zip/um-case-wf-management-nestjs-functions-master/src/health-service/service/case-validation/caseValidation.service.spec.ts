import { Test, TestingModule } from '@nestjs/testing';
import { ConfigService} from "@nestjs/config";
import {HttpMethod, HttpRequest} from "@azure/functions";
import {GraphQLClient} from "graphql-request/dist";
import {RequestDocument} from "graphql-request/dist/types";
import {Observable, of} from "rxjs";
import {CaseValidationService} from "./caseValidation.service";
import {CaseValidationRequest} from "../../model/CaseValidationRequest";
import {AuthorizationService} from "@ecp/func-tk/dist";
import {HealthServiceClient} from "../../shared/graphql/healthservicedomain/healthServiceClient";
import {DocumentServiceClient} from "../../shared/graphql/documentservicedomain/documentServiceClient";
import axios from "axios";
import {LoggerModule} from "nestjs-pino";
import { AxiosResponse } from 'axios';
import {DuplicateCheckServiceClient} from './ValidationService';
class MockGraphQLClient extends GraphQLClient{
    request(document: RequestDocument, variables?: any, requestHeaders?: any): Promise<any>{
        return of({
                    "hsc": [
                        {
                          "hsc_id": 12908,
                          "srvc_set_ref_id" : 3737,
                            "hsc_provs": [
                                {
                                    "hsc_prov_id": 5261,
                                    "hsc_prov_roles": [
                                        {
                                            "prov_role_ref_id": 3761
                                        }
                                    ]
                                },
                                {
                                    "hsc_prov_id": 5262,
                                    "hsc_prov_roles": [
                                        {
                                            "prov_role_ref_id": 3759
                                        }
                                    ]
                                }
                            ],
                          "mbr_cov_dtl": {
                            "indv_id": 503926748,
                            "pol_nbr": "0128855",
                            "cov_eff_dt": "2013-01-01",
                            "cov_end_dt": "9999-12-31",
                            "mbr_cov_id": 96963692,
                            "productCode": 214,
                            "indv_key_val": "16440436900",
                            "productCatgyTpe": null,
                            "coverageTypeDesc": "Medical",
                            "indv_key_typ_ref_id": 2757,
                            "claim_platform_ref_Id": 363
                          },
                          "hsc_facls": [
                            {
                              "actul_admis_dttm": null,
                             "actul_dschrg_dttm": null,
                              "expt_admis_dt": "2021-01-12",
                              "expt_dschrg_dt": "2021-01-20"
                            }
                          ],
                          "srvc_set_ref_cd": {
                               "ref_desc": "Inpatient"
                           }
                        }
                     ],
                    "hsc_clin_guid": [
                      {
                        "clin_rev_sys_rec_id": "d855853d-25ef-499d-be64-110fbb20b6bd"
                      },
                      {
                        "clin_rev_sys_rec_id": "1ce1d5e4-e816-42ec-b759-af6665ae07ce"
                      },
                      {
                        "clin_rev_sys_rec_id": "d9b1d0ba-cd5a-40de-8946-b20845f8f693"
                      },
                      {
                        "clin_rev_sys_rec_id": "7dd6590e-8a5c-4b14-a993-76c43bd11f1a"
                      },
                      {
                        "clin_rev_sys_rec_id": "e5007b17-9fc1-43a0-b919-95e348fff25a"
                      },
                   ]
        }).toPromise();
    }
}

class MockDuplicateCheckServiceClient {
    public getGraphqlClient(httpRequest: HttpRequest): GraphQLClient {
                return new MockGraphQLClient('testurl');
            }
}

class MockHealthServiceClient {
    public getGraphqlClient(httpRequest: HttpRequest): GraphQLClient {
        return new MockGraphQLClient('testurl');
    }
}
class MockDGraphQLClient extends GraphQLClient{
     request(document: RequestDocument, variables?: any, requestHeaders?: any): Promise<any>{
        return of({
                      "doc_sbj": [
                        {
                          "doc_id": 6022
                        },
                        {
                          "doc_id": 5721
                        }
                      ]
        }).toPromise();
     }
}
class MockAxios {
    post(url:any, body:any, header:any): Promise<any>{
        return of({
        "data" :[
                    {
                        "LosCheck":"actualDischargeDate",
                        "requiredDateChecks":"admitdate",
                        "requiredProviders":3761
                    }
                ]
        }).toPromise();
    }
}



class MockDocumentServiceClient {
    public getGraphqlClient(httpRequest: HttpRequest): GraphQLClient {
        return new MockDGraphQLClient('testurl');
    }
}
describe('CaseValidationService', () => {
    let service: CaseValidationService;
    let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid', headers: {authorization: 'test token', 'x-hasura-role': 'testrole', 'x-bpm-cli-org-id': 'ecp'}, query: {'test':'test'}, params: {'test':'test'}};
    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            imports: [LoggerModule.forRoot()],
            providers: [CaseValidationService,AuthorizationService,ConfigService,{provide: HealthServiceClient,useClass: MockHealthServiceClient},{provide: DocumentServiceClient,useClass: MockDocumentServiceClient}, {provide: DuplicateCheckServiceClient,useClass: MockDuplicateCheckServiceClient},{provide: axios,useClass: MockAxios}],
        }).compile();

        service = module.get<CaseValidationService>(CaseValidationService);
    });

    it('should be defined', () => {
        expect(service).toBeDefined();
    });

    jest.mock('axios');
    it('should call delete Procedure', async() => {
        const configResponse = {
            "data" :[
                {
                    "LosCheck":"actualDischargeDate",
                    "requiredDateChecks":"admitdate",
                    "requiredProviders":3761
                }
            ]
        };
        const readmissionconfigResponse:AxiosResponse = {
            "data" :[
                {
                    "id": "case_wf_mgmt_ui_1.0.0_readmission_criteria_config_2021-07-02",
                    "createDateTime": "2021-07-06T15:56:49.576+00:00",
                    "creatUserId": null,
                    "changeDateTime": "2021-07-06T15:56:49.576+00:00",
                    "changeUserId": null,
                    "updateVersionNumber": "0",
                    "createSystemReferenceId": null,
                    "changeSystemReferenceId": null,
                    "dataSecureRuleList": null,
                    "dataGltyIssList": null,
                    "application": "case_wf_mgmt_ui",
                    "version": "1.0.0",
                    "org": null,
                    "role": null,
                    "value": "{\"days\":\"30\"}",
                    "startDate": "2021-07-02T00:00:00.000+00:00",
                    "endDate": null,
                    "inactivityIndicator": "0"
                }
            ],
            status: 200, statusText: 'OK', headers: {}, config: {}
        };
        const caseValidationRequest: CaseValidationRequest = {
            "hsc_id": "12908",
            "validateEligibility": false,
            "validateProvider": true,
            "validateContract": true,
            "validateSOS": true,
            "validateLOCReview": true,
            "validateLOSReview": true,
            "validateDuplicateCase": true,
            "validateFacilityOutOfNetwork": true,
            "validateDxCode": true,
            "validateClinicalDocument": true,
            "validateReadmission":true
        };
        jest.spyOn(axios, 'post').mockImplementationOnce(async() => of(configResponse));
        jest.spyOn(axios, 'get').mockImplementationOnce(async() => Promise.resolve(readmissionconfigResponse));
        await service.caseValidation(caseValidationRequest, httpRequest).then((res) => {
            expect(res.hsc_id).toEqual("12908");
        });
    });
});
