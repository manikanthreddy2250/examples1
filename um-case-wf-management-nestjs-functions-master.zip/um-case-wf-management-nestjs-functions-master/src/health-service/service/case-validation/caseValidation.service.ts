import { AzureFunction, Context, HttpRequest } from "@azure/functions"
import {CaseValidationRequest} from "../../model/CaseValidationRequest";
import {errorMesgs} from "../../shared/constants/ErrorMesg";
import {CaseValidationResponse} from "../../model/CaseValidationResponse";
import {HttpService, Injectable} from '@nestjs/common';
import {applicationConstants} from "../../shared/constants/applicationConstants";
import {HealthServiceClient} from "../../shared/graphql/healthservicedomain/healthServiceClient";
import {GraphQLClient} from "graphql-request/dist";
import {res} from "pino-std-serializers";
import {DocumentServiceClient} from "../../shared/graphql/documentservicedomain/documentServiceClient";
import {Logger} from "nestjs-pino";
import {caseValidation, DuplicateCheckServiceClient} from "./ValidationService";
@Injectable()
export class CaseValidationService {

constructor(private readonly healthServiceClient: HealthServiceClient, private readonly documentServiceClient: DocumentServiceClient, private readonly duplicateCheckServiceClient: DuplicateCheckServiceClient, private readonly logger: Logger) {}
    async caseValidation(caseValidationRequest: CaseValidationRequest, httpRequest: HttpRequest): Promise<CaseValidationResponse> {
        const hscId = caseValidationRequest.hsc_id;
        const hscGraphqlClient: GraphQLClient = this.healthServiceClient.getGraphqlClient(httpRequest);
        const docGraphqlClient: GraphQLClient = this.documentServiceClient.getGraphqlClient();
        const duplicateCheckClient: GraphQLClient = this.duplicateCheckServiceClient.getGraphqlClient(httpRequest);
        this.logger.log(`caseValidation - auth token: ${httpRequest.headers.authorization}`);
        let response: CaseValidationResponse;
        try {
            if (caseValidationRequest.hsc_id) {
                try {
                    response = await caseValidation(caseValidationRequest, httpRequest, hscGraphqlClient,docGraphqlClient, duplicateCheckClient);
                    return response;
                } catch (e) {
                    this.logger.error("Error while calling CaseWF CaseValidationService caseValidation (caseValidationRequest: " + caseValidationRequest + ", httpRequest: " + httpRequest + ") " + e);        
                }
            }
        } catch (err) {
            this.logger.error("Error while calling CaseWF CaseValidationService caseValidation (caseValidationRequest: " + caseValidationRequest + ", httpRequest: " + httpRequest + ") " + err);        
        }
    }
}
