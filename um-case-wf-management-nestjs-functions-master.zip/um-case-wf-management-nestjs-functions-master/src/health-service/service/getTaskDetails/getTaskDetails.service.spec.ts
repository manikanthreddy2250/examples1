import { Test, TestingModule } from '@nestjs/testing';

import {ConfigService} from "@nestjs/config";
import {GraphQLClient} from "graphql-request/dist";
import {RequestDocument} from "graphql-request/dist/types";
import {of} from "rxjs";
import {HttpRequest} from "@azure/functions";
import {GetTaskDetailsRequest} from "../../models/getTaskDetailsRequest";
import {HealthServiceClient} from "../../shared/graphql/healthservicedomain/healthServiceClient";
import {TaskListRequest} from "../../models/TaskListRequest";
import {ReferenceClient} from "../../shared/graphql/referenceDomain/referenceClient";
import {GetTaskDetailsService} from "./getTaskDetails.service";
import {TaskMetadataService} from "../../../configuration/service/task-metadata/task-metadata.service";
import {LoggerModule} from "nestjs-pino";
import {MemberServiceClient} from "../../shared/graphql/memberdomain/memberServiceClient";
import {GetActivitiesRequest} from "../../models/get-activities.request";

class MockGraphQLClient extends GraphQLClient{
    request(document: RequestDocument, variables?: any, requestHeaders?: any): Promise<any>{
        if(variables.hscId){
            return of({
                "hsr_asgn": [{
                    "hsc_id": 12845,
                    "hsr_asgn_id": 1,
                    "asgn_desc": {
                        "wfName": "inpatientBaseWF"
                    },
                    "asgn_to_user_id": "skonjeti",
                    "asgn_typ_ref_id": 72138,
                    "tsk_nm_ref_cd": null,
                    "asgn_sts_ref_id": null,
                    "tsk_sts_ref_cd": null,
                    "asgn_catgy_ref_id": 72060,
                    "tsk_catgy_ref_cd": {
                        "ref_dspl": "Eligibility",
                        "ref_desc": "eligibility",
                        "ref_id": 72060
                    },
                    "asgn_to_wrk_que_ref_id": null,
                    "asgn_to_wrk_que_ref_cd": null
                },
                    {
                        "hsr_asgn_id": 536,
                        "asgn_to_user_id": "null",
                        "chg_user_id": null,
                        "chg_dttm": "2021-06-29T17:57:05.137",
                        "asgn_desc": {
                            "wfName": "inpatientBaseWF"
                        },
                        "src_rec_guid": "69d0c184-d903-11eb-af00-5617995e362a",
                        "asgn_typ_ref_id": 72135,
                        "asgn_typ_ref_cd": {
                            "ref_dspl": "Provider"
                        },
                        "asgn_sts_ref_id": 72114,
                        "asgn_sts_ref_cd": {
                            "ref_dspl": "Complete"
                        }
                    }],
                "hsr_actv": [
                    { "hsr_actv_sbjs": [
                            { hsr_sbj_rec_id: 2544, hsr_sbj_typ_ref_id: 74005 },
                            { hsr_sbj_rec_id: 73223, hsr_sbj_typ_ref_id: 25863 }
                        ] },
                    { "hsr_actv_sbjs": [
                            { hsr_sbj_rec_id: 2544, hsr_sbj_typ_ref_id: 74005 },
                            { hsr_sbj_rec_id: 73224, hsr_sbj_typ_ref_id: 25863 }
                        ] },
                    { "hsr_actv_sbjs": [
                            { hsr_sbj_rec_id: 2544, hsr_sbj_typ_ref_id: 74005 },
                            { hsr_sbj_rec_id: 73225, hsr_sbj_typ_ref_id: 25863 }
                        ] }
                ]
            }).toPromise();
        }
        else if(variables.assignUserId){
            return of({"hsr_asgn": [
                    {
                        "hsc_id": 747,
                        "hsr_asgn_id": 64,
                        "creat_dttm": "2021-06-29T12:27:11.435",
                        "asgn_to_user_id": "ddudaka",
                        "src_rec_guid": "5406fdfe-d8d5-11eb-b994-966362962ddc",
                        "asgn_typ_ref_id": 73432,
                        "asgn_typ_ref_cd": {
                            "ref_dspl": "Request Clinical"
                        },
                        "asgn_catgy_ref_id": 72093,
                        "asgn_catgy_ref_cd": {
                            "ref_dspl": "Automated Clinical Case Validations"
                        },
                        "asgn_sts_ref_id": 72113,
                        "asgn_sts_ref_cd": {
                            "ref_dspl": "Active"
                        },
                        "asgn_to_wrk_que_ref_id": null,
                        "asgn_to_wrk_que_ref_cd": null,
                        "hsc": {
                            "indv_id": 503926748,
                            "individual": [
                                {
                                    "fst_nm": "Matt",
                                    "lst_nm": "Meyer"
                                }
                            ],
                            "hsc_diags": [
                                {
                                    "diag_cd": "L02.52",
                                    "pri_ind": 0
                                },
                                {
                                    "diag_cd": "L02.51",
                                    "pri_ind": 1
                                }
                            ],
                            "hsc_provs": [
                                {
                                    "hsc_prov_id": 948,
                                    "prov_key_val": "1336603265",
                                    "prov_loc_affil_dtl": {
                                        "providerDetails": {
                                            "bus_nm": null,
                                            "fst_nm": "CINTIA",
                                            "lst_nm": "ROGUIN",
                                            "prov_id": 10624501,
                                            "prov_adr": {
                                                "cty_nm": "Brooklyn",
                                                "st_ref_id": 1101,
                                                "zip_cd_txt": "112183585",
                                                "adr_ln_1_txt": "1430 41st St",
                                                "adr_ln_2_txt": null
                                            },
                                            "prov_keys": [
                                                {
                                                    "prov_key_val": "1255539573",
                                                    "prov_key_typ_ref_id": 2782
                                                }
                                            ],
                                            "prov_adr_id": 30501956,
                                            "prov_catgy_ref_id": 16309
                                        }
                                    },
                                    "hsc_prov_roles": [
                                        {
                                            "prov_role_ref_id": 3758,
                                            "hsc_prov_id": 948,
                                            "prov_role_ref_cd": {
                                                "ref_desc": "Admitting Services"
                                            }
                                        },
                                        {
                                            "prov_role_ref_id": 3759,
                                            "hsc_prov_id": 948,
                                            "prov_role_ref_cd": {
                                                "ref_desc": "Attending Physician"
                                            }
                                        },
                                        {
                                            "prov_role_ref_id": 3765,
                                            "hsc_prov_id": 948,
                                            "prov_role_ref_cd": {
                                                "ref_desc": "Servicing"
                                            }
                                        }
                                    ]
                                },
                                {
                                    "hsc_prov_id": 947,
                                    "prov_key_val": "1609398916",
                                    "prov_loc_affil_dtl": {
                                        "providerDetails": {
                                            "bus_nm": "DIVERSICARE GOOD SAMARITAN",
                                            "fst_nm": null,
                                            "lst_nm": null,
                                            "prov_id": 13379944,
                                            "prov_adr": {
                                                "cty_nm": "Saint Petersburg",
                                                "st_ref_id": 1072,
                                                "zip_cd_txt": "337141320",
                                                "adr_ln_1_txt": "3127 57th Ave N",
                                                "adr_ln_2_txt": null
                                            },
                                            "prov_keys": [
                                                {
                                                    "prov_key_val": "256556261",
                                                    "prov_key_typ_ref_id": 16333
                                                }
                                            ],
                                            "prov_adr_id": 41179871,
                                            "prov_catgy_ref_id": 16310
                                        }
                                    },
                                    "hsc_prov_roles": [
                                        {
                                            "prov_role_ref_id": 3761,
                                            "hsc_prov_id": 947,
                                            "prov_role_ref_cd": {
                                                "ref_desc": "Facility"
                                            }
                                        }
                                    ]
                                }
                            ],
                            "hsc_facls": [
                                {
                                    "actul_admis_dttm": "2021-06-09T00:00:00",
                                    "tat_due_dttm": null
                                }
                            ]
                        }
                    },
                    {
                        "hsc_id": 759,
                        "hsr_asgn_id": 70,
                        "creat_dttm": "2021-06-29T14:42:53.131",
                        "asgn_to_user_id": "ddudaka",
                        "src_rec_guid": "48d9af8f-d8e8-11eb-b994-966362962ddc",
                        "asgn_typ_ref_id": 73432,
                        "asgn_typ_ref_cd": {
                            "ref_dspl": "Request Clinical"
                        },
                        "asgn_catgy_ref_id": 72093,
                        "asgn_catgy_ref_cd": {
                            "ref_dspl": "Automated Clinical Case Validations"
                        },
                        "asgn_sts_ref_id": 72113,
                        "asgn_sts_ref_cd": {
                            "ref_dspl": "Active"
                        },
                        "asgn_to_wrk_que_ref_id": null,
                        "asgn_to_wrk_que_ref_cd": null,
                        "hsc": {
                            "indv_id": 503926748,
                            "individual": [
                                {
                                    "fst_nm": "Matt",
                                    "lst_nm": "Meyer"
                                }
                            ],
                            "hsc_diags": [
                                {
                                    "diag_cd": "L02.52",
                                    "pri_ind": 0
                                },
                                {
                                    "diag_cd": "L02.51",
                                    "pri_ind": 1
                                }
                            ],
                            "hsc_provs": [
                                {
                                    "hsc_prov_id": 968,
                                    "prov_key_val": "1336603265",
                                    "prov_loc_affil_dtl": {
                                        "providerDetails": {
                                            "bus_nm": null,
                                            "fst_nm": "CINTIA",
                                            "lst_nm": "ROGUIN",
                                            "prov_id": 10624501,
                                            "prov_adr": {
                                                "cty_nm": "Brooklyn",
                                                "st_ref_id": 1101,
                                                "zip_cd_txt": "112183585",
                                                "adr_ln_1_txt": "1430 41st St",
                                                "adr_ln_2_txt": null
                                            },
                                            "prov_keys": [
                                                {
                                                    "prov_key_val": "1255539573",
                                                    "prov_key_typ_ref_id": 2782
                                                }
                                            ],
                                            "prov_adr_id": 30501956,
                                            "prov_catgy_ref_id": 16309
                                        }
                                    },
                                    "hsc_prov_roles": [
                                        {
                                            "prov_role_ref_id": 3758,
                                            "hsc_prov_id": 968,
                                            "prov_role_ref_cd": {
                                                "ref_desc": "Admitting Services"
                                            }
                                        },
                                        {
                                            "prov_role_ref_id": 3759,
                                            "hsc_prov_id": 968,
                                            "prov_role_ref_cd": {
                                                "ref_desc": "Attending Physician"
                                            }
                                        },
                                        {
                                            "prov_role_ref_id": 3765,
                                            "hsc_prov_id": 968,
                                            "prov_role_ref_cd": {
                                                "ref_desc": "Servicing"
                                            }
                                        }
                                    ]
                                },
                                {
                                    "hsc_prov_id": 967,
                                    "prov_key_val": "1609398916",
                                    "prov_loc_affil_dtl": {
                                        "providerDetails": {
                                            "bus_nm": "DIVERSICARE GOOD SAMARITAN",
                                            "fst_nm": null,
                                            "lst_nm": null,
                                            "prov_id": 13379944,
                                            "prov_adr": {
                                                "cty_nm": "Saint Petersburg",
                                                "st_ref_id": 1072,
                                                "zip_cd_txt": "337141320",
                                                "adr_ln_1_txt": "3127 57th Ave N",
                                                "adr_ln_2_txt": null
                                            },
                                            "prov_keys": [
                                                {
                                                    "prov_key_val": "256556261",
                                                    "prov_key_typ_ref_id": 16333
                                                }
                                            ],
                                            "prov_adr_id": 41179871,
                                            "prov_catgy_ref_id": 16310
                                        }
                                    },
                                    "hsc_prov_roles": [
                                        {
                                            "prov_role_ref_id": 3761,
                                            "hsc_prov_id": 967,
                                            "prov_role_ref_cd": {
                                                "ref_desc": "Facility"
                                            }
                                        }
                                    ]
                                }
                            ],
                            "hsc_facls": [
                                {
                                    "actul_admis_dttm": "2021-06-09T00:00:00",
                                    "tat_due_dttm": null
                                }
                            ]
                        }
                    }
                ]}).toPromise();
        }

    }
}

class MockMemGraphQLClient extends GraphQLClient{
    request(document: RequestDocument, variables?: any, requestHeaders?: any): Promise<any>{
        return of({
            mbr_cmnct: [
                {
                    mbr_cmnct_id: 73223,
                    creat_dttm: '2021-07-23T18:31:35.756',
                    creat_user_id: 'SYSTEM',
                    mbr_cmnct_chnl_ref_id: 17271,
                    mbr_cmnct_dir_ref_id: 20087,
                    mbr_cmnct_typ_ref_id: 25863,
                    mbr_cmnct_sts_ref_id: 20066,
                    mbr_cmnct_catgy_ref_id: 25050
                },
                {
                    mbr_cmnct_id: 73224,
                    creat_dttm: '2021-07-23T18:42:16.374',
                    creat_user_id: 'SYSTEM',
                    mbr_cmnct_chnl_ref_id: 17272,
                    mbr_cmnct_dir_ref_id: 20087,
                    mbr_cmnct_typ_ref_id: 25863,
                    mbr_cmnct_sts_ref_id: 20066,
                    mbr_cmnct_catgy_ref_id: 25050
                },
                {
                    mbr_cmnct_id: 73225,
                    creat_dttm: '2021-07-23T18:42:36.619',
                    creat_user_id: 'SYSTEM',
                    mbr_cmnct_chnl_ref_id: 74006,
                    mbr_cmnct_dir_ref_id: 20087,
                    mbr_cmnct_typ_ref_id: 25863,
                    mbr_cmnct_sts_ref_id: 20066,
                    mbr_cmnct_catgy_ref_id: 25050
                }
            ]
        }).toPromise();
    }
}

class MockRefGraphQLClient extends GraphQLClient{
    request(document: RequestDocument, variables?: any, requestHeaders?: any): Promise<any>{
        return of( {
            ref: [
                { ref_id: 17271, ref_cd: 'FAX', ref_dspl: 'Fax' },
                { ref_id: 17272, ref_cd: 'EMAIL', ref_dspl: 'Email' },
                { ref_id: 20066, ref_cd: null, ref_dspl: 'Sent' },
                { ref_id: 20087, ref_cd: null, ref_dspl: 'Outbound' },
                { ref_id: 25050, ref_cd: null, ref_dspl: 'Utilization Mgmt' },
                {
                    ref_id: 25863,
                    ref_cd: null,
                    ref_dspl: 'Member Communication ID'
                },
                { ref_id: 74006, ref_cd: null, ref_dspl: 'Letter' }
            ]
        }).toPromise();
    }
}


class MockConfigGraphQLClient extends GraphQLClient{
    request(document: RequestDocument, variables?: any, requestHeaders?: any): Promise<any>{
        return of({
            "data": {
                "getWorkflowTaskMetadata": {
                    "taskMetadata": [
                        {
                            "taskCategoryRefId": "73370",
                            "isManual": "false",
                            "taskCategoryName": "Clinical Review",
                            "tasks": [
                                {
                                    "taskName": "Admission Review",
                                    "isManual": "true",
                                    "taskDescription": "",
                                    "taskNameRefId": "72138"
                                },
                                {
                                    "taskName": "Concurrent Review",
                                    "isManual": "true",
                                    "taskDescription": "",
                                    "taskNameRefId": "72139"
                                },
                                {
                                    "taskName": "Escalate Review",
                                    "isManual": "false",
                                    "taskDescription": "",
                                    "taskNameRefId": "73287"
                                }
                            ]
                        },
                        {
                            "taskCategoryRefId": "72093",
                            "isManual": "false",
                            "taskCategoryName": "Automated Clinical Case Validations",
                            "tasks": [
                                {
                                    "taskName": "Eligibility",
                                    "isManual": "false",
                                    "taskDescription": "",
                                    "taskNameRefId": "72134"
                                },
                                {
                                    "taskName": "Provider",
                                    "isManual": "false",
                                    "taskDescription": "",
                                    "taskNameRefId": "72135"
                                },
                                {
                                    "taskName": "Request Clinical",
                                    "isManual": "false",
                                    "taskDescription": "",
                                    "taskNameRefId": "73432"
                                }
                            ]
                        }
                    ]
                }
            }
        }).toPromise();
    }
}

class MockHealthServiceClient {
    public getGraphqlClient(): GraphQLClient {
        return new MockGraphQLClient('testurl');
    }
}

class MockMemberServiceClient {
    public getGraphqlClient(): GraphQLClient {
        return new MockMemGraphQLClient('testurl');
    }
}

class MockRefServiceClient {
    public getGraphqlClient(): GraphQLClient {
        return new MockRefGraphQLClient('testurl');
    }
}

class MockConfigClient {
    public getGraphqlClient(): GraphQLClient {
        return new MockConfigGraphQLClient('testurl');
    }
}



describe('getTaskDetails', () => {
  let service: GetTaskDetailsService;
  let service1: TaskMetadataService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      imports: [LoggerModule.forRoot()],
      providers: [GetTaskDetailsService, {provide: HealthServiceClient, useClass: MockHealthServiceClient},
          {provide: MemberServiceClient, useClass: MockMemberServiceClient},
          {provide: ReferenceClient, useClass: MockRefServiceClient},
          {provide: ConfigService, useClass: MockConfigClient}, ConfigService,TaskMetadataService],
    }).compile();

    service = module.get<GetTaskDetailsService>(GetTaskDetailsService);
    service1=  module.get<TaskMetadataService>(TaskMetadataService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

    it('should call get TaskDetails', () => {
        let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
        const getTaskDetailsRequest: GetTaskDetailsRequest = {
            "hsr_asgn": {
                "hsc_id": 12845,
                "asgn_typ_ref_id":72138,
                "workFlow_cnfg_key": "inpatientBaseWF"
            }
        };
        service.getTaskDetails(getTaskDetailsRequest, httpRequest).then((res) => {
            expect(res.task.hsc_id).toEqual(12845);
            expect(res.task.tsk_nm_ref_id).toEqual(72138);

        });
        service.getTaskDetails(getTaskDetailsRequest, httpRequest).then((res) => {
            expect(res.task.hsc_id).toEqual(12845);
            expect(res.task.tsk_nm_ref_id).toEqual(72138);
        });
    });

    it('should call get TaskDetails with config key', () => {
        let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
        const getTaskDetailsRequest: GetTaskDetailsRequest = {
            "hsr_asgn": {
                "hsc_id": 12845,
                "asgn_typ_ref_id":72138,
                "workFlow_cnfg_key": "inpatientBaseWF"
            }
        };
        service.getTaskDetails(getTaskDetailsRequest, httpRequest).then((res) => {
            expect(res.task.hsc_id).toEqual(12845);
            expect(res.task.tsk_nm_ref_id).toEqual(72138);
        });
    });


    it('should call get TaskList', () => {
        let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
        const taskListRequest: TaskListRequest = {
            "hsc_id": 12845,
            "asgn_to_user_id": null

        };

        const taskListRequestUser: TaskListRequest = {
            "hsc_id": null,
            "asgn_to_user_id": "skonjeti"

        };

        const noTaskListRequest: TaskListRequest = {
            "hsc_id": null,
            "asgn_to_user_id": null

        };

        const hscDiag =  {
            "pri_ind": 1,
             "diag_cd": "S20"

        };

        service.getTaskListByHscId(taskListRequest, httpRequest).then((res) => {
            expect(res.hsr_asgn[0].hsc_id).toEqual(12845);
        });

        service.getTaskListByHscId(taskListRequestUser, httpRequest).then((res) => {
            expect(res.hsr_asgn[0].asgn_to_user_id).toEqual("skonjeti");
        });

        service.getTaskListByHscId(noTaskListRequest, httpRequest).then((res) => {
            expect(res).toEqual(null);
        });
    });

    it('should call get task details checklist items', () => {
        let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
        const getTaskDetailsRequest: GetTaskDetailsRequest = {
            "hsr_asgn": {
                "hsc_id": 12845,
                "asgn_typ_ref_id":72138,
                "workFlow_cnfg_key": "inpatientBaseWF"
            }
        };
        const taskMetadataList= {
            "taskMetadata": [
                {
                    "taskCategoryRefId": "73370",
                    "isManual": "false",
                    "taskCategoryName": "Clinical Review",
                    "tasks": [
                        {
                            "taskName": "Admission Review",
                            "isManual": "true",
                            "taskDescription": "",
                            "taskNameRefId": "72138"
                        },
                        {
                            "taskName": "Concurrent Review",
                            "isManual": "true",
                            "taskDescription": "",
                            "taskNameRefId": "72139"
                        },
                        {
                            "taskName": "Escalate Review",
                            "isManual": "false",
                            "taskDescription": "",
                            "taskNameRefId": "73287"
                        }
                    ]
                },
                {
                    "taskCategoryRefId": "72093",
                    "isManual": "false",
                    "taskCategoryName": "Automated Clinical Case Validations",
                    "tasks": [
                        {
                            "taskName": "Eligibility",
                            "isManual": "false",
                            "taskDescription": "",
                            "taskNameRefId": "72134"
                        },
                        {
                            "taskName": "Provider",
                            "isManual": "false",
                            "taskDescription": "",
                            "taskNameRefId": "72135"
                        },
                        {
                            "taskName": "Request Clinical",
                            "isManual": "false",
                            "taskDescription": "",
                            "taskNameRefId": "73432"
                        }
                    ]
                }
            ]
            };
        const configResponse = {
            data : [
                {
                    "id": "case_wf_mgmt_ui_1.0.0_ecp_inpatientBaseWF_2021-02-26",
                    "createDateTime": "2021-03-01T15:48:09.833+00:00",
                    "creatUserId": null,
                    "changeDateTime": "2021-03-01T15:48:09.833+00:00",
                    "changeUserId": null,
                    "updateVersionNumber": "0",
                    "createSystemReferenceId": null,
                    "changeSystemReferenceId": null,
                    "dataSecureRuleList": null,
                    "dataGltyIssList": null,
                    "application": "case_wf_mgmt_ui",
                    "version": "1.0.0",
                    "org": "ecp",
                    "role": null,
                    "Config": "inpatientBaseWF",
                    "value": "{ \"taskMetaDataCategoryRefIds\": [ 72142 ], \"taskMetaDataConfigKey\": \"ipBaseWF\" }",
                    "startDate": "2021-02-26T00:00:00.000+00:00",
                    "endDate": null,
                    "inactivityIndicator": "0"
                }
            ]
        };
        spyOn<any>(service1, 'getSysConfigRefIds').and.returnValue(configResponse);
        spyOn<any>(service1, 'getSysConfigDetailsByWF').and.returnValue(taskMetadataList);
        expect(service1.getSysConfigDetailsByWF(configResponse,httpRequest)).toBeTruthy();
        service.getTaskDetails(getTaskDetailsRequest, httpRequest).then((res) => {
            expect(res.task.tsk_nm_ref_id).toEqual(72064);
        });
    });

    it('should call get Activities', () => {
        const httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',
            headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
        const getActivitiesRequest: GetActivitiesRequest = {
            "hsc_id": 12845
        };
        service.getActivitiesByHscId(getActivitiesRequest, httpRequest).then((res) => {
            expect(res.communication_activities.length).toEqual(3);
        });
    });
});
