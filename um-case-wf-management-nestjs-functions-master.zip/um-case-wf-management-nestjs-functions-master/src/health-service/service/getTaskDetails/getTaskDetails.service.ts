import {Injectable} from '@nestjs/common';
import {GetTaskDetailsRequest} from "../../models/getTaskDetailsRequest";
import {GetTaskDetailsResponse} from "../../models/getTaskDetailsResponse";
import {HttpRequest} from "@azure/functions";
import {GraphQLClient} from "graphql-request/dist";
import {
    getHscActivitiesByHscId,
    getTaskDetailsQuery,
    getTaskListQuery,
    getTaskListQueryByUserName
} from "../../shared/graphql/healthservicedomain/healthServiceQuery";
import {HealthServiceClient} from "../../shared/graphql/healthservicedomain/healthServiceClient";
import {TaskListResponse} from "../../models/TaskListResponse";
import {TaskListRequest} from "../../models/TaskListRequest";
import {diagCdRefQuery, getRefDataForRefIds} from "../../shared/graphql/referenceDomain/referenceServiceQuery";
import {ReferenceClient} from "../../shared/graphql/referenceDomain/referenceClient";
import {caseDataConstants} from "../../../configuration/constants/caseDataConstants";
import {TaskMetadataService} from "../../../configuration/service/task-metadata/task-metadata.service";
import {Logger} from "nestjs-pino";
import { GetActivitiesRequest } from '../../models/get-activities.request';
import { GetActivitiesResponse } from '../../models/get-activities.response';
import {MemberServiceClient} from "../../shared/graphql/memberdomain/memberServiceClient";
import {getMemberCommunications} from "../../shared/graphql/memberdomain/memberServiceQuery";
import {CommunicationActivity} from "../../models/communication-activity";

@Injectable()
export class GetTaskDetailsService {
    static HTTPREQUESTLABEL = ", httpRequest: ";

    constructor(private readonly healthServiceClient: HealthServiceClient, private readonly referenceClient: ReferenceClient,
                private readonly taskMetadataService: TaskMetadataService, private readonly logger: Logger,
                private readonly memberServiceClient: MemberServiceClient) {}

   

    async getTaskListByHscId(taskListRequest : TaskListRequest,  httpRequest: HttpRequest): Promise<TaskListResponse> {
        try {
            const hscGraphqlClient: GraphQLClient = this.healthServiceClient.getGraphqlClient(httpRequest);
            const hscId = taskListRequest.hsc_id;
            const assignUserId = taskListRequest.asgn_to_user_id;
            let result;
            if(taskListRequest.asgn_to_user_id) {
                result = await hscGraphqlClient.request(getTaskListQueryByUserName, {assignUserId});
            }else if(taskListRequest.hsc_id){
                result = await hscGraphqlClient.request(getTaskListQuery, {hscId});
            }
            const response: TaskListResponse = {
                "hsr_asgn": result.hsr_asgn
            };
             this.calculateTatHours(response);
            for(var i = 0; i < response.hsr_asgn.length; i++) {
                response.hsr_asgn[i].hsc.individual = response.hsr_asgn[i].hsc.individual[0];
                response.hsr_asgn[i].hsc.hsc_diags  = response.hsr_asgn[i].hsc.hsc_diags.filter((item)=> item.pri_ind === 1);
                const diag_cds = response.hsr_asgn[i].hsc.hsc_diags[0].diag_cd;
                var hscDiagRefDataList = await this.referenceClient.getGraphqlClient(httpRequest).request(diagCdRefQuery, {diag_cds});
                response.hsr_asgn[i].hsc.hsc_diags.forEach((item) => {
                    if( item.pri_ind === 1) {
                        const diagRecord = hscDiagRefDataList.icd10.find(element => element.diag_cd === item.diag_cd);
                        item.diag_desc = diagRecord ? diagRecord.cd_desc: null;
                    }
                });
                const facilityProviders = this.getFacilityProvider(response.hsr_asgn[i].hsc.hsc_provs);
                response.hsr_asgn[i].hsc.hsc_provs = facilityProviders;
            }
            return response;
        } catch (e) {
            this.logger.error("Error while calling CaseWF GetTaskDetailsService getTaskListByHscId (taskListRequest: " + taskListRequest + GetTaskDetailsService.HTTPREQUESTLABEL + httpRequest + ") " + e);
        }
    }

    private getFacilityProvider(providers) {
        return providers.filter(provider => {
            if(provider.hsc_prov_roles) {
                const hasFacilityRole = provider.hsc_prov_roles.find(
                    role => role.prov_role_ref_id == caseDataConstants.PROVIDER_ROLE_REF_ID_FACILITY);
                if(hasFacilityRole) {
                    provider.facilityProviderName =
                        provider.prov_loc_affil_dtl.providerDetails.bus_nm;
                }
                delete provider.prov_loc_affil_dtl;
                delete provider.hsc_prov_roles;
                delete provider.prov_key_val;
            }
            if(provider.facilityProviderName) {
                return provider;
            }
        });
    }

    async getActivitiesByHscId(getActivitiesRequest : GetActivitiesRequest,  httpRequest: HttpRequest): Promise<GetActivitiesResponse> {
        try {
            const hscGraphqlClient: GraphQLClient = this.healthServiceClient.getGraphqlClient(httpRequest);
            const memberGraphqlClient: GraphQLClient = this.memberServiceClient.getGraphqlClient(httpRequest);
            const refGraphqlClient: GraphQLClient = this.referenceClient.getGraphqlClient(httpRequest);
            let response: GetActivitiesResponse;
            if(getActivitiesRequest.hsc_id) {
                const activities = await hscGraphqlClient.request(getHscActivitiesByHscId,
                    { hscId: getActivitiesRequest.hsc_id });
                if(activities.hsr_actv && activities.hsr_actv.length >0) {
                    let subjectRecordIds = [];
                    // Get hsr_sbj_rec_id from each actv_subj for hsr_sbj_typ_ref_id equal to ASSIGNMENT_TYPE_REF_ID
                    activities.hsr_actv.forEach(activitySubjects => {
                        const sbjRecIds = activitySubjects.hsr_actv_sbjs.filter(comm => {
                            return comm.hsr_sbj_typ_ref_id === caseDataConstants.MEMBER_COMMUNICATION_TYPE_REF_ID;
                        }).map(item => {
                            return item.hsr_sbj_rec_id;
                        });
                        subjectRecordIds = subjectRecordIds.concat(sbjRecIds);
                    });
                    // Get Communications for hsr_sbj_rec_id's
                    const communications = await memberGraphqlClient.request(getMemberCommunications,
                        { subjects: subjectRecordIds });
                    if(communications.mbr_cmnct && communications.mbr_cmnct.length >0) {
                        const refIds = this.getRefIds(communications.mbr_cmnct);
                        const refData = await refGraphqlClient.request(getRefDataForRefIds,
                            { referenceIds: refIds });
                        response=  this.mapCommunicationsResponse(communications.mbr_cmnct, refData.ref);
                    }
                }
            }
            return response;
        } catch (e) {
            this.logger.error("Error while calling CaseWF GetTaskDetailsService getActivitiesByHscId (" +
                "getActivitiesRequest: " +
                getActivitiesRequest + GetTaskDetailsService.HTTPREQUESTLABEL + httpRequest + ") " + e);
        }
    }

    private getRefIds(communications: any) {
        const refIds = communications.map(comm => {
           return [comm.mbr_cmnct_chnl_ref_id,comm.mbr_cmnct_sts_ref_id,
                comm.mbr_cmnct_dir_ref_id,comm.mbr_cmnct_typ_ref_id,comm.mbr_cmnct_catgy_ref_id];
        });
        const uniqRefIDs = new Set(refIds.flat(1));
        return [...uniqRefIDs];
    }

    private mapCommunicationsResponse(memberComms: any, refData: any) {
        const response= new GetActivitiesResponse();
        const communications: CommunicationActivity[] = [];
        memberComms.forEach(communication => {
            const comm = new CommunicationActivity();
            comm.creat_user_id = communication.creat_user_id;
            comm.creat_dttm = this.convertDate(communication.creat_dttm);
            comm.mbr_cmnct_chnl_ref_dspl = refData.find(item => item.ref_id === communication.mbr_cmnct_chnl_ref_id).ref_dspl;
            comm.mbr_cmnct_typ_ref_dspl = refData.find(item => item.ref_id === communication.mbr_cmnct_typ_ref_id).ref_dspl ;
            comm.mbr_cmnct_sts_ref_dspl = refData.find(item => item.ref_id === communication.mbr_cmnct_sts_ref_id).ref_dspl ;
            comm.mbr_cmnct_catgy_ref_dspl = refData.find(item => item.ref_id === communication.mbr_cmnct_catgy_ref_id).ref_dspl ;
            comm.mbr_cmnct_dir_ref_dspl = refData.find(item => item.ref_id === communication.mbr_cmnct_dir_ref_id).ref_dspl ;
            communications.push(comm);
        });
        response.communication_activities = communications;
        return response;
    }

    private convertDate(createDate) {
        const d = new Date(createDate);
        return d.getUTCMonth()+'/'+d.getUTCDate()+'/'+d.getUTCFullYear()
            +' '+d.getUTCHours()+':'+d.getUTCMinutes()+':'+d.getUTCSeconds();
    }

    async calculateTatHours(response){
        var today = new Date();
        var todayDateTime = JSON.stringify(today.toISOString().replace("T"," ").replace("Z",""));
        for(var i=0; i < response.hsr_asgn.length; i++){
            var createDateTime = JSON.stringify(response.hsr_asgn[i].creat_dttm.replace("T", " "));
            var hours = Math.abs(<any>new Date(todayDateTime) - <any>new Date(createDateTime)) / 36e5;
            var tatEstimatedHours = 48;
            var tatHrs = Math.round(tatEstimatedHours-hours);
            if( response.hsr_asgn[i].hsc.hsc_facls!=null) {
                response.hsr_asgn[i].hsc.hsc_facls[0].tat_due_dttm = tatHrs;
            }
        }
    }

    async getTaskDetails(getTaskDetailsRequest : GetTaskDetailsRequest, httpRequest: HttpRequest) {
        try {
           
                const hscGraphqlClient: GraphQLClient = this.healthServiceClient.getGraphqlClient(httpRequest);
                const hscId = getTaskDetailsRequest.hsr_asgn.hsc_id;
                const assignTypeRefId = getTaskDetailsRequest.hsr_asgn.asgn_typ_ref_id;
               
                const taskDetailsResponse = await hscGraphqlClient.request(getTaskDetailsQuery, {
                    hscId,
                    assignTypeRefId
                });
                let configKey = "";
                if(taskDetailsResponse.hsr_asgn.length>0){
                    configKey = taskDetailsResponse?.hsr_asgn[0]?.asgn_desc?.wfName?taskDetailsResponse?.hsr_asgn[0]?.asgn_desc?.wfName:"";
                }
                const configRefResponse = await this.taskMetadataService.getSysConfigRefIds(configKey, httpRequest);
                const configTaskMetadata = await this.taskMetadataService.getSysConfigDetailsByWF(configRefResponse, httpRequest);
                const configTaskList = [];
                const taskDetailsChecklistResponse = [];
                configTaskMetadata.taskMetadata.forEach((taskCategory) => {
                    taskCategory.tasks.forEach((task) => {
                        configTaskList.push(task)
                    })
                });
                const taskCheckList = configTaskList.filter(task => task.taskNameRefId === assignTypeRefId.toString());
                for (let i = 0; i < taskCheckList?.length; i++) {
                        for (let j = 0; j < taskCheckList[i].checklist?.length; j++) {
                            const assignTypeRefId = taskCheckList[i].checklist[j].taskNameRefIds;
                            const taskDetails = await hscGraphqlClient.request(getTaskDetailsQuery, {
                                hscId,
                                assignTypeRefId
                            });
                            taskDetailsChecklistResponse.push(taskDetails);
                        }
                }
                const response = new GetTaskDetailsResponse();
                response.task=[];
                 taskDetailsResponse.hsr_asgn.forEach((resp) =>
                     response.task.push(resp)
                 );
                 response.task.forEach((task)=> {
                    delete task.hsr_asgn_id;
                    task.checklist=[];
                    taskDetailsChecklistResponse.forEach((resp) =>
                   resp.hsr_asgn.forEach((checkList)=>
                        task.checklist.push(checkList)
                    ))});
    
                return response;
            
        } catch (e) {
            this.logger.error("Error while calling CaseWF GetTaskDetailsService getChecklistItems (getTaskDetailsRequest: " + getTaskDetailsRequest + GetTaskDetailsService.HTTPREQUESTLABEL + httpRequest + ") " + e);
        }
    }
}
