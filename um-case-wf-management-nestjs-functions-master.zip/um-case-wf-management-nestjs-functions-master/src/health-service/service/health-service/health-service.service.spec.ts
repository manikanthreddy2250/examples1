import { Test, TestingModule } from '@nestjs/testing';
import { GraphQLClient } from "graphql-request/dist";
import {RequestDocument} from "graphql-request/dist/types";
import {of as observableOf, of} from "rxjs";
import { HttpRequest } from "@azure/functions";
import { HealthService } from "./health-service.service";
import {HealthServiceClient} from "../../shared/graphql/healthservicedomain/healthServiceClient";
import {GetProviderDetailsRequest} from "../../models/get-provider-details-request";
import {ReferenceClient} from "../../shared/graphql/referenceDomain/referenceClient";
import {GetCaseHeaderDetailsRequest} from "../../models/get-case-header-details-request";
import {GetProviderListRequest} from "../../models/get-provider-list-request";
import {ProviderClient} from "../../shared/graphql/provider-domain/providerClient";
import {LoggerModule} from "nestjs-pino";
import { RequestClinicalEventInput } from 'src/health-service/models/request-clinical-event-input';
import {HttpModule} from "@nestjs/common";
import {ConfigModule} from "@nestjs/config";
import { HscLetterEventService } from './hsc-letter-event.service';
import {DomainConstants} from '../../../configuration/constants/domainConstants';
import {DischargeSignalRequest} from '../../models/signal/dischargeSignal.request';
import {PublishLetterEventRequest} from '../../models/events/publishLetterEvent.request';
import axios from "axios";
import { GetNextReviewDateResponse } from 'src/health-service/models/get-next-review-date-response';
import { GetNextReviewDateRequest } from 'src/health-service/models/get-next-review-date-request';
import {RulesService} from "../rules/rules.service";
import { Rule } from 'eslint';

const reqHeader = {
    'Content-Type': DomainConstants.CONTENT_TYPE,
    'Accept': DomainConstants.CONTENT_TYPE,
    'authorization': "authorization",
    'x-bpm-cli-org-id': "ecp",
    'x-bpm-func-role': "um_ecp_system",
    'x-bpm-tenant-id': "x-bpm-tenant-id",
    //'x-bpm-external-ref-id': GlobalConstants.X_BPM_EXTERNAL_REF_ID,
    'x-bpm-workflow': "workflow"
};


class MockGraphQLClient extends GraphQLClient {

    request(document: RequestDocument, variables?: any, requestHeaders?: any): Promise<any> {
        if(variables.hscID) {
            //this is return statement for getCaseHeaderDetails
            return of({
                "hsc": [
                    {
                        "hsc_facls": [
                            {
                                "actul_admis_dttm": "2021-02-16T00:00:00",
                                "actul_dschrg_dttm": null,
                                "expt_dschrg_dt": "2021-02-25",
                                "expt_admis_dt": "2021-02-22",
                                "srvc_dtl_ref_id": 4299,
                                "srvc_dtl_ref_cd": {
                                    "ref_dspl": "Hospice"
                                },
                                "srvc_desc_ref_id": 4347,
                                "srvc_desc_ref_cd": {
                                    "ref_dspl": "Scheduled"
                                }
                            }
                        ],
                        "hsc_srvcs": [
                            {
                                "hsc_srvc_non_facls": []
                            }
                        ],
                        "hsc_diags": [
                            {
                                "diag_cd": "S81.0"
                            },
                            {
                                "diag_cd": " A38.1"
                            }
                        ],
                        "srvc_set_ref_id": 3737,
                        "srvc_set_ref_cd": {
                            "ref_dspl": "Inpatient"
                        },
                        "mbr_cov_dtl": {
                            "indv_id": 503926748,
                            "pol_nbr": "0128855",
                            "cov_eff_dt": "2013-01-01",
                            "cov_end_dt": "9999-12-31",
                            "mbr_cov_id": 96963692,
                            "productCode": 214,
                            "indv_key_val": "16440436900",
                            "productCatgyTpe": null,
                            "coverageTypeDesc": "Medical",
                            "indv_key_typ_ref_id": 2757,
                            "claim_platform_ref_Id": 363
                        },
                        "hsc_provs": [
                            {
                                "prov_loc_affil_dtl": {
                                    "providerDetails": {
                                        "prov_id": 10455660,
                                        "prov_key": [
                                            {
                                                "prov_key_val": "1710081369",
                                                "prov_key_typ_ref_id": 2782
                                            },
                                            {
                                                "prov_key_val": "288158608",
                                                "prov_key_typ_ref_id": 16333
                                            },
                                            {
                                                "prov_key_val": "1710081369",
                                                "prov_key_typ_ref_id": 2783
                                            }
                                        ],
                                        "prov_adr_id": 117625630,
                                        "prov_cat_typ_ref_id": 16310
                                    }
                                }
                            }
                        ],
                        "hsc_sts_ref_id": 19275,
                        "hsc_sts_ref_cd": {
                            "ref_dspl": "Open"
                        },
                        "individual": [
                            {
                                "fst_nm": "Matt",
                                "indv_id": 503926748,
                                "lst_nm": "Meyer",
                                "gdr_ref_cd": {
                                    "ref_dspl": "Male",
                                    "ref_id": 2109
                                },
                                "bth_dt": "1978-07-26"
                            }
                        ]
                    }
                ]
                }).toPromise();

        } else if (variables.hscProvID){
            return of({
                "hscProv": [
                    {
                        "hsc_id": 68
                    }
                ]
            }).toPromise();
        } else if(variables.provId){

        } else if(variables.diag_cds) {
            return of(
                {
                    "icd10": [
                        {
                            "diag_cd": "J42",
                            "full_desc": "Unspecified chronic bronchitis",
                            "shrt_desc": "UNSPECIFIED CHRONIC BRONCHITIS",
                            "cd_desc": "UNSPECIFIED CHRONIC BRONCHITIS"
                        }
                    ]
                }
            ).toPromise();

        }else if (variables.hscID) {
            //this is return statement for getProviderList
            return of({
                "hsc_prov": [
                {
                    "hsc_id": 6341,
                    "prov_loc_affil_id": 5185485,
                    "hsc_prov_roles": [
                        {
                            "prov_role_ref_id": 3766,
                            "hsc_prov_id": 82
                        }
                    ],
                    "prov_loc_affil_dtl": {
                        "providerDetails": {
                            "prov_id": 125,
                            "prov_key": [
                                {
                                    "prov_key_val": "1699732990",
                                    "prov_key_typ_ref_id": 2782
                                },
                                {
                                    "prov_key_val": "123456",
                                    "prov_key_typ_ref_id": 16333
                                },
                                {
                                    "prov_key_typ_ref_id": 2783
                                }
                            ]
                        }
                    }
                }
            ]}).toPromise()
        }

    }
}

class MockHealthServiceClient {
    public getGraphqlClient(httpRequest: HttpRequest): GraphQLClient {
        return new MockGraphQLClient('testurl');
    }
}

class MockReferenceClient {
    public getGraphqlClient(httpRequest: HttpRequest): GraphQLClient {
        return new MockGraphQLClient('testurl');
    }
}

class MockProviderClient {      
    public getGraphqlClient(httpRequest: HttpRequest): GraphQLClient {
        return new MockGraphQLClient('testurl');
    }
}

describe('HealthService', () => {
    let service: HealthService;
    let ruleService: RulesService;
    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            imports: [LoggerModule.forRoot(), HttpModule, ConfigModule],
            providers: [HealthService, HscLetterEventService, RulesService,  {provide: HealthServiceClient, useClass: MockHealthServiceClient},
                {provide: ReferenceClient, useClass: MockReferenceClient}, {provide: ProviderClient, useClass: MockProviderClient}],
        }).compile();
        ruleService = module.get<RulesService>(RulesService);
        service = module.get<HealthService>(HealthService);
    });

    it('should be defined', () => {
        expect(service).toBeDefined();
    });

    it('should call hsc getProviderDetails', () => {
        let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
        const getProviderDetailsRequest: GetProviderDetailsRequest = {hscProv:{hsc_prov_id : 7}};
        service.getProviderDetails(getProviderDetailsRequest, httpRequest).then((res) => {
            expect(res).toBeTruthy();
        });
    });

    it('should call hsc getCaseHeaderDetails', () => {
        let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
        const getCaseHeaderDetailsRequest: GetCaseHeaderDetailsRequest = {hscID:{hsc_id : 7}};
        spyOn<any>(service, 'getReferenceCode').and.returnValue("");
        service.getCaseHeaderDetails(getCaseHeaderDetailsRequest, httpRequest).then((res) => {
            expect(res).toBeTruthy();
        });
    });

    it('should call hsc getProviderList', () => {
        let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
        const getProviderDetailsRequest: GetProviderListRequest = {hscID:{hsc_id : 7}};
        service.getProviderList(getProviderDetailsRequest, httpRequest).then((res) => {
            expect(res).toBeTruthy();
        });
    });
    it('should call gprepareBpmnDateFormat', () => {
        
        const providerType = service.prepareBpmnDateFormat(Date.now(),2,"2H");
        expect(providerType).toBeDefined();
    });
    it('should call gprepareBpmnDateFormat', () => {
        
        const providerType = service.prepareBpmnDateFormat(Date.now(),2,"2M");
        expect(providerType).toBeDefined();
    });
    it('should call gprepareBpmnDateFormat', () => {
        
        const providerType = service.prepareBpmnDateFormat(Date.now(),2,"2S");
        expect(providerType).toBeDefined();
    });
    it('should call calucuateNextReviewDate', () => {
        let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
       
        const providerType = service.calucuateNextReviewDate(httpRequest,12916,"2H");
        expect(providerType).toBeDefined();
    });
    it('should call getProviderType', () => {
        const provDraftData = {
            v_prov_srch: [
                {
                    bus_nm: "Business Name"
                }
            ]
        }
        const providerType = service.getProviderType(provDraftData);
        expect(providerType).toEqual("Facility");
    });

    it('should call update letter details for OP', () => {
        let httpRequest: HttpRequest = { method: null, url: '/test?session_id=encryptedid', headers: { authorization: 'test token', 'x-hasura-role': 'testrole' }, query: { 'test': 'test' }, params: { 'test': 'test' } };
        const requestClinicalEventInput: RequestClinicalEventInput =
        {   
            "requesterId":"sbamini",
            "hsc_id": 13596,
            "client_id": 1,
            "channel": "WEB",
            "fax_num": 1234,
            "email_id": "test@optum.com"
        };
        service.requestForClinical(requestClinicalEventInput, httpRequest).then((res) => {
            expect(res).toBeTruthy();
        });
    });


    it('should call publishLetterEvent', () => {
        let httpRequest: HttpRequest = { method: null, url: '/test?session_id=encryptedid', headers: { authorization: 'test token', 'x-hasura-role': 'testrole' }, query: { 'test': 'test' }, params: { 'test': 'test' } };
        let publishLetterEventRequest: PublishLetterEventRequest;
        publishLetterEventRequest = {
            "hsc_id": 11186,
            "client": "ecp",
            "decisionIds": [1, 2, 3],
            "eventChannel": "testWorkflow",
            "appUserId": "system"
        };
        const configResponse = {
                    "data" :{"success" : true}
                };
        jest.spyOn(axios, 'post').mockImplementationOnce(async() => of(configResponse));
        service.publishLetterEvent(publishLetterEventRequest, httpRequest).then((res) => {
            expect(res).toBeTruthy();
        });
    });
});
