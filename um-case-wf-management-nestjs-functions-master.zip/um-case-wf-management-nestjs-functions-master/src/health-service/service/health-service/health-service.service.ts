import { Injectable } from '@nestjs/common';
import { HealthServiceClient } from "../../shared/graphql/healthservicedomain/healthServiceClient";
import {
    getBedDayDecisionDetails,
    getHscHeaderDetailsByHscId,
    getHscProvByHscId,
    getHscProviderDetailsQuery,
    getProviderDataDetails,
    getProviderNameByProvId
} from "../../shared/graphql/healthservicedomain/healthServiceQuery";
import { GetProviderDetailsRequest } from "../../models/get-provider-details-request";
import { GetProviderDetailsResponse } from "../../models/get-provider-details-response";
import { HttpRequest } from "@azure/functions";
import { GetProviderListRequest } from "../../models/get-provider-list-request";
import { ReferenceClient } from "../../shared/graphql/referenceDomain/referenceClient";
import { GetCaseHeaderDetailsRequest } from "../../models/get-case-header-details-request";
import { diagCdRefQuery, getReferenceCodeQuery } from "../../shared/graphql/referenceDomain/referenceServiceQuery";
import { GetCaseHeaderDetailResponse } from "../../models/get-case-header-detail-response";
import { GetProviderListResponse } from "../../models/get-provider-list-response";
import { ProviderClient } from "../../shared/graphql/provider-domain/providerClient";
import { Logger } from "nestjs-pino";
import { RequestClinicalEventInput } from 'src/health-service/models/request-clinical-event-input';
import { RequestClinicalEventOutput } from 'src/health-service/models/request-clinical-event-output';
import { AuthorizationService } from '@ecp/func-tk/dist';
import { ConfigService } from '@nestjs/config';
import { HttpService } from '@nestjs/common';
import { HscLetterEventService } from './hsc-letter-event.service';
import { DischargeSignalResponse } from '../../models/signal/dischargeSignal.response';
import { PublishLetterEventResponse } from '../../models/events/publishLetterEvent.response';
import { GetNextReviewDateResponse } from 'src/health-service/models/get-next-review-date-response';
import { GetNextReviewDateRequest } from 'src/health-service/models/get-next-review-date-request';
import {applicationConstants, LetterEventConstants} from "../../shared/constants/applicationConstants"
import { PublishLetterEventRequest } from "../../models/events/publishLetterEvent.request";
import axios from "axios";
import {RulesService} from "../rules/rules.service";
import {DecisionConstants} from '../../shared/constants/applicationConstants';


const PROVIDER_KEY_VALUE_TYP_REF_ID_TIN = 16333;
const PROVIDER_KEY_VALUE_TYP_REF_ID_NPI = 2782;
@Injectable()
export class HealthService {
    static HTTPREQUESTLABEL = ", httpRequest: ";

    constructor(private readonly healthServiceClient: HealthServiceClient, private readonly referenceClient: ReferenceClient,
        private readonly providerClient: ProviderClient, private readonly logger: Logger, private configService: ConfigService,
        private readonly rulesService:RulesService   ,
        private readonly httpService: HttpService, private readonly hscLetterEventService: HscLetterEventService) { }

    async getProviderDetails(getProviderDetailsRequest: GetProviderDetailsRequest, httpRequest: HttpRequest): Promise<GetProviderDetailsResponse> {
        try {
            const hscProvID = getProviderDetailsRequest.hscProv.hsc_prov_id;
            const hscProvResponse = await this.healthServiceClient.getGraphqlClient(httpRequest).request(getHscProviderDetailsQuery, { hscProvID });

            return {
                "hscProv": hscProvResponse.hsc_prov
            };
        } catch (e) {
            this.logger.error("Error while calling CaseWF HealthService getProviderDetails (getProviderDetailsRequest: " + getProviderDetailsRequest + HealthService.HTTPREQUESTLABEL + httpRequest + ") " + e);
        }
    }

    async getCaseHeaderDetails(getCaseHeaderDetailsRequest: GetCaseHeaderDetailsRequest, httpRequest: HttpRequest): Promise<GetCaseHeaderDetailResponse> {
        try {
            const hscID = getCaseHeaderDetailsRequest.hscID.hsc_id;
            var hscHeaderDetails = await this.healthServiceClient.getGraphqlClient(httpRequest).request(getHscHeaderDetailsByHscId, { hscID });
            var responseBody;
            //populate diagnosis description
            const diagCodes = [];
            hscHeaderDetails?.hsc[0]?.hsc_diags.forEach((data) => {
                diagCodes.push(data.diag_cd);
            });
            var hscDiagRefDataList = await this.referenceClient.getGraphqlClient(httpRequest).request(diagCdRefQuery, { "diag_cds": diagCodes });
            hscHeaderDetails?.hsc[0]?.hsc_diags.forEach((item) => {
                if (item.diag_cd) {
                    const diagRecord = hscDiagRefDataList.icd10.find(element => element.diag_cd === item.diag_cd);
                    item.diag_desc = diagRecord ? diagRecord.cd_desc : null;
                }
            });

            // get facility's name
            var facility_name;
            var prov_id = hscHeaderDetails?.hsc[0]?.hsc_provs[0]?.prov_loc_affil_dtl?.providerDetails?.prov_id;
            if (prov_id != undefined) {
                var facilityDetail = await this.healthServiceClient.getGraphqlClient(httpRequest).request(getProviderNameByProvId, { provId: prov_id });
                facility_name = facilityDetail?.prov_org[0]?.bus_nm;
            }

            // get facility adress deatials
            let addressLine;
            let st_ref_cd;
            if (hscID != undefined && (prov_id != null || prov_id != undefined)) {
                const facilityQueryData = this.getProviderDataFromProviderId(hscHeaderDetails?.hsc[0]?.hsc_provs, prov_id)
                const adr_ln_1_txt = facilityQueryData?.prov_loc_affil_dtl?.providerDetails?.prov_adr?.adr_ln_1_txt;
                const adr_ln_2_txt = facilityQueryData?.prov_loc_affil_dtl?.providerDetails?.prov_adr?.adr_ln_1_txt;
                const zip_cd_txt = facilityQueryData?.prov_loc_affil_dtl?.providerDetails?.prov_adr?.zip_cd_txt;
                const facilityStateId = facilityQueryData?.prov_loc_affil_dtl?.providerDetails?.prov_adr?.st_ref_id;
                st_ref_cd = await this.getReferenceCode(facilityStateId, httpRequest);

                // setting adr_ln_2_txt as null as it have duplicate value from adr_ln_1_txt

                addressLine = this.getProviderAddressLine(adr_ln_1_txt, null, null, st_ref_cd, zip_cd_txt);
            }

            responseBody = this.mapCaseHeaderResponse(hscHeaderDetails, facility_name, addressLine, hscID, st_ref_cd);
            return responseBody;
        } catch (e) {
            this.logger.error("Error while calling CaseWF HealthService getCaseHeaderDetails (getCaseHeaderDetailsRequest: " + getCaseHeaderDetailsRequest + HealthService.HTTPREQUESTLABEL + httpRequest + ") " + e);
        }
    }

    private mapCaseHeaderResponse(hscHeaderDetails: any, facilityName: string, addressLine: string, hscId: number, st_ref_cd: string) {
        var responseData;
        if (hscHeaderDetails?.hsc[0]) {
            const hscFacility = hscHeaderDetails.hsc[0].hsc_facls[0];
            var actualAdmitDate = hscFacility?.actul_admis_dttm;
            var actualDischargeDate = hscFacility?.actul_dschrg_dttm;
            var expectedAdmitDate = hscFacility?.expt_admis_dt;
            var expectedDischargeDate = hscFacility?.expt_dschrg_dt;
            responseData = {
                srvc_set_ref_id: hscHeaderDetails.hsc[0].srvc_set_ref_id,
                srvc_set_ref_dspl: hscHeaderDetails.hsc[0].srvc_set_ref_cd?.ref_dspl,
                plsrv_ref_id: hscHeaderDetails.hsc[0].hsc_srvcs[0]?.hsc_srvc_non_facls[0]?.plsrv_ref_id,
                plsrv_ref_dspl: hscHeaderDetails.hsc[0].hsc_srvcs[0]?.hsc_srvc_non_facls[0]?.plsrv_ref_cd?.ref_dspl,
                hsc_id: hscId,
                srvc_desc_ref_id: hscFacility?.srvc_desc_ref_id,
                srvc_desc_ref_dspl: hscFacility?.srvc_desc_ref_cd?.ref_dspl,
                srvc_dtl_ref_id: hscFacility?.srvc_dtl_ref_id,
                srvc_dtl_ref_dspl: hscFacility?.srvc_dtl_ref_cd?.ref_dspl,
                admitDate: actualAdmitDate ? actualAdmitDate : expectedAdmitDate,
                dischargeDate: actualDischargeDate ? actualDischargeDate : expectedDischargeDate,
                primaryDiagnosis: hscHeaderDetails.hsc[0].hsc_diags[0]?.diag_cd + "-" + hscHeaderDetails.hsc[0].hsc_diags[0]?.diag_desc,
                tatDueDate: "12-31-9999",
                bus_nm: facilityName,
                contractPaperTypeCode: hscHeaderDetails?.hsc[0]?.hsc_provs[0]?.prov_loc_affil_dtl?.facilityContracts?.contractPaperType[0]?.contractPaperTypeCode,
                addressLine: addressLine ? addressLine : null,
                st_ref_cd: st_ref_cd,
                cov_eff_dt: hscHeaderDetails.hsc[0].mbr_cov_dtl?.cov_eff_dt,
                cov_end_dt: hscHeaderDetails.hsc[0].mbr_cov_dtl?.cov_end_dt,
                planCode: hscHeaderDetails.hsc[0].mbr_cov_dtl?.coverageTypeDesc,
                indv_id: hscHeaderDetails.hsc[0].mbr_cov_dtl?.indv_id,
                srvc_strt_dt: hscHeaderDetails.hsc[0].hsc_srvcs[0]?.hsc_srvc_non_facls[0]?.srvc_strt_dt,
                srvc_end_dt: hscHeaderDetails.hsc[0].hsc_srvcs[0]?.hsc_srvc_non_facls[0]?.srvc_end_dt,
                hsc_sts_ref_id: hscHeaderDetails.hsc[0].hsc_sts_ref_id,
                hsc_sts_ref_dspl: hscHeaderDetails.hsc[0].hsc_sts_ref_cd?.ref_dspl,
                fst_nm: hscHeaderDetails.hsc[0].individual[0]?.fst_nm,
                lst_nm: hscHeaderDetails.hsc[0].individual[0]?.lst_nm,
                gdr_ref_id: hscHeaderDetails.hsc[0].individual[0]?.gdr_ref_cd?.ref_id,
                gdr_ref_dspl: hscHeaderDetails.hsc[0].individual[0]?.gdr_ref_cd?.ref_dspl,
                bth_dt: hscHeaderDetails.hsc[0].individual[0]?.bth_dt
            }
        }
        return responseData;
    }
    private getProviderDataFromProviderId(hscProvs: any, prov_id) {
        return hscProvs.filter(hscProv => hscProv.prov_loc_affil_dtl.providerDetails.prov_id === prov_id)[0]
    }

    async getProviderList(getProviderDetailsRequest: GetProviderListRequest, httpRequest: HttpRequest): Promise<GetProviderListResponse> {
        try {
            const hscID = getProviderDetailsRequest.hscID.hsc_id;
            const hscProvResponse = await this.healthServiceClient.getGraphqlClient(httpRequest).request(getHscProvByHscId, { hscID });
            const responseBody = await this.buildProviderDetails(hscProvResponse, httpRequest);

            return {
                provList: responseBody
            };
        } catch (e) {
            this.logger.error("Error while calling CaseWF HealthService getProviderList (getProviderDetailsRequest: " + getProviderDetailsRequest + HealthService.HTTPREQUESTLABEL + httpRequest + ") " + e);
        }
    }

    async getProviderData(_prov_id: any, _provider_key_value_typ_ref_npi: any, _provider_npi_val: any, httpRequest: HttpRequest) {

        return await this.providerClient.getGraphqlClient(httpRequest).request(getProviderDataDetails,
            {
                prov_id: _prov_id,
                provider_key_value_typ_ref_npi: _provider_key_value_typ_ref_npi, provider_npi_val: _provider_npi_val
            });
    }

    getProviderType(provDraftData) {
        if (provDraftData.v_prov_srch[0].bus_nm != null) {
            return 'Facility';
        } else {
            return 'Provider';
        }
    }

    async buildProviderDetails(hscProviderList, httpRequest: HttpRequest) {
        try {
            const result: any[] = [];
            for (let i = 0; i < hscProviderList.hsc_prov.length; i++) {
                var providerTin;
                var providerNPI;
                var prov_loc_affil_dtls = hscProviderList.hsc_prov[i].prov_loc_affil_dtl?.providerDetails?.prov_keys;
                var prov_id = hscProviderList.hsc_prov[i].prov_loc_affil_dtl?.providerDetails?.prov_id;

                const providerNPIandTIN = this.getProviderNPIandTIN(prov_loc_affil_dtls, providerNPI, providerTin);
                providerNPI = providerNPIandTIN.providerNPI;
                providerTin = providerNPIandTIN.providerTin;

                const provDraftData = await this.getProviderData(prov_id, PROVIDER_KEY_VALUE_TYP_REF_ID_NPI, providerNPI, httpRequest);
                if (provDraftData.v_prov_srch.length > 0) {
                    var addressLine = this.getProviderAddressLine(provDraftData.v_prov_srch[0].adr_ln_1_txt, provDraftData.v_prov_srch[0].adr_ln_2_txt, provDraftData.v_prov_srch[0].cty_nm, provDraftData.v_prov_srch[0].st_ref_cd.ref_desc, provDraftData.v_prov_srch[0].zip_cd_txt);
                    const providerType = this.getProviderType(provDraftData);

                    const providerDetails = {
                        type: providerType,
                        bus_nm: provDraftData.v_prov_srch[0].bus_nm,
                        fst_nm: provDraftData.v_prov_srch[0].fst_nm,
                        lst_nm: provDraftData.v_prov_srch[0].lst_nm,
                        prov_id: provDraftData.v_prov_srch[0].prov_id,
                        telcom_adr_id: provDraftData.v_prov_srch[0].telcom_adr_id,
                        spcl_ref_dspl: provDraftData.v_prov_srch[0].spcl_ref_cd.ref_dspl,
                        spcl_ref_id: provDraftData.v_prov_srch[0].spcl_ref_id,
                        prov_role_ref_desc: hscProviderList.hsc_prov[i].hsc_prov_roles[0].prov_role_ref_cd.ref_desc,
                        provider_address: addressLine,
                        prov_catgy_ref_id: provDraftData.v_prov_srch[0].prov_catgy_ref_id,
                        prov_catgy_ref_desc: provDraftData.v_prov_srch[0].prov_catgy_ref_cd.ref_desc,
                        providerTin: providerTin,
                        providerNpi: providerNPI,
                        ntwk_sts_ref_id: hscProviderList.hsc_prov[i].ntwk_sts_ref_id // Look in hsr_prov table (hardcoded for now on UI as 'INN' (in-network))
                    };
                    let duplicate = false;
                    result.forEach(function (newProvider) {
                        if (providerDetails.fst_nm == newProvider.fst_nm && providerDetails.lst_nm == newProvider.lst_nm &&
                            providerDetails.providerNpi == newProvider.providerNpi && providerDetails.providerTin == newProvider.providerTin) {
                            duplicate = true;
                        }
                    });
                    if (!duplicate) {
                        result.push(providerDetails);
                    }
                }
            }

            return result;
        } catch (e) {
            this.logger.error("Error while calling CaseWF HealthService buildProviderDetails (hscProviderList: " + hscProviderList + HealthService.HTTPREQUESTLABEL + httpRequest + ") " + e);
        }
    }

    private getProviderNPIandTIN(prov_loc_affil_dtls, providerNPI, providerTin) {
        prov_loc_affil_dtls.forEach(element => {
            if (element.prov_key_typ_ref_id === PROVIDER_KEY_VALUE_TYP_REF_ID_NPI) {
                providerNPI = element.prov_key_val;
            } else if (element.prov_key_typ_ref_id === PROVIDER_KEY_VALUE_TYP_REF_ID_TIN) {
                providerTin = element.prov_key_val;
            }
        });
        return { providerNPI, providerTin };
    }

    async getReferenceDescription(_referenceId: any, httpRequest: HttpRequest): Promise<any> {
        let refData: any;
        try {
            refData = await this.referenceClient.getGraphqlClient(httpRequest).request(getReferenceCodeQuery, { referenceId: _referenceId });
        } catch (e) {
            refData = (`Error while fetching reference description ${e}`);
            this.logger.error("Error while calling CaseWF HealthService getReferenceDescription (_referenceId: " + _referenceId + HealthService.HTTPREQUESTLABEL + httpRequest + ") " + e);
        }
        return refData.ref[0].ref_desc;
    }

    async getReferenceCode(_referenceId: any, httpRequest: HttpRequest): Promise<any> {
        let refData: any;
        try {
            refData = await this.referenceClient.getGraphqlClient(httpRequest).request(getReferenceCodeQuery, { referenceId: _referenceId });
        } catch (e) {
            refData = (`Error while fetching reference code ${e}`);
            this.logger.error("Error while calling CaseWF HealthService getReferenceCode (_referenceId: " + _referenceId + HealthService.HTTPREQUESTLABEL + httpRequest + ") " + e);
        }
        return refData.ref[0].ref_cd;
    };

    private getProviderAddressLine(adr_ln_1_txt: string, adr_ln_2_txt: string, cty_nm: string, st_ref_cd: string, zip_cd_txt: string): string {
        let addressLine = '';
        if (adr_ln_1_txt) {
            addressLine = adr_ln_1_txt;
        }
        if (adr_ln_2_txt) {
            addressLine += ', ' + adr_ln_2_txt;
        }
        if (cty_nm) {
            addressLine += ', ' + cty_nm;
        }
        if (st_ref_cd) {
            addressLine += ', ' + st_ref_cd;
        }
        if (zip_cd_txt) {
            addressLine += ', ' + zip_cd_txt;
        }
        return addressLine;

    }
   async getNextReviewDate(getNextReviewDateRequest : GetNextReviewDateRequest, httpRequest: HttpRequest): Promise<GetNextReviewDateResponse>{
        var responseData;
        try{
                const newReviewbody = {taskNameRefId: getNextReviewDateRequest.task_name_ref_id};
            const newReviewDateRulesResponse = await this.rulesService.getDmnRuleResult(httpRequest, newReviewbody, "NextReviewDateRules");
                const nextReviewType = newReviewDateRulesResponse[0].nextReviewType;
                if(nextReviewType == DecisionConstants.LAST_DECN_BED_DAY_REF_ID){
                    const body = {taskNameRefId: getNextReviewDateRequest.task_name_ref_id};
                    const dmnResponse = await this.rulesService.getDmnRuleResult(httpRequest, body, "ReviewIntervalRules");
                    const configured_days = dmnResponse[0].intervalTime;
                    responseData=await this.calucuateNextReviewDate(httpRequest,getNextReviewDateRequest.hsc_id,configured_days)
            }
        } catch (e) {
        this.logger.log("error occured while  calucating getNextReviewDate ", e);

        }
        return responseData;
    }
    async calucuateNextReviewDate(httpRequest,hscId,configured_days){
        let responseData ;
        try{
             const bedDayDecisionData = await this.healthServiceClient.getGraphqlClient(httpRequest).request(getBedDayDecisionDetails,{hscID:hscId});
            const decision = bedDayDecisionData.hsc_decn_bed_day[0]
            const strt_bed_dt = decision.strt_bed_dt
            const decn_bed_day_cnt = (decision.hsc_decn.decn_bed_day_cnt);
          
             responseData ={
                     configured_days: configured_days,
                    next_review_date: this.prepareBpmnDateFormat(strt_bed_dt,decn_bed_day_cnt,configured_days)
            }
        } catch (e) {
            this.logger.log("error occured  in calucuateNextReviewDate ", e);
    
            }
            return responseData;
    }
    async prepareBpmnDateFormat(strt_bed_dt,decn_bed_day_cnt,configured_days){
        const startBedDay = new Date(strt_bed_dt);
        const  nextReviewDate = new Date(strt_bed_dt);
        const timeValue = configured_days.slice(-1);
        configured_days = configured_days.replace(timeValue,"");
        if(timeValue == 'H'){
            nextReviewDate.setHours(startBedDay.getHours()+parseInt(configured_days)+decn_bed_day_cnt*24);
        }else if(timeValue == 'M'){
            nextReviewDate.setMinutes(startBedDay.getMinutes()+parseInt(configured_days)+decn_bed_day_cnt*24*60);
        }else  if(timeValue == 'S'){
            nextReviewDate.setSeconds(startBedDay.getSeconds()+parseInt(configured_days)+decn_bed_day_cnt*24*60*60);

        }else{
           this.logger.error("Error in Formatting the BPMN Date Format");
        }
        return new Date(nextReviewDate).toISOString().slice(0,19);
    }

    async requestForClinical(requestClinicalEventInput: RequestClinicalEventInput, httpRequest: HttpRequest): Promise<RequestClinicalEventOutput> {
        const requestClinicalEventOutput: RequestClinicalEventOutput = {
            letterDetailResponse: 'Event Published Successfully'
        };
        let eventResponse: any;
        try {
            eventResponse = await this.hscLetterEventService.pushHscLetterEvent(requestClinicalEventInput, httpRequest);
            this.logger.log("HscLetterEventResponse:" + eventResponse);
        } catch (err) {
            requestClinicalEventOutput.letterDetailResponse = 'Event Published Failed';
            this.logger.error("Error while calling pushHscLetterEvent " + err);
        }
        return requestClinicalEventOutput;
    }

    async publishLetterEvent(publishLetterEventRequest: PublishLetterEventRequest, httpRequest: HttpRequest): Promise<PublishLetterEventResponse> {
        const hscId = publishLetterEventRequest.hsc_id;
        const eventDateTime = new Date().toISOString();
        const dateInMs = Date.parse(eventDateTime);
        const eventId =  hscId + '' + dateInMs;
        const eventChannel = publishLetterEventRequest.eventChannel ?? LetterEventConstants.SEND_LETTER_EVENT_CHANNEL;
        const appUserId = publishLetterEventRequest.appUserId ?? this.configService.get<string>("ECP_CLIENT_ID");


        const letterContextFromRequest : any[] = [];

        publishLetterEventRequest.decisionIds.forEach((decisionId) => {
            letterContextFromRequest.push(
                {
                   "decisionID": decisionId,
                   "decisionCategory": LetterEventConstants.SEND_LETTER_EVENT_DECISION_CATEGORY_AUTO_LETTER
                }
            );
        });

        const sendLetterEventRequestBody = {
           "event_name": LetterEventConstants.SEND_LETTER_EVENT_NAME,
           "app_id": this.configService.get<string>('HEALTH_SERVICE_BUS_EVENT_APPLICATION_ID'),
           "event_id": eventId,
           "event_date_time": eventDateTime,
           "event_channel": eventChannel,
           "event_source": applicationConstants.CASE_WF_MGMT_UI_APP_NAME,
           "payload": [
               {
                   "requestHeader": {
                       "appUserID": appUserId,
                       "appName": applicationConstants.CASE_WF_MGMT_UI_APP_NAME,
                       "appVersion": applicationConstants.CASE_WF_MGMT_UI_APP_VERSION
                   },
                   "letterEventIdentifier": {
                       "requestID": hscId,
                       "idType": LetterEventConstants.SEND_LETTER_EVENT_ID_TYPE_HSC_ID,
                       "letterContext": letterContextFromRequest
                   }
               }
           ]
        }

        const response: PublishLetterEventResponse = { 'publishLetterEventResponse': "" };

        const eventPayloadServiceUrl = this.configService.get<string>('EVENT_PAYLOAD_SERVICE');

        const headerParams = { 'headers' : { 'Authorization' : httpRequest.headers['authorization'] }}

        try{
         const eventResponse = await axios.post(eventPayloadServiceUrl,sendLetterEventRequestBody,headerParams);
            if(eventResponse?.data?.success){
                response.publishLetterEventResponse='Letter request published';
            }
        }
        catch(err){
            this.logger.error("Error while calling CaseWF HealthService pushHscLetterEvent " + err);
            response.publishLetterEventResponse='Letter request failed ' + err;
        }

        return response;
    }
   
}
