import { Test, TestingModule } from '@nestjs/testing';
import { HttpRequest } from "@azure/functions";
import { LoggerModule } from "nestjs-pino";
import { RequestClinicalEventInput } from 'src/health-service/models/request-clinical-event-input';
import { HttpModule } from "@nestjs/common";
import { ConfigModule } from "@nestjs/config";
import { HscLetterEventService } from './hsc-letter-event.service';


describe('LetterEventService', () => {
    let service: HscLetterEventService;

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            imports: [LoggerModule.forRoot(), HttpModule, ConfigModule],
            providers: [HscLetterEventService],
        }).compile();

        service = module.get<HscLetterEventService>(HscLetterEventService);
    });

    it('should be defined', () => {
        expect(service).toBeDefined();
    });

    it('should call push hsc letter event', () => {
        let httpRequest: HttpRequest = { method: null, url: '/test?session_id=encryptedid', headers: { authorization: 'test token', 'x-hasura-role': 'testrole' }, query: { 'test': 'test' }, params: { 'test': 'test' } };
        const requestClinicalEventInput: RequestClinicalEventInput =
        {
            "requesterId":"sbamini",
            "hsc_id": 13596,
            "client_id": 1,
            "channel": "WEB",
            "fax_num": 1234,
            "email_id": "test@optum.com"

        };
        service.pushHscLetterEvent(requestClinicalEventInput, httpRequest).then((res) => {
            expect(res).toBeTruthy();
        });
    });

    it('generateEventId should should return value', () => {
        const eventId = 123;
        expect(service.generateEventId(eventId)).not.toBe(eventId);
      });

    it('should call prepare Hsc LetterEvent Request', () => {
        let httpRequest: HttpRequest = { method: null, url: '/test?session_id=encryptedid', headers: { authorization: 'test token', 'x-hasura-role': 'testrole' }, query: { 'test': 'test' }, params: { 'test': 'test' } };
        const requestClinicalEventInput: RequestClinicalEventInput =
        {
            "requesterId":"sbamini",
            "hsc_id": 13596,
            "client_id": 1,
            "channel": "WEB",
            "fax_num": 1234,
            "email_id": "test@optum.com"
        };
        service.prepareHscBusinessEventRequest(requestClinicalEventInput, httpRequest).then((res) => {
            expect(res).toBeTruthy();
        });
    });
});
