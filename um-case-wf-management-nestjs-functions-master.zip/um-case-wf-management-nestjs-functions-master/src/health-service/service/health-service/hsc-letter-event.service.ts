import { HttpService, Injectable } from '@nestjs/common';
import { HttpRequest } from '@azure/functions';
import { ConfigService } from '@nestjs/config';
import { LetterEventRequest } from 'src/health-service/models/LetterEventRequest';
import { RequestClinicalEventInput } from 'src/health-service/models/request-clinical-event-input';
import { Logger } from 'nestjs-pino';
import { HscBusEventName } from 'src/health-service/models/HscBusEventName';
import { BusinessEventRequest } from 'src/health-service/models/businessEventRequest';
import { HscConstants } from '../../shared/constants/hscConstants';

@Injectable()
export class HscLetterEventService {
  constructor(
    private readonly logger: Logger,
    private readonly configService: ConfigService,
    private readonly httpService: HttpService,
  ) { }

  async pushHscLetterEvent(
    event: RequestClinicalEventInput,
    httpRequest: HttpRequest,
  ) {
    if (event) {
      const businessEventRequest: BusinessEventRequest = await this.prepareHscBusinessEventRequest(
        event,
        httpRequest,
      );
      return await this.httpService
        .post(
          this.configService.get<string>('BUS_EVENT_PUBLISH_API'),
          businessEventRequest,
          {
            headers: { Authorization: httpRequest.headers['authorization'] },
          },
        )
        .toPromise();
    }
  }

  generateEventId(eventId) {
    const currentdate = new Date();
    const dateInMs = Date.parse(currentdate.toISOString());
    return eventId + '' + dateInMs;
  }

  async prepareHscBusinessEventRequest(
    requestClinicalEventInput : RequestClinicalEventInput,
    httpRequest: HttpRequest,
  ): Promise<BusinessEventRequest> {

    const eventId = this.generateEventId(requestClinicalEventInput.hsc_id);
    const letterEventRequest: LetterEventRequest = {
      requestHeader: {
        "appUserID": requestClinicalEventInput.requesterId,
        "appName": HscConstants.HSC_REQUEST_CLINICAL_APP_NAME,
        "appVersion": HscConstants.HSC_REQUEST_CLINICAL_APP_VERSION
      },
      letterEventIdentifier: {
        "requestID": requestClinicalEventInput.hsc_id,
        "idType": HscConstants.HSC_REQUEST_CLINICAL_ID_TYPE,
        "letterContext": [
          {
            "decisionID": HscConstants.HSC_REQUEST_CLINICAL_DECISION_ID,
            "decisionCategory": HscConstants.HSC_REQUEST_CLINICAL_DECISION_CATEGORY
          }
        ]
      }
    };
    const businessEventRequest: BusinessEventRequest = {
      event_name: HscBusEventName.HSC_LETTER_NOTIFICATION_EVENT,
      event_date_time: new Date().toISOString(),
      event_source: HscConstants.HSC_BUS_EVENT_EVENT_SOURCE,
      event_channel: HscConstants.HSC_BUS_EVENT_EVENT_CHANNEL,
      event_id: parseInt(eventId),
      payload: [letterEventRequest],
    };
    return businessEventRequest;
  }
}
