import {Controller, Get, Headers, HttpCode, Post, UploadedFile, UseInterceptors} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import {FileInterceptor} from "@nestjs/platform-express";
import {ProviderContractService} from "./provider-contract.service";
import {HttpRequest} from "@azure/functions";

@Controller('/providerContract')
export class ProviderContractController {
    constructor(
        private readonly providerContractService: ProviderContractService){
    }
    @Post('/upload')
    @HttpCode(200)
    @UseInterceptors(FileInterceptor('file',{dest:"./upload",}))
    async uploadFile(@UploadedFile() file: Express.Multer.File,@Headers() reqHeaders:HttpRequest) {
        return this.providerContractService.readAndConvertFileDataToJSON(file,reqHeaders);
    }
}

