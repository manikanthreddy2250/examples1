import { Test, TestingModule } from '@nestjs/testing';
import { ProviderContractService } from './provider-contract.service';
import { Injectable ,HttpService,HttpModule} from '@nestjs/common';
import {GraphQLClient} from "graphql-request/dist";
import {HttpMethod, HttpRequest} from "@azure/functions";
import {ProviderClient} from "../../shared/graphql/provider-domain/providerClient";
import {ProviderContractRequest} from "../../models/providerContractRequest";
import {of} from "rxjs";
import {getProvByMpin, insertContractMutation,
updateContractMutation,getProviderContract,deleteContractMutation,getLastCallDate} from '../../shared/graphql/provider-domain/providerQuery';
import {ReferenceClient} from "../../shared/graphql/referenceDomain/referenceClient";
import {ReferenceConstants} from "../../shared/constants/applicationConstants";
import { ConfigService } from '@nestjs/config';
import axios from "axios";
import {NRTRequest} from "../../models/nrtRequest";
import {NRTData} from "../../models/NRTData";
import {AxiosResponse} from 'axios';
import {LoggerModule} from "nestjs-pino";

class MockDGraphQLClient extends GraphQLClient{
  request(query: any, variables: any): Promise<any>{
    let resp;
    switch(query) {
      case deleteContractMutation:
      resp = {
          "delete_prov_contr_by_pk": {
            "prov_contr_id": 100
          },
          "delete_prov_ntwk_by_pk": {
            "prov_ntwk_id": 100
          }
      };
      break;
      case getProviderContract:
        resp = {
            "prov_contr": [
              {
                "prov_contr_id": 123,
                "prov_ntwk_id": 153
              }
            ]
        };
        break;
      case insertContractMutation:
        resp = {
          "insert_prov_ntwk":
            {
              "affected_rows": 2,
            }

        };
        break;
        case updateContractMutation:
            resp = {
                "update_prov_contr":
                {
                    "affected_rows": 1,
                }

            };
            break;
        case getProvByMpin:
            resp = {
                "lob_ref":[],
                "contract_paper_type_ref":[],
                "med_nec_restriction_ref":[],
            };
            break;
        case getLastCallDate:
        resp= {
            "prov_contr": [
                          {
                            "lst_call_dt":"2021-04-03T22:02:41.697"
                          }
                        ]
        };
        break;
      default:
           resp = {
              "prov_key": [{
                "prov": {
                  "prov_orgs": [{
                    "bus_nm": "LANGE ORTHOPAEDICS PC",
                    "prov_id": 921514
                  }]
                }
              }]
            };
        break;
    }
    return of(resp).toPromise();
  }
}

class MockProviderClient {
  public getGraphqlClient(httpRequest: HttpRequest): GraphQLClient {
    return new MockDGraphQLClient('testurl');
  }
}
class MockGraphQLClient extends GraphQLClient{
request(query: any, variables: any): Promise<any>{
    return of(
{
  "data": {
    "ref": [
      {
        "ref_id": 19972
      }
    ]
  }
}
).toPromise();
}
}

class MockAxios {
    get(url:any,header:any){
        return of({
        "data" :[
                    {
                                      "MPIN": "302922",
                                      "Tax_ID_TIN": "561303855",
                                      "Address_Seq_Num": "13",
                                      "Fac_Prov_Name_Primary": "FAYETTEVILLE VAMC",
                                      "State_CD": "NC",
                                      "LOB": 0,
                                      "Entity": "CIP\r\n",
                                      "Contract_Paper_Type": 0,
                                      "Eff_Dt": "2020-10-02T00:00:00",
                                      "Term_Dt": "0001-01-01T00:00:00",
                                      "Med_Nec_Restriction_Type_Name": 0,
                                      "Med_Nec_Restriction": "Y",
                                      "Lst_Call_Dt": "2021-04-02T22:02:41.697",
                                      "Insert_Dt": "2021-04-02T14:32:18.33",
                                      "Action_CD": "I",
                                      "Lst_Updt_By": "cstove2"
                                  }
                ]
        }).toPromise();
    }
}
class MockReferenceClient {
    public getGraphqlClient(httpRequest: HttpRequest): GraphQLClient {
        return new MockGraphQLClient('testurl');
    }
}
describe('ProviderContractService', () => {
  let service: ProviderContractService;
  let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid', headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
    let httpService:HttpService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [ProviderContractService,ConfigService,{provide: ProviderClient,useClass: MockProviderClient},{provide: ReferenceClient, useClass: MockReferenceClient},{provide: axios,useClass: MockAxios}],
      imports: [HttpModule, LoggerModule.forRoot()]
       }).compile();

    service = module.get<ProviderContractService>(ProviderContractService);
    httpService = module.get<HttpService>(HttpService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
  jest.mock('axios');
  it('should call getProviderContractData',  () => {

        const lst_call_dt="2021-04-03T22:02:41.697";
           const tokenResult: AxiosResponse = {
                           data: {
                               access_token:'123445566777asdsfdgfgf'
                           },
                           status: 200,
                           statusText: 'OK',
                           headers: {},
                           config: {},
                           };
           const url='https://gateway-stage.optum.com/api/dev/ext/nrt/mednecrestriction/v1/MedNecRestriction/get?lst_call_dt=2021-03-02T22:02:41.697';
         const nrtResponse={
        data: [{
                    "MPIN": "302922",
                    "Tax_ID_TIN": "561303855",
                    "Address_Seq_Num": "13",
                    "Fac_Prov_Name_Primary": "FAYETTEVILLE VAMC",
                    "State_CD": "NC",
                    "LOB": "COM",
                    "Entity": "CIP\r\n",
                    "Contract_Paper_Type": 0,
                    "Eff_Dt": "2020-10-02T00:00:00",
                    "Term_Dt": "0001-01-01T00:00:00",
                    "Med_Nec_Restriction_Type_Name": 0,
                    "Med_Nec_Restriction": "Y",
                    "Lst_Call_Dt": "2021-04-02",
                    "Insert_Dt": "2021-04-02",
                    "Action_CD": "I",
                    "Lst_Updt_By": "cstove2"
                }]

         };
       jest.spyOn(httpService, 'post').mockImplementationOnce(() => of(tokenResult));
       jest.spyOn(axios, 'get').mockImplementationOnce(async() => of(nrtResponse));
      service.getProviderContractData(httpRequest).then(data =>
        {
         expect(data.responseMessage[0]).toBe("1 Contracts Inserted");
       });
  });

    it('should retry only once if NRT API is down',  async() => {

        const tokenResult: AxiosResponse = {
            data: {
                access_token:'123445566777asdsfdgfgf'
            },
            status: 200,
            statusText: 'OK',
            headers: {},
            config: {},
        };

        const nrtResponse={
            data: {
            },
            status: 500,
            statusText: 'Internal Server Error',
            headers: {},
            config: {},
        };
        jest.spyOn(httpService, 'post').mockImplementationOnce(() => of(tokenResult));
        jest.spyOn(axios, 'get').mockImplementationOnce(async() => of(nrtResponse));
        service.getProviderContractData(httpRequest).then(data =>
        {
            expect(data.responseMessage[0]).toBe("undefind");
        });
    });

  it('should call convertToProviderRequest contract', () => {
    const providerRequest: NRTData[] = [{
             "MPIN": "302922",
             "Tax_ID_TIN": "561303855",
             "Address_Seq_Num": "13",
             "Fac_Prov_Name_Primary": "FAYETTEVILLE VAMC",
             "State_CD": "NC",
             "LOB": 0,
             "Entity": "CIP\r\n",
             "Contract_Paper_Type": 0,
             "Eff_Dt": "2020-10-02T00:00:00",
             "Term_Dt": "0001-01-01T00:00:00",
             "Med_Nec_Restriction_Type_Name": 0,
             "Med_Nec_Restriction": "Y",
             "Lst_Call_Dt": "2021-04-02T22:02:41.697",
             "Insert_Dt": "2021-04-02T14:32:18.33",
             "Action_CD": "I",
             "Lst_Updt_By": "cstove2"
         }];
         const providerContractRequestList: ProviderContractRequest[] = [];
         const providerContractRequest: ProviderContractRequest[] = [{
               "mpin": "7622279",
               "tin": "12",
               "addressSeqNum": "1",
               "facilityName": "LANGE ORTHOPAEDICS PC",
               "stateCode": "NJ",
               "lobRefId": 9999,
               "entityCode": "00",
               "contractPaperTypRefId": 9999,
               "effDate": "12-31-9999",
               "termDate": "12-31-9999",
               "medNecRestrictionTypRefId": 9999,
               "medNecRestriction": "9999",
               "lastCallDttm": "12-31-9999",
               "insertDttm": "12-31-9999",
               "actionCode": "I",
               "lastUpdatedBy": "test"
             }];
        service.convertToProviderRequest(providerRequest, httpRequest).then((res) => {
          expect(res).not.toBeNull();
        });
      });
  it('should call save contract', () => {
    const providerContractRequest: ProviderContractRequest[] = [{
      "mpin": "7622279",
      "tin": "12",
      "addressSeqNum": "1",
      "facilityName": "LANGE ORTHOPAEDICS PC",
      "stateCode": "NJ",
      "lobRefId": "COM",
      "entityCode": "00",
      "contractPaperTypRefId": 9999,
      "effDate": "12-31-9999",
      "termDate": "12-31-9999",
      "medNecRestrictionTypRefId": 9999,
      "medNecRestriction": "9999",
      "lastCallDttm": "12-31-9999",
      "insertDttm": "12-31-9999",
      "actionCode": "I",
      "lastUpdatedBy": "test"
    }];
    service.saveContract(providerContractRequest, httpRequest).then((res) => {
      expect(res.responseMessage[0]).toEqual("1 Contracts Inserted");
    });
  });

  it('should call save contract for update', () => {
    const providerContractRequest: ProviderContractRequest[] = [{
      "mpin": "7622279",
      "tin": "12",
      "addressSeqNum": "1",
      "facilityName": "LANGE ORTHOPAEDICS PC",
      "stateCode": "NJ",
      "lobRefId": "COM",
      "entityCode": "00",
      "contractPaperTypRefId": 9999,
      "effDate": "12-31-9999",
      "termDate": "12-31-9999",
      "medNecRestrictionTypRefId": 9999,
      "medNecRestriction": "9999",
      "lastCallDttm": "12-31-9999",
      "insertDttm": "12-31-9999",
      "actionCode": "U",
      "lastUpdatedBy": "test"
    }];
    service.saveContract(providerContractRequest, httpRequest).then((res) => {
      expect(res.responseMessage[0]).toEqual("1 Contracts Updated");
    });
  });
  it('should call save contract for delete', () => {
    const providerContractRequest: ProviderContractRequest[] = [{
      "mpin": "7622279",
      "tin": "12",
      "addressSeqNum": "1",
      "facilityName": "LANGE ORTHOPAEDICS PC",
      "stateCode": "NJ",
      "lobRefId": "COM",
      "entityCode": "00",
      "contractPaperTypRefId": 9999,
      "effDate": "12-31-9999",
      "termDate": "12-31-9999",
      "medNecRestrictionTypRefId": 9999,
      "medNecRestriction": "9999",
      "lastCallDttm": "12-31-9999",
      "insertDttm": "12-31-9999",
      "actionCode": "D",
      "lastUpdatedBy": "test"
    }];
    service.saveContract(providerContractRequest, httpRequest).then((res) => {
      expect(res.responseMessage[0]).toEqual("Contract deleted : prov_contr_id - 100 prov_ntwk_id - 100");
    });
  });
});
