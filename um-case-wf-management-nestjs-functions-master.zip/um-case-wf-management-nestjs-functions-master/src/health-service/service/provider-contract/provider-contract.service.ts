import { AzureFunction, Context, HttpRequest } from "@azure/functions"
import { Injectable,HttpService} from '@nestjs/common';
import {ProviderContractRequest} from "../../models/providerContractRequest";
import {ProviderContractResponse} from "../../models/providerContractResponse";
import {ProviderClient} from "../../shared/graphql/provider-domain/providerClient";
import {GraphQLClient} from "graphql-request/dist";
import {getProvByMpin, insertContractMutation,
updateContractMutation,getProviderContract,deleteContractMutation,getLastCallDate} from '../../shared/graphql/provider-domain/providerQuery';
import {healthServiceConstants} from '../../shared/constants/applicationConstants'
import * as XLSX from "xlsx";
import {NRTDataStructure} from "../../../configuration/models/NRTDataStructure";
import {NRTRequest} from "../../models/nrtRequest";
import {ReferenceClient} from "../../shared/graphql/referenceDomain/referenceClient";
import {ReferenceConstants} from "../../shared/constants/applicationConstants";
import { ConfigService } from '@nestjs/config';
import {NRTData} from "../../models/NRTData";
import {LOB_ENUM} from "../../shared/constants/NRT_Ref_Constants";
import axios from "axios";
import {Logger} from "nestjs-pino";

@Injectable()
export class ProviderContractService {

    providerClient: GraphQLClient;
    constructor(private readonly providerDomainClient: ProviderClient,private readonly configService: ConfigService,
                                                                private readonly referenceClient: ReferenceClient,
                                                                private readonly httpService: HttpService,
                                                                private readonly logger: Logger
                                                                ){}

    async getToken() {
        try {
            const dataResponse= await this.httpService.post(this.configService.get<string>('STARGATE_TOKEN_URL') + '?grant_type=client_credentials&client_id=' +
            this.configService.get<string>('STARGATE_ECP_CLIENT_ID') + '&client_secret=' +
            this.configService.get<string>('STARGATE_ECP_CLIENT_SECRET'),
            {},
            {}
            ).toPromise();

            return dataResponse.data.access_token;
        } catch (e) {
            this.logger.error("Error while calling CaseWF ProviderContractService getToken: " + e);
        }
    }

    async getProviderContractData(httpRequest:HttpRequest):Promise<ProviderContractResponse>{
        try {
            var apiResponse;
            var retry=false;
            const providerClient:GraphQLClient = this.providerDomainClient.getGraphqlClient(httpRequest);
            const last_call_date=await providerClient.request(getLastCallDate);
            const lst_call_dt=last_call_date.prov_contr[0]?.chg_dttm;
            const baseURL = this.configService.get<string>('NRT_API_BASE_URL');
            const token = await this.getToken();
            const url =baseURL+'?'+'lst_call_dt'+'='+lst_call_dt;
            const headerParams={
                               headers: {
                                   Authorization: `Bearer ${token}`
                               }
                               };


              do
               {
                await axios.get(url, headerParams).then((response)=>{
                apiResponse=response.data;
                         retry=false;
                    }).
                    catch(async function(error)
                    {
                        this.logger.log("getProviderContractData - Error Occurred While Triggerring NRT Api"+error.response?.data);
                       if(!(error.response?.status===404))
                       {
                        await new Promise(resolve => setTimeout(resolve, 30000));
                       retry=!retry;
                       }
                    });
             }while(retry)
              const nrtResponse:NRTData[]=apiResponse;
               const providerRequest= await this.convertToProviderRequest(nrtResponse,httpRequest);
              const saveContractResponse:ProviderContractResponse= await this.saveContract(providerRequest,httpRequest);
            return saveContractResponse;
        } catch (e) {
            this.logger.error("getProviderContractData - Error while calling CaseWF ProviderContractService getProviderContractData (httpRequest: " + httpRequest + ") " + e);
        }
    }

    async convertToProviderRequest(nrtList: NRTData[],httpRequest:HttpRequest) :Promise<any>{

       const providerContractRequestList: ProviderContractRequest[] = [];
       for (const nrtObj of nrtList) {
         const providerContractRequest: ProviderContractRequest = {
             mpin: nrtObj.MPIN?.toString(),
             tin: nrtObj.Tax_ID_TIN.toString(),
             addressSeqNum: nrtObj.Address_Seq_Num?.toString(),
             facilityName: nrtObj.Fac_Prov_Name_Primary,
             stateCode: nrtObj.State_CD,
             lobRefId: nrtObj.LOB,
             entityCode: nrtObj.Entity,
             contractPaperTypRefId: nrtObj.Contract_Paper_Type,
             effDate: nrtObj.Eff_Dt,
             termDate: nrtObj.Term_Dt,
             medNecRestrictionTypRefId: nrtObj.Med_Nec_Restriction_Type_Name,
             medNecRestriction: nrtObj.Med_Nec_Restriction,
             actionCode: nrtObj.Action_CD,
             lastCallDttm: nrtObj.Lst_Call_Dt,
             insertDttm: nrtObj.Insert_Dt,
             lastUpdatedBy: nrtObj.Lst_Updt_By
         };
           providerContractRequestList.push(providerContractRequest);

       }
       this.logger.log("::::contractresult::"+JSON.stringify(providerContractRequestList));
       return providerContractRequestList;
    }

    async saveContract(providerContractRequests: ProviderContractRequest[], httpRequest: HttpRequest): Promise<ProviderContractResponse> {
        try {
            this.providerClient = this.providerDomainClient.getGraphqlClient(httpRequest);
            var response = new ProviderContractResponse();
    
            const inputRows:any[] = [];
            try {
                for (const providerContractRequest of providerContractRequests) {
                    const providerMpin = providerContractRequest.mpin;
                    await this.populateRefValues(providerContractRequest);
    
                    switch(providerContractRequest.actionCode){
                        case 'I':
                            const contractPaperTypRefId = this.populateDefaultContractPaperType(providerContractRequest);
                            const src_rec_guid =
                                "mpin:" + providerContractRequest.mpin + "|" +
                                "tin:" + providerContractRequest.tin +  "|" +
                                "addSeqNum:" + providerContractRequest.addressSeqNum +  "|" +
                                "facilityName:" + providerContractRequest.facilityName +  "|" +
                                "stateCode:" + providerContractRequest.stateCode +  "|";
    
                            inputRows.push(
                                {
                                    "lob_ref_id": providerContractRequest.lobRefId,
                                    "bus_seg_nm": providerContractRequest.entityCode,
                                    "chg_dttm": providerContractRequest.lastCallDttm,
                                    "creat_dttm": providerContractRequest.insertDttm,
                                    "prov_contrs": {
                                        "data": {
                                            "med_nec_rev_claus_ref_id": providerContractRequest.medNecRestrictionTypRefId,
                                            "prov_reim_typ_ref_id": contractPaperTypRefId,
                                            "end_dt": providerContractRequest.termDate,
                                            "strt_dt": providerContractRequest.effDate,
                                            "chg_dttm": providerContractRequest.lastCallDttm,
                                            "creat_dttm": providerContractRequest.lastCallDttm,
                                            "src_rec_guid": src_rec_guid,
                                        }
                                    }
                                }
                            );
                        break;
                        case 'U':
                            const src_rec_guid_u =
                                "mpin:" + providerContractRequest.mpin + "|" +
                                "tin:" + providerContractRequest.tin +  "|%" ;
                            const updateBody = {
                                    "_set": {
                                        "strt_dt": providerContractRequest.effDate,
                                        "end_dt": providerContractRequest.termDate,
                                        "chg_dttm": providerContractRequest.lastCallDttm,
                                    },
                                    "_src_rec_guid": src_rec_guid_u,
                                    "_med_nec_rev_claus_ref_id": providerContractRequest.medNecRestrictionTypRefId,
                                    "_lob_ref_id": providerContractRequest.lobRefId,
                                    "_bus_seg_nm": providerContractRequest.entityCode
    
                            };
                            const updateResponse = await this.providerClient.request(updateContractMutation, updateBody);
                            response.responseMessage.push(updateResponse?.update_prov_contr?.affected_rows + " Contracts Updated");
    
                        break;
                        case 'D':
                            const src_rec_guid_d =
                                "mpin:" + providerContractRequest.mpin + "|" +
                                "tin:" + providerContractRequest.tin +  "|%" ;
                            const getContractbody = {
                                "_src_rec_guid": src_rec_guid_d,
                                "_med_nec_rev_claus_ref_id": providerContractRequest.medNecRestrictionTypRefId,
                                "_lob_ref_id": providerContractRequest.lobRefId,
                                "_bus_seg_nm": providerContractRequest.entityCode
                            };
                            const provContractData  = await this.providerClient.request(getProviderContract, getContractbody);
                            if(provContractData?.prov_contr?.length > 0){
                                const deleteBody = {
                                    "prov_contr_id": provContractData?.prov_contr[0]?.prov_contr_id,
                                    "prov_ntwk_id": provContractData?.prov_contr[0]?.prov_ntwk_id
                                };
                                const deleteResponse = await this.providerClient.request(deleteContractMutation, deleteBody);
    
                                response.responseMessage.push("Contract deleted : prov_contr_id - " + deleteResponse?.delete_prov_contr_by_pk?.prov_contr_id +
                                                            " prov_ntwk_id - " + deleteResponse?.delete_prov_ntwk_by_pk?.prov_ntwk_id);
                            }
                        break;
                    }
                }
                    if(inputRows?.length > 0) {
                        const mutationBody = {
                            "inputArray": inputRows
                        };
                            const insertResponse = await this.providerClient.request(insertContractMutation, mutationBody);
                            const affectedRows = insertResponse?.insert_prov_ntwk?.affected_rows;
                            response.responseMessage.push( affectedRows/2 + " Contracts Inserted");
                    }
                }catch (err) {
                    response.responseMessage.push("Error in saveContracts : " + err);
                    this.logger.error("Error while calling CaseWF ProviderContractService saveContract (providerContractRequests: " + providerContractRequests + ", httpRequest: " + httpRequest + ") " + err);
                }
            return response;
        } catch (e) {
            this.logger.error("Error while calling CaseWF ProviderContractService saveContract (providerContractRequests: " + providerContractRequests + ", httpRequest: " + httpRequest + ") " + e);
        }
    }

    populateDefaultContractPaperType(providerContractRequest: ProviderContractRequest): number {
        let contractPaperTypRefId = providerContractRequest.contractPaperTypRefId;
        if(providerContractRequest.lobRefId === healthServiceConstants.LOB_TYPE_MNR_REF_ID){
            if(providerContractRequest.stateCode === healthServiceConstants.STATE_CODE_MARYLAND){
                contractPaperTypRefId = healthServiceConstants.CONTRACT_PAPER_TYPE_PER_DIEM_REF_ID;
            }
            else{
                contractPaperTypRefId = healthServiceConstants.CONTRACT_PAPER_TYPE_DRG_REF_ID;
            }
        }
        return contractPaperTypRefId;
    }

    async populateRefValues(providerContractRequest: ProviderContractRequest) {
        try {
            const lob_ref_disp = this.validateLOBRefDisp(providerContractRequest.lobRefId);
            const contract_paper_type_disp=providerContractRequest.contractPaperTypRefId;
            const mednec_restriction_ref_desc=providerContractRequest.medNecRestrictionTypRefId;
            const lob_base_ref_nm=ReferenceConstants.LOB_BASE_REF_NAME;
            const mednec_base_ref_nm=ReferenceConstants.MEDNEC_RESTRICTION_BASE_REF_NAME;
            const contract_papertype_base_ref_nm=ReferenceConstants.CONTRACT_PAPER_TYPE_BASE_REF_NAME;
            const body = {
                lobRefDisp:lob_ref_disp,
                contractPaperTypeRefDisp:contract_paper_type_disp,
                mednecRestrictionRefDesc:mednec_restriction_ref_desc,
                lobBaseRefNm:lob_base_ref_nm,
                contractPaperTypeBaseRefNm:contract_papertype_base_ref_nm,
                mednecBaseRefNm:mednec_base_ref_nm
            };
            const provData  = await this.providerClient.request(getProvByMpin, body);
            const lob_ref_id=provData.lob_ref[0]?provData.lob_ref[0].ref_id:0
            const contract_paper_type_ref_id = provData.contract_paper_type_ref[0]?provData.contract_paper_type_ref[0].ref_id:0;
            const med_nec_restriction_ref_id = provData.med_nec_restriction_ref[0]?provData.med_nec_restriction_ref[0].ref_id:0;
            providerContractRequest.lobRefId=lob_ref_id;
            providerContractRequest.contractPaperTypRefId=contract_paper_type_ref_id;
            providerContractRequest.medNecRestrictionTypRefId=med_nec_restriction_ref_id;
        } catch (e) {
            this.logger.error("Error while calling CaseWF ProviderContractService populateRefValues (providerContractRequest: " + providerContractRequest + ") " + e);
        }
    }

    async readAndConvertFileDataToJSON(file: Express.Multer.File,request:any){
        try {
            const wb: XLSX.WorkBook = XLSX.readFile(file.path,{cellDates:true});
            const wsname: string = wb.SheetNames[0];
            const ws: XLSX.WorkSheet = wb.Sheets[wsname];
            const data:NRTDataStructure[] = XLSX.utils.sheet_to_json(ws);
            const providerContractRequest: ProviderContractRequest[] = await this.convertToProviderRequestForm(data);
            const response = await this.saveContract(providerContractRequest,request);
            return JSON.stringify(response);
        } catch (e) {
            this.logger.error("Error while calling CaseWF ProviderContractService readAndConvertFileDataToJSON (file: " + file + ", request: " + request + ") " + e);
        }
    }

    async convertToProviderRequestForm(nrtList: NRTDataStructure[]) {
        const providerContractRequestList: ProviderContractRequest[] = [];
        for (const nrtObj of nrtList) {
            const providerContractRequest: ProviderContractRequest = {
                mpin: nrtObj.MPIN?.toString(),
                tin: nrtObj.TAX_ID_TIN?.toString(),
                addressSeqNum: nrtObj.Address_Seq_Num?.toString(),
                facilityName: nrtObj.Fac_Prov_Name_Primary,
                stateCode: nrtObj.State_CD,
                lobRefId: nrtObj.LOB,
                entityCode: nrtObj.Entity,
                contractPaperTypRefId: nrtObj.Contract_Paper_Type,
                effDate: nrtObj.Eff_Dt,
                termDate: nrtObj.Term_Dt==='NULL'?'0001-01-01':nrtObj.Term_Dt,
                medNecRestrictionTypRefId: nrtObj.Med_Nec_Restriction_Type_Name,
                medNecRestriction: nrtObj.Med_Nec_Restriction,
                actionCode: nrtObj.Action_Cd,
                lastCallDttm: nrtObj.Lst_Call_Dt,
                insertDttm: nrtObj.Insert_Dt,
                lastUpdatedBy: nrtObj.Lst_Updt_By
            };
            providerContractRequestList.push(providerContractRequest);
        }
        return providerContractRequestList;
    }
    
    validateLOBRefDisp(lob_ref:string):any{
        if(lob_ref.startsWith('COM')){
            return LOB_ENUM.COM;
            }
        else if(lob_ref.startsWith('MCR')){
            return LOB_ENUM.MCR;
        }
        else if(lob_ref.startsWith('MCD')){
            return LOB_ENUM.MCD;
        }
        else if(lob_ref.startsWith('Dual')){
            return LOB_ENUM.Dual;
        }
        else if(lob_ref.startsWith('GDCH')){
            return LOB_ENUM.GDCH;
        }

        else {
            return lob_ref;
        }
    }
}
