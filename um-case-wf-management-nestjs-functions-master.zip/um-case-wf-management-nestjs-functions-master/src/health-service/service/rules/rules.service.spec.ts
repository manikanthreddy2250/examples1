import { Test, TestingModule } from '@nestjs/testing';
import { RulesService } from './rules.service';
import {ConfigService} from "@nestjs/config";
import {LoggerModule} from "nestjs-pino";
import axios from "axios";
import {Observable, of} from "rxjs";

import { HttpRequest } from "@azure/functions";
class MockAxios {
  post(url:any, body:any, header:any): Promise<any>{
      return of({
      "data" :[
                  {
                      "LosCheck":"actualDischargeDate",
                      "requiredDateChecks":"admitdate",
                      "requiredProviders":3761
                  }
              ]
      }).toPromise();
  }
}
describe('RulesService', () => {
  let service: RulesService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      imports: [LoggerModule.forRoot()],
      providers: [ConfigService ,RulesService, {provide: axios,useClass: MockAxios}],
    }).compile();

    service = module.get<RulesService>(RulesService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
  it('should call getDmnRuleResult', () => {
   // spyOn(service, "getFunctionalRole").and.returnValue(Promise.resolve(""));
    const getDmnRuleResult = service.getDmnRuleResult({},{},"123");
    expect(getDmnRuleResult).toBeDefined();
  });
  it('should call getFunctionalRole', () => {
    // spyOn(service, "getFunctionalRole").and.returnValue(Promise.resolve(""));
     const getDmnRuleResult = service.getFunctionalRole("123");
     expect(getDmnRuleResult).toBeDefined();
   });
  
it('should call getDmnRuleResult', () => {
   spyOn(service, "getFunctionalRole").and.returnValue(Promise.resolve(""));
 
  let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole', 'x-bpm-cli-org-id':'ecp'}, query: {'test':'test'}, params: {'test':'test'}};
 
   const getDmnRuleResult = service.getDmnRuleResult(httpRequest,{},"123");
   expect(getDmnRuleResult).toBeDefined();
 });

it('should call getDmnRuleResult', () => {
  spyOn(service, "getFunctionalRole").and.returnValue(Promise.resolve(""));

 let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole', 'x-bpm-cli-org-id':''}, query: {'test':'test'}, params: {'test':'test'}};

  const getDmnRuleResult = service.getDmnRuleResult(httpRequest,{},"123");
  expect(getDmnRuleResult).toBeDefined();
});
});
