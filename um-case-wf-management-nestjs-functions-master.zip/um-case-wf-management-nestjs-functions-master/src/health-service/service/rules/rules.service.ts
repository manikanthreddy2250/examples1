import { Injectable } from '@nestjs/common';
import {ConfigService} from "@nestjs/config";
import {applicationConstants} from "../../shared/constants/applicationConstants";
import axios from "axios";
import {EcpClaim} from "@ecp/func-tk/src/lib/authorization-services/models/EcpClaim";
import {AuthorizationService} from "@ecp/func-tk/dist";
import {EcpTokenFeilds} from "@ecp/func-tk/src/lib/authorization-services/models/EcpTokenFeilds";
import { Logger } from "nestjs-pino";
@Injectable()
export class RulesService {
    constructor(private configService: ConfigService , private readonly logger: Logger){

    }
   
    async    getDmnRuleResult(httpRequest : any , body : any, dmnId : any): Promise<any> {
        let configResponse;
        const rulesUri = this.configService.get<string>('UM_RULES_ENDPOINT');
        const configHttpUrl = rulesUri + dmnId +  "/evaluate";

        const orgId = httpRequest.headers['x-bpm-cli-org-id'];
        const authorizationHeader = httpRequest.headers['authorization'];
        const token = authorizationHeader.replace("Bearer " , "");

        const bpmFunctionalRole = await this.getFunctionalRole(token);

        let tenantId = "";
        if(orgId == 'ecp'){
            tenantId = applicationConstants.ECP_BASE_DMN_TENENT_ID;
        }
        else {
            // TenantId is combination of orgId + 'umcasemgmt' + orgId + 'dmngrp'. ex - uhcumcasemgmtuhcdmngrp
            tenantId = orgId +  applicationConstants.UM_CASE_MGMT + orgId + applicationConstants.DMN_GRP
        }

        const headerParams  = { 'headers' : {
                'Content-Type': 'application/json',
                'x-bpm-cli-org-id': orgId,
                'x-bpm-func-role': bpmFunctionalRole,
                'x-bpm-tenant-id': tenantId,
                'x-bpm-external-ref-id': 'case_mgmt_rule_evaluation',
                'x-bpm-source': 'case_wf_mgmt_ui',
                'Authorization' : httpRequest.headers['authorization']
            }};
        await axios.post(configHttpUrl, body, headerParams).then(function (response) {
            configResponse = response.data;
        })
            .catch(function (error) {
                this.logger.log("Error Occured while extracting DMN Data" , error);
                
            });
        return configResponse;

    }
    async   getFunctionalRole(ecptoken: any): Promise<string> {
        const ecpClaim: EcpClaim = await AuthorizationService.getEcpClaim(ecptoken, this.configService.get<string>('JWK_URI'), this.configService.get<string>('ISSUER'));
        // Status of the decoded token will tell us if token is valid
        const authenticated: boolean = ecpClaim[EcpTokenFeilds.STATUS] === 'success' ? true : false;
        // Check for role only if token is valid
        if (authenticated) {
            const orgs: any[] = ecpClaim.message[EcpTokenFeilds.ECP_CLI_ORGS] || [];
            //console.log(":::: Bpm functional role: " + orgs[0][EcpTokenFeilds.FUNC_ROLES][0][EcpTokenFeilds.ROLE_NAME]);
            return orgs[0][EcpTokenFeilds.FUNC_ROLES][0][EcpTokenFeilds.ROLE_NAME];

        } else {
            //console.log(":::: Failed to derive Bpm functional role from token");
            return ""
        }
    }
}
