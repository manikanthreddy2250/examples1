import {Test, TestingModule} from '@nestjs/testing';
import {ConfigModule, ConfigService} from '@nestjs/config';
import {HttpModule, UnauthorizedException} from '@nestjs/common';
import {LoggerModule} from 'nestjs-pino';
import axios from 'axios';
import {CamundaSignalService, Client} from './camunda.signal.service';
import {DischargeSignalRequest} from '../../models/signal/dischargeSignal.request';
import {DomainConstants} from '../../../configuration/constants/domainConstants';
import {EcpClaim} from '@ecp/func-tk/src/lib/authorization-services/models/EcpClaim';
import {AuthorizationService} from '@ecp/func-tk/dist';
import assert = require('assert');
import { of as observableOf } from 'rxjs';
import { DocumentReceivedSignalRequest } from 'src/health-service/models/signal/documentRecievedSignal.request';

jest.mock('axios');
const tokenObject = {
    scope: null,
    facility: 'UNITEDHEALTHGROUP1',
    access_token: 'eyJraWQiOiI5NjEwNTdjMy1lMjNkLTRhYzItOGNhMi1iNDg0OTgzZWY1MWEiLCJhbGciOiJSUzUxMiJ9.eyJ4LWVjcC1jbGFpbXMiOnsieC1lY3AtYXR0cnMiOnt9LCJ4LWVjcC1hbHQtdXNlci1pZCI6InVtX2VjcF9jbGllbnRfbm9uX3Byb2QiLCJ4LWVjcC1jbGktb3JncyI6W3sib3JnLWlkIjoiZWNwIiwiZnVuYy1yb2xlcyI6W3sicm9sZS1uYW1lIjoidW1fZWNwX3N5c3RlbSIsImFwcGwtcm9sZXMiOlsiY2FzZV93Zl9tZ210X3VpX3N5c3RlbSIsInJ1bGVzX2F1dGhvcmluZ193cml0ZSIsInN5c3RlbV9tZ210X3VzZXIiLCJ1bV9jYXNlX21nbXRfYmFzZV9icG1fZ3JwX2V4ZWN1dGVfYWxsIiwidW1fY2FzZV9tZ210X2Jhc2VfZG1uX2dycF9leGVjdXRlX2FsbCIsInVtX2ludGFrZV9iYXNlX3Byb2R1Y3RfYnBtX2dycF9leGVjdXRlX2FsbCIsInVtX2ludGFrZV9iYXNlX3Byb2R1Y3RfZG1uX2dycF9leGVjdXRlX2FsbCIsInVtX2ludGFrZV91aV9jbGluaWNpYW4iXX1dfV0sIngtZWNwLXR5cGUiOiJDTElFTlRfQ1JFREVOVElBTFMiLCJ4LWVjcC11c2VyLWlkIjoidW1fZWNwX2NsaWVudF9ub25fcHJvZCJ9LCJodHRwczpcL1wvaGFzdXJhLmlvXC9qd3RcL2NsYWltcyI6eyJ4LWhhc3VyYS1kZWZhdWx0LXJvbGUiOiJjYXNlX3dmX21nbXRfdWlfc3lzdGVtIiwieC1oYXN1cmEtYXR0cnMiOiJ7IH0iLCJ4LWhhc3VyYS1jbGktb3JnIjoiZWNwIiwieC1oYXN1cmEtdXNlci1pZCI6InVtX2VjcF9jbGllbnRfbm9uX3Byb2QiLCJ4LWhhc3VyYS1mdW5jLXJvbGUiOiJ1bV9lY3Bfc3lzdGVtIiwieC1oYXN1cmEtYWxsb3dlZC1yb2xlcyI6WyJjYXNlX3dmX21nbXRfdWlfc3lzdGVtIiwicnVsZXNfYXV0aG9yaW5nX3dyaXRlIiwic3lzdGVtX21nbXRfdXNlciIsInVtX2Nhc2VfbWdtdF9iYXNlX2JwbV9ncnBfZXhlY3V0ZV9hbGwiLCJ1bV9jYXNlX21nbXRfYmFzZV9kbW5fZ3JwX2V4ZWN1dGVfYWxsIiwidW1faW50YWtlX2Jhc2VfcHJvZHVjdF9icG1fZ3JwX2V4ZWN1dGVfYWxsIiwidW1faW50YWtlX2Jhc2VfcHJvZHVjdF9kbW5fZ3JwX2V4ZWN1dGVfYWxsIiwidW1faW50YWtlX3VpX2NsaW5pY2lhbiJdfSwic2NvcGUiOiJvcGVuaWQiLCJpc3MiOiJlY3AtZGV2IiwiZXhwIjoxNjIxOTAwNDI5LCJjbGllbnRfaWQiOiJ1bV9lY3BfY2xpZW50X25vbl9wcm9kIn0.rQmyWqKhDLx1v8-m_GV-ZELCwdp-XxAqBcADGH1D74rD_0tOioxsfDqr8n9quBBwmQ5sTXvrBHnl2mQL2YxXhrjp___0lz4T51NZBNxXaCRq3_bZtFMogxol-Bg1GqZShEJq3HIdRN5SVSX_Lh6yfMfenk67bwLsWpkdzCnwmRtXG3w85KbVOjkce0c1xt9vjdKEu5Rv3FYKMbyTFBquxkT3K8yJ4kiOBCf05kym1Sjd3_xpzlZVJLpXJCf0BzuX6u9xP4125sxx_g-77iJbRf4UaNO3vB8TAf3_QSNwVGIwcpW_B3YAClbaNJWVvqKXPmm7jvOp5Do0wiz2o79a3w',
    token_type: 'Bearer',
    expires_in: 300,
    refresh_token: null,
};
const ecpClaims: EcpClaim = {
    "status": "success",
    "message": {
        "x-ecp-attrs": {},
        "x-ecp-alt-user-id": "um_ecp_client_non_prod",
        "x-ecp-cli-orgs": [{
            "org-id": "ecp",
            "func-roles": [{
                "role-name": "um_ecp_system",
                "appl-roles": ["case_wf_mgmt_ui_system", "rules_authoring_write", "system_mgmt_user", "um_case_mgmt_base_bpm_grp_execute_all", "um_case_mgmt_base_dmn_grp_execute_all", "um_intake_base_product_bpm_grp_execute_all", "um_intake_base_product_dmn_grp_execute_all", "um_intake_ui_clinician"]
            }]
        }],
        "x-ecp-type": "CLIENT_CREDENTIALS",
        "x-ecp-user-id": "um_ecp_client_non_prod"
    }
};
const dischargeSignalRequest: DischargeSignalRequest = {
    "hsc_id": 11186,
    "client": "ecp"
};
const documentReceivedSignalRequest: DocumentReceivedSignalRequest = {
    "hsc_id": 11186,
    "client": "ecp"
};
const reqHeader = {
    'Content-Type': DomainConstants.CONTENT_TYPE,
    'Accept': DomainConstants.CONTENT_TYPE,
    'authorization': "authorization",
    'x-bpm-cli-org-id': "ecp",
    'x-bpm-func-role': "um_ecp_system",
    'x-bpm-tenant-id': "x-bpm-tenant-id",
    //'x-bpm-external-ref-id': GlobalConstants.X_BPM_EXTERNAL_REF_ID,
    'x-bpm-workflow': "workflow"
};
const clientMap: Map<string, Client> = new Map([
    ["ECP", new Client('ECP_CLIENT_ID', 'ECP_CLIENT_SECRET', "ecpumcasemgmtbasebpmgrp")]
]);
const client: Client = {'clientId':"ECP_CLIENT_ID", 'clientSecret':'ECP_CLIENT_SECRET', 'tenantId':"ecpumcasemgmtbasebpmgrp"};
const emptyClient: Client = {'clientId':"", 'clientSecret':"", 'tenantId':""};
describe('CamundaSignalService', () => {
    let service: CamundaSignalService;
    let authorizationService: AuthorizationService;

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            imports: [ConfigModule, HttpModule, LoggerModule.forRoot()],
            providers: [CamundaSignalService, ConfigService, AuthorizationService],
        }).compile();

        service = module.get<CamundaSignalService>(CamundaSignalService);
        authorizationService = module.get<AuthorizationService>(AuthorizationService);
    });

    it('should be defined', () => {
        expect(service).toBeDefined();
    });

    it('should receive request for dischargeSignalRequest', () => {
        const request: any = {headers: {}};
        spyOn(service, 'getToken').and.returnValue(observableOf(tokenObject.access_token));
        spyOn(service, 'getFunctionalRole').and.returnValue(observableOf(''));
        spyOn(CamundaSignalService, 'getCamundaBpmHttpHeaders').and.returnValue(observableOf({}));
        spyOn(service.httpService, 'post').and.returnValue(observableOf({
                status: 200,
                statusText: 'OK',
        }));
        service.sendDischargeNotificationSignal(dischargeSignalRequest, request).then((res) => {
            expect(res).toBeTruthy();
        });
    });
 


    it('should receive error for send discharge signal request', () => {
        const request: any = {headers: {}};
        spyOn(service, 'getToken').and.returnValue(observableOf(tokenObject.access_token));
        spyOn(CamundaSignalService, 'getCamundaBpmHttpHeaders').and.returnValue(observableOf({}));
        spyOn(service.httpService, 'post').and.returnValue(observableOf({
            status: 200,
            statusText: 'OK',
        }));
        service.sendDischargeNotificationSignal(dischargeSignalRequest, request).then((res) => {
            expect(res).toBeTruthy();
        });
    });
    it('should receive request for document Received Signal Request', () => {
        const request: any = {headers: {}};
        spyOn(service, 'getToken').and.returnValue(observableOf(tokenObject.access_token));
        spyOn(service, 'getFunctionalRole').and.returnValue(observableOf(''));
        spyOn(CamundaSignalService, 'getCamundaBpmHttpHeaders').and.returnValue(observableOf({}));
        spyOn(service.httpService, 'post').and.returnValue(observableOf({
                status: 200,
                statusText: 'OK',
        }));
        service.sendDocumentReceivedSignal(documentReceivedSignalRequest, request).then((res) => {
            expect(res).toBeTruthy();
        });
    });


    it('fetches token successfully data from an API', async () => {
        const data = {
            data: tokenObject,
        };
        spyOn(CamundaSignalService, 'getClientMap').and.returnValue(client);
        spyOn(service.httpService, 'post').and.returnValue(observableOf({
            data: {
                access_token: tokenObject.access_token
            }
        }));
        (axios.get as jest.Mock).mockResolvedValueOnce(data);
        service.getToken(client).then((res) => {
            expect(res).toBeTruthy();
        });
    });

    it('returns valid token successfully data from an API', async () => {
        const data = {
            data: tokenObject,
        };
        spyOn(CamundaSignalService, 'getClientMap').and.returnValue(client);
        spyOn(service.httpService, 'post').and.returnValue(observableOf({
            data: {
                access_token: tokenObject.access_token
            }
        }));
        (axios.get as jest.Mock).mockResolvedValueOnce(data);
        service.getToken(client).then((res) => {
            const response  = res;
                expect(response).toEqual(data.data.access_token);
        });
    });

    it('returns valid token successfully defaulting to ECP token', async () => {
        const data = {
            data: tokenObject,
        };
        spyOn(CamundaSignalService, 'getClientMap').and.returnValue(emptyClient);
        spyOn(service.httpService, 'post').and.returnValue(observableOf({
            data: {
                access_token: tokenObject.access_token
            }
        }));
        //(axios.get as jest.Mock).mockResolvedValueOnce(data);
        service.getToken( emptyClient).then((res) => {
            const response  = res;
            expect(response).toEqual(data.data.access_token);
        });
    });

    it('returns error while fetching ECP token', async () => {
        const data = {
            data: tokenObject,
        };
        spyOn(CamundaSignalService, 'getClientMap').and.returnValue(emptyClient);
        // spyOn(service.httpService, 'post').and.returnValue(Observable.throw(''));
        jest.spyOn(service.httpService, 'post').mockImplementationOnce(() => { throw {response : { data : {error: '' }}}; });
        await service.getToken(emptyClient).catch(error => expect(UnauthorizedException));
        //expect(service).toBeTruthy();
    });

    it('fetches header information successfully from request', async () => {
        const request = {
            headers: reqHeader,
        };
        const headers = CamundaSignalService.getCamundaBpmHttpHeaders(dischargeSignalRequest, request, tokenObject.access_token, client, "um_ecp_system");
        assert.equal(headers['x-bpm-func-role'], "um_ecp_system");
    });

    it('fetches header information successfully from empty request', async () => {
        const request = { headers: {}};
        const headers = CamundaSignalService.getCamundaBpmHttpHeaders(undefined, request, tokenObject.access_token, undefined, "");
        assert.equal(headers['x-bpm-func-role'], "um_ecp_system");
    });

    it("get Functional role from ecp token", async() => {

        spyOn(AuthorizationService,'getEcpClaim').and.returnValue(ecpClaims);
        service.getFunctionalRole(tokenObject.access_token).then((res) => {
            expect(res).toBeTruthy();
        })
    })

    it("get Functional role for invalid ecp token", async() => {
        ecpClaims.status = 'fail';
        spyOn(AuthorizationService,'getEcpClaim').and.returnValue(ecpClaims);
        service.getFunctionalRole(tokenObject.access_token).then((res) => {
            expect(res).toBeTruthy();
        })
    })
})
;
