import {HttpService, Injectable, UnauthorizedException} from '@nestjs/common';
import {ConfigService} from '@nestjs/config';
import {DomainConstants} from '../../../configuration/constants/domainConstants';
import {AuthorizationService} from "@ecp/func-tk/dist";
import {EcpClaim} from '@ecp/func-tk/src/lib/authorization-services/models/EcpClaim';
import {EcpTokenFeilds} from '@ecp/func-tk/src/lib/authorization-services/models/EcpTokenFeilds';
import {DischargeSignalResponse} from '../../models/signal/dischargeSignal.response';
import { DocumentReceivedSignalResponse } from 'src/health-service/models/signal/documentReceivedSignal.response';
import {Logger} from "nestjs-pino";

export class Client {
    constructor(readonly clientId: string, readonly clientSecret: string, readonly  tenantId: string) {
    }
}

@Injectable()
export class CamundaSignalService {
    static CLIENT_CREDENTIALS = "client_credentials";
    static CLIENT_ID = "&client_id=";
    static CLIENT_SECRET = "&client_secret=";
    static DISCHARGE_NOTIFICATION = "dischargeNotification-";
    static DOCUMENT_RECEIVED_NOTIFICATION="documentReceivedNotification-";
    static CONTEXTLABEL = ", context: ";
    signalUrl: any;
    signalResponse:any;
    bpmnSignalResponse:any;
    signalReqName:any;

    constructor(public readonly configService: ConfigService, public readonly httpService: HttpService, public readonly logger: Logger) {
        this.signalUrl = this.configService.get<string>('SIGNAL_BPM_URL');
    }

    static getClientMap(clientId): Client {
        const clientMap: Map<string, Client> = new Map([
            ["ECP", new Client('ECP_CLIENT_ID', 'ECP_CLIENT_SECRET', "ecpumcasemgmtbasebpmgrp")]
        ]);
        return clientMap.get(clientId);
    }

    async sendDischargeNotificationSignal(dischargeSignalRequest: any, context: any): Promise<DischargeSignalResponse> {
        const response: DischargeSignalResponse = {'dischargeSignalResponse': ""};
        try {
            this.signalReqName=CamundaSignalService.DISCHARGE_NOTIFICATION + dischargeSignalRequest.hsc_id;
            response.dischargeSignalResponse =await this.sendBpmnSignal(dischargeSignalRequest,context, this.signalReqName);
        } catch (ex) {
            this.logger.error("Error while calling CaseWF CamundaSignalService sendDischargeNotificationSignal (dischargeSignalRequest: " + dischargeSignalRequest + CamundaSignalService.CONTEXTLABEL + context + ") " + ex);
            throw ex;
        }
        return response
    }

    async sendDocumentReceivedSignal(documentReceivedSignalRequest: any, context: any): Promise<DocumentReceivedSignalResponse> {
        const response: DocumentReceivedSignalResponse = {'documentRecievedSignalResponse': ""};
        try {
            this.signalReqName=CamundaSignalService.DOCUMENT_RECEIVED_NOTIFICATION + documentReceivedSignalRequest.hsc_id;
            response.documentRecievedSignalResponse =await this.sendBpmnSignal(documentReceivedSignalRequest,context, this.signalReqName);
        } catch (ex) {
            this.logger.error("Error while calling CaseWF CamundaSignalService sendDocumentReceivedSignal (documentReceivedSignalRequest: " + documentReceivedSignalRequest + CamundaSignalService.CONTEXTLABEL + context + ") " + ex);
            throw ex;
        }
        return response
    }

    async sendBpmnSignal(signalRequest: any, context: any, signalReqName: any) {
        try {
            const clientCredentials: Client = CamundaSignalService.getClientMap(signalRequest.client?.toUpperCase());
            const ecpToken = await this.getToken(clientCredentials);
            const camundaBpmHeaders = CamundaSignalService.getCamundaBpmHttpHeaders(signalRequest, context.req, ecpToken, clientCredentials, await this.getFunctionalRole(ecpToken));
            const signalReqBody = {
                'name': signalReqName,
                'variables': {}
            }
            this.bpmnSignalResponse = await this.httpService.post(this.signalUrl, signalReqBody, {
                headers: camundaBpmHeaders
            }).toPromise();

            this.signalResponse={
                'status': this.bpmnSignalResponse?.status,
                'statusText': this.bpmnSignalResponse?.statusText
            }
        } catch (ex) {
            this.logger.error("Error while calling CaseWF CamundaSignalService sendBpmnSignal (signalRequest: " + signalRequest + ", context: " + context + CamundaSignalService.CONTEXTLABEL + signalReqName + ") " + ex);
            throw ex;
        }
        return this.signalResponse;

    }

    async getToken(client: Client) {
        let tokenUrl: string = "";
        if (client && client?.clientId && client?.clientSecret) {
            tokenUrl = this.configService.get<string>('ECP_TOKEN_URL')
                + CamundaSignalService.CLIENT_CREDENTIALS
                + CamundaSignalService.CLIENT_ID
                + this.configService.get<string>(client?.clientId)
                + CamundaSignalService.CLIENT_SECRET
                + this.configService.get<string>(client?.clientSecret);
        } else {
            tokenUrl = this.configService.get<string>('ECP_TOKEN_URL')
                + CamundaSignalService.CLIENT_CREDENTIALS
                + CamundaSignalService.CLIENT_ID
                + this.configService.get<string>("ECP_CLIENT_ID")
                + CamundaSignalService.CLIENT_SECRET
                + this.configService.get<string>("ECP_CLIENT_SECRET");
        }
        try {
            const dataResponse = await this.httpService
                .post(tokenUrl,
                    {},
                    {},
                )
                .toPromise();
            return dataResponse.data.access_token;
        } catch (ex) {
            this.logger.error("Error while calling CaseWF CamundaSignalService getToken (client: " + client + ") " + ex);
            throw new UnauthorizedException(ex);
        }
    }

    async getFunctionalRole(ecptoken: any): Promise<string> {
        const ecpClaim: EcpClaim = await AuthorizationService.getEcpClaim(ecptoken, this.configService.get<string>('JWK_URI'), this.configService.get<string>('ISSUER'));
        // Status of the decoded token will tell us if token is valid
        const authenticated: boolean = ecpClaim[EcpTokenFeilds.STATUS] === 'success' ? true : false;

        // Check for role only if token is valid
        if (authenticated) {
            const orgs: any[] = ecpClaim.message[EcpTokenFeilds.ECP_CLI_ORGS] || [];
            this.logger.error("getFunctionalRole - Bpm functional role: " + orgs[0][EcpTokenFeilds.FUNC_ROLES][0][EcpTokenFeilds.ROLE_NAME]);
            return orgs[0][EcpTokenFeilds.FUNC_ROLES][0][EcpTokenFeilds.ROLE_NAME];

        } else {
            this.logger.error("getFunctionalRole - Failed to derive Bpm functional role from token");
            return ""
        }
    }

    static getCamundaBpmHttpHeaders(inputRequestVariable, req, ecptoken, client: Client, bpmFuncRole) {
        const camundaHeaders = {
            'Content-Type': DomainConstants.CONTENT_TYPE,
            'Accept': DomainConstants.CONTENT_TYPE,
            'Authorization': req.headers['authorization'] ? req.headers['authorization'] : ecptoken,
            'x-bpm-cli-org-id': inputRequestVariable?.client ? inputRequestVariable.client : "ecp",
            'x-bpm-func-role': bpmFuncRole ? bpmFuncRole : "um_ecp_system",
            'x-bpm-tenant-id': client?.tenantId ? client.tenantId : 'ecpumcasemgmtbasebpmgrp'
        };
        return camundaHeaders
    }
}
