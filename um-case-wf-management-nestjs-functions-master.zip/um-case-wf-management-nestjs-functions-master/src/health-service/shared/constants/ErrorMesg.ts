export const errorMesgs = {
    INVALID_TOKEN: "CaseValidation function: Token is invalid",
    INVALID_REQUEST: "CaseValidation function: Invalid requestBody hsc_id required"
}
