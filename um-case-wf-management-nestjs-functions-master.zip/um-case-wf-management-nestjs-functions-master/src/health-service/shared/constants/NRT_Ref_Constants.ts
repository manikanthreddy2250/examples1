export enum LOB_ENUM {
    COM = 'E&I',
    MCR = 'M&R',
    MCD = 'C&S',
    Dual = 'Dual',
    GDCH = 'GDCH/State of GA'
}
