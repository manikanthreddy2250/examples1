export const applicationConstants ={
    CASE_WF_MGMT_UI_APP_NAME : 'case_wf_mgmt_ui',
    CASE_WF_MGMT_UI_APP_VERSION: '1.0.0',
    DUPLICATE_CHECK_VALIDATION : 'https://dev-ecp-api.optum.com/util-funcs-nestjs/api/graphql',
    ECP_BASE_DMN_TENENT_ID : "ecpumcasemgmtbasedmngrp",
    UM_CASE_MGMT : "umcasemgmt",
    DMN_GRP : "dmngrp"
}

export const healthServiceConstants ={
 SERVICE_SETTING_REF_ID_INPATIENT : 3737,
 SERVICE_SETTING_REF_ID_OUTPATIENT : 3738,
 SERVICE_SETTING_REF_ID_OUTPATIENT_FACILITY : 3739,
 LOB_TYPE_MNR_REF_ID : 19972,
 STATE_CODE_MARYLAND : 'MD',
 CONTRACT_PAPER_TYPE_DRG_REF_ID : 72250,
 CONTRACT_PAPER_TYPE_PER_DIEM_REF_ID : 72251,
}

export const ReferenceConstants ={
    LOB_BASE_REF_NAME : 'lineOfBusinessType',
    CONTRACT_PAPER_TYPE_BASE_REF_NAME : 'providerReimbursementType',
    MEDNEC_RESTRICTION_BASE_REF_NAME : 'mednecReviewClause',
}
export const ConfigServiceConstants ={
    READMISSION_CONFIG_KEY : 'readmission_criteria_config'
}

export const LetterEventConstants = {
    SEND_LETTER_EVENT_NAME : 'letter.utility.event',
    SEND_LETTER_EVENT_CHANNEL : 'BPM',
    SEND_LETTER_EVENT_ID_TYPE_HSC_ID : 'hscID',
    SEND_LETTER_EVENT_DECISION_CATEGORY_AUTO_LETTER : 'AutoLetter'
}

export const DecisionConstants = {
   
    LAST_DECN_BED_DAY_REF_ID  : 73590
}
