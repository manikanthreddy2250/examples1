import {GraphQLClient} from "graphql-request/dist";
import {ConfigService} from "@nestjs/config";
import {DocumentServiceClient} from "./documentServiceClient";

class MockConfigService extends ConfigService {
    get(propertyPath: any){
        return 'testvalue';
    };
}

describe('DocumentServiceClient', () => {
    let documentServiceClient: DocumentServiceClient;

    beforeEach(async () => {
        documentServiceClient = new DocumentServiceClient(new MockConfigService());
    });

    it('should be defined', () => {
        expect(documentServiceClient).toBeDefined();
    });

    it('should return a document GraphQLClient', () => {
        //let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid', headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
        const client = documentServiceClient.getGraphqlClient();
        expect(client).toBeInstanceOf(GraphQLClient);
    });
});