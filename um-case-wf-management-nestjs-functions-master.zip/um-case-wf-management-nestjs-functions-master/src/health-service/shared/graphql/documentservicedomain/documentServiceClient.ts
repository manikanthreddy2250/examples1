import {GraphQLClient} from "graphql-request/dist";
import { ConfigService } from '@nestjs/config';
import { Injectable } from '@nestjs/common';

@Injectable()
export class DocumentServiceClient {
    private documentServiceClient;
    constructor(private readonly configService: ConfigService) {
        this.documentServiceClient = new GraphQLClient(process.env.DOCUMENT_SERVICE_API_ENDPOINT, { headers: {'x-hasura-admin-secret': process.env.DOCUMENT_API_ADMIN_SECRET} })
    }
    public getGraphqlClient(): GraphQLClient {
        return this.documentServiceClient;
    }
}