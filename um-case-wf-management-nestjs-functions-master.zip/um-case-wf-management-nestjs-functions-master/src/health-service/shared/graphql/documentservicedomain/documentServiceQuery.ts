export const getDocumentsByDocId= `query getDocuments($docRecId: String) {
  doc_sbj(where: {doc_sbj_rec_id: {_eq: $docRecId} _and:{inac_ind:{_eq:0} _and:{doc_sbj_typ_ref_id:{_eq:20047}}}}) {
               doc_id
               }
    }`;