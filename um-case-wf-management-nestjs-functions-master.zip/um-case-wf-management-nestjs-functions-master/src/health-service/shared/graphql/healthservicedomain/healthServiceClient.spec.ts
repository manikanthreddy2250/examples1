import {GraphQLClient} from "graphql-request/dist";
import {ConfigService} from "@nestjs/config";
import {HealthServiceClient} from "./healthServiceClient";
import {HttpRequest} from "@azure/functions";

class MockConfigService extends ConfigService {
    get(propertyPath: any){
        return 'testvalue';
    };
}

describe('HealthServiceClient', () => {
    let healthServiceClient: HealthServiceClient;

    beforeEach(async () => {
        healthServiceClient = new HealthServiceClient(new MockConfigService());
    });

    it('should be defined', () => {
        expect(healthServiceClient).toBeDefined();
    });

    it('should return a Health Service GraphQLClient', () => {
        let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid', headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
        const client = healthServiceClient.getGraphqlClient(httpRequest);
        expect(client).toBeInstanceOf(GraphQLClient);
    });
});
