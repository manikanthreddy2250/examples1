export const getHscProviderDetailsQuery = `query getHscProviderDetails($hscProvID: bigint!) {
  hsc_prov (where: {hsc_prov_id: {_eq: $hscProvID}}) {
      hsc_id
      prov_key_typ_ref_id
      prov_loc_affil_dtl
  }
}`;


export const    getProviderDataDetails = `
     query getProviderData($prov_id: bigint, $provider_key_value_typ_ref_npi: Int, $provider_npi_val: String) {
          v_prov_srch(distinct_on: adr_ln_1_txt, where: {prov_id: {_eq: $prov_id}, _and:{prov_key_typ_ref_id: {_eq: $provider_key_value_typ_ref_npi}, _and: {prov_key_val: {_eq: $provider_npi_val}}}}) {
                adr_ln_1_txt
                adr_ln_2_txt
                bus_nm
                cty_nm
                fst_nm
                lst_nm
                prov_catgy_ref_id
                prov_catgy_ref_cd {
                    ref_desc
                }
                prov_id
                spcl_ref_id
                spcl_ref_cd {
                    ref_desc
                    ref_dspl
                }
                st_ref_id
                st_ref_cd {
                    ref_desc
                }
                telcom_adr_id
                zip_cd_txt
          }
     }`;


export const getHscProviderRolesByHscId = `
query getProvRoles($hscId:bigint) {
   hsc(where: {hsc_id: {_eq: $hscId}}) {
    hsc_id
    srvc_set_ref_id
    hsc_provs {
      hsc_prov_id
      hsc_prov_roles {
        prov_role_ref_id
      }
    }
  }
}
`;
export const getCoverageDetailsByHscId = `
        query getCoverageDetails($hscId:bigint) {
          hsc(where: {hsc_id: {_eq: $hscId}}) {
            mbr_cov_dtl
          }
        }
`;

export const getReviewIdByHscId = `
        query getReviewId($hscId:bigint) {
          hsc_clin_guid(where: {hsc_id: {_eq: $hscId}}){
            clin_rev_sys_rec_id
          }
        }
`;

export const getTaskDetailsQuery = `
query getTaskDetails($hscId: bigint!,$assignTypeRefId: Int!) {
hsr_asgn(where: { hsc_id: { _eq: $hscId }, asgn_typ_ref_id: {_eq: $assignTypeRefId} }) {
hsr_asgn_id
asgn_to_user_id
chg_user_id
chg_dttm
asgn_desc
src_rec_guid
asgn_typ_ref_id
asgn_typ_ref_cd {
ref_dspl
}
asgn_sts_ref_id
asgn_sts_ref_cd {
ref_dspl
}
}
} `;

export const getTaskListQuery = `
query TaskList($hscId: bigint!) {
hsr_asgn(where: { hsc_id: { _eq: $hscId } }) {
hsc_id
hsr_asgn_id
creat_dttm
asgn_to_user_id
src_rec_guid
asgn_typ_ref_id
asgn_typ_ref_cd {
ref_dspl
}
asgn_catgy_ref_id
asgn_catgy_ref_cd {
ref_dspl
}
asgn_sts_ref_id
asgn_sts_ref_cd {
ref_dspl
}
asgn_to_user_id
asgn_to_wrk_que_ref_id
asgn_to_wrk_que_ref_cd {
ref_dspl
}
hsc {
indv_id
  individual {
      fst_nm
      lst_nm
    }
hsc_diags {
diag_cd
pri_ind
}
hsc_provs{
hsc_prov_id
prov_key_val
prov_loc_affil_dtl
hsc_prov_roles {
prov_role_ref_id
hsc_prov_id
prov_role_ref_cd {
ref_desc
}
}
}
hsc_facls {
actul_admis_dttm
tat_due_dttm
}
}
}
}`;

export const getTaskListQueryByUserName = `
query TaskList($assignUserId: String) {
hsr_asgn(where: {asgn_to_user_id: { _eq: $assignUserId } }) {
hsc_id
hsr_asgn_id
creat_dttm
asgn_to_user_id
src_rec_guid
asgn_typ_ref_id
asgn_typ_ref_cd {
ref_dspl
}
asgn_catgy_ref_id
asgn_catgy_ref_cd {
ref_dspl
}
asgn_sts_ref_id
asgn_sts_ref_cd {
ref_dspl
}
asgn_to_user_id
asgn_to_wrk_que_ref_id
asgn_to_wrk_que_ref_cd {
ref_dspl
}
hsc {
indv_id
  individual {
      fst_nm
      lst_nm
    }
hsc_diags {
diag_cd
pri_ind
}
hsc_provs{
hsc_prov_id
prov_key_val
prov_loc_affil_dtl
hsc_prov_roles {
prov_role_ref_id
hsc_prov_id
prov_role_ref_cd {
ref_desc
}
}
}
hsc_facls {
actul_admis_dttm
tat_due_dttm
}
}
}
}`;

export const hscDuplicateCheckMutation = `
            mutation duplicateCheck($duplicateCheckRequestInput : DuplicateCheckRequestInput! ){
        duplicateCheck(duplicateCheckRequestInput : $duplicateCheckRequestInput){
            hsc_duplicates{
                hsc_id
            }
        }
    }
    `;
export const getHscFaclByHscId = `
query getFacl($hscId:bigint) {
   hsc(where: {hsc_id: {_eq: $hscId}}) {
    hsc_id
    hsc_facls{
      actul_admis_dttm
      actul_dschrg_dttm
      expt_admis_dt
      expt_dschrg_dt
    }
    srvc_set_ref_id
    srvc_set_ref_cd {
    ref_desc
    }
  }
}
`;

export const getHscProvByHscId = `
    query getHscProv($hscID:bigint) {
      hsc_prov(where: {hsc_id: {_eq: $hscID}}) {
        hsc_id
        prov_loc_affil_id
        hsc_prov_roles {
            prov_role_ref_id
            hsc_prov_id
         }
         hsc_prov_roles {
            prov_role_ref_cd{
                ref_desc
            }
         }
         prov_loc_affil_dtl
      }
    }`;

export const getHscHeaderDetailsByHscId = `
query getHscHeader($hscID:bigint) {
  hsc(where: {hsc_id: {_eq: $hscID}}) {
    hsc_facls {
      actul_admis_dttm
      actul_dschrg_dttm
      expt_dschrg_dt
      expt_admis_dt
      srvc_dtl_ref_id
      srvc_dtl_ref_cd {
        ref_dspl
      }
      srvc_desc_ref_id
      srvc_desc_ref_cd {
        ref_dspl
      }
    }
    hsc_srvcs {
      hsc_srvc_non_facls {
        srvc_strt_dt
        srvc_end_dt
        srvc_desc_ref_id
        srvc_desc_ref_cd {
          ref_dspl
        }
        srvc_dtl_ref_id
        srvc_dtl_ref_cd {
          ref_dspl
        }
       plsrv_ref_id
       plsrv_ref_cd{
          ref_dspl
        }
      }
    }
    hsc_diags(where: {pri_ind: {_eq: 1}}) {
      diag_cd
      pri_ind
    }
    srvc_set_ref_id
    srvc_set_ref_cd {
      ref_dspl
    }
    mbr_cov_dtl
    hsc_provs(where: {hsc_prov_roles: {prov_role_ref_id: {_eq: 3761}}}) {
      prov_loc_affil_dtl
    }
    hsc_sts_ref_id
    hsc_sts_ref_cd{
    ref_dspl
  }
  individual {
      fst_nm
      indv_id
      lst_nm
      gdr_ref_cd {
        ref_dspl
        ref_id
      }
      bth_dt
    }
  }
}`;

export const getProviderNameByProvId = `
query getProvName($provId:bigint) {
  prov_org(where: {prov_id: {_eq: $provId}}) {
  bus_nm
 }
}`;

export const getAmissionDateByHscId = `
query getAdmissionDateByHscId($hscId:bigint) {
  hsc(where: {hsc_id: {_eq: $hscId}}) {
    hsc_facls {
      actul_admis_dttm
    }
    indv_id
  }
}`;
export const getDischargedHscCount = `query getDischargedHscCount($indv_id: bigint!, $admisMinusReadmissionConfig: timestamp!) {
  hsc_facl_aggregate(where: {hsc: {indv_id: {_eq: $indv_id}}, actul_dschrg_dttm: {_gte: $admisMinusReadmissionConfig}}) {
    aggregate {
      count
    }
  }
}`;

export const getHscActivitiesByHscId = `
query getHscActivitiesByHscId($hscId:bigint) {
  hsr_actv(where: {hsc_id: {_eq: $hscId}}) {
    hsr_actv_sbjs {
      hsr_sbj_rec_id
      hsr_sbj_typ_ref_id
    }
  }
}`;

export const getBedDayDecisionDetails = `query getBedDayDecisionDetails($hscID:bigint) {
  hsc_decn_bed_day(where: {hsc_decn: {hsc_id: {_eq: $hscID}}}, order_by: {hsc_decn_id: desc}) {
    strt_bed_dt
    hsc_decn {
      hsc_decn_id
      hsc_id
      hsc_decn_id
      decn_otcome_ref_id
      decn_bed_day_cnt
    }
  }
}`;
