import { GraphQLClient } from 'graphql-request/dist';
import { ConfigService } from '@nestjs/config';
import { MemberServiceClient } from './memberServiceClient';
import { HttpRequest } from '@azure/functions';

class MockConfigService extends ConfigService {
  get(propertyPath: any) {
    return 'testvalue';
  }
}

describe('MemberServiceClient', () => {
  let memberServiceClient: MemberServiceClient;

  beforeEach(async () => {
    memberServiceClient = new MemberServiceClient(new MockConfigService());
  });

  it('should be defined', () => {
    expect(memberServiceClient).toBeDefined();
  });

  it('should return a Health Service GraphQLClient', () => {
    const httpRequest: HttpRequest = {
      method: null,
      url: '/test?session_id=encryptedid',
      headers: { authorization: 'test token', 'x-hasura-role': 'testrole' },
      query: { test: 'test' },
      params: { test: 'test' },
    };
    const client = memberServiceClient.getGraphqlClient(httpRequest);
    expect(client).toBeInstanceOf(GraphQLClient);
  });
});
