import { GraphQLClient } from 'graphql-request/dist';
import { ConfigService } from '@nestjs/config';
import { Injectable } from '@nestjs/common';
import { HttpRequest } from '@azure/functions';

@Injectable()
export class MemberServiceClient {
  private memberServiceClient;
  constructor(private readonly configService: ConfigService) {
    this.memberServiceClient = new GraphQLClient(
      configService.get<string>('MEMBER_COMMUNICATION_API_ENDPOINT'),
    );
  }

  public getGraphqlClient(req: HttpRequest): GraphQLClient {
    const headers = {
      'content-type': req.headers['content-type'],
      Authorization: req.headers['authorization'],
      'x-hasura-role': req.headers['x-hasura-role'],
    };
    this.memberServiceClient.setHeaders(headers);
    return this.memberServiceClient;
  }
}
