export const getMemberCommunications = `    
query getMemberCommunications($subjects:[bigint!]) {
    mbr_cmnct(where: {mbr_cmnct_id: {_in: $subjects}}) {
    mbr_cmnct_id
    creat_dttm
    creat_user_id
    mbr_cmnct_chnl_ref_id
    mbr_cmnct_dir_ref_id
    mbr_cmnct_typ_ref_id
    mbr_cmnct_sts_ref_id
    mbr_cmnct_catgy_ref_id
  }
}`;
