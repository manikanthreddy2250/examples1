export const getProvByMpin =  `query getProviderByMpin($lobRefDisp: String,$contractPaperTypeRefDisp: String,$mednecRestrictionRefDesc: String,$lobBaseRefNm: String,$contractPaperTypeBaseRefNm: String,$mednecBaseRefNm: String) {
    lob_ref:prov_ref(where: {ref_dspl: {_eq: $lobRefDisp}, _and: {bas_ref_nm: {_eq: $lobBaseRefNm}}}){
        ref_id
    }
    contract_paper_type_ref:prov_ref(where: {ref_dspl: {_eq: $contractPaperTypeRefDisp}, _and: {bas_ref_nm: {_eq: $contractPaperTypeBaseRefNm}}}){
        ref_id
    }
    med_nec_restriction_ref:prov_ref(where: {ref_desc: {_eq: $mednecRestrictionRefDesc}, _and: {bas_ref_nm: {_eq: $mednecBaseRefNm}}}){
        ref_id
    }
}`;

//Sample Input Array : (first add prov_ntwk columns then prov_contrs columns) -
// {
// "inputArray" : [{"bus_seg_nm": "UHC", "prov_contrs": {"data": {"end_dt": "2/2/2021", "strt_dt": "2/2/2021", "prov_id":"921514"}}},
//                  {"bus_seg_nm": "UHC", "prov_contrs": {"data": {"end_dt": "2/2/2021", "strt_dt": "2/2/2021", "prov_id": "921514"}}}]
//}
export const insertContractMutation = `mutation insertProviderContract($inputArray: [prov_ntwk_insert_input!]!) {
  insert_prov_ntwk(objects:$inputArray ) {
    affected_rows
  }
}
`;

export const updateContractMutation = `mutation MyMutation($_set: prov_contr_set_input, $_src_rec_guid: String, $_med_nec_rev_claus_ref_id: Int, $_lob_ref_id: Int, $_bus_seg_nm: String) {
    update_prov_contr(
        where: {
            src_rec_guid: {_ilike: $_src_rec_guid},
            _and: {
                med_nec_rev_claus_ref_id: {_eq: $_med_nec_rev_claus_ref_id},
                _and: {
                    prov_ntwk: {
                        lob_ref_id: {_eq: $_lob_ref_id},
                        _and: {
                            bus_seg_nm: {_eq: $_bus_seg_nm}
                        }
                    }
                }
            }
        },
        _set: $_set
    )
    {
        affected_rows
    }
}
`;

export const getProviderContract =  `query getProviderContract($_src_rec_guid: String, $_med_nec_rev_claus_ref_id: Int, $_lob_ref_id: Int, $_bus_seg_nm: String) {
    prov_contr(
        where: {
            src_rec_guid: {_ilike: $_src_rec_guid},
            _and: {
                med_nec_rev_claus_ref_id: {_eq: $_med_nec_rev_claus_ref_id},
                _and: {
                    prov_ntwk: {
                        lob_ref_id: {_eq: $_lob_ref_id},
                        _and: {
                            bus_seg_nm: {_eq: $_bus_seg_nm}
                        }
                    }
                }
            }
        }
    ) {
        prov_contr_id
        prov_ntwk_id
    }
}`;

export const deleteContractMutation = `mutation MyMutation($prov_contr_id: bigint!, $prov_ntwk_id: Int!) {
  delete_prov_contr_by_pk(prov_contr_id: $prov_contr_id) {
    prov_contr_id
  }
  delete_prov_ntwk_by_pk(prov_ntwk_id: $prov_ntwk_id) {
    prov_ntwk_id
  }
}
`;
export const getLastCallDate= `query getLastCallDate{
prov_contr(order_by: {chg_dttm: desc},limit: 1) {
    chg_dttm
  }
}
`;