import {GraphQLClient} from "graphql-request/dist";
import {Injectable} from "@nestjs/common";
import {ConfigService} from "@nestjs/config";
import {HttpRequest} from "@azure/functions";

@Injectable()
export class ReferenceClient {
    private referenceClient;

    constructor(private readonly configService: ConfigService) {
        this.referenceClient = new GraphQLClient(
            configService.get<string>('REFERENCE_DATA_API_ENDPOINT'),
        );
    }

    public getGraphqlClient(req: HttpRequest): GraphQLClient {
        const headers = {
            'content-type': req.headers['content-type'],
            Authorization: req.headers['authorization'],
            'x-hasura-role': req.headers['x-hasura-role'],
        };
        this.referenceClient.setHeaders(headers);
        return this.referenceClient;
    }
}
