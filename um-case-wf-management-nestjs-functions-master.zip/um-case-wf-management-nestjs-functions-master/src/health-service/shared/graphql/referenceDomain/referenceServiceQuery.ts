export const diagCdRefQuery = `query icd10($diag_cds: [String!]) {
  icd10(where: {diag_cd: {_in:$diag_cds}}) {
    diag_cd
    full_desc
    shrt_desc
    cd_desc
  }
}`;

export const getReferenceCodeQuery = `
    query ReferenceData($referenceId: Int) {
      ref (where: {ref_id: {_eq: $referenceId}}) {
         ref_cd
         ref_desc
       }
     }`;
export const getRefDataForRefIds = `
    query getRefDataForRefIds($referenceIds: [Int!]) {
      ref (where: {ref_id: {_in: $referenceIds}}) {
         ref_id
         ref_cd
         ref_dspl
       }
     }`;
