import {GraphQLClient} from "graphql-request/dist";
import {UtilClient} from "./utilClient";
import {HttpRequest} from "@azure/functions";
import {ConfigService} from "@nestjs/config";

class MockConfigService extends ConfigService {
    get(propertyPath: any){
        return 'testvalue';
    };
}

describe('UtilClient', () => {
    let utilClient: UtilClient;

    beforeEach(async () => {
        utilClient = new UtilClient(new MockConfigService());
    });

    it('should be defined', () => {
        expect(utilClient).toBeDefined();
    });

    it('should return a Util GraphQLClient', () => {
        let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid', headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
        const client = utilClient.getGraphqlClient(httpRequest);
        expect(client).toBeInstanceOf(GraphQLClient);
    });
});
