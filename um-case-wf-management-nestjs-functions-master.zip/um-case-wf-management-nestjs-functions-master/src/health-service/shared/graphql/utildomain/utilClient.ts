import { GraphQLClient } from 'graphql-request/dist';
import { Injectable } from '@nestjs/common';
import { HttpRequest } from '@azure/functions';
import {ConfigService} from "@nestjs/config";

@Injectable()
export class UtilClient {
    private utilClient;

    constructor(private readonly configService: ConfigService) {
        this.utilClient = new GraphQLClient(
            configService.get<string>('UTILIZATION_NESTJS_API_ENDPOINT')
        );
    }

    public getGraphqlClient(req: HttpRequest): GraphQLClient {
        const headers = {
            "authorization": req.headers["authorization"],
            "content-type": req.headers["content-type"],
            "x-bpm-cli-org-id": req.headers["x-bpm-cli-org-id"],
            "x-bpm-func-role": req.headers["x-bpm-func-role"],
            "x-bpm-tenant-id": req.headers["x-bpm-tenant-id"],
            "x-hasura-role": req.headers["x-hasura-role"]
        };
        this.utilClient.setHeaders(headers);
        return this.utilClient;
    }
}
