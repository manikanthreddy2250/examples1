import { Test, TestingModule } from '@nestjs/testing';
import { ConfigurationDomainService } from './configuration-domain.service';
import {LoggerModule} from "nestjs-pino/dist";
import {ConfigService} from "@nestjs/config";

describe('ConfigurationDomainService', () => {
  let service: ConfigurationDomainService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      imports: [LoggerModule.forRoot()],
      providers: [ConfigurationDomainService,ConfigService],
    }).compile();

    service = module.get<ConfigurationDomainService>(ConfigurationDomainService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
