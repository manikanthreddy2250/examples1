import { Injectable } from '@nestjs/common';
import {HttpRequest} from "@azure/functions";
import {applicationConstants} from "../../health-service/shared/constants/applicationConstants";
import axios from "axios";
import {Logger} from "nestjs-pino";
import {ConfigService} from "@nestjs/config";

@Injectable()
export class ConfigurationDomainService {
    constructor(private readonly configService: ConfigService) {}
    async getConfigJson(cnfgKey:String ,httpRequest:HttpRequest):Promise<any>{
        const configHttpUrl = this.configService.get<string>('CONFIGURATION_API_ENDPOINT');
        let configResponse: any;
        const configRequestUrl = configHttpUrl + '/' +
            applicationConstants.CASE_WF_MGMT_UI_APP_NAME + '/' +
            applicationConstants.CASE_WF_MGMT_UI_APP_VERSION + '/' +
            cnfgKey;
        const token = {
            'x-bpm-func-role':  httpRequest.headers['x-bpm-func-role'],
            'Authorization': httpRequest.headers['authorization']
        };
        await axios.get(configRequestUrl, {headers: token}).then(function (response) {
            configResponse = response.data;
        })
        return configResponse;
    }
}
