import {ConfigService} from '@nestjs/config';
import {Test, TestingModule} from '@nestjs/testing';
import {AppController} from './app.controller';
import {AppService} from './app.service';
import {HttpModule} from "@nestjs/common";
import {HealthServiceClient} from "./shared/graphql/healthservicedomain/healthServiceClient";
import {ReferenceClient} from "./shared/graphql/referenceDomain/referenceClient";

describe('AppController', () => {
    let appController: AppController;
    let appService: AppService;

    beforeEach(async () => {
        const app: TestingModule = await Test.createTestingModule({
            controllers: [AppController],
            imports:[HttpModule],
            providers: [AppService, ConfigService, HealthServiceClient, ReferenceClient],
        }).compile();

        appController = app.get<AppController>(AppController);
        appService = app.get<AppService>(AppService);
    });

    describe('root', () => {
        it('should return "Hello World!"', () => {
            expect(appService.getHello()).toBe('Hello World!');
        });
    });

});
