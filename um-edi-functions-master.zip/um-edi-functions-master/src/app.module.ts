import {HttpModule, Module, OnModuleInit} from '@nestjs/common';
import { LoggerModule } from 'nestjs-pino';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { HttpClientModule} from '@angular/common/http';
import { GraphQLModule } from '@nestjs/graphql';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { GraphQLError, GraphQLFormattedError } from 'graphql';
import { AuthModule } from './auth/auth.module';
import { JwtStrategy } from './auth/jwt.strategy';
import { AuthGuard } from './auth/auth.guard';
import { RolesGuard } from './auth/roles.guard';
import { PassportModule } from '@nestjs/passport';
import { JwtModule } from '@nestjs/jwt';
import { EdiModule } from './edi/edi.module';
import {IndividualClient} from "./shared/graphql/individualDomain/individualClient";
import {EdiUtilities} from "./edi/edi-utilities";
import {HealthServiceClient} from "./shared/graphql/healthservicedomain/healthServiceClient";
import {ReferenceClient} from "./shared/graphql/referenceDomain/referenceClient";

@Module({
  imports: [
    HttpClientModule,
    LoggerModule.forRoot(),
    ConfigModule.forRoot({
      isGlobal: true,
      //ignoreEnvFile: true,
      envFilePath:['.env.dev','.env.local']
    }),
    GraphQLModule.forRoot({
      buildSchemaOptions: {
        numberScalarMode: 'integer',
      },
      //resolvers: { JSON: GraphQLJSON }, // if you need to expose a JSON as a type
      playground: true,
      installSubscriptionHandlers: false,
      context: ({ req }) => ({ req }),
      autoSchemaFile: 'schema.gql',
      useGlobalPrefix: true,
      formatError: (error: GraphQLError) => {
          return {
            message: error.extensions.exception.response.message || error.message,
          };
      },
    }),
    PassportModule,
    JwtModule.register({}),
    AuthModule,
    HttpModule,
    ConfigService,
    EdiModule
  ],
  controllers: [AppController],
  providers: [
      AppService,
      ConfigService,
      JwtStrategy,
      AuthGuard,
      RolesGuard,
      EdiUtilities,
      HealthServiceClient,
      ReferenceClient
      ],
})
export class AppModule implements OnModuleInit {

    onModuleInit() {
        console.log("App Module Initialization");
    }
}
