import {AppService} from "./app.service";
import {ConfigService} from "@nestjs/config";
import {Test, TestingModule} from "@nestjs/testing";
import {HttpModule, Injectable} from "@nestjs/common";
import {HealthServiceClient} from "./shared/graphql/healthservicedomain/healthServiceClient";
import {HealthServiceService} from "./edi/services/healthService/healthService.service";
import {GraphQLClient} from "graphql-request/dist";
import {ReferenceClient} from "./shared/graphql/referenceDomain/referenceClient";

@Injectable()
class HealthServiceServiceMock {
    createHscShell(hscShellVariables) {
        return {
            "insert_hsc":
                {"returning": [{"hsc_id": 15619}]}
        };
    }
}

@Injectable()
class HealthServiceClientMock {

    getGraphqlClientAuth(authorization) {
        let configService: ConfigService;
       // return new GraphQLClient(configService.get<string>('HEALTH_SERVICE_API_ENDPOINT'));
        return "testURL";
    }
}


describe('AppService', () => {
    let appService: AppService;
    const healthService = new HealthServiceClientMock();


    beforeEach(async () => {

        const app: TestingModule = await Test.createTestingModule({
            imports: [HttpModule],

            providers: [AppService, ConfigService, ReferenceClient, {provide: HealthServiceClient, useClass: HealthServiceClientMock},
                {provide: HealthServiceService, useClass: HealthServiceServiceMock}],
        }).compile();

        appService = app.get<AppService>(AppService);
    });

    describe('root', () => {
        it('should be defined', () => {
            expect(appService).toBeDefined();
        });

/*        it('should run #onModuleInit()', async () => {
            spyOn(healthService, 'getGraphqlClientAuth').and.callFake(function () {});
            appService.onModuleInit();
            expect(appService).toBeTruthy();
        });*/

/*        it('should run #getRefMatchCode()', async () => {
            const baseRefName = 'providerRole';
            const refCode = 'FA';
            appService.getRefMatchCode(baseRefName, refCode);
            expect(appService).toBeTruthy();
        });

        it('should run #getRefMatchDesc()', async () => {

            const baseRefName = 'providerRole';
            const refDesc = 'Facility';
            appService.getRefMatchDesc(baseRefName, refDesc);
            expect(appService).toBeTruthy();
        });*/

    });

});