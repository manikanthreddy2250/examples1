import {HttpService, Injectable, OnModuleInit} from '@nestjs/common';
import {ConfigService} from "@nestjs/config";
import {HealthServiceClient} from "./shared/graphql/healthservicedomain/healthServiceClient";
import {ReferenceClient} from "./shared/graphql/referenceDomain/referenceClient";
import {getReferenceData} from "./shared/graphql/referenceDomain/referenceQuery";


@Injectable()
export class AppService implements OnModuleInit {

    constructor(private readonly configService: ConfigService,
                private httpService: HttpService,
                private healthServiceClient: HealthServiceClient,
                private referenceClient: ReferenceClient) {
    }

    private refData: any;
    private refVars: any = {
        "baseRefNames": ["genderType",
            "relationshipCode",
            "stateCode",
            "countryCode",
            "providerRole",
            "procCodeType",
            "diagnosisCodeVersion",
            "serviceDetailType",
            "serviceDescriptionType",
            "serviceSettingType",
            "placeOfServiceCode",
            "eligibilitySystemTypeID"],
        "atrNames": ["serviceDetailType",
            "placeOfServiceCode"]
    };


    getHello(): string {
        return 'Hello World!';
    }

    async onModuleInit() {

        console.log("App Service Initialization")

        try {
            const token = await this.createToken().toPromise();
            //console.log("token " + token.data.access_token);
            const auth = 'Bearer ' + token.data.access_token;

        //    this.refData = await this.healthServiceClient.getGraphqlClientAuth(auth).request(getReferenceData, this.refVars);


            //get cdxref data
            this.refData = await this.referenceClient.getGraphqlClientAuth(auth).request(getReferenceData, this.refVars);
            console.log("REF DATA");
            console.dir(this.getRefMatchCode('relationshipCode', '1M'));
            console.dir(this.getRefMatchDesc('relationshipCode', 'Annuitant'));
            console.dir(this.getCdxRefMatchAtrVal('placeOfServiceCode', 'A+11+278N-IN'));

        } catch (err) {
            console.log(err);
        }
    }

    getRefMatchCode(baseRefName, refCode) {
        if (this.refData.ref) {
            return this.refData.ref.find(obj => {
                return obj.bas_ref_nm === baseRefName && obj.ref_cd === refCode;
            });
        }
    }

    getRefMatchDesc(baseRefName, refDesc) {
        if (this.refData.ref) {
            return this.refData.ref.find(obj => {
                return obj.bas_ref_nm === baseRefName && obj.ref_desc === refDesc;
            });
        }
    }

    getCdxRefMatchAtrVal(atrName, atrFromVal) {
        if (this.refData.cd_xref) {
            return this.refData.cd_xref.find(obj => {
                return obj.atr_nm === atrName && obj.atr_from_val === atrFromVal;
            });
        }
    }

    createToken() {
        const tokenUrl = this.configService.get<string>('OAUTH_TOKEN_URL') + '?grant_type=client_credentials&client_id='+this.configService.get<string>('NEST_JS_CLIENT_ID')+'&client_secret='+this.configService.get<string>('NEST_JS_CLIENT_SECRET')
        return this.httpService.post(tokenUrl, {});
        //return this.httpService.post(this.configService.get<string>('OAUTH_TOKEN_API'), {});
    }

    getRefData() {
        return this.refData;
    }

}
