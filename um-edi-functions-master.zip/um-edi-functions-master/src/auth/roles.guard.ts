import {
  Injectable,
  CanActivate,
  ExecutionContext,
  Logger,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { GqlExecutionContext } from '@nestjs/graphql';
import { ROLES_KEY } from '../decorators/roles.decorator';
import { Role } from '../decorators/roles';

@Injectable()
export class RolesGuard implements CanActivate {
  constructor(private readonly reflector: Reflector, private readonly logger: Logger) {}

  canActivate(context: ExecutionContext): boolean {
    const ctx = GqlExecutionContext.create(context);
    const { req } = ctx.getContext();
    const roles = this.reflector.getAllAndOverride<Role[]>(ROLES_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);

    if (!roles) {
      return true;
    }

    this.logger.log(`roles===> ${roles}`);
    const roleInRequest = req.headers['x-hasura-role'];
    const hasRole = () => roles.includes(roleInRequest);
    const user = req.user;
    this.logger.log(`user===> ${JSON.stringify(user)}`);
    // const hasRole = () =>
    this.logger.log(`roleInRequest===> ${roleInRequest}`);
    this.logger.log(`hasRole===> ${hasRole()}`);
    return roleInRequest && hasRole();
  }

  getRequest(context: ExecutionContext) {
    return (
      context.switchToHttp().getRequest() ||
      GqlExecutionContext.create(context).getContext().req
    );
  }
}
