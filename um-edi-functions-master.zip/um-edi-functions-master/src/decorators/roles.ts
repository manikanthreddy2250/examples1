export enum Role {
  User = 'system_mgmt_user',
  Admin = 'system_mgmt_admin',
  ClientAdmin = 'system_mgmt_client',
  Patient = 'patient',
  Provider = 'provider',
}
