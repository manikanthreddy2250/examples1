//278N constants
export const Edi278NConstants = {
    EDI_TYPE_278N_IN: '278N-IN',
    SOURCE_TYPE_278:'278',
    INT_ONE: 1,
    BHT02_ADVANCE_NOTIFICATION: '14',
    BHT02_INFORMATION_COPY:'22',
    BHT02_COMPLETION_NOTIFICATION: 'CN',
    MEMBER_ID_TYPE_MI: 'MI'
};

export const Edi278NMemberConstants = {
    MEMBER_ID_TYPE_MI: 'MI',
    MEMBER_ID_TYPE_IG: 'IG',
    MEMBER_ID_TYPE_1L: '1L',
    MEMBER_ID_TYPE_6P: '6P'
};

export const Edi278NDiagnosisConstants = {
    HI02_1_PRIMARY_DX_ICD10: 'ABK',
    HI02_1_SECONDARY_DX_ICD10: 'ABF',
    HI02_1_ADMITTING_DX_ICD10: 'ABJ'
};

export const Edi278NCanonicalProviderConstants = {
    SERVICING_PROVIDER: 'SJ',
    FACILITY_PROVIDER: 'FA',
    ATTENDING_PROVIDER: '71',
    ADMITTING_PROVIDER: 'AAJ',
    REQUESTING_PROVIDER: '1P'
};

export const Edi278NEventNoteLiterals = {
    ICD: 'ICD'
};

export const Edi278NLoopIdConstants = {
    MEMBER_LOOP_ID: '2010D',
    SUBSCRIBER_LOOP_ID: '2010C',

};
