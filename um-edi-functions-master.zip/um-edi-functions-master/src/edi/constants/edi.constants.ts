//edi constants

export const EdiConstants = {
    EDITYPE_278N: '278N',
};

export const EdiLineSeperator = {
    LINE_BREAK: '\n '
};

export const EnvironmentConstants = {
    ENV_DEV: 'dev',
    ENV_TST: 'tst',
    ENV_STG: 'stg',
    ENV_PRD: 'prd',
    ENV_LCL: 'lcl'
};

export const TestFlagConstants = {
    ISA15_PRODUCTION: 'P',
    ISA15_TEST: 'T'
};

export const EdiSourceTypeConstants = {
    EDI_278: '278'
};

export const EdiServiceSettingTypeConstants = {
    SERVICE_SETTING_INPATIENT: 'Inpatient'
};

export const EdiProviderConstants = {
    SERVICING_PROVIDER: 'SJ',
    FACILITY_PROVIDER: 'FA',
    ATTENDING_PROVIDER: 'AT',
    ADMITTING_PROVIDER: 'AD',
    REQUESTING_PROVIDER: 'RF'
};

export const EdiMemberConstants = {
    GENDER_M: 'M',
    GENDER_F: 'f',
    GENDER_U: 'U',
    OTHER_CARRIER: '00',
    MEDICARE_PART_A: 'GG',
    MEDICARE_PART_B: 'CA'
};

export const EdiFacilityConstants = {
    FACL_REQUEST_CATEGORY_AR: 'AR',
    FACL_CERTIFICATION_TYPE_INITIAL: 'I',
    FACL_CERTIFICATION_TYPE_REVISED: 'S',
    SERVICE_DESCRIPTION_TYPE_SCHEDULED: '1',
    SERVICE_DESCRIPTION_TYPE_URGENT: '2',
    SERVICE_DESCRIPTION_TYPE_EMERGENT: '3'
};

export const EdiServiceConstants = {
    SERVICE_PROC_CODE_TYPE_CPT4: 'CPT4',
    SERVICE_PROC_CODE_TYPE_HCPCS: 'HCPCS',
    SERVICE_REQUEST_CATEGORY_HS: 'HS',
    SERVICE_CERTIFICATION_TYPE_INITIAL: 'I',
    SERVICE_CERTIFICATION_TYPE_REVISED: 'S',
    SERVICE_TYPE_SURGICAL: '2'
};

export const EdiAdmissionTypeCodeConstants = {
    ADMISSION_TYPE_EMERGENCY: '1',
    ADMISSION_TYPE_URGENT: '2',
    ADMISSION_TYPE_ELECTIVE: '3',
    ADMISSION_TYPE_NEWBORN: '4'
};

export const EdiServiceDescriptionTypeConstants = {
    SERVICE_DESCRIPTION_TYPE_SCHEDULED: '1',
    SERVICE_DESCRIPTION_TYPE_URGENT: '2',
    SERVICE_DESCRIPTION_TYPE_EMERGENT: '3'
};

export enum canonicalRequestTags {
    CANONICALREQUEST = 'canonicalRequest',
    DATATRANSMISSIONHEADER = 'dataTransmissionHeader',
    EVENT = 'event',
    PROVIDERS = 'providers',
    PROVIDER = 'provider',
    FOLLOWUPCONTACT = 'followUpContact',
    MEMBER = 'member',
    MEMBERADDRESS = 'memberAddress',
    MEMBERIDENTIFIERS = 'memberIdentifiers',
    MEMBERIDENTIFIER = 'memberIdentifier',
    FACILITYBEDSTAYDECISIONS = 'facilityBedStayDecisions',
    FACILITYBEDSTAYDECISION = 'facilityBedStayDecision',
    FACILITYDECNBEDDAY = 'facilityDecnBedDay',
    DIAGNOSES = 'diagnoses',
    DIAGNOSIS = 'diagnosis',
    FACILITY = 'facility',
    SERVICES = 'services',
    SERVICE = 'service',
    SERVICEFACILITY = 'serviceFacility',
    SERVICENONFACILITY = 'serviceNonFacility',
    SERVICEDELIVERY = 'serviceDelivery',
    AMBULANCE = 'ambulanceInformation',
    SPINALMANIPULATION = 'spinalManipulationInformation',
    HOMEOXYGEN = 'homeOxygen',
    HOMEHEALTHCARE = 'homeHealthCare',
    SOURCEDATA = 'sourceData'
};

export enum canonicalResponseTags {
    RESPONSEXMLNS = 'http://uhg.com/app/icue/edihub/canonicalresponse/xml'
};

export enum hscAttributes {
    CREATEDATE = 'createDate',
    CREATETIME = 'createTime',
    OTHERUMOTYPE = 'otherUMOType',
    BATCHFILEID = 'batchFileID',
    ACCIDENTDATE = 'accidentDate',
    LASTMENSTRUALPERIODDATE = 'lastMenstrualPeriodDate',
    ESTIMATEDDATEOFBIRTH = 'estimatedDateOfBirth',
    ONSETOFILLNESSDATE = 'onsetOfIllnessDate',
    NOTE = 'note',
    OTHERUMONAME = 'otherUMOName',
    OTHERUMODENIALDATE = 'otherUMODenialDate',
    IDCODE = 'idCode',
    REVIEWIDDESC = 'reviewIdDesc',
    REPORTTYPECODE = 'reportTypeCode',
    REPORTTRANSMISSIONCODE = 'reportTransmissionCode',
    IDCODEQUALIFIER = 'idCodeQualifier'
};

export enum dataTransmissionHeaderAttributes {
    SOURCETYPE = 'sourceType',
    TRANSACTIONID = 'transactionID',
    VERSION = 'version',
    BATCHFILEID = 'batchFileID',
    RECEIVEDDATETIME = 'receivedDateTime',
    PURPOSECODE = 'purposeCode',
    TRANSACTIONTYPE = 'transactionType',
    TRANSACTIONSTATUS = 'transactionStatus',
    TESTFLAG = 'testFlag',
    CLINICALAPPLICATION = 'clinicalApplication',
    PAYERID = 'payerID',
    SUBMITTERID = 'submitterID',
    SOURCEDATA = 'sourceData',
    TRADINGPARTNERID = 'tradingPartnerID'
};

export enum providerAttributes {
    PROVIDERSEQNUM = 'providerSeqNum',
    ENTITYIDENTIFIER = 'entityIdentifier',
    ENTITYTYPE = 'entityType',
    PROVIDERTYPE = 'providerType',
    BUSINESSNAME = 'businessName',
    FIRSTNAME = 'firstName',
    MIDDLENAME = 'middleName',
    LASTNAME = 'lastName',
    SUFFIXNAME = 'suffixName',
    PROVIDERNPI = 'providerNPI',
    FEDERALTAXID = 'federalTaxID',
    FEDERALTAXIDSUFFIX = 'federalTaxIDSuffix',
    NDBMPIN = 'ndbMpin',
    PROVIDERTAXONOMYCODE = 'providerTaxonomyCode',
    ADDRESS1 = 'address1',
    ADDRESS2 = 'address2',
    CITY = 'city',
    STATE = 'state',
    ZIP = 'zip',
    ZIPSUFFIX = 'zipSuffix',
    COUNTRYCODE = 'countryCode',
    CONTACTNAME = 'contactName',
    PRIMARYPHONE = 'primaryPhone',
    PRIMARYPHONEEXT = 'primaryPhoneExt',
    SECONDARYPHONE = 'secondaryPhone',
    SECONDARYPHONEEXT = 'secondaryPhoneExt',
    FAX = 'fax',
    FAXEXT = 'faxExt',
    EMAILADDRESS = 'emailAddress'
};

export enum followUpContactAttributes {
    CONTACTNAME = 'contactName',
    PRIMARYPHONE = 'primaryPhone',
    MEDICALRECORDNUMBER = 'medicalRecordNumber',
    CONTACTPROVIDERSEQNUM = 'contactProviderSeqNum',
    PRIMARYPHONEEXT = 'primaryPhoneExt',
    SECONDARYPHONE = 'secondaryPhone',
    FAX = 'fax',
    EMAILADDRESS = 'emailAddress',
    SOURCEDATA = 'sourceData'
};

export enum memberAttributes {
    FIRSTNAME = 'firstName',
    LASTNAME = 'lastName',
    MIDDLENAME = 'middleName',
    SUFFIXNAME = 'suffixName',
    BIRTHDATE = 'birthDate',
    GENDER = 'gender',
    SUBSCRIBERFIRSTNAME = 'subscriberFirstName',
    SUBSCRIBERLASTNAME = 'subscriberLastName',
    SUBSCRIBERBIRTHDATE = 'subscriberBirthDate',
    SUBSCRIBEREMPLOYMENTSTATUS = 'subscriberEmploymentStatus',
    RELATIONSHIPCODE = 'relationshipCode',
    GROUPID = 'groupID',
    DIVID = 'divID',
    ELIGIBILITYSYSTEMTYPE = 'eligibilitySystemType',
    SOURCECODE = 'sourceCode',
    CLAIMSYSTEMCODE = 'claimSystemCode',
    MEMBERIDTYPE = 'memberIDType',
    MEMBERID = 'memberID',

    ADDRESSTYPE = 'addressType',
    ADDRESS1 = 'address1',
    ADDRESS2 = 'address2',
    CITY = 'city',
    STATE = 'state',
    ZIP = 'zip',
    ZIPSUFFIX = 'zipSuffix',
    COUNTRYCODE = 'countryCode',
    SOURCEDATA = 'sourceData'
};

export enum diagnosisAttributes {
    DIAGNOSISSEQNUM = 'diagnosisSeqNum',
    DIAGNOSISCODETYPE = 'diagnosisCodeType',
    DIAGNOSISCODE = 'diagnosisCode',
    DIAGNOSISDATE = 'diagnosisDate',
    PRIMARYIND = 'primaryInd',
    ADMITIND = 'admitInd',
    SOURCEDATA = 'sourceData'
};

export enum facilityAttributes {
    SERVICEREFERENCENUM = 'serviceReferenceNum',
    REQUESTCATEGORY = 'requestCategory',
    CERTFICATIONTYPE = 'certificationType',
    ADMISSIONTYPECODE = 'admissionTypeCode',
    SERVICETYPE = 'serviceType',
    FACILITYCODEQUALIFIER = 'facilityCodeQualifier',
    FACILITYCODE = 'facilityCode',
    LEVELOFSERVICE = 'levelOfService',
    ADMISSIONDATE = 'admissionDate',
    DISCHARGEDATE = 'dischargeDate',
    FACILITYPROVIDERSEQNUM = 'facilityProviderSeqNum',
    PATIENTSTATUSCODE = 'patientStatusCode',
    QUANTITYQUALIFIER = 'quantityQualifier',
    QUANTITY = 'quantity',
    DECISIONOUTCOMETYPEID = 'decisionOutcomeTypeID',
    REVENUECODE = 'revenueCode',
    BEDTYPEID = 'bedTypeID'
};

export enum serviceAttributes {
    SERVICERSEQNUM = 'serviceSeqNum',
    SERVICEREFERENCENUM = 'serviceReferenceNum',
    REQUESTCATEGORY = 'requestCategory',
    CERTFICATIONTYPE = 'certificationType',
    SERVICETYPE = 'serviceType',
    LOCATIONCODEQUALIFIER = 'locationCodeQualifier',
    LOCATIONCODE = 'locationCode',
    SERVICESTARTDATE = 'serviceStartDate',
    SERVICEENDDATE = 'serviceEndDate',
    SERVICEPROVIDERSEQNUM = 'serviceProviderSeqNum',
    NOTE = 'note',
    ACTIONCODE = 'actionCode',

    REVENUECODE = 'revenueCode',
    PROCEDURECODETYPE = 'procedureCodeType',
    PROCEDURECODE = 'procedureCode',
    PROCEDUREMODIFIER1 = 'procedureModifier1',
    PROCEDUREMODIFIER2 = 'procedureModifier2',
    PROCEDUREMODIFIER3 = 'procedureModifier3',
    PROCEDUREMODIFIER4 = 'procedureModifier4',
    PROCEDUREDESCRIPTION = 'procedureDescription',
    PROCEDURECODE2 = 'procedureCode2',
    MONETARYAMOUNT = 'monetaryAmount',
    UNITCODE = 'unitCode',
    QUANTITY = 'quantity',
    UNITRATE = 'unitRate',
    NURSINGHOMESTATUSCODE = 'nursingHomeStatusCode',
    NURSINGHOMELEVELOFCARE = 'nursingHomeLevelOfCare',
    DIAGNOSISSEQNUM1 = 'diagnosisSeqNum1',
    DIAGNOSISSEQNUM2 = 'diagnosisSeqNum2',
    DIAGNOSISSEQNUM3 = 'diagnosisSeqNum3',
    DIAGNOSISSEQNUM4 = 'diagnosisSeqNum4',
    EPSDTIND = 'epsdtInd',
    LEVELOFCARE = 'levelOfCare',
    QUANTITYQUALIFIER = 'quantityQualifier',

    SAMPLESELECTIONMODULUS = 'sampleSelectionModulus',
    TIMEPERIODQUALIFIER = 'timePeriodQualifier',
    NUMBEROFPERIODS = 'numberOfPeriods',

};

export enum ambulanceInfoAttributes {
    TRANSPORTCODE = 'transportCode',
    DISTANCEUNITS = 'distanceUnits',
    DISTANCE = 'distance',
};

export enum spinalManipulationInformationAttributes {
    TREATMENTSERIES = 'treatmentSeries',
    TREATMENTCOUNT = 'treatmentCount',
    SUBLUXATIONLEVEL1 = 'subluxationLevel1',
    SUBLUXATIONLEVEL2 = 'subluxationLevel2',
};

export enum homeOxygenAttributes {
    OXYGENEQUIPMENTCODE1 = 'oxygenEquipmentCode1',
    OXYGENEQUIPMENTCODE2 = 'oxygenEquipmentCode2',
    OXYGENEQUIPMENTCODE3 = 'oxygenEquipmentCode3',
    OXYGENFLOWRATE = 'oxygenFlowRate',
    DAILYOXYGENUSE = 'dailyOxygenUse',
    OXYGENUSEPERHOUR = 'oxygenUsePerHour',
    RESPIRATORYTHERAPISTORDER = 'respiratoryTherapistOrder',
    PORTABLEOXYGENSYSTEMFLOWRATE = 'portableOxygenSystemFlowRate',
    OXYGENDELIVERYSYSTEM = 'oxygenDeliverySystem'
};

export enum homeHealthCareAttributes {
    PROGNOSISCODE = 'prognosisCode',
    HOMEHEALTHSTARTDATE = 'homeHealthStartDate',
    CERTIFICATIONPERIODSTART = 'certificationPeriodStart',
    CERTIFICATIONPERIODEND = 'certificationPeriodEnd',
    CERTIFICATIONTYPE = 'certificationType'
};

export const eventNotes = {
    ACCIDENTDATE: 'AccidentDate',
    LMP: 'LMP',
    EDC: 'EDC',
    ONSETOFILLNESSDATE: 'OnsetofIllnessDate',
    OTHERUMONAME: 'otherUMOName',
    OTHERUMODENIALDATE: 'otherUMODenialDate',
    ACTIONCODE: 'actionCode'
};

export const facilityNotes = {
    PATIENTSTATUS: 'PatientStatus',
};

export const diagnosisNotes = {
    DIAGNOSISDATE: 'DiagnosisDate',
};


export const ambulanceNotes = {
    TRANSPORT_CODE: 'Patient Status',
    DISTANCE: 'Distance'
};

export const homeOxygenNotes = {
    PATIENTSTATUS: 'Patient Status',
    O2_EQUIPMENT_1: 'O2 Equipment 1',
    O2_EQUIPMENT_2: 'O2 Equipment 2',
    O2_EQUIPMENT_3: 'O2 Equipment 2',
    FLOW_RATE: 'Flow Rate',
    DAILY_USE: 'Daily Use',
    USE_PER_HOUR: 'Use per hour',
    RT_ORDER: 'RT Order',
    PORTABLE_O2_RATE: 'Portable O2 Rate',
    DELIVERY_SYSTEM: 'Delivery System'
};

export type RequestDetails = {
    dataTransmissionHeader: DataTransHeader;
    Membership: Member;
    Individual: Indiv;
    Provider: Provider;
    Facility: FacilityData;
    Diagnosis: DiagnosisData;
    Event: EventData;
    procCodes: procCDdetails[];
    Service: ServiceData;
    updateHscRequest: HscData;
    hscSourceData: any;
    ediType: string;
    followUpContact: any;
    Error: Error;
};

export type DataTransHeader = {
    sourceType: string;
    transactionID: string;
    version: number;
    batchFileID: string;
    receivedDateTime: string;
    purposeCode: string;
    transactionType: string;
    transactionStatus: string;
    testFlag: string;
    clinicalApplication: string;
    payerID: string;
    submitterID: string;
    ediID: number;
    sourceData: string;
    tradingPartnerID: string;
};

export type Hsc = {
    hsc: HscData;
};

export type EventData = {
};

export type Error = {
    dataTransmissionHeader: any;
    member: any;
    provider: any;
    followUpContact: any;
    diagnosis: any;
    facility: any;
    service: any;
};

export type ErrorDetails = {
    errorCode: string;
    errorDescription: string;
    errorLoop: string;
    followUpActionCode: string;
    reasonRejectCode: string;
};

export type HscProviderDetails = {
    creat_user_id: string;
    chg_user_id: string;
    id: number;
    //   sufx_nm: string;
    fst_nm: string;
    midl_nm: string;
    lst_nm: string;
    bus_nm: string;
    prov_keys: [object];
    hsc_prov_roles: ProviderRole[];
    prov_adr: any;
    prov_loc_affil_dtl: any;
};

export type HscPwkDetails = {
    hsc_clin_guid_id: string;
    clin_rev_desc: string;
    clin_rev_otcome_ref_id: number;
    clin_rev_sts_ref_id: number;
};

export type EventDetails = {
    idCode: any;
    reviewIdDesc: any;
    reportTypeCode: any;
    reportTransmissionCode: any;
    idCodeQualifier: any;
    accidentDate: any;
    note: any;
    createTime: any;
    createDate: any;
};

export type HscData = {
    creat_user_id: string;
    chg_user_id: string;
    hsc_id: number;
    indv_key_typ_ref_id: number;
    indv_key_val: string;
    mbr_cov: MemberCovDtl;
    srvc_set_ref_id: number;
    hsc: any;
    //hsc_rev_typ_ref_id: number;
    //hsc_sts_ref_id: number;
    //hsc_sts_rsn_ref_id: number;
    //auth_typ_ref_id: number;
    //creat_sys_ref_id: number;
    //chg_sys_ref_id: number;
    //rev_prr_ref_id: any;
    hsr_notes: Note[];
    hsc_diags: Diagnosis[];
    flwup_cntc_dtl: FollowUpContact;
    hsc_provs: HscProviderDetails[];
    hsc_facl: Facility;
    hsc_srvcs: Service[];
    hsc_keys: HscKey[];
    hsc_clin_guid: HscPwkDetails[];
};

export type HSC = {
    hsc_rev_typ_ref_id: any;
    hsc_sts_ref_id: any;
    hsc_sts_rsn_ref_id: any;
    auth_typ_ref_id: any;
    creat_sys_ref_id: any;
    chg_sys_ref_id: any;
    rev_prr_ref_id: any;
};

export type Provider = {
    prov: ProviderData[];
};

export type ProviderData = {
    prov_indvs: ProviderIndv;
    prov_orgs: ProviderOrg;
    prov_adrs: ProviderAddress[];
    providerSeqNum: any;
    ediType: any;
    entityType: any;
    ndbMpin: any;
    providerNPI: any;
    federalTaxID: any;
    loopID: any;
    facilityProviderSeqNum: any;
    providerType: any;
    firstName: any;
    requestCategory: any;
    lastName: any;
    businessName: any;
    federalTaxIDSuffix: any;
    entityIdentifier: any;
    sourceData: any;
    prov_loc_affil_dtl: any;
    // providerTaxonomyCode: any;
    // countryCode: any;
    // contactName: any;
    // primaryPhoneExt: any;
    // secondaryPhoneExt: any;
    // faxExt: any;
    // emailAddress: any;
};

export type ProviderAddress = {
    adr_ln_1_txt: string;
    adr_ln_2_txt: string;
    cty_nm: string;
    st_ref_id: string;
    zip_cd_txt: string;
    zip_sufx_cd_txt: string;
};

export type ProviderLocAffilDtl = {
    primary_Phone: string;
    secondary_Phone: string;
    faxNum: string;
    primaryPhoneExt: any;
    secondaryPhoneExt: any;
    faxExt: any;
    countryCode: any;
    providerTaxonomyCode: any;
    contactName: any;
    emailAddress: any;

};

export type HSC_PROV = {
    providerTaxonomyCode: any;
    countryCode: any;
    contactName: any;
    primaryPhoneExt: any;
    secondaryPhoneExt: any;
    faxExt: any;
    emailAddress: any;
};

export type ProviderOrg = {
    bus_nm: string;
};

export type ProviderIndv = {
    fst_nm: string;
    midl_nm: string;
    lst_nm: string;
    sufx_nm: string;
};

export type ProviderRole = {
    prov_role_ref_id: any;
};

export type HscKey = {
    creat_user_id: string;
    chg_user_id: string;
    hsc_key_val: string;
    hsc_key_typ_ref_id: number;
    inac_ind: any;
};


export  type HscKeys = {
    hsc_id: any;
    hsc_key_typ_ref_id: number;
};

export type Diagnosis = {
    diag_cd: any;
    pri_ind: number;
    diag_othr_txt: string;
    diag_cd_schm_ref_id: number;
    admit_ind: number;
    inac_ind: number;
    creat_user_id: string;
    chg_user_id: string;
};

export type Member = {
    mbrshp: Membership;
};

export type Indiv = {
    indv: Indv;
};

export type Indv = {
    fst_nm: string;
    lst_nm: string;
    midl_nm: string;
    sufx_nm: string;
    bth_dt: string;
    gdr_ref_id: number;
    sourceData: string;
    indv_adrs: IndvAddress[];
};

export type IndvAddress = {
    adr_ln_1_txt: string;
    adr_ln_2_txt: string;
    cty_nm: string;
    st_ref_id: string;
    zip_cd_txt: string;
    zip_sufx_cd_txt: string;
    cntry_ref_id: string;
};

export type Membership = {
    sbscr_fst_nm: string;
    sbscr_lst_nm: string;
    sbscr_empmt_dt: string;
    cob_ind: string;
    mbr_rel_ref_id: string;
    scrbr_id_txt: any;
    sbscr_bth_dt: any;
    //memberIDType: any;
    mbr_covs: MemberCoverage[];
};

export type MemberCoverage = {
    pol_nbr: string;
    grp_nbr: string;
};

/*export  type procCodes = {
    procCodes: procCDdetails[];
};*/

export type procCDdetails = {
    reqCategory: any;
    procCode: any;
};


export type MemberCovDtl = {
    fst_nm: string;
    lst_nm: string;
    midl_nm: string;
    sufx_nm: string;
    bth_dt: any;
    gdr_ref_id: number;
    orig_sys_cd: string;
    src_mbr_id: string;
    src_mbr_partn_id: string;
    cov_eff_dt: any;
    cov_end_dt: any;
    pol_nbr: string;
    grp_nbr: string;
    cov_typ_ref_id: number;
    clm_pltfm_ref_id: number;
};

export type FollowUpContact = {
    department: string;
    email: any;
    phone: any;
    //dphoneExt: any;
    fax: any;
    role: any;
    name: any;
    primaryContact: boolean;
};

export type FollowUpContactData = {
    prov_role_ref_id: string;
    sourceData: string;
};


export type PrimaryContact = {
    department: string;
    email: string;
    phone: string;
    fax: string;
    role: string;
    name: string;
};

export type SecondaryContact = {
    department: string;
    email: string;
    phone: string;
    fax: string;
    role: string;
    name: string;
};

export type FacilityData = {
    requestCategory: any;
    certificationType: any;
    admissionDate: any;
    dischargeDate: any;
    facilityProviderSeqNum: any;
    serviceReferenceNum: any;
};

export type DiagnosisData = {
    diagnosisSeqNum: any;
    diagnosisCodeType: any;
    diagnosisCode: any;
};
export type ServiceData = {
    requestCategory: any;
    serviceType: any;
    certificationType: any;
    actionCode: any;
    serviceSeqNum: any;
    serviceEndDate: any;
    serviceReferenceNum: any;
    serviceFacility: any;
    serviceNonFacility: any;
    serviceDelivery: any;
};

export type HSCval = {
    "hsc": any;
    "ediType": any;
    "sourceChannel": any;
};

export type ServiceFacilityData = {
    monetaryAmount: any;
    unitCode: any;
    quantity: any;
};

export type serviceDeliveryData = {
    unitCode: any;
    quantity: any;
    quantityQualifier: any;
    sampleSelectionModulus: any;
    timePeriodQualifier: any;
    numberOfPeriods: any;
};


export type ServiceNonFacilityData = {
    monetaryAmount: any;
    unitCode: any;
    quantity: any;
};


export type Facility = {
    plsrv_ref_id: number;
    srvc_desc_ref_id: number;
    srvc_dtl_ref_id: number;
    expt_admis_dt: string;
    expt_dschrg_dt: string;
    actul_admis_dttm: string;
    actul_dschrg_dttm: string;
    admis_ntfy_dttm: string;
    admis_ntfy_trans_id: string;
    adv_ntfy_trans_id: string;
    ctp_nom_sts_ref_id: number;
    dschrg_disp_ref_id: number;
    dschrg_ntfy_trans_id: string;
    goal_los_day_cnt: string;
    ipcm_typ_ref_id: number;
    rem_snf_day_cnt: string;
    snf_day_xhst_ind: number;
    tat_due_dttm: string;
    hsc_decn: HscFaclDecision;
};

export type FacilityNotes = {
    patientStatusCode: string;
};

export type FacBedDay = {
    rvnu_cd: string;
    bed_typ_ref_id: number;
    accum_bed_day_cnt: string;
    decn_facl_cmnct_dttm: string;
    decn_rndr_dttm_facl_lcl_txt: string;
    questnr_rspn_id: string;
    strt_bed_dt: string;
};

export type SrvcFacBedDay = {
    strt_bed_dt: string;
    rvnu_cd: string;
    bed_typ_ref_id: number;
};

export type HscFaclDecision = {
    decn_otcome_ref_id: any;
    decn_typ_ref_id: any;
    decn_rsn_ref_id: any;
    actual_nxt_rev_dt: string;
    decn_bed_day_cnt: string;
    aprv_proc_unit_cnt: string;
    aprv_unit_per_freq_cnt: string;
    ben_lvl_ref_id: number;
    ben_xcpt_ref_id: number;
    clm_note_txt: string;
    decn_clin_rsn_txt: string;
    decn_ent_by_user_id: string;
    decn_ent_rsn_ref_id: number;
    decn_hsc_prov_id: string;
    decn_made_by_user_id: string;
    decn_made_by_user_org_desc: any;
    decn_mbr_cmnct_dttm: string;
    decn_mbr_cmnct_to_role_ref_id: number;
    decn_prov_cmnct_ddtm: string;
    decn_prov_cmnct_to_role_ref_id: number;
    decn_rndr_dttm: string;
    decn_src_desc: any;
    decn_ur_jurdc_ref_id: number;
    gap_rev_otcome_ref_id: number;
    ltr_atr_list: any;
    mbr_cov_dtl: any;
    negot_rt: any;
    negot_rt_type_ref_id: number;
    ovrd_clm_rmrk_ref_id: any;
    sys_clm_rmrk_ref_id: any;
    wrt_decn_cmnct_dttm: any;
    decn_prov_cmnct_dttm: any;
    ovrd_rsn_ref_id: number;
    ovrd_rsn_txt: string;
    peer_to_peer_rev_dt: string;
    sched_nxt_rev_dt: string;
    site_of_care_pref_ref_id: number;
    hsc_decn_bed_days: FacBedDay[];
};

export type HscSrvcDecision = {
    decn_otcome_ref_id: any;
    decn_typ_ref_id: any;
    decn_rsn_ref_id: any;
    clm_note_txt: string;
    ovrd_clm_rmrk_ref_id: number;
    sys_clm_rmrk_ref_id: number;
    wrt_decn_cmnct_dttm: string;
    decn_rndr_dttm: string;
    decn_mbr_cmnct_dttm: string;
    decn_prov_cmnct_dttm: string;
    gap_rev_otcome_ref_id: number;
    negot_rt: number;
    hsc_decn_bed_days: SrvcFacBedDay[];
};

export type Note = {
    note_titl_txt: any;
    note_txt_lobj: any;
    src_user_nm: string;
    note_typ_ref_id: number;
    note_catgy_ref_id: number;
};

export type Event = {
    accidentDate: string;
    LMP: string;
    EDC: string;
    onsetOfIllnessDate: string;
    otherUMOName: string;
    otherUMODenialDate: string;
};

export type Service = {
    //creat_user_id: string;
    //chg_user_id: string;
    proc_cd: string;
    proc_cd_schm_ref_id: number;
    expmt_proc_ind: number;
    hsc_srvc_rev_typ_ref_id: number;
    adv_ntfy_trans_id: string;
    ben_chk_sts_ref_id: number;
    adv_ntfy_dttm: string;
    expt_proc_dt: string;
    inac_ind: 0,
    proc_othr_txt: string;
    srvc_hsc_prov_id: null;
    hsc_prov: HscProviderDetails;
    hsc_decn: HscSrvcDecision;
};

export type ServiceNotes = {
    nursingHomeStatusCode: string;
    nursingHomeLevelOfCare: string;
    //  diagnosisSeqNum1: string;
    //  diagnosisSeqNum2: string;
    //  diagnosisSeqNum3: string;
    //  diagnosisSeqNum4: string;
    //  epsdtInd: string;
    //   levelOfCare: string;
    // actionCode: string;
};

export type MbrCov = {
    fst_nm: string;
    lst_nm: string;
    midl_nm: string;
    sufx_nm: string;
    bth_dt: string;
    gdr_ref_id: number;
    orig_sys_cd: string;
    src_mbr_id: string;
    src_mbr_partn_id: string;
    cov_eff_dt: string;
    cov_end_dt: string;
    pol_nbr: string;
    cov_typ_ref_id: number;
    clm_pltfm_ref_id: number;
    sbscr_fst_nm: string;
    sbscr_lst_nm: string;
    // subscriberBirthDate: string;
    sbscr_empmt_dt: string;
    mbr_rel_ref_id: number;
    grp_nbr: number;
    div_id: string;
    eligibilitySystemType: string;
    //sourceCode: string;
};

export type ServiceNonFacility = {
    srvc_dtl_ref_id: string;
    plsrvc_ref_id: string;
    srvc_strt_dt: string;
    srvc_end_dt: string;
    proc_mod_1_cd: string;
    proc_mod_2_cd: string;
    proc_mod_3_cd: string;
    proc_mod_4_cd: string;
    proc_uom_ref_id: string;
    proc_unit_cnt: string;
    unit_per_freq_cnt: string;
    unit_per_ref_id: string;
    hsc_srvc_non_facl_dmes: ServiceNonFacilityDME;
};

export type ServiceNonFacilityDME = {
    dme_tot_cst_amt: string;
};

export const PatientStatusCode = {
    PATIENT_STATUS_CODE_1: 'Discharged to home or self care',
    PATIENT_STATUS_CODE_2: 'Discharged/transferred to a short-term general hospital for inpatient care',
    PATIENT_STATUS_CODE_3: 'Discharged/transferred to SNF with Medicare certification in anticipation of covered skilled care',
    PATIENT_STATUS_CODE_4: 'Discharged/transferred to an Intermediate Care Facility',
    PATIENT_STATUS_CODE_5: 'Discharged/transferred to another type of institution not defined elsewhere in this code list',
    PATIENT_STATUS_CODE_6: 'Discharged/transferred to home under care of organized home health service organization in anticipation of covered skills care',
    PATIENT_STATUS_CODE_7: 'Left against medical advice or discontinued care',
    PATIENT_STATUS_CODE_9: 'Admitted as an inpatient to this hospital',
    PATIENT_STATUS_CODE_20: 'Expired',
    PATIENT_STATUS_CODE_30: 'Still patient or expected to return for outpatient services',
    PATIENT_STATUS_CODE_40: 'Expired at home',
    PATIENT_STATUS_CODE_41: 'Expired in a medical facility, such as a hospital, SNF, ICF or freestanding hospice',
    PATIENT_STATUS_CODE_42: 'Expired - place unknown',
    PATIENT_STATUS_CODE_43: 'Discharged/transferred to a federal health care facility',
    PATIENT_STATUS_CODE_50: 'Discharged/transferred to Hospice - home',
    PATIENT_STATUS_CODE_51: 'Discharged/transferred to Hospice - medical facility',
    PATIENT_STATUS_CODE_61: 'Discharged/transferred within this institution to a hospital based Medicare approved swing bed',
    PATIENT_STATUS_CODE_62: 'Discharged/transferred to an inpatient rehabilitation facility including distinct part units of a hospital',
    PATIENT_STATUS_CODE_63: 'Discharged/transferred to long term care hospitals',
    PATIENT_STATUS_CODE_64: 'Discharged/transferred to a nursing facility certified under Medicaid but not certified under Medicare',
    PATIENT_STATUS_CODE_65: 'Discharged/transferred to a psychiatric hospital or psychiatric distinct part unit of a hospital',
    PATIENT_STATUS_CODE_66: 'Discharged/transferred to a Critical Access Hospital',
    PATIENT_STATUS_CODE_70: 'Discharge/transfer to another type of health care institution not defined elsewhere in the code list'
};