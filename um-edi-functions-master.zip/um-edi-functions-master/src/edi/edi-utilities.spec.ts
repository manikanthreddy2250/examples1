import { Test, TestingModule } from '@nestjs/testing';
import {Injectable} from "@nestjs/common";
import {EdiUtilities} from "./edi-utilities";
import {canonicalRequestTags} from "./constants/edi.constants";
import {canonicalRequest} from "../../test/ediTestData";


describe('EdiUtilities', () => {
  let component: EdiUtilities;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
        providers: [EdiUtilities],
    }).compile();

    component = module.get<EdiUtilities>(EdiUtilities);
  });

  it('should be defined', () => {
    expect(component).toBeDefined();
  });

  it('should run #getRequestInfo()', async () => {
    component.getRequestInfo(canonicalRequestTags.MEMBER, canonicalRequestTags.MEMBERIDENTIFIERS);
    spyOn(component, 'getRequestInfo');
    expect(component.getRequestInfo).toBeTruthy();
  });

  it('should run #getElementInfo()', async () => {
    component.getElementInfo(canonicalRequest, canonicalRequestTags.DATATRANSMISSIONHEADER);
    spyOn(component, 'getElementInfo');
    expect(component.getElementInfo).toBeTruthy();
  });

  it('should run #getElementAttributeInfo()', async () => {
    component.getElementAttributeInfo(canonicalRequest, canonicalRequestTags.DATATRANSMISSIONHEADER);
    spyOn(component, 'getElementAttributeInfo');
    expect(component.getElementAttributeInfo).toBeTruthy();
  });

  it('should run #getAttributeValue()', async () => {
    component.getAttributeValue(canonicalRequestTags.MEMBER, canonicalRequestTags.MEMBERIDENTIFIERS);
    spyOn(component, 'getRequestInfo');
    expect(component.getAttributeValue).toBeTruthy();
  });

  it('should run #ediLookupData()', async () => {
    component.ediLookupData("patientStatusCode", "61");
    spyOn(component, 'ediLookupData');
    expect(component.ediLookupData).toBeTruthy();
  });
});
