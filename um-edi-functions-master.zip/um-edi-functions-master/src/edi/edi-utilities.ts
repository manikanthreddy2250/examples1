import {Injectable} from "@nestjs/common";
import * as fs from "fs";

@Injectable()
export class EdiUtilities {

    getRequestInfo(data, tagName) {
        var result;
        if (data && data.search("<" + tagName + ">") != -1) {
            result = data.split("<" + tagName + ">").pop().split("</" + tagName + ">")[0];
        }
        return result;
    }

    getElementInfo(data, tagName) {
        var result;
        if (data && data.search("<" + tagName + " ") != -1) {
            result = data.split("<" + tagName + " ").pop().split("</" + tagName + ">")[0];
        }
        return result;
    }

    getElementAttributeInfo(data, tagName) {
        var result;
        if (data && data.search("<" + tagName) != -1) {
            result = data.split("<" + tagName).pop().split(">")[0];
        }
        return result;
    }

    getAttributeValue(data, attributeName) {
        var attributeValue;

        if (data && data.search(attributeName + "=\"") != -1) {
            attributeValue = data.split(attributeName + "=\"").pop().split("\"")[0];
            return attributeValue
        }
        return null;
    }

    isAlphaNumeric = require('is-alphanumeric');


    removeLineBreaks(data) {
        if (data) {
            var string = data.replace(/(\r\n|\n|\r)/gm, "");
            string = string.replace(/^\s+|\s+$/g, '');
            //  string.trim();
            return string;
        }
        return null
    }

    containsDecimal(data) {
        if (data && data.indexOf(".") != -1 ) {
            return true;
        }
        return false;
    }

    async ediLookupData(Attribute, statuscode) {
        const csvFile = fs.readFileSync('src/resource/edi_lookup_data.csv','utf8')
        const csvToRowArray = csvFile.split('\n');
        for (let index = 1; index < csvToRowArray.length - 1; index++) {
            const row  = csvToRowArray[index].split(",") as any;
            if (Attribute == row[0] && statuscode == row[1] ){
                const statusdescription = row[2].trim();
                return statusdescription.trim();
            }
        }

    }

}