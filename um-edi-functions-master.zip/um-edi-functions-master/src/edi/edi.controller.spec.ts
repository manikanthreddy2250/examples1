import { Test, TestingModule } from '@nestjs/testing';
import { EdiController } from './edi.controller';
import {EdiRequestService} from "./services/edi-request.service";
import {EdiResponseService} from "./services/edi-response.service";
import {UpdateHscApiService} from "./services/updateHscAPI/updateHscApi.service";
import {Injectable} from "@nestjs/common";
import {DuplicateCheck} from "./services/duplicateCheck/duplicateCheck.service";
import {LoggerModule, PinoLogger} from "nestjs-pino/dist";
import {ConfigService,ConfigModule} from '@nestjs/config';

import {testRequest} from "../../test/ediTestData";
import {request} from "http";



@Injectable()
class EdiRequestServiceMock {
}

@Injectable()
class EdiResponseServiceMock {
}

@Injectable()
class UpdateHscApiServiceMock {
}

@Injectable()
class DuplicateCheckMock {
}

@Injectable()
class LoggerMock {
}

describe('EdiController', () => {
  let controller: EdiController;
  let config: ConfigService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      imports: [ConfigModule, LoggerModule.forRoot()],
      controllers: [EdiController],
      providers: [{provide: EdiRequestService, useClass: EdiRequestServiceMock},
                  {provide: EdiResponseService, useClass: EdiResponseServiceMock},
                  {provide: UpdateHscApiService, useClass: UpdateHscApiServiceMock},
                  {provide: DuplicateCheck, useClass: DuplicateCheckMock}]
    }).compile();

    controller = module.get<EdiController>(EdiController);
    config = module.get<ConfigService>(ConfigService);
  });

  it('should be defined', () => {
      expect(controller).toBeDefined();
  });

    it('should run #canonicalToJSONTranslate()', async () => {
        let request = testRequest;
        // @ts-ignore
        controller.canonicalToJSONTranslate(request);
        expect(controller).toBeTruthy();
    });

    it('should run #processEDIMessage()', async () => {
        let request = testRequest;
        // @ts-ignore
        controller.processEDIMessage(request);
        expect(controller).toBeTruthy();
    });

    it('should run #processEDIMessageKafka()', async () => {
        let request = testRequest;
        // @ts-ignore
        controller.processEDIMessageKafka(request);
        expect(controller).toBeTruthy();
    });

    it('should run #processCanonicalResponseXML()', async () => {
        let request = testRequest;
        // @ts-ignore
        controller.processCanonicalResponseXML(request);
        expect(controller).toBeTruthy();
    });

    it('should run #DuplicateCheck()', async () => {
        let request = testRequest;
        // @ts-ignore
        controller.DuplicateCheck(request);
        expect(controller).toBeTruthy();
    });
});
