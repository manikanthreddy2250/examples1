import {Body, Controller, Delete, HttpStatus, Post, Put, Req, Res, UseGuards, UseInterceptors, Injectable} from '@nestjs/common';
import {EdiRequestService} from './services/edi-request.service';
import {Context} from "@nestjs/graphql";
import {JwtStrategy} from "../auth/jwt.strategy";
import {AuthGuard} from "../auth/auth.guard";
import {RolesGuard} from "../auth/roles.guard";
import {ApiBearerAuth} from "@nestjs/swagger";
import {Request, Response} from 'express';
import {EdiResponseService} from "./services/edi-response.service";
import {canonicalRequestTags, Hsc, memberAttributes} from "./constants/edi.constants";
import {Edi278NConstants} from "./constants/edi-278N.constants";
import {UpdateHscApiService} from "./services/updateHscAPI/updateHscApi.service";
import {DuplicateCheck} from "./services/duplicateCheck/duplicateCheck.service";
import {InjectPinoLogger, PinoLogger} from "nestjs-pino/dist";
import {timestamp} from "rxjs/operators";

@Injectable()
@Controller('edi')
export class EdiController {

    constructor(private readonly ediRequestService: EdiRequestService,
                private readonly ediResponseService: EdiResponseService,
                private readonly updateHscApiService: UpdateHscApiService,
                private readonly duplicateCheckService: DuplicateCheck,
                //private readonly logger: Logger
                @InjectPinoLogger(EdiController.name) private readonly logger: PinoLogger) {
    }

    @Post('/canonicalToJSONTranslate')
    //@UseGuards(AuthGuard('jwt'))
    async canonicalToJSONTranslate(@Req() request: Request) {

        this.logger.info("Before Query Call To canonicalToJSONTranslate API " + new Date());
        const req = await this.ediRequestService.canonicalToJSONTranslate(request);
        this.logger.info("After Query Call To canonicalToJSONTranslate API " + new Date());
        return req;
    }

    @Post('/processEDIMessage')
//@UseGuards(AuthGuard)
    async processEDIMessage(@Req() request: Request) {
        let canonicalResponse;
        //Transform Canonical Request XML to JSON Object
        this.logger.info("Before Query Call To processEDIMessage API " + new Date());
        var requestJSON = await this.ediRequestService.processEDIMessage(request);
        //console.log("UPDATE HSC REQUEST OBJECT:" + JSON.stringify(requestJSON.updateHscRequest));

        //Call Update HSC API
        const hscResponse = await this.updateHscApiService.updateHsc(requestJSON.updateHscRequest, request);
        console.log("UPDATE HSC RESPONSE OBJECT:" + JSON.stringify(hscResponse));


        requestJSON.hscResponse = hscResponse.hsc[0];
        //console.log("hscResponse +++++++++++++++++++++++++++++++++> " + JSON.stringify(requestJSON.hscResponse));
        //Creating Canonical Response
        if (hscResponse) {
            canonicalResponse = await this.ediResponseService.processEdiResponse(requestJSON, requestJSON.ediType);
        } else {
            return "Error in Updating HSC Details..."
        }
        this.logger.info("After Query Call To processEDIMessage API " + new Date());
        return canonicalResponse;
    }

    @Post('/processEDIMessageKafka')
    //@UseGuards(AuthGuard)
    async processEDIMessageKafka(@Req() request: Request) {
        let canonicalResponse;
        //Transform Canonical Request XML to JSON Object

        //console.log("REQUEST Body " + JSON.stringify(request.body));
        //console.log("REQUEST kafka ID " + request.body.kafkaId);
        this.logger.info("Before Query Call To processEDIMessageKafka API " + new Date());
        var requestJSON = await this.ediRequestService.processEDIMessageKafka(request);
        console.log("UPDATE HSC REQUEST OBJECT:" + JSON.stringify(requestJSON.updateHscRequest));

        //Call Update HSC API
        const hscResponse = await this.updateHscApiService.updateHsc(requestJSON.updateHscRequest, request);
        console.log("UPDATE HSC RESPONSE OBJECT:" + JSON.stringify(hscResponse));

        requestJSON.hscResponse = hscResponse.hsc[0];
        //console.log("hscResponse +++++++++++++++++++++++++++++++++> " + JSON.stringify(requestJSON.hscResponse));
        //Creating Canonical Response
        if (hscResponse) {
            canonicalResponse = await this.ediResponseService.processEdiResponse(requestJSON, requestJSON.ediType);
        } else {
            return "Error in Updating HSC Details..."
        }
        this.logger.info("After Query Call To processEDIMessageKafka API " + new Date());
        return canonicalResponse;
        //return await this.ediResponseService.processEdiResponse(requestJSON, requestJSON.ediType);
    }

    //Response API
    @Post('/processResponseXML')
//@UseGuards(AuthGuard)
    async processCanonicalResponseXML(@Req() request: Request) {
        const requestJSON = request.body;
        //console.log("requestJSON:" + JSON.stringify(requestJSON));
        this.logger.info("Before Query Call To processResponseXML API " + new Date());
        const canonicalResponse = await this.ediResponseService.processEdiResponse(requestJSON, requestJSON.ediType);
        //console.log("CANONICAL RESPONSE:" + JSON.stringify(canonicalResponse));
        this.logger.info("After Query Call To processResponseXML API " + new Date());
        return canonicalResponse;
    }



    //need to add additional method @Post('/dupCheck')
    @Post('/duplicateCheck')
    async DuplicateCheck(@Req() request: Request) {
        this.logger.info("Before Query Call To duplicateCheck API " + new Date());
        const dupRequest =  await this.duplicateCheckService.checkDuplicate(request);
        this.logger.info("After Query Call To duplicateCheck API " + new Date());
        return dupRequest;

    }

}
