import {HttpModule, Module} from '@nestjs/common';
import { EdiController } from './edi.controller';
import { EdiRequestService } from './services/edi-request.service';
import {EdiUtilities} from "./edi-utilities";
import {HTTP_INTERCEPTORS, HttpClient} from "@angular/common/http";
import {AuthHttpInterceptor} from '@ecp/auth-library';
import { APP_BASE_HREF } from '@angular/common';
import {IndividualClient} from "../shared/graphql/individualDomain/individualClient";
import {IndividualService} from "./services/individual/individual.service";
import {ProviderService} from "./services/provider/provider.service";
import {ProviderClient} from "../shared/graphql/providerDomain/providerClient";
import {EdiResolver} from "./resolvers/edi.resolver";
import {EdiResponseService} from "./services/edi-response.service";
import { Builder } from "xml2js";
import {Edi278NMapperService} from "./services/mapper/request-mapping/edi-278N/edi-278N-mapper.service";
import {HealthServiceService} from "./services/healthService/healthService.service";
import {HealthServiceClient} from "../shared/graphql/healthservicedomain/healthServiceClient";
import {Edi278NDiagnosisValidationService} from "./services/validation/278N-validation/edi-278N-diagnosis-validation.service";
import {UpdateHscApiService} from "./services/updateHscAPI/updateHscApi.service";
import {EdiDataTransmissionHeaderValidationService} from "./services/validation/edi-dataTransmissionHeader-validation.service";
import {Edi278NDataTransmissionHeaderValidationService} from "./services/validation/278N-validation/edi-278N-dataTransmissionHeader-validation.service";
import {EdiDiagnosisValidationService} from "./services/validation/edi-diagnosis-validation.service";
import {EdiMemberValidationService} from "./services/validation/edi-member-validation.service";
import {EdiProviderValidationService} from "./services/validation/edi-provider-validation.service";
import {UpdateHscApiClient} from "../shared/graphql/updateHscApi/updateHscApiClient";
import {EdiFacilityValidationService} from "./services/validation/edi-facility-validation.service";
import {DuplicateCheck} from "./services/duplicateCheck/duplicateCheck.service";
import {AuthDuplicateCheckingService} from "../shared/dmn/AuthDuplicateChecking/authDuplicateChecking.service";
import {EdiDataTransmissionHeaderMapperService} from "./services/mapper/request-mapping/edi-dataTransmissionHeader-mapper.service";
import {Edi278NDataTransmissionHeaderMapperService} from "./services/mapper/request-mapping/edi-278N/edi-278N-dataTransmissionHeader-mapper.service";
import {GenericMapperService} from "./services/mapper/request-mapping/generic-mapper-service";
import {EdiMemberMapperService} from "./services/mapper/request-mapping/edi-member-mapper.service";
import {Edi278NMemberMapperService} from "./services/mapper/request-mapping/edi-278N/edi-278N-member-mapper.service";
import {EdiProviderMapperService} from "./services/mapper/request-mapping/edi-provider-mapper.service";
import {Edi278NProviderMapperService} from "./services/mapper/request-mapping/edi-278N/edi-278N-provider-mapper.service";
import {EdiDiagnosisMapperService} from "./services/mapper/request-mapping/edi-diagnosis-mapper.service";
import {Edi278NDiagnosisMapperService} from "./services/mapper/request-mapping/edi-278N/edi-278N-diagnosis-mapper.service";
import {EdiFacilityMapperService} from "./services/mapper/request-mapping/edi-facility-mapper.service";
import {Edi278NFacilityMapperService} from "./services/mapper/request-mapping/edi-278N/edi-278N-facility-mapper.service";
import {AppService} from "../app.service";
import {EdiServiceMapperService} from "./services/mapper/request-mapping/edi-service-mapper.service";
import {Edi278NServiceMapperService} from "./services/mapper/request-mapping/edi-278N/edi-278N-service-mapper.service";
import {EdiServiceValidationService} from "./services/validation/edi-service-validation.service";
import {Edi278NServiceValidationService} from "./services/validation/278N-validation/edi-278N-service-validation.service";
import {GenericMapperResponseService} from "./services/mapper/response-mapping/generic-mapper-response.service";
import {EdiMemberMapperResponseService} from "./services/mapper/response-mapping/edi-member-mapper-response.service";
import {EdiDataTransmissionHeaderMapperResponseService} from "./services/mapper/response-mapping/edi-dataTransmissionHeader-mapper-response.service";
import {Edi278NMapperResponseService} from "./services/mapper/response-mapping/edi-278N/edi-278N-mapper-response.service";
import {Edi278NDataTransmissionHeaderMapperResponseService} from "./services/mapper/response-mapping/edi-278N/edi-278N-dataTransmissionHeader-mapper-response.service";
import {Edi278NMemberMapperResponseService} from "./services/mapper/response-mapping/edi-278N/edi-278N-member-mapper-response.service";
import {ReferenceClient} from "../shared/graphql/referenceDomain/referenceClient";
import {EdiDiagnosisMapperResponseService} from "./services/mapper/response-mapping/edi-diagnosis-mapper-response.service";
import {Edi278NDiagnosisMapperResponseService} from "./services/mapper/response-mapping/edi-278N/edi-278N-diagnosis-mapper-response.service";
import {Edi278NFacilityMapperResponseService} from "./services/mapper/response-mapping/edi-278N/edi-278N-facility-mapper-response.service";
import {EdiFacilityMapperResponseService} from "./services/mapper/response-mapping/edi-facility-mapper-response.service";
import {Edi278NProviderMapperResponseService} from "./services/mapper/response-mapping/edi-278N/edi-278N-provider-mapper-response.service";
import {EdiProviderMapperResponseService} from "./services/mapper/response-mapping/edi-provider-mapper-response.service";
import {Edi278NServiceMapperResponseService} from "./services/mapper/response-mapping/edi-278N/edi-278N-service-mapper-response.service";
import {EdiServiceMapperResponseService} from "./services/mapper/response-mapping/edi-service-mapper-response.service";
import { HttpClientModule } from '@angular/common/http';
import {Edi278NEventMapperService} from "./services/mapper/request-mapping/edi-278N/edi-278N-event-mapper.service";
import {EdiEventMapperService} from "./services/mapper/request-mapping/edi-event-mapper.service";



@Module({
  imports: [HttpModule, HttpClientModule],
  controllers: [EdiController],
  providers: [
      EdiRequestService,
      EdiResponseService,
      EdiUtilities,
      Edi278NMapperService,
      IndividualClient,
      IndividualService,
      EdiResolver,
      Builder,
      ProviderService,
      ProviderClient,
      HealthServiceService,
      HealthServiceClient,
      UpdateHscApiService,
      UpdateHscApiClient,
      HttpClient,
      EdiFacilityValidationService,
      EdiDiagnosisValidationService,
      EdiMemberValidationService,
      EdiProviderValidationService,
      EdiServiceValidationService,
      Edi278NServiceValidationService,
      Edi278NDiagnosisValidationService,
      EdiDataTransmissionHeaderValidationService,
      Edi278NDataTransmissionHeaderValidationService,
      DuplicateCheck,
      AuthDuplicateCheckingService,
      EdiDataTransmissionHeaderMapperService,
      Edi278NDataTransmissionHeaderMapperService,
      GenericMapperService,
      Edi278NMapperService,
      EdiMemberMapperService,
      Edi278NMemberMapperService,
      EdiProviderMapperService,
      Edi278NProviderMapperService,
      EdiDiagnosisMapperService,
      Edi278NDiagnosisMapperService,
      EdiFacilityMapperService,
      Edi278NFacilityMapperService,
      EdiServiceMapperService,
      Edi278NServiceMapperService,
      AppService,
      GenericMapperResponseService,
      EdiMemberMapperResponseService,
      EdiDataTransmissionHeaderMapperResponseService,
      Edi278NMapperResponseService,
      Edi278NDataTransmissionHeaderMapperResponseService,
      Edi278NMemberMapperResponseService,
      ReferenceClient,
      EdiDiagnosisMapperResponseService,
      Edi278NDiagnosisMapperResponseService,
      EdiServiceMapperResponseService,
      Edi278NServiceMapperResponseService,
      Edi278NFacilityMapperResponseService,
      EdiFacilityMapperResponseService,
      Edi278NProviderMapperResponseService,
      EdiProviderMapperResponseService,
      Edi278NEventMapperService,
      EdiEventMapperService
  ]
})
export class EdiModule {}
