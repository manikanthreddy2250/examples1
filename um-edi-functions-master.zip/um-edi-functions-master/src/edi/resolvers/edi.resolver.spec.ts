
import {EdiResolver} from "./edi.resolver";
import {Test, TestingModule} from "@nestjs/testing";
import {IndividualService} from "../services/individual/individual.service";
import {IndividualClient} from "../../shared/graphql/individualDomain/individualClient";
import {ConfigService} from "@nestjs/config";

describe('EdiResolver', () => {
    let ediResolver: EdiResolver;

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [ConfigService, EdiResolver, IndividualService, IndividualClient],
        }).compile();

        ediResolver = module.get<EdiResolver>(EdiResolver);
    });


        it('should be defined', () => {
            expect(ediResolver).toBeDefined();
        });

    });

