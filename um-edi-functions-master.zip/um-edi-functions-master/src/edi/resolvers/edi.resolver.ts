import {Args, Context, Int, Mutation, Query, Resolver} from "@nestjs/graphql";
import {IndividualService} from "../services/individual/individual.service";

@Resolver()
export class EdiResolver {
    constructor(
        private individualService: IndividualService
    ) {}

    /*
       All servers running with GraphQL must have at least one @Query() to be considered a valid GraphQL server.
       TODO - Remove this once this Repository has any queries implemented
     */
    @Query(() => String)
    sayHello(): string {
        return 'Hello World!';
    }

    /*@Query(() => String)
    async getIndividualId(@Args('individualVariables') individualVariables){
        //headers can be read from context.req
        console.log(this.individualService.getIndividualId(individualVariables));
        return 'Hello World!';
    }*/
}
