import { Test, TestingModule } from '@nestjs/testing';
import {Injectable} from "@nestjs/common";
import {DuplicateCheck} from "./duplicateCheck.service";
import {EdiUtilities}from "../../edi-utilities";
import {AuthDuplicateCheckingService} from "../../../shared/dmn/AuthDuplicateChecking/authDuplicateChecking.service";
import {IndividualService}from "../../services/individual/individual.service";
import {HealthServiceClient} from "../../../shared/graphql/healthservicedomain/healthServiceClient";
import {HealthServiceService} from "../../services/healthService/healthService.service";
import {testCanonicalRequest, testRequest} from "../../../../test/ediTestData";
import {HttpRequest} from "@azure/functions";

@Injectable()
class DuplicateCheckMock {
}

@Injectable()
class EdiUtilitiesMock {
}

@Injectable()
class IndividualServiceMock {
    getIndividualKeyData() {
        return {indv_key: [{indv_key_val: "test"}]}
    }
}

@Injectable()
class HealthServiceServiceMock {
}

@Injectable()
class HealthServiceClientMock {
    getGraphqlClient(request: HttpRequest){
           return "test";
    }
}

@Injectable()
class AuthDuplicateCheckingServiceMock {
    createDMNToken() {

    }
    duplicateCheck(dmntoken) {

    }
}


describe('DuplicateCheck', () => {

    let service: DuplicateCheck;
    let request: HttpRequest;

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [DuplicateCheck, EdiUtilities,
                {provide: IndividualService, useClass: IndividualServiceMock},
                {provide: HealthServiceService, useClass: HealthServiceServiceMock},
                {provide: HealthServiceClient, useClass: HealthServiceClientMock},
                {provide: AuthDuplicateCheckingService, useClass: AuthDuplicateCheckingServiceMock},]
        }).compile();

        service = module.get<DuplicateCheck>(DuplicateCheck);
    });

    it('should be defined', () => {
        expect(service).toBeDefined();
    });

    it('should run #checkDuplicate', () => {
        service.checkDuplicate(testRequest);
        expect(service).toBeTruthy();
    });

    it('should run #getIndividualData', () => {
        service.getIndividualData("test", "test", "test", "test", request);
        expect(service).toBeTruthy();
    });

    it('should run #processDmnResponse failed status', () => {
        var response = {data: [{"duplicateCheckValues":[19277,19275,19276],"duplicateCheckCriteria":"hscStatus"},{"duplicateCheckValues":[7],"duplicateCheckCriteria":"actualAdmitDate"},{"dupcheck":"true"}]};
        var memberInfo = {"hsc":[{"hsc_id":15675,"hsc_sts_ref_id":19274,"srvc_set_ref_id":3737,"auth_typ_ref_id":20137,"hsc_facls":[{"actul_admis_dttm":"2021-03-20T00:00:00"}]},{"hsc_id":15674,"hsc_sts_ref_id":19273,"srvc_set_ref_id":3737,"auth_typ_ref_id":20137,"hsc_facls":[{"actul_admis_dttm":"2021-02-28T00:00:00"}]},{"hsc_id":15673,"hsc_sts_ref_id":19274,"srvc_set_ref_id":3737,"auth_typ_ref_id":20137,"hsc_facls":[{"actul_admis_dttm":"2021-02-15T00:00:00"}]},{"hsc_id":15300,"hsc_sts_ref_id":19274,"srvc_set_ref_id":3737,"auth_typ_ref_id":20137,"hsc_facls":[{"actul_admis_dttm":"2021-03-09T00:00:00"}]}]};
        service.processDmnResponse(response, "2020-11-24", memberInfo);
        expect(service).toBeTruthy();
    });

    it('should run #processDmnResponse failed date', () => {
        var response = {data: [{"duplicateCheckValues":[19277,19275,19276],"duplicateCheckCriteria":"hscStatus"},{"duplicateCheckValues":[7],"duplicateCheckCriteria":"actualAdmitDate"},{"dupcheck":"true"}]};
        var memberInfo = {"hsc":[{"hsc_id":15675,"hsc_sts_ref_id":19274,"srvc_set_ref_id":3737,"auth_typ_ref_id":20137,"hsc_facls":[{"actul_admis_dttm":"2021-03-20T00:00:00"}]},{"hsc_id":15674,"hsc_sts_ref_id":19273,"srvc_set_ref_id":3737,"auth_typ_ref_id":20137,"hsc_facls":[{"actul_admis_dttm":"2021-02-28T00:00:00"}]},{"hsc_id":15673,"hsc_sts_ref_id":19274,"srvc_set_ref_id":3737,"auth_typ_ref_id":20137,"hsc_facls":[{"actul_admis_dttm":"2021-02-15T00:00:00"}]},{"hsc_id":15300,"hsc_sts_ref_id":19274,"srvc_set_ref_id":3737,"auth_typ_ref_id":20137,"hsc_facls":[{"actul_admis_dttm":"2021-03-09T00:00:00"}]}]};
        service.processDmnResponse(response, "2021-03-21", memberInfo);
        expect(service).toBeTruthy();
    });

    it('should run #processDmnResponse valid date', () => {
        var response = {data: [{"duplicateCheckValues":[19277,19275,19276],"duplicateCheckCriteria":"hscStatus"},{"duplicateCheckValues":[7],"duplicateCheckCriteria":"actualAdmitDate"},{"dupcheck":"true"}]};
        var memberInfo = {"hsc":[{"hsc_id":15675,"hsc_sts_ref_id":19274,"srvc_set_ref_id":3737,"auth_typ_ref_id":20137,"hsc_facls":[{"actul_admis_dttm":"2021-03-20T00:00:00"}]},{"hsc_id":15674,"hsc_sts_ref_id":19273,"srvc_set_ref_id":3737,"auth_typ_ref_id":20137,"hsc_facls":[{"actul_admis_dttm":"2021-02-28T00:00:00"}]},{"hsc_id":15673,"hsc_sts_ref_id":19274,"srvc_set_ref_id":3737,"auth_typ_ref_id":20137,"hsc_facls":[{"actul_admis_dttm":"2021-02-15T00:00:00"}]},{"hsc_id":15300,"hsc_sts_ref_id":19274,"srvc_set_ref_id":3737,"auth_typ_ref_id":20137,"hsc_facls":[{"actul_admis_dttm":"2021-03-09T00:00:00"}]}]};
        service.processDmnResponse(response, "2021-04-21", memberInfo);
        expect(service).toBeTruthy();
    });



});