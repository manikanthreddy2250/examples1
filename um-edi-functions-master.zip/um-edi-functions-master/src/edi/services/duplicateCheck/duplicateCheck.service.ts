import{Injectable}from"@nestjs/common";
import {EdiUtilities}from "../../edi-utilities";
import {canonicalRequestTags,
    memberAttributes,
    facilityAttributes,
    homeHealthCareAttributes,
    dataTransmissionHeaderAttributes}from "../../constants/edi.constants";
import {Edi278NConstants}from "../../constants/edi-278N.constants";
import {IndividualService}from "../../services/individual/individual.service";
import {HealthServiceClient} from "../../../shared/graphql/healthservicedomain/healthServiceClient";
import {HealthServiceService} from "../../services/healthService/healthService.service";
import {checkMemberData} from "../../../shared/graphql/healthservicedomain/healthServiceQuery";
import {AuthDuplicateCheckingService} from "../../../shared/dmn/AuthDuplicateChecking/authDuplicateChecking.service";
import {request} from "http";

@Injectable()
export class DuplicateCheck {
    canonicalcertificationType;

    constructor(private readonly ediUtils: EdiUtilities,
                private readonly individualService: IndividualService,
                private readonly healthServiceService: HealthServiceService,
                private readonly healthServiceClient: HealthServiceClient,
                private readonly authDuplicateCheckingService: AuthDuplicateCheckingService){}

    async checkDuplicate(request) {

        const canonicalRequest = this.ediUtils.getElementInfo(request.body, canonicalRequestTags.CANONICALREQUEST);
        var event = await this.ediUtils.getElementInfo(canonicalRequest, canonicalRequestTags.EVENT);
        var memberDetails = await this.ediUtils.getElementInfo(event, canonicalRequestTags.MEMBER);
        var firstName = this.ediUtils.getAttributeValue(memberDetails, memberAttributes.FIRSTNAME);
        var lastName = this.ediUtils.getAttributeValue(memberDetails, memberAttributes.LASTNAME);
        var birthDate = this.ediUtils.getAttributeValue(memberDetails, memberAttributes.BIRTHDATE);

        var facilityDetails = this.ediUtils.getElementInfo(event, canonicalRequestTags.FACILITY);
        var canonicaladmissionDate = this.ediUtils.getAttributeValue(facilityDetails, facilityAttributes.ADMISSIONDATE);
        var canonicalcertificationType = this.ediUtils.getAttributeValue(facilityDetails, facilityAttributes.CERTFICATIONTYPE);

        var dataTransmissionHeaderDetails = this.ediUtils.getElementInfo(canonicalRequest, canonicalRequestTags.DATATRANSMISSIONHEADER);
        var purposeCode = this.ediUtils.getAttributeValue(dataTransmissionHeaderDetails, dataTransmissionHeaderAttributes.PURPOSECODE);

        console.log ("Canonical Purpose Code: " + purposeCode);
        console.log ("Canonical AdmissionDate: " + canonicaladmissionDate);
        console.log ("Canonical CertificationType: " + canonicalcertificationType);
        var memberInformationArray = [];

        //var hscCount = this.memberInformationArray[0].hsc.length
        //console.log ("HSC Count>>>>>>>>>> " + hscCount);
        if (canonicalcertificationType == 'I' && purposeCode == 'CN') {

            //Member Identifier
            var memberIdentifierDetails = this.ediUtils.getRequestInfo(memberDetails, canonicalRequestTags.MEMBERIDENTIFIERS);
            var memberIdentifierArray = memberIdentifierDetails.split("<" + canonicalRequestTags.MEMBERIDENTIFIER);
            memberIdentifierArray.shift();

            for (var memberIdentifier of memberIdentifierArray) {
                var memberIDType = this.ediUtils.getAttributeValue(memberIdentifier, memberAttributes.MEMBERIDTYPE);
                if (memberIDType == Edi278NConstants.MEMBER_ID_TYPE_MI) {
                    var memberID = this.ediUtils.getAttributeValue(memberIdentifier, memberAttributes.MEMBERID);
                }
            }

            var canonicalMemberID = await this.getIndividualData(firstName, lastName, birthDate, memberID, request);
            var object = {memID: canonicalMemberID};
            var memberInformation = await this.healthServiceClient.getGraphqlClient(request).request(checkMemberData, object );
            memberInformationArray.push(memberInformation);

            try {

                var response = await this.authDuplicateCheckingService.duplicateCheck(request).toPromise();
                return await this.processDmnResponse(response, canonicaladmissionDate, memberInformation);

            } catch (err) {
                var e = err;
                console.error(`Error while executing  ${err}`);
                return JSON.stringify({ "error": e });
            }

        } else {
            console.log("Proceed with the case purposeCode not equal to CN Or canonicalcertificationType is not I " + canonicalcertificationType + purposeCode);
            return JSON.stringify({ "error": "purposeCode not equal to CN Or canonicalcertificationType is not I" });
        }
    }

    async processDmnResponse(response, canonicaladmissionDate, memberInformation) {

        console.log("RESPONSE " + JSON.stringify(response.data));
        console.log("canonicaladmissionDate " + canonicaladmissionDate);
        console.log("memberInformation " + JSON.stringify(memberInformation));
        var res;
        for(var x = 0, xlen = response.data[0].duplicateCheckValues.length; x < xlen; x++) {

            var dMNhscStatus = response.data[0].duplicateCheckValues[x];
            for(var i = 0, len = memberInformation.hsc.length; i < len; i++) {

                var domainhsc_sts_refID =  memberInformation.hsc[i].hsc_sts_ref_id;
                // should not be equal to the following status from dmn 19277, 19276, 19275
                if (dMNhscStatus == domainhsc_sts_refID) {
                    return JSON.stringify({ "duplicate": true,
                        "info": "hsc status already exists in domain" });
                }

                res = await this.checkAdmissionDateAndStatus(dMNhscStatus, canonicaladmissionDate, i, memberInformation);
                if(res.duplicate == true) {
                    return JSON.stringify(res);
                }

            }

        }

        return JSON.stringify(res);
    }

    async checkAdmissionDateAndStatus(dMNhscStatus, canonicaladmissionDate, i, memberInformation) {

        var response;

        var domainActul_admis_dttm =  memberInformation.hsc[i].hsc_facls[0].actul_admis_dttm;
        if (domainActul_admis_dttm !== null) {
            //console.log("This is the domain date >>>>>>>" + DOMAINactul_admis_dttm);
            //console.log("This is the canonical date >>>>" + canonicaladmissionDate);
            var canDate = new Date(canonicaladmissionDate);
            var domDate = new Date(domainActul_admis_dttm);
            var oneDay = 24*60*60*1000;
            var diffDays =  Math.abs((domDate.getTime() - canDate.getTime())/(oneDay));
            console.log("diffDays " + diffDays);
            console.log("domDate " + domDate);
            console.log("canDate " + canDate);
            //console.log("Number of Days between dates: " + diffDays);
            if (diffDays > 7) {
                console.log("This is the domain date >>>>>>>" + domainActul_admis_dttm);
                console.log("This is the canonical date >>>>" + canonicaladmissionDate);
                console.log("<<<<<<< This is the DOMAIN hsc_sts_refID >>>>>>>"+ domainActul_admis_dttm);
                console.log("<<<<<<< This is the DMN hscStatus >>>>>>>>>>>>>>"+ dMNhscStatus );
                console.log("Number of Days between dates: " + diffDays);
                //return JSON.stringify({ "error": err});
                console.log("<<<<<<<20402- Duplicate request>>>>>>>");
                //console.error(`<<<<<<<20402- Duplicate request>>>>>>> ${Error}`);
                //return JSON.stringify({ "<<<<<<<20402- Duplicate request>>>>>>>": diffDays });
                //var stop = 'yes'
                console.log("returning duplicate true  ")
                response = { "duplicate": false,
                    "info": "Date difference is greater than 7 days" };
            } else {
                response = { "duplicate": true,
                    "info": "Date difference is less than 7 days" };
            }
        }

        console.log("RESPONSE  " + JSON.stringify(response));
        return response;

    }


    async getIndividualData(firstName, lastName, birthDate, memberID, request) {
        const individualKeyVariables = {
            fst_nm: firstName,
            lst_nm: lastName,
            bth_dt: birthDate,
            indv_key_val: memberID
        };
        var individualKeyData: any = {"indv_key_typ_ref_id": 0, "indv_key_val": ""};
        individualKeyData = await
            this.individualService.getIndividualKeyData(individualKeyVariables, request);
        var dupcheckMemberID = individualKeyData.indv_key[0].indv_key_val;
        return dupcheckMemberID;
    }


}