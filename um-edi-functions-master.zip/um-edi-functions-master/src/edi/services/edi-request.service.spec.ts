import {Test, TestingModule} from '@nestjs/testing';
import {EdiRequestService} from './edi-request.service';
import {EdiResponseService} from "./edi-response.service";
import {IndividualService} from "./individual/individual.service";
import {Edi278NMapperService} from "./mapper/request-mapping/edi-278N/edi-278N-mapper.service";
import {HealthServiceService} from "./healthService/healthService.service";
import {Injectable} from "@nestjs/common";
import {EdiUtilities} from "../edi-utilities";
import {testCanonicalRequest, testDataTransmissionHeader, testRequest} from "../../../test/ediTestData";
import {canonicalRequestTags, EdiConstants} from "../constants/edi.constants";
import {HttpRequest} from "@azure/functions";

@Injectable()
class IndividualServiceMock {
}

@Injectable()
class Edi278NMapperServiceMock {
    mapCanonicalRequest(canonicalRequest, requestDetails, hscID){

    }
}

@Injectable()
class EdiResponseServiceMock {
}

@Injectable()
class HealthServiceServiceMock {
    createHscShell(hscShellVariables){
        return {
            "insert_hsc":
                {"returning": [{"hsc_id": 15619}]}
        };
    }
}


@Injectable()
class EdiUtilitiesMock {
   getElementInfo(data, tagName){
        return testCanonicalRequest;
    }

    getAttributeValue(data, attributeName){}
}

describe('EdiRequestService', () => {
    let service: EdiRequestService;
    let request: HttpRequest;
    request = {
        headers: {authorization: ""},
        method: null,
        url: "",
        query: {},
        params: {}
    };

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [EdiRequestService,
                {provide: EdiUtilities, useClass: EdiUtilitiesMock},
                {provide: IndividualService, useClass: IndividualServiceMock},
                {provide: Edi278NMapperService, useClass: Edi278NMapperServiceMock},
                {provide: EdiResponseService, useClass: EdiResponseServiceMock},
                {provide: HealthServiceService, useClass: HealthServiceServiceMock}],
        }).compile();

        service = module.get<EdiRequestService>(EdiRequestService);
    });

    it('should be defined', () => {
        expect(service).toBeDefined();
    });

    it('should run #canonicalToJSONTranslate()', async () => {
        let request = testRequest;
        var ediUtils = new EdiUtilitiesMock();
        spyOn(service, 'createHscShell').and.returnValue({
            "insert_hsc":
                {"returning": [{"hsc_id": 15619}]}
        });
        spyOn(ediUtils, 'getElementInfo').and.callThrough();
        spyOn(service, 'transformCanonicalReqToJSONObj').and.callFake(function () {
            return;
        });
        service.canonicalToJSONTranslate(request);
        expect(service).toBeTruthy();
    });

    it('should run #processEDIMessage()', async () => {
        let request = testRequest;
        var ediUtils = new EdiUtilitiesMock();
        spyOn(service, 'createHscShell').and.returnValue({
            "insert_hsc":
                {"returning": [{"hsc_id": 15619}]}
        });
        spyOn(ediUtils, 'getElementInfo').and.callThrough();
        spyOn(service, 'transformCanonicalReqToJSONObj').and.callFake(function () {
            return;
        });
        service.processEDIMessage(request);
        expect(service).toBeTruthy();
    });

    it('should run #processEDIMessageKafka()', async () => {
        let request = testRequest;
        var ediUtils = new EdiUtilitiesMock();
        spyOn(service, 'createHscShellKafka').and.returnValue({
            "insert_hsc":
                {"returning": [{"hsc_id": 15619}]}
        });
        spyOn(ediUtils, 'getElementInfo').and.callThrough();
        spyOn(service, 'transformCanonicalReqToJSONObj').and.callFake(function () {
            return;
        });
        service.processEDIMessageKafka(request);
        expect(service).toBeTruthy();
    });

    it('should run #transformCanonicalReqToJSONObj()', async () => {
        const hscID = 15619;
        var ediUtils = new EdiUtilitiesMock();
        var edi278NMapperService = new Edi278NMapperServiceMock();
        spyOn(ediUtils, 'getElementInfo').and.returnValue(testDataTransmissionHeader);
        spyOn(ediUtils, 'getAttributeValue').and.returnValue('CN');
        spyOn(service, 'getEdiTypeByPurposeCode').and.callFake(function () {
            return EdiConstants.EDITYPE_278N;
        });
        spyOn(edi278NMapperService, 'mapCanonicalRequest').and.callFake(function () {});
        service.transformCanonicalReqToJSONObj(testCanonicalRequest, hscID, request, true);
        expect(service).toBeTruthy();
    });

    it('should run #createHscShellKafka()', async () => {
        let request = testRequest;
        var healthService = new HealthServiceServiceMock();

        spyOn(healthService, 'createHscShell').and.callThrough();
        service.createHscShellKafka(request);
        expect(service).toBeTruthy();
    });

    it('should run #getEdiTypeByPurposeCode()', async () => {
        let purposeCode = 'CN';

        service.getEdiTypeByPurposeCode(purposeCode);
        expect(service).toBeTruthy();
    });

});
