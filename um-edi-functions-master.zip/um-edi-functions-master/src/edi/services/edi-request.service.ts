import {Injectable} from '@nestjs/common';
import {
    canonicalRequestTags,
    dataTransmissionHeaderAttributes,
    RequestDetails,
    EdiConstants
} from "../constants/edi.constants";
import {EdiUtilities} from "../edi-utilities";
import {IndividualService} from "./individual/individual.service";
import {EdiResponseService} from "./edi-response.service";
import {Edi278NConstants} from "../constants/edi-278N.constants";
import {Edi278NMapperService} from "./mapper/request-mapping/edi-278N/edi-278N-mapper.service";
import {HealthServiceService} from "./healthService/healthService.service";


@Injectable()
export class EdiRequestService {

    constructor(private readonly ediUtils: EdiUtilities,
                private readonly individualService: IndividualService,
                private readonly edi278NMapperService: Edi278NMapperService,
                private readonly ediResponseService: EdiResponseService,
                private readonly healthServiceService: HealthServiceService,) {
    }

    //check JSON object of request
    async canonicalToJSONTranslate(request) {
        let data;
        const hscID = 15067;
        const translateToJson = true;
        const canonicalRequest = await this.ediUtils.getElementInfo(request.body, canonicalRequestTags.CANONICALREQUEST);

        if (canonicalRequest) {
            data = await this.transformCanonicalReqToJSONObj(canonicalRequest, hscID, request, translateToJson);
        }
        return JSON.stringify(data);
    }

    async processEDIMessage(request) {
        let data;
        let hscID;
        const translateToJson = false;
        try {
            const hscShellData = await this.createHscShell(request);
            if(hscShellData){
                hscID = hscShellData.insert_hsc.returning[0].hsc_id;
            }else{
                hscID = 15067;
            }
            const canonicalRequest = this.ediUtils.getElementInfo(request.body, canonicalRequestTags.CANONICALREQUEST);

            if (canonicalRequest) {
                data = await this.transformCanonicalReqToJSONObj(canonicalRequest, hscID, request, translateToJson);

            }
            return data;
        } catch (err) {
        }
    }

    async processEDIMessageKafka(request) {
        let data;
        let hscID;
        const translateToJson = false;

        try {
            const hscShellData = await this.createHscShellKafka(request);
            if(hscShellData){
                hscID = hscShellData.insert_hsc.returning[0].hsc_id;
            }else{
                hscID = 15067;
            }
            const canonicalRequest = this.ediUtils.getElementInfo(request.body, canonicalRequestTags.CANONICALREQUEST);

            if (canonicalRequest) {
                data = await this.transformCanonicalReqToJSONObj(canonicalRequest, hscID, request, translateToJson);
            }

            return data;
        } catch (err) {
        }
    }

    async createHscShell(request) {
        try {
            const canonicalRequest = await this.ediUtils.getElementInfo(request.body, canonicalRequestTags.CANONICALREQUEST);
            const dataTransmissionHeader = await this.ediUtils.getElementInfo(canonicalRequest, canonicalRequestTags.DATATRANSMISSIONHEADER);
            const transactionId = this.ediUtils.getAttributeValue(dataTransmissionHeader, dataTransmissionHeaderAttributes.TRANSACTIONID);
            //const kafkaId = "test";
            const kafkaId = request.headers.kafkaid;
            const hscShellVariables: any = {
                createSystemRefId: 72099,
                hscStatusRefId: 19274,
                ediTransactionKeyTypeId: 72143,
                hscStatusReasonRefId: 72150,
                transactionId: transactionId,
                kafkaIdKeyTypeId: 72144,
                kafkaId: kafkaId,
                srcRecDoc: {
                    //canonicalRequest: [...Buffer.from(request.body)]
                    canonicalRequest: request.body
                }
            }

            return await this.healthServiceService.createHscShell(hscShellVariables, request);
        } catch (err) {
        }
    }

    async createHscShellKafka(request) {
        try {
            const canonicalRequest = await this.ediUtils.getElementInfo(request.body, canonicalRequestTags.CANONICALREQUEST);
            const dataTransmissionHeader = await this.ediUtils.getElementInfo(canonicalRequest, canonicalRequestTags.DATATRANSMISSIONHEADER);
            const transactionId = this.ediUtils.getAttributeValue(dataTransmissionHeader, dataTransmissionHeaderAttributes.TRANSACTIONID);
            //const kafkaId = request.body.kafkaId;
            //const kafkaId = "test";
            const kafkaId = request.headers.kafkaid;
            const hscShellVariables: any = {
                createSystemRefId: 72099,
                hscStatusRefId: 19274,
                ediTransactionKeyTypeId: 72143,
                hscStatusReasonRefId: 72150,
                transactionId: transactionId,
                kafkaIdKeyTypeId: 72144,
                kafkaId: kafkaId,
                srcRecDoc: {
                    //canonicalRequest: [...Buffer.from(request.body.body)]
                    canonicalRequest: request.body
                }
            };

            return await this.healthServiceService.createHscShell(hscShellVariables, request);
        } catch (err) {
        }
    }


    async transformCanonicalReqToJSONObj(canonicalRequest, hscID, request, translateToJson) {

        const requestDetails: RequestDetails = {
            dataTransmissionHeader: null,
            Membership: null,
            Individual: null,
            Provider: null,
            Facility: null,
            Diagnosis: null,
            Event: null,
            procCodes: null,
            Service: null,
            updateHscRequest: null,
            hscSourceData: null,
            ediType: null,
            followUpContact: null,
            Error: null
        };

        try {
            const dataTransmissionHeaderDetails = this.ediUtils.getElementInfo(canonicalRequest, canonicalRequestTags.DATATRANSMISSIONHEADER);
            if (dataTransmissionHeaderDetails) {
                const purposeCode = this.ediUtils.getAttributeValue(dataTransmissionHeaderDetails, dataTransmissionHeaderAttributes.PURPOSECODE);

                const ediType = this.getEdiTypeByPurposeCode(purposeCode);
                requestDetails.ediType = ediType;

                switch (ediType) {
                    case EdiConstants.EDITYPE_278N:
                        await this.edi278NMapperService.mapCanonicalRequest(canonicalRequest, requestDetails, hscID, request, ediType, translateToJson);
                        break;
                    default:
                        break;
                }
            }
        } catch (err) {
            console.log(`Error while transforming canonical request to JSON Objects: ${err}`);
        }
        return requestDetails;
    }

    getEdiTypeByPurposeCode(purposeCode) {
        if (purposeCode) {
            if (Edi278NConstants.BHT02_ADVANCE_NOTIFICATION == purposeCode || Edi278NConstants.BHT02_COMPLETION_NOTIFICATION == purposeCode || Edi278NConstants.BHT02_INFORMATION_COPY == purposeCode) {
                return EdiConstants.EDITYPE_278N;
            }
        }
        return null;
    }
}
