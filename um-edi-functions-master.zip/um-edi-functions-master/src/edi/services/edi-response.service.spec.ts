import { Test, TestingModule } from '@nestjs/testing';
import { EdiRequestService } from './edi-request.service';
import {EdiResponseService} from "./edi-response.service";
import {Injectable} from "@nestjs/common";
import {EdiUtilities} from "../edi-utilities";
import {Builder} from "xml2js";
import {Edi278NMapperResponseService} from "./mapper/response-mapping/edi-278N/edi-278N-mapper-response.service";
import {Edi278NDataTransmissionHeaderMapperResponseService} from "./mapper/response-mapping/edi-278N/edi-278N-dataTransmissionHeader-mapper-response.service";
import {Edi278NMemberMapperResponseService} from "./mapper/response-mapping/edi-278N/edi-278N-member-mapper-response.service";
import {Edi278NDiagnosisMapperResponseService} from "./mapper/response-mapping/edi-278N/edi-278N-diagnosis-mapper-response.service";
import {Edi278NFacilityMapperResponseService} from "./mapper/response-mapping/edi-278N/edi-278N-facility-mapper-response.service";
import {Edi278NProviderMapperResponseService} from "./mapper/response-mapping/edi-278N/edi-278N-provider-mapper-response.service";
import {Edi278NServiceMapperResponseService} from "./mapper/response-mapping/edi-278N/edi-278N-service-mapper-response.service";
import {data} from "browserslist";

@Injectable()
class BuilderMock {
    buildObject(s: string) {
        return "canonicalResposne"
    }

}

@Injectable()
class EdiUtilitiesMock {
}

var requestJSON: any = {
    "dataTransmissionHeader":    {
        "sourceType": "278",
        "transactionID": "4434443546594470",
        "version": 1,
        "batchFileID": null,
        "receivedDateTime": "2020-10-02T01:04:17.897Z",
        "purposeCode": "CN",
        "transactionType": "NO",
        "transactionStatus": "RECEIVED",
        "testFlag": "T",
        "clinicalApplication": "HSR",
        "payerID": "87726",
        "submitterID": "",
        "ediID": 1,
    },
    "Membership": {"mbrshp":    {
            "sbscr_fst_nm": "EDWARD",
            "sbscr_lst_nm": "GAIN",
            "mbr_rel_ref_id": null,
            "scrbr_id_txt": "931605237",
            "mbr_covs": [{"pol_nbr": null}]
    }},
    "Individual": {"indv":    {
            "fst_nm": "EDWARD",
            "lst_nm": "GAIN",
            "midl_nm": null,
            "sufx_nm": null,
            "bth_dt": "1931-09-19",
            "gdr_ref_id": "M",
            "indv_adrs": [  {
                "adr_ln_1_txt": "1441 EASTLAKE AVE",
                "adr_ln_2_txt": null,
                "cty_nm": "LOS ANGELES",
                "st_ref_id": "CA",
                "zip_cd_txt": "90033",
                "zip_sufx_cd_txt": null
            }]
    }},
    "updateHscRequest":{
        "hsc_id":14546,
        "indv_key_typ_ref_id":2757,
        "indv_key_val":"16440436900",
        "srvc_set_ref_id":3737,
        "rev_prr_ref_id":3754,
        "hsc_diags":{
            "create":[
                {
                    "diag_cd":"M21.51",
                    "pri_ind":0
                }
            ]
        },
        "hsr_notes":[
            {
                "note_txt_lobj":"testing",
                "note_titl_txt":"title",
                "src_user_nm":"clinician",
                "note_typ_ref_id":12,
                "note_catgy_ref_id":null
            }
        ],
        "flwup_cntc_dtl":{
            "primary_cntct":{
                "department":null,
                "email":null,
                "phone":"234-456-4666",
                "fax":null,
                "role":null,
                "name":"demo"
            },
            "secondary_cntct":{
                "department":null,
                "email":null,
                "phone":"234-456-4666",
                "fax":null,
                "role":null,
                "name":"wffwf"
            }
        },
        "hsc_provs":[
            {
                "prov_keys":[
                    {
                        "prov_key_typ_ref_id":2782,
                        "prov_key_val":"1851525091"
                    },
                    {
                        "prov_key_typ_ref_id":16333,
                        "prov_key_val":"288158608"
                    },
                    {
                        "prov_key_typ_ref_id":2783,
                        "prov_key_val":"1710081369"
                    }
                ],
                "hsc_prov_roles":[
                    {
                        "prov_role_ref_id":3765
                    }
                ],
                "prov_adr":{
                    "adr_ln_1_txt":"1920 Colorado Ave",
                    "adr_ln_2_txt":null,
                    "zip_cd_txt":"904043414",
                    "cty_nm":"Santa Monica",
                    "st_ref_id":1067
                }
            }
        ],
        "hsc_facl":{
            "plsrv_ref_id":3743,
            "srvc_desc_ref_id":4347,
            "srvc_dtl_ref_id":4296,
            "actul_admis_dttm":null,
            "actul_dschrg_dttm":null,
            "expt_admis_dt":"2021-03-02",
            "expt_dschrg_dt":"2021-03-04"
        },
        "hsc_srvcs":{
            "create":[
                {
                    "proc_cd":"80346",
                    "proc_cd_schm_ref_id":2,
                    "srvc_hsc_prov_id":null,
                    "hsc_prov":{
                        "prov_keys":[
                            {
                                "prov_key_typ_ref_id":2782,
                                "prov_key_val":"1851525091"
                            },
                            {
                                "prov_key_typ_ref_id":16333,
                                "prov_key_val":"288158608"
                            },
                            {
                                "prov_key_typ_ref_id":2783,
                                "prov_key_val":"1710081369"
                            }
                        ],
                        "hsc_prov_roles":[
                            {
                                "prov_role_ref_id":3765
                            }
                        ],
                        "prov_adr":{
                            "adr_ln_1_txt":"1920 Colorado Ave",
                            "adr_ln_2_txt":null,
                            "zip_cd_txt":"904043414",
                            "cty_nm":"Santa Monica",
                            "st_ref_id":1067
                        }
                    },
                    "hsc_decns":[
                        {
                            "decn_otcome_ref_id":1,
                            "decn_typ_ref_id":2,
                            "decn_rsn_ref_id":3,
                            "clm_note_txt":"test",
                            "ovrd_clm_rmrk_ref_id":1,
                            "sys_clm_rmrk_ref_id":1,
                            "decn_src_desc":{
                                "test":"test"
                            },
                            "wrt_decn_cmnct_dttm":"12-03-2021",
                            "decn_rndr_dttm":"12-03-2021",
                            "decn_mbr_cmnct_dttm":"12-03-2021",
                            "decn_prov_cmnct_dttm":"12-03-2021",
                            "gap_rev_otcome_ref_id":2,
                            "negot_rt":1,
                            "hsc_decn_bed_days":[
                                {
                                    "strt_bed_dt":"12-03-2021",
                                    "rvnu_cd":"test",
                                    "bed_typ_ref_id":1
                                }
                            ]
                        }
                    ]
                }
            ]
        }
    }
};

var hscResponse: any = {
    "data": {
        "updateHsc": {
            "hsc": [
                {
                    "hsc_id": 15067,
                    "hsc_diags": [
                        {
                            "hsc_diag_id": 4728,
                            "diag_cd": "M54.16",
                            "inac_ind": 0
                        }
                    ]
                }
            ]
        }
    }
};

describe('EdiResponseService', () => {
  let service: EdiResponseService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
        providers: [EdiResponseService, Edi278NDataTransmissionHeaderMapperResponseService, Edi278NDiagnosisMapperResponseService, Edi278NFacilityMapperResponseService, Edi278NProviderMapperResponseService,  Edi278NMemberMapperResponseService,  Edi278NServiceMapperResponseService, Edi278NMapperResponseService,  EdiUtilities, Builder],
    }).compile();

    service = module.get<EdiResponseService>(EdiResponseService);
  });

  it('should be defined', () => {
      expect(service).toBeDefined();
  });

  it('call processEdiResponse', () => {
      service.processEdiResponse(data, requestJSON.ediType).then( (res) => {
          expect(res).toContain("canonicalResponse");
      });
  });

});
