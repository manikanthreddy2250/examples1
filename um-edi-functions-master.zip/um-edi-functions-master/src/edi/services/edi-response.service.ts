import {Injectable} from "@nestjs/common";
import {Builder} from "xml2js";
import {EdiUtilities} from "../edi-utilities";
import {canonicalRequestTags, canonicalResponseTags, EdiConstants} from "../constants/edi.constants";
import {decode} from "html-entities";
import {Edi278NMapperService} from "./mapper/request-mapping/edi-278N/edi-278N-mapper.service";
import {Edi278NMapperResponseService} from "./mapper/response-mapping/edi-278N/edi-278N-mapper-response.service";


@Injectable()
export class EdiResponseService {

    constructor(private readonly builder: Builder,
                private readonly ediUtils: EdiUtilities,
                private readonly edi278NMapperResponseService: Edi278NMapperResponseService) {
    }

    async processEdiResponse(data, ediType) {
        let canonicalResponse;
        if (data) {
            canonicalResponse = await this.transformJSONObjToCanonicalResponse(data, ediType);
        }
        return canonicalResponse;
    }

    async transformJSONObjToCanonicalResponse(data, ediType) {
        let canonicalResponse;
        const responseDetails = {
            "canonicalResponse": {
                $: {
                    "xmlns": canonicalResponseTags.RESPONSEXMLNS
                }
            }
        };

        try {

            if (ediType) {
                switch (ediType) {
                    case EdiConstants.EDITYPE_278N:
                        canonicalResponse = await this.edi278NMapperResponseService.mapCanonicalResponse(data, responseDetails);
                        break;
                    default:
                        break;
                }

                //convert json to xml
                canonicalResponse = this.builder.buildObject(responseDetails);
                console.log("xmlFormattedResponse: " + JSON.stringify(canonicalResponse));

            }
        } catch (err) {
            console.log("error transformJSONObjToCanonicalResponse: " + JSON.stringify(err));
        }

        return decode(canonicalResponse);
    }





    /*    mapProviderData(data, eventData) {
            let i: number;
            const tempData = [];

            try {
                // let providerData = this.groupProviderData(data);
                let providerData = data.Provider.prov;
                if (providerData) {
                    let providerSize = providerData.length;
                    console.log("PROVIDER DATA LENGTH: " + JSON.stringify(providerSize));
                    console.log("PROVIDER DATA: " + JSON.stringify(providerData));
                    for (i = 0; i < providerSize; i++) {
                        //------------------------------PROV_INDVS------------------------------//
                        var firstName = providerData[i].prov_indvs[0].fst_nm;
                        var lastName = providerData[i].prov_indvs[0].lst_nm;
                        var middleName = providerData[i].prov_indvs[0].midl_nm;
                        var suffixName = providerData[i].prov_indvs[0].sufx_nm;

                        //------------------------------PROV_ORGS------------------------------//
                        var businessName = providerData[i].prov_orgs[0].bus_nm;

                        //------------------------------PROV_ADRS------------------------------//
                        var address1 = providerData[i].prov_adrs[0].adr_ln_1_txt;
                        var address2 = providerData[i].prov_adrs[0].adr_ln_2_txt;
                        var city = providerData[i].prov_adrs[0].cty_nm;
                        var state = providerData[i].prov_adrs[0].st_ref_id;
                        var zip = providerData[i].prov_adrs[0].zip_cd_txt;
                        var zipSuffix = providerData[i].prov_adrs[0].zip_sufx_cd_txt;
                        var entityIdentifier = providerData[i].prov_adrs[0].entityIdentifier;

                        var sourceData = providerData[i].sourceData;

                        let providerIndv = {
                            "provider": {
                                '$': {
                                    firstName: firstName,
                                    lastName: lastName,
                                    middleName: middleName,
                                    suffixName: suffixName,
                                    businessName: businessName,
                                    address1: address1,
                                    address2: address2,
                                    city: city,
                                    state: state,
                                    zip: zip,
                                    zipSuffix: zipSuffix,
                                    entityIdentifier: entityIdentifier
                                },
                                "sourceData": sourceData
                            }
                        };
                        tempData.push(providerIndv);
                        /!*     providersData["provider"] = providerIndv;*!/
                    }
                    if (tempData) {
                        eventData.providers = [tempData];
                    }

                }

            } catch (err) {
                console.log("error mapProviderData: " + err);
            }
        }*/

    /* groupProviderData(data) {
         var i: number;
         let providerData;

         try {
             if (data.Provider[0].prov) {
                 providerData = data.Provider[0].prov;
                 let providerSize = providerData.length;

                 /!*                //Provider Address
                                 let provAdrData = data.Provider[0].prov_adr;
                                 if (provAdrData) {
                                     for (i = 0; i < providerSize; i++) {
                                         var address1 = provAdrData[i].adr_ln_1_txt;
                                         var address2 = provAdrData[i].adr_ln_2_txt;
                                         var city = provAdrData[i].cty_nm;
                                         var state = provAdrData[i].st_ref_id;
                                         var zip = provAdrData[i].zip_cd_txt;
                                         var zipSuffix = provAdrData[i].zip_sufx_cd_txt;

                                         if (address1) {
                                             providerData[i]["address1"] = address1;
                                             providerData[i]["address2"] = address2;
                                             providerData[i]["city"] = city;
                                             providerData[i]["state"] = state;
                                             providerData[i]["zip"] = zip;
                                             providerData[i]["zipSuffix"] = zipSuffix;
                                         }
                                     }
                                 }*!/

                 //Hsc_Prov
                 let hscProvData = data.HealthService[0].hsc[0].hsc_prov_role;
                 console.log("Prov role data: " + JSON.stringify(hscProvData));
                 if (hscProvData) {
                     for (i = 0; i < providerSize; i++) {
                         var entityIdentifier = hscProvData[i].prov_role_ref_id;

                         if (entityIdentifier) {
                             providerData[i]["entityIdentifier"] = entityIdentifier;
                         }
                     }
                 }

             }
             return providerData;
         } catch (err) {
             console.log("error groupProviderData: " + err);
         }
     }*/

    /*    mapFollowUpContactData(data, eventData) {
            console.log("DIAGNOSIS DATA: " + JSON.stringify(data.HealthService));
            let tempData = [];
            try {
                let followUpContactData = data.hsc.flwup_cntc_dtl;
                if (followUpContactData) {
                    console.log("followUpContactData DATA: " + JSON.stringify(followUpContactData));
                    var diagnosisCode = followUpContactData.diag_cd;
                    //   var primaryInd = diag.pri_ind;
                    //   var admitInd = diag.admit_ind;
                    var sourceData = diag.sourceData;


                    let followUpCnctData = {
                        "followUpContact": {
                            '$': {
                                contactProviderSeqNum: diagnosisCode
                            },
                            "sourceData": sourceData
                        }
                    };
                    tempData.push(followUpCnctData);

                    if (tempData) {
                        eventData.diagnoses = [tempData];
                    }

                }

            } catch (err) {
                console.log("error mapDiagnosisData: " + err);
            }
        }*/

    /* mapDiagnosisData(data, eventData, hscResponse) {
         console.log("DIAGNOSIS DATA: " + JSON.stringify(hscResponse));
         let tempDiagData = [];
         try {
             let diagnosisData = hscResponse.hsc.hsc_diags.create;
             if (diagnosisData) {
                 console.log("DIAGNOSIS DATA: " + JSON.stringify(diagnosisData));
                 for (const diag of diagnosisData) {
                     var diagnosisCode = diag.diag_cd;
                     //   var primaryInd = diag.pri_ind;
                     //   var admitInd = diag.admit_ind;
                     var sourceData = data.hscSourceData.diagnosis;


                     let diagData = {
                         "diagnosis": {
                             '$': {
                                 diagnosisCode: diagnosisCode
                             },
                             "sourceData": sourceData
                         }
                     };
                     tempDiagData.push(diagData);
                 }
                 if (tempDiagData) {
                     eventData.diagnoses = [tempDiagData];
                 }
             }

         } catch (err) {
             console.log("error mapDiagnosisData: " + err);
         }
     }

     mapFacilityData(data, eventData, hscResponse) {
         let tempData = [];

         try {
             //    let facilityData = this.groupFacilityData(data);
             let facilityData = hscResponse.hsc.hsc_facl;
             if (facilityData) {
                 console.log("FACILITY DATA: " + JSON.stringify(facilityData));

                 var admissionDate = facilityData.expt_admis_dt;
                 var dischargeDate = facilityData.expt_dschrg_dt;
                 var serviceReferenceNum = facilityData.srvc_dtl_ref_id;
                 var sourceData = data.hscSourceData.facility;

                 let faclData = {
                     '$': {
                         admissionDate: admissionDate,
                         dischargeDate: dischargeDate,
                         serviceReferenceNum: serviceReferenceNum
                         //  facilityProviderSeqNum: null
                     },
                     "sourceData": sourceData
                 };

                 tempData.push(faclData);

                 if (tempData) {
                     eventData.facility = tempData;
                 }

             }

         } catch (err) {
             console.log("error mapProviderData: " + err);
         }
     }

     groupFacilityData(data) {
         var i: number;
         let facilityData;

         try {
             facilityData = data.HealthService[0].hsc[0].hsc_facl;
             if (facilityData) {
                 let facilitySize = facilityData.length;

                 //Hsc_Prov
                 let hsrNoteData = data.HealthService[0].hsc[0].hsr_note;
                 if (hsrNoteData) {
                     for (const data of hsrNoteData) {
                         if (data.note_titl_txt == canonicalRequestTags.FACILITY) {
                             let note = data.note_txt_lobj[0];
                             for (i = 0; i < facilitySize; i++) {
                                 var patientStatusCode = note[i].patientStatusCode;

                                 facilityData[i]["patientStatusCode"] = patientStatusCode;

                             }
                         }
                     }
                 }
             }
             return facilityData;
         } catch (err) {
             console.log("error groupFacilityData: " + err);
         }
     }*/

}
