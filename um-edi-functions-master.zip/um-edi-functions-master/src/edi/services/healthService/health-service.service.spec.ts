import { Test, TestingModule } from '@nestjs/testing';
import {Injectable} from "@nestjs/common";
import {HealthServiceService} from "./healthService.service";
import {HealthServiceClient} from "../../../shared/graphql/healthservicedomain/healthServiceClient";
import {request} from "http";

@Injectable()
class HealthServiceClientMock {
}

@Injectable()
class hscShellVariablesMock {
}

@Injectable()
class diagnosisVariablesMock {
}
@Injectable()
class procedureCodeLookupMock {
}


describe('HealthServiceService', () => {
  let service: HealthServiceService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
        providers: [HealthServiceService, {provide: HealthServiceClient, useClass: HealthServiceClientMock}],
    }).compile();

    service = module.get<HealthServiceService>(HealthServiceService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('should run #createHscShell()', async () => {
    spyOn(service, 'createHscShell').and.callThrough();
    service.createHscShell(hscShellVariablesMock, request);
    expect(service).toBeTruthy();
  })

  it('should run #diagnosisICD10Lookup()', async () => {
    spyOn(service, 'diagnosisICD10Lookup').and.callThrough();
    service.diagnosisICD10Lookup(diagnosisVariablesMock, request);
    expect(service).toBeTruthy();
  })

  it('should run #procedureCodeLookup()', async () => {
    spyOn(service, 'procedureCodeLookup').and.callThrough();
    service.procedureCodeLookup(procedureCodeLookupMock, request);
    expect(service).toBeTruthy();
  })
});
