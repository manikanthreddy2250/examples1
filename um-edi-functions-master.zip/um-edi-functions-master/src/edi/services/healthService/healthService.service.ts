import { Injectable } from '@nestjs/common';
import {HealthServiceClient} from "../../../shared/graphql/healthservicedomain/healthServiceClient";
import {
    createHscShell,
    diagnosisCodeQuery,
    procedureCodeQuery
} from "../../../shared/graphql/healthservicedomain/healthServiceQuery";
import {GraphQLClient} from "graphql-request/dist";

@Injectable()
export class HealthServiceService {

    constructor(private readonly healthServiceClient: HealthServiceClient) {}

    async createHscShell(hscShellVariables, request): Promise<any> {
        console.log("processing createHscShell");
        var response: any;
        const healthServiceGraphqlClient: GraphQLClient = this.healthServiceClient.getGraphqlClient(request);

        try {
            console.log("calling graphql");
            response = await healthServiceGraphqlClient.request(createHscShell, hscShellVariables);
            var dec = new TextDecoder("utf-8");
            console.log("HSC ID " + response.insert_hsc.returning[0].hsc_id);

            //canonical decoder
            //var arrayBuffer = new Uint8Array(response.insert_hsc.returning[0].hsc_src_recs[0].src_rec_doc.canonicalRequest).buffer;
            //console.log("decoded array buffer " + dec.decode(arrayBuffer));

        } catch(e) {
            console.log("CATCH BLOCK " + e.toString());
        }
        //console.log("RESPONSE FROM HEALTH SERVICE CALL " + JSON.stringify(response));

        //console.log("response src rec decoded " + dec.decode(response.data[0].hsc_src_recs[0].src_rec_doc));
        return response;
    }

    async diagnosisICD10Lookup(diagnosisVariables, request): Promise<any> {
        var response: any;
        const healthServiceGraphqlClient: GraphQLClient = this.healthServiceClient.getGraphqlClient(request);

        try {
            response = await healthServiceGraphqlClient.request(diagnosisCodeQuery, diagnosisVariables);
        } catch(e) {
            console.log("Error in diagnosisICD10Lookup(): " + e);
        }
        return response;
    }

    async procedureCodeLookup(procedureCodeVariables, request): Promise<any> {
        console.log("processing procedureCodeLookup");
        var response: any;
        const healthServiceGraphqlClient: GraphQLClient = this.healthServiceClient.getGraphqlClient(request);

        try {
            response = await healthServiceGraphqlClient.request(procedureCodeQuery, procedureCodeVariables);
        } catch(e) {
            console.log("Error in procedureCodeLookup(): " + e);
        }
        return response;
    }

}
