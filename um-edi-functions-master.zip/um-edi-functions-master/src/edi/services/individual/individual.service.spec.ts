import { Test, TestingModule } from '@nestjs/testing';
import {Injectable} from "@nestjs/common";
import {IndividualService} from "./individual.service";
import {IndividualClient} from "../../../shared/graphql/individualDomain/individualClient";

@Injectable()
class IndividualClientMock {
}


describe('IndividualService', () => {
  let service: IndividualService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
        providers: [IndividualService, {provide: IndividualClient, useClass: IndividualClientMock}],
    }).compile();

    service = module.get<IndividualService>(IndividualService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
