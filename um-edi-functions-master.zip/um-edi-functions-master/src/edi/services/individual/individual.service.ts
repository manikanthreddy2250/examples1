import {Injectable} from '@nestjs/common';
import {getIndividualKeyDataQuery} from "../../../shared/graphql/individualDomain/individualQuery";
import {IndividualClient} from "../../../shared/graphql/individualDomain/individualClient";

@Injectable()
export class IndividualService {

    constructor(private readonly individualClient: IndividualClient) {
    }

    /*    async getIndividualId(individualVariables): Promise<any> {
            console.log("processing getIndividualId");
            var response: any = "hello";
            try {
                response = await this.individualClient.getGraphqlClient().request(getIndividualIDQuery2, individualVariables);
                console.log("RESPONSE FROM INDIVIDUAL CALL " + JSON.stringify(response));
            } catch(e) {
                console.log("ERROR " + e);
            }
            console.log("RESPONSE FROM INDIVIDUAL CALL " + JSON.stringify(response));
            return response;
        }*/

    async getIndividualKeyData(individualVariables, request) {
        let response;
        try {
            response = await this.individualClient.getGraphqlClient(request).request(getIndividualKeyDataQuery, individualVariables);
        } catch (e) {
            console.log("error in getIndividualKeyData " + e);
        }
        return response;
    }
}
