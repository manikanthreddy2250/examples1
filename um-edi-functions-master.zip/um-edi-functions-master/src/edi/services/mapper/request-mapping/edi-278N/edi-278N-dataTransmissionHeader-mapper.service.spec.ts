import {RequestDetails} from "../../../../constants/edi.constants";
import {testCanonicalRequest} from "../../../../../../test/ediTestData";
import {Test, TestingModule} from "@nestjs/testing";
import {Edi278NDataTransmissionHeaderValidationService} from "../../../validation/278N-validation/edi-278N-dataTransmissionHeader-validation.service";
import {EdiUtilities} from "../../../../edi-utilities";
import {Edi278NDataTransmissionHeaderMapperService} from "./edi-278N-dataTransmissionHeader-mapper.service";
import {ConfigService} from "@nestjs/config";


describe('Edi278NDataTransmissionHeaderMapperService', () => {
    let service: Edi278NDataTransmissionHeaderMapperService;
    let ediUtilities: EdiUtilities;

    const requestDetails: RequestDetails = {
        dataTransmissionHeader: null,
        Membership: null,
        Individual: null,
        Provider: null,
        Facility: null,
        Diagnosis:null,
        Event: null,
        procCodes: null,
        Service: null,
        updateHscRequest: null,
        hscSourceData: null,
        ediType: null,
        followUpContact: null,
        Error: null
    };
    let event = null;

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [Edi278NDataTransmissionHeaderMapperService, EdiUtilities, Edi278NDataTransmissionHeaderValidationService, ConfigService],
        }).compile();

        service = module.get<Edi278NDataTransmissionHeaderMapperService>(Edi278NDataTransmissionHeaderMapperService);
        ediUtilities = module.get<EdiUtilities>(EdiUtilities);

    });

    it('should be defined', () => {
        expect(service).toBeDefined();
    });

    it('should run #mapDataTransmissionHeaderData()', async () => {
        service.mapDataTransmissionHeaderData(testCanonicalRequest, requestDetails, 1);
        expect(service).toBeTruthy();
    });
});