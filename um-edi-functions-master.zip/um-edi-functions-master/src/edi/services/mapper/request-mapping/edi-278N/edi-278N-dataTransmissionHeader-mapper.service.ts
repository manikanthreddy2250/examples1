import {Injectable} from "@nestjs/common";

import {EdiDataTransmissionHeaderMapperService} from "../edi-dataTransmissionHeader-mapper.service";
import {Edi278NDataTransmissionHeaderValidationService} from "../../../validation/278N-validation/edi-278N-dataTransmissionHeader-validation.service";
import {
    canonicalRequestTags,
    DataTransHeader,
    dataTransmissionHeaderAttributes
} from "../../../../constants/edi.constants";
import {Edi278NConstants} from "../../../../constants/edi-278N.constants";
import {EdiUtilities} from "../../../../edi-utilities";

@Injectable()
export class Edi278NDataTransmissionHeaderMapperService extends EdiDataTransmissionHeaderMapperService {

    constructor(ediUtils : EdiUtilities, protected readonly edi278NDataTransmissionHeaderValidationService: Edi278NDataTransmissionHeaderValidationService) {
        super(ediUtils, edi278NDataTransmissionHeaderValidationService)
    }

    async mapDataTransmissionHeaderData(canonicalRequest, requestDetails, hscID) {

        try {
            const dataTransmissionHeaderDetails = this.ediUtils.getElementInfo(canonicalRequest, canonicalRequestTags.DATATRANSMISSIONHEADER);
            const event = this.ediUtils.getElementInfo(canonicalRequest, canonicalRequestTags.EVENT);
            const facilityDetails = this.ediUtils.getElementInfo(event, canonicalRequestTags.FACILITY);

            if (dataTransmissionHeaderDetails) {
                const sourceType = this.edi278NDataTransmissionHeaderValidationService.validateSourceType(this.ediUtils.getAttributeValue(dataTransmissionHeaderDetails, dataTransmissionHeaderAttributes.SOURCETYPE));
                const transactionID = this.ediUtils.getAttributeValue(dataTransmissionHeaderDetails, dataTransmissionHeaderAttributes.TRANSACTIONID);
                //Version is always 1
                const version = Edi278NConstants.INT_ONE;
                const batchFileID = this.ediUtils.getAttributeValue(dataTransmissionHeaderDetails, dataTransmissionHeaderAttributes.BATCHFILEID);
                const receivedDateTime = this.ediUtils.getAttributeValue(dataTransmissionHeaderDetails, dataTransmissionHeaderAttributes.RECEIVEDDATETIME);
                const purposeCode = this.edi278NDataTransmissionHeaderValidationService.validatePurposeCode(this.ediUtils.getAttributeValue(dataTransmissionHeaderDetails, dataTransmissionHeaderAttributes.PURPOSECODE), requestDetails, facilityDetails);
                const transactionType = this.ediUtils.getAttributeValue(dataTransmissionHeaderDetails, dataTransmissionHeaderAttributes.TRANSACTIONTYPE);
                const transactionStatus = this.ediUtils.getAttributeValue(dataTransmissionHeaderDetails, dataTransmissionHeaderAttributes.TRANSACTIONSTATUS);
                const testFlag = this.edi278NDataTransmissionHeaderValidationService.validateTestFlag(this.ediUtils.getAttributeValue(dataTransmissionHeaderDetails, dataTransmissionHeaderAttributes.TESTFLAG));
                const clinicalApplication = this.ediUtils.getAttributeValue(dataTransmissionHeaderDetails, dataTransmissionHeaderAttributes.CLINICALAPPLICATION);
                const payerID = this.ediUtils.getAttributeValue(dataTransmissionHeaderDetails, dataTransmissionHeaderAttributes.PAYERID);
                const submitterID = this.ediUtils.getAttributeValue(dataTransmissionHeaderDetails, dataTransmissionHeaderAttributes.SUBMITTERID);
                const tradingPartnerID = this.ediUtils.getAttributeValue(dataTransmissionHeaderDetails, dataTransmissionHeaderAttributes.TRADINGPARTNERID);
                let sourceData = this.ediUtils.getRequestInfo(dataTransmissionHeaderDetails, canonicalRequestTags.SOURCEDATA);
                sourceData = this.ediUtils.removeLineBreaks(sourceData);

                var dataHeader: DataTransHeader = {
                    sourceType: sourceType,
                    transactionID: transactionID,
                    version: version,
                    batchFileID: batchFileID,
                    receivedDateTime: receivedDateTime,
                    purposeCode: purposeCode,
                    transactionType: transactionType,
                    transactionStatus: transactionStatus,
                    testFlag: testFlag,
                    clinicalApplication: clinicalApplication,
                    payerID: payerID,
                    submitterID: submitterID,
                    ediID: hscID,
                    sourceData: sourceData,
                    tradingPartnerID : tradingPartnerID
                };
                requestDetails.dataTransmissionHeader = dataHeader;
            }
        } catch (err) {
            console.log(`Error in mapDataTransmissionHeaderData:  ${err}`);
        }
    }
}