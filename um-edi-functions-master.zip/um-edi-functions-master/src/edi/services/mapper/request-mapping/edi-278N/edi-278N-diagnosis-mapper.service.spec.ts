import {canonicalRequestTags, RequestDetails} from "../../../../constants/edi.constants";
import {testCanonicalRequest, testCanonicalRequestMultipleDiagnoses} from "../../../../../../test/ediTestData";
import {Test, TestingModule} from "@nestjs/testing";
import {EdiUtilities} from "../../../../edi-utilities";
import {ConfigService} from "@nestjs/config";
import {Edi278NDiagnosisMapperService} from "./edi-278N-diagnosis-mapper.service";
import {Edi278NDiagnosisValidationService} from "../../../validation/278N-validation/edi-278N-diagnosis-validation.service";
import {HttpRequest} from "@azure/functions";
import {HealthServiceService} from "../../../healthService/healthService.service";
import {HealthServiceClient} from "../../../../../shared/graphql/healthservicedomain/healthServiceClient";
import {HttpModule, HttpService, Injectable} from "@nestjs/common";
import {AppService} from "../../../../../app.service";


@Injectable()
class Edi278NDiagnosisValidationServiceMock {
    validateDiagnosisCode(diagnosisCode, request) {
        return "M54.16";
    }

    getEventICDNote(canonicalRequest) {
        return null;
    }
}

@Injectable()
class AppServiceMock {
    getRefMatchCode(baseRefName, refCode) {
        return "123";
    }

    getRefMatchDesc(baseRefName, refCode) {
        return "123";
    }
}


describe('Edi278NDiagnosisMapperService', () => {
    let service: Edi278NDiagnosisMapperService;
    let ediUtilities: EdiUtilities;
    let diagnosisDetails;
    let httpService: HttpService;

    const requestDetails: RequestDetails = {
        dataTransmissionHeader: null,
        Membership: null,
        Individual: null,
        Provider: null,
        Facility: null,
        Diagnosis: null,
        Event: null,
        procCodes: null,
        Service: null,
        updateHscRequest: null,
        hscSourceData: null,
        ediType: null,
        followUpContact: null,
        Error: null
    };

    const hscData = {
        hsc_id: 1,
        indv_key_typ_ref_id: null,
        indv_key_val: null,
        srvc_set_ref_id: 3737,
        rev_prr_ref_id: 3754,
        flwup_cntc_dtl: null,
        hsr_notes: null,
        hsc_diags: new Array()
    };

    const sourceDataObject ={};
    let request: HttpRequest;
    let event;

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            imports: [HttpModule],
            providers: [{provide: AppService, useClass: AppServiceMock}, Edi278NDiagnosisMapperService, EdiUtilities,
                {provide: Edi278NDiagnosisValidationService, useClass: Edi278NDiagnosisValidationServiceMock}, ConfigService, HealthServiceClient, HealthServiceService],
        }).compile();

        service = module.get<Edi278NDiagnosisMapperService>(Edi278NDiagnosisMapperService);
        ediUtilities = module.get<EdiUtilities>(EdiUtilities);
        event = ediUtilities.getElementInfo(testCanonicalRequest, canonicalRequestTags.EVENT);
        diagnosisDetails = ediUtilities.getRequestInfo(event, canonicalRequestTags.DIAGNOSES);
        httpService = module.get<HttpService>(HttpService);
    });

    it('should be defined', () => {
        expect(service).toBeDefined();
    });

    it('should run #mapHscDiagnosisData() - single Diagnosis', async () => {
        var diagnosisValidation = new Edi278NDiagnosisValidationServiceMock();
        spyOn(diagnosisValidation, 'getEventICDNote').and.callThrough();
        spyOn(diagnosisValidation, 'validateDiagnosisCode').and.callThrough();
        spyOn(service, 'mapSingleDiagnosis').and.callFake(function () {});

        service.mapHscDiagnosisData(testCanonicalRequest, hscData, sourceDataObject, request, requestDetails);
        expect(service).toBeTruthy();
    });

    it('should run #mapHscDiagnosisData() - multiple Diagnoses', async () => {
        var diagnosisValidation = new Edi278NDiagnosisValidationServiceMock();
        var appService = new AppServiceMock();
        spyOn(appService, 'getRefMatchDesc').and.callThrough();
        spyOn(diagnosisValidation, 'getEventICDNote').and.callThrough();
        spyOn(diagnosisValidation, 'validateDiagnosisCode').and.callThrough();
        spyOn(service, 'mapMultipleDiagnoses').and.callFake(function () {});

        service.mapHscDiagnosisData(testCanonicalRequestMultipleDiagnoses, hscData, sourceDataObject, request, requestDetails);
        expect(service).toBeTruthy();
    });

    it('should run #mapSingleDiagnosis()', async () => {
        const diagSourceData ={};
        const createObject ={};
        var diagnosisValidation = new Edi278NDiagnosisValidationServiceMock();
        spyOn(diagnosisValidation, 'validateDiagnosisCode').and.callThrough();

        service.mapSingleDiagnosis(diagnosisDetails, diagSourceData, createObject, hscData, request, requestDetails);
        expect(service).toBeTruthy();
    });

    it('should run #mapMultipleDiagnoses()', async () => {
        const diagSourceData ={};
        const createObject ={};
        var diagnosisValidation = new Edi278NDiagnosisValidationServiceMock();
        spyOn(diagnosisValidation, 'validateDiagnosisCode').and.callThrough();

        service.mapMultipleDiagnoses(diagnosisDetails, diagSourceData, createObject, hscData, request, requestDetails);
        expect(service).toBeTruthy();
    });
});