import {Injectable} from "@nestjs/common";
import {EdiDiagnosisMapperService} from "../edi-diagnosis-mapper.service";
import {EdiUtilities} from "../../../../edi-utilities";
import {Edi278NDiagnosisValidationService} from "../../../validation/278N-validation/edi-278N-diagnosis-validation.service";
import {
    canonicalRequestTags,
    Diagnosis,
    diagnosisAttributes, DiagnosisData,
    EdiLineSeperator
} from "../../../../constants/edi.constants";
import {AppService} from "../../../../../app.service";

@Injectable()
export class Edi278NDiagnosisMapperService extends EdiDiagnosisMapperService {

    constructor(ediUtils: EdiUtilities,
                appService: AppService,
                protected readonly edi278NDiagnosisValidationService: Edi278NDiagnosisValidationService) {
        super(ediUtils, appService, edi278NDiagnosisValidationService);
    }

    async mapHscDiagnosisData(canonicalRequest, hscData, sourceDataObject, request, requestDetails) {
        const diagSourceData = [];
        let diagCodeSchemeRefID;

        try {
            //Get RefID of Diagnosis Code Scheme Ref ID
            const refDataResults = this.appService.getRefMatchDesc('diagnosisCodeVersion', 'ICD10');
            if (refDataResults) {
                diagCodeSchemeRefID = refDataResults.ref_id;
            } else {
                //ref id does not exists in ref domain -set error
            }

            //check event note for ICD
            const eventICDNoteExists = this.edi278NDiagnosisValidationService.getEventICDNote(canonicalRequest);
            if (eventICDNoteExists) {
                //add ICD to diagnosis object
            } else {
                var event = await this.ediUtils.getElementInfo(canonicalRequest, canonicalRequestTags.EVENT);
                const diagnosisDetails = this.ediUtils.getRequestInfo(event, canonicalRequestTags.DIAGNOSES);

                if (diagnosisDetails) {
                    const diagArray = diagnosisDetails.split("<" + canonicalRequestTags.DIAGNOSIS);
                    diagArray.shift();

                    if (diagArray.length == 1) { //single diagnosis is submitted
                        await this.mapSingleDiagnosis(diagArray, diagSourceData, diagCodeSchemeRefID, hscData, request, requestDetails);

                    } else { //multiple diagnosis
                        await this.mapMultipleDiagnoses(diagArray, diagSourceData, diagCodeSchemeRefID, hscData, request, requestDetails);
                    }
                    sourceDataObject[canonicalRequestTags.DIAGNOSIS] = diagSourceData;
                }
            }
        } catch (err) {
            //console.log(`Error in getHscDiagnosisData:  ${err}`);
        }
    }

    async mapSingleDiagnosis(diagArray, diagSourceData, diagCodeSchemeRefID, hscData, request, requestDetails) {

        try {
       //     const diagCode = await this.edi278NDiagnosisValidationService.validateDiagnosisCode(this.ediUtils.getAttributeValue(diagArray[0], diagnosisAttributes.DIAGNOSISCODE), request);
            const diagCode = this.ediUtils.getAttributeValue(diagArray[0], diagnosisAttributes.DIAGNOSISCODE);
            const singleDiag: Diagnosis = {
                diag_cd: diagCode,
                pri_ind: 1,         //set single diagnosis as primary
                diag_othr_txt: null,
                diag_cd_schm_ref_id: diagCodeSchemeRefID,
                admit_ind: 0,
                inac_ind: 0,
                creat_user_id: null,
                chg_user_id: null
            };

            const diagnosisCodeType = this.ediUtils.getAttributeValue(diagArray, diagnosisAttributes.DIAGNOSISCODETYPE);
            const diagnosisSeqNum = this.ediUtils.getAttributeValue(diagArray, diagnosisAttributes.DIAGNOSISSEQNUM);


            //set values for Diagnosis object
            const diagnosisData: DiagnosisData = {
                diagnosisSeqNum: diagnosisSeqNum,
                diagnosisCodeType: diagnosisCodeType,
                diagnosisCode: diagCode
            };
            requestDetails.Diagnosis = diagnosisData;

            if (diagCode) {
                hscData.hsc_diags.push(singleDiag);

                let sourceData = this.ediUtils.getRequestInfo(diagArray[0], canonicalRequestTags.SOURCEDATA);
                sourceData = this.ediUtils.removeLineBreaks(sourceData);
                if (sourceData) {
                    diagSourceData.push(sourceData);
                }
            }
        } catch (err) {
            //console.log(`Error in mapSingleDiagnosis:  ${err}`);
        }
    }


    async mapMultipleDiagnoses(diagArray, diagSourceData, diagCodeSchemeRefID, hscData, request, requestDetails) {
        const diagnosisDataArray = [];

        try {
            for (const diagnosis of diagArray) {
                //insert dupe checking of diagnosis

                const diag: Diagnosis = {
                    diag_cd: null,
                    pri_ind: 0,
                    diag_othr_txt: null,
                    diag_cd_schm_ref_id: diagCodeSchemeRefID,
                    admit_ind: 0,
                    inac_ind: 0,
                    creat_user_id: null,
                    chg_user_id: null
                };

                const diagnosisCodeType = this.ediUtils.getAttributeValue(diagnosis, diagnosisAttributes.DIAGNOSISCODETYPE);
              //  const diagnosisCode = await this.edi278NDiagnosisValidationService.validateDiagnosisCode(this.ediUtils.getAttributeValue(diagnosis, diagnosisAttributes.DIAGNOSISCODE), request);
                const diagnosisCode = this.ediUtils.getAttributeValue(diagnosis, diagnosisAttributes.DIAGNOSISCODE);
                const diagnosisSeqNum = this.ediUtils.getAttributeValue(diagnosis, diagnosisAttributes.DIAGNOSISSEQNUM);


                //set values for Diagnosis object
                const diagnosisData: DiagnosisData = {
                    diagnosisSeqNum: diagnosisSeqNum,
                    diagnosisCodeType: diagnosisCodeType,
                    diagnosisCode: diagnosisCode
                };

                requestDetails.Diagnosis = diagnosisDataArray;
                diagnosisDataArray.push(diagnosisData)

                if (diagnosisCode) {
                    diag.diag_cd = diagnosisCode;
                }
                const primaryInd = this.ediUtils.getAttributeValue(diagnosis, diagnosisAttributes.PRIMARYIND);
                const admitInd = this.ediUtils.getAttributeValue(diagnosis, diagnosisAttributes.ADMITIND);
                let sourceData = this.ediUtils.getRequestInfo(diagnosis, canonicalRequestTags.SOURCEDATA);
                sourceData = this.ediUtils.removeLineBreaks(sourceData);
                if (sourceData) {
                    diagSourceData.push(sourceData);
                }

                hscData.hsc_diags.push(diag);
            }

        } catch (err) {
            //console.log(`Error in getHscDiagnosisData:  ${err}`);
        }
    }

}