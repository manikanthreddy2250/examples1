import {RequestDetails} from "../../../../constants/edi.constants";
import {testCanonicalRequest} from "../../../../../../test/ediTestData";
import {Test, TestingModule} from "@nestjs/testing";
import {EdiUtilities} from "../../../../edi-utilities";
import {ConfigService} from "@nestjs/config";
import {Edi278NEventMapperService} from "./edi-278N-event-mapper.service";
import {
    canonicalRequestTags
} from "../../../../constants/edi.constants";
import {Edi278NDataTransmissionHeaderMapperService} from "./edi-278N-dataTransmissionHeader-mapper.service";
import {Injectable} from "@nestjs/common";

@Injectable()
class Edi278NDataTransmissionHeaderMapperServiceMock {
    mapDataTransmissionHeaderData(canonicalRequest, requestDetails, hscID) {

    }
}

describe('Edi278NDataTransmissionHeaderMapperService', () => {
    let service: Edi278NEventMapperService;
    let ediUtilities: EdiUtilities;
    const dataTransMapperService = new Edi278NDataTransmissionHeaderMapperServiceMock();

    const hscData = {
        hsc_id: 1,
        indv_key_typ_ref_id: null,
        indv_key_val: null,
        srvc_set_ref_id: 3737,
        rev_prr_ref_id: 3754,
        flwup_cntc_dtl: null,
        hsc_srvcs: new Array(),
        hsr_notes: null
    };
    let event = null;

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [Edi278NEventMapperService, EdiUtilities, ConfigService,
                {
                    provide: Edi278NDataTransmissionHeaderMapperService,
                    useClass: Edi278NDataTransmissionHeaderMapperServiceMock
                },],
        }).compile();

        service = module.get<Edi278NEventMapperService>(Edi278NEventMapperService);
        ediUtilities = module.get<EdiUtilities>(EdiUtilities);
        event = ediUtilities.getElementInfo(testCanonicalRequest, canonicalRequestTags.EVENT);
    });

    it('should be defined', () => {
        expect(service).toBeDefined();
    });

    it('should run #mapEventMBRSHP()', async () => {
        service.mapEventMBRSHP(testCanonicalRequest, hscData);
        expect(service).toBeTruthy();
    });

    it('should run #mapEventMBRSHP()', async () => {
        service.mapHscClinGuidData(testCanonicalRequest, hscData);
        expect(service).toBeTruthy();
    });

});