import {Injectable} from "@nestjs/common";
import {EdiEventMapperService} from "../edi-event-mapper.service";
import {
    hscAttributes,
    eventNotes,
    EdiLineSeperator,
    canonicalRequestTags, dataTransmissionHeaderAttributes, DataTransHeader, HscPwkDetails, EventDetails,
} from "../../../../constants/edi.constants";
import {Edi278NConstants} from "../../../../constants/edi-278N.constants";

@Injectable()
export class Edi278NEventMapperService extends EdiEventMapperService {

    mapEventMBRSHP(canonicalRequest, hscData) {
        let eventNoteString = "";
        const eventTagInfo = this.ediUtils.getElementAttributeInfo(canonicalRequest, canonicalRequestTags.EVENT);

        try {
            const otherUMOName = this.ediUtils.getAttributeValue(eventTagInfo, hscAttributes.OTHERUMONAME);
            if (otherUMOName) {
                eventNoteString += eventNotes.OTHERUMONAME + ": " + otherUMOName + EdiLineSeperator.LINE_BREAK;
            }
            if (eventNoteString.length > 0) {
                //this.addHsrNote(eventNoteString, canonicalRequestTags.FACILITY, hscData);
            }

        } catch (err) {
            console.log(`Error in getEventHsrNotes:  ${err}`);
        }
    }

    async mapHscClinGuidData(canonicalRequest, hscData) {

        try {
            const eventTagInfo = this.ediUtils.getElementInfo(canonicalRequest, canonicalRequestTags.EVENT);

            if (eventTagInfo) {

                const idCode = this.ediUtils.getAttributeValue(eventTagInfo, hscAttributes.IDCODE);
                const reviewIdDesc = this.ediUtils.getAttributeValue(eventTagInfo, hscAttributes.REVIEWIDDESC);

                var hscPwkDetails: HscPwkDetails = {
                    hsc_clin_guid_id: null,
                    clin_rev_desc: reviewIdDesc,
                    clin_rev_otcome_ref_id: parseInt(idCode),
                    clin_rev_sts_ref_id: 19274

                };
                hscData.hsc_clin_guid = hscPwkDetails;
            }
        } catch (err) {
            console.log(`Error in mapHscClinGuidData:  ${err}`);
        }
    }

    async mapEventData(canonicalRequest, requestDetails){
        try{
            const eventTagInfo = this.ediUtils.getElementInfo(canonicalRequest, canonicalRequestTags.EVENT);
            if (eventTagInfo){
                const idCode = this.ediUtils.getAttributeValue(eventTagInfo, hscAttributes.IDCODE);
                const reviewIdDesc = this.ediUtils.getAttributeValue(eventTagInfo, hscAttributes);
                const reportTypeCode = this.ediUtils.getAttributeValue(eventTagInfo, hscAttributes.REPORTTYPECODE);
                const accidentDate = this.ediUtils.getAttributeValue(eventTagInfo, hscAttributes.ACCIDENTDATE);
                const note = this.ediUtils.getAttributeValue(eventTagInfo, hscAttributes.NOTE);
                const createTime = this.ediUtils.getAttributeValue(eventTagInfo, hscAttributes.CREATETIME);
                const createDate = this.ediUtils.getAttributeValue(eventTagInfo, hscAttributes.CREATEDATE);
                const reportTransmissionCode = this.ediUtils.getAttributeValue(eventTagInfo, hscAttributes.REPORTTRANSMISSIONCODE);
                const idCodeQualifier = this.ediUtils.getAttributeValue(eventTagInfo, hscAttributes.IDCODEQUALIFIER);
                const eventDetails: EventDetails = {
                    idCode: parseInt(idCode),
                    reviewIdDesc: reviewIdDesc,
                    reportTypeCode: reportTypeCode,
                    reportTransmissionCode: reportTransmissionCode,
                    idCodeQualifier: idCodeQualifier,
                    accidentDate: accidentDate,
                    note: note,
                    createTime: createTime,
                    createDate: createDate
                };
                requestDetails.Event = eventDetails;
            }
        } catch (err) {
            console.log(`Error in getting Event Data:  ${err}`);

        }
    };
}
