import {HealthServiceService} from "../../../healthService/healthService.service";
import {testCanonicalRequest} from "../../../../../../test/ediTestData";
import {ConfigService} from "@nestjs/config";
import {Test, TestingModule} from "@nestjs/testing";
import {HealthServiceClient} from "../../../../../shared/graphql/healthservicedomain/healthServiceClient";
import {HttpModule, HttpService, Injectable} from "@nestjs/common";
import {HttpRequest} from "@azure/functions";
import {canonicalRequestTags, PatientStatusCode, RequestDetails} from "../../../../constants/edi.constants";
import {EdiUtilities} from "../../../../edi-utilities";
import {Edi278NFacilityMapperService} from "./edi-278N-facility-mapper.service";
import {EdiFacilityValidationService} from "../../../validation/edi-facility-validation.service";
import {AppService} from "../../../../../app.service";
import {ReferenceClient} from "../../../../../shared/graphql/referenceDomain/referenceClient";
import {HttpClient} from "@angular/common/http";

@Injectable()
class EdiFacilityValidationServiceMock {
    validateRequestCategory(serviceSettingType, requestCategory){
        return "AR";
    }

    validateCertificateType(certificateType){
        return "I";
    }

    validateServiceReferenceNumber(serviceReferenceNumber){
        return "testSRN123";
    }

    validateAdmissionTypeCode(admissionTypeCode){
        return "1234";
    }

    translatePatientStatusCode(patientStatusCode){
        return PatientStatusCode.PATIENT_STATUS_CODE_1;
    }
}

@Injectable()
class AppServiceMock {
    getCdxRefMatchAtrVal(baseRefName, refCode) {
        return "123";
    }

    getRefMatchCode(baseRefName, refCode) {
        return "123";
    }
}

describe('Edi278NFacilityMapperService', () => {
    let service: Edi278NFacilityMapperService;
    let ediUtilities: EdiUtilities;
    let httpService: HttpService;

    const requestDetails: RequestDetails = {
        dataTransmissionHeader: null,
        Membership: null,
        Individual: null,
        Provider: null,
        Facility: {
            requestCategory: "AR",
            certificationType: "I",
            admissionDate: "2021-02-20",
            dischargeDate: "2021-02-20",
            facilityProviderSeqNum: "2",
            serviceReferenceNum: "test123"
        },
        Diagnosis:null,
        Event: null,
        procCodes: null,
        Service: null,
        updateHscRequest: null,
        hscSourceData: null,
        ediType: null,
        followUpContact: null,
        Error: null
    };

    const hscData = {
        hsc_facl: {
            plsrv_ref_id: 3747,
            srvc_desc_ref_id: 4349,
            srvc_dtl_ref_id: 4319,
            actul_admis_dttm: "2021-02-20",
            actul_dschrg_dttm: "2021-02-20",
            expt_admis_dt: "2021-02-20",
            expt_dschrg_dt: "2021-02-20",
            admis_ntfy_dttm: null,
            admis_ntfy_trans_id: null,
            adv_ntfy_trans_id: null,
            ctp_nom_sts_ref_id: null,
            dschrg_disp_ref_id: null,
            dschrg_ntfy_trans_id: null,
            goal_los_day_cnt: null,
            ipcm_typ_ref_id: null,
            rem_snf_day_cnt: null,
            snf_day_xhst_ind: null,
            tat_due_dttm: null,
            hsc_decn: null
        }
    };

    const sourceDataObject ={};
    let request: HttpRequest;
    let event;

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            imports: [HttpModule],
            providers: [Edi278NFacilityMapperService, EdiUtilities, HttpClient,
                {provide: EdiFacilityValidationService, useClass: EdiFacilityValidationServiceMock}, ConfigService, HealthServiceClient, HealthServiceService, AppService, ReferenceClient],
        }).compile();

        service = module.get<Edi278NFacilityMapperService>(Edi278NFacilityMapperService);
        ediUtilities = module.get<EdiUtilities>(EdiUtilities);
        event = ediUtilities.getElementInfo(testCanonicalRequest, canonicalRequestTags.EVENT);
    });

    it('should be defined', () => {
        expect(service).toBeDefined();
    });

    it('should run #mapFacilityData()', async () => {
        var facilityValidation = new EdiFacilityValidationServiceMock();
        spyOn(facilityValidation, 'validateRequestCategory').and.callThrough();
        spyOn(facilityValidation, 'validateCertificateType').and.callThrough();
        spyOn(facilityValidation, 'validateServiceReferenceNumber').and.callThrough();
        spyOn(facilityValidation, 'validateAdmissionTypeCode').and.callThrough();
        spyOn(facilityValidation, 'translatePatientStatusCode').and.callThrough();

        service.mapFacilityData(event, hscData, sourceDataObject, "Inpatient", requestDetails);
        expect(service).toBeTruthy();
    });

    it('should run #getPlaceOfServiceCode()', async () => {
        expect(service.getPlaceOfServiceCode('21', 'A')).not.toBeNull();
        expect(service.getPlaceOfServiceCode).toBeTruthy();
        service.getPlaceOfServiceCode('21', 'A');
        expect(service).toBeTruthy();
    });

    it('should run #getServiceDetailType()', async () => {
        var appService = new AppServiceMock();
        spyOn(appService, 'getCdxRefMatchAtrVal').and.callThrough();
        spyOn(appService, 'getRefMatchCode').and.callThrough();
        expect(service.getServiceDetailType('A9', '21')).not.toBeNull();
        expect(service.getServiceDetailType).toBeTruthy();
        service.getServiceDetailType('A9', '21');
        expect(service).toBeTruthy();

    });

});