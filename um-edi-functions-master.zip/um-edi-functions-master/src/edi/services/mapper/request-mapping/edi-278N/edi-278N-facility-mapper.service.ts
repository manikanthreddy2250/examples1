import {Injectable} from "@nestjs/common";
import {EdiFacilityMapperService} from "../edi-facility-mapper.service";
import {
    canonicalRequestTags,
    Facility,
    facilityAttributes,
    FacilityData
} from "../../../../constants/edi.constants";
import {Edi278NConstants} from "../../../../constants/edi-278N.constants";


@Injectable()
export class Edi278NFacilityMapperService extends EdiFacilityMapperService {

    async mapFacilityData(event, hscData, sourceDataObject, serviceSettingType, requestDetails) {

        try {
            const facilityDetails = this.ediUtils.getElementInfo(event, canonicalRequestTags.FACILITY);

            if (facilityDetails) {
                const placeOfServiceCodeDetails = await this.getPlaceOfServiceCode(this.ediUtils.getAttributeValue(facilityDetails, facilityAttributes.FACILITYCODE), this.ediUtils.getAttributeValue(facilityDetails, facilityAttributes.FACILITYCODEQUALIFIER));
                const serviceDetailType = this.getServiceDetailType(this.ediUtils.getAttributeValue(facilityDetails, facilityAttributes.SERVICETYPE), placeOfServiceCodeDetails.placeOfServiceCode);
                const admissionDate = this.ediUtils.getAttributeValue(facilityDetails, facilityAttributes.ADMISSIONDATE);
                const dischargeDate = this.ediUtils.getAttributeValue(facilityDetails, facilityAttributes.DISCHARGEDATE);
                const certificationType = this.ediUtils.getAttributeValue(facilityDetails, facilityAttributes.CERTFICATIONTYPE);
                const requestCategory = this.ediFacilityValidationService.validateRequestCategory(serviceSettingType, this.ediUtils.getAttributeValue(facilityDetails, facilityAttributes.REQUESTCATEGORY));
                const serviceReferenceNum = this.ediFacilityValidationService.validateServiceReferenceNumber(this.ediUtils.getAttributeValue(facilityDetails, facilityAttributes.SERVICEREFERENCENUM));
                const admissionTypeCode = this.ediFacilityValidationService.validateAdmissionTypeCode(this.ediUtils.getAttributeValue(facilityDetails, facilityAttributes.ADMISSIONTYPECODE));
                const patientStatusCode = this.ediUtils.getAttributeValue(facilityDetails, facilityAttributes.PATIENTSTATUSCODE);
                const facilityProviderSeqNum = this.ediUtils.getAttributeValue(facilityDetails, facilityAttributes.FACILITYPROVIDERSEQNUM);
                const servReferenceNum = this.ediUtils.getAttributeValue(facilityDetails, facilityAttributes.SERVICEREFERENCENUM);




                let sourceData = this.ediUtils.getRequestInfo(facilityDetails, canonicalRequestTags.SOURCEDATA);
                sourceData = this.ediUtils.removeLineBreaks(sourceData);
                if (sourceData) {
                    sourceDataObject[canonicalRequestTags.FACILITY] = sourceData;
                }

                //set values for the updateHSC api object
                const facility: Facility = {
                    plsrv_ref_id: placeOfServiceCodeDetails.ref_id,
                    srvc_desc_ref_id: admissionTypeCode,
                    srvc_dtl_ref_id: serviceDetailType,
                    actul_admis_dttm: admissionDate,
                    actul_dschrg_dttm: dischargeDate,
                    expt_admis_dt: admissionDate,
                    expt_dschrg_dt: dischargeDate,
                    admis_ntfy_dttm: null,
                    admis_ntfy_trans_id: null,
                    adv_ntfy_trans_id: null,
                    ctp_nom_sts_ref_id: null,
                    dschrg_disp_ref_id: null,
                    dschrg_ntfy_trans_id: null,
                    goal_los_day_cnt: null,
                    ipcm_typ_ref_id: null,
                    rem_snf_day_cnt: null,
                    snf_day_xhst_ind: null,
                    tat_due_dttm: null,
                    hsc_decn: null
                };
                hscData.hsc_facl = facility;

                //set values for RequestDetails object
                const facilityData: FacilityData = {
                    requestCategory: requestCategory,
                    certificationType: certificationType,
                    admissionDate: admissionDate,
                    dischargeDate: dischargeDate,
                    facilityProviderSeqNum: facilityProviderSeqNum,
                    serviceReferenceNum: servReferenceNum
                };
                requestDetails.Facility = facilityData;


                /*                              //FacilityBedDay
                var facilityBedDayDetails = this.ediUtils.getElementAttributeInfo(facilityDetails, canonicalRequestTags.FACILITYDECNBEDDAY);

                var revenueCode = this.ediUtils.getAttributeValue(facilityBedDayDetails, facilityAttributes.REVENUECODE);
                var bedTypeID = this.ediUtils.getAttributeValue(facilityBedDayDetails, facilityAttributes.BEDTYPEID);

                var facBedDay: FacBedDay = {
                    rvnu_cd: revenueCode,
                    bed_typ_ref_id: bedTypeID
                }
                hscData.hsc_decn_bed_day.push(facBedDay);

                //FacilityBedStayDecision
                var facilityBedStayDecisionDetails = this.ediUtils.getRequestInfo(event, canonicalRequestTags.FACILITYBEDSTAYDECISIONS);
                if (facilityBedStayDecisionDetails) {
                    var tempFaceBedStayData: FacBedStayDecision[] = new Array();
                    var facilityBedStayDecisionDetailsArray = facilityBedStayDecisionDetails.split("<" + canonicalRequestTags.FACILITYBEDSTAYDECISION);
                    facilityBedStayDecisionDetailsArray.shift();

                    for (facilityBedStayDecision of facilityBedStayDecisionDetailsArray) {
                        var decisionOutcomeTypeID = this.ediUtils.getAttributeValue(facilityBedStayDecision, facilityAttributes.DECISIONOUTCOMETYPEID);

                        var facBedStayDecision: FacBedStayDecision = {
                            decn_otcome_ref_id: decisionOutcomeTypeID,
                            decn_typ_ref_id: null,
                            decn_rsn_ref_id: null,
                            clm_note_txt: null,
                            ovrd_clm_rmrk_ref_id: null,
                            sys_clm_rmrk_ref_id: null,
                            decn_src_desc: null,
                            wrt_decn_cmnct_dttm: null,
                            decn_rndr_dttm: null,
                            decn_mbr_cmnct_dttm: null,
                            decn_prov_cmnct_dttm: null,
                            gap_rev_otcome_ref_id: null,
                            negot_rt: null,
                            hsc_decn_bed_days: new Array()
                        };
                        tempFaceBedStayData.push(facBedStayDecision);
                    }
                    hscData.hsc_decn.push(tempFaceBedStayData);
                }*/
            }
        } catch (err) {
            //console.log(`Error in getHscFacilityData:  ${err}`);
        }
    }

    getPlaceOfServiceCode(facilityCode, facilityCodeQualifier) {
        try {
            if (facilityCode && facilityCodeQualifier) {
                const atrFromVal = facilityCodeQualifier + "+" + facilityCode + "+" + Edi278NConstants.EDI_TYPE_278N_IN;

                //Get cdxRef Data
                const cdxRefDataResults = this.appService.getCdxRefMatchAtrVal('placeOfServiceCode', atrFromVal);
                if (cdxRefDataResults.atr_to_val) {
                    //Get RefID of atrToVal
                    const refDataResults = this.appService.getRefMatchCode('placeOfServiceCode', cdxRefDataResults.atr_to_val);
                    if (refDataResults) {
                        refDataResults.placeOfServiceCode = cdxRefDataResults.atr_to_val;
                        return refDataResults;
                    }
                } else {
                    //throw error if atrToVal is null
                }
            }
        } catch (err) {

        }
    }

    getServiceDetailType(serviceType, placeOfServiceCode) {
        try {
            if (serviceType && placeOfServiceCode) {
                const atrFromVal = placeOfServiceCode + "+" + serviceType;

                //Get cdxRef Data

                const cdxRefDataResults = this.appService.getCdxRefMatchAtrVal('serviceDetailType', atrFromVal);
                if (cdxRefDataResults.atr_to_val) {
                    //Get RefID of atrToVal
                    const refDataResults = this.appService.getRefMatchCode('serviceDetailType', cdxRefDataResults.atr_to_val);
                    if (refDataResults) {
                        return refDataResults.ref_id;
                    }
                } else {
                    //throw error if atrToVal is null
                }
            }
        } catch (err) {

        }
    }

}