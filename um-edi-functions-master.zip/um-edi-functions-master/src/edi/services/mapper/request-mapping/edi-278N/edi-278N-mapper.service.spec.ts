import {Test, TestingModule} from '@nestjs/testing';
import {HttpModule, Injectable} from "@nestjs/common";
import {Edi278NMapperService} from "./edi-278N-mapper.service";
import {EdiMemberValidationService} from "../../../validation/edi-member-validation.service";
import {Edi278NDiagnosisValidationService} from "../../../validation/278N-validation/edi-278N-diagnosis-validation.service";
import {EdiProviderValidationService} from "../../../validation/edi-provider-validation.service";
import {ProviderService} from "../../../provider/provider.service";
import {EdiUtilities} from "../../../../edi-utilities";
import {Edi278NDataTransmissionHeaderValidationService} from "../../../validation/278N-validation/edi-278N-dataTransmissionHeader-validation.service";
import {IndividualService} from "../../../individual/individual.service";
import {EdiFacilityValidationService} from "../../../validation/edi-facility-validation.service";
import {testCanonicalRequest, testRequest} from "../../../../../../test/ediTestData";
import {
    canonicalRequestTags,
    EdiMemberConstants,
    EdiServiceSettingTypeConstants,
    IndvAddress,
    MemberCoverage, PatientStatusCode, Provider,
    ProviderAddress,
    ProviderData,
    ProviderIndv,
    ProviderOrg,
    RequestDetails
} from "../../../../constants/edi.constants";
import {Edi278NConstants} from "../../../../constants/edi-278N.constants";
import {HttpRequest} from "@azure/functions";
import {Edi278NServiceMapperService} from "./edi-278N-service-mapper.service";
import {Edi278NFacilityMapperService} from "./edi-278N-facility-mapper.service";
import {Edi278NDiagnosisMapperService} from "./edi-278N-diagnosis-mapper.service";
import {Edi278NDataTransmissionHeaderMapperService} from "./edi-278N-dataTransmissionHeader-mapper.service";
import {Edi278NProviderMapperService} from "./edi-278N-provider-mapper.service";
import {Edi278NMemberMapperService} from "./edi-278N-member-mapper.service";
import {AppService} from "../../../../../app.service";
import {ConfigService} from "@nestjs/config";
import {HealthServiceClient} from "../../../../../shared/graphql/healthservicedomain/healthServiceClient";
import {ReferenceClient} from "../../../../../shared/graphql/referenceDomain/referenceClient";
import {Edi278NEventMapperService} from "./edi-278N-event-mapper.service";

@Injectable()
class IndividualServiceMock {
    getIndividualKeyData(individualKeyVariables) {
        const response = {
            indv_key: [{indv_key_typ_ref_id: "123", indv_key_val: "123"}]
        };
        return response;
    }
}

@Injectable()
class ProviderServiceMock {
    getHscProviderForPerson(personProviderVariables) {
        return;
    }
}

@Injectable()
class Edi278NDataTransmissionHeaderMapperServiceMock {
    mapDataTransmissionHeaderData(canonicalRequest, requestDetails, hscID) {

    }

}

@Injectable()
class EdiMemberValidationServiceMock {
    validateGender(gender) {
        return EdiMemberConstants.GENDER_M;
    }

    validateOtherUMOType(otherUMOType) {
        return EdiMemberConstants.OTHER_CARRIER;
    }
}

@Injectable()
class EdiProviderValidationServiceMock {
    validateProviderFirstName(firstName, lastName, entityType) {
        return "Matt";
    }

    validateProviderLastName(lastName) {
        return "Meyer";
    }

    validateProviders(serviceSettingType, providers) {
        return true;
    }

    checkAttendingProvider(providers) {
        return true;
    }

    getProviderRole(entityIdentifier, attendingProviderExists) {
        return 1111;
    }
}

@Injectable()
class EdiFacilityValidationServiceMock {
    async getServiceSettingType(event, hscData) {
        return EdiServiceSettingTypeConstants.SERVICE_SETTING_INPATIENT;
    }

    validateRequestCategory(serviceSettingType, requestCategory) {
        return requestCategory;
    }

    validateCertificateType(certificateType) {
        return certificateType;
    }

    translatePatientStatusCode(patientStatusCode) {
        return PatientStatusCode.PATIENT_STATUS_CODE_1;
    }

}

@Injectable()
class Edi278NMemberMapperServiceMock {
    mapMemberData(event, requestDetails) {

    }

}

@Injectable()
class Edi278NProviderMapperServiceMock {
    mapProviderDomainData(event, requestDetails) {

    }
}

@Injectable()
class Edi278NDiagnosisMapperServiceMock {
    mapHscDiagnosisData(canonicalRequest, hscData, sourceDataObject, request, requestDetails) {
    }
}

@Injectable()
class Edi278NFacilityMapperServiceMock {
    mapFacilityData(event, hscData, sourceDataObject, serviceSettingType, requestDetails) {

    }
}

@Injectable()
class Edi278NEventMapperServiceMock {
    mapEventMBRSHP(event, hscData, sourceDataObject, serviceSettingType, requestDetails) {

    }
}

@Injectable()
class Edi278NServiceMapperServiceMock {
    mapServiceData(canonicalRequest, hscData) {

    }
}


describe('Edi278NMapperService', () => {
    let service: Edi278NMapperService;
    let ediUtilities: EdiUtilities;
    let memberDetails = null;
    let request: HttpRequest;
    const dataTransMapperService = new Edi278NDataTransmissionHeaderMapperServiceMock();
    const memberMapperService = new Edi278NMemberMapperServiceMock();
    const providerMapperService = new Edi278NProviderMapperServiceMock();
    const diagnosisMapperService = new Edi278NDiagnosisMapperServiceMock();
    const facilityMapperService = new Edi278NFacilityMapperServiceMock();
    const serviceMapperService = new Edi278NServiceMapperServiceMock();
    const providerValidation = new EdiProviderValidationServiceMock();
    const facilityValidation = new EdiFacilityValidationServiceMock();

    const provider: ProviderData = {
        "prov_indvs": {
            "fst_nm": "NATHAN",
            "midl_nm": null,
            "lst_nm": "ECK",
            "sufx_nm": null
        },
        "prov_orgs": null,
        "prov_adrs": [
            {
                "adr_ln_1_txt": "1067 Twining Dr",
                "adr_ln_2_txt": null,
                "cty_nm": "Barksdale AFB",
                "st_ref_id": "LA",
                "zip_cd_txt": "71110",
                "zip_sufx_cd_txt": null
            }
        ],
        "providerSeqNum": "2",
        "ediType": "278N",
        "entityType": "1",
        "ndbMpin": null,
        "providerNPI": "1376194050",
        "federalTaxID": null,
        "federalTaxIDSuffix": null,
        "entityIdentifier": "AAJ",
        "sourceData": "<ns5:loopID xmlns:ns5=\"http://authref278.transaction.b2b.uhg.com\">2010EA</ns5:loopID>                    <ns6:providerTaxonomyCode xmlns:ns6=\"http://authref278.transaction.b2b.uhg.com\">207VX0000X</ns6:providerTaxonomyCode>",
        "loopID": "2010EA",
        "facilityProviderSeqNum": "2",
        "providerType": "AD",
        "firstName": "NATHAN",
        "requestCategory": "AR",
        "lastName": "ECK",
        "businessName": null,
        "prov_loc_affil_dtl": null,
    };

    const providerData: Provider = {
       prov: []
    };
    providerData.prov.push(provider);

    const requestDetails: RequestDetails = {
        dataTransmissionHeader: null,
        Membership: {
            mbrshp: {
                scrbr_id_txt: "123",
                sbscr_fst_nm: null,
                sbscr_lst_nm: null,
                sbscr_empmt_dt: null,
                cob_ind: null,
                mbr_rel_ref_id: null,
                sbscr_bth_dt: null,
                mbr_covs: null,
            }
        },
        Individual: {
            indv: {
                fst_nm: "Matt",
                lst_nm: "Meyer",
                bth_dt: "07-18-1993",
                midl_nm: null,
                sufx_nm: null,
                gdr_ref_id: null,
                sourceData: null,
                indv_adrs: null
            }
        },
        Provider: providerData,
        Facility: null,
        Diagnosis: null,
        Event: null,
        procCodes: null,
        Service: null,
        updateHscRequest: null,
        hscSourceData: null,
        ediType: null,
        followUpContact: null,
        Error: null
    };

    const hscData = {
        hsc_id: 1,
        indv_key_typ_ref_id: null,
        indv_key_val: null,
        srvc_set_ref_id: 3737,
        rev_prr_ref_id: 3754,
        flwup_cntc_dtl: null,
        hsr_notes: []
    };
    const sourceDataObject = {};
    let event = null;

    const reqCategory  = {
        "reqCategory": {
            $: {
                reqCategory: "Inpatient",
            },
        }
    }
    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            imports: [HttpModule],
            providers: [Edi278NMapperService, EdiUtilities, AppService, ConfigService, HealthServiceClient, ReferenceClient,
                {provide: IndividualService, useClass: IndividualServiceMock},
                {provide: ProviderService, useClass: ProviderServiceMock},
                {
                    provide: Edi278NDataTransmissionHeaderMapperService,
                    useClass: Edi278NDataTransmissionHeaderMapperServiceMock
                },
                {provide: Edi278NMemberMapperService, useClass: Edi278NMemberMapperServiceMock},
                {provide: Edi278NProviderMapperService, useClass: Edi278NProviderMapperServiceMock},
                {provide: Edi278NDiagnosisMapperService, useClass: Edi278NDiagnosisMapperServiceMock},
                {provide: Edi278NFacilityMapperService, useClass: Edi278NFacilityMapperServiceMock},
                {provide: Edi278NServiceMapperService, useClass: Edi278NServiceMapperServiceMock},
                {provide: Edi278NEventMapperService, useClass: Edi278NEventMapperServiceMock},
                {provide: EdiMemberValidationService, useClass: EdiMemberValidationServiceMock},
                {provide: EdiProviderValidationService, useClass: EdiProviderValidationServiceMock},
                {provide: EdiFacilityValidationService, useClass: EdiFacilityValidationServiceMock}],

        }).compile();

        service = module.get<Edi278NMapperService>(Edi278NMapperService);
        ediUtilities = module.get<EdiUtilities>(EdiUtilities);
        event = ediUtilities.getElementInfo(testCanonicalRequest, canonicalRequestTags.EVENT);
        memberDetails = ediUtilities.getElementInfo(event, canonicalRequestTags.MEMBER);

    });

    it('should be defined', () => {
        expect(service).toBeDefined();
    });

    it('should run #mapCanonicalRequest()', async () => {
        spyOn(dataTransMapperService, 'mapDataTransmissionHeaderData').and.callThrough();
        spyOn(service, 'getServiceSettingType').and.callFake(function () {
            return "Inpatient";
        });
        spyOn(memberMapperService, 'mapMemberData').and.callThrough();
        spyOn(providerMapperService, 'mapProviderDomainData').and.callThrough();
        spyOn(service, 'getHscData').and.callFake(function () {
        });

        service.mapCanonicalRequest(testCanonicalRequest, requestDetails, 1, request, "278N", false );
        expect(service).toBeTruthy();
    });

    it('should run #getHscData()', async () => {
        spyOn(service, 'getIndividualData').and.callFake(function () {
            return
        });
        spyOn(service, 'getHscProviderDetails').and.callFake(function () {});
        spyOn(diagnosisMapperService, 'mapHscDiagnosisData').and.callThrough();
        spyOn(facilityMapperService, 'mapFacilityData').and.callThrough();
        spyOn(serviceMapperService, 'mapServiceData').and.callThrough();
        spyOn(service, 'getFollowUpContactData').and.callFake(function () {
        });
        spyOn(service, 'mapDataToHsrNotes').and.callFake(function () {
        });

        service.getHscData(hscData, event, requestDetails, 1, request, testCanonicalRequest, reqCategory, "278N", false);
        expect(service).toBeTruthy();
    });

    it('should run #getFollowUpContactData()', async () => {
        service.getFollowUpContactData(event, hscData, sourceDataObject, requestDetails);
        expect(service).toBeTruthy();
    });

    it('should run #getIndividualData()', async () => {
        var individualService = new IndividualServiceMock();
        spyOn(individualService, 'getIndividualKeyData').and.callThrough();

        service.getIndividualData(event, hscData, requestDetails, request);
        expect(service).toBeTruthy();
    });

    it('should run #getHscProviderDetails()', async () => {
        spyOn(providerValidation, 'validateProviders').and.callThrough();
        spyOn(providerValidation, 'checkAttendingProvider').and.callThrough();
        spyOn(service, 'getHscProvData').and.callFake(function () {
        });

        service.getHscProviderDetails(event, hscData, requestDetails, request);
        expect(service).toBeTruthy();
    });

    it('should run #getHscProvData()', async () => {
        const providerData = {
            entitiyType: '1',
            prov_indvs: [{fst_nm: "Nathan", lst_nm: "Eck"}]
        };

        var providerService = new ProviderServiceMock();
        spyOn(providerService, 'getHscProviderForPerson').and.callThrough();
        spyOn(providerValidation, 'getProviderRole').and.callThrough();

        service.getHscProvData('123', 111, providerData, 1, hscData, request, true);
        expect(service).toBeTruthy();
    });

    it('should run #mapDataToHsrNotes()', async () => {
        spyOn(service, 'mapEventNotes').and.callFake(function () {
        });
        spyOn(service, 'mapFacilityNotes').and.callFake(function () {
        });
        spyOn(service, 'getAmbulanceData').and.callFake(function () {
        });

        service.mapDataToHsrNotes(testCanonicalRequest, event, hscData);
        expect(service).toBeTruthy();
    });

    it('should run #getAmbulanceData()', async () => {
        service.getAmbulanceData(event, hscData);
        expect(service).toBeTruthy();
    });

    it('should run #addHsrNote()', async () => {
        const note = "test note";
        const title = "test title";
        service.addHsrNote(note, title, hscData);
        expect(service).toBeTruthy();
    });

    it('should run #mapEventNotes()', async () => {
        spyOn(service, 'addHsrNote').and.callFake(function () {
        });

        service.mapEventNotes(testCanonicalRequest, hscData);
        expect(service).toBeTruthy();
    });

    it('should run #mapFacilityNotes()', async () => {
        spyOn(service, 'mapEventNotes').and.callFake(function () {
        });
        spyOn(facilityValidation, 'translatePatientStatusCode').and.callThrough();

        service.mapFacilityNotes(event, hscData);
        expect(service).toBeTruthy();
    });

    /*
       it('should run #getAmbulanceData()', async () => {
           service.getAmbulanceData(event, hscData);
           expect(service).toBeTruthy();
       });

       it('should run #getSpinalManipulationData()', async () => {
           service.getSpinalManipulationData(event, hscData);
           expect(service).toBeTruthy();
       });

       it('should run #getHomeHealthCareData()', async () => {
           service.getHomeHealthCareData(event, hscData);
           expect(service).toBeTruthy();
       });
*/

})
;
