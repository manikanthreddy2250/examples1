import {Injectable} from "@nestjs/common";
import {EdiUtilities} from "../../../../edi-utilities";
import {EdiResponseService} from "../../../edi-response.service";
import {IndividualService} from "../../../individual/individual.service";
import {
    ambulanceInfoAttributes,
    canonicalRequestTags,
    DataTransHeader,
    dataTransmissionHeaderAttributes,
    Diagnosis,
    diagnosisAttributes,
    Event,
    FacBedDay,
    Facility,
    facilityAttributes,
    FacilityNotes,
    followUpContactAttributes,
    homeHealthCareAttributes,
    homeOxygenAttributes,
    hscAttributes,
    HscData,
    Indiv,
    Indv,
    IndvAddress,
    Member,
    memberAttributes,
    Membership,
    Note,
    Provider,
    ProviderAddress,
    providerAttributes,
    ProviderIndv,
    ProviderOrg,
    ProviderRole,
    RequestDetails,
    Service,
    serviceAttributes,
    ServiceNonFacility,
    ServiceNotes,
    spinalManipulationInformationAttributes,
    ServiceNonFacilityDME,
    MemberCoverage,
    EdiConstants,
    ProviderData,
    FollowUpContact,
    FollowUpContactData,
    PrimaryContact,
    HscProviderDetails,
    facilityNotes,
    eventNotes, EdiLineSeperator, homeOxygenNotes, ambulanceNotes, MemberCovDtl, HscKey, diagnosisNotes
} from "../../../../constants/edi.constants";
import {GenericMapperService} from "../generic-mapper-service";
import {
    Edi278NConstants,
    Edi278NMemberConstants
} from "../../../../constants/edi-278N.constants";
import {HealthServiceService} from "../../../healthService/healthService.service";
import {EdiDiagnosisValidationService} from "../../../validation/edi-diagnosis-validation.service";
import {ProviderService} from "../../../provider/provider.service";
import {Edi278NDiagnosisValidationService} from "../../../validation/278N-validation/edi-278N-diagnosis-validation.service";
import {Edi278NDataTransmissionHeaderValidationService} from "../../../validation/278N-validation/edi-278N-dataTransmissionHeader-validation.service";
import {EdiMemberValidationService} from "../../../validation/edi-member-validation.service";
import {EdiProviderValidationService} from "../../../validation/edi-provider-validation.service";
import {EdiFacilityValidationService} from "../../../validation/edi-facility-validation.service";
import {Edi278NDataTransmissionHeaderMapperService} from "./edi-278N-dataTransmissionHeader-mapper.service";
import {Edi278NMemberMapperService} from "./edi-278N-member-mapper.service";
import {EdiProviderMapperService} from "../edi-provider-mapper.service";
import {Edi278NProviderMapperService} from "./edi-278N-provider-mapper.service";
import {EdiDiagnosisMapperService} from "../edi-diagnosis-mapper.service";
import {Edi278NDiagnosisMapperService} from "./edi-278N-diagnosis-mapper.service";
import {EdiFacilityMapperService} from "../edi-facility-mapper.service";
import {Edi278NFacilityMapperService} from "./edi-278N-facility-mapper.service";
import {EdiServiceMapperService} from "../edi-service-mapper.service";
import {Edi278NServiceMapperService} from "./edi-278N-service-mapper.service";
import {Edi278NEventMapperService} from "./edi-278N-event-mapper.service";

import {AppService} from "../../../../../app.service";
import * as fs from "fs";
import {request} from "http";


@Injectable()
export class Edi278NMapperService extends GenericMapperService {

    constructor(ediUtils: EdiUtilities,
                protected readonly edi278NDataTransmissionHeaderMapperService: Edi278NDataTransmissionHeaderMapperService,
                protected readonly edi278NMemberMapperService: Edi278NMemberMapperService,
                protected readonly edi278NProviderMapperService: Edi278NProviderMapperService,
                protected readonly edi278NDiagnosisMapperService: Edi278NDiagnosisMapperService,
                protected readonly edi278NFacilityMapperService: Edi278NFacilityMapperService,
                protected readonly edi278NServiceMapperService: Edi278NServiceMapperService,
                protected readonly edi278NEventMapperService: Edi278NEventMapperService,
                appService: AppService,
                individualService: IndividualService,
                providerService: ProviderService,
                ediProviderValidationService: EdiProviderValidationService,
                ediFacilityValidationService: EdiFacilityValidationService) {

        super(ediUtils, edi278NDataTransmissionHeaderMapperService, edi278NMemberMapperService, edi278NProviderMapperService, edi278NDiagnosisMapperService, edi278NFacilityMapperService, edi278NServiceMapperService,
            appService, individualService, providerService, ediProviderValidationService, ediFacilityValidationService);
    }


    async mapCanonicalRequest(canonicalRequest, requestDetails, hscID, request, ediType, translateToJson) {

        try {
            await this.edi278NDataTransmissionHeaderMapperService.mapDataTransmissionHeaderData(canonicalRequest, requestDetails, hscID);
            //   await this.edi278NFacilityMapperService.ediLookupData();

            var event = await this.ediUtils.getElementInfo(canonicalRequest, canonicalRequestTags.EVENT);
            if (event) {

                const hscData: HscData = {
                    creat_user_id: null,
                    chg_user_id: null,
                    hsc_id: hscID,
                    indv_key_typ_ref_id: null,
                    indv_key_val: null,
                    mbr_cov: null,
                    srvc_set_ref_id: null,
                    hsc: null,
                    //hsc_rev_typ_ref_id: null,
                    //hsc_sts_ref_id: null,
                    //hsc_sts_rsn_ref_id: null,
                    //auth_typ_ref_id: null,
                    //creat_sys_ref_id: null,
                    //chg_sys_ref_id: null,
                    //rev_prr_ref_id: 3754,  //riskLevelType //Routine
                    hsr_notes: new Array(),
                    hsc_diags: new Array(),
                    flwup_cntc_dtl: null,
                    hsc_provs: new Array(),
                    hsc_facl: null,
                    hsc_srvcs: new Array(),
                    //hsc_keys: null
                    hsc_keys: new Array(),
                    hsc_clin_guid: null
                };



                //Get Service Setting Type
                this.serviceSettingType = this.getServiceSettingType(event, hscData);
                await this.edi278NMemberMapperService.mapMemberData(event, requestDetails, hscData);
                const facilityProviderSeqNum = this.ediUtils.getAttributeValue(canonicalRequest, facilityAttributes.FACILITYPROVIDERSEQNUM);
                await this.edi278NProviderMapperService.mapProviderDomainData(event, requestDetails, facilityProviderSeqNum, ediType);
                await this.getHscData(hscData, event, requestDetails, hscID, request, canonicalRequest, this.serviceSettingType, ediType, translateToJson);
            }
        } catch (err) {
            console.log(`Error while transforming canonical request to JSON Objects: ${err}`);
        }
        return requestDetails;
    }

    async getHscData(hscData, event, requestDetails, hscID, request, canonicalRequest, reqCategory, ediType, translateToJson) {
        const sourceDataObject = {};
        //var translateToJsonval = translateToJson;
        try {

            //This is the part when the script is calling member and provider domain
            if (translateToJson == false) {
                await this.getIndividualData(event, hscData, requestDetails, request);
                await this.getHscProviderDetails(event, hscData, requestDetails, request);
            }

            await this.edi278NDiagnosisMapperService.mapHscDiagnosisData(canonicalRequest, hscData, sourceDataObject, request, requestDetails);
            this.edi278NFacilityMapperService.mapFacilityData(event, hscData, sourceDataObject, this.serviceSettingType, requestDetails);
            await this.edi278NServiceMapperService.mapServiceData(event, hscData, sourceDataObject, this.serviceSettingType, requestDetails, request, ediType);
            this.getFollowUpContactData(event, hscData, sourceDataObject, requestDetails);
            this.mapDataToHsrNotes(canonicalRequest, event, hscData);
            this.edi278NEventMapperService.mapHscClinGuidData(canonicalRequest, hscData);
            this.edi278NEventMapperService.mapEventData(canonicalRequest, requestDetails);

            /*    await this.getHscHomeOxygenData(event, hscData);
                  await this.getAmbulanceData(event, hscData);
                  await this.getSpinalManipulationData(event, hscData);
                  await this.getHomeHealthCareData(event, hscData);*/

            if (hscData) {
                requestDetails.updateHscRequest = hscData;
            }
            if (sourceDataObject) {
                requestDetails.hscSourceData = sourceDataObject;
            }
        } catch (err) {
            console.log(`Error in getHscData:  ${err}`);
        }
    }

    getFollowUpContactData(event, hscData, sourceDataObject, requestDetails) {

        try {
            const followUpContactDetails = this.ediUtils.getElementInfo(event, canonicalRequestTags.FOLLOWUPCONTACT);

            if (followUpContactDetails) {
                const contactName = this.ediUtils.getAttributeValue(followUpContactDetails, followUpContactAttributes.CONTACTNAME);
                const primaryPhone = this.ediUtils.getAttributeValue(followUpContactDetails, followUpContactAttributes.PRIMARYPHONE);
                const medicalRecordNumber = this.ediUtils.getAttributeValue(followUpContactDetails, followUpContactAttributes.MEDICALRECORDNUMBER);
                const contactProviderSeqNum = this.ediUtils.getAttributeValue(followUpContactDetails, followUpContactAttributes.CONTACTPROVIDERSEQNUM);
                const primaryPhoneExt = this.ediUtils.getAttributeValue(followUpContactDetails, followUpContactAttributes.PRIMARYPHONEEXT);
                const secondaryPhone = this.ediUtils.getAttributeValue(followUpContactDetails, followUpContactAttributes.SECONDARYPHONE);
                const fax = this.ediUtils.getAttributeValue(followUpContactDetails, followUpContactAttributes.FAX);
                const emailAddress = this.ediUtils.getAttributeValue(followUpContactDetails, followUpContactAttributes.EMAILADDRESS);
                let sourceData = this.ediUtils.getRequestInfo(followUpContactDetails, canonicalRequestTags.SOURCEDATA);
                sourceData = this.ediUtils.removeLineBreaks(sourceData);
                if (sourceData) {
                    sourceDataObject[canonicalRequestTags.FOLLOWUPCONTACT] = sourceData;
                }

                const hscKey: HscKey = {
                    creat_user_id: null,
                    chg_user_id: null,
                    hsc_key_val: "502",
                    hsc_key_typ_ref_id: null,
                    inac_ind: null
                };
                const otherUMOName  = this.ediUtils.getAttributeValue(event, hscAttributes.OTHERUMONAME);
                //hscData.hsc_keys = hscKey;

                const followUpContact: FollowUpContact = {
                    department: null,
                    email: emailAddress,
                    phone: primaryPhone,
                    //phoneExt: primaryPhoneExt,
                    fax: fax,
                    role: null,
                    name: contactName,
                    primaryContact: true
                };

                hscData.flwup_cntc_dtl = followUpContact;


                const followUpContactData: FollowUpContactData = {
                    prov_role_ref_id: contactProviderSeqNum,
                    sourceData: sourceData,
                };
                requestDetails.followUpContact = followUpContactData;

            }
        } catch (err) {
            //console.log(`Error in getFollowUpContactData:  ${err}`);
        }
    }
    //Member Matching
    async getIndividualData(event, hscData, requestDetails, request) {
        try {
            if (requestDetails.Individual.indv && requestDetails.Membership.mbrshp) {
                const firstName = requestDetails.Individual.indv.fst_nm;
                const lastName = requestDetails.Individual.indv.lst_nm;
                const tempDate = requestDetails.Individual.indv.bth_dt;
                const birthDate: Date = new Date(tempDate);
                const memberID = requestDetails.Membership.mbrshp.scrbr_id_txt;
                const individualKeyVariables = {
                    fst_nm: firstName,
                    lst_nm: lastName,
                    bth_dt: birthDate,
                    indv_key_val: memberID
                };

                const individualKeyData = await
                    this.individualService.getIndividualKeyData(individualKeyVariables, request);

                if (individualKeyData) {
                    hscData.indv_key_typ_ref_id = individualKeyData.indv_key[0].indv_key_typ_ref_id;
                    hscData.indv_key_val = individualKeyData.indv_key[0].indv_key_val;
                }
            }
        } catch (err) {
        }
    }

    async getHscProviderDetails(event, hscData, requestDetails, request) {
        let i: number;
        try {
            if (requestDetails.Provider.prov) {
                const providerData = requestDetails.Provider.prov;
                //validate providers based on requirement for IP case
                const isProvidersValidated = this.ediProviderValidationService.validateProviders(this.serviceSettingType, providerData);

                //checking of attending provider exists
                const attendingProviderExists = this.ediProviderValidationService.checkAttendingProvider(providerData);

                if (isProvidersValidated) {
                    for (i = 0; i < providerData.length; i++) {
                        let prov_key_val;
                        let prov_key_typ_ref_id;

                        if (providerData[i].ndbMpin) {
                            prov_key_val = providerData[i].ndbMpin;
                            prov_key_typ_ref_id = 2783;
                        } else if (providerData[i].providerNPI) {
                            prov_key_val = providerData[i].providerNPI;
                            prov_key_typ_ref_id = 2782;
                        } else if (providerData[i].federalTaxID) {
                            prov_key_val = providerData[i].federalTaxID;
                            prov_key_typ_ref_id = 2784;
                        }

                        await this.getHscProvData(prov_key_val, prov_key_typ_ref_id, providerData[i], i, hscData, request, attendingProviderExists);
                    }
                }
            }
        } catch (err) {
        }
    }

    async getHscProvData(prov_key_val, prov_key_typ_ref_id, providerData, index, hscData, request, attendingProviderExists) {
        let hscProviderDetailsResult: any;
        try {
            const hscProvObject: HscProviderDetails = {
                creat_user_id: null,
                chg_user_id: null,
                id: index + 1,
                //     sufx_nm: null,
                fst_nm: null,
                midl_nm: null,
                lst_nm: null,
                bus_nm: null,
                prov_keys: null,
                hsc_prov_roles: new Array(),
                prov_adr: {},
                prov_loc_affil_dtl: null
            };

            const provlocaffildtl: any = {
                providerTaxonomyCode: providerData.prov_loc_affil_dtl.providerTaxonomyCode,
                countryCode: providerData.prov_loc_affil_dtl.countryCode,
                contactName: providerData.prov_loc_affil_dtl.contactName,
                primaryPhone: providerData.prov_loc_affil_dtl.primary_Phone,
                primaryPhoneExt: providerData.prov_loc_affil_dtl.primaryPhoneExt,
                secondaryPhone: providerData.prov_loc_affil_dtl.secondary_Phone,
                secondaryPhoneExt: providerData.prov_loc_affil_dtl.secondaryPhoneExt,
                fax: providerData.prov_loc_affil_dtl.faxNum,
                faxExt:  providerData.prov_loc_affil_dtl.faxExt,
                emailAddress:  providerData.prov_loc_affil_dtl.emailAddress,
            };

            //var indxx = 0;
            if (providerData.entityType === "1") {
                //      hscProvObject.sufx_nm = providerData.prov_indvs[0].sufx_nm;
                hscProvObject.fst_nm = providerData.prov_indvs.fst_nm; //!= null ? providerData.prov_indvs.fst_nm : null;
                hscProvObject.midl_nm = providerData.prov_indvs.midl_nm;//!= null ? providerData.prov_indvs.mdl_nm : null;
                hscProvObject.lst_nm = providerData.prov_indvs.lst_nm; // != null ? providerData.prov_indvs.lst_nm : null;

                const personProviderVariables: any = {
                    prov_key_typ_ref_id: prov_key_typ_ref_id,
                    prov_key_val: prov_key_val,
                    fst_nm: providerData.prov_indvs.fst_nm.substring(0, 3) + '%',
                    lst_nm: providerData.prov_indvs.lst_nm.substring(0, 3) + '%'
                };
                hscProviderDetailsResult = await this.providerService.getHscProviderForPerson(personProviderVariables, request);


            } else {
                hscProvObject.bus_nm = providerData.prov_orgs.bus_nm; //!= null ? providerData.prov_orgs.bus_nm : null;
                hscProvObject.prov_loc_affil_dtl = providerData.ndbMpin;
                const nonPersonProviderVariables: any = {
                    prov_key_typ_ref_id: prov_key_typ_ref_id,
                    prov_key_val: prov_key_val,
                    bus_nm: providerData.prov_orgs.bus_nm.substring(0, 3) + '%'
                };
                hscProviderDetailsResult = await this.providerService.getHscProviderForNonPerson(nonPersonProviderVariables, request);
            }

            hscProvObject.prov_loc_affil_dtl = provlocaffildtl;

            if (hscProviderDetailsResult) {
                hscProvObject.prov_keys = hscProviderDetailsResult.prov[0].prov_keys;
                hscProvObject.prov_adr = hscProviderDetailsResult.prov[0].prov_adrs[0];

                //get provider role ref id
                const provRoleID = this.ediProviderValidationService.getProviderRole(providerData.entityIdentifier, attendingProviderExists);
                const provRole: ProviderRole = {
                    prov_role_ref_id: provRoleID
                };
                hscProvObject.hsc_prov_roles.push(provRole);
            }

            hscData.hsc_provs.push(hscProvObject);

        } catch (err) {
        }

    }

    mapDataToHsrNotes(canonicalRequest, event, hscData) {

        try {
            this.mapEventNotes(canonicalRequest, hscData);
            this.mapFacilityNotes(event, hscData);
            this.mapDiagnosisNotes(event, hscData);
            //   this.getHscHomeOxygenData(event, hscData);
            this.getAmbulanceData(event, hscData);
            /*            await this.getSpinalManipulationData(event, hscData);
                        await this.getHomeHealthCareData(event, hscData);*/
            this.mapServiceNotes(event, hscData);
        } catch (err) {

        }
    }

    mapEventNotes(canonicalRequest, hscData) {
        const eventTagInfo = this.ediUtils.getElementAttributeInfo(canonicalRequest, canonicalRequestTags.EVENT);
        let eventNoteString = "";

        try {
            const accidentDate = this.ediUtils.getAttributeValue(eventTagInfo, hscAttributes.ACCIDENTDATE);
            if (accidentDate) {
                eventNoteString += eventNotes.ACCIDENTDATE + ": " + accidentDate + EdiLineSeperator.LINE_BREAK;
            }

            const lastMenstrualPeriodDate = this.ediUtils.getAttributeValue(eventTagInfo, hscAttributes.LASTMENSTRUALPERIODDATE);
            if (lastMenstrualPeriodDate) {
                eventNoteString += eventNotes.LMP + ": " + lastMenstrualPeriodDate + EdiLineSeperator.LINE_BREAK;
            }

            const estimatedDateOfBirth = this.ediUtils.getAttributeValue(eventTagInfo, hscAttributes.ESTIMATEDDATEOFBIRTH);
            if (estimatedDateOfBirth) {
                eventNoteString += eventNotes.EDC + ": " + estimatedDateOfBirth + EdiLineSeperator.LINE_BREAK;
            }

            const onsetOfIllnessDate = this.ediUtils.getAttributeValue(eventTagInfo, hscAttributes.ONSETOFILLNESSDATE);
            if (onsetOfIllnessDate) {
                eventNoteString += eventNotes.ONSETOFILLNESSDATE + ": " + onsetOfIllnessDate + EdiLineSeperator.LINE_BREAK;
            }

            const otherUMOName = this.ediUtils.getAttributeValue(eventTagInfo, hscAttributes.OTHERUMONAME);
            if (otherUMOName) {
                eventNoteString += eventNotes.OTHERUMONAME + ": " + otherUMOName + EdiLineSeperator.LINE_BREAK;
            }

            const otherUMODenialDate = this.ediUtils.getAttributeValue(eventTagInfo, hscAttributes.OTHERUMODENIALDATE);
            if (otherUMODenialDate) {
                eventNoteString += eventNotes.OTHERUMODENIALDATE + ": " + otherUMODenialDate + EdiLineSeperator.LINE_BREAK;
            }

            if (eventNoteString.length > 0) {
                this.addHsrNote(eventNoteString, canonicalRequestTags.EVENT, hscData);
            }
        } catch (err) {
            console.log(`Error in getEventHsrNotes:  ${err}`);
        }
    }

    async mapFacilityNotes(event, hscData) {
        let facilityNoteString = "";
        const facilityDetails = this.ediUtils.getElementInfo(event, canonicalRequestTags.FACILITY);

        try {
            //  const patientStatusCode = this.ediFacilityValidationService.translatePatientStatusCode(this.ediUtils.getAttributeValue(facilityDetails, facilityAttributes.PATIENTSTATUSCODE));
            const patientStatusCodeDescription = await this.ediUtils.ediLookupData(facilityAttributes.PATIENTSTATUSCODE, this.ediUtils.getAttributeValue(facilityDetails, facilityAttributes.PATIENTSTATUSCODE));
            if (patientStatusCodeDescription) {
                facilityNoteString += facilityNotes.PATIENTSTATUS + ": " + patientStatusCodeDescription + EdiLineSeperator.LINE_BREAK;
            }

            if (facilityNoteString.length > 0) {
                this.addHsrNote(facilityNoteString, canonicalRequestTags.FACILITY, hscData);
            }

        } catch (err) {
            console.log(`Error in mapFacilityNotes:  ${err}`);
        }
    }

    mapDiagnosisNotes(event, hscData) {
        let diagnosisNoteString = "";
        const diagnosisDetails = this.ediUtils.getRequestInfo(event, canonicalRequestTags.DIAGNOSES);

        try {
            if (diagnosisDetails) {
                const diagArray = diagnosisDetails.split("<" + canonicalRequestTags.DIAGNOSIS);
                diagArray.shift();

                for (const diagnosis of diagArray) {
                    const diagnosisDate = this.ediUtils.getAttributeValue(diagnosis, diagnosisAttributes.DIAGNOSISDATE);
                    const diagnosisCode = this.ediUtils.getAttributeValue(diagnosis, diagnosisAttributes.DIAGNOSISCODE);

                    if (diagnosisDate) {
                        diagnosisNoteString += diagnosisCode + " - " + diagnosisNotes.DIAGNOSISDATE + ": " + diagnosisDate + EdiLineSeperator.LINE_BREAK;
                    }

                }
            }
            if (diagnosisNoteString.length > 0) {
                this.addHsrNote(diagnosisNoteString, canonicalRequestTags.DIAGNOSIS, hscData);
            }

        } catch (err) {
            console.log(`Error in mapDiagnosisNotes:  ${err}`);
        }
    }

    async mapServiceNotes(event, hscData) {
        let serviceNoteString = "";
        const serviceDetails = this.ediUtils.getRequestInfo(event, canonicalRequestTags.SERVICE);

        try {
            /*       const actionCode = this.ediUtils.getAttributeValue(serviceDetails, serviceAttributes.ACTIONCODE);
                   if (actionCode) {
                       serviceNoteString += serviceAttributes.ACTIONCODE + ": " + actionCode + EdiLineSeperator.LINE_BREAK;
                   } */

            const nursingHomeLevelOfCareDescription = await this.ediUtils.ediLookupData(serviceAttributes.NURSINGHOMELEVELOFCARE, this.ediUtils.getAttributeValue(serviceDetails, serviceAttributes.NURSINGHOMELEVELOFCARE));
            if (nursingHomeLevelOfCareDescription) {
                serviceNoteString += serviceAttributes.NURSINGHOMELEVELOFCARE + ": " + nursingHomeLevelOfCareDescription + EdiLineSeperator.LINE_BREAK;
            }

            const nursingHomeStatusCodeDescription = await this.ediUtils.ediLookupData(serviceAttributes.NURSINGHOMESTATUSCODE, this.ediUtils.getAttributeValue(serviceDetails, serviceAttributes.NURSINGHOMESTATUSCODE));
            if (nursingHomeStatusCodeDescription) {
                serviceNoteString += serviceAttributes.NURSINGHOMESTATUSCODE + ": " + nursingHomeStatusCodeDescription + EdiLineSeperator.LINE_BREAK;
            }

            if (serviceNoteString.length > 0) {
                this.addHsrNote(serviceNoteString, canonicalRequestTags.SERVICES, hscData);
            }

        } catch (err) {
            console.log(`Error in mapFacilityNotes:  ${err}`);
        }
    }

    /*    getHscHomeOxygenData(event, hscData) {
            let homeOxygenNoteString = "";
            const homeOxygenDetails = this.ediUtils.getElementAttributeInfo(event, canonicalRequestTags.HOMEOXYGEN);

            try {
                if (homeOxygenDetails) {
                    const oxygenEquipmentCode1 = this.ediUtils.getAttributeValue(homeOxygenDetails, homeOxygenAttributes.OXYGENEQUIPMENTCODE1);
                    if (oxygenEquipmentCode1) {
                        homeOxygenNoteString += homeOxygenNotes.O2_EQUIPMENT_1 + ": " + oxygenEquipmentCode1 + EdiLineSeperator.LINE_BREAK;
                    }

                    const oxygenEquipmentCode2 = this.ediUtils.getAttributeValue(homeOxygenDetails, homeOxygenAttributes.OXYGENEQUIPMENTCODE2);
                    if (oxygenEquipmentCode2) {
                        homeOxygenNoteString += homeOxygenNotes.O2_EQUIPMENT_2 + ": " + oxygenEquipmentCode2 + EdiLineSeperator.LINE_BREAK;
                    }

                    const oxygenEquipmentCode3 = this.ediUtils.getAttributeValue(homeOxygenDetails, homeOxygenAttributes.OXYGENEQUIPMENTCODE3);
                    if (oxygenEquipmentCode3) {
                        homeOxygenNoteString += homeOxygenNotes.O2_EQUIPMENT_3 + ": " + oxygenEquipmentCode3 + EdiLineSeperator.LINE_BREAK;
                    }

                    const oxygenFlowRate = this.ediUtils.getAttributeValue(homeOxygenDetails, homeOxygenAttributes.OXYGENFLOWRATE);
                    if (oxygenFlowRate) {
                        homeOxygenNoteString += homeOxygenNotes.FLOW_RATE + ": " + oxygenFlowRate + EdiLineSeperator.LINE_BREAK;
                    }

                    const dailyOxygenUse = this.ediUtils.getAttributeValue(homeOxygenDetails, homeOxygenAttributes.DAILYOXYGENUSE);
                    if (dailyOxygenUse) {
                        homeOxygenNoteString += homeOxygenNotes.DAILY_USE + ": " + dailyOxygenUse + EdiLineSeperator.LINE_BREAK;
                    }

                    const oxygenUsePerHour = this.ediUtils.getAttributeValue(homeOxygenDetails, homeOxygenAttributes.OXYGENUSEPERHOUR);
                    if (oxygenUsePerHour) {
                        homeOxygenNoteString += homeOxygenNotes.USE_PER_HOUR + ": " + oxygenUsePerHour + EdiLineSeperator.LINE_BREAK;
                    }

                    const respiratoryTherapistOrder = this.ediUtils.getAttributeValue(homeOxygenDetails, homeOxygenAttributes.RESPIRATORYTHERAPISTORDER);
                    if (respiratoryTherapistOrder) {
                        homeOxygenNoteString += homeOxygenNotes.RT_ORDER + ": " + respiratoryTherapistOrder + EdiLineSeperator.LINE_BREAK;
                    }

                    const portableOxygenSystemFlowRate = this.ediUtils.getAttributeValue(homeOxygenDetails, homeOxygenAttributes.PORTABLEOXYGENSYSTEMFLOWRATE);
                    if (portableOxygenSystemFlowRate) {
                        homeOxygenNoteString += homeOxygenNotes.PORTABLE_O2_RATE + ": " + portableOxygenSystemFlowRate + EdiLineSeperator.LINE_BREAK;
                    }

                    const oxygenDeliverySystem = this.ediUtils.getAttributeValue(homeOxygenDetails, homeOxygenAttributes.OXYGENDELIVERYSYSTEM);
                    if (oxygenDeliverySystem) {
                        homeOxygenNoteString += homeOxygenNotes.DELIVERY_SYSTEM + ": " + oxygenDeliverySystem + EdiLineSeperator.LINE_BREAK;
                    }

                    if (homeOxygenNoteString.length > 0) {
                        this.addHsrNote(homeOxygenNoteString, canonicalRequestTags.HOMEOXYGEN, hscData);
                    }
                }
            } catch (err) {
                console.log(`Error in getHomeOxygenData:  ${err}`);
            }
        }*/

    getAmbulanceData(event, hscData) {
        let ambulanceNoteString = "";
        const ambulanceDetails = this.ediUtils.getElementAttributeInfo(event, canonicalRequestTags.AMBULANCE);

        try {

            if (ambulanceDetails) {
                const transportCode = this.ediUtils.getAttributeValue(ambulanceDetails, ambulanceInfoAttributes.TRANSPORTCODE);
                if (transportCode) {
                    ambulanceNoteString += ambulanceNotes.TRANSPORT_CODE + ": " + transportCode + EdiLineSeperator.LINE_BREAK;
                }
                /*                const distanceUnits = this.ediUtils.getAttributeValue(ambulanceDetails, ambulanceInfoAttributes.DISTANCEUNITS);
                                const distance = this.ediUtils.getAttributeValue(ambulanceDetails, ambulanceInfoAttributes.DISTANCE);
                                if (distanceUnits || distance) {
                                    ambulanceNoteString += ambulanceNotes.DISTANCE + ": " + distanceUnits +" "+ distance + EdiLineSeperator.LINE_BREAK;
                                }*/
                if (ambulanceNoteString.length > 0) {
                    this.addHsrNote(ambulanceNoteString, canonicalRequestTags.AMBULANCE, hscData);
                }
            }
        } catch (err) {
            //console.log(`Error in getAmbulanceData:  ${err}`);
        }
    }

    addHSC(hscData){
        /*hsc_rev_typ_ref_id: any;
        hsc_sts_ref_id: any;
        hsc_sts_rsn_ref_id: any;
        auth_typ_ref_id: any;
        creat_sys_ref_id: any;
        chg_sys_ref_id: any;
        rev_prr_ref_id: any;*/
    }

    async addHsrNote(note, title, hscData) {
        var hsrNote: Note = {
            note_titl_txt: title,
            note_txt_lobj: note,
            src_user_nm: "clinician",
            note_typ_ref_id: 12,
            note_catgy_ref_id: 80,
        };

        try {
            if (note) {
                //hsrNote.note_txt_lobj = note;
                hscData.hsr_notes.push(hsrNote);
            }

        } catch (err) {
            console.log(`Error in addHsrNote:  ${err}`);
        }
    }

    /*

          getSpinalManipulationData(event, hscData) {
              var hsrNote: Note = {
                  note_titl_txt: canonicalRequestTags.SPINALMANIPULATION,
                  note_txt_lobj: {},
                  src_user_nm: "clinician",
                  note_typ_ref_id: 12,
                  note_catgy_ref_id: null
              };

              try {
                  var spinalManipulationDetails = this.ediUtils.getElementAttributeInfo(event, canonicalRequestTags.SPINALMANIPULATION);

                  if (spinalManipulationDetails) {
                      var treatmentSeries = this.ediUtils.getAttributeValue(spinalManipulationDetails, spinalManipulationInformationAttributes.TREATMENTSERIES);
                      if (treatmentSeries) {
                          hsrNote.note_txt_lobj["Treatment Series (Count)"] = treatmentSeries;
                      }

                      var treatmentCount = this.ediUtils.getAttributeValue(spinalManipulationDetails, spinalManipulationInformationAttributes.TREATMENTCOUNT);
                      if (treatmentCount) {
                          hsrNote.note_txt_lobj["Treatment Count (Quantity)"] = treatmentCount;
                      }

                      var subluxationLevel1 = this.ediUtils.getAttributeValue(spinalManipulationDetails, spinalManipulationInformationAttributes.SUBLUXATIONLEVEL1);
                      if (subluxationLevel1) {
                          hsrNote.note_txt_lobj["Subluxation Level 1"] = subluxationLevel1;
                      }

                      var subluxationLevel2 = this.ediUtils.getAttributeValue(spinalManipulationDetails, spinalManipulationInformationAttributes.SUBLUXATIONLEVEL2);
                      if (subluxationLevel2) {
                          hsrNote.note_txt_lobj["Subluxation Level 2"] = subluxationLevel2;
                      }

                      hscData.hsr_notes.push(hsrNote);
                  }
              } catch (err) {
                  //console.log(`Error in getSpinalManipulationData:  ${err}`);
              }
          }

          getHomeHealthCareData(event, hscData) {
              var hsrNote: Note = {
                  note_titl_txt: canonicalRequestTags.HOMEHEALTHCARE,
                  note_txt_lobj: {},
                  src_user_nm: "clinician",
                  note_typ_ref_id: 12,
                  note_catgy_ref_id: null
              };

              try {
                  var homeHealthCareDetails = this.ediUtils.getElementAttributeInfo(event, canonicalRequestTags.HOMEHEALTHCARE);

                  if (homeHealthCareDetails) {
                      var prognosisCode = this.ediUtils.getAttributeValue(homeHealthCareDetails, homeHealthCareAttributes.PROGNOSISCODE);
                      if (prognosisCode) {
                          hsrNote.note_txt_lobj["Prognosis"] = prognosisCode;
                      }

                      var homeHealthStartDate = this.ediUtils.getAttributeValue(homeHealthCareDetails, homeHealthCareAttributes.HOMEHEALTHSTARTDATE);
                      if (homeHealthStartDate) {
                          hsrNote.note_txt_lobj["HHC Start"] = homeHealthStartDate;
                      }

                      var certificationPeriodStart = this.ediUtils.getAttributeValue(homeHealthCareDetails, homeHealthCareAttributes.CERTIFICATIONPERIODSTART);
                      if (certificationPeriodStart) {
                          hsrNote.note_txt_lobj["Certification Period Start"] = certificationPeriodStart;
                      }

                      var certificationPeriodEnd = this.ediUtils.getAttributeValue(homeHealthCareDetails, homeHealthCareAttributes.CERTIFICATIONPERIODEND);
                      if (certificationPeriodEnd) {
                          hsrNote.note_txt_lobj["Certification Period End"] = certificationPeriodEnd;
                      }

                      var certificationType = this.ediUtils.getAttributeValue(homeHealthCareDetails, homeHealthCareAttributes.CERTIFICATIONTYPE);
                      if (certificationType) {
                          hsrNote.note_txt_lobj["Certification Type"] = certificationType;
                      }

                      hscData.hsr_notes.push(hsrNote);
                  }
              } catch (err) {
                  //console.log(`Error in getHomeHealthCareData:  ${err}`);
              }
          }
*/


}