import {Edi278NFacilityMapperService} from "./edi-278N-facility-mapper.service";
import {HealthServiceService} from "../../../healthService/healthService.service";
import {testCanonicalRequest} from "../../../../../../test/ediTestData";
import {ConfigService} from "@nestjs/config";
import {Test, TestingModule} from "@nestjs/testing";
import {HealthServiceClient} from "../../../../../shared/graphql/healthservicedomain/healthServiceClient";
import {HttpRequest} from "@azure/functions";
import {EdiUtilities} from "../../../../edi-utilities";
import {Edi278NMemberMapperService} from "./edi-278N-member-mapper.service";
import {EdiMemberValidationService} from "../../../validation/edi-member-validation.service";
import {canonicalRequestTags, RequestDetails} from "../../../../constants/edi.constants";
import {EdiFacilityValidationService} from "../../../validation/edi-facility-validation.service";
import {HttpModule, HttpService, Injectable} from "@nestjs/common";
import {AppService} from "../../../../../app.service";
import {ReferenceClient} from "../../../../../shared/graphql/referenceDomain/referenceClient";

@Injectable()
class EdiMemberValidationServiceMock {
    validateGender(gender){
        return "M";
    }

    validateOtherUMOType(otherUMOType){
        return "00";
    }

}

@Injectable()
class AppServiceMock {
    getRefMatchCode(baseRefName, refCode) {
        return "123";
    }
}

describe('Edi278NMemberMapperService', () => {
    let service: Edi278NMemberMapperService;
    let ediUtilities: EdiUtilities;
    let memberDetails;
    let event;

    const requestDetails: RequestDetails = {
        dataTransmissionHeader: null,
        Membership: null,
        Individual: null,
        Provider: null,
        Facility: null,
        Diagnosis: null,
        Event: null,
        Service: null,
        procCodes: null,
        updateHscRequest: null,
        hscSourceData: null,
        ediType: null,
        followUpContact: null,
        Error: null
    };

    const hscData = {
        hsc_id: 1,
        indv_key_typ_ref_id: null,
        indv_key_val: null,
        srvc_set_ref_id: 3737,
        rev_prr_ref_id: 3754,
        flwup_cntc_dtl: null,
        hsc_srvcs: new Array(),
        hsr_notes: null
    };

    const indvDetails = {
        "Individual": {
            "indv": {
                "fst_nm": "Matt",
                "lst_nm": "Meyer",
                "midl_nm": null,
                "sufx_nm": null,
                "bth_dt": "1978-07-26",
                "gdr_ref_id": "M",
                "sourceData": "<ns8:loopID xmlns:ns8=\"http://authref278.transaction.b2b.uhg.com\">2010D</ns8:loopID>",
                "indv_adrs": [],
                "loopID": "2010D"
            }
        }
    }

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            imports: [HttpModule],
            providers: [Edi278NMemberMapperService, AppService, EdiUtilities,
                {provide: AppService, useClass: AppServiceMock},
                {provide: EdiMemberValidationService, useClass: EdiMemberValidationServiceMock},
                ConfigService, HealthServiceClient, HealthServiceService, ReferenceClient],
        }).compile();

        service = module.get<Edi278NMemberMapperService>(Edi278NMemberMapperService);
        ediUtilities = module.get<EdiUtilities>(EdiUtilities);
        event = ediUtilities.getElementInfo(testCanonicalRequest, canonicalRequestTags.EVENT);
        memberDetails = ediUtilities.getElementInfo(event, canonicalRequestTags.MEMBER);
    });

    it('should be defined', () => {
        expect(service).toBeDefined();
    });

    it('should run #mapMemberData()', async () => {
        var memberValidation = new EdiMemberValidationServiceMock();
        spyOn(memberValidation, 'validateGender').and.callThrough();
        spyOn(memberValidation, 'validateOtherUMOType').and.callThrough();

        service.mapMemberData(event, requestDetails, hscData);
        expect(service).toBeTruthy();
    });

    it('should run #getMemberAddressDetails()', async () => {
        service.getMemberAddressDetails(memberDetails);
        expect(service).toBeTruthy();
    });

    it('should run #getMembershipDetails()', async () => {
        service.getMembershipDetails(requestDetails, memberDetails, event, hscData, indvDetails);
        expect(service).toBeTruthy();
    });

    it('should run #memberCoverage()', async () => {
        var appService = new AppServiceMock();
        spyOn(appService, 'getRefMatchCode').and.callThrough();
        service.memberCoverage("FirstName", "LastName", hscData);
        expect(service).toBeTruthy();
    });


});