import {EdiMemberMapperService} from "../edi-member-mapper.service";
import {
    canonicalRequestTags,
    hscAttributes,
    Indiv,
    Indv,
    IndvAddress,
    Member,
    memberAttributes,
    MemberCoverage,
    Membership,
    MbrCov,
    facilityAttributes,
    EdiProviderConstants,
    EdiAdmissionTypeCodeConstants,
    EdiServiceDescriptionTypeConstants
} from "../../../../constants/edi.constants";
import {EdiUtilities} from "../../../../edi-utilities";
import {Injectable} from "@nestjs/common";
import {EdiMemberValidationService} from "../../../validation/edi-member-validation.service";
import {Edi278NLoopIdConstants, Edi278NMemberConstants} from "../../../../constants/edi-278N.constants";
import { AppService } from "../../../../../app.service";

@Injectable()
export class Edi278NMemberMapperService extends EdiMemberMapperService {

    constructor(ediUtils: EdiUtilities,
                ediMemberValidationService: EdiMemberValidationService,
                protected readonly appService: AppService) {

        super(ediUtils, ediMemberValidationService);
    }

    async mapMemberData(event, requestDetails, hscData) {
        const indiv: Indiv = {
            indv: null
        };

        try {
            const memberDetails = await this.ediUtils.getElementInfo(event, canonicalRequestTags.MEMBER);
            if (memberDetails) {
                const firstName = this.ediUtils.getAttributeValue(memberDetails, memberAttributes.FIRSTNAME);
                const lastName = this.ediUtils.getAttributeValue(memberDetails, memberAttributes.LASTNAME);
                const middleName = this.ediUtils.getAttributeValue(memberDetails, memberAttributes.MIDDLENAME);
                const suffixName = this.ediUtils.getAttributeValue(memberDetails, memberAttributes.SUFFIXNAME);
                const birthDate = this.ediUtils.getAttributeValue(memberDetails, memberAttributes.BIRTHDATE);
                //gender - need get ref id
                const gender = this.ediMemberValidationService.validateGender(this.ediUtils.getAttributeValue(memberDetails, memberAttributes.GENDER));
                let sourceData = this.ediUtils.getRequestInfo(memberDetails, canonicalRequestTags.SOURCEDATA);
                sourceData = this.ediUtils.removeLineBreaks(sourceData);

                this.memberCoverage(event, memberDetails, hscData);

                const indvDetails: Indv = {
                    fst_nm: firstName,
                    lst_nm: lastName,
                    midl_nm: middleName,
                    sufx_nm: suffixName,
                    bth_dt: null,
                    gdr_ref_id: gender,
                    sourceData: sourceData,
                    indv_adrs: []
                };

                this.getMemberBthDate(memberDetails, indvDetails, hscData);

                /* const memberAdd = await this.getMemberAddressDetails(memberDetails);
                 if (memberAdd) {
                     indvDetails.indv_adrs.push(memberAdd);
                 }*/

                indiv.indv = indvDetails;
                requestDetails.Individual = indiv;
                await this.getMembershipDetails(requestDetails, memberDetails, event, hscData, indvDetails);


            }
        } catch (err) {
            console.log(`Error in getMemberData:  ${err}`);
        }
    }

    async getMemberAddressDetails(memberDetails) {
        try {
            const memberAddressDetails = await this.ediUtils.getElementAttributeInfo(memberDetails, canonicalRequestTags.MEMBERADDRESS);
            if (memberAddressDetails) {
                const address1 = await this.ediUtils.getAttributeValue(memberAddressDetails, memberAttributes.ADDRESS1);
                const address2 = await this.ediUtils.getAttributeValue(memberAddressDetails, memberAttributes.ADDRESS2);
                const city = await this.ediUtils.getAttributeValue(memberAddressDetails, memberAttributes.CITY);
                //state - need get ref id
                const state = await this.ediUtils.getAttributeValue(memberAddressDetails, memberAttributes.STATE);
                const zip = await this.ediUtils.getAttributeValue(memberAddressDetails, memberAttributes.ZIP);
                const zipSuffix = await this.ediUtils.getAttributeValue(memberAddressDetails, memberAttributes.ZIPSUFFIX);
                //countryCode - need get ref id
                const countryCode = await this.ediUtils.getAttributeValue(memberAddressDetails, memberAttributes.COUNTRYCODE);

                const memberAdd: IndvAddress = {
                    adr_ln_1_txt: address1,
                    adr_ln_2_txt: address2,
                    cty_nm: city,
                    st_ref_id: state,
                    zip_cd_txt: zip,
                    zip_sufx_cd_txt: zipSuffix,
                    cntry_ref_id: countryCode
                };
                return memberAdd;
            }
        } catch (err) {
            //console.log(`Error in getMemberAddressDetails:  ${err}`);
        }
    }

    async getMembershipDetails(requestDetails, memberDetails, event, hscData, indvDetails) {
        let refID: number;

        console.log("check the value of pol_nbr");
        const memCovDetails: MemberCoverage = {
            pol_nbr: null,
            grp_nbr: null
        };

        const mem: Member = {
            mbrshp: null
        };

        try {
            const otherUMOType = await this.ediMemberValidationService.validateOtherUMOType(this.ediUtils.getAttributeValue(event, hscAttributes.OTHERUMOTYPE));
            const subscriberFirstName = await this.ediUtils.getAttributeValue(memberDetails, memberAttributes.SUBSCRIBERFIRSTNAME);
            const subscriberLastName = await this.ediUtils.getAttributeValue(memberDetails, memberAttributes.SUBSCRIBERLASTNAME);
            const subscriberBirthDate = await this.ediUtils.getAttributeValue(memberDetails, memberAttributes.SUBSCRIBERBIRTHDATE);
            const subscriberEmploymentStatus = await this.ediUtils.getAttributeValue(memberDetails, memberAttributes.SUBSCRIBEREMPLOYMENTSTATUS);
            const relationshipCode = await this.ediUtils.getAttributeValue(memberDetails, memberAttributes.RELATIONSHIPCODE);


            /*  var groupID = await this.ediUtils.getAttributeValue(memberDetails, memberAttributes.GROUPID);

            s

            var memCovDetails: MemberCoverage = {
                pol_nbr: groupID
            };
            */

            //Member Identifier
            const memberIdentifierDetails = this.ediUtils.getRequestInfo(memberDetails, canonicalRequestTags.MEMBERIDENTIFIERS);
            const memberIdentifierArray = memberIdentifierDetails.split("<" + canonicalRequestTags.MEMBERIDENTIFIER);
            //const mbr_id_typ_id = this.ediUtils.getAttributeValue(memberIdentifierArray, memberAttributes.MEMBERIDTYPE);
            memberIdentifierArray.shift();
            let memberID;
            for (const memberIdentifier of memberIdentifierArray) {
                let policyNum;
                const memberIDType = this.ediUtils.getAttributeValue(memberIdentifier, memberAttributes.MEMBERIDTYPE);
                if (memberIDType == Edi278NMemberConstants.MEMBER_ID_TYPE_MI) {
                    memberID = this.ediUtils.getAttributeValue(memberIdentifier, memberAttributes.MEMBERID);
                } else if (memberIDType == Edi278NMemberConstants.MEMBER_ID_TYPE_IG || memberIDType == Edi278NMemberConstants.MEMBER_ID_TYPE_1L) {
                    policyNum = this.ediUtils.getAttributeValue(memberIdentifier, memberAttributes.MEMBERID);
                    memCovDetails.pol_nbr = policyNum;
                    const pol_nbr = policyNum;
                    hscData.mbr_cov.pol_nbr = policyNum;
                    console.log("pol_nbr --------------> " + pol_nbr);
                    console.log("memCovDetails.pol_nbr --------------> " + memCovDetails.pol_nbr);
                    console.log("hscData.mbr_cov.pol_nbr --------------> " + hscData.mbr_cov.pol_nbr);
                } else if (memberIDType == Edi278NMemberConstants.MEMBER_ID_TYPE_6P) {
                    policyNum = this.ediUtils.getAttributeValue(memberIdentifier, memberAttributes.MEMBERID);
                    memCovDetails.grp_nbr = policyNum;
                    const grp_nbr = policyNum;
                    hscData.mbr_cov.grp_nbr = grp_nbr;
                }
            }

            const memDetails: Membership = {
                sbscr_fst_nm: subscriberFirstName,
                sbscr_lst_nm: subscriberLastName,
                cob_ind: otherUMOType,
                sbscr_empmt_dt: subscriberEmploymentStatus,
                mbr_rel_ref_id: relationshipCode,
                scrbr_id_txt: memberID,
                sbscr_bth_dt: indvDetails.bth_dt,

                //memberIDType: mbr_id_typ_id,
                mbr_covs: []
            };
            memDetails.mbr_covs.push(memCovDetails);
            mem.mbrshp = memDetails;
            requestDetails.Membership = mem;

        } catch (err) {
            //console.log(`Error in getMembershipDetails:  ${err}`);
        }
    }

    memberCoverage(event, memberDetails, hscData) {

        const gender = this.ediUtils.getAttributeValue(memberDetails, memberAttributes.GENDER);
        var genderRefID = this.appService.getRefMatchCode('genderType', gender);
        var genderRef = genderRefID.ref_id;
        const firstName = this.ediUtils.getAttributeValue(memberDetails, memberAttributes.FIRSTNAME);
        const lastName = this.ediUtils.getAttributeValue(memberDetails, memberAttributes.LASTNAME);
        const middleName = this.ediUtils.getAttributeValue(memberDetails, memberAttributes.MIDDLENAME);
        const suffixName = this.ediUtils.getAttributeValue(memberDetails, memberAttributes.SUFFIXNAME);
        const birthDate = this.ediUtils.getAttributeValue(memberDetails, memberAttributes.BIRTHDATE);
        const subscriberFirstName = this.ediUtils.getAttributeValue(memberDetails, memberAttributes.SUBSCRIBERFIRSTNAME);
        const subscriberLastName = this.ediUtils.getAttributeValue(memberDetails, memberAttributes.SUBSCRIBERLASTNAME);
        const subscriberBirthDate = this.ediUtils.getAttributeValue(memberDetails, memberAttributes.SUBSCRIBERBIRTHDATE);
        const subscriberEmploymentStatus = this.ediUtils.getAttributeValue(memberDetails, memberAttributes.SUBSCRIBEREMPLOYMENTSTATUS);
        const relationshipCode = this.ediUtils.getAttributeValue(memberDetails, memberAttributes.RELATIONSHIPCODE);
        const relationshipCodeResults = this.appService.getRefMatchCode('relationshipCode', relationshipCode);
        var relationshipCodeRefId = relationshipCodeResults.ref_id;
        const groupID = this.ediUtils.getAttributeValue(memberDetails, memberAttributes.GROUPID);
        const divID = this.ediUtils.getAttributeValue(memberDetails, memberAttributes.DIVID);
        const eligibilitySystemType = this.ediUtils.getAttributeValue(memberDetails, memberAttributes.ELIGIBILITYSYSTEMTYPE);
        console.log("ELIG TYPE eligibilitySystemType>>>>>>>>>>>>>>>" + eligibilitySystemType)
        const eligibilitySystemTypeResult = this.appService.getRefMatchCode('eligibilitySystemTypeID', eligibilitySystemType);
        console.log("ELIG TYPE eligibilitySystemTypeResult>>>>>>>>>>>>>>>" + eligibilitySystemTypeResult)
        var eligibilitySystemTypeId = eligibilitySystemTypeResult.ref_id;
        const sourceCode = this.ediUtils.getAttributeValue(memberDetails, memberAttributes.SOURCECODE);

        try {
            const MbrCov: any = {
                fst_nm: firstName,
                lst_nm: lastName,
                midl_nm: middleName,
                sufx_nm: suffixName,
                bth_dt: birthDate,
                gdr_ref_id: genderRef,
                // orig_sys_cd: sourceCode,
                orig_sys_cd: "CR",
                src_mbr_id: "30830290",
                src_mbr_partn_id: "10",
                cov_eff_dt: "2020-02-01",
                cov_end_dt: "9999-12-31",
                pol_nbr: "16440436900",
                //grp_nbr: groupID,
                cov_typ_ref_id: 182,
                clm_pltfm_ref_id: 363,
                /*sbscr_fst_nm: subscriberFirstName,
                sbscr_lst_nm: subscriberLastName,
                // subscriberBirthDate: subscriberBirthDate,
                sbscr_empmt_dt: subscriberEmploymentStatus,
                mbr_rel_ref_id: relationshipCodeRefId,
                div_id: divID,
                elig_sys_ref_id: eligibilitySystemTypeId,
                // sourceCode: sourceCode*/
            };
            //console.log("member coverage>>>>>>>>>>>>>>> " + JSON.stringify(MbrCov));
            hscData.mbr_cov = MbrCov;

            //return MbrCovs;
        } catch (err) {
            //console.log(`Error in getMemberAddressDetails:  ${err}`);
        }
    }

    async getMemberBthDate(memberDetails, indvDetails, hscData) {
        try {
            const sourceData = await this.ediUtils.getRequestInfo(memberDetails, canonicalRequestTags.SOURCEDATA);
            indvDetails.sourceData = await this.ediUtils.removeLineBreaks(sourceData);
            const xloopId = indvDetails.sourceData;
            var x = xloopId.indexOf('>') + 1;
            var y = xloopId.indexOf('<', x);
            var newloopID = xloopId.substring(x, y);
            indvDetails.loopID = newloopID;
            let memberBthDt;
            let sbscrbrBthDt;

            if (indvDetails.loopID == Edi278NLoopIdConstants.MEMBER_LOOP_ID) {
                memberBthDt = this.ediUtils.getAttributeValue(memberDetails, memberAttributes.BIRTHDATE);
                indvDetails.bth_dt = memberBthDt;
                hscData.mbr_cov.bth_dt = memberBthDt;
            } else if (indvDetails.loopID == Edi278NLoopIdConstants.SUBSCRIBER_LOOP_ID) {
                memberBthDt = this.ediUtils.getAttributeValue(memberDetails, memberAttributes.SUBSCRIBERBIRTHDATE);
                indvDetails.bth_dt = memberBthDt;
                hscData.mbr_cov.bth_dt = memberBthDt;
            }
        } catch (err) {
            //console.log(`Error in getMemberAddressDetails:  ${err}`);
        }
    }
}