import {Test, TestingModule} from "@nestjs/testing";
import {HealthServiceClient} from "../../../../../shared/graphql/healthservicedomain/healthServiceClient";
import {Injectable} from "@nestjs/common";
import {canonicalRequestTags, RequestDetails} from "../../../../constants/edi.constants";
import {EdiUtilities} from "../../../../edi-utilities";
import {HealthServiceService} from "../../../healthService/healthService.service";
import {testCanonicalRequest} from "../../../../../../test/ediTestData";
import {ConfigService} from "@nestjs/config";
import {Edi278NProviderMapperService} from "./edi-278N-provider-mapper.service";
import {EdiProviderValidationService} from "../../../validation/edi-provider-validation.service";

@Injectable()
class EdiProviderValidationServiceMock {
    validateProviderFirstName(firstName, lastName, entityType) {
        return "Matt";
    }

    validateProviderLastName(lastName) {
        return "Meyer";
    }

    validateEntityType(entityType) {
        return "1";
    }

    validateEntityIdentifier(entityIdentifier) {
        return "AAJ";
    }

    validateProviders(serviceSettingType, providers) {
        return true;
    }

    getProviderRole(entityIdentifier, attendingProviderExists) {
        return 1111;
    }

    checkAttendingProvider(providers) {
        return true;
    }

}

describe('Edi278NProviderMapperService', () => {
    let service: Edi278NProviderMapperService;
    let ediUtilities: EdiUtilities;
    let memberDetails;
    let providerDetails;
    let event;

    const requestDetails: RequestDetails = {
        dataTransmissionHeader: null,
        Membership: null,
        Individual: null,
        Provider: null,
        Facility: null,
        Diagnosis: null,
        Event: null,
        procCodes: null,
        Service: null,
        updateHscRequest: null,
        hscSourceData: null,
        ediType: null,
        followUpContact: null,
        Error: null
    };

    const facilityProviderSeqNum  = {
        "provider": {
            $: {
                facilityProviderSeqNum: "2",
            },
        }
    }


    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [Edi278NProviderMapperService, EdiUtilities,
                {provide: EdiProviderValidationService, useClass: EdiProviderValidationServiceMock},
                ConfigService, HealthServiceClient, HealthServiceService],
        }).compile();

        service = module.get<Edi278NProviderMapperService>(Edi278NProviderMapperService);
        ediUtilities = module.get<EdiUtilities>(EdiUtilities);
        event = ediUtilities.getElementInfo(testCanonicalRequest, canonicalRequestTags.EVENT);
        memberDetails = ediUtilities.getElementInfo(event, canonicalRequestTags.MEMBER);
        providerDetails = ediUtilities.getElementInfo(event, canonicalRequestTags.PROVIDERS);
    });

    it('should be defined', () => {
        expect(service).toBeDefined();
    });

    it('should run #mapProviderDomainData()', async () => {
        var providerValidation = new EdiProviderValidationServiceMock();
        spyOn(providerValidation, 'validateProviderFirstName').and.callThrough();
        spyOn(providerValidation, 'validateProviderLastName').and.callThrough();
        spyOn(providerValidation, 'validateEntityType').and.callThrough();
        spyOn(providerValidation, 'validateEntityIdentifier').and.callThrough();
        spyOn(providerValidation, 'validateProviders').and.callThrough();
        spyOn(providerValidation, 'getProviderRole').and.callThrough();
        spyOn(providerValidation, 'checkAttendingProvider').and.callThrough();

        service.mapProviderDomainData(event, requestDetails, facilityProviderSeqNum, "278N");
        expect(service).toBeTruthy();
    });

    it('should run #getProviderAddressData()', async () => {
        service.getProviderAddressData(providerDetails);
        expect(service).toBeTruthy();
    });

});