import {Injectable} from "@nestjs/common";
import {EdiProviderMapperService} from "../edi-provider-mapper.service";
import {
    canonicalRequestTags,
    Provider, ProviderAddress,
    providerAttributes,
    ProviderData,
    ProviderIndv, ProviderOrg, ProviderLocAffilDtl, HSC_PROV, facilityAttributes
} from "../../../../constants/edi.constants";
import {EdiUtilities} from "../../../../edi-utilities";
import {EdiProviderValidationService} from "../../../validation/edi-provider-validation.service";

@Injectable()
export class Edi278NProviderMapperService extends EdiProviderMapperService {

    constructor(ediUtils: EdiUtilities,
                ediProviderValidationService: EdiProviderValidationService) {
        super(ediUtils, ediProviderValidationService);
    }

    async mapProviderDomainData(event, requestDetails, facilityProviderSeqNum, ediType) {
        const tempProv: Provider = {
            prov: new Array()
        };

        try {
            const providerDetails = await this.ediUtils.getRequestInfo(event, canonicalRequestTags.PROVIDERS);
            const providerArray = await providerDetails.split("<" + canonicalRequestTags.PROVIDER + " ");
            const facilityDetails = this.ediUtils.getElementInfo(event, canonicalRequestTags.FACILITY);

            providerArray.shift();

            for (const provider of providerArray) {
                const prov: ProviderData = {
                    prov_indvs: null,
                    prov_orgs: null,
                    prov_adrs: new Array(),
                    providerSeqNum: null,
                    ediType: null,
                    entityType: null,
                    ndbMpin: null,
                    providerNPI: null,
                    federalTaxID: null,
                    federalTaxIDSuffix: null,
                    entityIdentifier: null,
                    sourceData: null,
                    loopID: null,
                    facilityProviderSeqNum: null,
                    providerType: null,
                    firstName: null,
                    requestCategory: null,
                    lastName: null,
                    businessName: null,
                    prov_loc_affil_dtl: null,
                    // providerTaxonomyCode: null,
                    // countryCode: null,
                    // contactName: null,
                    // primaryPhoneExt: null,
                    // secondaryPhoneExt: null,
                    // faxExt: null,
                    // emailAddress: null
                };

                prov.providerSeqNum = await this.ediUtils.getAttributeValue(provider, providerAttributes.PROVIDERSEQNUM);
                prov.entityType = this.ediProviderValidationService.validateEntityType(this.ediUtils.getAttributeValue(provider, providerAttributes.ENTITYTYPE));
                prov.entityIdentifier = this.ediProviderValidationService.validateEntityIdentifier(this.ediUtils.getAttributeValue(provider, providerAttributes.ENTITYIDENTIFIER));
                prov.ndbMpin = await this.ediUtils.getAttributeValue(provider, providerAttributes.NDBMPIN);
                prov.providerNPI = await this.ediUtils.getAttributeValue(provider, providerAttributes.PROVIDERNPI);
                prov.federalTaxID = await this.ediUtils.getAttributeValue(provider, providerAttributes.FEDERALTAXID);
                prov.federalTaxIDSuffix = await this.ediUtils.getAttributeValue(provider, providerAttributes.FEDERALTAXIDSUFFIX);
                prov.providerType = await this.ediUtils.getAttributeValue(provider, providerAttributes.PROVIDERTYPE);
                prov.requestCategory = this.ediUtils.getAttributeValue(facilityDetails, facilityAttributes.REQUESTCATEGORY);
                prov.firstName = await this.ediUtils.getAttributeValue(provider, providerAttributes.FIRSTNAME);
                prov.lastName = await this.ediUtils.getAttributeValue(provider, providerAttributes.LASTNAME);
                prov.businessName = await this.ediUtils.getAttributeValue(provider, providerAttributes.BUSINESSNAME);
                prov.ediType = ediType;
                const sourceData = await this.ediUtils.getRequestInfo(provider, canonicalRequestTags.SOURCEDATA);
                prov.sourceData = await this.ediUtils.removeLineBreaks(sourceData);
                const xloopId = prov.sourceData;
                var x = xloopId.indexOf('>') + 1;
                var y = xloopId.indexOf('<',x);
                var newloopID = xloopId.substring(x,y);
                prov.loopID = newloopID;
                prov.facilityProviderSeqNum = facilityProviderSeqNum;

                // await this.getHSC_PROV(provider, prov);


                if (prov.entityType == '1') {
                    const lastName = await this.ediProviderValidationService.validateProviderLastName(this.ediUtils.getAttributeValue(provider, providerAttributes.LASTNAME));
                    const firstName = await this.ediProviderValidationService.validateProviderFirstName(this.ediUtils.getAttributeValue(provider, providerAttributes.FIRSTNAME), lastName, prov.entityType);
                    const middleName = await this.ediUtils.getAttributeValue(provider, providerAttributes.MIDDLENAME);
                    const suffixName = await this.ediUtils.getAttributeValue(provider, providerAttributes.SUFFIXNAME);

                    const provIndv: ProviderIndv = {
                        fst_nm: firstName,
                        midl_nm: middleName,
                        lst_nm: lastName,
                        sufx_nm: suffixName
                    };
                    prov.prov_indvs = provIndv;

                } else if (prov.entityType == '2') {
                    const businessName = await this.ediUtils.getAttributeValue(provider, providerAttributes.BUSINESSNAME);

                    const provOrg: ProviderOrg = {
                        bus_nm: businessName
                    };
                    prov.prov_orgs = provOrg;
                }
                //console.log("Provider >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> " + JSON.stringify(provider));
                const provAddr = await this.getProviderAddressData(provider);
                const provTel = await this.getProviderLocAffilDtl(provider);
                prov.prov_loc_affil_dtl = provTel;

                //console.log("PHONE NUMBER>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> " + JSON.stringify(provTel));
                prov.prov_adrs.push(provAddr);
                tempProv.prov.push(prov);
            }
            requestDetails.Provider = tempProv;


        } catch (err) {
            console.log(`Error in getProviderDomainData:  ${err}`);
        }
    }

    async getProviderAddressData(provider) {
        try {

            const address1 = await this.ediUtils.getAttributeValue(provider, providerAttributes.ADDRESS1);
            const address2 = await this.ediUtils.getAttributeValue(provider, providerAttributes.ADDRESS2);
            const city = await this.ediUtils.getAttributeValue(provider, providerAttributes.CITY);
            const state = await this.ediUtils.getAttributeValue(provider, providerAttributes.STATE);
            const zip = await this.ediUtils.getAttributeValue(provider, providerAttributes.ZIP);
            const zipSuffix = await this.ediUtils.getAttributeValue(provider, providerAttributes.ZIPSUFFIX);
            /*var countryCode = this.ediUtils.getAttributeValue(provider, providerAttributes.COUNTRYCODE);
            var contactName = this.ediUtils.getAttributeValue(provider, providerAttributes.CONTACTNAME);
            var primaryPhone = this.ediUtils.getAttributeValue(provider, providerAttributes.PRIMARYPHONE);
            var primaryPhoneExt = this.ediUtils.getAttributeValue(provider, providerAttributes.PRIMARYPHONEEXT);
            var secondaryPhone = this.ediUtils.getAttributeValue(provider, providerAttributes.SECONDARYPHONE);
            var secondaryPhoneExt = this.ediUtils.getAttributeValue(provider, providerAttributes.SECONDARYPHONEEXT);
            var fax = this.ediUtils.getAttributeValue(provider, providerAttributes.FAX);
            var faxExt = this.ediUtils.getAttributeValue(provider, providerAttributes.FAXEXT);
            var emailAddress = this.ediUtils.getAttributeValue(provider, providerAttributes.EMAILADDRESS);
        */

            const provAddr: ProviderAddress = {
                adr_ln_1_txt: address1,
                adr_ln_2_txt: address2,
                cty_nm: city,
                st_ref_id: state,
                zip_cd_txt: zip,
                zip_sufx_cd_txt: zipSuffix
            };

            return provAddr;

        } catch (err) {
            //console.log(`Error in getProviderAddressData:  ${err}`);
        }
    }

    async getProviderLocAffilDtl(provider){
        try {
            const primaryPhone = await this.ediUtils.getAttributeValue(provider, providerAttributes.PRIMARYPHONE);
            const secondaryPhone = await  this.ediUtils.getAttributeValue(provider, providerAttributes.SECONDARYPHONE);
            const fax = await this.ediUtils.getAttributeValue(provider, providerAttributes.FAX);
            const primaryPhoneExt = await this.ediUtils.getAttributeValue(provider, providerAttributes.PRIMARYPHONEEXT);
            const secondaryPhoneExt = await this.ediUtils.getAttributeValue(provider, providerAttributes.SECONDARYPHONEEXT);
            const faxExt = await this.ediUtils.getAttributeValue(provider, providerAttributes.FAXEXT);
            const providerTaxonomyCode= await this.ediUtils.getAttributeValue(provider, providerAttributes.PROVIDERTAXONOMYCODE);
            const countryCode= await this.ediUtils.getAttributeValue(provider, providerAttributes.COUNTRYCODE);
            const contactName= await this.ediUtils.getAttributeValue(provider, providerAttributes.CONTACTNAME);
            const emailAddress= await this.ediUtils.getAttributeValue(provider, providerAttributes.EMAILADDRESS);
            //additional fields for AffilDtl for response mapping

            const provLocDtl: ProviderLocAffilDtl = {
                providerTaxonomyCode: providerTaxonomyCode,
                countryCode: countryCode,
                contactName: contactName,
                primary_Phone: primaryPhone,
                primaryPhoneExt: primaryPhoneExt,
                secondary_Phone: secondaryPhone,
                secondaryPhoneExt: secondaryPhoneExt,
                faxExt: faxExt,
                faxNum: fax,
                emailAddress: emailAddress,
            };
            return provLocDtl;
        }catch (err) {

        }

    }

    // async getHSC_PROV(provider, prov){
    //     try {
    //
    //         prov.providerSeqNum = await this.ediUtils.getAttributeValue(provider, providerAttributes.PROVIDERSEQNUM);
    //         prov.providerTaxonomyCode= await this.ediUtils.getAttributeValue(provider, providerAttributes.PROVIDERTAXONOMYCODE);
    //         prov.countryCode= await this.ediUtils.getAttributeValue(provider, providerAttributes.COUNTRYCODE);
    //         prov.contactName= await this.ediUtils.getAttributeValue(provider, providerAttributes.CONTACTNAME);
    //         prov.primaryPhoneExt= await this.ediUtils.getAttributeValue(provider, providerAttributes.PRIMARYPHONEEXT);
    //         prov.secondaryPhoneExt= await this.ediUtils.getAttributeValue(provider, providerAttributes.SECONDARYPHONEEXT);
    //         prov.faxExt= await this.ediUtils.getAttributeValue(provider, providerAttributes.FAXEXT);
    //         prov.emailAddress= await this.ediUtils.getAttributeValue(provider, providerAttributes.EMAILADDRESS);
    //
    //
    //         /*const providerSeqNum = await this.ediUtils.getAttributeValue(provider, providerAttributes.PROVIDERSEQNUM);
    //         const providerTaxonomyCode= await this.ediUtils.getAttributeValue(provider, providerAttributes.PROVIDERTAXONOMYCODE);
    //         const countryCode= await this.ediUtils.getAttributeValue(provider, providerAttributes.COUNTRYCODE);
    //         const contactName= await this.ediUtils.getAttributeValue(provider, providerAttributes.CONTACTNAME);
    //         const primaryPhoneExt= await this.ediUtils.getAttributeValue(provider, providerAttributes.PRIMARYPHONEEXT);
    //         const secondaryPhoneExt= await this.ediUtils.getAttributeValue(provider, providerAttributes.SECONDARYPHONEEXT);
    //         const faxExt= await this.ediUtils.getAttributeValue(provider, providerAttributes.FAXEXT);
    //         const emailAddress= await this.ediUtils.getAttributeValue(provider, providerAttributes.EMAILADDRESS);
    //
    //         const hsc_prov: HSC_PROV = {
    //             providerTaxonomyCode: providerTaxonomyCode,
    //             countryCode: countryCode,
    //             contactName: contactName,
    //             primaryPhoneExt: primaryPhoneExt,
    //             secondaryPhoneExt: secondaryPhoneExt,
    //             faxExt: faxExt,
    //             emailAddress: emailAddress
    //
    //         };*/
    //         //return hsc_prov;
    //     } catch (err){
    //
    //     }
    //
    // };
}