import {Test, TestingModule} from "@nestjs/testing";
import {HealthServiceClient} from "../../../../../shared/graphql/healthservicedomain/healthServiceClient";
import {Injectable} from "@nestjs/common";
import {canonicalRequestTags, RequestDetails, Service} from "../../../../constants/edi.constants";
import {EdiUtilities} from "../../../../edi-utilities";
import {HealthServiceService} from "../../../healthService/healthService.service";
import {testCanonicalRequest} from "../../../../../../test/ediTestData";
import {ConfigService} from "@nestjs/config";
import {Edi278NServiceMapperService} from "./edi-278N-service-mapper.service";
import {Edi278NServiceValidationService} from "../../../validation/278N-validation/edi-278N-service-validation.service";
import {HttpRequest} from "@azure/functions";
import {AppService} from "../../../../../app.service";

@Injectable()
class Edi278NServiceValidationServiceMock {
    validateServiceReferenceNumber(serviceReferenceNumber) {
        return "testSRN123";
    }

    validateCertificationType(certificationType, serviceReferenceNum, requestDetails) {
        return "I";
    }

    validateProcedureCode(procedureCode, serviceSettingType, requestDetails, request) {
        return 1111;
    }
}

@Injectable()
class AppServiceMock {
    getRefMatchCode(baseRefName, refCode) {
        return "123";
    }
}

describe('Edi278NServiceMapperService', () => {
    let service: Edi278NServiceMapperService;
    let ediUtilities: EdiUtilities;
    let request: HttpRequest;
    let memberDetails;
    let providerDetails;
    let serviceDetails;
    let event;

    const serviceValidation = new Edi278NServiceValidationServiceMock();
    const appService = new AppServiceMock();
    const sourceDataObject = {};
    const hscData = {
        hsc_id: 1,
        indv_key_typ_ref_id: null,
        indv_key_val: null,
        srvc_set_ref_id: 3737,
        rev_prr_ref_id: 3754,
        flwup_cntc_dtl: null,
        hsc_srvcs: new Array(),
        hsr_notes: null
    };

    const requestDetails: RequestDetails = {
        dataTransmissionHeader: null,
        Membership: null,
        Individual: null,
        Provider: null,
        Facility: null,
        Diagnosis: null,
        Event: null,
        procCodes: null,
        Service: null,
        updateHscRequest: null,
        hscSourceData: null,
        ediType: null,
        followUpContact: null,
        Error: null
    };

    const serviceInfo: Service = {
        //  creat_user_id: null,
        //  chg_user_id: null,
        expmt_proc_ind: null,
        hsc_srvc_rev_typ_ref_id: null,
        adv_ntfy_trans_id: null,
        ben_chk_sts_ref_id: null,
        adv_ntfy_dttm: null,
        expt_proc_dt: null,
        inac_ind: 0,
        proc_othr_txt: null,
        proc_cd: null,
        proc_cd_schm_ref_id: 2,
        srvc_hsc_prov_id: null,
        hsc_prov: {
            "creat_user_id": null,
            "chg_user_id": null,
            "id": 3,
            "fst_nm": null,
            "midl_nm": null,
            "lst_nm": null,
            "bus_nm": null,
            "prov_keys": [
                {
                    "prov_key_typ_ref_id": 2782,
                    "prov_key_val": "1376194050"
                }
            ],
            "hsc_prov_roles": [
                {
                    "prov_role_ref_id": 3765
                }
            ],
            "prov_adr": {
                "adr_ln_1_txt": "1067 Twining Dr",
                "adr_ln_2_txt": null,
                "zip_cd_txt": "71110",
                "cty_nm": "Barksdale AFB",
                "st_ref_id": 1083
            },
            "prov_loc_affil_dtl": null
        },
        hsc_decn: null
    };

    @Injectable()
    class Edi278NServiceMapperServiceMock {
        mapServiceData(event, hscData, sourceDataObject, serviceSettingType, requestDetails, request, mapServiceData) {
            return "Inpatient";
        }
    }


    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [Edi278NServiceMapperService, EdiUtilities,
                {provide: Edi278NServiceValidationService, useClass: Edi278NServiceValidationServiceMock},
                {provide: AppService, useClass: AppServiceMock},
                ConfigService, HealthServiceClient, HealthServiceService],
        }).compile();

        service = module.get<Edi278NServiceMapperService>(Edi278NServiceMapperService);
        ediUtilities = module.get<EdiUtilities>(EdiUtilities);
        event = ediUtilities.getElementInfo(testCanonicalRequest, canonicalRequestTags.EVENT);
        memberDetails = ediUtilities.getElementInfo(event, canonicalRequestTags.MEMBER);
        providerDetails = ediUtilities.getElementInfo(event, canonicalRequestTags.PROVIDERS);
        serviceDetails = ediUtilities.getElementInfo(event, canonicalRequestTags.SERVICES);
    });

    it('should be defined', () => {
        expect(service).toBeDefined();
    });

    it('should run #mapServiceData()', async () => {
        spyOn(service, 'getServicingProviderData').and.callFake(function () {
        });
        spyOn(serviceValidation, 'validateServiceReferenceNumber').and.callThrough();
        spyOn(serviceValidation, 'validateCertificationType').and.callThrough();
        spyOn(service, 'mapServiceFacilityData').and.callFake(function () {
        });

        service.mapServiceData(event, hscData, sourceDataObject, "Inpatient", requestDetails, request, "278N");
        expect(service).toBeTruthy();
    });

    it('should run #mapServiceFacilityData()', async () => {
        spyOn(serviceValidation, 'validateProcedureCode').and.callThrough();
        service.mapServiceFacilityData(serviceDetails, serviceInfo, "Inpatient", requestDetails, request);
        expect(service).toBeTruthy();
    });

    it('should run #getServicingProviderData()', async () => {
        spyOn(appService, 'getRefMatchCode').and.callThrough();
        service.getServicingProviderData('1', hscData);
        expect(service).toBeTruthy();
    });
});