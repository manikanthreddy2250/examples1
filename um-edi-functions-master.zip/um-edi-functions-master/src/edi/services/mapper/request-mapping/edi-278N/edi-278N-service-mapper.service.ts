import {Injectable} from "@nestjs/common";
import {EdiServiceMapperService} from "../edi-service-mapper.service";
import {
    canonicalRequestTags, EdiProviderConstants, Facility,
    FacilityData, followUpContactAttributes, HscProviderDetails, HscSrvcDecision, procCDdetails,
    Service, hscAttributes,
    serviceAttributes, ServiceData, ServiceFacilityData, ServiceNonFacilityData, SrvcFacBedDay, HSCval, serviceDeliveryData
} from "../../../../constants/edi.constants";
import {EdiServiceValidationService} from "../../../validation/edi-service-validation.service";
import {EdiUtilities} from "../../../../edi-utilities";
import {Edi278NServiceValidationService} from "../../../validation/278N-validation/edi-278N-service-validation.service";
import {AppService} from "../../../../../app.service";

@Injectable()
export class Edi278NServiceMapperService extends EdiServiceMapperService {

    constructor(ediUtils: EdiUtilities,
                appService: AppService,
                protected readonly edi278NServiceValidationService: Edi278NServiceValidationService) {
        super(ediUtils, appService, edi278NServiceValidationService);
    }

    async mapServiceData(event, hscData, sourceDataObject, serviceSettingType, requestDetails, request, ediType) {
        let service;
        const serviceSourceData = [];
        const serviceDataArray = [];
        const procCodesObject = [];
        try {
            const serviceDetails = this.ediUtils.getRequestInfo(event, canonicalRequestTags.SERVICES);
            if (serviceDetails) {
                //map servicing provider
                const serviceProviderSeqNum = this.ediUtils.getAttributeValue(service, serviceAttributes.SERVICEPROVIDERSEQNUM);
                const servicingProvider = await this.getServicingProviderData(serviceProviderSeqNum, hscData);
                const createDate = await this.ediUtils.getAttributeValue(event, hscAttributes.CREATEDATE);
                const createTime = await this.ediUtils.getAttributeValue(event, hscAttributes.CREATETIME);
                const adv_ntfy_dttm = createDate.concat('T', createTime.toString());
                const serviceArray = serviceDetails.split("<" + canonicalRequestTags.SERVICE + " ");
                serviceArray.shift();

                for (service of serviceArray) {

                    const serviceSeqNum = this.ediUtils.getAttributeValue(service, serviceAttributes.SERVICERSEQNUM);
                    const serviceReferenceNum = this.edi278NServiceValidationService.validateServiceReferenceNumber(this.ediUtils.getAttributeValue(service, serviceAttributes.SERVICEREFERENCENUM));
                    const certificationType = this.edi278NServiceValidationService.validateCertificationType(this.ediUtils.getAttributeValue(service, serviceAttributes.CERTFICATIONTYPE), serviceReferenceNum, requestDetails);
                    const serviceType = this.ediUtils.getAttributeValue(service, serviceAttributes.SERVICETYPE);
                    const requestCategory = this.ediUtils.getAttributeValue(service, serviceAttributes.REQUESTCATEGORY);
                    const locationCode = this.ediUtils.getAttributeValue(service, serviceAttributes.LOCATIONCODE);
                    const serviceStartDate = this.ediUtils.getAttributeValue(service, serviceAttributes.SERVICESTARTDATE);
                    const serviceEndDate = this.ediUtils.getAttributeValue(service, serviceAttributes.SERVICEENDDATE);
                    const actionCode = this.ediUtils.getAttributeValue(service, serviceAttributes.ACTIONCODE);
                    let sourceData = this.ediUtils.getRequestInfo(service, canonicalRequestTags.SOURCEDATA);
                    sourceData = this.ediUtils.removeLineBreaks(sourceData);
                    if (sourceData) {
                        serviceSourceData.push(sourceData);
                    }


                    const serviceDelivery = this.ediUtils.getElementAttributeInfo(service, canonicalRequestTags.SERVICEDELIVERY);
                    const unitCodeSD = this.ediUtils.getAttributeValue(serviceDelivery, serviceAttributes.UNITCODE);
                    const quantitySD = this.ediUtils.getAttributeValue(serviceDelivery, serviceAttributes.QUANTITY);
                    const quantityQualifierSD = this.ediUtils.getAttributeValue(serviceDelivery, serviceAttributes.QUANTITYQUALIFIER);
                    const sampleSelectionModulusSD = this.ediUtils.getAttributeValue(serviceDelivery, serviceAttributes.SAMPLESELECTIONMODULUS);
                    const timePeriodQualifierSD = this.ediUtils.getAttributeValue(serviceDelivery, serviceAttributes.TIMEPERIODQUALIFIER);
                    const numberOfPeriodsSD = this.ediUtils.getAttributeValue(serviceDelivery, serviceAttributes.NUMBEROFPERIODS);

                    const ServiceDeliveryData: serviceDeliveryData = {
                        unitCode: unitCodeSD,
                        quantity: quantitySD,
                        quantityQualifier: quantityQualifierSD,
                        sampleSelectionModulus: sampleSelectionModulusSD,
                        timePeriodQualifier: timePeriodQualifierSD,
                        numberOfPeriods: numberOfPeriodsSD
                    };



                    //Service Facility
                    const serviceFacility = this.ediUtils.getElementAttributeInfo(service, canonicalRequestTags.SERVICEFACILITY);
                    const monetaryAmount = this.ediUtils.getAttributeValue(serviceFacility, serviceAttributes.MONETARYAMOUNT);
                    const unitCode = this.ediUtils.getAttributeValue(serviceFacility, serviceAttributes.UNITCODE);
                    const quantity = this.ediUtils.getAttributeValue(serviceFacility, serviceAttributes.QUANTITY);

                    const serviceFacilityData: ServiceFacilityData = {
                        monetaryAmount: monetaryAmount,
                        unitCode: unitCode,
                        quantity: quantity
                    };

                    //Service Non Facility
                    const serviceNonFacility = this.ediUtils.getElementAttributeInfo(service, canonicalRequestTags.SERVICENONFACILITY);

                    const monetaryAmountNF = this.ediUtils.getAttributeValue(serviceNonFacility, serviceAttributes.MONETARYAMOUNT);
                    const unitCodeNF = this.ediUtils.getAttributeValue(serviceNonFacility, serviceAttributes.UNITCODE);
                    const quantityNF = this.ediUtils.getAttributeValue(serviceNonFacility, serviceAttributes.QUANTITY);

                    const serviceNonFacilityData: ServiceNonFacilityData = {
                        monetaryAmount: monetaryAmountNF,
                        unitCode: unitCodeNF,
                        quantity: quantityNF
                    };

                    if (serviceFacility) {
                        var serviceInfo: Service = {
                            //creat_user_id: null,
                            //chg_user_id: null,
                            proc_cd: null, //procedureCode,
                            proc_cd_schm_ref_id: null, //not sure what this is
                            expmt_proc_ind: null,
                            hsc_srvc_rev_typ_ref_id: 1, //hardcoded
                            adv_ntfy_trans_id: null,
                            ben_chk_sts_ref_id: null,
                            adv_ntfy_dttm: adv_ntfy_dttm,
                            expt_proc_dt: serviceEndDate,
                            inac_ind: 0,
                            proc_othr_txt: null,
                            srvc_hsc_prov_id: null,
                            hsc_prov: servicingProvider, // service_prov,
                            hsc_decn: null,
                        };
                        //  serviceInfo.adv_ntfy_dttm = adv_ntfy_dttm;
                    }

                    //     serviceInfo.expt_proc_dt = serviceEndDate;

                    //set values for Service Data object
                    const serviceData: ServiceData = {
                        serviceSeqNum: serviceSeqNum,
                        serviceReferenceNum: serviceReferenceNum,
                        requestCategory: requestCategory,
                        serviceType: serviceType,
                        certificationType: certificationType,
                        actionCode: actionCode,
                        serviceEndDate: serviceEndDate,
                        serviceFacility: serviceFacilityData,
                        serviceNonFacility: serviceNonFacilityData,
                        serviceDelivery: ServiceDeliveryData
                    };

                    requestDetails.Service = serviceDataArray;
                    serviceDataArray.push(serviceData)

                    //map procCodes object

                    await this.mapServiceFacilityData(service, serviceInfo, serviceSettingType, requestDetails, request);
                    if (serviceInfo.proc_cd) {
                        const prcCD: procCDdetails = {
                            "reqCategory": serviceSettingType,
                            "procCode": serviceInfo.proc_cd
                        };

                        const hscValue: HSCval = {
                            "hsc": prcCD,
                            "ediType": ediType,
                            "sourceChannel":""
                        };

                        procCodesObject.push(hscValue);
                    }

                    var hscDecn: HscSrvcDecision = {
                        decn_otcome_ref_id: 1,
                        decn_typ_ref_id: 2,
                        decn_rsn_ref_id: 3,
                        clm_note_txt: "test",
                        ovrd_clm_rmrk_ref_id: 1,
                        sys_clm_rmrk_ref_id: 1,
                        wrt_decn_cmnct_dttm: "11-03-2021",
                        decn_rndr_dttm: "12-03-2021",
                        decn_mbr_cmnct_dttm: "13-03-2021",
                        decn_prov_cmnct_dttm: "14-03-2021",
                        gap_rev_otcome_ref_id: 2,
                        negot_rt: 1,
                        hsc_decn_bed_days: [
                            {
                                strt_bed_dt: "15-03-2021",
                                rvnu_cd: "test",
                                bed_typ_ref_id: 1
                            }
                        ]
                    };
                    serviceInfo.hsc_decn = hscDecn;
                    hscData.hsc_srvcs.push(serviceInfo);
                }
                sourceDataObject[canonicalRequestTags.SERVICE] = serviceSourceData;
                requestDetails.procCodes = procCodesObject;
            }
        } catch (err) {
            console.log(`Error in getServiceData:  ${err}`);
        }
    }

    async mapServiceFacilityData(service, serviceInfo, serviceSettingType, requestDetails, request) {

        const serviceFacility = this.ediUtils.getElementAttributeInfo(service, canonicalRequestTags.SERVICEFACILITY);

        try {
            if (serviceFacility) {

                const procedureCodeDetails = await this.edi278NServiceValidationService.validateProcedureCode(this.ediUtils.getAttributeValue(serviceFacility, serviceAttributes.PROCEDURECODE), serviceSettingType, requestDetails, request);
                //const procedureCodeType = await this.ediUtils.getAttributeValue(serviceFacility, serviceAttributes.PROCEDURECODETYPE);
                const procedureCodeTypeDetails = this.appService.getRefMatchDesc('procCodeType', procedureCodeDetails.procCodeType);
                const procedureDescription = await this.ediUtils.getAttributeValue(serviceFacility, serviceAttributes.PROCEDUREDESCRIPTION);
                const procedureCode2 = await this.ediUtils.getAttributeValue(serviceFacility, serviceAttributes.PROCEDURECODE2);
                if (procedureCodeDetails) {
                    serviceInfo.proc_cd = procedureCodeDetails.proc_cd;
                    serviceInfo.proc_cd_schm_ref_id = procedureCodeTypeDetails.ref_id;
                }


            }
        } catch (err) {
            console.log("Error in Edi278NServiceMapperService: mapServiceFacilityData(): " + err);
        }
    }


    async getServicingProviderData(serviceProviderSeqNum, hscData) {
        let servicingProviderRoleRefID;

        try {
            //Get RefID of Provider Role -SJ
            const refDataResults = this.appService.getRefMatchCode('providerRole', EdiProviderConstants.SERVICING_PROVIDER);
            if (refDataResults) {
                servicingProviderRoleRefID = refDataResults.ref_id;
            }

            if (hscData.hsc_provs && servicingProviderRoleRefID) {
                for (const provider of hscData.hsc_provs) {
                    if (provider.hsc_prov_roles[0].prov_role_ref_id == servicingProviderRoleRefID) {
                        //  serviceInfo.hsc_prov.push(provider);
                        return provider;
                    }
                }
            }
        } catch (err) {
            console.log("Error in Edi278NServiceMapperService: mapServicingProviderData(): " + err);
        }
    }


}