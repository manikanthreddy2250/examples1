import {Injectable} from "@nestjs/common";
import {EdiUtilities} from "../../../edi-utilities";
import {EdiDataTransmissionHeaderValidationService} from "../../validation/edi-dataTransmissionHeader-validation.service";

@Injectable()
export class EdiDataTransmissionHeaderMapperService {

    constructor(protected readonly ediUtils: EdiUtilities,
                protected readonly ediDataTransmissionHeaderValidationService: EdiDataTransmissionHeaderValidationService) {
    }

    async mapDataTransmissionHeaderData(canonicalRequest, requestDetails, hscID) {
    }

}