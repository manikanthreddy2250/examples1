import {Injectable} from "@nestjs/common";
import {EdiUtilities} from "../../../edi-utilities";
import {EdiDiagnosisValidationService} from "../../validation/edi-diagnosis-validation.service";
import {AppService} from "../../../../app.service";

@Injectable()
export class EdiDiagnosisMapperService {

    constructor(protected readonly ediUtils: EdiUtilities,
                protected readonly appService: AppService,
                protected readonly ediDiagnosisValidationService: EdiDiagnosisValidationService) {}

    async mapHscDiagnosisData(event, hscData, sourceDataObject, request, requestDetails) {}

}