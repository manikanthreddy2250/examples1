import {Injectable} from "@nestjs/common";
import {EdiUtilities} from "../../../edi-utilities";

@Injectable()
export class EdiEventMapperService {

    constructor(protected readonly ediUtils: EdiUtilities) {}
    mapEventMBRSHP(canonicalRequest, hscData){}
    mapHscClinGuidData(canonicalRequest, hscData){}
}