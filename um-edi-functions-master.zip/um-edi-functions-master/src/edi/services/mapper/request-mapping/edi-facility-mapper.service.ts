import {Injectable} from "@nestjs/common";
import {EdiUtilities} from "../../../edi-utilities";
import {EdiFacilityValidationService} from "../../validation/edi-facility-validation.service";
import {AppService} from "../../../../app.service";
import { HttpClient } from "@angular/common/http";

@Injectable()
export class EdiFacilityMapperService {

    constructor(protected readonly ediUtils: EdiUtilities,
                protected readonly ediFacilityValidationService: EdiFacilityValidationService,
                protected readonly appService: AppService,
                protected readonly http: HttpClient) {}

    mapFacilityData(event, hscData, sourceDataObject, serviceSettingType, requestDetails) {}
}

export class csvData{
    Attribute: any;
    statuscode: any;
    statusdescription: any;

    constructor(Attribute: String, statuscode: String, statusdescription: String){
        this.Attribute = Attribute;
        this.statuscode = statuscode;
        this.statusdescription = statusdescription;
    }
}
