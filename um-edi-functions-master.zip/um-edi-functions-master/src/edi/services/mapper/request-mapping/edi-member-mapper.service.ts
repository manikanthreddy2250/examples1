import {Injectable} from "@nestjs/common";
import {EdiUtilities} from "../../../edi-utilities";
import {EdiDataTransmissionHeaderMapperService} from "./edi-dataTransmissionHeader-mapper.service";
import {EdiMemberValidationService} from "../../validation/edi-member-validation.service";

@Injectable()
export class EdiMemberMapperService {

    constructor(protected readonly ediUtils: EdiUtilities,
                protected readonly ediMemberValidationService: EdiMemberValidationService) {}

    async mapMemberData(event, requestDetails, hscData) {}
}