import {Injectable} from "@nestjs/common";
import {EdiUtilities} from "../../../edi-utilities";
import {EdiMemberValidationService} from "../../validation/edi-member-validation.service";
import {EdiProviderValidationService} from "../../validation/edi-provider-validation.service";

@Injectable()
export class EdiProviderMapperService {

    constructor(protected readonly ediUtils: EdiUtilities,
                protected readonly ediProviderValidationService: EdiProviderValidationService) {}

    async mapProviderDomainData(event, requestDetails, facilityProviderSeqNum, ediType) {}


}