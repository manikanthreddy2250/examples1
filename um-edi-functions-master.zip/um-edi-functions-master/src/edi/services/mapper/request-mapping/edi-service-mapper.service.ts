import {Injectable} from "@nestjs/common";
import {EdiUtilities} from "../../../edi-utilities";
import {EdiServiceValidationService} from "../../validation/edi-service-validation.service";
import {AppService} from "../../../../app.service";

@Injectable()
export class EdiServiceMapperService {

    constructor(protected readonly ediUtils: EdiUtilities,
                protected readonly appService: AppService,
                protected readonly ediServiceValidationService: EdiServiceValidationService) {}


    mapServiceData(event, hscData, sourceDataObject, serviceSettingType, requestDetails, request, mapServiceData) {}
}