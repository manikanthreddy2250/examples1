import {Injectable} from "@nestjs/common";
import {EdiUtilities} from "../../../edi-utilities";
import {EdiResponseService} from "../../edi-response.service";
import {IndividualService} from "../../individual/individual.service";
import {ProviderService} from "../../provider/provider.service";
import {
    canonicalRequestTags,
    EdiServiceSettingTypeConstants,
    facilityAttributes,
    RequestDetails
} from "../../../constants/edi.constants";
import {EdiDiagnosisValidationService} from "../../validation/edi-diagnosis-validation.service";
import {EdiDataTransmissionHeaderValidationService} from "../../validation/edi-dataTransmissionHeader-validation.service";
import {EdiMemberValidationService} from "../../validation/edi-member-validation.service";
import {EdiProviderValidationService} from "../../validation/edi-provider-validation.service";
import {EdiFacilityValidationService} from "../../validation/edi-facility-validation.service";
import {AppService} from "../../../../app.service";
import {EdiDataTransmissionHeaderMapperService} from "./edi-dataTransmissionHeader-mapper.service";
import {EdiMemberMapperService} from "./edi-member-mapper.service";
import {EdiProviderMapperService} from "./edi-provider-mapper.service";
import {EdiDiagnosisMapperService} from "./edi-diagnosis-mapper.service";
import {EdiFacilityMapperService} from "./edi-facility-mapper.service";
import {EdiServiceMapperService} from "./edi-service-mapper.service";

@Injectable()
export class GenericMapperService {

    serviceSettingType;

    constructor(protected readonly ediUtils: EdiUtilities,
                protected readonly ediDataTransmissionHeaderMapperService: EdiDataTransmissionHeaderMapperService,
                protected readonly ediMemberMapperService: EdiMemberMapperService,
                protected readonly ediProviderMapperService: EdiProviderMapperService,
                protected readonly ediDiagnosisMapperService: EdiDiagnosisMapperService,
                protected readonly ediFacilityMapperService: EdiFacilityMapperService,
                protected readonly ediServiceMapperService: EdiServiceMapperService,
                protected readonly appService: AppService,
                protected readonly individualService: IndividualService,
                protected readonly providerService: ProviderService,
                protected readonly ediProviderValidationService: EdiProviderValidationService,
                protected readonly ediFacilityValidationService: EdiFacilityValidationService) {
    }

    async mapCanonicalRequest(canonicalRequest, requestDetails, hscID, request, ediType, translateToJson) {}

    getServiceSettingType(event, hscData) {
        let serviceSettingType;
        let refID;
        const facilityDetails = this.ediUtils.getElementInfo(event, canonicalRequestTags.FACILITY);

        if (facilityDetails) {
            const facilityCode = this.ediUtils.getAttributeValue(facilityDetails, facilityAttributes.FACILITYCODE);
            const facilityCodeQualifier = this.ediUtils.getAttributeValue(facilityDetails, facilityAttributes.FACILITYCODEQUALIFIER);

            if (facilityCode == '21' && facilityCodeQualifier == 'A') {
                //INPATIENT
                serviceSettingType = EdiServiceSettingTypeConstants.SERVICE_SETTING_INPATIENT;
            }

            //Get RefID of Service Setting Type
            const refDataResults = this.appService.getRefMatchDesc('serviceSettingType', serviceSettingType);
            if (refDataResults) {
                refID = refDataResults.ref_id;
                hscData.srvc_set_ref_id = refID;
            } else {
                //serviceSettingType does not exists in ref domain -set error
            }


        } else {
            //error?
        }
        return serviceSettingType;
    }


}