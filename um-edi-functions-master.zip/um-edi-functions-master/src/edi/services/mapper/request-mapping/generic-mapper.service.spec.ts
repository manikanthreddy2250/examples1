import {Test, TestingModule} from '@nestjs/testing';
import {HttpService, Injectable} from "@nestjs/common";
import {GenericMapperService} from "./generic-mapper-service";
import {EdiUtilities} from "../../../edi-utilities";
import {IndividualService} from "../../individual/individual.service";
import {ProviderService} from "../../provider/provider.service";
import {EdiMemberValidationService} from "../../validation/edi-member-validation.service";
import {EdiProviderValidationService} from "../../validation/edi-provider-validation.service";
import {EdiDataTransmissionHeaderValidationService} from "../../validation/edi-dataTransmissionHeader-validation.service";
import {EdiDiagnosisValidationService} from "../../validation/edi-diagnosis-validation.service";
import {EdiFacilityValidationService} from "../../validation/edi-facility-validation.service";
import {EdiServiceMapperService} from "./edi-service-mapper.service";
import {EdiProviderMapperService} from "./edi-provider-mapper.service";
import {EdiDiagnosisMapperService} from "./edi-diagnosis-mapper.service";
import {EdiFacilityMapperService} from "./edi-facility-mapper.service";
import {EdiDataTransmissionHeaderMapperService} from "./edi-dataTransmissionHeader-mapper.service";
import {EdiMemberMapperService} from "./edi-member-mapper.service";
import {AppService} from "../../../../app.service";
import {EdiServiceValidationService} from "../../validation/edi-service-validation.service";
import {ConfigService} from "@nestjs/config";
import {HealthServiceClient} from "../../../../shared/graphql/healthservicedomain/healthServiceClient";
import {HealthServiceService} from "../../healthService/healthService.service";
import { HttpModule } from '@nestjs/common';
import { Observable } from 'rxjs';
import { AxiosResponse } from 'axios';
import {testCanonicalRequest} from "../../../../../test/ediTestData";
import {canonicalRequestTags} from "../../../constants/edi.constants";
import {HttpClient} from "@angular/common/http";

@Injectable()
class IndividualServiceMock {
}

@Injectable()
class ProviderServiceMock {
}

@Injectable()
class EdiDiagnosisValidationServiceMock {
}

@Injectable()
class EdiDataTransmissionHeaderValidationServiceMock {
}

@Injectable()
class EdiMemberValidationServiceMock {
}

@Injectable()
class EdiProviderValidationServiceMock {
}

@Injectable()
class EdiFacilityValidationServiceMock {
}

@Injectable()
class AppServiceMock {
    getRefMatchCode(baseRefName, refCode) {
        return "123";
    }

    getRefMatchDesc(baseRefName, refCode) {
        return "123";
    }
}


describe('GenericMapperService', () => {
    let service: GenericMapperService;
    let ediUtilities: EdiUtilities;
    let event = null;
    const hscData = {
        hsc_id: 1,
        indv_key_typ_ref_id: null,
        indv_key_val: null,
        srvc_set_ref_id: 3737,
        rev_prr_ref_id: 3754,
        flwup_cntc_dtl: null,
        hsc_srvcs: new Array(),
        hsr_notes: null
    };

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            imports:[HttpModule],
            providers: [GenericMapperService, EdiUtilities, HttpClient, EdiDataTransmissionHeaderMapperService, EdiMemberMapperService, EdiProviderMapperService, EdiDiagnosisMapperService,
                {provide: AppService, useClass: AppServiceMock},
                EdiFacilityMapperService, EdiServiceMapperService, EdiDataTransmissionHeaderValidationService, EdiMemberValidationService,
                EdiDiagnosisValidationService, EdiServiceValidationService, ConfigService, HealthServiceClient, HealthServiceService,
                {provide: IndividualService, useClass: IndividualServiceMock},
                {provide: ProviderService, useClass: ProviderServiceMock},
                {provide: EdiProviderValidationService, useClass: EdiProviderValidationServiceMock},
                {provide: EdiFacilityValidationService, useClass: EdiFacilityValidationServiceMock}],

        }).compile();

        service = module.get<GenericMapperService>(GenericMapperService);
        ediUtilities =  module.get<EdiUtilities>(EdiUtilities);
        event = ediUtilities.getElementInfo(testCanonicalRequest, canonicalRequestTags.EVENT);
    });

    it('should be defined', () => {
        expect(service).toBeDefined();
    });

    it('should run #getServiceSettingType()', async () => {
        var appService = new AppServiceMock();
        spyOn(appService, 'getRefMatchDesc').and.callThrough();
        service.getServiceSettingType(event, hscData);
        expect(service).toBeTruthy();
    });

});
