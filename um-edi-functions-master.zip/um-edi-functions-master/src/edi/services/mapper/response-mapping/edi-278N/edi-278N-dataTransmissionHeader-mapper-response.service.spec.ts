import {EdiUtilities} from "../../../../edi-utilities";
import {Edi278NDataTransmissionHeaderMapperResponseService} from "./edi-278N-dataTransmissionHeader-mapper-response.service";
import {Test, TestingModule} from "@nestjs/testing";
import {ConfigService} from "@nestjs/config";
import {data} from "browserslist";

describe('Edi278NDataTransmissionHeaderMapperResponseService', () => {
    let service: Edi278NDataTransmissionHeaderMapperResponseService;
    let ediUtilities: EdiUtilities;

    const responseDetails = {
        "canonicalResponse": {
            $: {
                dataPropSourceType: null,
                //  transactionID: transactionID,
                version: null,
                batchFileID: null,
                receivedDateTime: null,
                purposeCode: null,
                transactionStatus: null,
                testFlag: null,
                clinicalApplication: null,
                payerID: null,
                submitterID: null,
                ediID: null
            }
        }
    };

    const data = {
        "dataTransmissionHeader": {
            "sourceType": "278",
            "transactionID": "4444415944446333",
            "version": 1,
            "batchFileID": null,
            "receivedDateTime": "2021-03-02T01:04:17.897Z",
            "purposeCode": "CN",
            "transactionType": "NO",
            "transactionStatus": "RECEIVED",
            "testFlag": "L",
            "clinicalApplication": "HSR",
            "payerID": "87726",
            "submitterID": "",
            "ediID": 15067,
            "sourceData": "<ns1:loopID xmlns:ns1=\"http://authref278.transaction.b2b.uhg.com\">2000A</ns1:loopID>            <ns2:x12278 xmlns:ns2=\"http://authref278.transaction.b2b.uhg.com\">ISA*00*          *00*          *ZZ*B09080111864   *01*87726          *091116*0715*^*00501*000000432*0*T*:~GS*HI*B09080111864*87726*20091116*0715*278001*X*005010X216~ST*278*0015*005010X216~BHT*0007*CN*21969556*20150729*0715*NO~HL*1**20*1~NM1*FA*2*USC KENNETH NORRIS JR CANCER HOSPITAL*****XX*1770728438~N3*1441 EASTLAKE AVE~N4*LOS ANGELES*CA*90033~PER*IC*IAS*TE*3238653000~HL*2*1*21*1~NM1*PR*2*UNITEDHEALTHCARE*****PI*87726~HL*3*2*22*1~NM1*IL*1*STEPHENS*REBECCA****MI*00240239029~REF*6P*0752126~DMG*D8*19631008*F~HL*4*3*EV*1~UM*AR*I*2*21:B**U~DTP*435*D8*20200402~HI*ABK:M54.16~CL1*1~MSG*DC=4~NM1*FA*2*USC KENNETH NORRIS JR CANCER HOSPITAL*****XX*1770728438~N3*1441 EASTLAKE AVE~N4*LOS ANGELES*CA*90033~PER*IC*IAS*TE*3238653000~NM1*71*1*Abston*Anthony****24*631169804~PER*IC**TE*9416807000~HL*5*4*SS*0~UM*HS*I*2*21:B~DTP*472*D8*20200402~SV2**HC:28111~NM1*SJ*1*MANDARANO*CARMINE****24*113160339~N3*281 E MAIN ST~N4*EAST ISLIP*NY*11730~PER*IC*IAS*TE*6312243625~SE*34*0015~GE*1*278001~IEA*1*000000432~</ns2:x12278>",
            "tradingPartnerID": null
        },
        "hscResponse":{
            "hsc_id": 15067,
            "hsc_keys": [
                {
                    "hsc_key_typ_ref_id": 72143,
                    "hsc_key_val": "4444415944446591"
                }
            ]
        },
        "Error": {
            "dataTransmissionHeader": [
                {
                    "errorCode": "20201",
                    "errorDescription": "Testing dataTransheader error response.",
                    "errorLoop": "2010A",
                    "followupActionCode": "C",
                    "reasonRejectCode": "44"
                }
            ]
        }
    };

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers:[Edi278NDataTransmissionHeaderMapperResponseService, EdiUtilities, ConfigService] }).compile();

        service = module.get<Edi278NDataTransmissionHeaderMapperResponseService>(Edi278NDataTransmissionHeaderMapperResponseService);
        ediUtilities = module.get<EdiUtilities>(EdiUtilities);
    });

    it('should be defined', () => {
        expect(service).toBeDefined();
    });

    it('should run #mapDataTransmissionHeader()', async () => {
        service.mapDataTransmissionHeader(data, responseDetails);
        expect(service).toBeTruthy();
    });

    it('should run #mapErrors()', async () => {
        service.mapErrors(data);
        expect(service).toBeTruthy();
    });

});