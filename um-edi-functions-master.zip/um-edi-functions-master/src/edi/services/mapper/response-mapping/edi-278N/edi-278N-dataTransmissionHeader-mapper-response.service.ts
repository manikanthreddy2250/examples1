import {Injectable} from "@nestjs/common";
import {EdiDataTransmissionHeaderMapperResponseService} from "../edi-dataTransmissionHeader-mapper-response.service";


@Injectable()
export class Edi278NDataTransmissionHeaderMapperResponseService extends EdiDataTransmissionHeaderMapperResponseService {

    mapDataTransmissionHeader(data, responseDetails) {
        console.log("data.dataTransmissionHeader: " + JSON.stringify(data.dataTransmissionHeader));
        try {
            if (data.dataTransmissionHeader) {
                const sourceType = data.dataTransmissionHeader.sourceType;
                if(data.hscResponse && data.hscResponse.hsc_keys) {
                    var transactionID = data.hscResponse.hsc_keys[0].hsc_key_val != null ? data.hscResponse.hsc_keys[0].hsc_key_val : null;
                }
                const version = data.dataTransmissionHeader.version;
                const batchFileID = data.dataTransmissionHeader.batchFileID;
                const receivedDateTime = data.dataTransmissionHeader.receivedDateTime;
                const purposeCode = data.dataTransmissionHeader.purposeCode;
                const transactionStatus = data.dataTransmissionHeader.transactionStatus;
                const testFlag = data.dataTransmissionHeader.testFlag;
                const clinicalApplication = data.dataTransmissionHeader.clinicalApplication;
                const payerID = data.dataTransmissionHeader.payerID;
                const submitterID = data.dataTransmissionHeader.submitterID;
                const ediID = data.dataTransmissionHeader.ediID;
                const sourceData = data.dataTransmissionHeader.sourceData;
                const errors = this.mapErrors(data);

                if(errors) {
                    responseDetails.canonicalResponse.dataTransmissionHeader =
                        [
                            {
                                '$': {
                                    dataPropSourceType: sourceType,
                                    transactionID: transactionID,
                                    version: version,
                                    batchFileID: batchFileID,
                                    receivedDateTime: receivedDateTime,
                                    purposeCode: purposeCode,
                                    transactionStatus: transactionStatus,
                                    testFlag: testFlag,
                                    clinicalApplication: clinicalApplication,
                                    payerID: payerID,
                                    submitterID: submitterID,
                                    ediID: ediID
                                },
                                "sourceData": sourceData,
                                "errors": errors != null ? [errors] : null
                            }
                        ];
                }else{
                    responseDetails.canonicalResponse.dataTransmissionHeader =
                        [
                            {
                                '$': {
                                    dataPropSourceType: sourceType,
                                    transactionID: transactionID,
                                    version: version,
                                    batchFileID: batchFileID,
                                    receivedDateTime: receivedDateTime,
                                    purposeCode: purposeCode,
                                    transactionStatus: transactionStatus,
                                    testFlag: testFlag,
                                    clinicalApplication: clinicalApplication,
                                    payerID: payerID,
                                    submitterID: submitterID,
                                    ediID: ediID
                                },
                                "sourceData": sourceData
                            }
                        ];
                }
            }
        } catch (err) {
            console.log("error mapDataTransmissionHeader: " + err)
        }
    }

    mapErrors(data) {
        const errorArray = [];
        let i: number;

        try {
            const errorData = data.Error.dataTransmissionHeader;

            if (errorData) {
                for (i = 0; i < errorData.length; i++) {
                    const errorCode = errorData[i].errorCode;
                    const errorDescription = errorData[i].errorDescription;
                    const errorLoop = errorData[i].errorLoop;
                    const followupActionCode = errorData[i].followupActionCode;
                    const reasonRejectCode = errorData[i].reasonRejectCode;

                    const errors = {
                        "error": {
                            '$': {
                                errorCode: errorCode,
                                errorDescription: errorDescription,
                                errorLoop: errorLoop,
                                followupActionCode: followupActionCode,
                                reasonRejectCode: reasonRejectCode
                            }
                        }
                    };
                    errorArray.push(errors);

                }
            }
            return errorArray;
        } catch (err) {}
    }

}