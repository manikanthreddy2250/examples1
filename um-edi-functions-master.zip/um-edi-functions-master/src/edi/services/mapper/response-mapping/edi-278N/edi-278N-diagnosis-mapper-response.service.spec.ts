import {EdiUtilities} from "../../../../edi-utilities";
import {Test, TestingModule} from "@nestjs/testing";
import {ConfigService} from "@nestjs/config";
import {Edi278NDiagnosisMapperResponseService} from "./edi-278N-diagnosis-mapper-response.service";
import {data} from "browserslist";
import {testCanonicalRequest} from "../../../../../../test/ediTestData";

describe('Edi278NDiagnosisMapperResponseService', () => {
    let service: Edi278NDiagnosisMapperResponseService;
    let ediUtilities: EdiUtilities;

    const responseDetails = {
        "canonicalResponse": {
            $: {
                diagnosisSeqNum: null,
                diagnosisCodeType: null,
                diagnosisCode: null,
            }
        }
    };

    const eventData = {
        "diagnosis": {
            $: {
                diagnosisSeqNum: "1",
                diagnosisCodeType: "ABF",
                diagnosisCode: "M54.16",
            },
            sourceData: "<ns9:loopID xmlns:ns9=\"http://authref278.transaction.b2b.uhg.com\">2000E</ns9:loopID>"
        }
    };

    const data = {
        "Diagnosis": [
            {
                "diagnosisSeqNum": "1",
                "diagnosisCodeType": "ABF",
                "diagnosisCode": "M54.16"
            },
            {
                "diagnosisSeqNum": "2",
                "diagnosisCodeType": "ABK",
                "diagnosisCode": "A01.01"
            }
        ],
        "hscSourceData": {
            "diagnosis": [
                "<ns9:loopID xmlns:ns9=\"http://authref278.transaction.b2b.uhg.com\">2000E</ns9:loopID>",
                "<ns9:loopID xmlns:ns9=\"http://authref278.transaction.b2b.uhg.com\">2000E</ns9:loopID>"
            ],
            "facility": "<ns10:loopID xmlns:ns10=\"http://authref278.transaction.b2b.uhg.com\">2000E</ns10:loopID>",
            "service": [
                "<ns11:loopID xmlns:ns11=\"http://authref278.transaction.b2b.uhg.com\">2000F</ns11:loopID>"
            ],
            "followUpContact": "<ns7:loopID xmlns:ns7=\"http://authref278.transaction.b2b.uhg.com\">2010A</ns7:loopID>"
        },
        "Error": {
            "diagnosis": [
                {
                    "errorCode": "20201",
                    "errorDescription": "Testing diag 1 error response.",
                    "errorLoop": "2010A",
                    "followupActionCode": "C",
                    "reasonRejectCode": "44"
                },
                {
                    "errorCode": "20201",
                    "errorDescription": "Testing diag 2 error response.",
                    "errorLoop": "2010A",
                    "followupActionCode": "C",
                    "reasonRejectCode": "44"
                }
            ]
        }
    };


    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [Edi278NDiagnosisMapperResponseService, EdiUtilities, ConfigService]
        }).compile();

        service = module.get<Edi278NDiagnosisMapperResponseService>(Edi278NDiagnosisMapperResponseService);
        ediUtilities = module.get<EdiUtilities>(EdiUtilities);
    });

    it('should be defined', () => {
        expect(service).toBeDefined();
    });

    it('should run #mapDiagnosisData()', async () => {
        spyOn(service, 'mapErrors').and.callFake(function () {});
        service.mapDiagnosisData(data, eventData, responseDetails);
        expect(service).toBeTruthy();
    });

    it('should run #mapErrors()', async () => {
        service.mapErrors(data);
        expect(service).toBeTruthy();
    });

})