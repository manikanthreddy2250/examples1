import {Injectable} from "@nestjs/common";
import {EdiDiagnosisMapperResponseService} from "../edi-diagnosis-mapper-response.service";

@Injectable()
export class Edi278NDiagnosisMapperResponseService extends EdiDiagnosisMapperResponseService {


    mapDiagnosisData(data, eventData, responseDetails) {
        const diagnosis = [];
        let i: number;

        try {
            const diagnosisData = data.Diagnosis;
            if (diagnosisData) {
                for (i = 0; i < diagnosisData.length; i++) {
                    var diagnosisSeqNum = diagnosisData[i].diagnosisSeqNum;
                    var diagnosisCodeType = diagnosisData[i].diagnosisCodeType;
                    var diagnosisCode = diagnosisData[i].diagnosisCode;
                    var sourceData = data.hscSourceData.diagnosis[i];
                    if (data.Error) {
                        var errors = this.mapErrors(data.Error.diagnosis[i]);
                    }

                    if (errors) {
                        const diagData = {
                            "diagnosis": {
                                '$': {
                                    diagnosisSeqNum: diagnosisSeqNum,
                                    diagnosisCodeType: diagnosisCodeType,
                                    diagnosisCode: diagnosisCode,
                                },
                                "sourceData": sourceData,
                                "errors": [errors]
                            }
                        };
                        diagnosis.push(diagData);
                    } else {
                        const diagData = {
                            "diagnosis": {
                                '$': {
                                    diagnosisSeqNum: diagnosisSeqNum,
                                    diagnosisCodeType: diagnosisCodeType,
                                    diagnosisCode: diagnosisCode,
                                },
                                "sourceData": sourceData
                            }
                        };
                        diagnosis.push(diagData);
                    }
                }
                if (diagnosis) {
                    eventData["diagnoses"] = [diagnosis];
                }
            }
        }

        catch (err) {
            console.log("error mapDiagnosisData: " + err);
        }
    }

    mapErrors(errorData) {
        const errorArray = [];
        let i: number;

        try {

            if (errorData) {
                const errorCode = errorData.errorCode;
                const errorDescription = errorData.errorDescription;
                const errorLoop = errorData.errorLoop;
                const followupActionCode = errorData.followupActionCode;
                const reasonRejectCode = errorData.reasonRejectCode;

                const errors = {
                    "error": {
                        '$': {
                            errorCode: errorCode,
                            errorDescription: errorDescription,
                            errorLoop: errorLoop,
                            followupActionCode: followupActionCode,
                            reasonRejectCode: reasonRejectCode
                        }
                    }
                };
                errorArray.push(errors);
            }
            return errorArray;
        } catch (err) {
        }
    }

}

