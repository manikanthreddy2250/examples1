import {EdiUtilities} from "../../../../edi-utilities";
import {Test, TestingModule} from "@nestjs/testing";
import {ConfigService} from "@nestjs/config";
import {data} from "browserslist";
import {Edi278NFacilityMapperResponseService} from "./edi-278N-facility-mapper-response.service";

describe('Edi278NFacilityMapperResponseService', () => {
    let service: Edi278NFacilityMapperResponseService;
    let ediUtilities: EdiUtilities;

    const responseDetails = {
        "canonicalResponse": {
            $: {
                admissionDate: null,
                dischargeDate: null,
                facilityProviderSeqNum: null,
                serviceReferenceNum: null,
            }
        }
    };

    const data = {
        "Facility": {
            "requestCategory": "AR",
            "certificationType": "I",
            "admissionDate": "2021-02-20",
            "dischargeDate": "2021-02-20",
            "facilityProviderSeqNum": "2",
            "serviceReferenceNum": "test123"
        },
        "hscSourceData": {
            "diagnosis": [
                "<ns9:loopID xmlns:ns9=\"http://authref278.transaction.b2b.uhg.com\">2000E</ns9:loopID>",
                "<ns9:loopID xmlns:ns9=\"http://authref278.transaction.b2b.uhg.com\">2000E</ns9:loopID>"
            ],
            "facility": "<ns10:loopID xmlns:ns10=\"http://authref278.transaction.b2b.uhg.com\">2000E</ns10:loopID>",
            "service": [
                "<ns11:loopID xmlns:ns11=\"http://authref278.transaction.b2b.uhg.com\">2000F</ns11:loopID>"
            ],
            "followUpContact": "<ns7:loopID xmlns:ns7=\"http://authref278.transaction.b2b.uhg.com\">2010A</ns7:loopID>"
        },
        "Error": {
            "facility":[
                {
                    "errorCode": "20201",
                    "errorDescription": "Testing facility error response.",
                    "errorLoop": "2010A",
                    "followupActionCode": "C",
                    "reasonRejectCode": "44"
                }
            ]
        }
    };

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [Edi278NFacilityMapperResponseService, EdiUtilities, ConfigService]
        }).compile();

        service = module.get<Edi278NFacilityMapperResponseService>(Edi278NFacilityMapperResponseService);
        ediUtilities = module.get<EdiUtilities>(EdiUtilities);
    });

    it('should be defined', () => {
        expect(service).toBeDefined();
    });

    it('should run #mapFacilityData()', async () => {
        service.mapFacilityData(data, responseDetails);
        spyOn(service, 'mapErrors').and.callFake(function () {});
        expect(service).toBeTruthy();
    });

    it('should run #mapErrors()', async () => {
        service.mapErrors(data);
        expect(service).toBeTruthy();
    });


})