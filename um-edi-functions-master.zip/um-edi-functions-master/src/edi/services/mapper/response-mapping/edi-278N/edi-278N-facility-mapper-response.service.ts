import {Injectable} from "@nestjs/common";
import {EdiFacilityMapperResponseService} from "../edi-facility-mapper-response.service";

@Injectable()
export class Edi278NFacilityMapperResponseService extends EdiFacilityMapperResponseService {

    mapFacilityData(data, eventData){

        try {
            var expt_admis_dt = data.Facility.admissionDate;
            var expt_dschrg_dt = data.Facility.dischargeDate;
            var prov_role_ref_id = data.Facility.facilityProviderSeqNum;
            var srvc_dtl_ref_id = data.Facility.serviceReferenceNum;
            var sourceData = data.hscSourceData.facility;
            const errors = this.mapErrors(data);

            if(errors){
                const facility =
                    [
                        {
                            '$': {
                                admissionDate: expt_admis_dt,
                                dischargeDate: expt_dschrg_dt,
                                facilityProviderSeqNum: prov_role_ref_id,
                                serviceReferenceNum: srvc_dtl_ref_id
                            },
                            "sourceData": sourceData,
                            "errors": errors != null ? [errors] : null
                        }
                    ];

                if (facility) {
                    eventData["facility"] = facility;
                }
            }else{
                const facility =
                    [
                        {
                            '$': {
                                admissionDate: expt_admis_dt,
                                dischargeDate: expt_dschrg_dt,
                                facilityProviderSeqNum: prov_role_ref_id,
                                serviceReferenceNum: srvc_dtl_ref_id
                            },
                            "sourceData": sourceData
                        }
                    ];

                if (facility) {
                    eventData["facility"] = facility;
                }
            }

        }catch (err) {
            console.log("error mapFacilityData: " + err);
        }
    }


    mapErrors(data) {
        const errorArray = [];
        let i: number;

        try {
            const errorData = data.Error.facility;

            if (errorData) {
                for (i = 0; i < errorData.length; i++) {
                    const errorCode = errorData[i].errorCode;
                    const errorDescription = errorData[i].errorDescription;
                    const errorLoop = errorData[i].errorLoop;
                    const followupActionCode = errorData[i].followupActionCode;
                    const reasonRejectCode = errorData[i].reasonRejectCode;

                    const errors = {
                        "error": {
                            '$': {
                                errorCode: errorCode,
                                errorDescription: errorDescription,
                                errorLoop: errorLoop,
                                followupActionCode: followupActionCode,
                                reasonRejectCode: reasonRejectCode
                            }
                        }
                    };
                    errorArray.push(errors);
                }
            }
            return errorArray;
        } catch (err) {}
    }
}