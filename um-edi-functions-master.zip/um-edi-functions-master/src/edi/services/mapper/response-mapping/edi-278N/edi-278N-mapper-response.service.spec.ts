import {EdiUtilities} from "../../../../edi-utilities";
import {Test, TestingModule} from "@nestjs/testing";
import {ConfigService} from "@nestjs/config";
import {Edi278NMapperResponseService} from "./edi-278N-mapper-response.service";
import {testCanonicalRequest} from "../../../../../../test/ediTestData";
import {Injectable} from "@nestjs/common";
import {Edi278NDataTransmissionHeaderMapperResponseService} from "./edi-278N-dataTransmissionHeader-mapper-response.service";
import {canonicalRequestTags} from "../../../../constants/edi.constants";
import {Edi278NDiagnosisMapperResponseService} from "./edi-278N-diagnosis-mapper-response.service";
import {Edi278NFacilityMapperResponseService} from "./edi-278N-facility-mapper-response.service";
import {Edi278NProviderMapperResponseService} from "./edi-278N-provider-mapper-response.service";
import {Edi278NServiceMapperResponseService} from "./edi-278N-service-mapper-response.service";
import {Edi278NMemberMapperResponseService} from "./edi-278N-member-mapper-response.service";

@Injectable()
class edi278NDataTransmissionHeaderMapperServiceMock {
    mapDataTransmissionHeader(data, responseDetails) {

    }
}

@Injectable()
class Edi278NMemberMapperServiceMock {
    mapMemberData(event, requestDetails, hscData) {

    }
}

@Injectable()
class Edi278NProviderMapperServiceMock {
    mapProviderDomainData(event, requestDetails) {

    }
}

@Injectable()
class Edi278NDiagnosisMapperServiceMock{
    mapHscDiagnosisData(canonicalRequest, hscData, sourceDataObject, request, requestDetails) {

    }
}

@Injectable()
class Edi278NFacilityMapperServiceMock {
    mapFacilityData(event, hscData, sourceDataObject, serviceSettingType, requestDetails) {

    }
}

@Injectable()
class Edi278NServiceMapperServiceMock {
    mapServiceData(event, hscData, sourceDataObject, serviceSettingType, requestDetails, request) {

    }
}

    const data = {
        "followUpContact":[
            {
                "errorCode": "20201",
                "errorDescription": "Testing followUpContact error response.",
                "errorLoop": "2010A",
                "followupActionCode": "C",
                "reasonRejectCode": "44"
            }
        ],
        "hscSourceData": {
            "diagnosis": [
                "<ns9:loopID xmlns:ns9=\"http://authref278.transaction.b2b.uhg.com\">2000E</ns9:loopID>",
                "<ns9:loopID xmlns:ns9=\"http://authref278.transaction.b2b.uhg.com\">2000E</ns9:loopID>"
            ],
            "facility": "<ns10:loopID xmlns:ns10=\"http://authref278.transaction.b2b.uhg.com\">2000E</ns10:loopID>",
            "service": [
                "<ns11:loopID xmlns:ns11=\"http://authref278.transaction.b2b.uhg.com\">2000F</ns11:loopID>"
            ],
            "followUpContact": "<ns7:loopID xmlns:ns7=\"http://authref278.transaction.b2b.uhg.com\">2010A</ns7:loopID>"
        },
        "Error": {
            "followUpContact":[
                {
                    "errorCode": "20201",
                    "errorDescription": "Testing followUpContact error response.",
                    "errorLoop": "2010A",
                    "followupActionCode": "C",
                    "reasonRejectCode": "44"
                }
            ]
        }
    };


const responseDetails = {
    "canonicalResponse": {
        $: {
            dataPropSourceType: null,
            //  transactionID: transactionID,
            version: null,
            batchFileID: null,
            receivedDateTime: null,
            purposeCode: null,
            transactionStatus: null,
            testFlag: null,
            clinicalApplication: null,
            payerID: null,
            submitterID: null,
            ediID: null
        }
    }
};

var hscResponse: any = {
    "data": {
        "updateHsc": {
            "hsc": [
                {
                    "hsc_id": 15067,
                    "hsc_diags": [
                        {
                            "hsc_diag_id": 4728,
                            "diag_cd": "M54.16",
                            "inac_ind": 0
                        }],
                    "hsc_keys":[
                        {
                            "hsc_key_typ_ref_id":72143
                        }
                    ]
                }
            ]
        }
    }
};




const followUpContactData = {
    "followUpContact": {
        $: {

            contactProviderSeqNum: null,
        },
        sourceData: "<ns8:loopID xmlns:ns8=\"http://authref278.transaction.b2b.uhg.com\">2010C</ns8:loopID>",
        errors: {
            "followUpContact":[
                {
                    "errorCode": "20201",
                    "errorDescription": "Testing followUpContact error response.",
                    "errorLoop": "2010A",
                    "followupActionCode": "C",
                    "reasonRejectCode": "44"
                }
            ]
        }
    }
};

describe('Edi278NMapperResponseService', () => {

    let service: Edi278NMapperResponseService;
    let ediUtilities: EdiUtilities;
    const dataTransMapperResponseService = new edi278NDataTransmissionHeaderMapperServiceMock();
    const memberMapperResponseService = new Edi278NMemberMapperServiceMock();
    const providerMapperResponseService = new Edi278NProviderMapperServiceMock();
    const diagnosisMapperResponseService = new Edi278NDiagnosisMapperServiceMock();
    const facilityMapperResponseService = new Edi278NFacilityMapperServiceMock();
    const serviceMapperResponseService = new Edi278NServiceMapperServiceMock();

    let event = null;

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [Edi278NMapperResponseService, EdiUtilities, ConfigService,
                {provide: Edi278NDataTransmissionHeaderMapperResponseService, useClass: edi278NDataTransmissionHeaderMapperServiceMock},
                {provide: Edi278NMemberMapperResponseService, useClass: Edi278NMemberMapperServiceMock},
                {provide: Edi278NDiagnosisMapperResponseService, useClass: Edi278NDiagnosisMapperServiceMock},
                {provide: Edi278NFacilityMapperResponseService, useClass: Edi278NFacilityMapperServiceMock},
                {provide: Edi278NProviderMapperResponseService, useClass: Edi278NProviderMapperServiceMock},
                {provide: Edi278NServiceMapperResponseService   , useClass: Edi278NServiceMapperServiceMock},

            ]
        }).compile();

        service = module.get<Edi278NMapperResponseService>(Edi278NMapperResponseService);
        ediUtilities = module.get<EdiUtilities>(EdiUtilities);
    });

    it('should be defined', () => {
        expect(service).toBeDefined();
    });

    it('should run #mapCanonicalResponse()', async () => {
        spyOn(service, 'mapfollowUpContact').and.returnValue("followUpContact");
        let result = service.mapfollowUpContact(data, followUpContactData);
        expect(result).toContain('followUpContact');

        service.mapCanonicalResponse(data, responseDetails);
        expect(service).toBeTruthy();
    });

 /*   it('should run #mapEventData()', async () => {
        service.mapEventData(data, responseDetails, hscResponse);
        expect(service).toBeTruthy();
    });
*/
    it('should run #mapfollowUpContact()', async () => {
        service.mapfollowUpContact(data, followUpContactData);
        spyOn(service, 'mapFollowUpContactErrors').and.callFake(function () {});
        expect(service).toBeTruthy();
    });

    it('should run #mapFollowUpContactErrors()', async () => {
        service.mapFollowUpContactErrors(data);
        expect(service).toBeTruthy();
    });
})