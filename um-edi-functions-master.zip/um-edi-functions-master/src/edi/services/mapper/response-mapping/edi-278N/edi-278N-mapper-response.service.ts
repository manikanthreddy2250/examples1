import {Injectable} from "@nestjs/common";
import {GenericMapperResponseService} from "../generic-mapper-response.service";
import {EdiUtilities} from "../../../../edi-utilities";
import {Edi278NDataTransmissionHeaderMapperResponseService} from "./edi-278N-dataTransmissionHeader-mapper-response.service";
import {Edi278NMemberMapperResponseService} from "./edi-278N-member-mapper-response.service";
import {Edi278NDiagnosisMapperResponseService} from "./edi-278N-diagnosis-mapper-response.service";
import {Edi278NFacilityMapperResponseService} from "./edi-278N-facility-mapper-response.service";
import {Edi278NProviderMapperResponseService} from "./edi-278N-provider-mapper-response.service";
import {Edi278NServiceMapperResponseService} from "./edi-278N-service-mapper-response.service";

@Injectable()
export class Edi278NMapperResponseService extends GenericMapperResponseService {

    constructor(ediUtils: EdiUtilities,
                protected readonly edi278NDataTransmissionHeaderMapperResponseService: Edi278NDataTransmissionHeaderMapperResponseService,
                protected readonly edi278NMemberMapperResponseService: Edi278NMemberMapperResponseService,
                protected readonly edi278DiagnosisMapperResponseService: Edi278NDiagnosisMapperResponseService,
                protected readonly edi278NFacilityMapperResponseService: Edi278NFacilityMapperResponseService,
                protected readonly edi278NProviderMapperResponseService: Edi278NProviderMapperResponseService,
                protected readonly edi278NServiceMapperResponseService: Edi278NServiceMapperResponseService,) {

        super(ediUtils, edi278NDataTransmissionHeaderMapperResponseService, edi278NMemberMapperResponseService, edi278DiagnosisMapperResponseService);
    }

   async mapCanonicalResponse(data, responseDetails) {
        try {
            this.edi278NDataTransmissionHeaderMapperResponseService.mapDataTransmissionHeader(data, responseDetails);
            this.mapEventData(data, responseDetails);

        } catch (err) {
        }
        return responseDetails;
    }

    mapEventData(data, responseDetails) {

        try {
            // const idCode = data.Event.idCode;
            // const reviewIdDesc = data.Event.reviewIdDesc;
            // const reportTypeCode = data.Event.reportTypeCode;
            // const reportTransmissionCode = data.Event.reportTransmissionCode;
            // const idCodeQualifier = data.Event.idCodeQualifier;
            const accidentDate = data.Event.accidentDate;
            const note = data.Event.note;
            const createTime = data.Event.createTime;
            const createDate = data.Event.createDate;
            var actionCode = data.Service[0].actionCode;

            const event = {
                '$': {
                    actionCode: actionCode,
                    // idCode: idCode,
                    // reviewIdDesc: reviewIdDesc,
                    // reportTypeCode: reportTypeCode,
                    // reportTransmissionCode: reportTransmissionCode,
                    // idCodeQualifier: idCodeQualifier,
                    accidentDate: accidentDate,
                    note: note,
                    createTime: createTime,
                    createDate: createDate,
                    member: null
                }
            };

            this.edi278NProviderMapperResponseService.mapProviderData(data, responseDetails, event);
            this.mapfollowUpContact(data, event);
            this.edi278NMemberMapperResponseService.mapMemberData(data, event, responseDetails);
            this.ediDiagnosisMapperResponseService.mapDiagnosisData(data, event, responseDetails);
            this.edi278NFacilityMapperResponseService.mapFacilityData(data, event);
            this.edi278NServiceMapperResponseService.mapServiceData(data, event, responseDetails);

            if (event) {
                responseDetails.canonicalResponse.event = event;
            }

        } catch (err) {
            console.log("error mapEventData: " + err)
        }
    }

    mapfollowUpContact(data, event) {

        try {
            var prov_role_ref_id = data.followUpContact.prov_role_ref_id;
            var sourceData = data.followUpContact.sourceData;
            const errors = this.mapFollowUpContactErrors(data);

            if(errors){
                var followUpContact =
                    [
                        {
                            '$': {
                                contactProviderSeqNum: prov_role_ref_id
                            },
                            "sourceData": sourceData,
                            "errors": errors != null ? [errors] : null
                        }
                    ];
                if (followUpContact) {
                    event.followUpContact = followUpContact;
                }
            }else{
                var followUpContactSuccess =
                    [
                        {
                            '$': {
                                contactProviderSeqNum: prov_role_ref_id
                            },
                            "sourceData": sourceData
                        }
                    ];
                if (followUpContactSuccess) {
                    event.followUpContact = followUpContactSuccess;
                }
            }

            if (followUpContact) {
                event.followUpContact = followUpContact;
            }

        } catch (err) {
            console.log("error mapfollowUpContact: " + err)
        }
    }

    mapFollowUpContactErrors(data) {
        const errorArray = [];
        let i: number;

        try {
            const errorData = data.Error.followUpContact;

            if (errorData) {
                for (i = 0; i < errorData.length; i++) {
                    const errorCode = errorData[i].errorCode;
                    const errorDescription = errorData[i].errorDescription;
                    const errorLoop = errorData[i].errorLoop;
                    const followupActionCode = errorData[i].followupActionCode;
                    const reasonRejectCode = errorData[i].reasonRejectCode;

                    const errors = {
                        "error": {
                            '$': {
                                errorCode: errorCode,
                                errorDescription: errorDescription,
                                errorLoop: errorLoop,
                                followupActionCode: followupActionCode,
                                reasonRejectCode: reasonRejectCode
                            }
                        }
                    };
                    errorArray.push(errors);
                }
            }
            return errorArray;
        } catch (err) {}
    }
}