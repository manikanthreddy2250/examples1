import {Edi278NFacilityMapperResponseService} from "./edi-278N-facility-mapper-response.service";
import {EdiUtilities} from "../../../../edi-utilities";
import {Edi278NMemberMapperResponseService} from "./edi-278N-member-mapper-response.service";
import {Test, TestingModule} from "@nestjs/testing";
import {Edi278NProviderMapperResponseService} from "./edi-278N-provider-mapper-response.service";
import {ConfigService} from "@nestjs/config";
import {data} from "browserslist";

describe('Edi278NMemberMapperResponseService', () => {
    let service: Edi278NMemberMapperResponseService;
    let ediUtilities: EdiUtilities;

    const responseDetails = {
        "canonicalResponse": {
            $: {
                firstName: null,
                lastName: null,
                middleName: null,
                suffixName: null,
                birthDate: null,
                gender: null,
                subscriberFirstName: null,
                subscriberLastName: null,
                relationshipCode: null,
            }
        }
    };

    const eventData = {
        "provider": {
            $: {
                firstName: "Matt",
                lastName: "Meyer",
                middleName: null,
                suffixName: null,
                birthDate: "1978-07-26",
                gender: "M",
                subscriberFirstName: "Matt",
                subscriberLastName: "Meyer",
                relationshipCode: "1978-07-26",
            },
            memberAddress: "",
            memberIdentifiers: "",
            sourceData: "<ns8:loopID xmlns:ns8=\"http://authref278.transaction.b2b.uhg.com\">2010C</ns8:loopID>"
        }
    };

    const data = {
        "Membership": {
            "mbrshp": {
                "sbscr_fst_nm": "Matt",
                "sbscr_lst_nm": "Meyer",
                "sbscr_bth_dt": "1978-07-26",
                "sbscr_empmt_dt": null,
                "mbr_rel_ref_id": null,
                "scrbr_id_txt": "16440436900",
                "mbr_covs": [
                    {
                        "pol_nbr": null
                    }
                ]
            }
        },
        "Individual": {
            "indv": {
                "fst_nm": "Matt",
                "lst_nm": "Meyer",
                "midl_nm": null,
                "sufx_nm": null,
                "bth_dt": "1978-07-26",
                "gdr_ref_id": "M",
                "sourceData": "<ns8:loopID xmlns:ns8=\"http://authref278.transaction.b2b.uhg.com\">2010C</ns8:loopID>",
                "indv_adrs": []
            }
        },
        "hscSourceData": {
            "diagnosis": [
                "<ns9:loopID xmlns:ns9=\"http://authref278.transaction.b2b.uhg.com\">2000E</ns9:loopID>",
                "<ns9:loopID xmlns:ns9=\"http://authref278.transaction.b2b.uhg.com\">2000E</ns9:loopID>"
            ],
            "facility": "<ns10:loopID xmlns:ns10=\"http://authref278.transaction.b2b.uhg.com\">2000E</ns10:loopID>",
            "service": [
                "<ns11:loopID xmlns:ns11=\"http://authref278.transaction.b2b.uhg.com\">2000F</ns11:loopID>"
            ],
            "followUpContact": "<ns7:loopID xmlns:ns7=\"http://authref278.transaction.b2b.uhg.com\">2010A</ns7:loopID>"
        },
        "Error": {
            "member":[
                {
                    "errorCode": "20201",
                    "errorDescription": "Testing member error response.",
                    "errorLoop": "2010A",
                    "followupActionCode": "C",
                    "reasonRejectCode": "44"
                }
            ]
        }
    };

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [Edi278NMemberMapperResponseService, EdiUtilities, ConfigService]
        }).compile();

        service = module.get<Edi278NMemberMapperResponseService>(Edi278NMemberMapperResponseService);
        ediUtilities = module.get<EdiUtilities>(EdiUtilities);
    });

    it('should be defined', () => {
        expect(service).toBeDefined();
    });

    it('should run #mapMemberData()', async () => {
        spyOn(service, 'mapErrors').and.callFake(function () {});
        service.mapMemberData(data, eventData, responseDetails);
        expect(service).toBeTruthy();
    });

    it('should run #mapErrors()', async () => {
        service.mapErrors(data);
        expect(service).toBeTruthy();
    });

})