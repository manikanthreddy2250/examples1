import {Injectable} from "@nestjs/common";
import {EdiMemberMapperResponseService} from "../edi-member-mapper-response.service";

@Injectable()
export class Edi278NMemberMapperResponseService extends EdiMemberMapperResponseService {


    mapMemberData(data, eventData, responseDetails) {
        const memberAddr = [];
        const memberIdentifiers = [];
        try {
            //------------------------------INDIVIDUAL------------------------------//
            if (data.Individual.indv) {
                var firstName = data.Individual.indv.fst_nm;
                var lastName = data.Individual.indv.lst_nm;
                var middleName = data.Individual.indv.midl_nm;
                var suffixName = data.Individual.indv.sufx_nm;
                var birthDate = data.Individual.indv.bth_dt;
                var gender = data.Individual.indv.gdr_ref_id;
                var sourceData = data.Individual.indv.sourceData;
            }

            //------------------------------MEMBERSHIP------------------------------//
            if (data.Membership.mbrshp) {
                var subscriberFirstName = data.Membership.mbrshp.sbscr_fst_nm;
                var subscriberLastName = data.Membership.mbrshp.sbscr_lst_nm;
                var relationshipCode = data.Membership.mbrshp.mbr_rel_ref_id;
                var memberID = data.Membership.mbrshp.scrbr_id_txt;
                //var memberIDType = data.Membership.mbrshp.mbr_id_typ_id;
                //console.log("MemberShip --------------------> " + JSON.stringify(data.Membership.mbrshp));
            }

            const memIdentifiers = {
                "memberIdentifier": {
                    '$': {
                        "memberID": memberID,
                        "memberIDType": "memberIDType"
                    }
                }
            };

            memberIdentifiers.push(memIdentifiers);
            const errors = this.mapErrors(data);
            if (errors) {
                const member =

                    [
                        {
                            '$': {
                                firstName: firstName,
                                lastName: lastName,
                                middleName: middleName,
                                suffixName: suffixName,
                                birthDate: birthDate,
                                gender: gender,
                                subscriberFirstName: subscriberFirstName,
                                subscriberLastName: subscriberLastName,
                                relationshipCode: relationshipCode
                            },
                            "memberAddress": memberAddr,
                            "memberIdentifiers": memberIdentifiers,
                            "sourceData": sourceData,
                            "errors": errors != null ? [errors] : null
                        }
                    ];

                if (member) {
                    eventData["member"] = member;
                }
            } else {
                const memberSuccess =

                    [
                        {
                            '$': {
                                firstName: firstName,
                                lastName: lastName,
                                middleName: middleName,
                                suffixName: suffixName,
                                birthDate: birthDate,
                                gender: gender,
                                subscriberFirstName: subscriberFirstName,
                                subscriberLastName: subscriberLastName,
                                relationshipCode: relationshipCode
                            },
                            "memberAddress": memberAddr,
                            "memberIdentifiers": memberIdentifiers,
                            "sourceData": sourceData
                        }
                    ];
                if (memberSuccess) {
                    eventData["member"] = memberSuccess;
                }
            }



        } catch (err) {
            console.log("error edi 278N member mapper Response mapMemberData: " + err);

        }
    }

    mapErrors(data) {
        const errorArray = [];
        let i: number;
        const errorData = data.Error.member;

        if (errorData) {
            try {


                if (errorData) {
                    for (i = 0; i < errorData.length; i++) {
                        const errorCode = errorData[i].errorCode;
                        const errorDescription = errorData[i].errorDescription;
                        const errorLoop = errorData[i].errorLoop;
                        const followupActionCode = errorData[i].followupActionCode;
                        const reasonRejectCode = errorData[i].reasonRejectCode;

                        const errors = {
                            "error": {
                                '$': {
                                    errorCode: errorCode,
                                    errorDescription: errorDescription,
                                    errorLoop: errorLoop,
                                    followupActionCode: followupActionCode,
                                    reasonRejectCode: reasonRejectCode
                                }
                            }
                        };
                        errorArray.push(errors);
                    }
                }
                return errorArray;
            } catch (err) {
                console.log("error error edi 278N member mapper Response mapErrors: " + err)
            }
        };
    }

}