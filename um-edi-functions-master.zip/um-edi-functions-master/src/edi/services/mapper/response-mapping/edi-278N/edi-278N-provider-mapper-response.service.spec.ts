import {EdiUtilities} from "../../../../edi-utilities";
import {Test, TestingModule} from "@nestjs/testing";
import {ConfigService} from "@nestjs/config";
import {data} from "browserslist";
import {Edi278NProviderMapperResponseService} from "./edi-278N-provider-mapper-response.service";

describe('Edi278NProviderMapperResponseService', () => {
    let service: Edi278NProviderMapperResponseService;
    let ediUtilities: EdiUtilities;

    const responseDetails = {
        "canonicalResponse": {
            $: {
                providerSeqNum: null,
                entityIdentifier: null,
                businessName: null,
                firstName: null,
                middleName: null,
                lastName: null,
                suffixName: null,
                providerNPI: null,
                federalTaxID: null,
                federalTaxIDSuffix: null,
                address1: null,
                address2: null,
                city: null,
                state: null,
                zip: null,
                zipSuffix: null,
                countryCode: null,
                primaryPhone: null,
                primaryPhoneExt: null,
                secondaryPhone: null,
                secondaryPhoneExt: null,
                fax: null,
                faxExt: null,
            }
        }
    };

    const eventData = {
        "provider": {
            $: {
                providerSeqNum: "1",
                entityIdentifier: "FA",
                businessName: "ACUTE CARE CLINIC",
                firstName: null,
                middleName: null,
                lastName: null,
                suffixName: null,
                providerNPI: null,
                federalTaxID: null,
                federalTaxIDSuffix: null,
                address1: "4505 Hospital St Ste A",
                address2: null,
                city: "Pascagoula",
                state: "MS",
                zip: "39581",
                zipSuffix: null,
                countryCode: "Pascagoula",
                primaryPhone: "9858984060",
                primaryPhoneExt: null,
                secondaryPhone: null,
                secondaryPhoneExt: null,
                fax: null,
                faxExt: null,
            },
            sourceData: ""
        },

    };

    const data = {
        "Provider": {
            "prov": [
                {
                    "prov_indvs": null,
                    "prov_orgs": {
                        "bus_nm": "ACUTE CARE CLINIC"
                    },
                    "prov_adrs": [
                        {
                            "adr_ln_1_txt": "4505 Hospital St Ste A",
                            "adr_ln_2_txt": null,
                            "cty_nm": "Pascagoula",
                            "st_ref_id": "MS",
                            "zip_cd_txt": "39581",
                            "zip_sufx_cd_txt": null
                        }
                    ],
                    "providerSeqNum": "1",
                    "entityType": "2",
                    "ndbMpin": "1998801",
                    "providerNPI": null,
                    "federalTaxID": null,
                    "federalTaxIDSuffix": null,
                    "entityIdentifier": "FA",
                    "sourceData": "<ns3:loopID xmlns:ns3=\"http://authref278.transaction.b2b.uhg.com\">2010A</ns3:loopID>",
                    "loopID": "2010A",
                    "facilityProviderSeqNum": "2",
                    "providerType": null,
                    "firstName": null,
                    "requestCategory": "AR",
                    "lastName": null,
                    "businessName": "ACUTE CARE CLINIC",
                    "prov_loc_affil_dtl": {
                        "providerTaxonomyCode": null,
                        "countryCode": null,
                        "contactName": "",
                        "primary_Phone": "9858984060",
                        "primaryPhoneExt": null,
                        "secondary_Phone": null,
                        "secondaryPhoneExt": null,
                        "faxExt": null,
                        "faxNum": null,
                        "emailAddress": null
                    }
                },
                {
                    "prov_indvs": {
                        "fst_nm": "NATHAN",
                        "midl_nm": null,
                        "lst_nm": "ECK",
                        "sufx_nm": null
                    },
                    "prov_orgs": null,
                    "prov_adrs": [
                        {
                            "adr_ln_1_txt": "1067 Twining Dr",
                            "adr_ln_2_txt": null,
                            "cty_nm": "Barksdale AFB",
                            "st_ref_id": "LA",
                            "zip_cd_txt": "71110",
                            "zip_sufx_cd_txt": null
                        }
                    ],
                    "providerSeqNum": "2",
                    "entityType": "1",
                    "ndbMpin": null,
                    "providerNPI": "1376194050",
                    "federalTaxID": null,
                    "federalTaxIDSuffix": null,
                    "entityIdentifier": "AAJ",
                    "sourceData": "<ns5:loopID xmlns:ns5=\"http://authref278.transaction.b2b.uhg.com\">2010EA</ns5:loopID>                    <ns6:providerTaxonomyCode xmlns:ns6=\"http://authref278.transaction.b2b.uhg.com\">207VX0000X</ns6:providerTaxonomyCode>",
                    "loopID": "2010EA",
                    "facilityProviderSeqNum": "2",
                    "providerType": "AD",
                    "firstName": "NATHAN",
                    "requestCategory": "AR",
                    "lastName": "ECK",
                    "businessName": null,
                    "prov_loc_affil_dtl": {
                        "providerTaxonomyCode": "207VX0000X",
                        "countryCode": null,
                        "contactName": "",
                        "primary_Phone": "9858095850",
                        "primaryPhoneExt": null,
                        "secondary_Phone": null,
                        "secondaryPhoneExt": null,
                        "faxExt": null,
                        "faxNum": "9858095855",
                        "emailAddress": null
                    }
                },
                {
                    "prov_indvs": {
                        "fst_nm": "NATHAN",
                        "midl_nm": null,
                        "lst_nm": "ECK",
                        "sufx_nm": null
                    },
                    "prov_orgs": null,
                    "prov_adrs": [
                        {
                            "adr_ln_1_txt": "1067 Twining Dr",
                            "adr_ln_2_txt": null,
                            "cty_nm": "Barksdale AFB",
                            "st_ref_id": "LA",
                            "zip_cd_txt": "71110",
                            "zip_sufx_cd_txt": null
                        }
                    ],
                    "providerSeqNum": "3",
                    "entityType": "1",
                    "ndbMpin": null,
                    "providerNPI": "1376194050",
                    "federalTaxID": null,
                    "federalTaxIDSuffix": null,
                    "entityIdentifier": "SJ",
                    "sourceData": "<ns5:loopID xmlns:ns5=\"http://authref278.transaction.b2b.uhg.com\">2010EA</ns5:loopID>                    <ns6:providerTaxonomyCode xmlns:ns6=\"http://authref278.transaction.b2b.uhg.com\">207VX0000X</ns6:providerTaxonomyCode>",
                    "loopID": "2010EA",
                    "facilityProviderSeqNum": "2",
                    "providerType": "AD",
                    "firstName": "NATHAN",
                    "requestCategory": "AR",
                    "lastName": "ECK",
                    "businessName": null,
                    "prov_loc_affil_dtl": {
                        "providerTaxonomyCode": "207VX0000X",
                        "countryCode": null,
                        "contactName": "",
                        "primary_Phone": "9858095850",
                        "primaryPhoneExt": null,
                        "secondary_Phone": null,
                        "secondaryPhoneExt": null,
                        "faxExt": null,
                        "faxNum": "9858095855",
                        "emailAddress": null
                    }
                }
            ]
        },
        "hscSourceData": {
            "diagnosis": [
                "<ns9:loopID xmlns:ns9=\"http://authref278.transaction.b2b.uhg.com\">2000E</ns9:loopID>",
                "<ns9:loopID xmlns:ns9=\"http://authref278.transaction.b2b.uhg.com\">2000E</ns9:loopID>"
            ],
            "facility": "<ns10:loopID xmlns:ns10=\"http://authref278.transaction.b2b.uhg.com\">2000E</ns10:loopID>",
            "service": [
                "<ns11:loopID xmlns:ns11=\"http://authref278.transaction.b2b.uhg.com\">2000F</ns11:loopID>"
            ],
            "followUpContact": "<ns7:loopID xmlns:ns7=\"http://authref278.transaction.b2b.uhg.com\">2010A</ns7:loopID>"
        },
        "Error": {
            "provider":[
                {
                    "errorCode": "20201",
                    "errorDescription": "Testing prov 1 error response.",
                    "errorLoop": "2010A",
                    "followupActionCode": "C",
                    "reasonRejectCode": "44"
                },
                {
                    "errorCode": "20201",
                    "errorDescription": "Testing prov 2 error response.",
                    "errorLoop": "2010A",
                    "followupActionCode": "C",
                    "reasonRejectCode": "44"
                }
            ]
        }
    };

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [Edi278NProviderMapperResponseService, EdiUtilities, ConfigService]
        }).compile();

        service = module.get<Edi278NProviderMapperResponseService>(Edi278NProviderMapperResponseService);
        ediUtilities = module.get<EdiUtilities>(EdiUtilities);

    });

    it('should be defined', () => {
        expect(service).toBeDefined();
    });

    it('should run #mapProviderData()', async () => {
        service.mapProviderData(data, eventData, responseDetails);
        expect(service).toBeTruthy();
    });

    it('should run #mapFields()', async () => {
        let provData;
        let providerData= data.Provider.prov[0];
        spyOn(service, 'mapErrors').and.callFake(function () {});
        service.mapFields(provData, providerData, data, 1);
        expect(service).toBeTruthy();
    });

    it('should run #mapErrors()', async () => {
        service.mapErrors(data);
        expect(service).toBeTruthy();
    });

})

