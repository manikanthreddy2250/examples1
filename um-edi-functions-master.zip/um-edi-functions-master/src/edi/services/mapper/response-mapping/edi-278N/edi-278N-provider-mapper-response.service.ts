import {Injectable} from "@nestjs/common";
import {EdiProviderMapperResponseService} from "../edi-provider-mapper-response.service";

@Injectable()
export class Edi278NProviderMapperResponseService extends EdiProviderMapperResponseService {

    mapProviderData(data, responseDetails, eventData) {
        let i: number;
        const provData = [];
        try {
            const providerData = data.Provider.prov;
            if (providerData) {
                var provCount = providerData.length;
                for (i = 0; i < provCount; i++) {
                    this.mapFields(provData, providerData, data, i);
                }
                if (provData) {
                    eventData["providers"] = [provData];
                }
            }
        } catch (err) {
            console.log("error mapProviderData: " + err);
        }
    }

    mapFields(provData, providerData, data, i) {
        try {
            var hsc_prov_id = providerData[i].providerSeqNum;
            var prov_role_ref_id = providerData[i].entityIdentifier;
            var bus_nm = providerData[i].prov_orgs && providerData[i].prov_orgs.bus_nm != null ? providerData[i].prov_orgs.bus_nm : null;
            var fst_nm = providerData[i].prov_indvs && providerData[i].prov_indvs.fst_nm != null ? providerData[i].prov_indvs.fst_nm : null;
            var midl_nm = providerData[i].prov_indvs && providerData[i].prov_indvs.midl_nm != null ? providerData[i].prov_indvs.midl_nm : null;
            var lst_nm = providerData[i].prov_indvs && providerData[i].prov_indvs.lst_nm != null ? providerData[i].prov_indvs.lst_nm : null;
            var sufx_nmd = providerData[i].prov_indvs && providerData[i].prov_indvs.sufx_nm != null ? providerData[i].prov_indvs.sufx_nm : null;
            var providerNPI = providerData[i].providerNPI;
            var federalTaxID = providerData[i].federalTaxID;
            var federalTaxIDSuffix = providerData[i].federalTaxIDSuffix;
            var adr_ln_1_txt = providerData[i].prov_adrs[0].adr_ln_1_txt;
            var adr_ln_2_txt = providerData[i].prov_adrs[0].adr_ln_2_txt;
            var cty_nm = providerData[i].prov_adrs[0].cty_nm;
            var st_ref_id = providerData[i].prov_adrs[0].st_ref_id;
            var zip_cd_txt = providerData[i].prov_adrs[0].zip_cd_txt;
            var zip_sufx_cd_txt = providerData[i].prov_adrs[0].zip_sufx_cd_txt;
            var primaryPhone = providerData[i].prov_loc_affil_dtl.primary_Phone;
            var primaryPhoneExt = providerData[i].prov_loc_affil_dtl.primaryPhoneExt;
            var secondaryPhone = providerData[i].prov_loc_affil_dtl.secondary_Phone;
            var secondaryPhoneExt = providerData[i].prov_loc_affil_dtl.secondaryPhoneExt;
            var fax = providerData[i].prov_loc_affil_dtl.faxNum;
            var faxExt = providerData[i].prov_loc_affil_dtl.faxExt;
            var sourceData = providerData[i].sourceData;
            if (data.Error) {
                var errors = this.mapErrors(data.Error.provider[i]);
            }

            if (errors) {
                var prv = {
                    "provider": {
                        '$': {
                            providerSeqNum: hsc_prov_id,
                            entityIdentifier: prov_role_ref_id,
                            businessName: bus_nm,
                            firstName: fst_nm,
                            middleName: midl_nm,
                            lastName: lst_nm,
                            suffixName: sufx_nmd,
                            providerNPI: providerNPI,
                            federalTaxID: federalTaxID,
                            federalTaxIDSuffix: federalTaxIDSuffix,
                            address1: adr_ln_1_txt,
                            address2: adr_ln_2_txt,
                            city: cty_nm,
                            state: st_ref_id,
                            zip: zip_cd_txt,
                            zipSuffix: zip_sufx_cd_txt,
                            countryCode: cty_nm,
                            primaryPhone: primaryPhone,
                            primaryPhoneExt: primaryPhoneExt,
                            secondaryPhone: secondaryPhone,
                            secondaryPhoneExt: secondaryPhoneExt,
                            fax: fax,
                            faxExt: faxExt
                        },
                        "sourceData": sourceData,
                        "errors": [errors]
                    }
                };
                provData.push(prv);
            } else {
                var prvSuccess = {
                    "provider": {
                        '$': {
                            providerSeqNum: hsc_prov_id,
                            entityIdentifier: prov_role_ref_id,
                            businessName: bus_nm,
                            firstName: fst_nm,
                            middleName: midl_nm,
                            lastName: lst_nm,
                            suffixName: sufx_nmd,
                            providerNPI: providerNPI,
                            federalTaxID: federalTaxID,
                            federalTaxIDSuffix: federalTaxIDSuffix,
                            address1: adr_ln_1_txt,
                            address2: adr_ln_2_txt,
                            city: cty_nm,
                            state: st_ref_id,
                            zip: zip_cd_txt,
                            zipSuffix: zip_sufx_cd_txt,
                            countryCode: cty_nm,
                            primaryPhone: primaryPhone,
                            primaryPhoneExt: primaryPhoneExt,
                            secondaryPhone: secondaryPhone,
                            secondaryPhoneExt: secondaryPhoneExt,
                            fax: fax,
                            faxExt: faxExt
                        },
                        "sourceData": sourceData
                    }
                };
                provData.push(prvSuccess);
            }

        } catch (err) {
            console.log("error mapFields: " + err);
        }
    }

    mapErrors(errorData) {
        const errorArray = [];
        let i: number;

        try {

            if (errorData) {
                const errorCode = errorData.errorCode;
                const errorDescription = errorData.errorDescription;
                const errorLoop = errorData.errorLoop;
                const followupActionCode = errorData.followupActionCode;
                const reasonRejectCode = errorData.reasonRejectCode;

                const errors = {
                    "error": {
                        '$': {
                            errorCode: errorCode,
                            errorDescription: errorDescription,
                            errorLoop: errorLoop,
                            followupActionCode: followupActionCode,
                            reasonRejectCode: reasonRejectCode
                        }
                    }
                };
                errorArray.push(errors);
            }
            return errorArray;
        } catch (err) {
        }
    }
}