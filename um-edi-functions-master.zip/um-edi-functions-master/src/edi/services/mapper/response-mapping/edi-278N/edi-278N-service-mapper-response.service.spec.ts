import {EdiUtilities} from "../../../../edi-utilities";
import {Edi278NServiceMapperResponseService} from "./edi-278N-service-mapper-response.service";
import {Test, TestingModule} from "@nestjs/testing";
import {Edi278NDiagnosisMapperResponseService} from "./edi-278N-diagnosis-mapper-response.service";
import {ConfigService} from "@nestjs/config";
import {data} from "browserslist";

describe('Edi278NServiceMapperResponseService', () => {
    let service: Edi278NServiceMapperResponseService;
    let ediUtilities: EdiUtilities;

    const responseDetails = {
        "canonicalResponse": {
            $: {
                serviceSeqNum: null,
                actionCode: null,
                serviceEndDate: null,
            }
        }
    };

    const eventData = {
        "Service": [
            {
                "serviceSeqNum": "3",
                "requestCategory": "HS",
                "serviceType": "A9",
                "serviceEndDate": "2021-04-09"
            }
        ],
        "ServiceFacility": [
            {
                "monetaryAmount": null,
                "unitCode": null,
                "quantity": null
            }
        ],
        "ServiceNonFacility": [
            {
                "monetaryAmount": null,
                "unitCode": null,
                "quantity": null
            }
        ],
        "hscSourceData": {
            "diagnosis": [
                "<ns9:loopID xmlns:ns9=\"http://authref278.transaction.b2b.uhg.com\">2000E</ns9:loopID>",
                "<ns9:loopID xmlns:ns9=\"http://authref278.transaction.b2b.uhg.com\">2000E</ns9:loopID>"
            ],
            "facility": "<ns10:loopID xmlns:ns10=\"http://authref278.transaction.b2b.uhg.com\">2000E</ns10:loopID>",
            "service": [
                "<ns11:loopID xmlns:ns11=\"http://authref278.transaction.b2b.uhg.com\">2000F</ns11:loopID>"
            ],
            "followUpContact": "<ns7:loopID xmlns:ns7=\"http://authref278.transaction.b2b.uhg.com\">2010A</ns7:loopID>"
        },
        "Error": {
            "service":[
                {
                    "errorCode": "20201",
                    "errorDescription": "Testing serv 1 error response.",
                    "errorLoop": "2010A",
                    "followupActionCode": "C",
                    "reasonRejectCode": "44"
                }
            ]
        }
    };

    const errorData = {
        "error": {
            $: {
                errorCode: null,
                errorDescription: null,
                errorLoop: null,
                followupActionCode: null,
                reasonRejectCode: null,
            },
        },

    };

    const data = {
        "Service": [
            {
                "serviceSeqNum": "3",
                "requestCategory": "HS",
                "serviceType": "A9",
                "serviceEndDate": "2021-04-09"
            }
        ],
        "ServiceFacility": [
            {
                "monetaryAmount": null,
                "unitCode": null,
                "quantity": null
            }
        ],
        "ServiceNonFacility": [
            {
                "monetaryAmount": null,
                "unitCode": null,
                "quantity": null
            }
        ],
        "hscSourceData": {
            "diagnosis": [
                "<ns9:loopID xmlns:ns9=\"http://authref278.transaction.b2b.uhg.com\">2000E</ns9:loopID>",
                "<ns9:loopID xmlns:ns9=\"http://authref278.transaction.b2b.uhg.com\">2000E</ns9:loopID>"
            ],
            "facility": "<ns10:loopID xmlns:ns10=\"http://authref278.transaction.b2b.uhg.com\">2000E</ns10:loopID>",
            "service": [
                "<ns11:loopID xmlns:ns11=\"http://authref278.transaction.b2b.uhg.com\">2000F</ns11:loopID>"
            ],
            "followUpContact": "<ns7:loopID xmlns:ns7=\"http://authref278.transaction.b2b.uhg.com\">2010A</ns7:loopID>"
        },
        "Error": {
            "service":[
                {
                    "errorCode": "20201",
                    "errorDescription": "Testing serv 1 error response.",
                    "errorLoop": "2010A",
                    "followupActionCode": "C",
                    "reasonRejectCode": "44"
                }
            ]
        }
    };

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [Edi278NServiceMapperResponseService, EdiUtilities, ConfigService]
        }).compile();

        service = module.get<Edi278NServiceMapperResponseService>(Edi278NServiceMapperResponseService);
        ediUtilities = module.get<EdiUtilities>(EdiUtilities);
    });

    it('should be defined', () => {
        expect(service).toBeDefined();
    });

    it('should run #mapServiceData()', async () => {
        spyOn(service, 'mapErrors').and.callFake(function () {});
        service.mapServiceData(data, eventData, responseDetails);
        expect(service).toBeTruthy();
    });

    it('should run #mapErrors()', async () => {
        service.mapErrors(errorData);
        expect(service).toBeTruthy();
    });

    it('should run #mapErrors()', async () => {
        service.mapErrors(data);
        expect(service).toBeTruthy();
    });
})