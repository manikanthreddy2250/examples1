import {Injectable} from "@nestjs/common";
import {EdiServiceMapperResponseService} from "../edi-service-mapper-response.service";

@Injectable()
export class Edi278NServiceMapperResponseService extends EdiServiceMapperResponseService {


    mapServiceData(data, eventData, responseDetails) {
        const serviceOfArray = [];
        let i: number;
        let serviceFacilityArray = [];
        let serviceNonFacilityArray = [];
        let serviceDeliveryArray = [];
        try {
            const serviceData = data.Service;
            if (serviceData) {
                for (i = 0; i < serviceData.length; i++) {
                    var serviceEndDate = serviceData[i].serviceEndDate;
                    if(data.hscSourceData && data.hscSourceData.service) {
                        var sourceData = data.hscSourceData.service[i];
                    }
                    var serviceSeqNum = serviceData[i].serviceSeqNum;
                    var actionCode = serviceData[i].actionCode;
                    if (data.Error) {
                        var errors = this.mapErrors(data.Error.service[i]);
                    }

                    const serviceFacility = this.mapServiceFacl(serviceData[i].serviceFacility);
                    serviceFacilityArray.push(serviceFacility);

                    const serviceNonFacility = this.mapServiceNonFacl(serviceData[i].serviceNonFacility);
                    serviceNonFacilityArray.push(serviceNonFacility);

                    const serviceDelivery = this.mapServiceDelivery(serviceData[i].serviceDelivery);
                    serviceDeliveryArray.push(serviceDelivery);

                    this.mapServices(errors, serviceOfArray, serviceSeqNum, actionCode, serviceEndDate, serviceFacilityArray, serviceNonFacilityArray, sourceData, serviceDeliveryArray)

                    serviceFacilityArray = [];
                    serviceNonFacilityArray = [];
                    serviceDeliveryArray =[];
                }
                if (serviceOfArray) {
                    eventData["services"] = [serviceOfArray];
                }

            }
        } catch (err) {
            console.log("error mapServicesData: " + err);
        }
    }

    mapServices(errors, serviceOfArray, serviceSeqNum, actionCode, serviceEndDate, serviceFacilityArray, serviceNonFacilityArray, sourceData, serviceDeliveryArray) {

      if(errors){
        const services = {
            "service": {
                '$': {
                    serviceSeqNum: serviceSeqNum,
                    actionCode: actionCode,
                    serviceEndDate: serviceEndDate,
                },
                "serviceFacility": serviceFacilityArray,
                "serviceNonFacility": serviceNonFacilityArray,
                "serviceDelivery": serviceDeliveryArray,
                "sourceData": sourceData,
                "errors": [errors]
            }
        };
        serviceOfArray.push(services);
      }else{
        const services = {
            "service": {
                '$': {
                    serviceSeqNum: serviceSeqNum,
                    actionCode: actionCode,
                    serviceEndDate: serviceEndDate,
                },
                "serviceFacility": serviceFacilityArray,
                "serviceNonFacility": serviceNonFacilityArray,
                "serviceDelivery": serviceDeliveryArray,
                "sourceData": sourceData
            }
        };
        serviceOfArray.push(services);
     }

    }


    mapErrors(errorData) {
        const errorArray = [];
        let i: number;

        try {

            if (errorData) {
                const errorCode = errorData.errorCode;
                const errorDescription = errorData.errorDescription;
                const errorLoop = errorData.errorLoop;
                const followupActionCode = errorData.followupActionCode;
                const reasonRejectCode = errorData.reasonRejectCode;

                const errors = {
                    "error": {
                        '$': {
                            errorCode: errorCode,
                            errorDescription: errorDescription,
                            errorLoop: errorLoop,
                            followupActionCode: followupActionCode,
                            reasonRejectCode: reasonRejectCode
                        }
                    }
                };
                errorArray.push(errors);
            }
            return errorArray;
        } catch (err) {
        }
    }

    mapServiceFacl(serviceFacilityData) {

        try {
            if (serviceFacilityData) {
                var monetaryAmountF = serviceFacilityData.monetaryAmount;
                var unitCodeF = serviceFacilityData.unitCode;
                var quantityF = serviceFacilityData.quantity;

                const serviceFacility = {
                    '$': {
                        "monetaryAmount": monetaryAmountF,
                        "unitCode": unitCodeF,
                        "quantity": quantityF
                    },
                };
                return serviceFacility;
            }
        } catch (err) {
        }
    }

    mapServiceNonFacl(serviceNonFacilityData) {
        try {
            if (serviceNonFacilityData) {
                var monetaryAmountNF = serviceNonFacilityData.monetaryAmount;
                var unitCodeNF = serviceNonFacilityData.unitCode;
                var quantityNF = serviceNonFacilityData.quantity;

                const serviceNonFacility =
                    {
                        '$': {
                            "monetaryAmount": monetaryAmountNF,
                            "unitCode": unitCodeNF,
                            "quantity": quantityNF
                        },
                    };
                return serviceNonFacility;
            }
        } catch (err) {
        }
    }

    mapServiceDelivery(ServiceDeliveryData) {
        try {
            if (ServiceDeliveryData) {
                const unitCode = ServiceDeliveryData.unicode;
                const quantity = ServiceDeliveryData.quantity;
                const quantityQualifier = ServiceDeliveryData.quantityQualifier;
                const sampleSelectionModulus = ServiceDeliveryData.sampleSelectionModulus;
                const timePeriodQualifier = ServiceDeliveryData.timePeriodQualifier;
                const numberOfPeriods = ServiceDeliveryData.numberOfPeriods;

                const serviceDelivery =
                    {
                        '$': {
                            unitCode: unitCode,
                            quantity: quantity,
                            quantityQualifier: quantityQualifier,
                            sampleSelectionModulus: sampleSelectionModulus,
                            timePeriodQualifier: timePeriodQualifier,
                            numberOfPeriods: numberOfPeriods
                        },
                    };
                return serviceDelivery;
            }
        } catch (err) {

        }
    }




}

