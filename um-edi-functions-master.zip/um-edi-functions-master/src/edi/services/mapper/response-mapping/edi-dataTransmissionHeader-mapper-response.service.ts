import {Injectable} from "@nestjs/common";
import {EdiUtilities} from "../../../edi-utilities";
import {EdiDataTransmissionHeaderValidationService} from "../../validation/edi-dataTransmissionHeader-validation.service";

@Injectable()
export class EdiDataTransmissionHeaderMapperResponseService {

    mapDataTransmissionHeader(data, responseDetails) {
    }

}