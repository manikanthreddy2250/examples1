import {Injectable} from "@nestjs/common";

@Injectable()
export class EdiDiagnosisMapperResponseService {

    mapDiagnosisData(data, event, responseDetails){}
}