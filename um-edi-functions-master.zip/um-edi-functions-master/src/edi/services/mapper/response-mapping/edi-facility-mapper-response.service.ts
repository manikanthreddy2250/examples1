import {Injectable} from "@nestjs/common";

@Injectable()
export class EdiFacilityMapperResponseService {

    mapFacilityData(data, responseDetails){}
}