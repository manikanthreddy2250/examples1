import {Injectable} from "@nestjs/common";

@Injectable()
export class EdiMemberMapperResponseService {

    mapMemberData(data, eventData, responseDetails){}
}