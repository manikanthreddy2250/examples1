import {Injectable} from "@nestjs/common";

@Injectable()
export class EdiProviderMapperResponseService {

    mapProviderData(data, responseDetails, eventData){}
}