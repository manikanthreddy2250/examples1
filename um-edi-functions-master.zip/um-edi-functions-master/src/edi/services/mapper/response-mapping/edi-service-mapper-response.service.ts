import {Injectable} from "@nestjs/common";

@Injectable()
export class EdiServiceMapperResponseService {

    mapServiceData(data, event, responseDetails){}
}