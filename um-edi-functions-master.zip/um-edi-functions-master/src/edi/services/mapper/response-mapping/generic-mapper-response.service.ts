import {Injectable} from "@nestjs/common";
import {EdiUtilities} from "../../../edi-utilities";
import {EdiDataTransmissionHeaderMapperResponseService} from "./edi-dataTransmissionHeader-mapper-response.service";
import {Edi278NMemberMapperResponseService} from "./edi-278N/edi-278N-member-mapper-response.service";
import {EdiMemberMapperResponseService} from "./edi-member-mapper-response.service";
import {EdiDiagnosisMapperResponseService} from "./edi-diagnosis-mapper-response.service";


@Injectable()
export class GenericMapperResponseService {

    constructor(protected readonly ediUtils: EdiUtilities,
                protected readonly ediDataTransmissionHeaderMapperResponseService: EdiDataTransmissionHeaderMapperResponseService,
                protected readonly ediMemberMapperResponseService: EdiMemberMapperResponseService,
                protected readonly ediDiagnosisMapperResponseService: EdiDiagnosisMapperResponseService) {
    }

    async mapCanonicalResponse(data, hscResponse, responseDetails) {}

}