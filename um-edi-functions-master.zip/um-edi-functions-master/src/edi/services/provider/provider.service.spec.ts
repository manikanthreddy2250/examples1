import { Test, TestingModule } from '@nestjs/testing';
import {Injectable} from "@nestjs/common";
import {ProviderService} from "./provider.service";
import {ProviderClient} from "../../../shared/graphql/providerDomain/providerClient";
import {request} from "http";

@Injectable()
class ProviderClientMock {
}

@Injectable()
class providerVariablesMock {
}


describe('ProviderService', () => {
  let service: ProviderService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
        providers: [ProviderService, {provide: ProviderClient, useClass: ProviderClientMock}],
    }).compile();

    service = module.get<ProviderService>(ProviderService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('should run #getHscProviderDetails()', async () => {
    spyOn(service, 'getHscProviderDetails').and.callThrough();
    service.getHscProviderDetails(providerVariablesMock, request);
    expect(service).toBeTruthy();
  })

  it('should run #getHscProviderForPerson()', async () => {
    spyOn(service, 'getHscProviderForPerson').and.callThrough();
    service.getHscProviderForPerson(providerVariablesMock, request);
    expect(service).toBeTruthy();
  })

  it('should run #getHscProviderForNonPerson()', async () => {
    spyOn(service, 'getHscProviderForNonPerson').and.callThrough();
    service.getHscProviderForNonPerson(providerVariablesMock, request);
    expect(service).toBeTruthy();
  })
});
