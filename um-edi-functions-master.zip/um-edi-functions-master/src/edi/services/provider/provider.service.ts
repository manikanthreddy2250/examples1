import { Injectable } from '@nestjs/common';
import { getHscProviderDetailsQuery, getHscProviderForPersonQuery, getHscProviderForNonPersonQuery } from "../../../shared/graphql/providerDomain/providerQuery";
import { ProviderClient } from "../../../shared/graphql/providerDomain/providerClient";
import {GraphQLClient} from "graphql-request/dist";

@Injectable()
export class ProviderService {

    constructor(private readonly providerClient: ProviderClient) {}

    async getHscProviderDetails(providerVariables, request): Promise<any> {
        const provGraphqlClient: GraphQLClient = this.providerClient.getGraphqlClient(request);
            var response: any = "hello";
            try {
                response = await provGraphqlClient.request(getHscProviderDetailsQuery, providerVariables);

            } catch(e) {
                console.log("Error in getHscProviderDetails" + e);
            }
            return response;
    }

    async getHscProviderForPerson(providerVariables, request): Promise<any> {
        const provGraphqlClient: GraphQLClient = this.providerClient.getGraphqlClient(request);
        var response: any;
        try {
            response = await provGraphqlClient.request(getHscProviderForPersonQuery, providerVariables);
        } catch(e) {
            console.log("ERROR in getHscProviderForPerson: " + e);
        }
        return response;
    }

    async getHscProviderForNonPerson(providerVariables, request): Promise<any> {
        const provGraphqlClient: GraphQLClient = this.providerClient.getGraphqlClient(request);
        var response: any;

        try {
            response = await provGraphqlClient.request(getHscProviderForNonPersonQuery, providerVariables);
        } catch(e) {
            console.log(" Error in getHscProviderForNonPerson " + e);
        }
        return response;
    }

}