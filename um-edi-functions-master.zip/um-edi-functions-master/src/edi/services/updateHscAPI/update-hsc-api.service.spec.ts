import {Test, TestingModule} from '@nestjs/testing';
import {Injectable} from "@nestjs/common";
import {UpdateHscApiService} from "./updateHscApi.service";
import {ConfigService} from "@nestjs/config";
import {UpdateHscApiClient} from "../../../shared/graphql/updateHscApi/updateHscApiClient";
import {HttpRequest} from "@azure/functions";


@Injectable()
class UpdateHscApiClientMock {
    getGraphqlClient(request: HttpRequest){
       return "test";
    }
}

describe('UpdateHscApiService', () => {
    let service: UpdateHscApiService;
    let request: HttpRequest;
    request = {
        headers: {authorization: ""},
        method: null,
        url: "",
        query: {},
        params: {}
    };
    const graphQlClient = new UpdateHscApiClientMock();

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [UpdateHscApiService, ConfigService, {
                provide: UpdateHscApiClient,
                useClass: UpdateHscApiClientMock
            }],
        }).compile();

        service = module.get<UpdateHscApiService>(UpdateHscApiService);
    });

    it('should be defined', () => {
        expect(service).toBeDefined();
    });

/*    it('should run #updateHsc()', async () => {
        const hscRequest = {
            "updateHscRequest": {
                "hsc_id": 15067,
                "indv_key_typ_ref_id": 2757,
                "indv_key_val": "16440436900",
                "srvc_set_ref_id": 3737,
                "rev_prr_ref_id": 3754
            }
        };
        spyOn(graphQlClient, 'getGraphqlClient').and.callThrough();
        spyOn(graphQlClient, 'request').and.callFake({});

        service.updateHsc(hscRequest, request);
        expect(service).toBeTruthy();
    });*/
});
