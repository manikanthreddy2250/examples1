import {HttpService, Injectable} from "@nestjs/common";
import {ConfigService} from "@nestjs/config";
import {GraphQLClient} from "graphql-request/dist";
import {Observable} from 'rxjs';
import {tap} from "rxjs/operators";
import {of} from "rxjs/internal/observable/of";
import {HttpClient} from "@angular/common/http";
import {updateHscApiMutation} from "../../../shared/graphql/updateHscApi/updateHscApiQuery";
import {UpdateHscApiClient} from "../../../shared/graphql/updateHscApi/updateHscApiClient";

@Injectable()
export class UpdateHscApiService {

    constructor(private readonly configService: ConfigService,
                private updateHscApiClient: UpdateHscApiClient) {
    }

    async updateHsc(hscRequest, request) {
        const updateHscGraphqlClient: GraphQLClient = this.updateHscApiClient.getGraphqlClient(request);
        try {
            const updateHscRequest = {
                    "updateHscRequest": hscRequest
                };

            console.log(" calling update hsc client ");
            const updateHscResponse = await updateHscGraphqlClient.request(updateHscApiMutation, updateHscRequest);

            return updateHscResponse.updateHsc;
        } catch (err) {
            console.log("Error while executing updateHsc() in UpdateHscApiService: " + err);
        }
    }
}


