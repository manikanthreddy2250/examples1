import {Test, TestingModule} from '@nestjs/testing';
import {Injectable} from "@nestjs/common";
import {Edi278NDataTransmissionHeaderValidationService} from "./edi-278N-dataTransmissionHeader-validation.service";
import {EdiUtilities} from "../../../edi-utilities";
import {ConfigService} from "@nestjs/config";


@Injectable()
class UpdateHscApiClientMock {
}

describe('Edi278NDataTransmissionHeaderValidationService', () => {
    let service: Edi278NDataTransmissionHeaderValidationService;

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [Edi278NDataTransmissionHeaderValidationService, EdiUtilities, ConfigService],
        }).compile();

        service = module.get<Edi278NDataTransmissionHeaderValidationService>(Edi278NDataTransmissionHeaderValidationService);
    });

    it('should be defined', () => {
        expect(service).toBeDefined();
    });

    it('should run #validatePurposeCode()', async () => {
        const purposeCode = "ABK";
        const requestDetails = {};
        const facilityDetails ="";
        service.validatePurposeCode(purposeCode, requestDetails, facilityDetails);
        expect(service).toBeTruthy();
    });
});
