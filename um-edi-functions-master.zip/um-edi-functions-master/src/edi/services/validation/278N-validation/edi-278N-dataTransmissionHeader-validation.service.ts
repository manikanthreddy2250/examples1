import {Edi278NConstants, Edi278NDiagnosisConstants} from "../../../constants/edi-278N.constants";
import {Injectable} from "@nestjs/common";
import {EdiDataTransmissionHeaderValidationService} from "../edi-dataTransmissionHeader-validation.service";
import {canonicalRequestTags, facilityAttributes} from "../../../constants/edi.constants";

@Injectable()
export class Edi278NDataTransmissionHeaderValidationService extends EdiDataTransmissionHeaderValidationService {

    validatePurposeCode(purposeCode, requestDetails, facilityDetails) {
        if(facilityDetails) {
            let admissionDate = this.ediUtils.getAttributeValue(facilityDetails, facilityAttributes.ADMISSIONDATE);
            admissionDate = new Date(admissionDate);
            //Today's date
            const currentDate = new Date();

            if (purposeCode === Edi278NConstants.BHT02_COMPLETION_NOTIFICATION && (admissionDate <= currentDate)) {
                return purposeCode;
            }else{
                //fails to satisfy purposeCode validation logic
            }
        }
    }

}