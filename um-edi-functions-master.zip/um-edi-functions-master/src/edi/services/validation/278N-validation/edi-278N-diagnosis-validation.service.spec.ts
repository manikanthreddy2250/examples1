import {Test, TestingModule} from '@nestjs/testing';
import {Injectable} from "@nestjs/common";
import {Edi278NDiagnosisValidationService} from "./edi-278N-diagnosis-validation.service";
import {EdiUtilities} from "../../../edi-utilities";
import {HealthServiceService} from "../../healthService/healthService.service";
import {HealthServiceClient} from "../../../../shared/graphql/healthservicedomain/healthServiceClient";
import {ConfigService} from "@nestjs/config";
import {EdiMemberConstants} from "../../../constants/edi.constants";
import {ProviderService} from "../../provider/provider.service";
import {HttpRequest} from "@azure/functions";
import {testCanonicalRequest} from "../../../../../test/ediTestData";


@Injectable()
class HealthServiceServiceMock {
    diagnosisICD10Lookup(diagnosisVariables){
        const response = {
            icd10: [{diag_cd: "M45.21"}]
        };
        return response;
    }

}

describe('Edi278NDiagnosisValidationService', () => {
    let component: Edi278NDiagnosisValidationService;
    let request: HttpRequest;
    request = {
        headers: {authorization: ""},
        method: null,
        url: "",
        query: {},
        params: {}
    };

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [Edi278NDiagnosisValidationService, EdiUtilities,
                {provide: HealthServiceService, useClass: HealthServiceServiceMock}, HealthServiceClient, ConfigService],
        }).compile();

        component = module.get<Edi278NDiagnosisValidationService>(Edi278NDiagnosisValidationService);
    });

    it('should be defined', () => {
        expect(component).toBeDefined();
    });

    it('should run #setDiagnosisIndicatorsByDiagnosisCodeType() - ABK case', async () => {
        const diagnosisCodeType = "ABK";
        const diagnosis = {
            pri_ind: 0
        };
        component.setDiagnosisIndicatorsByDiagnosisCodeType(diagnosisCodeType, diagnosis);
        expect(component).toBeTruthy();
    });

    it('should run #setDiagnosisIndicatorsByDiagnosisCodeType() - ABJ case', async () => {
        const diagnosisCodeType = "ABJ";
        const diagnosis = {
            pri_ind: 0
        };
        component.setDiagnosisIndicatorsByDiagnosisCodeType(diagnosisCodeType, diagnosis);
        expect(component).toBeTruthy();
    });

    it('should run #setDiagnosisIndicatorsByDiagnosisCodeType() - ABF case', async () => {
        const diagnosisCodeType = "ABF";
        const diagnosis = {
            pri_ind: 0
        };
        component.setDiagnosisIndicatorsByDiagnosisCodeType(diagnosisCodeType, diagnosis);
        expect(component).toBeTruthy();
    });

    it('should run #validateDiagnosisCode() - with decimal ', async () => {
        const diagnosisCode = "M45.23";
        var healthService = new HealthServiceServiceMock();
        spyOn(healthService, 'diagnosisICD10Lookup').and.callThrough();
        component.validateDiagnosisCode(diagnosisCode, request);

        expect(component).toBeTruthy();
    });

    it('should run #validateDiagnosisCode() - without decimal ', async () => {
        const diagnosisCode = "M4523";
        var healthService = new HealthServiceServiceMock();
        spyOn(healthService, 'diagnosisICD10Lookup').and.callThrough();

        component.validateDiagnosisCode(diagnosisCode, request);
        expect(component).toBeTruthy();
    });

    it('should run #getEventICDNote() ', async () => {
        component.getEventICDNote(testCanonicalRequest);
        expect(component).toBeTruthy();
    });
});
