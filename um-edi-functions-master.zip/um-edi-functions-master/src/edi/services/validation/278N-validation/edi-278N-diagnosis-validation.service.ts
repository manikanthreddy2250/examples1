import {EdiDiagnosisValidationService} from "../edi-diagnosis-validation.service";
import {Edi278NDiagnosisConstants, Edi278NEventNoteLiterals} from "../../../constants/edi-278N.constants";
import {Injectable} from "@nestjs/common";
import {canonicalRequestTags, hscAttributes} from "../../../constants/edi.constants";

@Injectable()
export class Edi278NDiagnosisValidationService extends EdiDiagnosisValidationService {

    setDiagnosisIndicatorsByDiagnosisCodeType(diagnosisCodeType, diag) {

        if (diagnosisCodeType && (Edi278NDiagnosisConstants.HI02_1_PRIMARY_DX_ICD10 === diag.diagnosisCodeType || Edi278NDiagnosisConstants.HI02_1_SECONDARY_DX_ICD10 === diagnosisCodeType ||
            Edi278NDiagnosisConstants.HI02_1_ADMITTING_DX_ICD10 === diagnosisCodeType)) {
            if (Edi278NDiagnosisConstants.HI02_1_PRIMARY_DX_ICD10 === diag.diagnosisCodeType) { //ABK
                diag.pri_ind = 1;
              //  diag.admit_ind = 0;
            } else if (Edi278NDiagnosisConstants.HI02_1_SECONDARY_DX_ICD10 === diagnosisCodeType) { //ABF
                diag.pri_ind = 0;
             //   diag.admit_ind = 0;
            } else if (Edi278NDiagnosisConstants.HI02_1_ADMITTING_DX_ICD10 === diagnosisCodeType) { //ABJ
                diag.pri_ind = 0;
             //   diag.admit_ind = 1;
            }
        } else {
            //not valid diagnosisCodeType - set error
        }
    }

    async validateDiagnosisCode(diagnosisCode, request) {
        if (diagnosisCode && !this.ediUtils.containsDecimal(diagnosisCode)) {
            if (diagnosisCode.length > 3) {
                diagnosisCode = diagnosisCode.substring(0, 3) + "." + diagnosisCode.substring(3, diagnosisCode.length);
            }
        }
        //check diagnosis code in ICD10 table
        const diagnosisVariables = {
            diagnosisCode: diagnosisCode
        };
        const diagnosisCodeResponse = await this.healthServiceService.diagnosisICD10Lookup(diagnosisVariables, request);

        if (diagnosisCodeResponse.icd10[0].diag_cd) {
            return diagnosisCodeResponse.icd10[0].diag_cd;
        } else {
            //diagnosis not found during lookup set error
        }

    }

    getEventICDNote(canonicalRequest) {
        const eventTagInfo = this.ediUtils.getElementAttributeInfo(canonicalRequest, canonicalRequestTags.EVENT);
        const note = this.ediUtils.getAttributeValue(eventTagInfo, hscAttributes.NOTE);

        if (note && note.search(Edi278NEventNoteLiterals.ICD + "==") != -1) {
            const noteICD = note.split(Edi278NEventNoteLiterals.ICD + "==").pop().split(";;")[0];
            console.log("ICD NOTE -----:" + noteICD);
            return noteICD;
        }
        return null;
    }

}