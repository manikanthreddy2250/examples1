import {Test, TestingModule} from "@nestjs/testing";
import {HealthServiceClient} from "../../../../shared/graphql/healthservicedomain/healthServiceClient";
import {HttpRequest} from "@azure/functions";
import {EdiUtilities} from "../../../edi-utilities";
import {ConfigService} from "@nestjs/config";
import {Edi278NServiceValidationService} from "./edi-278N-service-validation.service";
import {RequestDetails} from "../../../constants/edi.constants";
import {HealthServiceService} from "../../healthService/healthService.service";
import {Injectable} from "@nestjs/common";

@Injectable()
class HealthServiceServiceMock {
    procedureCodeLookup(procedureCodeVariables, request) {
        return {
            cpt4: [{proc_cd: '1111'}],
            hcpcs: [{proc_cd: ''}]
        };
    }

}

describe('Edi278NServiceValidationService', () => {
    let component: Edi278NServiceValidationService;
    let request: HttpRequest;
    request = {
        headers: {authorization: ""},
        method: null,
        url: "",
        query: {},
        params: {}
    };

    const requestDetails: RequestDetails = {
        dataTransmissionHeader: null,
        Membership: null,
        Individual: null,
        Provider: null,
        Facility: {
            requestCategory: null,
            certificationType: 'S',
            admissionDate: null,
            dischargeDate: null,
            facilityProviderSeqNum: null,
            serviceReferenceNum: null
        },
        Diagnosis: null,
        Event: null,
        procCodes: null,
        Service: null,
        updateHscRequest: null,
        hscSourceData: null,
        ediType: null,
        followUpContact: null,
        Error: null
    };

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [Edi278NServiceValidationService, EdiUtilities,
                {provide: HealthServiceService, useClass: HealthServiceServiceMock}, HealthServiceClient, ConfigService],
        }).compile();

        component = module.get<Edi278NServiceValidationService>(Edi278NServiceValidationService);
    });

    it('should be defined', () => {
        expect(component).toBeDefined();
    });

    it('should run #validateRequestCategory()', async () => {
        const requestCategory = "HS";

        component.validateRequestCategory(requestCategory);
        expect(component).toBeTruthy();
    });

    it('should run #validateRequestCategory() - error', async () => {
        const requestCategory = "AR";

        component.validateRequestCategory(requestCategory);
        expect(component).toBeTruthy();
    });



    it('should run #validateCertificationType()', async () => {
        const certificationType = "S";

        component.validateCertificationType(certificationType, 1, requestDetails);
        expect(component).toBeTruthy();
    });

    it('should run #validateCertificationType() - error', async () => {
        const certificationType = "A";

        component.validateCertificationType(certificationType, 1, requestDetails);
        expect(component).toBeTruthy();
    });

    it('should run #validateProcedureCode() -cpt4', async () => {
        const procedureCode = "2345";
        var healthService = new HealthServiceServiceMock();
        spyOn(healthService, 'procedureCodeLookup').and.callThrough();

        component.validateProcedureCode(procedureCode, "Inpatient", requestDetails, request);
        expect(component).toBeTruthy();
    });

});