import {Injectable} from "@nestjs/common";
import {EdiServiceValidationService} from "../edi-service-validation.service";
import {EdiServiceConstants} from "../../../constants/edi.constants";

@Injectable()
export class Edi278NServiceValidationService extends EdiServiceValidationService {

    validateRequestCategory(requestCategory) {
        try {
            if (requestCategory == EdiServiceConstants.SERVICE_REQUEST_CATEGORY_HS) {
                return requestCategory;
            } else {
                //allows HS only -- set error if not HS
            }
        } catch (err) {
            //  console.log("Error in Edi278NServiceValidationService: validateRequestCategory(): " + err);
        }
    }

    validateCertificationType(certificationType, serviceReferenceNum, requestDetails) {
        try {
            if (certificationType == requestDetails.Facility.certificationType) {
                if (certificationType == EdiServiceConstants.SERVICE_CERTIFICATION_TYPE_REVISED && (serviceReferenceNum)) {
                    return certificationType;
                } else {
                    // must also have service/ServiceReferenceNbr -- set error here since condition is not satisfied
                }
            } else {
                //reject if not same - set error
            }
        } catch (err) {
            //   console.log("Error in Edi278NServiceValidationService: validateCertificationType(): " + err);
        }
    }

    async validateProcedureCode(procedureCode, serviceSettingType, requestDetails, request) {

        try {
            // if (requestDetails.Service.requestCategory != EdiServiceConstants.SERVICE_REQUEST_CATEGORY_AR && requestDetails.Service.serviceType != EdiServiceConstants.SERVICE_TYPE_SURGICAL && procedureCode) {
            //check procedure code in HCPCS/CPT4 table
            const procedureCodeVariables = {
                procedureCode: procedureCode
            };

            const procedureCodeResponse = await this.healthServiceService.procedureCodeLookup(procedureCodeVariables, request);
            /*            if (procedureCodeResponse.cpt4[0] || procedureCodeResponse.hcpcs[0]) {
                            return procedureCodeResponse.cpt4[0] != null ? procedureCodeResponse.cpt4[0] : procedureCodeResponse.hcpcs[0];
                            // return procedureCodeResponse.cpt4[0].proc_cd != null ? procedureCodeResponse.cpt4[0].proc_cd : procedureCodeResponse.hcpcs[0].proc_cd;
                        } else {

                        }*/
            if (procedureCodeResponse.cpt4[0]) {
                procedureCodeResponse.cpt4[0].procCodeType = EdiServiceConstants.SERVICE_PROC_CODE_TYPE_CPT4;
                return procedureCodeResponse.cpt4[0];
            } else if (procedureCodeResponse.hcpcs[0]) {
                procedureCodeResponse.hcpcs[0].procCodeType = EdiServiceConstants.SERVICE_PROC_CODE_TYPE_HCPCS;
                return procedureCodeResponse.hcpcs[0];
            } else {
                //procedure code not found during lookup set error
            }

            //   }
        } catch (err) {
            //  console.log("Error in Edi278NServiceValidationService: validateCertificationType(): " + err);
        }
    }
}