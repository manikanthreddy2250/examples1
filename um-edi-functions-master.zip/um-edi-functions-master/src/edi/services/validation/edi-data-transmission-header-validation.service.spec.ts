import {Test, TestingModule} from '@nestjs/testing';
import {Injectable} from "@nestjs/common";
import {EdiDataTransmissionHeaderValidationService} from "./edi-dataTransmissionHeader-validation.service";
import {EdiUtilities} from "../../edi-utilities";
import {ConfigService} from "@nestjs/config";


@Injectable()
class UpdateHscApiClientMock {
}

describe('EdiDataTransmissionHeaderValidationService', () => {
    let service: EdiDataTransmissionHeaderValidationService;

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [EdiDataTransmissionHeaderValidationService, EdiUtilities, ConfigService],
        }).compile();

        service = module.get<EdiDataTransmissionHeaderValidationService>(EdiDataTransmissionHeaderValidationService);
    });

    it('should be defined', () => {
        expect(service).toBeDefined();
    });

    it('should run #validateSourceType()', async () => {
        const sourceType = "278";
        service.validateSourceType(sourceType);
        expect(service).toBeTruthy();
    });

    it('should run #getTestFlag()', async () => {
        const testFlag = "T";
        service.validateTestFlag(testFlag);
        expect(service).toBeTruthy();
    });

    it('should run #validatePurposeCode()', async () => {
        const purposeCode = "ABK";
        const requestDetails = {};
        const facilityDetails ="";
        service.validatePurposeCode(purposeCode, requestDetails, facilityDetails);
        expect(service).toBeTruthy();
    });
});
