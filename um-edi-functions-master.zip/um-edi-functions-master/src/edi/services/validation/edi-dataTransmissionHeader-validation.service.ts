import {Injectable} from "@nestjs/common";
import {Edi278NConstants} from "../../constants/edi-278N.constants";
import {EdiUtilities} from "../../edi-utilities";
import {
    EdiSourceTypeConstants,
    EnvironmentConstants,
    facilityAttributes,
    TestFlagConstants
} from "../../constants/edi.constants";
import {ConfigService} from "@nestjs/config";

@Injectable()
export class EdiDataTransmissionHeaderValidationService {

    constructor(protected readonly ediUtils: EdiUtilities, private readonly configService: ConfigService){}


    validateSourceType(sourceType){
        if(sourceType){
          if(EdiSourceTypeConstants.EDI_278 == sourceType){
              return sourceType;
          }
        }
        //set error
        return null;
    }

    validateTestFlag(testFlag){
        const environment = this.configService.get<string>('ENV_NAME');

        if(testFlag){
            if((testFlag == TestFlagConstants.ISA15_TEST && (environment == EnvironmentConstants.ENV_DEV || environment == EnvironmentConstants.ENV_TST))
                || (testFlag == TestFlagConstants.ISA15_PRODUCTION && (environment == EnvironmentConstants.ENV_STG || environment == EnvironmentConstants.ENV_PRD))){
                return testFlag;
            }else if(testFlag == TestFlagConstants.ISA15_TEST && environment == EnvironmentConstants.ENV_LCL){
                return "L"; //local
            }else{
                // testFlag does not satisfy validation logic, set error
            }
        }
        //test flag is required - set error
    }

    validatePurposeCode(purposeCode, requestDetails, facilityDetails){}

}