import {Injectable} from "@nestjs/common";
import {EdiUtilities} from "../../edi-utilities";
import {HealthServiceService} from "../healthService/healthService.service";

@Injectable()
export class EdiDiagnosisValidationService {

    constructor(protected readonly ediUtils: EdiUtilities,
                readonly healthServiceService: HealthServiceService){}
    //  If Primary diag sent, set to primary
    //  If primary diag not sent, set admitting code to primary.  If neither admitting nor primary sent, set first diag cd received to primary.


    getDiagnosisCodeSchemaRefID(diagnosisCodeType, diagnosis){}

}