import {Test, TestingModule} from '@nestjs/testing';
import {Injectable} from "@nestjs/common";
import {EdiDiagnosisValidationService} from "./edi-diagnosis-validation.service";
import {EdiUtilities} from "../../edi-utilities";
import {HealthServiceService} from "../healthService/healthService.service";
import {HealthServiceClient} from "../../../shared/graphql/healthservicedomain/healthServiceClient";
import {ConfigService} from "@nestjs/config";


describe('EdiDiagnosisValidationService', () => {
    let component: EdiDiagnosisValidationService;

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [EdiDiagnosisValidationService, EdiUtilities, HealthServiceService, HealthServiceClient, ConfigService],
        }).compile();

        component = module.get<EdiDiagnosisValidationService>(EdiDiagnosisValidationService);
    });

    it('should be defined', () => {
        expect(component).toBeDefined();
    });

    it('should run #getDiagnosisCodeSchemaRefID()', async () => {
        const diagnosisCodeType="ABK";
        const diagnosis = "M45.23";
        component.getDiagnosisCodeSchemaRefID(diagnosisCodeType, diagnosis);
        expect(component).toBeTruthy();
    });
});
