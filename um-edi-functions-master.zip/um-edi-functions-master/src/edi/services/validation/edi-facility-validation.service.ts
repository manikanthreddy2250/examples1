import {Injectable} from "@nestjs/common";
import {EdiUtilities} from "../../edi-utilities";
import {
    canonicalRequestTags, EdiAdmissionTypeCodeConstants,
    EdiFacilityConstants,
    EdiMemberConstants, EdiServiceDescriptionTypeConstants, EdiServiceSettingTypeConstants,
    facilityAttributes, PatientStatusCode
} from "../../constants/edi.constants";
import {AppService} from "../../../app.service";
import {Edi278NConstants} from "../../constants/edi-278N.constants";

@Injectable()
export class EdiFacilityValidationService {

    constructor(protected readonly ediUtils: EdiUtilities,
                protected readonly appService: AppService) {
    }

    async getServiceSettingType(event, hscData) {
        let serviceSettingType;
        const facilityDetails = this.ediUtils.getElementInfo(event, canonicalRequestTags.FACILITY);

        try {
            if (facilityDetails) {
                const facilityCode = this.ediUtils.getAttributeValue(facilityDetails, facilityAttributes.FACILITYCODE);
                const facilityCodeQualifier = this.ediUtils.getAttributeValue(facilityDetails, facilityAttributes.FACILITYCODEQUALIFIER);

                if (facilityCode == '21' && facilityCodeQualifier == 'A') {
                    serviceSettingType = EdiServiceSettingTypeConstants.SERVICE_SETTING_INPATIENT;
                }

                //Get RefID of serviceSettingType
                const refDataResults = this.appService.getRefMatchDesc('serviceSettingType', serviceSettingType);
                if (refDataResults) {
                    hscData.srvc_set_ref_id = refDataResults.ref_id;
                    return serviceSettingType;
                }
            }
        } catch (err) {
            console.log("Error in EdiFacilityValidationService: getServiceSettingType(): " + err);
        }
    }

    validateRequestCategory(serviceSettingType, requestCategory) {
        try {
            if (requestCategory) {
                if (EdiServiceSettingTypeConstants.SERVICE_SETTING_INPATIENT == serviceSettingType && EdiFacilityConstants.FACL_REQUEST_CATEGORY_AR == requestCategory) {
                    return requestCategory;
                } else {
                    //fails to satisfy requestCategory validation logic
                }
            } else {
                //required value
            }
        } catch (err) {
            console.log("Error in EdiFacilityValidationService: validateRequestCategory(): " + err);
        }
    }

    validateCertificateType(certificateType) {
        try {
            if (EdiFacilityConstants.FACL_CERTIFICATION_TYPE_INITIAL == certificateType || EdiFacilityConstants.FACL_CERTIFICATION_TYPE_REVISED == certificateType) {
                return certificateType;
            } else {
                //fails to satisfy certificate type validation logic
            }
        } catch (err) {
            console.log("Error in EdiFacilityValidationService: validateCertificateType(): " + err);
        }
    }

    validateServiceReferenceNumber(serviceReferenceNumber) {
        try {
            //SRN should be alphanumeric
            if (serviceReferenceNumber) {
                if (this.ediUtils.isAlphaNumeric(serviceReferenceNumber)) {
                    return serviceReferenceNumber;
                } else {
                    //set error -SRN not alphanumeric -- error 20124
                }
            }
        } catch (err) {
            console.log("Error in EdiFacilityValidationService: validateServiceReferenceNumber(): " + err);
        }
    }

    validateAdmissionTypeCode(admissionTypeCode) {
        let serviceDescriptionType;
        let refID: number;

        try {
            if (admissionTypeCode) {
                if (admissionTypeCode == EdiAdmissionTypeCodeConstants.ADMISSION_TYPE_ELECTIVE || admissionTypeCode == EdiAdmissionTypeCodeConstants.ADMISSION_TYPE_NEWBORN) {
                    serviceDescriptionType = EdiServiceDescriptionTypeConstants.SERVICE_DESCRIPTION_TYPE_SCHEDULED;
                } else if (admissionTypeCode == EdiAdmissionTypeCodeConstants.ADMISSION_TYPE_URGENT) {
                    serviceDescriptionType = EdiServiceDescriptionTypeConstants.SERVICE_DESCRIPTION_TYPE_URGENT;
                } else if (admissionTypeCode == EdiAdmissionTypeCodeConstants.ADMISSION_TYPE_EMERGENCY) {
                    serviceDescriptionType = EdiServiceDescriptionTypeConstants.SERVICE_DESCRIPTION_TYPE_EMERGENT;
                }

                //Get RefID of serviceDescriptionType
                const refDataResults = this.appService.getRefMatchCode('serviceDescriptionType', serviceDescriptionType);
                if (refDataResults) {
                    refID = refDataResults.ref_id;
                    return refID;
                }
            } else {
                //admission type code is required --set error
            }
        } catch (err) {
            console.log("Error in EdiFacilityValidationService: validateAdmissionTypeCode(): " + err);
        }
    }

    validateAdmissionDate(admissionDate, requestCategory, requestDetails) {
        const purposeCode = requestDetails.dataTransmissionHeader.purposeCode;

        try {
            if (EdiFacilityConstants.FACL_REQUEST_CATEGORY_AR == requestCategory && admissionDate) {
                const newAdmissionDate = new Date(admissionDate);
                const currentDate = new Date();

                if (purposeCode === Edi278NConstants.BHT02_COMPLETION_NOTIFICATION && (newAdmissionDate <= currentDate)) {
                    return admissionDate;
                } else {
                    //admissiondate is required - set error
                }
            } else {
                //admission date is required if request category is AR --set error
            }
        } catch (err) {
            console.log("Error in EdiFacilityValidationService: validateAdmissionDate(): " + err);
        }
    }

    translatePatientStatusCode(patientStatusCode) {
        let statusCodeNote;

        try {
            if (patientStatusCode) {
                switch (patientStatusCode) {
                    case '1':
                        statusCodeNote = PatientStatusCode.PATIENT_STATUS_CODE_1;
                        break;
                    case '2':
                        statusCodeNote = PatientStatusCode.PATIENT_STATUS_CODE_2;
                        break;
                    case '3':
                        statusCodeNote = PatientStatusCode.PATIENT_STATUS_CODE_3;
                        break;
                    case '4':
                        statusCodeNote = PatientStatusCode.PATIENT_STATUS_CODE_4;
                        break;
                    case '5':
                        statusCodeNote = PatientStatusCode.PATIENT_STATUS_CODE_5;
                        break;
                    case '6':
                        statusCodeNote = PatientStatusCode.PATIENT_STATUS_CODE_6;
                        break;
                    case '7':
                        statusCodeNote = PatientStatusCode.PATIENT_STATUS_CODE_7;
                        break;
                    case '9':
                        statusCodeNote = PatientStatusCode.PATIENT_STATUS_CODE_9;
                        break;
                    case '20':
                        statusCodeNote = PatientStatusCode.PATIENT_STATUS_CODE_20;
                        break;
                    case '30':
                        statusCodeNote = PatientStatusCode.PATIENT_STATUS_CODE_30;
                        break;
                    case '40':
                        statusCodeNote = PatientStatusCode.PATIENT_STATUS_CODE_40;
                        break;
                    case '41':
                        statusCodeNote = PatientStatusCode.PATIENT_STATUS_CODE_41;
                        break;
                    case '42':
                        statusCodeNote = PatientStatusCode.PATIENT_STATUS_CODE_42;
                        break;
                    case '43':
                        statusCodeNote = PatientStatusCode.PATIENT_STATUS_CODE_43;
                        break;
                    case '50':
                        statusCodeNote = PatientStatusCode.PATIENT_STATUS_CODE_50;
                        break;
                    case '51':
                        statusCodeNote = PatientStatusCode.PATIENT_STATUS_CODE_51;
                        break;
                    case '61':
                        statusCodeNote = PatientStatusCode.PATIENT_STATUS_CODE_61;
                        break;
                    case '62':
                        statusCodeNote = PatientStatusCode.PATIENT_STATUS_CODE_62;
                        break;
                    case '63':
                        statusCodeNote = PatientStatusCode.PATIENT_STATUS_CODE_63;
                        break;
                    case '64':
                        statusCodeNote = PatientStatusCode.PATIENT_STATUS_CODE_64;
                        break;
                    case '65':
                        statusCodeNote = PatientStatusCode.PATIENT_STATUS_CODE_65;
                        break;
                    case '66':
                        statusCodeNote = PatientStatusCode.PATIENT_STATUS_CODE_66;
                        break;
                    case '70':
                        statusCodeNote = PatientStatusCode.PATIENT_STATUS_CODE_70;
                        break;
                    default:
                        break;
                }
                return statusCodeNote;
            }
        } catch (err) {
            console.log("Error in EdiFacilityValidationService: translatePatientStatusCode(): " + err);
        }
    }
}