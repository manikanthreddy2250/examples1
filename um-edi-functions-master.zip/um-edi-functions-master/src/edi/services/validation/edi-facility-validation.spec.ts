import {EdiUtilities} from "../../edi-utilities";
import {Test, TestingModule} from "@nestjs/testing";
import {EdiFacilityValidationService} from "./edi-facility-validation.service";
import {testCanonicalRequest} from "../../../../test/ediTestData";
import {canonicalRequestTags, Error, PatientStatusCode, RequestDetails} from "../../constants/edi.constants";
import {Injectable} from "@nestjs/common";
import {AppService} from "../../../app.service";

@Injectable()
class AppServiceMock {
    getRefMatchCode(baseRefName, refCode) {
        return "123";
    }

    getRefMatchDesc(baseRefName, refCode) {
        return "123";
    }
}

describe('EdiFacilityValidationService', () => {
    let component: EdiFacilityValidationService;
    let ediUtilities: EdiUtilities;
    let event = null;
    var appService = new AppServiceMock();

    const requestDetails: RequestDetails = {
        dataTransmissionHeader: {
            sourceType: null,
            transactionID: null,
            version: null,
            batchFileID: null,
            receivedDateTime: null,
            purposeCode: "CN",
            transactionType: null,
            transactionStatus: null,
            testFlag: null,
            clinicalApplication: null,
            payerID: null,
            submitterID: null,
            ediID: null,
            sourceData: null,
            tradingPartnerID: null
        },
        Membership: {
            mbrshp: {
                scrbr_id_txt: "123",
                sbscr_fst_nm: null,
                sbscr_lst_nm: null,
                sbscr_empmt_dt: null,
                cob_ind: null,
                mbr_rel_ref_id: null,
                sbscr_bth_dt: null,
                mbr_covs: null,
            }
        },
        Individual: {
            indv: {
                fst_nm: "Matt",
                lst_nm: "Meyer",
                bth_dt: "07-18-1993",
                midl_nm: null,
                sufx_nm: null,
                gdr_ref_id: null,
                sourceData: null,
                indv_adrs: null
            }
        },
        Provider: null,
        Facility: null,
        Diagnosis: null,
        Event: null,
        procCodes: null,
        Service: null,
        updateHscRequest: null,
        hscSourceData: null,
        ediType: null,
        followUpContact: null,
        Error: null

};

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [EdiFacilityValidationService, EdiUtilities,
                {provide: AppService, useClass: AppServiceMock}],
        }).compile();

        component = module.get<EdiFacilityValidationService>(EdiFacilityValidationService);
        ediUtilities = module.get<EdiUtilities>(EdiUtilities);
        event = ediUtilities.getElementInfo(testCanonicalRequest, canonicalRequestTags.EVENT);
    });

    it('should be defined', () => {
        expect(component).toBeDefined();
    });

    it('should run #getServiceSettingType()', async () => {
        const hscData = {
            hsc_id: 1,
            indv_key_typ_ref_id: null,
            indv_key_val: null,
            srvc_set_ref_id: 3737,
            rev_prr_ref_id: 3754,
        };
        spyOn(appService, 'getRefMatchDesc').and.callThrough();
        component.getServiceSettingType(event, hscData);
        expect(component).toBeTruthy();
    });

    it('should run #validateRequestCategory()', async () => {
        const serviceSettingType = "Inpatient";
        const requestCategory = "AR";

        component.validateRequestCategory(serviceSettingType, requestCategory);
        expect(component).toBeTruthy();
    });

    it('should run #validateCertificateType()', async () => {
        const certificateType = "I";

        component.validateCertificateType(certificateType);
        expect(component).toBeTruthy();
    });

    it('should run #validateServiceReferenceNumber()', async () => {
        const serviceReferenceNumber = "test123";

        component.validateServiceReferenceNumber(serviceReferenceNumber);
        expect(component).toBeTruthy();
    });

    it('should run #validateAdmissionDate()', async () => {
        const admissionDate = "07-18-21";

        component.validateAdmissionDate(admissionDate, "AR", requestDetails);
        expect(component).toBeTruthy();
    });

    it('should run #validateAdmissionTypeCode()', async () => {
        const admissionTypeCode = "1";
        spyOn(appService, 'getRefMatchCode').and.callThrough();

        component.validateAdmissionTypeCode(admissionTypeCode);
        expect(component).toBeTruthy();
    });

    it('should run #translatePatientStatusCode() - 1', async () => {
        const patientStatusCode = "1";

        component.translatePatientStatusCode(patientStatusCode);
        expect(component).toBeTruthy();
    });

    it('should run #translatePatientStatusCode() - 2', async () => {
        const patientStatusCode = "2";

        component.translatePatientStatusCode(patientStatusCode);
        expect(component).toBeTruthy();
    });

    it('should run #translatePatientStatusCode() - 3', async () => {
        const patientStatusCode = "3";

        component.translatePatientStatusCode(patientStatusCode);
        expect(component).toBeTruthy();
    });

    it('should run #translatePatientStatusCode() - 4', async () => {
        const patientStatusCode = "4";

        component.translatePatientStatusCode(patientStatusCode);
        expect(component).toBeTruthy();
    });

    it('should run #translatePatientStatusCode() - 5', async () => {
        const patientStatusCode = "5";

        component.translatePatientStatusCode(patientStatusCode);
        expect(component).toBeTruthy();
    });

    it('should run #translatePatientStatusCode() - 6', async () => {
        const patientStatusCode = "6";

        component.translatePatientStatusCode(patientStatusCode);
        expect(component).toBeTruthy();
    });

    it('should run #translatePatientStatusCode() - 7', async () => {
        const patientStatusCode = "7";

        component.translatePatientStatusCode(patientStatusCode);
        expect(component).toBeTruthy();
    });

    it('should run #translatePatientStatusCode() - 9', async () => {
        const patientStatusCode = "9";

        component.translatePatientStatusCode(patientStatusCode);
        expect(component).toBeTruthy();
    });

    it('should run #translatePatientStatusCode() - 20', async () => {
        const patientStatusCode = "20";

        component.translatePatientStatusCode(patientStatusCode);
        expect(component).toBeTruthy();
    });

    it('should run #translatePatientStatusCode() - 30', async () => {
        const patientStatusCode = "30";

        component.translatePatientStatusCode(patientStatusCode);
        expect(component).toBeTruthy();
    });

    it('should run #translatePatientStatusCode() - 40', async () => {
        const patientStatusCode = "40";

        component.translatePatientStatusCode(patientStatusCode);
        expect(component).toBeTruthy();
    });

    it('should run #translatePatientStatusCode() - 41', async () => {
        const patientStatusCode = "41";

        component.translatePatientStatusCode(patientStatusCode);
        expect(component).toBeTruthy();
    });

    it('should run #translatePatientStatusCode() - 42', async () => {
        const patientStatusCode = "42";

        component.translatePatientStatusCode(patientStatusCode);
        expect(component).toBeTruthy();
    });

    it('should run #translatePatientStatusCode() - 43', async () => {
        const patientStatusCode = "43";

        component.translatePatientStatusCode(patientStatusCode);
        expect(component).toBeTruthy();
    });

    it('should run #translatePatientStatusCode() - 50', async () => {
        const patientStatusCode = "50";

        component.translatePatientStatusCode(patientStatusCode);
        expect(component).toBeTruthy();
    });

    it('should run #translatePatientStatusCode() - 51', async () => {
        const patientStatusCode = "51";

        component.translatePatientStatusCode(patientStatusCode);
        expect(component).toBeTruthy();
    });

    it('should run #translatePatientStatusCode() - 61', async () => {
        const patientStatusCode = "61";

        component.translatePatientStatusCode(patientStatusCode);
        expect(component).toBeTruthy();
    });

    it('should run #translatePatientStatusCode() - 62', async () => {
        const patientStatusCode = "62";

        component.translatePatientStatusCode(patientStatusCode);
        expect(component).toBeTruthy();
    });

    it('should run #translatePatientStatusCode() - 63', async () => {
        const patientStatusCode = "63";

        component.translatePatientStatusCode(patientStatusCode);
        expect(component).toBeTruthy();
    });

    it('should run #translatePatientStatusCode() - 64', async () => {
        const patientStatusCode = "64";

        component.translatePatientStatusCode(patientStatusCode);
        expect(component).toBeTruthy();
    });

    it('should run #translatePatientStatusCode() - 65', async () => {
        const patientStatusCode = "65";

        component.translatePatientStatusCode(patientStatusCode);
        expect(component).toBeTruthy();
    });

    it('should run #translatePatientStatusCode() - 66', async () => {
        const patientStatusCode = "66";

        component.translatePatientStatusCode(patientStatusCode);
        expect(component).toBeTruthy();
    });

    it('should run #translatePatientStatusCode() - 70', async () => {
        const patientStatusCode = "70";

        component.translatePatientStatusCode(patientStatusCode);
        expect(component).toBeTruthy();
    });

});