import {Injectable} from "@nestjs/common";
import {EdiUtilities} from "../../edi-utilities";
import {EdiMemberConstants} from "../../constants/edi.constants";

@Injectable()
export class EdiMemberValidationService {

    validateGender(gender){
        if(gender) {
            if (EdiMemberConstants.GENDER_M == gender || EdiMemberConstants.GENDER_F == gender || EdiMemberConstants.GENDER_U == gender) {
                return gender;
            } else {
                //fails to satisfy gender validation logic
            }
        }else{
            //Gender not sent, default to U
            return EdiMemberConstants.GENDER_U;
        }
    }

    validateOtherUMOType(otherUMOType){
        if(EdiMemberConstants.OTHER_CARRIER == otherUMOType || EdiMemberConstants.MEDICARE_PART_A == otherUMOType ||
            EdiMemberConstants.MEDICARE_PART_B == otherUMOType){
            return otherUMOType;
        }else{
            //ignore all other values
           // fails to satisfy otherUMOType validation logic
        }
    }

}