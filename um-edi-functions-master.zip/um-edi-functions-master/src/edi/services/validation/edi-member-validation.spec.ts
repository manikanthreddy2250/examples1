import {Test, TestingModule} from '@nestjs/testing';
import {Injectable} from "@nestjs/common";
import {EdiMemberValidationService} from "./edi-member-validation.service";


describe('EdiMemberValidationService', () => {
    let component: EdiMemberValidationService;

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [EdiMemberValidationService],
        }).compile();

        component = module.get<EdiMemberValidationService>(EdiMemberValidationService);
    });

    it('should be defined', () => {
        expect(component).toBeDefined();
    });

    it('should run #validateGender()', async () => {
        const gender = "M";

        component.validateGender(gender);
        expect(component).toBeTruthy();
    });

    it('should run #validateOtherUMOType()', async () => {
        const otherUMOType = "00";

        component.validateOtherUMOType(otherUMOType)
        expect(component).toBeTruthy();
    });
});
