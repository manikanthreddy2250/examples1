import {Injectable} from "@nestjs/common";
import {EdiProviderConstants, EdiServiceSettingTypeConstants} from "../../constants/edi.constants";
import {Edi278NCanonicalProviderConstants} from "../../constants/edi-278N.constants";
import {AppService} from "../../../app.service";

@Injectable()
export class EdiProviderValidationService {

    constructor(protected readonly appService: AppService) {
    }

    validateProviderFirstName(firstName, lastName, entityType) {
        if (lastName && entityType == '1') {
            if (firstName) {
                return firstName;
            } else {
                //fails to satisfy firstName validation logic - first Name required
            }
        } else {
            //Does not require first name
            return firstName;
        }
    }

    validateProviderLastName(lastName) {
        if (lastName) {
            return lastName;
        } else {
            //fails to satisfy lastName validation logic - last Name required
        }
    }

    validateEntityType(entityType) {
        if (entityType) {
            return entityType;
        } else {
            //fails to satisfy entityType validation logic - entityType required
        }
    }

    validateEntityIdentifier(entityIdentifier) {
        if (entityIdentifier) {
            return entityIdentifier;
        } else {
            //fails to satisfy entityIdentifier validation logic - entityIdentifier required
        }
    }

    validateProviders(serviceSettingType, providers) {
        /* Minimum Requirement is one facility and one EITHER Admitting (AAJ) OR Attending (71) provider per Inpatient case
            and one servicing provider (if service sent)  */

        if (serviceSettingType == EdiServiceSettingTypeConstants.SERVICE_SETTING_INPATIENT) {
            let isFacilityProvider: boolean = false;
            let isAdmittingProvider: boolean = false;
            let isAttendingProvider: boolean = false;
            //   let isServicingProvider: boolean = false;

            for (const prov of providers) {
                if (prov.entityIdentifier == Edi278NCanonicalProviderConstants.FACILITY_PROVIDER) {
                    isFacilityProvider = true;
                } else if (prov.entityIdentifier == Edi278NCanonicalProviderConstants.ADMITTING_PROVIDER) {
                    isAdmittingProvider = true;
                } else if (prov.entityIdentifier == Edi278NCanonicalProviderConstants.ATTENDING_PROVIDER) {
                    isAttendingProvider = true;
                }
                /*else if(prov.entityIdentifier == Edi278NCanonicalProviderConstants.SERVICING_PROVIDER){
                                        isServicingProvider = true;
                                    }*/
            }

            if (isFacilityProvider && (isAttendingProvider || isAdmittingProvider)) {
                return true; //satisfied minimum requirement
            }
        }
        return false;
    }

    getProviderRole(entityIdentifier, attendingProviderExists) {
        let providerRole;
        let providerRoleRefID;

        if (entityIdentifier == Edi278NCanonicalProviderConstants.FACILITY_PROVIDER) {
            providerRole = EdiProviderConstants.FACILITY_PROVIDER;
        } else if (entityIdentifier == Edi278NCanonicalProviderConstants.ADMITTING_PROVIDER) {
            if (attendingProviderExists) {
                providerRole = EdiProviderConstants.ADMITTING_PROVIDER;
            } else {
                providerRole = EdiProviderConstants.ATTENDING_PROVIDER;
            }
        } else if (entityIdentifier == Edi278NCanonicalProviderConstants.ATTENDING_PROVIDER) {
            providerRole = EdiProviderConstants.ATTENDING_PROVIDER;
        } else if (entityIdentifier == Edi278NCanonicalProviderConstants.SERVICING_PROVIDER) {
            providerRole = EdiProviderConstants.SERVICING_PROVIDER;
        } else {
            //not valid provider role -set error
        }

        //Get RefID of Provider Role
        const refDataResults = this.appService.getRefMatchCode('providerRole', providerRole);
        if (refDataResults) {
            providerRoleRefID = refDataResults.ref_id;
            return providerRoleRefID;
        } else {
            //providerRole does not exists in ref domain -set error
        }
    }

    checkAttendingProvider(providers) {
        for (const prov of providers) {
            if (prov.entityIdentifier == Edi278NCanonicalProviderConstants.ATTENDING_PROVIDER) {
                return true;
            }
        }
        return false;
    }

}