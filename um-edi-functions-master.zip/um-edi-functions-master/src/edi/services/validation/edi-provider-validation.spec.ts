import {Test, TestingModule} from '@nestjs/testing';
import {Injectable} from "@nestjs/common";
import {EdiProviderValidationService} from "./edi-provider-validation.service";
import {AppService} from "../../../app.service";
import {canonicalRequestTags} from "../../constants/edi.constants";
import {EdiUtilities} from "../../edi-utilities";
import {testCanonicalRequest} from "../../../../test/ediTestData";

@Injectable()
class AppServiceMock {
    getRefMatchCode(baseRefName, refCode) {
        return "123";
    }

    getRefMatchDesc(baseRefName, refCode) {
        return "123";
    }
}

describe('EdiProviderValidationService', () => {
    let component: EdiProviderValidationService;
    let providerDetails;
    let ediUtilities: EdiUtilities;
    let event;

    let providers = [
        {
            entityIdentifier: "FA"
        },
        {
            entityIdentifier: "71"
        }
    ]

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [EdiProviderValidationService, EdiUtilities,
                {provide: AppService, useClass: AppServiceMock}],
        }).compile();

        component = module.get<EdiProviderValidationService>(EdiProviderValidationService);
        ediUtilities = module.get<EdiUtilities>(EdiUtilities);
        event = ediUtilities.getElementInfo(testCanonicalRequest, canonicalRequestTags.EVENT);
        providerDetails = ediUtilities.getElementInfo(event, canonicalRequestTags.PROVIDERS);

    });

    it('should be defined', () => {
        expect(component).toBeDefined();
    });

    it('should run #validateProviderFirstName()', async () => {
        const firstName = "Matt";
        const lastName = "Meyer";
        const entityType = "1";

        component.validateProviderFirstName(firstName, lastName, entityType);
        expect(component).toBeTruthy();
    });

    it('should run #validateProviderLastName()', async () => {
        const lastName = "Meyer";

        component.validateProviderLastName(lastName);
        expect(component).toBeTruthy();
    });

    it('should run #validateEntityType()', async () => {
        const entityType = "1";

        component.validateEntityType(entityType);
        expect(component).toBeTruthy();
    });

    it('should run #validateEntityIdentifier()', async () => {
        const entityIdentifier = "AAJ";

        component.validateEntityIdentifier(entityIdentifier);
        expect(component).toBeTruthy();
    });

    it('should run #validateProviders()', async () => {
        const entityType = "1";

        component.validateProviders("Inpatient", providers);
        expect(component).toBeTruthy();
    });

    it('should run #getProviderRole() --Admitting', async () => {
        const entityIdentifier = "AAJ";

        component.getProviderRole(entityIdentifier, true);
        expect(component).toBeTruthy();
    });

    it('should run #getProviderRole() - Attending', async () => {
        const entityIdentifier = "71";

        component.getProviderRole(entityIdentifier, true);
        expect(component).toBeTruthy();
    });

    it('should run #getProviderRole() - Facility', async () => {
        const entityIdentifier = "FA";

        component.getProviderRole(entityIdentifier, true);
        expect(component).toBeTruthy();
    });

    it('should run #getProviderRole() - Servicing', async () => {
        const entityIdentifier = "SJ";

        component.getProviderRole(entityIdentifier, true);
        expect(component).toBeTruthy();
    });

    it('should run #checkAttendingProvider()', async () => {

        component.checkAttendingProvider(providers);
        expect(component).toBeTruthy();
    });
});
