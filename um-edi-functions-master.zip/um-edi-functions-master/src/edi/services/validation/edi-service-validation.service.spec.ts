import {testCanonicalRequest} from "../../../../test/ediTestData";
import {AppService} from "../../../app.service";
import {Test, TestingModule} from "@nestjs/testing";
import {EdiProviderValidationService} from "./edi-provider-validation.service";
import {
    canonicalRequestTags, DataTransHeader,
    EventData, FacilityData,
    HscData,
    Indiv,
    Member,
    Provider,
    RequestDetails, ServiceData
} from "../../constants/edi.constants";
import {EdiUtilities} from "../../edi-utilities";
import {EdiServiceValidationService} from "./edi-service-validation.service";
import {HealthServiceService} from "../healthService/healthService.service";
import {HealthServiceClient} from "../../../shared/graphql/healthservicedomain/healthServiceClient";
import {ConfigService} from "@nestjs/config";

describe('EdiServiceValidationService', () => {
    let component: EdiServiceValidationService;
    let providerDetails;
    let ediUtilities: EdiUtilities;
    let event;

    let providers = [
        {
            entityIdentifier: "FA"
        },
        {
            entityIdentifier: "71"
        }
    ];

    const requestDetails: RequestDetails = {
        dataTransmissionHeader: null,
        Membership: {
            mbrshp: {
                scrbr_id_txt: "123",
                sbscr_fst_nm: null,
                sbscr_lst_nm: null,
                sbscr_empmt_dt: null,
                cob_ind: null,
                mbr_rel_ref_id: null,
                sbscr_bth_dt: null,
                mbr_covs: null,

            }
        },
        Individual: {
            indv: {
                fst_nm: "Matt",
                lst_nm: "Meyer",
                bth_dt: "07-18-1993",
                midl_nm: null,
                sufx_nm: null,
                gdr_ref_id: null,
                sourceData: null,
                indv_adrs: null
            }
        },
        Provider: null,
        Facility: null,
        Diagnosis: null,
        Event: null,
        procCodes: null,
        Service: null,
        updateHscRequest: null,
        hscSourceData: null,
        ediType: null,
        followUpContact: null,
        Error: null
    };

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [EdiServiceValidationService, EdiUtilities, HealthServiceService, HealthServiceClient, ConfigService]
        }).compile();

        component = module.get<EdiServiceValidationService>(EdiServiceValidationService);
        ediUtilities = module.get<EdiUtilities>(EdiUtilities);
        event = ediUtilities.getElementInfo(testCanonicalRequest, canonicalRequestTags.EVENT);
        providerDetails = ediUtilities.getElementInfo(event, canonicalRequestTags.PROVIDERS);

    });

    it('should be defined', () => {
        expect(component).toBeDefined();
    });

    it('should run #validateRequestCategory()', async () => {
        const requestCategory = "AR";

        component.validateRequestCategory(requestCategory);
        expect(component).toBeTruthy();
    });

    it('should run #validateCertificationType()', async () => {
        const certificationType = "AR";
        const serviceReferenceNum = "test124";

        component.validateCertificationType(certificationType, serviceReferenceNum, requestDetails);
        expect(component).toBeTruthy();
    });

    it('should run #validateCertificationType()', async () => {
        const serviceReferenceNumber = "test124";

        component.validateServiceReferenceNumber(serviceReferenceNumber);
        expect(component).toBeTruthy();
    });

});