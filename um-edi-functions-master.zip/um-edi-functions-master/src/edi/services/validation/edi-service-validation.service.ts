import {Injectable} from "@nestjs/common";
import {EdiUtilities} from "../../edi-utilities";
import {HealthServiceService} from "../healthService/healthService.service";

@Injectable()
export class EdiServiceValidationService {

    constructor(protected readonly ediUtils: EdiUtilities,
                protected readonly healthServiceService: HealthServiceService) {
    }

    validateRequestCategory(requestCategory) {
    }

    validateCertificationType(certificationType, serviceReferenceNum, requestDetails) {
    }

    validateServiceReferenceNumber(serviceReferenceNumber) {
        try {
            //SRN should be alphanumeric
            if (serviceReferenceNumber && this.ediUtils.isAlphaNumeric(serviceReferenceNumber)) {
                return serviceReferenceNumber;
            } else {
                //set error -SRN not alphanumeric -- error 20124
            }

        } catch (err) {
            console.log("Error in EdiServiceValidationService: validateServiceReferenceNumber(): " + err);
        }
    }
}