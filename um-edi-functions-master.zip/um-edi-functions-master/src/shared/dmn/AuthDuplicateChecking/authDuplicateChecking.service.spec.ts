import {HttpService, HttpModule, Injectable} from "@nestjs/common";
import {ConfigService} from "@nestjs/config";
import {GraphQLClient} from "graphql-request/dist";
import {Observable} from 'rxjs';
import {tap} from "rxjs/operators";
import {of} from "rxjs/internal/observable/of";
import {HttpClient, HttpHeaders} from '@angular/common/http';
import { Test, TestingModule } from '@nestjs/testing';
import { AuthDuplicateCheckingService } from './authDuplicateChecking.service';

class MockConfigService extends ConfigService {
  get(propertyPath: any){
    return 'testvalue';
  };
}

@Injectable()
class MockHttpClient {
  post() {};
}

@Injectable()
class MockHttpService {
  post() {};
}

jest.mock('axios');
describe('AuthDuplicateCheckingService', () => {
  let service: AuthDuplicateCheckingService;
  let httpService: HttpService;

    beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      imports: [HttpModule],
      providers: [AuthDuplicateCheckingService, {provide: ConfigService, useClass: MockConfigService},
      {provide: HttpClient, useClass: MockHttpClient},],
    }).compile();

       service = module.get<AuthDuplicateCheckingService>(AuthDuplicateCheckingService);
        httpService = module.get<HttpService>(HttpService);
      });

      it('should be defined', () => {
        expect(service).toBeDefined();
      });
});
