import {HttpService, Injectable} from "@nestjs/common";
import {ConfigService} from "@nestjs/config";
import {GraphQLClient} from "graphql-request/dist";
import {Observable} from 'rxjs';
import {tap} from "rxjs/operators";
import {of} from "rxjs/internal/observable/of";
import {HttpClient, HttpHeaders} from '@angular/common/http';

@Injectable()
export class AuthDuplicateCheckingService {
accessToken;
dmntoken: string;

constructor(private readonly configService: ConfigService,
            private http: HttpClient,
            private httpService: HttpService) {}

    body = {"hsc":{"serviceType":"Generic","serviceSettingRefId":3737}, "currentStep": 0 }​

    duplicateCheck(request): Observable<any> {

        const headers = {
            'content-type': 'application/json',
            Authorization: request.headers['authorization'],
            'x-bpm-cli-org-id':'uhc',
            'x-bpm-func-role':'um_uhc_system',
            'x-bpm-tenant-id':'uhcumintakeuhcdmngrp',
        };
        return this.httpService.post(this.configService.get<string>('AUTH_DUPLICACATECHECKING_API'), this.body, {headers:headers});
    }

}