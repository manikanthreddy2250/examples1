import { GraphQLClient } from 'graphql-request/dist';
import { ConfigService } from '@nestjs/config';
import { Injectable } from '@nestjs/common';
import { HttpRequest } from '@azure/functions';

@Injectable()
export class HealthServiceClient {
  private healthServiceClient;

  constructor(private readonly configService: ConfigService) {
    this.healthServiceClient = new GraphQLClient(
      configService.get<string>('HEALTH_SERVICE_API_ENDPOINT'),
    );
  }

  delay() {
    return new Promise(resolve => setTimeout(resolve, 1000));
  }

  public getGraphqlClient(req: HttpRequest): GraphQLClient {
    this.delay();
    const headers = {
      'content-type': req.headers['content-type'],
      Authorization: req.headers['authorization'],
      'x-hasura-role': req.headers['x-hasura-role'],
    };
    this.healthServiceClient.setHeaders(headers);
    return this.healthServiceClient;
  }
}