export const createHscShell = `
            mutation createHscShell($srcRecDoc: jsonb, 
                                    $createSystemRefId: Int!,
                                    $hscStatusRefId: Int!,
                                    $hscStatusReasonRefId: Int!,
                                    $ediTransactionKeyTypeId: Int!,
                                    $transactionId: String!
                                    $kafkaIdKeyTypeId: Int!,
                                    $kafkaId: String!) {

              insert_hsc(objects: {hsc_src_recs: {data: {src_rec_doc: $srcRecDoc}},
                                   creat_sys_ref_id: $createSystemRefId,
                                   hsc_sts_ref_id: $hscStatusRefId,
                                   hsc_sts_rsn_ref_id: $hscStatusReasonRefId,
                                   hsc_keys: {data: [{hsc_key_val: $transactionId, hsc_key_typ_ref_id: $ediTransactionKeyTypeId},
                                                     {hsc_key_val: $kafkaId, hsc_key_typ_ref_id: $kafkaIdKeyTypeId}]},                                                 
                                   hsc_facls: {data: { plsrv_ref_id: 3747,  
                                                       srvc_desc_ref_id: 4349,  
                                                       srvc_dtl_ref_id: 4319}}                 
                                   }) {
                returning {
                  hsc_id
                  hsc_src_recs {
                    hsc_id
                    src_rec_doc
                  }
                }
              }
            }
            `;

export const diagnosisCodeQuery = `
    query diagnosisCodeQuery($diagnosisCode: String!) {
        icd10(where: {diag_cd: {_eq: $diagnosisCode}, vld_typ_cd: {_eq: "C"}}) {
            diag_cd
            diag_cd_typ_cd
            full_desc
            shrt_desc
        }
    }
`;

export const checkMemberData = `
            query checkMemberData($memID: String!) {
                hsc(where: {indv_key_val: {_eq: $memID}, srvc_set_ref_id: {_eq: 3737}}) {
                            hsc_id
                            hsc_sts_ref_id
                            srvc_set_ref_id
                            auth_typ_ref_id
                            hsc_facls {
                                    actul_admis_dttm
                            }
                }
            }
`;

export const procedureCodeQuery = `
            query procedureCodeQuery($procedureCode: String!) {
                cpt4(where: {proc_cd: {_eq: $procedureCode}}) {
                        proc_cd
                        shrt_desc
                }
                hcpcs(where: {proc_cd: {_eq: $procedureCode}}) {
                        proc_cd
                        shrt_desc
                }
            }
`;