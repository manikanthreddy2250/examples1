import { Test, TestingModule } from '@nestjs/testing';
import {GraphQLClient} from "graphql-request/dist";
import {ConfigService} from "@nestjs/config";
import {IndividualClient} from "./individualClient";
import {HttpRequest} from "@azure/functions";

class MockConfigService extends ConfigService {
    get(propertyPath: any){
        return 'testvalue';
    };
}


describe('IndividualClient', () => {
    let individualClient: IndividualClient;

    let request: HttpRequest;
    request = {
        headers: {authorization: ""},
        method: null,
        url: "",
        query: {},
        params: {}
    };


    beforeEach(async () => {
        individualClient = new IndividualClient(new MockConfigService());
    });

    it('should be defined', () => {
        expect(individualClient).toBeDefined();
    });

    it('should return a Health Service GraphQLClient', () => {
        const client = individualClient.getGraphqlClient(request);
        expect(client).toBeInstanceOf(GraphQLClient);
    });
});
