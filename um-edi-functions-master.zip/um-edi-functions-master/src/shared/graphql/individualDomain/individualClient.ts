import {GraphQLClient} from "graphql-request/dist";
import { ConfigService } from '@nestjs/config';
import { Injectable } from '@nestjs/common';
import {HttpRequest} from "@azure/functions";

@Injectable()
export class IndividualClient {
    private individualClient;
    constructor(private readonly configService: ConfigService) {
        this.individualClient = new GraphQLClient(
            configService.get<string>('INDIVIDUAL_API_ENDPOINT')
        );
    }

    public getGraphqlClient(req: HttpRequest): GraphQLClient {
        const headers = {
            'content-type': req.headers['content-type'],
            Authorization: req.headers['authorization'],
            'x-hasura-role': req.headers['x-hasura-role'],
        };
        this.individualClient.setHeaders(headers);
        return this.individualClient;
    }

}
