export const getIndividualIDQuery = `
            query getIndividualIDQuery($fst_nm: String!, $lst_nm: String!, $bth_dt: String!) {
                   indv(where: {fst_nm: {_eq: $fst_nm}, lst_nm: {_eq: $lst_nm}, bth_dt: {_eq: $bth_dt}}) {
                        fst_nm
                        lst_nm
                        bth_dt
                        indv_id
                 }
               }
            `;

export const getIndividualIDQuery2 = `
            query getIndividualIDQuery($fst_nm: String!, $lst_nm: String!) {
                   indv(where: {fst_nm: {_eq: $fst_nm}, lst_nm: {_eq: $lst_nm}}) {
                        fst_nm
                        lst_nm
                        bth_dt
                        indv_id
                 }
               }
            `;

/*export const getIndividualKeyDataQuery = `
    query getIndividualKeyDataQuery($fst_nm: String!, $lst_nm: String!, $bth_dt: date) {
        indv_key(where: {_and: {indv: {fst_nm: {_eq: $fst_nm}, lst_nm: {_eq: $lst_nm}, bth_dt: {_eq: $bth_dt}}}}) {
            indv {
                fst_nm
                lst_nm
                bth_dt
            }
            indv_key_typ_ref_id
            indv_key_val
        }
    }`;*/

export const getIndividualKeyDataQuery = `
    query getIndividualKeyDataQuery($fst_nm: String!, $lst_nm: String!, $bth_dt: date, $indv_key_val: String!) {
        indv_key(where: {_and: {indv: {fst_nm: {_eq: $fst_nm}, lst_nm: {_eq: $lst_nm}, bth_dt: {_eq: $bth_dt}}, indv_key_val: {_eq:  $indv_key_val}}}) {
            indv {
                fst_nm
                lst_nm
                bth_dt
            }
            indv_key_typ_ref_id
            indv_key_val
        }
    }`;