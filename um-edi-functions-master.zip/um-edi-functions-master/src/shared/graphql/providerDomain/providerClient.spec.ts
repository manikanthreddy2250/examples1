import { Test, TestingModule } from '@nestjs/testing';
import {GraphQLClient} from "graphql-request/dist";
import {ConfigService} from "@nestjs/config";
import {ProviderClient} from "./providerClient";
import {HttpRequest} from "@azure/functions";

class MockConfigService extends ConfigService {
    get(propertyPath: any){
        return 'testvalue';
    };
}

describe('ProviderClient', () => {
    let providerClient: ProviderClient;

    beforeEach(async () => {
        providerClient = new ProviderClient(new MockConfigService());
    });

    it('should be defined', () => {
        expect(providerClient).toBeDefined();
    });

    it('should return a Provider GraphQLClient', () => {
        let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid', headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
        const client = providerClient.getGraphqlClient(httpRequest);
        expect(client).toBeInstanceOf(GraphQLClient);
    });
});
