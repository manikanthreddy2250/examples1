import { GraphQLClient } from 'graphql-request/dist';
import { ConfigService } from '@nestjs/config';
import { Injectable } from '@nestjs/common';
import {HttpRequest} from "@azure/functions";

@Injectable()
export class ProviderClient {
    private providerClient;

    constructor(private readonly configService: ConfigService) {
        this.providerClient = new GraphQLClient(
            configService.get<string>('PROVIDER_API_ENDPOINT'),
        );
    }

    public getGraphqlClient(req: HttpRequest): GraphQLClient {
        const headers = {
            'content-type': req.headers['content-type'],
            Authorization: req.headers['authorization'],
            'x-hasura-role': req.headers['x-hasura-role'],
        };
        this.providerClient.setHeaders(headers);
        return this.providerClient;
    }

}
