export const getProviderIDByProviderNameQuery = `
            query getProviderIDByProviderNameQuery($fst_nm: String!, $lst_nm: String!) {
                    prov_indv(where: {fst_nm: {_eq: $fst_nm}, lst_nm: {_eq: $lst_nm}}) {
                        fst_nm
                        lst_nm
                        prov_id
                 }
               }
            `;

export const getProviderIDByBusNameQuery = `
            query getProviderIDByBusNameQuery($bus_nm: String!) {
                   prov_org(where: {bus_nm: {_eq: $bus_nm}}) {
                        bus_nm
                        prov_id
                 }
               }
            `;


//query getProviderIDByBusNameQuery($bus_nm: String!) {\n' +
//    '  prov_org(where: {bus_nm: {_eq: $bus_nm}}) {\n' +
//    '    bus_nm\n' +
//    '    prov_id\n' +
//    ' } \n' +
//    ' }
//query getProviderIDByProviderNameQuery($fst_nm: String!, $lst_nm: String!) {\n' +
//    '  prov_indv(where: {fst_nm: {_eq: $fst_nm}, lst_nm: {_eq: $lst_nm}}) {\n' +
//    '    fst_nm\n' +
//    '    lst_nm\n' +
//    '    prov_id\n' +
//    ' } \n' +
//    ' } \n',

/*export const getHscProviderDetailsQuery = `query getHscProviderDetailsQuery($adr_ln_1_txt: String, $cty_nm: String, $st_ref_id: Int, $zip_cd_txt: String) {
   prov(where: {prov_adrs: {
     adr_ln_1_txt: {_eq: $adr_ln_1_txt},
     cty_nm: {_eq: $cty_nm},
     st_ref_id: {_eq: $st_ref_id},
     zip_cd_txt: {_eq: $zip_cd_txt}}, prov_keys: {prov_key_typ_ref_id: {_eq: 2782}},
      prov_orgs: {bus_nm: {_eq: "JENNIE STUART MEDICAL CENTER"}}}) {
       prov_id
       prov_keys {
         prov_key_val
         prov_key_typ_ref_id
       }
       prov_adrs {
         prov_adr_id
       }
       prov_catgy_ref_id
       prov_telcoms {
         telcom_adr_id
       }
   }
 }`;*/

export const getHscProviderDetailsQuery = `query getHscProviderDetailsQuery($prov_key_typ_ref_id: Int!, $prov_key_val: String!) {
  prov(where: {prov_keys: {prov_key_typ_ref_id: {_eq: $prov_key_typ_ref_id}, prov_key_val: {_eq: $prov_key_val}}}) {
    prov_id
    prov_keys {
      prov_key_typ_ref_id
      prov_key_val
    }
    prov_adrs {
      adr_ln_1_txt
      adr_ln_2_txt
      zip_cd_txt
      cty_nm
      st_ref_id
    }
    prov_indvs {
      fst_nm
      midl_nm
      lst_nm
      bth_dt
      gdr_ref_id
    }
    prov_orgs {
      bus_nm
    }
  }
}`;


export const getHscProviderForPersonQuery = `
query getHscProviderForPersonQuery($prov_key_typ_ref_id: Int!, $prov_key_val: String!, $fst_nm: String, $lst_nm: String) {
  prov(where: {prov_keys: {prov_key_typ_ref_id: {_eq: $prov_key_typ_ref_id}, prov_key_val: {_eq: $prov_key_val}}}) {
    prov_id
    prov_keys(where: {prov_key_typ_ref_id: {_eq: $prov_key_typ_ref_id}, prov_key_val: {_eq: $prov_key_val}}) {
      prov_key_typ_ref_id
      prov_key_val
    }
     prov_adrs(limit: 1) {
      adr_ln_1_txt
      adr_ln_2_txt
      zip_cd_txt
      cty_nm
      st_ref_id
    }
    prov_indvs (where: {
           _and: {fst_nm: {_eq: $fst_nm}, _and: {lst_nm: {_eq: $lst_nm}}},
            _or: {fst_nm: {_ilike: $fst_nm}, _and: {lst_nm: {_ilike: $lst_nm}}}
     }){
      fst_nm
      midl_nm
      lst_nm
      bth_dt
      gdr_ref_id
    }
    prov_orgs{
      bus_nm
    }
    }
  }
`;

export const getHscProviderForNonPersonQuery = `
query getHscProviderForNonPersonQuery($prov_key_typ_ref_id: Int!, $prov_key_val: String!, $bus_nm: String) {
    prov(where: {prov_keys: {prov_key_typ_ref_id: {_eq: $prov_key_typ_ref_id}, prov_key_val: {_eq: $prov_key_val}}}) {
        prov_id
        prov_keys(where: {prov_key_typ_ref_id: {_eq: $prov_key_typ_ref_id}, prov_key_val: {_eq: $prov_key_val}}) {
            prov_key_typ_ref_id
            prov_key_val
        }
        prov_adrs(limit: 1) {
            adr_ln_1_txt
            adr_ln_2_txt
            zip_cd_txt
            cty_nm
            st_ref_id
        }
        prov_indvs {
            fst_nm
            midl_nm
            lst_nm
            bth_dt
            gdr_ref_id
        }
        prov_orgs (where: {bus_nm: {_eq: $bus_nm}, _or: {bus_nm: {_ilike: $bus_nm}} }) {
            bus_nm
        }
    }
}
`;