import { GraphQLClient } from 'graphql-request/dist';
import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { HttpRequest } from '@azure/functions';

@Injectable()
export class ReferenceClient {
    private referenceClient;

    constructor(
        private readonly configService: ConfigService) {
        //this.healthServiceClient = new GraphQLClient(configService.get<string>('HEALTH_SERVICE_API_ENDPOINT'), { headers: {'x-hasura-admin-secret': configService.get<string>('HEALTH_SERVICE_API_ADMIN_SECRET') } })
        this.referenceClient = new GraphQLClient(
            configService.get<string>('REFERENCE_API_ENDPOINT'),
        );
        //this.referenceClient = new GraphQLClient(configService.get<string>('REFERENCE_API_ENDPOINT'), { headers: {'x-hasura-admin-secret': configService.get<string>('REFERENCE_API_ADMIN_SECRET') } });

    }

    delay() {
        return new Promise(resolve => setTimeout(resolve, 1000));
    }

    public getGraphqlClient(req: HttpRequest): GraphQLClient {
        this.delay();
        const headers = {
            'content-type': req.headers['content-type'],
            Authorization: req.headers['authorization'],
            'x-hasura-role': req.headers['x-hasura-role'],
        };
        this.referenceClient.setHeaders(headers);
        return this.referenceClient;
    }

    public getGraphqlClientAuth(authorization): GraphQLClient {
        this.delay();

        const headers = {
            'content-type': 'application/json',
            Authorization: authorization,
            'x-hasura-role': 'um_intake_ui_system'
        };
        this.referenceClient.setHeaders(headers);
        return this.referenceClient;
    }

}