export const getReferenceData = `
    query cdxrefQuery($atrNames: [String!], $baseRefNames: [String!]) {
        ref(where: {bas_ref_nm: {_in: $baseRefNames}}) {
                      bas_ref_nm,
                      ref_cd,
                      ref_id,
                      ref_desc,
                      ref_dspl
                }
        cd_xref(where: {atr_nm: {_in: $atrNames}}) {
            atr_from_val
            atr_nm
            atr_to_val
        }
    }
`;

