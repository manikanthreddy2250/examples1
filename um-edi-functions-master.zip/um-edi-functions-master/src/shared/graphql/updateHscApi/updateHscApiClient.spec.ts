import { Test, TestingModule } from '@nestjs/testing';
import {GraphQLClient} from "graphql-request/dist";
import {ConfigService} from "@nestjs/config";
import {UpdateHscApiClient} from "./updateHscApiClient";
import {HttpService} from "@nestjs/common";
import {Edi278NDiagnosisValidationService} from "../../../edi/services/validation/278N-validation/edi-278N-diagnosis-validation.service";
import {HealthServiceClient} from "../healthservicedomain/healthServiceClient";
import {HealthServiceService} from "../../../edi/services/healthService/healthService.service";
import {EdiUtilities} from "../../../edi/edi-utilities";

class MockConfigService extends ConfigService {
    get(propertyPath: any){
        return 'testvalue';
    };
}

describe('UpdateHscApiClient', () => {
    let updateHscApiClient: UpdateHscApiClient;

    beforeEach(async () => {
        updateHscApiClient = new UpdateHscApiClient(new MockConfigService(), new  HttpService);
    });

    it('should be defined', () => {
        expect(updateHscApiClient).toBeDefined();
    });

});
