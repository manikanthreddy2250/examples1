import {GraphQLClient} from "graphql-request/dist";
import {ConfigService} from "@nestjs/config";
import {HttpService, Injectable} from "@nestjs/common";
import {Observable} from "rxjs/index";
import {HttpRequest} from "@azure/functions";

@Injectable()
export class UpdateHscApiClient {
    private updateHscApiClient;

    constructor(
        private readonly configService: ConfigService,
        private httpService: HttpService) {

        this.updateHscApiClient = new GraphQLClient(this.configService.get<string>('UTILIZATION_MANAGEMENT_FUNCTIONS_API'));
    }

    public getGraphqlClient(request: HttpRequest): GraphQLClient {
        this.delay();
        const CONTENT_TYPE = 'application/json';
        const headerParams = {
            'Content-Type': CONTENT_TYPE,
            'Accept': CONTENT_TYPE,
            'content-type': 'application/json',
            Authorization: request.headers['authorization'],
            'x-hasura-role': request.headers['x-hasura-role'],
            'x-bpm-func-role': request.headers['case_manager'],
            'x-bpm-cli-org-id': request.headers['ecp']
        };
        this.updateHscApiClient.setHeaders(headerParams);
        return this.updateHscApiClient;
    }

    delay() {
        return new Promise(resolve => setTimeout(resolve, 1000));
    }

}