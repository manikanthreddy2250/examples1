export const updateHscApiMutation = `
            mutation updateHsc($updateHscRequest: UpdateHscRequest!) {
                updateHsc(updateHscRequest: $updateHscRequest) {
                    hsc {
                        hsc_id
                        hsc_diags {
                                    hsc_diag_id
                                    diag_cd
                                    inac_ind
                        }
                    }
                }
            }`;
