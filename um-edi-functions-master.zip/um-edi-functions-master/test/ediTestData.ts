export const canonicalRequest = `
            `;

export const testRequest = `<?xml version="1.0" encoding="UTF-8"?>
    <canonicalRequest xmlns="http://uhg.com/app/icue/edihub/canonicalrequest/xml">
        <dataTransmissionHeader sourceType="278" transactionID="4444415944446591" version="1" receivedDateTime="2021-03-02T01:04:17.897Z" purposeCode="CN" transactionType="NO" transactionStatus="RECEIVED" testFlag="T" clinicalApplication="HSR" payerID="87726" submitterID="">
            <sourceData>
                <ns1:loopID xmlns:ns1="http://authref278.transaction.b2b.uhg.com">2000A</ns1:loopID>
                <ns2:x12278 xmlns:ns2="http://authref278.transaction.b2b.uhg.com">ISA*00*          *00*          *ZZ*B09080111864   *01*87726          *091116*0715*^*00501*000000432*0*T*:~GS*HI*B09080111864*87726*20091116*0715*278001*X*005010X216~ST*278*0015*005010X216~BHT*0007*CN*21969556*20150729*0715*NO~HL*1**20*1~NM1*FA*2*USC KENNETH NORRIS JR CANCER HOSPITAL*****XX*1770728438~N3*1441 EASTLAKE AVE~N4*LOS ANGELES*CA*90033~PER*IC*IAS*TE*3238653000~HL*2*1*21*1~NM1*PR*2*UNITEDHEALTHCARE*****PI*87726~HL*3*2*22*1~NM1*IL*1*STEPHENS*REBECCA****MI*00240239029~REF*6P*0752126~DMG*D8*19631008*F~HL*4*3*EV*1~UM*AR*I*2*21:B**U~DTP*435*D8*20200402~HI*ABK:M54.16~CL1*1~MSG*DC=4~NM1*FA*2*USC KENNETH NORRIS JR CANCER HOSPITAL*****XX*1770728438~N3*1441 EASTLAKE AVE~N4*LOS ANGELES*CA*90033~PER*IC*IAS*TE*3238653000~NM1*71*1*Abston*Anthony****24*631169804~PER*IC**TE*9416807000~HL*5*4*SS*0~UM*HS*I*2*21:B~DTP*472*D8*20200402~SV2**HC:28111~NM1*SJ*1*MANDARANO*CARMINE****24*113160339~N3*281 E MAIN ST~N4*EAST ISLIP*NY*11730~PER*IC*IAS*TE*6312243625~SE*34*0015~GE*1*278001~IEA*1*000000432~</ns2:x12278>
            </sourceData>
        </dataTransmissionHeader>
        <event createDate="2021-02-20" createTime="07:15:00" note="ICD=Tongue CA;;DC=11">
            <providers>
                <provider providerSeqNum="1" entityIdentifier="FA" entityType="2" businessName="ST. TAMMANY PARISH HOSPITAL" providerNPI="1598798597" ndbMpin="000672809" address1="1202 S TYLER ST" city="COVINGTON" state="LA" zip="70433" contactName="" primaryPhone="9858984060">
                    <sourceData>
                        <ns3:loopID xmlns:ns3="http://authref278.transaction.b2b.uhg.com">2010A</ns3:loopID>
                    </sourceData>
                </provider>
                <provider providerSeqNum="2" entityIdentifier="AAJ" entityType="1" providerType="AD" firstName="DANIEL" middleName="P." lastName="MOKRY" providerNPI="1346209806" providerTaxonomyCode="207VX0000X" address1="71380 HIGHWAY 21" city="COVINGTON" state="LA" zip="70433" contactName="" primaryPhone="9858095850" fax="9858095855">
                    <sourceData>
                        <ns5:loopID xmlns:ns5="http://authref278.transaction.b2b.uhg.com">2010EA</ns5:loopID>
                        <ns6:providerTaxonomyCode xmlns:ns6="http://authref278.transaction.b2b.uhg.com">207VX0000X</ns6:providerTaxonomyCode>
                    </sourceData>
                </provider>
                     <provider providerSeqNum="3" entityIdentifier="SJ" entityType="1" providerType="AD" firstName="DANIEL" middleName="P." lastName="MOKRY" providerNPI="1346209806" providerTaxonomyCode="207VX0000X" address1="71380 HIGHWAY 21" city="COVINGTON" state="LA" zip="70433" contactName="" primaryPhone="9858095850" fax="9858095855">
                    <sourceData>
                        <ns5:loopID xmlns:ns5="http://authref278.transaction.b2b.uhg.com">2010EA</ns5:loopID>
                        <ns6:providerTaxonomyCode xmlns:ns6="http://authref278.transaction.b2b.uhg.com">207VX0000X</ns6:providerTaxonomyCode>
                    </sourceData>
                </provider>
            </providers>
            <followUpContact contactName="testing heidi" primaryPhone="3238653000" medicalRecordNumber="RAMSEY123" contactProviderSeqNum="1">
                <sourceData>
                    <ns7:loopID xmlns:ns7="http://authref278.transaction.b2b.uhg.com">2010A</ns7:loopID>
                </sourceData>
            </followUpContact>
            <member firstName="Ronald" lastName="Dobson" birthDate="1936-09-30" gender="M" subscriberFirstName="Ronald" subscriberLastName="Dobson" subscriberBirthDate="1936-09-30" groupID="67001" divID="NTL" eligibilitySystemType="02" sourceCode="CO" claimSystemCode="02">
                <memberIdentifiers>
                    <memberIdentifier memberIDType="MI" memberID="10011872"/>
                </memberIdentifiers>
                <sourceData>
                    <ns8:loopID xmlns:ns8="http://authref278.transaction.b2b.uhg.com">2010C</ns8:loopID>
                </sourceData>
            </member>
            <diagnoses>
                <diagnosis diagnosisSeqNum="1" diagnosisCodeType="ABF" diagnosisCode="M54.16" primaryInd="true" admitInd="false">
                    <sourceData>
                        <ns9:loopID xmlns:ns9="http://authref278.transaction.b2b.uhg.com">2000E</ns9:loopID>
                    </sourceData>
                </diagnosis>
                <diagnosis diagnosisSeqNum="2" diagnosisCodeType="ABJ" diagnosisCode="M54.16" primaryInd="true" admitInd="false">
                    <sourceData>
                        <ns9:loopID xmlns:ns9="http://authref278.transaction.b2b.uhg.com">2000E</ns9:loopID>
                    </sourceData>
                </diagnosis>
            </diagnoses>
            <facility serviceReferenceNum="" requestCategory="AR" certificationType="I" admissionTypeCode="1" serviceType="AG" facilityCodeQualifier="A" facilityCode="21" levelOfService="U" admissionDate="2021-02-20" facilityProviderSeqNum="2">
                 <facilityBedStayDecisions>
                    <facilityBedStayDecision decisionOutcomeTypeID="Status = AP"/>
                    <facilityDecnBedDay revenueCode="A" bedTypeID="1"/>
                    <facilityBedStayDecision decisionOutcomeTypeID="Status = DD"/>
                </facilityBedStayDecisions>
                <sourceData>
                    <ns10:loopID xmlns:ns10="http://authref278.transaction.b2b.uhg.com">2000E</ns10:loopID>
                </sourceData>
            </facility>
            <sourceData>
                <ns12:loopID xmlns:ns12="http://authref278.transaction.b2b.uhg.com">2000E</ns12:loopID>
            </sourceData>
        </event>
    </canonicalRequest>`
;

export const testCanonicalRequest = `<canonicalRequest xmlns="http://uhg.com/app/icue/edihub/canonicalrequest/xml">
        <dataTransmissionHeader sourceType="278" transactionID="4444415944446591" version="1" receivedDateTime="2021-03-02T01:04:17.897Z" purposeCode="CN" transactionType="NO" transactionStatus="RECEIVED" testFlag="T" clinicalApplication="HSR" payerID="87726" submitterID="">
            <sourceData>
                <ns1:loopID xmlns:ns1="http://authref278.transaction.b2b.uhg.com">2000A</ns1:loopID>
                <ns2:x12278 xmlns:ns2="http://authref278.transaction.b2b.uhg.com">ISA*00*          *00*          *ZZ*B09080111864   *01*87726          *091116*0715*^*00501*000000432*0*T*:~GS*HI*B09080111864*87726*20091116*0715*278001*X*005010X216~ST*278*0015*005010X216~BHT*0007*CN*21969556*20150729*0715*NO~HL*1**20*1~NM1*FA*2*USC KENNETH NORRIS JR CANCER HOSPITAL*****XX*1770728438~N3*1441 EASTLAKE AVE~N4*LOS ANGELES*CA*90033~PER*IC*IAS*TE*3238653000~HL*2*1*21*1~NM1*PR*2*UNITEDHEALTHCARE*****PI*87726~HL*3*2*22*1~NM1*IL*1*STEPHENS*REBECCA****MI*00240239029~REF*6P*0752126~DMG*D8*19631008*F~HL*4*3*EV*1~UM*AR*I*2*21:B**U~DTP*435*D8*20200402~HI*ABK:M54.16~CL1*1~MSG*DC=4~NM1*FA*2*USC KENNETH NORRIS JR CANCER HOSPITAL*****XX*1770728438~N3*1441 EASTLAKE AVE~N4*LOS ANGELES*CA*90033~PER*IC*IAS*TE*3238653000~NM1*71*1*Abston*Anthony****24*631169804~PER*IC**TE*9416807000~HL*5*4*SS*0~UM*HS*I*2*21:B~DTP*472*D8*20200402~SV2**HC:28111~NM1*SJ*1*MANDARANO*CARMINE****24*113160339~N3*281 E MAIN ST~N4*EAST ISLIP*NY*11730~PER*IC*IAS*TE*6312243625~SE*34*0015~GE*1*278001~IEA*1*000000432~</ns2:x12278>
            </sourceData>
        </dataTransmissionHeader>
        <event createDate="2021-02-20" createTime="07:15:00" note="ICD=Tongue CA;;DC=11">
            <providers>
                <provider providerSeqNum="1" entityIdentifier="FA" entityType="2" businessName="ST. TAMMANY PARISH HOSPITAL" providerNPI="1598798597" ndbMpin="000672809" address1="1202 S TYLER ST" city="COVINGTON" state="LA" zip="70433" contactName="" primaryPhone="9858984060">
                    <sourceData>
                        <ns3:loopID xmlns:ns3="http://authref278.transaction.b2b.uhg.com">2010A</ns3:loopID>
                    </sourceData>
                </provider>
                <provider providerSeqNum="2" entityIdentifier="AAJ" entityType="1" providerType="AD" firstName="DANIEL" middleName="P." lastName="MOKRY" providerNPI="1346209806" providerTaxonomyCode="207VX0000X" address1="71380 HIGHWAY 21" city="COVINGTON" state="LA" zip="70433" contactName="" primaryPhone="9858095850" fax="9858095855">
                    <sourceData>
                        <ns5:loopID xmlns:ns5="http://authref278.transaction.b2b.uhg.com">2010EA</ns5:loopID>
                        <ns6:providerTaxonomyCode xmlns:ns6="http://authref278.transaction.b2b.uhg.com">207VX0000X</ns6:providerTaxonomyCode>
                    </sourceData>
                </provider>
                <provider providerSeqNum="3" entityIdentifier="SJ" entityType="1" providerType="AD" firstName="DANIEL" middleName="P." lastName="MOKRY" providerNPI="1346209806" providerTaxonomyCode="207VX0000X" address1="71380 HIGHWAY 21" city="COVINGTON" state="LA" zip="70433" contactName="" primaryPhone="9858095850" fax="9858095855">
                    <sourceData>
                        <ns5:loopID xmlns:ns5="http://authref278.transaction.b2b.uhg.com">2010EA</ns5:loopID>
                        <ns6:providerTaxonomyCode xmlns:ns6="http://authref278.transaction.b2b.uhg.com">207VX0000X</ns6:providerTaxonomyCode>
                    </sourceData>
                </provider>
            </providers>
            <followUpContact contactName="testing heidi" primaryPhone="3238653000" medicalRecordNumber="RAMSEY123" contactProviderSeqNum="1">
                <sourceData>
                    <ns7:loopID xmlns:ns7="http://authref278.transaction.b2b.uhg.com">2010A</ns7:loopID>
                </sourceData>
            </followUpContact>
            <member firstName="Ronald" lastName="Dobson" birthDate="1936-09-30" gender="M" subscriberFirstName="Ronald" subscriberLastName="Dobson" subscriberBirthDate="1936-09-30" groupID="67001" divID="NTL" eligibilitySystemType="02" sourceCode="CO" claimSystemCode="02">
                <memberIdentifiers>
                    <memberIdentifier memberIDType="MI" memberID="10011872"/>
                </memberIdentifiers>
                <sourceData>
                    <ns8:loopID xmlns:ns8="http://authref278.transaction.b2b.uhg.com">2010C</ns8:loopID>
                </sourceData>
            </member>
            <diagnoses>
                <diagnosis diagnosisSeqNum="1" diagnosisCodeType="ABF" diagnosisCode="M54.16" primaryInd="true" admitInd="false">
                    <sourceData>
                        <ns9:loopID xmlns:ns9="http://authref278.transaction.b2b.uhg.com">2000E</ns9:loopID>
                    </sourceData>
                </diagnosis>
            </diagnoses>
            <facility serviceReferenceNum="" requestCategory="AR" certificationType="I" admissionTypeCode="1" serviceType="AG" facilityCodeQualifier="A" facilityCode="21" levelOfService="U" admissionDate="2021-02-20" facilityProviderSeqNum="2">
                <facilityBedStayDecisions>
                    <facilityBedStayDecision decisionOutcomeTypeID="Status = AP"/>
                    <facilityDecnBedDay revenueCode="A" bedTypeID="1"/>
                <facilityBedStayDecision decisionOutcomeTypeID="Status = DD"/>
                </facilityBedStayDecisions>
                <sourceData>
                    <ns10:loopID xmlns:ns10="http://authref278.transaction.b2b.uhg.com">2000E</ns10:loopID>
                </sourceData>
            </facility>
            <services>
			 <service serviceSeqNum="1" requestCategory="HS" certificationType="I" serviceType="A9" locationCodeQualifier="B" locationCode="61" serviceStartDate="2020-10-01" serviceEndDate="2021-04-09" serviceProviderSeqNum="4" note="StatusCode=A3;StatusReason=Medical Review-MD;DeciDte=20210223000000;" actionCode="3">
                <serviceFacility procedureCodeType="HC" procedureCode="28111" revenueCode="" nursingHomeStatusCode="a" nursingHomeLevelOfCare="t"/>
                <sourceData>
                    <ns11:loopID xmlns:ns11="http://authref278.transaction.b2b.uhg.com">2000F</ns11:loopID>
                </sourceData>
            </service>
        </services>
            <sourceData>
                <ns12:loopID xmlns:ns12="http://authref278.transaction.b2b.uhg.com">2000E</ns12:loopID>
            </sourceData>
        </event>
    </canonicalRequest>`;

export const testCanonicalRequestMultipleDiagnoses = `<canonicalRequest xmlns="http://uhg.com/app/icue/edihub/canonicalrequest/xml">
        <dataTransmissionHeader sourceType="278" transactionID="4444415944446591" version="1" receivedDateTime="2021-03-02T01:04:17.897Z" purposeCode="CN" transactionType="NO" transactionStatus="RECEIVED" testFlag="T" clinicalApplication="HSR" payerID="87726" submitterID="">
            <sourceData>
                <ns1:loopID xmlns:ns1="http://authref278.transaction.b2b.uhg.com">2000A</ns1:loopID>
                <ns2:x12278 xmlns:ns2="http://authref278.transaction.b2b.uhg.com">ISA*00*          *00*          *ZZ*B09080111864   *01*87726          *091116*0715*^*00501*000000432*0*T*:~GS*HI*B09080111864*87726*20091116*0715*278001*X*005010X216~ST*278*0015*005010X216~BHT*0007*CN*21969556*20150729*0715*NO~HL*1**20*1~NM1*FA*2*USC KENNETH NORRIS JR CANCER HOSPITAL*****XX*1770728438~N3*1441 EASTLAKE AVE~N4*LOS ANGELES*CA*90033~PER*IC*IAS*TE*3238653000~HL*2*1*21*1~NM1*PR*2*UNITEDHEALTHCARE*****PI*87726~HL*3*2*22*1~NM1*IL*1*STEPHENS*REBECCA****MI*00240239029~REF*6P*0752126~DMG*D8*19631008*F~HL*4*3*EV*1~UM*AR*I*2*21:B**U~DTP*435*D8*20200402~HI*ABK:M54.16~CL1*1~MSG*DC=4~NM1*FA*2*USC KENNETH NORRIS JR CANCER HOSPITAL*****XX*1770728438~N3*1441 EASTLAKE AVE~N4*LOS ANGELES*CA*90033~PER*IC*IAS*TE*3238653000~NM1*71*1*Abston*Anthony****24*631169804~PER*IC**TE*9416807000~HL*5*4*SS*0~UM*HS*I*2*21:B~DTP*472*D8*20200402~SV2**HC:28111~NM1*SJ*1*MANDARANO*CARMINE****24*113160339~N3*281 E MAIN ST~N4*EAST ISLIP*NY*11730~PER*IC*IAS*TE*6312243625~SE*34*0015~GE*1*278001~IEA*1*000000432~</ns2:x12278>
            </sourceData>
        </dataTransmissionHeader>
        <event createDate="2021-02-20" createTime="07:15:00" note="ICD=Tongue CA;;DC=11">
            <providers>
                <provider providerSeqNum="1" entityIdentifier="FA" entityType="2" businessName="ST. TAMMANY PARISH HOSPITAL" providerNPI="1598798597" ndbMpin="000672809" address1="1202 S TYLER ST" city="COVINGTON" state="LA" zip="70433" contactName="" primaryPhone="9858984060">
                    <sourceData>
                        <ns3:loopID xmlns:ns3="http://authref278.transaction.b2b.uhg.com">2010A</ns3:loopID>
                    </sourceData>
                </provider>
                <provider providerSeqNum="2" entityIdentifier="AAJ" entityType="1" providerType="AD" firstName="DANIEL" middleName="P." lastName="MOKRY" providerNPI="1346209806" providerTaxonomyCode="207VX0000X" address1="71380 HIGHWAY 21" city="COVINGTON" state="LA" zip="70433" contactName="" primaryPhone="9858095850" fax="9858095855">
                    <sourceData>
                        <ns5:loopID xmlns:ns5="http://authref278.transaction.b2b.uhg.com">2010EA</ns5:loopID>
                        <ns6:providerTaxonomyCode xmlns:ns6="http://authref278.transaction.b2b.uhg.com">207VX0000X</ns6:providerTaxonomyCode>
                    </sourceData>
                </provider>
                <provider providerSeqNum="3" entityIdentifier="SJ" entityType="1" providerType="AD" firstName="DANIEL" middleName="P." lastName="MOKRY" providerNPI="1346209806" providerTaxonomyCode="207VX0000X" address1="71380 HIGHWAY 21" city="COVINGTON" state="LA" zip="70433" contactName="" primaryPhone="9858095850" fax="9858095855">
                    <sourceData>
                        <ns5:loopID xmlns:ns5="http://authref278.transaction.b2b.uhg.com">2010EA</ns5:loopID>
                        <ns6:providerTaxonomyCode xmlns:ns6="http://authref278.transaction.b2b.uhg.com">207VX0000X</ns6:providerTaxonomyCode>
                    </sourceData>
                </provider>
            </providers>
            <followUpContact contactName="testing heidi" primaryPhone="3238653000" medicalRecordNumber="RAMSEY123" contactProviderSeqNum="1">
                <sourceData>
                    <ns7:loopID xmlns:ns7="http://authref278.transaction.b2b.uhg.com">2010A</ns7:loopID>
                </sourceData>
            </followUpContact>
            <member firstName="Ronald" lastName="Dobson" birthDate="1936-09-30" gender="M" subscriberFirstName="Ronald" subscriberLastName="Dobson" subscriberBirthDate="1936-09-30" groupID="67001" divID="NTL" eligibilitySystemType="02" sourceCode="CO" claimSystemCode="02">
                <memberIdentifiers>
                    <memberIdentifier memberIDType="MI" memberID="10011872"/>
                </memberIdentifiers>
                <sourceData>
                    <ns8:loopID xmlns:ns8="http://authref278.transaction.b2b.uhg.com">2010C</ns8:loopID>
                </sourceData>
            </member>
            <diagnoses>
                <diagnosis diagnosisSeqNum="1" diagnosisCodeType="ABF" diagnosisCode="M54.16" primaryInd="true" admitInd="false">
                    <sourceData>
                        <ns9:loopID xmlns:ns9="http://authref278.transaction.b2b.uhg.com">2000E</ns9:loopID>
                    </sourceData>
                </diagnosis>
                <diagnosis diagnosisSeqNum="2" diagnosisCodeType="ABJ" diagnosisCode="M54.16" primaryInd="true" admitInd="false">
                    <sourceData>
                        <ns9:loopID xmlns:ns9="http://authref278.transaction.b2b.uhg.com">2000E</ns9:loopID>
                    </sourceData>
                </diagnosis>
            </diagnoses>
            <facility serviceReferenceNum="" requestCategory="AR" certificationType="I" admissionTypeCode="1" serviceType="AG" facilityCodeQualifier="A" facilityCode="21" levelOfService="U" admissionDate="2021-02-20" facilityProviderSeqNum="2">
                <facilityBedStayDecisions>
                    <facilityBedStayDecision decisionOutcomeTypeID="Status = AP"/>
                    <facilityDecnBedDay revenueCode="A" bedTypeID="1"/>
                <facilityBedStayDecision decisionOutcomeTypeID="Status = DD"/>
                </facilityBedStayDecisions>
                <sourceData>
                    <ns10:loopID xmlns:ns10="http://authref278.transaction.b2b.uhg.com">2000E</ns10:loopID>
                </sourceData>
            </facility>
            <services>
			 <service serviceSeqNum="2" requestCategory="HS" certificationType="I" serviceType="A9" locationCodeQualifier="B" locationCode="61" serviceStartDate="2020-10-01" serviceEndDate="2021-04-09" serviceProviderSeqNum="4" note="StatusCode=A3;StatusReason=Medical Review-MD;DeciDte=20210223000000;" actionCode="3">
                <serviceFacility procedureCodeType="HC" procedureCode="28111" revenueCode="" nursingHomeStatusCode="a" nursingHomeLevelOfCare="t"/>
                <sourceData>
                    <ns11:loopID xmlns:ns11="http://authref278.transaction.b2b.uhg.com">2000F</ns11:loopID>
                </sourceData>
            </service>
        </services>
            <sourceData>
                <ns12:loopID xmlns:ns12="http://authref278.transaction.b2b.uhg.com">2000E</ns12:loopID>
            </sourceData>
        </event>
    </canonicalRequest>`;

export const testDataTransmissionHeader = `<dataTransmissionHeader sourceType="278" transactionID="4444415944446591" version="1" receivedDateTime="2021-03-02T01:04:17.897Z" purposeCode="CN" transactionType="NO" transactionStatus="RECEIVED" testFlag="T" clinicalApplication="HSR" payerID="87726" submitterID="">
                                                <sourceData>
                                                    <ns1:loopID xmlns:ns1="http://authref278.transaction.b2b.uhg.com">2000A</ns1:loopID>
                                                    <ns2:x12278 xmlns:ns2="http://authref278.transaction.b2b.uhg.com">ISA*00*          *00*          *ZZ*B09080111864   *01*87726          *091116*0715*^*00501*000000432*0*T*:~GS*HI*B09080111864*87726*20091116*0715*278001*X*005010X216~ST*278*0015*005010X216~BHT*0007*CN*21969556*20150729*0715*NO~HL*1**20*1~NM1*FA*2*USC KENNETH NORRIS JR CANCER HOSPITAL*****XX*1770728438~N3*1441 EASTLAKE AVE~N4*LOS ANGELES*CA*90033~PER*IC*IAS*TE*3238653000~HL*2*1*21*1~NM1*PR*2*UNITEDHEALTHCARE*****PI*87726~HL*3*2*22*1~NM1*IL*1*STEPHENS*REBECCA****MI*00240239029~REF*6P*0752126~DMG*D8*19631008*F~HL*4*3*EV*1~UM*AR*I*2*21:B**U~DTP*435*D8*20200402~HI*ABK:M54.16~CL1*1~MSG*DC=4~NM1*FA*2*USC KENNETH NORRIS JR CANCER HOSPITAL*****XX*1770728438~N3*1441 EASTLAKE AVE~N4*LOS ANGELES*CA*90033~PER*IC*IAS*TE*3238653000~NM1*71*1*Abston*Anthony****24*631169804~PER*IC**TE*9416807000~HL*5*4*SS*0~UM*HS*I*2*21:B~DTP*472*D8*20200402~SV2**HC:28111~NM1*SJ*1*MANDARANO*CARMINE****24*113160339~N3*281 E MAIN ST~N4*EAST ISLIP*NY*11730~PER*IC*IAS*TE*6312243625~SE*34*0015~GE*1*278001~IEA*1*000000432~</ns2:x12278>
                                                </sourceData>
                                            </dataTransmissionHeader>`;
