# um-intake-ui

### [ECP Docs](https://github.optum.com/pages/ecp/docs/)
###### Contains all documentation for the Enterprise Clinical Platform

# Getting started

0. Prerequisite is having npm installed:

   Install Node.js via the [app store for pc](http://appstore.uhc.com/AppInfo/AppVersionId/17515?BackToList=/AppList/AppList) or [download online for mac](https://nodejs.org/en/)

1. Go to project folder and install dependencies:

```sh
npm install
```

2. Launch development server, and open `localhost:4200` in your browser:

```sh
npm run start
```


3. This repo comes with an IntelliJ run configuration for [attaching a debugger to Chrome](https://github.optum.com/raw/ecp/docs/master/images/attach-js-debugger.png) to debug .ts files.

4. Optional: [Setup Intellij IDEA Auto Linting](https://github.optum.com/raw/ecp/docs/master/images/lint-plugins.png)
    - Be sure to [enable TSLint](https://github.optum.com/raw/ecp/docs/master/images/enable-tslint.png) in the preferences menu
    - [Setup Intellij IDEA Sonar Linting](https://github.optum.com/pages/ecp/docs/engineering-guide/3-coding-guide/9-sonar-lint-setup)

# Project structure

    dist/                           web app production build (untracked)
    e2e/                            end-to-end tests
    helm/                           helm templates for deploying to Azure
    nginx/                          nginx configuration files
    node_modules/                   project dependencies specified in package.json (untracked)
    src/                            project source code
    |- app/                         app components
    |  |- core/                     core module (singleton services and single-use components)
    |  |  |- constants/             constants folder
    |  |  |  |- app-global.ts       app global constants
    |  |  |- app.component.*        app root component (shell)
    |  |  |- app.module.ts          app root module definition
    |  |  |- app-routing.module.ts  app routes
    |  |- pages/                    ui pages specific to this project
    |  |  |- example/               example component with a graphql table
    |  |- shared/                   shared module (common components, services, directives, pipes, etc.)
    |  |- assets/                   app assets (images, fonts, sounds...)
    |  |  |- images/                app global images
    |  |  |- scss/                  app global scss variables and theme
    |- coverage/                    test and coverage reports (untracked)
    |- environments/                values for various build environments
    |- translations/                translations files
    |- index.html                   html entry point
    |- main.scss                    global style entry point
    |- main.ts                      app entry point
    |- polyfills.ts                 polyfills needed by Angular
    |- test.ts                      unit tests entry point

# Development process

Task automation is based on [NPM scripts](https://docs.npmjs.com/misc/scripts).

| Task                         | Description                                                                                    |
| -----------------------------| -----------------------------------------------------------------------------------------------|
| `npm run ng`                 | Pass-through to run an `ng` (Angular CLI) command                                              |
| `npm run start`              | Run development server on `http://localhost:4200/`                                             |
| `npm run start:dev`          | Run development server on `http://localhost:4200/` with hot-swapping for clinical dependencies |
| `npm hmr`                    | Run development server on `http://localhost:4200/` with hot module replacement (faster)        |
| `npm hmr:dev`                | Run development server on `http://localhost:4200/` with hot-swapping and hmr enabled           |
| `npm run build`              | Build web app for production in `dist/` folder                                                 |
| `npm run e2e`                | Run e2e tests using [Protractor](http://www.protractortest.org)                                |
| `npm run envsub`             | Replace system env vars in /app/src/app/core/constants/global.ts, used in Dockerfile           |
| `npm run precommit`          | Used in git hook to ren `pretty-quick` prior to committing                                     |
| `npm run pretty-quick`       | Automatically format all `.css` & `.scss` files                                                |
| `npm run generate`           | Pass-through to run an `ng generate` command                                                   |
| `npm run test:local`         | Run unit tests via [Karma](https://karma-runner.github.io) in watch mode                       |

When building the application, you can specify the target configuration using the additional flag
`--configuration <name>` (do not forget to prepend `--` to pass arguments to npm scripts, like so: `-- --configuration <name>`).

Currently supported configurations:
- dev
- hmr
- hmrdev
- test
- stage
- prod

When running with no configuration specified, the `environment.ts` file is used, which contains the same environment variables as
dev but can be customized for local development.

## Development server

Run `npm start` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change
any of the source files.
You should not use `ng serve` directly, as it does not use certain configurations that the NPM script does by default.

## Using a different role locally
1. app-landing-page.component.ts has some code in it that will set your ecp_token, org and role.
You will want to comment out the line of code that sets those values.
It should look similar to this:
    ```
    if (this.microProductAuthService.isLocalHost()) {
     // this.userSessionService.getLocalEcpToken();
    }
    ```
2. Login to ecp in the dev environment, and choose the correct role
3. Open chrome dev tools
4. Open Application tab
5. Open local storage
6. Start your local instance
7. In a new tab open your localhost url
8. Open chrome dev tools
9. Open Application tab
10. Open local storage
11. Set ecp_token value and set active_org_role to be the same as it was for dev
12. Refresh the page and you should now be 'logged in' as the different role

## Code scaffolding

Run `cd src/app/core && npm run generate -- component <name>` to generate a new component. You can also use
`npm run generate -- directive|pipe|service|class|module`.

If you have installed [angular-cli](https://www.npmjs.com/package/@angular/cli) globally with `npm install -g @angular/cli`,
you can also use the command `ng generate` directly.

## Useful Links

[Form Control Info](https://blog.angular-university.io/introduction-to-angular-2-forms-template-driven-vs-model-driven/)<br>
[Comparing AngularJS to Angular](https://angular.io/guide/ajs-quick-reference)

## Additional tools

Tasks are mostly based on the `angular-cli` tool. Use `ng help` to get more help or go check out the
[Angular-CLI README](https://github.com/angular/angular-cli#angular-cli).

## Code formatting

All `.ts`, `.js` & `.scss` files in this project are formatted automatically using [Prettier](https://prettier.io).

A pre-commit git hook has been configured on this project to automatically format staged files, using
[pretty-quick](https://github.com/azz/pretty-quick), so you don't have to care for it.

You can also force code formatting by running the command `npm run pretty-quick`.

# What's in this repo

The app is based on [HTML5](http://whatwg.org/html), [TypeScript](http://www.typescriptlang.org) and
[Sass](http://sass-lang.com). The translation files use the common [JSON](http://www.json.org) format.

#### Tools

Development, build and quality processes are based on [angular-cli](https://github.com/angular/angular-cli) and
[NPM scripts](https://docs.npmjs.com/misc/scripts), which includes:

- Optimized build and bundling process with [Webpack](https://webpack.github.io)
- [Development server](https://webpack.github.io/docs/webpack-dev-server.html) with backend proxy and live reload
- Cross-browser CSS with [autoprefixer](https://github.com/postcss/autoprefixer) and
  [browserslist](https://github.com/ai/browserslist)
- Unit tests using [Jasmine](http://jasmine.github.io) and [Karma](https://karma-runner.github.io)
- End-to-end tests using [Protractor](https://github.com/angular/protractor)
- Static code analysis: [TSLint](https://github.com/palantir/tslint), [Codelyzer](https://github.com/mgechev/codelyzer),
  [Stylelint](http://stylelint.io) and [HTMLHint](http://htmlhint.com/)
- Automatic code formatting with [Prettier](https://prettier.io)

#### Libraries

- [Angular](https://angular.io)
- [RxJS](http://reactivex.io/rxjs)
- [Lodash](https://lodash.com)

#### [Coding guides](https://github.optum.com/pages/ecp/docs/engineering-guide/3-coding-guide)

### Running Docker Locally

If you have [Docker installed locally](http://appstore.uhc.com/AppInfo/AppVersionId/17763?BackToList=/AppList/AppList) 
you are able to build an image of this project and run it locally:

- To build: `docker build -t um-intake-ui .`
- To run: `docker run -it -p 80:8082 -p 8443:8443 um-intake-ui`

### Troubleshooting

If you're having issues with NPM scripts, try running the following command (for Mac):

`sudo chown -R $USER /usr/local/lib/node_modules`

Or checking out [this site](https://docs.npmjs.com/resolving-eacces-permissions-errors-when-installing-packages-globally).
