// Protractor configuration file, see link for more information
// https://github.com/angular/protractor/blob/master/lib/config.ts
const fs = require('fs-extra')
const path = require('path')

/** @type {import('protractor').Config} */
exports.config = {
  allScriptsTimeout: 800000,
  getPageTimeout: 400000,
  //specs: ['./src/features/**/*.feature'],
  //specs: ['./src/features/regression/**/*.feature'],
  //specs: ['./src/features/regression_OPTUMID/**/*.feature'],
  specs: ['./src/features/regression_MSID/**/*.feature'],




  params: {
    pageObjects: require['./src/pages/**/*.po.ts'],
    customTimeout: 200000
  },

  capabilities: {
    browserName: 'chrome',
    acceptInsecureCerts: true,
    shardTestFiles: true,
    maxInstances: 1,
    chromeOptions: {
      //binary: '/tools/chromium/chromium-692376/chrome-linux/chrome',
      args: [
        '--allow-insecure-localhost',
        // '--incognito'
        //'--headless',
        //'--disable-setuid-sandbox',
       // '--disable-gpu',
       // '--window-size=800x600'
      ]
    }
  },
  // Only works with Chrome and Firefox
  directConnect: false,
  baseUrl: `https://localhost:4200/`,
  useAllAngular2AppRoots: true,
  framework: 'custom',
  frameworkPath: require.resolve('protractor-cucumber-framework'),
  cucumberOpts: {
    compiler: 'ts:ts-node/register',
    require: ['./src/steps/**/*.steps.ts'],
    format: 'json:e2e/reports/cucumber_report.json',
    monochrome: true,
    strict: true,
    tags: ['@Regression', '~@Ignore']
  },
  beforeLaunch: () => {
    const dirPath = path.join(__dirname, './reports')
    const files = fs.readdirSync(dirPath)
    if (files.length === 0) return
    const notToDelete = ['.gitignore', 'cucumber_report.html', 'cucumber_report.html.json' ]
    for (let i = 0; i < files.length; i++) {
      if (notToDelete.includes(files[i])) continue
      fs.remove(path.join(dirPath, files[i]))
    }
  },
  async onPrepare() {
    /** @type {import('protractor').ProtractorBrowser} */
    const browser = global['browser']
    /** @type {import('protractor').ElementHelper} */
    const element = global['element']
    /** @type {import('protractor').ProtractorBy} */
    const by = global['by']
    /** @type {import('protractor')} */
    const protractor = global['protractor']

    browser.manage().timeouts().pageLoadTimeout(40000)
    browser.manage().timeouts().implicitlyWait(25000)
    browser.driver.manage().window().maximize();
    // If you need to navigate to a page which does not use Angular,
    // you can turn off waiting for Angular
    browser.ignoreSynchronization = true
    await browser.get(`https://localhost:4200`)
    await browser.waitForAngular()

    try {
      // Log the user in
      // await element(by.cssContainingText('app-card-item button', 'Login with MS ID')).click()
      // await browser.sleep(1000)
      // await browser.driver.wait(async () => {
      //   const url = await browser.getCurrentUrl()
      //   return url.includes('localhost') || url.includes('127.0.0.1')
      // })
      // await browser.waitForAngular()
      // // await browser.wait(protractor.ExpectedConditions.presenceOf(element(by.css('#uitk-panel-item-0-0 > button'))), 10000)


      // // Make the user an "IT Admin"
      // await element(by.css('#uitk-panel-item-0-0 > button')).click()
      // await element(by.css('#sys_admin_selector')).click()
    } catch (e) {
      console.error('Troubles logging into the system.')
      console.error(e)
      await browser.driver.close()
      process.exit(1)
    }
    require('ts-node').register({
      project: path.join(__dirname, './tsconfig.e2e.json')
    })
  },
  afterLaunch: () => {
    var reporter = require('cucumber-html-reporter')
    var options = {
      theme: 'bootstrap',
      jsonDir: './e2e/reports',
      jsonFile: './e2e/reports/cucumber_report.html.json',
      output: './e2e/reports/cucumber_report.html',
      ignoreBadJsonFile: true,
      reportSuiteAsScenarios: true,
      launchReport: false,
      metadata: {
        'App Version': '0.3.2',
        'Test Environment': 'STAGING',
        'Browser': 'Chrome 88.0.4324.96',
        'Platform': 'Mac',
        'Parallel': 'Scenarios',
        'Executed': 'Remote'
      }
    }
    reporter.generate(options)
  },
}
