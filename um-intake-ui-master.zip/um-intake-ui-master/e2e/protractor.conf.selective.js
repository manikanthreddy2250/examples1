// Protractor configuration file, see link for more information
// https://github.com/angular/protractor/blob/master/lib/config.ts
const fs = require('fs-extra')
const path = require('path')
const pro = require('./protractor.conf.lcl')
const selection = require('./selection')

/** @type {import('protractor').Config} */
exports.config = {
  ...pro.config,
  specs: selection.selection
}
