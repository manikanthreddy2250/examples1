const path = require('path')
const root = path.join(__dirname, 'src/features')

exports.selection = [
  
  path.join(root, 'regression_MSID/um-intake-dashboard.feature'),
  //path.join(root, 'regression_MSID/hsc-ip-case-creation.feature')
]
