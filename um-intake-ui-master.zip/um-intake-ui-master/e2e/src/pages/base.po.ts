import { browser, by, element } from 'protractor';

export class BasePageObject {
  public navigateTo(location: string) {
    return browser.get(location);
  }
}
