import { expect } from 'chai';
import { title } from 'process';
import { browser, by, element } from 'protractor';
import { BasePageObject } from './base.po';

export class CommonPageObject{

    constructor(){
       browser.executeScript(() => localStorage.setItem("language", "en-US"));
    }

    clicksRadioButton(btnName: any): any {
        return element({ xpath: "//label[contains(text(),'" + btnName + "')]" }).click();
    }

    clicksButton(buttonId: any): any {
        return element({ xpath: "//button[@id='" + buttonId + "']" }).click();
    }

    async entersInTextBox(textValue: any, textBoxId: any) {
        return await element({ xpath: "//input[@id='" + textBoxId +"']" }).sendKeys(textValue);
    }

    async selectsDropDown(dropDownValue: any, dropDownId: any): Promise<any> {
        return await element({ xpath: "//select[@id='" + dropDownId +"']" }).sendKeys(dropDownValue);
    }
}