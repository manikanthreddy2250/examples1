import {by, element} from 'protractor';

export class DiagnosisStepperPageObject {
  public diagnosisStepperLabel: any;
  public diagnosisSelection: any;

  constructor(){
    this.diagnosisStepperLabel = element(by.xpath('//div[contains(text(),"Diagnoses")]'));
    this.diagnosisSelection = element(by.xpath("//a[@id='diagnosis_opt_0']"));
  }

  validateDiagnosisStepperLabel(): any {
    return this.diagnosisStepperLabel.getText();
  }

  userSelectsDiagnosis(): any {
    return this.diagnosisSelection.click();
  }
}
