import { expect } from 'chai';
import { title } from 'process';
import { browser, by, element } from 'protractor';
import { BasePageObject } from './base.po';

export class MainDashboardPageObject {

  constructor(){
    this.navigateTo();
  }
 
  navigateTo() {
    browser.sleep(10000);
    browser.executeScript(() => localStorage.setItem("language", "en-US"));
    browser.waitForAngular();
    browser.get("/um") as Promise<any>;
    browser.sleep(20000);
  }

  public async getCreateAuthLabel() {
    await browser.sleep(5000);
    return element(by.css('um-app-landing-page > div > label')).getText();
  }
}
