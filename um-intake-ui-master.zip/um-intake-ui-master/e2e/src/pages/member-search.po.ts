import { expect } from 'chai';
import { title } from 'process';
import { browser, by, element } from 'protractor';
import { BasePageObject } from './base.po';

export class MemberSearchPageObject{

    public memberSearchLabel: any;
    public memberTableSelection: any;
    public memberCoverageSelection: any;


    constructor(){
        // const page = new BasePageObject();
        // page.navigateTo('/um');
        //browser.get(browser.baseUrl);
        this.memberSearchLabel = element(by.xpath('//b[contains(text(),"Search for a member to create an authorization.")]'));
        this.memberTableSelection = element(by.xpath("//tr/td[@headers='indv_key_val']"));
        this.memberCoverageSelection = element(by.xpath("//input[@id='90881934']"));
    }

    validateMemberSearchLabel(): any {
        return this.memberSearchLabel.getText();
    }

    async userSelectsMember() {
        await this.memberTableSelection.click();
        return this.memberCoverageSelection.click();
    }
}