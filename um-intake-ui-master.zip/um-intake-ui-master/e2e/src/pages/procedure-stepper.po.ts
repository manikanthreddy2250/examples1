import {by, element} from 'protractor';

export class ProcedureStepperPageObject {
  public procedureSelection: any;
  public procedureAddButton: any;

  constructor(){
    this.procedureSelection = element(by.xpath("//a[@id='procedure_opt_0']"));
    this.procedureAddButton = element(by.xpath("//div[@id='procedure-add']//button[@type='button'][normalize-space()='Add']"));
  }

  userSelectsProcedure(): any {
    return this.procedureSelection.click();
  }

  userClicksProcedureAdd(): any {
    return this.procedureAddButton.click();
  }
}
