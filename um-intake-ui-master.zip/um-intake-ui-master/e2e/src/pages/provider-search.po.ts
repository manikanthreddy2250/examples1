import {by, element, browser} from 'protractor';

export class ProviderSearchPageObject {
  public providerSearchLabel: any;
  public providerTableSelection: any;

  constructor(){
    this.providerSearchLabel = element(by.xpath('//div[contains(text(),"Search for a Submitting Provider for an authorization")]'));
    this.providerTableSelection = element(by.xpath("//table[@id='basic-tale']/tbody/tr[1]/td[1]"));
  }

  validateProviderSearchLabel(): any {
      return this.providerSearchLabel.getText();
  }

  userSelectsProvider(): any {
    return this.providerTableSelection.click();
  }
}
