import {by, element} from 'protractor';

export class StepperPageObject {
  public caseTypeLabel: any;

  constructor() {
    this.caseTypeLabel = element(by.xpath('//div[contains(text(),"Case Type")]'));
  }

  validateCaseTypeLabel(): any {
    return this.caseTypeLabel.getText();
  }

  validateStepperLabel(label){
    return element({ xpath: "//div[normalize-space()='" + label + "']" }).getText(); 
  }

  validateProviderStepperLabel(label){
    return element({ xpath: "//h1[normalize-space()='" + label + "']" }).getText(); 
  }
}
