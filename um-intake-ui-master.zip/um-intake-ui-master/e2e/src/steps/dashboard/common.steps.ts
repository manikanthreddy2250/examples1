import { expect } from 'chai';
import { Before, Given, Then, When } from 'cucumber';
import { browser } from 'protractor';
import { CommonPageObject } from '../../pages/common.po';

let page: CommonPageObject;

Before(() => {
    page = new CommonPageObject;
});

Then('User click on Radio Button with name {string}', { timeout: 2 * 7000 }, async (buttonName) => {
    expect(await page.clicksRadioButton(buttonName));
});

Then('User enters {string} in textBox with id {string}', { timeout: 2 * 7000 }, async (textValue,textBoxId) => {
    expect(await page.entersInTextBox(textValue,textBoxId));
});

Then('User clicks on button with id {string}', { timeout: 2 * 7000 }, async (buttonId) => {
    expect(await page.clicksButton(buttonId));
});

Then('User selects {string} from dropDown with id {string}', { timeout: 2 * 7000 }, async (dropDownValue,dropDownId) => {
    expect(await page.selectsDropDown(dropDownValue,dropDownId));
});

Then('User waits for action to be Performed', { timeout: 6 * 7000 }, async () => {
    await browser.sleep(10000)
});
