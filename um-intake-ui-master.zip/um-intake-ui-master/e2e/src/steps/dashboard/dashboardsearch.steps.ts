import { expect } from 'chai';
import { Before, Given, Then, When } from 'cucumber';
import { browser, by, element, protractor } from 'protractor';


Then('I click on the {string} card', { timeout: 90 * 1000 }, async (buttonText: string) => {
  await browser.sleep(20000);
  await browser.waitForAngular();
 // await element(by.cssContainingText('button#basicPrimaryBtn', buttonText)).click();

  //const url = await browser.getCurrentUrl()
  if (element(by.css('form input[id=username]')).isPresent) {
    await element(by.css('form input[id=username]')).sendKeys(''); //pass msid
    await element(by.css('form input[id=password]')).sendKeys(''); //pass pwd
    await element(by.css("form div[class='col-sm-6 col-md-6'] button[class='btn btn-primary btn-sm btn-customized font-size-16 btn-cus']")).click();
  }

  //await browser.sleep(30000);
});




