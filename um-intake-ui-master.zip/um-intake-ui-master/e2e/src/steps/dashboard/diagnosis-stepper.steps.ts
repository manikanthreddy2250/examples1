import { expect } from 'chai';
import { Before, Given, Then, When } from 'cucumber';
import { browser } from 'protractor';
import {DiagnosisStepperPageObject} from '../../pages/diagnosis-stepper.po';

let page: DiagnosisStepperPageObject;

Before(() => {
  page = new DiagnosisStepperPageObject;
});

When('User validates {string} Diagnoses Label', { timeout: 2 * 7000 }, async (label) => {
  expect(await page.validateDiagnosisStepperLabel()).to.equal(label);
});

Then('User clicks and selects the diagnosis', { timeout: 8 * 7000 }, async () => {
  await browser.sleep(8000);
  await page.userSelectsDiagnosis();
});
