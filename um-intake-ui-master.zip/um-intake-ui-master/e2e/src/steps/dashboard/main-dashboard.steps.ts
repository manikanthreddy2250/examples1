import { expect } from 'chai';
import { Before, Given, Then, When } from 'cucumber';
import { MainDashboardPageObject } from '../../pages/main-dashboard.po';
import { browser } from 'protractor';

let page: MainDashboardPageObject;

Before(() => {
page = new MainDashboardPageObject;
});

Given('I am on the user dashboard', {timeout: 90 * 1000}, async () => {
  await page.navigateTo();
});

 Then('I should see create authorization label', {timeout: 90 * 1000}, async () => {
  await browser.sleep(10000);
  const createAuthTxt = await page.getCreateAuthLabel();
  expect(createAuthTxt).to.equal('Create Authorization');
  });


 

