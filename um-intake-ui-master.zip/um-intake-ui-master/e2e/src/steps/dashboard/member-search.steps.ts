import { expect } from 'chai';
import { Before, Given, Then, When } from 'cucumber';
import { browser } from 'protractor';
import { MemberSearchPageObject } from '../../pages/member-search.po';

let page: MemberSearchPageObject;

Before(() => {
    page = new MemberSearchPageObject;
});

When('User validates {string}  Member Search Label', { timeout: 2 * 7000 }, async (label) => {
    expect(await page.validateMemberSearchLabel()).to.equal(label);
});

Then('User clicks and selects the member', { timeout: 6 * 7000 }, async () => {
    await browser.sleep(6000)
    await page.userSelectsMember();
});
