import { expect } from 'chai';
import { Before, Given, Then, When } from 'cucumber';
import { browser } from 'protractor';
import {ProcedureStepperPageObject} from '../../pages/procedure-stepper.po';

let page: ProcedureStepperPageObject;

Before(() => {
  page = new ProcedureStepperPageObject;
});

Then('User clicks and selects the procedure', { timeout: 8 * 7000 }, async () => {
  await browser.sleep(5000);
  await page.userSelectsProcedure();
});

Then('User clicks on procedure add button', { timeout: 6 * 7000 }, async () => {
  await page.userClicksProcedureAdd();
  await browser.sleep(4000);
});
