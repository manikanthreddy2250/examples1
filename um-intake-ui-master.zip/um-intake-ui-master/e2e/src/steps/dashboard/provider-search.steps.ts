import { expect } from 'chai';
import { Before, Given, Then, When } from 'cucumber';
import { browser } from 'protractor';
import {ProviderSearchPageObject} from '../../pages/provider-search.po';

let page: ProviderSearchPageObject;

Before(() => {
  page = new ProviderSearchPageObject;
});

When('User validates {string}  Provider Search Label', { timeout: 8 * 7000 }, async (label) => {
  expect(await page.validateProviderSearchLabel()).to.equal(label);
});

Then('User clicks and selects the provider', { timeout: 6 * 7000 }, async () => {
  await browser.sleep(2000);
  await page.userSelectsProvider();
});
