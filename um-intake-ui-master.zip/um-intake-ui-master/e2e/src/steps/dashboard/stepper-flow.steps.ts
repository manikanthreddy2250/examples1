import { expect } from 'chai';
import { Before, Given, Then, When } from 'cucumber';
import { browser } from 'protractor';
import { StepperPageObject } from '../../pages/stepper-flow.po';

let page: StepperPageObject;

Before(() => {
  page = new StepperPageObject;
});

When('User validates {string}  Case Type  Label', { timeout: 2 * 7000 }, async (label) => {
  expect(await page.validateCaseTypeLabel()).to.equal(label);
});

When('User validates {string} Stepper Label', { timeout: 6 * 8000 }, async (label) => {
  expect(await page.validateStepperLabel(label)).to.equal(label);
});

When('User validates {string} label on Provider Stepper', { timeout: 6 * 8000 }, async (label) => {
  expect(await page.validateProviderStepperLabel(label)).to.equal(label);
});
