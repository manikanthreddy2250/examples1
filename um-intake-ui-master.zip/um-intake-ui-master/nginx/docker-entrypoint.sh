#!/usr/bin/env sh

set -e

# Rain dance to properly replace env vars with their values in the compiled javascript file
for var in $(env) ; do
  IFS='=' read -r key value <<EOF
$var
EOF
  sed -i "s#\${$key}#$value#g" /usr/share/nginx/html/main*.js
  sed -i "s#\${$key}#$value#g" /etc/nginx/nginx.conf
done

cat /etc/nginx/nginx.conf

exec "$@"
