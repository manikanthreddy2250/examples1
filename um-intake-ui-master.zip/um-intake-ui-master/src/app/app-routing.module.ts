import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {AuthGuardService} from '@ecp/auth-library';
import {EmptyRouteComponent} from './components/empty-route/empty-route.component';
import {InterqualComponent} from './components/guidelines/interqual/interqual.component';
import {HomeComponent} from './components/home/home.component';
import {IntakeFormComponent} from './components/intake-form/intake-form.component';
import {PocDashboardComponent} from './components/jbpm/poc-dashboard/poc-dashboard.component';
import {PocMdFormComponent} from './components/jbpm/poc-md-form/poc-md-form.component';
import {PocQualityFormComponent} from './components/jbpm/poc-quality-form/poc-quality-form.component';
import {PocTaskTableComponent} from './components/jbpm/poc-task-table/poc-task-table.component';
import {MemberSearch} from './components/member-search/member-search.component';
import {IqSearchComponent} from './components/iq-search/iq-search.component';
import {PocClinicalFormComponent} from './components/jbpm/poc-clinical-form/poc-clinical-form.component';
import {AppLandingPageComponent} from './components/app-landing-page/app-landing-page.component';
const UM_BASE_PATH = 'um';
/**
 * All UI routes are defined here and should start with um/ to make single-spa work in root app
 */
const newRoutes: Routes = [
  {path: '', pathMatch: 'full', redirectTo: UM_BASE_PATH},
  {path: 'um', pathMatch: 'full', redirectTo: UM_BASE_PATH},
  {path: UM_BASE_PATH, component: AppLandingPageComponent, data: { title: 'Authorization Intake' }, canActivate: [AuthGuardService]},
  {path: 'um/auth/initiate', component: MemberSearch, data: { title: 'Authorization Intake' }, canActivate: [AuthGuardService]},
  {path: 'um/workqueue/dashboard', component: PocDashboardComponent, data: { title: 'POC Dash Board' }, canActivate: [AuthGuardService]},
  {path: 'um/workqueue/list', component: PocTaskTableComponent, data: {title: 'POC Task Table'}, canActivate: [AuthGuardService]},
  {path: 'um/pocClinicalForm', component: PocClinicalFormComponent, data: {title: 'POC Clinical Form'}},
  {path: 'um/pocMdForm', component: PocMdFormComponent, data: {title: 'POC MD Form'}},
  {path: 'um/pocQualityForm', component: PocQualityFormComponent, data: {title: 'POC Quality Form'}},
  {path: 'um/intake-form/:id/:cov_id/:serviceType/:caseId/:hscId', component: IntakeFormComponent, data: { title: 'Intake Form' }, canActivate: [AuthGuardService]},
  {path: 'um/interqualGuidelines', component: IqSearchComponent, data: {title: 'Interqual Guidelines Search'}},
  {path: 'um/app2/redirectToIQ', component: InterqualComponent, data: {title: 'Redirect to IQ'}},
  {path: '**', component: EmptyRouteComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(newRoutes)],
  exports: [RouterModule],
  providers: []
})
export class AppRoutingModule {}
