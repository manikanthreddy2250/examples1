import { Component } from '@angular/core';

@Component({
  selector: 'um',
  templateUrl: './app.component.html',
})
export class AppComponent {}
