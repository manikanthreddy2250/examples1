import { A11yModule } from '@angular/cdk/a11y';
import { APP_BASE_HREF, CommonModule, DatePipe } from '@angular/common';
import { HttpClientModule, HttpHeaders } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatNativeDateModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDialogModule } from '@angular/material/dialog';
import { MatDividerModule } from '@angular/material/divider';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatRadioModule } from '@angular/material/radio';
import { MatSelectModule } from '@angular/material/select';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatSortModule } from '@angular/material/sort';
import { MatStepperModule } from '@angular/material/stepper';
import { MatTableModule } from '@angular/material/table';
import { MatTooltipModule } from '@angular/material/tooltip';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {AuthGuardService, AuthLibraryModule} from '@ecp/auth-library';
import {
  UMAnticipatedServiceModule,
  DocProcessModule,
  UmCaseHistoryModule,
  UMCaseHeaderModule,
  ConfigurableMemberHeaderModule,
  UmDiagnosesProceduresModule,
  ClinicalGuidelinesModule
} from '@ecp/ui-component-library';
import { GraphqlModule } from '@ecp/gql-tk-beta';
import { NgbTypeaheadModule } from '@ng-bootstrap/ng-bootstrap';
import { ContentLoaderModule } from '@ngneat/content-loader';
import {
  AccordionModule, AutocompleteModule, BarChartModule, ButtonModule, CardModule,
  CheckboxModule, ComponentLoadIndicatorModule, DialogModule, FileUploaderModule, FormFieldService, HeaderModule,
  IconFontComponent, IconFontModule, MessageModule, MultiSelectModule, NavigationModule, PanelModule,
  PicklistModule, RadioselectModule, SearchModule, TableModule, TabsModule,
  TextAreaModule, TextFieldModule, TooltipModule, UITKFormsCoreModule
} from '@uimf/uitk';
import {
  UITKCardModule, UITKCheckboxModule, UITKDatePickerModule, UITKDialogModule, UITKFieldsetModule,
  UITKFooterModule, UITKFormFieldService, UITKInputModule, UITKLoadingIndicatorModule, UITKPageNotificationModule,
  UITKPaginationModule, UITKPanelModule, UITKRadioGroupModule, UITKSelectModule, UITKTabbedPanelsModule,
  UITKTableFeaturesModule, UITKTableModule, UITKTextAreaModule, UITKWizardModule
} from '@uitk/angular';
import { LocalStorageModule } from 'angular-2-local-storage';
import { HotkeyModule } from 'angular2-hotkeys';
import { APOLLO_OPTIONS, ApolloModule } from 'apollo-angular';
import { HttpLink, HttpLinkModule } from 'apollo-angular-link-http';
import { InMemoryCache } from 'apollo-cache-inmemory';
import { NgxMaskModule } from 'ngx-mask';
import { environment } from '../environments/environment';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {EmptyRouteComponent} from './components/empty-route/empty-route.component';
import { DignosisCodeComponent } from './components/dignosis-code/dignosis-code.component';
import { InterqualComponent } from './components/guidelines/interqual/interqual.component';
import { OutboundSsoComponent } from './components/guidelines/outbound-sso/outbound-sso.component';
import { HomeComponent } from './components/home/home.component';
import {IntakeFormComponent} from './components/intake-form/intake-form.component';
import { PocAuthRequestComponent } from './components/jbpm/poc-auth-request/poc-auth-request.component';
import { PocClinicalFormComponent } from './components/jbpm/poc-clinical-form/poc-clinical-form.component';
import { PocDashboardComponent } from './components/jbpm/poc-dashboard/poc-dashboard.component';
import { PocMdFormComponent } from './components/jbpm/poc-md-form/poc-md-form.component';
import { PocQualityFormComponent } from './components/jbpm/poc-quality-form/poc-quality-form.component';
import { PocTaskTableComponent } from './components/jbpm/poc-task-table/poc-task-table.component';
import { MemberSearch } from './components/member-search/member-search.component';
import { MembershipExpandableRowComponent } from './components/member-search/membership-expandable-row/membership-expandable-row.component';
import { ProcedureCodeComponent } from './components/procedure-code/procedure-code.component';
import {SearchResultRowComponent} from './components/search-result-row/search-result-row.component';
import {AuthSearchComponent} from './components/auth-search/auth-search.component';
import {AuthorizationTypeComponent} from './components/authorization-type/authorization-type.component';
import {ConfirmationComponent} from './components/confirmation/confirmation.component';
import {NotesConfirmationComponent} from './components/confirmation/notes-confirmation/notes-confirmation.component';
import { ProcedureConfirmationComponent } from './components/confirmation/procedure-confirmation/procedure-confirmation.component';
import {IntialContactComponent} from './components/contact-and-followup/intialContactComponent.component';
import { DiagnosisSearchComponent } from './components/diagnosis/diagnosis-search/diagnosis-search.component';
import { DiagnosisComponent } from './components/diagnosis/diagnosis.component';
import {GenericStepperComponent} from './components/generic-stepper/generic-stepper.component';
import {DupProcedureComponent} from './components/hsc-duplicate/dup-procedure/dup-procedure.component';
import {DuplicateViewComponent} from './components/hsc-duplicate/duplicate-view/duplicate-view.component';
import { IqSearchComponent } from './components/iq-search/iq-search.component';
import { NotesGridComponent } from './components/notes-grid/notes-grid.component';
import { NotesComponent } from './components/notes/notes.component';
import { ProcedureExpandableRowComponent } from './components/procedure/procedure-expandable-row/procedure-expandable-row.component';
import { ProcedureSearchComponent } from './components/procedure/procedure-search/procedure-search.component';
import { ProcedureComponent } from './components/procedure/procedure.component';
import { ProviderSearchComponent } from './components/provider-search/provider-search.component';
import {ClinicalInformationComponent} from './components/clinical-information/clinical-information.component';
import { DragNDropDirective } from './components/clinical-information/drag-n-drop/drag-n-drop.directive';
import {RequestInformationComponent} from './components/request-information/request-information.component';
import {VerificationComponent} from './components/verification/verification.component';
import { DiagnosisGraphqlService } from 'src/app/services/diagnosis-graphql-service/diagnosis-graphql.service';
import {ProcedureService} from 'src/app/services/procedure/procedure.service';
import { ProviderSectionConfirmationPageComponent } from './components/provider-section-confirmation-page/provider-section-confirmation-page.component';
import { AppLandingPageComponent } from './components/app-landing-page/app-landing-page.component';
import { ProviderLaunchComponentComponent } from './components/provider-launch-component/provider-launch-component.component';
import { FavoriteProvidersTabComponent } from './components/provider-search/favorite-providers-tab/favorite-providers-tab.component';
import { ProviderPersonaLaunchComponentComponent } from './components/provider-persona-launch-component/provider-persona-launch-component.component';
import {UmIntakeFuncGraphqlServiceConfig} from './services/um-intake-functions/umintakefunc-graphql.service';
// UITK Modules, importing only the ones we need
export const uitkModules = [
  RadioselectModule,
  MultiSelectModule,
  UITKInputModule,
  BrowserAnimationsModule,
  TextFieldModule,
  NavigationModule,
  AutocompleteModule,
  HeaderModule,
  TableModule,
  TabsModule,
  PicklistModule,
  ButtonModule,
  AutocompleteModule,
  TabsModule,
  IconFontModule,
  CheckboxModule,
  MessageModule,
  GraphqlModule,
  AccordionModule,
  SearchModule,
  RadioselectModule,
  BarChartModule,
  ComponentLoadIndicatorModule,
  TooltipModule,
  // DialogModule,
  A11yModule
];

// angular material Modules
export const materialModules = [
  MatSidenavModule,
  MatButtonModule,
  MatCardModule,
  MatDividerModule,
  MatCheckboxModule,
  MatDialogModule,
  MatSelectModule,
  MatSortModule,
  MatTableModule,
  MatExpansionModule,
  MatTableModule,
  MatExpansionModule,
  MatTooltipModule,
  MatRadioModule,
  MatListModule,
  MatNativeDateModule,
  MatDatepickerModule,
  MatStepperModule,
  MatAutocompleteModule,
  MatInputModule,
  MatFormFieldModule
];

// UITK Angular Modules
export const uitkAngularModules = [
  UITKFooterModule,
  UITKPanelModule,
  UITKWizardModule,
  UITKCardModule,
  UITKPageNotificationModule,
  UITKInputModule,
  UITKDialogModule,
  UITKTableModule,
  UITKWizardModule,
  UITKSelectModule,
  UITKDatePickerModule,
  UITKLoadingIndicatorModule,
  UITKTableFeaturesModule,
  UITKTabbedPanelsModule,
];

// ng bootstrap Modules
export const ngbModules = [NgbTypeaheadModule];

export const ecpUIModules = [
  UMAnticipatedServiceModule,
  DocProcessModule,
  UmCaseHistoryModule,
  UMCaseHeaderModule,
  ConfigurableMemberHeaderModule,
  UmDiagnosesProceduresModule,
  ClinicalGuidelinesModule
];

@NgModule({
  declarations: [
    AppComponent,
    NotesGridComponent,
    HomeComponent,
    InterqualComponent,
    NotesComponent,
    DignosisCodeComponent,
    DiagnosisComponent,
    DiagnosisSearchComponent,
    ProcedureCodeComponent,
    ProcedureComponent,
    ProcedureSearchComponent,
    ProcedureExpandableRowComponent,
    MemberSearch,
    SearchResultRowComponent,
    IntakeFormComponent,
    ConfirmationComponent,
    IntialContactComponent,
    RequestInformationComponent,
    ClinicalInformationComponent,
    DragNDropDirective,
    PocAuthRequestComponent,
    PocClinicalFormComponent,
    PocMdFormComponent,
    PocDashboardComponent,
    PocQualityFormComponent,
    PocTaskTableComponent,
    AuthorizationTypeComponent,
    GenericStepperComponent,
    MembershipExpandableRowComponent,
    ProviderSearchComponent,
    //  NotesDisplayComponent
    VerificationComponent,
    OutboundSsoComponent,
    IqSearchComponent,
    EmptyRouteComponent,
    ProcedureConfirmationComponent,
    NotesConfirmationComponent,
    DiagnosisComponent,
    AuthSearchComponent,
    DuplicateViewComponent,
    DupProcedureComponent,
    ProviderSectionConfirmationPageComponent,
    AppLandingPageComponent,
    ProviderLaunchComponentComponent,
    FavoriteProvidersTabComponent,
    ProviderPersonaLaunchComponentComponent
  ],
  imports: [
    FormsModule,
    ReactiveFormsModule,
    ContentLoaderModule,
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    LocalStorageModule.forRoot({ prefix: '', storageType: 'localStorage' }),
    uitkAngularModules,
    uitkModules,
    materialModules,
    ngbModules,
   // UITKInputModule,
    ApolloModule,
    HttpLinkModule,
    NgxMaskModule.forRoot(),
    HotkeyModule.forRoot(),
    FlexLayoutModule,
    BrowserModule,
    BrowserAnimationsModule,
    TooltipModule,
    GraphqlModule,
    MultiSelectModule,
    TextAreaModule,
    UITKTextAreaModule,
    UITKFieldsetModule,
    UITKCheckboxModule,
    UITKRadioGroupModule,
    AuthLibraryModule,
    ecpUIModules
  ],
  exports: [uitkModules],
  providers: [
    [],
    {provide: APP_BASE_HREF, useValue: '/'},
    ProcedureService,
    DiagnosisGraphqlService,
    UmIntakeFuncGraphqlServiceConfig,
    CommonModule,
    FormFieldService,
    DatePipe,
    AuthGuardService],

  bootstrap: [AppComponent],
  entryComponents: [OutboundSsoComponent, MembershipExpandableRowComponent, ProcedureExpandableRowComponent,
                    IconFontComponent, ProcedureConfirmationComponent, NotesConfirmationComponent]
})
export class AppModule {}
