import { SummaryServiceService } from 'src/app/services/summaryservice/summary-service.service';
import { Subject } from 'rxjs/Subject';
import { StepperDataService } from 'src/app/services/StepperDataService/StepperDataService';
import { UserSessionService } from 'src/app/shared/services/user-session/user-session.service';
import { MicroProductAuthService } from '@ecp/auth-library';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA, Injectable } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {HttpClient, HttpHandler} from "@angular/common/http";
import { AppLandingPageComponent } from './app-landing-page.component';
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { Observable, BehaviorSubject, of } from 'rxjs';
import { RouterTestingModule } from '@angular/router/testing';
import {ActivatedRoute, Router} from '@angular/router';
import { ChangeDetectorRef } from '@angular/core';


@Injectable()
class MockStepperDataService {
  private stepperData = new BehaviorSubject({
                       selectedMemberId : "16440436900",
                        tenantId: 'ecpumintakebaseproductbpmgrp',
											 submittingProviderDetails:
												{
												addressLine: "401 6th Ave # 301, Montgomery, WV, 251362116",
												businessName: null,
												firstName: "LA",
												lastName: "HIDALGO-RAMIREZ, LA",
												locationAffiliationId: 7,
												phone: "3044424466",
												prov_id: 125,
												providerAddressId: 88538913,
												providerCategoryRefId: 16309,
												providerMPIN: undefined,
												providerNpi: "1699732990",
												providerTin: "123456",
												specialty: "208000000X",
												specialtyId: 16696,
                                              }});
  sharedStepperData = this.stepperData.asObservable();

  constructor() { }

  setStepperData(stepperData: any) {
    this.stepperData.next(stepperData);
  }
}

@Injectable()
class MicroProductAuthServiceStub {
  getEcpClaims() {
    return {'x-ecp-claims': {'x-ecp-cli-orgs': [{'org-id': 'ecp', 'func-roles': [{'role-name': 'provider'}]}]}};
  }
  getUserID() {
    return 'TESTUSERID';
  }

  isLocalHost() {
    return true;
  }
}

Injectable()
class UserSessionMockService {
  getLocalEcpToken(): Observable<any>{
  return of("SYSTEM");
  }

  getUserPermission(){
    return 'provider';
  }

  getUserName() {
    return "SYSTEM";
  }
}

@Injectable()
class SummaryServiceMockService {
  getHscDetailData(hscID): Observable<any> {
    return of({"data":{"hsc":[{"flwup_cntc_dtl":{"primary_cntct":{"department":"Admitting","email":"vivek_srivastava@optum.com","phone":"111-111-1112","fax":"222-222-2222","creat_dttm":"2020-11-11T09:15:25.779Z","chg_dttm":"2020-11-11T09:16:59.285Z","creat_user_id":"SYSTEM","role":"LifeSolutions","name":"Vivek 2"}},"rev_prr_ref_id":3754,"srvc_set_ref_id":3737,"hsc_sts_ref_id":19274,"mbr_cov_dtl":{"indv_id":503926748,"pol_nbr":null,"cov_eff_dt":"0001-01-01","cov_end_dt":"9999-12-31","mbr_cov_id":66333726,"productCode":null,"indv_key_val":"16440436900","productCatgyTpe":null,"coverageTypeDesc":"Medical","indv_key_typ_ref_id":2757,"claim_platform_ref_Id":null},"indv_key_typ_ref_id":2757,"indv_key_val":"16440436900","orig_sys_ref_id":null,"hsc_keys":[{"hsc_id":8671,"hsc_key_val":"6ee922f6-23fe-11eb-af15-f2eb266f01dc","inac_ind":0,"hsc_key_typ_ref_id":19517}]}]}});
  }
}

describe('AppLandingPageComponent', () => {
  let component: AppLandingPageComponent;
  let fixture: ComponentFixture<AppLandingPageComponent>;
  let cdrf: ChangeDetectorRef;
  let router: Router;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule.withRoutes([{path: 'um/intake', redirectTo: ''}])],
      declarations: [ AppLandingPageComponent ],
      providers: [
        HttpClient, HttpHandler, ChangeDetectorRef,
        { provide: SummaryServiceService, useClass: SummaryServiceMockService},
        {provide : UserSessionService, useClass: UserSessionMockService },
        {provide : MicroProductAuthService, useClass: MicroProductAuthServiceStub },
        { provide: StepperDataService, useClass: MockStepperDataService },
        {
          provide: ActivatedRoute,
          useValue: {
            queryParams: of(
              {
                tin: '12345678'
              }
            )
          }
        }
      ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppLandingPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    cdrf =  TestBed.inject(ChangeDetectorRef);
    router =  TestBed.inject(Router);
  });

  afterEach(() => {
      TestBed.resetTestingModule();
  });

  it('should create', (done) => {
    expect(component).toBeTruthy();
    done();
  });

  it('should call #ngOnInit()', async (done) => {
    component.ngOnInit();
    expect(component.umCaseHistoryConfig.showCaseHistoryTab).toBeDefined();
    expect(localStorage.getItem('providerTin')).toEqual('12345678');
    done();
  });

  it('should call #ngOnDestroy()', async (done) => {
    component.ngOnDestroy();
    expect(component.ngOnDestroy).toBeDefined();
    done();
  });

  it('should Check Onclick ', (done) => {
    const record = {
      hsc_key: "0248c63f-5196-11eb-b11f-9a50f9803a17",
      individual_key_Val: "16440436900",
      mbr_cov_id: 969636855,
      reqNum: 11035,
    }
    spyOn(router, 'navigate');
    component.onClick(record);
    expect(component.onClick).toBeDefined();
    done();
  });
});
