import { Component, OnInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import {Subscription} from 'rxjs';
import { FlowType } from './../../models/enums/flowType';
import {ActivatedRoute, Router} from '@angular/router';
import {MicroProductAuthService} from '@ecp/auth-library';
import { UmCaseHistoryConfig } from '@ecp/ui-component-library/src/lib/utilization-management/um-case-history/um-case-history.config';
import {UserSessionService} from 'src/app/shared/services/user-session/user-session.service';
import {Constants} from "../../constants/constants";
import {SummaryServiceService} from '../../services/summaryservice/summary-service.service';
import {StepperDataService} from '../../services/StepperDataService/StepperDataService';
import { ReferenceConstants } from 'src/app/constants/referenceConstants';


@Component({
  selector: 'um-app-landing-page',
  templateUrl: './app-landing-page.component.html',
  styleUrls: ['./app-landing-page.component.scss']
})
export class AppLandingPageComponent implements OnInit, OnDestroy {

  constructor(private readonly userSessionService: UserSessionService,
    private readonly changeDetector: ChangeDetectorRef,
    private readonly activatedRoute: ActivatedRoute,
    private readonly router: Router,
    public stepperDataService: StepperDataService,
    public summaryServiceService: SummaryServiceService,
    public readonly microProductAuthService: MicroProductAuthService) { }

  userRole: string;
  PROVIDER = Constants.UM_INTAKE_UI_USER_PERMISSION_PROVIDER;
  CLINICIAN = Constants.UM_INTAKE_UI_USER_PERMISSION_CLINICIAN;

  stepperDataSubscription: Subscription;
  stepperData: any;

  umCaseHistoryConfig: UmCaseHistoryConfig = {
    userID: this.userSessionService.getUserName(),
    showCaseHistoryTab: true,
    showMemberHistoryTab: true,
    showProviderHistoryTab: true,
    providerKeyTypeRefId: null,
    providerKeyValue: null,
    individualKeyValue: null
  };

  async ngOnInit() {
    if (this.microProductAuthService.isLocalHost()) {
      this.userSessionService.getLocalEcpToken();
    }
    this.userRole = this.userSessionService.getUserPermission();
    if(this.userRole === this.PROVIDER) {
      this.umCaseHistoryConfig.showCaseHistoryTab = false;
      this.umCaseHistoryConfig.showMemberHistoryTab = false;
    }
    this.stepperDataSubscription = this.stepperDataService.sharedStepperData.subscribe((stepperData) => {
      this.stepperData = stepperData;
      if(this.stepperData.selectedMemberId){
        this.umCaseHistoryConfig.individualKeyValue = this.stepperData.selectedMemberId;
      }
      if(this.stepperData.submittingProviderDetails && this.stepperData.submittingProviderDetails.providerTin){
        this.umCaseHistoryConfig.providerKeyValue = this.stepperData.submittingProviderDetails.providerTin;
        this.umCaseHistoryConfig.providerKeyTypeRefId = ReferenceConstants.PROVIDER_KEY_VALUE_TYP_REF_ID_TIN;
      }
    });

    this.activatedRoute.queryParams.subscribe((params) => {
      localStorage.setItem('providerTin', params['tin']);
      localStorage.setItem('providerMpin', params['mpin']);
      localStorage.setItem('hscReviewType', params['service-type']);
      localStorage.setItem('providerFName', params['providerFName']);
      localStorage.setItem('providerLName', params['providerLName']);
      localStorage.setItem('providerBName', params['providerBName']);
      localStorage.setItem('providerNpi', params['npi']);
    });
  }

  ngOnDestroy() {
    this.stepperDataSubscription.unsubscribe();
  }


  onClick(record: any){
    let serviceType = "Generic";
     const hscId = record.reqNum;
     this.summaryServiceService.getHscDetailData(hscId)
       .subscribe(async (data) => {
         const hscServiceTypeData = data.data.hsc[0].hsc_rev_typ_ref_cd;
         serviceType = hscServiceTypeData ? hscServiceTypeData.ref_desc : serviceType;
         const authData = data;
         const caseID = authData.data.hsc[0].hsc_keys[0].hsc_key_val;
         this.stepperDataService.setStepperData({...this.stepperData, flowType: FlowType.EDIT, serviceType});
         this.router.navigate(['/um/intake-form', authData.data.hsc[0].indv_key_val, authData.data.hsc[0].mbr_cov_dtl.mbr_cov_id, serviceType, caseID, hscId]);
       });
   }
}
