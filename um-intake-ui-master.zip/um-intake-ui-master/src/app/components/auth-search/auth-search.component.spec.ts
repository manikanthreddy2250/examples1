import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AuthSearchComponent } from './auth-search.component';
import {HttpClient, HttpHandler} from "@angular/common/http";
import {SummaryServiceService} from "src/app/services/summaryservice/summary-service.service";
import {ActivatedRoute} from "@angular/router";
import {Injectable, NO_ERRORS_SCHEMA} from "@angular/core";
import {Observable, of} from "rxjs";
import {RouterTestingModule} from "@angular/router/testing";
import {uitkAngularModules, uitkModules} from "src/app/app.module";
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import {UITKRadioGroupModule} from "@uitk/angular";
import {ProviderHistoryService} from "src/app/services/provider-history/provider-history.service";
import { DataserviceService } from 'src/app/services/dataservice-service/dataservice.service';
import {ProviderAuthHistoryDataService} from "src/app/services/provider-auth-history-data-service/provider-auth-history-data.service";

const activatedRouteStub = {
  params: of({ id: 22 })
};
@Injectable()
class SummaryServiceMockService {
  getHscDetailData(hscID): Observable<any> {
    return of({"data":{"hsc":[{"flwup_cntc_dtl":{"primary_cntct":{"department":"Admitting","email":"vivek_srivastava@optum.com","phone":"111-111-1112","fax":"222-222-2222","creat_dttm":"2020-11-11T09:15:25.779Z","chg_dttm":"2020-11-11T09:16:59.285Z","creat_user_id":"SYSTEM","role":"LifeSolutions","name":"Vivek 2"}},"rev_prr_ref_id":3754,"srvc_set_ref_id":3737,"hsc_sts_ref_id":19274,"mbr_cov_dtl":{"indv_id":503926748,"pol_nbr":null,"cov_eff_dt":"0001-01-01","cov_end_dt":"9999-12-31","mbr_cov_id":66333726,"productCode":null,"indv_key_val":"16440436900","productCatgyTpe":null,"coverageTypeDesc":"Medical","indv_key_typ_ref_id":2757,"claim_platform_ref_Id":null},"indv_key_typ_ref_id":2757,"indv_key_val":"16440436900","orig_sys_ref_id":null,"hsc_keys":[{"hsc_id":8671,"hsc_key_val":"6ee922f6-23fe-11eb-af15-f2eb266f01dc","inac_ind":0,"hsc_key_typ_ref_id":19517}]}]}});
  }
}

describe('AuthSearchComponent', () => {
  let component: AuthSearchComponent;
  let fixture: ComponentFixture<AuthSearchComponent>;
  let summaryServiceService :SummaryServiceService

/*  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AuthSearchComponent ],
      providers: [HttpClient, HttpHandler,SummaryServiceService,
        { provide: ActivatedRoute, useValue: activatedRouteStub }],
      schemas: [NO_ERRORS_SCHEMA]
    })
    .compileComponents();
  }));*/

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule.withRoutes([]), uitkModules, uitkAngularModules, FormsModule, ReactiveFormsModule, UITKRadioGroupModule],
      declarations: [ AuthSearchComponent ],
      providers: [HttpClient, HttpHandler, ProviderHistoryService, DataserviceService, ProviderAuthHistoryDataService,{ provide: SummaryServiceService, useClass: SummaryServiceMockService},
        { provide: ActivatedRoute, useValue: activatedRouteStub }],
      schemas: [NO_ERRORS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AuthSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    summaryServiceService = TestBed.get(SummaryServiceService);

  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it ('should searchByRequestNumber',  () => {
    const hscId=12345;
    const serviceType="Generic";
    const indv_key_val="16440436900";
    const mbr_cov_id="12484";
    component.searchByRequestNumber();
    expect(component.authData.data.hsc[0].hsc_keys[0].hsc_key_val).toEqual("6ee922f6-23fe-11eb-af15-f2eb266f01dc");
  });
  it('should do  clear Form Search', () => {
    component.clearForm();
    expect(component.clearForm).toBeTruthy();
  })
});
