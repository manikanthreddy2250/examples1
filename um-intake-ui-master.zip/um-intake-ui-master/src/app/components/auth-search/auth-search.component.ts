import {Component, Input, OnInit, ViewChild} from '@angular/core';
import {FormControl, FormGroup, Validators} from "@angular/forms";
import {FlowType} from '../../models/enums/flowType';
import {ReferenceService} from "src/app/services/refernce-service/reference.service";
import {IUITKColumnState, IUITKTableSortState, UITKSortDirection, UITKTableSortDirective} from "@uitk/angular";
import {SummaryServiceService} from "src/app/services/summaryservice/summary-service.service";
import {Router} from "@angular/router";
import {StepperDataService} from "src/app/services/StepperDataService/StepperDataService";

@Component({
  selector: 'um-auth-search',
  templateUrl: './auth-search.component.html',
  styleUrls: ['./auth-search.component.scss']
})
export class AuthSearchComponent implements OnInit {

  @Input() authSearch: FormGroup;
  requiredText: string = 'Input is required';
  invalidFormSubmitted = false;
  dataSource :any;
  authData:any;
  stepperData:any;

  public customConfigObj: any = {
    dateFormat: 'MM-dd-YYYY',
    iconCalendar: true,
    enableValidation: true,
    validationErrorsMap: {
      requiredMessage: 'Required'
    },
  };

  constructor(public referenceService: ReferenceService,
              private readonly summaryServiceService:SummaryServiceService,
              private router: Router,private readonly stepperDataService: StepperDataService) { }

  ngOnInit(): void {
    this.authSearch = new FormGroup({
      requestNumber: new FormControl('',Validators.required),
    });
  }
  requestNumber: string = 'Request Number';
  dateRange: string = 'Date Range';
  onSwitchTab(index) {
    console.log('Switched to tab ' + index);
  }
  clearForm() {
    this.invalidFormSubmitted = false;
    this.authSearch.reset();
    setTimeout(() => {
    }, 10);
  }
  searchByRequestNumber() {
    const hscId=this.authSearch.get('requestNumber').value;;
    let serviceType="Generic";
    const indv_key_val="16440436900";
    const mbr_cov_id="12484";
    this.summaryServiceService.getHscDetailData(hscId)
      .subscribe( async(  data ) => {
          const hscServiceTypeData = data.data.hsc[0].hsc_rev_typ_ref_cd;
          serviceType = hscServiceTypeData ? hscServiceTypeData.ref_desc : serviceType;
          this.authData = data;
          const caseID=  this.authData.data.hsc[0].hsc_keys[0].hsc_key_val;
          this.stepperDataService.setStepperData({...this.stepperData, flowType: FlowType.EDIT, serviceType});
          this.router.navigate(['/um/intake-form', this.authData.data.hsc[0].indv_key_val, this.authData.data.hsc[0].mbr_cov_dtl.mbr_cov_id, serviceType, caseID, hscId]);
        });
  }
}
