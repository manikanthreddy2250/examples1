import {async, ComponentFixture, inject, TestBed} from '@angular/core/testing';
import {AuthTypeConstants} from 'src/app/constants/authorization-type-constants';
import { AuthorizationTypeComponent } from './authorization-type.component';
import {FormBuilder, FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators} from "@angular/forms";
import {uitkModules,uitkAngularModules} from "src/app/app.module";
import {actions} from "@ecp/gql-tk-beta";
import {HttpClientTestingModule, HttpTestingController} from "@angular/common/http/testing";
import {HttpClient} from "@angular/common/http";
import { RouterModule } from '@angular/router';
import { RouterTestingModule } from "@angular/router/testing";
import {Injectable} from "@angular/core";
import {Observable, of} from "rxjs";
import { ReferenceService } from 'src/app/services/refernce-service/reference.service';
import * as moment from 'moment';


@Injectable()
class MockReferenceService {
  loadBaseRefNameDisplayData(category: any): Observable<any> {
    const mockupResults = of([{
      "ref_id": "1234",
      "ref_desc": "TestBed",
      "ref_dspl": "Behavorial",
       "inac_ind": "12",
       "ref_cd": "ABCD",
    }]);
    return mockupResults
  }
  loadRefChildDisplayDataInRef (category: any): Observable<any> {
    const mockupResultsChild = of([{
      "ref_id": "1234",
      "ref_desc": "TestBed",
      "ref_dspl": "Behavorial",
       "inac_ind": "12",
       "ref_cd": "ABCD",
    }]);
    return mockupResultsChild
  }
}

describe('AuthorizationTypeComponent', () => {
  let component: AuthorizationTypeComponent;
  let fixture: ComponentFixture<AuthorizationTypeComponent>;
  let httpTestCtrl: HttpTestingController;
  let requestTypes = [ ];
  let urgencys = [ ];
  let serviceDescription = [ ];
  let facilityTypes = [ ];
  let serviceDetailTypes = [ ];
  let IP = 'Inpatient';
  let OP = 'Outpatient';
  let OPF = 'Outpatient Facility';

  interface IRequestTermsType {
    databaseName: string;
    refName: string;
    refId: string;
  }

  class FakeHttpClient {

    constructor() {
    }

    public post(url: string, body: IRequestTermsType, options: string): Observable<any> {
      let result;

      if (body.databaseName === 'ref' && body.refName === 'bas_ref_nm' && body.refId === 'requestType') {
        return of(({
          id: 0,
          label: 'Inpatient',
          value: 'Inpatient'
        }));

      } else if (body.databaseName === 'ref_chld' && body.refName === 'bas_ref_nm' && body.refId === 'requestType') {
        return of(({
          id: 0,
          label: 'Inpatient',
          value: 'Inpatient'
        }));
      } else {
        return of(({}));
      }
    }

  }
  beforeEach(async(() => {
    const initialState = {
      ref_chld: [{
        ref_id: 1,
        chld_ref_id: 2
      }]
    };
    TestBed.configureTestingModule({
      imports: [uitkModules,uitkAngularModules, ReactiveFormsModule, FormsModule, HttpClientTestingModule, RouterModule, RouterTestingModule],
      declarations: [ AuthorizationTypeComponent ],
      providers : [HttpClient,  {provide: ReferenceService, useClass: MockReferenceService}]
    })
    .compileComponents();

    requestTypes[0] = {
      id: 0,
      label: 'Inpatient',
      value: 'Inpatient'
    };
    requestTypes[1] = {
      id: 1,
      label: 'Outpatient',
      value: 'Outpatient'
    };
    requestTypes[2] = {
      id: 2,
      label: 'Outpatient Facility',
      value: 'Outpatient Facility'
    };

    urgencys[0] = {
      id: 0,
      label: 'Routine',
      value: 'Routine'
    };
    urgencys[1] = {
      id: 1,
      label: 'Urgent',
      value: 'Urgent'
    };
    urgencys[2] = {
      id: 2,
      label: 'Time Sensitive',
      value: 'Time Sensitive'
    };

    serviceDescription[0] = {
      id: 0,
      label: 'Surgical',
      values: 'Surgical'
    };

    facilityTypes[0] = {
      id: 0,
      label: 'Ambulatory Surgical Center',
      value: 'Ambulatory Surgical Center'
    };

    serviceDetailTypes[0] = {
      id: 0,
      label: 'Diagnostic Testing',
      value: 'Diagnostic Testing'
    };
  }));

 beforeEach(inject([FormBuilder], (fb: FormBuilder) => {
    fixture = TestBed.createComponent(AuthorizationTypeComponent);
    component = fixture.componentInstance;
    httpTestCtrl = TestBed.get(HttpTestingController);
    component.authorizationTypeForm = fb.group({
      requestCategory: [IP],
      facilityType: [facilityTypes],
      serviceDetail: [serviceDetailTypes],
      serviceDescription: [serviceDescription],
      priority: [urgencys],
      expectedAdmissionDate: [null],
      expectedDischargeDate: [null],
      actualAdmissionDate: [null],
      actualDischargeDate: [null],
      startDate: [null],
      endDate: [null]
    });

    component.categoryTypes = requestTypes;
    component.facilityTypes = facilityTypes;
    component.updateCategoryType();
    component.priorityTypes = urgencys;
    component.updatePriority();
    component.serviceDetailTypes = serviceDetailTypes;
    component.serviceDescriptionTypes = serviceDescription;
    component.updateServiceDescription();
    component.selectedMember = {
      coverage: {
        cov_eff_dt: '07-24-2020',
        cov_end_dt: '12-31-9999'
      }
    };
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
   });
  it('should get the categoryTypes', () => {
    component.updateCategoryType();
    expect(component.categoryTypes.length).toBeGreaterThan(0);
  });

  it('should get the facilityTypes', () => {
    component.updateFacilityType(157);
  });

  it('should get the serviceDetailTypes', () => {
    component.updateServiceDetailType(3741);
  });
  it('should get the priorityTypes', () => {
    component.updatePriority();
  });

  it('should get the serviceDescription', () => {
    component.updateServiceDescription();
  });

  it('should set the formFields based on requestCategory', () => {
    component.authorizationTypeForm.get('requestCategory').setValue({value: IP});
    component.getUpdatedAuthorizationForm();
    expect(component.authorizationTypeForm.get('expectedAdmissionDate')?.validator != null);
    expect(component.authorizationTypeForm.get('actualAdmissionDate')?.validator != null);
    expect(component.authorizationTypeForm.get('expectedDischargeDate')?.validator != null);
    expect(component.authorizationTypeForm.get('actualDischargeDate')?.validator != null);
    expect(component.authorizationTypeForm.get('startDate')).toBeNull();
    expect(component.authorizationTypeForm.get('endDate')).toBeNull();

    component.authorizationTypeForm.get('requestCategory').setValue({value: OP});
    component.getUpdatedAuthorizationForm();
    expect(component.authorizationTypeForm.get('expectedAdmissionDate')).toBeNull();
    expect(component.authorizationTypeForm.get('actualAdmissionDate')).toBeNull();
    expect(component.authorizationTypeForm.get('expectedDischargeDate')).toBeNull();
    expect(component.authorizationTypeForm.get('actualDischargeDate')).toBeNull();
    expect(component.authorizationTypeForm.get('startDate')).toBeNull();
    expect(component.authorizationTypeForm.get('endDate')).toBeNull();

    component.authorizationTypeForm.get('requestCategory').setValue({value: OPF});
    component.getUpdatedAuthorizationForm();
    expect(component.authorizationTypeForm.get('expectedAdmissionDate')).toBeNull();
    expect(component.authorizationTypeForm.get('actualAdmissionDate')).toBeNull();
    expect(component.authorizationTypeForm.get('expectedDischargeDate')).toBeNull();
    expect(component.authorizationTypeForm.get('actualDischargeDate')).toBeNull();
    expect(component.authorizationTypeForm.get('startDate')?.validator != null);
    expect(component.authorizationTypeForm.get('endDate')?.validator != null);
  });

  it ('getExpectedAdmissionDateErrorMsg should not return message if control has no errors', () => {
    component.authorizationTypeForm.get('expectedAdmissionDate').setErrors(null);
    expect(component.getExpectedAdmissionDateErrorMsg()).toBeNull();
  });

  it ('getExpectedAdmissionDateErrorMsg should return proper message based on errorCode', () => {
    const expAdmDateControl = component.authorizationTypeForm.get('expectedAdmissionDate');
    expAdmDateControl.setErrors({isDateInPast: true});
    expect(component.getExpectedAdmissionDateErrorMsg()).toEqual(AuthTypeConstants.MORE_THAN_93DAYS_IN_PAST);
    expAdmDateControl.setErrors({dateNotInRange: true});
    expect(component.getExpectedAdmissionDateErrorMsg()).toEqual(AuthTypeConstants.NOT_IN_COVERAGE_RANGE);
  });

  it ('getActualAdmissionDateErrorMsg should not return message if control has no errors', () => {
    component.authorizationTypeForm.get('actualAdmissionDate').setErrors(null);
    expect(component.getActualAdmissionDateErrorMsg()).toBeNull();
  });

  it ('getActualAdmissionDateErrorMsg should return proper message based on errorCode', () => {
    const actualAdmDateControl = component.authorizationTypeForm.get('actualAdmissionDate');
    actualAdmDateControl.setErrors({isFutureDate: true});
    expect(component.getActualAdmissionDateErrorMsg()).toEqual(AuthTypeConstants.DATE_CANNOT_BE_FUTURE);
    actualAdmDateControl.setErrors({isDateInPast: true});
    expect(component.getActualAdmissionDateErrorMsg()).toEqual(AuthTypeConstants.MORE_THAN_93DAYS_IN_PAST);
    actualAdmDateControl.setErrors({dateNotInRange: true});
    expect(component.getActualAdmissionDateErrorMsg()).toEqual(AuthTypeConstants.NOT_IN_COVERAGE_RANGE);
  });

  it ('getExpectedDischargeDateErrorMsg should not return message if control has no errors', () => {
    component.authorizationTypeForm.get('expectedDischargeDate').setErrors(null);
    expect(component.getExpectedDischargeDateErrorMsg()).toBeNull();
  });

  it ('getExpectedDischargeDateErrorMsg should return proper message based on errorCode', () => {
    component.authorizationTypeForm.setErrors({expectedDischargeDateisPrior: true});
    expect(component.getExpectedDischargeDateErrorMsg()).toEqual(AuthTypeConstants.EXP_DISCHRG_DT_BEFORE_ADM_DT);
  });

  it ('getActualDischargeDateErrorMsg should not return message if control has no errors', () => {
    component.authorizationTypeForm.get('actualDischargeDate').setErrors(null);
    expect(component.getActualDischargeDateErrorMsg()).toBeNull();
  });

  it ('getActualDischargeDateErrorMsg should return proper message based on errorCode', () => {
    const actualDischargeDateControl = component.authorizationTypeForm.get('actualDischargeDate');
    actualDischargeDateControl.setErrors({isFutureDate: true});
    expect(component.getActualDischargeDateErrorMsg()).toEqual(AuthTypeConstants.DATE_CANNOT_BE_FUTURE);
    actualDischargeDateControl.setErrors(null);
    component.authorizationTypeForm.setErrors({actualDischargeDateisPrior: true});
    expect(component.getActualDischargeDateErrorMsg()).toEqual(AuthTypeConstants.ACT_DISCHRG_DT_BEFORE_ADM_DT);
  });

  it ('updateExpectedDischargeDate should set expectedDischargeDate if a valid actualDischargeDate exists', () => {
    const actualDischargeDateControl = component.authorizationTypeForm.get('actualDischargeDate');
    actualDischargeDateControl.setValue(moment());
    actualDischargeDateControl.setErrors(null);
    component.updateExpectedDischargeDate();
    expect(component.authorizationTypeForm.get('expectedDischargeDate').value).toEqual(actualDischargeDateControl.value);
  });

  it ('updateExpectedAdmissionDate should set expectedAdmissionDate if a valid actualAdmissionDate exists', () => {
    const actualAdmissionDateControl = component.authorizationTypeForm.get('actualAdmissionDate');
    actualAdmissionDateControl.setValue(moment());
    actualAdmissionDateControl.setErrors(null);
    component.updateExpectedAdmissionDate();
    expect(component.authorizationTypeForm.get('expectedAdmissionDate').value).toEqual(actualAdmissionDateControl.value);
  });

  it ('getStartDateErrorMsg should return proper message based on errorCode', () => {
    const startDateControl = component.authorizationTypeForm.get('startDate');
    startDateControl.setErrors({isDateInPast: true});
    expect(component.getStartDateErrorMsg()).toEqual(AuthTypeConstants.START_DT);
    startDateControl.setErrors({dateNotInRange: true});
    expect(component.getStartDateErrorMsg()).toEqual(AuthTypeConstants.NOT_IN_COVERAGE_RANGE);
  });

  it ('getEndDateErrorMsg should return proper message based on errorCode', () => {
    const endDateControl = component.authorizationTypeForm.get('endDate');
    endDateControl.setErrors({dateNotInRange: true});
    expect(component.getEndDateErrorMsg()).toEqual(AuthTypeConstants.NOT_IN_COVERAGE_RANGE);
    endDateControl.setErrors(null);
    component.authorizationTypeForm.setErrors({endDateisPrior: true});
    expect(component.getEndDateErrorMsg()).toEqual(AuthTypeConstants.END_DT);
  });

  it ('getStartDateErrorMsg should not return message if control has no errors', () => {
    component.authorizationTypeForm.get('startDate').setErrors(null);
    expect(component.getStartDateErrorMsg()).toBeNull();
  });

  it ('getEndDateErrorMsg should not return message if control has no errors', () => {
    component.authorizationTypeForm.get('endDate').setErrors(null);
    expect(component.getEndDateErrorMsg()).toBeNull();
  });

  it ('customConfig date Obj should set a custom required message', () => {
    expect(component.customConfigObj.validationErrorsMap.requiredMessage).toEqual('Required');
  });

  it ('build authstepper data for open and draft cases IP and OPF', () => {
    component.hscObj = {
      "hsc_id": 8613,
      "hsc_sts_ref_id": 19274,
      "rev_prr_ref_id": 3754,
      "rev_prr_ref_cd": [
        {
          "ref_id": 3754,
          "ref_desc": "Routine",
          "ref_dspl": "Routine"
        }
      ],
      "srvc_set_ref_id": 3737,
      "srvc_set_ref_cd": [
        {
          "ref_id": 3737,
          "ref_desc": "Inpatient",
          "ref_dspl": "Inpatient"
        }
      ],
      "hsc_srvcs": [
        {
          "inac_ind": 0,
          "proc_cd": "29280",
          "proc_cd_schm_ref_id": 2,
          "proc_othr_txt": " STRAPPING HAND/FINGER",
          "srvc_hsc_prov_id": null,
          "hsc_srvc_non_facls": []
        }
      ],
      "hsc_facls": [
        {
          "actul_admis_dttm": null,
          "actul_dschrg_dttm": null,
          "expt_admis_dt": "2020-11-10",
          "expt_dschrg_dt": "2020-11-11",
          "plsrv_ref_id": 3747,
          "plsrv_ref_cd": [
            {
              "ref_id": 3747,
              "ref_desc": "Skilled Nursing Facility",
              "ref_dspl": "Skilled Nursing Fac"
            }
          ],
          "srvc_desc_ref_id": 4347,
          "srvc_desc_ref_cd": [
            {
              "ref_id": 4347,
              "ref_desc": "Scheduled",
              "ref_dspl": "Scheduled"
            }
          ],
          "srvc_dtl_ref_id": 4302,
          "srvc_dtl_ref_cd": [
            {
              "ref_id": 4302,
              "ref_desc": "Infusion Services",
              "ref_dspl": "Infusion Services"
            }
          ]
        }
      ]
    }
    expect(component.buildAuthSteperData()).toBeTruthy;
  });

  it ('build authstepper data for open and draft cases OP', () => {
  component.hscObj = {
    "hsc_id": 8630,
    "hsc_sts_ref_id": 19274,
    "rev_prr_ref_id": 3754,
    "rev_prr_ref_cd": [
      {
        "ref_id": 3754,
        "ref_desc": "Routine",
        "ref_dspl": "Routine"
      }
    ],
    "srvc_set_ref_id": 3738,
    "srvc_set_ref_cd": [
      {
        "ref_id": 3738,
        "ref_desc": "Outpatient",
        "ref_dspl": "Outpatient"
      }
    ],
    "hsc_srvcs": [
      {
        "hsc_srvc_non_facls": [
          {
            "plsrv_ref_id": 3740,
            "plsrv_ref_cd": [
              {
                "ref_id": 3740,
                "ref_desc": "Office",
                "ref_dspl": "Office"
              }
            ],
            "srvc_desc_ref_cd": [
              {
                "ref_id": 4347,
                "ref_desc": "Scheduled",
                "ref_dspl": "Scheduled"
              }
            ]
          }
        ]
      }
    ]
  }
  expect(component.buildAuthSteperData()).toBeTruthy;
  });

  it ('build authstepper data default form', () => {
    component.hscObj = {
      "hsc_id": 8613,
      "hsc_sts_ref_id": 19274,
      "rev_prr_ref_id": 3754,
      "rev_prr_ref_cd": [
        {
          "ref_id": 3754,
          "ref_desc": "Routine",
          "ref_dspl": "Routine"
        }
      ],
      "srvc_set_ref_id": 3737,
      "srvc_set_ref_cd": [
        {
          "ref_id": 3737,
          "ref_desc": "Inpatient",
          "ref_dspl": "Inpatient"
        }
      ],
      "hsc_facls": []
    }
    expect(component.buildAuthSteperData()).toBeTruthy;
    });

  it('should existingCaseData ', () => {
    const   hscObj = {
      "hsc_id": 8613,
      "hsc_sts_ref_id": 19274,
      "rev_prr_ref_id": 3754,
      "rev_prr_ref_cd": [
        {
          "ref_id": 3754,
          "ref_desc": "Routine",
          "ref_dspl": "Routine"
        }
      ],
      "srvc_set_ref_id": 3737,
      "srvc_set_ref_cd": [
        {
          "ref_id": 3737,
          "ref_desc": "Inpatient",
          "ref_dspl": "Inpatient"
        }
      ],
      "hsc_facls": []
    }
    component.existingCaseData(hscObj);
    expect(component.existingCaseData).toBeTruthy();
  });
});
