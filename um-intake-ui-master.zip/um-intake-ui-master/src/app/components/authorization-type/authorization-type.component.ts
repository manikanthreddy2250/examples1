import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Component, Injectable, Input, OnDestroy, OnInit} from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {Subscription} from 'rxjs';
import {FlowType} from '../../models/enums/flowType';
import {IntakeFormValidationService} from 'src/app/services/intake-form/intake-form-validation.service';
import {ReferenceService} from 'src/app/services/refernce-service/reference.service';
import {ReferenceConstants} from 'src/app/constants/referenceConstants';
import {StepperDataService} from 'src/app/services/StepperDataService/StepperDataService';
import {AuthTypeConstants} from 'src/app/constants/authorization-type-constants';

export enum requestInfo {
  PLACE = 'placeOfServiceCode',
  REF = 'ref',
  REFCHLD = 'ref_chld',
  REFHEAD = 'ref_head',
  REFID = 'ref_id',
  REFBNM = 'bas_ref_nm',
  REFNM = 'ref_nm',
  REFSET = 'ref_set',
  REQUESTTERM = 'requestTerm',
  REQUESTTYPE = 'serviceSettingType',
  SERVICEDETAIL = 'serviceDetailType',
  SERVICES = 'Outpatient Services',
  PRIORITY = 'riskLevelType',
  SERVICEDESC = 'serviceDescriptionType',
  DUPJUSTIFICATION = 'hscDupJustificationType'
}

@Component({
  selector: 'um-authorization-type',
  templateUrl: './authorization-type.component.html',
  styleUrls: ['./authorization-type.component.scss']
})
@Injectable({
  providedIn: 'root'
})

export class AuthorizationTypeComponent implements OnInit, OnDestroy {
  authorizationTypeForm: FormGroup;
  @Input() selectedMember: any;
  // @Output() updateCategoryTypes: any = new EventEmitter();
  // TODO get these from ref db after the data is available
  stepperData: any;
  hscObj:any;
  ipOpfCaseTypeData :any;
  opCaseTypeData: any;
  public categoryTypes = [];
  public facilityTypes = [];
  public priorityTypes = [];
  public serviceDetailTypes = [];
  public IP = 'Inpatient';
  public OP = 'Outpatient';
  public OPF = 'Outpatient Facility';
  public serviceDescriptionTypes = [];
  public expectedAdmissionDate = '';
  public expectedDischargeDate = '';
  public actualAdmissionDate = '';
  public actualDischargeDate = '';
  public startDate = '';
  public endDate = '';
  public customConfigObj: any = {
    dateFormat: 'MM-dd-YYYY',
    iconCalendar: true,
    enableValidation: true,
    validationErrorsMap: {
      requiredMessage: 'Required'
    },
  };
  HSC_STATUS_TYPE_DRAFT = ReferenceConstants.HSC_STATUS_TYPE_DRAFT;
  HSC_STATUS_TYPE_OPEN = ReferenceConstants.HSC_STATUS_TYPE_OPEN;
  SERVICESETTINGTYPE_INPATIENT = ReferenceConstants.SERVICESETTINGTYPE_INPATIENT;
  SERVICESETTINGTYPE_OUTPATIENT_FACILITY = ReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY;
  SERVICESETTINGTYPE_OUTPATIENT = ReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT;
  constructor(private readonly httpClient: HttpClient,  private readonly formBuilder: FormBuilder, private readonly intakeValidationService: IntakeFormValidationService, public referenceService: ReferenceService,public stepperDataService: StepperDataService) { }
  private readonly httpOption = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Credentials': 'true',
      'Access-Control-Allow-Methods': 'GET, POST'
    }),
    // withCredentials: true
  };

  public configObj: any = {
    dateFormat: 'MM-dd-YYYY',
    delimiter: '/',
    minYear: 2001,
    maxYear: 2008,
    timeFormat: 'h:mm a',
    iconCalendar: true,
    enableValidation: true,
  };

  stepperDataSubscription: Subscription;

  // TODO Refactor: move authorizationTypeForm update to parent component
  public getUpdatedAuthorizationForm() {
    this.stepperDataService.setStepperData({...this.stepperData, hscDuplicates: []});
    const requestCategory = this.authorizationTypeForm.get('requestCategory').value;
    this.updateFacilityType(requestCategory.id);
    const previousRequestCategory = (this.stepperData.authorizationTypeForm && this.stepperData.authorizationTypeForm.get('requestCategory')) ? this.stepperData.authorizationTypeForm.get('requestCategory').value : null;
    if (previousRequestCategory && previousRequestCategory.id !== requestCategory.id) {
      // reset procedures if there is a chaneg in requestCategory, TODO delete from DB?
      this.stepperDataService.setStepperData({...this.stepperData, hscProcedures: []});
    }
    if (requestCategory.value === this.IP) {
      this.authorizationTypeForm = this.formBuilder.group({
        requestCategory: new FormControl(this.categoryTypes[0], Validators.required),
        facilityType: new FormControl(null, Validators.required),
        serviceDetail: new FormControl(null, Validators.required),
        serviceDescription: new FormControl(null, Validators.required),
        priority: new FormControl(null, Validators.required),
        expectedAdmissionDate:
          [null, Validators.compose(
             [this.intakeValidationService.dateWithinRangeValidator(this.selectedMember.coverage.cov_eff_dt, this.selectedMember.coverage.cov_end_dt),
             this.intakeValidationService.isDateInPastValidator(93)])
          ],
        expectedDischargeDate: [null, Validators.required],
        actualAdmissionDate: [null, Validators.compose(
          [this.intakeValidationService.dateWithinRangeValidator(this.selectedMember.coverage.cov_eff_dt, this.selectedMember.coverage.cov_end_dt),
          this.intakeValidationService.isDateInPastValidator(93),
          this.intakeValidationService.isFutureDateValidator()]),
        ],
        actualDischargeDate: [null, this.intakeValidationService.isFutureDateValidator()],
       }, {validators: [this.intakeValidationService.priorDateValidator('expectedAdmissionDate', 'expectedDischargeDate'),
          this.intakeValidationService.priorDateValidator('actualAdmissionDate', 'actualDischargeDate')]});
    } else if (this.authorizationTypeForm.get('requestCategory').value.value === this.OP) {
      this.authorizationTypeForm = new FormGroup({
        requestCategory: new FormControl(this.categoryTypes[1], Validators.required),
        facilityType: new FormControl(null, Validators.required),
        serviceDescription: new FormControl(null, Validators.required),
        priority: new FormControl(null, Validators.required),
      });
    } else if (this.authorizationTypeForm.get('requestCategory').value.value === this.OPF) {
      this.authorizationTypeForm = this.formBuilder.group({
        requestCategory: new FormControl(this.categoryTypes[2], Validators.required),
        facilityType: new FormControl(null, Validators.required),
        serviceDetail: new FormControl(null, Validators.required),
        serviceDescription: new FormControl(null, Validators.required),
        priority: new FormControl(null, Validators.required),
        startDate: [null, Validators.compose(
          [this.intakeValidationService.dateWithinRangeValidator(this.selectedMember.coverage.cov_eff_dt, this.selectedMember.coverage.cov_end_dt),
          this.intakeValidationService.isDateInPastValidator(1)]),
        ],
        endDate: [null, this.intakeValidationService.dateWithinRangeValidator(this.selectedMember.coverage.cov_eff_dt, this.selectedMember.coverage.cov_end_dt)],
        }, {validators: [this.intakeValidationService.isDateEqualOrAfter('startDate', 'endDate')]
      });
    } else {
      this.authorizationTypeForm = new FormGroup({
        requestCategory: new FormControl(null, Validators.required),
        facilityType: new FormControl(null, Validators.required),
        serviceDetail: new FormControl(null, Validators.required),
        serviceDescription: new FormControl(null, Validators.required),
        priority: new FormControl(null, Validators.required)
      });
    }

  }

  // Get Request type drop down menu
  updateCategoryType() {
    this.referenceService.loadBaseRefNameDisplayData(requestInfo.REQUESTTYPE).toPromise().then((res) => {
                res.data.ref.forEach((item: { ref_id: number; ref_dspl: string; ref_desc: string; }) => {
                    const categoryTypeObj = {
                          id: item.ref_id,
                          label: item.ref_dspl,
                          value: item.ref_desc
                    };
                    this.categoryTypes.push(categoryTypeObj);
                });
    }).catch((error) => { });
  }

  // Get Service Description drop down menu
  updatePriority() {
    this.priorityTypes = [];
    this.referenceService.loadBaseRefNameDisplayData(requestInfo.PRIORITY).toPromise().then((res) => {
                res.data.ref.forEach((item: { ref_id: number; ref_dspl: string; ref_desc: string; }) => {
                    const priorityTypeObj = {
                          id: item.ref_id,
                          label: item.ref_dspl,
                          value: item.ref_desc
                    };
                    this.priorityTypes.push(priorityTypeObj);
                });
    }).catch((error) => { });
  }

  // Get Service Description drop down menu
  updateServiceDescription() {
    this.serviceDescriptionTypes = [];
    this.referenceService.loadBaseRefNameDisplayData(requestInfo.SERVICEDESC).toPromise().then((res) => {
                res.data.ref.forEach((item: { ref_id: number; ref_dspl: string; ref_desc: string; }) => {
                    const serviceDescriptionTypeObj = {
                          id: item.ref_id,
                          label: item.ref_dspl,
                          value: item.ref_desc
                    };
                    this.serviceDescriptionTypes.push(serviceDescriptionTypeObj);
                });
    }).catch((error) => { });
  }

  // Update facility Type drop down menu
  updateFacilityType(refId: number) {
    this.facilityTypes = [];
    this.referenceService.loadRefChildDisplayDataInRef(refId).toPromise().then((res) => {
                res.data.ref_chld.forEach((item) => {
                    const facilityTypeObj = {
                          id: item.refSetByChldRefIdChldRefNm.ref.ref_id,
                          label: item.refSetByChldRefIdChldRefNm.ref.ref_dspl,
                          value: item.refSetByChldRefIdChldRefNm.ref.ref_desc
                    };
                    this.facilityTypes.push(facilityTypeObj);
                });
    }).catch((error) => { });
  }

  // Update service Detail Type drop down menu
  updateServiceDetailType(refId: number) {
    this.serviceDetailTypes = [];
    this.referenceService.loadRefChildDisplayDataInRef(refId).toPromise().then((res) => {
                   res.data.ref_chld.forEach((item) => {
                       const serviceDetailTypeObj = {
                             id: item.refSetByChldRefIdChldRefNm.ref.ref_id,
                             label: item.refSetByChldRefIdChldRefNm.ref.ref_dspl,
                             value: item.refSetByChldRefIdChldRefNm.ref.ref_desc
                       };
                       this.serviceDetailTypes.push(serviceDetailTypeObj);
                   });
    }).catch((error) => { });

    this.updateServiceDescription();
    this.updatePriority();
  }

  ngOnInit() {
    this.stepperDataSubscription = this.stepperDataService.sharedStepperData.subscribe((stepperData) => {
      this.stepperData = stepperData;
      this.hscObj = this.stepperData.hsc;
    });
    if(this.stepperData.flowType === FlowType.EDIT) {
      this.buildAuthSteperData();
      this.updateFacilityType(this.hscObj.srvc_set_ref_cd.ref_id);
      this.getOPCaseTypeAndProcedureData(this.hscObj.hsc_srvcs);
      this.stepperDataService.setStepperData({...this.stepperData, caseData: this.existingCaseData(this.hscObj)});
      this.stepperDataService.setStepperData({...this.stepperData, hscFacl: this.hscObj.hsc_facls});
    }else {
      this.authorizationTypeForm = this.getDefaultAuthorizationForm();
    }
    this.updateCategoryType();
  }
  ngOnDestroy() {
    this.stepperDataSubscription.unsubscribe();
  }


  existingCaseData(hscObj) {
    return {
      requestCategory: hscObj?.srvc_set_ref_cd?.ref_dspl,
      priority: hscObj?.rev_prr_ref_cd?.ref_dspl,
      facilityType: this.opCaseTypeData?.hsc_srvc_non_facls[0]?.plsrv_ref_cd?.ref_dspl ,
      serviceDetail: hscObj?.rev_prr_ref_cd?.ref_dspl ,
      serviceDescription: this.opCaseTypeData?.hsc_srvc_non_facls[0]?.srvc_desc_ref_cd?.ref_dspl
    };
  }

  buildAuthSteperData(){
    const hscObj = this.hscObj
      if(hscObj.srvc_set_ref_id == ReferenceConstants.SERVICESETTINGTYPE_INPATIENT || hscObj.srvc_set_ref_id == ReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY){
        if(hscObj.hsc_facls.length > 0){
        this.ipOpfCaseTypeData = hscObj.hsc_facls[0];
        this.buildFacilityForm(hscObj);
        this.updateServiceDetailType(this.ipOpfCaseTypeData.plsrv_ref_cd.ref_id);
        }else{
          this.authorizationTypeForm = this.getDefaultAuthorizationForm();
        }
      }else{
        const hscSrvcNonFacl = hscObj.hsc_srvcs.find((value) => value.hsc_srvc_non_facls && value.hsc_srvc_non_facls.length > 0).hsc_srvc_non_facls[0];
        this.authorizationTypeForm = new FormGroup({
          requestCategory: new FormControl(hscObj.srvc_set_ref_cd? { id: hscObj.srvc_set_ref_cd.ref_id,
            label: hscObj.srvc_set_ref_cd.ref_dspl,
            value: hscObj.srvc_set_ref_cd.ref_desc}: null, Validators.required),
          facilityType: new FormControl(hscSrvcNonFacl.plsrv_ref_cd? {
            id: hscSrvcNonFacl.plsrv_ref_cd.ref_id,
            label: hscSrvcNonFacl.plsrv_ref_cd.ref_dspl,
            value: hscSrvcNonFacl.plsrv_ref_cd.ref_desc}: null, Validators.required),
          serviceDescription: new FormControl( hscSrvcNonFacl.srvc_desc_ref_cd? {
            id: hscSrvcNonFacl.srvc_desc_ref_cd.ref_id,
            label: hscSrvcNonFacl.srvc_desc_ref_cd.ref_dspl,
            value: hscSrvcNonFacl.srvc_desc_ref_cd.ref_desc}: null, Validators.required),
          priority: new FormControl( hscObj.rev_prr_ref_cd? { id: hscObj.rev_prr_ref_cd.ref_id,
            label: hscObj.rev_prr_ref_cd.ref_dspl,
            value: hscObj.rev_prr_ref_cd.ref_desc}: null, Validators.required)
        });
        this.updateServiceDetailType(hscSrvcNonFacl.plsrv_ref_cd.ref_id);
    }
}

  private buildFacilityForm(hscObj) {
    this.authorizationTypeForm = new FormGroup({
      requestCategory: new FormControl(this.hscObj.srvc_set_ref_cd ? {
        id: this.hscObj.srvc_set_ref_cd.ref_id,
        label: this.hscObj.srvc_set_ref_cd.ref_dspl,
        value: this.hscObj.srvc_set_ref_cd.ref_desc}: null, Validators.required),
      facilityType: new FormControl(this.ipOpfCaseTypeData.plsrv_ref_cd ? {
        id: this.ipOpfCaseTypeData.plsrv_ref_cd.ref_id,
        label: this.ipOpfCaseTypeData.plsrv_ref_cd.ref_dspl,
        value: this.ipOpfCaseTypeData.plsrv_ref_cd.ref_desc}: null, Validators.required),
      serviceDescription: new FormControl( this.ipOpfCaseTypeData.srvc_desc_ref_cd ? {
        id: this.ipOpfCaseTypeData.srvc_desc_ref_cd.ref_id,
        label: this.ipOpfCaseTypeData.srvc_desc_ref_cd.ref_dspl,
        value: this.ipOpfCaseTypeData.srvc_desc_ref_cd.ref_desc}: null, Validators.required),
      priority: new FormControl( hscObj.rev_prr_ref_cd ? {
        id: hscObj.rev_prr_ref_cd.ref_id,
        label: hscObj.rev_prr_ref_cd.ref_dspl,
        value: hscObj.rev_prr_ref_cd.ref_desc}: null, Validators.required),
      serviceDetail: new FormControl( this.ipOpfCaseTypeData.srvc_dtl_ref_cd ? {
          id: this.ipOpfCaseTypeData.srvc_dtl_ref_cd.ref_id,
          label: this.ipOpfCaseTypeData.srvc_dtl_ref_cd.ref_dspl,
          value: this.ipOpfCaseTypeData.srvc_dtl_ref_cd.ref_desc}: null, Validators.required),
     });
  if(hscObj.srvc_set_ref_id == ReferenceConstants.SERVICESETTINGTYPE_INPATIENT){
      this.authorizationTypeForm.addControl("expectedAdmissionDate", new FormControl(this.ipOpfCaseTypeData.expt_admis_dt, Validators.required)),
      this.authorizationTypeForm.addControl("expectedDischargeDate", new FormControl(this.ipOpfCaseTypeData.expt_dschrg_dt, Validators.required)),
      this.authorizationTypeForm.addControl("actualAdmissionDate",new FormControl(this.ipOpfCaseTypeData.actul_admis_dttm ? this.ipOpfCaseTypeData.actul_admis_dttm: null)),
      this.authorizationTypeForm.addControl("actualDischargeDate",new FormControl(this.ipOpfCaseTypeData.actul_dschrg_dttm ? this.ipOpfCaseTypeData.actul_dschrg_dttm: null))

    }
    if(hscObj.srvc_set_ref_id == ReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY){
      this.authorizationTypeForm.addControl("startDate",new FormControl(this.ipOpfCaseTypeData.actul_admis_dttm ? this.ipOpfCaseTypeData.actul_admis_dttm: null, Validators.required)),
      this.authorizationTypeForm.addControl("endDate",new FormControl(this.ipOpfCaseTypeData.actul_dschrg_dttm ? this.ipOpfCaseTypeData.actul_dschrg_dttm: null, Validators.required))
    }
  }

  private getDefaultAuthorizationForm(): FormGroup {
    return this.formBuilder.group({
      requestCategory: [null, Validators.required],
      facilityType: [null, Validators.required],
      serviceDetail: [null, Validators.required],
      serviceDescription: [null, Validators.required],
      priority: [null, Validators.required],
      expectedAdmissionDate: [null, Validators.required],
      expectedDischargeDate: [null, Validators.required],
      actualAdmissionDate: [null],
      actualDischargeDate: [null],
      startDate: [null, Validators.required],
      endDate: [null, Validators.required]
    });
  }

  getOPCaseTypeAndProcedureData(hscsrvcs) {
    hscsrvcs.forEach((item) => {
      if (item.proc_cd === null) {
        this.opCaseTypeData = item;
      }
    });
  }

  /*
    Returns ExpectedAdmissionDate error message if exists else returns null
    Returns proper message if multiple exists based on precedence
   */
  getExpectedAdmissionDateErrorMsg() {
    const expectedAdmissionDateControl = this.authorizationTypeForm.get('expectedAdmissionDate');
    if (expectedAdmissionDateControl.hasError('isDateInPast')) {
      return AuthTypeConstants.MORE_THAN_93DAYS_IN_PAST;
    }
    return expectedAdmissionDateControl.hasError('dateNotInRange') ? AuthTypeConstants.NOT_IN_COVERAGE_RANGE : null;
  }
  /*
    Returns ActualAdmissionDate error message if exists else returns null
    Returns proper message if multiple exists based on precedence
   */
  getActualAdmissionDateErrorMsg() {
    const actualAdmissionDateControl = this.authorizationTypeForm.get('actualAdmissionDate');
    if (actualAdmissionDateControl.hasError('isFutureDate')) {
      return AuthTypeConstants.DATE_CANNOT_BE_FUTURE;
    }
    if (actualAdmissionDateControl.hasError('isDateInPast')) {
      return AuthTypeConstants.MORE_THAN_93DAYS_IN_PAST;
    }
    return actualAdmissionDateControl.hasError('dateNotInRange') ? AuthTypeConstants.NOT_IN_COVERAGE_RANGE : null;
  }
  /*
    Returns ExpectedDischargeDate error message if exists else returns null
   */
  getExpectedDischargeDateErrorMsg() {
    return this.authorizationTypeForm.hasError('expectedDischargeDateisPrior') ? AuthTypeConstants.EXP_DISCHRG_DT_BEFORE_ADM_DT : null;
  }
  /*
    Returns ActualDischargeDate error message if exists else returns null
    Returns proper message if multiple exists based on precedence
    Note: for actualDischargeDate there can be errors which are set at both FormControl and FormGroup level.
     Because, it includes validators at both FormControl and FormGroup level for cross-validation(evaluate sibling controls in a single custom validator)
   */
  getActualDischargeDateErrorMsg() {
    if (this.authorizationTypeForm.get('actualDischargeDate').hasError('isFutureDate')) {
      return AuthTypeConstants.DATE_CANNOT_BE_FUTURE;
    }
    return this.authorizationTypeForm.hasError('actualDischargeDateisPrior') ? AuthTypeConstants.ACT_DISCHRG_DT_BEFORE_ADM_DT : null;
  }

  /*
    Updates ExpectedDischargeDate value if its not set yet from valid ActualDischargeDate
   */
  updateExpectedDischargeDate() {
    const actualDischargeDateControl = this.authorizationTypeForm.get('actualDischargeDate');
    const expectedDischargeDateControl = this.authorizationTypeForm.get('expectedDischargeDate');
    if (!this.getActualDischargeDateErrorMsg()) {
      expectedDischargeDateControl.setValue(expectedDischargeDateControl.value ? expectedDischargeDateControl.value : actualDischargeDateControl.value);
    }
  }

  /*
    Updates ExpectedAdmissionDate value if its not set yet from valid ActualAdmissionDate
   */
  updateExpectedAdmissionDate() {
    const actualAdmissionDateControl = this.authorizationTypeForm.get('actualAdmissionDate');
    const expectedAdmissionDateControl = this.authorizationTypeForm.get('expectedAdmissionDate');
    if (!this.getActualAdmissionDateErrorMsg()) {
      expectedAdmissionDateControl.setValue(expectedAdmissionDateControl.value ? expectedAdmissionDateControl.value : actualAdmissionDateControl.value);
    }
  }

  /*
    Returns StartDate error message if exists else returns null
    Returns proper message if multiple exists based on precedence
   */
  getStartDateErrorMsg() {
    const startDateControl = this.authorizationTypeForm.get('startDate');
    if (startDateControl.hasError('isDateInPast')) {
      return AuthTypeConstants.START_DT;
    }
      return startDateControl.hasError('dateNotInRange') ? AuthTypeConstants.NOT_IN_COVERAGE_RANGE : null;
  }

   /*
    Returns endDate error message if exists else returns null
    Returns proper message if multiple exists based on precedence
    Note: for endDate there can be errors which are set at both FormControl and FormGroup level.
     Because, it includes validators at both FormControl and FormGroup level for cross-validation(evaluate sibling controls in a single custom validator)
   */
  getEndDateErrorMsg() {
    const endDateControl = this.authorizationTypeForm.get('endDate');
    if (endDateControl.hasError('dateNotInRange')){
          return AuthTypeConstants.NOT_IN_COVERAGE_RANGE ;
    }
    return this.authorizationTypeForm.hasError('endDateisPrior' ) ? AuthTypeConstants.END_DT : null;
  }
}
