import { HttpClient, HttpHandler } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import {CUSTOM_ELEMENTS_SCHEMA, Injectable, NO_ERRORS_SCHEMA} from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {Observable, of} from 'rxjs';
import {uitkModules} from 'src/app/app.module';
import {DocumentService} from 'src/app/services/document-service/document.service';
import {FileUploadService} from 'src/app/services/file-upload-service/file-upload.service';
import { ClinicalInformationComponent } from './clinical-information.component';
import { ReferenceService } from 'src/app/services/refernce-service/reference.service';

const fileItem = [{size: 123, name: 'inputFile', progress: 0}];

@Injectable()
class FileUploadMockService {
  uploadFile(file: File, metadata: any): Observable<any> {
    return of({documentId: '123', attachments: [{url: 'http://testurlx=10', fileName: 'test.txt'}]});
  }
  deleteFile(file: File): Observable<any> {
    return of({documentId: '123'});
  }
  getAttachmentConfigDetails(){
    return of({"data":{"sys_cnfg":[{"appl_nm":"um_intake_ui","cnfg_key":"attachments_config","cnfg_val":{"documentTypeRefIds":[19904,19905,19906,19907,19908,19909,19910,19911,19912], "maxFileSizeMB": 25, "maxFilesAllowed": null},"sys_cnfg_id":"um_intake_ui_attachments_config"}]}});
  }

  setFiles(file: File){}
  getFiles(){}
}

@Injectable()
class ReferenceMockService {
  getBulkRefEntriesByRefIds(refIds: any): Observable<any>{
    return of({"data":{"ref":[{"ref_desc":"image/bmp","ref_dspl":"bmp","ref_id":19904}, {"ref_desc":"Doc","ref_dspl":"Doc","ref_id":19905},
    {"ref_desc":"Gif","ref_dspl":"Gif","ref_id":19906}, {"ref_desc":"Jpg","ref_dspl":"Jpg","ref_id":19907},
    {"ref_desc":"Jpeg","ref_dspl":"Jpeg","ref_id":19908}, {"ref_desc":"Pdf","ref_dspl":"Pdf","ref_id":19909},
    {"ref_desc":"Png","ref_dspl":"Png","ref_id":19910}, {"ref_desc":"Tiff","ref_dspl":"Tiff","ref_id":19911},
    {"ref_desc":"Txt","ref_dspl":"Txt","ref_id":19912}]}});
  }
}

@Injectable()
class DocumentMockService {
  executeSaveHsrDocProcMutation(document: any): Promise<any> {
    return Promise.resolve({insert_hsr_doc_proc_one: {hsr_doc_proc_id: 123}});
  }
  executeSaveHsrDocProcSbjMutation(document: any): Promise<any> {
    return Promise.resolve({data: {insert_hsr_doc_proc_sbj_one: {hsr_doc_proc_id: 123}}});
  }
}

@Injectable()
class SysConfigMockService {
  getSysConfig(){
    return of({"data":{"sys_cnfg":[{"appl_nm":"um_intake_ui","cnfg_key":"attachments_config","cnfg_val":{"documentTypeRefIds":[19904,19905,19906,19907,19908,19909,19910,19911,19912], "maxFileSizeMB": 25, "maxFilesAllowed": null},"sys_cnfg_id":"um_intake_ui_attachments_config"}]}});
  }
}

describe('ClinicalInformationComponent', () => {
   let component: ClinicalInformationComponent;
   let fixture: ComponentFixture<ClinicalInformationComponent>;
   beforeEach(async(() => {
     TestBed.configureTestingModule({
    imports: [uitkModules, FormsModule, ReactiveFormsModule, HttpClientTestingModule],
    schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
    providers: [{ provide: ReferenceService, useClass: ReferenceMockService },
      { provide: FileUploadService, useClass: FileUploadMockService },
      { provide: DocumentService, useClass: DocumentMockService }],
    declarations: [ClinicalInformationComponent]
     }).compileComponents();
   }));

   beforeEach(() => {
     fixture = TestBed.createComponent(ClinicalInformationComponent);
     component = fixture.componentInstance;
    component.files = [[{"progress":100,"description":"","datetimeAdded":"Mon Nov 16 2020 19:28:20","status":"Ready to Upload","showNotes":true,"sizeFormat":"22 MB","dateTimeFormat":"11/16/20, 1:58 PM","uploadedBy":"SYSTEM","uploadedDate":"Mon Nov 16 2020 19:28:20","filename":"file123.txt"},
                        {"progress":100,"description":"","datetimeAdded":"Mon Nov 16 2020 19:28:20","status":"Ready to Upload","showNotes":false,"sizeFormat":"22 MB","dateTimeFormat":"11/16/20, 1:58 PM","uploadedBy":"SYSTEM","uploadedDate":"Mon Nov 16 2020 19:28:20","filename":"testfile.txt"}]];
    component.hscObj ={"hsc": [
                                     {
                                       "hsc_id": 7448,
                                       "auth_end_dt": null,
                                       "auth_strt_dt": null,
                                       "auth_typ_ref_id": null,
                                       "cont_of_care_ind": null,
                                       "indv_id": 503926748,
                                       "mbr_cov_dtl": null,
                                       "mbr_cov_id": 12484,
                                       "rev_prr_ref_id": 3754,
                                       "srvc_set_ref_id": 3738,
                                       "hsc_keys": [
                                         {
                                           "hsc_id": 7448,
                                           "hsc_key_val": "25a3edda-0e43-11eb-a339-86406bb57ba2",
                                           "inac_ind": 0,
                                           "hsc_key_typ_ref_id": 19517
                                         }
                                       ],
                                       "hsc_diags": [
                                         {
                                           "diag_cd": "S83.116",
                                           "inac_ind": 0,
                                           "hsc_id": 7448,
                                           "pri_ind": 0,
                                           "hscDiagDiagCdRef": [
                                             {
                                               "shrt_desc": "ANT DISLOCATION PROX TIBIA UNS KNEE",
                                               "full_desc": "Anterior dislocation of proximal end of tibia, unspecified knee",
                                               "cd_desc": "ANTERIOR DISLOCATION PROXIMAL END TIBIA UNS KNEE"
                                             }
                                           ]
                                         },
                                         {
                                           "diag_cd": "S80.242D",
                                           "inac_ind": 0,
                                           "hsc_id": 7448,
                                           "pri_ind": 1,
                                           "hscDiagDiagCdRef": [
                                             {
                                               "shrt_desc": "EXTERNAL CONSTRICTION LT KNEE SBSQT",
                                               "full_desc": "External constriction, left knee, subsequent encounter",
                                               "cd_desc": "EXTERNAL CONSTRICTION LT KNEE SUBSEQUENT ENCNTR"
                                             }
                                           ]
                                         }
                                       ],
                                       "hsc_provs": [
                                         {
                                           "hsc_id": 7448,
                                           "hsc_prov_id": 254,
                                           "prov_loc_affil_id": 5,
                                           "spcl_ref_id": 17048,
                                           "telcom_adr_id": "4326392664",
                                           "hsc_prov_roles": [
                                             {
                                               "hsc_prov_id": 254,
                                               "prov_role_ref_id": 3766
                                             }
                                           ]
                                         }
                                       ],
                                       "hsc_facls": [
                                         {
                                           "hsc_id": 7448,
                                           "actul_admis_dttm": "2020-10-11T00:00:00",
                                           "actul_dschrg_dttm": "2020-10-13T00:00:00",
                                           "expt_admis_dt": "2020-10-11",
                                           "expt_dschrg_dt": "2020-10-17",
                                           "plsrv_ref_id": 3743,
                                           "srvc_desc_ref_id": 4347,
                                           "srvc_dtl_ref_id": 4296
                                         }
                                       ],
                                       "hsr_doc_procs": [
                                         {
                                           "hsr_doc_proc_id": 78,
                                           "hsc_id": 7448,
                                           "doc_desc": "",
                                           "doc_key_val": "8f89ceb8-9701-4c5d-ae77-342111cbfe1f",
                                           "doc_proc_sts_ref_id": 19915,
                                           "doc_sys_ref_id": 19913,
                                           "hsr_doc_typ_ref_id": 19912,
                                           "creat_dttm": "2020-10-20T20:22:08.853",
                                           "creat_user_id": "SYSTEM",
                                           "hsr_doc_proc_sbjs": [
                                             {
                                               "hsr_doc_proc_id": 78,
                                               "hsr_sbj_rec_id": 7448,
                                               "hsr_sbj_typ_ref_id": 19917
                                             }
                                           ],
                                           "doc_proc_sts_desc": {
                                             "modifiedBy": "1p1jlikm259dts68hvjjoq3l0l",
                                             "documentId": "8f89ceb8-9701-4c5d-ae77-342111cbfe1f",
                                             "attachments": [
                                               {
                                                 "modifiedBy": "1p1jlikm259dts68hvjjoq3l0l",
                                                 "url": "https://fds-document-bucket-test-365944113879.s3.amazonaws.com/5140/7f4adac1-0029-4081-a7b0-e4e7c419fe17/5bb20558-3ba9-44ad-be4b-4ae35dc8cfd5/Testing.txt?X-Amz-Security-Token=FwoGZXIvYXdzEC4aDNS%2FMQTdhe3KP3CeHSKPBNIwz8yLTjQsDvCNd5OqUFC0twYPed0LC24%2FeHau8fx4ZIISxQDyNxA6kW9uG%2BKUt1Mt5llvxGEmAraczoczuWO0bRdX7kCzPuRplM%2FTLrbj8s%2B4PCvbBDGpGVV1QhunmhunCTiP1B31WGaHd4RyCGcLwFvwYUW2mEZjq1jbdpeLbmoFC5zEY2cKuXGwFR8xh6Bw9SN34grNYy3cMYOv4XslH5OnGk%2FDRsse9h0QwVXjVBAfrvSxl4dzw0d37tpPA%2B08H%2B9kHm0Vx87CgYbuG2gVxWACb9lQu5B0p8zELnXCKg4icJTKOjjRRyFLqny24tPfu35gkf9USytgPb3wVPmR1Nt5ELP6o52FGMNDhWjD11sMm5kiZdtjcIwDxzrs94FntzoHBiqvb7BRhkX1KqgpoXYuVLtlRFxMc2Bqxh1TYeQyfFGFjTDD7hymF4gRW0deUe5Qh6HazWNf3vvS2g8G4mVHYaJHYwpn4Y4JM7JnUyRdUDQKe4x07ZlEdiahkNfcEQ6BiCHIsJoJTOS4s1MqCNlGx746pezt4MV3tdf4Q1x0M0c6c17RBnNJbkIRRH0L8mYSFoWHJ8sklINnK8Qn%2FzAbfW7LTcVd1667sJYD0yFqygNmxjwjG%2FE898r06yV3Z%2BeARdp5gsCJbmvLxOlCSluPNsSLWNeS%2BwB61FyV%2FU8%2BlsQD0y5i8oyNzx5yKOyNvfwFMiqCXJzGy4UXctBWMdzY2N1qMkleqo1RIhDLqat0ZEkqSpqCXoE3cWstJBo%3D&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Date=20201020T202204Z&X-Amz-SignedHeaders=host&X-Amz-Expires=600&X-Amz-Credential=ASIAVKM7YBLL2UBR5FVJ%2F20201020%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Signature=58635153478845998d412c97b4da2f9810360f1cc9eb0dd99bb105a70f45b105",
                                                 "createdBy": "1p1jlikm259dts68hvjjoq3l0l",
                                                 "fileSize": 7,
                                                 "attachmentId": "5bb20558-3ba9-44ad-be4b-4ae35dc8cfd5",
                                                 "modifiedOn": 1603225324693,
                                                 "virusScanStatus": "SKIPPED",
                                                 "contentType": "text/plain",
                                                 "createdOn": 1603225324693,
                                                 "fileName": "Testing.txt",
                                                 "spaceId": "7f4adac1-0029-4081-a7b0-e4e7c419fe17"
                                               }
                                             ],
                                             "searchTerms": [],
                                             "createdBy": "1p1jlikm259dts68hvjjoq3l0l",
                                             "docTypeRefId": 19912,
                                             "metadata": "{\"name\":\"Testing.txt\",\"type\":\"text/plain\",\"notes\":\"\"}",
                                             "modifiedOn": 1603225324832,
                                             "createdOn": 1603225324832,
                                             "spaceId": "7f4adac1-0029-4081-a7b0-e4e7c419fe17"
                                           }
                                         }
                                       ]
                                     }
                                   ]
};
     const temp: any = '["ecp","sos_page_rules_admin"]';
    spyOn(localStorage, 'getItem').and.callFake((key: string): string => {
      return temp;
    });
     fixture.detectChanges();
   });

   afterEach(() => { fixture.destroy(); });

   afterAll(() => {
     TestBed.resetTestingModule();
   });

   it('should create', () => {
     expect(component).toBeTruthy();
     expect(component.fileAuthor).toEqual('SYSTEM');
   });

   it('should have file functions', () => {
       //component.files = [];
       component.files = [{name: 'input File'}];
       component.onFileDropped(fileItem);
       component.fileBrowseHandler(fileItem);
   });

   it('should delete files', () => {
       component.files = [{name: 'inputFile'}];
       component.deleteFile();
       expect(component.files).toEqual([]);
   });

   it('should return nothing when index is 0 and length 0', () => {
       component.files = [];
       expect(component.uploadFilesSimulator(0)).toBeUndefined();
    });

   it('should format bytes', () => {
       expect(component.formatBytes(1024, 0)).toEqual('1 KB');
   });

   it('should format 0 bytes', () => {
       expect(component.formatBytes(0, 0)).toEqual('0 Bytes');
   });

   it('should not add file to file array', () => {
      // component.files = [];
       const fileItem1 = [{size: 629145601, name: 'testFile', progress: 0}];
       component.prepareFilesList(fileItem1);
     //  expect(component.files).toEqual([]);
   });

   it('should add file to file array', () => {
     //  component.files = [];
     component.files = [{name: 'input File'}];
       component.prepareFilesList(fileItem);
   });

   it('should update file in file array if reinserted', () => {
      // component.files = [];
      component.files = [{name: 'input File'}];
       const fileItem1 = [{size: 200, name: 'testFile2', progress: 0}];
       component.prepareFilesList(fileItem1);
       component.submit();
   });

   it('should call file upload service for each file', () => {
      component.files = [new File([], 'testFile1'), new File([], 'testFile2')];
     component.files[0].status = 'Ready to Upload';
      spyOn(component.fileUploadService, 'uploadFile').and.callThrough();
      component.submit();
      expect(component.fileUploadService.uploadFile).toHaveBeenCalledTimes(0);
    });

    it('should call file upload service to delete the file', () => {
      component.files = [new File([], 'testFile1')];
      component.files[0].status = 'Ready to Upload';
      spyOn(component.fileUploadService, 'deleteFile').and.callThrough();
      component.deleteFile();
    });

    it('should open the delete dialog', () => {
      var files = [new File([], 'testFile1')];
      component.showDeleteDialog(files);
      expect(component.deleteDialogModal.show).toEqual(true);
    });

    it('should close the delete dialog', () => {
    component.closeDeleteDialog();
    expect(component.deleteDialogModal.show).toEqual(false);
    });

   it('should call activateNotes()', () => {
        var files = [new File([], 'testFile1')];
        component.activateNotes(files);
        expect(component.activateNotes).toBeTruthy()
      });

   it('should call onCountChange', () => {
       component.onCountChange(8);
       expect(component.onCountChange).toBeTruthy()
   });

   it('should call saveNote', () => {
          component.saveNote();
          expect(component.saveNote).toBeTruthy()
      });
   it('should call addNote', () => {
            var files = [new File([], 'testFile1')];
             component.addNote(files);
             expect(component.addNote).toBeTruthy()
         });

   it('should call document service for each file', () => {
      component.files = [new File([], 'testFile1'), new File([], 'testFile2')];
      component.files[0].status = 'Ready to Upload';
      component.submit();
      component.files[0].hsr_doc_proc_id = 123;
      expect(component.files[0].hsr_doc_proc_id).toEqual(123);
   });

   it('should call saveExpandNote', () => {
         var records = [{"progress":100,"description":"","datetimeAdded":"Mon Nov 16 2020 19:28:20","status":"Ready to Upload","showNotes":true,"sizeFormat":"22 MB","dateTimeFormat":"11/16/20, 1:58 PM","uploadedBy":"SYSTEM","uploadedDate":"Mon Nov 16 2020 19:28:20","filename":"file123.txt"}];
         component.fileForm.get('note').setValue({value: 'Hello'});
         component.saveExpandNote(records);
         expect(component.saveExpandNote).toBeTruthy()
   });

   it('should call saveExpandNote', () => {
        var records = [{"progress":100,"description":"","datetimeAdded":"Mon Nov 16 2020 19:28:20","status":"Ready to Upload","showNotes":true,"sizeFormat":"22 MB","dateTimeFormat":"11/16/20, 1:58 PM","uploadedBy":"SYSTEM","uploadedDate":"Mon Nov 16 2020 19:28:20","filename":"file123.txt"}];
        component.fileForm.get('note').setValue({value: 'Hello'});
        component.cancelNote(records);
        expect(component.cancelNote).toBeTruthy()
      });

  it('should call getAttachmentConfigData', () => {
        spyOn(component.sysConfigService, 'getClientConfigByKey').and.callThrough();
        component.getAttachmentConfigData()
      });

  it('should show the error notification', () => {
    component.files = [new File([], 'testFile1')];
    component.maxFilesAllowed = 1;
    component.processFilesList([new File([], 'testFile2'), new File([], 'testFile3')]);
    expect(component.filesLimitErrorVisible).toBeTrue();
  });

  it('should show getAttachmentsData', () => {
      component.files = [new File([], 'testFile1')];
      component.hscObj = {"hsr_doc_procs": [
                          {
                            "hsr_doc_proc_id": 78,
                            "hsc_id": 7448,
                            "doc_desc": "",
                            "doc_key_val": "8f89ceb8-9701-4c5d-ae77-342111cbfe1f",
                            "doc_proc_sts_ref_id": 19915,
                            "doc_sys_ref_id": 19913,
                            "hsr_doc_typ_ref_id": 19912,
                            "creat_dttm": "2020-10-20T20:22:08.853",
                            "creat_user_id": "SYSTEM",
                            "hsr_doc_proc_sbjs": [
                              {
                                "hsr_doc_proc_id": 78,
                                "hsr_sbj_rec_id": 7448,
                                "hsr_sbj_typ_ref_id": 19917
                              }
                            ],
                            "doc_proc_sts_desc": {
                              "modifiedBy": "1p1jlikm259dts68hvjjoq3l0l",
                              "documentId": "8f89ceb8-9701-4c5d-ae77-342111cbfe1f",
                              "attachments": [
                                {
                                  "modifiedBy": "1p1jlikm259dts68hvjjoq3l0l",
                                  "url": "https://fds-document-bucket-test-365944113879.s3.amazonaws.com/5140/7f4adac1-0029-4081-a7b0-e4e7c419fe17/5bb20558-3ba9-44ad-be4b-4ae35dc8cfd5/Testing.txt?X-Amz-Security-Token=FwoGZXIvYXdzEC4aDNS%2FMQTdhe3KP3CeHSKPBNIwz8yLTjQsDvCNd5OqUFC0twYPed0LC24%2FeHau8fx4ZIISxQDyNxA6kW9uG%2BKUt1Mt5llvxGEmAraczoczuWO0bRdX7kCzPuRplM%2FTLrbj8s%2B4PCvbBDGpGVV1QhunmhunCTiP1B31WGaHd4RyCGcLwFvwYUW2mEZjq1jbdpeLbmoFC5zEY2cKuXGwFR8xh6Bw9SN34grNYy3cMYOv4XslH5OnGk%2FDRsse9h0QwVXjVBAfrvSxl4dzw0d37tpPA%2B08H%2B9kHm0Vx87CgYbuG2gVxWACb9lQu5B0p8zELnXCKg4icJTKOjjRRyFLqny24tPfu35gkf9USytgPb3wVPmR1Nt5ELP6o52FGMNDhWjD11sMm5kiZdtjcIwDxzrs94FntzoHBiqvb7BRhkX1KqgpoXYuVLtlRFxMc2Bqxh1TYeQyfFGFjTDD7hymF4gRW0deUe5Qh6HazWNf3vvS2g8G4mVHYaJHYwpn4Y4JM7JnUyRdUDQKe4x07ZlEdiahkNfcEQ6BiCHIsJoJTOS4s1MqCNlGx746pezt4MV3tdf4Q1x0M0c6c17RBnNJbkIRRH0L8mYSFoWHJ8sklINnK8Qn%2FzAbfW7LTcVd1667sJYD0yFqygNmxjwjG%2FE898r06yV3Z%2BeARdp5gsCJbmvLxOlCSluPNsSLWNeS%2BwB61FyV%2FU8%2BlsQD0y5i8oyNzx5yKOyNvfwFMiqCXJzGy4UXctBWMdzY2N1qMkleqo1RIhDLqat0ZEkqSpqCXoE3cWstJBo%3D&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Date=20201020T202204Z&X-Amz-SignedHeaders=host&X-Amz-Expires=600&X-Amz-Credential=ASIAVKM7YBLL2UBR5FVJ%2F20201020%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Signature=58635153478845998d412c97b4da2f9810360f1cc9eb0dd99bb105a70f45b105",
                                  "createdBy": "1p1jlikm259dts68hvjjoq3l0l",
                                  "fileSize": 7,
                                  "attachmentId": "5bb20558-3ba9-44ad-be4b-4ae35dc8cfd5",
                                  "modifiedOn": 1603225324693,
                                  "virusScanStatus": "SKIPPED",
                                  "contentType": "text/plain",
                                  "createdOn": 1603225324693,
                                  "fileName": "Testing.txt",
                                  "spaceId": "7f4adac1-0029-4081-a7b0-e4e7c419fe17"
                                }
                              ],
                              "searchTerms": [],
                              "createdBy": "1p1jlikm259dts68hvjjoq3l0l",
                              "docTypeRefId": 19912,
                              "metadata": "{\"name\":\"Testing.txt\",\"type\":\"text/plain\",\"notes\":\"\"}",
                              "modifiedOn": 1603225324832,
                              "createdOn": 1603225324832,
                              "spaceId": "7f4adac1-0029-4081-a7b0-e4e7c419fe17"
                            }
                          }
                        ]
                }
      component.getAttachmentsData();
      expect(component.getAttachmentsData).toBeTruthy();
  });
});
