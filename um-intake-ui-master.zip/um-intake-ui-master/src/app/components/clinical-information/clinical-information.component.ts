import {Component, Input, OnInit, EventEmitter, Output, Injectable, HostListener, Host, OnDestroy} from '@angular/core';
import {Subscription} from 'rxjs';
import {ConfigConstants} from '../../constants/configConstants';
import {FlowType} from '../../models/enums/flowType';
import {FileUploadService} from 'src/app/services/file-upload-service/file-upload.service';
import { DatePipe } from "@angular/common";
import { DocumentService } from 'src/app/services/document-service/document.service';
import { ReferenceService } from 'src/app/services/refernce-service/reference.service';
import { FormGroup, FormControl } from '@angular/forms';
import {UserSessionService} from "src/app/shared/services/user-session/user-session.service";
import {StepperDataService} from 'src/app/services/StepperDataService/StepperDataService';
import { ClinicalInformationConstants } from 'src/app/constants/clinical-information-constants';
import {SysConfigService} from "../../services/sysconfig-service/sys-config.service";

@Component({
  selector: "um-clinical-information",
  templateUrl: "./clinical-information.component.html",
  styleUrls: ["./clinical-information.component.scss"]
})

@Injectable({
  providedIn: 'root'
})
export class ClinicalInformationComponent implements OnInit, OnDestroy {
  stepperData: any;
  hscObj: any;
  fileUploadRecordcounter = 0;
  fileUploadRecords = [];

  uploadFiles = [];
  closeButtonText: string = 'Close';
  files: any[] = [];
  inputValue = "";
  public simple: any;
  isErrorMessageEnabled = false;
  myTextLimit: number = 100;
  index: number = 0;
  myCharRemaining: string = 'characters remaining';
  remainingCount: number;
  filesLimitErrorContent = '';
  maxFileSize: number;
  filesLimitErrorVisible = false;
  maxFilesAllowed: any;
  fileDialogModal: boolean = false;
  allowedExtensions: any[] = [];
  fileForm = new FormGroup({
        note: new FormControl(null)
  });
  fileUploadColumns: any = [
    { label: 'Date/Time', id: 'dateTimeFormat', dataType: 'text', style: { width: '150px' } },
    { label: 'File Name', id: 'name', dataType: 'text', style: { width: '400x' }},
    { label: 'Size', id: 'sizeFormat', dataType: 'text'}
  ];
  fileUploadResultsTable = {
    title: 'FileUpload Results Table',
    enableSorting: true
  };

  tableHeader = ['Delete', 'File Name', 'Status', 'Uploaded Date', 'Uploaded By', 'Note'];
  allowedTypes = [];
  fileAuthor: string;
  documentTypeRefData: any = [];
  stepperDataSubscription: Subscription;

  constructor(public  fileUploadService: FileUploadService,
    public readonly documentService: DocumentService,
    private userSessionService: UserSessionService,
    public readonly referenceService: ReferenceService,
    private readonly stepperDataService: StepperDataService,
    public sysConfigService: SysConfigService) {
      this.fileAuthor = this.userSessionService.getUserName();
      this.files = [];
  }


  ngOnInit() {
    this.getAttachmentConfigData();
    this.stepperDataSubscription = this.stepperDataService.sharedStepperData.subscribe((stepperData) => this.stepperData = stepperData);
    this.hscObj=this.stepperData.hsc;
    this.docTypeRefData();
    if(this.stepperData.flowType === FlowType.EDIT && this.hscObj.hsr_doc_procs.length>0){
      this.getAttachmentsData();
      this.stepperDataService.setStepperData({...this.stepperData, hscDocs: this.files});
    }
  }
  ngOnDestroy() {
    this.stepperDataSubscription.unsubscribe();
  }

  async docTypeRefData() {
    await this.referenceService.loadBaseRefNameDisplayData("documentType").toPromise().then((res) => {
      this.documentTypeRefData = res.data.ref;
    }).catch((error) => {
    });
  }

  async getAttachmentsData(){
    const hsrDocProcs = this.hscObj.hsr_doc_procs;
    hsrDocProcs.forEach(element => {
      const item:any = {};
      const d = element.creat_dttm;
      const str = d.toString().substring(0, 24);
      const pipe = new DatePipe('en-US');
      const dateTimeFormat = pipe.transform(
        d, 'short', 'UTC');
      item.description = element.doc_desc;
      item.datetimeAdded = str;
      item.status = 'Uploaded';
      item.doc_key_val = element.doc_key_val;
      item.showNotes = false;
      item.sizeFormat = this.formatBytes(element.doc_proc_sts_desc.attachments[0].fileSize, 0);
      item.dateTimeFormat = dateTimeFormat;
      item.filename = element.doc_proc_sts_desc.attachments[0].fileName;
      item.uploadedBy = element.creat_user_id;
      item.uploadedDate = dateTimeFormat;
      this.files.push(item);
      this.files.sort((a, b) => new Date(b.dateTimeFormat).getTime() - new Date(a.dateTimeFormat).getTime());
    });
  }

  onChangeNote(event, index) {
    this.inputValue = event.target.value;
    this.files[index].description = event.target.value
  }

  /**
   * on file drop handler
   */
  onFileDropped($event) {
    this.processFilesList($event);
  }

  /**
   * handle file from browsing
   */
  fileBrowseHandler(files) {
    this.processFilesList(files);
  }

  /**
   * Delete file from files list
   * @param index (File index)
   */
  deleteFile() {
     const record = this.fileUploadService.getFiles();
     this.files.forEach((file,i) => {
        if(file === record){
                   this.index = i;
              }
            i++;
        });
    const file = this.files[this.index];
    if (file.status === 'Uploaded') {
      this.fileUploadService.deleteFile(file).toPromise().then((data) => {
          file.status = 'Deleted';
        this.documentService.deleteHsrDocProcSbj(file.hsr_doc_proc_id).then(async (res) => {
          file.hsr_doc_proc_id = res.data.delete_hsr_doc_proc_sbj.returning[0].hsr_doc_proc_id;
        });
        this.documentService.deleteHsrDocProc(file.hsr_doc_proc_id).then(async (res) => {
          file.hsr_doc_proc_id = res.data.delete_hsr_doc_proc_sbj.returning[0].hsr_doc_proc_id;
        });
      }).catch((err) => {
          file.status = 'Failed';
      });
    }
    this.files.splice(this.index, 1);
    this.closeDeleteDialog();
  }



  onEnterPressed(event: Event, index: number) {
    const finalValue = this.inputValue;
    const file = this.files[index];
    file.description = finalValue;
    this.files[index] = file;
  }

  /**
   * Simulate the upload process
   */
  uploadFilesSimulator(index: number) {
    setTimeout(() => {
      if (index === this.files.length) {
        return;
      } else {
        const progressInterval = setInterval(() => {
          if (this.files[index].progress === 100) {
            clearInterval(progressInterval);
            this.uploadFilesSimulator(index + 1);
          } else {
            this.files[index].progress += 5;
          }
        }, 200);
      }
    }, 1000);
  }


  processFilesList(files: Array<any>) {
    if( this.maxFilesAllowed > 0 && (this.files.length + files.length) > this.maxFilesAllowed){
      this.filesLimitErrorContent = 'You have selected too many files to attach. Please limit your selection to ' + this.maxFilesAllowed + ' files.';
      this.showFilesLimitErrorNotification();
    }else{
      this.prepareFilesList(files);
    }
  }

  /**
   * Convert Files list to normal array list
   * @param files (Files List)
   */
  prepareFilesList(files: Array<any>) {
    for (const item of files) {
      var regexp = new RegExp("^[A-Za-z0-9._ -]+$");
      var regexpfiletype = new RegExp("^.*\.(bmp|BMP|doc|DOC|gif|GIF|jpg|JPG|jpeg|JPEG|pdf|PDF|png|PNG|tiff|TIFF|txt|TXT)$");
      let FileErrMessage = ClinicalInformationConstants.FILE_STATUS_READY;
      if (item.size > 25000000) {
        FileErrMessage = ClinicalInformationConstants.FILE_SIZE_TOO_LARGE_MSG;
      }
      if ((!(regexpfiletype.test(item.name))) &&
        !this.allowedExtensions.includes(
          item.name.substr(item.name.lastIndexOf(".") + 1) || !this.allowedTypes.includes(item.type)
        )) {
        FileErrMessage = ClinicalInformationConstants.FILE_TYPE_INVALID_MSG;
      }
      if (!(regexp.test(item.name))) {
        FileErrMessage = ClinicalInformationConstants.FILE_NAME_INVALID_MSG;
      }
      item.progress = 100;
      const d = new Date();
      const str = d.toString().substring(0, 24);
      const pipe = new DatePipe('en-US');
      const dateTimeFormat = pipe.transform(
        d, 'short', 'UTC');
      item.description = '';
      item.datetimeAdded = str;
      item.status = FileErrMessage;
      item.showNotes = false;
      item.sizeFormat = this.formatBytes(item.size, 0);
      item.dateTimeFormat = dateTimeFormat;
      item.uploadedBy = this.fileAuthor;
      item.uploadedDate = dateTimeFormat;
      item.filename = item.name;
      this.files.sort((a, b) => new Date(b.datetimeAdded).getTime() - new Date(a.datetimeAdded).getTime());
      this.files.push(item);
    }
  }

  submit() {
     if (this.files.length > 0) {
         this.files.forEach((file) => {
           if(file.status != ClinicalInformationConstants.FILE_STATUS_READY && file.status != "Uploaded" ){
                     this.fileUploadService.setFiles(file);
                     this.deleteFile();
            }
         });
     }
     if (this.files.length > 0) {
       this.files.forEach((file) => {
          if(file.status == ClinicalInformationConstants.FILE_STATUS_READY ){
               file.status = 'In Progress';
               const metadata = {
                name: file.name,
                type: file.type,
                notes: file.description
              };
               this.fileUploadService.uploadFile(file, metadata).toPromise().then(async (data) => {
                 const document: any = {};
                 file.url = data.attachments[0].url;
                 file.doc_key_val = data.documentId;
                 file.status = 'Uploaded';
                 const fileExt = data.attachments[0].fileName.split('.').pop();
                 const docTypeRefObj = this.documentTypeRefData.find(result => result.ref_dspl.toLowerCase() == fileExt);
                 data.docTypeRefId =  docTypeRefObj?.ref_id;
                 document.doc_desc = file.description;
                 document.doc_key_val = data.documentId;
                 document.doc_proc_sts_desc = data;
                 document.doc_proc_sts_ref_id = 19915;
                 document.doc_sys_ref_id = 19913;
                 document.hsc_id = this.stepperData.hscId;
                 document.doc_url =  data.attachments[0].url.split('=')[0];
                 document.hsr_doc_typ_ref_id = docTypeRefObj.ref_id;
                 this.documentService.executeSaveHsrDocProcMutation(document).then((res) => {
                 file.hsr_doc_proc_id = res.insert_hsr_doc_proc_one.hsr_doc_proc_id;
                 this.documentService.executeSaveHsrDocProcSbjMutation(file.hsr_doc_proc_id, this.stepperData.hscId);
                });
               }).catch((err) => {
                 file.status = 'Failed';
               });
              }
           });
           this.stepperDataService.setStepperData({...this.stepperData, hscDocs: this.files});
      }
  }

  viewFile(documentId: any){
      this.fileUploadService.viewFile(documentId).subscribe(info => {
         const url = info.attachments[0].url;
          window.open(url);
      });
  }

  /**
   * format bytes
   * @param bytes (File size in bytes)
   * @param decimals (Decimals point)
   */
  formatBytes(bytes, decimals) {
    if (bytes === 0) {
      return "0 Bytes";
    }
    const k = 1024;
    const dm = decimals <= 0 ? 0 : decimals || 2;
    const sizes = ["Bytes", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    const term = parseFloat((bytes / Math.pow(k, i)).toFixed(dm));
    return `${term} ${sizes[i]}`;
  }

  deleteDialogModal = {
    show: false,
  };

  showDeleteDialog(record: any) {
    this.fileUploadService.setFiles(record);
    this.deleteDialogModal.show = true;
  }

  closeDeleteDialog() {
    this.deleteDialogModal.show = false;
  }

  showFilesLimitErrorNotification() {
    this.filesLimitErrorVisible = true;
  }

  activateNotes(record: any) {
     this.fileForm.reset();
     record.showNotes = true;
  }

  saveNote(){
     const record = this.fileUploadService.getFiles();
     this.files.forEach((file) => {
          if(file == record){
             file.description = this.fileForm.get('note').value;
             console.log("from value ", file.description);
          }
       });
     this.fileDialogModal = false;
     console.log(this.files);
     this.fileUploadService.setFiles(record);
  }
  onCountChange(count: number) {
        this.remainingCount = count;
  }

  addNote(record: any){
       this.files.forEach((file) => {
           if(file == record){
              this.fileForm.patchValue({note: file.description,});
           }
       });
       record.showNotes = true;
   }

  saveExpandNote(record: any) {
       this.files.forEach((file) => {
               if(file.filename == record.filename){
                   this.fileUploadService.setFiles(file);
                    this.saveNote();
                    record.showNotes = false;
               }
            });
   }

  cancelNote(record: any) {
     this.files.forEach((file) => {
        if(file.filename == record.filename){
             record.showNotes = false;
        }
     });
  }

  getAttachmentConfigData(){
    this.sysConfigService.getClientConfigByKey(ConfigConstants.ATTACHMENT_CONFIG_KEY).subscribe((response) => {
      const configData = JSON.parse(response[0].value);
      this.maxFileSize = configData?.maxFileSizeMB;
      if(configData?.maxFilesAllowed){
        this.maxFilesAllowed = configData?.maxFilesAllowed;
      }else{
        //if null unlimited files can be accepted
        this.maxFilesAllowed = 0;
      }
      this.referenceService.getBulkRefEntriesByRefIds(configData?.documentTypeRefIds).subscribe((refData) =>{
       refData.data.ref.forEach(element => {
         this.allowedExtensions.push(element.ref_dspl);
         this.allowedTypes.push(element.ref_desc);
        });
      });
    });
  }

}
