import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import {CUSTOM_ELEMENTS_SCHEMA, DebugElement, NO_ERRORS_SCHEMA} from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import {uitkAngularModules, uitkModules} from '../../../app.module';
import {ClinicalInformationComponent} from '../clinical-information.component';
import { DragNDropDirective } from './drag-n-drop.directive';

describe('DragNDropDirective', () => {
   let fixture: ComponentFixture<ClinicalInformationComponent>;
   let inputEl: HTMLElement;
   let input: DebugElement;

   beforeEach(() => {
       fixture = TestBed.configureTestingModule({
          imports: [uitkModules, uitkAngularModules, FormsModule, ReactiveFormsModule, HttpClientTestingModule],
          schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
          providers: [HttpClient],
          declarations: [DragNDropDirective, ClinicalInformationComponent],

       }).createComponent(ClinicalInformationComponent);
       input = fixture.debugElement.query(By.directive(DragNDropDirective));
        const temp: any = '["ecp","provider"]';
         spyOn(localStorage, 'getItem').and.callFake((key: string): string => {
           return temp;
         });
       fixture.detectChanges();
   });

   it('should create an instance', () => {
      const directive = new DragNDropDirective();
      expect(directive).toBeTruthy();
    });

   it('should prevent dragover event', () => {
      const event = new DragEvent('dragover', null);
      input.nativeElement.dispatchEvent(event);
      expect(event.defaultPrevented).toBeFalsy();
    });

   it('should prevent dragleave event', () => {
      const event = new DragEvent('dragleave', null);
      input.nativeElement.dispatchEvent(event);
      expect(event.defaultPrevented).toBeFalsy();
    });

   it('should prevent drop event', () => {
      const event = new DragEvent('drop', null);
      input.nativeElement.dispatchEvent(event);
      expect(event.defaultPrevented).toBeFalsy();
     });
});
