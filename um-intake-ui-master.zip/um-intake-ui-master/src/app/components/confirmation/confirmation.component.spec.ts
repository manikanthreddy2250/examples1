import {HttpClient} from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import {CUSTOM_ELEMENTS_SCHEMA, Injectable, NO_ERRORS_SCHEMA} from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {ActivatedRoute} from '@angular/router';
import {RouterTestingModule} from '@angular/router/testing';
import {BehaviorSubject, Observable, of} from 'rxjs';
import {environment} from 'src/environments/environment';
import {ReferenceConstants} from 'src/app/constants/referenceConstants';
import {StepperDataService} from 'src/app/services/StepperDataService/StepperDataService';
import {ReferenceService} from '../../services/refernce-service/reference.service';
import {ConfirmationComponent} from './confirmation.component';
import {ProviderSearchService} from "../../services/provider-search/provider-search.service";
import {UserSessionService} from '../../shared/services/user-session/user-session.service';
const activatedRouteStub = {
  params: of({ id: 22 })
};
@Injectable()
class MockStepperDataService {
  private stepperData = new BehaviorSubject({tenantId: 'ecpumintakebaseproductbpmgrp'});
  sharedStepperData = this.stepperData.asObservable();

  constructor() { }

  setStepperData(stepperData: any) {
    this.stepperData.next(stepperData);
  }
}
@Injectable()
class ProviderSearchMockService {
  getProviderTinOrNpiSearch(providerCategoryId, providerTIN, providerNPI): Observable<any> {
    return of({ data: {
        v_prov_srch: [{prov_id: '667', providerTin: '345', addressLine: 'test', lst_nm: 'test', fst_nm: 'test',
          bus_nm: 'facility', telcom_adr_id: '46', spcl_ref_dspl: 'vg', spcl_ref_id: '546',
          prov_loc_affil_id: '8686'}]
      } });
  }
  setProviderDetails(providerTelecomAddressId: string, providerSpecialtyRefId: string,
                     providerLocationAffiliationId: string, PROVIDER_ROLE_REF_ID: number, stepperData: any): Observable<any> {
    return of({hscduplicates: [{hsc_id: 123}]});
  }
  getProviderNameSearch(providerCategoryId: number, providerFirstName: string, providerLastName: string, providerState: number,
                        providerZipCode: string, providerOrgName: string): Observable<any> {
    return of({});
  }
  getProviderTinOrNpi(providerID: string, providerKeyTypeRefId: number): Observable<any> {
    return of({data: {
        prov_key: [{prov_key_val: '455'}]
      }});
  }
  getHscProvider(hscid): Observable<any> {
    return of({data: {
        hsc_prov: [{prov_key_val: '455', prov_loc_affil_id: 76, hsc_prov_roles: [{prov_role_ref_id: 3760}]
        }, {prov_key_val: '455', prov_loc_affil_id: 76, hsc_prov_roles: [{prov_role_ref_id: 3758}]
        }]}});
  }

  getHscProviderByProviderId(providerID: string): Observable<any> {
    return of({data: {
        hsc_prov: [{prov_key_val: '455'},{prov_loc_affil_id:'7'}]
      }});

  }
  getReferenceCD(ref_id: number): Observable<any> {
    return of({data: {
        ref: [{ref_cd: '455'},{ref_dspl:'test ref'}]
      }});

  }

  getProviderTinSearch(locationAffiliationId: number, providerTIN: string, providerTINKey: number) : Observable<any> {
    return of({data: {
        v_prov_srch: [{st_ref_id: 172, prov_id: 125, adr_ln_1_txt: 'g', adr_ln_2_txt: 'r', cty_nm: 'test', zip_cd_txt: '645456',
          spcl_ref_id: 437, }]
      }});
  }
  getProviderDetailsSearch(provId, provAdrId, provtelcomAdrId, ProvSpecialtyRefId): Observable<any> {
    return of({ data: {
        v_prov_srch: [{prov_id: '667', providerTin: '345', addressLine: 'test', lst_nm: 'test', fst_nm: 'test',
          bus_nm: 'facility', telcom_adr_id: '46', spcl_ref_dspl: 'vg', spcl_ref_id: '546', }]
      } });
  }
}
@Injectable()
class MockHttpClient {
  post(url: string, body: any | null, httpOptions?: any) {
    if (url === environment.GET_HSC_AUTH_DETAILS) {
      return of({
        hsc: [
          {
            hsc_id: 7557,
            srvc_set_ref_id: ReferenceConstants.SERVICESETTINGTYPE_INPATIENT,
            flwup_cntc_dtl: {
              primary_cntct: {
                department: 'Admitting',
                email: 'john_doe@gmail.com',
                phone: '555-555-5555',
                fax: '555-555-5555',
                creat_dttm: '2020-10-16T12:27:14.998Z',
                chg_dttm: '2020-10-16T12:52:13.277Z',
                creat_user_id: 'SYSTEM',
                role: 'Facility',
                name: 'gopi'
              }
            },
            rev_prr_ref_id: 3754,
            rev_prr_ref_cd: [
              {
                ref_id: 3754,
                ref_desc: 'Routine',
                ref_dspl: 'Routine'
              }
            ],
            srvc_set_ref_cd: [
              {
                ref_id: 3739,
                ref_desc: 'Outpatient Facility',
                ref_dspl: 'Outpatient Facility'
              }
            ],
            hsc_srvcs: [
              {
                inac_ind: 0,
                proc_cd: '80346',
                proc_cd_schm_ref_id: 2,
                proc_othr_txt: ' DRUG SCREENING BENZODIAZEPINES 1-12',
                srvc_hsc_prov_id: null,
                hsc_srvc_non_facls: [
                  {
                    plsrv_ref_id: 3741,
                    plsrv_ref_cd: [
                      {
                        ref_id: 3741,
                        ref_desc: 'Home',
                        ref_dspl: 'Home'
                      }
                    ],
                    proc_uom_ref_cd: [
                      {
                        ref_id: 3741,
                        ref_desc: 'Home',
                        ref_dspl: 'Home'
                      }
                    ],
                    proc_freq_ref_cd: [
                      {
                        ref_id: 3741,
                        ref_desc: 'Home',
                        ref_dspl: 'Home'
                      }
                    ],
                    srvc_dtl_ref_cd: [
                      {
                        ref_id: 3741,
                        ref_desc: 'Home',
                        ref_dspl: 'Home'
                      }
                    ]
                  }
                ]
              },
              {
                inac_ind: 0,
                proc_cd: null,
                proc_cd_schm_ref_id: 4,
                proc_othr_txt: ' 12-LEAD ELECTROCARDIOGRAM PERFORMED',
                srvc_hsc_prov_id: null,
                hsc_srvc_non_facls: []
              }
            ],
            hsc_facls: [
              {
                actul_admis_dttm: '2020-10-16T00:00:00',
                actul_dschrg_dttm: '2020-10-16T00:00:00',
                expt_admis_dt: null,
                expt_dschrg_dt: null,
                plsrv_ref_id: 3746,
                plsrv_ref_cd: [
                  {
                    ref_id: 3746,
                    ref_desc: 'Ambulatory Surgical Center',
                    ref_dspl: 'Ambul Surgical Centr'
                  }
                ],
                srvc_desc_ref_id: 4347,
                srvc_desc_ref_cd: [
                  {
                    ref_id: 4347,
                    ref_desc: 'Scheduled',
                    ref_dspl: 'Scheduled'
                  }
                ],
                srvc_dtl_ref_id: 4307,
                srvc_dtl_ref_cd: [
                  {
                    ref_id: 4307,
                    ref_desc: 'Surgical',
                    ref_dspl: 'Surgical'
                  }
                ]
              }
            ],
            hsc_diags: [
              {
                hsc_diag_id: 1905,
                diag_cd: 'M02.149',
                inac_ind: 0,
                hscDiagDiagCdRef: [
                  {
                    shrt_desc: 'POSTDYSENTERIC ARTHROPATHY UNS HAND',
                    full_desc: 'Postdysenteric arthropathy, unspecified hand',
                    cd_desc: 'POSTDYSENTERIC ARTHROPATHY UNSPECIFIED HAND'
                  }
                ]
              },
              {
                hsc_diag_id: 1907,
                diag_cd: 'S65.112',
                inac_ind: 0,
                hscDiagDiagCdRef: [
                  {
                    shrt_desc: 'LAC RAD ART WRIST HAND LEVEL LT ARM',
                    full_desc: 'Laceration of radial artery at wrist and hand level of left arm',
                    cd_desc: 'LACERATION RADIAL ARTERY WRIST HAND LEVEL LT ARM'
                  }
                ]
              }
            ],
            hsr_notes: [
              {
                hsr_note_id: 374,
                note_titl_txt: 'opf subject',
                note_txt_lobj: 'opf subject note',
                creat_user_id: 'SYSTEM',
                note_typ_ref_id: 11,
                src_user_nm: 'Provider',
                creat_dttm: '2020-10-16T12:52:44.233'
              },
              {
                hsr_note_id: 375,
                note_titl_txt: 'opf check',
                note_txt_lobj: 'add notes',
                creat_user_id: 'SYSTEM',
                note_typ_ref_id: 11,
                src_user_nm: 'Provider',
                creat_dttm: '2020-10-16T12:53:05.874'
              }
            ],
            hsr_doc_procs: [
              {
                "hsr_doc_proc_id": 78,
                "hsc_id": 7448,
                "doc_desc": "",
                "doc_key_val": "8f89ceb8-9701-4c5d-ae77-342111cbfe1f",
                "doc_proc_sts_ref_id": 19915,
                "doc_sys_ref_id": 19913,
                "hsr_doc_typ_ref_id": 19912,
                "creat_dttm": "2020-10-20T20:22:08.853",
                "creat_user_id": "SYSTEM",
                "hsr_doc_proc_sbjs": [
                  {
                    "hsr_doc_proc_id": 78,
                    "hsr_sbj_rec_id": 7448,
                    "hsr_sbj_typ_ref_id": 19917
                  }
                ],
                "doc_proc_sts_desc": {
                  "modifiedBy": "1p1jlikm259dts68hvjjoq3l0l",
                  "documentId": "8f89ceb8-9701-4c5d-ae77-342111cbfe1f",
                  "attachments": [
                    {
                      "modifiedBy": "1p1jlikm259dts68hvjjoq3l0l",
                      "url": "https://fds-document-bucket-test-365944113879.s3.amazonaws.com/5140/7f4adac1-0029-4081-a7b0-e4e7c419fe17/5bb20558-3ba9-44ad-be4b-4ae35dc8cfd5/Testing.txt?X-Amz-Security-Token=FwoGZXIvYXdzEC4aDNS%2FMQTdhe3KP3CeHSKPBNIwz8yLTjQsDvCNd5OqUFC0twYPed0LC24%2FeHau8fx4ZIISxQDyNxA6kW9uG%2BKUt1Mt5llvxGEmAraczoczuWO0bRdX7kCzPuRplM%2FTLrbj8s%2B4PCvbBDGpGVV1QhunmhunCTiP1B31WGaHd4RyCGcLwFvwYUW2mEZjq1jbdpeLbmoFC5zEY2cKuXGwFR8xh6Bw9SN34grNYy3cMYOv4XslH5OnGk%2FDRsse9h0QwVXjVBAfrvSxl4dzw0d37tpPA%2B08H%2B9kHm0Vx87CgYbuG2gVxWACb9lQu5B0p8zELnXCKg4icJTKOjjRRyFLqny24tPfu35gkf9USytgPb3wVPmR1Nt5ELP6o52FGMNDhWjD11sMm5kiZdtjcIwDxzrs94FntzoHBiqvb7BRhkX1KqgpoXYuVLtlRFxMc2Bqxh1TYeQyfFGFjTDD7hymF4gRW0deUe5Qh6HazWNf3vvS2g8G4mVHYaJHYwpn4Y4JM7JnUyRdUDQKe4x07ZlEdiahkNfcEQ6BiCHIsJoJTOS4s1MqCNlGx746pezt4MV3tdf4Q1x0M0c6c17RBnNJbkIRRH0L8mYSFoWHJ8sklINnK8Qn%2FzAbfW7LTcVd1667sJYD0yFqygNmxjwjG%2FE898r06yV3Z%2BeARdp5gsCJbmvLxOlCSluPNsSLWNeS%2BwB61FyV%2FU8%2BlsQD0y5i8oyNzx5yKOyNvfwFMiqCXJzGy4UXctBWMdzY2N1qMkleqo1RIhDLqat0ZEkqSpqCXoE3cWstJBo%3D&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Date=20201020T202204Z&X-Amz-SignedHeaders=host&X-Amz-Expires=600&X-Amz-Credential=ASIAVKM7YBLL2UBR5FVJ%2F20201020%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Signature=58635153478845998d412c97b4da2f9810360f1cc9eb0dd99bb105a70f45b105",
                      "createdBy": "1p1jlikm259dts68hvjjoq3l0l",
                      "fileSize": 7,
                      "attachmentId": "5bb20558-3ba9-44ad-be4b-4ae35dc8cfd5",
                      "modifiedOn": 1603225324693,
                      "virusScanStatus": "SKIPPED",
                      "contentType": "text/plain",
                      "createdOn": 1603225324693,
                      "fileName": "Testing.txt",
                      "spaceId": "7f4adac1-0029-4081-a7b0-e4e7c419fe17"
                    }
                  ],
                  "searchTerms": [],
                  "createdBy": "1p1jlikm259dts68hvjjoq3l0l",
                  "docTypeRefId": 19912,
                  "metadata": "{\"name\":\"Testing.txt\",\"type\":\"text/plain\",\"notes\":\"\"}",
                  "modifiedOn": 1603225324832,
                  "createdOn": 1603225324832,
                  "spaceId": "7f4adac1-0029-4081-a7b0-e4e7c419fe17"
                }
              }
            ]
          }
        ]
      });
    } else {
      return of({});
    }
  }
}

@Injectable()
class MockReferenceService {
  loadBaseRefNameDisplayData(baseRefName: string): Observable<any> {
    return of({data: { ref : [{ref_id: 1, ref_dspl: 'test', ref_cd: 123}] }});
  }

  getProcedureDescByCodes(procedures: any[]) {
    return [{proc_cd: '123', cd_desc: 'test desc'}];
  }
}

@Injectable()
class UserSessionMockService {
  i = 0;
  getUserName() {
    if (this.i === 0) {
      this.i++;
      return 'breddy88';
    } else if (this.i === 1) {
      this.i = this.i + 2;
      return 'SYSTEM';
    } else if (this.i === 3)  {
      return 'abcd';
    }
  }
  getUserOrg() {
    return 'ecp';
  }
  getUserPermission() {}
  getEcpToken() {}
  getFunctionalRole() {}
}

describe('ConfirmationComponent', () => {
  let component: ConfirmationComponent;
  let fixture: ComponentFixture<ConfirmationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule.withRoutes([])],
      declarations: [ ConfirmationComponent ],
      providers: [{ provide: StepperDataService, useClass: MockStepperDataService },
        { provide: HttpClient, useClass: MockHttpClient }, { provide: ActivatedRoute, useValue: activatedRouteStub }, { provide: ProviderSearchService, useClass: ProviderSearchMockService },
        {provide: ReferenceService, useClass: MockReferenceService}, { provide: UserSessionService, useClass: UserSessionMockService }],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfirmationComponent);
    component = fixture.componentInstance;
    component.hscObj ={"hsc": [
      {
        "hsc_id": 7448,
        "auth_end_dt": null,
        "auth_strt_dt": null,
        "auth_typ_ref_id": null,
        "cont_of_care_ind": null,
        "indv_id": 503926748,
        "mbr_cov_dtl": null,
        "mbr_cov_id": 12484,
        "rev_prr_ref_id": 3754,
        "srvc_set_ref_id": 3738,
        "hsc_keys": [
          {
            "hsc_id": 7448,
            "hsc_key_val": "25a3edda-0e43-11eb-a339-86406bb57ba2",
            "inac_ind": 0,
            "hsc_key_typ_ref_id": 19517
          }
        ],
        "hsc_diags": [
          {
            "diag_cd": "S83.116",
            "inac_ind": 0,
            "hsc_id": 7448,
            "pri_ind": 0,
            "hscDiagDiagCdRef": [
              {
                "shrt_desc": "ANT DISLOCATION PROX TIBIA UNS KNEE",
                "full_desc": "Anterior dislocation of proximal end of tibia, unspecified knee",
                "cd_desc": "ANTERIOR DISLOCATION PROXIMAL END TIBIA UNS KNEE"
              }
            ]
          },
          {
            "diag_cd": "S80.242D",
            "inac_ind": 0,
            "hsc_id": 7448,
            "pri_ind": 1,
            "hscDiagDiagCdRef": [
              {
                "shrt_desc": "EXTERNAL CONSTRICTION LT KNEE SBSQT",
                "full_desc": "External constriction, left knee, subsequent encounter",
                "cd_desc": "EXTERNAL CONSTRICTION LT KNEE SUBSEQUENT ENCNTR"
              }
            ]
          }
        ],
        "hsc_provs": [
          {
            "hsc_id": 7448,
            "hsc_prov_id": 254,
            "prov_loc_affil_id": 5,
            "spcl_ref_id": 17048,
            "telcom_adr_id": "4326392664",
            "hsc_prov_roles": [
              {
                "hsc_prov_id": 254,
                "prov_role_ref_id": 3766
              }
            ]
          }
        ],
        "hsc_facls": [
          {
            "hsc_id": 7448,
            "actul_admis_dttm": "2020-10-11T00:00:00",
            "actul_dschrg_dttm": "2020-10-13T00:00:00",
            "expt_admis_dt": "2020-10-11",
            "expt_dschrg_dt": "2020-10-17",
            "plsrv_ref_id": 3743,
            "srvc_desc_ref_id": 4347,
            "srvc_dtl_ref_id": 4296
          }
        ],
        "hsr_doc_procs": [
          {
            "hsr_doc_proc_id": 78,
            "hsc_id": 7448,
            "doc_desc": "",
            "doc_key_val": "8f89ceb8-9701-4c5d-ae77-342111cbfe1f",
            "doc_proc_sts_ref_id": 19915,
            "doc_sys_ref_id": 19913,
            "hsr_doc_typ_ref_id": 19912,
            "creat_dttm": "2020-10-20T20:22:08.853",
            "creat_user_id": "SYSTEM",
            "hsr_doc_proc_sbjs": [
              {
                "hsr_doc_proc_id": 78,
                "hsr_sbj_rec_id": 7448,
                "hsr_sbj_typ_ref_id": 19917
              }
            ],
            "doc_proc_sts_desc": {
              "modifiedBy": "1p1jlikm259dts68hvjjoq3l0l",
              "documentId": "8f89ceb8-9701-4c5d-ae77-342111cbfe1f",
              "attachments": [
                {
                  "modifiedBy": "1p1jlikm259dts68hvjjoq3l0l",
                  "url": "https://fds-document-bucket-test-365944113879.s3.amazonaws.com/5140/7f4adac1-0029-4081-a7b0-e4e7c419fe17/5bb20558-3ba9-44ad-be4b-4ae35dc8cfd5/Testing.txt?X-Amz-Security-Token=FwoGZXIvYXdzEC4aDNS%2FMQTdhe3KP3CeHSKPBNIwz8yLTjQsDvCNd5OqUFC0twYPed0LC24%2FeHau8fx4ZIISxQDyNxA6kW9uG%2BKUt1Mt5llvxGEmAraczoczuWO0bRdX7kCzPuRplM%2FTLrbj8s%2B4PCvbBDGpGVV1QhunmhunCTiP1B31WGaHd4RyCGcLwFvwYUW2mEZjq1jbdpeLbmoFC5zEY2cKuXGwFR8xh6Bw9SN34grNYy3cMYOv4XslH5OnGk%2FDRsse9h0QwVXjVBAfrvSxl4dzw0d37tpPA%2B08H%2B9kHm0Vx87CgYbuG2gVxWACb9lQu5B0p8zELnXCKg4icJTKOjjRRyFLqny24tPfu35gkf9USytgPb3wVPmR1Nt5ELP6o52FGMNDhWjD11sMm5kiZdtjcIwDxzrs94FntzoHBiqvb7BRhkX1KqgpoXYuVLtlRFxMc2Bqxh1TYeQyfFGFjTDD7hymF4gRW0deUe5Qh6HazWNf3vvS2g8G4mVHYaJHYwpn4Y4JM7JnUyRdUDQKe4x07ZlEdiahkNfcEQ6BiCHIsJoJTOS4s1MqCNlGx746pezt4MV3tdf4Q1x0M0c6c17RBnNJbkIRRH0L8mYSFoWHJ8sklINnK8Qn%2FzAbfW7LTcVd1667sJYD0yFqygNmxjwjG%2FE898r06yV3Z%2BeARdp5gsCJbmvLxOlCSluPNsSLWNeS%2BwB61FyV%2FU8%2BlsQD0y5i8oyNzx5yKOyNvfwFMiqCXJzGy4UXctBWMdzY2N1qMkleqo1RIhDLqat0ZEkqSpqCXoE3cWstJBo%3D&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Date=20201020T202204Z&X-Amz-SignedHeaders=host&X-Amz-Expires=600&X-Amz-Credential=ASIAVKM7YBLL2UBR5FVJ%2F20201020%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Signature=58635153478845998d412c97b4da2f9810360f1cc9eb0dd99bb105a70f45b105",
                  "createdBy": "1p1jlikm259dts68hvjjoq3l0l",
                  "fileSize": 7,
                  "attachmentId": "5bb20558-3ba9-44ad-be4b-4ae35dc8cfd5",
                  "modifiedOn": 1603225324693,
                  "virusScanStatus": "SKIPPED",
                  "contentType": "text/plain",
                  "createdOn": 1603225324693,
                  "fileName": "Testing.txt",
                  "spaceId": "7f4adac1-0029-4081-a7b0-e4e7c419fe17"
                }
              ],
              "searchTerms": [],
              "createdBy": "1p1jlikm259dts68hvjjoq3l0l",
              "docTypeRefId": 19912,
              "metadata": "{\"name\":\"Testing.txt\",\"type\":\"text/plain\",\"notes\":\"\"}",
              "modifiedOn": 1603225324832,
              "createdOn": 1603225324832,
              "spaceId": "7f4adac1-0029-4081-a7b0-e4e7c419fe17"
            }
          }
        ]
      }
    ]
};
    fixture.detectChanges();
  });
  afterEach(() => { fixture.destroy(); });

  afterAll(() => {
    TestBed.resetTestingModule();
  });
  it('should create', () => {
    component.stepperData = {hsc: {srvc_set_ref_id: 3737}};
    expect(component).toBeTruthy();
  });
  it('should buildProviderResultsDraftData', () => {
    let hsc_prov=[{
      "hsc_id": 7448,
      "hsc_prov_id": 254,
      "prov_loc_affil_id": 5,
      "spcl_ref_id": 17048,
      "telcom_adr_id": "4326392664",
      "hsc_prov_roles": [{
        "hsc_prov_id": 254,
        "prov_role_ref_id": 3766
      }]
    }, {
      "hsc_id": 7448,
      "hsc_prov_id": 311,
      "prov_loc_affil_id": 7,
      "spcl_ref_id": 16696,
      "telcom_adr_id": "3044429999",
      "hsc_prov_roles": [{
        "hsc_prov_id": 311,
        "prov_role_ref_id": 3760
      }]
    }];
    expect(component.getServicingProviderDetail).toBeTruthy();
    if(hsc_prov !==null){
      component.mapProviderDetail(hsc_prov,"WV");
    }
  });
  it('should getProviderAddressLine', () => {
    component.getProviderAddressLine('Adr1', 'Adr2', 'newyork', 'NYZ123', '4567');
    expect(component.getProviderAddressLine).toBeDefined();
  });

  it('should getServicingProviderName PHYSICIAN ', () => {
    const addressLine = "address 1 ,2 Tin City";
    const providerTin = "1234567";

    const servicingProviderDetail= {
      businessName: 'bussiness name',
      firstName: 'first name',
      lastName: 'fst name' + ', ' + 'providerDetails.fst_nm',
      addressLine, providerTin,
      prov_id: '12375544',
      phone: '13214566',
      specialty: '3445466',
      specialtyId: '3445466',
      locationAffiliationId: '7',
      providerCategoryId: 16309,
    };

    component.getServicingProviderName(servicingProviderDetail);
    if (ReferenceConstants.PHYSICIAN_CAT_ID === servicingProviderDetail.providerCategoryId) {
      expect(component.getServicingProviderName).toBeDefined();
    }

  });

  it('should getServicingProviderName Facility', () => {
    const addressLine = "address 1 ,2 Tin City";
    const providerTin = "1234567";

    const servicingProviderDetail= {
      businessName: 'bussiness name',
      firstName: 'first name',
      lastName: 'fst name' + ', ' + 'providerDetails.fst_nm',
      addressLine, providerTin,
      prov_id: '12375544',
      phone: '13214566',
      specialty: '3445466',
      specialtyId: '3445466',
      locationAffiliationId: '7',
      providerCategoryId: 16310,
    };
    component.getServicingProviderName(servicingProviderDetail);
    if (ReferenceConstants.FACILITY_CAT_ID === servicingProviderDetail.providerCategoryId) {
      expect(component.getServicingProviderName).toBeDefined();
    }

  });

  it('should getServicingProviderDetail', () => {
    component.getServicingProviderDetail(1234);
    expect(component.getServicingProviderDetail).toBeDefined();
  });

  it('should prepareProcedureOPDisplycall', () => {
    const procData  = [
      {
        inac_ind: 0,
        proc_cd: '80346',
        proc_cd_schm_ref_id: 2,
        proc_othr_txt: ' DRUG SCREENING BENZODIAZEPINES 1-12',
        srvc_hsc_prov_id: null,
        hsc_srvc_non_facls: [
          {
            "plsrv_ref_id": 3741,
            "plsrv_ref_cd": [
              {
                "ref_id": 3741,
                "ref_desc": "Home",
                "ref_dspl": "Home"
              }
            ],
            "proc_uom_ref_cd": [
              {
                "ref_id": 3741,
                "ref_desc": "Home",
                "ref_dspl": "Home"
              }
            ],
            "proc_freq_ref_cd": [
              {
                "ref_id": 3741,
                "ref_desc": "Home",
                "ref_dspl": "Home"
              }
            ],
            "srvc_dtl_ref_cd": [
              {
                "ref_id": 3741,
                "ref_desc": "Home",
                "ref_dspl": "Home"
              }
            ]
          }
        ]
      },
      {
        "inac_ind": 0,
        "proc_cd": null,
        "proc_cd_schm_ref_id": 4,
        "proc_othr_txt": " 12-LEAD ELECTROCARDIOGRAM PERFORMED",
        "srvc_hsc_prov_id": null
      }
    ]
    component.prepareProcedureOPDisply(procData);
    expect(component.prepareProcedureOPDisply).toBeDefined();
  });

  it('call function buildModifiersString()', () => {
    const hsc_srvc_non_facls  = {
      proc_mod_1_cd:'U1',
      proc_mod_2_cd:'',
      proc_mod_3_cd:'',
      proc_mod_4_cd:'',
    };
    const hsc_srvc_non_facls2  = {
      proc_mod_1_cd:'',
      proc_mod_2_cd:'U2',
      proc_mod_3_cd:'',
      proc_mod_4_cd:'',
    };
    const hsc_srvc_non_facls3  = {
      proc_mod_1_cd:'',
      proc_mod_2_cd:'',
      proc_mod_3_cd:'U3',
      proc_mod_4_cd:'',
    };
    const hsc_srvc_non_facls4  = {
      proc_mod_1_cd:'',
      proc_mod_2_cd:'',
      proc_mod_3_cd:'',
      proc_mod_4_cd:'U4',
    };
    component.buildModifiersString(hsc_srvc_non_facls);
    component.buildModifiersString(hsc_srvc_non_facls2);
    component.buildModifiersString(hsc_srvc_non_facls3);
    component.buildModifiersString(hsc_srvc_non_facls4);
    expect(component.buildModifiersString).toBeTruthy();
  });

  it('call function getOPCaseTypeAndProcedureData()', () => {
     const procData  = [
        {
          inac_ind: 0,
          proc_cd: '80346',
          proc_cd_schm_ref_id: 2,
          proc_othr_txt: ' DRUG SCREENING BENZODIAZEPINES 1-12',
          srvc_hsc_prov_id: null,
          hsc_srvc_non_facls: [
            {
              "plsrv_ref_id": 3741,
              "plsrv_ref_cd": [
                {
                  "ref_id": 3741,
                  "ref_desc": "Home",
                  "ref_dspl": "Home"
                }
              ],
              "proc_uom_ref_cd": [
                {
                  "ref_id": 3741,
                  "ref_desc": "Home",
                  "ref_dspl": "Home"
                }
              ],
              "proc_freq_ref_cd": [
                {
                  "ref_id": 3741,
                  "ref_desc": "Home",
                  "ref_dspl": "Home"
                }
              ],
              "srvc_dtl_ref_cd": [
                {
                  "ref_id": 3741,
                  "ref_desc": "Home",
                  "ref_dspl": "Home"
                }
              ]
            }
          ]
        },
        {
          "inac_ind": 0,
          "proc_cd": null,
          "proc_cd_schm_ref_id": 4,
          "proc_othr_txt": " 12-LEAD ELECTROCARDIOGRAM PERFORMED",
          "srvc_hsc_prov_id": null

        }
      ]

    const opCaseTypeData = {code: '1255', description: 'radioolgy ECG'};
    component.opCaseTypeData = opCaseTypeData;
    component.buildOPCaseTypeAndProcedureData(procData);
    expect(component.buildOPCaseTypeAndProcedureData).toBeTruthy();
    component.prepareProcedureOPDisply(procData);
    expect(component.prepareProcedureOPDisply).toBeTruthy();
  });
});
