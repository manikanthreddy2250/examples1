import {DatePipe} from '@angular/common';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Component, OnDestroy, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import { ITableInputModel, MessageService } from '@uimf/uitk';
import {Subscription} from 'rxjs';
import { environment } from 'src/environments/environment';
import {ReferenceConstants} from 'src/app/constants/referenceConstants';
import {StepperDataService} from 'src/app/services/StepperDataService/StepperDataService';
import {ReferenceService} from '../../services/refernce-service/reference.service';
import {NotesConfirmationComponent} from './notes-confirmation/notes-confirmation.component';
import { ProcedureConfirmationComponent } from './procedure-confirmation/procedure-confirmation.component';
import {ProviderSearchService} from "../../services/provider-search/provider-search.service";
import {UmintakefuncHscDetailsService} from '../../services/um-intake-functions/umintakefunc-hscDetails.service';
@Component({
  selector: 'um-confirmation',
  templateUrl: './confirmation.component.html',
  styleUrls: ['./confirmation.component.scss']
})
export class ConfirmationComponent implements OnInit, OnDestroy {
  constructor(private readonly httpClient: HttpClient,
              private readonly messageService: MessageService,
              private readonly activatedRoute: ActivatedRoute,
              private readonly router: Router,
              public stepperDataService: StepperDataService,
              private readonly  providerSearchService: ProviderSearchService,
              public readonly referenceService: ReferenceService,
              readonly umintakefuncHscDetailsService: UmintakefuncHscDetailsService
              ) {}
  httpHeaders = new HttpHeaders({
    'Content-Type': 'application/json',
    'Accept': 'application/json'
  });
  hscObj;
  opCaseTypeData: any;
  procedureOPList = [];
  ipOpfCaseTypeData: any;
  referenceNumber: any;
  stepperData: any;
  public IP = ReferenceConstants.SERVICESETTINGTYPE_INPATIENT;
  public OP = ReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT;
  public OPF = ReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY;
  servicingProviderName='';
  servicingProviderDetail :any;
  hscProviderDetail :any;
  tkExpandableRowEnable;
  procedureExpandableRecords = [];
  notesExpandableRecords = [];
  expandedRowData: any = 'code';
  notesexpandedRowData: any = 'dateTime';
  public tkRowComponent = ProcedureConfirmationComponent;
  public tkRowNotesComponent = NotesConfirmationComponent;
  procedureExpandableTable: ITableInputModel = {
    title: 'Procedure Expandable Results Table',
    enableSorting: true
  };
  diagnosisResultsTable = {
    title: 'Diagnosis Search Results Table',
    enableSorting: true
  };
  notesResultsTable = {
      title: 'Notes Results Table',
      enableSorting: true
      };
  fileUploadResultsTable = {
    title: 'FileUpload Results Table',
    enableSorting: true
  };
  procedureResultsTable = {
    title: 'Procedure Results Table',
    enableSorting: true
  };
  diagnosisColumns: any = [
    { label: 'Code', id: 'diag_cd', dataType: 'text', style: { width: '150px' } },
    { label: 'Description', id: 'diag_desc', dataType: 'text' }
  ];
  procedureColumns: any = [
    { label: 'Code', id: 'proc_cd', dataType: 'text', style: { width: '150px' } },
    { label: 'Description', id: 'description', dataType: 'text' }
  ];
  diagnosisRecords = [];

  procedureExpandableColumns: any = [
    { label: 'Code', id: 'code', dataType: 'text', style: { width: '150px' } },
    { label: 'Description', id: 'description', dataType: 'text' },
    { label: 'Servicing Provider', id: 'servicingProvider', dataType: 'text' }
  ];
  notesColumns: any = [
            { label: 'Date/Time', id: 'dateTime', dataType: 'text', style: { width: '15px' } },
            { label: 'Subject', id: 'subject', dataType: 'text', style: { width: '200px' } },
            { label: 'Role', id: 'role', dataType: 'text', style: { width: '20px' } },
            { label: 'Author', id: 'author', dataType: 'text', style: { width: '10px' } }
          ];

  fileUploadColumns: any = [
    { label: 'Date/Time', id: 'dateTimeFormat', dataType: 'text', style: { width: '150px' } },
    { label: 'File Name', id: 'filename', dataType: 'text', style: { width: '400x' }},
    { label: 'Size', id: 'sizeFormat', dataType: 'text'}
  ];
  uploadedDocuments = [];
  stepperDataSubscription: Subscription;

  ngOnInit() {
    this.stepperDataSubscription = this.stepperDataService.sharedStepperData.subscribe((stepperData) => this.stepperData = stepperData);
    this.loadData();
  }
  ngOnDestroy() {
    this.stepperDataSubscription.unsubscribe();
  }

  redirectToMemberSearch() {
    this.router.navigateByUrl('/um/auth/initiate');
  }

  loadData() {
     const body = {
      hsc: {
        hsc_id: parseInt(this.stepperData.hscId)
      }
    };
     this.umintakefuncHscDetailsService.getHscAuthDetails(body).subscribe((data: any) => {
         this.hscObj = data.data.getHscAuthDetails.hsc[0];
         this.populateCaseInformation();
         const hscKey = this.hscObj.hsc_keys.find((obj) => obj.hsc_key_typ_ref_id === ReferenceConstants.HSC_KEY_TYPE_REF_ID_SRN);
         this.referenceNumber = hscKey ? hscKey.hsc_key_val : null;
      });

  }

  async populateCaseInformation() {
    if (this.hscObj.srvc_set_ref_id === ReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT) {
      this.buildOPCaseTypeAndProcedureData(this.hscObj.hsc_srvcs);
    } else {
      this.buildIPOPFProcedureData(this.hscObj.hsc_srvcs);
    }

    this.prepareNotesDisply(this.hscObj.hsr_notes);
    this.prepareDaignosisDisply(this.hscObj.hsc_diags);
    if (this.hscObj.hsc_facls && this.hscObj.hsc_facls.length > 0) {
      this.ipOpfCaseTypeData = this.hscObj.hsc_facls[0];
    }
    this.buildAttachmentsData();
  }
  buildAttachmentsData() {
    this.hscObj.hsr_doc_procs.forEach((element) => {
      const item: any = {};
      const d = element.creat_dttm;
      const str = d.toString().substring(0, 24);
      const pipe = new DatePipe('en-US');
      const dateTimeFormat = pipe.transform(
        d, 'short', 'UTC');
      item.description = element.doc_desc;
      item.datetimeAdded = str;
      item.status = 'Uploaded';
      item.doc_key_val = element.doc_key_val;
      item.showNotes = false;
      item.sizeFormat = this.formatBytes(element.doc_proc_sts_desc.attachments[0].fileSize, 0);
      item.dateTimeFormat = dateTimeFormat;
      item.filename = element.doc_proc_sts_desc.attachments[0].fileName;
      item.uploadedBy = element.creat_user_id;
      item.uploadedDate = element.creat_dttm;
      this.uploadedDocuments.push(item);
    });
    this.uploadedDocuments.sort((a, b) => new Date(b.dateTimeFormat).getTime() - new Date(a.dateTimeFormat).getTime());
  }
  buildOPCaseTypeAndProcedureData(hscsrvcs) {
    hscsrvcs.forEach((item) => {
        if (item.proc_cd !== null && item.hsc_srvc_non_facls.length > 0) {
          this.procedureOPList.push(item);
        }
        if (item.proc_cd === null) {
          this.opCaseTypeData = item;
        }
      });
    if (this.procedureOPList.length > 0) {
      this.prepareProcedureOPDisply(this.procedureOPList);
    }
  }

  async prepareProcedureOPDisply(procedureList) {
    for (const i in  procedureList) {
        if (procedureList[i].hsc_srvc_non_facls.length > 0) {
          await this.getServicingProviderDetail(procedureList[i].srvc_hsc_prov_id);
          this.getServicingProviderName(this.servicingProviderDetail);
          const hscSrvcNonFacl = procedureList[i].hsc_srvc_non_facls[0];
          const hscSrvcNonFaclDme = hscSrvcNonFacl.hsc_srvc_non_facl_dmes.length > 0 ? hscSrvcNonFacl.hsc_srvc_non_facl_dmes[0] : null;
          const expandableprocObject = {
            procedureType: procedureList[i].proc_cd_schm_ref_id,
            code: procedureList[i].proc_cd,
            description: procedureList[i].proc_desc,
            servicingProvider : this.servicingProviderName,
            address : this.servicingProviderDetail.addressLine ,
            networkStatus : '',
            specialty :  this.servicingProviderDetail.specialty,
            providerTin :  this.servicingProviderDetail.providerTin,
            phone :this.servicingProviderDetail.phone,
            premiumDesignation : '',
            serviceDetail: hscSrvcNonFacl.srvc_dtl_ref_cd.ref_dspl,
            total: hscSrvcNonFacl.unit_per_freq_cnt,
            measure: hscSrvcNonFacl.proc_uom_ref_cd.ref_dspl,
            count: hscSrvcNonFacl.proc_unit_cnt,
            frequency: hscSrvcNonFacl.proc_freq_ref_cd.ref_dspl,
            startDate: hscSrvcNonFacl.srvc_strt_dt,
            endDate: hscSrvcNonFacl.srvc_end_dt,
            procedureModifiers: this.buildModifiersString(hscSrvcNonFacl),
            dmeType: hscSrvcNonFaclDme?.dme_procrmnt_typ_id ? hscSrvcNonFaclDme.dme_procrmnt_typ_id === 1 ? 'Purchase' : 'Rental' : null,
            dmeCost: hscSrvcNonFaclDme?.dme_tot_cst_amt,
            dmeClinicalDesc: hscSrvcNonFaclDme?.clin_ill_desc_txt,
            dmeItemDesc: hscSrvcNonFaclDme?.spl_desc_txt,
            dmeOtherDesc: procedureList[i].proc_othr_txt,
            dmeServicesDesc: hscSrvcNonFaclDme?.srvc_desc_txt
          };
          this.tkExpandableRowEnable = true;
          this.procedureExpandableRecords.push(expandableprocObject);
        } else {
          const procedureObject = {
            procedureType: procedureList[i].proc_cd_schm_ref_id,
            code: procedureList[i].proc_cd,
            description: procedureList[i].proc_desc
          };
          this.procedureExpandableRecords.push(procedureObject);
        }
    }
  }

  buildModifiersString(hscSrvcNonFacl) {
    let modifiersStr = '';
    if (hscSrvcNonFacl.proc_mod_1_cd) {
      modifiersStr = modifiersStr + hscSrvcNonFacl.proc_mod_1_cd;
    }
    if (hscSrvcNonFacl.proc_mod_2_cd) {
      modifiersStr = modifiersStr + ' ' + hscSrvcNonFacl.proc_mod_2_cd;
    }
    if (hscSrvcNonFacl.proc_mod_3_cd) {
      modifiersStr = modifiersStr + ' ' + hscSrvcNonFacl.proc_mod_3_cd;
    }
    if (hscSrvcNonFacl.proc_mod_4_cd) {
      modifiersStr = modifiersStr + ' ' + hscSrvcNonFacl.proc_mod_4_cd;
    }
    return modifiersStr;
  }
getProviderAddressLine(adr_ln_1_txt: string, adr_ln_2_txt: string, cty_nm: string, st_ref_cd: string, zip_cd_txt: string): string {
  let addressLine = '';
  if (adr_ln_1_txt) {
    addressLine = adr_ln_1_txt;
  }
  if (adr_ln_2_txt) {
    addressLine += ', ' + adr_ln_2_txt;
  }
  if (cty_nm) {
    addressLine += ', ' + cty_nm;
  }
  if (st_ref_cd) {
    addressLine += ', ' + st_ref_cd;
  }
  if (zip_cd_txt) {
    addressLine += ', ' + zip_cd_txt;
  }
  return addressLine;

}
getServicingProviderName(servicingProviderDetail){
  const prov_category = servicingProviderDetail.providerCategoryId;
  if (ReferenceConstants.PHYSICIAN_CAT_ID === prov_category) {
    this.servicingProviderName = servicingProviderDetail.lastName;
  } else if (ReferenceConstants.FACILITY_CAT_ID === prov_category) {
    this.servicingProviderName = servicingProviderDetail.businessName;
  }
}

async getServicingProviderDetail(providerId){
  await this.providerSearchService.getHscProviderByProviderId(providerId)
    .toPromise().then(async (res) => {
      const hscProviderDetail= res.data.hsc_prov[0];
      const hscProvId = hscProviderDetail?.prov_loc_affil_dtl?.providerDetails?.prov_id;
      const hscProvAdrId = hscProviderDetail?.prov_loc_affil_dtl?.providerDetails?.prov_adr_id;
      const hscProvtelcomAdrId = hscProviderDetail?.telcom_adr_id;
      const hscProvSpecialtyId = hscProviderDetail?.spcl_ref_id;
      await this.providerSearchService.getProviderDetailsSearch(hscProvId, hscProvAdrId, hscProvtelcomAdrId, hscProvSpecialtyId).toPromise().then(async(resServicingDetail) => {
        const  providerDetails = resServicingDetail.data.v_prov_srch[0];
        await this.providerSearchService.getReferenceCD(providerDetails.st_ref_id).toPromise().then(async(providerStateRes) => {
          const providerState = providerStateRes.data.ref[0].ref_cd;
          await this.providerSearchService.getReferenceCD(providerDetails.spcl_ref_id).toPromise().then(async (specialtydisplRes) => {
            providerDetails.spcl_ref_dspl = specialtydisplRes.data.ref[0].ref_dspl;
            this.mapProviderDetail(providerDetails, providerState)
          });
        });
      });
    });
}
  mapProviderDetail(providerDetails, providerState){
  const  providerTin = providerDetails.prov_key_val;
  const addressLine = this.getProviderAddressLine(providerDetails.adr_ln_1_txt, providerDetails.adr_ln_2_txt, providerDetails.cty_nm, providerState, providerDetails.zip_cd_txt);
  this.servicingProviderDetail= {
    businessName: providerDetails.bus_nm,
    firstName: providerDetails.fst_nm,
    lastName: providerDetails.lst_nm + ', ' + providerDetails.fst_nm,
    addressLine, providerTin,
    prov_id: providerDetails.prov_id,
    phone: providerDetails.telcom_adr_id,
    specialty: providerDetails.spcl_ref_dspl,
    specialtyId: providerDetails.spcl_ref_id,
    locationAffiliationId: providerDetails.prov_loc_affil_id,
    providerCategoryId: providerDetails.prov_catgy_ref_id,
  };
}

  async buildIPOPFProcedureData(procedureList) {
    this.procedureExpandableRecords = [];
    for (const i in  procedureList) {
      await this.getServicingProviderDetail(procedureList[i].srvc_hsc_prov_id);
      this.getServicingProviderName(this.servicingProviderDetail);
      const procedureObject = {
        procedureType: procedureList[i].proc_cd_schm_ref_id,
        code: procedureList[i].proc_cd,
        description: procedureList[i].proc_desc,
        servicingProvider : this.servicingProviderName,
        address : this.servicingProviderDetail.addressLine ,
        networkStatus : '',
        specialty :  this.servicingProviderDetail.specialty,
        providerTin :  this.servicingProviderDetail.providerTin,
        phone :this.servicingProviderDetail.phone,
        premiumDesignation : '',
      };
      this.procedureExpandableRecords.push(procedureObject);
    }
    this.tkExpandableRowEnable = false;
  }

  prepareNotesDisply(notesRecords) {
         this.notesExpandableRecords = [];
         if (notesRecords && notesRecords.length > 0) {
          notesRecords.forEach((element) => {
            const notesObject = {
              dateTime: element.creat_dttm,
              subject: element.note_titl_txt,
              role: element.src_user_nm,
              author: element.creat_user_id,
              note: element.note_txt_lobj,
              expanded: true
            };
            this.notesExpandableRecords.push(notesObject);
          });
        }
      }

  prepareDaignosisDisply(daignosisList) {
        if (((daignosisList) && (daignosisList !== undefined)) && (daignosisList.length > 0)) {
          daignosisList.forEach((element) => {
            const daigObject = {
              diag_cd: element.diag_cd,
              diag_desc: element.diag_desc,
            };
            this.diagnosisRecords.push(daigObject);
          });
        }
      }

  onExpand(event) {
    console.log(event);
  }

  /**
   * format bytes
   * @param bytes (File size in bytes)
   * @param decimals (Decimals point)
   */
  formatBytes(bytes, decimals) {
    if (bytes === 0) {
      return '0 Bytes';
    }
    const k = 1024;
    const dm = decimals <= 0 ? 0 : decimals || 2;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    const term = parseFloat((bytes / Math.pow(k, i)).toFixed(dm));
    return `${term} ${sizes[i]}`;
  }

}
