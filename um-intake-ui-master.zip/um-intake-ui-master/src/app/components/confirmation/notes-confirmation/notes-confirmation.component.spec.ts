import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NotesConfirmationComponent } from './notes-confirmation.component';

describe('NotesConfirmationComponent', () => {
  let component: NotesConfirmationComponent;
  let fixture: ComponentFixture<NotesConfirmationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NotesConfirmationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NotesConfirmationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
