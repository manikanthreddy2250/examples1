import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'um-notes-confirmation',
  templateUrl: './notes-confirmation.component.html',
  styleUrls: ['./notes-confirmation.component.scss']
})
export class NotesConfirmationComponent implements OnInit {

  public nestedData;
  note
  constructor() { }

  ngOnInit(): void {
  }

  @Input()
  set tkRowInfo(selectedRow: any) {
    this.nestedData = selectedRow;
    this.note = this.nestedData.note;
  }

}
