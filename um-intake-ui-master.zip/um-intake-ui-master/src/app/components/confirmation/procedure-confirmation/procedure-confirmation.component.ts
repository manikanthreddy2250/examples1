import { Component, OnInit, Input } from '@angular/core';
import { ClinicalGuidelinesConfig } from '@ecp/ui-component-library';

@Component({
  selector: 'um-procedure-confirmation',
  templateUrl: './procedure-confirmation.component.html',
  styleUrls: ['./procedure-confirmation.component.scss']
})
export class ProcedureConfirmationComponent implements OnInit {
  constructor() { }

  config : ClinicalGuidelinesConfig = {};

  ngOnInit(): void {
  }
  public nestedData: any;
  @Input()
   set tkRowInfo(val: any) {
       this.nestedData = val;
       this.config = {
          hscId: val.hsc_id
      };
   }
}
