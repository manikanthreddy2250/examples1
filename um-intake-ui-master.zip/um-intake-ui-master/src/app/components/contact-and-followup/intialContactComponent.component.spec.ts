import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import { ReferenceService } from 'src/app/services/refernce-service/reference.service';
import { IntialContactComponent } from './intialContactComponent.component';
import {FormBuilder, FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators,NG_VALUE_ACCESSOR, DefaultValueAccessor, ControlValueAccessor } from "@angular/forms";
import {uitkModules,uitkAngularModules} from "src/app/app.module";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import {CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA,Component} from '@angular/core';

 describe('IntialContactComponent', () => {
  let component: IntialContactComponent;
  let fixture: ComponentFixture<IntialContactComponent>;
  const formBuilder: FormBuilder = new FormBuilder();

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [uitkAngularModules, ReactiveFormsModule, FormsModule,HttpClientTestingModule],
      providers: [ReferenceService ,
        {
        provide: FormBuilder,
        useValue: formBuilder
      }],
      schemas: [CUSTOM_ELEMENTS_SCHEMA,NO_ERRORS_SCHEMA ],
      declarations: [ IntialContactComponent ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IntialContactComponent);
    component = fixture.componentInstance;
    component.flwup_cntc_dtl = {"flwup_cntc_dtl":{"primary_cntct":{"department":"Admitting","email":"john_doe@gmail.com","phone":"555-555-5555","fax":"555-555-5555","creat_dttm":"2020-10-16T12:27:14.998Z","chg_dttm":"2020-10-16T12:52:13.277Z","creat_user_id":"SYSTEM","role":"Facility","name":"gopi"}}};
    const intialContactForm = new FormGroup({
      name: new FormControl("test", Validators.required),
      role: new FormControl("member"),
      department: new FormControl("medical Record"),
      phone: new FormControl("111-111-1111",[ Validators.required,Validators.pattern('[0-9]{3}-[0-9]{3}-[0-9]{4}'),Validators.pattern("^[0-9-]*$")]),
      fax: new FormControl("111-111-1111",[Validators.pattern('[0-9]{3}-[0-9]{3}-[0-9]{4}'),Validators.pattern("^[0-9-]*$")]),
      email: new FormControl("test@optum.com",[Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")]),
    });
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it("should call displaySecondaryContact", () => {
      component.displaySecondaryContact();
      spyOn(component.toggleSecondaryContact, "emit");
  });

  it("should call deleteSecondaryContact", () => {
      component.deleteSecondaryContact();
      spyOn(component.toggleSecondaryContact, "emit");
     // expect(component.toggleSecondaryContact.emit).toHaveBeenCalled();
  });

  it("should call mapContactDraftData", () => {
    let contactInfoData={
      "secondary_cntct": {
        "department": "Medical Records",
          "email": "test@optum.com",
          "phone": "111-222-2222",
          "fax": "111-222-3333",
          "inac_ind": 1,
          "role": "Dentist",
          "name": "test"
      },
      "primary_cntct": {
        "department": "Utilization Review",
          "email": "vivek_srivadstava@optum.com",
          "phone": "111-111-1111",
          "fax": "111-222-2221",
          "creat_dttm": "2020-10-28T07:00:52.957Z",
          "chg_dttm": "2020-10-28T07:30:33.041Z",
          "creat_user_id": "SYSTEM",
          "role": "Nurseline",
          "name": "Vivek srivastava 1212"
      }
    };
    component.mapContactDraftData(contactInfoData);
    expect(component.mapContactDraftData).toBeTruthy();
  });
  it("should call buildContactInfoData", () => {
    let contactInfoData={
      "secondary_cntct": {
        "department": "Medical Records",
        "email": "test@optum.com",
        "phone": "111-222-2222",
        "fax": "111-222-3333",
        "inac_ind": 1,
        "role": "Dentist",
        "name": "test"
      },
      "primary_cntct": {
        "department": "Utilization Review",
        "email": "vivek_srivadstava@optum.com",
        "phone": "111-111-1111",
        "fax": "111-222-2221",
        "creat_dttm": "2020-10-28T07:00:52.957Z",
        "chg_dttm": "2020-10-28T07:30:33.041Z",
        "creat_user_id": "SYSTEM",
        "role": "Nurseline",
        "name": "Vivek srivastava 1212"
      }
    };
    component.buildContactInfoData(contactInfoData);
    component.getDepartmentsListQuery();
    expect(component.buildContactInfoData).toBeTruthy();
  });
  it("should call mapSecondaryContactDraftData", () => {
    let contactInfoData={
      "secondary_cntct": {
        "department": "Medical Records",
        "email": "test@optum.com",
        "phone": "111-222-2222",
        "fax": "111-222-3333",
        "inac_ind": 1,
        "role": "Dentist",
        "name": "test"
      },
      "primary_cntct": {
        "department": "Utilization Review",
        "email": "vivek_srivadstava@optum.com",
        "phone": "111-111-1111",
        "fax": "111-222-2221",
        "creat_dttm": "2020-10-28T07:00:52.957Z",
        "chg_dttm": "2020-10-28T07:30:33.041Z",
        "creat_user_id": "SYSTEM",
        "role": "Nurseline",
        "name": "Vivek srivastava 1212"
      }
    };
    component.mapSecondaryContactDraftData(contactInfoData);
    expect(component.mapSecondaryContactDraftData).toBeTruthy();
  });
  it("should call mapContactDraftData", () => {
    let contactInfoData={
      "secondary_cntct": {
        "department": "Medical Records",
        "email": "test@optum.com",
        "phone": "111-222-2222",
        "fax": "111-222-3333",
        "inac_ind": 1,
        "role": "Dentist",
        "name": "test"
      },
      "primary_cntct": {
        "department": "Utilization Review",
        "email": "vivek_srivadstava@optum.com",
        "phone": "111-111-1111",
        "fax": "111-222-2221",
        "creat_dttm": "2020-10-28T07:00:52.957Z",
        "chg_dttm": "2020-10-28T07:30:33.041Z",
        "creat_user_id": "SYSTEM",
        "role": "Nurseline",
        "name": "Vivek srivastava 1212"
      }
    };
    component.mapContactDraftData(contactInfoData);
    expect(component.mapContactDraftData).toBeTruthy();
  });

   it("should  getDepartmentsListQuery", () => {
     component.getDepartmentsListQuery();
     expect(component.getDepartmentsListQuery).toBeTruthy();
   });

});
