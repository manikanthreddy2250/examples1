import {Component, EventEmitter, Injectable, Input, OnDestroy, OnInit, Output} from '@angular/core';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import {Subscription} from 'rxjs';
import {ReferenceService} from 'src/app/services/refernce-service/reference.service';
import {FlowType} from '../../models/enums/flowType';
import {StepperDataService} from 'src/app/services/StepperDataService/StepperDataService';

@Component({
  selector: 'um-contact',
  templateUrl: './intialContactComponent.component.html',
  styleUrls: ['./intialContactComponent.component.scss']
})

@Injectable({
  providedIn: 'root'
})
export class IntialContactComponent implements OnInit, OnDestroy {
  constructor(public referenceService: ReferenceService,public stepperDataService: StepperDataService) { }
  @Input() showSecondaryContact:boolean;
  @Input() intialContactForm: FormGroup;
  @Input() followContactForm: FormGroup;
  @Output() toggleSecondaryContact = new EventEmitter();
  stepperData: any;
  flwup_cntc_dtl:any;
  public name = '';
  public phone = '';
  public email = '';
  public fax = '';
  public role = [];
  public department = [];
  public followName = '';
  public followPhone= '';
  public followFax= '';
  public followEmail= '';
  public followDepartment = [];
  public followRole = [];
  contactRoleList = [];
  departmentTypeList = [];
  requiredText: string = 'Input is required';
  patternErrorText: string = 'Pattern error';
  regexPattern = '[0-9]{3}-[0-9]{3}-[0-9]{4}';
  defaultRole : any ={};
  defaultFollowRole : any ={};
  defaultDepartment :any ={};
  defaultFollowDepartment :any ={};
  public contactRole ='';
  public contactDept ='';
  public contactFollowRole ='';
  public contactFollowDept ='';
  stepperDataSubscription: Subscription;
  ngOnInit() {
    this.stepperDataSubscription = this.stepperDataService.sharedStepperData.subscribe((stepperData) => {
      this.stepperData = stepperData;
      this.flwup_cntc_dtl = this.stepperData.flwup_cntc_dtl;
    });
    this.buildContactInfoData(this.stepperData.hsc);
  }
  ngOnDestroy() {
    this.stepperDataSubscription.unsubscribe();
  }
  async buildContactInfoData(contactInfoData){
    await this.getRolesListQuery();
    await this.getDepartmentsListQuery();
    if (this.stepperData.flowType === FlowType.EDIT && contactInfoData.flwup_cntc_dtl) {
      this.stepperDataService.setStepperData({...this.stepperData, hscContact :this.flwup_cntc_dtl});
      this.mapContactDraftData(contactInfoData.flwup_cntc_dtl);
    }
    this.intialContactForm = new FormGroup({
      name: new FormControl(this.name, Validators.required),
      role: new FormControl(this.contactRole),
      department: new FormControl(this.contactDept),
      phone: new FormControl(this.phone,[ Validators.required,Validators.pattern(this.regexPattern),Validators.pattern("^[0-9-]*$")]),
      fax: new FormControl(this.fax,[Validators.pattern(this.regexPattern),Validators.pattern("^[0-9-]*$")]),
      email: new FormControl(this.email,[Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")]),
    });
    this.followContactForm = new FormGroup({
      followName: new FormControl(this.followName, Validators.required),
      followRole: new FormControl(this.contactFollowRole),
      followDepartment: new FormControl(this.contactFollowDept),
      followPhone: new FormControl(this.followPhone,[ Validators.required, Validators.pattern(this.regexPattern),Validators.pattern("^[0-9-]*$")]),
      followFax: new FormControl(this.followFax,[Validators.pattern(this.regexPattern),Validators.pattern("^[0-9-]*$")]),
      followEmail: new FormControl(this.followEmail,[Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")]),
    });
  }
  mapContactDraftData(contactInfoData){
    this.name=contactInfoData.primary_cntct.name != null ? contactInfoData.primary_cntct.name : null;
    this.defaultRole=contactInfoData.primary_cntct.role !==null ? contactInfoData.primary_cntct.role : '';
    this.contactRole=this.contactRoleList.find((role) => role.value === this.defaultRole);
    this.defaultDepartment=contactInfoData.primary_cntct.department !==null ? contactInfoData.primary_cntct.department : "";
    this.contactDept=this.departmentTypeList.find((dept) => dept.value === this.defaultDepartment);
    this.phone=contactInfoData.primary_cntct.phone !==null ? contactInfoData.primary_cntct.phone :null;
    this.fax=contactInfoData.primary_cntct.fax !==null ? contactInfoData.primary_cntct.fax :null;
    this.email=contactInfoData.primary_cntct.email !==null ? contactInfoData.primary_cntct.email :null ;
    if(contactInfoData.secondary_cntct!== undefined && contactInfoData.secondary_cntct !== null ){
      this.mapSecondaryContactDraftData(contactInfoData)
    }
  }
  mapSecondaryContactDraftData(contactInfoData){
    this.showSecondaryContact=true;
    this.followName=contactInfoData.secondary_cntct.name != null ? contactInfoData.secondary_cntct.name : null;
    this.defaultFollowRole=contactInfoData.primary_cntct.role !==null ? contactInfoData.secondary_cntct.role : '';
    this.contactFollowRole=this.contactRoleList.find((followrole) => followrole.value === this.defaultFollowRole);
    this.defaultFollowDepartment=contactInfoData.secondary_cntct.department !==null ? contactInfoData.secondary_cntct.department : "";
    this.contactFollowDept=this.departmentTypeList.find((followdept) => followdept.value === this.defaultFollowDepartment)
    this.followPhone=contactInfoData.secondary_cntct.phone !==null ? contactInfoData.secondary_cntct.phone :null;
    this.followFax=contactInfoData.secondary_cntct.fax !==null ? contactInfoData.secondary_cntct.fax :null;
    this.followEmail=contactInfoData.secondary_cntct.email !==null ? contactInfoData.secondary_cntct.email :null ;
  }


  displaySecondaryContact(){
      this.toggleSecondaryContact.emit();
   }

   deleteSecondaryContact(){
       this.toggleSecondaryContact.emit();
   }

   async getRolesListQuery(){
          const contactRoleBaseRefName = 'contactRoleType';
         await this.referenceService.loadRefSetDisplayData(contactRoleBaseRefName).toPromise().then((res) => {
              res.data.ref_set.forEach((item) => {
                  const contactRoleObj = {
                      id: item.ref.ref_id,
                      label: item.ref.ref_dspl,
                      value: item.ref.ref_desc
                  };
                    this.contactRoleList.push(contactRoleObj);
              });
         }).catch((error) => { });
   }

  async  getDepartmentsListQuery(){
       const departmentTypeBaseRefName = 'departmentType';
       await this.referenceService.loadBaseRefNameDisplayData(departmentTypeBaseRefName).toPromise().then((res) => {
            res.data.ref.forEach((item: { ref_id: number; ref_dspl: string; ref_desc: string; }) => {
                const departmentTypeObj = {
                      id: item.ref_id,
                      label: item.ref_dspl,
                      value: item.ref_desc
                };
                this.departmentTypeList.push(departmentTypeObj);
            });

       }).catch((error) => { });
   }
}
