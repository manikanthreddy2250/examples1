import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA, ElementRef } from '@angular/core';
import { DiagnosisSearchComponent } from './diagnosis-search.component';
import { DiagnosisSearchServiceService as DiagnosisSearchService } from 'src/app/services/diagnosis-search-service/diagnosis-search-service.service';
import { uitkModules } from 'src/app/app.module';
import { FormsModule, FormGroup, FormBuilder, Validators, FormControl,ReactiveFormsModule } from '@angular/forms';
import { Observable } from 'rxjs';
import { Subject } from 'rxjs/Subject';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe("DiagnosisSearchComponent", () => {
    let component: DiagnosisSearchComponent;
    let service: DiagnosisSearchService;
    let fixture: ComponentFixture<DiagnosisSearchComponent>;

    beforeEach(async(() => {
      TestBed.configureTestingModule({
       imports: [uitkModules, FormsModule, ReactiveFormsModule],
        providers: [HttpClientTestingModule, HttpClient, HttpHandler,DiagnosisSearchService, Subject],
        declarations: [DiagnosisSearchComponent],
        schemas: [NO_ERRORS_SCHEMA]
      }).compileComponents();
    }));

    beforeEach(inject([FormBuilder], (fb: FormBuilder) => {
      fixture = TestBed.createComponent(DiagnosisSearchComponent);
      component = fixture.componentInstance;
      component.searchGroup = fb.group({
        name: ["Other Name", Validators.required],
        diagnosisCode: ["123"]
      });

      fixture.detectChanges();
    }));

    it("should create", () => {
      expect(component).toBeTruthy();
    });

    it("should call onSelect and change the searchterm value", () => {
      component.onSelect("test");
      expect(component.searchTerm$).toBeDefined();
    });

    it('parseResults should parse code and concatenate code and description',() => {
      let result = {diagCode: 'S56_22', diagDesc: 'test description'};
      let expected = 'S56.22 test description';
      expect(component.parseResults(result)).toEqual(expected);
    });

    it("should call onSelect and change the searchterm value", () => {
      component.onSelect("test");
      expect(component.searchTerm$).toBeDefined();
    });

    it("should tell me a number is a number", () => {
      expect(component.isNumber(3)).toBe(true);
    });

    it("should create a search result which is just the input with *s between", () => {
      expect(component.createSearchTerm("test", "*")).toEqual("t* e* s* t* ");
    });


    it("isSelectingNewDescription is called with an undefiend input", () => {
      const description = undefined;
      const returnValue = component.isSelectingNewDescription(description);
      expect(returnValue).toEqual(undefined);
    });

    it("isSelectingNewDescription is called with an input that has the code", () => {
      const description = "A1234 Test diagnosis Code";
      component.code = "A1234";
      const returnValue = component.isSelectingNewDescription(description);
      expect(returnValue).toEqual(true);
    });

    it("isSelectingNewDescription is called with an input that has valid code", () => {
      const description = "A1234 Test diagnosis Code";
      component.code = "A12345";
      const returnValue = component.isSelectingNewDescription(description);
      expect(returnValue).toEqual(false);
    });


    it("create search term - add a wildcard to a number", () => {
      const terms = [2];
      const returnValues = component.createSearchTerm(terms, "");
      expect(returnValues).toEqual("2* ");
    });

    it("should built a string when given an array of words", () => {
      const terms = ["test", "output"];
      const returnValues = component.constructDescription(terms);
      expect(returnValues).toEqual(" test output");
    });

    it("should return if event is undefined", () => {
      const event = undefined;
      //component.getSelectedValue(event);
     expect(component.code).toEqual("");
    });

    it("clear the content of the input - selecting new diagnosis", () => {
      const hostElement = fixture.nativeElement;
      const diagnosisInput: HTMLInputElement = hostElement.querySelector("input");
      diagnosisInput.value = "A1234 diagnosis Code";
      component.clearCount = 1;
      component.code = "A1234";
      component.selectFirstResult = true;
      spyOn(component, "constructDescription");
      component.clearContent(diagnosisInput);
      expect(component.constructDescription).toHaveBeenCalled();
    });

    it("clear the content of the input - is clearing the value", () => {
      component.searchGroup = new FormGroup({
        code: new FormControl(),
        diagnosisCode: new FormControl()
      });
      component.searchGroup.get("code").setValue("test");
      component.searchGroup.get("diagnosisCode").setValue("test");
      const hostElement = fixture.nativeElement;
      const diagnosisInput: HTMLInputElement = hostElement.querySelector("input");
      diagnosisInput.value = "A1234 diagnosis Code";
      component.clearCount = 1;
      component.code = "A1234";
      spyOn(component, "updateParent");
      component.clearContent(diagnosisInput);
      expect(component.updateParent).toHaveBeenCalled();
      expect(component.input).toEqual("");
      expect(component.code).toEqual("");
      expect(component.clearCount).toEqual(0);

    });

    it("clear the content of the input - the input is empty so clear the value", () => {
      component.searchComponent.value = 'test';
      component.clearCount = 2;
      const hostElement = fixture.nativeElement;
      const diagnosisInput: HTMLInputElement = hostElement.querySelector("input");
      diagnosisInput.value = '';
      component.clearContent(diagnosisInput);
      expect(component.searchComponent.value).toEqual('');

    });

    it("clear the content of the input - the input is not empty so update the count", () => {
      component.searchComponent.value = 'test';
      component.clearCount = 2;
      const hostElement = fixture.nativeElement;
      const diagnosisInput: HTMLInputElement = hostElement.querySelector("input");
      diagnosisInput.value = 'test';
      component.clearContent(diagnosisInput);
      expect(component.searchComponent.value).toEqual('test');
      expect(component.clearCount).toEqual(3);

    });

  	it("should add one additional Search Component", () => {
	     const searchComponentGroup = new FormGroup({
                code: new FormControl(),
             diagnosisCode: new FormControl("")
              });
       spyOn(component, "addRow");
       component.onSelect("test");
       expect(component.addRow).toBeDefined();
    });

    it("should call updateDisplay", () => {
      component.updateResultDisplay([
         { test: "test1", diagCode: "111", diagDesc: "desc" },
         { test: "test2", diagCode: "123", diagDesc: "desc" }
       ]);
      expect(component.results).toBeDefined();
      //expect(component.results).toEqual([{ name: "111 desc" }, { name: "123 desc" }]);
    });

    it("should call updateAndAddFocus", () => {
      component.updateResultDisplay([
              { test: "test1", diagCode: "111", diagDesc: "desc" },
              { test: "test2", diagCode: "123", diagDesc: "desc" }
            ]);
      expect(component.results).toBeDefined();
      // expect(component.results).toEqual([{ name: "111 desc" }, { name: "123 desc" }]);
      spyOn(component, "updateAndAddFocus");
      component.updateAndAddFocus('123','12');
      expect(component.updateAndAddFocus).toBeDefined();
    });

    it("should return if selectFirstResult is false", () => {
      component.selectFirstResult = false;
      component.focusFirst(component.selectFirstResult);
      expect(component.code).toEqual("");
      component.searchComponent.value !== ""
    });

    it("arrow down diagnosis search", () => {
      component.arrowDown();
	    component.arrowKeyTouched = true;
      component.selectFirstResult = true;
      component.searchComponent.value = 'test';
      expect(component.selectFirstResult).toBe(true);
      expect(component.arrowKeyTouched).toBe(true);
    });

    it("auto select diagnosis", () => {
      component.searchComponent.value = 'K10 test desc';
      component.clearCount = 2;
      const hostElement = fixture.nativeElement;
      const diagnosisInput: HTMLInputElement = hostElement.querySelector("input");
      component.tabFocus(diagnosisInput);
	  expect(component.searchComponent.value).toEqual("K10 test desc");
      expect(component.selectedCodeFlag).toBe(false);
    });

    it('tabFocus Case1', () => {
      const event = {
        target: {
          innerText : 'Abcd123'
        }
      };
      component.tabFocus(event);
      expect(component.selectedCodeFlag).toBe(false);
    });

    it('tabFocus Case3', () => {
      component.selectedCodeFlag = false;
      component.selectFirstResult = true;
	  component.arrowKeyTouched = true;
	   const event = {
			target: {
				innerText : 'Abcd123'
			}
	   };

	  component.searchGroup = new FormGroup({
      code: new FormControl(),
            diagnosisCode: new FormControl()
      });
      component.searchGroup.get("code").setValue("Abcd123");
      component.searchGroup.get("diagnosisCode").setValue("Abcd123");
      const hostElement = fixture.nativeElement;
      const diagnosisInput: HTMLInputElement = hostElement.querySelector("input");
      diagnosisInput.value = "A1234 diagnosis Code";
      component.code = "A1234";
      spyOn(component, "updateParent");
      component.tabFocus(event);
      expect(component.updateParent).toHaveBeenCalled();
      expect(component.arrowKeyTouched).toBe(false);
    });

    it('focusFirst Case1', () => {
      const event = {
        target: {
          innerText : 'Abcd123'
        }
      };
      component.focusFirst(event);
      expect(component.selectedCodeFlag).toBe(false);
    });

    it("should return from an empty search element", () => {
        component.tkSearchVal('undefined');
         expect(component.tkSearchVal).toBeTruthy();
    });

    it("should show clear icon", () => {
         component.showClearIcon();
         expect(component.showClearIcon).toBeTruthy();
    });

    it("should update parent", () => {
        component.searchGroup = new FormGroup({
                code: new FormControl(),
                diagnosisCode: new FormControl()
              });
        component.updateParent('code','description');
     	  component.searchGroup.get("code").setValue("code");
        component.searchGroup.get("diagnosisCode").setValue("description");
        expect(component.updateParent).toBeTruthy();
    });

  it('should run #bindDiagCodeAndDesc()', async () => {
 let result=[{
   "cd_desc": "OTHER REACTIVE ARTHROPATHIES KNEE",
   "diag_cd": "M02.86",
   "full_desc": "Other reactive arthropathies, knee",
   "shrt_desc": "OTHER REACTIVE ARTHROPATHIES KNEE"
 }, {
   "cd_desc": "POSTERIOR DISLOCATION PROXIMAL END TIBIA LT KNEE",
   "diag_cd": "S83.125",
   "full_desc": "Posterior dislocation of proximal end of tibia, left knee",
   "shrt_desc": "POST DISLOCATION PROX TIBIA LT KNEE"
 }];
    component.bindDiagCodeAndDesc(result);

  });

});

