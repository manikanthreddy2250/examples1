import { Component, OnInit, Input, Output, EventEmitter, ViewChild, ElementRef} from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { FormGroup, FormControl, FormArray, Validators } from '@angular/forms';
import { diagnosisConstants } from './diagnosis.constants';
//import { DiagnosisSearchServiceService as DiagnosisSearchService } from './diagnosis-search-service/diagnosis-search-service.service';
import { DiagnosisGraphqlService } from "src/app/services/diagnosis-graphql-service/diagnosis-graphql.service";

import { SearchComponent } from '@uimf/uitk';

@Component({
  selector: "um-diagnosis-search",
  templateUrl: "./diagnosis-search.component.html",
  styleUrls: ["./diagnosis-search.component.scss"]
})
export class DiagnosisSearchComponent implements OnInit {
  // This variable is used to communicate the selected value with the parent
    @Output() numberOfResults = new EventEmitter<string>();
      @Output() valueTyped = new EventEmitter();
      @Output() parentCode = new EventEmitter();
   @Output("addSearchComponent") addSearchComponent: EventEmitter<any> = new EventEmitter();
     @Output("addSearchComponentDynamicallyTab") addSearchTab: EventEmitter<any> = new EventEmitter();
    @Input() searchGroup: FormGroup;
    @Input() searchComponentsForm: FormGroup;
   @ViewChild("mySearch", { static: false }) searchComponent: SearchComponent;
    results: any[10];
    tkSearchResult: boolean;
    tkNewSearch: boolean;
   hasNoSearchResult :boolean;
    searchTerm$ = new Subject<string>();
    numberOfMatches = 0;
    currentValue: string;
    icons: any;
   result:any;
    searchBars: any;
    searchLists: any;
    autoFocus: any;
    code = "";
    clearCount = 0;
    selectedCodeFlag = false;
    input = "";
    selectFirstResult = false;
    public resultElement;
    arrowKeyTouched: boolean;

    constructor(private readonly diagnosisGraphqlService: DiagnosisGraphqlService,
                 private elemRef: ElementRef) {}

    ngOnInit() {
      this.icons = document.getElementsByClassName("tk-btn--search");
      this.searchBars = document.getElementsByClassName("tk-input--search");
      this.autoFocus = document.getElementsByClassName("tk-auto-search__list-item");
      this.numberOfMatches = 0;
      this.hasNoSearchResult=false;
      setTimeout(() => { this.setFocus();
          });

    }

      ngAfterViewChecked() {
        this.resultElement = this.elemRef.nativeElement.querySelector("#undefined_opt_0");
      }

      isSelectingNewDescription(diagnosis_description) {
        if (diagnosis_description === undefined) {
          return;
        }
        if (diagnosis_description.includes(this.code)) {
          return true;
        } else {
          return false;
        }
      }

    clearContent(input: HTMLInputElement) {
      if (this.clearCount % 2 === 1) {
        if (this.isSelectingNewDescription(input.value) && this.selectFirstResult === true) {
          this.selectedCodeFlag = true;
          const terms = input.value.split(/[ ,]+/).filter(Boolean);
          const [, ...diagnosis_description] = terms;
          let response;
          if(diagnosis_description.length >0){
           response = this.constructDescription(diagnosis_description);
                  }
          input.value = response;
        } else {
          this.selectedCodeFlag = false;
          this.code = "";
          const code = this.code;
          this.clearCount = 0;
          // this.searchGroup.get("code").setValue(code);
          let response;
          this.currentValue = response;
          this.updateParent(code, response);
        }
      } else {
        if (input.value === "") {
          this.searchComponent.value = "";
        } else {
          this.clearCount += 1;
        }
      }
      this.numberOfResults.emit("0");
    }


  updateParent(code, diagnosis_description) {
    this.searchGroup.get("code").setValue(code);
    this.searchGroup.get("diagnosisCode").setValue(diagnosis_description);
  }

tkSearchVal(val):void {
  this.input = val;
if (this.input.length > 2) {
  this.input = val;
  this.searchComponent.value = val;
  this.results = [];
    this.diagnosisGraphqlService.getDiagnosis(val)
    .subscribe(({ data }) => {
        this.results = data.icd10_search;
        this.bindDiagCodeAndDesc(this.results);
  },
      error => {
        this.result = 'undefined';
      } );
  if(this.result==='undefined'){
    this.hasNoSearchResult=true;
    if(this.hasNoSearchResult){
      this.messageSerachNotfound.visible = true;
    }
  }
}
}

  bindDiagCodeAndDesc(results){
   for (const  t in results) {
     results[t].cd_desc =  results[t].diag_cd + " " +  results[t].cd_desc;
   }
   return results;
}
messageSerachNotfound = {
  id: 'error_msg',
  pageNotificationType: 'error',
  content: 'The system is not available at this time. Please try again later',
  visible: false,
  closeButton: true,
};
 showClearIcon() {
      var i;
      for (i = 0; i < this.icons.length; i++) {
        (<HTMLElement>this.searchBars[i]).style.borderRight = "none";
        (<HTMLElement>this.icons[i]).style.display = "inline";
        (<HTMLElement>this.icons[i]).style.borderLeft = "none";
      }
    }

 /*searchEntries(val) {
  this.results = [];
   this.selectFirstResult = true;
    const terms = val.split(/[ ,]+/).filter(Boolean);
    let searchResult = this.createSearchTerm(terms, "*");
    this.diagnosisSearchService.search(val).subscribe(result => {
     let resultMatches = result[diagnosisConstants.dataCount];
       if (resultMatches !== 0) {
   this.updateAndAddFocus(resultMatches, result);
            } else {
        this.diagnosisSearchService.search(searchResult).subscribe(result => {
          resultMatches = result[diagnosisConstants.dataCount];
          if (resultMatches !== 0) {
          this.updateAndAddFocus(resultMatches, result);
          } else {
          this.selectFirstResult = false;
            searchResult = this.createSearchTerm(terms, "~");
            this.diagnosisSearchService.search(searchResult).subscribe(result => {
              resultMatches = result[diagnosisConstants.dataCount];
              if (resultMatches !== 0) {
              }
              },
              error => {
               this.results = [];
                                  }
                                );
                              }
                            },
                            error => {
                              this.results = [];
                            }
                          );
                        }
                      },
                      error => {
                        this.results = [];
                      }
                    );
                   return Promise.resolve("success");
                  }*/


    isNumber(text) {
      if (isNaN(text)) {
        return false;
      } else {
        return true;
      }
    }

    createSearchTerm(terms, specialCharacter) {
      let searchResult = "";
      for (const t in terms) {
        if (this.isNumber(terms[t])) {
          searchResult += `${terms[t]}* `;
               } else {
                 searchResult += `${terms[t]}${specialCharacter} `;
               }
      }
      return searchResult;
    }

  updateResultDisplay(jsonObject) {
    this.updateNumberOfResults(this.numberOfMatches);
    this.results = [];
    for (const object of jsonObject) {
      const row = { cd_desc: "" };
      row.cd_desc = this.parseResults(object);
      this.results.push(row);
    }
   return Promise.resolve("Success");
  }

   parseResults(result) {
      let resultString = "";
       // convertdiagnosiscodessinceazureindexdoesnotallow'.'inkeysdiagcodesarestoredwith'_'
      const diagCode = result.diagCode.replace('_','.');
      resultString += `${diagCode} ${result.diagDesc}`;
      return resultString;
    }

  onSelect(val) {
    this.searchTerm$.next(val.cd_desc);
  }

 updateCodeDisplay() {
    if (this.numberOfMatches === 1) {
    } else {
      this.parentCode.emit("");
    }
  }
  getSelectedValue(event) {
    if (event === undefined) {
        return;
      } else {
      const terms = event.diag_cd.split(/[ ,]+/).filter(Boolean);
      const terms_code = event.cd_desc.split(/[ ,]+/).filter(Boolean);
      const termsdisplay=terms.concat(terms_code);
      this.code = termsdisplay[0];
      this.parentCode.emit(terms[0]);
      const [, ...diagnosis_description] = terms_code;
      if (this.isSelectingNewDescription(event.cd_desc)) {
        this.selectedCodeFlag = true;
      }
      const response = this.constructDescription(terms_code);
      this.searchComponent.value=response;
      this.currentValue = response;
    const code = this.code;
    this.updateNumberOfResults(0);
      this.updateParent(code, response);
      if(this.searchBars[this.icons.length-1].value === ""){
          }/*else{
          this.addRow();
    }*/
    }
    }

  constructDescription(arrayOfTerms) {
    let result = "";
    for (const term of arrayOfTerms) {
      result += ` ${term}`;
    }
    return result;
  }

  addRow()
    {
        const searchComponentGroup = new FormGroup({
             code: new FormControl(),
          diagnosisCode: new FormControl("")
        });
         (this.searchComponentsForm.get("searchComponentArray") as FormArray).push(searchComponentGroup);
      }

  updateNumberOfResults(numberOfResults) {
    this.numberOfResults.emit(numberOfResults);
       this.updateCodeDisplay();
  }

    setFocus() {
      var i;
              (<HTMLElement>this.searchBars[this.icons.length-1]).focus();

    }

  updateAndAddFocus(resultMatches, result) {
     this.numberOfMatches = resultMatches;
        this.updateResultDisplay(result.value).then(() => {
          setTimeout(() => {
            try {
              this.resultElement.classList.add("focusFirstResult");
            } catch (e) {}
          }, 0);
        });
      }

 focusFirst(event) {
    if (this.selectFirstResult === false) {
      return;
    }
    if (!this.arrowKeyTouched && this.searchComponent.value !== "") {
      const terms = event.diag_cd.split(/[ ,]+/).filter(Boolean);
      const terms_code = event.cd_desc.split(/[ ,]+/).filter(Boolean);
      const termsdisplay=terms.concat(terms_code);
      this.searchComponent.value = this.searchComponent.displayitems.first.nativeElement.innerText;
    } else if (this.arrowKeyTouched) {
      const terms = event.diag_cd.split(/[ ,]+/).filter(Boolean);
      const terms_code = event.cd_desc.split(/[ ,]+/).filter(Boolean);
      const termsdisplay=terms.concat(terms_code);
      this.searchComponent.value = event.target.innerText;
    }

    if (this.searchComponent.displayitems.length > 0) {
      this.addSearchComponent.emit(this.searchComponent.value);
      const terms = this.searchComponent.value.split(/[ ,]+/).filter(Boolean);
      this.code = terms[0];
      let code = this.code;
      this.parentCode.emit(terms[0]);
      const [, ...description] = terms;
      if (this.isSelectingNewDescription(this.searchComponent.value)) {
        this.selectedCodeFlag = true;
      }
      let response;
      if (description.length > 0) {
        response = this.constructDescription(description);
      }
      if (this.input === "") {
        this.searchComponent.value = "";
        response = "";
        code = "";
      } else if (response !== "") {
        this.searchComponent.value = response;
      }
      this.currentValue = response;
      this.updateNumberOfResults(0);
      this.updateParent(code, response);
       if(this.searchBars[this.icons.length-1].value === ""){
                }/*else{
                this.addRow();
          }*/
      this.arrowKeyTouched = false;
    }
  }

 arrowDown() {
    if (this.searchComponent.displayitems.length > 0) {
      this.arrowKeyTouched = true;
      this.selectFirstResult = true;
      this.resultElement.classList.remove("focusFirstResult");
    }
  }

tabFocus(event) {
    if (this.selectedCodeFlag === true || this.selectFirstResult === false) {
      return;
    }
    if (!this.arrowKeyTouched && this.searchComponent.value !== "") {
      this.searchComponent.value = this.searchComponent.displayitems.first.nativeElement.innerText;
    } else {
      this.searchComponent.value = event.target.innerText;
    }
    if (this.searchComponent.displayitems) {
      this.addSearchTab.emit(this.searchComponent.value);
      const terms = this.searchComponent.value.split(/[ ,]+/).filter(Boolean);
      this.code = terms[0];
      let code = this.code;
      this.parentCode.emit(terms[0]);
      const [, ...description] = terms;
      if (this.isSelectingNewDescription(this.searchComponent.value)) {
        this.selectedCodeFlag = true;
      }
      let response;
      if (description.length > 0) {
        response = this.constructDescription(description);
      }
      if (this.input === "") {
        this.searchComponent.value = "";
        response = "";
        code = "";
      } else {
        this.searchComponent.value = response;
      }
      this.currentValue = response;
      this.updateNumberOfResults(0);
      this.updateParent(code, response);
      this.arrowKeyTouched = false;
    }
  }
  }
