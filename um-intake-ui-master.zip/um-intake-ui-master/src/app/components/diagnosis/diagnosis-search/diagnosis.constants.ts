export const diagnosisConstants = {
  dataCount: "@odata.count"
};
