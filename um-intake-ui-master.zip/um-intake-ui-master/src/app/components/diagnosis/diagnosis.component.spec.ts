import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA, ElementRef,QueryList, SimpleChange, ViewChildren,Injectable    } from '@angular/core';
import {Constants} from '../../constants/constants';
import {UserSessionService} from '../../shared/services/user-session/user-session.service';
import { DiagnosisComponent } from './diagnosis.component';
import { uitkModules,uitkAngularModules } from 'src/app/app.module';
import { FormsModule, FormArray,FormGroup, FormBuilder, Validators,ReactiveFormsModule, FormControl } from '@angular/forms';
import {DiagnosisSearchComponent} from "./diagnosis-search/diagnosis-search.component";
import { Subject } from 'rxjs/Subject';
import { HttpClient, HttpHandler } from '@angular/common/http';
import {DiagnosisGraphqlService} from "src/app/services/diagnosis-graphql-service/diagnosis-graphql.service";
import {StepperDataService} from 'src/app/services/StepperDataService/StepperDataService';
import {BehaviorSubject} from "rxjs";
import {UITKTableModule,UITKTableSortDirective,UITKTableDataSource,IUITKColumnState,UITKSortDirection,IUITKTableSortState,UITKTableFeaturesModule} from '@uitk/angular';
import {SysConfigService} from "../../services/sysconfig-service/sys-config.service";

@Injectable()
class MockStepperDataService {
  private stepperData = new BehaviorSubject({tenantId: 'ecpumintakebaseproductbpmgrp',"hsc":{"hsc_id": 7448,"hsc_sts_ref_id" : 19274}});
  sharedStepperData = this.stepperData.asObservable();
  constructor() { }
  setStepperData(stepperData: any) {
    this.stepperData.next(stepperData);
  }
}

@Injectable()
class UserSessionMockService {
  getVarData() {
    const ecpClaims = {"x-ecp-attrs":{ "taxIds": "['256556261','641486019','352115451','344620678']"}};
    return {ecpClaims};
  }
  getUserPermission() {
    return Constants.UM_INTAKE_UI_USER_PERMISSION_CLINICIAN;
  }
  getEcpToken() {
    return 'ecpToken';
  }
  getFunctionalRole() {
    return 'functionalRole';
  }
  getLocalEcpToken() {
    return null;
  }
  getUserName() {
    return 'SYSTEM';
  }
  getUserOrg() {
    return 'ecp';
  }
}

const  mockData = [
              {
       	       diag_code: "M21.37",
               diag_desc: "FOOT DROP ACQUIRED",
              }
            ];
describe("DiagnosisComponent", () => {

  let component: DiagnosisComponent;
    let fixture: ComponentFixture<DiagnosisComponent>;
    let diagnosisSearchComponentComponentFixture: ComponentFixture<DiagnosisSearchComponent>;
     const formBuilder: FormBuilder = new FormBuilder();

    beforeEach(async(() => {
      TestBed.configureTestingModule({
       imports: [uitkModules,uitkAngularModules, FormsModule, ReactiveFormsModule,UITKTableModule,UITKTableFeaturesModule],
        providers: [HttpClient,HttpHandler, Subject, SysConfigService, { provide: StepperDataService, useClass: MockStepperDataService },
          { provide: UserSessionService, useClass: UserSessionMockService },
        {
                  provide: FormBuilder,
                  useValue: formBuilder
                }
        ],
        declarations: [DiagnosisComponent,DiagnosisSearchComponent],
        schemas: [NO_ERRORS_SCHEMA]
      }).compileComponents();
    }));
    beforeEach(() => {
      fixture = TestBed.createComponent(DiagnosisComponent);
      diagnosisSearchComponentComponentFixture = TestBed.createComponent(DiagnosisSearchComponent);
      component = fixture.componentInstance;
      component.hscObj ={"hsc":[{"hsc_id":7448,"auth_end_dt":null,"auth_strt_dt":null,"auth_typ_ref_id":null,"cont_of_care_ind":null,"indv_id":503926748,"mbr_cov_dtl":null,"mbr_cov_id":12484,"rev_prr_ref_id":3754,"srvc_set_ref_id":3738,"hsc_keys":[{"hsc_id":7448,"hsc_key_val":"25a3edda-0e43-11eb-a339-86406bb57ba2","inac_ind":0,"hsc_key_typ_ref_id":19517}],"hsc_diags":[{"diag_cd":"S83.125","inac_ind":0,"hsc_id":7448,"pri_ind":1,"hscDiagDiagCdRef":[{"shrt_desc":"POST DISLOCATION PROX TIBIA LT KNEE","full_desc":"Posterior dislocation of proximal end of tibia, left knee","cd_desc":"POSTERIOR DISLOCATION PROXIMAL END TIBIA LT KNEE"}]},{"diag_cd":"S80.242D","inac_ind":0,"hsc_id":7448,"pri_ind":0,"hscDiagDiagCdRef":[{"shrt_desc":"EXTERNAL CONSTRICTION LT KNEE SBSQT","full_desc":"External constriction, left knee, subsequent encounter","cd_desc":"EXTERNAL CONSTRICTION LT KNEE SUBSEQUENT ENCNTR"}]}],"hsc_provs":[],"hsc_facls":[{"hsc_id":7448,"actul_admis_dttm":"2020-10-11T00:00:00","actul_dschrg_dttm":"2020-10-13T00:00:00","expt_admis_dt":"2020-10-11","expt_dschrg_dt":"2020-10-17","plsrv_ref_id":3743,"srvc_desc_ref_id":4347,"srvc_dtl_ref_id":4296}]}]};
      const diagnosisForm = formBuilder.group({
            searchComponentArray: formBuilder.array([
              formBuilder.group({
                code: [null, Validators.required],
                diagnosisCode: [null, Validators.required]
              })
            ])
       });
       component.dataSource.data = mockData;
      const temp: any = '["ecp","engineer"]';
       spyOn(localStorage, 'getItem').and.callFake((key: string): string => {
         return temp;
       });
       fixture.detectChanges();
    });

    it("should create", () => {
      expect(component).toBeTruthy();
    });

    afterEach(() => {
        fixture.destroy();
    });

    afterAll(() => {
        TestBed.resetTestingModule();
    });

    it("should remove search component", () => {
            component.removeSearchBar(1);
            expect(component.searchComponentsForm.value.searchComponentArray.length).toBe(1);
    });

    it("should add and remove search component", () => {
        		    component.addSearchComponent();
                component.removeSearchBar(1);
                expect(component.searchComponentsForm.value.searchComponentArray.length).toBe(1);
    });

    it("should check set and get code", () => {
            const searchComponentGroup = (component.searchComponentsForm.get("searchComponentArray") as FormArray).at(0);
            component.setCode('123', 0);
            expect(searchComponentGroup.get("code").value).toBe("123");
            component.getCode(0);
            expect(searchComponentGroup.get("code").value).toBe("123");
    });

    it("should check get and set Descrption", () => {
             const searchComponentGroup = (component.searchComponentsForm.get("searchComponentArray") as FormArray).at(0);
             component.setDescrption('123', 0);
             expect(searchComponentGroup.get("diagnosisCode").value).toBe("123");
             component.getDescription(0);
             expect(searchComponentGroup.get("diagnosisCode").value).toBe("123");
    });

    it("should openDeletePopup", () => {
    	const records = [{record: 'record'}]
        component.openDeletePopup(records);
        expect(component.openDeletePopup).toBeTruthy();
    });

    it("should update Parent Results", () => {
            component.updateParentResults('tony',1);
            expect(component.updateParentResults).toBeTruthy();
    });

    it("should has Duplicate", () => {
    		   const records = [{record: '123'}];
    		   let arr = component.records;
    		   const searchComponentGroup = (component.searchComponentsForm.get("searchComponentArray") as FormArray).at(0);
           component.setDescrption('123', 0);
           component.hasDuplicate(arr,'123');
           expect(component.hasDuplicate).toBeTruthy();
    });

    it("should  getDiagnosisRecordToDisplay", () => {
         component.getDiagnosisRecordToDisplay(0);
         expect(component.getDiagnosisRecordToDisplay).toBeTruthy();
     });

    it("should  getDiagnosisRecordToSave", () => {
      component.getDiagnosisRecordToSave(0);
      expect(component.getDiagnosisRecordToSave).toBeTruthy();
    });
  //
  // it("should call updatePriInd", () => {
  //   const recordsToSave=[{"hsc_id" :123,"diag_cd": "DZ.12","inac_ind": 0,"pri_ind": 1 },
  //     {"hsc_id" :123,"diag_cd": "DS.12","inac_ind": 0,"pri_ind": 0 }];
  //   component.updatePriInd(recordsToSave);
  //   let recordExist=false;
  // });

  it("should call duplicateDiagValidationCheck", () => {
    component.duplicateDiagValidationCheck("Abc");
    let duplicateDiagnosisCode="Abc";
    expect(component.dublicateDiagMessage).toBe('Diagnosis code'+' '+ duplicateDiagnosisCode +' ' +'has already been entered. Duplicate diagnosis codes are not allowed');
    expect(component.duplicateDiagValidationCheck).toBeTruthy();
  });


  it('should run #ngOnInit()', async () => {
    component.getDiagnosesLimit();
    component.ngOnInit();
  });


 it("should  buildDisplayDiagnosisData", () => {

    let diagList=[{
      "pri_ind": 1,
      "inac_ind": 1,
      "diag_code": "T34.70",
      "hscDiagDiagCdRef": [{
        "shrt_desc": "POST DISLOCATION PROX TIBIA LT KNEE",
        "full_desc": "Posterior dislocation of proximal end of tibia, left knee",
        "cd_desc": "POSTERIOR DISLOCATION PROXIMAL END TIBIA LT KNEE"
      }]

    }, {
      "pri_ind": 1,
      "inac_ind": 1,
      "diag_code": "S83.125",
      "hscDiagDiagCdRef": [{
        "shrt_desc": "POST DISLOCATION PROX TIBIA LT KNEE",
        "full_desc": "Posterior dislocation of proximal end of tibia, left knee",
        "cd_desc": "POSTERIOR DISLOCATION PROXIMAL END TIBIA LT KNEE"
      }]
    }];
    component.buildDisplayDiagnosisData(diagList);
    expect(component.buildDisplayDiagnosisData).toBeTruthy();
  });

  it("should  buildSavedDiagnosisData", () => {
    let diagList=[{
      "pri_ind": 0,
      "inac_ind": 0,
      "diag_code": "T34.70",
      "diag_desc": "FROSTBITE TISSUE NECROS UNSPEC KNEE & LOW LEG"
    }, {
      "pri_ind": 1,
      "inac_ind": 0,
      "diag_code": "S83.125",
      "diag_desc": "POSTERIOR DISLOCATION PROXIMAL END TIBIA LT KNEE"
    }];
    component.buildSavedDiagnosisData(diagList);
    expect(component.buildSavedDiagnosisData).toBeTruthy();
  });


  it('should run #getDiagnosesLimit()', async () => {
    component.getDiagnosesLimit();
  });

  it('should run #buildDescription()', async () => {
    let diagDescArray=["34","test 1","test2"];
    diagDescArray.splice(1,1);
    expect(component.buildDescription(diagDescArray));
  });
});

