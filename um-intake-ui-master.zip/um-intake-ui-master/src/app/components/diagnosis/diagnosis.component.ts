import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Component, EventEmitter, Input, OnInit, Output, ViewChild, AfterViewInit, OnDestroy} from '@angular/core';
import {FormArray, FormControl, FormGroup, Validators} from '@angular/forms';
import {MessageService} from '@uimf/uitk';
import {Subscription} from 'rxjs';
import {ConfigConstants} from '../../constants/configConstants';
import {FlowType} from '../../models/enums/flowType';
import {ReferenceConstants} from 'src/app/constants/referenceConstants';
import {DiagnosisGraphqlService} from 'src/app/services/diagnosis-graphql-service/diagnosis-graphql.service';
import {StepperDataService} from 'src/app/services/StepperDataService/StepperDataService';
import {UserSessionService} from 'src/app/shared/services/user-session/user-session.service';
import {environment} from 'src/environments/environment';
import {Constants} from 'src/app/constants/constants';
import {UITKTableModule,UITKTableSortDirective,UITKTableDataSource,IUITKColumnState,
        UITKSortDirection,IUITKTableSortState,UITKTableFeaturesModule,} from '@uitk/angular';
import {SysConfigService} from '../../services/sysconfig-service/sys-config.service';
import {UmIntakeFuncGraphqlService} from '../../services/um-intake-functions/umintakefunc-graphql.service';

@Component({
  selector: "um-diagnosis",
  templateUrl: "./diagnosis.component.html",
  styleUrls: ["./diagnosis.component.scss"]
})
export class DiagnosisComponent implements OnInit, AfterViewInit, OnDestroy {
  stepperData: any;
  hscObj:any;
  @Input() searchComponentsForm: FormGroup;
  @ViewChild('sortTable') uitkTableSort: UITKTableSortDirective;
  dataSource = new UITKTableDataSource<any>([]);
  sortDescription='';
  numberOfResults = 0;
  diagnosis:string;
  diagnosisLimit : any;
  recordcounter:number;
  duplicateDiagnosis:boolean;
  diagnosisType:boolean;
  inactiveInd:boolean;
  primaryDiagnosisSelected:boolean;
  numberOfMatches = 0;
  selectedMember:any;
  duplicateDiagnosisCode :string;
  dublicateDiagMessage :string;
  records:{"pri_ind": boolean,"inac_ind":boolean, "diag_code": string, "diag_desc": string}[];
  @Output() saveDiagnosisRecord: EventEmitter<any> = new EventEmitter();
  recordsTosave:{"hsc_id" :any,"diag_cd": string,"inac_ind": number,"pri_ind": number }[];
  filter:any;
  public selectedradio:string;
  selectedValue:any
  public selectRecord;
  HSC_STATUS_TYPE_DRAFT = ReferenceConstants.HSC_STATUS_TYPE_DRAFT;
  HSC_STATUS_TYPE_OPEN = ReferenceConstants.HSC_STATUS_TYPE_OPEN;

  constructor( private readonly httpClient: HttpClient,
               private messageService: MessageService,
               private userSessionService: UserSessionService,
               public stepperDataService: StepperDataService,
               public diagnosisGraphqlService: DiagnosisGraphqlService,
               public readonly umIntakeFuncGraphqlService: UmIntakeFuncGraphqlService,
               private readonly sysConfigService: SysConfigService) {
    this.duplicateDiagnosis = false;
    this.diagnosisType = false;
    this.inactiveInd = false;
    this.primaryDiagnosisSelected = false;
    this.records = [];
    this.recordsTosave = [];
  }
  httpHeaders = new HttpHeaders({
    'Content-Type': 'application/json',
    'Accept': 'application/json'
  });
  stepperDataSubscription: Subscription;

  ngOnInit() {
    this.stepperDataSubscription = this.stepperDataService.sharedStepperData.subscribe((stepperData) => {
      this.stepperData = stepperData;
      this.hscObj = this.stepperData.hsc;
    });
    if(this.stepperData.flowType === FlowType.EDIT && this.hscObj.hsc_diags.length>0){
      this.buildDisplayDiagnosisData(this.hscObj.hsc_diags);
      this.buildSavedDiagnosisData(this.hscObj.hsc_diags);
    }
    this.recordcounter= this.records.length > 0 ? this.records.length :0;
    const searchComponentGroup = new FormGroup({
      code: new FormControl(),
      diagnosisCode: new FormControl("", Validators.required)
    });

    this.searchComponentsForm = new FormGroup({
      searchComponentArray: new FormArray([searchComponentGroup]),
      code: new FormControl(),
      diagnosisCode: new FormControl("", Validators.required)
    });
    this.getDiagnosesLimit();
  }
  ngOnDestroy() {
    this.stepperDataSubscription.unsubscribe();
  }

  ngAfterViewInit() {
           // sets initial sort direction
          // this.uitkTableSort.setDirection({ column: "subject", direction: UITKSortDirection.DESC });
           this.dataSource.sort = this.uitkTableSort;
  }


  onSortChange(sortState: IUITKColumnState) {
            console.log('Sorting Change: ', sortState);
  }

  buildDisplayDiagnosisData(diagList) {
    for (const j in diagList) {
      const record = {
        "pri_ind": diagList[j].pri_ind,
        "inac_ind": diagList[j].inac_ind,
        "diag_code": diagList[j].diag_cd,
        "diag_desc": diagList[j].diag_desc
      }
      this.records.push(record);
    }
    this.dataSource.data = [...this.records];
    this.stepperDataService.setStepperData({...this.stepperData, hscDiagnosis :this.records});
  }
    buildSavedDiagnosisData(diagList) {
      for (const j in diagList) {
        const recordToSave = {
          "hsc_id": this.stepperData.hscId,
          "diag_cd": diagList[j].diag_cd,
          "inac_ind": diagList[j].inac_ind,
          "pri_ind": diagList[j].pri_ind
        }
        this.recordsTosave.push(recordToSave);
      }
    }

  getDiagnosesLimit() {
    this.sysConfigService.getClientConfigByKey(ConfigConstants.DIAGNOSIS_LIMIT_CONFIG_KEY).subscribe((res) => {
      this.diagnosisLimit = res ? res[0].value : null;
    }, (error) => {
      console.log('error');
    });
  }
  removeSearchBar(index) {
    if ((this.searchComponentsForm.get("searchComponentArray") as FormArray).length > 1) {
      (this.searchComponentsForm.get("searchComponentArray") as FormArray).removeAt(index);
    } else {
      this.addSearchComponent();
      (this.searchComponentsForm.get("searchComponentArray") as FormArray).removeAt(index);
    }
  }

  addDiagnosis(index) {
      if (!(this.getCode(index) === "" || this.getCode(index) === '' || this.getCode(index) === null)) {
        if (this.recordcounter >= this.diagnosisLimit) {
          this.messageLimitExceed.visible = true;
          this.setCode('', index);
        } else {
          const record = this.getDiagnosisRecordToDisplay(index);
          // build array to save in db
          const recordTosave = this.getDiagnosisRecordToSave(index);
          this.duplicateDiagnosis = this.hasDuplicate(this.records, record.diag_code);
          if (!this.duplicateDiagnosis) {
            this.records.push(record);
            this.recordsTosave.push(recordTosave);
            this.recordcounter += 1;
            this.primaryDiagnosisSelected = false;
            this.duplicateDiagnosis = false;
            this.setCode('', index);
          }
          else {
            this.duplicateDiagnosisCode = record.diag_code;
            this.duplicateDiagValidationCheck(this.duplicateDiagnosisCode);
            this.duplicateDiagnosis = true;
            this.setCode('', index);
          }
        }
      }else{
        this.duplicateDiagnosis= false;
        this.messageDuplicateDiagnosis.visible=false;
        this.messageLimitExceed.visible=false;
      }
  this.dataSource.data = [...this.records];
  this.stepperDataService.setStepperData({...this.stepperData, hscDiagnosis: this.records});
  this.saveDiagnosis(this.recordsTosave);
    (<HTMLInputElement>document.getElementById("diagnosis")).value = '';
}

  saveDiagnosis(savediagnosis) {
    // to Save diagnosis azure call
    savediagnosis.forEach((data) => {
      data.hsc_id = parseInt(this.stepperData.hscId);
    });
    const saveDiagnosisReq = {
      hsc_diags: savediagnosis
    };
    this.umIntakeFuncGraphqlService.saveDiagnosis(saveDiagnosisReq).subscribe((data: any) => {
        console.log('Saved diagnosis!');
      },
      (error) => {
        if (error) {
          this.showError();
        }
      });
  }

  showError() {
    this.errorAlert.visible = true;
    this.messageService.add(this.errorAlert);
  }
  errorAlert = {
    id: 'error_msg',
    pageNotificationType: 'error',
    content: 'Unable to save Diagnosis.',
    visible: false,
    closeButton: true,
  };


  deleteDiagnosis(diag_code) {
    // to Delete diagnosis nestJs GraphQL call
    const deleteDiagnosisReq = {
        diag_cd: diag_code,
        hsc_id: parseInt(this.stepperData.hscId)
    };
    this.umIntakeFuncGraphqlService.deleteDiagnosis(deleteDiagnosisReq).subscribe((data: any) => {
        console.log('Deleted diagnosis!');
      },
      (error) => {
        if (error) {
          this.showError();
        }
      });
  }

duplicateDiagValidationCheck(duplicateDiagnosisCode){
  this.dublicateDiagMessage='Diagnosis code'+' '+ duplicateDiagnosisCode +' ' +'has already been entered. Duplicate diagnosis codes are not allowed';
  this.messageDuplicateDiagnosis.visible=true;
  this.messageDuplicateDiagnosis.content= this.dublicateDiagMessage;
}
getDiagnosisRecordToDisplay(index){
  const record = {
    "pri_ind": this.diagnosisType,
    "inac_ind": this.inactiveInd,
    "diag_code": this.getCode(index),
    "diag_desc": this.getDescription(index)
  }
  return record;
}

getDiagnosisRecordToSave(index){
  const recordToSave= {
    "hsc_id": Number(this.stepperData.hscId),
    "diag_cd": this.getCode(index),
    "inac_ind" :this.inactiveInd ===true ? 1 : 0,
    "pri_ind": this.diagnosisType===true ? 1: 0
  }
  return recordToSave;
}
  hasDuplicate(array, code) {
    for (const i in array) {
      if (code === array[i].diag_code) {
        return true;
    }
    }
    return false;
  }

  addSearchComponent() {
    const searchComponentArray = this.searchComponentsForm.get("searchComponentArray") as FormArray;
    const searchComponentGroup = new FormGroup({
      code: new FormControl(),
      diagnosisCode: new FormControl("")
    });
    (this.searchComponentsForm.get("searchComponentArray") as FormArray).push(searchComponentGroup);
  }

  updateParentResults(message:any, searchComponentGroupId) {
    this.numberOfResults = message;
  }

  setCode(code, arrayIndex) {
  const searchComponentGroup = (this.searchComponentsForm.get("searchComponentArray") as FormArray).at(arrayIndex);
  searchComponentGroup.get("code").setValue(code);
}

  setDescrption(desc, arrayIndex) {
    const searchComponentGroup = (this.searchComponentsForm.get("searchComponentArray") as FormArray).at(arrayIndex);
    searchComponentGroup.get("diagnosisCode").setValue(desc);
  }

  getCode(index) {
    const searchComponentGroup = (this.searchComponentsForm.get("searchComponentArray") as FormArray).at(index);
    return searchComponentGroup.get("code").value;
  }

  getDescription(index) {
    const searchComponentGroup = (this.searchComponentsForm.get("searchComponentArray") as FormArray).at(index);
    const diagDesc=searchComponentGroup.get("diagnosisCode").value.split(" ");
    diagDesc.splice(1, 1);
    const displayDesc=this.buildDescription(diagDesc)
    return displayDesc;
  }

  buildDescription(diagDescArray) {
    let result = "";
    for (const term of diagDescArray) {
      result += ` ${term}`;
    }
    return result;
  }

  diagnosisResultsTable = {
    title: 'Diagnosis Search Results Table',
    enableSorting: true
  };
  columns:any = [
    {label: 'Code', id: 'diag_code', dataType: 'text'},
    {label: 'Description', id: 'diag_desc', dataType: 'text'},
    {label: 'Action', id: 'action', dataType: 'text', sortable: false, enableFiltering: false},
  ];
  diagnosisColumns: any = [
    { label: 'Code', id: 'diag_code', dataType: 'text', style: { width: '150px' } },
    { label: 'Description', id: 'diag_desc', dataType: 'text' }
  ];

  openDeletePopup(record) {
  let index = -1;
  let diagCodesToRemove="";
  const arr = this.records;
  this.selectRecord = record;
  this.recordcounter -= 1;
  this.primaryDiagnosisSelected = false;
  this.duplicateDiagnosis= false;
  for (let i = 0; i < arr.length; i++) {
    if (arr[i].diag_code === this.selectRecord.diag_code) {
      index = i;
      diagCodesToRemove=arr[i].diag_code;
      break;
    }
  }
  this.records.splice(index, 1);
  this.stepperDataService.setStepperData({...this.stepperData, hscDiagnosis: this.records});
  this.records = [...this.records];
  this.dataSource.data = [...this.records];
  this.recordsTosave = [...this.recordsTosave];
  this.deleteDiagnosis(this.selectRecord.diag_code);
  }

messageLimitExceed = {
  id: 'error_msg',
  messageType: 'error',
  content: 'The number of diagnosis codes entered has reached the maximum limit.',
  visible: false,
  closeButton: true,
};

messageDuplicateDiagnosis = {
  id: 'error_msg',
  messageType: 'error',
  content: "",
  visible: false,
  closeButton: true,
};
}
