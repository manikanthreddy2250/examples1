import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'um-dignosis-code',
  templateUrl: './dignosis-code.component.html',
  styleUrls: ['./dignosis-code.component.scss']
})
export class DignosisCodeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
