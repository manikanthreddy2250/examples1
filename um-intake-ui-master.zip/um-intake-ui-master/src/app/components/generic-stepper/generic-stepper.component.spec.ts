import { DatePipe } from '@angular/common';
import {HttpClient} from '@angular/common/http';
import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';
import {CUSTOM_ELEMENTS_SCHEMA, Injectable, NO_ERRORS_SCHEMA} from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {FormBuilder, FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators} from '@angular/forms';
import {ActivatedRoute, Router, } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import {MicroProductAuthService} from '@ecp/auth-library';
import {Observable, of, throwError} from 'rxjs';
import {IntakeFormComponent} from 'src/app/components/intake-form/intake-form.component';
import {EcpAuthTokenService} from '../../services/ecp-auth-token-service/ecp-auth-token.service';
import {IUserSessionService} from '../../shared/services/user-session/interface-user-session.service';
import {UserSessionService} from '../../shared/services/user-session/user-session.service';
import {AuthorizationTypeComponent} from '../authorization-type/authorization-type.component';
import { GenericStepperComponent } from './generic-stepper.component';

const activatedRouteStub = {
    params: of({id: 22, cov_id: 123, serviceType: 'test', caseId: 321, hscId: 111})
};

const formBuilder = new FormBuilder();

@Injectable()
class UserSessionMockServiceZ implements IUserSessionService {

  constructor() {}

  readonly microProductAuthService: MicroProductAuthService;
  public readonly ecpAuthTokenService: EcpAuthTokenService;

  orgTag = 'x-ecp-cli-orgs';
  APP_NAME_PREFIX = 'um_intake_ui_';
  ECP_TOKEN_KEY = 'ecp_token';
  ACTIVE_ORG_ROLE_KEY = 'active_org_role';
  ACTIVE_ORG_ROLE_VALUE = '["ecp", "engineer"]';
  i = 0;

  getVarData() {
    return null;
  }

  getLocalEcpToken() {
    return null;
  }

  getUserName() {
    if (this.i === 0) {
      this.i++;
      return 'breddy88';
    } else if (this.i === 1) {
      this.i = this.i + 2;
      return 'SYSTEM';
    } else if (this.i === 3)  {
      return 'abcd';
    }
  }
  getUserOrg() {
    return 'ecp';
  }
  getUserPermission() {
    return 'userPermission';
  }

  getEcpToken() {
    return 'ecpToken';
  }
  getFunctionalRole() {
    return 'functionalRole';
  }
}

describe('GenericStepperComponent', () => {
  let component: GenericStepperComponent;
  let fixture: ComponentFixture<GenericStepperComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientTestingModule, FormsModule, ReactiveFormsModule, ],
      declarations: [ GenericStepperComponent],
      providers: [DatePipe, IntakeFormComponent, AuthorizationTypeComponent, HttpClient,
      { provide: ActivatedRoute, useValue: activatedRouteStub }, { provide: UserSessionService, useClass: UserSessionMockServiceZ}],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GenericStepperComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  afterEach(() => {
      fixture.destroy();
  });

  afterAll(() => {
      TestBed.resetTestingModule();
  });

  it('should create', () => {
   expect(component).toBeTruthy();
  });

  it('should call toggleSecondaryContact', () => {
    component.toggleSecondaryContact();
    expect(component.toggleSecondaryContact).toBeTruthy();
  });

  it('currentStepperUpdateEvent() invokes', () => {
    component.updateStep = 1;
    expect(component.updateStep).toBeDefined();
    component.currentStepperUpdateEvent(component.updateStep);
    expect(component.currentStepperUpdateEvent).toBeTruthy();
    // spyOn(component.intakeCurStepperUpdateEvent, 'emit');
    // component.currentStepperUpdateEvent(component.updateStep)
    // expect(component.intakeCurStepperUpdateEvent.emit).toHaveBeenCalledWith(1);
  });
  it('should call notesUpdated', () => {
   const data = {
      hsr_note: [{
        creat_dttm: '5/29/20, 7:07 AM',
        note_txt_lobj: 'simple text', creat_user_id: 'testUser', hsr_note_sbjs: [{ inac_ind: 0 }]
      }]
    };
   component.notesUpdated(data);
   expect(component.notesUpdated).toBeTruthy();
});

it('should call #ngOnInit()', async () => {
  component.ngOnInit();
  expect(component.documentConfig).toBeDefined();
});

});
