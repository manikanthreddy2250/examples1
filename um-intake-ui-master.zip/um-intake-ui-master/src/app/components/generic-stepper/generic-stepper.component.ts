import { Component, Input, OnInit, ViewChild, Output, EventEmitter } from '@angular/core';
import { IntakeFormComponent } from 'src/app/components/intake-form/intake-form.component';
import { AuthorizationTypeComponent } from "../authorization-type/authorization-type.component";
import { IntialContactComponent } from "../contact-and-followup/intialContactComponent.component";
import { DatePipe } from '@angular/common';
import { ClinicalInformationComponent } from "src/app/components/clinical-information/clinical-information.component";
import { NotesComponent } from '../notes/notes.component';
import {DocProcessConfig, UMAnticipatedServiceComponent} from '@ecp/ui-component-library';
import { ReferenceConstants } from './../../constants/referenceConstants';
import { Constants } from './../../constants/constants';
import { UserSessionService } from 'src/app/shared/services/user-session/user-session.service';

@Component({
  selector: 'um-generic-stepper',
  templateUrl: './generic-stepper.component.html',
  styleUrls: ['./generic-stepper.component.scss']
})
export class GenericStepperComponent implements OnInit {
  private bpmFunctionalRole: string = '';
  private clientOrganizationId: string = '';
  @Input() stepNumber: number;
  notesData;
  public stepperIds = this.intakeFormComponent.stepperIds;
  public intakeForm = this.intakeFormComponent.intakeForm;
  public selectedMember = this.intakeFormComponent.selectedMember;
  public hscId = this.intakeFormComponent.hscId;
  public showSecondaryContact = false;
  documentConfig: DocProcessConfig;
  @Input() procDetailData;
  @Input() stepperData: any;
  updateStep
  @ViewChild('authType', { static: false }) authorizationTypeComponent: AuthorizationTypeComponent;
  @ViewChild('intial', { static: false }) intialContactComponent: IntialContactComponent;
  @ViewChild('files', {static: false}) clinicalInformationComponent : ClinicalInformationComponent;
  @ViewChild('notes', {static: false}) notesComponent : NotesComponent;
  @ViewChild('anticipatedServiceCmp', {static: false}) public anticipatedServiceComponent: UMAnticipatedServiceComponent;

  @Output() intakeCurStepperUpdateEvent = new EventEmitter<number>();
  
  constructor(public datepipe: DatePipe, private intakeFormComponent: IntakeFormComponent, private userSessionService: UserSessionService) {
    this.bpmFunctionalRole = userSessionService.getFunctionalRole();
    this.clientOrganizationId = userSessionService.getUserOrg();
  }

  ngOnInit() {
    this.documentConfig = {
     subjectId: this.hscId,
     subjecTypeId : ReferenceConstants.DOC_PROCESS_SUBJECT_TYPE_HSC_ID_REF_ID,
     configAppName: Constants.UM_INTAKE_UI_APP_NAME
    };
  }

  public getLabel(id) {
    return this.intakeFormComponent.stepperLabels.find((label) => label.id === id);
  }

  toggleSecondaryContact() {
    this.showSecondaryContact = !this.showSecondaryContact;
  }
  
  currentStepperUpdateEvent($event) {
    this.updateStep = $event
    this.intakeCurStepperUpdateEvent.emit(this.updateStep)
  }

  notesUpdated = (data) => {
    this.notesData = data;
  }
}
