import {Component, Input, OnChanges, OnInit, Inject} from '@angular/core';
import {DomSanitizer, SafeResourceUrl} from '@angular/platform-browser';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {Location} from '@angular/common';
import * as xml2js from 'xml2js';
import {InterQualReviewRequest, InterQualReviewSaveResponse} from 'src/app/services/interqual/interqual.model';
import {GlobalConstants} from "@ecp/gql-tk-beta";
import { PriorAuthorizationService } from 'src/app/services/prior-authorization-service/prior-authorization.service';
import { DpocConstants } from 'src/app/constants/dpocConstants';

declare var InterQualOnline: any;

@Component({
  selector: 'um-interrqual',
  templateUrl: './interqual.component.html',
  styleUrls: ['./interqual.component.scss']
})

export class InterqualComponent implements OnInit {
  public priorAuthSSOData: any;
  public url: string;
  public urlSafe: SafeResourceUrl;

  get getUUID() {
    if (InterQualReviewSaveResponse.uuid) {
      return InterQualReviewSaveResponse.uuid;
    }
  }

  get getReviewStatus() {
    const  myarray = this.parseXML(InterQualReviewSaveResponse.reviewXml);
     if (myarray) {
       return myarray[0]['Review'];
     }
  }
  get getCriteria() {
    const  myarray = this.parseXML(InterQualReviewSaveResponse.reviewXml);
    if (myarray) {
      return myarray[1]['Criteria'];
    }
  }

  constructor(private readonly priorAuthorizationService: PriorAuthorizationService,
           private http: HttpClient,
          public readonly sanitizer: DomSanitizer,
           private location: Location) {}

  ngOnInit() {
    this.priorAuthSSOData = this.priorAuthorizationService.getSSOStorageData();
    this.redirectToIQApp().subscribe(result => {
      console.log('IQ Redirect URL is = ' + result["_embedded"]);
      this.url = result["_embedded"];
      this.urlSafe = this.sanitizer.bypassSecurityTrustResourceUrl(this.url);
    });
    window.addEventListener('message', this.receiveMessage, false);
  }
  receiveMessage(event: any) {
    if (event.data === 'close') {
      console.log('PARENT');
      // window.close();
      window.location.href = '/app2/landingPage';
    }
  }
  public parseXML(data: any) {
    const  myarray = [];
    if (data) {
      const parser = new xml2js.Parser({strict: false, trim: true});
      parser.parseString(data, (err, result) => {
        myarray.push(
          {
            'Review': result.REVIEW.$.CURRENTSTATUSDESC
          }
        );
        result.REVIEW.CRITERIA.forEach(value => {
          myarray.push(
            {
              'Criteria': value.$.CRITERIAMETDESC
            }
          );
        });
      });
      return myarray;
    }
  }
  public redirectToIQApp() {
    return this.http.post(
      DpocConstants.BASE_REST_URL + 'outboundsso/v1/ssoToInterQual', {
        username: 'f.jones2',
        firstName: 'Frank',
        lastName: 'Jones',
        applicationId: 'InterQualOnline',
        facilityID: 'UNITEDHEALTHFACIL1'
      });
  }

  public cancel() {
    this.location.back(); // <-- go back to previous location on cancel
  }

  public init() {
    console.log('init() Started');
    if (InterQualReviewRequest.reviewId) {
      InterQualOnline.initialize({
        interqualFrameElementId: 'iqconnect',
        errorHandler: this.genericErrorHandler,
        newReviewStartedHandler: this.handleNewReviewStarted,
        reviewSavedHandler: this.handleReviewSaved,
        reviewOpenedHandler: this.handleReviewOpened,
        reviewSummaryPdfHandler: this.handleReviewSummaryPdf,
        reviewSharedHandler: this.handleReviewShared,
        reviewUnsharedHandler: this.handleReviewUnshared,
        reviewStateChangedHandler: this.handleReviewStateChanged,
        initializedHandler: this.handleInitialized,
        applicationReadyHandler: this.handleApplicationReady,
        applicationLogoutHandler: this.handleApplicationLogout,
        guidelineRestricted: false
      });

    } else {
      InterQualOnline.initialize({
        interqualFrameElementId: 'iqconnect',
        errorHandler: this.genericErrorHandler,
        newReviewStartedHandler: this.handleNewReviewStarted,
        reviewSavedHandler: this.handleReviewSaved,
        reviewOpenedHandler: this.handleReviewOpened,
        reviewSummaryPdfHandler: this.handleReviewSummaryPdf,
        reviewSharedHandler: this.handleReviewShared,
        reviewUnsharedHandler: this.handleReviewUnshared,
        reviewStateChangedHandler: this.handleReviewStateChanged,
        initializedHandler: this.handleInitialized,
        applicationReadyHandler: this.handleApplicationReady,
        applicationLogoutHandler: this.handleApplicationLogout,
        guidelineRestricted: true
      });
    }
  }

  public genericErrorHandler(message: any) {
    console.log('FAILURE');
    console.log('Generic: ' + message);
}

  public handleNewReviewStarted(result: any) {
    // handleNewReviewStartedSilently(result);
    // showStatus('SUCCESS');
    console.log('SUCCESS');
    let message = 'New Review Started';
    if (result) {
      if (result.guidelineId) {
        message += ' for subset ' + result.guidelineId;
        if (result.cptCodes && result.cptCodes.length > 0) {
          message += ' cptCodes ' + result.cptCodes;
        }
        if (result.hcpcsCodes && result.hcpcsCodes.length >
          0) {
          message += ' hcpcsCodes ' + result.hcpcsCodes;
        }
      }
      if (result.patient) {
        message += ' for patient';
        /*document.getElementById('reviewXml').value =
          JSON.stringify(result.patient, null, 2);*/
      } else {
        message += ' no patient info provided';
      }
    }
    // setMessage(message);
    console.log(message);
  }

  public handleReviewSaved(result: any) {
    // showStatus('SUCCESS');
    console.log('SUCCESS');
    console.log('Review Saved UUID = ' + result.UUID);
    console.log('Review Saved reviewXml = ' + result.review_xml);
    InterQualReviewSaveResponse.uuid = result.UUID;
    InterQualReviewSaveResponse.reviewXml = result.review_xml;
  }

  public handleReviewOpened(result: any) {
    // showStatus('SUCCESS');
    // setMessage('Review Opened Successfully');
    console.log('Review Opened Successfully');
    console.log('review_xml = ' + result.review_xml);
    if (result.patient) {
      console.log('FirstName = ' + result.patient.firstName);
      console.log('PatientMiddleName = ' + result.patient.middleName);
      console.log('PatientLastName = ' + result.patient.lastName);
      console.log('PatientDOB = ' + result.patient.dob);
      console.log('Gender = ' + result.patient.gender);
      console.log('ExternalID = ' + result.patient.externalID);
      console.log('ExternalIDType = ' + result.patient.externalIDType);
    }
    if (result.UUID) {
      console.log('reviewSaveId UUID = ' + result.UUID);
    }
  }

  public handleReviewSummaryPdf(result: any) {
    // console.log('SUCCESS');
    console.log('PDF retrieved');
    /*var blob = new Blob([result], {type: 'application/pdf'});
    if (window.navigator.msSaveOrOpenBlob) {
      window.navigator.msSaveOrOpenBlob(blob, 'review summary.pdf');
    } else {
      var pdfLink = document.getElementById('pdfLink');
      pdfLink.href = URL.createObjectURL(blob);
      pdfLink.click();
    }*/
  }

  public handleReviewUnshared(result: any) {
    // console.log('SUCCESS');
    console.log('Review Shared');
  }

  public handleReviewShared(result: any) {
    // console.log('SUCCESS');
    console.log('Review UnShared');
  }

  public handleReviewStateChanged(result: any) {
    console.log('Review State Changed');
  }

  public handleInitialized(data: any) {
    console.log('API/IFrame is initialized' + data.apiVersion);
  }

  public handleApplicationReady(result: any) {
    console.log('handle Application Ready' + result);
    if (InterQualReviewRequest.reviewId) {
      InterQualOnline.openReview({
        savedReviewId: InterQualReviewRequest.reviewId
      });
    } else {
      InterQualOnline.guidelineSearch(
        {
          'type': 'MEDICAL',
          'serviceCode': InterQualReviewRequest.procedureCode,
          'age': '5'
        },
        (data: any) => {
          console.log('Guideline Search Complete');
          if (data.members && data.members.length > 0) {
            console.log('Found ' + data.members.length + ' subsets.');
            console.log(JSON.stringify(data.members));
            InterQualOnline.newReview({guidelineId: data.members[0].id});
          } else {
            console.log('No subsets found for given search criteria');
          }
        },
        (data: any) => {
          console.log('Could not perform guideline search ' + data,
            true);
        }
      );
    }
  }

  public handleApplicationLogout(result: any) {
    console.log('Application Logout in ' + result.timeout);
  }
}
//
