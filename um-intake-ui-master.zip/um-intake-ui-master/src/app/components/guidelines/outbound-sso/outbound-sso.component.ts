import {Component, Inject, OnInit} from '@angular/core';
import { OutboundSsoService } from 'src/app/services/outbound-sso-service/outbound-sso.service';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'um-sso-to-evicore',
  templateUrl: './outbound-sso.component.html',
  styleUrls: ['./outbound-sso.component.scss']
})
export class OutboundSsoComponent implements OnInit {

  public evicoreRedirectTitle: string;

  constructor(private outboundSSOService: OutboundSsoService,
              @Inject(MAT_DIALOG_DATA) public data: any) {
  }

  ngOnInit() {
    this.evicoreRedirectTitle = 'You are being redirected';
  }

  //public ssoToOutboundAPP() {
    //this.outboundSSOService.ssoTOOutboundApplicationFrmContinue(this.data.ssoAppName);
  //}

}
