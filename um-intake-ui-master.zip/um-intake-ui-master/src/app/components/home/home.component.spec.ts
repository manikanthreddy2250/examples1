import { HttpClientTestingModule } from '@angular/common/http/testing';
import {NO_ERRORS_SCHEMA} from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {ActivatedRoute, Router} from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { of } from 'rxjs';
import { HomeComponent } from './home.component';

const activatedRouteStub = {
   params: of({ id: 22 })
};

describe('HomeComponent', () => {
   let component: HomeComponent;
   let fixture: ComponentFixture<HomeComponent>;

   beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [HomeComponent],
      imports: [RouterTestingModule.withRoutes([]), HttpClientTestingModule],
      providers: [ { provide: ActivatedRoute, useValue: activatedRouteStub }],
      schemas: [NO_ERRORS_SCHEMA]
     }).compileComponents();
  }));

   beforeEach(() => {
    fixture = TestBed.createComponent(HomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

   it('should create', () => {
         expect(component).toBeTruthy();
   });

   it('createAuthCardConfig should create', () => {
    const spy = spyOn(component.router, 'navigateByUrl');
    expect(component.createAuthCardConfig.name).toEqual('Create Authorization');
    expect(component.createAuthCardConfig.text).toEqual('Create Authorization');
    expect(component.createAuthCardConfig.primaryBtn.name).toEqual('Create');
    component.createAuthCardConfig.primaryBtn.callback();
    expect(spy).toHaveBeenCalledWith('/um/auth/initiate');
  });
});
