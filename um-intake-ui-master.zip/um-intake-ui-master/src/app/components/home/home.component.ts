import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {IUITKCardConfig, UITKHeadingLevel} from '@uitk/angular';
@Component({
  selector: 'um-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  createAuthCardConfig: IUITKCardConfig = {
    name: 'Create Authorization',
    headingLevel: UITKHeadingLevel.h1,
    text: 'Create Authorization',
    primaryBtn: {
      id: 'basicPrimaryBtn',
      name: 'Create',
      callback: () => {
        this.router.navigateByUrl('/um/auth/initiate');
      },
    },
  };
  constructor(readonly router: Router) {}
  ngOnInit() {}
}
