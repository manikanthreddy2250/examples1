import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DupProcedureComponent } from './dup-procedure.component';

describe('DupProcedureComponent', () => {
  let component: DupProcedureComponent;
  let fixture: ComponentFixture<DupProcedureComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DupProcedureComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DupProcedureComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('dateFormat() should return the formatted date', () => {
    const formattedDate = component.dateFormat(new Date('2020-10-23T00:00:00'));
    expect(formattedDate).toEqual('10-23-2020');
  });
});
