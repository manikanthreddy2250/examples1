import {Component, Input, OnInit} from '@angular/core';
import * as moment from 'moment';
import {ReferenceConstants} from 'src/app/constants/referenceConstants';

@Component({
  selector: 'um-dup-procedure',
  templateUrl: './dup-procedure.component.html',
  styleUrls: ['./dup-procedure.component.scss']
})
export class DupProcedureComponent implements OnInit {

  @Input()
  hscProcedures: any;
  @Input()
  serviceSettingType: any;
  @Input()
  viewType: string;
  OP = ReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT;
  OPF = ReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY;
  IP = ReferenceConstants.SERVICESETTINGTYPE_INPATIENT;
  constructor() { }

  ngOnInit(): void {
  }

  dateFormat(date) {
    return moment(date).format('MM-DD-YYYY');
  }

}
