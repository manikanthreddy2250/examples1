import {HttpClientTestingModule} from '@angular/common/http/testing';
import {CUSTOM_ELEMENTS_SCHEMA, Injectable, NO_ERRORS_SCHEMA} from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {FormsModule, ReactiveFormsModule } from '@angular/forms';
import {BehaviorSubject} from 'rxjs';
import {uitkAngularModules, uitkModules} from 'src/app/app.module';
import {ReferenceService} from 'src/app/services/refernce-service/reference.service';
import {StepperDataService} from 'src/app/services/StepperDataService/StepperDataService';
import { DuplicateViewComponent } from './duplicate-view.component';
import {UserSessionService} from '../../../shared/services/user-session/user-session.service';


@Injectable()
class MockStepperDataService {
  private stepperData = new BehaviorSubject({tenantId: 'ecpumintakebaseproductbpmgrp'});
  sharedStepperData = this.stepperData.asObservable();

  constructor() { }

  setStepperData(stepperData: any) {
    this.stepperData.next(stepperData);
  }
}

@Injectable()
class UserSessionMockService {
  i = 0;
  getUserName() {
    if (this.i === 0) {
      this.i++;
      return 'breddy88';
    } else if (this.i === 1) {
      this.i = this.i + 2;
      return 'SYSTEM';
    } else if (this.i === 3)  {
      return 'abcd';
    }
  }
  getUserOrg() {
    return 'ecp';
  }
  getUserPermission() {}

  getEcpToken() {return 'dfghjk'; }
  getFunctionalRole() {}
}

describe('DuplicateViewComponent', () => {
  let component: DuplicateViewComponent;
  let fixture: ComponentFixture<DuplicateViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [uitkModules, uitkAngularModules, FormsModule, ReactiveFormsModule, HttpClientTestingModule],
      declarations: [ DuplicateViewComponent ],
      providers: [{provide: StepperDataService, useClass: MockStepperDataService},{ provide: UserSessionService, useClass: UserSessionMockService}, ReferenceService],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DuplicateViewComponent);
    component = fixture.componentInstance;
    component.duplicateViewData = {viewType: 'current'};
    fixture.detectChanges();
  });

  afterEach(() => {
    fixture.destroy();
  });

  afterAll(() => {
    TestBed.resetTestingModule();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should getFacilityTypeRefDisplay ', () => {
    component.getFacilityTypeRefDisplay(12);
    expect(component.getFacilityTypeRefDisplay).toBeTruthy();
  });
  it('should getServiceDescTypeRefDisplay ', () => {
    component.getServiceDescTypeRefDisplay(123);
    expect(component.getServiceDescTypeRefDisplay).toBeTruthy();
  });
  it('buildCaseData() should build case data from hscFacl for IP', () => {
    component.duplicateViewData = {viewType: 'current'};
    component.hsc = {srvc_set_ref_id: 3737};
    component.hscFacl = {srvc_desc_ref_id: 321, plsrv_ref_id: 123};
    component.facilityTypes = [{ref_id: 123, ref_dspl: 'facility'}];
    component.serviceDescriptionTypes = [{ref_id: 321, ref_dspl: 'srvc desc'}];
    component.buildCaseData();
    expect(component.caseData.facilityType).toEqual('facility');
    expect(component.caseData.serviceDescription).toEqual('srvc desc');
  });
  it('buildCaseData() should build case data from hscSrvcNonFacl for OP', () => {
    component.duplicateViewData = {viewType: 'current'};
    component.hsc = {srvc_set_ref_id: 3738};
    component.hscSrvcNonFacl = {srvc_desc_ref_id: 321, plsrv_ref_id: 123};
    component.facilityTypes = [{ref_id: 123, ref_dspl: 'facility'}];
    component.serviceDescriptionTypes = [{ref_id: 321, ref_dspl: 'srvc desc'}];
    component.buildCaseData();
    expect(component.caseData.facilityType).toEqual('facility');
    expect(component.caseData.serviceDescription).toEqual('srvc desc');
  });
  it('buildDuplicateCase should build duplicate case data from hscDuplicates', () => {
    component.duplicateViewData = {viewType: 'duplicate', duplicateCaseCurrentIndex: 0};
    component.stepperData = {hscDuplicates: [
        {
          hsc_id: 7448,
          auth_end_dt: null,
          auth_strt_dt: null,
          auth_typ_ref_id: null,
          cont_of_care_ind: null,
          indv_id: 503926748,
          mbr_cov_dtl: null,
          mbr_cov_id: 12484,
          rev_prr_ref_id: 3754,
          srvc_set_ref_id: 3737,
          hsc_diags: [
            {
              diag_cd: 'S83.116',
              inac_ind: 0,
              hsc_id: 7448,
              pri_ind: 0,
              hscDiagDiagCdRef: [
                {
                  shrt_desc: 'ANT DISLOCATION PROX TIBIA UNS KNEE',
                  full_desc: 'Anterior dislocation of proximal end of tibia, unspecified knee',
                  cd_desc: 'ANTERIOR DISLOCATION PROXIMAL END TIBIA UNS KNEE'
                }
              ]
            },
            {
              diag_cd: 'S80.242D',
              inac_ind: 0,
              hsc_id: 7448,
              pri_ind: 1,
              hscDiagDiagCdRef: [
                {
                  shrt_desc: 'EXTERNAL CONSTRICTION LT KNEE SBSQT',
                  full_desc: 'External constriction, left knee, subsequent encounter',
                  cd_desc: 'EXTERNAL CONSTRICTION LT KNEE SUBSEQUENT ENCNTR'
                }
              ]
            }
          ],
          hsc_facls: [{
            hsc_id: 7448,
            actul_admis_dttm: '2020-10-11T00:00:00',
            actul_dschrg_dttm: '2020-10-13T00:00:00',
            expt_admis_dt: '2020-10-11',
            expt_dschrg_dt: '2020-10-17',
            plsrv_ref_id: 3743,
            srvc_desc_ref_id: 4347,
            srvc_dtl_ref_id: 4296
          }],
          hsc_provs: []
        }
      ]
    };
    component.buildDuplicateCase();
    expect(component.hscDiagnosis.length).toEqual(2);
    expect(component.hsc.srvc_set_ref_id).toEqual(3737);
  });

  it('buildCurrentCaseData() should build current case data from stepperData', () => {
    component.duplicateViewData = {viewType: 'current'};
    component.stepperData = {
      hsc: {
          hsc_id: 7448,
          auth_end_dt: null,
          auth_strt_dt: null,
          auth_typ_ref_id: null,
          cont_of_care_ind: null,
          indv_id: 503926748,
          mbr_cov_dtl: null,
          mbr_cov_id: 12484,
          rev_prr_ref_id: 3754,
          srvc_set_ref_id: 3737
        },
      hscDiagnosis: [
            {
              diag_cd: 'S83.116',
              inac_ind: 0,
              hsc_id: 7448,
              pri_ind: 0,
              hscDiagDiagCdRef: [
                {
                  shrt_desc: 'ANT DISLOCATION PROX TIBIA UNS KNEE',
                  full_desc: 'Anterior dislocation of proximal end of tibia, unspecified knee',
                  cd_desc: 'ANTERIOR DISLOCATION PROXIMAL END TIBIA UNS KNEE'
                }
              ]
            },
            {
              diag_cd: 'S80.242D',
              inac_ind: 0,
              hsc_id: 7448,
              pri_ind: 1,
              hscDiagDiagCdRef: [
                {
                  shrt_desc: 'EXTERNAL CONSTRICTION LT KNEE SBSQT',
                  full_desc: 'External constriction, left knee, subsequent encounter',
                  cd_desc: 'EXTERNAL CONSTRICTION LT KNEE SUBSEQUENT ENCNTR'
                }
              ]
            }
          ],
      hscProcedures: [{}]
    };
    component.buildCurrentCaseData();
    expect(component.hscDiagnosis.length).toEqual(2);
    expect(component.hscProcedures.length).toEqual(1);
  });
  it('dateFormat() should return the formatted date', () => {
    const formattedDate = component.dateFormat(new Date('2020-10-23T00:00:00'));
    expect(formattedDate).toEqual('10-23-2020');
  });
});
