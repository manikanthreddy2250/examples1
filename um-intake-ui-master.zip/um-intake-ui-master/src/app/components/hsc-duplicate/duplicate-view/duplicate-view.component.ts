import {Component, Input, OnDestroy, OnInit} from '@angular/core';
import * as moment from 'moment';
import {Constants} from 'src/app/constants/constants';
import {Subscription} from 'rxjs';
import {ReferenceService} from 'src/app/services/refernce-service/reference.service';
import {ReferenceConstants} from 'src/app/constants/referenceConstants';
import {ProviderSearchService} from 'src/app/services/provider-search/provider-search.service';
import {StepperDataService} from 'src/app/services/StepperDataService/StepperDataService';
import {UserSessionService} from 'src/app/shared/services/user-session/user-session.service';

@Component({
  selector: 'um-duplicate-view',
  templateUrl: './duplicate-view.component.html',
  styleUrls: ['./duplicate-view.component.scss']
})
export class DuplicateViewComponent implements OnInit, OnDestroy {
  OP = ReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT;
  IP = ReferenceConstants.SERVICESETTINGTYPE_INPATIENT;
  OPF = ReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY;
  constructor(public stepperDataService: StepperDataService,
              public referenceService: ReferenceService,
              public providerSearchService: ProviderSearchService,
              private readonly userSessionService: UserSessionService) {
  }
  PROVIDER = Constants.UM_INTAKE_UI_USER_PERMISSION_PROVIDER;
  CLINICIAN = Constants.UM_INTAKE_UI_USER_PERMISSION_CLINICIAN;
  stepperData: any;
  caseData: any;
  hsc: any;
  hscProcedures: any;
  hscDiagnosis: any;
  hscContact: any;
  hscFacl: any;
  hscSrvcNonFacl: any;
  submittingProvider: any;
  facilityProvider: any;
  @Input()
  duplicateViewData: any;
  userPermission: any;
  serviceDescriptionTypes: any = [];
  facilityTypes: any = [];
  hscStatusTypes: any = [];
  stepperDataSubscription: Subscription;
  ngOnInit(): void {
    this.userPermission = this.userSessionService.getUserPermission();  // This method returns generic role ('provider' or 'clinician')
    this.stepperDataSubscription = this.stepperDataService.sharedStepperData.subscribe((stepperData) => {
      this.stepperData = stepperData;
      if (this.duplicateViewData.viewType === 'current') {
        this.buildCurrentCaseData();
      }
      if (this.duplicateViewData.viewType === 'duplicate') {
        this.buildDuplicateCase();
      }
    });
    this.getFacilityTypeRefData();
    this.getServiceDescriptionRefData();
    this.getHscStatusTypeRefData();
  }

  ngOnDestroy() {
    this.stepperDataSubscription.unsubscribe();
  }

  buildCurrentCaseData() {
    this.hsc = this.stepperData.hsc;
    this.hscDiagnosis = this.stepperData.hscDiagnosis;
    this.hscProcedures = this.stepperData.hscProcedures;
    this.hscContact = this.stepperData.hscContact;
    if (this.hsc.srvc_set_ref_id === this.OP) {
      this.hscSrvcNonFacl = this.stepperData.hscSrvcNonFacl;
    } else {
      this.hscFacl = this.stepperData.hscFacl;
      this.facilityProvider = this.stepperData.facilityProviderDetails;
    }
    const submittingProvider = this.stepperData.submittingProviderDetails;
    if (submittingProvider) {
      this.submittingProvider = submittingProvider;
    }
  }

  ngOnChanges() {
    if (this.duplicateViewData.viewType === 'duplicate') {
      this.buildDuplicateCase();
    }
  }

  buildDuplicateCase() {
    if (this.stepperData && this.stepperData.hscDuplicates && this.stepperData.hscDuplicates.length > 0) {
      this.hsc = this.stepperData.hscDuplicates[this.duplicateViewData.duplicateCaseCurrentIndex];
      if (this.hsc.srvc_set_ref_id === this.OP) {
        this.hscSrvcNonFacl = this.hsc.hsc_srvcs[0].hsc_srvc_non_facls[0];
      } else {
        this.hscFacl = this.hsc.hsc_facls[0];
        this.buildFacilityProviderData();
      }
      this.hscProcedures = this.hsc.hsc_srvcs;
      this.hscDiagnosis = this.hsc.hsc_diags;
      this.hscContact = this.hsc.flwup_cntc_dtl;
      this.buildCaseData();
      this.hsc.status = this.hscStatusTypes.length > 0 ? this.hscStatusTypes.find((item) => item.ref_id === this.hsc.hsc_sts_ref_id).ref_dspl : null;
      // all duplicates will have same submitting provider since these were already filtered during saveProvider API call
      this.submittingProvider = this.stepperData.submittingProviderDetails;
    }
  }

  private buildFacilityProviderData() {
    function isFacilityProvider(prov) {
      return prov.hsc_prov_roles?.find((item) => item.prov_role_ref_id === ReferenceConstants.PROVIDER_ROLE_REF_ID_FACILITY) ? true : false;
    }
    const facilityProvider = this.hsc.hsc_provs?.find((prov) => isFacilityProvider(prov));
    if (facilityProvider) {
      this.providerSearchService.getProviderDetailDraftData(facilityProvider.prov_loc_affil_id, ReferenceConstants.PROVIDER_KEY_VALUE_TYP_REF_ID_TIN)
        .toPromise()
        .then((resProvData) => {
          const facProvider = resProvData.data.v_prov_srch[0];
          this.facilityProvider = {businessName: facProvider.bus_nm};
          this.facilityProvider.providerTin = facilityProvider.prov_key_val;
        });
    }
  }

  buildCaseData() {
    this.caseData = {};
    if (this.hsc.srvc_set_ref_id === this.OP) {
      this.caseData.facilityType = this.getFacilityTypeRefDisplay(this.hscSrvcNonFacl.plsrv_ref_id);
      this.caseData.serviceDescription = this.getServiceDescTypeRefDisplay(this.hscSrvcNonFacl.srvc_desc_ref_id);
    } else {
      this.caseData.facilityType = this.getFacilityTypeRefDisplay(this.hscFacl.plsrv_ref_id);
      this.caseData.serviceDescription = this.getServiceDescTypeRefDisplay(this.hscFacl.srvc_desc_ref_id);
    }

  }

  getFacilityTypeRefData() {
    this.referenceService.loadBaseRefNameDisplayData(ReferenceConstants.FACILITY_TYPE_BAS_REF_NM).toPromise().then((res) => {
      this.facilityTypes = res.data.ref;
      this.buildCaseData();
    }).catch((error) => { });
  }

  getServiceDescriptionRefData() {
    this.referenceService.loadBaseRefNameDisplayData(ReferenceConstants.SERVICE_DESC_BAS_REF_NM).toPromise().then((res) => {
        this.serviceDescriptionTypes = res.data.ref;
        this.buildCaseData();
    }).catch((error) => { });
  }

  getHscStatusTypeRefData() {
    this.referenceService.loadBaseRefNameDisplayData(ReferenceConstants.HSC_STATUS_BAS_REF_NM).toPromise().then((res) => {
      this.hscStatusTypes = res.data.ref;
      this.hsc.status = this.hscStatusTypes.find((item) => item.ref_id === this.hsc.hsc_sts_ref_id).ref_dspl;
    }).catch((error) => { });
  }

  getFacilityTypeRefDisplay(refId) {
    const facilityType = this.facilityTypes.find((item) => item.ref_id === refId);
    return facilityType ? facilityType.ref_dspl : null;
  }

  getServiceDescTypeRefDisplay(refId) {
    const serviceDesc = this.serviceDescriptionTypes.find((item) => item.ref_id === refId);
    return serviceDesc ? serviceDesc.ref_dspl : null;
  }

  dateFormat(date) {
    return moment(date).format('MM-DD-YYYY');
  }
}
