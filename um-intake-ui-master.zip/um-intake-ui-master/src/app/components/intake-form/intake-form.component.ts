import {DatePipe} from '@angular/common';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Component, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {ActivatedRoute, Router} from '@angular/router';
import {IWizardConfig} from '@uimf/uitk';
import {UITKPageNotificationService} from '@uitk/angular';
import {Subscription} from 'rxjs';
import {filter, map, tap} from 'rxjs/operators';
import {GenericStepperComponent} from 'src/app/components/generic-stepper/generic-stepper.component';
import {MemberEligibilityService} from 'src/app/services/member-eligiblity-service/member-eligibility-service';
import {MemberSearchServiceGraphqlConfig} from 'src/app/services/member-search-service/member-search-service-graphql';
import {ProcedureServiceService} from 'src/app/services/procedure/procedure-service.service';
import {ProviderSearchService} from 'src/app/services/provider-search/provider-search.service';
import {ReferenceConstants} from 'src/app/constants/referenceConstants';
import {ReferenceService} from 'src/app/services/refernce-service/reference.service';
import {requestInfo} from "../authorization-type/authorization-type.component";
import {StepperDataService} from 'src/app/services/StepperDataService/StepperDataService';
import {SummaryServiceService} from 'src/app/services/summaryservice/summary-service.service';
import {UserSessionService} from 'src/app/shared/services/user-session/user-session.service';
import {environment} from 'src/environments/environment';
import env from '../../../environments/.env';
import {ConfigConstants} from '../../constants/configConstants';
import {RulesConstants} from '../../constants/rulesConstants';
import {FlowType} from '../../models/enums/flowType';
import {CamunadaSignalService} from '../../services/camundaSignal-service/camunadaSignal.service';
import {FileUploadService} from '../../services/file-upload-service/file-upload.service';
import {AuthorizationAddService} from '../../services/health-service/authorization-add.service';
import {SysConfigService} from '../../services/sysconfig-service/sys-config.service';
import {UmIntakeFuncGraphqlService} from '../../services/um-intake-functions/umintakefunc-graphql.service';
import { Constants } from './../../constants/constants';
import {HealthGraphqlService} from '../../services/health-service/health-graphql.service';
import {ColumnValue, Predicate, SqlOperator, WhereClause} from "@ecp/gql-tk-beta";
import {UmintakefuncHscDetailsService} from '../../services/um-intake-functions/umintakefunc-hscDetails.service';

const ADVANCE_NOTIFICATION = 'ADVNTF - Advance Notification';
const CONTENT_TYPE_APPLICATION_JSON = 'application/json';

@Component({
  selector: 'um-in-take-form',
  templateUrl: './intake-form.component.html',
  styleUrls: ['./intake-form.component.scss']
})

export class IntakeFormComponent implements OnInit, OnDestroy {
  constructor(private activatedRoute: ActivatedRoute,
              private readonly router: Router,
              private memberSearchGraphqlConfig: MemberSearchServiceGraphqlConfig,
              private formBuilder: FormBuilder,
              private messageService: UITKPageNotificationService,
              private memberEligibilityConfig: MemberEligibilityService,
              private readonly authAddService: AuthorizationAddService,
              private readonly camundaSignalService: CamunadaSignalService,
              private readonly httpClient: HttpClient,
              private userSessionService: UserSessionService, public providerSearchService: ProviderSearchService,
              private readonly procedureServiceService: ProcedureServiceService,
              public datepipe: DatePipe,
              private readonly summaryServiceService: SummaryServiceService,
              private fileUploadService: FileUploadService, public stepperDataService: StepperDataService,
              private readonly sysConfigService: SysConfigService,
              public referenceService: ReferenceService,
              public readonly umIntakeFuncGraphqlService: UmIntakeFuncGraphqlService,
              public readonly healthGraphqlService: HealthGraphqlService,
              readonly umintakefuncHscDetailsService: UmintakefuncHscDetailsService

  ) { }

  @ViewChild('authType', { static: false }) genericStepperComponent: GenericStepperComponent;
  @ViewChild('intial', { static: false }) genericStepperIntialContact: GenericStepperComponent;
  @ViewChild('files', { static: false }) genericStepperfiles: GenericStepperComponent;
  @ViewChild('notes', { static: false }) genericStepperNotes: GenericStepperComponent;
  @ViewChild('anticipatedServiceCmp', { static: false }) genericStepperAnticipateServiceComponent: GenericStepperComponent;


  profileForm = new FormGroup({
    duplicateRequestReason: new FormControl(null),
  });

  public justificationReasonTypes = [];
  defaultLabel = 'Select';
  defaultLabelFlag = true;
  currentStepUpdate: any;
  normalDialogModal = false;
  duplicateDialogModal = false;
  duplicateJustificationDialogModal = false;
  exitDialogModal = false;
  duplicateCaseCurrentIndex = 0;
  validationRequired = false;
  public currentStep = 1;
  clientId: any;
  recordsOPToSaveLS = [];
  files = [];
  completedStepIds = [];
  existingCaseId: any;
  requestCategory;
  OUTPATIENTFACILITY_REF_CD = ReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY;
  HSC_STATUS_TYPE_OPEN = ReferenceConstants.HSC_STATUS_TYPE_OPEN;
  HSC_STATUS_TYPE_DRAFT = ReferenceConstants.HSC_STATUS_TYPE_DRAFT;
  OUTPATIENT_REF_CD = ReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT;
  CONTACT_STEPPER = 'Contact Details';
  CASE_TYPE_STEPPER = 'Case Type';
  DIAG_PROC_STEPPER = 'Diagnoses/Procedures';
  DIAG_PROC_ANTICIPATED_SERVICE_STEPPER = 'Diagnoses/Procedures and Anticipated Service';
  PROVIDER_STEPPER = 'Provider';
  DOCUMENTATION_STEPPER = 'Documentation';
  BPM_WORK_FLOW_CASE_ID = 19517;
  public creat_dttm = new Date();
  stepperData: any;
  public anticipatedServiceDateConfigKey = ConfigConstants.ANTICIPATED_SERVICE_DATE_CONFIG_KEY;

  lineOfBusiness = '13 - CIP M&R';
  procedureCode = 'E0465';
  networkStatus = '1 - In Network';
  stateOfIssue = 'MN';
  tatPeriodType = 'Notification to Decision';
  tatCategoryType = 'Decision';
  triggerTatPointType = 'Notification';
  /**
   * Configuration for wizard using IWizardConfig interface
   */
  public horizontalWizard: IWizardConfig;
  wizardStepsKeys = [];
  caseId = null;
  signalVariables = null;
  hscId = null;
  hscSrvcId = null;
  procedureIPRecords = [];
  procedureOPFRecords = [];
  httpHeaders = new HttpHeaders({
    'Content-Type': CONTENT_TYPE_APPLICATION_JSON,
    'Accept': CONTENT_TYPE_APPLICATION_JSON,
    'Authorization': 'Bearer ' + this.userSessionService.getEcpToken() });
  camundaHttpHeaders = new HttpHeaders({});
  selectedMember;
  notes;
  intakeForm: FormGroup;
  reasonTextLimit = 120;
  myValue: string;
  isShowTextArea = false ;

  onKeyup(event: KeyboardEvent) {
    if (this.myValue.length >= 1) {
      if (document.getElementById('continueBtn')) {
        document.getElementById('continueBtn').removeAttribute('disabled');
      }
    } else {
      if (document.getElementById('continueBtn')) {
        document.getElementById('continueBtn').setAttribute('disabled', 'true');
      }
    }
  }

  public stepperLabels = [
    { id: 1, label: 'Case Type', value: '1' },
    { id: 2, label: 'Provider', value: '2' },
    { id: 3, label: 'Servicing Provider', value: '3' },
    { id: 4, label: 'Diagnoses', value: '4' },
    { id: 5, label: 'Procedures', value: '5' },
    { id: 6, label: 'Assessment/Questionnaire', value: '6' },
    { id: 7, label: 'Contact Details', value: '7' },
    { id: 8, label: 'Documentation', value: '8' },
    { id: 9, label: 'Summary', value: '9' },
    { id: 10, label: 'Diagnoses/Procedures', value: '10' },
    { id: 11, label: 'Diagnoses/Procedures and Anticipated Service', value: '11' }

  ];
  public stepperIds = [];
  procType;
  procedureCategory = [];
  requestCatOP = 'Outpatient';
  requestCatIP = 'Inpatient';
  requestCatOPF = 'Outpatient Facility';

  facilityTypeForProc;
  genericSaveErrorAlert = {
    id: 'error_msg',
    pageNotificationType: 'error',
    content: 'Unable to save the data.',
    visible: false,
    closeButton: true,
  };
  missingStepperAlert = {
    id: 'error_msg',
    pageNotificationType: 'error',
    content: 'The review type selected does not have stepperIDs associated to it. Please contact your system administrator.',
    visible: false,
    closeButton: true,
  };
  errorProcAlert = {
    id: 'error_msg',
    pageNotificationType: 'error',
    content: 'Unable to save Procedure.',
    visible: false,
    closeButton: true,
  };
  errorAlert = {
    id: 'error_msg',
    pageNotificationType: 'error',
    content: 'Unable to save Diagnosis.',
    visible: false,
    closeButton: true,
  };

  errorConfigDiag = {
    id: 'error_msg',
    pageNotificationType: 'error',
    visible: false,
    content: 'At least one diagnosis code is required',
    closeButton: true,
  };
  saveAuthErrorAlert = {
    id: 'error_msg',
    pageNotificationType: 'error',
    content: 'Unable to save Auth Type Data.',
    visible: false,
    closeButton: true,
  };

  authTypeErrorConfig = {
    id: 'error_msg',
    pageNotificationType: 'error',
    visible: false,
    content: 'Please correct missing fields in order to proceed.',
    closeButton: true,
  };
  saveContactDetailsAlert = {
    id: 'error_msg',
    pageNotificationType: 'error',
    content: 'Unable to Save Contact Details Data.',
    visible: false,
    closeButton: true,
  };

  intialContactErrorConfig = {
    id: 'error_msg',
    pageNotificationType: 'error',
    visible: false,
    content: 'Please correct missing fields in order to proceed.',
    closeButton: true,
  };
  stepperDataSubscription: Subscription;

  environmentId = environment.envID;
  appName = Constants.UM_INTAKE_UI_APP_NAME;
  versionNumber = env.npm_package_version;
  keyVal = Constants.MEMBER_HEADER_KEY;

  notesUpdated = (data) => {
    this.notes = data;
  }

  getWizardSteps(stepperIds) {
    const stepperObj = {
      step1: { label: this.stepperLabels.find((label) => label.id === stepperIds[0]).label },
      step2: { label: this.stepperLabels.find((label) => label.id === stepperIds[1]).label }
    };
    stepperIds.forEach((item, index) => {
      if (index > 1) {
        const step = 'step' + (index + 1);
        stepperObj[step] = { label: this.stepperLabels.find((label) => label.id === item).label };
      }
    });
    return stepperObj;
  }

  ngOnInit(): void {
    this.getDefaultZipRadius();
    this.stepperDataSubscription = this.stepperDataService.sharedStepperData.subscribe((stepperData) => this.stepperData = stepperData);
    this.camundaHttpHeaders = new HttpHeaders({
      'Content-Type': CONTENT_TYPE_APPLICATION_JSON,
      'Accept': CONTENT_TYPE_APPLICATION_JSON,
      'Authorization': 'Bearer ' + this.userSessionService.getEcpToken(),
      'x-bpm-cli-org-id': this.userSessionService.getUserOrg(),
      'x-bpm-func-role': this.userSessionService.getFunctionalRole(),
      'x-bpm-tenant-id': this.stepperData.tenantId
    });
    this.clientId = this.userSessionService.getUserOrg();
    this.selectedMember = {};
    this.selectedMember.coverage = {};
    this.activatedRoute.params.pipe(
      map((params) => params['id']),
      filter((indv_key_val) => !!indv_key_val),
      tap((indv_key_val) => {
        this.getMemberDetails(indv_key_val);
      })
    ).subscribe();

    this.activatedRoute.params.pipe(
      map((params) => params['cov_id']),
      filter((mbr_cov_id) => !!mbr_cov_id),
      tap((mbr_cov_id) => {
        this.getMemberCovDetails(mbr_cov_id);
      })
    ).subscribe();

    this.activatedRoute.params.pipe(
      map((params) => params['serviceType']),
      filter((serviceType) => !!serviceType),
      tap((serviceType) => {
        this.getStepperIds(serviceType);
      })
    ).subscribe();

    this.activatedRoute.params.pipe(
      map((params) => params['caseId']),
      filter((caseId) => !!caseId),
      tap((caseId) => {
        this.caseId = caseId;
        this.stepperDataService.setStepperData({...this.stepperData, caseId});
      })
    ).subscribe();

    this.activatedRoute.params.pipe(
      map((params) => params['hscId']),
      filter((hscId) => !!hscId),
      tap((hscId) => {
        this.hscId = hscId;
        this.stepperDataService.setStepperData({...this.stepperData, hscId});
      })
    ).subscribe();
    if (this.stepperData.flowType === FlowType.NEW) {
        this.getAuthDetails(this.hscId);
        this.validationRequired = true;
    } else {
      this.getAuthDraftData(this.hscId);
    }
    this.intakeForm = this.formBuilder.group({
      requestInformationForm: this.getRequestFrom(),
      intialContactForm: this.getIntialContactForm(),
      followContactForm: this.getFollowContactForm(),
    });
    this.providerSearchService.setHscId(this.hscId);
    this.updateReason();
  }

  ngOnDestroy() {
    this.stepperDataSubscription.unsubscribe();
  }
  getDefaultZipRadius() {
      let defaultRadiusForSearch = {};
      this.sysConfigService.getClientConfigByKey(ConfigConstants.DEFAULT_ZIP_RADIUS_CONFIG_KEY).subscribe((res: any) => {
        if (res[0].value) {
          defaultRadiusForSearch = JSON.parse(res[0].value);
          this.stepperDataService.setStepperData({...this.stepperData, defaultRadius: defaultRadiusForSearch});
        }
      });
  }
  public getUpdatedAuthorizationForm(model) {
    if (document.getElementById('continueBtn')) {
      document.getElementById('continueBtn').removeAttribute('disabled');
    }
    if (model == null) {
      this.isShowTextArea = false;
      document.getElementById('continueBtn').setAttribute('disabled', 'true');
    } else {
      if (('Other' === model.label)) {
        this.isShowTextArea = true;
        if (document.getElementById('continueBtn')) {
          if (this.myValue?.length >= 1) {
            document.getElementById('continueBtn').removeAttribute('disabled');
          } else {
            document.getElementById('continueBtn').setAttribute('disabled', 'true');
          }
        }
      } else {
        this.isShowTextArea = false;
      }
    }
  }
  getAuthDraftData(hscId) {
    this.setRulesAndWFTenantId();
    this.summaryServiceService.getHscDetailData(hscId)
      .subscribe(async ({ data }) => {
          const srvc_set_ref_id = data.hsc && data.hsc[0].srvc_set_ref_id;
          this.validationRequired = data.hsc && data.hsc[0].hsc_sts_ref_id === ReferenceConstants.HSC_STATUS_TYPE_DRAFT;
          this.getAuthDraftDetailData(hscId, srvc_set_ref_id);
        },
        (error) => {
        });
  }

  private setRulesAndWFTenantId() {
    this.sysConfigService.getClientConfigByKey(ConfigConstants.INTAKE_RULES_CONFIG_KEY).subscribe((configRes) => {
      const rulesTenantId = JSON.parse(configRes[0].value).tenantId;
      this.stepperDataService.setStepperData({...this.stepperData, rulesTenantId});
    });
    this.sysConfigService.getClientConfigByKey(ConfigConstants.INTAKE_WORKFLOW_CONFIG_KEY).subscribe((wfconfigRes) => {
      const tenantId = JSON.parse(wfconfigRes[0].value).tenantId;
      this.stepperDataService.setStepperData({...this.stepperData, tenantId});
    });
  }

  getAuthDetails(hscId) {
    this.summaryServiceService.getHscDetailData(hscId)
      .subscribe(async ({ data }) => {
          this.stepperDataService.setStepperData({...this.stepperData, hsc: data.hsc[0]});
          /* We need anticipatedServiceDateConfigKey for app-um-anticipated-service component */
          this.anticipatedServiceDateConfigKey = this.anticipatedServiceDateConfigKey + this.stepperData.hsc.hsc_rev_typ_ref_id;
        },
        (error) => {
        });
  }

  getAuthDraftDetailData(hsc_id, srvc_set_ref_id) {
    const body = {
      hsc: {
        hsc_id: parseInt(hsc_id)
      }
    };
    this.umintakefuncHscDetailsService.getHscAuthDetails(body).subscribe((data: any) => {
        this.stepperDataService.setStepperData({...this.stepperData, hsc: data.data.getHscAuthDetails.hsc[0]});
        /* We need anticipatedServiceDateConfigKey for app-um-anticipated-service component */
        this.anticipatedServiceDateConfigKey = this.anticipatedServiceDateConfigKey + this.stepperData.hsc.hsc_rev_typ_ref_id;
        this.existingCaseId = data.data.getHscAuthDetails.hsc[0].hsc_keys.find((item) => item.hsc_key_typ_ref_id === this.BPM_WORK_FLOW_CASE_ID)?.hsc_key_val;
        this.draftORopenCaseStepStatus();
        const hsc = data.data.getHscAuthDetails.hsc[0];
        const hscFacl = data.data.getHscAuthDetails.hsc[0].hsc_facls[0];
        const hscSrvcNonFacl = data.data.getHscAuthDetails.hsc[0].hsc_srvcs.length > 0  ? data.data.getHscAuthDetails.hsc[0].hsc_srvcs[0].hsc_srvc_non_facls[0] : [];
        const caseId = this.existingCaseId;
        const dupCheckbody = {
          caseId,
          hsc,
          hscSrvcNonFacl,
          hscFacl
        };
        const camundaHttpHeaders = new HttpHeaders({
          'Content-Type': CONTENT_TYPE_APPLICATION_JSON,
          'Accept': CONTENT_TYPE_APPLICATION_JSON,
          'Authorization': 'Bearer ' + this.userSessionService.getEcpToken(),
          'x-bpm-cli-org-id': this.userSessionService.getUserOrg(),
          'x-bpm-func-role': this.userSessionService.getFunctionalRole(),
          'x-bpm-tenant-id': this.stepperData.tenantId,
          'x-bpm-external-ref-id': '1234',
          'x-bpm-source': 'um_intake_ui',
          'x-bpm-workflow': 'Duplicate Check'
        });
        this.httpClient.post(environment.DUPCHECK_HTTP_FUNCTION_URL, dupCheckbody, {
          headers: camundaHttpHeaders
        }).subscribe((dupCheckData: any) => {
            this.stepperDataService.setStepperData({...this.stepperData, hscDuplicates: dupCheckData.hscDuplicates});
          });
      },
      (error) => {
        if (error) {
          // this.showError();
        }
      });
  }
  private getRequestFrom(): FormGroup {
    return this.formBuilder.group({
      requestTerm: [null, Validators.required],
      siteOfService: [null, Validators.required],
      urgency: [null, Validators.required],
      requestType: [null, Validators.required],
      placeOfService: [null, Validators.required],
      serviceCategory: [null, Validators.required],
      serviceStart: [null, Validators.required],
      serviceDuration: [null, Validators.required]
    });
  }

  private getIntialContactForm(): FormGroup {
    return this.formBuilder.group({
      name: [null, Validators.required],
      role: [null],
      department: [null],
      phone: [null, Validators.required],
      fax: [null],
      email: [null],
    });
  }

  private getFollowContactForm(): FormGroup {
    return this.formBuilder.group({
      followName: [null, Validators.required],
      followRole: [null],
      followDepartment: [null],
      followPhone: [null, Validators.required],
      followFax: [null],
      followEmail: [null],
    });
  }

  redirectToMemberSearch() {
    this.router.navigateByUrl('/um/auth/initiate');
  }

  getMemberDetails(indv_key_val) {
    this.selectedMember = {};
    const memberSearchGraphqlConfig = new MemberSearchServiceGraphqlConfig(this.httpClient, this.userSessionService);
    memberSearchGraphqlConfig.returnSearch(indv_key_val).subscribe((result) => {
      this.selectedMember = { ...this.selectedMember, ...result.data.v_indv_srch[0] };
    });
    return;
  }

  getMemberCovDetails(mbr_cov_id) {
    const memberEligibilityServiceConfig = new MemberEligibilityService(this.httpClient, this.userSessionService);
    memberEligibilityServiceConfig.returnSearch(mbr_cov_id).subscribe((result) => {
      this.selectedMember.coverage = result.data.mbr_cov[0];
      this.stepperDataService.setStepperData({...this.stepperData, selectedMember: this.selectedMember});
    });
    return;
  }

  updateReason() {
    this.referenceService.loadBaseRefNameDisplayData(requestInfo.DUPJUSTIFICATION).toPromise().then((res) => {
      res.data.ref.forEach((item: { ref_id: number; ref_dspl: string; ref_desc: string; }) => {
        const reasonObj = {
          id: item.ref_id,
          label: item.ref_dspl,
          value: item.ref_desc
        };
        this.justificationReasonTypes.push(reasonObj);
      });
    }).catch((error) => { });
  }
  getStepperIds(serviceType) {
    let tenantId = '';
    this.sysConfigService.getClientConfigByKey(ConfigConstants.INTAKE_RULES_CONFIG_KEY).subscribe((configRes) => {
      tenantId = JSON.parse(configRes[0].value).tenantId;
      const camundaHttpHeaders = new HttpHeaders({
        'Content-Type': CONTENT_TYPE_APPLICATION_JSON,
        'Accept': CONTENT_TYPE_APPLICATION_JSON,
        'Authorization': 'Bearer ' + this.userSessionService.getEcpToken(),
        'x-bpm-cli-org-id': this.userSessionService.getUserOrg(),
        'x-bpm-func-role': this.userSessionService.getFunctionalRole(),
        'x-bpm-tenant-id': tenantId,
        'x-bpm-external-ref-id': RulesConstants.X_BPM_EXTERNAL_REF_ID,
        'x-bpm-source': RulesConstants.X_BPM_SOURCE,
        'x-bpm-workflow': RulesConstants.X_BPM_WORKFLOW
      });
      const httpOptions = {
        headers: camundaHttpHeaders
      };
      const body = {
          hsc: {
              serviceType
          }
      };

      this.httpClient.post(environment.WORK_FLOW_STEPPER_DMN_URL, body, httpOptions).subscribe((data: any) => {
        if (data && data.length > 0) {
          this.stepperIds = data[0]['stepperIds'];
          this.stepperDataService.setStepperData({...this.stepperData, stepperIds: this.stepperIds});
          this.horizontalWizard = {
            id: 'linearHorizontalWizard',
            wizardSteps: this.getWizardSteps(this.stepperIds),
            nextBtn: {
              disabled: false,
              action: this.nextBtnAction,
              label: 'Next',
            },
            previousBtn: {
              disabled: false,
              action: this.preBtnAction,
              label: 'Previous',
            },
            finishBtn: {
              disabled: false,
              label: 'Submit',
              render: false,
            },
            cancelBtn: {
              disabled: false,
              action: this.cancelBtnAction,
              label: 'Exit Case',
            },
            isRenderNavIndexes: false,
          };
          // get Wizard steps keys as an array to allow for moving to specific step and complete it.
          this.wizardStepsKeys = Object.keys(this.horizontalWizard.wizardSteps);
        } else {
          console.log('getStepperIds(): The review type selected is missing associated stepperIDs. Please contact your system administrator.');
          this.showMissingStepperError();
        }
      },
        (error) => {
          if (error) {
            const errorData: any = error;
            console.log('getStepperIds(): The call to retrieve work flow stepperIDs failed. Please contact your system administrator. ', errorData);
            this.showMissingStepperError();
          }
        });
    });
  }
  preBtnAction = async () => {
    this.currentStep--;
    this.stepperDataService.setStepperData({...this.stepperData, currentStepId: this.currentStep});
    const stepperId = this.stepperIds[this.currentStep];
    const stepperLabel = this.stepperLabels.find((label) => label.id === stepperId);
    const variables = this.sendStepperSignalVariablesOnPrevious();
    const camundaHttpHeaders = new HttpHeaders({
      'Content-Type': CONTENT_TYPE_APPLICATION_JSON,
      'Accept': CONTENT_TYPE_APPLICATION_JSON,
      'Authorization': 'Bearer ' + this.userSessionService.getEcpToken(),
      'x-bpm-cli-org-id': this.userSessionService.getUserOrg(),
      'x-bpm-func-role': this.userSessionService.getFunctionalRole(),
      'x-bpm-tenant-id': this.stepperData.tenantId,
      'x-bpm-external-ref-id': '1234',
      'x-bpm-source': 'um_intake_ui',
      'x-bpm-workflow': 'Previous Stepper'
    });
    if (stepperLabel.label === this.DIAG_PROC_STEPPER) {
      await this.camundaSignalService.sendStepperSignaltoProc(this.caseId, camundaHttpHeaders, 'procedureNavigateAway', {});
    } else {
      this.camundaSignalService.sendStepperSignaltoBPM(this.caseId, camundaHttpHeaders, 'StepperSignal', variables);
    }
  }
  nextBtnAction = () => {
    const camundaHttpHeaders = new HttpHeaders({
      'Content-Type': CONTENT_TYPE_APPLICATION_JSON,
      'Accept': CONTENT_TYPE_APPLICATION_JSON,
      'Authorization': 'Bearer ' + this.userSessionService.getEcpToken(),
      'x-bpm-cli-org-id': this.userSessionService.getUserOrg(),
      'x-bpm-func-role': this.userSessionService.getFunctionalRole(),
      'x-bpm-tenant-id': this.stepperData.tenantId,
      'x-bpm-external-ref-id': '1234',
      'x-bpm-source': 'um_intake_ui',
      'x-bpm-workflow': 'Next Stepper'
    });
    const stepperId = this.stepperIds[this.currentStep - 1];
    const stepperLabel = this.stepperLabels.find((label) => label.id === stepperId);
    if (this.validationRequired && stepperLabel.label === this.CASE_TYPE_STEPPER) {
      // if on step 1, move to next step if form is valid.
     this.processAuthorizationType();
    } else if (this.validationRequired && stepperLabel.label === this.DIAG_PROC_STEPPER) {
        this.processDiagnosisAndProcedure();
    } else if (this.validationRequired && stepperLabel.label === this.DIAG_PROC_ANTICIPATED_SERVICE_STEPPER) {
      this.processDiagnosisProcedureAndAnticipatedServiceDateData();
    } else if (stepperLabel.label === this.CONTACT_STEPPER) {
      this.verifyContactDetails();
    } else if (this.validationRequired && stepperLabel.label === this.PROVIDER_STEPPER) {
      this.currentStep++;
      this.completeStep(this.wizardStepsKeys[this.currentStep - 2]);
      const variables = this.sendStepperSignalVariabletoBPM();
      this.camundaSignalService.sendStepperSignaltoBPM(this.caseId, camundaHttpHeaders,  'StepperSignal', variables);
    } else if (this.validationRequired && stepperLabel.label === this.DOCUMENTATION_STEPPER) {
     this.notesValidation();
    } else { // move to next step and complete previous
      this.currentStep++;
      this.completeStep(this.wizardStepsKeys[this.currentStep - 2]);
    }
    this.stepperDataService.setStepperData({...this.stepperData, currentStepId: this.currentStep});
    if (this.stepperData.hsc && this.stepperData.hsc?.hsc_sts_ref_id === ReferenceConstants.HSC_STATUS_TYPE_DRAFT) {
      this.enableSubmitButton();
    }
}
  cancelBtnAction = () => {
    this.exitDialogModal = true;
  }

  enableSubmitButton() {
  let allStepsCompleted = true;
  this.wizardStepsKeys.forEach((element) => {
    if (this.currentStep !== this.stepperIds.length && this.horizontalWizard.wizardSteps[element] && !this.horizontalWizard.wizardSteps[element].isComplete) {
      allStepsCompleted = false;
    }
  });
  this.horizontalWizard.finishBtn.render = allStepsCompleted;
}
  processAuthorizationType() {
      if (this.genericStepperComponent.authorizationTypeComponent.authorizationTypeForm.valid) {
      this.currentStep++;
      this.completeStep(this.wizardStepsKeys[this.currentStep - 2]);
      this.saveAuthorizationTypeData();
    } else {
      this.addAuthTypeErrorMessage();
    }
    }
  processDiagnosisAndProcedure() {
     if (this.stepperData.hscDiagnosis === undefined || (this.stepperData.hscDiagnosis && this.stepperData.hscDiagnosis.length === 0)) {
       this.addDiagnosisErrorMessage();
     }
     if (this.stepperData.hscProcedures === undefined || (this.stepperData.hscProcedures && this.stepperData.hscProcedures.length === 0)) {
       this.procedureServiceService.addErrorMessage();
     }
     this.updateToNextStep();
   }
   /*
   validates and saves 'Diagnoses/Procedures and Anticipated Service' stepper data
   */
  processDiagnosisProcedureAndAnticipatedServiceDateData() {
    if (this.genericStepperAnticipateServiceComponent?.anticipatedServiceComponent?.anticipateServiceForm?.valid) {
      // Mutation Fields
      const hsc_srvc_updateFields: ColumnValue[] = [
        { column: 'chg_user_id', value:  this.userSessionService.getUserName()},
        { column: 'expt_proc_dt', value: this.genericStepperAnticipateServiceComponent.anticipatedServiceComponent.anticipatedServiceDate}
      ];
      // Set return fields
      const returnFields = {
        fields: ['hsc_id', 'hsc_srvc_id', 'expt_proc_dt']
      };
      // Set where clause
      const hsc_srvc_updateFilterFields: WhereClause[] = [{
        field: 'hsc_id',
        predicate: Predicate.EQUAL,
        value: this.hscId,
        sqlOperator: SqlOperator.AND
      }];
      // call the mutation to save anticipatedServiceDate to hsc_srvc table
      this.healthGraphqlService.update('hsc_srvc', hsc_srvc_updateFields, hsc_srvc_updateFilterFields, returnFields).subscribe(
        (result) => {
          if (result.errors?.length > 0) {
            console.log('processDiagnosisProcedureAndAnticipatedServiceDateData(): ave anticipatedServiceDate error ', result.errors);
            this.showGenericSaveError();
          } else {
            this.genericSaveErrorAlert.visible = false;
            this.currentStep++;
            this.completeStep(this.wizardStepsKeys[this.currentStep - 2]);
          }
        },
        (error) => {
          const errorData: any = error;
          console.log('processDiagnosisProcedureAndAnticipatedServiceDateData(): save anticipatedServiceDate error ', errorData);
          this.showGenericSaveError();
        }
      );
    } else {
      this.addAuthTypeErrorMessage();
    }
  }

  processFilesAndAttachments() {
   // this.validateFiles();
    this.currentStep++;
    this.completeStep(this.wizardStepsKeys[this.currentStep - 2]);
    const variables = this.sendStepperSignalVariabletoBPM();
    const camundaHttpHeaders = new HttpHeaders({
      'Content-Type': CONTENT_TYPE_APPLICATION_JSON,
      'Accept': CONTENT_TYPE_APPLICATION_JSON,
      'Authorization': 'Bearer ' + this.userSessionService.getEcpToken(),
      'x-bpm-cli-org-id': this.userSessionService.getUserOrg(),
      'x-bpm-func-role': this.userSessionService.getFunctionalRole(),
      'x-bpm-tenant-id': this.stepperData.tenantId,
      'x-bpm-external-ref-id': '1234',
      'x-bpm-source': 'um_intake_ui',
      'x-bpm-workflow': 'Save Attachments'
    });
    this.camundaSignalService.sendStepperSignaltoBPM(this.caseId, camundaHttpHeaders, 'StepperSignal', variables);
  }

  notesValidation() {
    const subject = this.genericStepperNotes.notesComponent.noteForm.get('subject').value ? this.genericStepperNotes.notesComponent.noteForm.get('subject').value : null;
    if (this.genericStepperNotes.notesComponent.required && (this.genericStepperNotes.notesComponent.note === undefined || (this.genericStepperNotes.notesComponent.note && this.genericStepperNotes.notesComponent.note.length == 0))) {
      this.notesErrorMessage();
    } else {
      if (subject == null && this.genericStepperNotes.notesComponent.note && this.genericStepperNotes.notesComponent.note.length != 0) {
              this.notesErrorMessage();
      } else {
             this.processFilesAndAttachments();
      }
    }
  }

  async updateToNextStep(): Promise<any> {
    const hscDiags = this.stepperData.hscDiagnosis;
    const hscProcedures = this.stepperData.hscProcedures;
    if (hscDiags && hscProcedures && hscDiags.length > 0 && hscProcedures.length > 0) {
      this.currentStep++;
      const camundaHttpHeaders = new HttpHeaders({
        'Content-Type': CONTENT_TYPE_APPLICATION_JSON,
        'Accept': CONTENT_TYPE_APPLICATION_JSON,
        'Authorization': 'Bearer ' + this.userSessionService.getEcpToken(),
        'x-bpm-cli-org-id': this.userSessionService.getUserOrg(),
        'x-bpm-func-role': this.userSessionService.getFunctionalRole(),
        'x-bpm-tenant-id': this.stepperData.tenantId,
        'x-bpm-external-ref-id': '1234',
        'x-bpm-source': 'um_intake_ui',
        'x-bpm-workflow': 'Save Procedure and Diagonsis'
      });
      this.completeStep(this.wizardStepsKeys[this.currentStep - 2]);
      const variables = this.sendStepperSignalVariabletoBPM();
      await this.camundaSignalService.sendStepperSignaltoProc(this.caseId, camundaHttpHeaders, 'procedureNavigateAway', {});
      this.camundaSignalService.sendStepperSignaltoBPM(this.caseId, camundaHttpHeaders,  'StepperSignal', variables);
    }
  }
  showProcedureError() {
    this.errorProcAlert.visible = true;
    this.messageService.add(this.errorProcAlert);
  }

  notesErrorMessage() {
    this.authTypeErrorConfig.visible = true;
    this.messageService.add(this.authTypeErrorConfig);
  }

  showError() {
    this.errorAlert.visible = true;
    this.messageService.add(this.errorAlert);
  }

  showGenericSaveError() {
    this.genericSaveErrorAlert.visible = true;
    this.messageService.add(this.genericSaveErrorAlert);
  }

  showMissingStepperError() {
    this.genericSaveErrorAlert.visible = true;
    this.messageService.add(this.missingStepperAlert);
  }

  private sendStepperSignalVariablesOnPrevious() {
    const requestCategory = this.genericStepperComponent.authorizationTypeComponent.authorizationTypeForm.get('requestCategory').value.value;
    const facilityType = this.genericStepperComponent.authorizationTypeComponent.authorizationTypeForm.get('facilityType').value.value;
    const clinicalInformationRecieved = 'Yes';
    const admissionType = this.genericStepperComponent.authorizationTypeComponent.authorizationTypeForm.get('actualAdmissionDate') ? 'Notification' : ADVANCE_NOTIFICATION;
    const priority = this.genericStepperComponent.authorizationTypeComponent.authorizationTypeForm.get('priority').value.value;
    const notificationDate = new Date().toLocaleDateString();
    const serviceType = this.stepperData.serviceType;
    const caseType = this.genericStepperComponent.authorizationTypeComponent.authorizationTypeForm.get('requestCategory').value.id;

    const variables = {
      currentStep: {
        value: this.stepperIds[this.currentStep - 1]
      },
      completedStep: {
        value: this.stepperIds[this.currentStep - 2]
      },
      hsc: {
        value: { serviceType, caseType, requestCategory, facilityType, clinicalInformationRecieved,
                 admissionType, lineOfBusiness: this.lineOfBusiness, procedureCode: this.procedureCode, networkStatus: this.networkStatus,
                 stateOfIssue: this.stateOfIssue, priority, tatPeriodType: this.tatPeriodType, tatCategoryType: this.tatCategoryType, triggerTatPointType: this.triggerTatPointType,
                 notificationDate, hsc_key_val: this.caseId }
      }
    };
    return variables;
  }

  private sendFlagToSaveAuthType() {
    const requestCategory = this.genericStepperComponent.authorizationTypeComponent.authorizationTypeForm.get('requestCategory').value.value;
    const facilityType = this.genericStepperComponent.authorizationTypeComponent.authorizationTypeForm.get('facilityType').value.value;
    const clinicalInformationRecieved = 'Yes';
    const admissionType = this.genericStepperComponent.authorizationTypeComponent.authorizationTypeForm.get('actualAdmissionDate') ? 'Notification' : ADVANCE_NOTIFICATION;
    const priority = this.genericStepperComponent.authorizationTypeComponent.authorizationTypeForm.get('priority').value.value;
    const notificationDate = new Date().toLocaleDateString();
    if (!(this.completedStepIds.includes(this.stepperIds[this.currentStep - 2]))) {
      this.completedStepIds.push(this.stepperIds[this.currentStep - 2]);
    }
    const serviceType = this.stepperData.serviceType;
    const caseType = this.genericStepperComponent.authorizationTypeComponent.authorizationTypeForm.get('requestCategory').value.id;

    const variables = {
        hsc: {
          value: {
            serviceType, caseType, requestCategory, facilityType, clinicalInformationRecieved,
            admissionType, lineOfBusiness: this.lineOfBusiness, procedureCode: this.procedureCode, networkStatus: this.networkStatus,
            stateOfIssue: this.stateOfIssue, priority, tatPeriodType: this.tatPeriodType, tatCategoryType: this.tatCategoryType, triggerTatPointType: this.triggerTatPointType,
            notificationDate, hsc_key_val: this.caseId, hsc_id: this.hscId, orgId: this.clientId
          }
        },
        currentStep: {
          value: this.stepperIds[this.currentStep - 2]
        },
        completedStep: {
          value: this.stepperIds[this.currentStep - 2]
        },
        completedStepIds: {
          value: this.completedStepIds
        }
    };
    return variables;
  }

  private sendStepperSignalVariabletoBPM() {
    const requestCategory = this.genericStepperComponent.authorizationTypeComponent.authorizationTypeForm.get('requestCategory').value.value;
    const facilityType = this.genericStepperComponent.authorizationTypeComponent.authorizationTypeForm.get('facilityType').value.value;
    const clinicalInformationRecieved = 'Yes';
    const admissionType = this.genericStepperComponent.authorizationTypeComponent.authorizationTypeForm.get('actualAdmissionDate') ? 'Notification' : ADVANCE_NOTIFICATION;
    const priority = this.genericStepperComponent.authorizationTypeComponent.authorizationTypeForm.get('priority').value.value;
    const notificationDate = new Date();
    if (!(this.completedStepIds.includes(this.stepperIds[this.currentStep - 2]))) {
    this.completedStepIds.push(this.stepperIds[this.currentStep - 2]);
    }
    const serviceType = this.stepperData.serviceType;
    const caseType = this.genericStepperComponent.authorizationTypeComponent.authorizationTypeForm.get('requestCategory').value.id;

    const variables =  {
      currentStep: {
        value: this.stepperIds[this.currentStep - 1]
      },
      completedStep: {
        value: this.stepperIds[this.currentStep - 2]
      },
      completedStepIds: {
        value: this.completedStepIds
      },
      hsc: {
        value: { serviceType, caseType, requestCategory, facilityType, clinicalInformationRecieved,
                 admissionType, lineOfBusiness: this.lineOfBusiness, procedureCode: this.procedureCode, networkStatus: this.networkStatus,
                 stateOfIssue: this.stateOfIssue, priority, tatPeriodType: this.tatPeriodType, tatCategoryType: this.tatCategoryType, triggerTatPointType: this.triggerTatPointType,
                 notificationDate, hsc_key_val: this.caseId, hsc_id: this.hscId, orgId: this.clientId }
      }
    };
    return variables;
  }

  draftORopenCaseStepStatus() {
    const camundaHttpHeaders = new HttpHeaders({
      'Content-Type': CONTENT_TYPE_APPLICATION_JSON,
      'Accept': CONTENT_TYPE_APPLICATION_JSON,
      'Authorization': 'Bearer ' + this.userSessionService.getEcpToken(),
      'x-bpm-cli-org-id': this.userSessionService.getUserOrg(),
      'x-bpm-func-role': this.userSessionService.getFunctionalRole(),
      'x-bpm-tenant-id': this.stepperData.tenantId,
      'x-bpm-external-ref-id': '1234',
      'x-bpm-source': 'um_intake_ui',
      'x-bpm-workflow': 'Draft Case Open'
    });
    this.httpClient.get(environment.PROCESS_INSTANCE_BASE_URL + '?superProcessInstance=' + this.existingCaseId, {
      headers: camundaHttpHeaders
      }).subscribe((data: any) => {
        const processInstanceId = data[0].id;
        this.httpClient.get(`${environment.PROCESS_INSTANCE_BASE_URL}${processInstanceId}/variables/completedStepIds`, {
          headers: camundaHttpHeaders
        }).subscribe((res: any) => {
          this.completedStepIds = res.value;
          if (this.completedStepIds.length > 0) {
            this.completedStepIds.forEach((stepId, index) => {
                const step = 'step' + (index + 1);
                this.horizontalWizard.wizardSteps[step].isComplete = true;
            });
          }
      });
    });
  }

  addDiagnosisErrorMessage() {
    this.errorConfigDiag.visible = true;
    this.messageService.add(this.errorConfigDiag);
  }

  handlePreviousBtnDisabled(event) {
    switch (event.currentStep.index) {
      case (1):
        this.horizontalWizard.nextBtn.disabled = false;
        break;
      case (2):
        this.horizontalWizard.previousBtn.disabled = false;
        break;
      case (3):
        this.horizontalWizard.previousBtn.disabled = false;
        break;
      case (4):
        this.horizontalWizard.previousBtn.disabled = false;
        break;
      case (5):
        this.horizontalWizard.previousBtn.disabled = false;
        break;
    }
  }

  handleNextBtnDisabled(event) {
    switch (event.currentStep.index) {
      case (1):
        this.horizontalWizard.nextBtn.disabled = false;
        break;
      case (2):
        this.horizontalWizard.nextBtn.disabled = false;
        break;
      case (3):
        this.horizontalWizard.nextBtn.disabled = false;
        break;
      case (4):
        this.horizontalWizard.nextBtn.disabled = false;
        break;
      case (5):
        this.horizontalWizard.nextBtn.disabled = false;
        break;
    }
  }

  nextBtnCallback(event) {
    this.currentStep = event.currentStep.index;
    this.stepperDataService.setStepperData({...this.stepperData, currentStep: this.currentStep});
    this.handlePreviousBtnDisabled(event);
    this.handleNextBtnDisabled(event);
  }

  previousBtnCallback(event) {
    this.currentStep = event.currentStep.index;
    this.stepperDataService.setStepperData({...this.stepperData, currentStep: this.currentStep});
    this.handlePreviousBtnDisabled(event);
    this.handleNextBtnDisabled(event);
  }

  finishBtnCallback(event) {
    this.stepperDataService.setStepperData({...this.stepperData, hscID: this.hscId});
    this.horizontalWizard.isWizardCompleted = true;
    this.completeStep(event.currentStep.key);
    this.currentStep++;
    this.stepperDataService.setStepperData({...this.stepperData, currentStep: this.currentStep});
    const submitHsc = {
      hsc_id: this.hscId,
      caseId: this.caseId,
      variables: this.sendStepperSignalVariabletoBPM()
    };
    this.umIntakeFuncGraphqlService.submitHsc(submitHsc).subscribe(
      (result) => {
        this.stepperDataService.setStepperData({...this.stepperData, hsc: {...this.stepperData.hsc, hsc_sts_ref_id: result.data.submitHsc.hsc_sts_ref_id}, showConfirmation: true});
      },
      (error) => {
        const errorData: any = error;
      }
    );
  }
  /*
  cancelBtnCallback(event) {
  }
  */
  stepHeaderCallback(event) {
    this.currentStep = event.currentStep.index;
    this.stepperDataService.setStepperData({...this.stepperData, currentStep: this.currentStep});
    this.handlePreviousBtnDisabled(event);
    this.handleNextBtnDisabled(event);
  }

  completeStep(key) {
    if (this.horizontalWizard.wizardSteps[key]) {
      this.horizontalWizard.wizardSteps[key].isComplete = true;
    }
  }

  async saveAuthorizationTypeData() {
    const authorizationTypeForm = this.genericStepperComponent.authorizationTypeComponent.authorizationTypeForm;
    const hsc = this.getHsc();
    const hsc_facl = this.getHscFacl();
    const hsc_srvc_non_facl = this.getHscSrvcNonFacl();
    const caseId = this.caseId;
    const variables = this.sendFlagToSaveAuthType();
    this.stepperDataService.setStepperData({...this.stepperData, hsc, hscFacl: hsc_facl, hscSrvcNonFacl: hsc_srvc_non_facl, authorizationTypeForm});
    this.providerSearchService.setProviderRoles();
    const saveAuth = {
      variables,
      caseId,
      hsc,
      hsc_srvc: {
        hsc_srvc_id: this.hscSrvcId,
        hsc_id: this.hscId,
      },
      hsc_srvc_non_facl,
      hsc_facl
    };
      this.umIntakeFuncGraphqlService.saveAuthTypeHttp(saveAuth).subscribe(async (data: any) => {
      this.hscSrvcId = data.hsc_srvc_id;
      this.stepperDataService.setStepperData({...this.stepperData, hscSrvcId: this.hscSrvcId, hscDuplicates: data.data.saveAuthType.hscDuplicates});
      const modifications = this.sendStepperSignalVariabletoBPM();
      const camundaHttpHeaders = new HttpHeaders({
          'Content-Type': CONTENT_TYPE_APPLICATION_JSON,
          'Accept': CONTENT_TYPE_APPLICATION_JSON,
          'Authorization': 'Bearer ' + this.userSessionService.getEcpToken(),
          'x-bpm-cli-org-id': this.userSessionService.getUserOrg(),
          'x-bpm-func-role': this.userSessionService.getFunctionalRole(),
          'x-bpm-tenant-id': this.stepperData.tenantId,
          'x-bpm-external-ref-id': '1234',
          'x-bpm-source': 'um_intake_ui',
          'x-bpm-workflow': 'Save Procedure and Diagonsis'
        });
      // this.camundaSignalService.sendFlagToDiagProc(this.caseId, camundaHttpHeaders, modifications);
      this.camundaSignalService.sendStepperSignaltoBPM(this.caseId, camundaHttpHeaders, 'StepperSignal', modifications);
        },
      (error) => {
        if (error) {
          this.showSaveAuthError();
        }
      });
  }

  private getHscFacl() {
    const authTypeForm = this.genericStepperComponent.authorizationTypeComponent.authorizationTypeForm;
    return {
      hsc_id: this.hscId,
      plsrv_ref_id: authTypeForm.get('facilityType').value ? authTypeForm.get('facilityType').value.id : null,
      srvc_desc_ref_id: authTypeForm.get('serviceDescription').value ? authTypeForm.get('serviceDescription').value.id : null,
      srvc_dtl_ref_id: this.getSrvcDtlRefId(authTypeForm),
      actul_admis_dttm: authTypeForm.get('requestCategory').value.id === this.OUTPATIENTFACILITY_REF_CD ?
        authTypeForm.get('startDate') ? authTypeForm.get('startDate').value : null :
        authTypeForm.get('actualAdmissionDate') ? authTypeForm.get('actualAdmissionDate').value : null,
      actul_dschrg_dttm: authTypeForm.get('requestCategory').value.id === this.OUTPATIENTFACILITY_REF_CD ?
        authTypeForm.get('endDate') ? authTypeForm.get('endDate').value : null :
        authTypeForm.get('actualDischargeDate') ? authTypeForm.get('actualDischargeDate').value : null,
      expt_admis_dt: authTypeForm.get('expectedAdmissionDate') ? authTypeForm.get('expectedAdmissionDate').value : null,
      expt_dschrg_dt: authTypeForm.get('expectedDischargeDate') ? authTypeForm.get('expectedDischargeDate').value : null,
    };
  }

  private getSrvcDtlRefId(authTypeForm) {
    return authTypeForm.get('requestCategory').value.id !== this.OUTPATIENT_REF_CD ?
      authTypeForm.get('serviceDetail').value ? authTypeForm.get('serviceDetail').value.id : null : null;
  }

  private getHsc() {
    const authTypeForm = this.genericStepperComponent.authorizationTypeComponent.authorizationTypeForm;
    let dupJustificationRefId = '';
    let dupJustificationRefNm = '';
    let dupJustificationTxt = '';

    if (document.getElementById('duplicateRequestReason')) {
      const e = (document.getElementById('duplicateRequestReason')) as HTMLSelectElement;
      dupJustificationRefId = this.justificationReasonTypes[e.selectedIndex - 1].id;
      dupJustificationRefNm = this.justificationReasonTypes[e.selectedIndex - 1].label;
      dupJustificationTxt = this.myValue;
    }
    const hscDuplicatesIDs = [];

    if (this.stepperData.hscDuplicates && this.stepperData.hscDuplicates.length > 0) {
      this.stepperData.hscDuplicates.forEach(function (value) {
        hscDuplicatesIDs.push(value.hsc_id);
      });
    }
    return {
      indv_id: this.selectedMember.indv_id,
      hsc_id: this.hscId,
      srvc_set_ref_id: authTypeForm.get('requestCategory').value ? authTypeForm.get('requestCategory').value.id : null,
      rev_prr_ref_id: authTypeForm.get('priority').value ? authTypeForm.get('priority').value.id : null,
      hsc_sts_ref_id: ReferenceConstants.HSC_STATUS_TYPE_DRAFT,
      data_qlty_iss_list: {
        dupHSCInfo: {
          dupHSCIds: hscDuplicatesIDs,
          dupJustificationRefId: dupJustificationRefId,
          dupJustificationRefNm: dupJustificationRefNm,
          dupJustificationTxt: dupJustificationTxt
        }
      }

    };
  }
  private getHscSrvcNonFacl() {
    const authTypeForm = this.genericStepperComponent.authorizationTypeComponent.authorizationTypeForm;
    return  {
      hsc_srvc_id: this.hscSrvcId,
      plsrv_ref_id: authTypeForm.get('facilityType').value ? authTypeForm.get('facilityType').value.id : null,
      srvc_desc_ref_id: authTypeForm.get('serviceDescription').value ? authTypeForm.get('serviceDescription').value.id : null
    };
  }

  verifyContactDetails() {
    if (!this.genericStepperIntialContact.intialContactComponent.showSecondaryContact) {
      if (this.genericStepperIntialContact.intialContactComponent.intialContactForm.valid) {
        this.currentStep++;
        this.completeStep(this.wizardStepsKeys[this.currentStep - 2]);
        this.saveContactDetails();
      } else {
        this.intialContactErrorMessage();
      }
    } else {
      if (this.genericStepperIntialContact.intialContactComponent.intialContactForm.valid
        && this.genericStepperIntialContact.intialContactComponent.followContactForm.valid) {
        this.currentStep++;
        this.completeStep(this.wizardStepsKeys[this.currentStep - 2]);
        this.saveContactDetails();
      } else {
        this.intialContactErrorMessage();
      }
    }
  }
  saveContactDetails() {
    const intialContactForm = this.genericStepperIntialContact.intialContactComponent.intialContactForm;
    const followContactForm = this.genericStepperIntialContact.intialContactComponent.followContactForm;
    const secondary_cntct = 'secondary_cntct';
    const httpOptions = {
      headers: this.camundaHttpHeaders
    };
    const userObj = {
      creat_user_id: this.userSessionService.getUserName(),
      chg_user_id: this.userSessionService.getUserName()
    };
    const body = {
      caseId: this.caseId,
      variables: this.sendStepperSignalVariabletoBPM(),
      hsc_id: this.hscId,
      flwup_cntc_dtl: {
        primary_cntct: {
          name: intialContactForm.get('name').value,
          role: intialContactForm.get('role').value ? intialContactForm.get('role').value.value : null,
          department: intialContactForm.get('department').value ? intialContactForm.get('department').value.value : null,
          phone: intialContactForm.get('phone').value,
          fax: intialContactForm.get('fax').value ? intialContactForm.get('fax').value : null,
          email: intialContactForm.get('email').value ? intialContactForm.get('email').value : null
        }
      }
    };
    if (this.genericStepperIntialContact.intialContactComponent.showSecondaryContact) {
      body.flwup_cntc_dtl[secondary_cntct] = {
        inac_ind: 1,
        name: followContactForm.get('followName').value,
        role: followContactForm.get('followRole').value ? followContactForm.get('followRole').value.value : null,
        department: followContactForm.get('followDepartment').value ? followContactForm.get('followDepartment').value.value : null,
        phone: followContactForm.get('followPhone').value,
        fax: followContactForm.get('followFax').value ? followContactForm.get('followFax').value : null,
        email: followContactForm.get('followEmail').value ? followContactForm.get('followEmail').value : null,
      };
    }
    this.stepperDataService.setStepperData({...this.stepperData, hscContact: body.flwup_cntc_dtl});
    this.umIntakeFuncGraphqlService.saveContactMutation(body).subscribe((data: any) => { },
      (error) => {
        if (error) {
          this.showContactDetailsError();
        }
      });
  }

  showSaveAuthError() {
    this.saveAuthErrorAlert.visible = true;
    this.messageService.add(this.saveAuthErrorAlert);
  }

  addAuthTypeErrorMessage() {
    this.authTypeErrorConfig.visible = true;
    this.messageService.add(this.authTypeErrorConfig);
  }

  showContactDetailsError() {
    this.saveContactDetailsAlert.visible = true;
    this.messageService.add(this.saveContactDetailsAlert);
  }

  intialContactErrorMessage() {
    this.intialContactErrorConfig.visible = true;
    this.messageService.add(this.intialContactErrorConfig);
  }

  intakeCurStepperUpdateEvent($event) {
    this.currentStepUpdate = $event;
    this.currentStep = this.currentStepUpdate;
    this.stepperDataService.setStepperData({...this.stepperData, currentStep: this.currentStep});
  }

  validateFiles() {
      this.files =  this.genericStepperfiles.clinicalInformationComponent.files;
      if (this.files.length > 0) {
               this.files.forEach((file) => {
                 if (file.status == 'Ready to Upload') {
                   this.normalDialogModal = true;
                 }
             });
         }
  }

  deleteFile() {
          for (let i = 0; i < this.files.length; i = 0) {
                 this.fileUploadService.setFiles(this.files[i]);
                 this.genericStepperfiles.clinicalInformationComponent.deleteFile();

          }
          this.normalDialogModal = false;
  }
  uploadFiles() {
    this.genericStepperfiles.clinicalInformationComponent.submit();
    this.normalDialogModal = false;
  }

  saveCase() {
    const authTypeForm = this.genericStepperComponent.authorizationTypeComponent.authorizationTypeForm;
    const stepperId = this.stepperIds[this.genericStepperComponent.stepNumber];
    const stepperLabel = this.stepperLabels.find((label) => label.id === stepperId);
    if (stepperLabel.label === this.CASE_TYPE_STEPPER && authTypeForm.get('requestCategory').value !== null) {
      // if on step 1, move to next step if form is valid.
      this.saveAuthorizationTypeData();
    } else {
      if (stepperLabel.label === this.CONTACT_STEPPER) {
            this.saveContactDetails();
          }
    }
    this.exitDialogModal = false;
    this.router.navigateByUrl('/um');
  }

  discardCase() {
    this.authAddService.executeAuthorizationMutation(ReferenceConstants.HSC_STATUS_TYPE_DISCARDED);
    this.files =  this.genericStepperfiles.clinicalInformationComponent.files;
    this.deleteFile();
    this.exitDialogModal = false;
    this.router.navigateByUrl('/um');
  }

  showDuplicateDialog() {
    this.duplicateDialogModal = true;
    this.duplicateCaseCurrentIndex = 0;
  }

  showDuplicateJustificationDialog() {
    this.duplicateJustificationDialogModal = true;
  }

  saveDuplicateRequestJustification() {
    this.saveAuthorizationTypeData();
    this.myValue = '';
    this.hideDuplicateJustificationDialog();
  }

  hideDuplicateJustificationDialog() {
    this.duplicateJustificationDialogModal = false;
  }
  previousAction() {
    if (this.duplicateCaseCurrentIndex > 0) {
      this.duplicateCaseCurrentIndex--;
    }
  }

  nextAction() {
    if (this.duplicateCaseCurrentIndex < this.stepperData.hscDuplicates.length - 1) {
      this.duplicateCaseCurrentIndex++;
    }
  }
}
