// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { IqSearchComponent } from './iq-search.component';

// describe('IqSearchComponent', () => {
//   let component: IqSearchComponent;
//   let fixture: ComponentFixture<IqSearchComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ IqSearchComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(IqSearchComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
