import { Component, OnInit } from '@angular/core';
import { InterQualReviewRequest } from 'src/app/services/interqual/interqual.model';
import { OutboundSsoService } from 'src/app/services/outbound-sso-service/outbound-sso.service';

@Component({
  selector: 'um-iq-search',
  templateUrl: './iq-search.component.html',
  styleUrls: ['./iq-search.component.scss']
})
export class IqSearchComponent implements OnInit {
  public reviewId: string;
  public procedureCode: string;

  constructor(private outBoundSSOService: OutboundSsoService) { }

  ngOnInit(): void {}

  ssoToIQ(procedureCode: string, reviewId: string) {
    InterQualReviewRequest.procedureCode = procedureCode;
    InterQualReviewRequest.reviewId = reviewId;
    this.outBoundSSOService.ssoToIQ();
  }
}
