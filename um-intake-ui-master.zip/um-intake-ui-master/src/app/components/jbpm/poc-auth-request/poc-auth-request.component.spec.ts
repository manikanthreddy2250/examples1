/*import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { PocAuthRequestComponent } from './poc-auth-request.component';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { uitkModules } from 'src/app/app.module';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { RouterTestingModule } from '@angular/router/testing';

describe('PocAuthRequestComponent', () => {
   let component: PocAuthRequestComponent;
   let fixture: ComponentFixture<PocAuthRequestComponent>;

   beforeEach(async(() => {
     TestBed.configureTestingModule({
       imports: [uitkModules,HttpClientTestingModule,RouterTestingModule.withRoutes([])],
       declarations: [ PocAuthRequestComponent ],
       schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
     })
     .compileComponents();
   }));

   beforeEach(() => {
     fixture = TestBed.createComponent(PocAuthRequestComponent);
     component = fixture.componentInstance;
     fixture.detectChanges();
   });

   it('should create', () => {
    expect(component).toBeTruthy();
   });

   it('should submit auth request', () => {
        component.submitAuthRequest();
        expect(component.submitAuthRequest).toBeTruthy();
       });

   it('should validate  Show Success', () => {
       component.showSuccess ();
       expect(component.showSuccess).toBeTruthy();
      });

   it('should validate  Show Error', () => {
       component.showError();
       expect(component.showError).toBeTruthy();
      });

});
*/