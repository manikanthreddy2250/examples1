import { HttpClient, HttpClientModule, HttpHeaders, HttpParams} from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'um-poc-auth-request',
  templateUrl: './poc-auth-request.component.html',
  styleUrls: ['./poc-auth-request.component.scss']
})
export class PocAuthRequestComponent implements OnInit {
  caseId = null;
  ownersURL = 'https://dev-ecp-api.optum.com/kie-server/services/rest/server/queries/tasks/instances/pot-owners';
  caseMilestoneURL = 'https://dev-ecp-api.optum.com/kie-server/services/rest/server/containers/AuthorizationRequest_1.0.0-SNAPSHOT/cases/AuthorizationRequest.Milestones/instances';
  baseURL = 'https://dev-ecp-api.optum.com/kie-server/services/rest/server/containers/';
  httpHeaders = new HttpHeaders({
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'Authorization': 'Basic ' + btoa('wbadmin:wbadmin')
  });
  successAlert = {
    id: 'success_msg',
    messageType: 'success',
    content: 'Success New Case id got created.Go Back to the Homepage.',
    visible: false,
    closeButton: true,
  };

  errorAlert = {
    id: 'error_msg',
    messageType: 'error',
    content: 'Error. Request failed.',
    visible: false,
    closeButton: true,
  };
  constructor(private readonly router: Router, private readonly httpClient: HttpClient) { }
  body = {
  };
  ngOnInit() {}
  submitAuthRequest = () => {
    const httpOptions = {
      headers: this.httpHeaders
    };
    const parameters = new HttpParams({
      fromObject: {
        status: 'Ready',
        groups: 'clinician'
      }
    });

    const options = {
      headers: this.httpHeaders,
      params: parameters
    };
    // this.httpClient.post(this.caseMilestoneURL, this.body, httpOptions).subscribe((data) => {
    //   if (data) {
    //     this.caseId = data;
    //     this.httpClient
    //       .get(this.ownersURL, options)
    //       .pipe()
    //       .subscribe((data) => {
    //         const containerId = data['task-summary'][0]['task-container-id'];
    //         const taskInstanceId = data['task-summary'][0]['task-id'];
    //         let url = this.baseURL + `${containerId}/tasks/${taskInstanceId}/states/claimed`;
    //         this.httpClient
    //           .put(url, '', httpOptions)
    //           .pipe()
    //           .subscribe((result) => {
    //             url = this.baseURL + `${containerId}/tasks/${taskInstanceId}/states/started`;
    //             this.httpClient
    //               .put(url, '', httpOptions)
    //               .pipe()
    //               .subscribe((result) => {
    //                 url = this.baseURL + `${containerId}/tasks/${taskInstanceId}/states/completed`;
    //                 this.httpClient
    //                   .put(url, '', httpOptions)
    //                   .pipe()
    //                   .subscribe((result) => {
    //                     console.log(result);
    //                   });
    //               });
    //           });
    //
    //         this.showSuccess();
    //       });
    //   } else {
    //     this.showError();
    //   }
    // });
  }

  showSuccess = () => {
    // this.successAlert.visible = true;
    this.router.navigate(['um/workqueue/dashboard']);
  }

  showError() {
    this.errorAlert.visible = true;
  }
}
