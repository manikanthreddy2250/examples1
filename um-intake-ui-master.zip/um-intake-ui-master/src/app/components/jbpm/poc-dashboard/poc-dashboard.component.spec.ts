/*
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { PocDashboardComponent } from './poc-dashboard.component';
import { Component, OnInit,Input } from '@angular/core';
import { Router } from '@angular/router';
import { uitkModules } from 'src/app/app.module';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('PocDashboardComponent', () => {
   let component: PocDashboardComponent;
   let fixture: ComponentFixture<PocDashboardComponent>;

   beforeEach(async(() => {
     TestBed.configureTestingModule({
	   imports: [uitkModules,HttpClientTestingModule],
       declarations: [ PocDashboardComponent ]
     })
     .compileComponents();
   }));

   beforeEach(() => {
     fixture = TestBed.createComponent(PocDashboardComponent);
     component = fixture.componentInstance;
     fixture.detectChanges();
   });

   it('should create', () => {
     expect(component).toBeTruthy();
   });

   it('should validate  On Row Select', () => {
   	const row =  2 ;
          component.onRowSelect(row);
          expect(component.onRowSelect).toBeTruthy();
    });

});
*/