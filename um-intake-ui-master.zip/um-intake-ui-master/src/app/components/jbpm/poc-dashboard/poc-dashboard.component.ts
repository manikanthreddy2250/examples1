import {Component, Input, OnInit} from '@angular/core';
import {Router} from '@angular/router';

@Component({
  selector: 'um-poc-dashboard',
  templateUrl: './poc-dashboard.component.html',
  styleUrls: ['./poc-dashboard.component.scss']
})
export class PocDashboardComponent implements OnInit {

  loadingData: boolean;
  records = [];

  columns: any = [
    { label: 'Lists', id: 'workQueueName', dataType: 'text',
      style: { fontWeight: 'bold', borderRight: '0px' }},
  ];

  modelFour = {
    title: 'Work Queue Table',
    enableSorting: false,
    enableFiltering: false,
    enableSingleRowSelect: true,
    clearAllFilters: true,
    caseSensitiveFilter: true,
    fixedHeader: true,
    filterCondition: {
      columnSorting: {
        columnId: 'workQueueName',
        dataType: String,
        sortOrder: 1,
      },
    },
  };

  constructor(private readonly router: Router) { }

  ngOnInit() {
    this.getTestData();
  }

  onRowSelect(row: any) {
    localStorage.setItem('state', row.queueName.toString());
    this.router.navigate(['/um/workqueue/list']);

  }

  getTestData(): void {
    this.loadingData = true;
    const data = [{queueName: 'Work Queue List'}];
    this.records = data;
    this.loadingData = false;
  }
}
