/*import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { PocMdFormComponent } from './poc-md-form.component';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { uitkModules,uitkAngularModules } from 'src/app/app.module';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormsModule, FormGroup, FormBuilder,FormControl,ReactiveFormsModule } from '@angular/forms';

describe('PocMdFormComponent', () => {
   let component: PocMdFormComponent;
   let fixture: ComponentFixture<PocMdFormComponent>;

   beforeEach(async(() => {
     TestBed.configureTestingModule({
	      imports: [uitkModules,uitkAngularModules,HttpClientTestingModule,FormsModule,ReactiveFormsModule],
        declarations: [ PocMdFormComponent ],
	      providers : [HttpClient]
     })
     .compileComponents();
   }));

   beforeEach(() => {
     fixture = TestBed.createComponent(PocMdFormComponent);
     component = fixture.componentInstance;
     fixture.detectChanges();
   });

   it('should create', () => {
     expect(component).toBeTruthy();
   });

   it('should run #ngOnInit()', async () => {
       component.ngOnInit();
   });

  it('should validate  Submit Review Request ', () => {
          let taskInstanceId = 12;
           let containerId = 11;
           let url = "text12";
          component.submitReviewRequest ();
          expect(component.submitReviewRequest ).toBeTruthy();
   });

});
*/