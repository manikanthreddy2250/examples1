import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {FormControl, FormGroup} from "@angular/forms";
@Component({
  selector: 'um-poc-md-form',
  templateUrl: './poc-md-form.component.html',
  styleUrls: ['./poc-md-form.component.scss']
})
export class PocMdFormComponent implements OnInit {
  httpHeaders = new HttpHeaders({
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'Authorization': 'Basic ' + btoa('krisv:krisv')
  });
  baseURL = `https://dev-ecp-api.optum.com/umautorouting/engine-rest/task/`;
  constructor(private readonly router: Router, private readonly httpClient: HttpClient) {
    this.decisionOptions = [
    {
      label: 'Approved',
      value: '1'

    }, {
      label: 'Not Approved',
      value: '2'

    }
  ];
  }
  public decision: any;
  public decisionOptions: any;
  public decisionForm = new FormGroup({
    decision: new FormControl('')
  });

  ngOnInit() {}
  submitReviewRequest = () => {
    const taskInstanceId = history.state.id;
    const options = {
      headers: this.httpHeaders
    };
    let url = this.baseURL + `${taskInstanceId}/claim`;
    this.httpClient
      .post(url, '', options)
      .pipe()
      .subscribe((result) => {
        url = this.baseURL + `${taskInstanceId}/complete`;
        this.httpClient
          .post(url, '{"variables":{"decisionOutcome": {"value": "' + this.decision.value + '"}}}', options)
          .pipe()
          .subscribe((result) => {
            this.router.navigate(['um/workqueue/dashboard']);
          });
      });
  }
}
