/*import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { PocQualityFormComponent } from './poc-quality-form.component';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { uitkModules } from 'src/app/app.module';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormsModule, FormGroup, FormBuilder,FormControl,ReactiveFormsModule } from '@angular/forms';

describe('PocQualityFormComponent', () => {
   let component: PocQualityFormComponent;
   let fixture: ComponentFixture<PocQualityFormComponent>;

   beforeEach(async(() => {
     TestBed.configureTestingModule({
	  imports: [uitkModules,HttpClientTestingModule,FormsModule,ReactiveFormsModule],
       declarations: [ PocQualityFormComponent ],
	    providers : [HttpClient]
     })
     .compileComponents();
   }));

   beforeEach(() => {
     fixture = TestBed.createComponent(PocQualityFormComponent);
     component = fixture.componentInstance;
                let taskInstanceId = 12;
                let containerId = 11;
                let url = "text12";
     fixture.detectChanges();
   });

   it('should create', () => {
     expect(component).toBeTruthy();
   });

   it('should validate  Submit Review Request ', () => {
          component.submitQualityRequest();
          expect(component.submitQualityRequest).toBeTruthy();
   });

});
*/