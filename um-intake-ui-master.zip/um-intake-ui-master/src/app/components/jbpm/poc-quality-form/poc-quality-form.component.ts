import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
@Component({
  selector: 'um-poc-quality-form',
  templateUrl: './poc-quality-form.component.html',
  styleUrls: ['./poc-quality-form.component.scss']
})
export class PocQualityFormComponent implements OnInit {
  httpHeaders = new HttpHeaders({
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'Authorization': 'Basic ' + btoa('wbadmin:wbadmin')
  });

  baseURL = `https://dev-ecp-api.optum.com/kie-server/services/rest/server/containers/`;
  constructor(private readonly router: Router, private readonly httpClient: HttpClient) {}

  ngOnInit() {
  }

  submitQualityRequest = () => {
    const containerId = history.state['task-container-id'];
    const taskInstanceId = history.state.taskid;
    const options = {
      headers: this.httpHeaders
    };
    let url = this.baseURL + `${containerId}/tasks/${taskInstanceId}/states/claimed`;
    this.httpClient
      .put(url, '', options)
      .pipe()
      .subscribe((result) => {
        url = this.baseURL + `${containerId}/tasks/${taskInstanceId}/states/started`;
        this.httpClient
          .put(url, '', options)
          .pipe()
          .subscribe(result => {
            url = this.baseURL + `${containerId}/tasks/${taskInstanceId}/states/completed`;
            this.httpClient
              .put(url, '', options)
              .pipe()
              .subscribe(result => {
                this.router.navigate(['um/workqueue/dashboard']);
              });
          });
      });
  }

}
