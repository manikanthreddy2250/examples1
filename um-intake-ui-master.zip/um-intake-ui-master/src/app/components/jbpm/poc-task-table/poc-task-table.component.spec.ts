/*import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Pipe, PipeTransform, Injectable, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA, Directive, Input, Output } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { Observable, of as observableOf, throwError } from 'rxjs';
import { Component } from '@angular/core';
import { PocTaskTableComponent } from './poc-task-table.component';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Injectable()
class MockRouter {
  navigate() {};
}

@Injectable()
class MockHttpClient {
  post() {};
}

@Directive({ selector: '[oneviewPermitted]' })
class OneviewPermittedDirective {
  @Input() oneviewPermitted;
}

@Pipe({name: 'translate'})
class TranslatePipe implements PipeTransform {
  transform(value) { return value; }
}

@Pipe({name: 'phoneNumber'})
class PhoneNumberPipe implements PipeTransform {
  transform(value) { return value; }
}

@Pipe({name: 'safeHtml'})
class SafeHtmlPipe implements PipeTransform {
  transform(value) { return value; }
}

describe('PocTaskTableComponent', () => {
  let fixture;
  let component;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ FormsModule, ReactiveFormsModule ],
      declarations: [
        PocTaskTableComponent,
        TranslatePipe, PhoneNumberPipe, SafeHtmlPipe,
        OneviewPermittedDirective
      ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA ],
      providers: [
        { provide: Router, useClass: MockRouter },
        { provide: HttpClient, useClass: MockHttpClient }
      ]
    }).overrideComponent(PocTaskTableComponent, {

    }).compileComponents();
    fixture = TestBed.createComponent(PocTaskTableComponent);
    component = fixture.debugElement.componentInstance;
  });

  afterEach(() => {
    component.ngOnDestroy = function() {};
    fixture.destroy();
  });

  it('should create', async () => {
    expect(component).toBeTruthy();
  });

  it('should onRowselect', () => {
    	  component.onRowSelect({
              name: 'name'
            });
  });

  it('should run populateColumns and populateTable ', async () => {
    	const terms = ["test", "output"];
      spyOn(component, "populateColumns").and.callThrough();
      component.populateColumns(terms);
  	  spyOn(component, "populateTable").and.callThrough();
      component.populateTable(terms);
      expect(component.populateColumns).toHaveBeenCalled();
      expect(component.populateTable).toHaveBeenCalled();
  });
});
*/