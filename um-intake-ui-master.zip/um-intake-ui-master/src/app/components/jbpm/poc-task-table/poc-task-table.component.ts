import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'um-poc-task-table',
  templateUrl: './poc-task-table.component.html',
  styleUrls: ['./poc-task-table.component.scss']
})
export class PocTaskTableComponent implements OnInit {
  titleName: string;
  loadingData: boolean;
  records = [];
  taskSumamry = 'task-summary';
  columnIncludes = [
    'id',
    'name',
    'assignee',
    'created',
  ];
  groupName: string;
  url: string;

  columns: any = [
    { label: '', id: 'name', dataType: 'text' },
    { label: '', id: 'name2', dataType: 'text' },
    { label: '', id: 'name3', dataType: 'text' },
    { label: '', id: 'name4', dataType: 'text' },
    { label: '', id: 'name5', dataType: 'text' },
    { label: '', id: 'name6', dataType: 'text' },
    { label: '', id: 'name7', dataType: 'text' }
  ];

  observableFour = {
    title: this.titleName + ' Table',
    enableSorting: false,
    enableFiltering: false,
    enableSingleRowSelect: true,
    clearAllFilters: true,
    caseSensitiveFilter: true,
    fixedHeader: true,
    filterCondition: {
      columnSorting: {
        columnId: 'workQueueName',
        dataType: String,
        sortOrder: 1
      }
    }
  };
  httpHeaders = new HttpHeaders({
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'Authorization': 'Basic ' + btoa('wbadmin:wbadmin')
  });

  tableHeader = ['ID', 'NAME', 'ASSIGNED', 'CREATED'];

  constructor(private readonly router: Router, private readonly httpClient: HttpClient) {}

  ngOnInit() {
    this.titleName = localStorage.getItem('state');

    if (this.titleName.includes('Work')) {
      this.groupName = 'Workflow';
    }else {
      this.groupName = '';
    }
    this.url = 'https://dev-ecp-api.optum.com/umautorouting/engine-rest/task?assignee=' + this.groupName;
    const options = {
      headers: this.httpHeaders,
    };
    this.httpClient
      .get(this.url, options)
      .pipe()
      .subscribe((result) => {
        this.populateColumns(result);
        this.populateTable(result);
      });
  }
  populateColumns = (columnData) => {
    if (columnData.length === 0) {
      return;
    } else {
      this.columns = [];
      const columns = Object.keys(columnData[0]);
      for (const column of columns) {
        if (this.columnIncludes.includes(column)) {
          const columnLabel = column.toUpperCase();
          const columnInfo = {
            label: columnLabel,
            id: column,
            dataType: 'text',
            style: { fontWeight: 'bold', borderRight: '0px' }
          };
          this.columns.push(columnInfo);
          this.columns = [...this.columns];
        }
      }
    }
  }

  populateTable = (recordData) => {
    if (recordData.length === 0) {
      return;
    } else {
      const tableData = [];
      const tasks = recordData;
      let rowData = {};
      for (const task of tasks) {
        rowData = {};
        for (const column of this.columns) {
          if (column.id === 'created') {
            var date = new Date(task[column.id]);
            task[column.id] = date.toString();
          }
          const removedHyphenLabel = column.id.split('-').join('');
          rowData[removedHyphenLabel] = task[column.id];
        }
        rowData['id'] = task['id'];
        tableData.push(rowData);
      }
      this.records = tableData;
      // return tableData;
    }
  }

  // containerId and task instance id
  onRowSelect(row: any) {

    let checkString = '';
    if (this.titleName !== undefined) {
      checkString = row.name.toLowerCase();
    }
    // Redirect based on which page we are on
    if (checkString.includes('clinical')) {
      this.router.navigate(['um/pocClinicalForm'], { state: row });
    } else if (checkString.includes('md')) {
      this.router.navigate(['um/pocMdForm'], { state: row });
    } else if (checkString.includes('quality')) {
      this.router.navigate(['um/pocQualityForm'], { state: row });
    } else {
      console.error('Cannot recognize task list');
    }
  }
}
