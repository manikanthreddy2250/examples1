import { HttpClient, HttpHandler, HttpHeaders, HttpResponse } from '@angular/common/http';
import {Injectable, NO_ERRORS_SCHEMA} from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule, FormGroup, FormControl, Validators } from '@angular/forms';
import { Apollo } from 'apollo-angular';
import {of} from 'rxjs';
import { MemberSearchService } from 'src/app/services/member-search-service/member-search.service';
import { ReferenceService } from 'src/app/services/refernce-service/reference.service';
import { uitkModules,uitkAngularModules } from '../../app.module';
import {SysConfigService} from '../../services/sysconfig-service/sys-config.service';
import { MemberSearch } from './member-search.component';
import { DataserviceService } from 'src/app/services/dataservice-service/dataservice.service';
import {UITKRadioGroupModule} from "@uitk/angular";
import {UserSessionService} from "src/app/shared/services/user-session/user-session.service";
import { HscReviewTypeService} from "../../services/health-service/hsc-review-type-service";
import { RouterTestingModule } from '@angular/router/testing';
import {environment} from "../../../environments/environment";
import {UmintakefuncCreateDraftHscService} from "../../services/um-intake-functions/umintakefunc-create-draft-hsc.service";


@Injectable()
class MockHscReviewTypeService {
  loadHscReviewType(key: string) {
    return of([{id: 1, label: 'Radiology', value: 'Radiology'}, {id: 2, label: 'Cardiology', value: 'Cardiology'}]);
  }
}

@Injectable()
class MockUmintakefuncCreateDraftHscService {
  createHscDraft(key: string) {
    return of({
      data: {
        "createDraftAuth": {
          "hscId": 17736,
          "caseId": "78734a39-a8f4-11eb-b68b-5e049650cdb3",
          "tenantId": "ecpumintakebaseproductbpmgrp",
          "isMbrBlocked": false
        }
      }
    })
  }
}

@Injectable()
class UserSessionMockService {
  i = 0;
  getUserName() {
    if (this.i === 0) {
      this.i++;
      return 'breddy88';
    } else if (this.i === 1) {
      this.i = this.i + 2;
      return 'SYSTEM';
    } else if (this.i === 3)  {
      return 'abcd';
    }
  }
  getUserOrg() {
    return 'ecp';
  }
  getUserPermission() {}

  getEcpToken() {}
  getFunctionalRole() {}
}

@Injectable()
class MockHttpClient {
  post(url: string, body: any | null, options?: any) {
    switch (url) {
      case environment.WORK_FLOW_NAME_DMN_URL:
        return of([{workFlowName: {value: 'workFlow'}}]);
      default:
        return of({});
    }
  }
}

@Injectable()
class SysConfigMockService {
  getClientConfigByKey(configKey: string) {
    return of([{
      "id": "um_intake_ui_1.0.0_ecp_intake_rules_2021-02-15",
      "createDateTime": "2021-02-15T20:08:44.231+00:00",
      "creatUserId": null,
      "changeDateTime": "2021-02-15T20:08:44.231+00:00",
      "changeUserId": null,
      "updateVersionNumber": "0",
      "createSystemReferenceId": null,
      "changeSystemReferenceId": null,
      "dataSecureRuleList": null,
      "dataGltyIssList": null,
      "application": "um_intake_ui",
      "version": "1.0.0",
      "org": "ecp",
      "role": null,
      "key": "intake_rules",
      "value": "{\"tenantId\":\"ecpumintakebaseproductdmngrp\"}",
      "startDate": "2021-02-15T00:00:00.000+00:00",
      "endDate": null,
      "inactivityIndicator": "0"
    }]);
  }
}

describe('MemberSearchComponent', () => {
  let component: MemberSearch;
  let fixture: ComponentFixture<MemberSearch>;
  let injectedService;
  let selectedMember;
  let httpHeaders = new HttpHeaders({
    'Content-Type': 'application/json',
    'Accept': 'application/json'
  });

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [uitkModules,uitkAngularModules,FormsModule, ReactiveFormsModule, UITKRadioGroupModule,RouterTestingModule],
      providers: [MemberSearchService, ReferenceService, DataserviceService, Apollo, HttpHandler, DataserviceService,
        { provide: UserSessionService, useClass: UserSessionMockService}, { provide: SysConfigService, useClass: SysConfigMockService},
        { provide: HscReviewTypeService, useClass: MockHscReviewTypeService}, {provide: HttpClient, useClass: MockHttpClient},
        { provide: UmintakefuncCreateDraftHscService, useClass: MockUmintakefuncCreateDraftHscService}],
      declarations: [MemberSearch],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
    injectedService = TestBed.get(DataserviceService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MemberSearch);
    component = fixture.componentInstance;
    fixture.detectChanges();
    const temp: any = '["ecp","sos_page_rules_admin"]';
    spyOn(localStorage, 'getItem').and.callFake((key: string): string => {
      return temp;
    });
  });

  afterEach(() => { fixture.destroy(); });


  it('should create', () => {
    expect(component).toBeTruthy();
  });

 /* it("should on Pagination Change", () => {
    let paginator: IPaginator;
    paginator = {};
    paginator.currentPageNumber = 1;
    component.onPaginationChange(paginator);
    expect(component.onPaginationChange).toBeTruthy();
  });*/

  it('should test on Change', () => {
    component.onChange('log');
    expect(component.onChange).toBeTruthy();
  });

  it('should test on Expand', () => {
    component.onExpand('log');
    expect(component.onExpand).toBeTruthy();
  });

  /* it('should test showSuccess', () => {
     component.showSuccess();
     expect(component.showSuccess).toBeTruthy();
   });
 */
  it('should test showError', () => {
    component.showError();
    expect(component.showError).toBeTruthy();
  });

  it('should test MemberBlockError', () => {
    component.showMemberBlockError();
    expect(component.showMemberBlockError).toBeTruthy();
  });

  it('should test showMissingFlowError', () => {
    component.showMissingFlowError();
    expect(component.showMissingFlowError).toBeTruthy();
  });

  it('should check for condition changed', () => {
    component.columns = [
      { label: 'Member search', id: 'wqname', style: { width: '175px' }, dataType: 'text' }
    ];
    const event = {
      event: 'ON_COLUMN_FILTER',
      filterCondition: {
        filterColumns: [
          { wqname: 'wqnqme' }
        ]
      }
    };
    component.conditionChanged(event);
    expect(component.columns[0].searchInput).toBe('wqnqme');
  });

  it('should check for on column clear condition changed', () => {
    component.columns = [
      { label: 'Member search', id: 'wqname', style: { width: '175px' }, dataType: 'text' }
    ];
    const event = {
      event: 'ON_CLEAR_ALL_FILTERS'
    };
    component.conditionChanged(event);
    expect(component.columns[0]).toEqual({ label: 'Member search', id: 'wqname', style: { width: '175px' }, dataType: 'text' });
  });

  it('should do  individual Search', () => {

    component.searchForm = new FormGroup({
      radioGroup: new FormControl('memberIdSearch'),
      memberId: new FormControl('16440436900'),
      firstName: new FormControl('flavtest'),
      lastName: new FormControl('Meyer'),
      dob: new FormControl('1978-07-26'),
      groupId: new FormControl('33994')
    });

    const result = [{ fullName: "abcd" }];

    component.notificationVisible = false;
    component.invalidFormSubmitted = false;
    component.selectedRow = true;
    component.memberDetailsGrid = true;
    expect(component.notificationVisible).toBe(false)
    expect(component.invalidFormSubmitted).toBe(false)
    expect(component.selectedRow).toBe(true)
    component.selectedradio = 'memberIdSearch'
    expect(component.selectedradio).toBe('memberIdSearch')
    expect(component.searchForm).toBeDefined()
    expect(component.searchForm.valid).toBeTruthy()
    component.individualSearch();
    expect(component.individualSearch).toBeTruthy();
  });


  it('should do memberId validation individual Search', () => {

    component.searchForm = new FormGroup({
      radioGroup: new FormControl('memberIdSearch'),
      memberId: new FormControl(null,Validators.required),
      firstName: new FormControl('flavtest'),
      lastName: new FormControl('Meyer'),
      dob: new FormControl('1978-07-26'),
      groupId: new FormControl('33994')
    });

    component.notificationVisible = true;
    component.invalidFormSubmitted = true;
    expect(component.notificationVisible).toBe(true)
    expect(component.invalidFormSubmitted).toBe(true)

    component.selectedradio = 'memberIdSearch'
    expect(component.selectedradio).toEqual('memberIdSearch')
    expect(component.searchForm).toBeDefined()
    expect(component.searchForm.valid).toBeFalsy()
    expect(component.searchForm.get('memberId').value).toBe(null)
    component.individualSearch();
    component.validation();
    expect(component.individualSearch).toBeTruthy();
  });

  it('should do DOB validation individual Search', () => {

    component.searchForm = new FormGroup({
      radioGroup: new FormControl('namedobSearch'),
      memberId: new FormControl(null),
      firstName: new FormControl("abc",Validators.required),
      lastName: new FormControl("abc",Validators.required),
      dob: new FormControl('01-01-2012',Validators.required),
      groupId: new FormControl('33994')
    });

    component.notificationVisible = true;
    component.invalidFormSubmitted = true;
    expect(component.notificationVisible).toBe(true)
    expect(component.invalidFormSubmitted).toBe(true)

    component.selectedradio = 'namedobSearch'
    expect(component.selectedradio).toEqual('namedobSearch')
    expect(component.searchForm).toBeDefined()
    expect(component.searchForm.valid).toBeTruthy()
    expect(component.searchForm.get('firstName').value).toBe('abc')
    expect(component.searchForm.get('lastName').value).toBe('abc')
    expect(component.searchForm.get('dob').value).toBe('01-01-2012')
    component.individualSearch();
    expect(component.individualSearch).toBeTruthy();
  });

  it('should do DOB validation Search', () => {

      component.searchForm = new FormGroup({
        radioGroup: new FormControl('namedobSearch'),
        memberId: new FormControl('16440436900'),
        firstName: new FormControl(null,Validators.required),
        lastName: new FormControl(null,Validators.required),
        dob: new FormControl(null,Validators.required),
        groupId: new FormControl('33994')
      });
      component.validation();
      expect(component.validation).toBeTruthy();
    });

  it('should do  clear Form Search', () => {
    component.clearForm();
    expect(component.clearForm).toBeTruthy();
  });

  /*it("should set Member Details", () => {
    let result = [{ fullName: "abcd" }];
    component.memberDetailsGrid  = true;
    component.setMemberDetails(result);
    expect(component.setMemberDetails).toBeTruthy();
  });*/

  it('should call azure function on initiateAuthAndRedirectToInTakeForm', () => {
    selectedMember =  {
      "indv_key_val":"16440436900",
      "indv_id":503926748,
      "mbr_cov_id":12484,
      "cov_eff_dt":"2020-07-24",
      "cov_end_dt":"2020-12-31",
      "pol_nbr":"24142",
      "coverageTypeDesc":"Behavioral Health",
      "productCatgyTpe":"Medicare"
    }
    component.serviceForm = new FormGroup({
      serviceType: new FormControl({})
    });
    component.dataserviceService.setOption(selectedMember);
    fixture.detectChanges();
    component.initiateAuthAndRedirectToInTakeForm();
    expect(component.initiateAuthAndRedirectToInTakeForm).toBeTruthy();
  });

  //test is failing
  // 1) should call on radio change
  // MemberSearchComponent

  // it("should call on radio change", () => {
  //   const mockEvent: Event = <Event><any>{
  //     toElement: {
  //       defaultValue: 'namedobSearch'
  //     }}
  //   component.onRadioChange(mockEvent);
  //   //component.selectedradio= memberIdSearch;
  //   component.invalidFormSubmitted = false;
  //   expect(component.onRadioChange).toBeTruthy();
  //   expect(component.invalidFormSubmitted).toBe(false);
  // });

  it("should call on memberIdSearch radio change", () => {
    const mockEvent: Event = <Event><any>{
      toElement: {
        defaultValue: 'memberIdSearch'
      }}
    component.onRadioChange(mockEvent);
    component.invalidFormSubmitted = false;
    expect(component.onRadioChange).toBeTruthy();
    expect(component.invalidFormSubmitted).toBe(false);
  });

  it("should select a row", () => {
    let testEvent = { value: "random" };
    //spyOn(component, "getSelectedMember");
    component.rowSelected(testEvent);
    //expect(component.selectedMember).toEqual({r});
    //expect(component.rowSelected).toBe(True);
    //expect(component.getSelectedMember).toHaveBeenCalled();
  });

  it('should populate search boxes with from provider auth history page from radioButton memberIdSearch', () => {
    component.searchProviderHis = {
      mbr: '16440436900',
      firstName: 'John',
      lastName: 'Doe',
      bth_dt: '01-01-2012',
      grpId: 1234,
      radioButton: 'memberIdSearch'
    };
    expect (component.searchProviderHis).toEqual({
      mbr: '16440436900',
      firstName: 'John',
      lastName: 'Doe',
      bth_dt: '01-01-2012',
      grpId: 1234,
      radioButton: 'memberIdSearch'});
    component.selectedradio = 'memberIdSearch';
    expect(component.selectedradio).toEqual('memberIdSearch');
    component.searchForm = new FormGroup({
      radioGroup: new FormControl('memberIdSearch'),
      memberId: new FormControl('16440436900', Validators.required),
      firstName: new FormControl('John'),
      lastName: new FormControl('Doe'),
      dob: new FormControl('01-01-2012'),
      groupId: new FormControl('1234')
    });
    expect(component.searchForm.get('firstName').value).toBe('John');
    expect(component.searchForm.get('lastName').value).toBe('Doe');
    expect(component.searchForm.get('dob').value).toBe('01-01-2012');
    expect(component.searchForm.get('radioGroup').value).toBe('memberIdSearch');
    expect(component.searchForm.get('memberId').value).toBe('16440436900');
    expect(component.searchForm.get('groupId').value).toBe('1234');
    component.searchProviderHis.radioButton = 'memberIdSearch';
    expect(component.searchForm).toBeDefined();
    expect(component.searchForm.valid).toBeTruthy();
    // component.fromProviderHistory();
//    expect(component.fromProviderHistory).toBeTruthy();
  });

  // it('should call from providerhistory', () => {
  //   component.dataserviceService.setProviderHistoryMbrSearchData({
  //     mbr: '16440436900',
  //     firstName: 'John',
  //     lastName: 'Doe',
  //     bth_dt: '01-01-2012',
  //     grpId: 1234,
  //     radioButton: 'memberIdSearch'
  //   })
  //   component.fromProviderHistory();
  //   expect(component.fromProviderHistory).toBeTruthy();
  // })

  it('should populate search boxes with from provider auth history page from radioButton namedobSearch', () => {
    component.selectedradio = 'namedobSearch';
    expect(component.selectedradio).toEqual('namedobSearch');
    component.searchProviderHis = {
      mbr: '16440436900',
      firstName: 'John',
      lastName: 'Doe',
      bth_dt: '01-01-2012',
      grpId: 1234,
      radioButton: 'namedobSearch'
    };
    expect (component.searchProviderHis).toEqual({
      mbr: '16440436900',
      firstName: 'John',
      lastName: 'Doe',
      bth_dt: '01-01-2012',
      grpId: 1234,
      radioButton: 'namedobSearch'});
    component.selectedradio = 'namedobSearch';
    expect(component.selectedradio).toEqual('namedobSearch');
    component.searchForm = new FormGroup({
      radioGroup: new FormControl('namedobSearch'),
      memberId: new FormControl(16440436900),
      firstName: new FormControl('John', Validators.required),
      lastName: new FormControl('Doe', Validators.required),
      dob: new FormControl('01-01-2012', Validators.required),
      groupId: new FormControl(1234)
    });
    expect(component.searchForm.get('firstName').value).toBe('John');
    expect(component.searchForm.get('lastName').value).toBe('Doe');
    expect(component.searchForm.get('dob').value).toBe('01-01-2012');
    expect(component.searchForm.get('radioGroup').value).toBe('namedobSearch');
    expect(component.searchForm.get('memberId').value).toBe(16440436900);
    expect(component.searchForm.get('groupId').value).toBe(1234);
    component.searchProviderHis.radioButton = 'namedobSearch';
    expect(component.searchForm).toBeDefined();
    expect(component.searchForm.valid).toBeTruthy();
    // component.fromProviderHistory();
    //expect(component.fromProviderHistory).toBeTruthy();
  });

  /*it ('should navigate to navigateBackToProviderHist', () => {
    component.navigateBackToProviderHist();
    expect(component.navigateBackToProviderHist).toBeDefined();
  });*/

  it ('should call getHscReviewTypes', () => {
    component.getHscReviewTypes();
    expect(component.getHscReviewTypes).toBeTruthy();
  });

  it ('should call ngOnInit', () => {
    component.ngOnInit();
    expect(component.ngOnInit).toBeTruthy();
  });

  it ('should set headers', () => {
    component.setCamundaHtppHeaders('123');
    expect(component.setCamundaHtppHeaders).toBeTruthy();
  });

  it ('should set work flow name body', () => {
    component.setWorkFlowBody('Surgical');
    expect(component.setWorkFlowBody).toBeTruthy();
  });
});
