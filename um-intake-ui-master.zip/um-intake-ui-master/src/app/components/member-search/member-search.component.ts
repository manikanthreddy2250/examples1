import { Component, OnInit, AfterViewInit, OnChanges, ViewChild, ChangeDetectorRef } from '@angular/core';
import { Router } from "@angular/router";
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { RadioselectModule } from '@uimf/uitk';
import { IUITKRadioGroupItem, UITKRadioGroupModule ,UITKInputModule} from '@uitk/angular';
import { ITableInputModel } from '@uimf/uitk';
import { MemberSearchService } from 'src/app/services/member-search-service/member-search.service';
import { ReferenceService } from 'src/app/services/refernce-service/reference.service';
import { Observable, Observer } from 'rxjs';
import { MembershipExpandableRowComponent } from 'src/app/components/member-search/membership-expandable-row/membership-expandable-row.component';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { MessageService } from "@uimf/uitk";
import { UITKPageNotificationService} from '@uitk/angular';
import { environment } from '../../../environments/environment';
import {FlowType} from '../../models/enums/flowType';
import { UserSessionService } from 'src/app/shared/services/user-session/user-session.service';
import { DataserviceService } from 'src/app/services/dataservice-service/dataservice.service'
import { ProviderAuthHistoryDataService} from 'src/app/services/provider-auth-history-data-service/provider-auth-history-data.service';
import {StepperDataService} from "src/app/services/StepperDataService/StepperDataService";
import {SysConfigService} from '../../services/sysconfig-service/sys-config.service';
import { HscReviewTypeService } from "../../services/health-service/hsc-review-type-service";
import {UmintakefuncCreateDraftHscService} from '../../services/um-intake-functions/umintakefunc-create-draft-hsc.service';
import {ConfigConstants} from "../../constants/configConstants";
import {RulesConstants} from "../../constants/rulesConstants";
import {error} from "selenium-webdriver";
// import { IntakeFormComponent } from 'src/app/components/intake-form/intake-form.component';

const CONTENT_TYPE_APPLICATION_JSON = "application/json";

@Component({
  selector: 'um-member-search',
  templateUrl: './member-search.component.html',
  styleUrls: ['./member-search.component.scss']
})

export class MemberSearch implements OnInit {
  stepperData:any;
  searchProviderHis: any;
  notes;
  myRadioGroupSelection: any;
  searchForm: FormGroup
  searchSubmitted: boolean;
  invalidFormSubmitted = false;
  datePickerConfig: any;
  dobOutOfRangeErrorMessage: string;
  selectedRow: boolean = true;
  public selectedradio: any;
  public isMemberRadioSelected: boolean;
  public isNameRadioSelected: boolean;
  records: any[];
  selectedMember: any;
  notificationVisible: boolean;
  memberDetailsGrid: boolean = false;
  invalidFormErrorMessage: string;
  requiredText = 'Input is required';
  invalidDateFormatErrorText: string;
  tableHeader: any[];
  displayRecordsList = []
  radioButtonSelected;
  previousProviderPage: boolean;
  // @ViewChild('MembershipExpandableRowComponent', { static: false }) membershipExpandableRowComponent: MembershipExpandableRowComponent;
  model = {
    pagination: {
      currentPageNumber: 1,
      recordsPerPage: 10,
      recordsPerPageOptions: [10, 25, 50, 75, 100],
    },
  };

  public observableFour: Observable<any>;
  public observerFour: Observer<any>;
  httpHeaders = new HttpHeaders({
    'Content-Type': CONTENT_TYPE_APPLICATION_JSON,
    'Accept': CONTENT_TYPE_APPLICATION_JSON
  });
  modelFour: ITableInputModel = {
    title: 'Plain Table',
    enableSorting: true,
    enableFiltering: true,
    clearAllFilters: true,
    enableSingleRowSelect: true,
    //enableMultiRowSelect: true,
    fixedHeader: false,
    tkHidePagination: true,
    caseSensitiveFilter: true,
    tkTableClass: 'tk-table-expanded',
    pagination: {},
    filterCondition: {
      columnSorting: {
        columnId: 'indv_key_val',
        sortOrder: 1
      }
    },
  };
  errorAlert = {
    id: 'error_msg',
    pageNotificationType: 'error',
    content: 'Unable to save draft auth.',
    visible: false
};

  memberBlockAlert = {
    id: 'error_msg',
    pageNotificationType: 'error',
    content: '',
	visible: false
};

  missingFlowAlert = {
    id: 'error_msg',
    pageNotificationType: 'error',
    content: 'The review type selected does not have a stepper flow associated. Please contact your system administrator.',
    visible: false,
    closeButton: true,
  };

  message2 = {
    id: 'error-msg-example',
    content: 'This member does not have membership details',
    visible: false
  };

  message3 = {
    id: 'error-msg-example',
    content: 'Required mandatory field values for Search a Member',
    visible: false
  };
  serviceForm: FormGroup;

  constructor(private readonly router: Router, private readonly memberSearchService: MemberSearchService,
              private readonly referenceService: ReferenceService, private readonly messageService: MessageService,
              private readonly httpClient: HttpClient, private readonly userSessionService: UserSessionService,
              readonly dataserviceService: DataserviceService, private readonly uITKPageNotificationService: UITKPageNotificationService,
              private readonly providerAuthHistoryDataService: ProviderAuthHistoryDataService,
              private readonly stepperDataService: StepperDataService, private readonly configurationService: SysConfigService,
              readonly umintakefuncCreateDraftHscService: UmintakefuncCreateDraftHscService,
              // intakeFormComponent: IntakeFormComponent,
              private readonly hscReviewTypeService: HscReviewTypeService) {
  this.selectedRow = true;
    this.observableFour = new Observable(obj => this.observerFour = obj);
    this.modelFour.pagination = this.model.pagination;
    // Variable for controlling default radio button
    this.radioButtonSelected = 0;
  }

  public tkRowComponent = MembershipExpandableRowComponent;

  onExpand(event) {
    console.log(event);
  }

  rowSelected(event) {
    //alert('row event fired'+event)
    console.log(" rowSelected Selected Value is  " + JSON.stringify(event.value))

  }

  onPaginationChange(e): void {
    this.modelFour.pagination = e;
    this.observerFour.next(this.modelFour);
  }

  // filter and sort function customization
  onChange(e): void {
    console.log(e);
  }
  items: IUITKRadioGroupItem[] = [
    {
      label: 'Name DOB ',
      value: 'nameDobSearch'
    },
    {
      label: 'Member ID ',
      value: 'memberIdSearch'
    },
  ];

  radioMemberForm = new FormGroup({
    radioGroup: new FormControl(''),
  });

  columns: any = [
    { label: 'Member ID', id: 'indv_key_val', dataType: 'number' },
    { label: 'Member Name', id: 'fullName', dataType: 'text' },
    { label: 'Gender', id: 'genderDesc', dataType: 'text' },
    { label: 'DOB', id: 'bth_dt', dataType: 'date' },
    { label: 'Address', id: 'adr_ln_1_txt', dataType: 'text' }
  ];

  expandedRowData: any = 'indv_key_val';

  memberId;
  firstName;
  lastName;
  dob;
  address;

  // radioControl = this.searchForm.get('radioGroup') as FormControl;

  public serviceTypes = [];

  async ngOnInit() {
    this.stepperDataService.sharedStepperData.subscribe((stepperData) => {
      this.stepperData = stepperData;
    });
    this.myRadioGroupSelection = this.items[0]
    this.isMemberRadioSelected = false;
    this.isNameRadioSelected = true;
    this.notificationVisible = false;
    this.records = [];
    this.requiredText = 'Input is required';
    this.invalidDateFormatErrorText = 'Please enter valid date format of mm/dd/yyyy';
    this.invalidFormErrorMessage = 'Review the form and correct the highlighted fields';
    this.tableHeader = ['Member ID', 'First Name', 'Last Name', 'DOB', 'Address'];
    this.selectedMember = {};
    this.searchSubmitted = false;
    this.dobOutOfRangeErrorMessage = 'Birth Date must be the same as or after 01/01/1900';
    this.datePickerConfig = {
      minYear: 1900,
      minMonth: 1,
      minDay: 1
    };
    this.searchForm = new FormGroup({
      memberId: new FormControl(''),
      firstName: new FormControl('', Validators.required),
      lastName: new FormControl('', Validators.required),
      dob: new FormControl('', Validators.required),
      groupId: new FormControl('')
    });
    this.getHscReviewTypes()

  }

  async getHscReviewTypes() {
    this.serviceTypes = await this.hscReviewTypeService.loadHscReviewType();
    if (this.serviceTypes && this.serviceTypes.length > 0) {
      this.serviceForm = new FormGroup({
        serviceType: new FormControl(this.serviceTypes[0])
      });
    }
  }

  onRadioChange(radioid) {
    this.selectedradio = radioid.value;
    this.invalidFormSubmitted = false;
    this.searchForm.reset();
    // if (this.searchForm.get('radioGroup').value !== '' && this.searchForm.get('radioGroup').value === 'memberIdSearch') {
    if (this.selectedradio == "nameDobSearch") {
      this.isNameRadioSelected = true;
      this.isMemberRadioSelected = false;
      this.searchForm = new FormGroup({
        memberId: new FormControl(''),
        firstName: new FormControl('', Validators.required),
        lastName: new FormControl('', Validators.required),
        dob: new FormControl('', Validators.required),
        groupId: new FormControl('')
      });
    } else  if(this.selectedradio == "memberIdSearch"){
      this.isNameRadioSelected = false;
      this.isMemberRadioSelected = true;
      this.searchForm = new FormGroup({
        memberId: new FormControl('', Validators.required),
        firstName: new FormControl(''),
        lastName: new FormControl(''),
        dob: new FormControl(''),
        groupId: new FormControl('')
      });
    }
  }

  individualSearch() {

    if (this.searchForm.valid) {
      this.notificationVisible = false;
      this.invalidFormSubmitted = false;
      this.selectedRow = true;
      this.memberDetailsGrid = true;

      const memberId = this.searchForm.get('memberId').value ? this.searchForm.get('memberId').value : null;
      const firstName = this.searchForm.get('firstName').value ? this.searchForm.get('firstName').value : null;
      const lastName = this.searchForm.get('lastName').value ? this.searchForm.get('lastName').value : null;
      const dob = this.searchForm.get('dob').value ? this.searchForm.get('dob').value : null;
      const groupId = this.searchForm.get('groupId').value ? this.searchForm.get('groupId').value : null;

      this.memberSearchService.getIndividuals(memberId, firstName, lastName, dob, groupId)//.subscribe(r => this.setMemberDetails(r));
        .then((result) => {
          this.setMemberDetails(result)
        }
        ).catch((error) => {
          this.message2.visible = true;
        });

    } else {
      //   this.memberSearchService.getMemberDetailsByNameDOB(firstName,lastName,dob).subscribe(r => this.setMemberDetails(r));
      this.validation();
      this.notificationVisible = true;
      this.invalidFormSubmitted = true;
      this.message3.visible = true;
    }
  }

  validation(){
     if (this.selectedradio == 'nameDobSearch') {
            if (this.searchForm.get('firstName').value == null) {
              this.searchForm.get('firstName').errors['required'] = true;
            }
            if (this.searchForm.get('lastName').value == null) {
              this.searchForm.get('lastName').errors['required'] = true;
            }
            if (this.searchForm.get('dob').value == null) {
              this.searchForm.get('dob').errors['required'] = true;
            }
          } else {
            if (this.searchForm.get('memberId').value == null) {
              this.searchForm.get('memberId').errors['required'] = true;
            }
          }
  }
  setMemberDetails(result) {
    this.modelFour.pagination = this.model.pagination;
    //this.records = result.data.v_indv_srch;
    result.map((obj) => {
      obj['fullName'] = obj.lst_nm + ", " + obj.fst_nm
      return obj;
    })
    this.records = result;
    this.stepperDataService.setStepperData({...this.stepperData, memberinf: result});
    console.log('Records are: ' + JSON.stringify(this.records))
    this.observerFour.next(this.modelFour);
    this.searchSubmitted = true;
  }

  clearForm() {
    this.invalidFormSubmitted = false;
    this.searchForm.reset();
  }

  conditionChanged(event) {
    if (event.event === 'ON_COLUMN_FILTER') {
      this.columns.forEach((col) => {
        event.filterCondition.filterColumns.forEach((condition) => {
          const key = Object.keys(condition)[0];
          if (col.id === key) {
            col.searchInput = condition[key];
          }
        });
      });
    } else if (event.event === 'ON_CLEAR_ALL_FILTERS') {
      this.columns.forEach((col) => {
        if (col.searchInput) {
          col.searchInput = '';
        }
      });
    }
  }

  /* notesUpdated = (data) => {
     this.notes = data;
   }*/

  async initiateAuthAndRedirectToInTakeForm() {
    // TODO Pass the  Active Member_Cov_Id to get the member coverage details
    // this.intakeFormComponent.getStepperIds(this.serviceForm.get('serviceType').value.value);
    const hasFlow = await this.validateFlow(this.serviceForm.get('serviceType').value.value);
    if (hasFlow) {
      this.selectedMember = this.dataserviceService.getOption();
      const createHsc = {
        serviceType: this.serviceForm.get('serviceType').value.value,
        hsc: {
          indv_id: this.selectedMember.indv_id.toString(),
          indv_key_typ_ref_id: this.selectedMember.indv_key_typ_ref_id,
          indv_key_val: this.selectedMember.indv_key_val,
          mbr_cov_dtl: this.selectedMember,
          hsc_rev_typ_ref_id: this.serviceForm.get('serviceType').value.id
        },
        coverage: {
          policyNumber: this.selectedMember.pol_nbr,
          productCode: this.selectedMember.prdct_ref_id ? this.selectedMember.prdct_ref_id : 0,
          claimPlatform: this.selectedMember.clm_pltfm_ref_id ? this.selectedMember.clm_pltfm_ref_id : 0,
          sourceChannel: ''
        }
      };
      this.stepperDataService.setStepperData({
        ...this.stepperData,
        serviceType: this.serviceForm.get('serviceType').value.value
      });
      this.umintakefuncCreateDraftHscService.createHscDraft(createHsc).subscribe((data: any) => {
          if (data && !data.data.createDraftAuth.isMbrBlocked) {
            this.stepperDataService.setStepperData({...this.stepperData, flowType: FlowType.NEW});
            this.stepperDataService.setStepperData({...this.stepperData, tenantId: data.data.createDraftAuth.tenantId});
            this.router.navigate(['/um/intake-form', this.selectedMember.indv_key_val, this.selectedMember.mbr_cov_id,
              this.serviceForm.get('serviceType').value.value, data.data.createDraftAuth.caseId, data.data.createDraftAuth.hscId]);
          } else {
            this.memberBlockAlert.content = data.mbrBlockMessage;
            this.showMemberBlockError();
          }
        },
        (error) => {
          console.log("error ====== " + error);
          if (error) {
            this.showError();
          }
        });
    }
  }

  async validateFlow(serviceType): Promise<boolean> {
    const configRes = await this.configurationService.getClientConfigByKey(ConfigConstants.INTAKE_RULES_CONFIG_KEY).toPromise();
    if (configRes) {
      const tenantId = JSON.parse(configRes[0].value).tenantId;
      return await this.getWorkFlowDMN(await this.setWorkFlowBody(serviceType), await this.setCamundaHtppHeaders(tenantId));
    }
    return false;
  }

  async setCamundaHtppHeaders(tenantId) {
    return {
      headers: new HttpHeaders({
        'Content-Type': CONTENT_TYPE_APPLICATION_JSON,
        'Accept': CONTENT_TYPE_APPLICATION_JSON,
        'Authorization': 'Bearer ' + this.userSessionService.getEcpToken(),
        'x-bpm-cli-org-id': this.userSessionService.getUserOrg(),
        'x-bpm-func-role': this.userSessionService.getFunctionalRole(),
        'x-bpm-tenant-id': tenantId,
        'x-bpm-external-ref-id': RulesConstants.X_BPM_EXTERNAL_REF_ID,
        'x-bpm-source': RulesConstants.X_BPM_SOURCE,
        'x-bpm-workflow': RulesConstants.X_BPM_WORKFLOW
      })
    }
  }

  async setWorkFlowBody(serviceType) {
    const body = {
      hsc: {
        serviceType
      }
    };
    return body;
  }

  async getWorkFlowDMN(body, httpOptions) {
    return await this.validateWorkFlowName(await this.httpClient.post(environment.WORK_FLOW_NAME_DMN_URL, body, httpOptions).toPromise());
  }

  async validateWorkFlowName(flowName: any) {
    if (flowName && flowName.length > 0) {
      return true;
    } else {
      console.log('validateFlow(): data length = 0 for WorkFlowName.');
      this.showMissingFlowError();
      return false;
    }
  }

  showError() {
    this.errorAlert.visible = true;
   // this.messageService.add(this.errorAlert);
   this.uITKPageNotificationService.add(this.errorAlert)
  }

  showMemberBlockError() {
    this.memberBlockAlert.visible = true;
   // this.messageService.add(this.memberBlockAlert);
    this.uITKPageNotificationService.add(this.memberBlockAlert);
  }

  showMissingFlowError() {
    this.missingFlowAlert.visible = true;
    this.uITKPageNotificationService.add(this.missingFlowAlert);
  }

  navigateBackToProviderHist() {
    this.providerAuthHistoryDataService.setFromMemberSearch(true);
    this.providerAuthHistoryDataService.setRetainHscRecords(true);
    this.searchProviderHis = this.dataserviceService.getProviderHistoryMbrSearchData();
    this.providerAuthHistoryDataService.setProviderAuthHistoryData(this.searchProviderHis);
    this.router.navigate(['/um']);
  }
}
