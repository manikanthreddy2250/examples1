import { HttpClient, HttpHandler } from '@angular/common/http';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Apollo } from 'apollo-angular';
import { MembershipExpandableRowComponent } from './membership-expandable-row.component';

import { uitkModules } from '../../../app.module';
import { DataserviceService } from 'src/app/services/dataservice-service/dataservice.service'

import { of } from 'zen-observable';
describe('MembershipExpandableRowComponent', () => {
  let component: MembershipExpandableRowComponent;
  let fixture: ComponentFixture<MembershipExpandableRowComponent>;
  let dataService: DataserviceService;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [uitkModules, FormsModule, ReactiveFormsModule],
      providers: [DataserviceService, Apollo, HttpClient, HttpHandler],
      declarations: [MembershipExpandableRowComponent],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MembershipExpandableRowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    // dataService = new DataserviceService();
  });

  afterEach(() => { fixture.destroy(); });


  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should create ngoninit', () => {
    //expect(component).toBeTruthy();
    component.ngOnInit()
    expect(component.ngOnInit).toBeTruthy()
  });

  it("should call on selectedRowRadioVal is false radio change", () => {

    let activeMemCoverageObj = {
      "indv_key_val": '16440436900',
      "indv_id": 503926748,
      "mbr_cov_id": '12484',
      "cov_eff_dt": '2020-07-24',
      "cov_end_dt": '2020-12-31',
      "pol_nbr": '1234'
    }
    component.records = [activeMemCoverageObj]
    component.selectedRowRadioVal = false
    expect(component.selectedRowRadioVal).toBe(false)
    component.selectedMbrshrpdtl = activeMemCoverageObj;
    expect(component.selectedMbrshrpdtl).toBe(activeMemCoverageObj)
    component.onRadioChange('12484');
    //component.selectedradio= memberIdSearch;
    expect(component.onRadioChange).toBeTruthy();

  });

  it("should call on selectedRowRadioVal is true radio change", () => {
    let activeMemCoverageObj = {
      "indv_key_val": '16440436900',
      "indv_id": 503926748,
      "mbr_cov_id": '12484',
      "cov_eff_dt": '2020-07-24',
      "cov_end_dt": '2020-12-31',
      "pol_nbr": '1234'
    }
    component.records = [activeMemCoverageObj]
    component.selectedRowRadioVal = true
    expect(component.selectedRowRadioVal).toBe(true)
    component.onRadioChange('12');
    expect(component.onRadioChange).toBeTruthy();
  });

  it("should call on setActiveMemberData", () => {
    //this.nestedData.indv_key_val = '16440436900'
    const nextedData = { indv_key_val: '16440436900', indv_id: 503926748, memberships: [{ mbrshpData: { active_mbr_covs: [{ mbr_cov_id: 123 }] } }] };
    component.nestedData = nextedData;
    component.setActiveMemberData(nextedData)
    expect(component.setActiveMemberData).toBeDefined;
    expect(component.setActiveMemberData).toBeTruthy();

  });

  it('should run SetterDeclaration #tkRowInfo', () => {
    spyOn(fixture.componentInstance, 'setActiveMemberData');
    fixture.componentInstance.tkRowInfo = 4500;
    fixture.detectChanges();
    expect(fixture.componentInstance.setActiveMemberData).toHaveBeenCalled();
  });

});
