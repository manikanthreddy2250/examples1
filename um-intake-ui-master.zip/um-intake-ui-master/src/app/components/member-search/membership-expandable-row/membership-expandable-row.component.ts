import { Component, OnInit, Input } from '@angular/core';
import { DataserviceService } from 'src/app/services/dataservice-service/dataservice.service'
import {StepperDataService} from "../../../services/StepperDataService/StepperDataService";
import {Constants} from "../../../constants/constants";
import {UserSessionService} from 'src/app/shared/services/user-session/user-session.service';
@Component({
  selector: 'um-membership-expandable-row',
  templateUrl: './membership-expandable-row.component.html',
  styleUrls: ['./membership-expandable-row.component.scss']
})
export class MembershipExpandableRowComponent implements OnInit {
  [x: string]: any;
  @Input() label: any;
  @Input() trackid: any;
  @Input() sdlcPhase: any;
  public selectedradio: string;
  public nestedData;
  stepperData: any;
  records = [];
  activembrcovsList = []
  selectedMbrshrpdtl
  selectedRowRadioVal = true
  PROVIDER = Constants.UM_INTAKE_UI_USER_PERMISSION_PROVIDER;
  /**
   * This is a required input that the table uses to pass in the row object.
   * It must be called tkRowInfo.
   */
  columns: any[] = [
    { label: 'Select', id: 'mbr_cov_id', dataType: 'boolean', sortable: false },
    { label: 'GroupID', id: 'pol_nbr', dataType: 'number' },
    { label: 'Policy Start Date', id: 'cov_eff_dt', dataType: 'date' },
    { label: 'Policy End Date', id: 'cov_end_dt', dataType: 'date' },
    { label: 'Coverage Type', id: 'coverageTypeDesc', dataType: 'text' },
    { label: 'Insurance Type', id: 'productCatgyTpe', style: { width: '200px' }, dataType: 'text' }
  ];

  modelFour = {
    title: 'Plain Table',
    enableSorting: true,
    enableFiltering: false,
    clearAllFilters: false,
    fixedHeader: false,
    filterCondition: {
      columnSorting: {
        columnId: 'pol_nbr',
        sortOrder: 1
      }
    },
  };

  @Input()
  set tkRowInfo(selectedRow: any) {
    // Extract the relevant information from the row object for usee in this component.
    this.nestedData = selectedRow;
    this.setActiveMemberData(this.nestedData)
   // console.log('Expandable grid data' + JSON.stringify(this.nestedData))
  }

  constructor(private readonly dataserviceService: DataserviceService, public stepperDataService: StepperDataService, private readonly userSessionService: UserSessionService) {
    console.log('MembershipExpandableRowComponent is loaded')
    this.selectedRowRadioVal = true
  }

  ngOnInit() {
     this.stepperDataService.sharedStepperData.subscribe((stepperData) => {
               this.stepperData = stepperData;
     });
  }

  setActiveMemberData(nestedData): any {
    const indvKeyval = this.nestedData.indv_key_val;
    const indvid = this.nestedData.indv_id;
    nestedData.memberships[0].mbrshpData.active_mbr_covs.forEach(element => {
      const activeMemCoverageObj = {
        "indv_key_val": indvKeyval ? indvKeyval : null,
        "indv_key_typ_ref_id": this.nestedData.indv_key_typ_ref_id ? this.nestedData.indv_key_typ_ref_id : null,
        "indv_id": indvid ? indvid : null,
        "mbr_cov_id": element.mbr_cov_id,
        "cov_eff_dt": element.cov_eff_dt,
        "cov_end_dt": element.cov_end_dt,
        "pol_nbr": element.pol_nbr,
        "coverageTypeDesc": element.coverageTypeDesc,
        "productCatgyTpe": element.productCatgyTpe,
        "claim_platform_ref_Id": element.clm_pltfm_ref_id,
        "productCode" : element.prdct_ref_id
      }
      this.activembrcovsList.push(activeMemCoverageObj)
    });
    this.records = this.activembrcovsList;
  }

  public onRadioChange(radioid) {
    this.records.forEach((record) => {
      if (radioid == record.mbr_cov_id) {
        //This logging is only for testing, we will remove once confirm
        console.log('Provider'+this.userSessionService.getUserPermission());
        console.log('Stepper' +this.stepperData.submittingProviderDetails);
        if (this.userSessionService.getUserPermission() === this.PROVIDER) {
          if (this.stepperData.submittingProviderDetails) {
            this.selectedRowRadioVal = false;
            this.dataserviceService.setSelectedRow(this.selectedRowRadioVal);
          }
        }
        else {
          this.selectedRowRadioVal = false;
          this.dataserviceService.setSelectedRow(this.selectedRowRadioVal);
        }
        this.selectedMbrshrpdtl = record;
        this.dataserviceService.setOption(this.selectedMbrshrpdtl);
        this.stepperDataService.setStepperData({...this.stepperData, selectedMemberId: this.selectedMbrshrpdtl.indv_key_val});
      }
    });
    this.selectedradio = radioid;
  }

}
