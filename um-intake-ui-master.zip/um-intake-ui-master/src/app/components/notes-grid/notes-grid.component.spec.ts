import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import {NotesGridComponent} from './notes-grid.component';
import {NO_ERRORS_SCHEMA} from "@angular/core";
import {UserSessionService} from "src/app/shared/services/user-session/user-session.service";
import {of, Observable, AsyncSubject} from "rxjs";
import { NotesGraphqlService } from 'src/app/services/noteservice/notes-graphql.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { IPaginator } from '@uimf/uitk';
import { Observer } from 'rxjs/Rx';
import { uitkAngularModules, uitkModules } from "src/app/app.module";
import {UITKTableModule,UITKTableSortDirective,UITKTableDataSource,IUITKColumnState,UITKSortDirection,
IUITKTableSortState,UITKTableFeaturesModule,} from '@uitk/angular';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

const  mockData = [
              {
       	       dateTime: "11/13/2020",
                type: "Outpatient Office Visits - New Patients",
                subject: "Active",
       	    	 note: "wertrewe",
                author: "Annik White",
                viewNote: true
              }
            ];

describe('NotesGridComponent', () => {
  let component: NotesGridComponent;
  let fixture: ComponentFixture<NotesGridComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NotesGridComponent ],
      imports: [HttpClientTestingModule,UITKTableModule,UITKTableFeaturesModule,uitkAngularModules,uitkModules,FormsModule,ReactiveFormsModule],
      providers: [HttpClient],
      schemas: [NO_ERRORS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NotesGridComponent);
    component = fixture.componentInstance;
    component.dataSource.data = mockData;
      component.inputNotes = true;
    fixture.detectChanges();
  });

  afterEach(() => {
    TestBed.resetTestingModule();
    fixture.destroy();
  });

  afterAll(() => {
    TestBed.resetTestingModule();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should run #ngOnInit()', async () => {
    component.ngOnInit();
  });

  it('should update notes list', () => {
   const data = {dateTime: "8/3/20, 2:51 PM", type: "provider",
      note: "trimNote", author: "ngopi2", subject:"subject"}
    component.inputNotes = data;
    component.notesList = [component.inputNotes]
    component.trimmedNotesList = [component.inputNotes]
    fixture.detectChanges();
   expect(component.inputNotes).toEqual(data);
   expect(component.notesList).toEqual([data]);
   expect(component.trimmedNotesList).toEqual([data]);
   expect(component.trimmedNotesList[0]).toEqual(data);
  });

  it('should note update notes list', () => {
    component.inputNotes = undefined;
    component.trimmedNotesList = [];
    component.ngOnChanges();
    fixture.detectChanges();
    expect(component.trimmedNotesList).toEqual([]);
  });

  it("should enable mesg dialog onDeleteMesgClick", () => {
    component.mesgDialog = false;
    component.onDeleteMesgClick()
    expect(component.mesgDialog).toBeTrue();
  });

  it("should enable mesg dialog onCancel", () => {
    component.mesgDialog = true;
    component.onCancel()
    expect(component.mesgDialog).toBeFalse();
  });

  it("should trim note on row select", () => {
    const data = {dateTime: "8/3/20, 2:51 PM", type: "provider",
      note: "trimNote", author: "ngopi2", subject:"subject"}
    const text = "Simple random text that is added for simple testing purpose and now we expect it is " +
      "more than  150 character to see how notes grid acts for karma tests";
    const resultText = "Simple random text that is added for simple testing purpose and now we expect it is " +
      "more than  150 character to see how notes grid acts for karma test...";
    const event = {dateTime: "8/3/20, 2:51 PM", type: "provider",
    note: "trimNote", author: "ngopi2", subject:"subject", selected: false};

    component.maxNotesLength = 150;
    component.notesList[0] = event;
  });

  it("should have actual note on row select", () => {
    let text = "Simple text that is added for simple testing purpose and now we expect it is " +
      "more than  150 character to see how notes grid acts for karma tests";
    const event = {dateTime: '5/29/20', note: text, selected: true};
    component.trimmedNotesList[0] = event;
    component.maxNotesLength = 150;
    component.notesList[0] = event;
    expect(component.trimmedNotesList[0].note).toEqual(text);
  });

  it('should empty trimmedNotesList on delete', () => {
    const data= {dateTime: '5/29/20, 11:07 AM', type: 'Provider comments', note: 'simple text', author: 'testUser'};
    component.onDeleteClick();
    expect(component.mesgDialog).toBeFalsy();
  });

  it('should fetch test', () => {
    component.fetchNotes()
    expect(component.fetchNotes).toBeTruthy();
  });

  it('should  test Note Function', () => {
     const data = {dateTime: "8/3/20, 2:51 PM", type: "provider",
               note: "trimNote", author: "ngopi2", subject:"Active"}
      component.notesList = mockData;
      component.Note(data);
      expect(component.Note).toBeTruthy();
  });

  it('should  test collapse Function', () => {
      const data = {dateTime: "8/3/20, 2:51 PM", type: "provider",
           note: "trimNote", author: "ngopi2", subject:"Active"}
      component.notesList = mockData;
      component.collapseNote(data);
      expect(component.collapseNote).toBeTruthy();
  });

   it('should  test onSortChange', () => {
      const sortState =  {direction: 1, column: "note", enabled: true};
      component.onSortChange(sortState);
      expect(component.onSortChange).toBeTruthy();
    });
});

