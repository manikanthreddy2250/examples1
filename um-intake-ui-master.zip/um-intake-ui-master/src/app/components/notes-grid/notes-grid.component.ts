import {Component, Input, OnInit, ViewChild, AfterViewInit, OnDestroy} from '@angular/core';
import {StepperDataService} from 'src/app/services/StepperDataService/StepperDataService';
import {UserSessionService} from "src/app/shared/services/user-session/user-session.service";
import {DatePipe} from "@angular/common";
import { NoteserviceService } from 'src/app/services/noteservice/noteservice.service';
import {NotesGraphqlService} from "src/app/services/noteservice/notes-graphql.service";
import {Observable, Observer, Subscription} from 'rxjs';
import {map} from 'rxjs/operators';
import {
UITKTableModule,
UITKTableSortDirective,
UITKTableDataSource,
IUITKColumnState,
UITKSortDirection,
IUITKTableSortState,
UITKTableFeaturesModule,
} from '@uitk/angular';
import {Constants} from "../../constants/constants";


@Component({
  selector: 'um-notes-grid',
  templateUrl: './notes-grid.component.html',
  styleUrls: ['./notes-grid.component.scss']
})
export class NotesGridComponent implements OnInit, AfterViewInit, OnDestroy {
  @Input() inputNotes;
  @ViewChild('sortTable') uitkTableSort: UITKTableSortDirective;
  dataSource = new UITKTableDataSource<any>([]);
  notesList = [];
  trimmedNotesList = [];
  currentDateTime: string;
  type: string ;
  note: string;
  role: string;
  author: string;
  typeN:number;
  expandSubject: string;
  expandNote: string;
  subject:string;
  sortDescription='';
  mesgDialog: boolean = false;
  maxNotesLength = 100;
  viewNote: boolean = false;
  stepperData: any;
  hsrNoteId: any;
  gridhscId: any;

  notesColumns: any[] = [
    { label: 'Date', id: 'dateTime', dataType: 'text' },
     { label: 'Subject', id: 'subject', dataType: 'text' },
     { label: 'Note', id: 'note', dataType: 'text'},
    { label: 'Author', id: 'author', dataType: 'text' }
  ];
  stepperDataSubscription: Subscription;

  constructor(private readonly userSessionService: UserSessionService,
              private readonly notesGraphqlService: NotesGraphqlService,
              private stepperDataService: StepperDataService) {}

  ngOnInit() {
    this.stepperDataSubscription = this.stepperDataService.sharedStepperData.subscribe((stepperData) => this.stepperData = stepperData);
    this.fetchNotes();
    this.stepperDataService.setStepperData({...this.stepperData, notesExpandRowRecords: this.trimmedNotesList});
  }
  ngOnDestroy() {
    this.stepperDataSubscription.unsubscribe();
  }

  ngAfterViewInit() {
         this.dataSource.sort = this.uitkTableSort;
  }


  onSortChange(sortState: IUITKColumnState) {
          console.log('Sorting Change: ', sortState);
  }

  ngOnChanges() {
    if(this.inputNotes){
      this.notesList.push(this.inputNotes);
      const trimNote = this.inputNotes.note.length > this.maxNotesLength ?
      this.inputNotes.note.substring(0, this.maxNotesLength) + ' ' : this.inputNotes.note;
      this.trimmedNotesList.push({dateTime: this.inputNotes.dateTime, type: this.inputNotes.type,
      note: trimNote, author: this.inputNotes.author, subject:this.inputNotes.subject,viewNote: this.viewNote});
      this.stepperDataService.setStepperData({...this.stepperData, hscNotes: this.notesList});
      this.dataSource.data = [...this.trimmedNotesList];
    }
  }

  onDeleteClick() {
    this.mesgDialog = false;
    this.notesList = [];
    this.trimmedNotesList = [];
    this.notesGraphqlService.getNoteID(this.type, this.note, this.author)
      .subscribe(r =>
    this.notesGraphqlService.updateNoteSbj(r.data.hsr_note[0].hsr_note_id)
      .subscribe(() => this.fetchNotes()));
  }

  fetchNotes = () => {
    if(this.userSessionService.getUserPermission()== Constants.UM_INTAKE_UI_USER_PERMISSION_PROVIDER)
    {
      this.notesGraphqlService.getNotesList(this.stepperData.hscId)
            .subscribe(r => this.setNotesList(r));
    }
    if(this.userSessionService.getUserPermission()== Constants.UM_INTAKE_UI_USER_PERMISSION_CLINICIAN)
    {
      this.notesGraphqlService.getNotesListReviewer()
              .subscribe(r => this.setNotesList(r));
    }
    if(this.userSessionService.getUserPermission()== Constants.UM_INTAKE_UI_USER_PERMISSION_ADMIN)
      {
      this.notesGraphqlService.getNotesListAdmin(this.userSessionService.getUserPermission())
                  .subscribe(r => this.setNotesList(r));
      }
  }

  onDeleteMesgClick() {
    this.mesgDialog = true;
  }

  onCancel() {
    this.mesgDialog = false;
  }

  setNotesList(result) {
    let trimNote;
    for(let i = 0; i< result.data.hsr_note.length; i++) {
      if(result.data.hsr_note[i].hsr_note_sbjs.length != 0) {
        const pipe = new DatePipe('en-US');
        this.currentDateTime = pipe.transform(
        result.data.hsr_note[i].creat_dttm, 'short', 'UTC');
        this.note = result.data.hsr_note[i].note_txt_lobj;
        this.subject = result.data.hsr_note[i].note_titl_txt;
        trimNote = this.note.length > this.maxNotesLength ?
        this.note.substring(0, this.maxNotesLength) + '...' : this.note;
        this.author = result.data.hsr_note[i].creat_user_id;
        this.typeN=result.data.hsr_note[i].note_typ_ref_id;
        this.gridhscId = result.data.hsr_note[i].hsc_id;
        this.hsrNoteId = result.data.hsr_note[i].hsr_note_id;

       if(this.typeN == 10)
        {
        this.type="Reviewer Comments";
        }
        if(this.typeN == 11)
        {
        this.type="Provider Comments";
        }
        if(this.typeN == 12)
        {
        this.type="Admin Comments";
        }
        this.notesList.push({dateTime: this.currentDateTime, type: this.type,
        note: this.note, author: this.author, subject: this.subject, gridhscId: this.gridhscId, hsrNoteId:this.hsrNoteId });
        this.trimmedNotesList.push({dateTime: this.currentDateTime, type: this.type,
        note: trimNote, author: this.author, subject:this.subject, gridhscId: this.gridhscId, hsrNoteId:this.hsrNoteId});
        this.dataSource.data=[...this.trimmedNotesList];
      }
    }
  }

   Note(record: any){
      this.expandNote = null;
      this.expandSubject= null;
      this.notesList.forEach((item) => {
              if(item.subject == record.subject){
                 this.expandNote = item.note;
                 this.expandSubject = item.subject;
                 record.viewNote = true;
              }
        });
   }

   collapseNote(record: any){
      this.notesList.forEach((item) => {
          if(item.subject == record.subject){
             record.viewNote = false;
          }
      });
   }
}
