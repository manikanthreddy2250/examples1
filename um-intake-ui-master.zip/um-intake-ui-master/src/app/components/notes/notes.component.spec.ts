import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NoteserviceService } from 'src/app/services/noteservice/noteservice.service';
import { NotesComponent } from './notes.component';
import {Injectable, NO_ERRORS_SCHEMA} from '@angular/core';
import { of } from "rxjs";
import { NotesGraphqlService } from "src/app/services/noteservice/notes-graphql.service";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { HttpClientTestingModule, HttpTestingController } from "@angular/common/http/testing";
import { environment } from 'src/environments/environment';
import { FormsModule, ReactiveFormsModule, FormControl } from '@angular/forms';
import {UserSessionService} from '../../shared/services/user-session/user-session.service';


const notesGraphqlServiceStub = {
  getNotesList: () => of({
    data: {
      hsr_note: [{
        creat_dttm: '5/29/20, 7:07 AM',
        note_txt_lobj: 'simple text', creat_user_id: 'testUser', hsr_note_sbjs: [{ inac_ind: 0 }]
      }]
    }
  }),
  deleteNote: () => of({}),
  getNoteID: () => of({}),
  updateNoteSbj: () => of({})
}

@Injectable()
class UserSessionMockService {
  i = 0;
  getUserName() {
    if (this.i === 0) {
      this.i++;
      return 'breddy88';
    } else if (this.i === 1) {
      this.i = this.i + 2;
      return 'SYSTEM';
    } else if (this.i === 3)  {
      return 'abcd';
    }
  }
  getUserRoles() {
    return [{'role-name': 'provider'}];
  }

  getUserPermission() {
    return 'provider';
  }
  getUserOrg() {
    return 'ecp';
  }

  getEcpToken() {}
  getFunctionalRole() {}
}


describe('NotesComponent', () => {
  let component: NotesComponent;
  let fixture: ComponentFixture<NotesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [NotesComponent],
      imports: [HttpClientTestingModule, FormsModule, ReactiveFormsModule],
      providers: [
        { provide: NotesGraphqlService, useValue: notesGraphqlServiceStub }, { provide: UserSessionService, useClass: UserSessionMockService}, HttpClient
      ],
      schemas: [NO_ERRORS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NotesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  afterEach(() => {
    fixture.destroy();
  });

  afterAll(() => {
    TestBed.resetTestingModule();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should run #ngOnInit()', async () => {
    component.ngOnInit();
  });

  it("should save notes provider role", () => {
    const noteObject = {
      "hsc_id": "5443",
      "note_txt_lobj": "added note by gopi",
      "creat_user_id": "ngopi2",
      "note_titl_txt": "gopi",
      "src_user_nm": "Provider",
      "hsr_note_sbjs": {
        "data": {
          "note_sbj_rec_id": "rec_id",
          "note_sbj_typ_ref_id": 12,
          "inac_ind": 0
        }
      }
    }
    component.subject = "subject"
    component.role = "Provider"
    component.checked = true
    component.dispVal = "hide"
    component.type = "Provider Comments";
    component.typeN = 10;
    //const service = TestBed.get(HttpClientTestingModule)
    expect(component.role).toBe("Provider")
    expect(component.type).toBe("Provider Comments")
    expect(component.checked).toBeTrue()
   const httpHeaders = new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': 'Basic ' + btoa('wbadmin:wbadmin')
    });
    const httpOptions = {
      headers: httpHeaders
    };
    const body = {
      note: noteObject,
    };
    const service = TestBed.inject(HttpClient);
    service.post(environment.SAVE_NOTE_HTTP_FUNTION_URL, body, httpOptions).subscribe((data: any) => {
      expect(data).toBe(noteObject);
      component.setNote(noteObject);
      expect(component.setNote).toBeTruthy()
    })

    component.onSaveClick();
    expect(component.onSaveClick).toBeTruthy()
  });

  it("should save notes admin", () => {
    component.subject = "subject"
    component.role = "admin"
    component.type = "Admin Comments";
    component.typeN = 12;
    //const service = TestBed.get(HttpClientTestingModule)
    expect(component.role).toBe("admin")
    expect(component.type).toBe("Admin Comments")
    expect(component.typeN).toBe(12)
    component.onSaveClick();
    expect(component.onSaveClick).toBeTruthy()
  });

  it("should save notes reviewr", () => {
    component.subject = "subject"
    component.role = "reviewer"
    component.checked = true
    component.type = "Reviewer Comments";
    component.typeN = 10;
    expect(component.role).toBe("reviewer")
    expect(component.checked).toBeTrue()
    expect(component.type).toBe("Reviewer Comments")
    expect(component.typeN).toBe(10)
    component.onSaveClick();
    expect(component.onSaveClick).toBeTruthy()
  });

  it("should enable mesgDialog", () => {
    component.mesgDialog = false;
    component.onMesgDiscardClick();
    expect(component.mesgDialog).toBeTrue();
  });

  it("should set onDiscardClick", () => {
    component.note = "reset";
    component.mesgDialog = true;
    component.onDiscardClick();
    expect(component.note).toEqual("");
    expect(component.mesgDialog).toBeFalse();
  });

  it("should enable mesg dialog onCancel", () => {
    component.mesgDialog = true;
    component.onCancel()
    expect(component.mesgDialog).toBeFalse();
  });

  it("should set onDiscardClick", () => {
    component.note = "reset";
    component.mesgDialog = true;
    component.onDiscardClick();
    expect(component.note).toEqual("");
    expect(component.mesgDialog).toBeFalse();
  });

  it("should validate note on validateNote", () => {
    component.note = "reset";
    expect(component.validateNote()).toBeFalsy();
  });

  it("should update remaining template text character count", () => {
    component.onCountChange(1);
    expect(component.remainingCount).toEqual(1);
  });

  it('should update notes list', () => {
    //component.trimmedNotesList = [];
    const result = [{
      creat_dttm: "8/3/20, 2:51 PM",
      creat_user_id: "TestUser1",
      hsr_note_sbj: { inac_ind: 0, chg_dttm: "8/3/20, 2:51 PM", chg_user_id: "TestUser1" },
      note_catgy_ref_id: 104,
      note_txt_lobj: "test1",
      note_typ_ref_id: "-1"
    }];
    component.setNote(result)
    expect(component.setNote).toBeTruthy()
    //component.inputRefData = refData;
    //expect(component.trimmedNotesList[0].note).toEqual("test1");
  });

  it("should reset note", () => {
    component.note = "reset";
    //component.checked = "false";
    expect(component.reset()).toBeFalsy();
  });

  it("should call myValueChange", () => {
    component.oneBoxItem.checked = true;
    component.myValueChange('');
    expect(component.myValueChange).toBeTruthy();
  });

  it("should make notes required when subject is available", () => {
    component.noteForm.setValue({
      subject: "test Notes"
    });
    component.onTextChange();
    expect(component.required).toBeTrue();
  });

  it("should make notes not required when subject is empty", () => {
    component.noteForm.setValue({
      subject: ""
    });
    component.onTextChange();
    expect(component.required).toBeFalse();
  });

  it('should call setNote', () => {
    const result = {
      creat_dttm: "8/3/20, 2:51 PM",
      creat_user_id: "TestUser1",
      hsr_note_sbj: { inac_ind: 0, chg_dttm: "8/3/20, 2:51 PM", chg_user_id: "TestUser1" },
      note_catgy_ref_id: 104,
      note_txt_lobj: "test1",
      note_typ_ref_id: "-1"
    };
    component.setNote(result);
    //component.inputRefData = refData;
    expect(component.setNote).toBeTruthy()
  });
  it('prepareNotesDisply() invokes', () => {
    component.tkExpandableRowEnable = true
    const result = [
      {
        "dateTime": "2020-10-06",
        "subject": "Note",
        "author": "Provider",
        "role": "user",
        "hsr_note": [
          {
            "creat_dttm": "2020-10-09",
            "note_titl_txt": "note",
            "src_user_nm": "System",
            "creat_user_id": "author"

          }
        ]
      }
    ]

    component.notesExpandableRecords.push(result)
    expect(component.notesExpandableRecords).toBeDefined()
    expect(component.tkExpandableRowEnable).toBe(true)
    component.prepareNotesDisplay(result)
    expect(component.prepareNotesDisplay).toBeTruthy()
  });

});

