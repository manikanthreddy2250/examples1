import { DatePipe, CommonModule } from '@angular/common';
import {Component, EventEmitter, Output, NgModule, OnInit, Input, OnDestroy} from '@angular/core';
import {Subscription} from 'rxjs';
import { NotesGraphqlService } from 'src/app/services/noteservice/notes-graphql.service';
import { NoteserviceService } from 'src/app/services/noteservice/noteservice.service';
import {StepperDataService} from 'src/app/services/StepperDataService/StepperDataService';
import { UserSessionService } from 'src/app/shared/services/user-session/user-session.service';
import { UITKTextAreaModule, UITKCheckboxModule, UITKFieldsetModule } from '@uitk/angular';
import { FormsModule, ReactiveFormsModule, FormGroup, FormControl, Validators } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import {FlowType} from '../../models/enums/flowType';
import {NotesConfirmationComponent} from "../confirmation/notes-confirmation/notes-confirmation.component";
import { NotesConstants } from 'src/app/constants/notesConstants';
import {UmIntakeFuncGraphqlService} from '../../services/um-intake-functions/umintakefunc-graphql.service';

@Component({
  selector: 'um-notes',
  templateUrl: './notes.component.html',
  styleUrls: ['./notes.component.scss']
})
export class NotesComponent implements OnInit, OnDestroy {
  tkExpandableRowEnable;
  public selectedItems = [];
  note: string;
  notes;
  role: string;
  type = NotesConstants.type;
  typeN;
  author: string;
  mesgDialog = false;
  maxNotesLength = 150;
  checked: boolean;
  required: boolean = false;
  displayValue = false;
  dispVal;
  myCharRemaining = NotesConstants.myCharRemaining;
  myTextLimit: number = 1000;
  subjectErrorMsg = NotesConstants.subjectErrorMsg;
  notesErrorMessage = NotesConstants.notesErrorMessage;
  subjectError = false;
  remainingCount: number;
  myValue: string;
  subject: string;
  requiredText = NotesConstants.requiredText;
  public oneBoxItem = { label: 'Hide from Provider', val: 'AGREE', checked: false, disabled: false };
  noteForm: FormGroup;
  stepperData: any;
  public tkRowNotesComponent = NotesConfirmationComponent;
  notesExpandableRecords = [];
  notesRecordcounter
  notesResultsTable = {
    title: 'Notes Results Table',
    enableSorting: true
  };
  notesColumns: any = [
    { label: 'Date/Time', id: 'dateTime', dataType: 'text', style: { width: '15px' } },
    { label: 'Subject', id: 'subject', dataType: 'text', style: { width: '200px' } },
    { label: 'Role', id: 'role', dataType: 'text', style: { width: '20px' } },
    { label: 'Author', id: 'author', dataType: 'text', style: { width: '10px' } }
  ];
  httpHeaders = new HttpHeaders({
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'Authorization': 'Basic ' + btoa('wbadmin:wbadmin')
  });
  stepperDataSubscription: Subscription;
  ngOnInit(): void {
    this.stepperDataSubscription = this.stepperDataService.sharedStepperData.subscribe((stepperData) => this.stepperData = stepperData);
    this.noteForm = new FormGroup({
      subject: new FormControl(''),
    });
    if(this.stepperData.flowType === FlowType.EDIT){
      this.prepareNotesDisplay(this.stepperData.hsc.hsr_notes)
    }
  }
  ngOnDestroy() {
    this.stepperDataSubscription.unsubscribe();
  }

  @Output() outputNotes: EventEmitter<any> = new EventEmitter();

  constructor(private readonly userSessionService: UserSessionService
    , private readonly notesGraphqlService: NotesGraphqlService,
    private readonly httpClient: HttpClient, private stepperDataService: StepperDataService,
              public readonly umIntakeFuncGraphqlService: UmIntakeFuncGraphqlService) {
    this.role = this.userSessionService.getUserPermission();
    if (this.role == "reviewer") {
      this.displayValue = true
      // console.log("displayValue " + this.displayValue);
    }
  }
  prepareNotesDisplay(notesRecords) {
    this.notesExpandableRecords = [];
    if (((notesRecords) && (notesRecords !== undefined)) && (notesRecords.length > 0)) {
      notesRecords.forEach((element) => {
        const notesObject = {
          dateTime: element.creat_dttm,
          subject: element.note_titl_txt,
          role: element.src_user_nm,
          author: element.creat_user_id,
          note: element.note_txt_lobj,
          expanded: true
        };
        this.notesExpandableRecords.push(notesObject);
      });
    }
    this.notesRecordcounter = this.notesExpandableRecords.length;
  }
  onSaveClick() {
    this.subject = this.noteForm.get('subject').value ? this.noteForm.get('subject').value : null;
    this.author = this.userSessionService.getUserName();
    this.role = this.userSessionService.getUserPermission();
    if (this.role == "reviewer" && this.checked) {
      this.dispVal = "hide";
      // console.log("checkbox checked" + this.checked);
    }
    else {
      this.dispVal = "display";
    }
    if (this.role == "reviewer") {
      this.type = "Reviewer Comments";
      this.typeN = 10;
    }
    if (this.role == "Provider") {
      this.type = "Provider Comments";
      this.typeN = 11;
    }
    if (this.role == "admin" || this.role == 'clinician') {
      this.type = "Admin Comments";
      this.typeN = 12;
    }
    if (this.subject != null) {
        const noteObject = {
          hsc_id: this.stepperData.hscId,
          note_txt_lobj: this.note,
          note_titl_txt: this.subject,
          src_user_nm: this.role,
          note_typ_ref_id: this.typeN,
          hsr_note_sbjs: {
            data: {
              note_sbj_rec_id: 'rec_id',
              note_sbj_typ_ref_id: 12,
              inac_ind: 0
            }
          }
        };
        this.umIntakeFuncGraphqlService.saveNotesMutation(noteObject).subscribe((data: any) => {
         // console.log('Saved Notes!');
         // console.log(`data... ${JSON.stringify(data)}`);
          const hsr_note_id = data.data.saveNote.hsr_note_id;
          const creat_dttm = data.data.saveNote.creat_dttm;
          const creat_user_id = data.data.saveNote.creat_user_id;
          const result = {creat_dttm,
                          creat_user_id,
                          note_txt_lobj: noteObject.note_txt_lobj,
                          note_titl_txt: noteObject.note_titl_txt,
                          hsr_note_id,
                          note_typ_ref_id: this.typeN,
                          hsc_id: this.stepperData.hscId,
          };
          this.setNote(result);
        },
          (error) => {
            if (error) {
              // this.showProcedureError();
           //   console.log('error...'+error);
            }
          });
        this.required = false;
        this.note = '';
        this.noteForm.reset();
     }
    else{
          this.subjectError = true;
    }
  }

  setNote(result) {
    const pipe = new DatePipe('en-US');
    const currentDateTime = pipe.transform(
      result.creat_dttm, 'short', 'UTC');
    const note = result.note_txt_lobj;
    const author = result.creat_user_id;
    const type = result.note_typ_ref_id;
    const subject = result.note_titl_txt;
    const hscId = result.hsc_id;
    const hsrNoteId = result.hsr_note_id;
    const notes = { dateTime: currentDateTime, type: this.type, note, author, subject, hscId, hsrNoteId };
    this.outputNotes.emit(notes);
  }

  onMesgDiscardClick() {
    this.mesgDialog = true;

  }

  onDiscardClick() {
    this.note = '';
    this.noteForm.reset();
    this.mesgDialog = false;
  }

  onCancel() {
    this.mesgDialog = false;
  }

  onTextChange(){
    if(this.noteForm.get('subject').value){
      this.required = true;
    }else{
      this.required = false;
    }
  }

  reset() {
    this.note = '';
    this.subject = '';
    this.checked = false;
  }

  validateNote = () => {
    if (!this.note || (this.note && this.note.trim() === '')) {
      return true;
    }
    return false;
  }
  public myValueChange(selectedItems) {
    this.checked = selectedItems.checked;
    console.log(selectedItems.checked);
  }


  onCountChange(count: number) {
    this.remainingCount = count;
  }

}
