import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'um-procedure-code',
  templateUrl: './procedure-code.component.html',
  styleUrls: ['./procedure-code.component.scss']
})
export class ProcedureCodeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
