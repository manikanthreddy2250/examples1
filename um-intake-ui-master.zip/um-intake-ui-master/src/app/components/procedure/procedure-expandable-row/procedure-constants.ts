export class ProcedureConstants {
  public static readonly NOT_IN_COVERAGE_RANGE = 'Date cannot be outside of the Member\'s Effective/Termination Date.';
  public static readonly END_DT = 'Date cannot be prior to Start Date.';
  public static readonly START_DT = 'Date cannot be in the past';
  public static readonly DATE_CANNOT_BE_FUTURE = 'Date cannot be future';
  public static readonly INVALID_DATE = 'Date format is invalid';
  public static readonly DME_TYPCST: string[] = ['DME Type', 'DME Cost'];
  public static readonly DME_DESSRV: string[] = ['Service Description'];
  public static readonly DME_INITTR: string[] = ['Initial Treatment'];
  public static readonly DME_EQUIP: string[] = ['Clinical Illness', 'Item Description'];
  public static readonly DME_SSON: string[] = ['Sole Source of Nutrition', 'Formula Name','Medical Condition'];
  public static readonly OthrTxtReq: string[] = ['Other Info'];
}
