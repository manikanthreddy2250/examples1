import { HttpClient, HttpHandler } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import {ChangeDetectorRef, Component, CUSTOM_ELEMENTS_SCHEMA, Injectable, NO_ERRORS_SCHEMA} from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {
  AbstractControl, ControlValueAccessor, DefaultValueAccessor, FormArray, FormBuilder, FormControl, FormGroup
  , FormsModule, NG_VALUE_ACCESSOR, ReactiveFormsModule, ValidationErrors, ValidatorFn, Validators
} from '@angular/forms';
import {FormFieldService} from '@uimf/uitk';
import { UITKRadioGroupModule } from '@uitk/angular';
import {Observable, of} from 'rxjs';
import {uitkAngularModules, uitkModules} from '../../../app.module';
import {ProcedureServiceService} from '../../../services/procedure/procedure-service.service';
import {ProviderSearchService} from '../../../services/provider-search/provider-search.service';
import {ReferenceService} from '../../../services/refernce-service/reference.service';
import {ProcedureComponent} from '../procedure.component';
import { ProcedureExpandableRowComponent } from './procedure-expandable-row.component';
import {UserSessionService} from '../../../shared/services/user-session/user-session.service';
import {SysConfigService} from '../../../services/sysconfig-service/sys-config.service';

@Injectable()
class MockHttpClient {
  post(url: string, body: any | null, options?: any) {
    if (url.includes('dme_RangeRules_Config')) {
      return of([
        {
          procRngCatgySeqnbr: {
            type: 'Integer',
            value: 7,
            valueInfo: {}
          },
          procCatgyTypid: {
            type: 'String',
            value: 'DME_InitTr',
            valueInfo: {}
          }
        }
      ]);
    } else if (body.includes('getReferenceCd')) {
      return of({ data : {ref: [{ref_cd: 123}]} });
    } else if (body.includes('getReferenceDataForStateQuery')) {
      return of({ data : {ref_set: [{ref_cd: 123}]} });
    } else {
      return of({});
    }
  }
  get(url: string, body: any | null, options?: any) {
    return of([
      {
        id: 'um_intake_ui_1.0.0_ecp_authorization_type_2021-02-12',
        createDateTime: '2021-02-12T21:12:29.235+00:00',
        creatUserId: null,
        changeDateTime: '2021-02-12T21:12:29.235+00:00',
        changeUserId: null,
        updateVersionNumber: '0',
        createSystemReferenceId: null,
        changeSystemReferenceId: null,
        dataSecureRuleList: null,
        dataGltyIssList: null,
        application: 'um_intake_ui',
        version: '1.0.0',
        org: 'ecp',
        role: null,
        key: 'authorization_type',
        value: '{"authorizationTypeRefIds":[20135, 20136, 20137, 20138]}',
        startDate: '2021-02-12T00:00:00.000+00:00',
        endDate: null,
        inactivityIndicator: '0'
      }
    ]);
  }
}

@Injectable()
class ProviderSearchMockService {
  getProviderTinOrNpiSearch(providerCategoryId, providerTIN, providerNPI): Observable<any> {
    return of({ data: {
        v_prov_srch: [{prov_id: '667', providerTin: '345', addressLine: 'test', lst_nm: 'test', fst_nm: 'test',
          bus_nm: 'facility', telcom_adr_id: '46', spcl_ref_dspl: 'vg', spcl_ref_id: '546',
          prov_loc_affil_id: '8686'}]
      } });
  }
  getProviderDetailsSearch(provId, provAdrId, provtelcomAdrId, ProvSpecialtyRefId): Observable<any> {
    return of({ data: {
        v_prov_srch: [{prov_id: '667', providerTin: '345', addressLine: 'test', lst_nm: 'test', fst_nm: 'test',
          bus_nm: 'facility', telcom_adr_id: '46', spcl_ref_dspl: 'vg', spcl_ref_id: '546', }]
      } });
  }
  setProviderDetails(providerTelecomAddressId: string, providerSpecialtyRefId: string,
                     providerLocationAffiliationId: string, PROVIDER_ROLE_REF_ID: number, stepperData: any): Observable<any> {
    return of({hscduplicates: [{hsc_id: 123}]});
  }
  getProviderNameSearch(providerCategoryId: number, providerFirstName: string, providerLastName: string, providerState: number,
                        providerZipCode: string, providerOrgName: string): Observable<any> {
    return of({});
  }
  getProviderTinOrNpi(providerID: string, providerKeyTypeRefId: number): Observable<any> {
    return of({data: {
        prov_key: [{prov_key_val: '455'}]
      }});
  }
  getHscProvider(hscid): Observable<any> {
    return of({data: {
        hsc_prov: [{prov_key_val: '455', prov_loc_affil_dtl: {providerDetails: { prov_id: 90, prov_adr_id: 2355, prov_cat_typ_ref_id: 16309}},
          prov_loc_affil_id: 76, hsc_prov_roles: [{prov_role_ref_id: 3760}]
        }, {prov_key_val: '455', prov_loc_affil_id: 76, hsc_prov_roles: [{prov_role_ref_id: 3758}]
        }]}});
  }
  getProviderTinSearch(locationAffiliationId: number, providerTIN: string, providerTINKey: number) {
    return of({data: {
        v_prov_srch: [{st_ref_id: 172, prov_id: 125, adr_ln_1_txt: 'g', adr_ln_2_txt: 'r', cty_nm: 'test', zip_cd_txt: '645456',
          spcl_ref_id: 437, }]
      }});
  }
}

@Injectable()
class UserSessionMockService {
  i = 0;
  getUserName() {
    if (this.i === 0) {
      this.i++;
      return 'breddy88';
    } else if (this.i === 1) {
      this.i = this.i + 2;
      return 'SYSTEM';
    } else if (this.i === 3)  {
      return 'abcd';
    }
  }
  getUserOrg() {
    return 'ecp';
  }
  getUserPermission() {}

  getEcpToken() {return 'dfghjk'; }
  getFunctionalRole() {}
}


@Injectable()
class ReferenceMockService {
  loadRefDataByRefID(refIds: any): Observable<any>{
  return of({data: {ref: [{ref_cd: 34}]}});
  }
  getReferenceDataForState(refIds: any): Observable<any>{
  return of({data: {ref_set: [{ref_id: 1059,ref_nm: "stateCode", ref:
			[{ref_cd: "AA", ref_id: 1059,}]}]}});
  }
}

describe('ProcedureExpandableRowComponent', () => {
    let component: ProcedureExpandableRowComponent;
    let fixture: ComponentFixture<ProcedureExpandableRowComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [uitkModules, uitkAngularModules, FormsModule, ReactiveFormsModule, HttpClientTestingModule, UITKRadioGroupModule],
            providers: [ FormFieldService, { provide: ReferenceService, useClass: ReferenceMockService }, ProcedureServiceService, ProcedureComponent, ChangeDetectorRef, { provide: HttpClient, useClass: MockHttpClient },
              { provide: ProviderSearchService, useClass: ProviderSearchMockService }, { provide: UserSessionService, useClass: UserSessionMockService}],
            declarations: [ProcedureExpandableRowComponent],
            schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
        })
            .compileComponents();
    }));

    beforeEach(async () => {
        fixture = TestBed.createComponent(ProcedureExpandableRowComponent);
        component = fixture.componentInstance;
        component.stepperDataService.setStepperData({tenantId: 'ecpumintakebaseproductbpmgroup', hsc: {srvc_set_ref_id: 3737}, hscProcedures: [{code: '123', description: 'test'}]});
        component.nestedData = {
            proc_cd_schm_ref_id: 2,
            procedureType: 'CPT4', code: '1118F',
            description: ' GERD SYMPTOMS ASSESSED AFTER 12 MONTHS THERAPY', hscId: '1557', procedureCounter: 1, expanded: true,
            procedureCategory: [{ name: 'DME_TypCst', rank: 1 }] , procedureOthrTxtSwitch: 1
        };
        component.procCatAndRank = [{ name: 'DME_TypCst', rank: 1 }];
        component.procedureOthrTxtSwitch = 1;
        fixture.detectChanges();
    });

    afterEach(() => {
        fixture.destroy();
    });

    it('should create', () => {
        component.nestedData = {
            procedureType: 'CPT4', code: '1118F',
            description: ' GERD SYMPTOMS ASSESSED AFTER 12 MONTHS THERAPY', hscId: '1557', procedureCounter: 1,
            expanded: true, procedureCategory: [{ name: 'DME_TypCst', rank: 1 }]
            , procedureOthrTxtSwitch: 1
        };
        fixture.detectChanges();
        expect(component).toBeTruthy();
    });

    it('should call changeSrvcTypeDropdownVal', () => {
        const model = {
            value: 'value',
            id: 'id'
        };
        component.nestedData = {
            procedureType: 'CPT4', code: '1118F',
            description: ' GERD SYMPTOMS ASSESSED AFTER 12 MONTHS THERAPY', hscId: '1557', procedureCounter: 1, expanded: true, procedureCategory: [{ name: 'DME_TypCst', rank: 1 }]
        ,   procedureOthrTxtSwitch: 1};
        spyOn(component, 'changeSrvcTypeDropdownVal').and.callThrough();
        component.changeSrvcTypeDropdownVal(null);
        component.changeSrvcTypeDropdownVal(model);
        expect(component.changeSrvcTypeDropdownVal).toBeTruthy();
        expect(component.selectedVal).toEqual(model);
    });

    it('should call changeSrvcTypeDropdownVal', () => {
        const model = {
            value: 'value',
            id: 'id'
        };
        spyOn(component, 'changeprocFrequencyDropdownVal').and.callThrough();
        component.changeprocFrequencyDropdownVal(null);
        component.changeprocFrequencyDropdownVal(model);
        expect(component.changeprocFrequencyDropdownVal).toBeTruthy();
        expect(component.selectedVal).toEqual(model);
    });

    it('should call changestandardMeasureDropdownVal', () => {
        const model = {
            value: 'value',
            id: 'id'
        };
        spyOn(component, 'changestandardMeasureDropdownVal').and.callThrough();
        component.changestandardMeasureDropdownVal(null);
        component.changestandardMeasureDropdownVal(model);
        expect(component.changestandardMeasureDropdownVal).toBeTruthy();
        expect(component.selectedVal).toEqual(model);
    });

    it('should call changeprocModifierOneDropdownVal', () => {
        const model = {
            value: 'value',
            id: 'id'
        };
        spyOn(component, 'changeprocModifierOneDropdownVal').and.callThrough();
        component.changeprocModifierOneDropdownVal(null);
        component.changeprocModifierOneDropdownVal(model);
        expect(component.changeprocModifierOneDropdownVal).toBeTruthy();
        expect(component.selectedVal).toEqual(model);
    });

    it('should call changeprocModifierTwoDropdownVal', () => {
        const model = {
            value: 'value',
            id: 'id'
        };
        spyOn(component, 'changeprocModifierTwoDropdownVal').and.callThrough();
        component.changeprocModifierTwoDropdownVal(null);
        component.changeprocModifierTwoDropdownVal(model);
        expect(component.changeprocModifierTwoDropdownVal).toBeTruthy();
        expect(component.selectedVal).toEqual(model);
    });

    it('should call changeprocModifierThreeDropdownVal', () => {
        const model = {
            value: 'value',
            id: 'id'
        };
        spyOn(component, 'changeprocModifierThreeDropdownVal').and.callThrough();
        component.changeprocModifierThreeDropdownVal(null);
        component.changeprocModifierThreeDropdownVal(model);
        expect(component.changeprocModifierThreeDropdownVal).toBeTruthy();
        expect(component.selectedVal).toEqual(model);
    });

    it('should call changeprocModifierFourDropdownVal', () => {
        component.nestedData = { procedureType: 'CPT4', code: '1118F', description: ' GERD SYMPTOMS ASSESSED AFTER 12 MONTHS THERAPY', hscId: '1557', procedureCounter: 1, expanded: true, procedureCategory: [{ name: 'DME_TypCst', rank: 1 }]
        ,                        procedureOthrTxtSwitch: 1};
        const model = {
            value: 'value',
            id: 'id'
        };
        spyOn(component, 'changeprocModifierFourDropdownVal').and.callThrough();
        component.changeprocModifierFourDropdownVal(null);
        component.changeprocModifierFourDropdownVal(model);
        expect(component.changeprocModifierFourDropdownVal).toBeTruthy();
        expect(component.selectedVal).toEqual(model);
    });

    it('should run SetterDeclaration #tkRowInfo', async () => {
        component.covStartDate = '2020-07-24';
        component.covEndDate = '2020-12-31';
        component.facilityTypeForProc = {id: 3742, label: 'Home', value: 'Home'};
        component.nestedData = { procedureType: 'CPT4', code: '1118F', description: 'GERD', hscId: '1557', procedureCounter: 1, expanded: true, procedureCategory: [{ name: 'DME_TypCst', rank: 1 }] , procedureOthrTxtSwitch: 1};
        component.procCatAndRank = [{ name: 'DME_TypCst', rank: 1 }];
        component.procedureCount = 1;
        component.procedureOthrTxtSwitch = 0;
        await component.ngOnInit();
        expect(component.ngOnInit).toBeTruthy();
    });

    /* it('should cancelForm button', () => {
      component.procedureForm = component.procedureForm || {}
       component.cancelForm()
       expect(component.cancelForm).toBeDefined()
     });
    */
    it('should onCountChange', () => {
        component.onCountChange(5);
        expect(component.onCountChange).toBeTruthy();
    });

    it('should onCountChangeOtherInfo', () => {
        component.onCountChangeOtherInfo(5);
        expect(component.onCountChangeOtherInfo).toBeTruthy();
    });
    it('should onCountChangeFormula', () => {
        component.onCountChangeFormula(5);
        expect(component.onCountChangeFormula).toBeTruthy();
    });
    it('should onCountChangeMedical', () => {
        component.onCountChangeMedical(5);
        expect(component.onCountChangeMedical).toBeTruthy();
    });

    it('should onCountChangeClinical', () => {
        component.onCountChangeClinical(5);
        expect(component.onCountChangeClinical).toBeTruthy();
    });
    it('should onCountChangeItemDesc', () => {
        component.onCountChangeItemDesc(5);
        expect(component.onCountChangeItemDesc).toBeTruthy();
    });

    it('should run #onCountChange()', async () => {
        let count = 50;
        component.remainingCount = count;
        component.onCountChange(count);
        expect(component.onCountChange).toBeTruthy();

    });

    it('should  identifyFieldToBeDispalyed DME_TypCst true', () => {
        let procCatAndRank = [{ name: 'DME_TypCst', rank: 1 }];
        let procedureOthrTxtSwitch = 0;
        component.facilityTypeForProc = {id: 3742, label: 'Home', value: 'Home'};
        component.identifyFieldToBeDispalyed(procCatAndRank, procedureOthrTxtSwitch);
        expect(component.identifyFieldToBeDispalyed).toBeTruthy();
    });

    it('should  identifyFieldToBeDispalyed DME_Equip true', () => {
        let procCatAndRank = [{ name: 'DME_Equip', rank: 2 }];
        let procedureOthrTxtSwitch = 1;
        let tenantId = 'sampleId';
        component.identifyFieldToBeDispalyed(procCatAndRank, procedureOthrTxtSwitch);
        expect(component.identifyFieldToBeDispalyed).toBeTruthy();
    });

    it('should  identifyFieldToBeDispalyed DME_DesSrv true', () => {
        let procCatAndRank = [{ name: 'DME_DesSrv', rank: 7 }];
        let procedureOthrTxtSwitch = 1;
        component.identifyFieldToBeDispalyed(procCatAndRank, procedureOthrTxtSwitch);
        expect(component.identifyFieldToBeDispalyed).toBeTruthy();
    });

    it('should  identifyFieldToBeDispalyed OthrTxtReq true', () => {
        let procCatAndRank = [{ name: 'OthrTxtReq', rank: 10 }];
        let procedureOthrTxtSwitch = 1;
        component.identifyFieldToBeDispalyed(procCatAndRank, procedureOthrTxtSwitch);
        expect(component.identifyFieldToBeDispalyed).toBeTruthy();
    });

    it('should  identifyFieldToBeDispalyed DME_InitTr true', () => {
        let procCatAndRank = [{ name: 'DME_InitTr', rank: 5 }];
        let procedureOthrTxtSwitch = 1;
        component.identifyFieldToBeDispalyed(procCatAndRank, procedureOthrTxtSwitch);
        expect(component.identifyFieldToBeDispalyed).toBeTruthy();
    });

    it('should  identifyFieldToBeDispalyed DME_SSON true', () => {
        let procCatAndRank = [{ name: 'DME_SSON', rank: 6 }];
        let procedureOthrTxtSwitch = 1;
        component.identifyFieldToBeDispalyed(procCatAndRank, procedureOthrTxtSwitch);
        expect(component.identifyFieldToBeDispalyed).toBeTruthy();
    });

    it('should getProviderAddressLine', () => {
    component.getProviderAddressLine('Adr1', 'Adr2', 'newyork', 'NYZ123', '4567');
    expect(component.getProviderAddressLine).toBeDefined();
  });

    it('should getProviderResultsData', () => {
    component.PHYSICIAN_CAT_ID = 16309;
    component.PHYSICIAN_CAT_ID = 16310;
    component.providerData = [{st_ref_id: 1072}, 'test2'];
    component.getProviderResultsData();
    expect(component.getProviderResultsData).toBeDefined();
  });

    it('should getFacilityProviderDataOnTinOrNpi', () => {
    component.getFacilityProviderDataOnTinOrNpi();
    expect(component.getFacilityProviderDataOnTinOrNpi).toBeDefined();
  });

    it('should getPhysicianProviderDataOnTinOrNpi', () => {
    component.tinOrNipform = new FormGroup({
      providerTIN: new FormControl(''),
      providerNPI: new FormControl('')
    });
    component.getPhysicianProviderDataOnTinOrNpi();
    expect(component.getPhysicianProviderDataOnTinOrNpi).toBeDefined();
  });

    it('should getFacilityProviderData', () => {
    component.getFacilityProviderData();
    expect(component.getFacilityProviderData).toBeDefined();
  });

    it('should getFacilityProviderData for valid form', () => {
    component.facilityNameStateOrZipform.controls['facilityState'].setValue('CA');
    component.facilityNameStateOrZipform.controls['providerOrgName'].setValue('RIVERSIDE');
    component.getFacilityProviderData();
    expect(component.getFacilityProviderData).toBeDefined();
  });

  // it('should getPhysicianProviderDataOnTinOrNpi', () => {
  //     component.tinOrNipform.controls['providerTIN'].setValue('3566');
  //     const providerSearchService = TestBed.get(ProviderSearchService)
  //     const spy = spyOn(providerSearchService, 'getProviderTinOrNpiSearch')
  //    component.getPhysicianProviderDataOnTinOrNpi();
  //    expect(component.getPhysicianProviderDataOnTinOrNpi).toBeDefined();
  //     expect(spy).toHaveBeenCalled();
  //  });

    it('should getPhysicianProviderData', () => {
    spyOn(component, 'getPhysicianProviderData').and.callThrough();
    component.getPhysicianProviderData();
    expect(component.invalidFormSubmitted).toBeDefined();
    expect(component.getPhysicianProviderData).toBeDefined();

  });

    it('should getPhysicianProviderData for valid form', () => {
    component.nameStateOrZipform.controls['providerLastName'].setValue('Attia');
    component.nameStateOrZipform.controls['providerFirstName'].setValue('Fadia');
    component.nameStateOrZipform.controls['providerState'].setValue('CA');

    component.getPhysicianProviderData();
    expect(component.invalidFormSubmitted).toBeDefined();
    expect(component.getPhysicianProviderData).toBeDefined();

  });

    it('should set tin', () => {
    const providerTin = {data: {prov_key: [{prov_key_val: 123}]}};
    component.setTin(providerTin);
    expect(component.setTin).toBeDefined();
  });

    it('should clear', () => {
    component.onClear();
    expect(component.onClear).toBeTruthy();
  });

    it('closeRow should collapse the row', () => {
    component.closeRow();
    expect(component.nestedData.expanded).toBeFalse();
  });

    it('submitForm should set error message visible if the form is invalid', () => {
    component.procedureForm = new FormGroup({
      servicingProvider: new FormControl('', Validators.required),
      serviceType: new FormControl(''),
      total: new FormControl(''),
      standardMeasure: new FormControl(''),
      count: new FormControl(''),
      frequency: new FormControl(''),
      serviceStartDate: new FormControl(''),
      serviceEndDate: new FormControl(''),
      procMod1: new FormControl(''),
      procMod2: new FormControl(''),
      procMod3: new FormControl(''),
      procMod4: new FormControl('')
    });
    component.submitForm();
    expect(component.message3.visible).toBeTrue();
  });

 it('should select provider for case table for facility', () => {
    const radioid = {
      toElement: {
        defaultValue: 'NameStateZip'
      }
    };
    component.onRadioChangeForFacility(radioid);
    expect(component.onRadioChangeForFacility).toBeTruthy();
  });

 it('should select onRadio Change For Servicinging Provider', () => {
      const radioid = {
        toElement: {
          defaultValue: 'NameStateZip'
        }
      };
      component.onRadioChangeForServicingingProvider(radioid);
      expect(component.onRadioChangeForServicingingProvider).toBeTruthy();
    });

 it('should cancelForm', () => {
    component.cancelForm();
    expect(component.cancelForm).toBeTruthy();
 });

 it('should getStartDateErrorMsg', () => {
     component.getStartDateErrorMsg();
     expect(component.getStartDateErrorMsg).toBeTruthy();
  });

 it('should getEndDateErrorMsg', () => {
     component.getEndDateErrorMsg();
     expect(component.getEndDateErrorMsg).toBeTruthy();
  });

 it('should editRow', () => {
      component.editRow();
      expect(component.editRow).toBeTruthy();
   });
  it('should getDMEConfig', async () => {
    await component.getDMEConfig(4, '123');
    expect(component.procCatAndRank.length).toEqual(1);
  });

  it('should setValuesForOPProc', () => {
    component.precedureRefData = {serviceTypeCodeList: [], standardMeasureList: [], procFrequencyList: [], procedureModifierList: [] };
    component.nestedData = {
      proc_cd_schm_ref_id: 2,
      procedureType: 'CPT4', code: '1118F',
      description: 'GERD SYMPTOMS ASSESSED AFTER 12 MONTHS THERAPY', hscId: '1557', procedureCounter: 1, expanded: true,
      hsc_srvc_non_facls: [{unit_per_freq_cnt: 1, proc_unit_cnt: 4, }]
    };
    component.setValuesForOPProc();
    expect(component.procedureForm.get('count').value).toEqual(4);
  });

  it ('should checkAndSetBussinessNameIfFacility', async () => {
    await component.checkAndSetBussinessNameIfFacility({providerCategoryRefId: 16310});
    expect(component.checkAndSetBussinessNameIfFacility).toBeTruthy();
  });
});
