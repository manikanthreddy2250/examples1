import { HttpClient, HttpHeaders } from '@angular/common/http';
import {Component, Input, OnDestroy, OnInit} from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import {RawQuery} from '@ecp/gql-tk-beta';
import {ITableInputModel} from '@uimf/uitk';
import {IUITKRadioGroupItem} from '@uitk/angular';
import {Observable, Subscription} from 'rxjs';
import {environment} from 'src/environments/environment';
import {ConfigConstants} from '../../../constants/configConstants';
import {Constants} from '../../../constants/constants';
import {ReferenceConstants} from '../../../constants/referenceConstants';
import {RulesConstants} from '../../../constants/rulesConstants';
import {ProcedureServiceService} from '../../../services/procedure/procedure-service.service';
import {ProcedureService} from '../../../services/procedure/procedure.service';
import {ProviderSearchService} from '../../../services/provider-search/provider-search.service';
import {ReferenceService} from '../../../services/refernce-service/reference.service';
import {StepperDataService} from '../../../services/StepperDataService/StepperDataService';
import {SysConfigService} from '../../../services/sysconfig-service/sys-config.service';
import {UserSessionService} from '../../../shared/services/user-session/user-session.service';
import {ProviderSearchComponent} from '../../provider-search/provider-search.component';
import {ReferenceSet} from '../../provider-search/referenceSet';
import {ProcedureComponent} from '../procedure.component';
import { ProcedureConstants } from './procedure-constants';

const PROVIDER_ROLE_REF_ID_SERVICING = 3765;
const PROVIDER_KEY_VALUE_TYP_REF_ID_NPI = 2782;
const PROVIDER_KEY_VALUE_TYP_REF_ID_TIN = 16333;
const PROVIDER_KEY_VALUE_TYP_REF_ID_MPIN = 2783;
@Component({
  selector: 'um-procedure-expandable-row',
  templateUrl: './procedure-expandable-row.component.html',
  styleUrls: ['./procedure-expandable-row.component.scss']
})
export class ProcedureExpandableRowComponent implements OnInit, OnDestroy {
  @Input()
  set tkRowInfo(selectedRow: any) {
    this.nestedData = selectedRow;
    this.procedureOthrTxtSwitch = this.nestedData.procedureOthrTxtSwitch;
    this.procedureCount = this.nestedData.procedureCounter;
    this.dmeData = this.nestedData?.hsc_srvc_non_facls && this.nestedData.hsc_srvc_non_facls[0].hsc_srvc_non_facl_dmes ? this.nestedData.hsc_srvc_non_facls[0].hsc_srvc_non_facl_dmes[0] : null;
  }

  constructor(public providerSearchService: ProviderSearchService,
              public readonly httpClient: HttpClient,
              private readonly formBuilder: FormBuilder,
              private readonly referenceService: ReferenceService,
              public procedureServiceService: ProcedureServiceService,
              private readonly service: ProcedureService,
              public stepperDataService: StepperDataService,
              public procedureComponent: ProcedureComponent,
              public providerSearchComponent: ProviderSearchComponent,
              private readonly sysConfigService: SysConfigService,
              private userSessionService: UserSessionService) {
    this.headerParams = {'x-hasura-role': Constants.UM_INTAKE_UI_APP_NAME + '_' + userSessionService.getUserPermission(),
                         'Authorization': 'Bearer ' + userSessionService.getEcpToken()};
    this.params = { headers: {...this.staticParams, ...this.headerParams} };
  }

  get dme(): FormArray {
    return this.procedureForm.get('dme') as FormArray;
  }
  private hscProvId: number;
  private providerMPIN: any;
  @Input()
  precedureRefData;
  public IP = ReferenceConstants.SERVICESETTINGTYPE_INPATIENT;
  public OP = ReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT;
  public OPF = ReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY;
  HSC_STATUS_TYPE_OPEN = ReferenceConstants.HSC_STATUS_TYPE_OPEN;
  HSC_STATUS_TYPE_DRAFT = ReferenceConstants.HSC_STATUS_TYPE_DRAFT;
  readonly httpUrl: string = environment.REFERENCE_API ;
  procedureCounter;
  procedureCount;
  remainingCount: number;
  remainingCountFormula: number;
  remainingCountMedical: number;
  remainingCountOtherInfo: number;
  remainingCountClinical: number;
  remainingCountItemDesc: number;
  myCharRemaining = 'characters remaining';
  headerParams: any = {};
  readonly contentType = 'application/json';
  private readonly staticParams: any = { 'content-type': this.contentType };

  procedureForm: FormGroup;
  public selectedradio = '2';
  total = 0;
  count = 0;
  public nestedData: any;
  dmeData: any;
  records = [];
  selectedVal: any;
  covStartDate;
  covEndDate;
  procCatAndRank = [];
  myTextLimit = 100;
  myTextLimitOtherInfo = 100;
  servicingProvider;
  proc: any = {};
  confirmOpRecord = [];
  params: any = {};
  providerData = []; // source of truth after search
  physicianResultsData: any[];
  selectedProviderResultsData: any[] = [];
  selectedFacilityResultsData: any[] = [];
  facilityResultsData: any[];
  REFERENCE_STATE = 'stateCode';
  PHYSICIAN_CAT_ID = 16309;
  FACILITY_CAT_ID = 16310;
  invalidFormSubmitted = false;
  notificationVisible = false;
  selectedRow: number;
  invalidFormErrorMessage: string;
  isEditProviderEnabled = true;
  servicingProviderSelected: any;

  medicalConditionRequiredMsg = 'Medical Condition is required';
  patternErrorTextTotal = 'Total should be a number';
  requiredText = 'Input is required';
  httpHeaders = new HttpHeaders({
    'Content-Type': this.contentType,
    'Accept': this.contentType
  });

  public configObj: any = {
    dateFormat: 'MM-dd-YYYY',
    minYear: 1900,
    minMonth: 1,
    minDay: 1,
    iconCalendar: true,
    enableValidation: true,
    enableLabels: true,
    customLabels: {
      calendar: 'Service Start Date',
    },
  };
  providerTin = '';
  providerNpi = '';
  public references: ReferenceSet[] = [];

  public facilityTinOrNipform = new FormGroup({
    facilityTIN: new FormControl(''),
    facilityNPI: new FormControl('')
  });

  public tinOrNipform = new FormGroup({
    providerTIN: new FormControl(''),
    providerNPI: new FormControl('')
  });

  public nameStateOrZipform = new FormGroup({
    providerFirstName: new FormControl(''),
    providerLastName: new FormControl('', Validators.required),
    providerState: new FormControl('', Validators.required),
    providerZipCode: new FormControl('', Validators.required),
  });

  public facilityNameStateOrZipform = new FormGroup({
    facilityState: new FormControl('', Validators.required),
    facilityZipCode: new FormControl('', Validators.required),
    providerOrgName: new FormControl('', Validators.required)
  });
  myRadioGroupSelectionForServicingProvider: any;
  public selectedradioForServicingProvider: any;

  configObj1: any = {
    dateFormat: 'MM-dd-YYYY',
    minYear: 1900,
    minMonth: 1,
    minDay: 1,
    iconCalendar: true,
    enableValidation: true,
    enableLabels: true,
    customLabels: {
      calendar: 'Service End Date',
    },
  };

  modelForPhysician: ITableInputModel = {
    title: 'Physician Results Table',
    enableSorting: true,
    enableFiltering: true,
    enableSingleRowSelect: true,
    clearAllFilters: true,
    fixedHeader: false,
    tkHidePagination: true,
    // pagination: {
    //   currentPageNumber: 1,
    //   recordsPerPage: 10,
    //   recordsPerPageOptions: [10, 25, 50, 75, 100],
    // },
    filterCondition: {
      columnSorting: {
        columnId: 'prov_id',
        sortOrder: -1
      }
    }
  };

  columnsForPhysicianTable: any = [
    {label: 'Name', id: 'lastName', dataType: 'text'},
    {label: 'Address', id: 'addressLine', dataType: 'text'},
    {label: 'Phone', id: 'phone', dataType: 'text'},
    { label: 'Specialty', id: 'specialty', dataType: 'text'},
    {label: 'TIN', id: 'providerTin', dataType: 'text'}
  ];

  modelForSelectedProviders: ITableInputModel = {
    title: 'Select From case',
    enableSorting: true,
    enableFiltering: true,
    enableSingleRowSelect: true,
    clearAllFilters: true,
    fixedHeader: false,
    tkHidePagination: true,
    // pagination: {
    //   currentPageNumber: 1,
    //   recordsPerPage: 10,
    //   recordsPerPageOptions: [10, 25, 50, 75, 100],
    // },
    filterCondition: {
      columnSorting: {
        columnId: 'prov_id',
        sortOrder: -1
      }
    }
  };

  results: any;

  columnsForSelectedProviderTable: any = [
    {label: 'Name', id: 'lastName', dataType: 'text'},
    {label: 'Address', id: 'addressLine', dataType: 'text'},
    {label: 'Phone', id: 'phone', dataType: 'text'},
    { label: 'Specialty', id: 'specialty', dataType: 'text'},
    {label: 'TIN', id: 'providerTin', dataType: 'text'},
    {label: 'NPI', id: 'providerNpi', dataType: 'text'}
  ];

  procedureOthrTxtSwitch;
  stepperData: any;
  private selectedradioForFacility: any;

  modelForFacility: ITableInputModel = {
    title: 'Facility Results Table',
    enableSorting: true,
    enableFiltering: true,
    enableSingleRowSelect: true,
    clearAllFilters: true,
    fixedHeader: false,
    tkHidePagination: true,
    // pagination: {
    //   currentPageNumber: 1,
    //   recordsPerPage: 10,
    //   recordsPerPageOptions: [10, 25, 50, 75, 100],
    // },
    filterCondition: {
      columnSorting: {
        columnId: 'prov_id',
        sortOrder: -1
      }
    }
  };

  columnsForFacilityTable: any = [
    {label: 'Name', id: 'businessName', dataType: 'text'},
    {label: 'Address', id: 'addressLine', dataType: 'text'},
    {label: 'Phone', id: 'phone', dataType: 'text'},
    { label: 'Specialty', id: 'specialty', dataType: 'text'},
    {label: 'TIN', id: 'providerTin', dataType: 'text'},
    {label: 'NPI', id: 'providerNpi', dataType: 'text'}
  ];

  items: IUITKRadioGroupItem[] = [
    {
      label: 'Yes',
      value: '3',
      disabled: false,
    },
    {
      label: 'No',
      value: '4',
      disabled: false,
    },
  ];

  dmeTypeItems: IUITKRadioGroupItem[] = [
    {
      label: 'Purchase',
      value: '1',
    },
    {
      label: 'Rental',
      value: '2',
    },
  ];
  // dmeTypeRadioGroupSelection = this.dmeTypeItems[0];
  // sourceOfNutriRadioGroupSelection = this.items[0];
  sourceOfNutriRadioGroupSelection;
  dmeTypeRadioGroupSelection;
  dmeInitTrFG: FormGroup = this.formBuilder.group({
    initialTreatmentDate: [''],
  });

  dmeSsonFG: FormGroup = this.formBuilder.group({
    sourceOfNutri: new FormControl('', Validators.required),
    formulaName: new FormControl('', [Validators.required]),
    medicalCondition: new FormControl('', Validators.required)
  });

  dmeEquipFG: FormGroup = this.formBuilder.group({
    clinicalIllenessDesc: new FormControl(''),
    itemDescription: new FormControl('', Validators.required)
  });

  dmeTypCstFG: FormGroup = this.formBuilder.group({
    dmeType: new FormControl('', Validators.required),
    dmeCost: new FormControl('', [Validators.required]),
  });

  dmeDesSrvFG: FormGroup = this.formBuilder.group({
    serviceDescription: new FormControl(''),
  });

  othrTxtReqFG: FormGroup = this.formBuilder.group({
    otherInfo: new FormControl(''),
  });

  procedureLimit: any;

  /*dme:FormArray= this.formBuilder.array([
                          ]);*/
  facilityTypeForProc;

  isdmeDesSrv = false;
  isDmeInitTr = false;
  isDmeTypCst = false;
  isdmeEquip = false;
  isdmeSson = false;
  isOthrTxtReq = false;
  isDefaultOtherTxt = false;
  message3 = {
    id: 'error_msg',
    messageType: 'error',
    content: 'Please fill all mandatory fields before clicking on Confirm',
    visible: false,
    closeButton: true,
  };

  referenceData = [];
  isNameStateRadioSelected = true;
  isTINAndNPISelected: boolean;
  isSpecialtyAndZipSelected: boolean;
  currentProviderSearchSpecialtyRefID: any;
  flagForSpeacilatySearchWarningVisibility = false;
  warningForSpecialtyValidaion = 'please enter Zip and Specialty';
  myRadioGroupSelectionForFacilityProvider: any;
  itemsForFacilityProviderSearch: IUITKRadioGroupItem[] = [
    {
      label: 'Name + State/Zip',
      value: 'NameStateZip'
    },
    {
      label: 'TIN and/or NPI',
      value: 'TINAndNPI'
    },
    {
      label: 'Zip and Specialty',
      value: 'ZipAndSpecialty'
    },
  ];
  itemsForPhysicianProviderSearch: IUITKRadioGroupItem[] = [
    {
      label: 'Name + State/Zip',
      value: 'NameStateZip'
    },
    {
      label: 'TIN and/or NPI',
      value: 'TINAndNPI'
    },
    {
      label: 'Zip and Specialty',
      value: 'ZipAndSpecialty'
    }
  ];
  stepperDataSubscription: Subscription;

  public specialtyZipform = new FormGroup({
    providerZip: new FormControl('', Validators.required),
    providerSpecialtyRefID: new FormControl('')
  });
  async ngOnInit() {
    this.myRadioGroupSelectionForFacilityProvider = this.itemsForFacilityProviderSearch[0];
    this.myRadioGroupSelectionForServicingProvider = this.itemsForPhysicianProviderSearch[0];
    this.stepperDataSubscription = this.stepperDataService.sharedStepperData.subscribe((stepperData) => {
      this.stepperData = stepperData;
      this.facilityTypeForProc = this.stepperData.authorizationTypeForm?.get('facilityType')?.value;
    });
    this.getStateRefDataList();
    this.covStartDate = this.stepperData.selectedMember?.coverage.cov_eff_dt;
    this.covEndDate = this.stepperData.selectedMember?.coverage.cov_end_dt;
    this.procedureForm = this.formBuilder.group({
        servicingProvider: new FormControl(''),
        dme: this.formBuilder.array([]),
        serviceType: new FormControl(null, Validators.required),
        total: new FormControl('', [Validators.required, Validators.pattern('^[0-9]*$')]),
        standardMeasure: new FormControl(null, Validators.required),
        count: new FormControl('', [Validators.required, Validators.pattern('^[0-9]*$')]),
        frequency: new FormControl(null, Validators.required),
        serviceStartDate: new FormControl(null, Validators.compose([Validators.required,
          this.procedureServiceService.isDateInPastValidator(),
          this.procedureServiceService.dateWithinRangeValidator(this.covStartDate, this.covEndDate)])),
        serviceEndDate: new FormControl('', Validators.required),
        procMod1: new FormControl(),
        procMod2: new FormControl(),
        procMod3: new FormControl(),
        procMod4: new FormControl()
      }, {
        validators: [this.procedureServiceService.fromToDate('serviceStartDate', 'serviceEndDate')]
      }
    );
    await this.getDMEConfig(this.nestedData.proc_cd_schm_ref_id, this.nestedData.code);
    this.identifyFieldToBeDispalyed(this.procCatAndRank, this.procedureOthrTxtSwitch);
    this.setValuesToDisplayWhenRowIsExpanded();
    if (this.stepperData.selectedProviderResultsData) {
      this.selectedProviderResultsData = this.stepperData.selectedProviderResultsData;
    }
  }

  ngOnDestroy() {
    this.stepperDataSubscription.unsubscribe();
  }

  setValuesToDisplayWhenRowIsExpanded() {
    this.setValuesForOPProc();
    this.setValuesForDMETypCst();
    this.setValuesForDMESson();
    this.setValuesForDMEDesSrv();
    this.setValuesForDMEInitTr();
    this.setValuesForDMEOthrTxtReq();
    this.setValuesForDMEEquip();
  }
  setValuesForDMETypCst() {
    if (this.dmeData) {
      if (this.dmeData.dme_procrmnt_typ_id && this.dmeData.dme_procrmnt_typ_id.value === '2') {
        this.dmeTypeRadioGroupSelection = this.dmeTypeItems[1];
      }
      if (this.dmeData.dme_procrmnt_typ_id && this.dmeData.dme_procrmnt_typ_id.value === '1') {
        this.dmeTypeRadioGroupSelection = this.dmeTypeItems[0];
      }
      this.dmeTypCstFG.patchValue({
        dmeCost: this.dmeData.dme_tot_cst_amt,
      });
    }
  }

  setValuesForDMESson() {
    if (this.dmeData) {
      if (this.dmeData.ental_fd_sngl_src_nutritn_ind && this.dmeData.ental_fd_sngl_src_nutritn_ind.value === '4') {
        this.sourceOfNutriRadioGroupSelection = this.items[1];
      }
      if (this.dmeData.ental_fd_sngl_src_nutritn_ind && this.dmeData.ental_fd_sngl_src_nutritn_ind.value === '3') {
        this.sourceOfNutriRadioGroupSelection = this.items[0];
      }
      this.dmeSsonFG.patchValue({
        sourceOfNutri: this.dmeData.ental_fd_sngl_src_nutritn_ind,
        formulaName: this.dmeData.fml_nm_txt,
        medicalCondition: this.dmeData.med_cond_txt,
      });
    }
  }

  setValuesForDMEDesSrv() {
    if (this.dmeData) {
      this.dmeDesSrvFG.patchValue({
        serviceDescription: this.dmeData.srvc_desc_txt,
      });
    }
  }

  setValuesForDMEInitTr() {
    if (this.nestedData && this.nestedData.hsc_srvc_non_facls) {
      this.dmeInitTrFG.patchValue({
        initialTreatmentDate: this.nestedData.hsc_srvc_non_facls[0].init_trt_dt,
      });
    }
  }

  setValuesForDMEOthrTxtReq() {
    if (this.nestedData) {
      this.othrTxtReqFG.patchValue({
        otherInfo: this.nestedData.proc_othr_txt,
      });
    }
  }

  setValuesForDMEEquip() {
    if (this.dmeData) {
      this.dmeEquipFG.patchValue({
        clinicalIllenessDesc: this.dmeData.clin_ill_desc_txt,
        itemDescription: this.dmeData.spl_desc_txt,
      });
    }
  }

  setValuesForOPProc() {
    const data = this.nestedData?.hsc_srvc_non_facls ? this.nestedData.hsc_srvc_non_facls[0] : null;
    if (data) {
      const serviceType = this.precedureRefData.serviceTypeCodeList.find((item) => item.id === data.srvc_dtl_ref_id);
      const standardMeasure = this.precedureRefData.standardMeasureList.find((item) => item.id === data.proc_uom_ref_id);
      const frequency = this.precedureRefData.procFrequencyList.find((item) => item.id === data.proc_freq_ref_id);
      this.procedureForm.patchValue({
        serviceType,
        total: data.unit_per_freq_cnt,
        standardMeasure,
        count: data.proc_unit_cnt,
        frequency,
        serviceStartDate: data.srvc_strt_dt,
        serviceEndDate: data.srvc_end_dt
      });
      this.setModifiersIfExists(data);
    }
  }
  setModifiersIfExists(hscSrvcNonFacl) {
    const procModifier1 = hscSrvcNonFacl.proc_mod_1_cd ? this.precedureRefData.procedureModifierList.find((item) => item.value === hscSrvcNonFacl.proc_mod_1_cd) : null;
    const procModifier2 = hscSrvcNonFacl.proc_mod_2_cd ? this.precedureRefData.procedureModifierList.find((item) => item.value === hscSrvcNonFacl.proc_mod_2_cd) : null;
    const procModifier3 = hscSrvcNonFacl.proc_mod_3_cd ? this.precedureRefData.procedureModifierList.find((item) => item.value === hscSrvcNonFacl.proc_mod_3_cd) : null;
    const procModifier4 = hscSrvcNonFacl.proc_mod_4_cd ? this.precedureRefData.procedureModifierList.find((item) => item.value === hscSrvcNonFacl.proc_mod_4_cd) : null;
    this.procedureForm.patchValue({
      procMod1: procModifier1 ? procModifier1 : null,
      procMod2: procModifier2 ? procModifier2 : null,
      procMod3: procModifier3 ? procModifier3 : null,
      procMod4: procModifier4 ? procModifier4 : null,
    });
  }

  /*Identify Fields to be displayed based on Procedure Category and Rank*/

  identifyFieldToBeDispalyed(procCatAndRank, procedureOthrTxtSwitch) {
    const dmeArray = this.procedureForm.controls.dme as FormArray;
    console.log(`procCatAndRank.....in procedure expandable row ${JSON.stringify(procCatAndRank)}`);

    if (procCatAndRank) {

      for (const value of procCatAndRank) {
        const dmeArrayLen = dmeArray.length;
        if (value.name === 'DME_TypCst' && this.facilityTypeForProc?.value === 'Home') {
          this.isDmeTypCst = true;
          dmeArray.insert(dmeArrayLen, this.dmeTypCstFG);
          console.log(`DME_TypCst Fields...${ProcedureConstants.DME_TYPCST}`);
        } else if (value.name === 'DME_DesSrv') {
          this.isdmeDesSrv = true;
          dmeArray.insert(dmeArrayLen, this.dmeDesSrvFG);
          console.log(`DME_DESSRV Fields...${ProcedureConstants.DME_DESSRV}`);
        } else if (value.name === 'DME_InitTr') {
          this.isDmeInitTr = true;
          dmeArray.insert(dmeArrayLen, this.dmeInitTrFG);
          console.log(`DME_INITTR Fields...${ProcedureConstants.DME_INITTR}`);
        } else if (value.name === 'OthrTxtReq') {
          this.isOthrTxtReq = true;
          dmeArray.insert(dmeArrayLen, this.othrTxtReqFG);
          console.log(`OthrTxtReq Fields...${ProcedureConstants.OthrTxtReq}`);
         } else if (value.name === 'DME_Equip') {
          this.isdmeEquip = true;
          dmeArray.insert(dmeArrayLen, this.dmeEquipFG);
          console.log(`DME_EQUIP Fields...${ProcedureConstants.DME_EQUIP}`);
        } else if (value.name === 'DME_SSON') {
          this.isdmeSson = true;
          dmeArray.insert(dmeArrayLen, this.dmeSsonFG);
          console.log(`DME_SSON Fields...${ProcedureConstants.DME_SSON}`);
        }
    }
      if ((!this.isOthrTxtReq) && (procedureOthrTxtSwitch === 1)) {
    const dmeArrayLen1 = dmeArray.length;
    console.log(`OthrTxtReq Fields.default..${this.isOthrTxtReq}`);
    dmeArray.insert(dmeArrayLen1, this.othrTxtReqFG);
    console.log(`OthrTxtReq Fields.default..${ProcedureConstants.OthrTxtReq}`);
    }
      this.procedureForm.addControl('dme', dmeArray);

    }
  }

  changeSrvcTypeDropdownVal(model) {
    this.selectedVal = model;
  }

  changeprocFrequencyDropdownVal(model) {
    this.selectedVal = model;
  }

  changestandardMeasureDropdownVal(model) {
    this.selectedVal = model;
  }

  changeprocModifierOneDropdownVal(model) {
    this.selectedVal = model;
  }

  changeprocModifierTwoDropdownVal(model) {
    this.selectedVal = model;
  }

  changeprocModifierThreeDropdownVal(model) {
    this.selectedVal = model;
  }

  changeprocModifierFourDropdownVal(model) {
    this.selectedVal = model;
  }

  submitForm() {
    if (this.procedureForm.valid) {
      this.proc = {...this.proc, ...this.procedureForm.value};
      this.procedureCounter = this.procedureCount;
      this.procedureServiceService.confirmProc(this.procedureCounter, this.proc, this.confirmOpRecord,
        this.nestedData);
      this.nestedData.expanded = false;
      this.nestedData.viewDetails = false;
      this.setServicingProvider();
    } else {
      this.message3.visible = true;
    }

  }

  setServicingProvider() {
    if (this.servicingProviderSelected) {
      this.procedureComponent.setServicingProviderForcurrentProcedure(this.servicingProviderSelected, this.nestedData.hsc_srvc_id);
    } else if (this.stepperData.ServicingProviderDetails) {
      this.procedureComponent.setServicingProviderForcurrentProcedure(this.stepperData.ServicingProviderDetails, this.nestedData.hsc_srvc_id);
    }
  }

  closeRow() {
    this.nestedData.expanded = false;
    this.nestedData.viewDetails = false;
    this.setServicingProvider();
  }
  cancelForm() {
    this.procedureForm.reset();
    this.dmeTypCstFG.reset();
    this.dmeInitTrFG.reset();
    this.dmeSsonFG.reset();
    this.dmeEquipFG.reset();
    this.dmeDesSrvFG.reset();
    this.othrTxtReqFG.reset();
  }

  getEndDateErrorMsg() {
    const endDateControl = this.procedureForm.get('serviceEndDate');
    if (endDateControl.hasError('invalidFormat')) {
      return ProcedureConstants.INVALID_DATE;
    }
    return this.procedureForm.hasError('fromToDate') ? ProcedureConstants.END_DT : null;
  }

  getStartDateErrorMsg() {
    const startDateControl = this.procedureForm.get('serviceStartDate');
    if (startDateControl.hasError('invalidFormat')) {
      return ProcedureConstants.INVALID_DATE;
    } else if (startDateControl.hasError('isDateInPast')) {
      return ProcedureConstants.START_DT;
    }
    return startDateControl.hasError('dateNotInRange') ? ProcedureConstants.NOT_IN_COVERAGE_RANGE : null;
  }
  onCountChangeClinical(count: number) {
      this.remainingCountClinical = count;
    }

  onCountChangeItemDesc(count: number) {
        this.remainingCountItemDesc = count;
      }

  onCountChange(count: number) {
    this.remainingCount = count;
  }

  onCountChangeOtherInfo(count: number) {
    this.remainingCountOtherInfo = count;
  }
  onCountChangeFormula(count: number) {
    this.remainingCountFormula = count;
  }

  onCountChangeMedical(count: number) {
    this.remainingCountMedical = count;
  }

  getPhysicianProviderData() {
    if (this.nameStateOrZipform.valid) {
      this.invalidFormSubmitted = false;
      // this.notificationVisible = false;
      // this.selectedRow = -1;
      this.providerSearchService.getProviderNameSearch(this.PHYSICIAN_CAT_ID,
        this.nameStateOrZipform.controls.providerFirstName.value ? this.nameStateOrZipform.controls.providerFirstName.value : null,
        this.nameStateOrZipform.controls.providerLastName.value,
        this.nameStateOrZipform.controls.providerState.value.refId,
        this.nameStateOrZipform.controls.providerZipCode.value ? this.nameStateOrZipform.controls.providerZipCode.value : null,
        null, this.currentProviderSearchSpecialtyRefID)
        // specialty value need to be added as an argument after ui change here above
        .toPromise()
        .then((res) => {
          this.providerData = res.data.v_prov_srch;
          this.physicianResultsData = this.getProviderResultsData();
          this.currentProviderSearchSpecialtyRefID = null;
        });
    } else {
      if (this.nameStateOrZipform.get('providerLastName').value == null) {
        this.nameStateOrZipform.get('providerLastName').errors['required'] = true;
      }
      if (this.nameStateOrZipform.get('providerState').value == null) {
        this.nameStateOrZipform.get('providerState').errors['required'] = true;
      }
      this.invalidFormSubmitted = true;
      this.notificationVisible = true;
      // this.invalidFormErrorMessage = 'Review the form and correct the highlighted fields';
    }
  }

  getPhysicianProviderDataOnTinOrNpi() {
    if (this.tinOrNipform.valid) {
      this.invalidFormSubmitted = false;
      this.notificationVisible = false;
      this.selectedRow = -1;
      if (!this.tinOrNipform.controls.providerTIN.value &&  !this.tinOrNipform.controls.providerNPI.value) {
        this.notificationVisible = true;
        this.invalidFormErrorMessage = 'Review the form and enter a TIN or NPI';
      } else {
        this.providerSearchService.getProviderTinOrNpiSearch(this.PHYSICIAN_CAT_ID, this.tinOrNipform.controls.providerTIN.value ? this.tinOrNipform.controls.providerTIN.value : null,
          this.tinOrNipform.controls.providerNPI.value ? this.tinOrNipform.controls.providerNPI.value : null)
          .toPromise()
          .then((resTin) => {
            this.providerData = resTin.data.v_prov_srch;
            this.physicianResultsData = this.getProviderResultsData();
          });
      }
    } else {
      this.invalidFormSubmitted = true;
      // this.notificationVisible = true;
    }
  }

  getFacilityProviderData() {
    if (this.facilityNameStateOrZipform.valid) {
      this.invalidFormSubmitted = false;
      this.notificationVisible = false;
      this.selectedRow = -1;
      this.providerSearchService.getProviderNameSearch(this.FACILITY_CAT_ID , null,
        null,
        this.facilityNameStateOrZipform.controls.facilityState.value.refId,
        this.facilityNameStateOrZipform.controls.facilityZipCode.value ? this.facilityNameStateOrZipform.controls.facilityZipCode.value  : null,
        '%' + this.facilityNameStateOrZipform.controls.providerOrgName.value + '%',  this.currentProviderSearchSpecialtyRefID)
        // specialty value need to be added as an argument after ui change here above
        .toPromise()
        .then((facilityRes) => {
          this.providerData = facilityRes.data.v_prov_srch;
          this.facilityResultsData = this.getProviderResultsData();
          this.currentProviderSearchSpecialtyRefID = null;
        });
    } else {
      if (this.facilityNameStateOrZipform.get('providerOrgName').value == null) {
        this.facilityNameStateOrZipform.get('providerOrgName').errors['required'] = true;
      }
      if (this.facilityNameStateOrZipform.get('facilityState').value == null) {
        this.facilityNameStateOrZipform.get('facilityState').errors['required'] = true;
      }
      this.invalidFormSubmitted = true;
      // this.notificationVisible = true;
      // this.invalidFormErrorMessage = 'Review the form and correct the highlighted fields';
    }
  }

  getFacilityProviderDataOnTinOrNpi() {
    // this.modelFour.pagination = this.model.pagination;
    if (this.facilityTinOrNipform.valid) {
      this.invalidFormSubmitted = false;
      this.notificationVisible = false;
      this.selectedRow = -1;
      if (!this.facilityTinOrNipform.controls.facilityTIN.value &&  !this.facilityTinOrNipform.controls.facilityNPI.value) {
        this.notificationVisible = true;
        this.invalidFormErrorMessage = 'Review the form and enter a TIN or NPI';
      } else {
        this.providerSearchService.getProviderTinOrNpiSearch(this.FACILITY_CAT_ID,
          this.facilityTinOrNipform.controls.facilityTIN.value ? this.facilityTinOrNipform.controls.facilityTIN.value : null,
          this.facilityTinOrNipform.controls.facilityNPI.value ? this.facilityTinOrNipform.controls.facilityNPI.value : null)
          .toPromise()
          .then((facilityResTin) => {
            this.providerData = facilityResTin.data.v_prov_srch;
            this.facilityResultsData = this.getProviderResultsData();
          });
      }
    } else {
      this.invalidFormSubmitted = true;
      // this.notificationVisible = true;
    }
  }

  getProviderZipandSpecialty() {
    if (this.specialtyZipform.valid && this.currentProviderSearchSpecialtyRefID != null) {
      this.providerSearchService.getProviderByZipAndSpecialty(this.currentProviderSearchSpecialtyRefID,
        this.specialtyZipform.controls.providerZip.value, this.PHYSICIAN_CAT_ID)
        .toPromise()
        .then((res) => {
          this.providerData = res.data.v_prov_srch;
          this.physicianResultsData = this.getProviderResultsData();
          this.currentProviderSearchSpecialtyRefID = null;
        });
    } else {
      if (this.flagForSpeacilatySearchWarningVisibility === false) {
        this.flagForSpeacilatySearchWarningVisibility = !this.flagForSpeacilatySearchWarningVisibility;
      }
    }
  }

  getProviderZipandSpecialtyforFacility() {
    if (this.specialtyZipform.valid && this.currentProviderSearchSpecialtyRefID != null) {
      this.providerSearchService.getProviderByZipAndSpecialty(this.currentProviderSearchSpecialtyRefID,
        this.specialtyZipform.controls.providerZip.value, this.FACILITY_CAT_ID)
        .toPromise()
        .then((res) => {
          this.providerData = res.data.v_prov_srch;
          this.facilityResultsData = this.getProviderResultsData();
          this.currentProviderSearchSpecialtyRefID = null;
        });
    } else {
      if (this.flagForSpeacilatySearchWarningVisibility === false) {
        this.flagForSpeacilatySearchWarningVisibility = !this.flagForSpeacilatySearchWarningVisibility;
      }
    }
  }

  getProviderResultsData(): any {
    const providerResultsData = [];
    // tslint:disable-next-line:prefer-for-of
    for (let j = 0; j < this.providerData.length; j++) {
      let providerState = '';
      let addressLine = '';
      const getRefCode = this.referenceService.loadRefDataByRefID(this.providerData[j].st_ref_id).toPromise();
      getRefCode.then((providerStateRes) => {
        providerState = providerStateRes.data.ref[0].ref_cd;
        this.providerSearchService.getProviderTinOrNpi(this.providerData[j].prov_id, PROVIDER_KEY_VALUE_TYP_REF_ID_TIN).toPromise().then((providerTin) => {
          this.providerTin =  providerTin.data.prov_key.length === 0 ? null : providerTin.data.prov_key[0].prov_key_val;
          this.providerSearchService.getProviderTinOrNpi(this.providerData[j].prov_id, PROVIDER_KEY_VALUE_TYP_REF_ID_NPI).toPromise().then((providerNpi) => {
            this.providerNpi = providerNpi?.data?.prov_key[0]?.prov_key_val;
            this.providerSearchService.getProviderTinOrNpi(this.providerData[j].prov_id, PROVIDER_KEY_VALUE_TYP_REF_ID_MPIN).toPromise().then((providerMPIN) => {
              this.providerMPIN = providerMPIN?.data?.prov_key[0]?.prov_key_val;
              if (providerState && this.providerNpi !== '') {
                addressLine = this.getProviderAddressLine(this.providerData[j].adr_ln_1_txt, this.providerData[j].adr_ln_2_txt, this.providerData[j].cty_nm, providerState,
                  this.providerData[j].zip_cd_txt);
                this.referenceService.loadRefDataByRefID(this.providerData[j].spcl_ref_id).toPromise().then((specialtydisplRes) => {
                  this.providerData[j].spcl_ref_dspl = specialtydisplRes.data.ref[0].ref_dspl;
                  let providerDetails = {
                    businessName: this.providerData[j].bus_nm,
                    firstName: this.providerData[j].fst_nm,
                    lastName: this.providerData[j].lst_nm + ', ' + this.providerData[j].fst_nm,
                    addressLine, providerTin: this.providerTin, providerNpi: this.providerNpi,
                    prov_id: this.providerData[j].prov_id,
                    phone: this.providerData[j].telcom_adr_id,
                    specialty: this.providerData[j].spcl_ref_dspl,
                    specialtyId: this.providerData[j].spcl_ref_id,
                    locationAffiliationId: this.providerData[j].prov_loc_affil_id,
                    providerAddressId: this.providerData[j].prov_adr_id,
                    providerMPIN: this.providerMPIN,
                    providerCategoryRefId: this.providerData[j].prov_catgy_ref_id
                  };
                  providerDetails = this.checkAndSetBussinessNameIfFacility(providerDetails);
                  providerResultsData.push(providerDetails);
                });
              }
            });
          });
        });
      });
    }
    return providerResultsData;
  }

  checkAndSetBussinessNameIfFacility(providerDetails) {
    if (providerDetails.providerCategoryRefId === this.FACILITY_CAT_ID) {
      providerDetails.lastName = providerDetails.businessName;
    }
    return providerDetails;
  }

  setTin(providerTin) {
    this.providerTin = providerTin.data.prov_key.length === 0 ? null : providerTin.data.prov_key[0].prov_key_val;
  }

  onSwitchTab($event: any) {

  }

  onClear() {
    this.nameStateOrZipform.reset();
    this.facilityTinOrNipform.reset();
    this.facilityNameStateOrZipform.reset();
    this.tinOrNipform.reset();
  }

  onRadioChangeForFacility(radioid) {
    this.selectedradioForFacility = radioid.toElement.defaultValue;
    if (this.selectedradioForFacility === 'NameStateZip') {
      this.isNameStateRadioSelected = true;
      this.isTINAndNPISelected = false;
      this.isSpecialtyAndZipSelected = false;
    } else if (this.selectedradioForFacility === 'TINAndNPI') {
      this.isTINAndNPISelected = true;
      this.isNameStateRadioSelected = false;
      this.isSpecialtyAndZipSelected = false;
    } else {
      this.isTINAndNPISelected = false;
      this.isNameStateRadioSelected = false;
      this.isSpecialtyAndZipSelected = true;
    }
  }

  getStateRefDataList() {
    this.referenceService.getReferenceDataForState(this.REFERENCE_STATE).subscribe((event) => {
        this.references = ReferenceSet.getDataObjects(event.data[ReferenceSet.REFERENCE_SET_TABLE_NAME]);
        if (this.references.length > 0) {
          for (let i = 0; i < this.references.length; i++) {
            this.referenceData.push({id: i, label: this.references[i].reference.cd, value: this.references[i].reference.cd, refId: this.references[i].reference.id});
          }
        }
      }
    );
  }

  getProviderAddressLine(adr_ln_1_txt: string, adr_ln_2_txt: string, cty_nm: string, st_ref_cd: string, zip_cd_txt: string): string {
    let addressLine = '';
    if (adr_ln_1_txt) {
      addressLine = adr_ln_1_txt;
    }
    if (adr_ln_2_txt) {
      addressLine += ', ' + adr_ln_2_txt;
    }
    if (cty_nm) {
      addressLine += ', ' + cty_nm;
    }
    if (st_ref_cd) {
      addressLine += ', ' + st_ref_cd;
    }
    if (zip_cd_txt) {
      addressLine += ', ' + zip_cd_txt;
    }
    return addressLine;

  }
  // providerSelectedForFacility(selectedProv) {
  //   if (selectedProv.businessName !== null) {
  //     this.selectedFacilityResultsData.push(selectedProv);
  //   }
  //   this.providerSearchService.setProviderDetails(selectedProv.phone, selectedProv.specialtyId,
  //     selectedProv.locationAffiliationId, PROVIDER_ROLE_REF_ID_FACILITY, selectedProv.providerNpi, selectedProv.providerTin);
  //
  // }

  onRadioChangeForServicingingProvider(radioid) {
    this.selectedradioForServicingProvider = radioid.toElement.defaultValue;
    if (this.selectedradioForServicingProvider === 'NameStateZip') {
      this.isNameStateRadioSelected = true;
      this.isTINAndNPISelected = false;
      this.isSpecialtyAndZipSelected = false;
    } else if (this.selectedradioForServicingProvider === 'TINAndNPI') {
      this.isTINAndNPISelected = true;
      this.isNameStateRadioSelected = false;
      this.isSpecialtyAndZipSelected = false;
    } else {
      this.isTINAndNPISelected = false;
      this.isNameStateRadioSelected = false;
      this.isSpecialtyAndZipSelected = true;
    }
  }

  providerSelectedForServicingProvider(selectedProv) {
    this.providerSearchComponent.setProviderAffilDetailJson(selectedProv);
    console.log(selectedProv);
    let isDuplicate = false;
    this.selectedProviderResultsData?.forEach((value) => {
      if (value.prov_id === selectedProv.prov_id) {
        isDuplicate = true;
        return;
      }
    });
    if (!isDuplicate) {
      this.selectedProviderResultsData.push(selectedProv);
      this.providerSearchComponent.selectedProviderResultsData.push(selectedProv);
    }
    this.providerSearchService.setProviderDetails(selectedProv.phone, selectedProv.specialtyId,
      PROVIDER_ROLE_REF_ID_SERVICING, selectedProv.providerTin,
      this.providerSearchComponent.currentProviderAffiliationDetailJson).subscribe((data) => {
        console.log(data);
        // console.log(data.insert_hsc_prov_one.hsc_prov_id);
        if (data.insert_hsc_prov_one === undefined) {
          this.hscProvId = data.update_hsc_prov.returning[0].hsc_prov_id;
        } else {
          this.hscProvId = data.insert_hsc_prov_one.hsc_prov_id;
        }
        console.log(this.hscProvId);
        this.providerSearchService.updateServcingProviderAgainstProcedure(this.nestedData.hsc_srvc_id, this.hscProvId).subscribe((dataResult) => {
        }, (error) => {});
    }, (error) => {}
    );
    this.isEditProviderEnabled = false;
    this.servicingProviderSelected = selectedProv;
  }

  editRow() {
    this.isEditProviderEnabled = true;
  }

  async getDMEConfig(procType, procCode) {
    const configRes = await this.sysConfigService.getClientConfigByKey(ConfigConstants.INTAKE_RULES_CONFIG_KEY).toPromise();
    const tenantId = JSON.parse(configRes[0].value).tenantId;
    const camundaHttpHeaders = new HttpHeaders({
      'Content-Type': this.contentType,
      'Accept': this.contentType,
      'Authorization': 'Bearer ' + this.userSessionService.getEcpToken(),
      'x-bpm-cli-org-id': this.userSessionService.getUserOrg(),
      'x-bpm-func-role': this.userSessionService.getFunctionalRole(),
      'x-bpm-tenant-id': tenantId,
      'x-bpm-external-ref-id': RulesConstants.X_BPM_EXTERNAL_REF_ID,
      'x-bpm-source': RulesConstants.X_BPM_SOURCE,
      'x-bpm-workflow': RulesConstants.X_BPM_WORKFLOW
    });
    const httpOptions = {
      headers: camundaHttpHeaders
    };
    const body = {
        procTypid: procType,
        procRngStrtcd: procCode
      };
    const dmeConfigRes = await this.httpClient.post(environment.WORK_FLOW_DME_CONFIG_DMN_URL, body, httpOptions).toPromise();
    this.mapDmeConfigRes(dmeConfigRes);
  }
  mapDmeConfigRes(dmeConfigRes) {
    if (dmeConfigRes.length > 0) {
      this.procCatAndRank = [];
      for (const value of dmeConfigRes) {
        const categoryNameAndRank = { name: value.procCatgyTypid.value, rank: value.procRngCatgySeqnbr.value };
        this.procCatAndRank.push(categoryNameAndRank);
      }
      /*Sorting the procedure categories based on the rank*/
      this.procCatAndRank.sort((procCat1, procCat2) => {
        return procCat1.rank - procCat2.rank;
      });
    }
  }

  tkSearchVal($event: any) {
    if ($event.length > 3) {
      this.providerSearchService.getSpecialty($event).subscribe((res) => {
        this.results = res.data.ref;
      });
    }
  }

  onSelect($event: any) {
    console.log($event);
    this.currentProviderSearchSpecialtyRefID = $event.ref_id;
  }

  tkSearchGo($event: any) {

  }
}
