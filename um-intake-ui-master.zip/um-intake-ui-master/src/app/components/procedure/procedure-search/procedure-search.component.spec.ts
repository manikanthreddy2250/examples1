import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { uitkAngularModules, uitkModules } from 'src/app/app.module';
import {ProcedureService} from 'src/app/services/procedure/procedure.service';
import { ProcedureSearchComponent } from './procedure-search.component';
describe('ProcedureSearchComponent', () => {
  let component: ProcedureSearchComponent;
  let service: ProcedureService;
  let fixture: ComponentFixture<ProcedureSearchComponent>;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [uitkModules, uitkAngularModules, FormsModule, ReactiveFormsModule, HttpClientTestingModule],
      declarations: [ProcedureSearchComponent],
      providers: [ProcedureService],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));
  beforeEach(() => {
    fixture = TestBed.createComponent(ProcedureSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('isSelectingNewDescription is called with an undefiend input', () => {
    const description = undefined;
    const returnValue = component.isSelectingNewDescription(description);
    expect(returnValue).toEqual(undefined);
  });
  it('isSelectingNewDescription is called with an input that has the code', () => {
    const description = 'A1234 Test Procedure Code';
    component.code = 'A1234';
    const returnValue = component.isSelectingNewDescription(description);
    expect(returnValue).toEqual(true);
  });
  it('isSelectingNewDescription is called with an input that has valid code', () => {
    const description = 'A1234 Test Procedure Code';
    component.code = 'A12345';
    const returnValue = component.isSelectingNewDescription(description);
    expect(returnValue).toEqual(false);
  });
  it('arrow down diagnosis search', () => {
    component.arrowDown();
    component.arrowKeyTouched = true;
    component.selectFirstResult = true;
    component.searchComponent.value = 'test';
    expect(component.selectFirstResult).toBe(true);
    expect(component.arrowKeyTouched).toBe(true);
  });
  it('should clear input element', () => {
    let inputElement = document.createElement('input');
    inputElement.value = 'Hello World';
    component.clearContent(inputElement);
    expect(component.clearContent).toBeTruthy();
  });
  it('should getProcedureResultsData ', () => {
    component.getProcedureResultsData();
    expect(component.getProcedureResultsData).toBeTruthy();
  });

  it('clear the content of the input - the input is empty so clear the value', () => {
    component.searchComponent.value = 'test';
    let inputElement = document.createElement('input');
    component.emptyString = '';
    inputElement.value = '';
    component.clearCount = 2;
    component.clearContent(inputElement);
    expect(component.searchComponent.value).toEqual('');
  });

  it('should built a string when given an array of words', () => {
    const terms = ['test', 'output'];
    const returnValues = component.constructDescription(terms);
    expect(returnValues).toEqual(' test output');
  });
  /*
  it("clear the content of the input - selecting new procedure", () => {
         let inputElement = document.createElement("input");
         component.clearCount = 1;
         component.code = "A1234";
         component.selectFirstResult = true;
         spyOn(component, "constructDescription");
         inputElement.value = "A1234 Procedure Code";
         component.clearContent(inputElement);
         expect(component.constructDescription).toHaveBeenCalled();
  });

   it('should call changeSrvcTypeDropdownVal', () => {
      const model = {
        value: 'value',
        id: 'id'
      };
      spyOn(component, 'changeSrvcTypeDropdownVal').and.callThrough();
      component.changeSrvcTypeDropdownVal(null);
      component.changeSrvcTypeDropdownVal(model);
      expect(component.changeSrvcTypeDropdownVal).toBeTruthy();
      expect(component.selectedVal).toEqual(model);
    });

  */
  it('should return from an empty search element', () => {
    component.tkSearchVal('');
    expect(component.numberOfMatches).toBe(0);
  });
  it('should call searchEntries with non null param', () => {
    component.tkSearchVal('something');
    expect(component.tkSearchVal).toBeTruthy();
  });

  it('should return from an empty search element', () => {
    component.tkSearchVal('undefined');
    expect(component.tkSearchVal).toBeTruthy();
  });

  //  it("should call updateAndAddFocus", () => {
  //    component.updateResultDisplay([
  //      { test: "test1", proc_cd: "111", description: "desc" },
  //      { test: "test2", proc_cd: "123", description: "desc" }
  //    ]);
  //    expect(component.results).toBeDefined();
  //     expect(component.results).toEqual([{ name: "111 desc" }, { name: "123 desc" }]);
  //    spyOn(component, "updateAndAddFocus");
  //    component.updateAndAddFocus('123', '12');
  //    expect(component.updateAndAddFocus).toBeDefined();
  //  });

  it('should call tabFocus', () => {
    component.searchComponent.value = 'K10 test desc';
    component.clearCount = 2;
    const hostElement = fixture.nativeElement;
    const diagnosisInput: HTMLInputElement = hostElement.querySelector('input');
    component.tabFocus(diagnosisInput);
    expect(component.searchComponent.value).toEqual('K10 test desc');
    expect(component.selectedCodeFlag).toBe(false);
  });
  it('tabFocus Case1', () => {
    const event = {
      target: {
        innerText: 'Abcd123'
      }
    };
    component.tabFocus(event);
    expect(component.selectedCodeFlag).toBe(false);
  });
  it('tabFocus Case3', () => {
    component.selectedCodeFlag = false;
    component.selectFirstResult = true;
    component.arrowKeyTouched = true;
    const event = {
      target: {
        innerText: 'Abcd123'
      }
    };
    component.searchGroup = new FormGroup({
      code: new FormControl(),
      diagnosisCode: new FormControl()
    });
    component.searchGroup.get('code').setValue('Abcd123');
    component.searchGroup.get('diagnosisCode').setValue('Abcd123');
    const hostElement = fixture.nativeElement;
    const diagnosisInput: HTMLInputElement = hostElement.querySelector('input');
    diagnosisInput.value = 'A1234 diagnosis Code';
    component.code = 'A1234';
    spyOn(component, 'updateParent');
    component.tabFocus(event);
    expect(component.updateParent).toHaveBeenCalled();
    expect(component.arrowKeyTouched).toBe(false);
  });
  it('focusFirst Case1', () => {
    const event = {
      target: {
        innerText: 'Abcd123'
      }
    };
    component.focusFirst(event);
    expect(component.selectedCodeFlag).toBe(false);
  });
  it('should return if selectFirstResult is false', () => {
    component.selectFirstResult = false;
    component.focusFirst(component.selectFirstResult);
    expect(component.code).toEqual('');
    component.searchComponent.value !== '';
  });
  it('should check if it is a number ', () => {
    const returnValue = component.isNumber('A12345');
    expect(returnValue).toEqual(false);
  });
  it('should check if it is a number ', () => {
    const returnValue = component.isNumber('12345');
    expect(returnValue).toEqual(true);
  });
  it('should create a search result which is just the input with *s between', () => {
    expect(component.createSearchTerm('test', '*')).toEqual('t* e* s* t* ');
  });
  it('create search term - add a wildcard to a number', () => {
    const terms = [2];
    const returnValues = component.createSearchTerm(terms, '');
    expect(returnValues).toEqual('2* ');
  });
  it('isSelectingNewDescription is called with an undefiend input', () => {
    const description = undefined;
    const returnValue = component.isSelectingNewDescription(description);
    expect(returnValue).toEqual(undefined);
  });

  it('isSelectingNewDescription is called with an input that has the code', () => {
    const description = 'A1234 Test Procedure Code';
    component.code = 'A1234';
    const returnValue = component.isSelectingNewDescription(description);
    expect(returnValue).toEqual(true);
  });

  it('isSelectingNewDescription is called with an input that has valid code', () => {
    const description = 'A1234 Test Procedure Code';
    component.code = 'A12345';
    const returnValue = component.isSelectingNewDescription(description);
    expect(returnValue).toEqual(false);
  });

  it('arrow down diagnosis search', () => {
    component.arrowDown();
    component.arrowKeyTouched = true;
    component.selectFirstResult = true;
    component.searchComponent.value = 'test';
    expect(component.selectFirstResult).toBe(true);
    expect(component.arrowKeyTouched).toBe(true);
  });

  it('should getProcedureResultsData ', () => {
    component.getProcedureResultsData();
    expect(component.getProcedureResultsData).toBeTruthy();
  });

  it('should update Parent Results', () => {
    component.searchGroup = new FormGroup({
      code: new FormControl(),
      procedureCode: new FormControl(),
      procedureCType: new FormControl()
    });
    component.updateParent('test', 'test', 'text');
    component.searchGroup.get('code').setValue('test');
    component.searchGroup.get('procedureCode').setValue('test');
    component.searchGroup.get('procedureCType').setValue('text');
    expect(component.updateParent).toBeTruthy();
    expect(component.searchGroup.get('code').value).toBe('test');
    expect(component.searchGroup.get('procedureCode').value).toBe('test');
  });

  it('clear content should determine if we do clear the input and code', () => {
    component.searchGroup = new FormGroup({
      code: new FormControl(),
      procedureCode: new FormControl(),
      procedureCType: new FormControl()
    });
    component.updateParent('test', 'test', 'text');
    component.searchGroup.get('code').setValue('test');
    component.searchGroup.get('procedureCode').setValue('test');
    component.code = 'A12345';
    let inputElement = document.createElement('input');
    inputElement.value = 'A1234 Test Procedure Code';
    component.clearCount = 1;
    component.clearContent(inputElement);
    expect(component.selectedCodeFlag).toEqual(false);
    expect(component.code).toEqual('');
    expect(component.clearCount).toEqual(0);
  });

  it('clear the content of the input - the input is empty so clear the value', () => {
    component.searchComponent.value = 'test';
    let inputElement = document.createElement('input');
    component.emptyString = '';
    inputElement.value = '';
    component.clearCount = 2;
    component.clearContent(inputElement);
    expect(component.searchComponent.value).toEqual('');
  });

  it('clear the content of the input - selecting new procedure', () => {
    let inputElement = document.createElement('input');
    component.clearCount = 1;
    component.code = 'A1234';
    component.selectFirstResult = true;
    spyOn(component, 'constructDescription');
    inputElement.value = 'A1234 Procedure Code';
    component.clearContent(inputElement);
    expect(component.constructDescription).toHaveBeenCalled();
  });

  it('should return from an empty search element', () => {
    component.tkSearchVal('');
    expect(component.numberOfMatches).toBe(0);
  });

  it('should call searchEntries with non null param', () => {
    component.tkSearchVal('something');
    expect(component.tkSearchVal).toBeTruthy();
  });

  it('should call tabFocus', () => {
    component.searchComponent.value = 'K10 test desc';
    component.clearCount = 2;
    const hostElement = fixture.nativeElement;
    const diagnosisInput: HTMLInputElement = hostElement.querySelector('input');
    component.tabFocus(diagnosisInput);
    expect(component.searchComponent.value).toEqual('K10 test desc');
    expect(component.selectedCodeFlag).toBe(false);
  });

  it('tabFocus Case1', () => {
    const event = {
      target: {
        innerText: 'Abcd123'
      }
    };
    component.tabFocus(event);
    expect(component.selectedCodeFlag).toBe(false);
  });

  it('tabFocus Case3', () => {
    component.selectedCodeFlag = false;
    component.selectFirstResult = true;
    component.arrowKeyTouched = true;
    const event = {
      target: {
        innerText: 'Abcd123'
      }
    };

    component.searchGroup = new FormGroup({
      code: new FormControl(),
      diagnosisCode: new FormControl()
    });
    component.searchGroup.get('code').setValue('Abcd123');
    component.searchGroup.get('diagnosisCode').setValue('Abcd123');
    const hostElement = fixture.nativeElement;
    const diagnosisInput: HTMLInputElement = hostElement.querySelector('input');
    diagnosisInput.value = 'A1234 diagnosis Code';
    component.code = 'A1234';
    spyOn(component, 'updateParent');
    component.tabFocus(event);
    expect(component.updateParent).toHaveBeenCalled();
    expect(component.arrowKeyTouched).toBe(false);
  });

  it('focusFirst Case1', () => {
    const event = {
      target: {
        innerText: 'Abcd123'
      }
    };
    component.focusFirst(event);
    expect(component.selectedCodeFlag).toBe(false);
  });

  it('should return if selectFirstResult is false', () => {
    component.selectFirstResult = false;
    component.focusFirst(component.selectFirstResult);
    expect(component.code).toEqual('');
    component.searchComponent.value !== '';
  });

  it('should check if it is a number ', () => {
    const returnValue = component.isNumber('A12345');
    expect(returnValue).toEqual(false);
  });

  it('should check if it is a number ', () => {
    const returnValue = component.isNumber('12345');
    expect(returnValue).toEqual(true);
  });

  it('should create a search result which is just the input with *s between', () => {
    expect(component.createSearchTerm('test', '*')).toEqual('t* e* s* t* ');
  });

  it('create search term - add a wildcard to a number', () => {
    const terms = [2];
    const returnValues = component.createSearchTerm(terms, '');
    expect(returnValues).toEqual('2* ');
  });

// it("should call updateDisplay", () => {
//    component.updateResultDisplay([
//      { test: "test1", diagCode: "111", diagDesc: "desc" },
//      { test: "test2", diagCode: "123", diagDesc: "desc" }
//    ]);
//    expect(component.results).toBeDefined();
//    expect(component.results).toEqual([{ name: "111 desc" }, { name: "123 desc" }]);
//  });
  it('should show Clear Icon', () => {
    component.showClearIcon();
    expect(component.showClearIcon).toBeTruthy();
  });

});
