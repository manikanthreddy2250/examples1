import {
  ChangeDetectorRef,
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ViewChild
} from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { SearchComponent } from '@uimf/uitk';
import { Subject } from 'rxjs/Subject';
import {ReferenceService} from 'src/app/services/refernce-service/reference.service';
import {ProcedureService} from 'src/app/services/procedure/procedure.service';
import {ReferenceConstants} from '../../../constants/referenceConstants';

@Component({
  selector: 'um-procedure-search',
  templateUrl: './procedure-search.component.html',
  styleUrls: ['./procedure-search.component.scss']
})
export class ProcedureSearchComponent implements OnInit {
  constructor(
    private readonly graphqlService: ProcedureService,
    private elemRef: ElementRef,
    public cd: ChangeDetectorRef,
    private referenceService: ReferenceService
  ) { }
  @Input() searchComponentsForm: FormGroup;
  @Output() numberOfResults = new EventEmitter<string>();
  @Output('addSearchComponent') addSearchComponent: EventEmitter<any> = new EventEmitter();
  @Output('addSearchComponentDynamicallyTab') addSearchTab: EventEmitter<any> = new EventEmitter();
  @Output() valueTyped = new EventEmitter();
  @Output() parentCode = new EventEmitter();
  @Input() searchGroup: FormGroup;
  @ViewChild('mySearch', { static: false }) searchComponent: SearchComponent;
  results: any[];
  procedureData = [];
  procedureResultsData = [];
  tkSearchResult: boolean;
  tkNewSearch: boolean;
  searchTerm$ = new Subject<string>();
  numberOfMatches = 0;
  emptyString = '';
  currentValue: string;
  icons: any;
  searchBars: any;
  autoFocus: any;
  code = this.emptyString;
  codeDesc = this.emptyString;
  clearCount = 0;
  selectedCodeFlag = false;
  input = this.emptyString;
  selectFirstResult = false;
  public resultElement;
  selected: boolean;

  arrowKeyTouched: boolean;
  selectedVal: any;

  procedureTypeList = [];

  myDemoForm = new FormGroup({
    procedureCodeType: new FormControl(''),
  });

  procedureCodeTypeControl = this.myDemoForm.get('procedureCodeType') as FormControl;

  ngOnInit() {
    this.icons = document.getElementsByClassName('tk-btn--search');
    this.searchBars = document.getElementsByClassName('tk-input--search');
    this.autoFocus = document.getElementsByClassName('tk-auto-search__list-item');
    this.numberOfMatches = 0;
    this.selected = false;
    this.getprocedureTypeListQuery();
    setTimeout(() => {
      this.setFocus();
    });
  }

  setFocus() {
    let i;
    (this.searchBars[this.icons.length - 1] as HTMLElement).focus();

  }

  getprocedureTypeListQuery() {
    const procCodeTypeBaseRefName = 'procCodeType';
    this.referenceService.loadBaseRefNameDisplayData(procCodeTypeBaseRefName).toPromise().then((res) => {
      const procCodeTypeResponse = res.data.ref;
      procCodeTypeResponse.forEach((item: { ref_id: number; ref_dspl: string; ref_cd: string; }) => {
        const procCodeTypeObj = {
          id: item.ref_id,
          label: item.ref_dspl,
          value: item.ref_cd
        };
        this.procedureTypeList.push(procCodeTypeObj);
      });
      this.myDemoForm.controls['procedureCodeType'].setValue(this.procedureTypeList[4]);
    }
    ).catch((error) => {

    });
  }

  changeSrvcTypeDropdownVal(model) {
    this.selectedVal = model;
  }

  ngAfterViewInit() {
    this.searchComponent._inputElementRef.nativeElement.focus();
    window.scrollTo(0, 0);
  }

  ngAfterViewChecked() {
    this.resultElement = this.elemRef.nativeElement.querySelector('#undefined_opt_0');
  }

  arrowDown() {
    if (this.searchComponent.displayitems.length > 0) {
      this.arrowKeyTouched = true;
      this.selectFirstResult = true;
      this.resultElement.classList.remove('focusFirstResult');
    }
  }
  /**
   * Function that returns true if selecting a new description
   * @param description
   */
  isSelectingNewDescription(description) {
    if (description === undefined) {
      return;
    }
    if (description.includes(this.code)) {
      return true;
    } else {
      return false;
    }
  }

  /**
   * This method will clear the content of the search bar upon clicking the 'x' icon
   * @param input
   */
  clearContent(input: HTMLInputElement) {
    if (this.clearCount % 2 === 1) {
      if (this.isSelectingNewDescription(input.value) && this.selectFirstResult === true) {
        this.selectedCodeFlag = true;
        const terms = input.value.split(/[ ,]+/).filter(Boolean);
        const [, ...description] = terms;
        let response;
        if (description.length > 0) {
          response = this.constructDescription(description);
        }
        input.value = response;
      } else {
        this.selectedCodeFlag = false;
        this.code = this.emptyString;
        const code = this.code;
        this.clearCount = 0;
        // this.searchGroup.get("code").setValue(code);
        this.updateParent(this.emptyString, this.emptyString, this.emptyString);
        this.currentValue = this.emptyString;
        this.input = this.emptyString;
        input.value = this.emptyString;
      }
    } else {
      if (input.value === this.emptyString) {
        this.searchComponent.value = this.emptyString;
      } else {
        this.clearCount += 1;
      }
    }
    this.numberOfResults.emit('0');
  }

  /**
   * execute this method from within onSelect(), pass the selected value as parameter, it will communicate the
   * selected value from search results to the parent component.
   * @param selectedResult
   */
  updateParent(code, description, searchType) {
    this.searchGroup.get('code').setValue(code);
    this.searchGroup.get('procedureCode').setValue(description);
    this.searchGroup.get('procedureCType').setValue(searchType);

  }

  tkSearchVal(val)
    :
    void {
    this.input = val;
    this.procedureCodeTypeControl = this.myDemoForm.get('procedureCodeType') as FormControl;
    const searchType = this.procedureCodeTypeControl.value.label;
    if (this.input.length > 1) {
      this.input = val;
      this.searchComponent.value = val;
      this.results = [];
      this.graphqlService.getProcedures(val, searchType)
        .subscribe(({ data }) => {
          this.results = data.ProcedureSmartSearch;
        },
          (error) => {
            this.results = [];
          });
    }
  }

  getProcedureResultsData(): any {
    const procedureResultsData = [];
    for (let j = 0; j < this.procedureData.length; j++) {
      const code = '';
      const procedureCode = '';
      procedureResultsData.push({ code: this.results[j] });
      alert('asssss=' + procedureResultsData[j].code);
    }
    return procedureResultsData;
  }

  focusFirst(event) {
    this.procedureCodeTypeControl = this.myDemoForm.get('procedureCodeType') as FormControl;
    const searchType = this.procedureCodeTypeControl.value.label;
    if (this.selectFirstResult === false) {
      return;
    }
    if (!this.arrowKeyTouched && this.searchComponent.value !== this.emptyString) {
      this.searchComponent.value = this.searchComponent.displayitems.first.nativeElement.innerText;
    } else if (this.arrowKeyTouched) {
      this.searchComponent.value = event.target.innerText;
    }

    if (this.searchComponent.displayitems.length > 0) {
      console.log(`this.searchComponent.value.... ${this.searchComponent.value}`);
      this.addSearchComponent.emit(this.searchComponent.value);
      const terms = this.searchComponent.value.split(/[ ,]+/).filter(Boolean);
      this.code = terms[0];
      let code = this.code;
      this.parentCode.emit(terms[0]);
      const [, ...description] = terms;
      if (this.isSelectingNewDescription(this.searchComponent.value)) {
        this.selectedCodeFlag = true;
      }
      let response;
      if (description.length > 0) {
        response = this.constructDescription(description);
      }
      if (this.input === this.emptyString) {
        this.searchComponent.value = this.emptyString;
        response = this.emptyString;
        code = this.emptyString;
      } else if (response !== this.emptyString) {
        this.searchComponent.value = response;
      }
      this.currentValue = response;
      this.updateNumberOfResults(0);
      this.updateParent(code, response, searchType);
      this.arrowKeyTouched = false;
    }
  }

  tabFocus(event) {
    this.procedureCodeTypeControl = this.myDemoForm.get('procedureCodeType') as FormControl;
    const searchType = this.procedureCodeTypeControl.value.label;
    if (this.selectedCodeFlag === true || this.selectFirstResult === false) {
      return;
    }
    if (!this.arrowKeyTouched && this.searchComponent.value !== this.emptyString) {
      this.searchComponent.value = this.searchComponent.displayitems.first.nativeElement.innerText;
    } else {
      this.searchComponent.value = event.target.innerText;
    }
    if (this.searchComponent.displayitems) {
      this.addSearchTab.emit(this.searchComponent.value);
      const terms = this.searchComponent.value.split(/[ ,]+/).filter(Boolean);
      this.code = terms[0];
      let code = this.code;
      this.parentCode.emit(terms[0]);
      const [, ...description] = terms;
      if (this.isSelectingNewDescription(this.searchComponent.value)) {
        this.selectedCodeFlag = true;
      }
      let response;
      if (description.length > 0) {
        response = this.constructDescription(description);
      }
      if (this.input === this.emptyString) {
        this.searchComponent.value = this.emptyString;
        response = this.emptyString;
        code = this.emptyString;
      } else {
        this.searchComponent.value = response;
      }
      this.currentValue = response;
      this.updateNumberOfResults(0);
      this.updateParent(code, response, searchType);
      this.arrowKeyTouched = false;
    }
  }

  updateAndAddFocus(resultMatches, result) {
    console.log(`result in updateAndAddFocus ${JSON.stringify(result)}`);
    this.numberOfMatches = resultMatches;
    this.updateResultDisplay(result.value).then(() => {
      setTimeout(() => {
        try {
          this.resultElement.classList.add('focusFirstResult');
        } catch (e) { }
      }, 0);
    });
  }

  /*
  updateAndRemoveFocus(resultMatches, result) {
    this.numberOfMatches = resultMatches;
    console.log(`resultMatches..${resultMatches}`);
    this.updateResultDisplay(result.value).then(() => {
      setTimeout(() => {
        try {
          this.resultElement.classList.remove("focusFirstResult");
        } catch (e) {}
      }, 0);
    });
  }
  */

  /*/!**
   * Function that calls the azure search index depending on the input
   * @param val
   *!/
  searchEntries(val) {
    this.results = [];
    this.selectFirstResult = true;
    const terms = val.split(/[ ,]+/).filter(Boolean);
    const filter = this.createFilter();
    let searchResult = this.createSearchTerm(terms, "*");
    this.procedureSearchService.search(val, filter).subscribe(
      result => {
        let resultMatches = result[procedureConstants.dataCount];
        if (resultMatches !== 0) {
          this.updateAndAddFocus(resultMatches, result);
        } else {
          this.procedureSearchService.search(searchResult, filter).subscribe(
            result => {
              resultMatches = result[procedureConstants.dataCount];
              if (resultMatches !== 0) {
                this.updateAndAddFocus(resultMatches, result);
              } else {
                this.selectFirstResult = false;
                searchResult = this.createSearchTerm(terms, "~");
                this.procedureSearchService.search(searchResult, filter).subscribe(
                  result => {
                    resultMatches = result[procedureConstants.dataCount];
                    if (resultMatches !== 0) {
                      this.updateAndRemoveFocus(resultMatches, result);
                    }
                  },
                  error => {
                    this.results = [];
                    console.log(error);
                  }
                );
              }
            },
            error => {
              this.results = [];
              console.log(error);
            }
          );
        }
      },
      error => {
        this.results = [];
        console.log(error);
      }
    );
    return Promise.resolve("success");
  }*/

  isNumber(text) {
    if (isNaN(text)) {
      return false;
    } else {
      return true;
    }
  }

  createSearchTerm(terms, specialCharacter) {
    let searchResult = this.emptyString;
    for (const t in terms) {
      if (this.isNumber(terms[t])) {
        searchResult += `${terms[t]}* `;
      } else {
        searchResult += `${terms[t]}${specialCharacter} `;
      }
    }
    return searchResult;
  }

  /*createFilter() {
    const codeType: string = this.searchGroup.get("codeType").value;
    switch (codeType) {
      case "rev":
        return procedureConstants.codeTypeFilters.revFilter;
      case "cptHcpcs":
        return procedureConstants.codeTypeFilters.cptHcpcsFilter;
      default:
        return this.emptyString;
    }
  }*/

  updateResultDisplay(jsonObject) {
    this.updateNumberOfResults(this.numberOfMatches);
    this.results = [];
    for (const object of jsonObject) {
      /* Some objects did not contain a search highlight key */
      const row = { displayText: this.emptyString };
      row.displayText = this.parseResults(object);
      this.results.push(row);
    }
    return Promise.resolve('Success');
  }

  parseResults(result) {
    let resultString = this.emptyString;
    resultString += `${result.proc_cd}       ${result.description}`;
    return resultString;
  }

  onSelect(val) {
    this.searchTerm$.next(val.displayText);
  }

  updateCodeDisplay() {
    if (this.numberOfMatches === 1) {
      return;
    } else {
      this.parentCode.emit(this.emptyString);
    }
  }

  getSelectedValue(event) {
    this.procedureCodeTypeControl = this.myDemoForm.get('procedureCodeType') as FormControl;
    if (event === undefined) {
      return;
    } else {
    console.log(`event... in getSelectedValue${JSON.stringify(event)}`);
    const terms = event.displayText.split(/[ ,]+/).filter(Boolean);
    this.code = terms[0];
    const searchType = event.searchType === 'hcpcs_search' ? ReferenceConstants.PROCEDURE_TYPE_HCPCS_REF_DESC : ReferenceConstants.PROCEDURE_TYPE_CPT4_REF_DESC;
    this.parentCode.emit(terms[0]);
    const [, ...description] = terms;
    if (this.isSelectingNewDescription(event.dispalyText)) {
        this.selectedCodeFlag = true;
      }
    let response;
    if (description.length > 0) {
        response = this.constructDescription(description);
      }
    this.currentValue = response;
    const code = this.code;
    this.updateNumberOfResults(0);
    this.updateParent(code, response, searchType);
    this.code = code;
    this.codeDesc = response;
    this.selected = true;
    }
  }
  /**
   * Function that constructs the description by adding a space (helps split the code and description)
   * @param arrayOfTerms split based on spaces
   * @returns the description with spaces
   */
  constructDescription(arrayOfTerms) {
    let result = this.emptyString;
    for (const term of arrayOfTerms) {
      result += ` ${term}`;
    }
    return result;
  }

  showClearIcon() {
    let i;
    for (i = 0; i < this.icons.length; i++) {
      (this.searchBars[i] as HTMLElement).style.borderRight = 'none';
      (this.icons[i] as HTMLElement).style.display = 'inline';
      (this.icons[i] as HTMLElement).style.borderLeft = 'none';
    }
  }

  updateNumberOfResults(numberOfResults) {
    this.numberOfResults.emit(numberOfResults);
    this.updateCodeDisplay();
  }
}
