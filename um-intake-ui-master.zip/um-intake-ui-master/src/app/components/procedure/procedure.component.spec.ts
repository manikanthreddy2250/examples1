import { HttpClient, HttpHandler } from '@angular/common/http';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import {CUSTOM_ELEMENTS_SCHEMA, Injectable, NO_ERRORS_SCHEMA} from '@angular/core';
import { async, ComponentFixture, inject, TestBed } from '@angular/core/testing';
import {FormArray, FormBuilder, FormsModule, ReactiveFormsModule, Validators} from '@angular/forms';
import { LiveRegionService } from '@uimf/uitk';
import {
UITKPageNotificationComponent,
UITKTableFeaturesModule, UITKTableModule
} from '@uitk/angular';
import { Apollo } from 'apollo-angular';
import {BehaviorSubject, Observable, of} from 'rxjs';
import { environment } from 'src/environments/environment';
import { uitkAngularModules, uitkModules } from 'src/app/app.module';
import {ProcedureService} from 'src/app/services/procedure/procedure.service';
import {StepperDataService} from 'src/app/services/StepperDataService/StepperDataService';
import {ReferenceService} from '../../services/refernce-service/reference.service';
import { ProcedureExpandableRowComponent } from './procedure-expandable-row/procedure-expandable-row.component';
import { ProcedureComponent } from './procedure.component';
import {ReferenceConstants} from "../../constants/referenceConstants";
import {ProviderSearchService} from "../../services/provider-search/provider-search.service";
import {UserSessionService} from '../../shared/services/user-session/user-session.service';
import {UmIntakeFuncGraphqlService} from '../../services/um-intake-functions/umintakefunc-graphql.service';
@Injectable()
class MockStepperDataService {
  private stepperData = new BehaviorSubject({tenantId: 'ecpumintakebaseproductbpmgrp',hsc:
                                                    {
                                                      hsc_id: 7448,
                                                      auth_end_dt: null,
                                                      chg_user_id: 'SYSTEM',
                                                      creat_user_id: 'SYSTEM',
                                                      auth_strt_dt: null,
                                                      auth_typ_ref_id: null,
                                                      cont_of_care_ind: null,
                                                      indv_id: 503926748,
                                                      mbr_cov_dtl: null,
                                                      mbr_cov_id: 12484,
                                                      rev_prr_ref_id: 3754,
                                                      srvc_set_ref_id: 3738,
                                                      hsc_sts_ref_id : 19274
                                                    },
                                                    selectedMember:{
                                                      coverage:{
                                                        cov_typ_ref_id: 123
                                                      }
                                                    }
                                                  });
  sharedStepperData = this.stepperData.asObservable();

  constructor() { }

  setStepperData(stepperData: any) {
    this.stepperData.next(stepperData);
  }
}
@Injectable()
class MockHttpClient {
  post(url: string, body: any | null, options?: any) {
    switch (url) {
      case environment.SAVE_HSC_PROCEDURE:
        return of({ insert_hsc_srvc_one : {hsc_id: 123, hsc_srvc_id: 111}, displayMessage: "test" });
      case environment.SERVICE_ETA_URL:
        return of({ data: {eta: 2} });
      default:
        return of({data: { sys_cnfg : [{}] }});
    }
  }
  get(url: string) {
    if (url.includes('/activity-instances')) {
      return of({ childActivityInstances: [{ executionIds: [{}] }] });
    } else if (environment.PROCESS_INSTANCE_BASE_URL === url) {
      return of([{}]);
    } else {
      return of({});
    }
  }
}
@Injectable()
class MockUmIntakeService {
  saveProcedure(caseId: string, hsc_id: string, proc_cd: string,  proc_cd_schm_ref_id: number, srvc_hsc_prov_id: number, requestCategory: string): Observable<any>  {
    return of({data: { saveProcedure: { hscSrvcId : 12980}}});
  }

  deleteProcedure(hsc_id: string, hsc_srvc_id: number): Observable<any>  {
    return of({data: { deleteProcedure: { hsc_id : '15430'}}});
  }

  upsertProcedure(upsertProc): Observable<any>  {
    return of({data: { upsertProcedure: { hscSrvcId : 13073}}});
  }

}

@Injectable()

class MockReferenceService {
  loadBaseRefNameDisplayData(baseRefName: string): Observable<any> {
    return of({data: { ref : [{ref_id: 1, ref_dspl: 'test', ref_cd: 123}] }});
  }

  getProcedureDescByCodes(procedures: any[]) {
    return [{proc_cd: '123', cd_desc: 'test desc'}];
  }
}

@Injectable()

class MockProcedureServiceService{
  getServiceETA(record): Observable<any> {
    return of({ data: {eta: 2} });
  }
}

@Injectable()
class ProviderSearchMockService {
  getProviderTinOrNpiSearch(providerCategoryId, providerTIN, providerNPI): Observable<any> {
    return of({ data: {
        v_prov_srch: [{prov_id: '667', providerTin: '345', addressLine: 'test', lst_nm: 'test', fst_nm: 'test',
          bus_nm: 'facility', telcom_adr_id: '46', spcl_ref_dspl: 'vg', spcl_ref_id: '546',
          prov_loc_affil_id: '8686'}]
      } });
  }
  setProviderDetails(providerTelecomAddressId: string, providerSpecialtyRefId: string,
                     providerLocationAffiliationId: string, PROVIDER_ROLE_REF_ID: number, stepperData: any): Observable<any> {
    return of({hscduplicates: [{hsc_id: 123}]});
  }
  getProviderNameSearch(providerCategoryId: number, providerFirstName: string, providerLastName: string, providerState: number,
                        providerZipCode: string, providerOrgName: string): Observable<any> {
    return of({});
  }
  getProviderTinOrNpi(providerID: string, providerKeyTypeRefId: number): Observable<any> {
    return of({data: {
        prov_key: [{prov_key_val: '455'}]
      }});
  }
  getHscProvider(hscid): Observable<any> {
    return of({data: {
        hsc_prov: [{prov_key_val: '455', prov_loc_affil_id: 76, hsc_prov_roles: [{prov_role_ref_id: 3760}]
        }, {prov_key_val: '455', prov_loc_affil_id: 76, hsc_prov_roles: [{prov_role_ref_id: 3758}]
        }]}});
  }

  getHscProviderByProviderId(providerID: string): Observable<any> {
    return of({data: {
        hsc_prov: [{prov_key_val: '455'},{prov_loc_affil_id:'7'}]
      }});

  }

  getServicingProviderByHscId(hscID: string): Observable<any> {
    return of({data: {
        hsc_prov: [{hsc_prov_id: '455',hsc_prov_roles:[{hsc_prov_id : '455',prov_role_ref_id:'3765'}]},{hsc_prov_id: '456',hsc_prov_roles:[{hsc_prov_id : '456',prov_role_ref_id:'3764'}]}]
      }});

  }

  getReferenceCD(ref_id: number): Observable<any> {
    return of({data: {
        ref: [{ref_cd: '455'},{ref_dspl:'test ref'}]
      }});

  }

  getProviderTinSearch(locationAffiliationId: number, providerTIN: string, providerTINKey: number) : Observable<any> {
    return of({data: {
        v_prov_srch: [{st_ref_id: 172, prov_id: 125, adr_ln_1_txt: 'g', adr_ln_2_txt: 'r', cty_nm: 'test', zip_cd_txt: '645456',
          spcl_ref_id: 437, }]
      }});
  }
  getProviderDetailsSearch(provId, provAdrId, provtelcomAdrId, ProvSpecialtyRefId): Observable<any> {
    return of({ data: {
        v_prov_srch: [{prov_id: '667', providerTin: '345', addressLine: 'test', lst_nm: 'test', fst_nm: 'test',
          bus_nm: 'facility', telcom_adr_id: '46', spcl_ref_dspl: 'vg', spcl_ref_id: '546', }]
      } });
  }
}

const  mockData = [
              {
				code: '95912',
				description: ' NERVE CONDUCTION STUDIES 11-12 STUDIES',
				expanded: false,
				hscId: '9099',
				index: 0,
				procedureCategory: [],
				procedureCounter: 1,
				procedureOthrTxtSwitch: 0,
				procedureType: 'CPT4',
				viewDetails: false,
              }
            ];
@Injectable()
class UserSessionMockService {
  i = 0;
  getUserName() {
    if (this.i === 0) {
      this.i++;
      return 'breddy88';
    } else if (this.i === 1) {
      this.i = this.i + 2;
      return 'SYSTEM';
    } else if (this.i === 3)  {
      return 'abcd';
    }
  }
  getUserOrg() {
    return 'ecp';
  }
  getUserPermission() {}

  getEcpToken() {}
  getFunctionalRole() {}
}
describe('ProcedureComponent', () => {
  let component: ProcedureComponent;
  let fixture: ComponentFixture<ProcedureComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [uitkModules, uitkAngularModules, FormsModule, ReactiveFormsModule, HttpClientTestingModule, UITKTableModule, UITKTableFeaturesModule],
      declarations: [ProcedureComponent, ProcedureExpandableRowComponent],
      providers: [Apollo, HttpHandler, ProcedureService, LiveRegionService,
        { provide: StepperDataService, useClass: MockStepperDataService }, { provide: HttpClient, useClass: MockHttpClient },{ provide: UserSessionService, useClass: UserSessionMockService},
        {provide: ReferenceService, useClass: MockReferenceService},{ provide: ProviderSearchService, useClass: ProviderSearchMockService }, { provide: UmIntakeFuncGraphqlService, useClass: MockUmIntakeService }],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(function() {
    spyOn(window.console, 'log');
  });

  beforeEach(inject([FormBuilder], (fb: FormBuilder) => {
    fixture = TestBed.createComponent(ProcedureComponent);
    component = fixture.componentInstance;
    component.dataSource.data = mockData;
    fixture.detectChanges();
  }));

  afterEach(() => {
      TestBed.resetTestingModule();
      fixture.destroy();
  });

  afterAll(() => {
      TestBed.resetTestingModule();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should add search component', () => {
    component.addSearchComponent();
    expect(component.searchComponentsForm.value.searchComponentArray.length).toBe(2);
  });

  it('should check set and get code', () => {
    const searchComponentGroup = (component.searchComponentsForm.get('searchComponentArray') as FormArray).at(0);
    component.setCode('123', 0);
    expect(searchComponentGroup.get('code').value).toBe('123');
    component.getCode(0);
    expect(searchComponentGroup.get('code').value).toBe('123');
  });

  /*  it('should show Clear Icon', () => {
         component.showClearIcon();
         expect(component.showClearIcon).toBeTruthy();
    });*/

  /* it("should select Radio Value", () => {
           const searchComponentGroup = (component.searchComponentsForm.get("searchComponentArray") as FormArray).at(0);
           component.selectRadioValue('123', 0);
           expect(searchComponentGroup.get("codeType").value).toBe("123");
   });
*/
  it('should update Parent Results', () => {
    component.updateParentResults('tony', 1);
    expect(component.updateParentResults).toBeTruthy();
  });

  /*  it("should get Requested Units", () => {
            const searchComponentGroup = (component.searchComponentsForm.get("searchComponentArray") as FormArray).at(0);
            component.getRequestedUnits(0);
            expect(searchComponentGroup.get("requestedUnits").value).toBe(1);
    });*/

  it('should checkForEmptyField', () => {
    const returnValue = component.checkForEmptyField();
    expect(component.checkForEmptyField).toBeTruthy();
    expect(returnValue).toEqual(false);
  });

  it('should add Search Component Dynamically Tab', () => {
    const searchComponentGroup = (component.searchComponentsForm.get('searchComponentArray') as FormArray).at(0);
    const selectedValue = 'text';
    component.addSearchComponentDynamicallyTab(selectedValue, 0);
    expect(component.addSearchComponentDynamicallyTab).toBeTruthy();
  });

  /*   it("should add Search Component1 ", () => {
         const searchComponentGroup = (component.searchComponentsForm.get("searchComponentArray") as FormArray).at(0);
              const selectedValue = 'text'
         component.addSearchComponentDynamic(selectedValue,0);
         expect(component.addSearchComponentDynamic).toBeTruthy();
     })
 */
  it('should onCancel Message ', () => {
    component.onExpand('text');
    expect(component.onExpand).toBeTruthy();
    expect(window.console.log).toHaveBeenCalled();
  });

  it('should get Procedure CType', () => {
    const searchComponentGroup = (component.searchComponentsForm.get('searchComponentArray') as FormArray).at(0);
    component.getProcedureCType(0);
    expect(searchComponentGroup.get('procedureCType').value).toBe('');
  });

  it('should check get and set Descrption', () => {
    const searchComponentGroup = (component.searchComponentsForm.get('searchComponentArray') as FormArray).at(0);
    component.setDescrption('123', 0);
    expect(searchComponentGroup.get('procedureCode').value).toBe('123');
    component.getDescription(0);
    expect(searchComponentGroup.get('procedureCode').value).toBe('123');
  });

  it('should has Duplicate', () => {
    const records = [{ code: '123' }];
    let arr = component.records;
    const searchComponentGroup = (component.searchComponentsForm.get('searchComponentArray') as FormArray).at(0);
    component.setDescrption('123', 0);
    component.hasDuplicate(arr, '123');
    expect(component.hasDuplicate).toBeTruthy();
  });

  it('should get Procedure details ', () => {
      const record = { procedureType: 'CPT4', code: '1118F', description: 'GERD', hscId: '1557', procedureCounter: 1, expanded: true, procedureCategory: [{ name: 'DME_TypCst', rank: 1 }] , procedureOthrTxtSwitch: 1};
      component.getProcRecordToSave(record);
      expect(component.getProcRecordToSave).toBeTruthy();
  });
  it('should enable custom DialogModal onCancel', () => {
    component.customDialogModal = true;
    component.onCancel();
    expect(component.customDialogModal).toBeFalse();
  });

  it('should enable message1 visible showInfo', () => {
    component.successMessage = {} as UITKPageNotificationComponent;
    component.successMessage.headerText = 'Success';
    component.message1.visible = true;
    // component.showInfo();
    // expect(component.message1.visible).toBe(true);
  });

  it('should call openDeletePopup', () => {
    /*const record: any = {
      code: 'any'
    };*/
    const record: any = {procedureType: 'HCPCS', code: 'A9900', description: ' DME SUP/ACCESS/SRV-COMPON/OTH HCPCS', hscId: '7374',
                         procedureCounter: 1, expanded: false, procedureCategory: [{name: 'DME_TypCst', rank: 1}, {name: 'DME_Equip', rank: 2},
    {name: 'DME_DesSrv', rank: 7},
    {name: 'OthrTxtReq', rank: 10}], procedureOthrTxtSwitch: 1};
    component.openDeletePopup(record);
    expect(component.openDeletePopup).toBeTruthy();
    // expect(component.customDialogModal).toBe(true);
  });

  it('should call openDeletePopup', () => {
   /* const record: any = {
      text: 'any'
    };*/
    const record: any = {procedureType: 'HCPCS', code: 'A9900', description: ' DME SUP/ACCESS/SRV-COMPON/OTH HCPCS', hscId: '7374',
                         procedureCounter: 1, expanded: false, procedureCategory: [{name: 'DME_TypCst', rank: 1}, {name: 'DME_Equip', rank: 2},
        {name: 'DME_DesSrv', rank: 7},
        {name: 'OthrTxtReq', rank: 10}], procedureOthrTxtSwitch: 1};
    component.openDeletePopup(record);
    expect(component.openDeletePopup).toBeTruthy();
  });

  it('should call addProcedure', () => {
    component.requestCategory = {id: 3738, label: 'Outpatient', value: 'Outpatient'};
    let authTypeForm = new FormBuilder().group({
      requestCategory: [{value: 'Inpatient', id: 123}, Validators.required],
      facilityType: [{value: 'Office', id: 123}, Validators.required],
      priority: [{value: 'Urgent', id: 123}, Validators.required]
    });
    component.stepperDataService.setStepperData({selectedMember: [{indv_id: 1234 }], authorizationTypeForm: authTypeForm,hsc: { chg_user_id: 'SYSTEM',creat_user_id: 'SYSTEM'} });
    component.addProc(0, '1234');
   // expect(component.saveProcedure).toBeDefined();
    expect(component.addProcedure).toBeDefined();
  });

  it('should call deleteRow', () => {
    const record: any = {
      code: 'any'
    };
    component.recordsIPOPFTosave = [{proc_cd_schm_ref_id: 4, proc_cd: 'A9509', proc_othr_txt: ' IODINE I-123 SODIUM IODIDE DX PER MILLICURIE', hsc_id: '2177'}];
    component.recordsOPToSaveInProcD = [{hsc_srvc_id: 4, hsc_id: '2177', proc_cd: '1118F',
                                         proc_othr_txt: ' GERD SYMPTOMS ASSESSED AFTER 12 MONTHS THERAPY',
                                         proc_cd_schm_ref_id: 2, hsc_srvc_rev_typ_ref_id: '18',
                                         hsc_srvc_non_facls: {data: {proc_freq_ref_id: '4',
                                                                     proc_uom_ref_id: 4287, proc_unit_cnt: '1',
                                                                     unit_per_freq_cnt: '2', proc_mod_1_cd: '2', proc_mod_2_cd: '8',
                                                                     proc_mod_3_cd: '1', proc_mod_4_cd: '8', srvc_end_dt: '07-07-2020',
                                                                     srvc_strt_dt: '07-16-2020'}}}];

    const arr = [{ procedureType: 'CPT4', code: '1118F', description: 'GERD', hscId: '1557', procedureCounter: 1, expanded: true, procedureCategory: [{ name: 'DME_TypCst', rank: 1 }] , procedureOthrTxtSwitch: 1}]
    ;

    component.selectRecord = { procedureType: 'CPT4', code: '1118F', description: 'GERD', hscId: '1557', procedureCounter: 1, expanded: true, procedureCategory: [{ name: 'DME_TypCst', rank: 1 }] , procedureOthrTxtSwitch: 1};
    component.openDeletePopup(record);
    component.successMessage = {} as UITKPageNotificationComponent;
    component.successMessage.headerText = 'Success';
    // component.showInfo();
    // expect(component.showInfo).toBeTruthy();
    component.deleteRow();
    expect(component.deleteRow).toBeDefined();
    expect(component.deleteRow).toBeTruthy();
  });

  it('should  recordWithExpandedValue false', () => {
      component.recordWithExpandedValue(0, false);
      expect(component.recordWithExpandedValue).toBeDefined();
    });

  it('should  recordWithExpandedValue true', () => {
        component.recordWithExpandedValue(0, true);
        expect(component.recordWithExpandedValue).toBeDefined();
   });

  it('should showServiceBlockError  Error', () => {
    component.showServiceBlockError();
    expect(component.showServiceBlockError).toBeTruthy();
  });
  it('should showError  Error', () => {
    component.showError();
    expect(component.showError).toBeTruthy();
  });
  it('should mapServiceBlockRes ', () => {
    const mapServiceBlockRes = [
      {
        displayMessage: {
          type: 'String',
          value: 'Service is blocked for this procedure code',
          valueInfo: {}
        },
        rulesDecision: {
          type: 'String',
          value: 'STOP',
          valueInfo: {}
        }
      }
    ];
    if (mapServiceBlockRes.length > 0) {
      component.isServiceBlock = true;
      expect(component.showServiceBlockError).toBeTruthy();
    } else {
      component.isServiceBlock = false;
    }
    component.mapServiceBlockRes(mapServiceBlockRes);
  });

  it('should  addProc', () => {
    component.allowMultipleServicingProvider = false;
    component.procedureCounter = 1;
    component.requestCategory = {id: 3738, label: 'Outpatient', value: 'Outpatient'};
    let authTypeForm = new FormBuilder().group({
      requestCategory: [{value: 'Inpatient', id: 123}, Validators.required],
      facilityType: [{value: 'Office', id: 123}, Validators.required],
      priority: [{value: 'Urgent', id: 123}, Validators.required]
    });
    component.stepperDataService.setStepperData({selectedMember: [{indv_id: 1234 }], authorizationTypeForm: authTypeForm,hsc: { chg_user_id: 'SYSTEM',creat_user_id: 'SYSTEM'}});
    component.addProc(0, '1234');
    expect(component.addProc).toBeDefined();
  });

 /* it('call  setRecords false', () => {
    component.disableExpandedRow = false;
    component.requestCategory = {value: 'Inpatient'};
    let authTypeForm = new FormBuilder().group({
      requestCategory: [{value: 'Inpatient', id: 123}, Validators.required],
      facilityType: [{value: 'Office', id: 123}, Validators.required],
      priority: [{value: 'Urgent', id: 123}, Validators.required]
    });
    component.stepperDataService.setStepperData({selectedMember: [{indv_id: 1234 }], authorizationTypeForm: authTypeForm });
    let recordTosave =
      [{"code":"89342","description":" STORAGE PER YEAR EMBRYO","hscId":"3637", 'hsc_srvc_id': '123'}];
    component.setRecords(recordTosave);
    expect(component.setRecords).toBeDefined();
  });

  it('call  setRecords true', () => {
    component.requestCategory = {value: 'Outpatient Facility'};
    let authTypeForm = new FormBuilder().group({
      requestCategory: [{value: 'Inpatient', id: 123}, Validators.required],
      facilityType: [{value: 'Office', id: 123}, Validators.required],
      priority: [{value: 'Urgent', id: 123}, Validators.required]
    });
    component.stepperDataService.setStepperData({selectedMember: [{indv_id: 1234 }], authorizationTypeForm: authTypeForm });
    let recordTosave =
      [{"code":"89342","description":" STORAGE PER YEAR EMBRYO","hscId":"3637", 'hsc_srvc_id': '123'}];
    component.setRecords(recordTosave);
    expect(component.setRecords).toBeDefined();
  });
*/

  it('call function getOPCaseTypeAndProcedureData()', () => {
  /*  const procData  = [
      {
        inac_ind: 0,
        proc_cd: '80346',
        proc_cd_schm_ref_id: 2,
        proc_othr_txt: ' DRUG SCREENING BENZODIAZEPINES 1-12',
        srvc_hsc_prov_id: null,
        hsc_srvc_non_facls: [
          {
            "plsrv_ref_id": 3741,
            "plsrv_ref_cd": [
              {
                "ref_id": 3741,
                "ref_desc": "Home",
                "ref_dspl": "Home"
              }
            ],
            "proc_uom_ref_cd": [
              {
                "ref_id": 3741,
                "ref_desc": "Home",
                "ref_dspl": "Home"
              }
            ],
            "proc_freq_ref_cd": [
              {
                "ref_id": 3741,
                "ref_desc": "Home",
                "ref_dspl": "Home"
              }
            ],
            "srvc_dtl_ref_cd": [
              {
                "ref_id": 3741,
                "ref_desc": "Home",
                "ref_dspl": "Home"
              }
            ]
          }
        ]
      },
      {
        "inac_ind": 0,
        "proc_cd": null,
        "proc_cd_schm_ref_id": 4,
        "proc_othr_txt": " 12-LEAD ELECTROCARDIOGRAM PERFORMED",
        "srvc_hsc_prov_id": null,
        "hsc_srvc_non_facls": []
      }
    ]*/

    const opCaseTypeData = {code: '1255', description: 'radioolgy ECG'};
    component.opCaseTypeData = opCaseTypeData;
    // component.procedureOPList.push(procData)
    // expect(component.procedureOPList).toBeDefined()
  //  spyOn(component,"prepareProcedureOPDisply").and.callThrough()
    component.getOPCaseTypeAndProcedureData([]);
    expect(component.getOPCaseTypeAndProcedureData).toBeTruthy();
    component.prepareProcedureOPDisply([]);
    expect(component.prepareProcedureOPDisply).toBeTruthy();
  });
  it('call function prepareProcedureOPDisply()', () => {
    const procData  = [
      {
        inac_ind: 0,
        proc_cd: '80346',
        proc_cd_schm_ref_id: 2,
        proc_othr_txt: ' DRUG SCREENING BENZODIAZEPINES 1-12',
        srvc_hsc_prov_id: null,
        hsc_srvc_non_facls: [
          {
            plsrv_ref_id: 3741,
            plsrv_ref_cd: [
              {
                ref_id: 3741,
                ref_desc: 'Home',
                ref_dspl: 'Home'
              }
            ],
            proc_uom_ref_cd: [
              {
                ref_id: 3741,
                ref_desc: 'Home',
                ref_dspl: 'Home'
              }
            ],
            proc_freq_ref_cd: [
              {
                ref_id: 3741,
                ref_desc: 'Home',
                ref_dspl: 'Home'
              }
            ],
            srvc_dtl_ref_cd: [
              {
                ref_id: 3741,
                ref_desc: 'Home',
                ref_dspl: 'Home'
              }
            ],
          }
        ]
      },
      {
        inac_ind: 0,
        proc_cd: null,
        proc_cd_schm_ref_id: 4,
        proc_othr_txt: ' 12-LEAD ELECTROCARDIOGRAM PERFORMED',
        srvc_hsc_prov_id: null,
        hsc_srvc_non_facls: []
      }
    ];

    component.prepareProcedureOPDisply([]);
    expect(component.prepareProcedureOPDisply).toBeTruthy();

  });

  /*it('should save OP Procedure Records', () => {
    let authTypeForm = new FormBuilder().group({
      requestCategory: new FormControl({ id: 3738, label: 'Outpatient', value: '3' }),
      facilityType: new FormControl({ id: 1, label: 'Home', value: '4' }),
      priority: new FormControl({ id: 1, label: 'Home', value: '4' }),
      serviceDescription: new FormControl({ id: 1, label: 'Home', value: '4' })
    });
    component.stepperDataService.setStepperData({selectedMember: [{indv_id: 1234 }], authorizationTypeForm: authTypeForm, hscSrvcid: '123' });
    component.saveProcedure([{ proc_cd_schm_ref_id: 4, proc_cd: 'A9509', proc_othr_txt: ' IODINE I-123 SODIUM IODIDE DX PER MILLICURIE', hsc_id: '2177' }]);
    expect(component.saveProcedure).toBeTruthy();
  });*/

  it('should call buildIPOPFProcedures', () => {
    const hscProcs = [{
      inac_ind: 0,
      proc_cd: '88299',
      proc_cd_schm_ref_id: 2,
      proc_othr_txt: ' UNLISTED CYTOGENETIC STUDY',
      srvc_hsc_prov_id: null,
      hsc_srvc_non_facls: []
    }];
    component.buildIPOPFProcedures(hscProcs);
    expect(component.records.length).toEqual(0);
  });

  it('should call prepareProcedureOPDisply', () => {
    component.stepperData = {hsc: {
      hsc_sts_ref_id: 19274
      }};
    const hscSrvcs = [
      {
        inac_ind: 0,
        proc_cd: '88299',
        proc_cd_schm_ref_id: 2,
        proc_othr_txt: ' UNLISTED CYTOGENETIC STUDY',
        srvc_hsc_prov_id: null,
        hsc_srvc_non_facls: []
      }
    ];
    component.prepareProcedureOPDisply(hscSrvcs);
    expect(component.records.length).toEqual(0);
  });

  it('should  test onSortChange', () => {
        const sortState =  {direction: 1, column: 'note', enabled: true};
        component.onSortChange(sortState);
        expect(component.onSortChange).toBeTruthy();
      });

  it('should  test expandable Function', () => {
    component.records = [{hsc_srvc_id: 123, viewDetails: false}, {hsc_srvc_id: 456, viewDetails: false}];
    const data = {hsc_srvc_id: 123};
    component.toggleExpand(data);
    expect(component.records[0].viewDetails).toBeTrue();
  });

  it('should mapProviderDetail', () => {
    let hsc_prov=[{
      "hsc_id": 7448,
      "hsc_prov_id": 254,
      "prov_loc_affil_id": 5,
      "spcl_ref_id": 17048,
      "telcom_adr_id": "4326392664",
      "hsc_prov_roles": [{
        "hsc_prov_id": 254,
        "prov_role_ref_id": 3766
      }]
    }, {
      "hsc_id": 7448,
      "hsc_prov_id": 311,
      "prov_loc_affil_id": 7,
      "spcl_ref_id": 16696,
      "telcom_adr_id": "3044429999",
      "hsc_prov_roles": [{
        "hsc_prov_id": 311,
        "prov_role_ref_id": 3760
      }]
    }];
    expect(component.getServicingProviderDetail).toBeTruthy();
    if(hsc_prov !==null){
      component.mapProviderDetail(hsc_prov,"WV");
    }
  });
  it('should getProviderAddressLine', () => {
    component.getProviderAddressLine('Adr1', 'Adr2', 'newyork', 'NYZ123', '4567');
    expect(component.getProviderAddressLine).toBeDefined();
  });

  it('should getServicingProviderName PHYSICIAN ', () => {
    const addressLine = "address 1 ,2 Tin City";
    const providerTin = "1234567";

    const servicingProviderDetail= {
      businessName: 'bussiness name',
      firstName: 'first name',
      lastName: 'fst name' + ', ' + 'providerDetails.fst_nm',
      addressLine, providerTin,
      prov_id: '12375544',
      phone: '13214566',
      specialty: '3445466',
      specialtyId: '3445466',
      locationAffiliationId: '7',
      providerCategoryId: 16309,
    };
    component.getServicingProviderName(servicingProviderDetail);
    if (ReferenceConstants.PHYSICIAN_CAT_ID === servicingProviderDetail.providerCategoryId) {
      expect(component.getServicingProviderName).toBeDefined();
    }  });
  it('should getServicingProviderNameFacility', () => {
    const addressLine = "address 1 ,2 Tin City";
    const providerTin = "1234567";

    const servicingProviderDetail= {
      businessName: 'bussiness name',
      firstName: 'first name',
      lastName: 'fst name' + ', ' + 'providerDetails.fst_nm',
      addressLine, providerTin,
      prov_id: '12375544',
      phone: '13214566',
      specialty: '3445466',
      specialtyId: '3445466',
      locationAffiliationId: '7',
      providerCategoryId: 16310,
    };
    component.getServicingProviderName(servicingProviderDetail);
    if (ReferenceConstants.FACILITY_CAT_ID === servicingProviderDetail.providerCategoryId) {
      expect(component.getServicingProviderName).toBeDefined();
    }
  });

  it('should getServicingProviderDetail', () => {
    component.getServicingProviderDetail(1234);
    expect(component.getServicingProviderDetail).toBeDefined();
  });

  it('should setServicingProviderDetail', () => {
    const servicingProviderDetail= {
      businessName: 'bussiness name',
      firstName: 'first name',
      lastName: 'fst name' + ', ' + 'providerDetails.fst_nm',
      prov_id: '12375544',
      phone: '13214566',
      specialty: '3445466',
      specialtyId: '3445466',
      locationAffiliationId: '7',
      providerCategoryId: 16310,
    };
    component.setServicingProviderForexistingProcedure(servicingProviderDetail,12);
    expect(component.setServicingProviderForexistingProcedure).toBeDefined();
  });
});
