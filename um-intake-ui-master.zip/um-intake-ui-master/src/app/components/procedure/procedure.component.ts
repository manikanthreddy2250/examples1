import { HttpClient, HttpHeaders } from '@angular/common/http';
import {REFERENCE_PREFIX} from '@angular/compiler/src/render3/view/util';
import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  createPlatformFactory,
  Injectable,
  Input,
  OnDestroy,
  OnInit,
  QueryList,
  ViewChild,
  ViewChildren
} from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, NumberValueAccessor, Validators } from '@angular/forms';
// import {ITableInputModel} from '@uimf/uitk/components/tables';
import { ITableInputModel, LiveRegionService, SearchComponent } from '@uimf/uitk';
import { UITKPageNotificationComponent, UITKPageNotificationService } from '@uitk/angular';
import {
IUITKColumnState,
UITKTableDataSource,
UITKTableSortDirective,
} from '@uitk/angular';
import {Observable, Subscription} from 'rxjs';
import {ConfigConstants} from '../../constants/configConstants';
import {Constants} from '../../constants/constants';
import {FlowType} from '../../models/enums/flowType';
import { ProcedureServiceService } from 'src/app/services/procedure/procedure-service.service';
import {ReferenceConstants} from 'src/app/constants/referenceConstants';
import {ProcedureService} from 'src/app/services/procedure/procedure.service';
import {StepperDataService} from 'src/app/services/StepperDataService/StepperDataService';
import {environment} from 'src/environments/environment';
import {ReferenceService} from '../../services/refernce-service/reference.service';
import {ProcedureConfirmationComponent} from '../confirmation/procedure-confirmation/procedure-confirmation.component';
import { ProcedureConstants } from './procedure-expandable-row/procedure-constants';
import { ProcedureExpandableRowComponent } from './procedure-expandable-row/procedure-expandable-row.component';
import { ProcedureSearchComponent } from './procedure-search/procedure-search.component';
import {ProviderSearchService} from "../../services/provider-search/provider-search.service";
import {RawQuery} from "@ecp/gql-tk-beta";
import {SysConfigService} from "../../services/sysconfig-service/sys-config.service";
import {UserSessionService} from '../../shared/services/user-session/user-session.service';
import {UmIntakeFuncGraphqlService} from '../../services/um-intake-functions/umintakefunc-graphql.service';

const ADVANCE_NOTIFICATION = "ADVNTF - Advance Notification";
const CONTENT_TYPE_APPLICATION_JSON = "application/json";

@Component({
  selector: 'um-procedure',
  templateUrl: './procedure.component.html',
  styleUrls: ['./procedure.component.scss'],
  providers: [LiveRegionService]
})

@Injectable({
  providedIn: 'root'
})
export class ProcedureComponent implements OnInit, AfterViewInit, OnDestroy  {

  constructor(
    private readonly fb: FormBuilder,
    //private readonly service: ProcedureService,
    private readonly procedureServiceService: ProcedureServiceService,
    private readonly  providerSearchService: ProviderSearchService,
    private messageService: UITKPageNotificationService,
    private readonly httpClient: HttpClient, public stepperDataService: StepperDataService,
    public readonly referenceService: ReferenceService,
    private readonly sysConfigService: SysConfigService,
    private readonly userSessionService: UserSessionService,
    private readonly umIntakeFuncGraphqlService: UmIntakeFuncGraphqlService
  ) {
    this.records = [];
    this.recordsIPOPFTosave = [];
    this.recordsIPTosave = [];
    this.recordsOPFTosave = [];
    this.recordsTosave = [];
    this.isServiceBlock = false;

  }
  // sourceForListOfProcModifiers: any = (procedureModifierList as any).default;
  procedureResultsTable: ITableInputModel = {
    title: 'Procedure Search Results Table',
    enableSorting: true
  };
  @ViewChild('sortTable') uitkTableSort: UITKTableSortDirective;
  dataSource = new UITKTableDataSource([]);
  sortDescription = '';
  customDialogModal: boolean;
  selectRecord: any;
  recordsTosave;
  requestCategory;
  procedureCounter = 1;
  expandedRowData: any = 'code';
  procedureCat = [];
  procedureLimit: any;
  stepperData: any;
  records = [];
  procedure: string;
  searchComponentsForm: FormGroup;
  numberOfResults = 0;
  rulesDecision;
  displayMessage;
  isServiceBlock: boolean;
  @ViewChildren(ProcedureSearchComponent) searchComponentChild: QueryList<ProcedureSearchComponent>;
  recordsIPOPFTosave = [];
  hscServiceRecordTosave = [];
  recordsOPToSaveInProcD = [];
  recordsIPTosave = [];
  recordsOPTosave = [];
  recordsOPFTosave = [];
  savedProcRecords = [];
  procedureOPList = [];
  opCaseTypeData: any;
  HSC_STATUS_TYPE_OPEN = ReferenceConstants.HSC_STATUS_TYPE_OPEN;
  HSC_STATUS_TYPE_DRAFT = ReferenceConstants.HSC_STATUS_TYPE_DRAFT;
  currentIndex = 0;
  SERVICESETTINGTYPE_OUTPATIENT = ReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT;
  SERVICESETTINGTYPE_OUTPATIENT_FACILITY = ReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY;
  SERVICESETTINGTYPE_INPATIENT = ReferenceConstants.SERVICESETTINGTYPE_INPATIENT;
  FLOW_TYPE_EDIT = FlowType.EDIT;
  serviceTypeCodeList = [];
  procFrequencyList = [];
  standardMeasureList = [];
  procedureModifierList = [];
  precedureRefData: any = {};
  servicingProviderName='';
  servicingProviderDetail :any;
  hscProviderDetail :any;
  allowMultipleServicingProvider = true;

  // public tkRowComponent = NestedRowContentComponent;
  public tkRowComponent = ProcedureExpandableRowComponent;
  public tkRowProcedureComponent = ProcedureConfirmationComponent;

  procedureExpandableTable: ITableInputModel = {
    title: 'Procedure Expandable Results Table',
    enableSorting: true
  };
  procedureExpandableColumns: any = [
    { label: 'Code', id: 'code', dataType: 'text', style: { width: '150px' } },
    { label: 'Description', id: 'description', dataType: 'text' },
    { label: 'Servicing Provider', id: 'servicingProvider', dataType: 'text' }
  ];
  columns: any = [
    { label: 'Type', id: 'procedureType', dataType: 'text', style: { width: '150px' } },
    { label: 'Code', id: 'code', dataType: 'text', style: { width: '150px' } },
    { label: 'Description', id: 'description', dataType: 'text', style: { width: '500px' } },
    { label: 'Action', id: 'action', dataType: 'text', style: { width: '150px' }, sortable: false, enableFiltering: false },
    { label: 'Servicing Provider', id: 'servicingProvider', dataType: 'text', style: { width: '150px' }, sortable: false, enableFiltering: false },
  ];

  message1 = {
    id: 'rowdelete_success_msg',
    messageType: 'success',
    content: 'You have successfully deleted record to table.',
    visible: false,
    closeButton: true,
    pageNotificationTypeIcon: 'uitk-icon-checkmark_filled'
  };
  stepperDataSubscription: Subscription;
  procedureOthrText;

  messageLimitExceed = {
    id: 'error_msg',
    messageType: 'error',
    content: 'The number of procedure codes entered has reached the maximum limit.',
    visible: false,
    closeButton: true,
  };

  httpHeaders = new HttpHeaders({
    'Content-Type': CONTENT_TYPE_APPLICATION_JSON,
    'Accept': CONTENT_TYPE_APPLICATION_JSON,
    'Authorization': 'Basic ' + btoa('wbadmin:wbadmin')
  });

  camundaHttpHeaders = new HttpHeaders({});
  errorAlert = {
    id: 'error_msg',
    pageNotificationType: 'error',
    content: 'Unable to process Procedure.',
    visible: false,
    closeButton: true,
  };
  serviceBlockAlert = {
    id: 'error_msg',
    pageNotificationType: 'error',
    content: '',
    visible: false,
    closeButton: true,
  };
  @ViewChild(UITKPageNotificationComponent) successMessage: UITKPageNotificationComponent;

  onExpand(event) {
    console.log(event);
  }

  setServicingProviderForcurrentProcedure(servicingProviderSelected, hscSrvcId: number) {
    const index = this.records.findIndex((item) => item.hsc_srvc_id === hscSrvcId);
    if (index > -1) {
      this.records[index].servicingProvider = servicingProviderSelected.lastName;
      this.records[index].specialty = servicingProviderSelected?.specialty;
      this.records[index].providerTin = servicingProviderSelected?.providerTin;
      this.records[index].addressLine = servicingProviderSelected?.addressLine;
      this.records[index].phone = servicingProviderSelected.phone;
      this.dataSource.data = [...this.records];
      this.stepperDataService.setStepperData({...this.stepperData, hscProcedures: this.records});
    }
  }
  setServicingProviderForexistingProcedure(servicingProviderSelected, hscSrvcId: number) {
    this.stepperDataSubscription = this.stepperDataService.sharedStepperData.subscribe((stepperData) => {
      this.stepperData = stepperData;
      this.records = this.stepperData.hscProcedures ? this.stepperData.hscProcedures : this.records;
    });
    this.records.forEach((record)=>{
      record.servicingProvider = servicingProviderSelected.lastName;
    })
  }

  onSortChange(sortState: IUITKColumnState) {
      console.log('Sorting Change: ', sortState);
  }

  async ngOnInit() {
    this.getserviceTypeListQuery();
    this.getprocFrequencyListQuery();
    this.getstandardMeasureListQuery();
    this.getprocedureModifierListQuery();
    this.stepperDataSubscription = this.stepperDataService.sharedStepperData.subscribe((stepperData) => {
      this.stepperData = stepperData;
      this.records = this.stepperData.hscProcedures ? this.stepperData.hscProcedures : this.records;
      const serviceETA = this.columns.filter((arr) => arr.id === 'ServiceETA');
         if((this.stepperData.hsc.srvc_set_ref_id === this.SERVICESETTINGTYPE_OUTPATIENT) && serviceETA.length === 0) {
           this.columns.push({ label: 'Service ETA', id: 'ServiceETA', dataType: 'text', style: { width: '150px' }, sortable: false, enableFiltering: false });
         } else if(this.stepperData.hsc.srvc_set_ref_id !== this.SERVICESETTINGTYPE_OUTPATIENT && serviceETA.length !== 0){
           const id = this.columns.indexOf('ServiceETA');
           this.columns.splice(id,  1);
         }
      this.dataSource.data = [...this.records];
    });
    this.camundaHttpHeaders = new HttpHeaders({
      'Content-Type': ADVANCE_NOTIFICATION,
      'Accept': CONTENT_TYPE_APPLICATION_JSON,
      'Authorization': 'Bearer ' + this.userSessionService.getEcpToken(),
      'x-bpm-cli-org-id': this.userSessionService.getUserOrg(),
      'x-bpm-func-role': this.userSessionService.getFunctionalRole(),
      'x-bpm-tenant-id': this.stepperData.tenantId
    });
    const searchComponentGroup = new FormGroup({
      procedureTypeList: new FormControl(''),
      code: new FormControl(),
      procedureCode: new FormControl('', Validators.required),
      procedureCType: new FormControl(''),
    });

    this.searchComponentsForm = new FormGroup({
      searchComponentArray: new FormArray([searchComponentGroup]),
      code: new FormControl(),
      procedureCode: new FormControl('', Validators.required),
      procedureTypeList: new FormControl(''),
    });
    this.getProcedureLimit();
    this.getServiceProviderConfig();
    this.getProcedureOthrTxt();
    if (this.stepperData.flowType === FlowType.EDIT) {
      if (this.stepperData.hsc.srvc_set_ref_id === ReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT) {
        this.getOPCaseTypeAndProcedureData(this.stepperData.hsc.hsc_srvcs);
      } else {
        this.buildIPOPFProcedures(this.stepperData.hsc.hsc_srvcs);
      }
    }
  }
  ngOnDestroy() {
    this.stepperDataSubscription.unsubscribe();
  }
  getProcedureOthrTxt() {
    this.sysConfigService.getClientConfigByKey(ConfigConstants.PROC_OTHRTXT_CONFIG_KEY).subscribe((res) => {
      this.procedureOthrText = res ? res[0].value : null;
    }, (error) => {
    });
  }

  async buildIPOPFProcedures(hscProcs) {
    for (let i = 0; i < hscProcs.length; i++) {
      const proc = hscProcs[i];
      await this.getServicingProviderDetail(hscProcs[i].srvc_hsc_prov_id);
      this.getServicingProviderName(this.servicingProviderDetail);
      const record = {
        procedureType: proc.proc_cd_schm_ref_id === 2 ? ReferenceConstants.PROCEDURE_TYPE_CPT4_REF_DESC : ReferenceConstants.PROCEDURE_TYPE_HCPCS_REF_DESC,
        code: proc.proc_cd,
        description: proc.proc_desc,
        servicingProvider : this.servicingProviderName,
        address : this.servicingProviderDetail.addressLine ,
        networkStatus : '',
        specialty :  this.servicingProviderDetail.specialty,
        providerTin :  this.servicingProviderDetail.providerTin,
        phone :this.servicingProviderDetail.phone,
        premiumDesignation : '',
        hscId: proc.hsc_id,
        hsc_srvc_id: proc.hsc_srvc_id,
        expanded: false,
        procedureCategory: '',
        procedureOthrTxtSwitch: '',
        procedureCounter: this.procedureCounter
      };
      this.records.push(record);
      this.procedureCounter++;
    }
    this.stepperDataService.setStepperData({...this.stepperData, hscProcedures: this.records});
  }

  getOPCaseTypeAndProcedureData(hscsrvcs) {
    const opCaseTypeAndProcResponse = hscsrvcs;
    opCaseTypeAndProcResponse.forEach((item) => {
      if (item.proc_cd !== null) {
        this.procedureOPList.push(item);
      }
      if (item.proc_cd === null) {
        this.opCaseTypeData = item;
      }
    });
    if (((this.procedureOPList) && (this.procedureOPList !== undefined)) && (this.procedureOPList.length > 0)) {
      this.prepareProcedureOPDisply(this.procedureOPList);
    }
  }

   async  prepareProcedureOPDisply(procedureList) {
     for (const i in  procedureList) {
       const procedureType = procedureList[i].proc_cd_schm_ref_id === 2 ? ReferenceConstants.PROCEDURE_TYPE_CPT4_REF_DESC : ReferenceConstants.PROCEDURE_TYPE_HCPCS_REF_DESC;
       await this.getServicingProviderDetail(procedureList[i].srvc_hsc_prov_id);
       this.getServicingProviderName(this.servicingProviderDetail);
       if (procedureList[i].hsc_srvc_non_facls.length > 0) {
        if (this.stepperData.hsc?.hsc_sts_ref_id === this.HSC_STATUS_TYPE_DRAFT) {
          // build to support edit
          const editableOPProc = { ...procedureList[i], procedureType, code: procedureList[i].proc_cd, description: procedureList[i].proc_desc};
          this.records.push(editableOPProc);
        } else {
          // build for view only
          const hscSrvcNonFacl = procedureList[i].hsc_srvc_non_facls[0];
          const hscSrvcNonFaclDme = hscSrvcNonFacl?.hsc_srvc_non_facl_dmes ? hscSrvcNonFacl?.hsc_srvc_non_facl_dmes[0] : null;
          const viewOnlyOPProc = {
            procedureType,
            code: procedureList[i].proc_cd,
            hsc_id: this.stepperData.hsc?.hsc_id,
            description: procedureList[i].proc_desc,
            servicingProvider : this.servicingProviderName,
            address : this.servicingProviderDetail.addressLine ,
            networkStatus : '',
            specialty :  this.servicingProviderDetail.specialty,
            providerTin :  this.servicingProviderDetail.providerTin,
            phone :this.servicingProviderDetail.phone,
            premiumDesignation : '',
            serviceDetail: hscSrvcNonFacl.srvc_dtl_ref_cd.ref_dspl,
            total: hscSrvcNonFacl.proc_unit_cnt,
            measure: hscSrvcNonFacl.proc_uom_ref_cd.ref_dspl,
            count: hscSrvcNonFacl.unit_per_freq_cnt,
            frequency: hscSrvcNonFacl.proc_freq_ref_cd.ref_dspl,
            startDate: hscSrvcNonFacl.srvc_strt_dt,
            endDate: hscSrvcNonFacl.srvc_end_dt,
            procedureModifiers: this.buildModifiersString(procedureList[i]),
            expanded: false,
            procedureCounter: this.procedureCounter,
            dmeType: this.buildDmeType(hscSrvcNonFaclDme),
            dmeCost: hscSrvcNonFaclDme?.dme_tot_cst_amt,
            dmeClinicalDesc: hscSrvcNonFaclDme?.clin_ill_desc_txt,
            dmeItemDesc: hscSrvcNonFaclDme?.spl_desc_txt,
            dmeOtherDesc: procedureList[i].proc_othr_txt,
            dmeServicesDesc: hscSrvcNonFaclDme?.srvc_desc_txt,
            hsc_srvc_id: procedureList[i].hsc_srvc_id
          };
          this.records.push(viewOnlyOPProc);
        }
      } else {
        const procedureObject = {
          hsc_id: this.stepperData.hsc?.hsc_id,
          procedureType,
          code: procedureList[i].proc_cd,
          description: procedureList[i].proc_desc,
          servicingProvider:this.servicingProviderName ,
          procedureCounter: this.procedureCounter,
          hsc_srvc_id: procedureList[i].hsc_srvc_id,
          proc_cd_schm_ref_id: procedureList[i].proc_cd_schm_ref_id
        };
        this.records.push(procedureObject);
      }
      this.procedureCounter++;
      this.stepperDataService.setStepperData({...this.stepperData, hscProcedures: this.records});
    }
  }


  buildDmeType(hscSrvcNonFaclDme) {
    return  hscSrvcNonFaclDme?.dme_procrmnt_typ_id ?  hscSrvcNonFaclDme.dme_procrmnt_typ_id === 1 ? 'Purchase' : 'Rental' : null;
  }

  getProviderAddressLine(adr_ln_1_txt: string, adr_ln_2_txt: string, cty_nm: string, st_ref_cd: string, zip_cd_txt: string): string {
    let addressLine = '';
    if (adr_ln_1_txt) {
      addressLine = adr_ln_1_txt;
    }
    if (adr_ln_2_txt) {
      addressLine += ', ' + adr_ln_2_txt;
    }
    if (cty_nm) {
      addressLine += ', ' + cty_nm;
    }
    if (st_ref_cd) {
      addressLine += ', ' + st_ref_cd;
    }
    if (zip_cd_txt) {
      addressLine += ', ' + zip_cd_txt;
    }
    return addressLine;

  }
   getServicingProviderName(servicingProviderDetail){
      const prov_category = servicingProviderDetail.providerCategoryId;
      if (ReferenceConstants.PHYSICIAN_CAT_ID === prov_category) {
        this.servicingProviderName = servicingProviderDetail.lastName;
      } else if (ReferenceConstants.FACILITY_CAT_ID === prov_category) {
        this.servicingProviderName = servicingProviderDetail.businessName;
      }
    }
    async getServicingProviderDetail(providerId){
       await this.providerSearchService.getHscProviderByProviderId(providerId)
         .toPromise().then(async (res) => {
         const hscProviderDetail= res.data.hsc_prov[0];
         const hscProvId = hscProviderDetail?.prov_loc_affil_dtl?.providerDetails?.prov_id;
         const hscProvAdrId = hscProviderDetail?.prov_loc_affil_dtl?.providerDetails?.prov_adr_id;
         const hscProvtelcomAdrId = hscProviderDetail?.telcom_adr_id;
         const hscProvSpecialtyId = hscProviderDetail?.spcl_ref_id;
         await this.providerSearchService.getProviderDetailsSearch(hscProvId, hscProvAdrId, hscProvtelcomAdrId, hscProvSpecialtyId).toPromise().then(async(resServicingDetail) => {
           const  providerDetails = resServicingDetail.data.v_prov_srch[0];
            await this.providerSearchService.getReferenceCD(providerDetails.st_ref_id).toPromise().then(async(providerStateRes) => {
              const providerState = providerStateRes.data.ref[0].ref_cd;
               await this.providerSearchService.getReferenceCD(providerDetails.spcl_ref_id).toPromise().then(async (specialtydisplRes) => {
                 providerDetails.spcl_ref_dspl = specialtydisplRes.data.ref[0].ref_dspl;
                 this.mapProviderDetail(providerDetails, providerState)
              });
            });
         });
       });
  }
  mapProviderDetail(providerDetails, providerState){
      const  providerTin = providerDetails.prov_key_val;
      const addressLine = this.getProviderAddressLine(providerDetails.adr_ln_1_txt, providerDetails.adr_ln_2_txt, providerDetails.cty_nm, providerState, providerDetails.zip_cd_txt);
      this.servicingProviderDetail= {
        businessName: providerDetails.bus_nm,
        firstName: providerDetails.fst_nm,
        lastName: providerDetails.lst_nm + ', ' + providerDetails.fst_nm,
        addressLine, providerTin,
        prov_id: providerDetails.prov_id,
        phone: providerDetails.telcom_adr_id,
        specialty: providerDetails.spcl_ref_dspl,
        specialtyId: providerDetails.spcl_ref_id,
        locationAffiliationId: providerDetails.prov_loc_affil_id,
        providerCategoryId: providerDetails.prov_catgy_ref_id,
        providerAddressId: providerDetails.prov_adr_id,
      };
    }

  buildModifiersString(element) {
    let modifiersStr = '';
    if (element.hsc_srvc_non_facls[0].proc_mod_1_cd) {
      modifiersStr = modifiersStr + element.hsc_srvc_non_facls[0].proc_mod_1_cd;
    }
    if (element.hsc_srvc_non_facls[0].proc_mod_2_cd) {
      modifiersStr = modifiersStr + ' ' + element.hsc_srvc_non_facls[0].proc_mod_2_cd;
    }
    if (element.hsc_srvc_non_facls[0].proc_mod_3_cd) {
      modifiersStr = modifiersStr + ' ' + element.hsc_srvc_non_facls[0].proc_mod_3_cd;
    }
    if (element.hsc_srvc_non_facls[0].proc_mod_4_cd) {
      modifiersStr = modifiersStr + ' ' + element.hsc_srvc_non_facls[0].proc_mod_4_cd;
    }
    return modifiersStr;
  }

  getProcedureLimit() {
    this.sysConfigService.getClientConfigByKey(ConfigConstants.PROC_LIMIT_CONFIG_KEY).subscribe((res) => {
      this.procedureLimit = res ? res[0].value : null;
    }, (error) => {
    });
  }
  getServiceProviderConfig() {
    // Get servicing provider config from sys_cnfg
    this.sysConfigService.getClientConfigByKey(ConfigConstants.ALLOW_MULTI_SRVC_PROV_CONFIG_KEY).subscribe((res: any) => {
        this.allowMultipleServicingProvider = res ? res[0].value.toString() === '1' : true;
      },
      (error) => {}
    );
  }
  ngAfterViewInit() {
     this.dataSource.sort = this.uitkTableSort;
     this.tabSkipModifier();
     console.log(` tkRowComponent  ${JSON.stringify(this.tkRowComponent)}`);
  }

  // singelSelectControl = this.searchComponentsForm.get('procedureTypeList') as FormControl;

  /* Function is called whenever procedure modifiers are changed*/
  changedProcModifierValue(event: Event, currentIndex: number): void {
    const searchComponentGroup = (this.searchComponentsForm.get('searchComponentArray') as FormArray).at(currentIndex);
    const selectedModifiers = searchComponentGroup
      .get('procModifiers')
      .value.map((val) => {
        if (val.label.length > 38) {
          return val.label.substring(0, 38).concat('...');
        } else {
          return val.label.substring(0, 40);
        }
      })
      .join('\n\n ');
    searchComponentGroup.get('selectedProcModifiers').setValue(selectedModifiers);
  }

  tabSkipModifier() {
    const modifierButton = document.getElementsByClassName('tk-multi-sel-btn');
    for (let i = 0; i < modifierButton.length; i++) {
      const tabSkip = modifierButton[i] as HTMLElement;
      tabSkip.tabIndex = -1;
    }
  }

  addSearchComponent() {
    const searchComponentGroup = new FormGroup({
      code: new FormControl(),
      procedureCode: new FormControl(''),
      procedureTypeList: new FormControl('')
    });
    (this.searchComponentsForm.get('searchComponentArray') as FormArray).push(searchComponentGroup);
  }

  addSearchComponentDynamic(selectedValue, i) {
    console.log(`addSearchComponentDynamic selectedValue.... ${selectedValue}`);
    const searchComponentArray = this.searchComponentsForm.get('searchComponentArray') as FormArray;
    const previousCodeTypeValue = searchComponentArray.at(searchComponentArray.length - 1).get('codeType').value;

    this.searchComponentsForm.value.searchComponentArray[i].procedureCode = selectedValue;
    if (this.checkForEmptyField() === true) {
      const searchComponentGroup = new FormGroup({
        codeType: new FormControl(previousCodeTypeValue),
        code: new FormControl(),
        requestedUnits: new FormControl(1, [Validators.min(1), Validators.required]),
        procModifiers: new FormControl(''),
        selectedProcModifiers: new FormControl('')
      });
      (this.searchComponentsForm.get('searchComponentArray') as FormArray).push(searchComponentGroup);
    } else {
      const searchComponentChildArray = this.searchComponentChild.toArray();
      for (let j = this.searchComponentsForm.value.searchComponentArray.length; j > 0; j--) {
        if (!this.searchComponentsForm.value.searchComponentArray[j - 1].procedureCode) {
          searchComponentChildArray[j - 1].searchComponent._inputElementRef.nativeElement.focus();
          break;
        }
      }
    }
    this.tabSkipModifier();
    // this.sourceForListOfProcModifiers.forEach(item => item._selected = false);
    // this.itemsToDisplayForModifiers.push(this.sourceForListOfProcModifiers);
  }

  addSearchComponentDynamicallyTab(selectedValue, i) {
    console.log(`addSearchComponentDynamicallyTab selectedValue.... {selectedValue}`);
    this.searchComponentsForm.value.searchComponentArray[i].procedureCode = selectedValue;
  }

  checkForEmptyField() {
    for (const i of this.searchComponentsForm.value.searchComponentArray) {
      if (!i.procedureCode) {
        return false;
      }
    }
    return true;
  }

  /**
   * Function is triggered if Child component passes data to parent component.
   * Message is the results Found
   * @param message
   * @param searchComponentId
   */
  updateParentResults(message: any, searchComponentGroupId) {
    this.numberOfResults = message;
  }

  /**
   * Method used for to get Requested Units Form Control for validation purposes
   * @param index
   */
  getRequestedUnits(index) {
    const searchComponentGroup = (this.searchComponentsForm.get('searchComponentArray') as FormArray).at(index);
    return searchComponentGroup.get('requestedUnits');
  }

  /**
   * Show Clear Icon Upon Typing and control TabIndex of Icon
   */
  /*
 showClearIcon() {
   const procedureSearchWidget = document.getElementById('proceduresWidget');
   const icons = procedureSearchWidget.getElementsByClassName('tk-btn--search');
   const searchBars = procedureSearchWidget.getElementsByClassName('tk-input--search');
   for (let i = 0; i < icons.length; i++) {
     (searchBars[i] as HTMLElement).style.borderRight = 'none';
     const icon = icons[i] as HTMLElement;
     icon.style.display = 'inline';
     icon.style.borderLeft = 'none';
     icon.style.visibility = 'visible';
     icon.tabIndex = -1;
   }
 }
 */

  /**
   * Function responsible for setting radio button value upon clicking the respective radio button label
   * @param codeTypeSelected
   * @param arrayIndex
   */
  selectRadioValue(codeTypeSelected, arrayIndex) {
    const searchComponentGroup = (this.searchComponentsForm.get('searchComponentArray') as FormArray).at(arrayIndex);
    searchComponentGroup.get('codeType').setValue(codeTypeSelected);
  }

  setCode(code, arrayIndex) {
    const searchComponentGroup = (this.searchComponentsForm.get('searchComponentArray') as FormArray).at(arrayIndex);
    searchComponentGroup.get('code').setValue(code);
  }

  getCode(index) {
    const searchComponentGroup = (this.searchComponentsForm.get('searchComponentArray') as FormArray).at(index);
    return searchComponentGroup.get('code').value;
  }

  getProcedureCType(index) {
    const searchComponentGroup = (this.searchComponentsForm.get('searchComponentArray') as FormArray).at(index);
    console.log(`searchComponentGroup.get('procedureCType').value...${JSON.stringify(searchComponentGroup.get('procedureCType').value)}`);
    return searchComponentGroup.get('procedureCType').value;
  }

  async addProcedure(index) {
    this.requestCategory = this.stepperData.authorizationTypeForm.get('requestCategory')?.value;
    const procCode = this.getCode(index);
    if (this.getCode(index) === '' || this.getCode(index) === null) {
    } else {
      if ((this.procedureLimit !== 0) && (this.records.length >= this.procedureLimit)) {
        this.messageLimitExceed.visible = true;
        this.setCode('', index);
      } else {
        this.addProc(index, procCode);
      }
    }
    // To clear the search text box after add
    (document.getElementById('procedure') as HTMLInputElement).value = '';

  }

  saveProcedure(saveProcedure, procCode, record) {
    const hsc = this.getHsc();
    const caseId = this.stepperData.caseId;
    const reqCategory = this.stepperData.authorizationTypeForm.get('requestCategory')?.value.value;
    this.umIntakeFuncGraphqlService.saveProcedure(caseId, hsc.hsc_id, saveProcedure.proc_cd, saveProcedure.proc_cd_schm_ref_id, saveProcedure.srvc_hsc_prov_id, reqCategory).subscribe(
      (data: any) => {
        const serviceBlockRes = data;
        if (data.displayMessage) {
          this.mapServiceBlockRes(serviceBlockRes);
        } else {
          this.records.push(record); // to display
          this.dataSource.data = [...this.records];
          this.stepperDataService.setStepperData({...this.stepperData, hscProcedures: this.records});
          this.records.forEach((item, i) => {
            if (item.procedureCounter === this.procedureCounter) {
              this.records[i]['hsc_srvc_id'] = data.data.saveProcedure.hscSrvcId;
            }
          });
          this.procedureCounter++;
          if (hsc.srvc_set_ref_id === ReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT) {
            this.stepperDataService.setStepperData({ ...this.stepperData, hscDuplicates: data.hscDuplicates && data.hscDuplicates.length > 0 ? data.hscDuplicates : []});
          }
        }      },
      (error) => {
        if (error) {
        }
      }
    );
  }

  private getHsc() {
    const authTypeForm = this.stepperData.authorizationTypeForm;
    return {
      indv_id: this.stepperData.selectedMember.indv_id,
      hsc_id: this.stepperData.hscId,
      srvc_set_ref_id: authTypeForm.get('requestCategory')?.value.id,
      rev_prr_ref_id: authTypeForm.get('priority')?.value.id,
      hsc_sts_ref_id: ReferenceConstants.HSC_STATUS_TYPE_DRAFT
    };
  }
  private getHscSrvcNonFacl() {
    const authTypeForm = this.stepperData.authorizationTypeForm;
    return  {
      hsc_srvc_id: this.stepperData.hscSrvcid,
      plsrv_ref_id: authTypeForm.get('facilityType')?.value.id,
      srvc_desc_ref_id: authTypeForm.get('serviceDescription')?.value.id
    };
  }

  addProc(index, procCode) {
    const record: any = this.recordWithExpandedValue(index, true);
    const recordProcTosave = this.getProcRecordToSave(record);
    record.viewDetails = true;
    if (this.stepperData.hsc.srvc_set_ref_id === this.SERVICESETTINGTYPE_OUTPATIENT) {
      this.procedureServiceService.getServiceETA(record);
    }
    this.checkServicingProviderIsEnabledForCase(recordProcTosave,procCode,record);
  }

  checkServicingProviderIsEnabledForCase(recordProcTosave, procCode, record){
    this.providerSearchService.getServicingProviderByHscId(recordProcTosave.hsc_id).toPromise().then(async (res) => {
      res.data?.hsc_prov.forEach((hscProv)=>{
        hscProv.hsc_prov_roles.forEach((hscProvRoles)=>{
           if( hscProvRoles.prov_role_ref_id === ReferenceConstants.PROVIDER_ROLE_REF_ID_SERVICING && !this.allowMultipleServicingProvider){
            recordProcTosave.srvc_hsc_prov_id = hscProv.hsc_prov_id;
          }
        })
      });
      this.saveProcedure(recordProcTosave, procCode, record);
    });
  }

  mapServiceBlockRes(serviceBlockRes) {
    if (serviceBlockRes) {
      this.isServiceBlock = true;
      this.displayMessage = serviceBlockRes.displayMessage;
      this.rulesDecision = serviceBlockRes.rulesDecision;
      this.serviceBlockAlert.content = this.displayMessage;
      this.showServiceBlockError();
    } else {
      this.isServiceBlock = false;
    }
  }

  showServiceBlockError() {
    this.serviceBlockAlert.visible = true;
    this.messageService.add(this.serviceBlockAlert);
  }
  showError() {
    this.errorAlert.visible = true;
    this.messageService.add(this.errorAlert);
  }

  recordWithExpandedValue(index, expandedValue) {
    const record = {
        index: this.currentIndex,
        procedureType: this.getProcedureCType(index),
        code: this.getCode(index),
        description: this.getDescription(index),
        hscId: this.stepperData.hscId,
        procedureCounter: this.procedureCounter,
        expanded: expandedValue,
        procedureCategory: this.procedureCat,
        procedureOthrTxtSwitch: this.procedureOthrText,
        proc_cd_schm_ref_id: this.getProcedureCType(index) === ReferenceConstants.PROCEDURE_TYPE_HCPCS_REF_DESC ? 4 : 2
      };

    return record;
  }

  getProcRecordToSave(record) {
    return {
      proc_cd_schm_ref_id: record.procedureType === ReferenceConstants.PROCEDURE_TYPE_HCPCS_REF_DESC ? 4 : 2,
      proc_cd: record.code,
      hsc_id: record.hscId,
      chg_user_id: this.stepperData.hsc.chg_user_id,
      creat_user_id: this.stepperData.hsc.creat_user_id,
      srvc_hsc_prov_id: null
    };
  }

  hasDuplicate(array, code) {
    for (const i in array) {
      if (code === array[i].code) {
        return true;
      }
    }
    return false;
  }

  getDescription(index) {
    const searchComponentGroup = (this.searchComponentsForm.get('searchComponentArray') as FormArray).at(index);
    return searchComponentGroup.get('procedureCode').value;
  }

  setDescrption(desc, arrayIndex) {
    const searchComponentGroup = (this.searchComponentsForm.get('searchComponentArray') as FormArray).at(arrayIndex);
    searchComponentGroup.get('procedureCode').setValue(desc);
    console.log(`procedureCode  ${desc}`);
  }

  openDeletePopup(record) {
    if (record.code) {
      this.selectRecord = record;
      this.customDialogModal = true;
      this.deleteRow();
    }
  }

  deleteRow() {
    const index = this.records.findIndex((item) => item.hsc_srvc_id === this.selectRecord.hsc_srvc_id);
    this.records.splice(index, 1);
    this.records = [...this.records];
    this.dataSource.data = [...this.records];
    this.stepperDataService.setStepperData({...this.stepperData, hscProcedures: this.records});
    this.customDialogModal = false;
    this.procedureServiceService.deleteProcedure(this.stepperData.hscId, this.selectRecord.hsc_srvc_id);
    this.stepperDataService.setStepperData({...this.stepperData}); // refresh stepper data to reflect changes on Verify page (verification.component.ts);
    this.procedureCounter--;
  }

  onCancel() {
    this.customDialogModal = false;
  }

  showInfo() {
    this.successMessage.headerText = 'Success';
    this.message1.visible = true;
  }
  /* toggleTableRows() {
       this.isTableExpanded = !this.isTableExpanded;

       this.records.forEach((row: any) => {
         row.expanded = this.isTableExpanded;
       })
     }
 */

  toggleExpand(record: any) {
     this.records.forEach((item) => {
       if (item.hsc_srvc_id === record.hsc_srvc_id) {
         item.viewDetails = !item.viewDetails;
       }
     });
   }

  getserviceTypeListQuery() {
    const servicetypeBaseRefName = 'ServiceTypeCode';
    this.referenceService.loadBaseRefNameDisplayData(servicetypeBaseRefName).toPromise().then((res) => {
        const servicetypeResponse = res.data.ref;
        servicetypeResponse.forEach((item: { ref_id: number; ref_dspl: string; ref_cd: string; }) => {
          const servicetypeObj = {
            id: item.ref_id,
            label: item.ref_dspl,
            value: item.ref_cd
          };
          this.serviceTypeCodeList.push(servicetypeObj);
        });
        this.precedureRefData.serviceTypeCodeList = this.serviceTypeCodeList;
      }
    ).catch((error) => {

    });
  }

  getprocFrequencyListQuery() {
    const procFrequencyBaseRefName = 'actualProcedureFrequencyType';
    this.referenceService.loadBaseRefNameDisplayData(procFrequencyBaseRefName).toPromise().then((res) => {
        const procFrequencyResponse = res.data.ref;
        procFrequencyResponse.forEach((item: { ref_id: number; ref_dspl: string; ref_cd: string; }) => {
          const procFrequencyObj = {
            id: item.ref_id,
            label: item.ref_dspl,
            value: item.ref_cd
          };
          this.procFrequencyList.push(procFrequencyObj);
        });
        this.precedureRefData.procFrequencyList = this.procFrequencyList;
      }
    ).catch((error) => {

    });
  }

  getstandardMeasureListQuery() {
    const standardOfMeasureBaseRefName = 'procedureUnitOfMeasureType';
    this.referenceService.loadBaseRefNameDisplayData(standardOfMeasureBaseRefName).toPromise().then((res) => {
        const stndMeasureResponse = res.data.ref;
        stndMeasureResponse.forEach((item: { ref_id: number; ref_dspl: string; ref_cd: string; }) => {
          this.standardMeasureList.push(
            {
              id: item.ref_id,
              label: item.ref_dspl,
              value: item.ref_cd
            }
          );
        });
        for (const value of this.procedureCat) {
          if (value.name === 'OP_Nursin') {
            this.standardMeasureList = [{id: 19888, label: '1U = 15 mins of care', value: 6}];
          }
        }
        this.precedureRefData.standardMeasureList = this.standardMeasureList;
      }
    ).catch((error) => {

    });
  }

  getprocedureModifierListQuery() {
    const procFrequencyBaseRefName = 'procedureModifier';
    this.referenceService.loadBaseRefNameDisplayData(procFrequencyBaseRefName).toPromise().then((res) => {
        const procFrequencyResponse = res.data.ref;
        procFrequencyResponse.forEach((item: { ref_id: number; ref_dspl: string; ref_cd: string; }) => {
          this.procedureModifierList.push(
            {
              id: item.ref_id,
              label: item.ref_dspl,
              value: item.ref_cd
            }
          );
        });
        this.precedureRefData.procedureModifierList = this.procedureModifierList;
      }
    ).catch((error) => {

    });
  }

  isProcedureRefDataAvaialable() {
    return Object.keys(this.precedureRefData).length;
  }
}
