import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ProviderLaunchComponentComponent } from './provider-launch-component.component';
import { uitkAngularModules, uitkModules } from 'src/app/app.module';
import {FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators} from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import {Injectable, NO_ERRORS_SCHEMA} from '@angular/core';
import {UITKRadioGroupModule} from '@uitk/angular';
import {Observable, of, BehaviorSubject} from 'rxjs';
import {ReferenceService} from 'src/app/services/refernce-service/reference.service';
import {ProviderSearchService} from 'src/app/services/provider-search/provider-search.service';

@Injectable()
class ReferenceMockService {
  loadRefDataByRefID(refIds: any): Observable<any>{
  return of({data: {ref: [{ref_cd: 34}]}});
  }
  getReferenceDataForState(refIds: any): Observable<any>{
  return of({data: {ref_set: [{ref_id: 1059,ref_nm: "stateCode", ref:
			[{ref_cd: "AA", ref_id: 1059,}]}]}});
  }
}

@Injectable()
class ProviderSearchMockService {
  getProviderTinOrNpiSearch(providerCategoryId, providerTIN, providerNPI): Observable<any> {
    return of({ data: {
        v_prov_srch: [{prov_id: '667', providerTin: '345', addressLine: 'test', lst_nm: 'test', fst_nm: 'test',
                       bus_nm: 'facility', telcom_adr_id: '46', spcl_ref_dspl: 'vg', spcl_ref_id: '546',
                       prov_loc_affil_id: '8686'}]
      } });
  }
  
  getProviderAddressLine(adr1,adr2,ctynm,state,zip): Observable<any> {
    return of('test');
  }

  buildProviderData(provData): Observable<any> {
    const provResData = [{
      providerName : 'abcd',
      businessName: "bsu_nm",
      firstName: "fst_nm",
      lastName: "lst_nm",
      addressLine: "myAddress", 
      providerTin: 2342, 
      providerNpi: 2342,
      prov_id: 1234,
      phone: 8989898,
      specialty: "QWERTY",
      specialtyId: 123,
      locationAffiliationId: 8989889,
      providerAddressId: 9899898,
      providerMPIN: 2839,
      providerCategoryRefId: 12312,
    }];

    return of(provResData);
  }
  setProviderDetails(providerTelecomAddressId: string, providerSpecialtyRefId: string,
                     providerLocationAffiliationId: string, PROVIDER_ROLE_REF_ID: number, stepperData: any): Observable<any> {
    return of({hscduplicates: [{hsc_id: 123}]});
}
  getProviderNameSearch(providerCategoryId: number, providerFirstName: string, providerLastName: string, providerState: number,
                        providerZipCode: string, providerOrgName: string): Observable<any> {
    return of({data: {
      v_prov_srch: [{prov_id: '667', providerTin: '345', addressLine: 'test', lst_nm: 'test', fst_nm: 'test',
                     bus_nm: 'facility', telcom_adr_id: '46', spcl_ref_dspl: 'vg', spcl_ref_id: '546',
                     prov_loc_affil_id: '8686'}]
    }});
  }
  getProviderTinOrNpi(providerID: string, providerKeyTypeRefId: number): Observable<any> {
    return of({data: {
        prov_key: [{prov_key_val:'455'}]
      }});
  }
}

describe('ProviderLaunchComponentComponent', () => {
  let component: ProviderLaunchComponentComponent;
  let fixture: ComponentFixture<ProviderLaunchComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [uitkModules, uitkAngularModules, FormsModule, ReactiveFormsModule,
            HttpClientTestingModule,UITKRadioGroupModule],
      providers: [{ provide: ReferenceService, useClass: ReferenceMockService },
                  { provide: ProviderSearchService, useClass: ProviderSearchMockService }] ,
      declarations: [ ProviderLaunchComponentComponent ],
      schemas: [NO_ERRORS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProviderLaunchComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should select Name/State Radio Button for onRadioChangeForPhysician', () => {
      const radioid = {
        toElement: {
          defaultValue: 'NameStateZip'
        }
      };
      component.onRadioChangeForPhysician(radioid);
      expect(component.onRadioChangeForPhysician).toBeTruthy();
  });

  it('should select Tin/Npi Radio Button for onRadioChangeForPhysician', () => {
      const radioid = {
        toElement: {
          defaultValue: 'TinNpi'
        }
      };
      component.onRadioChangeForPhysician(radioid);
      expect(component.onRadioChangeForPhysician).toBeTruthy();
  });

  it('should select ZipSpec  Radio Button for onRadioChangeForPhysician', () => {
      const radioid = {
        toElement: {
          defaultValue: 'ZipSpec'
        }
      };
      component.onRadioChangeForPhysician(radioid);
      expect(component.onRadioChangeForPhysician).toBeTruthy();
  });

  it('should Clear all the forms', () => {
      component.clearForm();
      expect(component.clearForm).toBeTruthy();
  });

  it('should select provider Facility For Submitting Provider', () => {
     const selectedProv = {
  							addressLine: "1813 SE Port St Lucie Blvd, Port St Lucie, FL, 349525544",
  							businessName: "VISITING HOME HEALTH SERVICES, INC",
  							firstName: null,
  							lastName: "null, null",
  							locationAffiliationId: null,
  							phone: "7723371996",
  							prov_id: 4570365,
  							providerNpi: "1669428355",
  							providerTin: "810291933",
  							specialty: "251E00000X",
  							specialtyId: 16963,
  						}
     component.selectedProviderRecord(selectedProv);
     expect(component.selectedProviderRecord).toBeTruthy();
  });

  it('should select provider Physician For Submitting Provider', () => {
     const selectedProv = {
  							addressLine: "1813 SE Port St Lucie Blvd, Port St Lucie, FL, 349525544",
  							businessName: "VISITING HOME HEALTH SERVICES, INC",
  							firstName: "VISITING HOME HEALTH",
  							lastName: "VISITING HOME HEALTH SERVICES",
  							locationAffiliationId: null,
  							phone: "7723371996",
  							prov_id: 4570365,
  							providerNpi: "1669428355",
  							providerTin: "810291933",
  							specialty: "251E00000X",
  							specialtyId: 16963,
  						}
     component.selectedProviderRecord(selectedProv);
     expect(component.selectedProviderRecord).toBeTruthy();
  });

  /*it('should getProviderResultsData', () => {
      component.PHYSICIAN_CAT_ID = 16309;
      component.providerData = [{st_ref_id: 1072}, 'test2'];
      component.getProviderResultsData();
      expect(component.getProviderResultsData).toBeDefined();
  });*/

  it('should get Facility Search Name State Zip Results Data', () => {
      const radioid = {
        toElement: {
          defaultValue: 'NameStateZip'
        }
      };
      component.FacilityNameStateOrZipForm = new FormGroup({
            facilityProviderState: new FormControl({ id: 1111, label: 'Outpatient Facility', value: '3' }, Validators.required),
            facilityName: new FormControl('VISITING HOME', Validators.required),
            facilityProviderZipCode: new FormControl('373123713', Validators.required),
      });
      component.getFacilitySearchResultsData();
      expect(component.getFacilitySearchResultsData).toBeTruthy();
  });

  it('should get Facility Search Invalid Name State Zip Results Data', () => {
        component.getFacilitySearchResultsData();
        expect(component.getFacilitySearchResultsData).toBeTruthy();
  });

  it('should get Facility Search Tin/Npi Results Data', () => {
    const radioid = {
  	toElement: {
  	  defaultValue: 'TinNpi'
  	}
    };
    component.onRadioChangeForPhysician(radioid);
    component.FacilityTinOrNipForm.get('facilityProviderTIN').setValue({value: '810291933'});
    component.getFacilitySearchResultsData();
    expect(component.getFacilitySearchResultsData).toBeTruthy();
  });

  it('should get Facility Search Invalid Tin/Npi Results Data', () => {
    const radioid = {
  	toElement: {
  	  defaultValue: 'TinNpi'
  	}
    };
    component.onRadioChangeForPhysician(radioid);
    component.getFacilitySearchResultsData();
    expect(component.getFacilitySearchResultsData).toBeTruthy();
  });

  it('should get Facility Search Zip/Spec Results Data', () => {
    const radioid = {
  	toElement: {
  	  defaultValue: 'ZipSpec'
  	}
    };
    component.onRadioChangeForPhysician(radioid);
    component.FacilityZipSpecialtyForm = new FormGroup({
  		facilityProviderSpecialty: new FormControl('VISITING HOME', Validators.required),
  		facilityproviderZipCode: new FormControl('373123713', Validators.required),
    });
    component.getFacilitySearchResultsData();
    expect(component.getFacilitySearchResultsData).toBeTruthy();
  });

  it('should get Facility Search Invalid Zip/Spec Results Data', () => {
    const radioid = {
  	toElement: {
  	  defaultValue: 'ZipSpec'
  	}
    };
    component.onRadioChangeForPhysician(radioid);
    component.getFacilitySearchResultsData();
    expect(component.getFacilitySearchResultsData).toBeTruthy();
  });

  it('should get Physician Search Name State Zip Results Data', () => {
    const radioid = {
  	toElement: {
  	  defaultValue: 'NameStateZip'
  	}
    };
    component.nameStateOrZipForm = new FormGroup({
  		providerState: new FormControl({ id: 1102, label: 'Outpatient Facility', value: 'LA' }, Validators.required),
  		providerLastName: new FormControl('MEHLS', Validators.required),
  		providerZipCode: new FormControl('441141162', Validators.required),
  		providerFirstName: new FormControl('Elgibeth'),
    });
    component.getPhysicianSearchResultsData();
    expect(component.getPhysicianSearchResultsData).toBeTruthy();
  });

  it('should get Physician Search Invalid Name State Zip Results Data', () => {
  	component.getPhysicianSearchResultsData();
  	expect(component.getPhysicianSearchResultsData).toBeTruthy();
  });

  it('should get Physician Search Tin/Npi Results Data', () => {
  	const radioid = {
  		toElement: {
  		  defaultValue: 'TinNpi'
  	}
  	};
  	component.onRadioChangeForPhysician(radioid);
  	component.tinOrNipForm.get('providerNPI').setValue({value: '1619025723'});
  	component.getPhysicianSearchResultsData();
  	expect(component.getPhysicianSearchResultsData).toBeTruthy();
  });

  it('should get Physician Search Invalid Tin/Npi Results Data', () => {
  	const radioid = {
  		toElement: {
  		  defaultValue: 'TinNpi'
  	}
  	};
  	component.onRadioChangeForPhysician(radioid);
  	component.getPhysicianSearchResultsData();
  	expect(component.getPhysicianSearchResultsData).toBeTruthy();
  });

  it('should get Physician Search Zip/Spec Results Data', () => {
  	const radioid = {
  		toElement: {
  		  defaultValue: 'ZipSpec'
  		}
  	};
  	component.onRadioChangeForPhysician(radioid);
  	component.zipSpecialtyForm = new FormGroup({
  		providerSpecialty: new FormControl('VISITING HOME', Validators.required),
  		providerZipCode: new FormControl('373123713', Validators.required),
  	});
  	component.getPhysicianSearchResultsData();
  	expect(component.getPhysicianSearchResultsData).toBeTruthy();
  });

  it('should get Physician Search Invalid Zip/Spec Results Data', () => {
  	const radioid = {
  		toElement: {
  		  defaultValue: 'ZipSpec'
  	}
  	};
  	component.onRadioChangeForPhysician(radioid);
  	component.getPhysicianSearchResultsData();
  	expect(component.getPhysicianSearchResultsData).toBeTruthy();
  });


  it('should validate Facility  Tin/Npi Search', () => {
  	component.FacilityTinOrNipForm.get('facilityProviderTIN').setValue({value: '1619025723'});
  	component.validateFacilityTinNpiSearch();
  	expect(component.validateFacilityTinNpiSearch).toBeTruthy();
  });

  it('should validate Physician Tin Npi Search', () => {
  	component.tinOrNipForm.get('providerTIN').setValue({value: '1619025723'});
  	component.validatePhysicianTinNpiSearch();
  	expect(component.validatePhysicianTinNpiSearch).toBeTruthy();
  });
});
