import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { IUITKRadioGroupItem, UITKRadioGroupModule } from '@uitk/angular';
import {ProviderSearchService} from 'src/app/services/provider-search/provider-search.service';
import {StepperDataService} from 'src/app/services/StepperDataService/StepperDataService';
import {UserSessionService} from 'src/app/shared/services/user-session/user-session.service';
import {ReferenceService} from 'src/app/services/refernce-service/reference.service';
import {ProviderSearchComponent} from 'src/app/components/provider-search/provider-search.component';
import {ReferenceConstants} from 'src/app/constants/referenceConstants';

const PROVIDER_KEY_VALUE_TYP_REF_ID_NPI = 2782;
const PROVIDER_KEY_VALUE_TYP_REF_ID_TIN = 16333;
const PROVIDER_KEY_VALUE_TYP_REF_ID_MPIN = 2783;
const ErrorMessage = "Please fill the required fields.";

@Component({
  selector: 'um-provider-launch-component',
  templateUrl: './provider-launch-component.component.html',
  styleUrls: ['./provider-launch-component.component.scss']
})
export class ProviderLaunchComponentComponent implements OnInit {

  constructor(public providerSearchService: ProviderSearchService,private userSessionService: UserSessionService,
                    public stepperDataService: StepperDataService,public referenceService: ReferenceService) { }
  panelHeader1: string = 'Search for Physician';
  panelHeader2: string = 'Search for Facility';
  panelHeader3: string = 'My Favorites';
  myLabel: string = 'Search';
  myOptionLabel1: string = 'Name + State/Zip';
  myOptionLabel2: string = 'TIN and/or NPI';
  myOptionLabel3: string = 'Zip and Specialty';
  myOptionLabel4: string = 'miles';
  myOptionLabel5: string = 'killometers';
  myRadioGroupSelectionForSubmittingProvider: any;
  myRadioGroupSelectionForZipRadius: any;
  public selectedRadioForSubmittingProvider: any;
  public isNameStateRadioSelected = true;
  public isTinNpiRadioSelected = false;
  public isZipSpecRadioSelected = false;
  visibleRequired = false;
  public providerSelectionFlag = true;
  requiredErrorMessage: string;
  FACILITY_CAT_ID = 16310;
  PHYSICIAN_CAT_ID = 16309;
  providerTin = '';
  providerNpi = '';
  providerData = [];
  physicianResultsData: any[];
  facilityResultsData: any[];
  REFERENCE_STATE = 'stateCode';
  stateList = [];
  defaultLabel: string = 'Please Select';
  defaultLabelFlag: boolean = true;
  submittingProviderName: string;
  stepperData: any;
  private providerMPIN: any;

  profileForm = new FormGroup({
      radioGroup: new FormControl(''),
  });
    radiusForm = new FormGroup({
         radiusGroup: new FormControl(''),
    });

  radios: IUITKRadioGroupItem[] = [
      {
          label: 'Name + State/Zip',
          value: 'NameStateZip',
      },
      {
          label: 'TIN and/or NPI',
          value: 'TinNpi',
      },
      {
          label: 'Zip and Specialty',
          value: 'ZipSpec',
      },
  ];
  radius: IUITKRadioGroupItem[] = [
         {
              label: 'miles',
              value: 'miles',
          },
          {
              label: 'kilometers',
              value: 'kilometers',
          },
  ];

    public nameStateOrZipForm = new FormGroup({
        providerFirstName: new FormControl(''),
        providerLastName: new FormControl('', Validators.required),
        providerState: new FormControl('', Validators.required),
        providerZipCode: new FormControl('', Validators.required),
        providerZipRadius: new FormControl(''),
        providerSpecialty: new FormControl(''),
      });
    public tinOrNipForm = new FormGroup({
      providerTIN: new FormControl(''),
      providerNPI: new FormControl('')
    });
    public zipSpecialtyForm = new FormGroup({
        providerZipCode: new FormControl('', Validators.required),
        providerZipRadius: new FormControl(''),
        providerSpecialty: new FormControl('',Validators.required),
    });

    public FacilityNameStateOrZipForm = new FormGroup({
        facilityName: new FormControl('', Validators.required),
        facilityProviderState: new FormControl('', Validators.required),
        facilityProviderZipCode: new FormControl('', Validators.required),
        facilityProviderZipRadius: new FormControl(''),
        facilityProviderSpecialty: new FormControl(''),
      });
    public FacilityTinOrNipForm = new FormGroup({
      facilityProviderTIN: new FormControl(''),
      facilityProviderNPI: new FormControl('')
    });
    public FacilityZipSpecialtyForm = new FormGroup({
        facilityproviderZipCode: new FormControl('', Validators.required),
        facilityProviderZipRadius: new FormControl(''),
        facilityProviderSpecialty: new FormControl('',Validators.required),
    });

    columnsForFavProviders = [ 'Action','Name','Address','Phone','TIN','NPI','Specialty'];
    columnsForFacilitySearchTable = ['Name','Address','Phone','Speciality','TIN']

    favProvidersList = [
     {providerName: 'Anderson, Susan',addressLine:'click my name to select this Provider',Phone:'952-485-0198',TIN:'012345678',NPI:'8912345567',Specialty:'Oncology',type:'physician'},
     {providerName: 'Brooks, Robert',addressLine:'1322 N Elm Drive, Mesa, AZ 14235',Phone:'715-422-5945',TIN:'345678901',NPI:'8902453289',Specialty:'Family Medcine',type:'physician'},
     {providerName: 'McDonald, Richard',addressLine:'22635 Oak Drive, Tempe, AZ 00567',Phone:'952-906-1774',TIN:'901234567',NPI:'3459204833',Specialty:'Dermatology',type:'physician'},
     {providerName: 'Anderson, Mary',addressLine:'1663 N Main Drive, Mesa, AZ 14235',Phone:'715-422-5615',TIN:'345678901',NPI:'8902453289',Specialty:'Dermatology',type:'physician'},
     {providerName: 'Stewart, John',addressLine:'22635 Oak Drive, Tempe, AZ 00567',Phone:'952-916-1774',TIN:'901234567',NPI:'3459204833',Specialty:'Family Medicine',type:'physician'},
     {providerName: 'Phoenix General Hospital',addressLine:'1115 Quarry Rd, Tempe, AZ 00567',Phone:'952-485-0198',TIN:'012345678',NPI:'8912345567',Specialty:'Oncology',type:'facility'},
     {providerName: 'Mesa Vista Hospital',addressLine:'576 W Locust Lane, Mesa, AZ 14235',Phone:'715-422-5645',TIN:'345678901',NPI:'8902453289',Specialty:'Family Medicne',type:'facility'},
     {providerName: 'Mayo Clinic',addressLine:'97845 Iris Ln, Minnetonka, MN 55101',Phone:'952-926-1774',TIN:'901234567',NPI:'3459204833',Specialty:'Dermatology',type:'facility'},
    ];


  ngOnInit(): void {
    this.stepperDataService.sharedStepperData.subscribe((stepperData) => {
          this.stepperData = stepperData;
    });
    this.myRadioGroupSelectionForSubmittingProvider = this.radios[0];
    this.myRadioGroupSelectionForZipRadius = this.radius[0];
    this.getStateRefData();
  }

   onRadioChangeForPhysician(radioid) {
      this.selectedRadioForSubmittingProvider = radioid.value;
      if (this.selectedRadioForSubmittingProvider === 'NameStateZip') {
        this.isNameStateRadioSelected = true;
        this.isTinNpiRadioSelected = false;
        this.isZipSpecRadioSelected = false;
      } else if(this.selectedRadioForSubmittingProvider === 'TinNpi'){
        this.isNameStateRadioSelected = false;
        this.isTinNpiRadioSelected = true;
        this.isZipSpecRadioSelected = false;
      }else{
        this.isNameStateRadioSelected = false;
        this.isTinNpiRadioSelected = false;
        this.isZipSpecRadioSelected = true;
      }
   }

   clearForm(){
      this.nameStateOrZipForm.reset();
      this.tinOrNipForm.reset();
      this.zipSpecialtyForm.reset();
      this.FacilityNameStateOrZipForm.reset();
      this.FacilityTinOrNipForm.reset();
      this.FacilityZipSpecialtyForm.reset();
   }

   getFacilitySearchResultsData(){
        if(this.isNameStateRadioSelected == true){
           this.validateFacilityNameStateSearch();
        }else if (this.isTinNpiRadioSelected ==  true){
            this.validateFacilityTinNpiSearch();
        } else{
           this.validateFacilityZipSpecSearch();
        }
   }

   getPhysicianSearchResultsData(){
      if(this.isNameStateRadioSelected == true){
          this.validatePhysicianNameStateSearch();
      }else if (this.isTinNpiRadioSelected ==  true){
           this.validatePhysicianTinNpiSearch();
      }else{
          this.validatePhysicianZipSpecSearch();
      }
   }

   async getStateRefData(){
       const StateRefName = ReferenceConstants.STATE_REFNAME;;
             await this.referenceService.getReferenceDataForState(StateRefName).toPromise().then((res) => {
                  res.data.ref_set.forEach((item) => {
                      const stateObj = {
                            id: item.ref_id,
                            label: item.ref.ref_cd,
                            value: item.ref.ref_cd,
                      };
                      this.stateList.push(stateObj);
                  });

             }).catch((error) => { });
   }

   selectedProviderRecord(selectedProv: any){
      if(selectedProv.firstName === null){
            this.submittingProviderName = selectedProv.businessName;
            this.providerSelectionFlag = false;
            selectedProv.lastName = selectedProv.businessName;
      }
      else{
            this.submittingProviderName = selectedProv.lastName;
            this.providerSelectionFlag = false;
      }
      this.stepperDataService.setStepperData({...this.stepperData, submittingProviderDetails: selectedProv});
      console.log('Provider Data ' + JSON.stringify(this.stepperData));
   }

   validateFacilityNameStateSearch(){
        if (this.FacilityNameStateOrZipForm.valid) {
              this.providerSearchService.getProviderNameSearch(this.FACILITY_CAT_ID , null,null,
                      this.FacilityNameStateOrZipForm.controls.facilityProviderState.value.id,
                      this.FacilityNameStateOrZipForm.controls.facilityProviderZipCode.value ? this.FacilityNameStateOrZipForm.controls.facilityProviderZipCode.value  : null,
                      '%' + this.FacilityNameStateOrZipForm.controls.facilityName.value + '%', null)
                //specialty value need to be added as an argument after ui change here above
                .toPromise()
                .then(async (facilityRes) => {
                        this.providerData = facilityRes.data.v_prov_srch;
                        this.facilityResultsData = await this.providerSearchService.buildProviderData(this.providerData)
               });
        }else{
            this.visibleRequired = true;
            this.requiredErrorMessage = ErrorMessage;
        }
   }
   validateFacilityTinNpiSearch(){
        if (!this.FacilityTinOrNipForm.controls.facilityProviderTIN.value &&  !this.FacilityTinOrNipForm.controls.facilityProviderNPI.value) {
            this.visibleRequired = true;
            this.requiredErrorMessage = 'Please enter a TIN or NPI';
        } else {
           this.providerSearchService.getProviderTinOrNpiSearch(this.FACILITY_CAT_ID,
               this.FacilityTinOrNipForm.controls.facilityProviderTIN.value ? this.FacilityTinOrNipForm.controls.facilityProviderTIN.value : null,
               this.FacilityTinOrNipForm.controls.facilityProviderNPI.value ? this.FacilityTinOrNipForm.controls.facilityProviderNPI.value : null)
            .toPromise()
            .then(async (facilityResTin) => {
              this.providerData = facilityResTin.data.v_prov_srch;
              this.facilityResultsData = await this.providerSearchService.buildProviderData(this.providerData)
            });
        }
   }

   validateFacilityZipSpecSearch(){
        if (this.FacilityZipSpecialtyForm.valid) {

        }else{
           this.visibleRequired = true;
           this.requiredErrorMessage = ErrorMessage;
        }
   }

   validatePhysicianNameStateSearch(){
       if (this.nameStateOrZipForm.valid) {
           this.providerSearchService.getProviderNameSearch(this.PHYSICIAN_CAT_ID,
              this.nameStateOrZipForm.controls.providerFirstName.value ? this.nameStateOrZipForm.controls.providerFirstName.value : null,
              this.nameStateOrZipForm.controls.providerLastName.value,
              this.nameStateOrZipForm.controls.providerState.value.id,
              this.nameStateOrZipForm.controls.providerZipCode.value ? this.nameStateOrZipForm.controls.providerZipCode.value : null, null, null)
             //specialty value need to be added as an argument after ui change here above
             .toPromise()
              .then(async (res) => {
                this.providerData = res.data.v_prov_srch;
                this.physicianResultsData = await this.providerSearchService.buildProviderData(this.providerData)
           });
       }else{
          this.visibleRequired = true;
          this.requiredErrorMessage = ErrorMessage;
       }
   }

   validatePhysicianTinNpiSearch(){
       if (!this.tinOrNipForm.controls.providerTIN.value &&  !this.tinOrNipForm.controls.providerNPI.value) {
            this.visibleRequired = true;
            this.requiredErrorMessage = 'Please enter a TIN or NPI. ';
       } else {
            this.providerSearchService.getProviderTinOrNpiSearch(this.PHYSICIAN_CAT_ID,
              this.tinOrNipForm.controls.providerTIN.value ? this.tinOrNipForm.controls.providerTIN.value : null,
              this.tinOrNipForm.controls.providerNPI.value ? this.tinOrNipForm.controls.providerNPI.value : null)
                  .toPromise()
                  .then(async (resTin) => {
                    this.providerData = resTin.data.v_prov_srch;
                    this.physicianResultsData = await this.providerSearchService.buildProviderData(this.providerData)
            });
       }
   }

   validatePhysicianZipSpecSearch(){
       if (this.zipSpecialtyForm.valid) {

       }else{
          this.visibleRequired = true;
          this.requiredErrorMessage = ErrorMessage;
       }
   }

}
