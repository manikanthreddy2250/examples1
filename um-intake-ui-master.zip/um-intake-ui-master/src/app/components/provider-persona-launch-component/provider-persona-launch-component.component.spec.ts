import { ComponentFixture, TestBed } from '@angular/core/testing';
import { uitkAngularModules, uitkModules } from 'src/app/app.module';
import { ProviderPersonaLaunchComponentComponent } from './provider-persona-launch-component.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import {UserSessionService} from 'src/app/shared/services/user-session/user-session.service';
import { Injectable } from '@angular/core';
import { of, Observable } from 'rxjs';
import { Constants } from 'src/app/constants/constants';
import { ProviderSearchService } from 'src/app/services/provider-search/provider-search.service';


@Injectable()
class UserSessionMockService {

  getVarData() {
    const ecpClaims = {"x-ecp-attrs":{ "taxIds": "['256556261','641486019','352115451','344620678']"}}
    return {ecpClaims}
  }

  getUserPermission() {
    return Constants.UM_INTAKE_UI_USER_PERMISSION_CLINICIAN;
  }

  getEcpToken() {
    return 'ecpToken';
  }
  getFunctionalRole() {
    return 'functionalRole';
  }

  getLocalEcpToken() {
    return null;
  }

  getUserName() {
      return 'SYSTEM';
  }
  getUserOrg() {
    return 'ecp';
  }
}

@Injectable()
class ProviderSearchMockService {
  getProviderDetailsByTaxIDBulk(data:any){
    return of({data: { v_prov_srch: [{prov_id: '667', providerTin: '345', addressLine: 'test', lst_nm: 'test', fst_nm: 'test',
                     bus_nm: 'facility', telcom_adr_id: '46', spcl_ref_dspl: 'vg', spcl_ref_id: '546',
                     prov_loc_affil_id: '8686'}]
    }})
  }

  getProviderAddressLine(adr1,adr2,ctynm,state,zip): Observable<any> {
    return of('test');
  }
  
  buildProviderData(provData): Observable<any> {
    const provResData = [{
      providerName : 'abcd',
      businessName: "bsu_nm",
      firstName: "fst_nm",
      lastName: "lst_nm",
      addressLine: "myAddress", 
      providerTin: 2342, 
      providerNpi: 2342,
      prov_id: 1234,
      phone: 8989898,
      specialty: "QWERTY",
      specialtyId: 123,
      locationAffiliationId: 8989889,
      providerAddressId: 9899898,
      providerMPIN: 2839,
      providerCategoryRefId: 12312,
    }];

    return of(provResData);
  }
}

describe('ProviderPersonaLaunchComponentComponent', () => {
  let component: ProviderPersonaLaunchComponentComponent;
  let fixture: ComponentFixture<ProviderPersonaLaunchComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [uitkModules, uitkAngularModules, FormsModule, ReactiveFormsModule, HttpClientTestingModule],
      providers: [{ provide: UserSessionService, useClass: UserSessionMockService },ProviderSearchService],
      declarations: [ ProviderPersonaLaunchComponentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProviderPersonaLaunchComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should select provider For Submitting Provider', () => {
    const selectedProv = {
               addressLine: "1813 SE Port St Lucie Blvd, Port St Lucie, FL, 349525544",
               providerName: "VISITING HOME HEALTH SERVICES, INC",
               providerTin: "810291933",
               specialty: "251E00000X",
               specialtyId: 16963,
             }
    component.selectedProviderRecord(selectedProv);
    expect(component.selectedProviderRecord).toBeTruthy();
 });
  
});
