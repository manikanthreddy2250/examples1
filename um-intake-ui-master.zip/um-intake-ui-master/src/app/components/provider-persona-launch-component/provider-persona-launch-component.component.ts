import { Component, OnInit } from '@angular/core';
import {StepperDataService} from 'src/app/services/StepperDataService/StepperDataService';
import {UserSessionService} from 'src/app/shared/services/user-session/user-session.service';
import { ProviderSearchService } from 'src/app/services/provider-search/provider-search.service';
import { ReferenceConstants } from 'src/app/constants/referenceConstants';
import { data } from 'jquery';


@Component({
  selector: 'um-provider-persona-launch-component',
  templateUrl: './provider-persona-launch-component.component.html',
  styleUrls: ['./provider-persona-launch-component.component.scss']
})
export class ProviderPersonaLaunchComponentComponent implements OnInit {

  constructor(private userSessionService: UserSessionService,public providerSearchService: ProviderSearchService,
    public stepperDataService: StepperDataService) { }

    PROVIDER_TYPE_PHYSICIAN = ReferenceConstants.PHYSICIAN_CAT_ID;
    PROVIDER_TYPE_FACILITY = ReferenceConstants.FACILITY_CAT_ID;
    public panelContent: string = 'Hello!!';
    public panelHeader: string = 'My Current Provider:';
    public collapsiblePanel: boolean = true;
    public noRecordsFlag: boolean = true;
    public openPanel: boolean = false;
    submittingProviderName: string = null ;
    visibleTextValue: string = 'Loading, please wait...';
    stepperData: any;

    columnsForFavouritesTable = ['Provider Name','Address','Phone','TIN'];

    providersList = [];

  ngOnInit(): void {
    this.stepperDataService.sharedStepperData.subscribe((stepperData) => {
      this.stepperData = stepperData;
    });
    this.getProvidersData();
  }

  selectedProviderRecord(selectedProv: any){
    this.submittingProviderName = selectedProv.providerName;
    this.openPanel = false;
    this.stepperDataService.setStepperData({...this.stepperData, submittingProviderDetails: selectedProv});
  }

  async getProvidersData(){
    const ecpAttrs:any = this.userSessionService.getVarData().ecpClaims["x-ecp-attrs"];
    if(ecpAttrs.taxIds){
        const providerTaxIds:any = ecpAttrs.taxIds.slice(1,-1);
        const provTaxIdDetails = providerTaxIds.replace(/'/g, "");
        const provTaxIdArray = await provTaxIdDetails.split(",");
        const provDetails = await this.providerSearchService.getProviderDetailsByTaxIDBulk(provTaxIdArray);
        if(provDetails.data.v_prov_srch.length > 0){
          this.noRecordsFlag = true;
          this.providersList = await this.providerSearchService.buildProviderData(provDetails.data.v_prov_srch);
          if (this.providersList && this.providersList.length > 0) {
            this.selectedProviderRecord(this.providersList[0]);
          }
        }else{
          this.noRecordsFlag = false;
        }
    }else{
      this.noRecordsFlag = false;
      }
  }
}
