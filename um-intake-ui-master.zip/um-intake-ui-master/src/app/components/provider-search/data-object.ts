export interface IDataObject {
  getViewFields(): string[];

  getTableName(): string ;

}
