import {NO_ERRORS_SCHEMA} from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {uitkAngularModules, uitkModules} from '../../../app.module';

import { FavoriteProvidersTabComponent } from './favorite-providers-tab.component';

describe('FavoriteProvidersTabComponent', () => {
  let component: FavoriteProvidersTabComponent;
  let fixture: ComponentFixture<FavoriteProvidersTabComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [uitkModules, uitkAngularModules, FormsModule, ReactiveFormsModule],
      declarations: [ FavoriteProvidersTabComponent ],
      schemas: [NO_ERRORS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FavoriteProvidersTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should close pop up dialog box', () => {
    component.deleteDialogModal.show = false;
    component.closeDeleteDialog();
    expect(component.closeDeleteDialog).toBeTruthy();
  });

  it('should confirm Delete', () => {
    component.selectedFavoriteProviderRecord= {providerAddressId:123456};
    component.confirmDelete();
    expect(component.confirmDelete).toBeTruthy();
  });

  it('should confirm Delete', () => {
      const selectedFavoriteProviderRecord= {providerAddressId:123456};
      component.showDeleteDialog(selectedFavoriteProviderRecord);
      expect(component.showDeleteDialog).toBeTruthy();
  });
});
