import {Component, EventEmitter, Input, OnChanges, OnInit, SimpleChanges, Output} from '@angular/core';
import {UITKTableDataSource} from '@uitk/angular';
import {ReferenceConstants} from '../../../constants/referenceConstants';

@Component({
  selector: 'um-favorite-providers-tab',
  templateUrl: './favorite-providers-tab.component.html',
  styleUrls: ['./favorite-providers-tab.component.scss']
})
export class FavoriteProvidersTabComponent implements OnInit, OnChanges {
  deleteDialogModal = {
    show: false,
  };

  constructor() {
  }
  PROVIDER_TYPE_PHYSICIAN = ReferenceConstants.PHYSICIAN_CAT_ID;
  PROVIDER_TYPE_FACILITY = ReferenceConstants.FACILITY_CAT_ID;
  myFavoriteTableColumns: any = [
    {label: 'Action', id: 'action', dataType: 'text'},
    {label: 'Provider Name', id: 'providerName', dataType: 'text'},
    {label: 'Address', id: 'addressLine', dataType: 'text'},
    {label: 'Phone', id: 'phone', dataType: 'text'},
    {label: 'TIN', id: 'providerTin', dataType: 'text'},
    {label: 'NPI', id: 'providerNpi', dataType: 'text'},
    {label: 'Specialty', id: 'specialty', dataType: 'text'}
  ];
  myFavoritesDataSource = new UITKTableDataSource<any>([]);
  @Input()
  myFavProvidersList;
  @Output()
  deleteFavorite = new EventEmitter<any>();
  selectedFavoriteProviderRecord;
  ngOnInit(): void {
  }

  ngOnChanges(changes: SimpleChanges) {
    this.myFavoritesDataSource.data = changes['myFavProvidersList'].currentValue;
  }

  confirmDelete() {
    this.deleteFavorite.emit(this.selectedFavoriteProviderRecord.providerAddressId);
    this.closeDeleteDialog();
  }

  showDeleteDialog(selectedFavoriteProviderRecord) {
    this.selectedFavoriteProviderRecord = selectedFavoriteProviderRecord;
    this.deleteDialogModal.show = true;
  }

  closeDeleteDialog() {
    this.deleteDialogModal.show = false;
  }

}
