import { HttpClient, HttpHandler } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import {Injectable, NO_ERRORS_SCHEMA} from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators} from '@angular/forms';
import {FormFieldService} from '@uimf/uitk';
import {UITKRadioGroupModule} from '@uitk/angular';
import {BehaviorSubject, Observable, of} from 'rxjs';
import { uitkAngularModules, uitkModules } from 'src/app/app.module';
import {ProviderSearchService} from 'src/app/services/provider-search/provider-search.service';
import {StepperDataService} from 'src/app/services/StepperDataService/StepperDataService';
import {UserSessionService} from 'src/app/shared/services/user-session/user-session.service';
import {environment} from 'src/environments/environment';
import {EcpAuthTokenService} from '../../services/ecp-auth-token-service/ecp-auth-token.service';
import {ReferenceService} from '../../services/refernce-service/reference.service';
import {UserAttrService} from '../../services/user-attr-service/user-attr.service';
import {ProcedureComponent} from '../procedure/procedure.component';
import { ProviderSearchComponent } from './provider-search.component';

@Injectable()
class MockStepperDataService {
  isDistanceMatrixSearchAllowed = false;
  private stepperData = new BehaviorSubject({hsc:
                                          {
                                            hsc_id: 7448,
                                            auth_end_dt: null,
                                            auth_strt_dt: null,
                                            auth_typ_ref_id: null,
                                            cont_of_care_ind: null,
                                            indv_id: 503926748,
                                            mbr_cov_dtl: null,
                                            mbr_cov_id: 12484,
                                            rev_prr_ref_id: 3754,
                                            srvc_set_ref_id: 3738,
                                            hsc_sts_ref_id : 19274,

                                          },
                                             tenantId: 'ecpumintakebaseproductbpmgrp',
                                             serviceType: 'Generic',
                                             submittingProviderDetails:
                                                  {
                                                      addressLine: '1813 SE Port St Lucie Blvd, Port St Lucie, FL, 349525544',
                                                      businessName: 'VISITING HOME HEALTH SERVICES, INC',
                                                      firstName: null,
                                                      lastName: 'null, null',
                                                      locationAffiliationId: null,
                                                      phone: '7723371996',
                                                      prov_id: 4570365,
                                                      providerNpi: '1669428355',
                                                      providerTin: '810291933',
                                                      specialty: '251E00000X',
                                                      specialtyId: 16963,
                                                      providerAddressId: 123
                                                  },
                                             admittingProviderDetails:
                                              {
                                                addressLine: '1813 SE Port St Lucie Blvd, Port St Lucie, FL, 349525544',
                                                businessName: 'VISITING HOME HEALTH SERVICES, INC',
                                                firstName: null,
                                                lastName: 'null, null',
                                                locationAffiliationId: null,
                                                phone: '7723371996',
                                                prov_id: 4570365,
                                                providerNpi: '1669428355',
                                                providerTin: '810291933',
                                                specialty: '251E00000X',
                                                specialtyId: 16963,
                                                providerAddressId: 123
                                              },
                                             attendingProviderDetails:
                                              {
                                                addressLine: '1813 SE Port St Lucie Blvd, Port St Lucie, FL, 349525544',
                                                businessName: 'VISITING HOME HEALTH SERVICES, INC',
                                                firstName: null,
                                                lastName: 'null, null',
                                                locationAffiliationId: null,
                                                phone: '7723371996',
                                                prov_id: 4570365,
                                                providerNpi: '1669428355',
                                                providerTin: '810291933',
                                                specialty: '251E00000X',
                                                specialtyId: 16963,
                                                providerAddressId: 123
                                              },
                                             OrderingProviderDetails:
                                              {
                                                addressLine: '1813 SE Port St Lucie Blvd, Port St Lucie, FL, 349525544',
                                                businessName: 'VISITING HOME HEALTH SERVICES, INC',
                                                firstName: null,
                                                lastName: 'null, null',
                                                locationAffiliationId: null,
                                                phone: '7723371996',
                                                prov_id: 4570365,
                                                providerNpi: '1669428355',
                                                providerTin: '810291933',
                                                specialty: '251E00000X',
                                                specialtyId: 16963,
                                                providerAddressId: 123
                                              },
                                             facilityProviderDetails:
                                              {
                                                addressLine: '1813 SE Port St Lucie Blvd, Port St Lucie, FL, 349525544',
                                                businessName: 'VISITING HOME HEALTH SERVICES, INC',
                                                firstName: null,
                                                lastName: 'null, null',
                                                locationAffiliationId: null,
                                                phone: '7723371996',
                                                prov_id: 4570365,
                                                providerNpi: '1669428355',
                                                providerTin: '810291933',
                                                specialty: '251E00000X',
                                                specialtyId: 16963,
                                                providerAddressId: 123
                                              },
                                             ServicingProviderDetails:
                                              {
                                                addressLine: '1813 SE Port St Lucie Blvd, Port St Lucie, FL, 349525544',
                                                businessName: 'VISITING HOME HEALTH SERVICES, INC',
                                                firstName: null,
                                                lastName: 'null, null',
                                                locationAffiliationId: null,
                                                phone: '7723371996',
                                                prov_id: 4570365,
                                                providerNpi: '1669428355',
                                                providerTin: '810291933',
                                                specialty: '251E00000X',
                                                specialtyId: 16963,
                                                providerAddressId: 123
                                              }
                                              });
  sharedStepperData = this.stepperData.asObservable();

  constructor() { }

  setStepperData(stepperData: any) {
    this.stepperData.next(stepperData);
  }
}

@Injectable()
class UserSessionMockService {
  i = 0;
  getUserName() {
    if (this.i === 0) {
      this.i++;
      return 'breddy88';
    } else if (this.i === 1) {
      this.i = this.i + 2;
      return 'SYSTEM';
    } else if (this.i === 3)  {
      return 'abcd';
    }
  }
  getUserRoles() {
    return [{'role-name': 'provider'}];
  }

  getUserPermission() {
    return 'provider';
  }
  getUserOrg() {
    return 'ecp';
  }

  getEcpToken() {}
  getFunctionalRole() {}
}

@Injectable()
class MockHttpClient {
  post(url: string, body: any | null, options?: any) {
    switch (url) {
      case environment.HEALTH_SERVICE_API:
        return of({data: {ref: [{ref_cd: 34}]}});
      case environment.SAVE_AUTH_HTTP_FUNCTION_URL:
        return of({hscDuplicates: [{hsc_id: 123}]});
      case environment.INDIVIDUAL_API:
        return of({data: {v_indv_srch: [{}]}});
      case environment.MEMBERSHIP_API:
        return of({data: {mbr_cov: [{}]}});
      default:
        return of({});
    }
  }
}

@Injectable()
class ProviderSearchMockService {
  getProviderTinOrNpiSearch(providerCategoryId, providerTIN, providerNPI): Observable<any> {
    return of({ data: {
        v_prov_srch: [{prov_id: '667', providerTin: '345', addressLine: 'test', lst_nm: 'test', fst_nm: 'test',
                       bus_nm: 'facility', telcom_adr_id: '46', spcl_ref_dspl: 'vg', spcl_ref_id: '546',
                       prov_loc_affil_id: '8686'}]
      } });
  }
  getProviderAddressLine(adr1,adr2,ctynm,state,zip): Observable<any> {
    return of('test');
  }
  setProviderDetails(providerTelecomAddressId: string, providerSpecialtyRefId: string,
                     providerLocationAffiliationId: string, PROVIDER_ROLE_REF_ID: number, stepperData: any): Observable<any> {
    return of({hscduplicates: [{hsc_id: 123}]});
  }
  async buildProviderData(provData) {
    return [
      {
        businessName: null,
        firstName: 'Trent',
        lastName: 'Boult',
        addressLine: '401 6th Ave # 301, Parkville, NY, 08029',
        providerTin: '67306790',
        providerNpi: '12345679',
        prov_id: 10293944,
        phone: '9932293485',
        specialty: 'testabXYZ',
        specialtyId: 17078,
        locationAffiliationId: null,
        providerCategoryRefId: 16309,
        providerAddressId: 117451820,
        addressLine1: '401 6th Ave # 301',
        addressLine2: null,
        cityName: 'Parkville',
        zipCodeText: '08029'
      },
      {
        businessName: 'XYZ CORPORATION',
        firstName: null,
        lastName: null,
        addressLine: '2704 West Oxford Loop Ste 110, Oxford, MS, 386555728, Brooklyn, NY, 01234',
        providerTin: '98879811',
        providerNpi: '98768956',
        prov_id: 10112925,
        phone: '9932293485',
        specialty: 'testabXYZ',
        specialtyId: 17077,
        locationAffiliationId: null,
        providerCategoryRefId: 16310,
        providerAddressId: 117451820,
        addressLine1: '2704 West Oxford Loop Ste 110, Oxford, MS, 386555728',
        addressLine2: null,
        cityName: 'Brooklyn',
        zipCodeText: '01234'
      }
    ];
  }
  getProviderNameSearch(providerCategoryId: number, providerFirstName: string, providerLastName: string, providerState: number,
                        providerZipCode: string, providerOrgName: string): Observable<any> {
                          return of({ data: {
                            v_prov_srch: [{prov_id: '667', providerTin: '345', addressLine: 'test', lst_nm: 'test', fst_nm: 'test',
                                           bus_nm: 'facility', telcom_adr_id: '46', spcl_ref_dspl: 'vg', spcl_ref_id: '546',
                                           prov_loc_affil_id: '8686'}]
                          } });
  }
  getProviderTinOrNpi(providerID: string, providerKeyTypeRefId: number): Observable<any> {
    return of({data: {
        prov_key: [{prov_key_val: '455'}]
      }});
  }

  getProviderDetailsSearch(provId, provAdrId, provtelcomAdrId, ProvSpecialtyRefId): Observable<any> {
    return of({data: {
        v_prov_srch: [{st_ref_id: 172, prov_id: 125, adr_ln_1_txt: 'g', adr_ln_2_txt: 'r', cty_nm: 'test', zip_cd_txt: '645456',
                       spcl_ref_id: 437, }]
      }});
  }

  getProvidersZipCodeSearch(zipCodeText: string, providerCategoryReferenceID: number) {
    return of({
      data: {
        v_prov_srch: [
          {
            prov_id: 10112925,
            fst_nm: null,
            lst_nm: null,
            bus_nm: 'XYZ CORPORATION',
            adr_ln_1_txt: '2704 West Oxford Loop Ste 110, Oxford, MS, 386555728',
            adr_ln_2_txt: null,
            cty_nm: 'Brooklyn',
            st_ref_id: 1101,
            zip_cd_txt: '01234',
            prov_key_val: '98879811',
            prov_key_typ_ref_id: 18836,
            spcl_ref_id: 17077,
            telcom_adr_id: '7186380360',
            prov_loc_affil_id: null,
            prov_catgy_ref_id: 16310,
            prov_adr_id: 117451820
          },
          {
            prov_id: 10293944,
            fst_nm: 'Trent',
            lst_nm: 'Boult',
            bus_nm: null,
            adr_ln_1_txt: '401 6th Ave # 301',
            adr_ln_2_txt: null,
            cty_nm: 'Parkville',
            st_ref_id: 1101,
            zip_cd_txt: '08029',
            prov_key_val: '67306790',
            prov_key_typ_ref_id: 18836,
            spcl_ref_id: 17077,
            telcom_adr_id: '7186380360',
            prov_loc_affil_id: null,
            prov_catgy_ref_id: 16309,
            prov_adr_id: 117451820
          }
        ]
      }
    });
  }

  async getDistanceMatrixDataForProvider(distanceMatrixRProviderRequest, distanceMatrixToken) {
    return of({
      Providers: [{
        ProviderName: 'XYZ CORPORATION',
        ProviderType: 'Organization',
        npi: '98768956',
        tax_id_number: '98879811',
        ProviderAddress: {
          adr_ln_1_txt: '2704 West Oxford Loop Ste 110, Oxford, MS, 386555728',
          adr_ln_2_txt: null,
          cty_nm: 'Brooklyn',
          cnty_nm: 'Kings',
          st_nm: 'NY',
          zip_cd_txt: '01234',
          lat_deg: '42.3788',
          lng_deg: '-70.7865'
        },
        Distance: '10.8 mi',
        Time: '10 mins'
      },
        {
          ProviderName: 'Boult, Trent',
          ProviderType: 'Individual',
          npi: '12345679',
          tax_id_number: '67306790',
          ProviderAddress: {
            adr_ln_1_txt: '401 6th Ave # 301',
            adr_ln_2_txt: null,
            cty_nm: 'Parkville',
            cnty_nm: 'Kings',
            st_nm: 'NY',
            zip_cd_txt: '08029',
            lat_deg: '42.7867',
            lng_deg: '-74.6789'
          },
          Distance: '25.8 mi',
          Time: '40 mins'
        }]
    }).toPromise();
  }
}

@Injectable()
class MockUserAttrService {
  saveUserFavorite(favoriteTypeId, favoriteValue): Observable<any> {
    return of({data: {insert_user_fav: {affected_rows : 1}}});
  }

  getUserFavorites(favoriteTypeId, userId): Observable<any> {
    return of({data: {user_fav: [{user_fav_val : 123}]}});
  }

  deleteUserFavoriteProvider(favoriteTypeId, userId): Observable<any> {
    return of({data: {delete_user_fav: {affected_rows : 1}}});
  }

}

@Injectable()
class MockReferenceService {
  loadRefDataByRefID(stateRefId: number): Observable<any> {
    return of({data: {ref: [{ref_cd: 'NY'}]}});
  }
}

@Injectable()
class MockEcpAuthTokenService {
  getEcpToken() {
    return of({
      access_token: 'XYZ'
    });
  }
}

describe('ProviderSearchComponent', () => {
  let component: ProviderSearchComponent;
  let fixture: ComponentFixture<ProviderSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
	  imports: [UITKRadioGroupModule, uitkModules, uitkAngularModules, FormsModule, ReactiveFormsModule,
      HttpClientTestingModule],
	  providers: [HttpHandler, FormFieldService, ProcedureComponent,
    { provide: UserSessionService, useClass: UserSessionMockService },
      { provide: HttpClient, useClass: MockHttpClient },
      { provide: ProviderSearchService, useClass: ProviderSearchMockService },
      { provide: StepperDataService, useClass: MockStepperDataService },
      { provide: UserAttrService, useClass: MockUserAttrService },
      { provide: ReferenceService, useClass: MockReferenceService },
      { provide: EcpAuthTokenService, useClass: MockEcpAuthTokenService }
    ],
   declarations: [ ProviderSearchComponent ],
   schemas: [NO_ERRORS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProviderSearchComponent);
    component = fixture.componentInstance;
    component.hscObj = {hsc: [{hsc_id: 7448, auth_end_dt: null, auth_strt_dt: null, auth_typ_ref_id: null, cont_of_care_ind: null, indv_id: 503926748, mbr_cov_dtl: null, mbr_cov_id: 12484, rev_prr_ref_id: 3755, srvc_set_ref_id: 3738, flwup_cntc_dtl: {secondary_cntct: {department: 'Medical Records', email: 'test@optum.com', phone: '111-222-2222', fax: '111-222-3333', inac_ind: 1, role: 'Dentist', name: 'test'}, primary_cntct: {department: 'Utilization Review', email: 'vivek_srivadstava@optum.com', phone: '111-111-1111', fax: '111-222-2221', creat_dttm: '2020-10-28T07:00:52.957Z', chg_dttm: '2020-10-28T07:30:33.041Z', creat_user_id: 'SYSTEM', role: 'Nurseline', name: 'Vivek srivastava 1212'}}, hsc_keys: [{hsc_id: 7448, hsc_key_val: '25a3edda-0e43-11eb-a339-86406bb57ba2', inac_ind: 0, hsc_key_typ_ref_id: 19517}], hsc_diags: [{diag_cd: 'S83.116', inac_ind: 0, hsc_id: 7448, pri_ind: 0, hscDiagDiagCdRef: [{shrt_desc: 'ANT DISLOCATION PROX TIBIA UNS KNEE', full_desc: 'Anterior dislocation of proximal end of tibia, unspecified knee', cd_desc: 'ANTERIOR DISLOCATION PROXIMAL END TIBIA UNS KNEE'}]}, {diag_cd: 'S80.242D', inac_ind: 0, hsc_id: 7448, pri_ind: 1, hscDiagDiagCdRef: [{shrt_desc: 'EXTERNAL CONSTRICTION LT KNEE SBSQT', full_desc: 'External constriction, left knee, subsequent encounter', cd_desc: 'EXTERNAL CONSTRICTION LT KNEE SUBSEQUENT ENCNTR'}]}], hsc_provs: [{hsc_id: 7448, hsc_prov_id: 254, prov_loc_affil_id: 5, spcl_ref_id: 17048, telcom_adr_id: '4326392664', hsc_prov_roles: [{hsc_prov_id: 254, prov_role_ref_id: 3766}]}, {hsc_id: 7448, hsc_prov_id: 311, prov_loc_affil_id: 7, spcl_ref_id: 16696, telcom_adr_id: '3044429999', hsc_prov_roles: [{hsc_prov_id: 311, prov_role_ref_id: 3760}]}], hsc_facls: [{hsc_id: 7448, actul_admis_dttm: '2020-10-11T00:00:00', actul_dschrg_dttm: '2020-10-13T00:00:00', expt_admis_dt: '2020-10-11', expt_dschrg_dt: '2020-10-17', plsrv_ref_id: 3743, srvc_desc_ref_id: 4347, srvc_dtl_ref_id: 4296}], hsr_notes: [{hsr_note_id: 368, note_titl_txt: 'Test Notes', note_txt_lobj: 'adding draft note ', creat_user_id: '000844947', note_typ_ref_id: 11, src_user_nm: 'Provider', creat_dttm: '2020-10-14T17:39:39.457', hsr_note_sbjs: [{note_sbj_typ_ref_id: 12, note_sbj_rec_id: 'rec_id', inac_ind: 0, hsr_note_id: 368, chg_sys_ref_id: null, creat_dttm: '2020-10-14T17:39:39.457', creat_sys_ref_id: null, creat_user_id: null, chg_user_id: null}]}, {hsr_note_id: 460, note_titl_txt: 'test', note_txt_lobj: 'feeee', creat_user_id: 'SYSTEM', note_typ_ref_id: 11, src_user_nm: 'Provider', creat_dttm: '2020-10-22T10:20:59.423', hsr_note_sbjs: [{note_sbj_typ_ref_id: 12, note_sbj_rec_id: 'rec_id', inac_ind: 0, hsr_note_id: 460, chg_sys_ref_id: null, creat_dttm: '2020-10-22T10:20:59.423', creat_sys_ref_id: null, creat_user_id: null, chg_user_id: null}]}, {hsr_note_id: 474, note_titl_txt: 'test', note_txt_lobj: 'aaaaaaaaaa', creat_user_id: 'SYSTEM', note_typ_ref_id: 11, src_user_nm: 'Provider', creat_dttm: '2020-10-26T10:14:22.875', hsr_note_sbjs: [{note_sbj_typ_ref_id: 12, note_sbj_rec_id: 'rec_id', inac_ind: 0, hsr_note_id: 474, chg_sys_ref_id: null, creat_dttm: '2020-10-26T10:14:22.875', creat_sys_ref_id: null, creat_user_id: null, chg_user_id: null}]}, {hsr_note_id: 475, note_titl_txt: 'test2', note_txt_lobj: 'aaaaaddddd', creat_user_id: 'SYSTEM', note_typ_ref_id: 11, src_user_nm: 'Provider', creat_dttm: '2020-10-26T10:15:03.078', hsr_note_sbjs: [{note_sbj_typ_ref_id: 12, note_sbj_rec_id: 'rec_id', inac_ind: 0, hsr_note_id: 475, chg_sys_ref_id: null, creat_dttm: '2020-10-26T10:15:03.078', creat_sys_ref_id: null, creat_user_id: null, chg_user_id: null}]}]}]};
    fixture.detectChanges();
  });

  afterEach(() => {
    fixture.destroy();
  });

  afterAll(() => {
    TestBed.resetTestingModule();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should getFacilityProviderDataOnTinOrNpi', () => {
  	  component.getFacilityProviderDataOnTinOrNpi();
     expect(component.getFacilityProviderDataOnTinOrNpi).toBeDefined();
  });

  it('should getPhysicianProviderDataOnTinOrNpi', () => {
    component.tinOrNipform = new FormGroup({
      providerTIN: new FormControl(''),
      providerNPI: new FormControl('')
    });
    component.getPhysicianProviderDataOnTinOrNpi();
    expect(component.getPhysicianProviderDataOnTinOrNpi).toBeDefined();
  });

  it('should getFacilityProviderData', () => {
    	component.getFacilityProviderData();
     expect(component.getFacilityProviderData).toBeDefined();
  });

  it('should getFacilityProviderData for valid form', () => {
    component.facilityNameStateOrZipform.controls['facilityState'].setValue('CA');
    component.facilityNameStateOrZipform.controls['providerOrgName'].setValue('RIVERSIDE');
    component.facilityNameStateOrZipform.controls['facilityZipCode'].setValue('06001');
    component.getFacilityProviderData();
    expect(component.getFacilityProviderData).toBeDefined();
  });

 // it('should getPhysicianProviderDataOnTinOrNpi', () => {
 //     component.tinOrNipform.controls['providerTIN'].setValue('3566');
 //     const providerSearchService = TestBed.get(ProviderSearchService)
 //     const spy = spyOn(providerSearchService, 'getProviderTinOrNpiSearch')
 //    component.getPhysicianProviderDataOnTinOrNpi();
 //    expect(component.getPhysicianProviderDataOnTinOrNpi).toBeDefined();
 //     expect(spy).toHaveBeenCalled();
 //  });

  it('should getPhysicianProviderData', () => {
    spyOn(component, 'getPhysicianProviderData').and.callThrough();
    component.getPhysicianProviderData();
  	 expect(component.invalidFormSubmitted).toBeDefined();
    expect(component.getPhysicianProviderData).toBeDefined();

  });

  it('should getPhysicianProviderData for valid form', () => {
    component.nameStateOrZipform.controls['providerLastName'].setValue('Attia');
    component.nameStateOrZipform.controls['providerFirstName'].setValue('Fadia');
    component.nameStateOrZipform.controls['providerState'].setValue('CA');
    component.nameStateOrZipform.controls['providerZipCode'].setValue('06001');

    component.getPhysicianProviderData();
    expect(component.invalidFormSubmitted).toBeDefined();
    expect(component.getPhysicianProviderData).toBeDefined();

  });

  it('should onSwitchTab', () => {
  	  component.onSwitchTab(1);
     expect(component.onSwitchTab).toBeTruthy();
  });

  it('should clear filter for Physician', () => {
    const event = {
      event: 'ON_CLEAR_ALL_FILTERS'
    };
    component.conditionChangedForPhysician(event);
    component.conditionChangedForPhysician('ON_COLUMN_FILTER');
    expect(component.conditionChangedForPhysician).toBeDefined();
  });

  it('should filter condition changed for Physician', () => {
    const event = {
      event: 'ON_COLUMN_FILTER',
      filterCondition: {
        filterColumns: [
          { Name: 'lastName' }
        ]
      }
    };
    component.conditionChangedForPhysician(event);
    component.conditionChangedForPhysician('ON_COLUMN_FILTER');
    expect(component.conditionChangedForPhysician).toBeDefined();
  });

  it('should clear filter for Facility', () => {
    const event = {
      event: 'ON_CLEAR_ALL_FILTERS'
    };
    component.conditionChangedForFacility(event);
    component.conditionChangedForPhysician('ON_COLUMN_FILTER');
    expect(component.conditionChangedForFacility).toBeDefined();
  });

  it('should filter condition changed for Facility', () => {
    const event = {
      event: 'ON_COLUMN_FILTER',
      filterCondition: {
        filterColumns: [
          { Name: 'lastName' }
        ]
      }
    };
    component.conditionChangedForFacility(event);
    component.conditionChangedForPhysician('ON_COLUMN_FILTER');
    expect(component.conditionChangedForFacility).toBeDefined();
  });

  it('should clear', () => {
    component.onClear();
    expect(component.onClear).toBeTruthy();
  });

  it('should select provider for admitting role', () => {
    component.stepperData = {hsc: {hsc_id: 123 }, hscFacl: {hsc_id: 123 }, hscSrvcNonFacl: {hsc_id: 123 }};
    component.providerSelectedForAdmittingProvider(1);
    expect(component.providerSelectedForAdmittingProvider).toBeTruthy();
  });

  it('should select provider for attending role', () => {
    component.stepperData = {hsc: {hsc_id: 123 }, hscFacl: {hsc_id: 123 }, hscSrvcNonFacl: {hsc_id: 123 }};
    component.providerSelectedForAttendingProvider(1);
    expect(component.providerSelectedForAttendingProvider).toBeTruthy();
  });

  it('should select provider for ordering role', () => {
    component.stepperData = {hsc: {hsc_id: 123 }, hscFacl: {hsc_id: 123 }, hscSrvcNonFacl: {hsc_id: 123 }};
    component.providerSelectedForOrderingProvider(1);
    expect(component.providerSelectedForOrderingProvider).toBeTruthy();
  });

  it('should select provider for case table for facility', () => {
    component.stepperData = {hsc: {hsc_id: 123 }, hscFacl: {hsc_id: 123 }, hscSrvcNonFacl: {hsc_id: 123 }};
    component.providerSelectedFromCaseTableforFacility(1);
    expect(component.providerSelectedFromCaseTableforFacility).toBeTruthy();
  });

  it('should select provider for case table for admitting', () => {
    component.stepperData = {hsc: {hsc_id: 123 }, hscFacl: {hsc_id: 123 }, hscSrvcNonFacl: {hsc_id: 123 }};
    component.providerSelectedFromCaseTableForAdmittingProvider(1);
    expect(component.providerSelectedFromCaseTableForAdmittingProvider).toBeTruthy();
  });

  it('should select provider for case table for attending', () => {
    component.stepperData = {hsc: {hsc_id: 123 }, hscFacl: {hsc_id: 123 }, hscSrvcNonFacl: {hsc_id: 123 }};
    component.providerSelectedFromCaseTableForAttendingProvider(1);
    expect(component.providerSelectedFromCaseTableForAttendingProvider).toBeTruthy();
  });

  it('should select provider for case table for ordering', () => {
    component.stepperData = {hsc: {hsc_id: 123 }, hscFacl: {hsc_id: 123 }, hscSrvcNonFacl: {hsc_id: 123 }};
    component.providerSelectedFromCaseTableForOrderingProvider(1);
    expect(component.providerSelectedFromCaseTableForOrderingProvider).toBeTruthy();
  });

  it('should select provider for case table for servicing', () => {
    component.stepperData = {hsc: {hsc_id: 123 }, hscFacl: {hsc_id: 123 }, hscSrvcNonFacl: {hsc_id: 123 }, hscProcedures: [{hsc_srvc_id: 123 }]};
    let servicingProviderSelected = {adr_ln_1_txt: '401 6th Ave # 301',
                                     adr_ln_2_txt: null,
                                     bus_nm: null,
                                     cty_nm: 'Montgomery',
                                     fst_nm: 'AMOR',
                                     lst_nm: 'RAMIREZ',
                                     prov_catgy_ref_id: 16309,
                                     prov_id: 125,
                                     prov_key_typ_ref_id: 2782,
                                     prov_key_val: '1699732990',
                                     prov_loc_affil_id: 7,
                                     spcl_ref_id: 16696,
                                     st_ref_id: 1119,
                                     telcom_adr_id: '3044429999',
                                     zip_cd_txt: '251362116',
                                     spcl_ref_dspl: '208000000X'};
    component.setServicingProvider(servicingProviderSelected);
    expect(component.setServicingProvider).toBeTruthy();
  });

  it('should select provider for case to map procedure', () => {
    component.stepperData = {hsc: {hsc_id: 123}, hscFacl: {hsc_id: 123}, hscSrvcNonFacl: {hsc_id: 123}};

    const insert_hsc_prov_one = [{
      hsc_id: 7448,
      hsc_prov_id: 254,
      prov_loc_affil_id: 5,
      spcl_ref_id: 17048,
      telcom_adr_id: '4326392664',
      hsc_prov_roles: [{
        hsc_prov_id: 254,
        prov_role_ref_id: 3766
      }]
    }, {
      hsc_id: 7448,
      hsc_prov_id: 311,
      prov_loc_affil_id: 7,
      spcl_ref_id: 16696,
      telcom_adr_id: '3044429999',
      hsc_prov_roles: [{
        hsc_prov_id: 311,
        prov_role_ref_id: 3760
      }]
    }];
    let data = [insert_hsc_prov_one];
    component.mapCaseLevelSrvcProvToSrvcLines(data);
    expect(component.mapCaseLevelSrvcProvToSrvcLines).toBeTruthy();
  });

  it('toggle open panel', () => {
    component.toggleOpenPanel();
    expect(component.toggleOpenPanel).toBeTruthy();
  });

  it('should select provider for case table for ordering', () => {
    const radioid = {
      toElement: {
        defaultValue: 'NameStateZip'
      }
    };
    component.onRadioChangeForOrderingProvider(radioid);
    expect(component.onRadioChangeForOrderingProvider).toBeTruthy();
  });

  it('should select provider for case table for attending', () => {
    const radioid = {
      toElement: {
        defaultValue: 'NameStateZip'
      }
    };
    component.onRadioChangeForAttendingProvider(radioid);
    expect(component.onRadioChangeForAttendingProvider).toBeTruthy();
  });

  it('should select provider for case table for admitting', () => {
    const radioid = {
      toElement: {
        defaultValue: 'NameStateZip'
      }
    };
    component.onRadioChangeForAdmittingProvider(radioid);
    expect(component.onRadioChangeForAdmittingProvider).toBeTruthy();
  });

  it('should select provider for case table for facility', () => {
    const radioid = {
      toElement: {
        defaultValue: 'NameStateZip'
      }
    };
    component.onRadioChangeForFacility(radioid);
    expect(component.onRadioChangeForFacility).toBeTruthy();
  });

  it('should select provider for facility', () => {
    component.stepperData = {hsc: {hsc_id: 123 }, hscFacl: {hsc_id: 123 }, hscSrvcNonFacl: {hsc_id: 123 }};
    const radioid = {
      toElement: {
        defaultValue: 'NameStateZip'
      }
    };
    component.providerSelectedForFacility(radioid);
    expect(component.providerSelectedForFacility).toBeTruthy();
  });

  it('should getSubmittingProviderDetails', () => {
    component.getSubmittingProviderDetails();
    expect(component.getSubmittingProviderDetails).toBeTruthy();
  });

  it('should getSubmittingProviderDetails 2', () => {
    component.getSubmittingProviderDetails();
    expect(component.getSubmittingProviderDetails).toBeTruthy();
  });

  it('should getSubmittingProviderDetails 3', () => {
    component.getSubmittingProviderDetails();
    expect(component.getSubmittingProviderDetails).toBeTruthy();
  });

  it('should populate State drop down to default member state', () => {
    component.referenceData = [{id: 0, label: 'AA', value: 'AA', refId: 1059}];
    component.memberStateId = 1059;
    component.populateMemberState();
    expect(component.populateMemberState).toBeDefined();
  });

  it('should buildProviderResultsDraftData', () => {
    let hsc_prov = [{
        hsc_id: 7448,
        hsc_prov_id: 254,
        prov_loc_affil_id: 5,
        spcl_ref_id: 17048,
        telcom_adr_id: '4326392664',
        hsc_prov_roles: [{
          hsc_prov_id: 254,
          prov_role_ref_id: 3766
        }]
      }, {
        hsc_id: 7448,
        hsc_prov_id: 311,
        prov_loc_affil_id: 7,
        spcl_ref_id: 16696,
        telcom_adr_id: '3044429999',
        hsc_prov_roles: [{
          hsc_prov_id: 311,
          prov_role_ref_id: 3760
        }]
      }];
    expect(component.buildProviderResultsDraftData).toBeTruthy();
    if (hsc_prov !== null) {
      component.mapProviderDraftData(hsc_prov, 12345);
    }
  });
  it('should buildProviderResultsDraftData', () => {
    let provDraftData = {
      adr_ln_1_txt: '401 6th Ave # 301',
      adr_ln_2_txt: null,
      bus_nm: null,
      cty_nm: 'Montgomery',
      fst_nm: 'AMOR',
      lst_nm: 'RAMIREZ',
      prov_catgy_ref_id: 16309,
      prov_id: 125,
      prov_key_typ_ref_id: 2782,
      prov_key_val: '1699732990',
      prov_loc_affil_id: 7,
      spcl_ref_id: 16696,
      st_ref_id: 1119,
      telcom_adr_id: '3044429999',
      zip_cd_txt: '251362116',
      spcl_ref_dspl: '208000000X'
    };
    let providerState = 'WV';
    component.mapProviderDraftData(provDraftData, 12345);
    expect(component.mapProviderDraftData).toBeTruthy();
  });

  it('should mapSelectedProvider', () => {
     let provDraftData = {
       adr_ln_1_txt: '401 6th Ave # 301',
       adr_ln_2_txt: null,
       bus_nm: null,
       cty_nm: 'Montgomery',
       fst_nm: 'AMOR',
       lst_nm: 'RAMIREZ',
       prov_catgy_ref_id: 16309,
       prov_id: 125,
       prov_key_typ_ref_id: 2782,
       prov_key_val: '1699732990',
       prov_loc_affil_id: 7,
       spcl_ref_id: 16696,
       st_ref_id: 1119,
       telcom_adr_id: '3044429999',
       zip_cd_txt: '251362116',
       spcl_ref_dspl: '208000000X'
     };
     const addressLine = 'Address 12345 ';
     const  providerTin = provDraftData.prov_key_val;
     let providerDetails = {
       businessName: provDraftData.bus_nm,
       firstName: provDraftData.fst_nm,
       lastName: provDraftData.lst_nm + ', ' + provDraftData.fst_nm,
       addressLine, providerTin,
       prov_id: provDraftData.prov_id,
       phone: provDraftData.telcom_adr_id,
       specialty: provDraftData.spcl_ref_dspl,
       specialtyId: provDraftData.spcl_ref_id,
       locationAffiliationId: provDraftData.prov_loc_affil_id
     };
     let providerState = 'WV';
     component.mapSelectedProvider(providerDetails, 3758);
     component.mapSelectedProvider(providerDetails, 3759);
     component.mapSelectedProvider(providerDetails, 3760);
     component.mapSelectedProvider(providerDetails, 3765);
     expect(component.mapSelectedProvider).toBeTruthy();
   });

  it('should select provider For Submitting Provider', () => {
       component.stepperData = {hsc: {hsc_id: 123, hsc_sts_ref_id : 19274 }, hscFacl: {hsc_id: 123 }, hscSrvcNonFacl: {hsc_id: 123 }};
       component.providerSelectedForSubmittingProvider(1);
       expect(component.providerSelectedForSubmittingProvider).toBeTruthy();
   });

  it('should add to favorites on Ordering Provider heart hollow icon click', () => {
    component.myFavoriteProvidersAdrList = [];
    component.myFavoriteProvidersList = [];
    component.onOrderingFavoriteChange();
    expect(component.myFavoriteProvidersAdrList.length).toEqual(1);
    expect(component.myFavoriteProvidersList.length).toEqual(1);
  });

  it('should add to favorites on Submitting Provider heart hollow icon click', () => {
    component.myFavoriteProvidersAdrList = [];
    component.myFavoriteProvidersList = [];
    component.onSubmittingFavoriteChange();
    expect(component.myFavoriteProvidersAdrList.length).toEqual(1);
    expect(component.myFavoriteProvidersList.length).toEqual(1);
  });

  it('should add to favorites on Facility Provider heart hollow icon click', () => {
    component.myFavoriteProvidersAdrList = [];
    component.myFavoriteProvidersList = [];
    component.onFacilityFavoriteChange();
    expect(component.myFavoriteProvidersAdrList.length).toEqual(1);
    expect(component.myFavoriteProvidersList.length).toEqual(1);
  });

  it('should add to favorites on Admitting Provider heart hollow icon click', () => {
    component.myFavoriteProvidersAdrList = [];
    component.myFavoriteProvidersList = [];
    component.onAdmittingFavoriteChange();
    expect(component.myFavoriteProvidersAdrList.length).toEqual(1);
    expect(component.myFavoriteProvidersList.length).toEqual(1);
  });

  it('should add to favorites on Attending Provider heart hollow icon click', () => {
    component.myFavoriteProvidersAdrList = [];
    component.myFavoriteProvidersList = [];
    component.onAttendingFavoriteChange();
    expect(component.myFavoriteProvidersAdrList.length).toEqual(1);
    expect(component.myFavoriteProvidersList.length).toEqual(1);
  });

  it('should add to favorites on Servicing Provider heart hollow icon click', () => {
    component.myFavoriteProvidersAdrList = [];
    component.myFavoriteProvidersList = [];
    component.onServicingFavoriteChange();
    expect(component.myFavoriteProvidersAdrList.length).toEqual(1);
    expect(component.myFavoriteProvidersList.length).toEqual(1);
  });

  it('should call edit change on panel collapse false', () => {
    component.collapsiblePanel6 = false;
    component.onOrderingProviderEditChange();
    expect(component.onOrderingProviderEditChange).toBeTruthy();
  });

  it('should call edit change on panel collapse true', () => {
    component.collapsiblePanel6 = true;
    component.onOrderingProviderEditChange();
    expect(component.onOrderingProviderEditChange).toBeTruthy();
  });

  it('should editRow', () => {
    component.editRow();
    expect(component.isEditProviderEnabled).toBeTruthy();
  });

  it('closeRow should collapse the row', () => {
    component.closeRow();
    expect(component.isEditProviderEnabled).toBeFalsy();
  });

  it('should setProviderAffilDetailJson', () => {
    component.setProviderAffilDetailJson({providerNpi: '656'});
    expect(component.setProviderAffilDetailJson).toBeTruthy();
  });

  it('should delete from favorites on Ordering Provider heart filled icon click', () => {
    const spy =  spyOn(component, 'showDeleteDialog');
    component.myFavoriteProvidersAdrList = [123];
    component.myFavoriteProvidersList = [{
        providerType: 16310,
        providerName: 'NORTH MISSISSIPPI MEDICAL CENTER',
        address: '2704 West Oxford Loop Ste 110, Oxford, MS, 386555728',
        phone: '2285751735',
        specialty: '2084P0800X',
        npi: '1710081369',
        tin: '288158608',
        providerAddressId: 123
      }];
    component.onOrderingFavoriteChange();
    expect(spy).toHaveBeenCalled();
  });

  it('should delete from favorites on Submitting Provider heart filled icon click', () => {
    const spy =  spyOn(component, 'showDeleteDialog');
    component.myFavoriteProvidersAdrList = [123];
    component.myFavoriteProvidersList = [{
      providerType: 16310,
      providerName: 'NORTH MISSISSIPPI MEDICAL CENTER',
      address: '2704 West Oxford Loop Ste 110, Oxford, MS, 386555728',
      phone: '2285751735',
      specialty: '2084P0800X',
      npi: '1710081369',
      tin: '288158608',
      providerAddressId: 123
    }];
    component.onSubmittingFavoriteChange();
    expect(spy).toHaveBeenCalled();
  });

  it('should delete from favorites on Facility Provider heart filled icon click', () => {
    const spy =  spyOn(component, 'showDeleteDialog');
    component.myFavoriteProvidersAdrList = [123];
    component.myFavoriteProvidersList = [{
      providerType: 16310,
      providerName: 'NORTH MISSISSIPPI MEDICAL CENTER',
      address: '2704 West Oxford Loop Ste 110, Oxford, MS, 386555728',
      phone: '2285751735',
      specialty: '2084P0800X',
      npi: '1710081369',
      tin: '288158608',
      providerAddressId: 123
    }];
    component.onFacilityFavoriteChange();
    expect(spy).toHaveBeenCalled();
  });

  it('should delete from favorites on Admitting Provider heart filled icon click', () => {
    const spy =  spyOn(component, 'showDeleteDialog');
    component.myFavoriteProvidersAdrList = [123];
    component.myFavoriteProvidersList = [{
      providerType: 16310,
      providerName: 'NORTH MISSISSIPPI MEDICAL CENTER',
      address: '2704 West Oxford Loop Ste 110, Oxford, MS, 386555728',
      phone: '2285751735',
      specialty: '2084P0800X',
      npi: '1710081369',
      tin: '288158608',
      providerAddressId: 123
    }];
    component.onAdmittingFavoriteChange();
    expect(spy).toHaveBeenCalled();
  });

  it('should delete from favorites on Attending Provider heart filled icon click', () => {
    const spy =  spyOn(component, 'showDeleteDialog');
    component.myFavoriteProvidersAdrList = [123];
    component.myFavoriteProvidersList = [{
      providerType: 16310,
      providerName: 'NORTH MISSISSIPPI MEDICAL CENTER',
      address: '2704 West Oxford Loop Ste 110, Oxford, MS, 386555728',
      phone: '2285751735',
      specialty: '2084P0800X',
      npi: '1710081369',
      tin: '288158608',
      providerAddressId: 123
    }];
    component.onAttendingFavoriteChange();
    expect(spy).toHaveBeenCalled();
  });

  it('should delete from favorites on Servicing Provider heart filled icon click', () => {
    const spy =  spyOn(component, 'showDeleteDialog');
    component.myFavoriteProvidersAdrList = [123];
    component.myFavoriteProvidersList = [{
      providerType: 16310,
      providerName: 'NORTH MISSISSIPPI MEDICAL CENTER',
      address: '2704 West Oxford Loop Ste 110, Oxford, MS, 386555728',
      phone: '2285751735',
      specialty: '2084P0800X',
      npi: '1710081369',
      tin: '288158608',
      providerAddressId: 123
    }];
    component.onServicingFavoriteChange();
    expect(spy).toHaveBeenCalled();
  });

  it('should close pop up dialog box', () => {
    component.deleteDialogModal.show = false;
    component.closeDeleteDialog();
    expect(component.closeDeleteDialog).toBeTruthy();
  });

  it('should open pop up dialog box', () => {
    component.deleteDialogModal.show = false;
    component.closeDeleteDialog();
    expect(component.closeDeleteDialog).toBeTruthy();
  });

  it('should populateDefaultProvidersOnPageLoad', () => {
    component.stepperData = {
      memberinf: [{
        adr_ln_1_txt: 'z street, xy',
        cty_nm: 'Brooklyn',
        zip_cd_txt: '112171604',
        st_ref_id: 1101
      }],
      flowType: 'new'
    };
    component.isDistanceMatrixSearchAllowed = true;
    component.populateDefaultProvidersOnPageLoad();
    expect(component.populateDefaultProvidersOnPageLoad).toBeTruthy();
    component.isDistanceMatrixSearchAllowed = false;
    component.populateDefaultProvidersOnPageLoad();
    expect(component.populateDefaultProvidersOnPageLoad).toBeTruthy();
    component.isDistanceMatrixSearchAllowed = true;
    component.stepperData = {
      flowType: null
    };
    component.populateDefaultProvidersOnPageLoad();
    expect(component.populateDefaultProvidersOnPageLoad).toBeTruthy();
  });

  it('should filterDistanceMatrixProviders', () => {
    const provider1 = {
      ProviderName: 'Holmes, Sherlock',
      ProviderType: 'Individual',
      Distance: '22.1 mi',
      Time: '22 min',
      ProviderAddress: {adr_ln_1_txt: '221-B Baker Street', adr_ln_2_txt: null, cty_nm: 'London', cnty_nm: 'County', st_nm: 'NY', zip_cd_txt: '123Xyz', lat_deg: '123.4', lng_deg: '405.3'}
    };
    const provider2 = {
      ProviderName: 'Holmes, Sherlock',
      ProviderType: 'Individual',
      Distance: '22.1 mi',
      Time: '22 min',
      ProviderAddress: {adr_ln_1_txt: '221-B Baker Street', adr_ln_2_txt: null, cty_nm: 'London', cnty_nm: 'County', st_nm: 'NY', zip_cd_txt: '123Xyz', lat_deg: '123.4', lng_deg: '405.3'}
    };
    const provider3 = {
      ProviderName: 'St Abc Hospital',
      ProviderType: 'Organization',
      Distance: '10.1 mi',
      Time: '25 min',
      ProviderAddress: {adr_ln_1_txt: '456 Jump  Street', adr_ln_2_txt: null, cty_nm: 'London', cnty_nm: 'County', st_nm: 'NY', zip_cd_txt: '456Xyz', lat_deg: '123.4', lng_deg: '405.3'}
    };
    const providerDataList = [provider1, provider2, provider3];
    const expectedProviderDataList = [provider1, provider3];
    expect(component.filterDistanceMatrixProviders(providerDataList)).toEqual(expectedProviderDataList);
    expect(component.filterDistanceMatrixProviders(expectedProviderDataList)).toEqual(expectedProviderDataList);
  });

  it('should checkProviderExistenceInDistanceMatrix', () => {
    const provider1 = {
      firstName: null,
      lastName: null,
      businessName: 'St Abc Hospital',
      addressLine1: '456 Jump  Street',
      addressLine2: null,
      cityName: 'London',
      zipCodeText: '456Xyz',
      providerTin: '74928382',
      providerNpi: '87654908'
    };
    const provider2 = {
      firstName: null,
      lastName: null,
      businessName: 'XYZ CORPORATION',
      addressLine1: '2704 West Oxford Loop Ste 110, Oxford, MS, 386555728',
      addressLine2: null,
      cityName: 'Brooklyn',
      zipCodeText: '01234',
      providerTin: '98879811',
      providerNpi: '98768956'
    };
    const distanceMatrixProviderList = [
      {
        ProviderName: 'XYZ CORPORATION',
        ProviderType: 'Organization',
        npi: '98768956',
        tax_id_number: '98879811',
        ProviderAddress: {
          adr_ln_1_txt: '2704 West Oxford Loop Ste 110, Oxford, MS, 386555728',
          adr_ln_2_txt: null,
          cty_nm: 'Brooklyn',
          cnty_nm: 'Kings',
          st_nm: 'NY',
          zip_cd_txt: '01234',
          lat_deg: '42.3788',
          lng_deg: '-70.7865'
        },
        Distance: '10.8 mi',
        Time: '10 mins'
      }
    ];
    expect(component.checkProviderExistenceInDistanceMatrix(provider1, distanceMatrixProviderList)).toBe(-1);
    expect(component.checkProviderExistenceInDistanceMatrix(provider2, distanceMatrixProviderList)).toBe(0);
    expect(component.checkProviderExistenceInDistanceMatrix(null, distanceMatrixProviderList)).toBe(-1);
  });

  it('should setDistanceMatrixParamsInProvider', () => {
    const provider1 = {fst_nm: 'Sherlock', lst_nm: 'Holmes', bus_nm: null, adr_ln_1_txt: '221-B Baker Street', adr_ln_2_txt: null, cty_nm: 'London', zip_cd_txt: '123Xyz'};
    const provider2 = {fst_nm: null, lst_nm: null, bus_nm: 'St Xyz Hospital', adr_ln_1_txt: '496 Jump  Street', adr_ln_2_txt: null, cty_nm: 'London', zip_cd_txt: '456Xyz'};
    const dMProvider1 = {
      ProviderName: 'Holmes, Sherlock',
      ProviderType: 'Individual',
      Distance: '22.1 mi',
      Time: '22 min',
      ProviderAddress: {adr_ln_1_txt: '221-B Baker Street', adr_ln_2_txt: null, cty_nm: 'London', cnty_nm: 'County', st_nm: 'NY', zip_cd_txt: '123Xyz', lat_deg: '123.4', lng_deg: '405.3'}
    };
    const dMProvider2 = {
      ProviderName: 'St Abc Hospital',
      ProviderType: 'Organization',
      Distance: '10.1 mi',
      Time: '25 min',
      ProviderAddress: {adr_ln_1_txt: '456 Jump  Street', adr_ln_2_txt: null, cty_nm: 'London', cnty_nm: 'County', st_nm: 'NY', zip_cd_txt: '456Xyz', lat_deg: '123.4', lng_deg: '405.3'}
    };
    const distanceMatrixProviderList = [dMProvider1, dMProvider2];
    component.setDistanceMatrixParamsInProvider(provider1, distanceMatrixProviderList, 0);
    expect(component.setDistanceMatrixParamsInProvider).toBeTruthy();
    component.setDistanceMatrixParamsInProvider(provider2, distanceMatrixProviderList, -1);
    expect(component.setDistanceMatrixParamsInProvider).toBeTruthy();
  });

  it('should setDistMatrixParamsByMbrAdrAndProvSpcl', async () => {
    const providerDataList: any = [
      {
        businessName: 'XYZ CORPORATION',
        firstName: null,
        lastName: null,
        addressLine: '2704 West Oxford Loop Ste 110, Oxford, MS, 386555728, Brooklyn, NY, 01234',
        providerTin: '98879811',
        providerNpi: '98768956',
        prov_id: 10112925,
        phone: '9932293485',
        specialty: 'testabXYZ',
        specialtyId: 17077,
        locationAffiliationId: null,
        providerCategoryRefId: 16310,
        providerAddressId: 117451820,
        addressLine1: '2704 West Oxford Loop Ste 110, Oxford, MS, 386555728',
        addressLine2: null,
        cityName: 'Brooklyn',
        zipCodeText: '01234'
      },
      {
        businessName: null,
        firstName: 'Trent',
        lastName: 'Boult',
        addressLine: '401 6th Ave # 301, Parkville, NY, 08029',
        providerTin: '67306790',
        providerNpi: '12345679',
        prov_id: 10293944,
        phone: '9932293485',
        specialty: 'testabXYZ',
        specialtyId: 17077,
        locationAffiliationId: null,
        providerCategoryRefId: 16309,
        providerAddressId: 117451820,
        addressLine1: '401 6th Ave # 301',
        addressLine2: null,
        cityName: 'Parkville',
        zipCodeText: '08029'
      }
    ];
    const form = {controls: {
      providerZipRadius: {value: '20'},
      providerZipRadiusUnits: {value: {label: 'miles', value: 'miles'}}
    }};
    expect(await component.setDistMatrixParamsByMbrAdrAndProvSpcl(providerDataList, form)).toEqual(providerDataList);
    component.stepperData = {
      memberinf: [{
        adr_ln_1_txt: 'z street, xy',
        cty_nm: 'Brooklyn',
        zip_cd_txt: '112171604',
        st_ref_id: 1101
      }],
      flowType: 'new'
    };
    component.isDistanceMatrixSearchAllowed = true;
    const responseObject: any = [providerDataList[0], providerDataList[1]];
    responseObject[0].distance = '10.8 mi';
    responseObject[0].time = '10 mins';
    responseObject[1].distance = '25.8 mi';
    responseObject[1].time = '40 mins';
    expect(await component.setDistMatrixParamsByMbrAdrAndProvSpcl(providerDataList, form)).toEqual(responseObject);
    component.isDistanceMatrixSearchAllowed = false;
    expect(await component.setDistMatrixParamsByMbrAdrAndProvSpcl(providerDataList, form)).toEqual(providerDataList);
  });

  it('should setServicingProviderColumnsByAuthorizationType if isDistanceMatrixSearchAllowed', () => {
    const columnsForServicingProviderPhysicianTable = [
      {label: 'Name', id: 'providerName', dataType: 'text'},
      {label: 'Address', id: 'addressLine', dataType: 'text'},
      {label: 'Phone', id: 'phone', dataType: 'text'},
      {label: 'Specialty', id: 'specialty', dataType: 'text'},
      {label: 'TIN', id: 'providerTin', dataType: 'text'},
      {label: 'NPI', id: 'providerNpi', dataType: 'text'},
      {label: 'Distance', id: 'distance', dataType: 'text'},
      {label: 'Time', id: 'time', dataType: 'text'}
    ];

    // For Tab1 -> Select from Case Tab
    const columnsForSelectedServicingProviderTable = [
      {label: 'Name', id: 'providerName', dataType: 'text'},
      {label: 'Address', id: 'addressLine', dataType: 'text'},
      {label: 'Phone', id: 'phone', dataType: 'text'},
      {label: 'Specialty', id: 'specialty', dataType: 'text'},
      {label: 'TIN', id: 'providerTin', dataType: 'text'},
      {label: 'NPI', id: 'providerNpi', dataType: 'text'},
      {label: 'Distance', id: 'distance', dataType: 'text'},
      {label: 'Time', id: 'time', dataType: 'text'}
    ];

    // For Tab2 -> Search for Facility Tab
    const columnsForServicingProviderFacilityTable = [
      {label: 'Name', id: 'providerName', dataType: 'text'},
      {label: 'Address', id: 'addressLine', dataType: 'text'},
      {label: 'Phone', id: 'phone', dataType: 'text'},
      {label: 'Specialty', id: 'specialty', dataType: 'text'},
      {label: 'TIN', id: 'providerTin', dataType: 'text'},
      {label: 'NPI', id: 'providerNpi', dataType: 'text'},
      {label: 'Distance', id: 'distance', dataType: 'text'},
      {label: 'Time', id: 'time', dataType: 'text'}
    ];
    component.isDistanceMatrixSearchAllowed = true;
    component.setServicingProviderColumnsByAuthorizationType();
    expect(component.columnsForServicingProviderPhysicianTable).toEqual(columnsForServicingProviderPhysicianTable);
    expect(component.columnsForSelectedServicingProviderTable).toEqual(columnsForSelectedServicingProviderTable);
    expect(component.columnsForServicingProviderFacilityTable).toEqual(columnsForServicingProviderFacilityTable);
  });

  it('should setServicingProviderColumnsByAuthorizationType if not isDistanceMatrixSearchAllowed', () => {
    const columnsForServicingProviderPhysicianTable = [
      {label: 'Name', id: 'providerName', dataType: 'text'},
      {label: 'Address', id: 'addressLine', dataType: 'text'},
      {label: 'Phone', id: 'phone', dataType: 'text'},
      {label: 'Specialty', id: 'specialty', dataType: 'text'},
      {label: 'TIN', id: 'providerTin', dataType: 'text'},
      {label: 'NPI', id: 'providerNpi', dataType: 'text'}
    ];

    // For Tab1 -> Select from Case Tab
    const columnsForSelectedServicingProviderTable = [
      {label: 'Name', id: 'providerName', dataType: 'text'},
      {label: 'Address', id: 'addressLine', dataType: 'text'},
      {label: 'Phone', id: 'phone', dataType: 'text'},
      {label: 'Specialty', id: 'specialty', dataType: 'text'},
      {label: 'TIN', id: 'providerTin', dataType: 'text'},
      {label: 'NPI', id: 'providerNpi', dataType: 'text'}
    ];

    // For Tab2 -> Search for Facility Tab
    const columnsForServicingProviderFacilityTable = [
      {label: 'Name', id: 'providerName', dataType: 'text'},
      {label: 'Address', id: 'addressLine', dataType: 'text'},
      {label: 'Phone', id: 'phone', dataType: 'text'},
      {label: 'Specialty', id: 'specialty', dataType: 'text'},
      {label: 'TIN', id: 'providerTin', dataType: 'text'},
      {label: 'NPI', id: 'providerNpi', dataType: 'text'}
    ];
    component.isDistanceMatrixSearchAllowed = false;
    component.setServicingProviderColumnsByAuthorizationType();
    expect(component.columnsForServicingProviderPhysicianTable).toEqual(columnsForServicingProviderPhysicianTable);
    expect(component.columnsForSelectedServicingProviderTable).toEqual(columnsForSelectedServicingProviderTable);
    expect(component.columnsForServicingProviderFacilityTable).toEqual(columnsForServicingProviderFacilityTable);
  });

  it('should getDistanceMatrixProviderLists', async () => {
    const providerDataList: any = [
      {
        businessName: 'XYZ CORPORATION',
        firstName: null,
        lastName: null,
        addressLine: '2704 West Oxford Loop Ste 110, Oxford, MS, 386555728, Brooklyn, NY, 01234',
        providerTin: '98879811',
        providerNpi: '98768956',
        prov_id: 10112925,
        phone: '9932293485',
        specialty: 'testabXYZ',
        specialtyId: 17077,
        locationAffiliationId: null,
        providerCategoryRefId: 16310,
        providerAddressId: 117451820,
        addressLine1: '2704 West Oxford Loop Ste 110, Oxford, MS, 386555728',
        addressLine2: null,
        cityName: 'Brooklyn',
        zipCodeText: '01234'
      },
      {
        businessName: null,
        firstName: 'Trent',
        lastName: 'Boult',
        addressLine: '401 6th Ave # 301, Parkville, NY, 08029',
        providerTin: '67306790',
        providerNpi: '12345679',
        prov_id: 10293944,
        phone: '9932293485',
        specialty: 'testabXYZ',
        specialtyId: 17077,
        locationAffiliationId: null,
        providerCategoryRefId: 16309,
        providerAddressId: 117451820,
        addressLine1: '401 6th Ave # 301',
        addressLine2: null,
        cityName: 'Parkville',
        zipCodeText: '08029'
      }
    ];

    const distanceMatrixResponseList = [
      [
        {
          ProviderName: 'Boult, Trent',
          ProviderType: 'Individual',
          npi: '12345679',
          tax_id_number: '67306790',
          ProviderAddress: {
            adr_ln_1_txt: '401 6th Ave # 301',
            adr_ln_2_txt: null,
            cty_nm: 'Parkville',
            cnty_nm: 'Kings',
            st_nm: 'NY',
            zip_cd_txt: '08029',
            lat_deg: '42.7867',
            lng_deg: '-74.6789'
          },
          Distance: '25.8 mi',
          Time: '40 mins'
        }
      ],
      [
        {
          ProviderName: 'XYZ CORPORATION',
          ProviderType: 'Organization',
          npi: '98768956',
          tax_id_number: '98879811',
          ProviderAddress: {
            adr_ln_1_txt: '2704 West Oxford Loop Ste 110, Oxford, MS, 386555728',
            adr_ln_2_txt: null,
            cty_nm: 'Brooklyn',
            cnty_nm: 'Kings',
            st_nm: 'NY',
            zip_cd_txt: '01234',
            lat_deg: '42.3788',
            lng_deg: '-70.7865'
          },
          Distance: '10.8 mi',
          Time: '10 mins'
        }
      ]
    ];
    const response = await component.getDistanceMatrixProviderLists(
      {adr_ln_1_txt: 'z street, xy', cty_nm: 'Brooklyn', zip_cd_txt: '112171604', st_nm: 'NY'},
      providerDataList,
      {radius: '20', radius_uom: 'miles'});
    expect(response).toEqual(distanceMatrixResponseList);
  });

  it('should getMemberAddressInfo', async () => {
    expect(await component.getMemberAddressInfo()).toEqual(null);
    component.stepperData = {
      memberinf: [{
        adr_ln_1_txt: 'z street, xy',
        cty_nm: 'Brooklyn',
        zip_cd_txt: '112171604',
        st_ref_id: 1101
      }],
      flowType: 'new'
    };
    expect(await component.getMemberAddressInfo()).toEqual(({
      adr_ln_1_txt: 'z street, xy',
      cty_nm: 'Brooklyn',
      zip_cd_txt: '112171604',
      st_nm: 'NY'
    }));

    component.stepperData = {
      hsc: {
        indv_adr: [{
          adr_ln_1_txt: 'z street, xy',
          cty_nm: 'Brooklyn',
          zip_cd_txt: '112171604',
          st_ref_id: 1101
        }]
      },
      flowType: 'edit'
    };
    expect(await component.getMemberAddressInfo()).toEqual(({
      adr_ln_1_txt: 'z street, xy',
      cty_nm: 'Brooklyn',
      zip_cd_txt: '112171604',
      st_nm: 'NY'
    }));
  });

  it('should prepareDistMatrixResponseLists', () => {
    const distanceMatrixResponseList = [
      {Providers: [{
          ProviderName: 'XYZ CORPORATION',
          ProviderType: 'Organization',
          npi: '98768956',
          tax_id_number: '98879811',
          ProviderAddress: {
            adr_ln_1_txt: '2704 West Oxford Loop Ste 110, Oxford, MS, 386555728',
            adr_ln_2_txt: null,
            cty_nm: 'Brooklyn',
            cnty_nm: 'Kings',
            st_nm: 'NY',
            zip_cd_txt: '01234',
            lat_deg: '42.3788',
            lng_deg: '-70.7865'
          },
          Distance: '10.8 mi',
          Time: '10 mins'
        },
          {
            ProviderName: 'Boult, Trent',
            ProviderType: 'Individual',
            npi: '12345679',
            tax_id_number: '67306790',
            ProviderAddress: {
              adr_ln_1_txt: '401 6th Ave # 301',
              adr_ln_2_txt: null,
              cty_nm: 'Parkville',
              cnty_nm: 'Kings',
              st_nm: 'NY',
              zip_cd_txt: '08029',
              lat_deg: '42.7867',
              lng_deg: '-74.6789'
            },
            Distance: '25.8 mi',
            Time: '40 mins'
          }]},
      {Providers: [{
          ProviderName: 'XYZ CORPORATION',
          ProviderType: 'Organization',
          npi: '98768956',
          tax_id_number: '98879811',
          ProviderAddress: {
            adr_ln_1_txt: '2704 West Oxford Loop Ste 110, Oxford, MS, 386555728',
            adr_ln_2_txt: null,
            cty_nm: 'Brooklyn',
            cnty_nm: 'Kings',
            st_nm: 'NY',
            zip_cd_txt: '01234',
            lat_deg: '42.3788',
            lng_deg: '-70.7865'
          },
          Distance: '10.8 mi',
          Time: '10 mins'
        }]}];

    const response = [
      [
        {
          ProviderName: 'Boult, Trent',
          ProviderType: 'Individual',
          npi: '12345679',
          tax_id_number: '67306790',
          ProviderAddress: {
            adr_ln_1_txt: '401 6th Ave # 301',
            adr_ln_2_txt: null,
            cty_nm: 'Parkville',
            cnty_nm: 'Kings',
            st_nm: 'NY',
            zip_cd_txt: '08029',
            lat_deg: '42.7867',
            lng_deg: '-74.6789'
          },
          Distance: '25.8 mi',
          Time: '40 mins'
        }
      ],
      [
        {
          ProviderName: 'XYZ CORPORATION',
          ProviderType: 'Organization',
          npi: '98768956',
          tax_id_number: '98879811',
          ProviderAddress: {
            adr_ln_1_txt: '2704 West Oxford Loop Ste 110, Oxford, MS, 386555728',
            adr_ln_2_txt: null,
            cty_nm: 'Brooklyn',
            cnty_nm: 'Kings',
            st_nm: 'NY',
            zip_cd_txt: '01234',
            lat_deg: '42.3788',
            lng_deg: '-70.7865'
          },
          Distance: '10.8 mi',
          Time: '10 mins'
        }
      ]
    ];

    expect(component.prepareDistMatrixResponseLists(distanceMatrixResponseList)).toEqual(response);
    expect(component.prepareDistMatrixResponseLists([[]])).toEqual([[], []]);
  });

  it('should setDistanceMatrixDataForProviders', () => {
    const providerDataList: any = [
      {
        businessName: null,
        firstName: 'Trent',
        lastName: 'Boult',
        addressLine: '401 6th Ave # 301, Parkville, NY, 08029',
        providerTin: '67306790',
        providerNpi: '12345679',
        prov_id: 10293944,
        phone: '9932293485',
        specialty: 'testabXYZ',
        specialtyId: 17077,
        locationAffiliationId: null,
        providerCategoryRefId: 16309,
        providerAddressId: 117451820,
        addressLine1: '401 6th Ave # 301',
        addressLine2: null,
        cityName: 'Parkville',
        zipCodeText: '08029'
      },
      {
        businessName: 'XYZ CORPORATION',
        firstName: null,
        lastName: null,
        addressLine: '2704 West Oxford Loop Ste 110, Oxford, MS, 386555728, Brooklyn, NY, 01234',
        providerTin: '98879811',
        providerNpi: '98768956',
        prov_id: 10112925,
        phone: '9932293485',
        specialty: 'testabXYZ',
        specialtyId: 17077,
        locationAffiliationId: null,
        providerCategoryRefId: 16310,
        providerAddressId: 117451820,
        addressLine1: '2704 West Oxford Loop Ste 110, Oxford, MS, 386555728',
        addressLine2: null,
        cityName: 'Brooklyn',
        zipCodeText: '01234'
      }
    ];
    const distanceMatrixResponse = [
      [
        {
          ProviderName: 'Boult, Trent',
          ProviderType: 'Individual',
          npi: '12345679',
          tax_id_number: '67306790',
          ProviderAddress: {
            adr_ln_1_txt: '401 6th Ave # 301',
            adr_ln_2_txt: null,
            cty_nm: 'Parkville',
            cnty_nm: 'Kings',
            st_nm: 'NY',
            zip_cd_txt: '08029',
            lat_deg: '42.7867',
            lng_deg: '-74.6789'
          },
          Distance: '25.8 mi',
          Time: '40 mins'
        }
      ],
      [
        {
          ProviderName: 'XYZ CORPORATION',
          ProviderType: 'Organization',
          npi: '98768956',
          tax_id_number: '98879811',
          ProviderAddress: {
            adr_ln_1_txt: '2704 West Oxford Loop Ste 110, Oxford, MS, 386555728',
            adr_ln_2_txt: null,
            cty_nm: 'Brooklyn',
            cnty_nm: 'Kings',
            st_nm: 'NY',
            zip_cd_txt: '01234',
            lat_deg: '42.3788',
            lng_deg: '-70.7865'
          },
          Distance: '10.8 mi',
          Time: '10 mins'
        }
      ]
    ];
    component.setDistanceMatrixDataForProviders(providerDataList, distanceMatrixResponse);
    expect(providerDataList[0].distance).toBe('10.8 mi');
    expect(providerDataList[0].time).toBe('10 mins');
    expect(providerDataList[1].distance).toBe('25.8 mi');
    expect(providerDataList[1].time).toBe('40 mins');
  });

  it('should resolveDistanceMatrixRadiusSearchParams', () => {
    expect(component.resolveDistanceMatrixRadiusSearchParams(null)).toEqual({
      radius: '2',
      radius_uom: 'miles'
    });
  });

  it('should resolveDistanceMatrixRadiusSearchParams', () => {
    expect(component.resolveDistanceMatrixRadiusSearchParams(null)).toEqual({
      radius: '2',
      radius_uom: 'miles'
    });
  });

  it('should get Facility Provider Data On Tin Or Npi', () => {
  	component.facilityTinOrNipform.get('facilityTIN').setValue({value: '1619025723'});
  	component.getFacilityProviderDataOnTinOrNpi();
  	expect(component.getFacilityProviderDataOnTinOrNpi).toBeTruthy();
  });

  it('should get Physician Provider Data On Tin Or Npi', () => {
  	component.tinOrNipform.get('providerTIN').setValue({value: '1619025723'});
  	component.getPhysicianProviderDataOnTinOrNpi();
  	expect(component.getPhysicianProviderDataOnTinOrNpi).toBeTruthy();
  });

  it('should setPermissionForDistanceMatrixSearch', () => {
    const serviceTypeList = ['Cardiology', 'Radiology', 'Radiology and Cardiology', 'Generic', 'Behavioral'];
    const result = [true, true, true, false, false];
    serviceTypeList.forEach((serviceType, index) => {
      component.stepperData = {
        serviceType
      };
      component.isDistanceMatrixSearchAllowed = false;
      component.setPermissionForDistanceMatrixSearch();
      expect(component.isDistanceMatrixSearchAllowed).toBe(result[index]);
    });
  });

  it('should getDistanceMatrixData', async () => {
    const providerDataList: any = [
      {
        businessName: 'XYZ CORPORATION',
        firstName: null,
        lastName: null,
        addressLine: '2704 West Oxford Loop Ste 110, Oxford, MS, 386555728, Brooklyn, NY, 01234',
        providerTin: '98879811',
        providerNpi: '98768956',
        prov_id: 10112925,
        phone: '9932293485',
        specialty: 'testabXYZ',
        specialtyId: 17077,
        locationAffiliationId: null,
        providerCategoryRefId: 16310,
        providerAddressId: 117451820,
        addressLine1: '2704 West Oxford Loop Ste 110, Oxford, MS, 386555728',
        addressLine2: null,
        cityName: 'Brooklyn',
        zipCodeText: '01234',
      },
      {
        businessName: null,
        firstName: 'Trent',
        lastName: 'Boult',
        addressLine: '401 6th Ave # 301, Parkville, NY, 08029',
        providerTin: '67306790',
        providerNpi: '12345679',
        prov_id: 10293944,
        phone: '9932293485',
        specialty: 'testabXYZ',
        specialtyId: 17078,
        locationAffiliationId: null,
        providerCategoryRefId: 16309,
        providerAddressId: 117451820,
        addressLine1: '401 6th Ave # 301',
        addressLine2: null,
        cityName: 'Parkville',
        zipCodeText: '08029',
      },
    ];
    const distanceMatrixProviderRequest = {
      adr_ln_1_txt: 'Address Line 1',
      cty_nm: 'City',
      st_nm: 'ST',
      zip_cd_txt: '12345',
      prov_spcl_cd: '',
      radius: 2,
      radius_uom: 'miles'
    };
    const distanceMatrixToken = {
      access_token: '1234567890Abcd'
    };
    const distanceMatrixResponseList = [
      {
        Providers: [{
          ProviderName: 'XYZ CORPORATION',
          ProviderType: 'Organization',
          npi: '98768956',
          tax_id_number: '98879811',
          ProviderAddress: {
            adr_ln_1_txt: '2704 West Oxford Loop Ste 110, Oxford, MS, 386555728',
            adr_ln_2_txt: null,
            cty_nm: 'Brooklyn',
            cnty_nm: 'Kings',
            st_nm: 'NY',
            zip_cd_txt: '01234',
            lat_deg: '42.3788',
            lng_deg: '-70.7865'
          },
          Distance: '10.8 mi',
          Time: '10 mins'
        },
          {
            ProviderName: 'Boult, Trent',
            ProviderType: 'Individual',
            npi: '12345679',
            tax_id_number: '67306790',
            ProviderAddress: {
              adr_ln_1_txt: '401 6th Ave # 301',
              adr_ln_2_txt: null,
              cty_nm: 'Parkville',
              cnty_nm: 'Kings',
              st_nm: 'NY',
              zip_cd_txt: '08029',
              lat_deg: '42.7867',
              lng_deg: '-74.6789'
            },
            Distance: '25.8 mi',
            Time: '40 mins'
          }]
      },
      {
        Providers: [{
          ProviderName: 'XYZ CORPORATION',
          ProviderType: 'Organization',
          npi: '98768956',
          tax_id_number: '98879811',
          ProviderAddress: {
            adr_ln_1_txt: '2704 West Oxford Loop Ste 110, Oxford, MS, 386555728',
            adr_ln_2_txt: null,
            cty_nm: 'Brooklyn',
            cnty_nm: 'Kings',
            st_nm: 'NY',
            zip_cd_txt: '01234',
            lat_deg: '42.3788',
            lng_deg: '-70.7865'
          },
          Distance: '10.8 mi',
          Time: '10 mins'
        },
          {
            ProviderName: 'Boult, Trent',
            ProviderType: 'Individual',
            npi: '12345679',
            tax_id_number: '67306790',
            ProviderAddress: {
              adr_ln_1_txt: '401 6th Ave # 301',
              adr_ln_2_txt: null,
              cty_nm: 'Parkville',
              cnty_nm: 'Kings',
              st_nm: 'NY',
              zip_cd_txt: '08029',
              lat_deg: '42.7867',
              lng_deg: '-74.6789'
            },
            Distance: '25.8 mi',
            Time: '40 mins'
          }]
      }
    ];
    expect(await component.getDistanceMatrixData(providerDataList, distanceMatrixProviderRequest, distanceMatrixToken['access_token'])).toEqual(distanceMatrixResponseList);
  });
  it('should getProviderName', () => {
    const providerDetailsPhysician = {
      addressLine: 'xyz, Brooklyn, NY, 11217',
      addressLine1: 'xyz',
      addressLine2: null,
      businessName: null,
      cityName: 'Brooklyn',
      distance: 'NA',
      firstName: 'TOM',
      lastName: 'CRUISE',
      locationAffiliationId: null,
      phone: '8165411000',
      prov_id: 268067,
      providerAddressId: 17788,
      providerCategoryRefId: 16309,
      providerMPIN: null,
      providerName: 'CRUISE, TOM',
      providerNpi: '1255539598',
      providerTin: null,
      specialty: '174400000X',
      specialtyId: 16536,
      time: 'NA',
      zipCodeText: '11217'
    };
    const providerDetailsFacility = {
      businessName: 'XYZ CORPORATION',
      firstName: null,
      lastName: null,
      addressLine: '2704 West Oxford Loop Ste 110, Oxford, MS, 386555728, Brooklyn, NY, 01234',
      providerTin: '98879811',
      providerNpi: '98768956',
      prov_id: 10112925,
      phone: '9932293485',
      specialty: 'testabXYZ',
      specialtyId: 17077,
      locationAffiliationId: null,
      providerCategoryRefId: 16310,
      providerAddressId: 117451820,
      addressLine1: '2704 West Oxford Loop Ste 110, Oxford, MS, 386555728',
      addressLine2: null,
      cityName: 'Brooklyn',
      zipCodeText: '01234'
    };
    expect(component.getProviderName(providerDetailsPhysician)).toEqual('CRUISE');
    expect(component.getProviderName(providerDetailsFacility)).toEqual('XYZ CORPORATION');
  });
  it('should sortProvidersByDistance', () => {
    const providerDataList: any = [
      {
        businessName: 'XYZ CORPORATION',
        firstName: null,
        lastName: null,
        addressLine: '2704 West Oxford Loop Ste 110, Oxford, MS, 386555728, Brooklyn, NY, 01234',
        providerTin: '98879811',
        providerNpi: '98768956',
        prov_id: 10112925,
        phone: '9932293485',
        specialty: 'testabXYZ',
        specialtyId: 17077,
        locationAffiliationId: null,
        providerCategoryRefId: 16310,
        providerAddressId: 117451820,
        addressLine1: '2704 West Oxford Loop Ste 110, Oxford, MS, 386555728',
        addressLine2: null,
        cityName: 'Brooklyn',
        zipCodeText: '01234',
        distance: '25.8 mi',
        time: '40 mins'
      },
      {
        businessName: null,
        firstName: 'Ryan',
        lastName: 'Collins',
        addressLine: '2704 West Oxford Loop Ste 120, Oxford, MS, 386555728, Brooklyn, NC, 012347',
        providerTin: '18879813',
        providerNpi: '98468953',
        prov_id: 40416985,
        phone: '9932293485',
        specialty: 'testabMNO',
        specialtyId: 17077,
        locationAffiliationId: null,
        providerCategoryRefId: 16309,
        providerAddressId: 117451820,
        addressLine1: '2704 West Oxford Loop Ste 120, Oxford, MS, 386555728',
        addressLine2: null,
        cityName: 'Brooklyn',
        zipCodeText: '012347',
        distance: 'NA',
        time: 'NA'
      },
      {
        businessName: null,
        firstName: 'Trent',
        lastName: 'Boult',
        addressLine: '401 6th Ave # 301, Parkville, NY, 08029',
        providerTin: '67306790',
        providerNpi: '12345679',
        prov_id: 10293944,
        phone: '9932293485',
        specialty: 'testabXYZ',
        specialtyId: 17078,
        locationAffiliationId: null,
        providerCategoryRefId: 16309,
        providerAddressId: 117451820,
        addressLine1: '401 6th Ave # 301',
        addressLine2: null,
        cityName: 'Parkville',
        zipCodeText: '08029',
        distance: '10.8 mi',
        time: '10 mins'
      }
    ];
    const resultProviderDataList = [providerDataList[2], providerDataList[0], providerDataList[1]];
    component.sortProvidersByDistance(providerDataList);
    expect(providerDataList).toEqual(resultProviderDataList);
  });
  it('should extractDistance', () => {
    expect(component.extractDistance('9.5 mi')).toBe(9.5);
    expect(component.extractDistance('.5 mi')).toBe(0.5);
    expect(component.extractDistance('9.55 mi')).toBe(9.55);
    expect(component.extractDistance('19.5576 mi')).toBe(19.5576);
    expect(component.extractDistance('9. mi')).toBe(9);
    expect(component.extractDistance('10 mi')).toBe(10);
    expect(component.extractDistance('9.5 km')).toBe(9.5);
    expect(component.extractDistance('.5 km')).toBe(0.5);
    expect(component.extractDistance('9.55 km')).toBe(9.55);
    expect(component.extractDistance('19.5576 km')).toBe(19.5576);
    expect(component.extractDistance('9. km')).toBe(9);
    expect(component.extractDistance('10 km')).toBe(10);
  });

  it('should buildProviderDataAndSetDistMatrixParams', async () => {
    const providerData = {
      v_prov_srch: [
        {
          prov_id: 10293944,
          fst_nm: 'Trent',
          lst_nm: 'Boult',
          bus_nm: null,
          adr_ln_1_txt: '401 6th Ave # 301',
          adr_ln_2_txt: null,
          cty_nm: 'Parkville',
          st_ref_id: 1101,
          zip_cd_txt: '08029',
          spcl_ref_id: 17078,
          telcom_adr_id: '4067429978',
          prov_loc_affil_id: null,
          prov_adr_id: 117451820,
          prov_catgy_ref_id: 16309
        },
        {
          prov_id: 10112925,
          fst_nm: null,
          lst_nm: null,
          bus_nm: 'XYZ CORPORATION',
          adr_ln_1_txt: '2704 West Oxford Loop Ste 110, Oxford, MS, 386555728',
          adr_ln_2_txt: null,
          cty_nm: 'Brooklyn',
          st_ref_id: 1101,
          zip_cd_txt: '01234',
          spcl_ref_id: 17077,
          telcom_adr_id: '3044429999',
          prov_loc_affil_id: null,
          prov_adr_id: 117451820,
          prov_catgy_ref_id: 16310
        }
      ]
    };
    const formControl = null;
    component.stepperData = {
      memberinf: [{
        adr_ln_1_txt: 'z street, xy',
        cty_nm: 'Brooklyn',
        zip_cd_txt: '112171604',
        st_ref_id: 1101
      }],
      flowType: 'new'
    };
    component.isDistanceMatrixSearchAllowed = false;
    const responseData: any[] = [
      {
        businessName: null,
        firstName: 'Trent',
        lastName: 'Boult',
        addressLine: '401 6th Ave # 301, Parkville, NY, 08029',
        providerTin: '67306790',
        providerNpi: '12345679',
        prov_id: 10293944,
        phone: '9932293485',
        specialty: 'testabXYZ',
        specialtyId: 17078,
        locationAffiliationId: null,
        providerCategoryRefId: 16309,
        providerAddressId: 117451820,
        addressLine1: '401 6th Ave # 301',
        addressLine2: null,
        cityName: 'Parkville',
        zipCodeText: '08029'
      },
      {
        businessName: 'XYZ CORPORATION',
        firstName: null,
        lastName: null,
        addressLine: '2704 West Oxford Loop Ste 110, Oxford, MS, 386555728, Brooklyn, NY, 01234',
        providerTin: '98879811',
        providerNpi: '98768956',
        prov_id: 10112925,
        phone: '9932293485',
        specialty: 'testabXYZ',
        specialtyId: 17077,
        locationAffiliationId: null,
        providerCategoryRefId: 16310,
        providerAddressId: 117451820,
        addressLine1: '2704 West Oxford Loop Ste 110, Oxford, MS, 386555728',
        addressLine2: null,
        cityName: 'Brooklyn',
        zipCodeText: '01234'
      }
    ];
    expect(await component.buildProviderDataAndSetDistMatrixParams(providerData, formControl)).toEqual(responseData);
    const distMatrixRespData = [responseData[1], responseData[0]];
    distMatrixRespData[0].distance = '10.8 mi';
    distMatrixRespData[0].time = '10 mins';
    distMatrixRespData[1].distance = '25.8 mi';
    distMatrixRespData[1].time = '40 mins';
    component.isDistanceMatrixSearchAllowed = true;
    expect(await component.buildProviderDataAndSetDistMatrixParams(providerData, formControl)).toEqual(distMatrixRespData);
  });
});
