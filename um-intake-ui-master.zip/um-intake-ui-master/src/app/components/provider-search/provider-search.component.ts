import {HttpClient, HttpHeaders} from '@angular/common/http';
import {SwitchableVariableDeclaration} from '@angular/compiler-cli/ngcc/src/host/ngcc_host';
import {Component, EventEmitter, Injectable, Input, OnChanges, OnDestroy, OnInit, Output} from '@angular/core';
import {FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators} from '@angular/forms';
import {Router} from '@angular/router';
import {RawQuery} from '@ecp/gql-tk-beta';
import {ITableInputModel, RadioselectModule} from '@uimf/uitk';
import {IUITKColumnState, IUITKRadioGroupItem, UITKTableDataSource} from '@uitk/angular';
import {Observable, Subscription} from 'rxjs';
import {ReferenceConstants} from 'src/app/constants/referenceConstants';
import {EcpAuthTokenService} from 'src/app/services/ecp-auth-token-service/ecp-auth-token.service';
import {ProviderSearchService} from 'src/app/services/provider-search/provider-search.service';
import {ReferenceService} from 'src/app/services/refernce-service/reference.service';
import {StepperDataService} from 'src/app/services/StepperDataService/StepperDataService';
import {UserSessionService} from 'src/app/shared/services/user-session/user-session.service';
import {environment} from 'src/environments/environment';
import {Constants} from '../../constants/constants';
import {FlowType} from '../../models/enums/flowType';
import {UserAttrService} from '../../services/user-attr-service/user-attr.service';
import {ProcedureComponent} from '../procedure/procedure.component';
import {ReferenceSet} from './referenceSet';

// ordering provider ref is same as 'Attending' only for OP -- following icue here
// Submitting provider ref is called as 'requesting' in ref domain
const PROVIDER_ROLE_REF_ID_ADMITTING = 3758;
const PROVIDER_ROLE_REF_ID_ATTENDING = 3759;
const PROVIDER_ROLE_REF_ID_ORDERING = 3759;
const PROVIDER_ROLE_REF_ID_SERVICING = 3765;
const PROVIDER_ROLE_REF_ID_SUBMITTING = 3764;
const PROVIDER_KEY_VALUE_TYP_REF_ID_NPI = 2782;
const PROVIDER_KEY_VALUE_TYP_REF_ID_MPIN = 2783;
const PROVIDER_KEY_VALUE_TYP_REF_ID_TIN = 16333;

// Setting Distance Matrix Auth Type List
const DISTANCE_MATRIX_AUTH_TYPE_LIST = ['Cardiology', 'Radiology', 'Radiology and Cardiology'];
// Distance Matrix Constants
const DISTANCE_MATRIX_PROVIDER_INDIVIDUAL = 'Individual';
const DISTANCE_MATRIX_PROVIDER_ORGANIZATION = 'Organization';

@Component({
  selector: 'um-provider-search',
  templateUrl: './provider-search.component.html',
  styleUrls: ['./provider-search.component.scss']
})
@Injectable({
  providedIn: 'root'
})
export class ProviderSearchComponent implements OnInit, OnDestroy {
  private currentProviderSearchSpecialtyRefID: any;
  private isTINAndNPISelected: boolean;
  private isSpecialtyAndZipSelected: boolean;
  constructor(public providerSearchService: ProviderSearchService, public http: HttpClient, private readonly referenceService: ReferenceService,
              private userSessionService: UserSessionService, private router: Router, public stepperDataService: StepperDataService ,
              public procedureComponent: ProcedureComponent, public userAttrService: UserAttrService, public readonly ecpAuthTokenService: EcpAuthTokenService) {
    this.headerParams = {'x-hasura-role': Constants.UM_INTAKE_UI_APP_NAME + '_' + userSessionService.getUserPermission(),
                         'Authorization': 'Bearer ' + userSessionService.getEcpToken()};
    this.params = { headers: {...this.staticParams, ...this.headerParams} };
  }
  panelHeader1 = 'Submitting Provider : ';
  panelHeader2 = 'Primary Care Physician : ';
  panelHeader3 = 'Facility : ';
  panelHeader4 = 'Admitting Provider : ';
  panelHeader5 = 'Attending Provider : ';
  panelHeader6 = 'Ordering Provider : ';
  panelHeader7 = 'Servicing Provider : ';
  userRole: string;
  collapsiblePanel1 = false;
  openPanel1 = true;
  collapsiblePanel2 = false;
  openPanel2 = true;
  collapsiblePanel3 = true;
  openPanel3 = true;
  collapsiblePanel4 = true;
  openPanel4 = true;
  collapsiblePanel5 = true;
  openPanel5 = true;
  collapsiblePanel6 = false;
  openPanel6 = true;
  collapsiblePanel7 = true;
  openPanel7 = true;
  USER_PERM_CLINICIAN = Constants.UM_INTAKE_UI_USER_PERMISSION_CLINICIAN;
  iconHollow = 'uimf-icon-favorite_hollow';
  iconFilled = 'uimf-icon-favorite_filled';
  currentProviderAffiliationDetailJson: any;
  myRadioGroupSelectionForOrderingProvider: any;
  myRadioGroupSelectionForServicingProvider: any;
  myRadioGroupSelectionForAttendingProvider: any;
  myRadioGroupSelectionForAdmittingProvider: any;
  myRadioGroupSelectionForFacilityProvider: any;
  myRadioGroupSelectionZipRadiusUnits: any;
  currentFavoriteProviderAddressId;
  DISTANCE_MATRIX_DEFAULT_RADIUS = '2';
  DISTANCE_MATRIX_DEFAULT_RADIUS_UNIT = 'miles';

  items: IUITKRadioGroupItem[] = [
    {
      label: 'Name + State/Zip',
      value: 'NameStateZip'
    },
    {
      label: 'TIN and/or NPI',
      value: 'TINAndNPI'
    },
    {
      label: 'Zip and Specialty',
      value: 'ZipAndSpecialty'
    },
  ];

  radius: IUITKRadioGroupItem[] = [
    {
      label: 'miles',
      value: 'miles',
    },
    {
      label: 'kilometers',
      value: 'km',
    },
  ];

  flagForSpeacilatySearchWarningVisibility = false;
  warningForSpecialtyValidaion = 'please enter Zip and Specialty';

  columnsForServicingProviderPhysicianTable: any;         // For Tab3 -> Search for Physician
  columnsForSelectedServicingProviderTable: any;          // For Tab1 -> Select from Case Tab
  columnsForServicingProviderFacilityTable: any;          // For Tab2 -> Search for Facility Tab

  columnsForPhysicianTable: any = [
    {label: 'Name', id: 'providerName', dataType: 'text'},
    {label: 'Address', id: 'addressLine', dataType: 'text'},
    {label: 'Phone', id: 'phone', dataType: 'text'},
    { label: 'Specialty', id: 'specialty', dataType: 'text'},
    {label: 'TIN', id: 'providerTin', dataType: 'text'},
    {label: 'NPI', id: 'providerNpi', dataType: 'text'}
  ];

  columnsForSelectedProviderTable: any = [
    {label: 'Name', id: 'providerName', dataType: 'text'},
    {label: 'Address', id: 'addressLine', dataType: 'text'},
    {label: 'Phone', id: 'phone', dataType: 'text'},
    { label: 'Specialty', id: 'specialty', dataType: 'text'},
    {label: 'TIN', id: 'providerTin', dataType: 'text'},
    {label: 'NPI', id: 'providerNpi', dataType: 'text'}
  ];

  columnsForFacilityTable: any = [
    {label: 'Name', id: 'providerName', dataType: 'text'},
    {label: 'Address', id: 'addressLine', dataType: 'text'},
    {label: 'Phone', id: 'phone', dataType: 'text'},
    { label: 'Specialty', id: 'specialty', dataType: 'text'},
    {label: 'TIN', id: 'providerTin', dataType: 'text'},
    {label: 'NPI', id: 'providerNpi', dataType: 'text'}
  ];

  columnsForSelectedProviderFacilityTable: any = [
    {label: 'Name', id: 'providerName', dataType: 'text'},
    {label: 'Address', id: 'addressLine', dataType: 'text'},
    {label: 'Phone', id: 'phone', dataType: 'text'},
    { label: 'Specialty', id: 'specialty', dataType: 'text'},
    {label: 'TIN', id: 'providerTin', dataType: 'text'},
    {label: 'NPI', id: 'providerNpi', dataType: 'text'}
  ];
  myFavoriteTabTitle = 'My Favorite';
  model = {
    pagination: {
      currentPageNumber: 1,
      recordsPerPage: 10,
      recordsPerPageOptions: [10, 25, 50, 75, 100],
    },
  };

  modelForPhysician: ITableInputModel = {
    title: 'Physician Results Table',
    enableSorting: true,
    enableFiltering: true,
    enableSingleRowSelect: true,
    clearAllFilters: true,
    fixedHeader: false,
    tkHidePagination: true,
    // pagination: {
    //   currentPageNumber: 1,
    //   recordsPerPage: 10,
    //   recordsPerPageOptions: [10, 25, 50, 75, 100],
    // },
  };

  modelForSelectedProviders: ITableInputModel = {
    title: 'Select From case',
    enableSorting: true,
    enableFiltering: true,
    enableSingleRowSelect: true,
    clearAllFilters: true,
    fixedHeader: false,
    tkHidePagination: true,
    // pagination: {
    //   currentPageNumber: 1,
    //   recordsPerPage: 10,
    //   recordsPerPageOptions: [10, 25, 50, 75, 100],
    // },
    filterCondition: {
      columnSorting: {
        columnId: 'prov_id',
        sortOrder: -1
      }
    }
  };

  modelForSelectedFacilityProviders: ITableInputModel = {
    title: 'Select From case',
    enableSorting: true,
    enableFiltering: true,
    enableSingleRowSelect: true,
    clearAllFilters: true,
    fixedHeader: false,
    tkHidePagination: true,
    // pagination: {
    //   currentPageNumber: 1,
    //   recordsPerPage: 10,
    //   recordsPerPageOptions: [10, 25, 50, 75, 100],
    // },
    filterCondition: {
      columnSorting: {
        columnId: 'prov_id',
        sortOrder: -1
      }
    }
  };

  public IP = ReferenceConstants.SERVICESETTINGTYPE_INPATIENT;
  public OP = ReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT;
  public OPF = ReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY;
  readonly httpUrl: string = environment.REFERENCE_API;
  params: any = {};
  headerParams: any = {};
  readonly contentType = 'application/json';
  private readonly staticParams: any = { 'content-type': this.contentType };
  @Output()
  private prov_id = new EventEmitter<any>();
  private hsc_id;
  private hscProvId: number;
  public nestedData: any;
  roles: any[];
  public selectedradioForAttendingProvider: any;
  public selectedradioForFacility: any;
  public selectedradioForAdmittingProvider: any;
  public selectedradioForOrderingProvider: any;
  public selectedradioForServicingProvider: any;
  public isNameStateRadioSelected = true;
  providerBusinessNameSelected: string;
  admittingproviderNameSelected: string;
  attendingproviderNameSelected: string;
  orderingproviderNameSelected: string;
  servicingproviderNameSelected: string;
  submittingproviderName: string;
  isEditProviderEnabled = true;
  servicingProviderSelected: any;
  @Input() memberStateId: number;
  stepperData: any;
  caseType: any;
  hscObj: any;
  providerMPIN: any;

  modelForFacility: ITableInputModel = {
    title: 'Facility Results Table',
    enableSorting: true,
    enableFiltering: true,
    enableSingleRowSelect: true,
    clearAllFilters: true,
    fixedHeader: false,
    tkHidePagination: true,
    // pagination: {
    //   currentPageNumber: 1,
    //   recordsPerPage: 10,
    //   recordsPerPageOptions: [10, 25, 50, 75, 100],
    // },
  };

  referenceData = [];
  public references: ReferenceSet[] = [];
  tableHeader = ['Name', 'Address', 'TIN', 'NPI'];
  myRequiredValue: string;
  requiredText = 'Input is required';
  providerData = []; // source of truth after search
  physicianResultsData: any[] = [];
  selectedProviderResultsData: any[] = [];
  selectedFacilityResultsData: any[] = [];
  facilityResultsData: any[];
  REFERENCE_STATE = 'stateCode';
  PHYSICIAN_CAT_ID = ReferenceConstants.PHYSICIAN_CAT_ID;
  FACILITY_CAT_ID = ReferenceConstants.FACILITY_CAT_ID;
  invalidFormSubmitted = false;
  notificationVisible = false;
  providerTin = '';
  providerNpi = '';
  invalidFormErrorMessage: string;
  selectedRow: number;
  isDistanceMatrixSearchAllowed = false;                        // Flag to check if DistanceMatrix Search is Allowed

  httpHeaders = new HttpHeaders({
    'Content-Type': this.contentType,
    'Accept': this.contentType
  });

  public nameStateOrZipform = new FormGroup({
    providerFirstName: new FormControl(''),
    providerLastName: new FormControl('', Validators.required),
    providerState: new FormControl('', Validators.required),
    providerZipCode: new FormControl('', Validators.required)
  });

  public tinOrNipform = new FormGroup({
    providerTIN: new FormControl(''),
    providerNPI: new FormControl('')
  });

  public specialtyZipform = new FormGroup({
    providerZip: new FormControl('', Validators.required),
    providerSpecialtyRefID: new FormControl(''),
    providerZipRadius: new FormControl(''),
    providerZipRadiusUnits: new FormControl('')
  });

  public facilityNameStateOrZipform = new FormGroup({
    facilityState: new FormControl('', Validators.required),
    facilityZipCode: new FormControl('', Validators.required),
    providerOrgName: new FormControl('', Validators.required)
  });

  public facilityTinOrNipform = new FormGroup({
    facilityTIN: new FormControl(''),
    facilityNPI: new FormControl('')
  });
  providerRolesClicked: boolean;
  HSC_STATUS_TYPE_OPEN = ReferenceConstants.HSC_STATUS_TYPE_OPEN;
  HSC_STATUS_TYPE_DRAFT = ReferenceConstants.HSC_STATUS_TYPE_DRAFT;
  stepperDataSubscription: Subscription;

  public attendingNameStateOrZipform = new FormGroup({
    providerFirstName: new FormControl(''),
    providerLastName: new FormControl('', Validators.required),
    providerState: new FormControl('', Validators.required),
    providerZipCode: new FormControl('', Validators.required),
  });

  myFavoriteProvidersAdrList = [];
  myFavoriteProvidersList = [];

  results: any;

  deleteDialogModal = {
    show: false,
  };

  async ngOnInit() {
    this.stepperDataSubscription = this.stepperDataService.sharedStepperData.subscribe((stepperData) => {
      this.stepperData = stepperData;
      this.hscObj = this.stepperData.hsc;
    });
    if (this.stepperData.defaultRadius) {
      this.DISTANCE_MATRIX_DEFAULT_RADIUS = this.stepperData.defaultRadius.value;
      this.DISTANCE_MATRIX_DEFAULT_RADIUS_UNIT = this.stepperData.defaultRadius.unit;
    }
    this.getUserFavoriteProviders();
    this.stepperDataService.setStepperData({...this.stepperData, attendingProviderSelected: false});
    this.stepperDataService.setStepperData({...this.stepperData, facilityProviderSelected: false});
    this.setPermissionForDistanceMatrixSearch();
    if (!this.isDistanceMatrixSearchAllowed) {
      this.modelForPhysician.filterCondition = {
        columnSorting: {
          columnId: 'prov_id',
          sortOrder: -1
        }
      };
      this.modelForFacility.filterCondition = {
        columnSorting: {
          columnId: 'prov_id',
          sortOrder: -1
        }
      };
    }
    this.setServicingProviderColumnsByAuthorizationType();
    if (this.stepperData.flowType === FlowType.EDIT) {
      this.providerSearchService.setProviderRoles();
      this.buildProviderResultsDraftData(this.hscObj.hsc_provs);
    } else if (this.stepperData.flowType === FlowType.NEW) {
      this.populateDefaultProvidersOnPageLoad();
    }
    this.myRadioGroupSelectionForFacilityProvider = this.items[0];
    this.myRadioGroupSelectionForAdmittingProvider = this.items[0];
    this.myRadioGroupSelectionForAttendingProvider = this.items[0];
    this.myRadioGroupSelectionForOrderingProvider = this.items[0];
    this.myRadioGroupSelectionForServicingProvider = this.items[0];
    this.myRadioGroupSelectionZipRadiusUnits = this.radius[0];
    await this.getStateRefDataList();
    // tslint:disable-next-line:no-duplicate-string
    this.invalidFormErrorMessage = 'Review the form and correct the highlighted fields';
    this.notificationVisible = false;
    this.nameStateOrZipform.reset();
    this.facilityNameStateOrZipform.reset();
    this.attendingNameStateOrZipform.reset();
    this.facilityResultsData = [];
    this.getSubmittingProviderDetails();
    this.userRole = this.userSessionService.getUserPermission();
    if (this.userRole === Constants.UM_INTAKE_UI_USER_PERMISSION_CLINICIAN
      && this.stepperData.hsc.hsc_sts_ref_id === this.HSC_STATUS_TYPE_DRAFT) {
     this.collapsiblePanel1 = true;
     this.openPanel1 =  true;
    }
  }

  setPermissionForDistanceMatrixSearch() {
    if (DISTANCE_MATRIX_AUTH_TYPE_LIST.indexOf(this.stepperData.serviceType) > -1) {
      this.isDistanceMatrixSearchAllowed = true;
    }
  }

  setServicingProviderColumnsByAuthorizationType() {
    if (this.isDistanceMatrixSearchAllowed) {
      // For Tab3 -> Search for Physician
      this.columnsForServicingProviderPhysicianTable = [
        {label: 'Name', id: 'providerName', dataType: 'text'},
        {label: 'Address', id: 'addressLine', dataType: 'text'},
        {label: 'Phone', id: 'phone', dataType: 'text'},
        {label: 'Specialty', id: 'specialty', dataType: 'text'},
        {label: 'TIN', id: 'providerTin', dataType: 'text'},
        {label: 'NPI', id: 'providerNpi', dataType: 'text'},
        {label: 'Distance', id: 'distance', dataType: 'text'},
        {label: 'Time', id: 'time', dataType: 'text'}
      ];

      // For Tab1 -> Select from Case Tab
      this.columnsForSelectedServicingProviderTable = [
        {label: 'Name', id: 'providerName', dataType: 'text'},
        {label: 'Address', id: 'addressLine', dataType: 'text'},
        {label: 'Phone', id: 'phone', dataType: 'text'},
        {label: 'Specialty', id: 'specialty', dataType: 'text'},
        {label: 'TIN', id: 'providerTin', dataType: 'text'},
        {label: 'NPI', id: 'providerNpi', dataType: 'text'},
        {label: 'Distance', id: 'distance', dataType: 'text'},
        {label: 'Time', id: 'time', dataType: 'text'}
      ];

      // For Tab2 -> Search for Facility Tab
      this.columnsForServicingProviderFacilityTable = [
        {label: 'Name', id: 'providerName', dataType: 'text'},
        {label: 'Address', id: 'addressLine', dataType: 'text'},
        {label: 'Phone', id: 'phone', dataType: 'text'},
        {label: 'Specialty', id: 'specialty', dataType: 'text'},
        {label: 'TIN', id: 'providerTin', dataType: 'text'},
        {label: 'NPI', id: 'providerNpi', dataType: 'text'},
        {label: 'Distance', id: 'distance', dataType: 'text'},
        {label: 'Time', id: 'time', dataType: 'text'}
      ];
    } else {
      // For Tab3 -> Search for Physician
      this.columnsForServicingProviderPhysicianTable = [
        {label: 'Name', id: 'providerName', dataType: 'text'},
        {label: 'Address', id: 'addressLine', dataType: 'text'},
        {label: 'Phone', id: 'phone', dataType: 'text'},
        {label: 'Specialty', id: 'specialty', dataType: 'text'},
        {label: 'TIN', id: 'providerTin', dataType: 'text'},
        {label: 'NPI', id: 'providerNpi', dataType: 'text'}
      ];

      // For Tab1 -> Select from Case Tab
      this.columnsForSelectedServicingProviderTable = [
        {label: 'Name', id: 'providerName', dataType: 'text'},
        {label: 'Address', id: 'addressLine', dataType: 'text'},
        {label: 'Phone', id: 'phone', dataType: 'text'},
        {label: 'Specialty', id: 'specialty', dataType: 'text'},
        {label: 'TIN', id: 'providerTin', dataType: 'text'},
        {label: 'NPI', id: 'providerNpi', dataType: 'text'}
      ];

      // For Tab2 -> Search for Facility Tab
      this.columnsForServicingProviderFacilityTable = [
        {label: 'Name', id: 'providerName', dataType: 'text'},
        {label: 'Address', id: 'addressLine', dataType: 'text'},
        {label: 'Phone', id: 'phone', dataType: 'text'},
        {label: 'Specialty', id: 'specialty', dataType: 'text'},
        {label: 'TIN', id: 'providerTin', dataType: 'text'},
        {label: 'NPI', id: 'providerNpi', dataType: 'text'}
      ];
    }
  }

  private getUserFavoriteProviders() {
    this.userAttrService.getUserFavorites(ReferenceConstants.USER_FAVORITE_TYPE_PROVIDER_REF_ID, this.userSessionService.getUserName()).subscribe((res) => {
      if (res.data.user_fav && res.data.user_fav.length > 0) {
        res.data.user_fav.forEach((item) => {
          if (!this.myFavoriteProvidersAdrList.includes(item.user_fav_val)) {
            this.myFavoriteProvidersAdrList.push(item.user_fav_val);
          }
        });
        this.getUserFavoriteProvidersDetails();
      }
    });
  }

  private async getUserFavoriteProvidersDetails() {
    function getRefDisplay(refId) {
      return refEntriesResponse.data.ref.find((item) => item.ref_id === refId)?.ref_dspl;
    }
    const provDetailRecords = [];
    const refIds = [];
    for (const provAdrId of this.myFavoriteProvidersAdrList) {
      const provDetailsRes = await this.providerSearchService.getProviderDetailsByAdrId(provAdrId).toPromise();
      if (provDetailsRes.data?.v_prov_srch_v2 && provDetailsRes.data.v_prov_srch_v2.length > 0) {
        const provDetail = provDetailsRes.data.v_prov_srch_v2[0];
        provDetailRecords.push(provDetail);
        refIds.push(provDetail.st_ref_id);
        refIds.push(provDetail.spcl_ref_id);
        refIds.push(provDetail.prov_key_typ_ref_id);
      }
    }
    const refEntriesResponse = await this.referenceService.getBulkRefEntriesByRefIds(refIds).toPromise();
    provDetailRecords.forEach((provDtlRec) => {
      const favoriteRecord = {
        providerType: provDtlRec.prov_catgy_ref_id,
        providerName: provDtlRec.prov_catgy_ref_id === ReferenceConstants.FACILITY_CAT_ID ? provDtlRec.bus_nm : provDtlRec.lst_nm + ', ' + provDtlRec.fst_nm,
        address: provDtlRec.adr_ln_1_txt + ', ' + provDtlRec.cty_nm + ', ' + getRefDisplay(provDtlRec.st_ref_id) + ' ' + provDtlRec.zip_cd_txt,
        phone: provDtlRec.telcom_adr_id,
        specialty: provDtlRec.spcl_ref_id ? getRefDisplay(provDtlRec.spcl_ref_id) : '',
        npi: provDtlRec.prov_key_typ_ref_id === ReferenceConstants.PROVIDER_KEY_VALUE_TYP_REF_ID_NPI ? provDtlRec.prov_key_val : '',
        tin: provDtlRec.prov_key_typ_ref_id === ReferenceConstants.PROVIDER_KEY_TYP_REF_ID_TIN ? provDtlRec.prov_key_val : '',
        providerAddressId: provDtlRec.prov_adr_id
      };
      this.myFavoriteProvidersList = [...this.myFavoriteProvidersList, favoriteRecord]; // generating new reference for the array to trigger ngOnChanges in FavoriteProvidersTabComponent
    });
  }

  ngOnDestroy() {
    this.stepperDataSubscription.unsubscribe();
  }
  buildProviderResultsDraftData(hscProvData) {
    for (const i in hscProvData) {
      const hsc_prov_ref_id = hscProvData[i].hsc_prov_roles[0].prov_role_ref_id;
      const hscProvId = hscProvData[i]?.prov_loc_affil_dtl?.providerDetails?.prov_id;
      const hscProvAdrId = hscProvData[i]?.prov_loc_affil_dtl?.providerDetails?.prov_adr_id;
      const hscProvtelcomAdrId = hscProvData[i]?.telcom_adr_id;
      const hscProvSpecialtyId = hscProvData[i]?.spcl_ref_id;
      this.providerSearchService.getProviderDetailsSearch(hscProvId, hscProvAdrId, hscProvtelcomAdrId, hscProvSpecialtyId)
        .toPromise()
        .then(async (resProvData) => {
          this.providerData = resProvData.data.v_prov_srch[0];
          const provDraftDataTemp = await this.providerSearchService.buildProviderData([this.providerData]);
          await this.setDistMatrixParamsByMbrAdrAndProvSpcl(provDraftDataTemp, null);
          const provDraftData = provDraftDataTemp[0];
          this.mapProviderDraftData(provDraftData, hsc_prov_ref_id);
        });
    }
  }
  mapProviderDraftData(provDraftData, hsc_prov_ref_id) {
   let isProviderDuplicate = false;
   this.selectedProviderResultsData.forEach((value) => {
      if (value.prov_id === provDraftData.prov_id) {
        isProviderDuplicate = true;
        return;
      }
    });
   this.mapSelectedProvider(provDraftData, hsc_prov_ref_id);
   if (!isProviderDuplicate) {
     this.selectedProviderResultsData.push(provDraftData);
   }
  }
  mapSelectedProvider(providerDetails, hsc_prov_ref_id) {
    if (PROVIDER_ROLE_REF_ID_ADMITTING == hsc_prov_ref_id) {
      this.admittingproviderNameSelected = this.getProviderName(providerDetails);
      this.stepperDataService.setStepperData({...this.stepperData, admittingProviderDetails: providerDetails});
    } else if (PROVIDER_ROLE_REF_ID_ORDERING == hsc_prov_ref_id) {
      this.orderingproviderNameSelected = this.getProviderName(providerDetails);
      this.stepperDataService.setStepperData({...this.stepperData, OrderingProviderDetails: providerDetails});
    } else if (PROVIDER_ROLE_REF_ID_ATTENDING == hsc_prov_ref_id) {
      this.attendingproviderNameSelected = this.getProviderName(providerDetails);
      this.stepperDataService.setStepperData({...this.stepperData, attendingProviderDetails: providerDetails});
    } else if (PROVIDER_ROLE_REF_ID_SERVICING == hsc_prov_ref_id) {
      this.servicingproviderNameSelected = this.getProviderName(providerDetails);
      this.stepperDataService.setStepperData({...this.stepperData, ServicingProviderDetails: providerDetails});
    } else if (PROVIDER_ROLE_REF_ID_SUBMITTING == hsc_prov_ref_id) {
      this.submittingproviderName = this.getProviderName(providerDetails);
      this.stepperDataService.setStepperData({...this.stepperData, submittingProviderDetails: providerDetails});
    }
  }
  getProviderName(providerDetails) {
    return this.PHYSICIAN_CAT_ID == providerDetails.providerCategoryRefId ? providerDetails.lastName : providerDetails.businessName;
  }
  getSubmittingProviderDetails() {
        if (this.stepperData?.submittingProviderDetails) {
          this.selectedProviderResultsData.push(this.stepperData?.submittingProviderDetails);
          this.providerSelectedForSubmittingProvider(this.stepperData.submittingProviderDetails);
        }
  }

  populateDefaultProvidersOnPageLoad() {
    if (!this.isDistanceMatrixSearchAllowed) {
      return;
    } else {
      this.getMemberAddressInfo().then((memberAddress) => {
        if (!memberAddress) {
          return;
        } else {
          this.providerSearchService.getProvidersZipCodeSearch(memberAddress.zip_cd_txt, this.PHYSICIAN_CAT_ID)
            .toPromise()
            .then(async (providerData) => {
              this.providerData = providerData.data.v_prov_srch;
              const tempPhysicianResultsData = await this.providerSearchService.buildProviderData(this.providerData);
              const radiusSearchParams = this.resolveDistanceMatrixRadiusSearchParams(null);
              this.getDistanceMatrixProviderLists(memberAddress, tempPhysicianResultsData, radiusSearchParams).then((distanceMatrixProviderList) => {
                this.setDistanceMatrixDataForProviders(tempPhysicianResultsData, distanceMatrixProviderList);
                this.physicianResultsData = tempPhysicianResultsData;
              });
            });
        }
      });
    }
  }

  onClear() {
    this.nameStateOrZipform.reset();
    this.facilityTinOrNipform.reset();
    this.facilityNameStateOrZipform.reset();
    this.attendingNameStateOrZipform.reset();
    this.tinOrNipform.reset();
    this.specialtyZipform.reset();
    this.currentProviderSearchSpecialtyRefID = null;
  }
  onSwitchTab(index) {
    const tabIndex = index;
    this.physicianResultsData = [];
    this.facilityResultsData = [];
  }

  async buildProviderDataAndSetDistMatrixParams(providerData, formControl) {
    const providerResultsData = await this.providerSearchService.buildProviderData(providerData);
    await this.setDistMatrixParamsByMbrAdrAndProvSpcl(providerResultsData, formControl);
    return providerResultsData;
  }

  getPhysicianProviderData() {
    if (this.nameStateOrZipform.valid) {
      this.invalidFormSubmitted = false;
      // this.notificationVisible = false;
      // this.selectedRow = -1;
      this.providerSearchService.getProviderNameSearch(this.PHYSICIAN_CAT_ID,
        this.nameStateOrZipform.controls.providerFirstName.value ? this.nameStateOrZipform.controls.providerFirstName.value : null,
        this.nameStateOrZipform.controls.providerLastName.value,
        this.nameStateOrZipform.controls.providerState.value.refId,
        this.nameStateOrZipform.controls.providerZipCode.value ? this.nameStateOrZipform.controls.providerZipCode.value : null, null,
        this.currentProviderSearchSpecialtyRefID)
        .toPromise()
        .then(async (res) => {
          this.providerData = res.data.v_prov_srch;
          this.physicianResultsData = await this.buildProviderDataAndSetDistMatrixParams(this.providerData, null);
          this.currentProviderSearchSpecialtyRefID = null;
        });
    } else {
      if (this.nameStateOrZipform.get('providerLastName').value == null) {
        this.nameStateOrZipform.get('providerLastName').errors['required'] = true;
      }
      if (this.nameStateOrZipform.get('providerState').value == null) {
        this.nameStateOrZipform.get('providerState').errors['required'] = true;
      }
      if (this.nameStateOrZipform.get('providerZipCode').value == null) {
        this.nameStateOrZipform.get('providerZipCode').errors['required'] = true;
      }
      this.invalidFormSubmitted = true;
      this.notificationVisible = true;
      // this.invalidFormErrorMessage = 'Review the form and correct the highlighted fields';
    }
  }
  getPhysicianProviderDataOnTinOrNpi() {
    if (this.tinOrNipform.valid) {
      this.invalidFormSubmitted = false;
      this.notificationVisible = false;
      this.selectedRow = -1;
      if (!this.tinOrNipform.controls.providerTIN.value &&  !this.tinOrNipform.controls.providerNPI.value) {
        this.notificationVisible = true;
        this.invalidFormErrorMessage = 'Review the form and enter a TIN or NPI';
      } else {
        this.providerSearchService.getProviderTinOrNpiSearch(this.PHYSICIAN_CAT_ID, this.tinOrNipform.controls.providerTIN.value ? this.tinOrNipform.controls.providerTIN.value : null,
          this.tinOrNipform.controls.providerNPI.value ? this.tinOrNipform.controls.providerNPI.value : null)
          .toPromise()
          .then(async (resTin) => {
            this.providerData = resTin.data.v_prov_srch;
            this.physicianResultsData = await this.buildProviderDataAndSetDistMatrixParams(this.providerData, null);
          });
      }
    } else {
      this.invalidFormSubmitted = true;
      // this.notificationVisible = true;
    }
  }

  getProviderZipandSpecialty() {
    if (this.specialtyZipform.valid && this.currentProviderSearchSpecialtyRefID != null) {
        this.providerSearchService.getProviderByZipAndSpecialty(this.currentProviderSearchSpecialtyRefID,
          this.specialtyZipform.controls.providerZip.value, this.PHYSICIAN_CAT_ID)
          .toPromise()
          .then(async (res) => {
            this.providerData = res.data.v_prov_srch;
            this.physicianResultsData = await this.buildProviderDataAndSetDistMatrixParams(this.providerData, this.specialtyZipform);
            this.currentProviderSearchSpecialtyRefID = null;
          });
    } else {
      if (this.flagForSpeacilatySearchWarningVisibility === false) {
        this.flagForSpeacilatySearchWarningVisibility = !this.flagForSpeacilatySearchWarningVisibility;
      }
    }
  }

  getProviderZipandSpecialtyforFacility() {
    if (this.specialtyZipform.valid && this.currentProviderSearchSpecialtyRefID != null) {
      this.providerSearchService.getProviderByZipAndSpecialty(this.currentProviderSearchSpecialtyRefID,
        this.specialtyZipform.controls.providerZip.value, this.FACILITY_CAT_ID)
        .toPromise()
        .then(async (res) => {
          this.providerData = res.data.v_prov_srch;
          this.facilityResultsData = await this.buildProviderDataAndSetDistMatrixParams(this.providerData, null);
          this.currentProviderSearchSpecialtyRefID = null;
        });
    } else {
      if (this.flagForSpeacilatySearchWarningVisibility === false) {
        this.flagForSpeacilatySearchWarningVisibility = !this.flagForSpeacilatySearchWarningVisibility;
      }
    }
  }

  getFacilityProviderData() {
    if (this.facilityNameStateOrZipform.valid) {
      this.invalidFormSubmitted = false;
      this.notificationVisible = false;
      this.selectedRow = -1;
      this.providerSearchService.getProviderNameSearch(this.FACILITY_CAT_ID , null,
        null,
        this.facilityNameStateOrZipform.controls.facilityState.value.refId,
        this.facilityNameStateOrZipform.controls.facilityZipCode.value ? this.facilityNameStateOrZipform.controls.facilityZipCode.value  : null,
        '%' + this.facilityNameStateOrZipform.controls.providerOrgName.value + '%', this.currentProviderSearchSpecialtyRefID)
        .toPromise()
        .then(async (facilityRes) => {
          this.providerData = facilityRes.data.v_prov_srch;
          this.facilityResultsData = await this.buildProviderDataAndSetDistMatrixParams(this.providerData, null);
          this.currentProviderSearchSpecialtyRefID = null;
        });
    } else {
      if (this.facilityNameStateOrZipform.get('providerOrgName').value == null) {
        this.facilityNameStateOrZipform.get('providerOrgName').errors['required'] = true;
      }
      if (this.facilityNameStateOrZipform.get('facilityState').value == null) {
        this.facilityNameStateOrZipform.get('facilityState').errors['required'] = true;
      }
      if (this.facilityNameStateOrZipform.get('facilityZipCode').value == null) {
        this.facilityNameStateOrZipform.get('facilityZipCode').errors['required'] = true;
      }
      this.invalidFormSubmitted = true;
      // this.notificationVisible = true;
      // this.invalidFormErrorMessage = 'Review the form and correct the highlighted fields';
    }
  }

  getFacilityProviderDataOnTinOrNpi() {
    // this.modelFour.pagination = this.model.pagination;
    if (this.facilityTinOrNipform.valid) {
      this.invalidFormSubmitted = false;
      this.notificationVisible = false;
      this.selectedRow = -1;
      if (!this.facilityTinOrNipform.controls.facilityTIN.value &&  !this.facilityTinOrNipform.controls.facilityNPI.value) {
        this.notificationVisible = true;
        this.invalidFormErrorMessage = 'Review the form and enter a TIN or NPI';
      } else {
        this.providerSearchService.getProviderTinOrNpiSearch(this.FACILITY_CAT_ID,
          this.facilityTinOrNipform.controls.facilityTIN.value ? this.facilityTinOrNipform.controls.facilityTIN.value : null,
          this.facilityTinOrNipform.controls.facilityNPI.value ? this.facilityTinOrNipform.controls.facilityNPI.value : null)
          .toPromise()
          .then(async (facilityResTin) => {
            this.providerData = facilityResTin.data.v_prov_srch;
            this.facilityResultsData = await this.buildProviderDataAndSetDistMatrixParams(this.providerData, null);
          });
      }
    } else {
      this.invalidFormSubmitted = true;
      // this.notificationVisible = true;
    }
  }

  async getStateRefDataList() {
     const StateRefName = ReferenceConstants.STATE_REFNAME;
     await this.referenceService.getReferenceDataForState(StateRefName).toPromise().then((res) => {
                      res.data.ref_set.forEach((item) => {
                          const stateObj = {
                                id: item.ref_id,
                                label: item.ref.ref_cd,
                                value: item.ref.ref_cd,
                          };
                          this.referenceData.push(stateObj);
                      });

                 }).catch((error) => { });
  }

  async setDistMatrixParamsByMbrAdrAndProvSpcl(providerData: any[], formControl: any): Promise<any> {
    return new Promise((resolveProv) => {
      if (!(this.isDistanceMatrixSearchAllowed && providerData.length > 0)) {
        resolveProv(providerData);
      } else {
        this.getMemberAddressInfo().then((memberAddress) => {
          if (!memberAddress) {
            resolveProv(providerData);
          } else {
            const radiusSearchParams = this.resolveDistanceMatrixRadiusSearchParams(formControl);
            this.getDistanceMatrixProviderLists(memberAddress, providerData, radiusSearchParams).then((distanceMatrixProviderList) => {
              this.setDistanceMatrixDataForProviders(providerData, distanceMatrixProviderList);
              resolveProv(providerData);
            });
          }
        });
      }
    });
  }

  public async getMemberAddressInfo(): Promise<any> {
    let memberInfo: any;
    if (this.stepperData.flowType === FlowType.EDIT && this.stepperData.hsc.indv_adr) {
      memberInfo = this.stepperData.hsc.indv_adr[0];
    } else if (this.stepperData.flowType === FlowType.NEW && this.stepperData.memberinf) {
      memberInfo = this.stepperData.memberinf[0];
    } else {
      memberInfo = null;
    }

    return new Promise((resolveMem) => {
      if (memberInfo === null) {
        resolveMem(memberInfo);
      } else {
        const getRefCode = this.referenceService.loadRefDataByRefID(memberInfo.st_ref_id).toPromise();
        getRefCode.then((providerStateRes) => {
          const memberAddressInfo = {
            adr_ln_1_txt: memberInfo.adr_ln_1_txt,
            cty_nm: memberInfo.cty_nm,
            zip_cd_txt: memberInfo.zip_cd_txt,
            st_nm: providerStateRes.data.ref[0].ref_cd
          };
          resolveMem(memberAddressInfo);
        });
      }
    });
  }

  async getDistanceMatrixProviderLists(memberAddress: any, providerDataList: any[], radiusSearchParams: any): Promise<any> {
    return new Promise((resolve) => {
      if (!(memberAddress && providerDataList && providerDataList.length > 0 && radiusSearchParams)) {
        console.error('Insufficient Parameters');
        resolve([]);
      } else {
        this.ecpAuthTokenService.getEcpToken().toPromise().then((distanceMatrixToken) => {
          if (!distanceMatrixToken || !distanceMatrixToken['access_token']) {
            console.error('Error in Distance Matrix Token');
            resolve([]);
          } else {
            const distanceMatrixProviderRequest = {
              adr_ln_1_txt: memberAddress.adr_ln_1_txt,
              cty_nm: memberAddress.cty_nm,
              st_nm: memberAddress.st_nm,
              zip_cd_txt: memberAddress.zip_cd_txt,
              prov_spcl_cd: '',
              radius: radiusSearchParams.radius,
              radius_uom: radiusSearchParams.radius_uom
            };

            this.getDistanceMatrixData(providerDataList, distanceMatrixProviderRequest, distanceMatrixToken).then((distanceMatrixResponseList) => {
              distanceMatrixResponseList = this.prepareDistMatrixResponseLists(distanceMatrixResponseList);
              resolve(distanceMatrixResponseList);
            });
          }
        });
      }
    });
  }

  async getDistanceMatrixData(providerDataList: any[], distanceMatrixRProviderRequest: any, distanceMatrixToken: string): Promise<any> {
    return new Promise((resolve) => {
      const dMPromises = [];
      const specialties = [];

      providerDataList.forEach((providerData) => {
        // Making Unique Specialties Call
        if (!providerData.specialtyId || specialties.indexOf(providerData.specialtyId) !== -1) {
          return;
        }
        // Setting Specialty Reference ID of the iterating Provider
        specialties.push(providerData.specialtyId);
        distanceMatrixRProviderRequest.prov_spcl_cd = providerData.specialtyId;

        // Pushing Distance Matrix call Promises
        dMPromises.push(new Promise((resolveDM) => {
          this.providerSearchService.getDistanceMatrixDataForProvider(distanceMatrixRProviderRequest, distanceMatrixToken['access_token'])
            .then((distanceMatrixResponse) => resolveDM(distanceMatrixResponse))
            .catch((exception) => console.log('Exception in Distance Matrix Call: ' + exception));
        }));
      });

      Promise.all(dMPromises).then((distanceMatrixResponseList: any[]) => {
        resolve(distanceMatrixResponseList);
      });
    });
  }

  prepareDistMatrixResponseLists(distanceMatrixResponseList: any[]): any[] {
    if (distanceMatrixResponseList && distanceMatrixResponseList.length > 0) {

      let distMatIndProvData = [];                            // Distance Matrix Individual Providers List
      let distMatOrgProvData = [];                            // Distance Matrix Organization Providers List

      // Iterating over Distance Matrix Response
      distanceMatrixResponseList.forEach((distMatrix) => {
        // Iterating over Providers in each Distance Matrix Response
        if (distMatrix && distMatrix.Providers) {
          distMatrix.Providers.forEach((provider) => {
            if (provider.ProviderType === DISTANCE_MATRIX_PROVIDER_INDIVIDUAL) {
              distMatIndProvData.push(provider);
            } else if (provider.ProviderType === DISTANCE_MATRIX_PROVIDER_ORGANIZATION) {
              distMatOrgProvData.push(provider);
            }
          });
        }
      });

      // Filtering the Distance Matrix of Providers
      distMatIndProvData = this.filterDistanceMatrixProviders(distMatIndProvData);
      distMatOrgProvData = this.filterDistanceMatrixProviders(distMatOrgProvData);

      distanceMatrixResponseList = [distMatIndProvData, distMatOrgProvData];
    }
    return distanceMatrixResponseList;
  }

  filterDistanceMatrixProviders(distanceMatrixProviderDataList: any[]): any[] {
    if (distanceMatrixProviderDataList.length > 1) {
      // Remove Duplicate Providers
      const distanceMatrixProviders = distanceMatrixProviderDataList.filter((v, i) => distanceMatrixProviderDataList.findIndex((item) => (
        item.ProviderName === v.ProviderName &&
        item.ProviderType === v.ProviderType &&
        item.npi === v.npi &&
        item.tax_id_number === v.tax_id_number &&
        item.Distance === v.Distance &&
        item.Time === v.Time &&
        item.ProviderAddress.adr_ln_1_txt === v.ProviderAddress.adr_ln_1_txt &&
        item.ProviderAddress.adr_ln_2_txt === v.ProviderAddress.adr_ln_2_txt &&
        item.ProviderAddress.cty_nm === v.ProviderAddress.cty_nm &&
        item.ProviderAddress.cnty_nm === v.ProviderAddress.cnty_nm &&
        item.ProviderAddress.st_nm === v.ProviderAddress.st_nm &&
        item.ProviderAddress.zip_cd_txt === v.ProviderAddress.zip_cd_txt &&
        item.ProviderAddress.lat_deg === v.ProviderAddress.lat_deg &&
        item.ProviderAddress.lng_deg === v.ProviderAddress.lng_deg
      )) === i);

      // Sort the Distance Matrix Provider Data
      // distanceMatrixProviders.sort((a, b) => a.ProviderName.localeCompare(b.ProviderName));
      return distanceMatrixProviders;
    }

    return distanceMatrixProviderDataList;
  }

  setDistanceMatrixDataForProviders(providerDataList: any[], distanceMatrixResponse: any[]) {
    if ((providerDataList && providerDataList.length > 0) && (distanceMatrixResponse && distanceMatrixResponse.length > 0)) {

      const distMatIndProvData = distanceMatrixResponse[0] ? distanceMatrixResponse[0] : [];
      const distMatOrgProvData = distanceMatrixResponse[1] ? distanceMatrixResponse[1] : [];
      let indx = -1;

      providerDataList.forEach((provider) => {
        if (provider.providerCategoryRefId === this.PHYSICIAN_CAT_ID) {
          indx = this.checkProviderExistenceInDistanceMatrix(provider, distMatIndProvData);
          this.setDistanceMatrixParamsInProvider(provider, distMatIndProvData, indx);
        } else if (provider.providerCategoryRefId === this.FACILITY_CAT_ID) {
          indx = this.checkProviderExistenceInDistanceMatrix(provider, distMatOrgProvData);
          this.setDistanceMatrixParamsInProvider(provider, distMatOrgProvData, indx);
        }
      });
      // Sort the Provider Data on the basis of distance
      this.sortProvidersByDistance(providerDataList);
    } else {
      return;
    }
  }

  sortProvidersByDistance(providerDataList: any[]) {
    providerDataList.sort((a, b) => {
      if (a.distance.localeCompare('NA') === 0 && b.distance.localeCompare('NA') === 0) {
        return 0;
      } else if (a.distance.localeCompare('NA') === 0 && b.distance.localeCompare('NA') !== 0) {
        return 1;
      } else if (a.distance.localeCompare('NA') !== 0 && b.distance.localeCompare('NA') === 0) {
        return -1;
      } else {
        return this.extractDistance(a.distance) - this.extractDistance(b.distance);
      }
    });
  }

  extractDistance(distanceParam) {
    // Regular expression to extract numerical value from distance field
    const expression = /(\d*\.)?\d+/;
    return parseFloat(distanceParam.match(expression)[0]);
  }

  checkProviderExistenceInDistanceMatrix(provider: any, distanceMatrixProviderList: any[]) {
    if (provider && distanceMatrixProviderList && distanceMatrixProviderList.length > 0) {
      return distanceMatrixProviderList.findIndex((item) => item.npi === provider.providerNpi);
    } else {
      return -1;
    }
  }

  setDistanceMatrixParamsInProvider(provider: any, distanceMatrix: any[], indx: number) {
    if (indx !== -1 && distanceMatrix && distanceMatrix.length > 0) {
      provider.distance = distanceMatrix[indx].Distance ? distanceMatrix[indx].Distance : 'NA';
      provider.time = distanceMatrix[indx].Time ? distanceMatrix[indx].Time : 'NA';
    } else {
      provider.distance = 'NA';
      provider.time = 'NA';
    }
  }

  resolveDistanceMatrixRadiusSearchParams(formControl: any) {
    const radiusSearchParameters = {
      radius: this.DISTANCE_MATRIX_DEFAULT_RADIUS,
      radius_uom: this.DISTANCE_MATRIX_DEFAULT_RADIUS_UNIT
    };
    if (formControl) {
      const radius = formControl.controls.providerZipRadius.value;
      const radius_uom = formControl.controls.providerZipRadiusUnits.value;

      if (radius && radius.length > 0) {
        radiusSearchParameters.radius = radius;
      }
      if (radius_uom && radius_uom.value.length > 0) {
        radiusSearchParameters.radius_uom = radius_uom.value;
      }
    }
    return radiusSearchParameters;
  }

  conditionChangedForFacility(event) {
    if (event.event === 'ON_COLUMN_FILTER') {
      this.columnsForFacilityTable.forEach((col) => {
        event.filterCondition.filterColumns.forEach((condition) => {
          const key = Object.keys(condition)[0];
          if (col.id === key) {
            col.searchInput = condition[key];
          }
        });
      });
    } else if (event.event === 'ON_CLEAR_ALL_FILTERS') {
      this.columnsForFacilityTable.forEach((col) => {
        if (col.searchInput) {
          col.searchInput = '';
        }
      });
    }
  }

  conditionChangedForPhysician(event) {
    if (event.event === 'ON_COLUMN_FILTER') {
      this.columnsForPhysicianTable.forEach((col) => {
        event.filterCondition.filterColumns.forEach((condition) => {
          const key = Object.keys(condition)[0];
          if (col.id === key) {
            col.searchInput = condition[key];
          }
        });
      });
    } else if (event.event === 'ON_CLEAR_ALL_FILTERS') {
      this.columnsForPhysicianTable.forEach((col) => {
        if (col.searchInput) {
          col.searchInput = '';
        }
      });
    }
  }

  conditionChangedForSelectedProvider(event) {
    if (event.event === 'ON_COLUMN_FILTER') {
      this.columnsForPhysicianTable.forEach((col) => {
        event.filterCondition.filterColumns.forEach((condition) => {
          const key = Object.keys(condition)[0];
          if (col.id === key) {
            col.searchInput = condition[key];
          }
        });
      });
    } else if (event.event === 'ON_CLEAR_ALL_FILTERS') {
      this.columnsForPhysicianTable.forEach((col) => {
        if (col.searchInput) {
          col.searchInput = '';
        }
      });
    }
  }

  onRadioChangeForServicingProvider(radioid) {
    this.selectedradioForServicingProvider = radioid.value;
    if (this.selectedradioForServicingProvider === 'NameStateZip') {
      this.isNameStateRadioSelected = true;
      this.isTINAndNPISelected = false;
      this.isSpecialtyAndZipSelected = false;
    } else if (this.selectedradioForServicingProvider === 'TINAndNPI') {
      this.isTINAndNPISelected = true;
      this.isNameStateRadioSelected = false;
      this.isSpecialtyAndZipSelected = false;
    } else {
      this.isTINAndNPISelected = false;
      this.isNameStateRadioSelected = false;
      this.isSpecialtyAndZipSelected = true;
    }
  }

  onRadioChangeForOrderingProvider(radioid) {
    this.selectedradioForOrderingProvider = radioid.value;
    if (this.selectedradioForOrderingProvider === 'NameStateZip') {
      this.isNameStateRadioSelected = true;
      this.isTINAndNPISelected = false;
      this.isSpecialtyAndZipSelected = false;
    } else if (this.selectedradioForOrderingProvider === 'TINAndNPI') {
      this.isTINAndNPISelected = true;
      this.isNameStateRadioSelected = false;
      this.isSpecialtyAndZipSelected = false;
    } else {
      this.isTINAndNPISelected = false;
      this.isNameStateRadioSelected = false;
      this.isSpecialtyAndZipSelected = true;
    }
  }

  onRadioChangeForAttendingProvider(radioid) {
    this.selectedradioForAttendingProvider = radioid.value;
    if (this.selectedradioForAttendingProvider === 'NameStateZip') {
      this.isNameStateRadioSelected = true;
      this.isTINAndNPISelected = false;
      this.isSpecialtyAndZipSelected = false;
    } else if (this.selectedradioForAttendingProvider === 'TINAndNPI') {
      this.isTINAndNPISelected = true;
      this.isNameStateRadioSelected = false;
      this.isSpecialtyAndZipSelected = false;
    } else {
      this.isTINAndNPISelected = false;
      this.isNameStateRadioSelected = false;
      this.isSpecialtyAndZipSelected = true;
    }
  }

  onRadioChangeForAdmittingProvider(radioid) {
    this.selectedradioForAdmittingProvider = radioid.value;
    if (this.selectedradioForAdmittingProvider === 'NameStateZip') {
      this.isNameStateRadioSelected = true;
      this.isTINAndNPISelected = false;
      this.isSpecialtyAndZipSelected = false;
    } else if (this.selectedradioForAdmittingProvider === 'TINAndNPI') {
      this.isTINAndNPISelected = true;
      this.isNameStateRadioSelected = false;
      this.isSpecialtyAndZipSelected = false;
    } else {
      this.isTINAndNPISelected = false;
      this.isNameStateRadioSelected = false;
      this.isSpecialtyAndZipSelected = true;
    }
  }

  onRadioChangeForFacility(radioid) {
    this.selectedradioForFacility = radioid.value;
    if (this.selectedradioForFacility === 'NameStateZip') {
      this.isNameStateRadioSelected = true;
      this.isTINAndNPISelected = false;
      this.isSpecialtyAndZipSelected = false;
    } else if (this.selectedradioForFacility === 'TINAndNPI') {
      this.isTINAndNPISelected = true;
      this.isNameStateRadioSelected = false;
      this.isSpecialtyAndZipSelected = false;
    } else {
      this.isTINAndNPISelected = false;
      this.isNameStateRadioSelected = false;
      this.isSpecialtyAndZipSelected = true;
    }
  }

  onPaginationChange(event) {
  }

  providerSelectedForFacility(selectedProv) {
    this.setProviderAffilDetailJson(selectedProv);
    this.stepperDataService.setStepperData({...this.stepperData, facilityProviderSelected: true});
    this.openPanel3 = false;
    this.providerBusinessNameSelected = selectedProv.businessName;
    this.selectedFacilityResultsData?.forEach((value) => {
      if (value.prov_id === selectedProv.prov_id) {
        return;
      }
    });
    if (selectedProv.businessName !== null) {
        this.selectedFacilityResultsData.push(selectedProv);
      }
    this.providerSearchService.setProviderDetails(selectedProv.phone, selectedProv.specialtyId,
      ReferenceConstants.PROVIDER_ROLE_REF_ID_FACILITY,
      selectedProv.providerTin, this.currentProviderAffiliationDetailJson).subscribe((data) => {

    }, (error) => {});
    this.stepperDataService.setStepperData({...this.stepperData, facilityProviderDetails: selectedProv});
  }

  providerSelectedForAdmittingProvider(selectedProv) {
    this.setProviderAffilDetailJson(selectedProv);
    this.openPanel4 = false;
    this.admittingproviderNameSelected = this.getProviderName(selectedProv);
    let isDuplicate = false;
    this.selectedProviderResultsData?.forEach((value) => {
      if (value.prov_id === selectedProv.prov_id) {
        isDuplicate = true;
        return;
      }
    });
    if (!isDuplicate) {
      this.selectedProviderResultsData.push(selectedProv);
      this.stepperDataService.setStepperData({...this.stepperData, selectedProviderResultsData: this.selectedProviderResultsData});
    }
    this.providerSearchService.setProviderDetails(selectedProv.phone, selectedProv.specialtyId,
      ReferenceConstants.PROVIDER_ROLE_REF_ID_ADMITTING, selectedProv.providerTin,
      this.currentProviderAffiliationDetailJson).subscribe((data) => {
    }, (error) => {});
    this.stepperDataService.setStepperData({...this.stepperData, admittingProviderDetails: selectedProv});
  }

  providerSelectedForAttendingProvider(selectedProv) {
    this.setProviderAffilDetailJson(selectedProv);
    this.stepperDataService.setStepperData({...this.stepperData, attendingProviderSelected: true});
    this.openPanel5 = false;
    this.attendingproviderNameSelected = this.getProviderName(selectedProv);
    let isDuplicate = false;
    this.selectedProviderResultsData?.forEach((value) => {
      if (value.prov_id === selectedProv.prov_id) {
        isDuplicate = true;
        return;
      }
    });
    if (!isDuplicate) {
      this.selectedProviderResultsData.push(selectedProv);
      this.stepperDataService.setStepperData({...this.stepperData, selectedProviderResultsData: this.selectedProviderResultsData});
    }
    this.providerSearchService.setProviderDetails(selectedProv.phone, selectedProv.specialtyId,
      ReferenceConstants.PROVIDER_ROLE_REF_ID_ATTENDING, selectedProv.providerTin,
      this.currentProviderAffiliationDetailJson).subscribe((data) => {
    }, (error) => {});
    this.stepperDataService.setStepperData({...this.stepperData, attendingProviderDetails: selectedProv});
  }

  setProviderAffilDetailJson(selectedProv) {
    this.currentProviderAffiliationDetailJson = {
      providerDetails: {
        prov_keys: [{prov_key_typ_ref_id: PROVIDER_KEY_VALUE_TYP_REF_ID_NPI, prov_key_val: selectedProv?.providerNpi ? selectedProv?.providerNpi : null},
                    {prov_key_typ_ref_id: PROVIDER_KEY_VALUE_TYP_REF_ID_TIN, prov_key_val: selectedProv?.providerTin ? selectedProv?.providerTin : null},
                    {prov_key_typ_ref_id: PROVIDER_KEY_VALUE_TYP_REF_ID_MPIN, prov_key_val: selectedProv?.providerMPIN ? selectedProv?.providerMPIN : null}],
        prov_id: selectedProv.prov_id,
        prov_adr_id: selectedProv.providerAddressId,
        prov_cat_typ_ref_id: selectedProv.providerCategoryRefId
      }
    };
  }

  providerSelectedForOrderingProvider(selectedProv) {
    this.setProviderAffilDetailJson(selectedProv);
    this.openPanel6 = false;
    this.orderingproviderNameSelected = this.getProviderName(selectedProv);
    let isDuplicate = false;
    this.selectedProviderResultsData?.forEach((value) => {
      if (value.prov_id === selectedProv.prov_id) {
        isDuplicate = true;
        return;
      }
    });
    if (!isDuplicate) {
      this.selectedProviderResultsData.push(selectedProv);
      this.stepperDataService.setStepperData({...this.stepperData, selectedProviderResultsData: this.selectedProviderResultsData});
    }
    this.providerSearchService.setProviderDetails(selectedProv.phone, selectedProv.specialtyId,
      ReferenceConstants.PROVIDER_ROLE_REF_ID_ORDERING, selectedProv.providerTin,
      this.currentProviderAffiliationDetailJson).subscribe((data) => {
    }, (error) => {});
    this.stepperDataService.setStepperData({...this.stepperData, OrderingProviderDetails: selectedProv});
  }

  providerSelectedFromCaseTableforFacility(selectedProv) {
    this.setProviderAffilDetailJson(selectedProv);
    this.stepperDataService.setStepperData({...this.stepperData, facilityProviderSelected: true});

    this.openPanel3 = false;
    this.providerBusinessNameSelected = selectedProv.businessName;
    this.providerSearchService.setProviderDetails(selectedProv.phone, selectedProv.specialtyId,
      ReferenceConstants.PROVIDER_ROLE_REF_ID_FACILITY,
      selectedProv.providerTin, this.currentProviderAffiliationDetailJson).subscribe((data) => {
    }, (error) => {});
    this.stepperDataService.setStepperData({...this.stepperData, facilityProviderDetails: selectedProv});
  }

  providerSelectedFromCaseTableForAdmittingProvider(selectedProv) {
    this.setProviderAffilDetailJson(selectedProv);
    this.openPanel4 = false;
    this.admittingproviderNameSelected = this.getProviderName(selectedProv);
    this.providerSearchService.setProviderDetails(selectedProv.phone, selectedProv.specialtyId,
      ReferenceConstants.PROVIDER_ROLE_REF_ID_ADMITTING
      , selectedProv.providerTin, this.currentProviderAffiliationDetailJson).subscribe((data) => {
    }, (error) => {});
    this.stepperDataService.setStepperData({...this.stepperData, admittingProviderDetails: selectedProv});
  }

  providerSelectedFromCaseTableForAttendingProvider(selectedProv) {
    this.setProviderAffilDetailJson(selectedProv);
    this.stepperDataService.setStepperData({...this.stepperData, attendingProviderSelected: true});
    this.openPanel5 = false;
    this.attendingproviderNameSelected = this.getProviderName(selectedProv);
    this.providerSearchService.setProviderDetails(selectedProv.phone, selectedProv.specialtyId,
      ReferenceConstants.PROVIDER_ROLE_REF_ID_ATTENDING,
      selectedProv.providerTin, this.currentProviderAffiliationDetailJson).subscribe((data) => {
    }, (error) => {});
    this.stepperDataService.setStepperData({...this.stepperData, attendingProviderDetails: selectedProv});
  }

  providerSelectedFromCaseTableForOrderingProvider(selectedProv) {
    this.setProviderAffilDetailJson(selectedProv);
    this.openPanel6 = false;
    this.orderingproviderNameSelected = this.getProviderName(selectedProv);
    this.providerSearchService.setProviderDetails(selectedProv.phone, selectedProv.specialtyId,
      ReferenceConstants.PROVIDER_ROLE_REF_ID_ORDERING, selectedProv.providerTin,
      this.currentProviderAffiliationDetailJson).subscribe((data) => {
    }, (error) => {});
    this.stepperDataService.setStepperData({...this.stepperData, OrderingProviderDetails: selectedProv});
  }

  providerSelectedForSubmittingProvider(selectedProv) {
    this.setProviderAffilDetailJson(selectedProv);
    this.openPanel1 = false;
    this.submittingproviderName = this.getProviderName(selectedProv);
    let isDuplicate = false;
    this.selectedProviderResultsData?.forEach((value) => {
      if (value.prov_id === selectedProv.prov_id) {
        isDuplicate = true;
        return;
      }
    });
    if (!isDuplicate) {
      this.selectedProviderResultsData.push(selectedProv);
    }
    this.providerSearchService.setProviderDetails(selectedProv.phone, selectedProv.specialtyId,
            ReferenceConstants.PROVIDER_ROLE_REF_ID_SUBMITTING, selectedProv.providerTin,
            this.currentProviderAffiliationDetailJson).subscribe((data) => {
      }, (error) => {});

    this.stepperDataService.setStepperData({...this.stepperData, submittingProviderDetails: selectedProv});
  }

  mapCaseLevelSrvcProvToSrvcLines(data) {
    if (data.insert_hsc_prov_one) {
      this.hscProvId = data.insert_hsc_prov_one.hsc_prov_id;
      this.providerSearchService.checkExistingServiceLines(this.stepperData.hscId).subscribe((serviceLines) => {
        serviceLines.data.hsc_srvc.forEach((serviceLine) => {
          this.providerSearchService.updateServcingProviderAgainstProcedure(serviceLine.hsc_srvc_id, this.hscProvId).subscribe((dataResult) => {
          }, (error) => {
          });
        });
      });
    }
  }

  setServicingProvider(selectedProv) {
    if (selectedProv) {
      this.setProviderAffilDetailJson(selectedProv);
      this.openPanel6 = false;
      this.servicingproviderNameSelected = this.getProviderName(selectedProv);
      // this.servicingproviderNameSelected = selectedProv.lastName;
      let isDuplicate = false;
      this.selectedProviderResultsData?.forEach((value) => {
        if (value.prov_id === selectedProv.prov_id) {
          isDuplicate = true;
          return;
        }
      });
      if (!isDuplicate) {
        this.selectedProviderResultsData.push(selectedProv);
      }
      this.providerSearchService.setProviderDetails(selectedProv.phone, selectedProv.specialtyId,
        ReferenceConstants.PROVIDER_ROLE_REF_ID_SERVICING, selectedProv.providerTin,
        this.currentProviderAffiliationDetailJson).subscribe((data) => {
        if (!this.providerSearchService.allowMultipleServicingProvider) {
          this.mapCaseLevelSrvcProvToSrvcLines(data);
        }
      }, (error) => {
      });
      this.stepperDataService.setStepperData({...this.stepperData, ServicingProviderDetails: selectedProv});
      this.servicingProviderSelected = selectedProv;
    }
    if (this.servicingProviderSelected) {
      this.procedureComponent.setServicingProviderForexistingProcedure(this.servicingProviderSelected, this.stepperData?.hscProcedures[0]?.hsc_srvc_id);
    }
  }

  toggleOpenPanel() {
    this.openPanel2 = true;
    this.collapsiblePanel2 = false;
  }

  poulatePCP() {
    if (this.selectedProviderResultsData.length !== 0) {
    this.selectedProviderResultsData.push(this.providerSearchService.PCPProviderDetails);
  }
  }

  populateMemberState() {
    const referenceId = this.referenceData.find((array) => array.refId === this.memberStateId).id;
    const memberState = (referenceId.toString() + ':' + ' ' + 'Object');
    this.nameStateOrZipform.setValue({providerFirstName: '', providerLastName: '', providerState: memberState, providerZipCode: ''});
    this.facilityNameStateOrZipform.setValue({facilityState: memberState, facilityZipCode: '', providerOrgName: ''});
    this.attendingNameStateOrZipform.setValue({providerFirstName: '', providerLastName: '', providerState: memberState, providerZipCode: ''});
    }

  onOrderingFavoriteChange() {
    const currentOrderingProvider = this.stepperData.OrderingProviderDetails;
    const isCurrentOrderingFavorite = this.isFavorite(currentOrderingProvider.providerAddressId);
    if (!isCurrentOrderingFavorite) {
      this.saveFavoriteAndUpdateLocalState(currentOrderingProvider);
    } else {
      this.currentFavoriteProviderAddressId = currentOrderingProvider.providerAddressId;
      this.showDeleteDialog();
    }
  }

  onAdmittingFavoriteChange() {
    const currentAdmittingProvider = this.stepperData.admittingProviderDetails;
    const isCurrentAdmittingFavorite = this.isFavorite(currentAdmittingProvider.providerAddressId);
    if (!isCurrentAdmittingFavorite) {
      this.saveFavoriteAndUpdateLocalState(currentAdmittingProvider);
    } else {
      this.currentFavoriteProviderAddressId = currentAdmittingProvider.providerAddressId;
      this.showDeleteDialog();
    }
  }

  onAttendingFavoriteChange() {
    const currentAttendingProvider = this.stepperData.attendingProviderDetails;
    const isCurrentAttendingFavorite = this.isFavorite(currentAttendingProvider.providerAddressId);
    if (!isCurrentAttendingFavorite) {
      this.saveFavoriteAndUpdateLocalState(currentAttendingProvider);
    } else {
      this.currentFavoriteProviderAddressId = currentAttendingProvider.providerAddressId;
      this.showDeleteDialog();
    }
  }

  onFacilityFavoriteChange() {
    const currentFacilityProvider = this.stepperData.facilityProviderDetails;
    const isCurrentFacilityFavorite = this.isFavorite(currentFacilityProvider.providerAddressId);
    if (!isCurrentFacilityFavorite) {
      this.saveFavoriteAndUpdateLocalState(currentFacilityProvider);
    } else {
      this.currentFavoriteProviderAddressId = currentFacilityProvider.providerAddressId;
      this.showDeleteDialog();
    }
  }

  onSubmittingFavoriteChange() {
    const currentSubmittingProvider = this.stepperData.submittingProviderDetails;
    const isCurrentSubmittingFavorite = this.isFavorite(currentSubmittingProvider.providerAddressId);
    if (!isCurrentSubmittingFavorite) {
      this.saveFavoriteAndUpdateLocalState(currentSubmittingProvider);
    } else {
      this.currentFavoriteProviderAddressId = currentSubmittingProvider.providerAddressId;
      this.showDeleteDialog();
    }
  }

  onServicingFavoriteChange() {
    const currentServicingProvider = this.stepperData.ServicingProviderDetails;
    const isCurrentServicingFavorite = this.isFavorite(currentServicingProvider.providerAddressId);
    if (!isCurrentServicingFavorite) {
      this.saveFavoriteAndUpdateLocalState(currentServicingProvider);
    } else {
      this.currentFavoriteProviderAddressId = currentServicingProvider.providerAddressId;
      this.showDeleteDialog();
    }
  }

  private saveFavoriteAndUpdateLocalState(provider) {
    this.userAttrService.saveUserFavorite(ReferenceConstants.USER_FAVORITE_TYPE_PROVIDER_REF_ID, provider.providerAddressId).subscribe();
    const favoriteRecord = {
      providerType: provider.providerCategoryRefId,
      providerName: provider.providerCategoryRefId === ReferenceConstants.FACILITY_CAT_ID ? provider.businessName : provider.lastName + ', ' + provider.firstName,
      address: provider.addressLine,
      phone: provider.phone,
      specialty: provider.specialty,
      npi: provider.providerNpi,
      tin: provider.providerTin,
      providerAddressId: provider.providerAddressId
    };
    this.myFavoriteProvidersList = [...this.myFavoriteProvidersList, favoriteRecord]; // generating new reference for the array to trigger ngOnChanges in FavoriteProvidersTabComponent
    this.myFavoriteProvidersAdrList.push(provider.providerAddressId);
  }

  onOrderingProviderEditChange() {
      if (!this.collapsiblePanel6) {
        this.collapsiblePanel6 = true;
      } else {
        this.collapsiblePanel6 = false;
      }
  }

  onFacilityEditChange() {
    if (!this.collapsiblePanel3) {
      this.collapsiblePanel3 = true;
    } else {
      this.collapsiblePanel3 = false;
    }
  }

  onSortChange(sortState: IUITKColumnState) {
    console.log('Sorting Change: ', sortState);
  }

  editRow() {
    this.isEditProviderEnabled = true;
  }

  closeRow() {
    this.isEditProviderEnabled = false;
  }

  tkSearchVal($event: any) {
    if ($event.length > 3) {
      this.providerSearchService.getSpecialty($event).subscribe((res) => {
        this.results = res.data.ref;
      });
    }
  }

  onSelect($event: any) {
    this.currentProviderSearchSpecialtyRefID = $event.ref_id;
  }

  tkSearchGo($event: any) {

  }

  isFavorite(provAdrId) {
    return this.myFavoriteProvidersAdrList.includes(provAdrId);
  }

  deleteFavoriteAndUpdateLocalState(adrsId?: any) {
    if (adrsId) {
      this.currentFavoriteProviderAddressId = adrsId;
    }
    this.userAttrService.deleteUserFavoriteProvider(this.userSessionService.getUserName(), this.currentFavoriteProviderAddressId).subscribe();
    this.myFavoriteProvidersAdrList = this.myFavoriteProvidersAdrList.filter((item) => item !== this.currentFavoriteProviderAddressId);
    this.myFavoriteProvidersList = this.myFavoriteProvidersList.filter((item) => item.providerAddressId !== this.currentFavoriteProviderAddressId);
    this.closeDeleteDialog();
  }

  showDeleteDialog() {
    this.deleteDialogModal.show = true;
  }

  closeDeleteDialog() {
    this.deleteDialogModal.show = false;
  }
}
