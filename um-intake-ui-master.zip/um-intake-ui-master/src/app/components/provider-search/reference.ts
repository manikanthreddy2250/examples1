import {IDataObject} from "./data-object";

export class Reference implements IDataObject {
  static readonly REFERENCE_VIEW_FIELDS: string[] = ['ref_id', 'inac_ind', 'bas_ref_nm', 'ref_cd', 'ref_dspl', 'ref_desc'];
  static readonly REFERENCE_TABLE_NAME: string = 'ref';

  static readonly PROVIDER_ORGANIZATION_TYPE: string = 'providerOrgType';

  label: string;
  value: string;

  constructor(private _id?: number, private _inactiveInd: boolean = false, private _baseReferenceName?: string, private _cd?: string, private _display?: string, private _description?: string) {
    this.label = this.display;
    this.value = this.description;
  }

  static getDataObjects(records: any[]): Reference[] {
    const refs: Reference[] = [];
    if (records != null) {
      for (let i = 0; i < records.length; i++) {
        const ref: Reference = this.getDataObject(records[i]);
        refs.push(ref);
      }
    }
    return refs;
  }

  static getDataObject(record: any): Reference {
    const ref: Reference = new Reference();
    if (record != null) {
      ref.id = record[Reference.REFERENCE_VIEW_FIELDS[0]];
      ref.inactiveInd = record[Reference.REFERENCE_VIEW_FIELDS[1]];
      ref.baseReferenceName = record[Reference.REFERENCE_VIEW_FIELDS[2]];
      ref.cd = record[Reference.REFERENCE_VIEW_FIELDS[3]];
      ref.display = record[Reference.REFERENCE_VIEW_FIELDS[4]];
      ref.description = record[Reference.REFERENCE_VIEW_FIELDS[5]];
      ref.label = record[Reference.REFERENCE_VIEW_FIELDS[4]];
      ref.value = record[Reference.REFERENCE_VIEW_FIELDS[5]];
    }
    return ref;
  }

  getViewFields(): string[] {
    return Reference.REFERENCE_VIEW_FIELDS;
  }

  getTableName(): string {
    return Reference.REFERENCE_TABLE_NAME;
  }

  get id(): number {
    return this._id;
  }

  set id(value: number) {
    this._id = value;
  }

  get cd(): string {
    return this._cd;
  }

  set cd(value: string) {
    this._cd = value;
  }

  get display(): string {
    return this._display;
  }

  set display(value: string) {
    this._display = value;
  }

  get description(): string {
    return this._description;
  }

  set description(value: string) {
    this._description = value;
  }

  get inactiveInd(): boolean {
    return this._inactiveInd;
  }

  set inactiveInd(value: boolean) {
    this._inactiveInd = value;
  }

  get baseReferenceName(): string {
    return this._baseReferenceName;
  }

  set baseReferenceName(value: string) {
    this._baseReferenceName = value;
  }
}
