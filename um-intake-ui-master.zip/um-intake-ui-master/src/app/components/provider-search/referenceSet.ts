import {Reference} from './reference';
import {IDataObject} from "./data-object";

export class ReferenceSet implements IDataObject {
  static readonly REFERENCE_SET_VIEW_FIELDS: string[] = ['ref_nm', 'ref_id', 'strt_dt', 'end_dt', 'ref'];
  static readonly REFERENCE_SET_TABLE_NAME: string = 'hsr_ref_set';

  constructor(private _name?: string, private _id?: number, private _startDate?: Date, private _endDate?: Date, private _reference?: Reference) {
  }

  static getDataObjects(records: any[]): ReferenceSet[] {
    const refset: ReferenceSet[] = [];
    if (records != null) {
      for (let i = 0; i < records.length; i++) {
        const ref: ReferenceSet = this.getDataObject(records[i]);
        refset.push(ref);
      }
    }
    return refset;
  }

  static getDataObject(record: any): ReferenceSet {
    const ref: ReferenceSet = new ReferenceSet();
    if (record != null) {
      ref.name = record[ReferenceSet.REFERENCE_SET_VIEW_FIELDS[0]];
      ref.id = record[ReferenceSet.REFERENCE_SET_VIEW_FIELDS[1]];
      ref.startDate = record[ReferenceSet.REFERENCE_SET_VIEW_FIELDS[2]];
      ref.endDate = record[ReferenceSet.REFERENCE_SET_VIEW_FIELDS[3]];
      ref.reference = Reference.getDataObject(record[ReferenceSet.REFERENCE_SET_VIEW_FIELDS[4]]);
    }
    return ref;
  }

  getViewFields(): string[] {
    return ReferenceSet.REFERENCE_SET_VIEW_FIELDS;
  }

  getTableName(): string {
    return ReferenceSet.REFERENCE_SET_TABLE_NAME;
  }

  get name(): string {
    return this._name;
  }

  set name(value: string) {
    this._name = value;
  }

  get id(): number {
    return this._id;
  }

  set id(value: number) {
    this._id = value;
  }

  get startDate(): Date {
    return this._startDate;
  }

  set startDate(value: Date) {
    this._startDate = value;
  }

  get endDate(): Date {
    return this._endDate;
  }

  set endDate(value: Date) {
    this._endDate = value;
  }

  get reference(): Reference {
    return this._reference;
  }

  set reference(value: Reference) {
    this._reference = value;
  }
}
