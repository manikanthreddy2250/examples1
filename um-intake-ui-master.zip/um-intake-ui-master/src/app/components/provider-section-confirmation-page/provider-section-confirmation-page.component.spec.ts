import {HttpClient, HttpHandler} from '@angular/common/http';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import {Injectable, NO_ERRORS_SCHEMA} from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {MicroProductAuthService} from '@ecp/auth-library';
import {FormFieldService} from '@uimf/uitk';
import {UITKRadioGroupModule} from '@uitk/angular';
import {Observable, of} from 'rxjs';
import {uitkAngularModules, uitkModules} from 'src/app/app.module';
import {ProviderSearchService} from 'src/app/services/provider-search/provider-search.service';
import {UserSessionService} from 'src/app/shared/services/user-session/user-session.service';
import {environment} from 'src/environments/environment';
import {ReferenceConstants} from '../../constants/referenceConstants';
import {EcpAuthTokenService} from '../../services/ecp-auth-token-service/ecp-auth-token.service';
import {IUserSessionService} from '../../shared/services/user-session/interface-user-session.service';
import {ProviderSearchComponent} from '../provider-search/provider-search.component';
import { ProviderSectionConfirmationPageComponent } from './provider-section-confirmation-page.component';

@Injectable()
class UserSessionMockServiceY implements IUserSessionService {

  constructor() {}

  readonly microProductAuthService: MicroProductAuthService;
  readonly ecpAuthTokenService: EcpAuthTokenService;

  orgTag = 'x-ecp-cli-orgs';
  APP_NAME_PREFIX = 'um_intake_ui_';
  ECP_TOKEN_KEY = 'ecp_token';
  ACTIVE_ORG_ROLE_KEY = 'active_org_role';
  ACTIVE_ORG_ROLE_VALUE = '["ecp", "engineer"]';
  i = 0;

  getVarData() {
    return null;
  }

  getLocalEcpToken() {
    return null;
  }

  getUserName() {
    if (this.i === 0) {
      this.i++;
      return 'breddy88';
    } else if (this.i === 1) {
      this.i = this.i + 2;
      return 'SYSTEM';
    } else if (this.i === 3)  {
      return 'abcd';
    }
  }
  getUserOrg() {
    return 'ecp';
  }
  getUserPermission() {
    return 'userPermission';
  }

  getEcpToken() {
    return 'ecpToken';
  }
  getFunctionalRole() {
    return 'functionalRole';
  }
}
@Injectable()
class MockHttpClient {
  post(url: string, body: any | null, options?: any) {
    switch (url) {
      case environment.HEALTH_SERVICE_API:
        return of({data: {ref: [{ref_cd: 34}]}});
      case environment.SAVE_AUTH_HTTP_FUNCTION_URL:
        return of({hscDuplicates: [{hsc_id: 123}]});
      case environment.INDIVIDUAL_API:
        return of({data: {v_indv_srch: [{}]}});
      case environment.MEMBERSHIP_API:
        return of({data: {mbr_cov: [{}]}});
      default:
        return of({});
    }
  }
}
@Injectable()
class ProviderSearchMockService {
  getProviderTinOrNpiSearch(providerCategoryId, providerTIN, providerNPI): Observable<any> {
    return of({ data: {
        v_prov_srch: [{prov_id: '667', providerTin: '345', addressLine: 'test', lst_nm: 'test', fst_nm: 'test',
                       bus_nm: 'facility', telcom_adr_id: '46', spcl_ref_dspl: 'vg', spcl_ref_id: '546',
                       prov_loc_affil_id: '8686'}]
      } });
  }
  getProviderDetailsSearch(provId, provAdrId, provtelcomAdrId, ProvSpecialtyRefId): Observable<any> {
    return of({ data: {
        v_prov_srch: [{prov_id: '667', providerTin: '345', addressLine: 'test', lst_nm: 'test', fst_nm: 'test',
                       bus_nm: 'facility', telcom_adr_id: '46', spcl_ref_dspl: 'vg', spcl_ref_id: '546', }]
      } });
  }
  setProviderDetails(providerTelecomAddressId: string, providerSpecialtyRefId: string,
                     providerLocationAffiliationId: string, PROVIDER_ROLE_REF_ID: number, stepperData: any): Observable<any> {
    return of({hscduplicates: [{hsc_id: 123}]});
  }
  getProviderNameSearch(providerCategoryId: number, providerFirstName: string, providerLastName: string, providerState: number,
                        providerZipCode: string, providerOrgName: string): Observable<any> {
    return of({});
  }
  getProviderTinOrNpi(providerID: string, providerKeyTypeRefId: number): Observable<any> {
    return of({data: {
        prov_key: [{prov_key_val: '455'}]
      }});
  }
  getHscProvider(hscid): Observable<any> {
   return of({data: {
       hsc_prov: [{prov_key_val: '455', prov_loc_affil_dtl: {providerDetails: { prov_id: 90, prov_adr_id: 2355, prov_cat_typ_ref_id: 16309}},
                   prov_loc_affil_id: 76, hsc_prov_roles: [{prov_role_ref_id: 3760}]
     }, {prov_key_val: '455', prov_loc_affil_id: 76, hsc_prov_roles: [{prov_role_ref_id: 3758}]
       }]}});
}
  getProviderTinSearch(locationAffiliationId: number, providerTIN: string, providerTINKey: number) {
    return of({data: {
        v_prov_srch: [{st_ref_id: 172, prov_id: 125, adr_ln_1_txt: 'g', adr_ln_2_txt: 'r', cty_nm: 'test', zip_cd_txt: '645456',
                       spcl_ref_id: 437, }]
      }});
  }
}

describe('ProviderSectionConfirmationPageComponent', () => {
  let component: ProviderSectionConfirmationPageComponent;
  let fixture: ComponentFixture<ProviderSectionConfirmationPageComponent>;

  // beforeEach(async(() => {
  //   TestBed.configureTestingModule({
  //     declarations: [ ProviderSectionConfirmationPageComponent ]
  //   })
  //   .compileComponents();
  // }));

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [UITKRadioGroupModule, uitkModules, uitkAngularModules, FormsModule, ReactiveFormsModule,
        HttpClientTestingModule],
      providers: [HttpHandler, FormFieldService,
        { provide: UserSessionService, useClass: UserSessionMockServiceY },
        { provide: HttpClient, useClass: MockHttpClient },
        { provide: ProviderSearchService, useClass: ProviderSearchMockService }
      ],
      declarations: [ ProviderSectionConfirmationPageComponent ],
      schemas: [NO_ERRORS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProviderSectionConfirmationPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should setProviders', () => {
    let provDraftData = {
      adr_ln_1_txt: '401 6th Ave # 301',
      adr_ln_2_txt: null,
      bus_nm: null,
      cty_nm: 'Montgomery',
      fst_nm: 'AMOR',
      lst_nm: 'RAMIREZ',
      prov_catgy_ref_id: 16309,
      prov_id: 125,
      prov_key_typ_ref_id: 2782,
      prov_key_val: '1699732990',
      prov_loc_affil_id: 7,
      spcl_ref_id: 16696,
      st_ref_id: 1119,
      telcom_adr_id: '3044429999',
      zip_cd_txt: '251362116',
      spcl_ref_dspl: '208000000X'
    };
    const addressLine = 'Address 12345 ';
    const  providerTin = provDraftData.prov_key_val;
    let providerDetails = {
      businessName: provDraftData.bus_nm,
      firstName: provDraftData.fst_nm,
      lastName: provDraftData.lst_nm + ', ' + provDraftData.fst_nm,
      addressLine, providerTin,
      prov_id: provDraftData.prov_id,
      phone: provDraftData.telcom_adr_id,
      specialty: provDraftData.spcl_ref_dspl,
      specialtyId: provDraftData.spcl_ref_id,
      locationAffiliationId: provDraftData.prov_loc_affil_id
    };
    component.setProviders(providerDetails, 3764);
    component.setProviders(providerDetails, 3761);
    component.setProviders(providerDetails, 3759);
    component.setProviders(providerDetails, 3760);
    component.setProviders(providerDetails, 3758);
    expect(component.setProviders).toBeTruthy();
  });

  it('should setProviderTinfromHsc', () => {
    component.setProviderTinfromHsc(866);
    expect(component.setProviderTinfromHsc).toBeTruthy();
  });

});
