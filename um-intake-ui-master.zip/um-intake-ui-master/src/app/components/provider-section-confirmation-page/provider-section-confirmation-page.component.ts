import {HttpClient} from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import {RawQuery} from '@ecp/gql-tk-beta';
import {Console} from 'inspector';
import {Observable} from 'rxjs';
import {ReferenceConstants} from 'src/app/constants/referenceConstants';
import {ProviderSearchService} from 'src/app/services/provider-search/provider-search.service';
import {ReferenceService} from 'src/app/services/refernce-service/reference.service';
import {StepperDataService} from 'src/app/services/StepperDataService/StepperDataService';
import {environment} from 'src/environments/environment';
import {Constants} from '../../constants/constants';
import {UserSessionService} from '../../shared/services/user-session/user-session.service';

const PROVIDER_KEY_VALUE_TYP_REF_ID_NPI = 2782;
const PROVIDER_KEY_VALUE_TYP_REF_ID_TIN = 16333;

@Component({
  selector: 'um-provider-section-confirmation-page',
  templateUrl: './provider-section-confirmation-page.component.html',
  styleUrls: ['./provider-section-confirmation-page.component.scss']
})
export class ProviderSectionConfirmationPageComponent implements OnInit {

  readonly httpUrl: string = environment.HEALTH_SERVICE_API;
  headerParams: any = {};
  params: any = {};
  readonly contentType = 'application/json';
  private readonly staticParams: any = { 'content-type': this.contentType };
  stepperData: any;
  hscObj: any;
  attendingProviderHscDetails: {};
  facilityProviderHscDetails: {};
  submittingProviderHscDetails: {};
  private providerNpi: string;
  private providerData: any;
  private providerTin: string;
  facilityProviderDetails: any;
  submittingProviderDetails: any;
  attendingProviderDetails: any;
  orderingProviderDetails: any;
  admittingProviderDetails: any;
  public IP = ReferenceConstants.SERVICESETTINGTYPE_INPATIENT;
  public OP = ReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT;
  public OPF = ReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY;
  private providerMPIN: any;

  constructor(public stepperDataService: StepperDataService,
              private readonly referenceService: ReferenceService,
              public  providerSearchService: ProviderSearchService,
              public http: HttpClient,
              private readonly userSessionService: UserSessionService) {

    this.headerParams = {'x-hasura-role': Constants.UM_INTAKE_UI_APP_NAME + '_' + userSessionService.getUserPermission(),
                         'Authorization': 'Bearer ' + userSessionService.getEcpToken()};
    this.params = { headers: {...this.staticParams, ...this.headerParams} };
  }

  async ngOnInit() {
     this.stepperDataService.sharedStepperData.subscribe((stepperData) => {
      this.stepperData = stepperData;
      this.hscObj = this.stepperData.hsc;
      this.printTins();
    });
     this.setProviderTinfromHsc(this.stepperData.hscId);
  }

  printTins() {

  }

  async setProviderTinfromHsc(hscId: number) {
     this.providerSearchService.getHscProvider(hscId).subscribe((res) => {
      const hscProviders = res.data.hsc_prov;
      hscProviders.forEach((hscProvider) => {
        const hscProvId = hscProvider?.prov_loc_affil_dtl?.providerDetails?.prov_id;
        const hscProvAdrId = hscProvider?.prov_loc_affil_dtl?.providerDetails?.prov_adr_id;
        const hscProvtelcomAdrId = hscProvider?.telcom_adr_id;
        const hscProvSpecialtyId = hscProvider?.spcl_ref_id;
        const providerRole = hscProvider?.hsc_prov_roles[0]?.prov_role_ref_id;
        if (providerRole === ReferenceConstants.PROVIDER_ROLE_REF_ID_SUBMITTING) {
          this.submittingProviderHscDetails = {hscProvId, hscProvAdrId, hscProvtelcomAdrId, hscProvSpecialtyId};
          this.getProviderDataOnTinOrNpi(hscProvId, hscProvAdrId, hscProvtelcomAdrId, hscProvSpecialtyId, ReferenceConstants.PROVIDER_ROLE_REF_ID_SUBMITTING);
        } else if (providerRole === ReferenceConstants.PROVIDER_ROLE_REF_ID_FACILITY) {
          this.facilityProviderHscDetails = {hscProvId, hscProvAdrId, hscProvtelcomAdrId, hscProvSpecialtyId};
          this.getProviderDataOnTinOrNpi(hscProvId, hscProvAdrId, hscProvtelcomAdrId, hscProvSpecialtyId,
            ReferenceConstants.PROVIDER_ROLE_REF_ID_FACILITY);
        } else if (providerRole === ReferenceConstants.PROVIDER_ROLE_REF_ID_ATTENDING) {
          this.attendingProviderHscDetails = {hscProvId, hscProvAdrId, hscProvtelcomAdrId, hscProvSpecialtyId};
          this.getProviderDataOnTinOrNpi(hscProvId, hscProvAdrId, hscProvtelcomAdrId, hscProvSpecialtyId,
            ReferenceConstants.PROVIDER_ROLE_REF_ID_ATTENDING);
        } else if (providerRole === ReferenceConstants.PROVIDER_ROLE_REF_ID_ORDERING) {
          this.orderingProviderDetails = {hscProvId, hscProvAdrId, hscProvtelcomAdrId, hscProvSpecialtyId};
          this.getProviderDataOnTinOrNpi(hscProvId, hscProvAdrId, hscProvtelcomAdrId, hscProvSpecialtyId,
            ReferenceConstants.PROVIDER_ROLE_REF_ID_ORDERING);
        } else if (providerRole === ReferenceConstants.PROVIDER_ROLE_REF_ID_ADMITTING) {
          this.admittingProviderDetails = {hscProvId, hscProvAdrId, hscProvtelcomAdrId, hscProvSpecialtyId};
          this.getProviderDataOnTinOrNpi(hscProvId, hscProvAdrId, hscProvtelcomAdrId, hscProvSpecialtyId,
            ReferenceConstants.PROVIDER_ROLE_REF_ID_ADMITTING);
        }
      });
    });
  }

  getProviderDataOnTinOrNpi(hscProvId, hscProvAdrId, hscProvtelcomAdrId, hscProvSpecialtyId, providerRole) {
        this.providerSearchService.getProviderDetailsSearch(hscProvId, hscProvAdrId, hscProvtelcomAdrId, hscProvSpecialtyId)
          .toPromise()
          .then((facilityResTin) => {
            console.log(facilityResTin);
            if (facilityResTin?.data.v_prov_srch.length > 0) {
              const providerData = facilityResTin?.data.v_prov_srch[0];

              this.getProviderResultsData(providerRole, providerData);
            }
          });
  }

  getProviderResultsData(providerRole: number, providerData: any): any {
    const providerResultsData = [];
    let providerDetails = {};
    // tslint:disable-next-line:prefer-for-of
    let providerState = '';
    let addressLine = '';
    const getRefCode = this.referenceService.loadRefDataByRefID(providerData.st_ref_id).toPromise();
    getRefCode.then((providerStateRes) => {
        providerState = providerStateRes?.data?.ref[0]?.ref_cd;
        this.providerSearchService.getProviderTinOrNpi(providerData.prov_id, PROVIDER_KEY_VALUE_TYP_REF_ID_TIN).toPromise().then((providerTin) => {
          this.providerTin =  providerTin?.data?.prov_key.length === 0 ? null : providerTin.data.prov_key[0].prov_key_val;

          this.providerSearchService.getProviderTinOrNpi(providerData.prov_id, PROVIDER_KEY_VALUE_TYP_REF_ID_NPI).toPromise().then((providerNpi) => {
            console.log('provider NPI');
            this.providerNpi = providerNpi.data.prov_key[0].prov_key_val;
            console.log(this.providerNpi);
            this.providerSearchService.getProviderTinOrNpi(providerData.prov_id, PROVIDER_KEY_VALUE_TYP_REF_ID_NPI).toPromise().then((providerMPIN) => {
              this.providerMPIN = providerMPIN.data.prov_key[0].prov_key_val;
              if (providerState && this.providerNpi !== '') {
              addressLine = this.getProviderAddressLine(providerData.adr_ln_1_txt, providerData.adr_ln_2_txt, providerData.cty_nm, providerState,
                providerData.zip_cd_txt);
              this.referenceService.loadRefDataByRefID(providerData.spcl_ref_id).toPromise().then((specialtydisplRes) => {
                providerData.spcl_ref_dspl = specialtydisplRes.data.ref[0].ref_dspl;
                providerDetails = {
                  businessName: providerData.bus_nm,
                  firstName: providerData.fst_nm,
                  lastName: providerData.lst_nm + ', ' + providerData.fst_nm,
                  addressLine, providerTin: this.providerTin, providerNpi: this.providerNpi,
                  prov_id: providerData.prov_id,
                  phone: providerData.telcom_adr_id,
                  specialty: providerData.spcl_ref_dspl,
                  specialtyId: providerData.spcl_ref_id,
                  locationAffiliationId: providerData.prov_loc_affil_id,
                  providerAddressId: providerData.prov_adr_id,
                  providerMPIN: this.providerMPIN,
                  providerCategoryRefId: providerData.prov_catgy_ref_id
                };
                this.setProviders(providerDetails, providerRole);
                providerResultsData.push(providerDetails);
              });
            }
          });
        });
        });
    });
    return providerResultsData[0];
  }

  setProviders(providerDetails, providerRole: number) {
    if (providerRole === ReferenceConstants.PROVIDER_ROLE_REF_ID_SUBMITTING) {
      this.submittingProviderDetails = providerDetails;
    } else if (providerRole === ReferenceConstants.PROVIDER_ROLE_REF_ID_FACILITY) {
      this.facilityProviderDetails = providerDetails;
    } else if (providerRole === ReferenceConstants.PROVIDER_ROLE_REF_ID_ATTENDING) {
      this.attendingProviderDetails = providerDetails;
    } else if (providerRole === ReferenceConstants.PROVIDER_ROLE_REF_ID_ORDERING) {
      this.orderingProviderDetails = providerDetails;
    } else if (providerRole === ReferenceConstants.PROVIDER_ROLE_REF_ID_ADMITTING) {
      this.admittingProviderDetails = providerDetails;
    }
  }

  getProviderAddressLine(adr_ln_1_txt: string, adr_ln_2_txt: string, cty_nm: string, st_ref_cd: string, zip_cd_txt: string): string {
    let addressLine = '';
    if (adr_ln_1_txt) {
      addressLine = adr_ln_1_txt;
    }
    if (adr_ln_2_txt) {
      addressLine += ', ' + adr_ln_2_txt;
    }
    if (cty_nm) {
      addressLine += ', ' + cty_nm;
    }
    if (st_ref_cd) {
      addressLine += ', ' + st_ref_cd;
    }
    if (zip_cd_txt) {
      addressLine += ', ' + zip_cd_txt;
    }
    return addressLine;

  }

}
