import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RequestInformationComponent } from './request-information.component';
import {uitkModules,uitkAngularModules} from "src/app/app.module";
import {FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators} from "@angular/forms";

describe('RequestInformationComponent', () => {
  let component: RequestInformationComponent;
  let fixture: ComponentFixture<RequestInformationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [uitkModules,uitkAngularModules, FormsModule, ReactiveFormsModule],
      declarations: [ RequestInformationComponent ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RequestInformationComponent);
    component = fixture.componentInstance;
    component.requestInformationForm = new FormGroup({
      requestTerm: new FormControl(''),
      siteOfService: new FormControl(''),
      urgency: new FormControl(''),
      requestType: new FormControl(''),
      placeOfService: new FormControl(''),
      serviceCategory: new FormControl(''),
      serviceStart: new FormControl(''),
      serviceDuration: new FormControl(''),

    });

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
