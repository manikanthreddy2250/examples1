import {Component, Input, OnInit} from '@angular/core';
import {FormGroup} from "@angular/forms";
import {requestInformationConstants} from "src/app/constants/request-information.constants";

@Component({
  selector: 'um-request-information',
  templateUrl: './request-information.component.html',
  styleUrls: ['./request-information.component.scss']
})
export class RequestInformationComponent implements OnInit {
  @Input() requestInformationForm: FormGroup;
  public requestTermOptions: any = requestInformationConstants.requestTermOptions;
  public siteOfServiceOptions: any = requestInformationConstants.siteOfServiceOptions;
  public urgencyOptions: any = requestInformationConstants.urgencyOptions;
  public requestTypes: any = requestInformationConstants.requestTypes;
  public placeOfService: any = requestInformationConstants.placeOfService;
  public serviceCategory: any = requestInformationConstants.serviceCategory;

  constructor() { }

  ngOnInit() {

  }

}
