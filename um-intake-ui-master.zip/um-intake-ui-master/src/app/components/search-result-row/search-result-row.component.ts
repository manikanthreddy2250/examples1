import {Component, Input, OnInit} from '@angular/core';

@Component({
  selector: '[app-search-result-row]',
  templateUrl: './search-result-row.component.html',
  styleUrls: ['./search-result-row.component.scss']
})
export class SearchResultRowComponent implements OnInit {

  @Input('app-search-result-row') record: any;
  expanded: boolean;
  addressLine: string;
  tableHeader = ['Group ID', 'Policy Start Date', 'Policy End Date'];
  constructor() { }

  ngOnInit(): void {
    this.expanded = false;
    if (this.record.adr_ln_1_txt) {
      this.addressLine = this.record.adr_ln_1_txt;
    }
    if (this.record.adr_ln_2_txt) {
      this.addressLine += ', ' + this.record.adr_ln_2_txt;
    }
    if (this.record.cty_nm) {
      this.addressLine += ', ' + this.record.cty_nm;
    }
    if (this.record.stateRefDesc) {
      this.addressLine += ', ' + this.record.stateRefDesc;
    }
    if (this.record.zip_cd_txt) {
      this.addressLine += ', ' + this.record.zip_cd_txt;
    }
  }
  showDetails() {
    this.expanded = !this.expanded;
  }

}
