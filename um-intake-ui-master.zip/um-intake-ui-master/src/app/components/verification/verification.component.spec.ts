import { HttpClientTestingModule } from '@angular/common/http/testing';
import {CUSTOM_ELEMENTS_SCHEMA, Injectable, NO_ERRORS_SCHEMA} from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {FormBuilder, FormArray, FormsModule, ReactiveFormsModule, Validators} from '@angular/forms';
import {BehaviorSubject, of} from 'rxjs';
import {StepperDataService} from 'src/app/services/StepperDataService/StepperDataService';
import { VerificationComponent } from './verification.component';
import { UITKPageNotificationComponent, UITKTableFeaturesModule, UITKTableModule } from '@uitk/angular';
import { uitkAngularModules, uitkModules } from 'src/app/app.module';


const authTypeForm = new FormBuilder().group({
        requestCategory: [{value: 'Inpatient'}, Validators.required],
        facilityType: [{value: 'Office'}, Validators.required],
  	    priority: [{value: 'EmrgntNonLifeThretng'}, Validators.required],
  	    serviceDescription: [{value: 'Urgent'}, Validators.required],
  	    serviceDetail: [{value: 'Hospice'}, Validators.required],
      });
@Injectable()
class MockStepperDataService {
  private stepperData = new BehaviorSubject({tenantId: 'ecpumintakebaseproductbpmgrp',
                                              hsc:
                                                {
                                                  hsc_id: 7448,
                                                  auth_end_dt: null,
                                                  auth_strt_dt: null,
                                                  auth_typ_ref_id: null,
                                                  cont_of_care_ind: null,
                                                  indv_id: 503926748,
                                                  mbr_cov_dtl: null,
                                                  mbr_cov_id: 12484,
                                                  rev_prr_ref_id: 3754,
                                                  srvc_set_ref_id: 3738,
                                                  hsc_sts_ref_id : 19274,

                                                },
                                                authorizationTypeForm: authTypeForm,
                                                hscDiagnosis: [{diag_code: '456', diag_desc: 'test'}],
                                                notesExpandRowRecords: [{author: "SYSTEM",
                                                                dateTime: "12/2/20, 10:50 AM",
                                                                note: "The Lion King ",
                                                                subject: "Test 1",
                                                                type: "Provider Comments",
                                                                viewNote: false}],
                                                serviceType: "Generic",
                                                hscDocs:[{dateTimeFormat: "12/2/20, 4:20 PM",
                                                          filename: "Image.jpg",
                                                          name: "Image.jpg",
                                                          progress: 100,
                                                          showNotes: false,
                                                          size: 1166358,
                                                          sizeFormat: "1 MB",
                                                          status: "In Progress",
                                                          type: "image/jpeg"}],
                                                hscProcedures: [{code: "80346",
                                                                description: " DRUG SCREENING BENZODIAZEPINES 1-12",
                                                                expanded: true,
                                                                hscId: "9759",
                                                                hsc_srvc_id: 8683,
                                                                index: 0,
                                                                procedureCategory: [],
                                                                procedureCounter: 1,
                                                                procedureOthrTxtSwitch: undefined,
                                                                procedureType: "CPT4",
                                                                viewDetails: false}],
                                              });
  sharedStepperData = this.stepperData.asObservable();

  constructor() { }

  setStepperData(stepperData: any) {
    this.stepperData.next(stepperData);
  }
}
describe('VerificationComponent', () => {
  let component: VerificationComponent;
  let fixture: ComponentFixture<VerificationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, UITKTableFeaturesModule,UITKTableModule,uitkAngularModules, uitkModules, FormsModule, ReactiveFormsModule],
      declarations: [ VerificationComponent ],
      providers: [{ provide: StepperDataService, useClass: MockStepperDataService }],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VerificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  afterEach(() => { fixture.destroy(); });

  afterAll(() => {
    TestBed.resetTestingModule();
});
  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('authTypeEdit() invokes', () => {
    spyOn(component.currentStepperUpdateEvent, 'emit');
    component.authTypeEdit();
    expect(component.currentStepperUpdateEvent.emit).toHaveBeenCalledWith(1);
  });

  it('diagnosisEdit() invokes', () => {
    spyOn(component.currentStepperUpdateEvent, 'emit');
    component.diagnosisEdit();
    expect(component.currentStepperUpdateEvent.emit).toHaveBeenCalledWith(2);
  });

  it('procedureEdit() invokes', () => {
    spyOn(component.currentStepperUpdateEvent, 'emit');
    component.procedureEdit();
    expect(component.currentStepperUpdateEvent.emit).toHaveBeenCalledWith(2);
  });

  it('providersEdit() invokes', () => {
    spyOn(component.currentStepperUpdateEvent, 'emit');
    component.providersEdit();
    expect(component.currentStepperUpdateEvent.emit).toHaveBeenCalledWith(3);
  });

  it('contactEdit() invokes', () => {
    spyOn(component.currentStepperUpdateEvent, 'emit');
    component.contactEdit();
    expect(component.currentStepperUpdateEvent.emit).toHaveBeenCalledWith(4);
  });

  it('documentationEdit() invokes', () => {
    spyOn(component.currentStepperUpdateEvent, 'emit');
    component.documentationEdit();
    expect(component.currentStepperUpdateEvent.emit).toHaveBeenCalledWith(5);
  });

  it('prepareProcedureOPDisply() invokes', () => {
    component.prepareProcedureOPDisply([]);
    expect(component.prepareProcedureOPDisply).toBeTruthy();
  });

  it('onExpand() invokes', () => {
    const result = [
      {code: '1255',
       description: 'radioolgy ECG'
      }
    ];
    component.onExpand(result);
    expect(component.onExpand).toBeTruthy();
  });

  it('stepperData change should refresh the verification page', () => {
    let authTypeForm = new FormBuilder().group({
      requestCategory: [{value: 'Inpatient'}, Validators.required],
      facilityType: [{value: 'Office'}, Validators.required]
    });
    component.stepperDataService.setStepperData({hsc: {srvc_set_ref_id: 3737}, hscProcedures: [{code: '123', description: 'test'}], authorizationTypeForm: authTypeForm});
//    expect(component.procedureIPOPFRecords.length).toEqual(1);
  });

   it('should  test expandnotes Function', () => {
        component.notesDataSource.data = [{dateTime: "8/3/20, 2:51 PM", type: "provider",
                 note: "trimNote", author: "ngopi2", subject:"Active"}];
        const	data = {dateTime: "8/3/20, 2:51 PM", type: "provider",
                 note: "trimNote", author: "ngopi2", subject:"Active"}
        component.expandnotes(data);
        expect(component.expandnotes).toBeTruthy();
    });

    it('should  test collapseNote Function', () => {
        const data = {dateTime: "8/3/20, 2:51 PM", type: "provider",
             note: "trimNote", author: "ngopi2", subject:"Active"};
        component.notesDataSource.data  = [{dateTime: "8/3/20, 2:51 PM", type: "provider",
             note: "trimNote", author: "ngopi2", subject:"Active"}];
        component.collapseNote(data);
        expect(component.collapseNote).toBeTruthy();
    });

});
