import {Component, EventEmitter, Input, OnDestroy, OnInit, Output,  ViewChild, AfterViewInit} from '@angular/core';
import { ITableInputModel } from '@uimf/uitk';
import {Subscription} from 'rxjs';
import {ReferenceConstants} from 'src/app/constants/referenceConstants';
import {StepperDataService} from 'src/app/services/StepperDataService/StepperDataService';
import { UITKTableModule,UITKTableSortDirective,UITKTableDataSource,IUITKColumnState,
         UITKSortDirection,IUITKTableSortState,UITKTableFeaturesModule} from '@uitk/angular';
@Component({
  selector: 'um-verification',
  templateUrl: './verification.component.html',
  styleUrls: ['./verification.component.scss']
})
export class VerificationComponent implements OnInit, OnDestroy, AfterViewInit {
  @Input() currentStepEditInfo: number;
  stepperData: any;
  @Output() currentStepperUpdateEvent = new EventEmitter<number>();
  diagnosisDataSource = new UITKTableDataSource<any>([]);
  notesDataSource = new UITKTableDataSource<any>([]);
  fileDataSource = new UITKTableDataSource<any>([]);
  procIPOPFDataSource = new UITKTableDataSource<any>([]);
  procOPDataSource = new UITKTableDataSource<any>([]);
  @ViewChild('sortTable') uitkTableSort: UITKTableSortDirective;
  @ViewChild('sortTableOne') uitkTableSortOne: UITKTableSortDirective;
  @ViewChild('sortTableTwo') uitkTableSortTwo: UITKTableSortDirective;
  @ViewChild('sortTableThree') uitkTableSortThree: UITKTableSortDirective;
  @ViewChild('sortTableProc') uitkTableSortProc: UITKTableSortDirective;
  public IP = ReferenceConstants.SERVICESETTINGTYPE_INPATIENT;
  public OP = ReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT;
  public OPF = ReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY;
  notesExpandRowRecords = [];
  procedureExpandableRecords = [];
  procedureIPOPFRecords = [];
  notesRecordcounter = 0;
  currentStepEdit: number;
  notesResultsTable = {
    title: 'Notes Results Table',
    enableSorting: true
  };
  diagnosisResultsTable = {
    title: 'Diagnosis Search Results Table',
    enableSorting: true
  };
  fileUploadResultsTable = {
    title: 'FileUpload Results Table',
    enableSorting: true
  };
  procedureResultsTable = {
    title: 'Procedure Results Table',
    enableSorting: true
  };
  procedureExpandableTable: ITableInputModel = {
    title: 'Procedure Expandable Results Table',
    enableSorting: true
  };
  diagnosisColumns: any = [
    { label: 'Code', id: 'diag_code', dataType: 'text', style: { width: '150px' } },
    { label: 'Description', id: 'diag_desc', dataType: 'text' }
  ];
  fileUploadColumns: any = [
    { label: 'Date/Time', id: 'dateTimeFormat', dataType: 'text', style: { width: '150px' } },
    { label: 'File Name', id: 'filename', dataType: 'text', style: { width: '400x' } },
    { label: 'Size', id: 'sizeFormat', dataType: 'text' }
  ];
  procedureColumns: any = [
    { label: 'Code', id: 'code', dataType: 'text', style: { width: '150px' } },
    { label: 'Description', id: 'description', dataType: 'text' }
  ];
  procedureExpandableColumns: any = [
    { label: 'Code', id: 'code', dataType: 'text', style: { width: '150px' } },
    { label: 'Description', id: 'description', dataType: 'text' },
    { label: 'Servicing Provider', id: 'servicingProvider', dataType: 'text' }
  ];
  notesColumns: any = [
    { label: 'Date/Time', id: 'dateTime', dataType: 'text', style: { width: '150px' } },
    { label: 'Subject', id: 'subject', dataType: 'text', style: { width: '200px' } },
    { label: 'Role', id: 'role', dataType: 'text', style: { width: '200px' } },
    { label: 'Author', id: 'author', dataType: 'text', style: { width: '100px' } },
  ];
  notesColumnsExpanded : any = [
        { label: 'Date/Time', id: 'dateTime', dataType: 'text', style: { width: '150px' } },
        { label: 'Subject', id: 'subject', dataType: 'text', style: { width: '200px' } },
        { label: 'Author', id: 'author', dataType: 'text', style: { width: '100px' } },
    ];
  expandedRowData: any = 'code';
  stepperDataSubscription: Subscription;
  constructor(public stepperDataService: StepperDataService) {

  }
  HSC_STATUS_TYPE_OPEN = ReferenceConstants.HSC_STATUS_TYPE_OPEN;
  HSC_STATUS_TYPE_DRAFT = ReferenceConstants.HSC_STATUS_TYPE_DRAFT;
  caseData: any;
  ngOnInit(): void {
    this.stepperDataSubscription = this.stepperDataService.sharedStepperData.subscribe((stepperData) => {
      this.stepperData = stepperData;
      const  diagnosisDisplayRecords = [];
      const  notesDisplayRecords = [];
      const  fileDisplayRecords = [];
       for (const j in this.stepperData.hscDiagnosis) {
           const record = {
             "diag_code": this.stepperData.hscDiagnosis[j].diag_code,
             "diag_desc": this.stepperData.hscDiagnosis[j].diag_desc,
           }
          diagnosisDisplayRecords.push(record);
       }
       this.diagnosisDataSource.data = diagnosisDisplayRecords;
       for (const j in this.stepperData.notesExpandRowRecords) {
            const record = {
              "dateTime": this.stepperData.notesExpandRowRecords[j].dateTime,
              "subject": this.stepperData.notesExpandRowRecords[j].subject,
              "author": this.stepperData.notesExpandRowRecords[j].author,
              "note": this.stepperData.notesExpandRowRecords[j].note,
              "viewNote": this.stepperData.notesExpandRowRecords[j].viewNote,
            }
           notesDisplayRecords.push(record);
       }
       this.notesDataSource.data = notesDisplayRecords;
       for (const j in this.stepperData.hscDocs) {
               const record = {
                 "dateTimeFormat": this.stepperData.hscDocs[j].dateTimeFormat,
                 "filename": this.stepperData.hscDocs[j].filename,
                 "sizeFormat": this.stepperData.hscDocs[j].sizeFormat,
               }
              fileDisplayRecords.push(record);
       }
       this.fileDataSource.data = fileDisplayRecords;
      this.updateCaseData();
      if (this.stepperData.hsc && this.stepperData.hscProcedures) {
        this.populateProcedureData();
      }
    });
  }

  private populateProcedureData() {
    if (this.stepperData.hsc.srvc_set_ref_id === this.OPF || this.stepperData.hsc.srvc_set_ref_id === this.IP) {
      this.procedureIPOPFRecords = this.stepperData.hscProcedures;
      this.procIPOPFDataSource.data  = this.procedureIPOPFRecords;
    } else {
      if (this.stepperData.hsc.hsc_sts_ref_id === ReferenceConstants.HSC_STATUS_TYPE_DRAFT) {
        this.prepareProcedureOPDisply(this.stepperData.hscProcedures);
      } else {
        this.procedureExpandableRecords = this.stepperData.hscProcedures ? this.stepperData.hscProcedures : [];
      }
      this.procOPDataSource.data  = this.procedureExpandableRecords;
    }
  }

  ngOnDestroy() {
    this.stepperDataSubscription.unsubscribe();
  }

  ngAfterViewInit() {
     this.diagnosisDataSource.sort = this.uitkTableSortTwo;
     this.notesDataSource.sort = this.uitkTableSortOne;
     this.fileDataSource.sort = this.uitkTableSortThree;
     //this.procIPOPFDataSource.sort = this.uitkTableSortProc;
     //this.procOPDataSource.sort = this.uitkTableSort;
  }
  onSortChange(sortState: IUITKColumnState) {}

  updateCaseData() {
    const caseData: any = {};
    const authTypeForm = this.stepperData.authorizationTypeForm;
    if (authTypeForm) {
      caseData.requestCategory = authTypeForm.get('requestCategory')?.value.value;
      caseData.priority = authTypeForm.get('priority')?.value.value;
      caseData.facilityType = authTypeForm.get('facilityType')?.value.value;
      caseData.serviceDetail = authTypeForm.get('serviceDetail')?.value.value;
      caseData.serviceDescription = authTypeForm.get('serviceDescription')?.value.value;
    }
    this.caseData = authTypeForm ? caseData : null;
  }

  authTypeEdit() {
    this.currentStepEdit = 1;
    this.currentStepperUpdateEvent.emit(this.currentStepEdit);
  }

  diagnosisEdit() {
    this.currentStepEdit = 2;
    this.currentStepperUpdateEvent.emit(this.currentStepEdit);
  }

  procedureEdit() {
    this.currentStepEdit = 2;
    this.currentStepperUpdateEvent.emit(this.currentStepEdit);
  }
  providersEdit() {
    this.currentStepEdit = 3;
    this.currentStepperUpdateEvent.emit(this.currentStepEdit);
  }
  contactEdit() {
    this.currentStepEdit = 4;
    this.currentStepperUpdateEvent.emit(this.currentStepEdit);
  }
  documentationEdit() {
    this.currentStepEdit = 5;
    this.currentStepperUpdateEvent.emit(this.currentStepEdit);
  }
  prepareProcedureOPDisply(procedureList) {
    this.procedureExpandableRecords = [];

    function buildModifiersString(hscSrvcNonFacl) {
      let modifiersStr = '';
      if (hscSrvcNonFacl?.proc_mod_1_cd) {
        modifiersStr = modifiersStr + hscSrvcNonFacl.proc_mod_1_cd.label;
      }
      if (hscSrvcNonFacl?.proc_mod_2_cd) {
        modifiersStr = modifiersStr + ' ' + hscSrvcNonFacl.proc_mod_2_cd.label;
      }
      if (hscSrvcNonFacl?.proc_mod_3_cd) {
        modifiersStr = modifiersStr + ' ' + hscSrvcNonFacl.proc_mod_3_cd.label;
      }
      if (hscSrvcNonFacl?.proc_mod_4_cd) {
        modifiersStr = modifiersStr + ' ' + hscSrvcNonFacl.proc_mod_4_cd.label;
      }
      return modifiersStr;
    }

    procedureList.forEach((element) => {
      const hscSrvcNonFacl = element.hsc_srvc_non_facls ? element.hsc_srvc_non_facls[0] : null;
      const hscSrvcNonFaclDme = hscSrvcNonFacl?.hsc_srvc_non_facl_dmes ? hscSrvcNonFacl.hsc_srvc_non_facl_dmes[0] : null;
      const procedureObject = {
        procedureType: element.proc_cd_schm_ref_id,
        code: element.code,
        description: element.description,
        servicingProvider : element.servicingProvider,
        address : element.addressLine ,
        networkStatus : '',
        specialty :  element.specialty,
        providerTin :  element.providerTin,
        phone :element.phone,
        premiumDesignation : '',
        serviceDetail: hscSrvcNonFacl?.srvc_dtl_ref_id.label,
        total: hscSrvcNonFacl?.unit_per_freq_cnt,
        measure: hscSrvcNonFacl?.proc_uom_ref_id.label,
        count: hscSrvcNonFacl?.proc_unit_cnt,
        frequency: hscSrvcNonFacl?.proc_freq_ref_id.label,
        startDate: hscSrvcNonFacl?.srvc_strt_dt,
        endDate: hscSrvcNonFacl?.srvc_end_dt,
        procedureModifiers: buildModifiersString(hscSrvcNonFacl),
        expanded: false,
        dmeType: hscSrvcNonFaclDme?.dme_procrmnt_typ_id ? hscSrvcNonFaclDme?.dme_procrmnt_typ_id === 1 ? 'Purchase' : 'Rental' : null,
        dmeCost: hscSrvcNonFaclDme?.dme_tot_cst_amt,
        dmeClinicalDesc: hscSrvcNonFaclDme?.clin_ill_desc_txt,
        dmeItemDesc: hscSrvcNonFaclDme?.spl_desc_txt,
        dmeOtherDesc: element.proc_othr_txt,
        dmeServicesDesc: hscSrvcNonFaclDme?.srvc_desc_txt
      };
      this.procedureExpandableRecords.push(procedureObject);
    });
  }
  onExpand(event) {
    console.log(event);
  }

   expandnotes(record: any){
      this.notesDataSource.data.forEach((item) => {
              if(item.subject == record.subject){
                 item.viewNote = true;
              }
        });
    }

  collapseNote(record: any){
     this.notesDataSource.data.forEach((item) => {
        if(item.subject == record.subject){
           item.viewNote = false;
        }
    });
  }

  buildDmeType(element){
      return  element.hsc_srvc_non_facls.data.hsc_srvc_non_facl_dmes.data.dme_procrmnt_typ_id === 1 ? "Purchase" : "Rental"
  }

   expandProc(record: any){
        this.procOPDataSource.data.forEach((item) => {
                if(item.description == record.description){
                   item.expanded = true;
                }
          });
   }

  collapseProc(record: any){
     this.procOPDataSource.data.forEach((item) => {
        if(item.description == record.description){
           item.expanded = false;
        }
    });
  }
}
