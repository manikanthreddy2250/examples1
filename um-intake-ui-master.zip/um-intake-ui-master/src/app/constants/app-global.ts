/**
 *  System environment variables set via Dockerfile and envsub
 */
export const SystemEnvironmentVariables = Object.freeze({
  BUILD_INFO: '${BUILD_INFO}',
  BUILD_SEPARATOR: ' | '
});
