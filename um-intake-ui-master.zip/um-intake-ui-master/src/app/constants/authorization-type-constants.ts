export class AuthTypeConstants {
  public static readonly MORE_THAN_93DAYS_IN_PAST = 'Date cannot be more than 93 days in the past.';
  public static readonly NOT_IN_COVERAGE_RANGE = 'Date cannot be outside of the Member\'s Effective/Termination Date.';
  public static readonly EXP_DISCHRG_DT_BEFORE_ADM_DT = 'Expected Discharge Date cannot be prior to Expected Admission Date.';
  public static readonly ACT_DISCHRG_DT_BEFORE_ADM_DT = 'Actual Discharge Date cannot be prior to Actual Admission Date.';
  public static readonly END_DT = 'Date cannot be prior to Start Date.';
  public static readonly START_DT = 'Date cannot be in the past';
  public static readonly DATE_CANNOT_BE_FUTURE = 'Date cannot be future';
}
