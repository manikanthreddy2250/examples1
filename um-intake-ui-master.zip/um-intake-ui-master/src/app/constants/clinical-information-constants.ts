
export class ClinicalInformationConstants {
  public static readonly FILE_STATUS_READY = 'Ready to Upload';
  public static readonly FILE_SIZE_TOO_LARGE_MSG  = 'File size too large.';
  public static readonly FILE_TYPE_INVALID_MSG = 'File type is invalid.';
  public static readonly FILE_NAME_INVALID_MSG = 'File name is invalid.';
}
