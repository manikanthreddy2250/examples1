import { Injectable } from '@angular/core';

@Injectable()
export class ConfigConstants {
  static readonly DIAGNOSIS_LIMIT_CONFIG_KEY = 'diag_count_limit';
  static readonly HSC_REVIEW_TYPE_CONFIG_KEY = 'hsc_review_type';
  static readonly INTAKE_RULES_CONFIG_KEY = 'intake_rules';
  static readonly INTAKE_WORKFLOW_CONFIG_KEY = 'intake_workflow';
  static readonly ALLOW_MULTI_SRVC_PROV_CONFIG_KEY = 'allow_mult_srvc_prov';
  static readonly ALLOWED_PROVIDER_ROLES_OP_CONFIG_KEY = 'prov_roles_OP';
  static readonly ALLOWED_PROVIDER_ROLES_IP_CONFIG_KEY = 'prov_roles_IP';
  static readonly ALLOWED_PROVIDER_ROLES_OPF_CONFIG_KEY = 'prov_roles_OPF';
  static readonly PROC_LIMIT_CONFIG_KEY = 'proc_count_limit';
  static readonly PROC_OTHRTXT_CONFIG_KEY = 'proc_othrtext';
  static readonly ATTACHMENT_CONFIG_KEY = 'attachments_config';
  static readonly ANTICIPATED_SERVICE_DATE_CONFIG_KEY = 'anticipated_service_date_review_type_';
  static readonly DEFAULT_ZIP_RADIUS_CONFIG_KEY = 'default_zip_radius';
}
