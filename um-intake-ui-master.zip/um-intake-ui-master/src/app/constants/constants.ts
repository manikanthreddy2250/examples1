import { Injectable } from '@angular/core';

@Injectable()
export class Constants {
  static readonly UM_INTAKE_UI_APP_NAME = 'um_intake_ui';
  static readonly UM_INTAKE_UI_USER_PERMISSION_PROVIDER = "provider";
  static readonly UM_INTAKE_UI_USER_PERMISSION_CLINICIAN = "clinician";
  static readonly UM_INTAKE_UI_USER_PERMISSION_ADMIN = "admin";
  static readonly ECP_ENGINEER_CLIENTID = 'ecp_engineer';
  static readonly ECP_ENGINEER_CLIENTSECRET = 'ecp_engineer';
  static readonly ECP_DEV_TOKEN_URL = 'https://dev-ecp-api.optum.com/auth/oauth/token';
  static readonly MEMBER_HEADER_KEY = 'member_header';
}
