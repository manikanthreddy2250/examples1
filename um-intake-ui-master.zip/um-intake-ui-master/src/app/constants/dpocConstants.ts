/**
 * Define global variables for DPoC here
 */
export const DpocConstants = Object.freeze({
  BASE_OCM_URL: '/ocm/',
  BASE_REST_URL: '/ocm/ui/',
  REF_NAME_PATIENT_CARE_TYPE: 'patientCareType',
  OCM_CHEMO_SERVICETYPE: 'ocmChemoServiceType',
  MEMBER_PRODUCTTYPE: 'memberProductType',
  MEMBER_STATE: 'state',
  PriorAuthPortalLP: '62',
  EVICORE_ERR_CODE : 'ERR3510',
  EVICORE_ERR_MESAAGE: '[ERR3510] The system is not available at this time. Please try again later.',
  MBM_ERR_CODE : 'ERR3511',
  MBM_ERR_MESAAGE: '[ERR3511] The system is not available at this time. Please try again later.',
  RAD_CARD_ONC_EVICORE_REDIRECTION_CONTENT: 'You are now leaving https://provider.linkhealth.com and being redirected to submit your UnitedHealthcare Radiology, Cardiology, or Oncology prior authorization or notification request. If you are not automatically redirected in five seconds, click the <b>Continue</b> button.<br><br>\
      The Link Prior Authorization and Notification Main Menu will still be available behind the new window. When you are ready to return to https://provider.linkhealth.com, simply close this window.<br><br>\
      For security purposes, if your login has been inactive for more than 30 minutes, https://provider.linkhealth.com will automatically log you off. You will need to logon again to access the website.<br><br>\
      If your Link Prior Authorization and Notification Main Menu session expires, you will not automatically be logged off the website for your UnitedHealthcare Radiology, Cardiology, or Oncology request.',
  RADIATION_THERAPY_EVICORE_REDIRECTION_CONTENT: 'You are now leaving https://provider.linkhealth.com and being redirected to submit your UnitedHealthcare Radiation Therapy prior authorization or notification request. If you are not automatically redirected in five seconds, click the <b>Continue</b> button.<br><br>\
      The Link Prior Authorization and Notification Main Menu will still be available behind the new window. When you are ready to return to https://provider.linkhealth.com, simply close this window.<br><br>\
      For security purposes, if your login has been inactive for more than 30 minutes, https://provider.linkhealth.com will automatically log you off. You will need to logon again to access the website.<br><br>\
      If your Link Prior Authorization and Notification Main Menu session expires, you will not automatically be logged off the website for your UnitedHealthcare Radiation Therapy request.',
  ONCOLOGY_EVICORE_OR_MBMNOW_REDIRECTION_CONTENT: 'You are now leaving https://provider.linkhealth.com and being redirected to submit your UnitedHealthcare Oncology prior authorization or notification request. If you are not automatically redirected in five seconds, click the <b>Continue</b> button.<br><br>\
      The Link Prior Authorization and Notification Main Menu will still be available behind the new window. When you are ready to return to https://provider.linkhealth.com, simply close this window.<br><br>\
      For security purposes, if your login has been inactive for more than 30 minutes, https://provider.linkhealth.com will automatically log you off. You will need to logon again to access the website.<br><br>\
      If your Link Prior Authorization and Notification Main Menu session expires, you will not automatically be logged off the website for your UnitedHealthcare Oncology request.',
  SPECIALTY_PHARMACY_MBMNOW_REDIRECTION_CONTENT: 'You are now leaving https://provider.linkhealth.com and being redirected to submit your UnitedHealthcare Specialty Pharmacy prior authorization or notification request. If you are not automatically redirected in five seconds, click the <b>Continue</b> button.<br><br>\
      The Link Prior Authorization and Notification Main Menu will still be available behind the new window. When you are ready to return to https://provider.linkhealth.com, simply close this window.<br><br>\
      For security purposes, if your login has been inactive for more than 30 minutes, https://provider.linkhealth.com will automatically log you off. You will need to logon again to access the website.<br><br>\
      If your Link Prior Authorization and Notification Main Menu session expires, you will not automatically be logged off the website for your UnitedHealthcare Specialty Pharmacy request.',
  DRUGCLASS_INFO_MSG: `Alpha1-Proteinase inhibitors (Aralast NP™, Glassia™, Prolastin-C™, or Zemaira®)
  Asthma (Cinqair®, Fasenra®, Nucala®, or Xolair®)
  Blood modifiers (Soliris® or Ultomiris™)
  Botulinum toxins A and B (Botox®, Dyport®, Myobloc®, or Xeomin®)
  Central Nervous System agents (Onpattro™ or Radicava™)
  Endocrine (Crysvita®, H.P. Acthar gel®)
  Enzyme deficiency (ex. Aldurazyme®, Eleprase®, Fabrazyme®, Lumizyme®, Revcovi™, Brineura etc)
  Enzyme replacement therapy for Gaucher\'s disease (Vpriv®, Cerezyme®, or ®Elelyso)
  Gonadotropin Releasing Hormone Analogs (Lupron Depot®, Triptodur®, and Zoladex® etc)
  Gene therapy (Spinraza™, Luxturna™ or Exondys-51®)
  HIV agents (Trogarzo™)
  Immune globulin ( Bivigam™, Gamunex®-C, Gammagard®, HyQvia®, Privigen®, etc)
  Immunomodulatory agents (Ilaris®, Gamifant® or Benlysta®)
  Inflammatory agents (Remicade®, Entyvio®, Ilumya™, etc)
  Multiple sclerosis agents (Ocrevus™ or Lemtrada®)
  Neutropenia (Neulasta, Zarxio, etc)
  Opioid addiction (Sublocade™ or Probuphine®)
  Sodium Hyaluronate (Hyalgan®, Supartz™, Monovisc™, etc)
  RSV Prevention (Synagis®)
  Other (Anemia, Hemophilia, Ophthalmic, Hematologic and Parsabiv®)`,
  EXTERNAL_RESOURCE_TYPE_ID: 'externalResourceTypeID',
  RESOURCE_TYPE_ID_LINK_LOGIN: 'PAANLNKDB',
  QUESTIONMARK: '?',
  EQUALS: '=',
  IDLE_TIMEOUT_IN_SECONDS: 1200000,
  SESSION_TIMEOUT_IN_SECONDS: 3000000,
  LINK_MENU_BAR_SCRIPT: 'https://cdn-stage.linkhealth.com/widgets/link-widgets.js',
  ADOBE_ANALYTICS_SCRIPT: '//assets.adobedtm.com/bff7f95d5e60a9bb1bafa9115ce25108c698418f/satelliteLib-787d52f3384fac47d7dca94f7fa5fe1e58af64d6-staging.js',
  TESTUUID: ''
});


/**
 *  System environment variables set via Dockerfile and envsub
 */
export const SystemEnvironmentVariables = Object.freeze({
  BUILD_INFO: '${BUILD_INFO}'
});
