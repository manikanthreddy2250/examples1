export class NotesConstants {
   public static readonly myCharRemaining = 'characters remaining';
   public static readonly subjectErrorMsg = 'Please Enter Subject';
   public static readonly notesErrorMessage = 'Notes are required';
   public static readonly requiredText = 'Input is required';
   public static readonly type = 'Provider comments';
}
