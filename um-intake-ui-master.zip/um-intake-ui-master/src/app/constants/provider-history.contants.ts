export const providerHistoryConsants = {
  providerAuthHistoryStaticResults : [
    {requestNumber: 'A003456782', memberName: 'Nicols, Albert', serviceSetting: 'Outpatient', serviceStartDate: '06/30/2020', serviceEndDate: '07/14/2020', status: 'Approved'},
    {requestNumber: 'A007878659', memberName: 'Davis, Emily', serviceSetting: 'Inpatient', serviceStartDate: '07/06/2020', status: 'Denied'},
    {requestNumber: 'A008640976', memberName: 'O\'Hara, Sharon', serviceSetting: 'Outpatient Facility', serviceStartDate: '07/10/2020', serviceEndDate: '07/12/2020', status: 'Denied'},
    {requestNumber: 'A008640976', memberName: 'Wlilliamson, Kevin', serviceSetting: 'Inpatient', serviceStartDate: '08/10/2020', status: 'Denied'},
    {requestNumber: 'A003983461', memberName: 'Johnson, April', serviceSetting: 'Outpatient', serviceStartDate: '08/03/2020', status: 'Denied'}
  ]
};
