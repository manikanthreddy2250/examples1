export const requestInformationConstants = {
  requestTermOptions: [
    {
      label : 'Prospestive',
      value : 'prospestive'

    }, {
      label : 'Retrospective',
      value : 'retrospective'

    }, {
      label : 'Concurrent',
      value : 'concurrent'
    },
    {
      label : 'Appeal',
      value : 'appeal'
    }
  ],
  siteOfServiceOptions: [
    {
      label : 'Outpatient',
      value : 'outpatient'

    }, {
      label : 'Inpatient',
      value : 'inpatient'

    }
  ],
  urgencyOptions:  [
    {
      label : 'Routine',
      value : 'Routine'

    }, {
      label : 'Routine Time Sensitive',
      value : 'Routine Time Sensitive'

    }, {
      label : 'Urgent',
      value : 'Urgent'
    }
  ],
  requestTypes:  [
    {id: 1, label: 'Referral', value: 'Referral'},
    {id: 2, label: 'Services', value: 'Services'},
    {id: 3, label: 'DME', value: 'DME'},
    {id: 4, label: 'Admission', value: 'Admission'}
  ],
  placeOfService: [
    {id: 1, label: 'Office', value: 'Office'},
    {id: 2, label: 'Home', value: 'Home'},
    {id: 3, label: 'Acute Hospital', value: 'Acute Hospital'},
    {id: 4, label: 'Outpatient', value: 'Outpatient'},
    {id: 4, label: 'Outpatient Facility', value: 'Outpatient Facility'}
  ],
  serviceCategory: [
    {id: 1, label: 'Behavioral', value: 'Behavioral'},
    {id: 2, label: 'Dental', value: 'Dental'},
    {id: 3, label: 'Medical', value: 'Medical'}
  ]
};
