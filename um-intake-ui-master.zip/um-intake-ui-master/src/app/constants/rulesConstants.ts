export const RulesConstants = {
    X_DMN_TENANT_ID : 'ecpumintakebaseproductdmngrp',
    X_BPM_TENANT_ID : 'ecpumintakebaseproductbpmgrp',
    X_BPM_EXTERNAL_REF_ID : '1',
    X_BPM_SOURCE : 'um_intake_ui',
    X_BPM_WORKFLOW:'workFlowStepperIds'
};
