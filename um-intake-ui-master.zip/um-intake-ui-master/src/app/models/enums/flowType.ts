export enum FlowType {
  NEW = 'new',
  EDIT = 'edit'
}
