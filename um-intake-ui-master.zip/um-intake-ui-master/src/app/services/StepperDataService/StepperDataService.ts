import {Injectable} from '@angular/core';
import {BehaviorSubject} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class StepperDataService {

  private stepperData = new BehaviorSubject({});
  sharedStepperData = this.stepperData.asObservable();

  constructor() { }

  setStepperData(stepperData: any) {
    this.stepperData.next(stepperData);
  }

}
