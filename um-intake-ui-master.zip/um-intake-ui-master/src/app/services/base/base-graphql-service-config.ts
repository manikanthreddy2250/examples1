import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {GraphqlServiceConfig} from '@ecp/gql-tk-beta';
import {Constants} from '../../constants/constants';
import {UserSessionService} from '../../shared/services/user-session/user-session.service';

export class BaseGraphQLServiceConfig implements GraphqlServiceConfig {

  http: HttpClient;
  readonly userSessionService: UserSessionService;
  readonly httpUrl: string;
  readonly wsUrl: string;
  params: any = {};

  constructor(http: HttpClient, userSessionService: UserSessionService, httpUrl: string, wsUrl: string) {
    this.http = http;
    this.userSessionService = userSessionService;
    this.httpUrl = httpUrl;
    this.wsUrl = wsUrl;

    this.params = {'content-type': 'application/json',
                   'Access-Control-Allow-Origin': '*',
                   'x-hasura-role': Constants.UM_INTAKE_UI_APP_NAME + '_' + userSessionService.getUserPermission(),
                   'Authorization': 'Bearer ' + userSessionService.getEcpToken()};

  }

}
