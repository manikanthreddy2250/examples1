import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {GraphqlService, Predicate, SqlOperator} from '@ecp/gql-tk-beta';
import {UserSessionService} from '../../shared/services/user-session/user-session.service';
import {BaseGraphQLServiceConfig} from './base-graphql-service-config';

@Injectable()
export class BaseGraphQlService extends GraphqlService {

  constructor(http: HttpClient, public readonly userSessionService: UserSessionService, httpUrl: string, wsUrl: string) {
    super(http, new BaseGraphQLServiceConfig(http, userSessionService, httpUrl, wsUrl));
  }

  protected static buildWhereClause(fieldName: string, fieldValue: any) {
    return {
      field: fieldName,
      predicate: Predicate.EQUAL,
      value: fieldValue,
      sqlOperator: SqlOperator.AND
    };
  }

}
