import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {Constants} from '../../constants/constants';
import {IUserSessionService} from '../../shared/services/user-session/interface-user-session.service';
import {UserSessionService} from '../../shared/services/user-session/user-session.service';

@Injectable()
export class BaseHttpService {

  readonly staticParams: any = { 'content-type': 'application/json' };
  readonly http: HttpClient;
  readonly userSessionService: IUserSessionService;
  httpUrl: string;
  headerParams: any = {};
  params: any = {};

  constructor(http: HttpClient, userSessionService: IUserSessionService, httpUrl: string) {
    this.http = http;
    this.userSessionService = userSessionService;
    this.httpUrl = httpUrl;
    this.headerParams = {'x-hasura-role': Constants.UM_INTAKE_UI_APP_NAME + '_' + userSessionService.getUserPermission(),
                         'Authorization': 'Bearer ' + userSessionService.getEcpToken()};
    this.params = { headers: { ...this.staticParams, ...this.headerParams } };
  }

}
