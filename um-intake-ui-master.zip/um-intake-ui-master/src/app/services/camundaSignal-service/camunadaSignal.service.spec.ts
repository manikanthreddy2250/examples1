import {async, TestBed} from '@angular/core/testing';
import {CamunadaSignalService} from './camunadaSignal.service';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import {DiagnosisSearchServiceService} from '../diagnosis-search-service/diagnosis-search-service.service';
import { CUSTOM_ELEMENTS_SCHEMA, Injectable, NO_ERRORS_SCHEMA } from '@angular/core';
import {HttpClient, HttpHandler} from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable()
class MockHttpClient {
  get(url: string) {
         if (url.includes('/activity-instances')) {
              return of({ childActivityInstances: [{ executionIds: [{}] }] });
            } else if (url.includes('/variables/completedStepIds')) {
              return of({"type":"Object","value":[1,10,2,7,8,9],"valueInfo":{"objectTypeName":"java.util.ArrayList","serializationDataFormat":"application/x-java-serialized-object"}});
            } else if (environment.PROCESS_INSTANCE_BASE_URL === url) {
              return of([{}]);
            } else {
              return of([{caseInstanceId : 345}]);
            }
  }

   post(url: string, body: any | null, options?: any) {
      switch (url) {
        case environment.WORK_FLOW_STEPPER_DMN_URL:
          return of([{ stepperIds: { value: [1, 2, 3] } }]);
        case environment.SAVE_AUTH_HTTP_FUNCTION_URL:
          return of({ hscDuplicates: [{ hsc_id: 123 }] });
        case environment.INDIVIDUAL_API:
          return of({ data: { v_indv_srch: [{}] } });
        case environment.MEMBERSHIP_API:
          return of({ data: { mbr_cov: [{}] } });
        case environment.SAVE_HSC_PROCEDURE:
          return of({ hscDuplicates: [] });
        case environment.GET_HSC_AUTH_DETAILS:
          return of({ hsc: [{hsc_id: 123}] });
        default:
          return of({});
      }
    }
}

describe('CamunadaSignalService', () => {
  let service: CamunadaSignalService;
  let http: HttpClient;
  let httphandler: HttpHandler;

  beforeEach(async(() => {
  TestBed.configureTestingModule({
    imports: [HttpClientTestingModule],
    providers: [CamunadaSignalService, { provide: HttpClient, useClass: MockHttpClient }],
    schemas: [NO_ERRORS_SCHEMA]
  });
  service = TestBed.inject(CamunadaSignalService);
  }));

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should send StepperSignal to BPM', () => {
    const camundaHeaders= {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'authorization': 'Bearer hwfiobpwbvpwvnvipvonvppvnvdfnvnpwbevwp',
      'x-bpm-cli-org-id': 'ecp',
      'x-bpm-func-role': "rules_admin",
      'x-bpm-external-ref-id': 'X_BPM_EXTERNAL_REF_ID',
      'x-bpm-source': 'X_BPM_SOURCE',
      'x-bpm-workflow': 'workflow'
    };
    service.sendStepperSignaltoBPM('123', camundaHeaders, 'signalName', {currentStep: { value: 1}});
    expect(service.sendStepperSignaltoBPM).toBeTruthy();
  });

  it('should send StepperSignal to BPM', () => {
    const camundaHeaders= {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'authorization': 'Bearer hwfiobpwbvpwvnvipvonvppvnvdfnvnpwbevwp',
      'x-bpm-cli-org-id': 'ecp',
      'x-bpm-func-role': "rules_admin",
      'x-bpm-external-ref-id': 'X_BPM_EXTERNAL_REF_ID',
      'x-bpm-source': 'X_BPM_SOURCE',
      'x-bpm-workflow': 'workflow'
    };
    service.sendStepperSignaltoProc('123', camundaHeaders,  'signalName', {currentStep: { value: 1}});
    expect(service.sendStepperSignaltoProc).toBeTruthy();
  });
});
