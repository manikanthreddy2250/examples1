import { Injectable } from '@angular/core';
import {environment} from '../../../environments/environment';
import {HttpClient} from '@angular/common/http';

const queryParameter = '?superProcessInstance=';
@Injectable({
  providedIn: 'root'
})
export class CamunadaSignalService {
  constructor(private readonly httpClient: HttpClient) {}

  public sendStepperSignaltoBPM(caseId: any, camundaHttpHeaders, signalName: string, variables: any) {
    this.httpClient.get(environment.PROCESS_INSTANCE_BASE_URL + queryParameter + caseId, {
      headers: camundaHttpHeaders
    }).subscribe((data: any) => {
      const processInstanceId = data[0].id;
      let executionId;
      this.httpClient.get(`${environment.PROCESS_INSTANCE_BASE_URL}${processInstanceId}/activity-instances`, {
        headers: camundaHttpHeaders
      }).subscribe((res: any) => {
        executionId = res.childActivityInstances[0].executionIds[0];
        const signalReqBody = {
          name: signalName,
          executionId,
          variables
        };
        this.httpClient.post(environment.SIGNAL_BPM_URL, signalReqBody, {
          headers: camundaHttpHeaders
        }).subscribe();
      });
    });
  }

  async sendStepperSignaltoProc(caseId: any, camundaHttpHeaders, signalName: string, variables: any): Promise<any> {
    const processInstanceResponse: any = await this.httpClient.get(environment.PROCESS_INSTANCE_BASE_URL + queryParameter + caseId, {
      headers: camundaHttpHeaders
    }).toPromise();
    const processInstanceId = processInstanceResponse[0].id;
    const subprocessInstanceResponse: any = await this.httpClient.get(environment.PROCESS_INSTANCE_BASE_URL + queryParameter + processInstanceId, {
      headers: camundaHttpHeaders
    }).toPromise();
    const subprocessInstanceId = subprocessInstanceResponse[0].id;
    const activityInstanceResponse: any = await this.httpClient.get(`${environment.PROCESS_INSTANCE_BASE_URL}${subprocessInstanceId}/activity-instances`, {
      headers: camundaHttpHeaders
    }).toPromise();
    const executionId = activityInstanceResponse.childActivityInstances.find((childInstances) => childInstances.name === signalName)?.executionIds[0];
    const signalReqBody = {
      name: signalName,
      executionId,
      variables
    };
    return this.httpClient.post(environment.SIGNAL_BPM_URL, signalReqBody, {
      headers: camundaHttpHeaders
    }).toPromise();
  }

}
