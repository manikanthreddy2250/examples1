import { TestBed } from '@angular/core/testing';

import { DataserviceService } from './dataservice.service';

describe('DataserviceService', () => {
  let service: DataserviceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DataserviceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should be setOption call', () => {
    service.setOption({"indv_key_val":"16440436900" , "indv_id": 12345})
    expect(service.setOption).toBeTruthy();
  });

  it('should be getOption call', () => {
    service.getOption()
    expect(service.getOption).toBeTruthy();
  });

  it('should be setSelectedRow call', () => {
    service.setSelectedRow(true)
    expect(service.setSelectedRow).toBeTruthy();
  });

  it('should be getSelectedRow call', () => {
    service.getSelectedRow()
    expect(service.getSelectedRow).toBeTruthy();
  });

  it('should set Is Selected RadioNameDobSearch call', () => {
    service.setIsSelectedRadioNameDobSearch(true)
    expect(service.setIsSelectedRadioNameDobSearch).toBeTruthy();
  });

  it('should be getIsselectedRadioNameDobSearch call', () => {
    service.getIsselectedRadioNameDobSearch()
    expect(service.getIsselectedRadioNameDobSearch).toBeTruthy();
  });

  it('should be setIsFromProviderHistory call', () => {
    service.setIsFromProviderHistory(true);
    expect(service.setIsFromProviderHistory).toBeTruthy();
  });

  it('should getIsFromProviderHistory call', () => {
    service.getIsFromProviderHistory();
    expect(service.getIsFromProviderHistory).toBeTruthy();
  });

  it('should setProviderHistoryMbrSearchData call', () => {
    service.setProviderHistoryMbrSearchData({"indv_key_val":"16440436900" , "indv_id": 12345});
    expect(service.setProviderHistoryMbrSearchData).toBeTruthy();
  });

  it('should getProviderHistoryMbrSearchData call', () => {
    service.getProviderHistoryMbrSearchData();
    expect(service.getProviderHistoryMbrSearchData).toBeTruthy();
  });
});
