import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs/Rx';
@Injectable({
  providedIn: 'root'
})
export class DataserviceService {

  private mbmshpDtls: {};
  private isFromProviderHistory: boolean;
  private providerHistoryMbrSearchData: {};
  selectedRow = true
  selectedRadioNameDobSearch = false;

  setOption(value) {
    this.mbmshpDtls = value;
  }

  getOption() {
    return this.mbmshpDtls;
  }

  setSelectedRow(value) {
    this.selectedRow = value;
  }

  getSelectedRow() {
    return this.selectedRow;
  }

  setIsFromProviderHistory(value) {
    this.isFromProviderHistory = value;
  }

  getIsFromProviderHistory() {
    return this.isFromProviderHistory;
  }

  setProviderHistoryMbrSearchData(value) {
    this.providerHistoryMbrSearchData = value;
  }

  getProviderHistoryMbrSearchData() {
    return this.providerHistoryMbrSearchData;
  }

  setIsSelectedRadioNameDobSearch(value) {
    this.selectedRadioNameDobSearch = value;
  }

  getIsselectedRadioNameDobSearch() {
    return this.selectedRadioNameDobSearch;
  }
}
