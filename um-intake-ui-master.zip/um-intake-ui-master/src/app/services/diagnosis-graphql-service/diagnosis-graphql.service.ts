import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import { getDiagnosisDetailsQuery } from 'src/app/shared/graphql/referencedomain/referenceQuery';
import {environment} from '../../../environments/environment';
import {UserSessionService} from '../../shared/services/user-session/user-session.service';
import {BaseGraphQlService} from '../base/base-graphql.service';

@Injectable({
  providedIn: 'root'
})
export class DiagnosisGraphqlService extends BaseGraphQlService {

  constructor(http: HttpClient, public readonly userSessionService: UserSessionService) {
    super(http, userSessionService, environment.REFERENCE_API, environment.REFERENCE_API);
  }

  // To get list for diagnosis code and desc from icd 10
  getDiagnosis(search: string): Observable<any> {
    const queryToExecute = {
      query: getDiagnosisDetailsQuery,
      variables: {
        search
      }
    };
    return this.rawCrudQuery(queryToExecute);
  }

}
