import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import {UserSessionService} from '../../shared/services/user-session/user-session.service';
import {BaseHttpService} from '../base/base-http.service';

@Injectable({
  providedIn: 'root'
})
export class DiagnosisSearchServiceService extends BaseHttpService {
  body = {
      queryType: 'full',
      searchMode: 'all',
      search: '',
      top: '25',
      count: 'true'
  };

  constructor(http: HttpClient, userSessionService: UserSessionService) {
    super(http, userSessionService, environment.REFERENCE_API);
  }

  public search(searchTerm): Observable<any> {
    this.body['search'] = searchTerm;
    return this.http.post(this.httpUrl, this.body, this.params).pipe();
  }
}
