import { TestBed } from '@angular/core/testing';
import { DocumentService } from './document.service';
import { HttpHandler, HttpClient } from '@angular/common/http';

describe('DocumentService', () => {
  let service: DocumentService;

  beforeEach(() => {
    TestBed.configureTestingModule({providers: [HttpClient, HttpHandler] });
    service = TestBed.inject(DocumentService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
