import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {GraphQLClient} from 'graphql-request/dist';
import { environment } from 'src/environments/environment';
import { UserSessionService } from 'src/app/shared/services/user-session/user-session.service';
import {GraphQLConfig} from "../graphql-config-service/graphql-config.service";
import { deleteHsrDocProcMutation,deleteHsrDocProcSbjMutation,
         insertHsrDocProcSbjMutation,insertHsrDocProcMutation}  from "src/app/shared/graphql/healthservicedomain/healthServiceQuery";

@Injectable({
  providedIn: 'root'
})
export class DocumentService {

  healthClient: GraphQLClient;

  constructor(public userSessionService: UserSessionService,
              private readonly graphQLConfig: GraphQLConfig) {
    this.healthClient = graphQLConfig.getHealthClient();

  }


  readonly createUserID = this.userSessionService.getUserName();
  readonly changeUserID  = this.userSessionService.getUserName();

 public executeSaveHsrDocProcMutation(document): Promise<any> {
    document.creat_user_id = this.createUserID;
    document.chg_user_id = this.changeUserID;
   const docVariables = {"docVariables": document};
   const data = this.healthClient.request(insertHsrDocProcMutation, docVariables);

   return data;
  }

  public executeSaveHsrDocProcSbjMutation(hsrDocProdId: any, hscId: any): Promise<any> {
    const docVariables = {"docVariables": {hsr_doc_proc_id: hsrDocProdId, hsr_sbj_rec_id: hscId, hsr_sbj_typ_ref_id: 19917}};
    const data = this.healthClient.request(insertHsrDocProcSbjMutation, docVariables);

    return data;
  }

  deleteHsrDocProcSbj(hsrDocProcId: bigint) {
    const docVariables = {"hsrDocProcId": hsrDocProcId};
    const data = this.healthClient.request(deleteHsrDocProcSbjMutation, docVariables);
    return data;
  }

  deleteHsrDocProc(hsrDocProcId: bigint) {
    const docVariables = {"hsrDocProcId": hsrDocProcId};
    const data = this.healthClient.request(deleteHsrDocProcMutation, docVariables);
    return data;
  }

}

