import {HttpClient, HttpHandler, HttpHeaders} from '@angular/common/http';
import {Injectable} from '@angular/core';
import { TestBed } from '@angular/core/testing';
import {of} from 'rxjs';
import {environment} from '../../../environments/environment';
import {Constants} from '../../constants/constants';
import { EcpAuthTokenService } from './ecp-auth-token.service';

@Injectable()
class MockHttpClient {
  post(url: string, body: any | null, options?: any) {
    return of('XYZ');
  }
}

describe('EcpAuthTokenService', () => {
  let service: EcpAuthTokenService;

  beforeEach(() => {
    TestBed.configureTestingModule({providers: [{provide: HttpClient, useClass: MockHttpClient}, HttpHandler]});
    service = TestBed.inject(EcpAuthTokenService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should getDistanceMatrixToken', async () => {
    const response = await service.getEcpToken();
    expect(service.getEcpToken).toBeDefined();
  });
});
