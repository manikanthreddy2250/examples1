import {HttpClient, HttpHeaders} from '@angular/common/http';
import { Injectable } from '@angular/core';
import {Observable} from 'rxjs';
import {environment} from '../../../environments/environment';
import {Constants} from '../../constants/constants';


@Injectable({
  providedIn: 'root'
})
export class EcpAuthTokenService {
  token: any;
  data: any;
  readonly ecptokenurl: string = Constants.ECP_DEV_TOKEN_URL;
  constructor(public httpClient: HttpClient) { }

  getToken(): Observable<any>  {
    const headers = {
      'Content-Type': 'application/x-www-form-urlencoded', 'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PATCH, PUT, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Origin, Content-Type, X-Auth-Token'
    }
    const body = `grant_type=client_credentials&client_id=${Constants.ECP_ENGINEER_CLIENTID}&client_secret=${Constants.ECP_ENGINEER_CLIENTSECRET}`;
    return this.httpClient.post<any>(this.ecptokenurl, body, { headers });
  }

  getEcpToken(): Observable<any> {
    const headerParamsDistMatrix = {headers: new HttpHeaders({'Content-Type': 'application/json', 'Accept': 'application/json' })};
    const paramsDistMatrix = `?grant_type=client_credentials&client_id=${Constants.ECP_ENGINEER_CLIENTID}&client_secret=${environment.ECP_CLIENT_SECRET_KEY}`;
    return this.httpClient.post(environment.ECP_TOKEN_URL + paramsDistMatrix, {}, headerParamsDistMatrix);
  }
}
