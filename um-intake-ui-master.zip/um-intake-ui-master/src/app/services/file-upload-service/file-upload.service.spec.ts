import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import { TestBed } from '@angular/core/testing';
import {of} from 'rxjs';
import { FileUploadService } from './file-upload.service';
import {SysConfigService} from "../sysconfig-service/sys-config.service";

@Injectable()
class MockHttpClient {
  post(url: string, body: any | null, options?: any) {
    return of({documentId: '123'});
  }
  delete(url: string, body: any | null, options?: any) {
    return of({documentId: '123'});
  }
}

describe('FileUploadService', () => {
  let service: FileUploadService;

  beforeEach(() => {
    TestBed.configureTestingModule({providers: [
        { provide: HttpClient, useClass: MockHttpClient }
      ]});
    service = TestBed.inject(FileUploadService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should call post method on upload', () => {
    spyOn(service.httpClient, 'post');
    const metadata = {
      "name": "test",
      "type": "jpg",
      "notes": "testing file"
    }
    service.uploadFile(new File([], "test"), metadata);
    expect(service.httpClient.post).toHaveBeenCalled();
  });

  it('should call delete method on delete', () => {
    spyOn(service.httpClient, 'delete');
    service.deleteFile(new File([], 'test'));
    expect(service.httpClient.delete).toHaveBeenCalled();
  });

  it('should run #setFiles()', async () => {
        service.setFiles('abcd');
  });

  it('should run #getFiles()', async () => {
        service.getFiles();
  });

  /*it('should call getAttachmentConfigDetails', () => {
    const service: SysConfigService = TestBed.get(SysConfigService);
    expect(service.getSysConfig).toBeDefined();
    service.getSysConfig('attachments_config');
  });*/

});
