import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { MicroProductAuthService } from '@ecp/auth-library';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
@Injectable({
  providedIn: 'root'
})
export class FileUploadService {
  params: any = {};
  headerParams: any = {};
  readonly httpUrl: string = environment.FILE_UPLOAD_API;
  HttpOptions: any;
  private uploadFiles: [];
  constructor(public httpClient: HttpClient, private microProductAuthService: MicroProductAuthService) {
    this.HttpOptions = {
      headers: new HttpHeaders({ Authorization: 'Bearer ' + microProductAuthService.getEcpToken() })
    };
  }

  uploadFile(file: File, metadata: any): Observable<any> {
    const uploadOptions = { params: new HttpParams({ fromObject: { metadata: JSON.stringify(metadata), searchTerms: '', virusScan: 'true' } }), ...this.HttpOptions };
    const formData = new FormData();
    formData.append('file', file);
    return this.httpClient.post(this.httpUrl, formData, uploadOptions);
  }

  deleteFile(file: any): Observable<any> {
    const formData = new FormData();
    formData.append('file', file);
    return this.httpClient.delete(this.httpUrl + '/' + file.doc_key_val, this.HttpOptions);
  }

  viewFile(documentId: any): Observable<any> {
    return this.httpClient.get(this.httpUrl + '/' + documentId + '?timeToLive=1000', this.HttpOptions);
  }

  setFiles(value) {
    this.uploadFiles = value;
  }
  getFiles() {
    return this.uploadFiles;
  }
}
