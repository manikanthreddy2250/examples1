import { TestBed } from '@angular/core/testing';
import {GraphQLConfig} from "./graphql-config.service";
import {HttpClient, HttpHandler} from "@angular/common/http";

describe('GraphQLConfig', () => {
  let service: GraphQLConfig;

  beforeEach(() => {
    TestBed.configureTestingModule({providers: [HttpClient, HttpHandler]});
    service = TestBed.inject(GraphQLConfig);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
