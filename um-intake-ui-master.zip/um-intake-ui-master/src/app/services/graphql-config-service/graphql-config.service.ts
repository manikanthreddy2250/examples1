import { Injectable } from '@angular/core';
import {GraphQLClient} from 'graphql-request/dist';
import {UserSessionService} from 'src/app/shared/services/user-session/user-session.service';
import {environment} from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class GraphQLConfig {

  jwtKeyHeader: any;

  constructor(private userSessionService: UserSessionService) {
    this.jwtKeyHeader = { headers: {'x-hasura-role': this.userSessionService.getUserPermission(),
                                    'Authorization': 'Bearer ' + this.userSessionService.getEcpToken()} };
  }

  getHealthClient() {
    return new GraphQLClient(environment.HEALTH_SERVICE_API, this.jwtKeyHeader);
  }

  getHsrRefClient() {
    return new GraphQLClient(environment.HEALTH_SERVICE_API, this.jwtKeyHeader);
  }

  getRefClient() {
    return new GraphQLClient(environment.REFERENCE_API, this.jwtKeyHeader);
  }

  getIndividualClient() {
    return new GraphQLClient(environment.INDIVIDUAL_API, this.jwtKeyHeader);
  }
}
