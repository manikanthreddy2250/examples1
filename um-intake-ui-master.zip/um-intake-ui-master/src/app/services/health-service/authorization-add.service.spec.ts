import { HttpClient,HttpHandler } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { ColumnValue, ReturnFields, WhereClause } from '@ecp/gql-tk-beta';
import { Observable, of, BehaviorSubject } from 'rxjs';
import {StepperDataService} from 'src/app/services/StepperDataService/StepperDataService';
import {UserSessionService} from 'src/app/shared/services/user-session/user-session.service';
import { AuthorizationAddService } from './authorization-add.service';
import { HealthGraphqlService} from './health-graphql.service';

@Injectable()
class MockHealthGraphqlService {
    update(databaseTableName: string, updateFields: ColumnValue[], filterFields: WhereClause[], returnFields?: ReturnFields): Observable<any> {
        return of({hsc_id: 1234});
    }
}

@Injectable()
class MockStepperDataService {
  private stepperData = new BehaviorSubject({tenantId: 'ecpumintakebaseproductbpmgrp',
                                              hsc:
                                                {
                                                  hsc_id: 7448,
                                                  auth_end_dt: null,
                                                  auth_strt_dt: null,
                                                  auth_typ_ref_id: null,
                                                  cont_of_care_ind: null,
                                                  indv_id: 503926748,
                                                  mbr_cov_dtl: null,
                                                  mbr_cov_id: 12484,
                                                  rev_prr_ref_id: 3754,
                                                  srvc_set_ref_id: 3738,
                                                  hsc_sts_ref_id : 19274,

                                                },
                                                authorizationTypeForm: null,
                                                hscDiagnosis: [{diag_code: '456', diag_desc: 'test'}],
                                                notesExpandRowRecords: [{author: "SYSTEM",
                                                                dateTime: "12/2/20, 10:50 AM",
                                                                note: "The Lion King ",
                                                                subject: "Test 1",
                                                                type: "Provider Comments",
                                                                viewNote: false}],
                                                serviceType: "Generic",
                                                hscDocs:[{dateTimeFormat: "12/2/20, 4:20 PM",
                                                          filename: "Image.jpg",
                                                          name: "Image.jpg",
                                                          progress: 100,
                                                          showNotes: false,
                                                          size: 1166358,
                                                          sizeFormat: "1 MB",
                                                          status: "In Progress",
                                                          type: "image/jpeg"}],
                                                hscProcedures: [{code: "80346",
                                                                description: " DRUG SCREENING BENZODIAZEPINES 1-12",
                                                                expanded: true,
                                                                hscId: "9759",
                                                                hsc_srvc_id: 8683,
                                                                index: 0,
                                                                procedureCategory: [],
                                                                procedureCounter: 1,
                                                                procedureOthrTxtSwitch: undefined,
                                                                procedureType: "CPT4",
                                                                viewDetails: false}],
                                              });
  sharedStepperData = this.stepperData.asObservable();

  constructor() { }

  setStepperData(stepperData: any) {
    this.stepperData.next(stepperData);
  }
}

describe('AuthorizationAddService', () => {

    beforeEach(() => {
    TestBed.configureTestingModule({providers: [{ provide: HealthGraphqlService, useClass: MockHealthGraphqlService }, 
                                                  { provide: StepperDataService, useClass: MockStepperDataService },
                                                    HttpClient,HttpHandler, UserSessionService, 
        ]});
    });

    it('should be created', () => {
        const service: AuthorizationAddService = TestBed.get(AuthorizationAddService);
        expect(service).toBeTruthy();
    });

    it('should call update hsc mutation on submit button ', () => {
    const service: AuthorizationAddService = TestBed.get(AuthorizationAddService);
    spyOn(service.healthGraphqlService, 'update');
    service.executeAuthorizationMutation(19580);
    expect(service.healthGraphqlService.update).toHaveBeenCalled();
    });
});
