import { Injectable } from '@angular/core';
import { ColumnValue, Predicate, SqlOperator, WhereClause } from '@ecp/gql-tk-beta';
import {ReferenceConstants} from 'src/app/constants/referenceConstants';
import {StepperDataService} from 'src/app/services/StepperDataService/StepperDataService';
import {UserSessionService} from 'src/app/shared/services/user-session/user-session.service';
import {HealthGraphqlService} from './health-graphql.service';

@Injectable({
  providedIn: 'root'
})
export class AuthorizationAddService {
  stepperData: any;

  constructor(
    public readonly healthGraphqlService: HealthGraphqlService,
    private userSessionService: UserSessionService, public stepperDataService: StepperDataService
  ) {
      this.stepperDataService.sharedStepperData.subscribe((stepperData) => this.stepperData = stepperData);
  }

  private static buildWhereClause(fieldName: string, fieldValue: any) {
    return {
      field: fieldName,
      predicate: Predicate.EQUAL,
      value: fieldValue,
      sqlOperator: SqlOperator.AND
    };
  }

  executeAuthorizationMutation = async (hscStatus: number) => {
    // Mutation Fields
    const updateFields = [];
    const changeUserID: ColumnValue = { column: 'chg_user_id', value:  this.userSessionService.getUserName()};
    const hscStatusRefID: ColumnValue = { column: 'hsc_sts_ref_id', value: hscStatus};

    updateFields.push(hscStatusRefID);
    updateFields.push(changeUserID);

    // Define Return Fields
    const fieldsToReturn = [];
    fieldsToReturn.push('hsc_id');

    const updateFilterFields: WhereClause[] = [
      AuthorizationAddService.buildWhereClause('hsc_id', this.stepperData.hscId)];

    // Set Return Fields
    const returnFields = {
      fields: fieldsToReturn
    };
    this.healthGraphqlService.update('hsc', updateFields, updateFilterFields, returnFields).subscribe(
      (result) => {
        this.stepperDataService.setStepperData({...this.stepperData, hsc: {...this.stepperData.hsc, hsc_sts_ref_id: hscStatus}, showConfirmation: true});
      },
      (error) => {
        const errorData: any = error;
      }
    );
  }
}
