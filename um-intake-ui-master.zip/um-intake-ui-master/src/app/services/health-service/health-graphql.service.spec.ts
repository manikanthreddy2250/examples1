import {HttpClient, HttpHandler} from '@angular/common/http';
import {TestBed} from '@angular/core/testing';
import {HealthGraphqlService} from './health-graphql.service';

describe('HealthGraphqlService', () => {
  beforeEach(() => TestBed.configureTestingModule(
    { providers: [HttpClient, HttpHandler] }
  ));

  it('should be created', () => {
      const service: HealthGraphqlService = TestBed.get(HealthGraphqlService);
      expect(service).toBeTruthy();
  });

  it('should get Hsc Details by Username', () => {
        const service: HealthGraphqlService = TestBed.get(HealthGraphqlService);
        service.getHscDetailsbyUserName('SYSTEM');
        expect(service.getHscDetailsbyUserName).toBeTruthy();
  });

  it('should get Hsc Details by Provider', () => {
        const service: HealthGraphqlService = TestBed.get(HealthGraphqlService);
        service.getHscDetailsbyProvider(123456, 16333);
        expect(service.getHscDetailsbyProvider).toBeTruthy();
  });

  it('should get Hsc Details by Provider', () => {
        const service: HealthGraphqlService = TestBed.get(HealthGraphqlService);
        service.getHscDetailsbyMember(16440436900);
        expect(service.getHscDetailsbyMember).toBeTruthy();
  });

});
