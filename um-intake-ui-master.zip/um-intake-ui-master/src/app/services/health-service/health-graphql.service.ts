import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { getHscDataByMemberIdQuery, getHscDataByProviderQuery,
         getHscDatabyUserNameQuery } from 'src/app/shared/graphql/healthservicedomain/healthServiceQuery';
import {UserSessionService} from 'src/app/shared/services/user-session/user-session.service';
import { environment } from '../../../environments/environment';
import {BaseGraphQlService} from '../base/base-graphql.service';

@Injectable({
  providedIn: 'root'
})

export class HealthGraphqlService extends BaseGraphQlService {

  constructor(http: HttpClient, public readonly userSessionService: UserSessionService) {
    super(http, userSessionService, environment.HEALTH_SERVICE_API, environment.HEALTH_SERVICE_API);
  }

  getHscDetailsbyUserName(userName): Observable<any> {
    const queryToExecute = {
      query: getHscDatabyUserNameQuery,
      variables: {
        userName
      }
    };
    return this.rawCrudQuery(queryToExecute);
  }

  getHscDetailsbyProvider(providerKeyVal, prov_key_typ_ref_id): Observable<any> {
    const queryToExecute = {
      query: getHscDataByProviderQuery,
      variables: {
        providerKeyVal,
        prov_key_typ_ref_id
      }
    };
    return this.rawCrudQuery(queryToExecute);
}

  getHscDetailsbyMember(indvKeyVal): Observable<any> {
    const queryToExecute = {
      query: getHscDataByMemberIdQuery,
      variables: {
        indvKeyVal
      }
    };
    return this.rawCrudQuery(queryToExecute);
  }

}
