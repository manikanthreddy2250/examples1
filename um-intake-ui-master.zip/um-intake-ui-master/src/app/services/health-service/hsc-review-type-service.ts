import { Injectable } from '@angular/core';
import { ConfigConstants } from "../../constants/configConstants";
import { ReferenceService } from 'src/app/services/refernce-service/reference.service';
import { SysConfigService } from '../sysconfig-service/sys-config.service';

@Injectable({
  providedIn: 'root'
})
export class HscReviewTypeService {

  private serviceTypes = [];

  constructor(
    private readonly referenceService: ReferenceService,
    private readonly configurationService: SysConfigService) {}

  setServiceTypes(value) {
    console.log(`set serviceTypes: ${value}`);
    this.serviceTypes = value;
  }

  getServiceTypes() {
    console.log(`get serviceTypes: ${this.serviceTypes}`);
    return this.serviceTypes;
  }

  async loadHscReviewType() {
    if (this.serviceTypes && this.serviceTypes.length > 0) {
      this.serviceTypes.splice(0, this.serviceTypes.length);
    }
    const configRes = await this.configurationService.getClientConfigByKey(ConfigConstants.HSC_REVIEW_TYPE_CONFIG_KEY).toPromise();
      let hscReviewTypeRefData = [];
      if (configRes && configRes.length > 0) {
        console.log(`hscReviewTypes: ${configRes[0].value}`);
        const configValue = JSON.parse(configRes[0].value);
        const refDataResponse = await this.referenceService.getBulkRefEntriesByRefIds(configValue.hscReviewTypeRefIds).toPromise();
        hscReviewTypeRefData = refDataResponse.data.ref;
        this.serviceTypes = this.getServiceTypesList(configValue.hscReviewTypeRefIds, hscReviewTypeRefData);
      }
    return this.serviceTypes;
  }
  
  getServiceTypesList(hscReviewTypeRefIds, hscReviewTypeRefData) {
    const serviceTypes = [];
    hscReviewTypeRefIds.forEach((hscReviewTypeRefId) => {
      const refDisplay = hscReviewTypeRefData.find((item) => item.ref_id === hscReviewTypeRefId)?.ref_dspl;
      serviceTypes.push({id: hscReviewTypeRefId, label: refDisplay, value: refDisplay});
    });
    return serviceTypes;
  }

  hasClientHscReviewTypeConfigs() {
    this.configurationService.getClientConfigByKey(ConfigConstants.HSC_REVIEW_TYPE_CONFIG_KEY).subscribe((configRes) => {
      console.log(`hscReviewTypes: ${configRes[0].value}`);
      return (configRes && configRes.length > 0);
    });
  }
}
