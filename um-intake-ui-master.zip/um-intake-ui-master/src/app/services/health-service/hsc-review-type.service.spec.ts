import { TestBed } from '@angular/core/testing';
import { HscReviewTypeService } from './hsc-review-type-service';
import {ReferenceService} from "../refernce-service/reference.service";
import {SysConfigService} from "../sysconfig-service/sys-config.service";
import {Injectable} from "@angular/core";
import {of} from "rxjs";

@Injectable()
class MockSysConfigService {
  getClientConfigByKey(key: string) {
    return of([
      {
        id: 'um_intake_ui_1.0.0_mbm_uhc_hsc_review_type_2021-02-26',
        createDateTime: '2021-02-12T21:12:29.235+00:00',
        creatUserId: null,
        changeDateTime: '2021-02-12T21:12:29.235+00:00',
        changeUserId: null,
        updateVersionNumber: '0',
        createSystemReferenceId: null,
        changeSystemReferenceId: null,
        dataSecureRuleList: null,
        dataGltyIssList: null,
        application: 'um_intake_ui',
        version: '1.0.0',
        org: 'mbm_uhc',
        role: null,
        key: 'hsc_review_type',
        value: '{"hscReviewTypeRefIds":[20401,20403,20404]}',
        startDate: '2021-02-12T00:00:00.000+00:00',
        endDate: null,
        inactivityIndicator: '0'
      }
    ]);
  }
}

@Injectable()
class MockReferenceService {
  getBulkRefEntriesByRefIds(key: any) {
    return of(
      {
        data: {
          ref: [
            {
              ref_desc: 'Cardiology',
              ref_dspl: 'Cardiology',
              ref_id: 20401
            },
            {
              ref_desc: 'Radiology',
              ref_dspl: 'Radiology',
              ref_id: 20402
            },
            {
              ref_desc: 'Radiology and Cardiology',
              ref_dspl: 'Radiology and Cardiology',
              ref_id: 20403
            }
          ]
        }
      }
    );
  }
}

describe('HscReviewTypeService', () => {
  let service: HscReviewTypeService;

  beforeEach(() => {
    TestBed.configureTestingModule( {providers: [{ provide: ReferenceService, useClass: MockReferenceService }, { provide: SysConfigService, useClass: MockSysConfigService }]} );
    service = TestBed.inject(HscReviewTypeService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should call loadHscReviewType', () => {
    service.loadHscReviewType();
    expect(service.loadHscReviewType).toBeTruthy()
  });

  it('should call loadHscReviewType', () => {
    service.setServiceTypes([
      {ref_desc: 'Cardiology', ref_dspl: 'Cardiology', ref_id: 20401},
      {ref_desc: 'Radiology', ref_dspl: 'Radiology', ref_id: 20402},
      {ref_desc: 'Radiology & Cardiology', ref_dspl: 'Radiology & Cardiology', ref_id: 20403}
    ]);
    service.loadHscReviewType();
    expect(service.loadHscReviewType).toBeTruthy()
  });

  it('should call getServiceTypesList', () => {
    const hscReviewTypeRefData = [
      {ref_desc: 'Cardiology', ref_dspl: 'Cardiology', ref_id: 20401},
      {ref_desc: 'Radiology', ref_dspl: 'Radiology', ref_id: 20402},
      {ref_desc: 'Radiology & Cardiology', ref_dspl: 'Radiology & Cardiology', ref_id: 20403}
    ];
    service.getServiceTypesList([1, 2, 3], hscReviewTypeRefData);
    expect(service.getServiceTypesList).toBeTruthy()
  });

  it('should call hasClientHscReviewTypeConfigs', () => {
    service.hasClientHscReviewTypeConfigs();
    expect(service.hasClientHscReviewTypeConfigs).toBeTruthy()
  });

  it('should call setServiceTypes', () => {
    service.setServiceTypes([{id:1, label:'Cardiology', value:'Cardiology'}, {id:2, label:'Radiology', value:'Radiology'}, {id:3, label:'Radiology & Cardiology', value:'Radiology & Cardiology'}]);
    expect(service.setServiceTypes).toBeTruthy()
  });

  it('should call getServiceTypes', () => {
    service.getServiceTypes();
    expect(service.getServiceTypes).toBeTruthy()
  });
});
