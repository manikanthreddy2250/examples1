import { Injectable } from '@angular/core';
import {AbstractControl, FormGroup, ValidationErrors, ValidatorFn} from '@angular/forms';
import * as moment from 'moment';
@Injectable({
  providedIn: 'root'
})
export class IntakeFormValidationService {

  constructor() { }

  /*
    Returns a Validator function which checks whether dateB >= dateA +1
   */
  priorDateValidator(dateAControlName: string, dateBControlName: string): ValidatorFn {
    const validationErrors = {};
    validationErrors[dateBControlName + 'isPrior'] = true;
    return (control: FormGroup): ValidationErrors | null => {
      const dateA = control.get(dateAControlName);
      const dateB = control.get(dateBControlName);
      return (dateA.value && dateB.value && !moment(dateB.value).isSameOrAfter(moment(dateA.value).add(1, 'days'))) ? validationErrors : null;
    };
  }

  /*
    Returns a Validator function which checks whether a date control value is in future
  */
  isFutureDateValidator(): ValidatorFn {
    return (control: AbstractControl): {[key: string]: any} | null => {
      return moment(control.value).isAfter(moment()) ? {isFutureDate: true} : null;
    };
  }

  /*
    Returns a Validator function which checks whether a date control value is more than the specified number of days in past
  */
  isDateInPastValidator(numberOfDays: number): ValidatorFn {
    return (control: AbstractControl): {[key: string]: any} | null => {
      return moment(control.value).isBefore(moment().subtract(numberOfDays, 'day')) ? {isDateInPast: true} : null;
    };
  }

  /*
    Returns a Validator function which checks whether a date control value falls within the given range(inclusive)
  */
  dateWithinRangeValidator(startDate: string, endDate: string): ValidatorFn {
    return (control: AbstractControl): {[key: string]: any} | null => {
      if (control.value) {
        return !moment(control.value).isBetween(moment(startDate), moment(endDate), 'days', '[]') ?  {dateNotInRange: true} : null;
      } else {
        return null;
      }
    };
  }

   /*
    Returns a Validator function which checks whether dateB >= dateA
   */
  isDateEqualOrAfter(startDate: string, endDate: string): ValidatorFn {
    const validationErrors = {};
    validationErrors[endDate + 'isPrior'] = true;
    return (control: FormGroup): ValidationErrors | null => {
      const dateA = control.get(startDate);
      const dateB = control.get(endDate);
      return (dateA.value && dateB.value && !moment(dateB.value).isSameOrAfter(moment(dateA.value))) ? validationErrors : null;
    };
  }
}
