export class InterQualReviewSaveResponse {
  public static uuid: string;
  public static reviewXml: string;
}

export class InterQualReviewRequest {
  public static procedureCode: string;
  public static reviewId: string;
}
