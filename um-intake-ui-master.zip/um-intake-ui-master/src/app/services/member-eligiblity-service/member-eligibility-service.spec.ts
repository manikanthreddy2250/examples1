import { HttpClient, HttpHandler } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import {Injectable, NO_ERRORS_SCHEMA} from '@angular/core';
import { async, TestBed } from '@angular/core/testing';
import {MicroProductAuthService} from '@ecp/auth-library';
import {IUserSessionService} from '../../shared/services/user-session/interface-user-session.service';
import {EcpAuthTokenService} from '../ecp-auth-token-service/ecp-auth-token.service';
import { MemberEligibilityService } from './member-eligibility-service';

describe('MemberServiceServiceComponent', () => {
  let service: MemberEligibilityService;
  let httpHandler: HttpHandler;
  let http: HttpClient;
  let httphandler: HttpHandler;
  let userSessionService: IUserSessionService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [MemberEligibilityService],
      schemas: [NO_ERRORS_SCHEMA]
    });
    userSessionService = new UserSessionMockServiceX();
  }));

  it('should create', () => {
    http = new HttpClient(httphandler);
    // service = new MemberEligibilityService(http);
    service = new MemberEligibilityService(http, userSessionService);
    expect(service).toBeTruthy();
  });

});

@Injectable()
class UserSessionMockServiceX implements IUserSessionService {

  constructor() {}

  readonly microProductAuthService: MicroProductAuthService;
  public readonly ecpAuthTokenService: EcpAuthTokenService;

  orgTag = 'x-ecp-cli-orgs';
  APP_NAME_PREFIX = 'um_intake_ui_';
  ECP_TOKEN_KEY = 'ecp_token';
  ACTIVE_ORG_ROLE_KEY = 'active_org_role';
  ACTIVE_ORG_ROLE_VALUE = '["ecp", "engineer"]';

  getVarData() {
    return null;
  }

  getLocalEcpToken() {
    return null;
  }
  getUserName() {
    return 'userName';
  }
  getUserOrg() {
    return 'ecp';
  }
  getUserPermission() {
    return 'userPermission';
  }

  getEcpToken() {
    return 'ecpToken';
  }
  getFunctionalRole() {
    return 'functionalRole';
  }
}
