import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {environment} from '../../../environments/environment';
import {getMembershipDetailsByMemberCoverageIdQuery} from '../../shared/graphql/membershipDomain/membershipQuery';
import {UserSessionService} from '../../shared/services/user-session/user-session.service';
import {BaseGraphQlService} from '../base/base-graphql.service';

@Injectable({
  providedIn: 'root'
})

export class MemberEligibilityService extends BaseGraphQlService {

  constructor(http: HttpClient, public readonly userSessionService: UserSessionService) {
    super(http, userSessionService, environment.MEMBERSHIP_API, environment.MEMBERSHIP_API);
  }

  public returnSearch(mbr_cov_id): Observable<any> {
    const queryToExecute = {
      query: getMembershipDetailsByMemberCoverageIdQuery,
      variables: {
        mbr_cov_id
      }
    };
    return this.rawCrudQuery(queryToExecute);
  }
}
