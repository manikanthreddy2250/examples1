import { HttpClient } from '@angular/common/http';

import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import { getIndvDataQuery, getIndvDetailsByIndvkeyIDQuery } from 'src/app/shared/graphql/individualdomain/individualQuery';
import {UserSessionService} from 'src/app/shared/services/user-session/user-session.service';
import {environment} from 'src/environments/environment';
import {BaseGraphQlService} from '../base/base-graphql.service';

@Injectable({
  providedIn: 'root'
})

export class IndividualSearchGraphqlService extends BaseGraphQlService {

  constructor(http: HttpClient, public readonly userSessionService: UserSessionService) {
    super(http, userSessionService, environment.INDIVIDUAL_API, environment.INDIVIDUAL_API);
  }

  getMemberDetails(memberId: string, firstName: string, lastName: string, dob: string): Observable<any> {
    const queryToExecute = {
      query: getIndvDataQuery,
      variables: { memberId, firstName , lastName, dob }
    };
    return this.rawCrudQuery(queryToExecute);
  }

  searchIndividual(memberId: string, firstName: string, lastName: string, dob: string): Observable<any> {
    const queryToExecute = {
      query: getIndvDataQuery,
      variables: {
        memberId,
        firstName,
        lastName,
        dob
      }
    };
    return this.rawCrudQuery(queryToExecute);
  }

  getIndividualKeysData(individualIds): Observable<any> {
    const queryToExecute = {
      query: getIndvDetailsByIndvkeyIDQuery,
      variables: {
        individualIds
      }
    };
    return this.rawCrudQuery(queryToExecute);
  }

}
