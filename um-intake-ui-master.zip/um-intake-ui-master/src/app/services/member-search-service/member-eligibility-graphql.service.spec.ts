import {TestBed} from '@angular/core/testing';
import {HttpClient, HttpHandler} from "@angular/common/http";
import {MemberShipService} from './member-eligibility-graphql.service';

describe('MemberShipService', () => {
  beforeEach(() => TestBed.configureTestingModule(
    { providers: [HttpClient, HttpHandler] }
  ));

  it('should be created', () => {
      const service: MemberShipService = TestBed.get(MemberShipService);
      expect(service).toBeTruthy();
  });

  it('should get member deatils ', () => {
        const service: MemberShipService = TestBed.get(MemberShipService);
        expect(service.getMembrshipData).toBeDefined();
  	  service.getMembrshipData('1234','fname');
    });
});
