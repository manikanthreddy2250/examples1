import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import { getMembershipDetailsByOrgIdQuery , IDSearchQuery } from 'src/app/shared/graphql/membershipDomain/membershipQuery';
import { environment } from '../../../environments/environment';
import {UserSessionService} from '../../shared/services/user-session/user-session.service';
import {BaseGraphQlService} from '../base/base-graphql.service';


@Injectable({
  providedIn: 'root'
})

export class MemberShipService extends BaseGraphQlService {

  constructor(http: HttpClient, public readonly userSessionService: UserSessionService) {
    super(http, userSessionService, environment.MEMBERSHIP_API, environment.MEMBERSHIP_API);
  }

  getMembrshipData(orgSysMbrIds, orgSysCodes): Observable<any> {
    const queryToExecute = {
      query: IDSearchQuery,
      variables: {
        orgSysMbrIds,
        orgSysCodes
      }
    };
    return this.rawCrudQuery(queryToExecute);
  }

  getMembrshipPCPData(originalSystemMemberId: string): Observable<any> {
    const queryToExecute = {
      query: getMembershipDetailsByOrgIdQuery,
      variables: {
        originalSystemMemberId
      }
    };
    return this.rawCrudQuery(queryToExecute);
  }

}
