import {TestBed} from '@angular/core/testing';
import {HttpClient, HttpHandler} from "@angular/common/http";
import {MemberSearchServiceGraphql} from './member-search-graphql.service';

describe('MemberSearchService', () => {
  beforeEach(() => TestBed.configureTestingModule(
    { providers: [HttpClient, HttpHandler] }
  ));

  it('should be created', () => {
      const service: MemberSearchServiceGraphql = TestBed.get(MemberSearchServiceGraphql);
      expect(service).toBeTruthy();
  });

  it('should get member deatils ', () => {
      const service: MemberSearchServiceGraphql = TestBed.get(MemberSearchServiceGraphql);
      expect(service.getMemberDetails).toBeDefined();
	  service.getMemberDetails('1234','fname','lname','21-03-1997');
  });

  it('should search Individual deatils ', () => {
      const service: MemberSearchServiceGraphql = TestBed.get(MemberSearchServiceGraphql);
      expect(service.searchIndividual).toBeDefined();
	  service.searchIndividual('1234','fname','lname','21-03-1997');
  });

  it('should search Individual deatils ', () => {
        const service: MemberSearchServiceGraphql = TestBed.get(MemberSearchServiceGraphql);
        expect(service.getIndividualKeysData).toBeDefined();
  	  service.getIndividualKeysData('1234');
  });

  it('should get Member Deatils by IndvId ', () => {
      const service: MemberSearchServiceGraphql = TestBed.get(MemberSearchServiceGraphql);
      expect(service.getMemberDeatilsbyIndvId).toBeDefined();
      service.getMemberDeatilsbyIndvId('16440436900');
  });

});
