import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import {getIndvDetailsByIndvKey} from '../../shared/graphql/individualdomain/individualQuery';
import {UserSessionService} from '../../shared/services/user-session/user-session.service';
import {BaseGraphQlService} from '../base/base-graphql.service';

@Injectable({
  providedIn: 'root'
})
export class MemberSearchServiceGraphqlConfig extends BaseGraphQlService {

  constructor(http: HttpClient, public readonly userSessionService: UserSessionService) {
    super(http, userSessionService, environment.INDIVIDUAL_API, environment.INDIVIDUAL_API);
  }

  public returnSearch(indv_key_val): Observable<any> {
    const queryToExecute = {
      query: getIndvDetailsByIndvKey,
      variables: {
        indv_key_val
      }
    };
    return this.rawCrudQuery(queryToExecute);
  }
}
