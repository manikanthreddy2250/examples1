/*
import {TestBed} from '@angular/core/testing';
import {HttpClient, HttpHandler} from "@angular/common/http";
import {MemberSearchServiceGraphql} from './member-search-graphql.service';
import {MemberSearchService} from './member-search.service';
fdescribe('MemberSearchService', () => {
  beforeEach(() => TestBed.configureTestingModule(
    { providers: [HttpClient, HttpHandler] }
  ));

  it('should be created', () => {
      const service: MemberSearchService = TestBed.get(MemberSearchService);
      expect(service).toBeTruthy();
  });
});
*/
