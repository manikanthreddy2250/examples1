import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {
  RawQuery,
} from '@ecp/gql-tk-beta';
import { Observable } from 'rxjs';
import { ReferenceService } from 'src/app/services/refernce-service/reference.service';
import { MemberSearchServiceGraphql } from 'src/app/services/member-search-service/member-search-graphql.service';
import { MemberShipService } from 'src/app/services/member-search-service/member-eligibility-graphql.service';
@Injectable({
  providedIn: 'root'
})
export class MemberSearchService {

  memberSearchRefData: any;

  constructor(
    private readonly memberSearchServiceGraphql: MemberSearchServiceGraphql,
    private readonly memberShipService: MemberShipService,
    private readonly referenceService: ReferenceService) { }

  /*
  queries individual and membership domains to map individuals along with their active memberships
 */
  async getIndividuals(memberId: string, firstName: string, lastName: string, dob: string, groupId: string): Promise<any> {
    let individuals = [];
    let indvIDs = [];
    let indvMbrshipMap = [];
    await this.referenceService.loadRefDisplayData().toPromise().then((res) =>
      this.memberSearchRefData = res.data.ref
    )
    await this.memberSearchServiceGraphql.searchIndividual(memberId, firstName, lastName, dob)
      .toPromise()
      .then((res) =>
        individuals = res.data.v_indv_srch);
    individuals.forEach((ind) => {
      ind['genderDesc'] = ind['gdr_ref_id'] ? this.getRefDisplayValueForMemberSearch(ind['gdr_ref_id']) : null;
      ind['stateRefDesc'] = ind['st_ref_id'] ? this.getRefDisplayValueForMemberSearch(ind['st_ref_id']) : null;
      indvIDs.push(ind.indv_id);
    });
    await this.mapActiveMemberships(indvIDs, indvMbrshipMap, individuals);
    // filter out individuals if there are no active memberships
    let activeMbrshpIndvls = individuals.filter((ind) => {
      return ind.memberships && ind.memberships.length > 0;
    });
    // filter by groupID if exists
    if (groupId) {
      let filteredIndividuals = [];
      filteredIndividuals = activeMbrshpIndvls.filter((indv) => {
        let filteredMbrships = indv.memberships.filter((mbrshp) => {
          return mbrshp.mbrshpData.active_mbr_cov.pol_nbr === groupId;
        });
        indv.memberships = filteredMbrships;
        return filteredMbrships.length > 0 ? true : false;
      });
      return filteredIndividuals;
    }
    return activeMbrshpIndvls;
  }

  private async mapActiveMemberships(indvIDs, indvMbrshipMap, individuals) {
    await this.getMembershipDetails(indvIDs)
      .then((res) => indvMbrshipMap = res);
    individuals.forEach((ind) => {
      let memberships = indvMbrshipMap.filter((element) => {
        return (element.indv_id === ind.indv_id && ind.indv_key_val === element.mbrshpData.orig_sys_mbr_id);
      });
      ind.memberships = memberships ? memberships : null;
    });
  }

  // searchIndividual(memberId: string, firstName: string, lastName: string, dob: string): Observable<any> {
  //   return this.http.post(this.indHttpUrl, JSON.stringify(this.getIndvSearchQuery(memberId, firstName, lastName, dob)), this.indParams);
  // }

  async getMembershipDetails(individualIds): Promise<any> {
    let indvKeyData = [];
    let indvMbrshipMap = [];
    let memberShipData = [];
    let activeMemberShipData;
    await this.memberSearchServiceGraphql.getIndividualKeysData(individualIds)
      .toPromise()
      .then((res) => {
        indvKeyData = res.data.indv_key;
      });
    const orgSysMbrIds = indvKeyData.map((obj) => obj['indv_key_val']);
    const orgSysCodes = indvKeyData.map((obj) => obj['orig_sys_cd']);
    if (orgSysMbrIds && orgSysMbrIds.length > 0) {
      const mbrshipResponseData = await this.memberShipService.getMembrshipData(orgSysMbrIds, orgSysCodes)
        .toPromise()
        .then((res) => {
          memberShipData = res.data.mbrshp;
        });
    }
    // filter out inactive memberships
    if (memberShipData && memberShipData.length > 0) {
      activeMemberShipData = memberShipData.filter((element) => {
        if (element['mbr_covs'] && element['mbr_covs'].length > 0 && this.getActiveMbrCoverage(element['mbr_covs'])) {

          return true;
        }
        return false;
      });
    }
    this.processIndvMembershipMapping(indvKeyData, activeMemberShipData, indvMbrshipMap);
    return indvMbrshipMap;
  }

  getActiveMbrCoverage = (memberCovDetails: any): any => {
    let filteredMemberCovs;
    let activeMemberCovs;
    filteredMemberCovs = memberCovDetails.filter((record) => {
      this.bindCoveragetypeDesc(record)
      if (record['cov_eff_dt'] != null && record['cov_end_dt'] != null) {
        return new Date(record['cov_eff_dt']) <= new Date() && new Date(record['cov_end_dt']) >= new Date();
      } else {
        if (record['cov_eff_dt'] == null) {
          return false;
        } else {
          return new Date(record['cov_eff_dt']) <= new Date();
        }
      }
    });
    if (filteredMemberCovs && filteredMemberCovs.length > 0) {
      filteredMemberCovs.sort((a, b) => (a.mbr_cov_id > b.mbr_cov_id) ? 1 : -1);
      //activeMemberCov = filteredMemberCovs[0];
      activeMemberCovs = filteredMemberCovs;
    }
    return activeMemberCovs;
  }
  bindCoveragetypeDesc(record) {
    record['coverageTypeDesc'] = record['cov_typ_ref_id'] ? this.getRefDisplayValueForMemberSearch(record['cov_typ_ref_id']) : null;
    record['productCatgyTpe'] = record['prdct_catgy_ref_id'] ? this.getRefDisplayValueForMemberSearch(record['prdct_catgy_ref_id']) : null;
  }
  processIndvMembershipMapping = (indvKeyData, memberShipData, indvMbrshipMap) => {
    indvKeyData.forEach((indKey) => {
      const filteredMembershipData = memberShipData.filter((record) => {
        return record['orig_sys_mbr_id'] === indKey['indv_key_val'] && record['orig_sys_cd'] === indKey['orig_sys_cd'];
      });
      if (filteredMembershipData && filteredMembershipData.length > 0) {
        filteredMembershipData[0]['active_mbr_covs'] = this.getActiveMbrCoverage(filteredMembershipData[0]['mbr_covs']);
        const indMbrshipObj = { indv_id: indKey['indv_id'], mbrshpData: filteredMembershipData[0] };
        indvMbrshipMap.push(indMbrshipObj);
      }
    });
  }

  // getIndividualKeysData(individualIds): Observable<any> {
  //   return this.http.post(this.indHttpUrl, JSON.stringify(this.getIndividualKeysByIds(individualIds)), this.indParams);
  // }

  // getMembrshipData(orgSysMbrIds, orgSysCodes): Observable<any> {
  //   return this.http.post(this.memHttpUrl, JSON.stringify(this.getMembershipQuery(orgSysMbrIds, orgSysCodes)), this.memParams);
  // }

  getRefDisplayValueForMemberSearch = (refCode): string => {
    if (refCode) {
      const refData = this.memberSearchRefData.filter((record) => {
        return record['ref_id'] === refCode;
      });
      return refData[0] ? refData[0]['ref_dspl'] : 'Unknown';
    } else {
      return null;
    }
  }

}
