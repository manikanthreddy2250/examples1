import {TestBed} from '@angular/core/testing';
import {HttpClient, HttpHandler} from "@angular/common/http";
import {NotesGraphqlService} from './notes-graphql.service';

describe('NotesGraphqlService', () => {
  beforeEach(() => TestBed.configureTestingModule(
    { providers: [HttpClient, HttpHandler] }
  ));

  it('should be created', () => {
    const service: NotesGraphqlService = TestBed.get(NotesGraphqlService);
    expect(service).toBeTruthy();
  });

  it('should have get notes', () => {
    const hscId = "123"
    const service: NotesGraphqlService = TestBed.get(NotesGraphqlService);
    expect(service.getNotesList).toBeDefined();
    service.getNotesList(hscId);
  });

  it('should have get note Id', () => {
    const service: NotesGraphqlService = TestBed.get(NotesGraphqlService);
    expect(service.getNoteID).toBeDefined();
    service.getNoteID('104','note', 'author');
  });

  it('should have create Note', () => {
    const service: NotesGraphqlService = TestBed.get(NotesGraphqlService);
    expect(service.createNote).toBeDefined();
    service.createNote('104', '107', 'simple text', 'sample',104,'text');
  });

  it('should have create Note SBJ', () => {
    const service: NotesGraphqlService = TestBed.get(NotesGraphqlService);
    expect(service.createNoteSbj).toBeDefined();
    service.createNoteSbj(BigInt(123));
  });

  it('should have update Note SBJ', () => {
    const service: NotesGraphqlService = TestBed.get(NotesGraphqlService);
    expect(service.updateNoteSbj).toBeDefined();
    service.updateNoteSbj(BigInt(123));
  });

  it('should have delete Note', () => {
    const service: NotesGraphqlService = TestBed.get(NotesGraphqlService);
    expect(service.deleteNote).toBeDefined();
    service.deleteNote('Provider comments', 'simple text', 'sample');
  });
});
