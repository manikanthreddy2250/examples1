import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {environment} from 'src/environments/environment';

import {
  ColumnValue,
  CreateFields,
  FilterFieldsModel,
  ReturnFields,
  WhereClause
} from '@ecp/gql-tk-beta';
import {
  getHscDatabyUserNameQuery,
  getNotesDataByHscId,
  getNotesDataByRole,
  getNotesSubjectQuery
} from 'src/app/shared/graphql/healthservicedomain/healthServiceQuery';
import {UserSessionService} from 'src/app/shared/services/user-session/user-session.service';
import {BaseGraphQlService} from '../base/base-graphql.service';

@Injectable({
  providedIn: 'root'
})

export class NotesGraphqlService extends BaseGraphQlService {

  constructor(http: HttpClient, public readonly userSessionService: UserSessionService) {
    super(http, userSessionService, environment.HEALTH_SERVICE_API, environment.HEALTH_SERVICE_API);
  }

  private readonly _noteReturnFields: ReturnFields = {
    fields: ['hsr_note_id', 'creat_user_id', 'creat_dttm', 'note_txt_lobj', 'src_rec_guid']
  };

  private readonly _returnNotesId: ReturnFields = {
    fields: ['hsr_note_id']
  };

  getNotesList(hsc_Id): Observable<any> {
    const queryToExecute = {
      query: getNotesDataByHscId,
      variables: { hsc_Id}
    };
    return this.rawCrudQuery(queryToExecute);
  }

  getNotesListReviewer(): Observable<any> {
    const queryToExecute = {
      query: getNotesSubjectQuery,
      variables: {
        inActive: 0
      }
    };
    return this.rawCrudQuery(queryToExecute);
  }

  getNotesListAdmin(authorRole: string): Observable<any> {
    const queryToExecute = {
      query: getNotesDataByRole,
      variables: {
        testAuthorRole: authorRole , inActive: 0
      }
    };
    return this.rawCrudQuery(queryToExecute);
  }

  getNoteID(type: string, note: string, authorId: string): Observable<any> {
    const filterFields: FilterFieldsModel = {
      whereClauses: [
        NotesGraphqlService.buildWhereClause('note_txt_lobj', note),
        NotesGraphqlService.buildWhereClause('creat_user_id', authorId),
      ]
    };
    return this.read('hsr_note', filterFields, this._returnNotesId, false);
  }

  createNote(type: string, note: string, authorId: string, authorRole: string, typeN: number, subject: string) {
    const createFields: CreateFields[] = [{ fields: [
      { column: 'note_txt_lobj', value: note },
      { column: 'src_user_nm', value: authorRole },
      { column: 'note_typ_ref_id', value: typeN },
      { column: 'creat_user_id', value: authorId },
      { column: 'src_rec_guid', value: subject }], children: [] }];

    return this.create('hsr_note', createFields, null, this._noteReturnFields);

  }

  createNoteSbj(noteId: bigint) {
    const createFields: CreateFields[] = [{ fields: [
        { column: 'hsr_note_id', value: noteId },
        { column: 'note_sbj_rec_id', value: 'rec_id' },
        { column: 'note_sbj_typ_ref_id', value: 1 },
        { column: 'inac_ind', value: 0 }],  children: [] }];

    return this.create('hsr_note_sbj', createFields, null, null);

  }

  updateNoteSbj(noteId: bigint) {
    const updateFilterFields: ColumnValue[] = [{ column: 'inac_ind', value: 1 }];
    const filterFields: WhereClause[] = [
      NotesGraphqlService.buildWhereClause('hsr_note_id', noteId)];

    return this.update('hsr_note_sbj', updateFilterFields, filterFields, null);

  }

  // Not used, as every thing is only soft delete
  deleteNote(type: string, note: string, authorId: string) {
    const deleteFilterFields: WhereClause[] = [
      NotesGraphqlService.buildWhereClause('note_txt_lobj', note),
        NotesGraphqlService.buildWhereClause('creat_user_id', authorId)];
    return this.delete('hsr_note', deleteFilterFields, this._noteReturnFields);

  }
}
