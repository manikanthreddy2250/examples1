import { Injectable } from '@angular/core';
import gql from 'graphql-tag';

@Injectable({
  providedIn: 'root'
})
export class NoteserviceService {

  constructor() {
    console.log("*********Noteservice is loaded ********")
   }

    ADD_NOTES = gql`
     mutation insert_care_mgt_note($objects: [care_mgt_note_insert_input!]!){
       insert_care_mgt_note(objects: $objects){
         returning {
           care_mgt_note_id
           creat_dttm
           creat_user_id
           indv_id
           note_txt_lobj
           src_user_nm
         }
       }
     }`;


    GetNotes = gql`
   query MyQuery {
     care_mgt_note(order_by: {creat_dttm: desc}, limit: 10) {
       care_mgt_note_id
       indv_id
       note_catgy_ref_id
       note_txt_lobj
       note_typ_ref_id
       src_user_nm
       src_rec_guid
       creat_user_id
       creat_dttm
     }
   }`;


  GetQuery = gql`
  query MyQuery {
    care_mgt_note(order_by: {creat_dttm: desc}, limit: 10) {
      care_mgt_note_id
      indv_id
      note_catgy_ref_id
      note_txt_lobj
      note_typ_ref_id
      src_user_nm
      src_rec_guid
      creat_user_id
      creat_dttm
    }
  }`;

  AddMutation = gql`
  mutation addNotes {
    insert_care_mgt_note(objects: {creat_user_id: "NGOPI2", indv_id: "1524072", note_txt_lobj: "UM Notes", src_user_nm: "UM Based Products"}) {
      affected_rows
      returning {
        care_mgt_note_id
        creat_dttm
        creat_user_id
        indv_id
        note_txt_lobj
        src_user_nm
      }
    }
  }`;

  AddNoteMutation = gql`
  mutation insert_care_mgt_note($objects: [care_mgt_note_insert_input!]!){
    insert_care_mgt_note(objects: $objects){
      returning {
        care_mgt_note_id
        creat_dttm
        creat_user_id
        indv_id
        note_txt_lobj
        src_user_nm
      }
    }
  }`;
}
