// import { TestBed } from "@angular/core/testing";
//
// import { OutboundSsoService } from "./member-search.service";
//
// describe("OutboundSsoService", () => {
//   beforeEach(() => TestBed.configureTestingModule({}));
//
//   it("should be created", () => {
//     const service: OutboundSsoService = TestBed.get(OutboundSsoService);
//     expect(service).toBeTruthy();
//   });
// });
