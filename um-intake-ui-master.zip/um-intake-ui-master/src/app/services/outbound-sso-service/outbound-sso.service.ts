import {EventEmitter, Injectable, Output} from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {Router} from '@angular/router';
import {DomSanitizer, SafeResourceUrl} from '@angular/platform-browser';
import {Overlay} from '@angular/cdk/overlay';
import {DpocConstants} from 'src/app/constants/dpocConstants';
import Timer = NodeJS.Timer;
import { OutboundSsoComponent } from 'src/app/components/guidelines/outbound-sso/outbound-sso.component';
import { MatDialog } from '@angular/material/dialog';

@Injectable({
  providedIn: 'root'
})
export class OutboundSsoService {

  @Output() PingFederateSerResult = new EventEmitter()
  public priorAuthSSOData: any;
  public url: string;
  public urlSafe: SafeResourceUrl;
  public timer: any = 0;
  private redirectContent: string;

  constructor(private router: Router,
              private http: HttpClient,
              private sanitizer: DomSanitizer,
              private dialog: MatDialog,
              private overlay: Overlay
  ) {
  }

  public ssoToIQ() {
    this.router.navigateByUrl('app2/redirectToIQ');
  }
}
