import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot } from "@angular/router";
import { PriorAuthorizationService } from "./prior-authorization.service";
import { Injectable } from "@angular/core";
/**
 * Prevents UI router from going to any route without a user logging in first
 * Handles routing to legacy AngularJS app
 */
@Injectable({
    providedIn: 'root'
  })
  
export class PriorAuthorizationGuardService implements CanActivate {
    private priorAuthorizationService;
    constructor(priorAuthorizationService: PriorAuthorizationService){};
    /**
     * Checks if user is already logged in/session is valid, if not they are redirected to the login page
     * @param {ActivatedRouteSnapshot} route
     * @param {RouterStateSnapshot} state
     * @return {boolean}
     */
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean{
        return;
    };
}
