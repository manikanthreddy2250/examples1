import { Observable } from 'rxjs/Rx';
import { Router } from "@angular/router";
import { LocalStorageService } from "angular-2-local-storage";
import { Injectable } from '@angular/core';
import {Inject} from '@angular/core';

@Injectable({
    providedIn: 'root'
  })
  
export  class PriorAuthorizationService {
    private localStorageService;
    private router;
    private loggedIn;
    constructor(localStorageService: LocalStorageService, router: Router){};
    // constructor(router: Router){};
    /**
     * localStorage data is set to keep a user in context when hard refreshing
     * @param embedded
     */
    setSSOStorageData(embedded: any): void{

    }
    /**
     * This is to update the stored sso storage data
     * @param embedded
     */
    updateSSOStorageData(embedded: any): void{

    }
    /**
     * getting localStorage data
     *
     */
    getSSOStorageData(): any{

    }
    /**
     * Adds token to localStorage, later used to determine if the user is logged in
     * @param {string} sessionToken
     */
    addAuthorizationToStorage(sessionToken: string): void{

    }
    /**
     * Extend Authorization Time in local storage to current timestamp
     */
    extendAuthorizationTime(): void{
        
    }
    /**
     * checks if the current user is logged in
     * @return {Observable}
     */
    isLoggedInAsync(): Observable<boolean>{
        return;
    };
    /**
     * checks if the current user is logged in
     * @return {boolean}
     */
    isLoggedIn(): boolean{
        return;
    }
    /**
     * Check if current time is before authorization timestamp plus 30 minutes
     */
    isAuthTimeLikelyValid(): boolean{
        return;
    }
    /**
     * Invalids session, clears client side data, optionally redirects to login page
     * @param {boolean} redirect
     * @return {Subscription}
     */
    logout(redirect?: boolean): void{
        return;
    }
}
