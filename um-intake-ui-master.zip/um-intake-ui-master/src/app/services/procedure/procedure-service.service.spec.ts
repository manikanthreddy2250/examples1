import { DatePipe } from '@angular/common';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import { UITKPageNotificationService } from '@uitk/angular';
import { ProcedureServiceService } from './procedure-service.service';
import {StepperDataService} from 'src/app/services/StepperDataService/StepperDataService';
import {Injectable} from '@angular/core';
import {BehaviorSubject, Observable, of} from 'rxjs';
import {UserSessionService} from '../../shared/services/user-session/user-session.service';
import {UmIntakeFuncGraphqlService} from '../um-intake-functions/umintakefunc-graphql.service';
import {environment} from "../../../environments/environment";

@Injectable()
class MockStepperDataService {
  private stepperData = new BehaviorSubject({tenantId: 'ecpumintakebaseproductbpmgrp',  hsc:
      {
        hsc_id: 7448,
        auth_end_dt: null,
        auth_strt_dt: null,
        auth_typ_ref_id: null,
        cont_of_care_ind: null,
        indv_id: 503926748,
        mbr_cov_dtl: null,
        mbr_cov_id: 12484,
        rev_prr_ref_id: 3754,
        srvc_set_ref_id: 3738,
        hsc_sts_ref_id : 19274
      },
      selectedMember:{
        coverage:{
          cov_typ_ref_id: 123
        }
      },
      hscProcedures: [{code: "80346",
        description: " DRUG SCREENING BENZODIAZEPINES 1-12",
        expanded: true,
        hscId: "9759",
        hsc_srvc_id: 8683,
        index: 0,
        hsc_srvc_non_facls: [],
        proc_othr_txt: "test",
        procedureCategory: [],
        procedureCounter: 1,
        procedureOthrTxtSwitch: undefined,
        procedureType: "CPT4",
        viewDetails: false}]
  });
  sharedStepperData = this.stepperData.asObservable();

  constructor() { }

  setStepperData(stepperData: any) {
    this.stepperData.next(stepperData);
  }
}

@Injectable()
class UserSessionMockService {
  i = 0;
  getUserName() {
    if (this.i === 0) {
      this.i++;
      return 'breddy88';
    } else if (this.i === 1) {
      this.i = this.i + 2;
      return 'SYSTEM';
    } else if (this.i === 3)  {
      return 'abcd';
    }
  }
  getUserOrg() {
    return 'ecp';
  }
  getUserPermission() {}

  getEcpToken() {}
  getFunctionalRole() {}
}

@Injectable()
class MockUmIntakeService {
  deleteProcedure(hsc_id: string, hsc_srvc_id: number): Observable<any>  {
    return of({data: { deleteProcedure: { hsc_id : '15430'}}});
  }

  upsertProcedure(upsertProc): Observable<any>  {
    return of({data: { upsertProcedure: { hscSrvcId : 13073}}});
  }
}

@Injectable()
class MockHttpClient {
  post(url: string, body: any | null, options?: any) {
    switch (url) {
      case environment.SERVICE_ETA_URL:
        return of({data: {eta: 2}});
      default:
        return of({});
    }
  }
}

describe('ProcedureServiceService', () => {

  beforeEach(() => TestBed.configureTestingModule(
    { providers: [DatePipe, UITKPageNotificationService, HttpHandler, { provide: HttpClient, useClass: MockHttpClient }, { provide: StepperDataService, useClass: MockStepperDataService },
        { provide: UserSessionService, useClass: UserSessionMockService}, { provide: UmIntakeFuncGraphqlService, useClass: MockUmIntakeService }] }
  ));

  it('should be created', () => {
    const service: ProcedureServiceService = TestBed.get(ProcedureServiceService);
    expect(service).toBeTruthy();
  });

  it('should validate  add Error', () => {
    const service: ProcedureServiceService = TestBed.get(ProcedureServiceService);
    service.addErrorMessage();
    expect(service.addErrorMessage).toBeTruthy();
  });

  it('should validate  add Error', () => {
    const service: ProcedureServiceService = TestBed.get(ProcedureServiceService);
    service.showProcedureError();
    expect(service.showProcedureError).toBeTruthy();
  });

  it('should add confirmProcProc code ', () => {
    const service: ProcedureServiceService = TestBed.get(ProcedureServiceService);
    let authTypeForm = new FormBuilder().group({
      requestCategory: [{value: 'Inpatient', id: 123}, Validators.required],
      facilityType: [{value: 'Office', id: 123}, Validators.required],
      priority: [{value: 'Urgent', id: 123}, Validators.required]
    });
    service.stepperDataService.setStepperData({authorizationTypeForm: authTypeForm, hsc: {hsc_id: 123} });
    let confirmOpRecord = [
      {
        servicingProvider: '', serviceType: { id: 3787, label: 'Pre-Admission Testin', value: '17' },
        total: '1', standardMeasure: { id: 4287, label: 'Days', value: null },
        count: '4', frequency: { id: 3913, label: 'Daily', value: '2' },
        serviceStartDate: '07-03-2020', serviceEndDate: '07-01-2020',
        procMod1: { id: 4289, label: '25', value: null },
        procMod2: { id: 4291, label: '01', value: '1' },
        procMod3: { id: 4292, label: '02', value: '2' },
        procMod4: { id: 4292, label: '02', value: '2' },
        hsc_srvc_id: 123
      }
    ];
    let proc = {
      servicingProvider: '', serviceType: { id: 3787, label: 'Pre-Admission Testin', value: '17' },
      total: '1', standardMeasure: { id: 4287, label: 'Days', value: null },
      count: '4', frequency: { id: 3913, label: 'Daily', value: '2' },
      serviceStartDate: '07-03-2020', serviceEndDate: '07-01-2020',
      procMod1: { id: 4289, label: '25', value: null },
      procMod2: { id: 4291, label: '01', value: '1' },
      procMod3: { id: 4292, label: '02', value: '2' },
      procMod4: { id: 4292, label: '02', value: '2' },
      hsc_srvc_id: 123
    };
    let procDetailsOP = confirmOpRecord;
    let nestedData = {
      procedureType: 'CPT4', code: '1118F',
      description: ' GERD SYMPTOMS ASSESSED AFTER 12 MONTHS THERAPY', hscId: '1557', hsc_srvc_id: '123'
    };
    // service.get(AuthService);
    expect(service.confirmProc).toBeDefined();
    service.confirmProc(1, proc, confirmOpRecord, nestedData);
  });

  it('dateWithinRangeValidatorFn return error object if the control date is NOT within the range of specified dates', () => {
    const service: ProcedureServiceService = TestBed.get(ProcedureServiceService);
    const dateWithinRangeValidatorFn = service.dateWithinRangeValidator('01-01-2020', '12-31-2020');
    const result = dateWithinRangeValidatorFn(new FormControl('01-01-2021'));
    expect(result.dateNotInRange).toBeTrue();
  });

  it('isDateInPastValidatorFn return error object if the control date is in past', () => {
    const service: ProcedureServiceService = TestBed.get(ProcedureServiceService);
    const isDateInPastValidatorFn = service.isDateInPastValidator();
    const result = isDateInPastValidatorFn(new FormControl('01-01-2020'));
    expect(result.isDateInPast).toBeTrue();
  });

  it('should  setDmeFieldValForDMEEquipOthrTxtReq ', () => {
    const service: ProcedureServiceService = TestBed.get(ProcedureServiceService);
    let proc = {
      servicingProvider: null, dme: [{ dmeType: { label: 'Rental', value: '2' }, dmeCost: '90' },
      { clinicalIllenessDesc: 'clinical', itemDescription: 'item' }, { serviceDescription: 'service' },
      { otherInfo: 'other' }], serviceType: { id: 3772, label: 'Surgical', value: '02' }, total: 89,
      standardMeasure: { id: 4287, label: 'Days', value: null }, count: 67,
      frequency: { id: 3914, label: 'Weekly', value: '3' }, serviceStartDate: '2020-09-26',
      serviceEndDate: '2020-09-26', procMod1: { id: 4290, label: '00', value: '00' },
      procMod2: { id: 4291, label: '01', value: '1' }, procMod3: { id: 4295, label: '0J', value: '0J' },
      procMod4: { id: 4290, label: '00', value: '00' }
    };
    expect(service.setDmeFieldValForDMEEquipOthrTxtReq).toBeDefined();
    service.setDmeFieldValForDMEEquipOthrTxtReq(proc);
    expect(service.setDmeFieldValForDMEEquipOthrTxtReq).toBeTruthy();
  });

  it('should  setDmeFieldValForDMESson ', () => {
    const service: ProcedureServiceService = TestBed.get(ProcedureServiceService);
    let proc = {
      servicingProvider: null, dme: [{ dmeType: { label: 'Rental', value: '2' }, dmeCost: '90' },
      { clinicalIllenessDesc: 'clinical', itemDescription: 'item' }, { serviceDescription: 'service' },
      { otherInfo: 'other' }], serviceType: { id: 3772, label: 'Surgical', value: '02' }, total: 89,
      standardMeasure: { id: 4287, label: 'Days', value: null }, count: 67,
      frequency: { id: 3914, label: 'Weekly', value: '3' }, serviceStartDate: '2020-09-26',
      serviceEndDate: '2020-09-26', procMod1: { id: 4290, label: '00', value: '00' },
      procMod2: { id: 4291, label: '01', value: '1' }, procMod3: { id: 4295, label: '0J', value: '0J' },
      procMod4: { id: 4290, label: '00', value: '00' }
    };
    expect(service.setDmeFieldValForDMESson).toBeDefined();
    service.setDmeFieldValForDMESson(proc);
    expect(service.setDmeFieldValForDMESson).toBeTruthy();
  });

  it('should  setDmeFieldValForDMETypCst ', () => {
    const service: ProcedureServiceService = TestBed.get(ProcedureServiceService);
    let proc = {
      servicingProvider: null, dme: [{ dmeType: { label: 'Rental', value: '2' }, dmeCost: '90' },
      { clinicalIllenessDesc: 'clinical', itemDescription: 'item' }, { serviceDescription: 'service' },
      { otherInfo: 'other' }], serviceType: { id: 3772, label: 'Surgical', value: '02' }, total: 89,
      standardMeasure: { id: 4287, label: 'Days', value: null }, count: 67,
      frequency: { id: 3914, label: 'Weekly', value: '3' }, serviceStartDate: '2020-09-26',
      serviceEndDate: '2020-09-26', procMod1: { id: 4290, label: '00', value: '00' },
      procMod2: { id: 4291, label: '01', value: '1' }, procMod3: { id: 4295, label: '0J', value: '0J' },
      procMod4: { id: 4290, label: '00', value: '00' }
    };
    expect(service.setDmeFieldValForDMETypCst).toBeDefined();
    service.setDmeFieldValForDMETypCst(proc);
    expect(service.setDmeFieldValForDMETypCst).toBeTruthy();
  });

  it('should  setDmeFieldValForInittrDessrv ', () => {
    const service: ProcedureServiceService = TestBed.get(ProcedureServiceService);
    let proc = {
      servicingProvider: null, dme: [{ dmeType: { label: 'Rental', value: '2' }, dmeCost: '90' },
      { clinicalIllenessDesc: 'clinical', itemDescription: 'item' }, { serviceDescription: 'service' },
      { otherInfo: 'other' }], serviceType: { id: 3772, label: 'Surgical', value: '02' }, total: 89,
      standardMeasure: { id: 4287, label: 'Days', value: null }, count: 67,
      frequency: { id: 3914, label: 'Weekly', value: '3' }, serviceStartDate: '2020-09-26',
      serviceEndDate: '2020-09-26', procMod1: { id: 4290, label: '00', value: '00' },
      procMod2: { id: 4291, label: '01', value: '1' }, procMod3: { id: 4295, label: '0J', value: '0J' },
      procMod4: { id: 4290, label: '00', value: '00' }
    };
    expect(service.setDmeFieldValForInittrDessrv).toBeDefined();
    service.setDmeFieldValForInittrDessrv(proc);
    expect(service.setDmeFieldValForInittrDessrv).toBeTruthy();
  });

  it('should  setProcModifiers ', () => {
    const service: ProcedureServiceService = TestBed.get(ProcedureServiceService);
    let proc = {
      servicingProvider: null, dme: [{ dmeType: { label: 'Rental', value: '2' }, dmeCost: '90' },
      { clinicalIllenessDesc: 'clinical', itemDescription: 'item' }, { serviceDescription: 'service' },
      { otherInfo: 'other' }], serviceType: { id: 3772, label: 'Surgical', value: '02' }, total: 89,
      standardMeasure: { id: 4287, label: 'Days', value: null }, count: 67,
      frequency: { id: 3914, label: 'Weekly', value: '3' }, serviceStartDate: '2020-09-26',
      serviceEndDate: '2020-09-26', procMod1: { id: 4290, label: '00', value: '00' },
      procMod2: { id: 4291, label: '01', value: '1' }, procMod3: { id: 4295, label: '0J', value: '0J' },
      procMod4: { id: 4290, label: '00', value: '00' }
    };
    expect(service.setProcModifiers).toBeDefined();
    service.setProcModifiers(proc);
    expect(service.setProcModifiers).toBeTruthy();
  });

  it('should getServiceETA', () => {
    const service: ProcedureServiceService = TestBed.get(ProcedureServiceService);
    let record = {code: 1234,proc_cd_schm_ref_id: 234};
    service.getServiceETA(record);
    expect(service.getServiceETA).toBeDefined();
  });

});
