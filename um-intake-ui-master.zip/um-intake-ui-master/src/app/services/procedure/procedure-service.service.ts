import { DatePipe } from '@angular/common';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AbstractControl, ValidatorFn } from '@angular/forms';
import { UITKPageNotificationService } from '@uitk/angular';
import * as moment from 'moment';
import {StepperDataService} from 'src/app/services/StepperDataService/StepperDataService';
import { environment } from 'src/environments/environment';
import {ReferenceConstants} from '../../constants/referenceConstants';
import {UserSessionService} from 'src/app/shared/services/user-session/user-session.service';
import {UmIntakeFuncGraphqlService} from '../um-intake-functions/umintakefunc-graphql.service';
const ADVANCE_NOTIFICATION = "ADVNTF - Advance Notification";
const CONTENT_TYPE_APPLICATION_JSON = "application/json";
@Injectable({
  providedIn: 'root'
})
export class ProcedureServiceService {
  constructor(public datepipe: DatePipe,  private readonly userSessionService: UserSessionService,
              private readonly umIntakeFuncGraphqlService: UmIntakeFuncGraphqlService,
              private readonly messageService: UITKPageNotificationService, private readonly http: HttpClient, public stepperDataService: StepperDataService) {
    this.stepperDataService.sharedStepperData.subscribe((stepperData) => this.stepperData = stepperData);
    this.camundaHttpHeaders = new HttpHeaders({
      'Content-Type': CONTENT_TYPE_APPLICATION_JSON,
      'Accept': ADVANCE_NOTIFICATION,
      'Authorization': 'Bearer ' + this.userSessionService.getEcpToken(),
      'x-bpm-cli-org-id': this.userSessionService.getUserOrg(),
      'x-bpm-func-role': this.userSessionService.getFunctionalRole(),
      'x-bpm-tenant-id': this.stepperData.tenantId
    });
  }
  stepperData: any;
  initialTrmntDate;
  otherText;
  sourceOfNutrition;
  formulaName;
  medicalCondition;
  itemDescription;
  clinicalIllenessDesc;
  serviceDescription;
  dmeType;
  dmeCost;
  recordToSave;
  procMod1;
  procMod2;
  procMod3;
  procMod4;

  camundaHttpHeaders = new HttpHeaders({});

  httpHeaders = new HttpHeaders({
    'Content-Type': CONTENT_TYPE_APPLICATION_JSON,
    'Accept': ADVANCE_NOTIFICATION
  });

  errorProcAlert = {
    id: 'error_msg',
    pageNotificationType: 'error',
    content: 'Unable to update Procedure.',
    visible: false,
    closeButton: true,
  };

  errorConfig = {
    id: 'error_msg',
    pageNotificationType: 'error',
    visible: false,
    content: 'Please select atleast one procedure code',
    closeButton: true,
  };

  confirmProc(procedureCounter, proc, confirmOpRecord, nestedData) {
    this.recordToSave = {};
    this.initialTrmntDate = null;
    this.otherText = null;
    this.sourceOfNutrition = null;
    this.formulaName = null;
    this.medicalCondition = null;
    this.itemDescription = null;
    this.clinicalIllenessDesc = null;
    this.procMod1 = null;
    this.procMod2 = null;
    this.procMod3 = null;
    this.procMod4 = null;
    this.serviceDescription = null;
    this.dmeType = null;
    this.dmeCost = null;
    this.setProcModifiers(proc);
    this.setDmeFieldValForInittrDessrv(proc);
    this.setDmeFieldValForDMETypCst(proc);
    this.setDmeFieldValForDMESson(proc);
    this.setDmeFieldValForDMEEquipOthrTxtReq(proc);
    this.prepareJsonToSaveOPRecord(procedureCounter, proc, confirmOpRecord, nestedData);
    this.updateProcedure();
  }
  isDme() {
    return this.clinicalIllenessDesc || this.dmeType || this.dmeCost || this.sourceOfNutrition || this.formulaName || this.medicalCondition || this.itemDescription || this.serviceDescription;
  }

  prepareJsonToSaveOPRecord(procedureCounter, proc, confirmOpRecord, nestedData) {
    this.recordToSave = {
      procCounter: procedureCounter,
      procedureCategory: nestedData.procedureCategory,
      procedureOthrTxtSwitch: nestedData.procedureOthrTxtSwitch,
      procDesc: nestedData.description,
      hsc_id: nestedData.hscId,
      hsc_srvc_id: nestedData.hsc_srvc_id,
      proc_cd: nestedData.code,
      proc_othr_txt: this.otherText,
      proc_cd_schm_ref_id: nestedData.procedureType === ReferenceConstants.PROCEDURE_TYPE_HCPCS_REF_DESC ? 4 : 2,
      hsc_srvc_non_facls: [{
          srvc_dtl_ref_id: proc.serviceType,
          proc_freq_ref_id: proc.frequency,
          proc_uom_ref_id: proc.standardMeasure,
          proc_unit_cnt: proc.count,
          unit_per_freq_cnt: proc.total,
          proc_mod_1_cd: this.procMod1,
          proc_mod_2_cd: this.procMod2,
          proc_mod_3_cd: this.procMod3,
          proc_mod_4_cd: this.procMod4,
          srvc_end_dt: proc.serviceEndDate,
          srvc_strt_dt: proc.serviceStartDate,
          init_trt_dt: this.initialTrmntDate
        }]
    };
    if (this.isDme()) {
      this.recordToSave.hsc_srvc_non_facls[0].hsc_srvc_non_facl_dmes = [{
        clin_ill_desc_txt: this.clinicalIllenessDesc,
        dme_procrmnt_typ_id: this.dmeType,
        dme_tot_cst_amt: this.dmeCost,
        ental_fd_sngl_src_nutritn_ind: this.sourceOfNutrition,
        fml_nm_txt: this.formulaName,
        med_cond_txt: this.medicalCondition,
        spl_desc_txt: this.itemDescription,
        srvc_desc_txt: this.serviceDescription
      }];
    }
  }

  setDmeFieldValForInittrDessrv(proc) {
    if (proc.dme !== undefined) {
      for (const value of proc.dme) {
        if (value.initialTreatmentDate && value.initialTreatmentDate !== undefined) {
          this.initialTrmntDate = value.initialTreatmentDate;
        }
        if (value.serviceDescription && value.serviceDescription !== undefined) {
          this.serviceDescription = value.serviceDescription;
        }
      }
    }
  }

  setDmeFieldValForDMEEquipOthrTxtReq(proc) {
    if (proc.dme !== undefined) {
      for (const value of proc.dme) {
        if (value.otherInfo && value.otherInfo !== undefined) {
          this.otherText = value.otherInfo;
          console.log(`otherText...${this.otherText}`);
        }
        if (value.itemDescription && value.itemDescription !== undefined) {
          this.itemDescription = value.itemDescription;
        }
        if (value.clinicalIllenessDesc && value.clinicalIllenessDesc !== undefined) {
          this.clinicalIllenessDesc = value.clinicalIllenessDesc;
        }
      }
    }
  }

  setProcModifiers(proc) {
    if (proc.dme !== undefined) {

      if (proc.procMod1 && proc.procMod1 !== undefined) {
        this.procMod1 = proc.procMod1;
        console.log(`this.procMod1...${this.procMod1}`);
      }
      if (proc.procMod2 && proc.procMod2 !== undefined) {
        this.procMod2 = proc.procMod2;
        console.log(`this.procMod2...${this.procMod2}`);
      }
      if (proc.procMod3 && proc.procMod3 !== undefined) {
        this.procMod3 = proc.procMod3;
        console.log(`this.procMod3...${this.procMod3}`);
      }
      if (proc.procMod4 && proc.procMod4 !== undefined) {
        this.procMod4 = proc.procMod4;
        console.log(`this.procMod4...${this.procMod4}`);
      }
    }
  }

  setDmeFieldValForDMETypCst(proc) {
    if (proc.dme !== undefined) {
      for (const value of proc.dme) {
        if (value.dmeType && value.dmeType !== undefined) {
          this.dmeType = value.dmeType;
        }
        if (value.dmeCost && value.dmeCost !== undefined) {
          this.dmeCost = value.dmeCost;
        }
      }
    }
  }
  setDmeFieldValForDMESson(proc) {
    if (proc.dme !== undefined) {
      for (const value of proc.dme) {
        if (value.sourceOfNutri && value.sourceOfNutri !== undefined) {
          this.sourceOfNutrition = value.sourceOfNutri;
        }
        if (value.formulaName && value.formulaName !== undefined) {
          this.formulaName = value.formulaName;
        }
        if (value.medicalCondition && value.medicalCondition !== undefined) {
          this.medicalCondition = value.medicalCondition;
        }

      }
    }
  }

  deleteProcedure(hscId, hscSrvcId) {
    this.umIntakeFuncGraphqlService.deleteProcedure(hscId, hscSrvcId).subscribe((data: any) => {
    },
      (error) => {
        if (error) {
          console.log(`error... in deleteProcedure...${JSON.stringify(error)}`);
        }
      });
  }

  updateProcedure() {
    const serviceType = this.stepperData.serviceType;
    const currentStep = this.stepperData.currentStepId;
    const stepperIds = this.stepperData.stepperIds;
    const caseType = this.stepperData.authorizationTypeForm.get('requestCategory')?.value.id;
    const {hsc, hscSrvcNonFacl, caseId} = this.stepperData;
    const value = this.recordToSave;
    const procNonFaclData = value.hsc_srvc_non_facls[0];
    const { hsc_srvc_non_facl_dmes, ...procNonFaclDataWithOutDme } = procNonFaclData;
    const hscSrvcNonFaclInput = {...procNonFaclDataWithOutDme, hsc_srvc_id: value.hsc_srvc_id, plsrv_ref_id: hscSrvcNonFacl?.plsrv_ref_id, srvc_desc_ref_id: hscSrvcNonFacl?.srvc_desc_ref_id};
    hscSrvcNonFaclInput.proc_mod_1_cd = procNonFaclData.proc_mod_1_cd ? procNonFaclData.proc_mod_1_cd.label : null;
    hscSrvcNonFaclInput.proc_mod_2_cd = procNonFaclData.proc_mod_2_cd ? procNonFaclData.proc_mod_2_cd.label : null;
    hscSrvcNonFaclInput.proc_mod_3_cd = procNonFaclData.proc_mod_3_cd ? procNonFaclData.proc_mod_3_cd.label : null;
    hscSrvcNonFaclInput.proc_mod_4_cd = procNonFaclData.proc_mod_4_cd ? procNonFaclData.proc_mod_4_cd.label : null;
    hscSrvcNonFaclInput.proc_uom_ref_id = procNonFaclData.proc_uom_ref_id.id;
    hscSrvcNonFaclInput.srvc_dtl_ref_id = procNonFaclData.srvc_dtl_ref_id.id;
    hscSrvcNonFaclInput.proc_freq_ref_id = procNonFaclData.proc_freq_ref_id.id;
    const procNonFaclDmeData = hsc_srvc_non_facl_dmes ? hsc_srvc_non_facl_dmes[0] : null;
    const hscSrvcNonFaclDmeInput = procNonFaclDmeData ? {...procNonFaclDmeData, hsc_srvc_id: value.hsc_srvc_id} : null;
    if (hscSrvcNonFaclDmeInput) {
      hscSrvcNonFaclDmeInput.dme_procrmnt_typ_id = procNonFaclDmeData.dme_procrmnt_typ_id ? procNonFaclDmeData.dme_procrmnt_typ_id.value : null;
    }
    const upsertProcVariables = {
        hsc_id: hsc.hsc_id,
        caseId,
        caseType,
        currentStep,
        hsc_srvc: {
          proc_othr_txt: value.proc_othr_txt
        },
        hsc_srvc_non_facl: hscSrvcNonFaclInput,
        hsc_srvc_non_facl_dme: hscSrvcNonFaclDmeInput,
        serviceType,
        stepperIds
    };

    this.umIntakeFuncGraphqlService.upsertProcedure(upsertProcVariables).subscribe((data: any) => {
    // update record in scope with non facility data in store along with hscDuplicates if any returned in response
      const updatedHscProcs = this.stepperData?.hscProcedures?.map((item) => {
        if (item.hsc_srvc_id === value.hsc_srvc_id) {
          item.hsc_srvc_non_facls = value.hsc_srvc_non_facls;
          item.proc_othr_txt = value.proc_othr_txt;
        }
        return item;
      });
      this.stepperDataService.setStepperData({ ...this.stepperData, hscProcedures: updatedHscProcs, hscDuplicates: data.data.upsertProcedure.hscDuplicates ? data.data.upsertProcedure.hscDuplicates : this.stepperData.hscDuplicates});
    },
      (error) => {
        this.showProcedureError();
      });
  }

  showProcedureError() {
    this.errorProcAlert.visible = true;
  }

  addErrorMessage() {
    this.errorConfig.visible = true;
    this.messageService.add(this.errorConfig);
  }

  /*
      Returns a Validator function which checks whether fromDate >= toDate
  */
  fromToDate(fromDateField: string, toDateField: string, errorName = 'fromToDate'): ValidatorFn {
    return (formGroup: AbstractControl): { [key: string]: boolean } | null => {
      const fromDate = formGroup.get(fromDateField).value;
      const toDate = formGroup.get(toDateField).value;
      // Ausing the fromDate and toDate are numbers. In not convert them first after null check
      if ((fromDate !== null && toDate !== null) && fromDate > toDate) {
        return { [errorName]: true };
      }
      return null;
    };
  }

  /*
     Returns a Validator function which checks whether service Start Date is not in past
     We check the serviceStartDate(its in string format) is not null and then do the comparison
     with currentDateWithoutTime and serviceStartDateWithoutTime.
  */
  isDateInPastValidator(): ValidatorFn {
    return (control: AbstractControl): { [key: string]: any } | null => {
      const serviceStartDate = control.value;
      const serviceStartDateWithoutTime = new Date(new Date(serviceStartDate).getTime());
      serviceStartDateWithoutTime.setHours(0, 0, 0, 0);
      const currentDateWithoutTime = new Date(new Date().getTime());
      currentDateWithoutTime.setHours(0, 0, 0, 0);
      if ((serviceStartDate !== null) && serviceStartDateWithoutTime < currentDateWithoutTime) {
        return { isDateInPast: true };
      }
      return null;
    };
  }

  /*
      Returns a Validator function which checks whether a date control value falls within the given range(inclusive)
  */
  dateWithinRangeValidator(startDate: string, endDate: string): ValidatorFn {
    return (control: AbstractControl): { [key: string]: any } | null => {
      if (control.value) {
        return !moment(control.value).isBetween(moment(startDate), moment(endDate), 'days', '[]') ? { dateNotInRange: true } : null;
      } else {
        return null;
      }
    };
  }

  /*Returns the Service ETA (number of Days) */
  getServiceETA(record){
    const httpOptions = {
      headers: new HttpHeaders({
        'Authorization': 'Bearer ' + this.userSessionService.getEcpToken()
      })
    };
    const body = {
      DECN_SUB_TYP_ID : 'UNK',
      DECN_OTCOME_TYP_ID : 'UNK',
      SYS_CLM_RMRK_CD : 'UNK',
      DECN_MADE_BY_USER_DEPT_ID : 'UNK',
      RCIP_FAX_INTNTL_IND : 'UNK',
      DAYOFWEEK : 'UNK',
      PROC_CD : record.code,
      PROC_TYP_ID : record.proc_cd_schm_ref_id,
      SRVC_REV_TYP_ID : 'UNK',
      ST_CD : 'UNK',
      SPCL_TYP_ID : 'UNK',
      PROV_CATGY_TYP_ID : 'UNK',
      DIAG_CD : 'UNK',
      PRI_IND : '0',
      ADMIT_IND : 'UNK',
      COV_TYP_ID : this.stepperData.selectedMember.coverage.cov_typ_ref_id,
      FUND_ARNG_ID : 'UNK',
      MKT_NTWK_IND : 'UNK',
      PRDCT_CATGY_CD : 'UNK',
      CLM_PLTFM_ID : 'UNK',
      MED_NECESSITY_APPL_IND : 'UNK',
      LOB_TYP_ID : 'UNK',
      REV_PRR_TYP_ID : this.stepperData.hsc.rev_prr_ref_id,
      SPCL_PROC_TYP_ID : 'UNK',
      CORE_MED_REV_TYP_ID : 'UNK',
      SEC_SPCL_PROC_TYP_ID : 'UNK'
    };
    this.http.post(environment.SERVICE_ETA_URL, body, httpOptions).subscribe((data: any) => {
        if (data && data.eta) {
          record.serviceETA = data.eta + ' Days';
        }
      },
      (error) => {
        if (error) {
          console.error('error occured in while getting service ETA' + error);
        }
      });
  }

}
