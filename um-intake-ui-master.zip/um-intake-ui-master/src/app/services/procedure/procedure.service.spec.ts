import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import { TestBed } from '@angular/core/testing';
import {of} from 'rxjs';
import {ProcedureService} from './procedure.service';
@Injectable()
class MockHttpClient {
  post(url: string, body: any | null, options?: any) {
    if (body.includes('procedureSmartSearchQuery')) {
      return of({ ProcedureSmartSearch : [{proc_cd: 123}, {proc_cd: 321}]});
    } else if (body.includes('systemConfigurationQuery')) {
      return of({ sys_cnfg : [{config_val: 1}] });
    } else {
      return of({ });
    }
  }
}
describe('ProcedureService', () => {
  let service: ProcedureService;

  beforeEach(() => {
    TestBed.configureTestingModule({providers: [
        { provide: HttpClient, useClass: MockHttpClient }
      ]});
    service = TestBed.inject(ProcedureService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('getProcedures should return Observable with response', () => {
    let response;
    service.getProcedures('test', 'CPT4').subscribe((res) => {
      response = res;
      expect(response.ProcedureSmartSearch.length).toEqual(2);
    });
  });
});
