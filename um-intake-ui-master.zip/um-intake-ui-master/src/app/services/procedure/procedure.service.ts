import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import { getProcedureDetailsQuery } from 'src/app/shared/graphql/referencedomain/referenceQuery';
import {environment} from '../../../environments/environment';
import {UserSessionService} from '../../shared/services/user-session/user-session.service';
import {BaseGraphQlService} from '../base/base-graphql.service';

@Injectable({
  providedIn: 'root'
})
export class ProcedureService extends BaseGraphQlService {

  constructor(http: HttpClient, public readonly userSessionService: UserSessionService) {
    super(http, userSessionService, environment.REFERENCE_API, environment.REFERENCE_API);
  }

  getProcedures(searchText: string, searchType: string): Observable<any> {
    const queryToExecute = {
      query: getProcedureDetailsQuery,
      variables: {
        searchText,
        searchType
      }
    };
    return this.rawCrudQuery(queryToExecute);
  }

}
