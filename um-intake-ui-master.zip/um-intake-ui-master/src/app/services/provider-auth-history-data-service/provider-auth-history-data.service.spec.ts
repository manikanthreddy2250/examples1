import { TestBed } from '@angular/core/testing';

import { ProviderAuthHistoryDataService } from './provider-auth-history-data.service';

describe('ProviderAuthHistoryDataService', () => {
  let service: ProviderAuthHistoryDataService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ProviderAuthHistoryDataService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should setFromMemberSearch', () => {
    service.setFromMemberSearch(true);
    expect(service.setFromMemberSearch).toBeTruthy();
  });

  it('should getFromMemberSearch', () => {
    service.getFromMemberSearch();
    expect(service.getFromMemberSearch).toBeTruthy();
  });

  it('should setProviderAuthHistoryData', () => {
    service.setProviderAuthHistoryData({"indv_key_val":"16440436900" , "indv_id": 12345});
    expect(service.setProviderAuthHistoryData).toBeTruthy();
  });

  it('should getProviderAuthHistoryData', () => {
    service.getProviderAuthHistoryData();
    expect(service.getProviderAuthHistoryData).toBeTruthy();
  });
});
