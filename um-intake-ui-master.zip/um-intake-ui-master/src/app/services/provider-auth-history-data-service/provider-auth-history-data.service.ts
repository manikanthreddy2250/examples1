import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProviderAuthHistoryDataService {

  private isFromMemberSearch: boolean = false;
  private retainHscRecords: boolean = false;
  private providerAuthHistoryData: {};
  private hscRecords: any;

  setFromMemberSearch(value) {
    this.isFromMemberSearch = value;
  }

  getFromMemberSearch() {
    return this.isFromMemberSearch;
  }

  setProviderAuthHistoryData(value) {
    this.providerAuthHistoryData = value;
  }

  getProviderAuthHistoryData() {
    return this.providerAuthHistoryData;
  }

  setHscRecords(value) {
    this.hscRecords = value;
  }

  getHscRecords() {
    return this.hscRecords;
  }

  setRetainHscRecords(value) {
    this.retainHscRecords = value;
  }

  getRetainHscRecords() {
    return this.retainHscRecords;
  }
}
