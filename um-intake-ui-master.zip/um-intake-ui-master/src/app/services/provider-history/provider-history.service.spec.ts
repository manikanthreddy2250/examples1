import { TestBed } from '@angular/core/testing';
import {HttpClient, HttpHandler} from '@angular/common/http';
import { ProviderHistoryService } from './provider-history.service';

describe('ProviderHistoryService', () => {

  beforeEach(() => {
    TestBed.configureTestingModule({providers: [HttpClient, HttpHandler]});
  });

  it('should be created', () => {
    const service: ProviderHistoryService = TestBed.get(ProviderHistoryService);
    expect(service).toBeTruthy();
  });

  it('should get HscIDs', () => {
    const service: ProviderHistoryService = TestBed.get(ProviderHistoryService);
    expect(service.getHscId).toBeDefined();
    service.getHscId();
  });

  it('should get MemberName', () => {
    const service: ProviderHistoryService = TestBed.get(ProviderHistoryService);
    expect(service.getMemberName).toBeDefined();
    service.getMemberName(1234);
  });

  it('should get Hsc Auths', () => {
    const service: ProviderHistoryService = TestBed.get(ProviderHistoryService);
    expect(service.getProviderHistoryAuthHistory).toBeDefined();
    service.getProviderHistoryAuthHistory('216793306', 16333);
  });

});
