import { HttpClient, HttpHeaders } from '@angular/common/http';
import {Injectable} from '@angular/core';
import {
  RawQuery
} from '@ecp/gql-tk-beta';
import {Observable} from 'rxjs';
import { getHscIdDetailsQuery } from 'src/app/shared/graphql/healthservicedomain/healthServiceQuery';
import { getIndvDetailsbyIdQuery } from 'src/app/shared/graphql/individualdomain/individualQuery';
import { getRefDataByRefID } from 'src/app/shared/graphql/referencedomain/referenceQuery';
import {UserSessionService} from 'src/app/shared/services/user-session/user-session.service';
import {environment} from 'src/environments/environment';
import {Constants} from '../../constants/constants';

@Injectable({
  providedIn: 'root'
})
export class ProviderHistoryService {

  // Set Graphql databases environments variables
  readonly hscHttpUrl: string = environment.HEALTH_SERVICE_API;
  readonly indHttpUrl: string = environment.INDIVIDUAL_API;
  // Set params variables for the databases
  params: any = {};
  // Set headerParams variables for the databases
  headerParams: any = {};
  private readonly staticParams: any = {'content-type': 'application/json'};
  contentType = 'application/json';
  httpHeaders = new HttpHeaders({
    'Content-Type': this.contentType,
    'Accept': this.contentType
  });

  hscAuths: any = {};

  // Set up databases authentication
  constructor(private http: HttpClient,
              private readonly userSessionService: UserSessionService) {

    this.headerParams = {'x-hasura-role': Constants.UM_INTAKE_UI_APP_NAME + '_' + this.userSessionService.getUserPermission(),
                         'Authorization': 'Bearer ' + this.userSessionService.getEcpToken()};
    this.params = {headers: {...this.staticParams, ...this.headerParams}};

  }

  // Get all Hsc entries with the table fields first
  getHscId(): Observable<any> {
    return this.http.post(this.hscHttpUrl, JSON.stringify(this.getHscIdQuery()), this.params);
  }

  // Raw query syntax
  private  getHscIdQuery(): RawQuery {
    return {
      query: getHscIdDetailsQuery,
      variables: {
      }
    };
  }

  // Get all member name
  getMemberName(indId: number): Observable<any> {
    return this.http.post(this.indHttpUrl, JSON.stringify(this.retrieveMemberName(indId)), this.params);
  }

  // Raw query syntax
  private  retrieveMemberName(indId: number): RawQuery {
    return {
      query: getIndvDetailsbyIdQuery,
      variables: {
        indId
      }
    };
  }

  async getProviderHistoryAuthHistory(providerKeyVal: any, provKeyTypeRefId: any) {
    const httpOptions = {
      headers: this.httpHeaders
    };
    const body = {
      prov: {
        prov_key_val: providerKeyVal,
        prov_key_type_ref_id: provKeyTypeRefId
      }
    };
    await this.http.post(environment.GET_PROVIDER_HISTORY_AUTH_FUNCTION_URL, body, httpOptions).toPromise().then((data: any) => {
        if (data) {
          this.hscAuths = data;
        }
      },
      (error) => {
          this.hscAuths = undefined;
      });

    return this.hscAuths;
  }
}
