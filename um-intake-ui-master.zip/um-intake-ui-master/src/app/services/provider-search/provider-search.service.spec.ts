/*import {HttpClient, HttpHandler} from '@angular/common/http';
import {Injectable} from '@angular/core';
import { TestBed } from '@angular/core/testing';
import {Observable, of} from 'rxjs';
import { DataserviceService } from 'src/app/services/dataservice-service/dataservice.service';
import {ReferenceConstants} from 'src/app/constants/referenceConstants';
import {ConfigConstants} from '../../constants/configConstants';
import {Constants} from '../../constants/constants';
import {SysConfigService} from '../sysconfig-service/sys-config.service';
import { ProviderSearchService } from './provider-search.service';
import { environment } from 'src/environments/environment';
import {ReferenceService} from 'src/app/services/refernce-service/reference.service';


@Injectable()
class MockHttpClient {
  post(url: string, body: any | null, options?: any) {
    if (JSON.stringify(body).includes('query ReferenceData')) {
      return of({data: {ref: [{ref_cd: 123, ref_desc: 'test', ref_dspl: 'test'}]}});
    } 
    else if (url = environment.DISTANCE_MATRIX_PROVIDERS_API){
      return of({})
    }
    else {
      return of({hscDuplicates: [{hsc_id: 123}]});
    }
  }
}

@Injectable()
class DataserviceMockService {
  getOption() {
    return of({state: 'cd'});
  }
}
@Injectable()
class SysConfigServiceMock {
  getClientConfigByKey(configKey: string): Observable<any> {
    if (configKey === ConfigConstants.ALLOW_MULTI_SRVC_PROV_CONFIG_KEY) {
      return of([
        {
          id: 'test_config_id',
          application: 'um_intake_ui',
          version: '1.0.0',
          org: 'ecp',
          role: null,
          key: 'allow_mult_srvc_prov',
          value: '\"0\"',
          startDate: '2021-02-12T00:00:00.000+00:00',
          endDate: null,
          inactivityIndicator: '0'
        }
      ]);
    } else if (configKey?.includes('provRoles')) {
      return of([
        {
          id: 'test_config_id2',
          application: 'um_intake_ui',
          version: '1.0.0',
          org: 'ecp',
          role: null,
          key: 'provRoles..',
          value: '[ \"Submitting\", \"PCP\", \"Ordering\" ]',
          startDate: '2021-02-12T00:00:00.000+00:00',
          endDate: null,
          inactivityIndicator: '0'
        }
      ]);
    } else {
      return of([
        {
          id: 'test_config_id3',
          application: 'um_intake_ui',
          version: '1.0.0',
          org: 'ecp',
          role: null,
          key: 'test_key',
          value: '',
          startDate: '2021-02-12T00:00:00.000+00:00',
          endDate: null,
          inactivityIndicator: '0'
        }
      ]);
    }
  }
}

@Injectable()
class ReferenceMockService {
  loadRefDataByRefID(refIds: any): Observable<any>{
  return of({data: {ref: [{ref_cd: 34}]}});
  }
  getReferenceDataForState(refIds: any): Observable<any>{
  return of({data: {ref_set: [{ref_id: 1059,ref_nm: "stateCode", ref:
			[{ref_cd: "AA", ref_id: 1059,}]}]}});
  }
}

describe('ProviderSearchService', () => {

    beforeEach(() => {
      TestBed.configureTestingModule({providers: [{ provide: HttpClient, useClass: MockHttpClient },
      { provide: DataserviceService, useClass: DataserviceMockService }, HttpHandler, 
      { provide: SysConfigService, useClass: SysConfigServiceMock },{ provide: ReferenceService, useClass: ReferenceMockService }] });
      const temp: any = '["ecp","provider"]';
      spyOn(localStorage, 'getItem').and.callFake((key: string): string => {
        return temp;
      });
    });

    afterEach(() => {
      TestBed.resetTestingModule();
    });
  
    afterAll(() => {
      TestBed.resetTestingModule();
    });

  it('should be created', () => {
    const service: ProviderSearchService = TestBed.get(ProviderSearchService);
    expect(service).toBeTruthy();
  });

  it('should get Provider Name Search', () => {
        const service: ProviderSearchService = TestBed.get(ProviderSearchService);
        expect(service.getProviderNameSearch).toBeDefined();
    	   service.getProviderNameSearch(1234, 'firstname', 'lastName', 456, 'TS103', 'optum', 123);
  });

  it('should get Provider Tin Or Npi Search', () => {
        const service: ProviderSearchService = TestBed.get(ProviderSearchService);
        expect(service.getProviderTinOrNpiSearch).toBeDefined();
    	   service.getProviderTinOrNpiSearch(1234, '89282hey', 'di82739183');
  });

  it('should get Provider Tin Or Npi Search is null', () => {
        const service: ProviderSearchService = TestBed.get(ProviderSearchService);
        expect(service.getProviderTinOrNpiSearch).toBeDefined();
    	   service.getProviderTinOrNpiSearch(1234, null, null);
  });

  it('should get Provider Tin Or Npi', () => {
        const service: ProviderSearchService = TestBed.get(ProviderSearchService);
        expect(service.getProviderTinOrNpi).toBeDefined();
    	   service.getProviderTinOrNpi('test', 1234);
  });

  it('should get Provider Tin Or Npi', () => {
    const service: ProviderSearchService = TestBed.get(ProviderSearchService);
    expect(service.saveProvider).toBeDefined();
    service.saveProvider({});
  });

  it('should get Provider Tin Or Npi', () => {
    const service: ProviderSearchService = TestBed.get(ProviderSearchService);
    expect(service.setProviderDetails).toBeDefined();
    service.setProviderDetails('1', '2', 3, '12', {});
  });

  it('should get Provider DetailsQuery', () => {
    const service: ProviderSearchService = TestBed.get(ProviderSearchService);
    expect(service.getProviderDetailsQuery).toBeDefined();
    service.getProviderDetailsQuery(1, null, null, null, null, null, null);
  });

  it('should get Provider Details Query for physician', () => {
    const service: ProviderSearchService = TestBed.get(ProviderSearchService);
    expect(service.getProviderDetailsQuery).toBeDefined();
    service.getProviderDetailsQuery(1, null, 'test', null, null, null, null);
  });

  it('should get getProviderDetailDraftData', () => {
    const service: ProviderSearchService = TestBed.get(ProviderSearchService);
    expect(service.getProviderDetailDraftData).toBeDefined();
    service.getProviderDetailDraftData(1234, 1234456);
  });

  it('should  setProviderRoles outpatient', () => {
    const service: ProviderSearchService = TestBed.get(ProviderSearchService);
    service.stepperData = { hsc: {srvc_set_ref_id : ReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT}};
    expect(service.setProviderRoles).toBeDefined();
    service.setProviderRoles();
  });

  it('should  getConfigKey inpatient', () => {
    const service: ProviderSearchService = TestBed.get(ProviderSearchService);
    service.stepperData = { hsc: {srvc_set_ref_id : ReferenceConstants.SERVICESETTINGTYPE_INPATIENT}};
    expect(service.getConfigKey).toBeDefined();
    service.getConfigKey();
  });

  it('should  getConfigKey OPF', () => {
    const service: ProviderSearchService = TestBed.get(ProviderSearchService);
    service.stepperData = { hsc: {srvc_set_ref_id : ReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY}};
    expect(service.getConfigKey).toBeDefined();
    service.getConfigKey();
  });

  it('should get resetValidProviderRoles facility', () => {
    const service: ProviderSearchService = TestBed.get(ProviderSearchService);
    service.roles = ['Facility'];
    expect(service.resetValidProviderRoles).toBeDefined();
    service.resetValidProviderRoles();
  });

  it('should get setValidProviderRoles admitting', () => {
    const service: ProviderSearchService = TestBed.get(ProviderSearchService);
    service.roles = ['Admitting', 'Attending', 'Facility', 'Ordering'];
    expect(service.setValidProviderRoles).toBeDefined();
    service.setValidProviderRoles();
  });

  it('should get getHscProviderByProviderId', () => {
    const service: ProviderSearchService = TestBed.get(ProviderSearchService);
    expect(service.getHscProviderByProviderId).toBeDefined();
    service.getHscProviderByProviderId(12345);
  });

    it('should get Provider by ProvID and AdrId', () => {
      const service: ProviderSearchService = TestBed.get(ProviderSearchService);
      expect(service.getProviderbyProvIDAdrId).toBeDefined();
      service.getProviderbyProvIDAdrId(125,88538913);
    });

  it('should get getHscServiceByHscId', () => {
    const service: ProviderSearchService = TestBed.get(ProviderSearchService);
    expect(service.checkExistingServiceLines).toBeDefined();
    service.checkExistingServiceLines(123);
  });

  it('getReferenceCD should get refData by code', async () => {
    const service: ProviderSearchService = TestBed.get(ProviderSearchService);
    const response = await service.getReferenceCD(123).toPromise();
    expect(response.data.ref[0].ref_dspl).toEqual('test');
  });
 it('getSpecialty should get speciality by code', async () => {
    const service: ProviderSearchService = TestBed.get(ProviderSearchService);
    const response = await service.getSpecialty('test').toPromise();
    expect(response.data.ref[0].ref_cd).toEqual(123);
  });

  it('should getDistanceMatrixDataForProvider', async () => {
    const distanceMatrixRProviderRequest = JSON.stringify({adr_ln_1_txt: '16 Valley Drive', cty_nm: 'Randolph', st_nm: 'NJ', zip_cd_txt: '078694453', prov_spcl_cd: '207RN0300X', radius: '20', radius_uom: 'miles'});
    const service: ProviderSearchService = TestBed.get(ProviderSearchService);
    const distanceMatrixToken = {access_token: 'Xyz123'};
    expect(service.getDistanceMatrixDataForProvider).toBeDefined();
    const distanceMatrixRProviderResponse = await service.getDistanceMatrixDataForProvider(distanceMatrixRProviderRequest, 'hjwbcbcubci2e');
  });

  it('should build Provider Data', async () => {
    const service: ProviderSearchService = TestBed.get(ProviderSearchService);
    const data = [{prov_id: '667', providerTin: '345', addressLine: 'test', lst_nm: 'test', fst_nm: 'test',bus_nm: 'facility', telcom_adr_id: '46', spcl_ref_dspl: 'vg', spcl_ref_id: '546',
    prov_loc_affil_id: '8686'}]
    const myData = {data: {
      prov_key: [{prov_key_val:'455'}]
    }}
    spyOn(service, 'getProviderTinOrNpi').and.returnValue(of(myData));
    const response = await service.buildProviderData(data);
    //expect(response.data.ref[0].ref_cd).toEqual(123);
  });

  it('should getProviderAddressLine', async () => {
    const service: ProviderSearchService = TestBed.get(ProviderSearchService);
    service.getProviderAddressLine('abc','def','hongkong','AZ','1234');
    expect(service.getProviderAddressLine).toBeDefined();
  });
});

*/