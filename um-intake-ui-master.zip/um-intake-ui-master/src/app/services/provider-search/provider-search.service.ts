import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {RawQuery} from '@ecp/gql-tk-beta';
import {Observable, Subscription} from 'rxjs';
import {ReferenceConstants} from 'src/app/constants/referenceConstants';
import {DataserviceService} from 'src/app/services/dataservice-service/dataservice.service';
import {MemberShipService} from 'src/app/services/member-search-service/member-eligibility-graphql.service';
import { getHscProvDataByProvIdQuery, getHscProvDataQuery, getHscProviderDataQuery,
         getServiceByHscIdQuery, updateProviderDataQuery, } from 'src/app/shared/graphql/healthservicedomain/healthServiceQuery';
import { getProvDataByOnTinorNpiQuery, getProvDetailsBasedOnTinorNpiQuery,
         getProvDetailsBasedOnZipandSpecialityQuery, getProvDetailsByProvCatIdQuery,
         getProviderDataByAdrIdQuery, getProviderDataByProvIDAdrIdQuery,
         getProviderDataByProvIDQuery, getProviderDataQuery, getProviderDetailsQuery,
         getProviderDraftDataQuery, getProvKeyValByProvIdQuery, getDistinctProviderDataByZipCodeQuery, getProvDetailByTaxIds} from 'src/app/shared/graphql/providerdomain/providerQuery';
import { getRefDataByRefID, getSpecialtyQuery } from 'src/app/shared/graphql/referencedomain/referenceQuery';
import {UserSessionService} from 'src/app/shared/services/user-session/user-session.service';
import {environment} from 'src/environments/environment';
import {ConfigConstants} from '../../constants/configConstants';
import {Constants} from '../../constants/constants';
import {StepperDataService} from '../StepperDataService/StepperDataService';
import {SysConfigService} from '../sysconfig-service/sys-config.service';
import {ReferenceService} from 'src/app/services/refernce-service/reference.service';
import {UmintakefuncCreateDraftHscService} from '../um-intake-functions/umintakefunc-create-draft-hsc.service';


const PROVIDER_KEY_VALUE_TYP_REF_ID_NPI = 2782;
const PROVIDER_KEY_VALUE_TYP_REF_ID_TIN = 16333;
const PROVIDER_KEY_VALUE_TYP_REF_ID_MPIN = 2783;
const PROVIDER_SPECIALTY_BASE_REF_NAME = 'providerSpecialty';
const DISTINCT_FILTER_FOR_QUERY = ' distinct_on: [prov_id, adr_ln_1_txt, adr_ln_2_txt, cty_nm, st_ref_id, zip_cd_txt]) {\n';

@Injectable({
  providedIn: 'root'
})
export class ProviderSearchService {

  readonly httpUrl: string = environment.PROVIDER_API;
  readonly wsUrl: string = environment.PROVIDER_API;
  params: any = {};
  headerParams: any = {};
  headersdistMatProv: any = {};
  contentType = 'application/json';
  private readonly staticParams: any = {'content-type': this.contentType};
  providerTelecomAddressId: string;
  providerSpecialtyRefId: string;
  providerLocationAffiliationId: string;
  providerRoleReferenceId: number;
  providerTin: string;
  providerNpi: string;
  requestCategory: any;
  roles: any[];
  hscId: string;
  submittingProviderDetails;
  PCPProviderDetails: any = {
    firstName: '',
    lastName: ''
  };
  httpHeaders = new HttpHeaders({
    'Content-Type': this.contentType,
    'Accept': this.contentType
  });
  isFacilityValid = false;
  isAdmittingValid = false;
  isAttendingValid = false;
  isOrderingValid = false;
  isServicingValid = false;
  isPCPValid = false;
  isSubmittingValid = false;
  allowMultipleServicingProvider = true;
  stepperData: any;
  stepperDataSubscription: Subscription;

  public IP = ReferenceConstants.SERVICESETTINGTYPE_INPATIENT;
  public OP = ReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT;
  public OPF = ReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY;

  constructor(public http: HttpClient, private userSessionService: UserSessionService,
              private dataserviceService: DataserviceService, private memberEligibilityGraphqlService: MemberShipService,
              public stepperDataService: StepperDataService,private referenceService: ReferenceService,
              private readonly sysConfigService: SysConfigService,
              private readonly umintakefuncCreateDraftHscService: UmintakefuncCreateDraftHscService
  ) {
      this.headerParams = {'x-hasura-role': Constants.UM_INTAKE_UI_APP_NAME + '_' + this.userSessionService.getUserPermission(),
                           'Authorization': 'Bearer ' + this.userSessionService.getEcpToken()};
      this.params = {headers: {...this.staticParams, ...this.headerParams}};
  }

  async getDistanceMatrixDataForProvider(distanceMatrixRProviderRequest: any, distanceMatrixToken: string) {
    let distanceMatrixRProviderResponse = null;
    if (distanceMatrixRProviderRequest && distanceMatrixToken && distanceMatrixToken.length > 0) {
      this.headersdistMatProv = {headers: new HttpHeaders({
          'Content-Type': this.contentType,
          'Authorization': 'Bearer ' + distanceMatrixToken
        })};
      distanceMatrixRProviderResponse = await this.http.post<any>(environment.DISTANCE_MATRIX_PROVIDERS_API,
        JSON.stringify(distanceMatrixRProviderRequest), this.headersdistMatProv).toPromise();
    }
    return distanceMatrixRProviderResponse;
  }

  public getProviderKeyVal(providerKeyVal: number, providerKeyValTypeId: number): Observable<any> {
    return this.http.post(this.httpUrl, JSON.stringify(this.getProviderKeyValQuery(providerKeyVal, providerKeyValTypeId)), this.params);
  }

  public setProviderDetails(providerTelecomAddressId: string, providerSpecialtyRefId: string,
                            providerRoleRefId: number, providerTin: string, currentProviderAffiliationDetailJson: {}): Observable<any> {
    this.providerTelecomAddressId = providerTelecomAddressId;
    this.providerSpecialtyRefId = providerSpecialtyRefId;
    this.providerRoleReferenceId = providerRoleRefId;
    this.providerTin = providerTin;
    return this.saveProvider(currentProviderAffiliationDetailJson);
  }

  public setHscId(hscId) {
    this.hscId = hscId;
  }

  setProviderRoles() {
    this.resetValidProviderRoles();
    let systemConfigId = '';
    this.stepperDataSubscription = this.stepperDataService.sharedStepperData.subscribe((stepperData) => {
      this.stepperData = stepperData;
      systemConfigId = this.getConfigKey();
    });
    // Get provider roles from sys_cnfg
    this.sysConfigService.getClientConfigByKey(systemConfigId).subscribe((res: any) => {
        this.roles = res ? JSON.parse(res[0].value) : [];
        this.setValidProviderRoles();
      },
      (error) => {
      }
    );
    // Get servicing provider config from sys_cnfg
    this.sysConfigService.getClientConfigByKey(ConfigConstants.ALLOW_MULTI_SRVC_PROV_CONFIG_KEY).subscribe((res: any) => {
        this.allowMultipleServicingProvider = res ? res[0].value.toString() === '1' : true;
      },
      (error) => {
      }
    );
  }

  getConfigKey(): string {
    if (this.stepperData?.hsc?.srvc_set_ref_id === this.OP) {
      return ConfigConstants.ALLOWED_PROVIDER_ROLES_OP_CONFIG_KEY;
    } else if (this.stepperData?.hsc?.srvc_set_ref_id === this.IP) {
      return ConfigConstants.ALLOWED_PROVIDER_ROLES_IP_CONFIG_KEY;
    } else if (this.stepperData?.hsc?.srvc_set_ref_id === this.OPF) {
      return ConfigConstants.ALLOWED_PROVIDER_ROLES_OPF_CONFIG_KEY;
    }
  }

  resetValidProviderRoles() {
    this.isOrderingValid = false;
    this.isFacilityValid = false;
    this.isAttendingValid = false;
    this.isAdmittingValid = false;
    this.isServicingValid = false;
    this.isPCPValid = false;
    this.isSubmittingValid = false;
  }

  setValidProviderRoles() {
    for (let i = 0; i < this.roles?.length; i++) {
      if (this.roles[i] === 'Facility') {
        this.isFacilityValid = true;
      } else if (this.roles[i] === 'Admitting') {
        this.isAdmittingValid = true;
      } else if (this.roles[i] === 'Attending') {
        this.isAttendingValid = true;
      } else if (this.roles[i] === 'Ordering') {
        this.isOrderingValid = true;
      } else if (this.roles[i] === 'Servicing') {
        this.isServicingValid = true;
      } else if (this.roles[i] === 'PCP') {
        this.isPCPValid = true;
      } else if (this.roles[i] === 'Submitting') {
        this.isSubmittingValid = true;
      }
    }
  }

  public saveProvider(currentProviderAffiliationDetailJson: {}): Observable<any> {
    const saveProviderVariables = {prov: {
        hsc_id: this.hscId,
        prov_role_ref_id: this.providerRoleReferenceId,
        prov_key_typ_ref_id: PROVIDER_KEY_VALUE_TYP_REF_ID_TIN,
        prov_key_val: this.providerTin,
        spcl_ref_id: this.providerSpecialtyRefId,
        telcom_adr_id: this.providerTelecomAddressId,
        prov_loc_affil_dtl: currentProviderAffiliationDetailJson
      }
    };
    return this.umintakefuncCreateDraftHscService.saveProvider(saveProviderVariables);
  }

  // return all Provider indv rows (including inactive)
  getProviderNameSearch(providerCategoryId: number, providerFirstName: string, providerLastName: string, providerState: number,
                        providerZipCode: string, providerOrgName: string, specialtyRefID: number): Observable<any> {
    console.log('before lastname');
    if (providerLastName && providerLastName.length > 2) {
      providerLastName = providerLastName.toUpperCase();
      providerFirstName = providerFirstName && providerFirstName.length > 2 ? providerFirstName.toUpperCase() : null;
    } else if (providerOrgName && providerOrgName.length > 2) {
      providerOrgName = providerOrgName.toUpperCase();
    }
    return this.http.post(this.httpUrl, JSON.stringify(getProviderDataQuery(providerCategoryId, providerFirstName,
      providerLastName, providerState, providerZipCode, providerOrgName, specialtyRefID)), this.params);
  }

  getProviderTinOrNpiSearch(providerCategoryId: number, providerTIN: string, providerNPI: string): Observable<any> {
    const providerTINKey = providerTIN === null ? null : 16333;
    const providerNPIKey = providerNPI === null ? null : 2782;
    if (providerTINKey !== null || providerNPIKey !== null) {
      return this.http.post(this.httpUrl, JSON.stringify(this.getProviderDetailsTinOrNpiQuery(providerCategoryId, providerTIN, providerNPI, providerTINKey, providerNPIKey)), this.params);
    } else if (providerTINKey !== null && providerNPIKey !== null) {
      return this.http.post(this.httpUrl, JSON.stringify(this.getProviderDetailsTinAndNpiQuery(providerCategoryId, providerTIN, providerNPI, providerTINKey, providerNPIKey)), this.params);

    }
  }

  getProviderTinOrNpi(providerID: string, providerKeyTypeRefId: number): Observable<any> {
    return this.http.post(this.httpUrl, JSON.stringify(this.getProviderTinOrNpiQuery(providerID, providerKeyTypeRefId)), this.params);
  }

  getProviderDetailDraftData(prov_loc_affil_id: number, prov_key_typ_ref_id: number): Observable<any> {
    return this.http.post(this.httpUrl, JSON.stringify(this.getProviderDraftData(prov_loc_affil_id, prov_key_typ_ref_id)), this.params);
  }

  getHscProviderByProviderId(providerID: number): Observable<any> {
    return this.http.post(environment.HEALTH_SERVICE_API, JSON.stringify(this.getHscProviderByProviderIdQuery(providerID)), this.params);
  }

  getServicingProviderByHscId(hscID): Observable<any> {
    return this.http.post(environment.HEALTH_SERVICE_API, JSON.stringify(this.checkServicingProviderAssoiciatedToCase(hscID)), this.params);
  }

  getHscProviderByProviderIdQuery(providerID: number): RawQuery {
    return {
      query: getHscProvDataByProvIdQuery,
      variables: {
        providerID,
      }
    };
  }

  getProviderDetailsTinOrNpiQuery(providerCategoryId: number, providerTIN: string, providerNPI: string, providerTINKey: number, providerNPIKey: number): RawQuery {
    return {
      query: getProvDataByOnTinorNpiQuery,
      variables: {
        providerCategoryId,
        providerTIN,
        providerNPI,
        providerTINKey,
        providerNPIKey
      }
    };
  }

  getProviderAffilDetailsQuery(provId, provAdrId, provtelcomAdrId, ProvSpecialtyRefId): RawQuery {
    return {
      query: getProviderDataByProvIDAdrIdQuery,
      variables: {
        provId,
        provAdrId,
        provtelcomAdrId,
        ProvSpecialtyRefId
      }
    };
  }

  getProviderDetailsTinAndNpiQuery(providerCategoryId: number, providerTIN: string, providerNPI: string, providerTINKey: number, providerNPIKey: number): RawQuery {
    return {
      query: getProvDetailsByProvCatIdQuery,
      variables: {
        providerCategoryId,
        providerTIN,
        providerNPI,
        providerTINKey,
        providerNPIKey
      }
    };
  }

  getProviderDetailsSearch(provId, provAdrId, provtelcomAdrId, ProvSpecialtyRefId): Observable<any> {
    return this.http.post(this.httpUrl, JSON.stringify(this.getProviderAffilDetailsQuery(provId, provAdrId,
      provtelcomAdrId, ProvSpecialtyRefId)), this.params);
  }

  getProviderTinOrNpiQuery(providerID: string, providerKeyTypeRefId: number): RawQuery {
    return {
      query: getProvKeyValByProvIdQuery,
      variables: {
        providerID,
        providerKeyTypeRefId
      }
    };
  }

  getReferenceCD(referenceId: number): Observable<any> {
    return this.http.post(environment.HEALTH_SERVICE_API, JSON.stringify(this.getReferenceCd(referenceId)), this.params);
  }

  getReferenceCd(referenceId: number): RawQuery {
    return {
      query: getRefDataByRefID,
      variables: {
        referenceId
      }
    };
  }

  getProviderKeyValQuery(providerKeyVal: number, providerKeyTypeRefId: number): RawQuery {
    return {
      query: getProviderDataByProvIDQuery,
      variables: {
        providerKeyVal,
        providerKeyTypeRefId
      }
    };
  }

  private getProviderDraftData(prov_loc_affil_id, provider_key_value_typ_ref_tin): RawQuery {
    return {
      query: getProviderDraftDataQuery,
      variables: {
        "prov_loc_affil_id": prov_loc_affil_id,
        "provider_key_value_typ_ref_tin": provider_key_value_typ_ref_tin
      }
    };
  }

  getProviderDetailsQuery(providerCategoryId: number, providerFirstName: string, providerLastName: string,
                          providerState: number, providerZipCode: string, providerOrgName: string, specialtyRefID: number): RawQuery {
    if (providerFirstName) {
      return {
        query: 'query ProvDetails($providerCategoryId: Int, $providerFirstName: String, $providerLastName: String, \n' +
          '$providerState: Int, $providerZipCode: String, $providerOrgName: String, $specialtyRefID: Int) {\n' +
          '  v_prov_srch(where: {prov_catgy_ref_id: {_eq: $providerCategoryId},  fst_nm: {_eq: $providerFirstName}, \n' +
          'lst_nm: {_like: "%' + providerLastName + '%"}, st_ref_id: {_eq: $providerState}, \n' +
          'zip_cd_txt: {_eq: $providerZipCode}, bus_nm: {_eq: $providerOrgName}, spcl_ref_id: {_eq: $specialtyRefID}}\n' +
          DISTINCT_FILTER_FOR_QUERY +
          '    prov_id\n' +
          '    fst_nm\n' +
          '    lst_nm\n' +
          '    bus_nm\n' +
          '    adr_ln_1_txt\n' +
          '    adr_ln_2_txt\n' +
          '    cty_nm\n' +
          '    st_ref_id\n' +
          '    zip_cd_txt\n' +
          '    prov_key_val\n' +
          '    prov_key_typ_ref_id\n' +
          '    spcl_ref_id\n' +
          '    telcom_adr_id\n' +
          '    prov_loc_affil_id\n' +
          '    prov_catgy_ref_id\n' +
          '    prov_adr_id\n' +
          '   }\n' +
          '  }\n',
        variables: {
          providerCategoryId,
          providerLastName,
          providerFirstName,
          providerState,
          providerZipCode,
          providerOrgName,
          specialtyRefID
        }
      };
    } else {
      return {
        query: getProviderDetailsQuery,
        variables: {
          providerCategoryId,
          providerLastName,
          providerState,
          providerZipCode,
          providerOrgName,
          specialtyRefID
        }
      };
    }

  }

  getProvidersZipCodeSearch(zipCodeText: string, providerCategoryReferenceID: number): Observable<any> {
    return this.http.post(environment.PROVIDER_API, JSON.stringify(this.getProvidersZipCodeSearchQuery(zipCodeText, providerCategoryReferenceID)), this.params);
  }

  getProvidersZipCodeSearchQuery(zipCodeText: string, providerCategoryReferenceID: number): RawQuery {
    return {
      query: getDistinctProviderDataByZipCodeQuery,
      variables: {
        zipCodeText,
        providerCategoryReferenceID
      }
    };
  }

  updateServcingProviderAgainstProcedure(hscServiceId: number, serviceHscProviderId: number): Observable<any> {
    return this.http.post(environment.HEALTH_SERVICE_API, JSON.stringify(this.updateProviderQuery(hscServiceId, serviceHscProviderId)), this.params);
  }

  updateProviderQuery(hscServiceId: number, serviceHscProviderId: number): RawQuery {
    return {
      query: updateProviderDataQuery,
      variables: {
        hscServiceId,
        serviceHscProviderId
      }
    };
  }

  getHscProvider(hscId: number): Observable<any> {
    return this.http.post(environment.HEALTH_SERVICE_API, JSON.stringify(this.getHscProviderQuery(hscId)), this.params);
  }

  getHscProviderQuery(hscId: number): RawQuery {
    return {
      query: getHscProvDataQuery,
      variables: {
        hscId,
      }
    };
  }

  getSpecialty(refDescription: string): Observable<any> {
    return this.http.post(environment.HEALTH_SERVICE_API,
      JSON.stringify(getSpecialtyQuery(refDescription, PROVIDER_SPECIALTY_BASE_REF_NAME)), this.params);
  }

  public getProviderByZipAndSpecialty(specialtyRefId, zipCode, categoryRefId): Observable<any>  {
    return this.http.post(this.httpUrl, JSON.stringify(this.getSpecialtyandZipQuery(specialtyRefId, zipCode, categoryRefId)), this.params);

  }

  private getSpecialtyandZipQuery(specialtyRefId, zipCode, categoryRefId): RawQuery {
    return {
      query: getProvDetailsBasedOnZipandSpecialityQuery,
      variables: {
        specialtyRefId,
        zipCode,
        categoryRefId
      }
    };
  }

  public getProviderbyProvIDAdrId(provID, provAdrId): Observable<any>  {
      return this.http.post(this.httpUrl, this.getProviderbyProvIDAdrIdQuery(provID, provAdrId), this.params);
  }

  private getProviderbyProvIDAdrIdQuery(provID, provAdrId): RawQuery {
      return {
        query: getProvDetailsBasedOnTinorNpiQuery,
        variables: {
          provID,
          provAdrId,
        }
      };
  }

  public checkServicingProviderAssoiciatedToCase(hscId): RawQuery {
    return {
      query: getHscProviderDataQuery,
      variables: {
          hscId
      }
    };

  }
  public checkExistingServiceLines(hscId): Observable<any> {
    return this.http.post(environment.HEALTH_SERVICE_API, JSON.stringify(this.getServicebyHscId(hscId)), this.params);
  }
  private getServicebyHscId(hscId): RawQuery {
    return {
      query: getServiceByHscIdQuery,
      variables: {
        hscId
      }
    };
  }

  public getProviderDetailsByAdrId(provAdrId): Observable<any> {
    const getDetailsByAdrIdQuery = {
      query: getProviderDataByAdrIdQuery,
      variables: {
        provAdrId
      }
    };
    return this.http.post(this.httpUrl, JSON.stringify(getDetailsByAdrIdQuery), this.params);
  }

  public getProviderDetailsByTaxIDBulk(provKeyVal): Promise<any>{
    const getDetailsByTaxIdQuery = {
      query: getProvDetailByTaxIds,
      variables: {
        provKeyVal
      }
    };
    return this.http.post(this.httpUrl, JSON.stringify(getDetailsByTaxIdQuery), this.params).toPromise();
  }

  async buildProviderData(providerData){
    const providerResultsData = [];
    // tslint:disable-next-line:prefer-for-of
    for (let j = 0; j < providerData.length; j++) {
      let providerState = '';
      let addressLine = '';
      let providerTin = '';
      let providerNpi = '';
      let providerMpin = '';
      let providerName = '';

      const getRefCode = await this.referenceService.loadRefDataByRefID(providerData[j].st_ref_id).toPromise();
      providerState = getRefCode.data.ref[0].ref_cd;

      await this.getProviderTinOrNpi(providerData[j].prov_id, PROVIDER_KEY_VALUE_TYP_REF_ID_TIN).toPromise().then((providerTinRes) => {
            providerTin =  providerTinRes.data.prov_key.length === 0 ? null : providerTinRes.data.prov_key[0].prov_key_val;
      });
      await this.getProviderTinOrNpi(providerData[j].prov_id, PROVIDER_KEY_VALUE_TYP_REF_ID_NPI).toPromise().then((providerNpiRes) => {
            providerNpi =  providerNpiRes.data.prov_key.length === 0 ? null : providerNpiRes.data.prov_key[0].prov_key_val;
      });
      await this.getProviderTinOrNpi(providerData[j].prov_id, PROVIDER_KEY_VALUE_TYP_REF_ID_MPIN).toPromise().then((providerMPINRes) => {
        providerMpin =  providerMPINRes.data.prov_key.length === 0 ? null : providerMPINRes.data.prov_key[0].prov_key_val;
      });

      if (providerState) {
          addressLine = this.getProviderAddressLine(providerData[j].adr_ln_1_txt, providerData[j].adr_ln_2_txt, providerData[j].cty_nm, providerState,providerData[j].zip_cd_txt);
      }
      await this.referenceService.loadRefDataByRefID(providerData[j].spcl_ref_id).toPromise().then((specialtydisplRes) => {
                  providerData[j].spcl_ref_dspl = specialtydisplRes.data.ref[0].ref_dspl;
      });

        if(providerData[j].bus_nm != null){
          providerName = providerData[j].bus_nm;
        }else{
          providerName = providerData[j].lst_nm + ', ' + providerData[j].fst_nm;
        }
        providerResultsData.push({
              providerName,
              businessName: providerData[j].bus_nm,
              firstName: providerData[j].fst_nm,
              lastName: providerData[j].lst_nm,
              addressLine,
              providerTin,
              providerNpi,
              prov_id: providerData[j].prov_id,
              phone: providerData[j].telcom_adr_id,
              specialty: providerData[j].spcl_ref_dspl,
              specialtyId: providerData[j].spcl_ref_id,
              locationAffiliationId: providerData[j].prov_loc_affil_id,
              providerAddressId: providerData[j].prov_adr_id,
              providerMPIN: providerMpin,
              providerCategoryRefId: providerData[j].prov_catgy_ref_id,
              addressLine1: providerData[j].adr_ln_1_txt,
              addressLine2: providerData[j].adr_ln_2_txt,
              cityName: providerData[j].cty_nm,
              zipCodeText: providerData[j].zip_cd_txt
        });
    }
    return providerResultsData;
  }

  getProviderAddressLine(adr_ln_1_txt: string, adr_ln_2_txt: string, cty_nm: string, st_ref_cd: string, zip_cd_txt: string): string {
    let addressLine = '';
    if (adr_ln_1_txt) {
      addressLine = adr_ln_1_txt;
    }
    if (adr_ln_2_txt) {
      addressLine = this.appendAddressComponent(addressLine, adr_ln_2_txt);
    }
    if (cty_nm) {
      addressLine = this.appendAddressComponent(addressLine, cty_nm);
    }
    if (st_ref_cd) {
      addressLine = this.appendAddressComponent(addressLine, st_ref_cd);
    }
    if (zip_cd_txt) {
      addressLine = this.appendAddressComponent(addressLine, zip_cd_txt);
    }
    return addressLine;
  }

  appendAddressComponent(addressLine: string, addressComponent: string): string {
    if (addressComponent.length > 0) {
      if (addressLine && addressLine.length > 0) {
        addressLine += ', ' + addressComponent;
      } else {
        addressLine = addressComponent;
      }
    }
    return addressLine;
  }

}
