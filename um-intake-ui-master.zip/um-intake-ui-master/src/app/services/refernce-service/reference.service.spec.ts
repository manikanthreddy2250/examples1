import { HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {TestBed} from '@angular/core/testing';
import {of} from 'rxjs';
import { ReferenceService } from './reference.service';

@Injectable()
class MockHttpClient {
  post(url: string, body: any | null, options?: any) {
    const bodyStr = JSON.stringify(body);
    if (bodyStr.includes('cpt4')) {
      return of({ data : {cpt4: [{proc_cd: 123, dc_desc: 'test'}]} });
    } else if (bodyStr.includes('hcpcs')) {
      return of({ data : {hcpcs: [{proc_cd: 123, dc_desc: 'test'}]} });
    } else {
      return of({data: {ref: [{ref_cd: '222', ref_desc: 'ref test desc'}]}});
    }
  }
}

describe('ReferenceService', () => {
  let service: ReferenceService;
  beforeEach(() => {
    TestBed.configureTestingModule({providers: [
        { provide: HttpClient, useClass: MockHttpClient }
      ]});
    service = TestBed.inject(ReferenceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should load Ref Display Data ', () => {
    expect(service.loadRefDisplayData).toBeDefined();
    service.loadRefDisplayData();
  });

  it('should load Base Ref Name Display Data', () => {
      expect(service.loadBaseRefNameDisplayData).toBeDefined();
      service.loadBaseRefNameDisplayData('1234');
  });

  it('should load Base Ref Name Ref Set Display Data', () => {
    expect(service.loadRefSetDisplayData).toBeDefined();
    service.loadRefSetDisplayData('1234');
  });

  it('should load Base Ref Child Display Data', () => {
    expect(service.loadRefChildDisplayDataInRef).toBeDefined();
    service.loadRefChildDisplayDataInRef(1234);
  });

  it('should load Ref Data By Ref ID Display Data', () => {
    expect(service.loadRefDataByRefID).toBeDefined();
    service.loadRefDataByRefID(1234);
  });

  it('should load DocumentType Ref Data', () => {
    const refIds = [19904, 19905, 19906, 19907, 19908, 19909, 19910, 19911, 19912];
    expect(service.getBulkRefEntriesByRefIds).toBeDefined();
    service.getBulkRefEntriesByRefIds(refIds);
  });
});
