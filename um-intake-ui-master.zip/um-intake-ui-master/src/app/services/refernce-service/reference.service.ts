import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {
  getBulkRefDataByRefID, getRefChildDataByRefIDQuery, getRefDataByBaseRefNameQuery,
  getRefDataByRefID, getRefDataByRefName,
  getRefSetDataByRefNameQuery, RefSearchQuery
} from 'src/app/shared/graphql/referencedomain/referenceQuery';
import {UserSessionService} from 'src/app/shared/services/user-session/user-session.service';
import { environment } from 'src/environments/environment';
import {BaseGraphQlService} from '../base/base-graphql.service';

@Injectable({
  providedIn: 'root'
})
export class ReferenceService extends BaseGraphQlService {

  constructor(http: HttpClient, public readonly userSessionService: UserSessionService) {
    super(http, userSessionService, environment.HEALTH_SERVICE_API, environment.HEALTH_SERVICE_API);
  }

  loadRefDisplayData(): Observable<any> {
    const queryToExecute = {
      query: RefSearchQuery,
      variables: {
      }
    };
    return this.rawCrudQuery(queryToExecute);
  }

  loadBaseRefNameDisplayData(baseRefName: string): Observable<any> {
    const queryToExecute = {
      query: getRefDataByBaseRefNameQuery,
      variables: {
        bas_ref_nm: baseRefName
      }
    };
    return this.rawCrudQuery(queryToExecute);
  }

  // if we associate any existing ref values to new ref_nm in ref_set table
  loadRefSetDisplayData(baseRefName: string): Observable<any> {
    const queryToExecute = {
      query: getRefSetDataByRefNameQuery,
      variables: {
        ref_nm: baseRefName
      }
    };
    return this.rawCrudQuery(queryToExecute);
  }

  // get records from ref table with refrence to ref_chld table
  loadRefChildDisplayDataInRef(refId: number): Observable<any> {
    const queryToExecute = {
      query: getRefChildDataByRefIDQuery,
      variables: {
        ref_id: refId
      }
    };
    return this.rawCrudQuery(queryToExecute);
  }

  getBulkRefEntriesByRefIds(refIds: any): Observable<any> {
    const queryToExecute = {
      query: getBulkRefDataByRefID,
      variables: {
        refIds
      }
    };
    return this.rawCrudQuery(queryToExecute);
  }

  getReferenceDataForState(referenceName: string): Observable<any> {
    const queryToExecute = {
      query: getRefDataByRefName,
      variables: {
        referenceName
      }
    };
    return this.rawCrudQuery(queryToExecute);
  }

  /*   get data from ref table by ref_id   */
  loadRefDataByRefID(referenceId: number): Observable<any> {
    const queryToExecute = {
      query: getRefDataByRefID,
      variables: {
        referenceId
      }
    };
    return this.rawCrudQuery(queryToExecute);
  }

}
