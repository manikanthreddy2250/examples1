import {HttpClient, HttpHandler} from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import { SummaryServiceService } from './summary-service.service';

describe('SummaryServiceService', () => {
  let service: SummaryServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({ providers: [HttpClient, HttpHandler] });
    service = TestBed.inject(SummaryServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should have call getHscDetailData', () => {
    const hscId = '123';
    const service: SummaryServiceService = TestBed.get(SummaryServiceService);
    expect(service.getHscDetailData).toBeDefined();
    service.getHscDetailData(hscId);
  //  expect(service).toBeTruthy();
  });
});
