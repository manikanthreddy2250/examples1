import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { getHscDetailDataQuery } from 'src/app/shared/graphql/healthservicedomain/healthServiceQuery';
import {UserSessionService} from 'src/app/shared/services/user-session/user-session.service';
import { environment } from 'src/environments/environment';
import {BaseGraphQlService} from '../base/base-graphql.service';

@Injectable({
  providedIn: 'root'
})
export class SummaryServiceService extends BaseGraphQlService {

  constructor(http: HttpClient, public readonly userSessionService: UserSessionService) {
    super(http, userSessionService, environment.HEALTH_SERVICE_API, environment.HEALTH_SERVICE_API);
  }

  getHscDetailData(hscID): Observable<any> {
    const queryToExecute = {
      query: getHscDetailDataQuery,
      variables: {
        Hscid: hscID
      }
    };
    return this.rawCrudQuery(queryToExecute);
  }
}
