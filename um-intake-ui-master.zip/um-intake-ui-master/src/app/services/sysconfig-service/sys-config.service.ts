import {HttpClient} from '@angular/common/http';
import { Injectable } from '@angular/core';
import {Observable} from 'rxjs';
import {UserSessionService} from 'src/app/shared/services/user-session/user-session.service';
import env from '../../../environments/.env';
import {environment} from '../../../environments/environment';
import {Constants} from '../../constants/constants';

@Injectable({
  providedIn: 'root'
})
export class SysConfigService {
  readonly configHttpUrl: string = environment.CONFIGURATION_API_BASE_URL;
  configHeaderParams: any = {};

  constructor(private readonly http: HttpClient, private readonly userSessionService: UserSessionService) {
    this.configHeaderParams = {headers: {authorization: 'Bearer ' + userSessionService.getEcpToken()}};
  }

  getClientConfigByKey(configKey: string): Observable<any> {
    return this.http.get(this.configHttpUrl + '/prop/' + Constants.UM_INTAKE_UI_APP_NAME + '/' + env.npm_package_version + '/' + configKey, this.configHeaderParams);
  }
}
