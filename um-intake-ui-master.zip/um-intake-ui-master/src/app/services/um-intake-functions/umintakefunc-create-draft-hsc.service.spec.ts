import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import { TestBed } from '@angular/core/testing';
import {of} from 'rxjs';
import {UserSessionService} from '../../shared/services/user-session/user-session.service';
import { UmintakefuncCreateDraftHscService } from './umintakefunc-create-draft-hsc.service';

@Injectable()
class UserSessionMockService {
  i = 0;
  getUserName() {
    if (this.i === 0) {
      this.i++;
      return 'padepu';
    } else if (this.i === 1) {
      this.i = this.i + 2;
      return 'SYSTEM';
    } else if (this.i === 3)  {
      return 'abcd';
    }
  }
  getUserOrg() {
    return 'ecp';
  }
  getUserPermission() {}
  getEcpToken() {}
  getFunctionalRole() {}
}
@Injectable()
class MockHttpClient {
  post(url: string, body: any | null, options?: any) {
    if (body.includes('createDraftAuth')) {
      return of({data: {createDraftAuth: {hscId: 123}}});
    } else if (body.includes('saveProvider')) {
      return of({data: {saveProvider: {hscId: 15763}}});
    }
  }
}

describe('UmintakefuncCreateDraftHscService', () => {
  let service: UmintakefuncCreateDraftHscService;

  beforeEach(() => {
    TestBed.configureTestingModule({providers: [
        { provide: UserSessionService, useClass: UserSessionMockService }, { provide: HttpClient, useClass: MockHttpClient }
      ]});
    service = TestBed.inject(UmintakefuncCreateDraftHscService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should create Hsc Draft ', () => {
    const createHscDraftReq = {
      "createHsc":{
        "serviceType": "Generic",
        "coverage": {
          "claimPlatform": 0,
          "policyNumber": "0128855",
          "productCode": 0,
          "sourceChannel": ""
        },
        "hsc": {
          "chg_user_id": "SYSTEM",
          "creat_user_id": "SYSTEM",
          "indv_id": 503926748,
          "indv_key_typ_ref_id": 2757,
          "indv_key_val": "16440436900",
          "hsc_rev_typ_ref_id": 20402,
          "mbr_cov_dtl" : {
            "claim_platform_ref_Id": 363,
            "cov_eff_dt": "2013-01-01",
            "cov_end_dt": "9999-12-31",
            "coverageTypeDesc": "Medical",
            "indv_id": 503926748,
            "indv_key_typ_ref_id": 2757,
            "indv_key_val": "16440436900",
            "mbr_cov_id": 96963692,
            "pol_nbr": "0128855",
            "productCatgyTpe": null,
            "productCode": 214
          }
        }
      }
    };
    service.createHscDraft(createHscDraftReq).subscribe((res) => {
      expect(res.data.createDraftAuth.hscId).toEqual(123);
    });
  });

  it('should save provider ', () => {
    const saveProvReq = {
      "prov": {
        "hsc_id": "14535",
        "prov_role_ref_id": 3759,
        "prov_key_typ_ref_id": 16333,
        "prov_key_val": "4568900",
        "spcl_ref_id": 16536,
        "telcom_adr_id": "7186222000",
        "prov_loc_affil_dtl": {
          "providerDetails": {
            "prov_adr_id": 98265064,
            "prov_cat_typ_ref_id": 16309,
            "prov_id": 6675410,
            "prov_keys": [
              {
                "prov_key_typ_ref_id": 2782,
                "prov_key_val": "1255539573"
              },
              {
                "prov_key_typ_ref_id": 16333,
                "prov_key_val": null
              },
              {
                "prov_key_typ_ref_id": 2783,
                "prov_key_val": null
              }
            ]
          }
        }
      }
    }
    service.saveProvider(saveProvReq).subscribe((res) => {
      expect(res.data.saveProvider.hscId).toEqual(15763);
    });
  });
});
