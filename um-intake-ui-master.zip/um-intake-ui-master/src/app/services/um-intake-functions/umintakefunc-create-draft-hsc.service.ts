import {HttpClient} from '@angular/common/http';
import { Injectable } from '@angular/core';
import {GraphqlService, GraphqlServiceConfig} from '@ecp/gql-tk-beta';
import {Observable, Subscription} from 'rxjs';
import {environment} from '../../../environments/environment';
import {Constants} from '../../constants/constants';
import {createHscDraftMutationQuery, saveProviderMutation} from '../../shared/graphql/umintakefunctions/umIntakeFuncQuery';
import {UserSessionService} from '../../shared/services/user-session/user-session.service';
import {StepperDataService} from '../StepperDataService/StepperDataService';

@Injectable({
  providedIn: 'root'
})
export class UmintakefuncCreateDraftHscServiceConfig implements GraphqlServiceConfig {
  readonly httpUrl: string = environment.UMINTAKEFUNC_SERVICE_API;
  readonly wsUrl: string = environment.UMINTAKEFUNC_SERVICE_API;
  params: any = {};
  contentType = 'application/json';
  stepperData: any;
  stepperDataSubscription: Subscription;
  constructor(userSessionService: UserSessionService,  public stepperDataService: StepperDataService) {
    this.params = { 'x-hasura-role': Constants.UM_INTAKE_UI_APP_NAME + '_' + userSessionService.getUserPermission(),
                    'x-bpm-cli-org-id': userSessionService.getUserOrg(),
                    'x-bpm-func-role': userSessionService.getFunctionalRole(),
                    'Authorization': 'Bearer ' + userSessionService.getEcpToken()};
   }

}

@Injectable({
  providedIn: 'root'
})
export class UmintakefuncCreateDraftHscService extends GraphqlService {
  constructor(userSessionService: UserSessionService, umintakefuncCreateDraftHscServiceConfig: UmintakefuncCreateDraftHscServiceConfig, http: HttpClient) {
    super(http, umintakefuncCreateDraftHscServiceConfig);
  }

  createHscDraft(createHsc): Observable<any> {
    const createHscDraftMutation = {
      query: createHscDraftMutationQuery,
      variables: {
        createHsc
      }
    };
    return this.rawCrudQuery(createHscDraftMutation);
  }

  saveProvider(saveProv): Observable<any> {
    const saveProviderMutationQuery = {
      query: saveProviderMutation,
      variables: { saveProv }
    };
    return this.rawCrudQuery(saveProviderMutationQuery);
  }
}
