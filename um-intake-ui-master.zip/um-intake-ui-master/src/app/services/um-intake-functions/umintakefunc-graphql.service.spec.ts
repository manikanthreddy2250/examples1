import { HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {TestBed} from '@angular/core/testing';
import {BehaviorSubject, of} from 'rxjs';
import {Constants} from '../../constants/constants';
import {UserSessionService} from 'src/app/shared/services/user-session/user-session.service';
import {UmIntakeFuncGraphqlService} from './umintakefunc-graphql.service';
import {StepperDataService} from '../StepperDataService/StepperDataService';


@Injectable()
class UserSessionMockService {
  i = 0;
  getUserName() {
    if (this.i === 0) {
      this.i++;
      return 'breddy88';
    } else if (this.i === 1) {
      this.i = this.i + 2;
      return 'SYSTEM';
    } else if (this.i === 3)  {
      return 'abcd';
    }
  }
  getUserOrg() {
    return 'ecp';
  }
  getUserPermission() {}
  getEcpToken() {}
  getFunctionalRole() {}
}
@Injectable()
class MockHttpClient {
  post(url: string, body: any | null, options?: any) {
    if (body.includes('saveProcedure')) {
      return of({data: { saveProcedure: { hscSrvcId : 12980}}});
    } else if (body.includes('upsertProcedure')) {
      return of({data: { upsertProcedure: { hscSrvcId : 13073}}});
    } else if (body.includes('deleteProcedure')) {
      return of({data: { deleteProcedure: { hsc_id : '15430'}}});
    } else if (body.includes('submitHsc')) {
      return of({data: { submitHsc: { hsc_id : 15466, hsc_sts_ref_id: 19275}}});
    } else if (body.includes('saveconatct')) {
      return of({data: { saveconatct: { hsc_id : '16573'}}});
    } else if (body.includes('saveNote')) {
      return of({data: { saveNote: { hsr_note_id : 3220, creat_dttm: '12-Apr-2021 14:32:32', creat_user_id: 'ecp_engineer'}}});
    }
    if (body.includes('saveAuthType')) {
      return of({data: {saveAuthType: {hsc_id: 15491}}});
    }
    if (body.includes('saveDiagnosis')) {
      return of({data: {saveDiagnosis: {hsc_diag_id: 4803}}});
    }
    if (body.includes('deleteDiagnosis')) {
      return of({data: {deleteDiagnosis: {hsc_diag_id: 4803}}});
    }
  }
}

@Injectable()
class MockStepperDataService {
  private stepperData = new BehaviorSubject({tenantId: 'ecpumintakebaseproductbpmgrp'}
    );
  sharedStepperData = this.stepperData.asObservable();

  constructor() { }

  setStepperData(stepperData: any) {
    this.stepperData.next(stepperData);
  }
}

describe('UmIntakeFuncGraphqlService', () => {
  let service: UmIntakeFuncGraphqlService;
  beforeEach(() => {
    TestBed.configureTestingModule({providers: [
        { provide: UserSessionService, useClass: UserSessionMockService }, { provide: StepperDataService, useClass: MockStepperDataService }, { provide: HttpClient, useClass: MockHttpClient }
      ]});
    service = TestBed.inject(UmIntakeFuncGraphqlService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should save procedure ', () => {
    service.saveProcedure('1', "15250", "78191", 2, null,"Outpatient").subscribe((res) => {
      expect(res.data.saveProcedure.hscSrvcId).toEqual(12980);
    });
  });

  it('should upsert procedure ', () => {
    const variables = {
      "caseId":"eb5f790c-9255-11eb-8989-228a5ac1243a",
      "caseType":3738,
      "currentStep":2,
      "hsc_srvc":{
        "proc_othr_txt":null
      },
      "hsc_srvc_non_facl":{
        "srvc_dtl_ref_id":3786,
        "proc_freq_ref_id":3914,
        "proc_uom_ref_id":19884,
        "proc_unit_cnt":8,
        "unit_per_freq_cnt":8,
        "proc_mod_1_cd":"01",
        "proc_mod_2_cd":"25",
        "proc_mod_3_cd":"08",
        "proc_mod_4_cd":"02",
        "srvc_end_dt":"2021-04-09",
        "srvc_strt_dt":"2021-04-01",
        "init_trt_dt":null,
        "hsc_srvc_id":13073,
        "plsrv_ref_id":3742,
        "srvc_desc_ref_id":4347
      },
      "hsc_srvc_non_facl_dme":null,
      "serviceType":"Generic",
      "stepperIds":[
        1,
        10,
        2,
        7,
        8,
        9
      ]
    };
    service.upsertProcedure(variables).subscribe((res) => {
      expect(res.data.upsertProcedure.hscSrvcId).toEqual(13073);
    });
  });

  it('should save Auth', () => {
    const saveAuthReq = {
      "saveAuth":{
        "variables": {
          "hsc": {
            "value": {
              "serviceType": "Generic",
              "caseType": 3738,
              "requestCategory": "Outpatient",
              "facilityType": "Office",
              "clinicalInformationRecieved": "Yes",
              "admissionType": "ADVNTF - Advance Notification",
              "lineOfBusiness": "13 - CIP M&R",
              "procedureCode": "E0465",
              "networkStatus": "1 - In Network",
              "stateOfIssue": "MN",
              "priority": "Routine",
              "tatPeriodType": "Notification to Decision",
              "tatCategoryType": "Decision",
              "triggerTatPointType": "Notification",
              "notificationDate": 1614284256,
              "hsc_key_val": "c5ca304d-8808-11eb-9a7a-36f7bcd820a8",
              "hsc_id": "14241",
              "orgId": "ecp"
            }
          },
          "currentStep": {
            "value": 1
          },
          "completedStep": {
            "value": 1
          },
          "completedStepIds": {
            "value": [
              1
            ]
          }
        },
        "caseId": "c5ca304d-8808-11eb-9a7a-36f7bcd820a8",
        "hsc": {
          "indv_id": 503926748,
          "hsc_id": "14241",
          "srvc_set_ref_id": 3738,
          "rev_prr_ref_id": 3754,
          "creat_user_id": "SYSTEM",
          "chg_user_id": "SYSTEM",
          "hsc_sts_ref_id": 19274
        },
        "hscSrvc": {
          "hsc_srvc_id": 11708,
          "hsc_id": "14241",
          "creat_user_id": "SYSTEM",
          "chg_user_id": "SYSTEM"
        },
        "hscSrvcNonFacl": {
          "hsc_srvc_id": 11708,
          "plsrv_ref_id": 3740,
          "srvc_desc_ref_id": 4347
        },
        "hscFacl": {
          "hsc_id": "14241",
          "plsrv_ref_id": 3740,
          "srvc_desc_ref_id": 4347,
          "srvc_dtl_ref_id": 123,
          "actul_admis_dttm": "",
          "actul_dschrg_dttm": "",
          "expt_admis_dt": "",
          "expt_dschrg_dt": ""
        }
      }
    };
    service.saveAuthTypeHttp(saveAuthReq).subscribe((res) => {
      expect(res.data.saveAuthType.hsc_id).toEqual(15491);
    });
  });

  it('should save diagnosis ', () => {
    const saveDiagnosisReq = {
      "saveDiagnosis":{
        "diagnosisCartList" : [{
          "diag_cd":"M21.53",
          "hsc_id":13677,
          "inac_ind":0,
          "pri_ind":1
        }]
      }
    };
    service.saveDiagnosis(saveDiagnosisReq).subscribe((res) => {
      expect(res.data.saveDiagnosis.hsc_diag_id).toEqual(4803);
    });
  });

  it('should delete diagnosis ', () => {
    const deleteDiagnosisReq = {
      "deleteDiagnosis":{
        "diag_cd":"M21.52",
        "hsc_id":13606
      }
    };
    service.deleteDiagnosis(deleteDiagnosisReq).subscribe((res) => {
      expect(res.data.deleteDiagnosis.hsc_diag_id).toEqual(4803);
    });
  });

  it('should delete procedure ', () => {
    service.deleteProcedure('115430', 13143).subscribe((res) => {
      expect(res.data.deleteProcedure.hsc_id).toEqual('15430');
    });
  });

  it('should submit Hsc ', () => {
    const variables = {
      hsc_id: '15466',
      caseId: '6867868c-9325-11eb-8989-228a5ac1243a',
      variables: {
        currentStep: {},
        completedStep: {
          value: 9
        },
        completedStepIds: {
          value: [
            1,
            10,
            2,
            7,
            8,
            9
          ]
        },
        hsc: {
          value: {
            serviceType: 'Generic',
            caseType: 3738,
            requestCategory: 'Outpatient',
            facilityType: 'Home',
            clinicalInformationRecieved: 'Yes',
            admissionType: 'ADVNTF - Advance Notification',
            lineOfBusiness: '13 - CIP M&R',
            procedureCode: 'E0465',
            networkStatus: '1 - In Network',
            stateOfIssue: 'MN',
            priority: 'Routine',
            tatPeriodType: 'Notification to Decision',
            tatCategoryType: 'Decision',
            triggerTatPointType: 'Notification',
            notificationDate: new Date(),
            hsc_key_val: '6867868c-9325-11eb-8989-228a5ac1243a',
            hsc_id: '15466',
            orgId: 'ecp'
          }
        }
      }
    };
    service.submitHsc(variables).subscribe((res) => {
      expect(res.data.submitHsc.hsc_id).toEqual(15466);
    });
  });

  it('should save contact ', () => {
    const variables = {
      caseId:"33b60233-9ba4-11eb-b114-3aa309c4f219",
      variables: {
        currentStep: {
          value: 8
        },
        completedStep: {
          value: 7
        },
        completedStepIds: {
          value: [
            1,
            10,
            2,
            7
          ]
        },
        hsc: {
          value: {
            serviceType: 'Generic',
            caseType: 3738,
            requestCategory: 'Outpatient',
            facilityType: 'Home',
            clinicalInformationRecieved: 'Yes',
            admissionType: 'ADVNTF - Advance Notification',
            lineOfBusiness: '13 - CIP M&R',
            procedureCode: 'E0465',
            networkStatus: '1 - In Network',
            stateOfIssue: 'MN',
            priority: 'Routine',
            tatPeriodType: 'Notification to Decision',
            tatCategoryType: 'Decision',
            triggerTatPointType: 'Notification',
            notificationDate: new Date(),
            hsc_key_val: '6867868c-9325-11eb-8989-228a5ac1243a',
            hsc_id: '15466',
            orgId: 'ecp'
          }
        }
      },
      hsc_id: '16573',
      flwup_cntc_dtl: {
        primary_cntct: {
          name: 'test',
          role: null,
          department: null,
          phone: '555-555-5555',
          fax: null,
          email: null
        },
        secondary_cntct: {
          inac_ind: 1,
          name: 'test1',
          role: null,
          department: null,
          phone: '666-666-6666',
          fax: null,
          email: null
        }
      }
    };
    service.saveContactMutation(variables).subscribe((res) => {
      expect(res.data.saveconatct.hsc_id).toEqual('16573');
    });
  });

  it('should save note ', () => {
    const variables = {
      hsc_id: '16594',
      note_txt_lobj: 'much',
      note_titl_txt: 'tooo',
      src_user_nm: 'clinician',
      note_typ_ref_id: 12,
      hsr_note_sbjs: {
        data: {
          note_sbj_rec_id: 'rec_id',
          note_sbj_typ_ref_id: 12,
          inac_ind: 0}
      }
    };
    service.saveNotesMutation(variables).subscribe((res) => {
      expect(res.data.saveNote.hsr_note_id).toEqual(3220);
    });
  });

});
