import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { GraphqlService, GraphqlServiceConfig, RawQuery } from '@ecp/gql-tk-beta';
import {Observable, Subscription} from 'rxjs';
import { environment } from '../../../environments/environment';
import {Constants} from '../../constants/constants';
import {
  deleteDiagnosisMutationQuery,
  saveAuthTypeHttpMutationQuery,
  saveDiagnosisMutationQuery, deleteProcedureMutation, saveProcedureMutation, submitHscMutation, upsertProcedureMutation, saveContactMutation, saveNoteMutation
} from '../../shared/graphql/umintakefunctions/umIntakeFuncQuery';
import {UserSessionService} from '../../shared/services/user-session/user-session.service';
import {StepperDataService} from '../StepperDataService/StepperDataService';

@Injectable({
  providedIn: 'root'
})
export class UmIntakeFuncGraphqlServiceConfig implements GraphqlServiceConfig {
  readonly httpUrl: string = environment.UMINTAKEFUNC_SERVICE_API;
  readonly wsUrl: string = environment.UMINTAKEFUNC_SERVICE_API;
  params: any = {};
  contentType = 'application/json';
  stepperData: any;
  stepperDataSubscription: Subscription;
  constructor(userSessionService: UserSessionService,  public stepperDataService: StepperDataService) {
    this.stepperDataSubscription = this.stepperDataService.sharedStepperData.subscribe((stepperData) => {
      this.stepperData = stepperData;
    });
    this.params = {'x-hasura-role': Constants.UM_INTAKE_UI_APP_NAME + '_' + userSessionService.getUserPermission(),
                    'x-bpm-cli-org-id': userSessionService.getUserOrg(),
                    'x-bpm-func-role': userSessionService.getFunctionalRole(),
                    'x-bpm-tenant-id': this.stepperData.tenantId,
                    'Authorization': 'Bearer ' + userSessionService.getEcpToken()};
  }

}

@Injectable({
  providedIn: 'root'
})
export class UmIntakeFuncGraphqlService extends GraphqlService {
  stepperData: any;
  stepperDataSubscription: Subscription;
  constructor(userSessionService: UserSessionService, umIntakeFuncGraphqlServiceConfig: UmIntakeFuncGraphqlServiceConfig, public stepperDataService: StepperDataService, http: HttpClient) {
    super(http, umIntakeFuncGraphqlServiceConfig);
  }

  saveProcedure(caseId: string, hsc_id: string, proc_cd: string,  proc_cd_schm_ref_id: number, srvc_hsc_prov_id: number, requestCategory: string): Observable<any> {
    const saveProcedureMutationQuery = {
      query: saveProcedureMutation,
      variables: {
        saveProc: {
          caseId,
          hsc_id,
          proc_cd,
          proc_cd_schm_ref_id,
          srvc_hsc_prov_id,
          requestCategory
        }
      }
    };
    return this.rawCrudQuery(saveProcedureMutationQuery);
  }

  upsertProcedure(upsertProc): Observable<any> {
    const upsertProcedureMutationQuery = {
      query: upsertProcedureMutation,
      variables: { upsertProc }
    };
    return this.rawCrudQuery(upsertProcedureMutationQuery);
  }

  saveAuthTypeHttp(saveAuth): Observable<any> {
    const saveAuthTypeHttpMutation = {
      query: saveAuthTypeHttpMutationQuery,
      variables: {
        saveAuth
      }
    };
    return this.rawCrudQuery(saveAuthTypeHttpMutation);
  }

  saveDiagnosis(saveDiagnosis): Observable<any> {
    const saveDiagnosisMutation = {
      query: saveDiagnosisMutationQuery,
      variables: {
        saveDiagnosis
      }
    };
    return this.rawCrudQuery(saveDiagnosisMutation);
  }

  deleteDiagnosis(deleteDiagnosis): Observable<any> {
    const deleteDiagnosisMutation = {
      query: deleteDiagnosisMutationQuery,
      variables: {
        deleteDiagnosis
      }
    };
    return this.rawCrudQuery(deleteDiagnosisMutation);
  }

  deleteProcedure(hsc_id: string, hsc_srvc_id: number): Observable<any> {
    const deleteProcedureMutationQuery = {
      query: deleteProcedureMutation,
      variables: { deleteProc : {
          hsc_id,
          hsc_srvc_id
        }
      }
    };
    return this.rawCrudQuery(deleteProcedureMutationQuery);
  }

  submitHsc(submitHsc): Observable<any> {
    const submitHscMutationQuery = {
      query: submitHscMutation,
      variables: { submitHsc }
    };
    return this.rawCrudQuery(submitHscMutationQuery);
  }

  saveContactMutation(saveContactreq): Observable<any> {
    const saveContactMutationQuery = {
      query: saveContactMutation,
      variables: { saveContactreq }
    };
    return this.rawCrudQuery(saveContactMutationQuery);
  }

  saveNotesMutation(saveNotereq): Observable<any> {
    const saveNoteMutationQuery = {
      query: saveNoteMutation,
      variables: { saveNotereq }
    };
    return this.rawCrudQuery(saveNoteMutationQuery);
  }
}
