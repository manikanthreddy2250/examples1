import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import { TestBed } from '@angular/core/testing';
import {of} from 'rxjs';
import {UserSessionService} from '../../shared/services/user-session/user-session.service';
import { UmintakefuncCreateDraftHscService } from './umintakefunc-create-draft-hsc.service';
import {UmintakefuncHscDetailsService} from './umintakefunc-hscDetails.service';

@Injectable()
class UserSessionMockService {
  i = 0;
  getUserName() {
    if (this.i === 0) {
      this.i++;
      return 'padepu';
    } else if (this.i === 1) {
      this.i = this.i + 2;
      return 'SYSTEM';
    } else if (this.i === 3)  {
      return 'abcd';
    }
  }
  getUserOrg() {
    return 'ecp';
  }
  getUserPermission() {}
  getEcpToken() {}
  getFunctionalRole() {}
}
@Injectable()
class MockHttpClient {
  post(url: string, body: any | null, options?: any) {
    if (body.includes('getHscAuthDetails')) {
      return of({
        data: {
          getHscAuthDetails: {
            hsc: [
              {
                hsc_id: 17111,
                creat_dttm: null,
                creat_user_id: 'SYSTEM',
                indv_id: 503926748,
                indv_key_typ_ref_id: 2757,
                indv_key_val: '16440436900',
                mbr_cov_dtl: {
                  indv_id: 503926748,
                  pol_nbr: '0752023',
                  cov_eff_dt: '2020-02-01',
                  cov_end_dt: '9999-12-31',
                  mbr_cov_id: 90881934,
                  productCode: 226,
                  indv_key_val: '16440436900',
                  productCatgyTpe: null,
                  coverageTypeDesc: 'Optum Behav. Health',
                  indv_key_typ_ref_id: 2757,
                  claim_platform_ref_Id: 363
                },
                hsc_sts_ref_id: 19274,
                flwup_cntc_dtl: null,
                rev_prr_ref_id: 3754,
                rev_prr_ref_cd: {
                  ref_id: 3754,
                  ref_cd: '1',
                  ref_desc: 'Routine',
                  ref_dspl: 'Routine'
                },
                srvc_set_ref_id: 3737,
                srvc_set_ref_cd: {
                  ref_id: 3737,
                  ref_cd: '1',
                  ref_desc: 'Inpatient',
                  ref_dspl: 'Inpatient'
                },
                hsc_keys: [
                  {
                    hsc_id: 16078,
                    hsc_key_val: 'ad1adf4f-96f7-11eb-a953-d6ea16ab6fef',
                    hsc_key_typ_ref_id: 19517
                  }
                ],
                hsc_srvcs: [],
                hsc_facls: [
                  {
                    actul_admis_dttm: null,
                    actul_dschrg_dttm: null,
                    expt_admis_dt: null,
                    expt_dschrg_dt: null,
                    plsrv_ref_id: 3743,
                    plsrv_ref_cd: {
                      ref_id: 3743,
                      ref_cd: '21',
                      ref_desc: 'Acute Hospital',
                      ref_dspl: 'Acute Hospital'
                    },
                    srvc_desc_ref_id: 4347,
                    srvc_desc_ref_cd: {
                      ref_id: 4347,
                      ref_cd: '1',
                      ref_desc: 'Scheduled',
                      ref_dspl: 'Scheduled'
                    },
                    srvc_dtl_ref_id: 4307,
                    srvc_dtl_ref_cd: {
                      ref_id: 4307,
                      ref_cd: '2',
                      ref_desc: 'Surgical',
                      ref_dspl: 'Surgical'
                    }
                  }
                ],
                hsc_diags: [
                  {
                    hsc_diag_id: 4969,
                    diag_cd: 'A78',
                    inac_ind: 0
                  }
                ],
                hsr_notes: [],
                hsc_provs: [
                  {
                    auto_aprv_ltr_ind: null,
                    hsc_prov_id: 6331,
                    chg_sys_ref_id: null,
                    chg_user_id: 'ecp_engineer',
                    creat_sys_ref_id: null,
                    creat_user_id: 'ecp_engineer',
                    data_qlty_iss_list: null,
                    data_secur_rule_list: null,
                    end_dt: null,
                    hsc_prov_end_rsn_ref_id: null,
                    ltr_opt_out_cc_ind: null,
                    med_rec_nbr: null,
                    ntwk_strg_rsn_ref_id: null,
                    ntwk_sts_ref_id: null,
                    prov_loc_affil_dtl: {
                      providerDetails: {
                        prov_id: 2529852,
                        prov_keys: [
                          {
                            prov_key_val: '1114122074',
                            prov_key_typ_ref_id: 2782
                          },
                          {
                            prov_key_val: null,
                            prov_key_typ_ref_id: 16333
                          },
                          {
                            prov_key_val: null,
                            prov_key_typ_ref_id: 2783
                          }
                        ],
                        prov_adr_id: 7425448,
                        prov_cat_typ_ref_id: 16309
                      }
                    },
                    prov_loc_affil_id: null,
                    spcl_ref_id: 16892,
                    strt_dt: null,
                    telcom_adr_id: '7735104726',
                    updt_ver_nbr: 0,
                    hsc_prov_roles: [
                      {
                        hsc_prov_id: 6331,
                        prov_role_ref_id: 3765
                      }
                    ]
                  }
                ]
              }
            ]
          }
        }
      });
    }
  }
}

describe('UmintakefuncHscDetailsService', () => {
  let service: UmintakefuncHscDetailsService;

  beforeEach(() => {
    TestBed.configureTestingModule({providers: [
        { provide: UserSessionService, useClass: UserSessionMockService }, { provide: HttpClient, useClass: MockHttpClient }
      ]});
    service = TestBed.inject(UmintakefuncHscDetailsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should get Hsc Details ', () => {
    const getHscAuthRequest = {hsc: {hsc_id: 17111}};
    service.getHscAuthDetails(getHscAuthRequest).subscribe((res) => {
      expect(res.data.getHscAuthDetails.hsc[0].hsc_id).toEqual(17111);
    });
  });
});
