import {HttpClient} from '@angular/common/http';
import { Injectable } from '@angular/core';
import {GraphqlService, GraphqlServiceConfig} from '@ecp/gql-tk-beta';
import {Observable, Subscription} from 'rxjs';
import {environment} from '../../../environments/environment';
import {Constants} from '../../constants/constants';
import {getHscAuthDetails} from '../../shared/graphql/umintakefunctions/umIntakeFuncQuery';
import {UserSessionService} from '../../shared/services/user-session/user-session.service';

@Injectable({
  providedIn: 'root'
})
export class UmintakefuncHscDetailsServiceConfig implements GraphqlServiceConfig {
  readonly httpUrl: string = environment.UTILFUNC_SERVICE_API;
  readonly wsUrl: string = environment.UTILFUNC_SERVICE_API;
  params: any = {};
  contentType = 'application/json';
  constructor(userSessionService: UserSessionService) {
    this.params = { 'x-hasura-role': Constants.UM_INTAKE_UI_APP_NAME + '_' + userSessionService.getUserPermission(),
                    'x-bpm-cli-org-id': userSessionService.getUserOrg(),
                    'x-bpm-func-role': userSessionService.getFunctionalRole(),
                    'Authorization': 'Bearer ' + userSessionService.getEcpToken()};
   }

}

@Injectable({
  providedIn: 'root'
})
export class UmintakefuncHscDetailsService extends GraphqlService {
  constructor(userSessionService: UserSessionService, umintakefuncHscDetailsServiceConfig: UmintakefuncHscDetailsServiceConfig, http: HttpClient) {
    super(http, umintakefuncHscDetailsServiceConfig);
  }
  getHscAuthDetails(getHscAuthRequest): Observable<any> {
    const getHscAuthDetailsMutationQuery = {
      query: getHscAuthDetails,
      variables: { getHscAuthRequest }
    };
    return this.rawCrudQuery(getHscAuthDetailsMutationQuery);
  }
}
