import { HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {TestBed} from '@angular/core/testing';
import {of} from 'rxjs';
import {Constants} from '../../constants/constants';
import {UserSessionService} from 'src/app/shared/services/user-session/user-session.service';
import { UserAttrService } from './user-attr.service';

@Injectable()
class MockUserSessionService {
  getUserName() {
    return 'SYSTEM';
  }
  getUserPermission() {
    return Constants.UM_INTAKE_UI_USER_PERMISSION_CLINICIAN;
  }
  getEcpToken() {
    return 'test token';
  }
}
@Injectable()
class MockHttpClient {
  post(url: string, body: any | null, options?: any) {
    return of({data: {insert_user_fav: {affected_rows : 1}}});
  }
}

describe('UserAttrService', () => {
  let service: UserAttrService;
  beforeEach(() => {
    TestBed.configureTestingModule({providers: [
        { provide: UserSessionService, useClass: MockUserSessionService }, { provide: HttpClient, useClass: MockHttpClient }
      ]});
    service = TestBed.inject(UserAttrService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should save user favorite ', () => {
    service.saveUserFavorite('1', 123).subscribe((res) => {
      expect(res.data.insert_user_fav.affected_rows).toEqual(1);
    });
  });
});
