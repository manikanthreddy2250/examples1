import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {CreateFields, WhereClause} from '@ecp/gql-tk-beta';
import { Observable } from 'rxjs';
import { getUserFavoriteQuery } from 'src/app/shared/graphql/userattributesdomain/userattributesQuery';
import {UserSessionService} from 'src/app/shared/services/user-session/user-session.service';
import {environment} from '../../../environments/environment';
import {BaseGraphQlService} from '../base/base-graphql.service';

@Injectable({
  providedIn: 'root'
})

@Injectable({
  providedIn: 'root'
})
export class UserAttrService extends BaseGraphQlService {

  constructor(http: HttpClient, public readonly userSessionService: UserSessionService) {
    super(http, userSessionService, environment.USER_ATTRIBUTES_API, environment.USER_ATTRIBUTES_API);
  }

  saveUserFavorite(favoriteTypeId, favoriteValue): Observable<any> {
    const createFields: CreateFields[] = [];
    const userIdColumn = {column: 'user_id', value: this.userSessionService.getUserName()} ;
    const favoriteTypeIdColumn = {column: 'user_fav_typ_ref_id', value: favoriteTypeId} ;
    const favoriteValueColumn = {column: 'user_fav_val', value: favoriteValue} ;
    createFields.push({fields: [userIdColumn, favoriteTypeIdColumn, favoriteValueColumn]});
    return this.create('user_fav', createFields);
  }

  getUserFavorites(favoriteTypeId, userId): Observable<any> {
    const getUserFavoritesQuery = {
      query: getUserFavoriteQuery,
      variables: {
        favoriteTypeId,
        userId
      }
    };
    return this.rawCrudQuery(getUserFavoritesQuery);
  }

  deleteUserFavoriteProvider(userId, favoriteValue): Observable<any> {
    const deleteFilterFields: WhereClause[] = [
      UserAttrService.buildWhereClause('user_id', userId),
      UserAttrService.buildWhereClause('user_fav_val', favoriteValue)];
    return this.delete('user_fav', deleteFilterFields);
  }
}
