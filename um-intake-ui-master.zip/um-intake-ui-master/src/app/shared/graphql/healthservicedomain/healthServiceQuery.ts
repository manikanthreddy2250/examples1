const hscReturnColumns = '    hsc_id\n' +
  '    creat_user_id\n' +
  '    indv_key_val\n' +
  '    creat_dttm\n' +
  '    mbr_cov_dtl\n' +
  '    hsc_sts_ref_id\n' +
  '    hsc_provs {\n' +
  '       prov_loc_affil_dtl\n' +
  '       }\n ' +
  '    srvc_set_ref_cd {\n' +
  '       ref_desc\n' +
  '       }\n ' +
  '    hsc_keys {\n' +
  '       hsc_key_val\n' +
  '       } \n ';

const hscKeysColumns =    '     hsc_keys {\n' +
                                          '       hsc_id\n' +
                                          '       hsc_key_val\n' +
                                          '       inac_ind\n' +
                                          '       hsc_key_typ_ref_id\n' +
                                          '  }\n';

const hscServiceTypeColumns =    '     hsc_rev_typ_ref_cd {\n' +
  '       ref_desc\n' +
  '  }\n';

export const updateProviderDataQuery = 'mutation updateProvider($serviceHscProviderId: bigint, $hscServiceId: bigint!){ \n' +
                          'update_hsc_srvc_by_pk(_set: {srvc_hsc_prov_id: $serviceHscProviderId}, pk_columns: {hsc_srvc_id: $hscServiceId}) { \n' +
                          ' hsc_srvc_id \n' +
                          '} \n' +
                          '} \n';

export const insertHsrDocProcMutation = `
                      mutation HsrDocProcMutation($docVariables: hsr_doc_proc_insert_input!) {
                      insert_hsr_doc_proc_one(object: $docVariables) {
                          hsr_doc_proc_id
                      }
                    }`;

export const  insertHsrDocProcSbjMutation = `
                     mutation HsrDocProcSbjMutation($docVariables: hsr_doc_proc_sbj_insert_input!) {
                       insert_hsr_doc_proc_sbj_one(object: $docVariables) {
                         hsr_doc_proc_id
                       }
                     }
                   `;

export const deleteHsrDocProcSbjMutation = `
               mutation deleteHsrDocProcSbjMutation($hsrDocProcId: bigint!) {
                 delete_hsr_doc_proc_sbj(where: {hsr_doc_proc_id: {_eq: $hsrDocProcId}}) {
                   returning {
                     hsr_doc_proc_id
                   }
                 }
               }
           `;

export const deleteHsrDocProcMutation = `
               mutation deleteHsrDocProcMutation($hsrDocProcId: bigint!) {
                 delete_hsr_doc_proc(where: {hsr_doc_proc_id: {_eq: $hsrDocProcId}}) {
                   returning {
                     hsr_doc_proc_id
                   }
                 }
               }
           `;

export const getHscDatabyUserNameQuery = 'query getHscDetailbyUserName($userName: String) {\n' +
                             'hsc(where: {creat_user_id: {_eq: $userName}},order_by: {chg_dttm: desc}, limit: 10) {\n' +
                              hscReturnColumns +
                             '  } \n' +
                             '}\n';

export const getHscDataByProviderQuery = 'query getHscDetailbyProvider($providerKeyVal: String,$prov_key_typ_ref_id: Int  ) {\n' +
                       '    hsc(where: {hsc_provs: {prov_key_val: {_eq: $providerKeyVal},prov_key_typ_ref_id: {_eq: $prov_key_typ_ref_id}}}, order_by: {hsc_id: desc}, limit: 10) {\n' +
                            hscReturnColumns +
                           '  } \n' +
                           '}\n';

export const getHscDataByMemberIdQuery = 'query getHscDetailbyMember($indvKeyVal: String ) {\n' +
                                             '    hsc(where: {indv_key_val: {_eq: $indvKeyVal}}, order_by: {hsc_id: desc}, limit: 10) {\n' +
                                              hscReturnColumns +
                                             '  } \n' +
                                             '}\n';

export const getHscProvDataByProvIdQuery = 'query getHscProvDataByProvIdQuery($providerID: bigint!) { \n' +
                                                   'hsc_prov(where: {hsc_prov_id: {_eq:$providerID}}) { \n' +
                                                   'prov_loc_affil_dtl \n' +
                                                   'prov_loc_affil_id \n' +
                                                   'prov_key_val \n' +
                                                   '} \n' +
                                                   '} \n';

export const getHscIdDetailsQuery = 'query HscIdDetails {\n' +
                         ' hsc(where: {hsc_id: {_in: [1,5,50,100,300,7448,7417,7557,8245,8438,8493,8486,8613,8629,8630,8685,8668,8670,8671,8673]} }) {\n' +
                         '    hsc_id\n' +
                         '    auth_strt_dt\n' +
                         '    auth_end_dt\n' +
                         '    auth_typ_ref_id\n' +
                         '    srvc_set_ref_id\n' +
                         '    indv_id\n' +
                         '    hsc_sts_ref_id\n' +
                         ' } \n' +
                         ' } \n';

export const getHscProvDataQuery = 'query MyQuery($hscId: bigint) { \n' +
                           'hsc_prov(where: {hsc_id: {_eq:$hscId}}) { \n' +
                           ' prov_key_val \n' +
                           'hsc_prov_id \n' +
                           'prov_loc_affil_id \n' +
                           ' prov_loc_affil_dtl \n' +
                           ' spcl_ref_id \n' +
                           ' telcom_adr_id \n' +
                           'prov_key_typ_ref_id \n' +
                           'hsc_prov_roles { \n' +
                           ' prov_role_ref_id \n' +
                           '} \n' +
                           '} \n' +
                           '} \n';

export const getHscProviderDataQuery = 'query ($hscId: bigint!) {\n' +
                         '     hsc_prov(where: {hsc_id: {_eq: $hscId}}) {\n' +
                         '    hsc_id\n' +
                         '    hsc_prov_id\n' +
                         '    hsc_prov_roles{ \n' +
                         '    hsc_prov_id\n' +
                           ' prov_role_ref_id\n' +
                           ' }\n' +
                         ' } \n' +
                         ' } \n';

export const getServiceByHscIdQuery = ' query ($hscId:bigint!) {\n' +
                           'hsc_srvc(where: {hsc_id: {_eq: $hscId}}) {\n' +
                           'hsc_srvc_id\n' +
                           'srvc_hsc_prov_id\n' +
                           '}\n' +
                           '} \n';

export const getHscDetailDataQuery = 'query ($Hscid:bigint!) {\n' +
                           '    hsc(where: {hsc_id: {_eq: $Hscid}}) {\n' +
                           '    flwup_cntc_dtl\n' +
                           '    hsc_rev_typ_ref_id\n' +
                           '    rev_prr_ref_id\n' +
                           '    srvc_set_ref_id\n' +
                           '    hsc_sts_ref_id\n' +
                           '    mbr_cov_dtl\n' +
                           '    indv_key_typ_ref_id\n' +
                           '    indv_key_val\n' +
                           '    orig_sys_ref_id\n' +
                          hscKeysColumns +
                          hscServiceTypeColumns +
                           '  }\n' +
                           '}\n';

export const getNotesSubjectQuery = 'query ($inActive: smallint!) {hsr_note(where: {src_user_nm: {_in: ["provider","clinician"]}}) {\n' +
                         '    hsr_note_sbjs(where: {inac_ind: {_eq: $inActive, _is_null: false}}) {\n' +
                         '      inac_ind\n' +
                         '    }\n' +
                         '    hsc_id\n' +
                         '    creat_user_id\n' +
                         '    creat_dttm\n' +
                         '    note_typ_ref_id\n' +
                         '    note_txt_lobj\n' +
                         '    src_rec_guid\n' +
                         '  }}';

export const getNotesDataByHscId = 'query ($hscId:bigint!) {\n' +
                                           ' hsr_note(where: {hsc_id: {_eq: $hscId}}){\n' +
                                           '    hsr_note_sbjs(where: {inac_ind: {_eq: 0}}) {\n' +
                                           '      inac_ind\n' +
                                           '    }\n' +
                                           '    hsc_id\n' +
                                           '    hsr_note_id\n' +
                                           '    creat_user_id\n' +
                                           '    note_titl_txt\n' +
                                           '    creat_dttm\n' +
                                           '    note_typ_ref_id\n' +
                                           '    note_txt_lobj\n' +
                                           '    src_rec_guid\n' +
                                           '  }\n' +
                                           '}\n';

export const getNotesDataByRole = 'query ($testAuthorRole: String, $inActive: smallint!) {hsr_note(where: { src_user_nm: {_eq: $testAuthorRole}}) {\n' +
                                            '    hsr_note_sbjs(where: {inac_ind: {_eq: $inActive, _is_null: false}}) {\n' +
                                            '      inac_ind\n' +
                                            '    }\n' +
                                            '    creat_user_id\n' +
                                            '    creat_dttm\n' +
                                            '    note_typ_ref_id\n' +
                                            '    note_txt_lobj\n' +
                                            '    src_rec_guid\n' +
                                            '  }}';

// export const getAuthDraftDetailsQuery = 'query ($hscid:bigint!) {\n' +
//                                                 '  hsc(where: {hsc_id: {_eq: $hscid}, hsc_sts_ref_id: {_eq: 19274}}) {\n' +
//                                                 ' hsc_id\n' +
//                                                 ' auth_end_dt\n' +
//                                                 ' auth_strt_dt\n' +
//                                                 ' auth_typ_ref_id\n' +
//                                                 ' cont_of_care_ind\n' +
//                                                 ' indv_id\n' +
//                                                 ' mbr_cov_dtl\n' +
//                                                 ' rev_prr_ref_id\n' +
//                                                 ' srvc_set_ref_id\n' +
//                                                 ' flwup_cntc_dtl\n' +
//                                                 hscKeysColumns +
//                                                 '  hsc_diags {\n' +
//                                                         ' diag_cd\n' +
//                                                        '   inac_ind\n' +
//                                                        '   hsc_id\n' +
//                                                        '   pri_ind\n' +
//                                                        '    hscDiagDiagCdRef {\n' +
//                                                                 ' shrt_desc\n' +
//                                                                 ' full_desc\n' +
//                                                                 ' cd_desc\n' +
//                                                              '}\n' +
//                                                      '  }\n' +
//                                                 ' hsc_provs {\n' +
//                                                 '  hsc_id\n' +
//                                                 '  hsc_prov_id\n' +
//                                                 '  prov_loc_affil_id\n' +
//                                                 '  spcl_ref_id\n' +
//                                                 '  telcom_adr_id\n' +
//                                                 '   hsc_prov_roles {\n' +
//                                                 '    hsc_prov_id\n' +
//                                                 '    prov_role_ref_id\n' +
//                                                 '   }\n' +
//                                                 '  }\n' +
//                                                 'hsc_srvcs { \n' +
//                                                 '        inac_ind \n' +
//                                                 '        proc_cd \n' +
//                                                 '        proc_cd_schm_ref_id \n' +
//                                                 '        proc_othr_txt \n' +
//                                                 '        srvc_hsc_prov_id \n' +
//                                                 '        hsc_srvc_non_facls { \n' +
//                                                 '          init_trt_dt \n' +
//                                                 '          plsrv_ref_id \n' +
//                                                 '          proc_freq_ref_id \n' +
//                                                 '          proc_mod_1_cd \n' +
//                                                 '          proc_mod_2_cd \n' +
//                                                 '          proc_mod_3_cd \n' +
//                                                 '          proc_mod_4_cd \n' +
//                                                 '          proc_unit_cnt \n' +
//                                                 '          proc_uom_ref_id \n' +
//                                                 '          srvc_desc_ref_id \n' +
//                                                 '          srvc_dtl_ref_id \n' +
//                                                 '          srvc_end_dt \n' +
//                                                 '          srvc_strt_dt \n' +
//                                                 '          unit_per_freq_cnt \n' +
//                                                 '           hsc_srvc_non_facl_dmes { \n' +
//                                                 '            clin_ill_desc_txt \n' +
//                                                 '            dme_procrmnt_typ_id \n' +
//                                                 '            dme_tot_cst_amt \n' +
//                                                 '            ental_fd_sngl_src_nutritn_ind \n' +
//                                                 '            fml_nm_txt \n' +
//                                                 '            hsc_srvc_id \n' +
//                                                 '            med_cond_txt \n' +
//                                                 '            spl_desc_txt \n' +
//                                                 '            srvc_desc_txt \n' +
//                                                 '          }\n' +
//                                                 '        } \n' +
//                                                 '      } \n' +
//                                                 ' hsc_facls {\n' +
//                                                 '      hsc_id\n' +
//                                                 '      actul_admis_dttm\n' +
//                                                 '      actul_dschrg_dttm\n' +
//                                                 '      expt_admis_dt\n' +
//                                                 '      expt_dschrg_dt\n' +
//                                                 '      plsrv_ref_id\n' +
//                                                 '      srvc_desc_ref_id\n' +
//                                                 '      srvc_dtl_ref_id\n' +
//                                                 '    }\n' +
//                                                 'hsr_doc_procs {\n' +
//                                                 '      hsr_doc_proc_id\n' +
//                                                 '      hsc_id\n' +
//                                                 '      doc_desc\n' +
//                                                 '      doc_key_val\n' +
//                                                 '      doc_proc_sts_ref_id\n' +
//                                                 '      doc_sys_ref_id\n' +
//                                                 '      hsr_doc_typ_ref_id\n' +
//                                                 '      creat_dttm\n' +
//                                                 '      creat_user_id\n' +
//                                                 '      hsr_doc_proc_sbjs {\n' +
//                                                 '        hsr_doc_proc_id\n' +
//                                                 '        hsr_sbj_rec_id\n' +
//                                                 '        hsr_sbj_typ_ref_id\n' +
//                                                 '      }\n' +
//                                                 '      doc_proc_sts_desc\n' +
//                                                 '    }\n' +
//                                                 ' hsr_notes{\n' +
//                                                 '	     hsr_note_id\n ' +
//                                                 '      note_titl_txt\n ' +
//                                                 '		   note_txt_lobj\n ' +
//                                                 '			 creat_user_id\n ' +
//                                                 '	     note_typ_ref_id\n' +
//                                                 '			 src_user_nm\n' +
//                                                 '		   creat_dttm\n' +
//                                                 '       hsr_note_sbjs {\n' +
//                                                 '         note_sbj_typ_ref_id\n' +
//                                                 '         note_sbj_rec_id\n' +
//                                                 '         inac_ind\n' +
//                                                 '         hsr_note_id\n' +
//                                                 '         chg_sys_ref_id\n' +
//                                                 '         creat_dttm\n' +
//                                                 '         creat_sys_ref_id\n' +
//                                                 '         creat_user_id\n' +
//                                                 '         chg_user_id\n' +
//                                                 '       }\n' +
//                                                 '		}\n' +
//                                                 ' }\n' +
//                                                 '}\n';
