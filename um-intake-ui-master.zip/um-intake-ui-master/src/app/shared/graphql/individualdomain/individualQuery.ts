export const getIndvDetailsbyIdQuery = 'query indvName($indId: bigint) {\n' +
                       ' indv(where: {indv_id: {_eq: $indId}}) {\n' +
                       '    fst_nm\n' +
                       '    lst_nm\n' +
                       ' } \n' +
                       ' } \n';

export const getIndvDetailsByIndvKeyVal = 'query IDSearch($indvkeyId: String) {\n' +
                         '  v_indv_srch(where: {indv_key_val: {_eq: $indvkeyId}, indv_key_typ_ref_id: {_eq: 2757}}) {\n' +
                         '    indv_id\n' +
                         '    fst_nm\n' +
                         '    lst_nm\n' +
                         '    indv_key_val\n' +
                         '  } \n' +
                         '}\n';

export const getIndvDetailsByIndvkeyIDQuery = 'query IDSearch($individualIds: [bigint!]) {\n' +
                         '  indv_key(where: {indv_id: {_in: $individualIds}, indv_key_typ_ref_id: {_eq: 2757}, orig_sys_cd: {_like: "%CDB%"}}) {\n' +
                         '    indv_key_val\n' +
                         '    orig_sys_cd\n' +
                         '    indv_id\n' +
                         '  } \n' +
                         '}\n';

export const getIndvDataQuery = 'query IDSearch($memberId: String, $firstName: String, $lastName: String, $dob: date) {\n' +
                                      '  v_indv_srch(where: {indv_key_val: {_eq: $memberId}, fst_nm: {_eq: $firstName}, lst_nm: {_eq: $lastName}, bth_dt: {_eq: $dob},  indv_key_typ_ref_id: {_eq: 2757}}) {\n' +
                                      '    indv_id\n' +
                                      '    fst_nm\n' +
                                      '    lst_nm\n' +
                                      '    bth_dt\n' +
                                      '    indv_key_val\n' +
                                      '    indv_key_typ_ref_id\n' +
                                      '    gdr_ref_id\n' +
                                      '    adr_ln_1_txt\n' +
                                      '    adr_ln_2_txt\n' +
                                      '    cty_nm\n' +
                                      '    st_ref_id\n' +
                                      '    zip_cd_txt\n' +
                                      '  } \n' +
                                      '}\n';

export const getIndvDetailsByIndvKey = 'query IDSearch($indv_key_val: String) {\n' +
  '  v_indv_srch(where: {indv_key_val: {_eq: $indv_key_val}}) {\n' +
  '    indv_id\n' +
  '    fst_nm\n' +
  '    lst_nm\n' +
  '    bth_dt\n' +
  '    gdr_ref_id\n' +
  '    adr_ln_1_txt\n' +
  '    indv_key_val\n' +
  '  } \n' +
  '}\n';
