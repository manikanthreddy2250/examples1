export const IDSearchQuery = 'query IDSearch($orgSysMbrIds: [String!], $orgSysCodes: [String!]) {\n' +
                           '  mbrshp(where: {orig_sys_mbr_id: {_in: $orgSysMbrIds},\n' +
                           '              orig_sys_cd: {_in: $orgSysCodes}}) {\n' +
                           '   mbr_rel_ref_id\n' +
                           '   cob_ind\n' +
                           '   orig_sys_cd\n' +
                           '   orig_sys_mbr_id\n' +
                           '   mbr_covs {\n' +
                           '     mbr_cov_id\n' +
                           '     cov_eff_dt\n' +
                           '     cov_end_dt\n' +
                           '     pol_nbr\n' +
                           '     cov_typ_ref_id\n' +
                           '     prdct_catgy_ref_id\n' +
                           '     prdct_ref_id\n' +
                           '     clm_pltfm_ref_id\n' +
                           '   } \n' +
                           '  } \n' +
                           '}\n';

export const getMembershipDetailsByOrgIdQuery = 'query MyQuery($originalSystemMemberId: String!) { \n' +
                           'mbrshp(where: {orig_sys_mbr_id: {_eq: $originalSystemMemberId}}) { \n' +
                           '  mbr_pcps { \n' +
                           '    prov_key_val \n' +
                           '    prov_key_typ_ref_id  \n' +
                           '  }  \n' +
                           ' } \n' +
                           '}  \n';

export const getMembershipDetailsByMemberCoverageIdQuery = 'query memCovQuery($mbr_cov_id: bigint!) { \n' +
  'mbr_cov(where: {mbr_cov_id: {_eq: $mbr_cov_id}}){\n' +
  '   mbr_cov_id \n' +
  '   mbrshp_id \n' +
  '   carr_nm \n' +
  '   cov_eff_dt \n' +
  '   cov_end_dt \n' +
  '   pol_iss_st_ref_id \n' +
  '   pol_nbr \n' +
  '   cov_typ_ref_id \n' +
  '   prdct_catgy_ref_id \n' +
  '  }\n' +
  '}\n';
