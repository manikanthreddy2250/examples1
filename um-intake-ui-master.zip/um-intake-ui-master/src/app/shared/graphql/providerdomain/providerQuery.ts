import {RawQuery} from '@ecp/gql-tk-beta';
const DISTINCT_FILTER_FOR_QUERY = ' distinct_on: [prov_id, adr_ln_1_txt, adr_ln_2_txt, cty_nm, st_ref_id, zip_cd_txt]) {\n';

export const getProvKeyValByProvIdQuery = 'query ProvTinOrNpiDetails($providerID: bigint, $providerKeyTypeRefId: Int) {\n' +
                           '  prov_key(where: {prov_id: {_eq: $providerID}, prov_key_typ_ref_id: {_eq: $providerKeyTypeRefId}}) {\n' +
                           '    prov_key_val\n' +
                           '   }\n' +
                           '  }\n';

export const getProviderDataByProvIDQuery = 'query ProvTinOrNpiDetails($providerKeyVal: bigint, $providerKeyTypeRefId: Int) {\n' +
                           '  v_prov_srch(where: {prov_id: {_eq: $providerKeyVal}, prov_key_typ_ref_id: {_eq: $providerKeyTypeRefId}}) {\n' +
                           '    prov_id\n' +
                           '    fst_nm\n' +
                           '    lst_nm\n' +
                           '    bus_nm\n' +
                           '    adr_ln_1_txt\n' +
                           '    adr_ln_2_txt\n' +
                           '    cty_nm\n' +
                           '    st_ref_id\n' +
                           '    zip_cd_txt\n' +
                           '    prov_key_val\n' +
                           '    prov_key_typ_ref_id\n' +
                           '    spcl_ref_id\n' +
                           '    telcom_adr_id\n' +
                           '    prov_loc_affil_id\n' +
                           '     }\n' +
                           '  }\n';

export const getProvDetailsBasedOnZipandSpecialityQuery = 'query ProvDetailsBasedOnZipandSpeciality($specialtyRefId: Int, $zipCode: String, $categoryRefId: Int) {\n' +
                         '  v_prov_srch(where: {spcl_ref_id: {_eq: $specialtyRefId}, zip_cd_txt: {_eq: $zipCode}, prov_catgy_ref_id: {_eq: $categoryRefId}} \n' +
                         DISTINCT_FILTER_FOR_QUERY +
                         '    prov_id\n' +
                         '    fst_nm\n' +
                         '    lst_nm\n' +
                         '    bus_nm\n' +
                         '    adr_ln_1_txt\n' +
                         '    adr_ln_2_txt\n' +
                         '    cty_nm\n' +
                         '    st_ref_id\n' +
                         '    zip_cd_txt\n' +
                         '    spcl_ref_id\n' +
                         '    telcom_adr_id\n' +
                         '    prov_loc_affil_id\n' +
                         '    prov_adr_id\n' +
                         '    prov_catgy_ref_id\n' +
                         '   }\n' +
                         '  }\n'

export const getProviderDataByAdrIdQuery = 'query getDetailsByAdrIdQuery($provAdrId: bigint!) {\n' +
                         'v_prov_srch_v2(where: {prov_adr_id: {_eq: $provAdrId}}, limit: 1) {\n' +
                         'bus_nm\n' +
                         'fst_nm\n' +
                         'lst_nm\n' +
                         'cty_nm\n' +
                         'adr_typ_ref_id\n' +
                         'adr_ln_2_txt\n' +
                         'adr_ln_1_txt\n' +
                         'prov_catgy_ref_id\n' +
                         'st_ref_id\n' +
                         'zip_cd_txt\n' +
                         'telcom_adr_id\n' +
                         'spcl_ref_id\n' +
                         'prov_key_typ_ref_id\n' +
                         'prov_key_val\n' +
                         'prov_adr_id\n' +
                         '}\n' +
                         '} \n';

export const getProvDetailsBasedOnTinorNpiQuery =  'query ProvDetailsBasedOnTinorNpi($provID:  bigint!, $provAdrId: bigint!, $provCategoryRefId: Int) {\n' +
                           '  v_prov_srch(where: {prov_id: {_eq: $provID}, prov_adr_id: {_eq: $provAdrId}},distinct_on: prov_id){ \n' +
                           '    prov_id\n' +
                           '    fst_nm\n' +
                           '    lst_nm\n' +
                           '    bus_nm\n' +
                           '   }\n' +
                           '  }\n';

export const getProvDataByOnTinorNpiQuery = 'query ProvDetailsBasedOnTinorNpi($providerCategoryId: Int, $providerTIN: String, $providerNPI: String, $providerTINKey: Int, $providerNPIKey: Int) {\n' +
                         '  v_prov_srch(where: {prov_catgy_ref_id: {_eq: $providerCategoryId}, _and: [\n' +
                         '    {_and: [\n' +
                         '           {prov_key_typ_ref_id: {_eq: $providerTINKey}},\n' +
                         '           {prov_key_val: {_eq: $providerTIN}}\n' +
                         '     ]},\n' +
                         '    {_and: [\n' +
                         '           {prov_key_typ_ref_id: {_eq: $providerNPIKey}},\n' +
                         '           {prov_key_val: {_eq: $providerNPI}}\n' +
                         '    ]}\n' +
                         '  ]\n' +
                         '  }\n' +
                         DISTINCT_FILTER_FOR_QUERY +
                         '    prov_id\n' +
                         '    fst_nm\n' +
                         '    lst_nm\n' +
                         '    bus_nm\n' +
                         '    adr_ln_1_txt\n' +
                         '    adr_ln_2_txt\n' +
                         '    cty_nm\n' +
                         '    st_ref_id\n' +
                         '    zip_cd_txt\n' +
                         '    spcl_ref_id\n' +
                         '    telcom_adr_id\n' +
                         '    prov_loc_affil_id\n' +
                         '    prov_adr_id\n' +
                         '    prov_catgy_ref_id\n' +
                         '   }\n' +
                         '  }\n';

export const getProviderDataByProvIDAdrIdQuery = 'query getProviderDataByProvIDAdrIdQuery($provId: bigint, $provAdrId: bigint, $provtelcomAdrId: String, $ProvSpecialtyRefId: Int) {\n' +
                           '  v_prov_srch(where: {prov_id: {_eq: $provId}, prov_adr_id: {_eq: $provAdrId}, telcom_adr_id: {_eq: $provtelcomAdrId},\n' +
                           'spcl_ref_id: {_eq: $ProvSpecialtyRefId}},\n' +
                           DISTINCT_FILTER_FOR_QUERY +
                           '    prov_id\n' +
                           '    fst_nm\n' +
                           '    lst_nm\n' +
                           '    bus_nm\n' +
                           '    adr_ln_1_txt\n' +
                           '    adr_ln_2_txt\n' +
                           '    cty_nm\n' +
                           '    st_ref_id\n' +
                           '    zip_cd_txt\n' +
                           '    spcl_ref_id\n' +
                           '    telcom_adr_id\n' +
                           '    prov_loc_affil_id\n' +
                           '    prov_catgy_ref_id\n' +
                           '    prov_key_val\n' +
                           '    prov_adr_id\n' +
                           '   }\n' +
                           '  }\n'

export const getProvDetailsByProvCatIdQuery = 'query ProvDetailsByProvCatIdQuery($providerCategoryId: Int, $providerTIN: String, $providerNPI: String, $providerTINKey: Int, $providerNPIKey: Int) {\n' +
                         '  v_prov_srch(where: {prov_catgy_ref_id: {_eq: $providerCategoryId}, _or: [\n' +
                         '    {_and: [\n' +
                         '           {prov_key_typ_ref_id: {_eq: $providerTINKey}},\n' +
                         '           {prov_key_val: {_eq: $providerTIN}}\n' +
                         '     ]},\n' +
                         '    {_and: [\n' +
                         '           {prov_key_typ_ref_id: {_eq: $providerNPIKey}},\n' +
                         '           {prov_key_val: {_eq: $providerNPI}}\n' +
                         '    ]}\n' +
                         '  ]\n' +
                         '  }\n' +
                         DISTINCT_FILTER_FOR_QUERY +
                         '    prov_id\n' +
                         '    fst_nm\n' +
                         '    lst_nm\n' +
                         '    bus_nm\n' +
                         '    adr_ln_1_txt\n' +
                         '    adr_ln_2_txt\n' +
                         '    cty_nm\n' +
                         '    st_ref_id\n' +
                         '    zip_cd_txt\n' +
                         '    spcl_ref_id\n' +
                         '    telcom_adr_id\n' +
                         '    prov_loc_affil_id\n' +
                         '    prov_catgy_ref_id\n' +
                         '    prov_adr_id\n' +
                         '   }\n' +
                         '  }\n';

export const getProviderDraftDataQuery = 'query getProviderDraftData($prov_loc_affil_id: bigint, $provider_key_value_typ_ref_tin: Int) {\n' +
                         '  v_prov_srch(distinct_on: adr_ln_1_txt, where: {prov_loc_affil_id: {_eq: $prov_loc_affil_id}, _and: {prov_key_typ_ref_id: {_eq: $provider_key_value_typ_ref_tin}}}) {\n' +
                         '    adr_ln_1_txt\n' +
                         '    adr_ln_2_txt\n' +
                         '    bus_nm\n' +
                         '    cty_nm\n' +
                         '    fst_nm\n' +
                         '    lst_nm\n' +
                         '    prov_catgy_ref_id\n' +
                         '    prov_id\n' +
                         '    prov_key_typ_ref_id\n' +
                         '    prov_key_val\n' +
                         '    prov_loc_affil_id\n' +
                         '    spcl_ref_id\n' +
                         '    st_ref_id\n' +
                         '    telcom_adr_id\n' +
                         '    zip_cd_txt\n' +
                         '  }\n' +
                         '}\n';

export const getProviderDetailsQuery = 'query ProvDetails($providerCategoryId: Int, $providerFirstName: String, $providerLastName: String, $providerState: Int, $providerZipCode: String, $providerOrgName: String, $specialtyRefID: Int) {\n' +
                             '  v_prov_srch(where: {prov_catgy_ref_id: {_eq: $providerCategoryId}, lst_nm: {_eq: $providerLastName}, st_ref_id: {_eq: $providerState}, zip_cd_txt: {_eq: $providerZipCode}, bus_nm: {_like: $providerOrgName},  spcl_ref_id: {_eq: $specialtyRefID}}\n' +
                             DISTINCT_FILTER_FOR_QUERY +
                             '    prov_id\n' +
                             '    fst_nm\n' +
                             '    lst_nm\n' +
                             '    bus_nm\n' +
                             '    adr_ln_1_txt\n' +
                             '    adr_ln_2_txt\n' +
                             '    cty_nm\n' +
                             '    st_ref_id\n' +
                             '    zip_cd_txt\n' +
                             '    prov_key_val\n' +
                             '    prov_key_typ_ref_id\n' +
                             '    spcl_ref_id\n' +
                             '    telcom_adr_id\n' +
                             '    prov_loc_affil_id\n' +
                             '    prov_catgy_ref_id\n' +
                             '    prov_adr_id\n' +
                             '   }\n' +
                             '  }\n';

export const getDistinctProviderDataByZipCodeQuery = 'query getDistinctProviderDataByStateCode($zipCodeText: String, $providerCategoryReferenceID: Int) {\n' +
                          '  v_prov_srch(where: {zip_cd_txt: {_eq: $zipCodeText}, prov_catgy_ref_id: {_eq: $providerCategoryReferenceID}}  distinct_on: [prov_id], limit: 5) {' +
                          '    prov_id\n' +
                          '    fst_nm\n' +
                          '    lst_nm\n' +
                          '    bus_nm\n' +
                          '    adr_ln_1_txt\n' +
                          '    adr_ln_2_txt\n' +
                          '    cty_nm\n' +
                          '    st_ref_id\n' +
                          '    zip_cd_txt\n' +
                          '    prov_key_val\n' +
                          '    prov_key_typ_ref_id\n' +
                          '    spcl_ref_id\n' +
                          '    telcom_adr_id\n' +
                          '    prov_loc_affil_id\n' +
                          '    prov_catgy_ref_id\n' +
                          '    prov_adr_id\n' +
                          '   }\n' +
                          '  }\n';

export const getProviderDataQuery  = function (providerCategoryId: number, providerFirstName: string, providerLastName: string,
                                                                           providerState: number, providerZipCode: string, providerOrgName: string, specialtyRefID: number): RawQuery {
                                                     if (providerFirstName) {
                                                       return {
                                                         query: 'query ProvDetails($providerCategoryId: Int, $providerFirstName: String, $providerLastName: String, \n' +
                                                           '$providerState: Int, $providerZipCode: String, $providerOrgName: String, $specialtyRefID: Int) {\n' +
                                                           '  v_prov_srch(where: {prov_catgy_ref_id: {_eq: $providerCategoryId},  fst_nm: {_eq: $providerFirstName}, \n' +
                                                           'lst_nm: {_like: "%' + providerLastName + '%"}, st_ref_id: {_eq: $providerState}, \n' +
                                                           'zip_cd_txt: {_eq: $providerZipCode}, bus_nm: {_eq: $providerOrgName}, spcl_ref_id: {_eq: $specialtyRefID}}\n' +
                                                           DISTINCT_FILTER_FOR_QUERY +
                                                           '    prov_id\n' +
                                                           '    fst_nm\n' +
                                                           '    lst_nm\n' +
                                                           '    bus_nm\n' +
                                                           '    adr_ln_1_txt\n' +
                                                           '    adr_ln_2_txt\n' +
                                                           '    cty_nm\n' +
                                                           '    st_ref_id\n' +
                                                           '    zip_cd_txt\n' +
                                                           '    prov_key_val\n' +
                                                           '    prov_key_typ_ref_id\n' +
                                                           '    spcl_ref_id\n' +
                                                           '    telcom_adr_id\n' +
                                                           '    prov_loc_affil_id\n' +
                                                           '    prov_catgy_ref_id\n' +
                                                           '    prov_adr_id\n' +
                                                           '   }\n' +
                                                           '  }\n',
                                                         variables: {
                                                           providerCategoryId,
                                                           providerLastName,
                                                           providerFirstName,
                                                           providerState,
                                                           providerZipCode,
                                                           providerOrgName,
                                                           specialtyRefID
                                                         }
                                                       };
                                                     } else {
                                                       return {
                                                         query: getProviderDetailsQuery,
                                                         variables: {
                                                           providerCategoryId,
                                                           providerLastName,
                                                           providerState,
                                                           providerZipCode,
                                                           providerOrgName,
                                                           specialtyRefID
                                                         }
                                                       };
                                                     }
                                                   }

export const getProvDetailByTaxIds = 'query TaxIdSearch($provKeyVal: [String!]) {\n' +
                        '  v_prov_srch(where: {prov_key_val: {_in: $provKeyVal}, prov_key_typ_ref_id: {_eq: 16333}},distinct_on: prov_id) {\n' +
                        '    prov_id\n' +
                        '    fst_nm\n' +
                        '    lst_nm\n' +
                        '    bus_nm\n' +
                        '    adr_ln_1_txt\n' +
                        '    adr_ln_2_txt\n' +
                        '    cty_nm\n' +
                        '    st_ref_id\n' +
                        '    zip_cd_txt\n' +
                        '    spcl_ref_id\n' +
                        '    telcom_adr_id\n' +
                        '    prov_loc_affil_id\n' +
                        '    prov_adr_id\n' +
                        '    prov_catgy_ref_id\n' +
                        '  } \n' +
                        '}\n'

