import {RawQuery} from '@ecp/gql-tk-beta';
export const getRefDataByRefID = 'query ReferenceData($referenceId: Int) {\n' +
                                         ' ref: hsr_ref (where: {ref_id: {_eq: $referenceId}}) {\n' +
                                             'ref_desc\n' +
                                             'ref_cd\n' +
                                             'ref_dspl\n' +
                                             'ref_id\n' +
                                         '  } \n' +
                                         '}\n';

export const getRefDataByRefName = 'query ReferenceData($referenceName: String!) {\n' +
                                           ' ref_set: hsr_ref_set(where: {ref_nm: {_eq: $referenceName}}) {\n' +
                                           '    ref_nm\n' +
                                           '    ref_id\n' +
                                           '    ref: hsr_ref {\n' +
                                           '     ref_cd\n' +
                                           '     ref_id\n' +
                                           '     ref_dspl\n' +
                                           '     ref_desc\n' +
                                           '     inac_ind\n' +
                                           '     bas_ref_nm\n' +
                                           '    }\n' +
                                           '  } \n' +
                                           '}\n';

export const getBulkRefDataByRefID  = 'query getReferenceList($refIds: [Int!]!) {\n' +
                                              ' ref: hsr_ref(where: {ref_id: { _in: $refIds } }){\n' +
                                              ' ref_id\n' +
                                              ' ref_dspl\n' +
                                              ' ref_desc\n' +
                                              ' }\n' +
                                              ' }\n';

export const getRefChildDataByRefIDQuery = 'query RefChildSearch ( $ref_id: Int!){\n' +
                                              'ref_chld: hsr_ref_chld(where: {ref_id: {_eq: $ref_id}}){\n' +
                                              'refSetByChldRefIdChldRefNm: hsr_ref_set{\n' +
                                              'ref: hsr_ref{\n' +
                                              'ref_desc\n' +
                                              'ref_dspl\n' +
                                              'ref_id\n' +
                                              '}\n' +
                                              '}\n' +
                                              '}\n' +
                                              '}\n';

export const getRefSetDataByRefNameQuery = 'query RefSmartSearch ( $ref_nm:String ){\n' +
                                                   ' ref_set: hsr_ref_set(where: {ref_nm: {_eq: $ref_nm}}){\n' +
                                                   ' ref: hsr_ref{\n' +
                                                   'ref_desc\n' +
                                                   'ref_dspl\n' +
                                                   'ref_id\n' +
                                                   ' }\n' +
                                                   '  }\n' +
                                                   '}\n';

export const getRefDataByBaseRefNameQuery =  'query RefSmartSearch ( $bas_ref_nm:String ){\n' +
                                                    ' ref: hsr_ref(where: {bas_ref_nm: {_eq: $bas_ref_nm}}){\n' +
                                                    'inac_ind\n' +
                                                    'ref_cd\n' +
                                                    'ref_desc\n' +
                                                    'ref_dspl\n' +
                                                    'ref_id\n' +
                                                    '  } \n' +
                                                    '}\n';

export const RefSearchQuery = 'query RefSearch{\n' +
                                      ' ref: hsr_ref(where: {bas_ref_nm: {_in: ["relationshipCode", "genderType", "stateCode","productCategoryType","coverageType"]}}){\n' +
                                      'inac_ind\n' +
                                      'ref_cd\n' +
                                      'ref_desc\n' +
                                      'ref_dspl\n' +
                                      'ref_id\n' +
                                      '  } \n' +
                                      '}\n';

export const getProcedureDetailsQuery = 'query procedureSmartSearchQuery($searchText: String!,$searchType: String!) {\n' +
                                                '    ProcedureSmartSearch(searchQuery: $searchText,searchType: $searchType) {\n' +
                                                '     code\n' +
                                                '    description\n' +
                                                '    displayText\n' +
                                                '    searchType\n' +
                                                ' } \n' +
                                                ' } \n';

export const getDiagnosisDetailsQuery  = 'query ($search: String!) {\n' +
                         '    icd10_search(args:{search: $search}) {\n' +
                         '    cd_desc\n' +
                         '    diag_cd\n' +
                         '    full_desc\n' +
                         '    shrt_desc\n' +
                         ' } \n' +
                         ' } \n';

export const getSpecialtyQuery = function(refDescription, baseRefName: string): RawQuery {
                                              return {
                                                query: 'query ReferenceData($baseRefName: String, $refDescription: String) {\n' +
                                                  ' ref: hsr_ref (where: {bas_ref_nm: {_eq: $baseRefName}, ref_desc: {_ilike:  "%' + refDescription + '%"}}) {\n' +
                                                  '    ref_id\n' +
                                                  '    ref_desc\n' +
                                                  '  } \n' +
                                                  '}\n',
                                                variables: {
                                                  baseRefName,
                                                  refDescription
                                                }
                                              };
                                            };
