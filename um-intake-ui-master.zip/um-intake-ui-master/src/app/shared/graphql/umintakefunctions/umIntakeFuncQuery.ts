export const saveProcedureMutation = `
           mutation saveProcedure($saveProc : SaveProcedureRequest! ){
            saveProcedure(saveProcedureRequest : $saveProc){
                                                 hscSrvcId
              }
            }
           `;

export const upsertProcedureMutation = `
           mutation upsertProcedure($upsertProc : UpsertProcedureRequest! ){
            upsertProcedure(upsertProcedureRequest : $upsertProc){
            hscSrvcId
            hscDuplicates
          }
         }
           `;
export const deleteProcedureMutation = `
           mutation deleteProcedure($deleteProc : DeleteProcedureRequest! ){
       deleteProcedure(deleteProcedureRequest : $deleteProc){
                                                 hsc_id
              }
          }
           `;

export const submitHscMutation = `
          mutation submitHsc($submitHsc : SubmitHscRequest! ){
        submitHsc(submitHscRequest : $submitHsc){
          hsc_id
          hsc_sts_ref_id
        }
      }
           `;

export const createHscDraftMutationQuery = `
           mutation createDraftAuth($createHsc : DraftAuthRequest! ){
             createDraftAuth(draftAuthRequest : $createHsc){
                                                       hscId
                                                       caseId
                                                       tenantId
                                                       isMbrBlocked
                }
             }
           `;

export const saveAuthTypeHttpMutationQuery = `
            mutation saveAuthType($saveAuth : SaveAuthRequest! ){
                   saveAuthType(saveAuthRequest : $saveAuth){
                                                    hsc_id
                                                    hscDuplicates
                   }
              }
            `;

export const saveDiagnosisMutationQuery = `
              mutation saveDiagnosis($saveDiagnosis : SaveDiagnosisRequest! ){
                      saveDiagnosis(saveDiagnosisRequest : $saveDiagnosis){
                                                 hsc_diag_id
                      }
              }
            `;

export const deleteDiagnosisMutationQuery = `
              mutation deleteDiagnosis($deleteDiagnosis : DeleteDiagnosisRequest! ){
                deleteDiagnosis(deleteDiagnosisRequest : $deleteDiagnosis){
                                                 hsc_diag_id
                }
              }
            `;

export const saveProviderMutation = `
          mutation saveProvider($saveProv : SaveProviderRequest! ){
       saveProvider(saveProviderRequest : $saveProv){
                     hscId
         }
    }
           `;

export const saveContactMutation = `
          mutation saveconatct($saveContactreq : SaveContactRequest! ){
       saveContact(saveContactRequest : $saveContactreq){
                                                 hsc_id
                                                }
}
           `;

export const saveNoteMutation = `
          mutation saveNote($saveNotereq : SaveNoteRequest!){
    saveNote(saveNoteRequest : $saveNotereq){
     hsr_note_id
     creat_dttm
     creat_user_id
    }
}
           `;

export const getHscAuthDetails = `
          query getHscAuthDetails($getHscAuthRequest : GetHscAuthRequest! ){
       getHscAuthDetails(getHscAuthRequest : $getHscAuthRequest){
                                                 hsc{
                                                  hsc_id
                                                  creat_dttm
                                                  creat_user_id
                                                  indv_id
                                                  indv_key_typ_ref_id
                                                  indv_key_val
                                                  mbr_cov_dtl
                                                  hsc_sts_ref_id
                                                  flwup_cntc_dtl
                                                  rev_prr_ref_id
                                                  rev_prr_ref_cd{
                                                    ref_id
                                                    ref_cd
                                                    ref_desc
                                                    ref_dspl
                                                  }
                                                  srvc_set_ref_id
                                                  srvc_set_ref_cd{
                                                    ref_id
                                                    ref_cd
                                                    ref_desc
                                                    ref_dspl
                                                  }
                                                  hsc_keys{
                                                    hsc_id
                                                    hsc_key_val
                                                    hsc_key_typ_ref_id
                                                  }
                                                  hsc_srvcs{
                                                    hsc_id
                                                    hsc_srvc_id
                                                    inac_ind
                                                    proc_cd
                                                    proc_cd_schm_ref_id
                                                    proc_othr_txt
                                                    srvc_hsc_prov_id
                                                    hsc_srvc_non_facls{
                                                      proc_unit_cnt
                                                      init_trt_dt
                                                      plsrv_ref_id
                                                      plsrv_ref_cd{
                                                        ref_id
                                                        ref_cd
                                                        ref_desc
                                                        ref_dspl
                                                      }
                                                      proc_freq_ref_id
                                                      proc_freq_ref_cd{
                                                        ref_id
                                                        ref_cd
                                                        ref_desc
                                                        ref_dspl
                                                      }
                                                      proc_mod_1_cd
                                                      proc_mod_2_cd
                                                      proc_mod_3_cd
                                                      proc_mod_4_cd
                                                      proc_unit_cnt
                                                      proc_uom_ref_id
                                                      proc_uom_ref_cd{
                                                        ref_id
                                                        ref_cd
                                                        ref_desc
                                                        ref_dspl
                                                      }
                                                      srvc_desc_ref_id
                                                      srvc_desc_ref_cd{
                                                        ref_id
                                                        ref_cd
                                                        ref_desc
                                                        ref_dspl
                                                      }
                                                      srvc_dtl_ref_id
                                                      srvc_dtl_ref_cd{
                                                        ref_id
                                                        ref_cd
                                                        ref_desc
                                                        ref_dspl
                                                      }
                                                      srvc_end_dt
                                                      srvc_strt_dt
                                                      unit_per_freq_cnt
                                                      hsc_srvc_non_facl_dmes{
                                                        clin_ill_desc_txt
                                                        dme_procrmnt_typ_id
                                                        dme_tot_cst_amt
                                                        ental_fd_sngl_src_nutritn_ind
                                                        fml_nm_txt
                                                        med_cond_txt
                                                        spl_desc_txt
                                                        srvc_desc_txt
                                                      }
                                                    }
                                                  }
                                                  hsc_facls{
                                                    actul_admis_dttm
                                                    actul_dschrg_dttm
                                                    expt_admis_dt
                                                    expt_dschrg_dt
                                                    plsrv_ref_id
                                                    plsrv_ref_cd{
                                                        ref_id
                                                        ref_cd
                                                        ref_desc
                                                        ref_dspl
                                                      }
                                                    srvc_desc_ref_id
                                                    srvc_desc_ref_cd{
                                                        ref_id
                                                        ref_cd
                                                        ref_desc
                                                        ref_dspl
                                                      }
                                                    srvc_dtl_ref_id
                                                    srvc_dtl_ref_cd{
                                                        ref_id
                                                        ref_cd
                                                        ref_desc
                                                        ref_dspl
                                                      }
                                                  }
                                                  hsc_diags{
                                                    hsc_diag_id
                                                    diag_cd
                                                    inac_ind
                                                    diag_desc
                                                  }
                                                  hsr_notes{
                                                    hsr_note_id
                                                    note_titl_txt
                                                    note_txt_lobj
                                                    creat_user_id
                                                    note_typ_ref_id
                                                    src_user_nm
                                                    creat_dttm
                                                  }
                                                  hsc_provs{
                                                    auto_aprv_ltr_ind
                                                    hsc_prov_id
                                                    chg_sys_ref_id
                                                    chg_user_id
                                                    creat_sys_ref_id
                                                    creat_user_id
                                                    data_qlty_iss_list
                                                    data_secur_rule_list
                                                    end_dt
                                                    hsc_prov_end_rsn_ref_id
                                                    ltr_opt_out_cc_ind
                                                    med_rec_nbr
                                                    ntwk_strg_rsn_ref_id
                                                    ntwk_sts_ref_id
                                                    prov_loc_affil_dtl
                                                    prov_loc_affil_id
                                                    spcl_ref_id
                                                    strt_dt
                                                    telcom_adr_id
                                                    updt_ver_nbr
                                                    hsc_prov_roles{
                                                      hsc_prov_id
                                                      prov_role_ref_id
                                                    }
                                                  }


                                                }
    }
  }
           `;
