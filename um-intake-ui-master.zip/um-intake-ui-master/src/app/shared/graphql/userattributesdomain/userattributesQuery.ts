export const getUserFavoriteQuery = 'query getUserFavorites($userId: String,$favoriteTypeId: Int  ) {\n' +
                                       'user_fav(where: {user_id: {_eq: $userId}, user_fav_typ_ref_id: {_eq: $favoriteTypeId}}) {\n' +
                                       'user_id\n' +
                                       'user_fav_typ_ref_id\n' +
                                       'user_fav_val\n' +
                                       '  } \n' +
                                       '}\n';
