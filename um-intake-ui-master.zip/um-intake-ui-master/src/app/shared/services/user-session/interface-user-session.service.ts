import { Injectable } from '@angular/core';
import { MicroProductAuthService} from '@ecp/auth-library';
import {Constants} from 'src/app/constants/constants';
import {EcpAuthTokenService} from 'src/app/services/ecp-auth-token-service/ecp-auth-token.service';

export interface IUserSessionService {

  readonly microProductAuthService: MicroProductAuthService;
  readonly ecpAuthTokenService: EcpAuthTokenService;

  orgTag: string;
  APP_NAME_PREFIX: string;
  ECP_TOKEN_KEY: string;
  ACTIVE_ORG_ROLE_KEY: string;
  ACTIVE_ORG_ROLE_VALUE: string;

  getVarData();

  getUserPermission();

  getUserName();

  getEcpToken();

  getLocalEcpToken();

  getUserOrg();

  /*This is to get the active functional role of the loggedIn user*/
  getFunctionalRole();

}
