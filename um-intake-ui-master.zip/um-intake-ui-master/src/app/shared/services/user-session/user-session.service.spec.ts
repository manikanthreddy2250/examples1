import {HttpClient, HttpHandler} from '@angular/common/http';
import {CUSTOM_ELEMENTS_SCHEMA, Injectable, NO_ERRORS_SCHEMA } from '@angular/core';
import {async, TestBed } from '@angular/core/testing';
import {MicroProductAuthService} from '@ecp/auth-library';
import {of} from 'rxjs/internal/observable/of';
import { UserSessionService } from './user-session.service';
@Injectable()
class MicroProductAuthServiceStub {
  getEcpClaims() {
    return {'x-ecp-claims': {'x-ecp-cli-orgs': [{'org-id': 'ecp', 'func-roles': [{'role-name': 'provider'}]}]}};
  }
  getUserID() {
    return 'TESTUSERID';
  }

  isLocalHost() {
    return false;
  }
}

class MockHttpClient {
  post(url: string, body: any | null, options?: any) {
    if (url) {
        return of({
          "access_token": "eyJraWQiOiI3NTEwYJ9.eyJ4LWVtZWNwLWNsaS1vcmdzIjpbeyJH-OPj70TgUQ8v8qQO5w2YV2l5aGu4yGBw",
          "token_type": "bearer",
          "expires_in": 7199
        });
    }
  }
}

describe('UserSessionService', () => {
  let userSessionService: UserSessionService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      providers: [ {provide : MicroProductAuthService, useClass: MicroProductAuthServiceStub },
        { provide: HttpClient, useClass: MockHttpClient },],
    }).compileComponents();
  }));

  beforeEach(() => {
    userSessionService = TestBed.get(UserSessionService);
    const temp: any = '["ecp","sos_page_rules_admin"]';
    spyOn(localStorage, 'getItem').and.callFake((key: string): string => {
      return temp;
    });
  });

  afterEach(() => {
    TestBed.resetTestingModule();
  });

  it('should be created', () => {
    const service: UserSessionService = TestBed.get(UserSessionService);
    expect(service).toBeTruthy();
  });

  it('getUserName() should return userId from MicroProductAuthService', () => {
    expect(userSessionService.getUserName()).toEqual('TESTUSERID');
  });

  it('getUserPermission() should return list of user roles from MicroProductAuthService', () => {
    expect(userSessionService.getUserPermission()).toEqual('clinician');
  });

  it('getUserOrg() should return list of user org  from local Storage', () => {
    expect(userSessionService.getUserOrg()).toEqual('ecp');
  });

  it('getFunctionalRole() should return list of user org  from local Storage', () => {
    expect(userSessionService.getFunctionalRole()).toEqual('sos_page_rules_admin');
  });

});
