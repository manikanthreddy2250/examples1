import { Injectable } from '@angular/core';
import { MicroProductAuthService} from '@ecp/auth-library';
import {Constants} from 'src/app/constants/constants';
import {EcpAuthTokenService} from 'src/app/services/ecp-auth-token-service/ecp-auth-token.service';
import {IUserSessionService} from './interface-user-session.service';

@Injectable({
  providedIn: 'root'
})
export class UserSessionService implements IUserSessionService {
  constructor(readonly microProductAuthService: MicroProductAuthService,
              readonly ecpAuthTokenService: EcpAuthTokenService) {}

  orgTag = 'x-ecp-cli-orgs';
  APP_NAME_PREFIX = 'um_intake_ui_';
  ECP_TOKEN_KEY = 'ecp_token';
  ACTIVE_ORG_ROLE_KEY = 'active_org_role';
  ACTIVE_ORG_ROLE_VALUE = '["ecp", "engineer"]';

  getVarData() {
    const ecpClaims = this.microProductAuthService.getEcpClaims()['x-ecp-claims'];
    const orgs = ecpClaims[this.orgTag];
    return {
      orgs,
      ecpClaims
    };
  }

  getUserPermission() {
    let userPermission = Constants.UM_INTAKE_UI_USER_PERMISSION_CLINICIAN;
    if (this.microProductAuthService.isLocalHost()) { // to avoid adding a token in storage while working in local
      return userPermission;
    } else {
      const result = this.getVarData();
      const orgs = result.ecpClaims[this.orgTag];
      const appRoles = orgs.length > 0 ? orgs[0]['func-roles'][0]['appl-roles'] : [];

      if (appRoles?.length > 0) {
        appRoles.forEach((appRole) => {
          if (appRole.includes(this.APP_NAME_PREFIX)) {
            userPermission = appRole.replace(this.APP_NAME_PREFIX, '');
          }
        });
      }
      return userPermission;
    }
  }

  getUserName() {
    if (this.microProductAuthService.isLocalHost()) { // to avoid adding a token in storage while working in local
      return 'SYSTEM';
    } else {
      return this.microProductAuthService.getUserID();
    }
  }

  getEcpToken() {
    return this.microProductAuthService.getEcpToken();
  }

  getLocalEcpToken() {
    this.ecpAuthTokenService.getToken().subscribe((data) => {
      localStorage.setItem(this.ECP_TOKEN_KEY, data.access_token);
      localStorage.setItem(this.ACTIVE_ORG_ROLE_KEY, this.ACTIVE_ORG_ROLE_VALUE);
    });
  }

  getUserOrg() {
    const activeOrg = localStorage.getItem('active_org_role');
    const orgName = activeOrg.split(',', 1)[0].split('"', 2)[1];
    return orgName;
  }

  /*This is to get the active functional role of the loggedIn user*/
  getFunctionalRole() {
    const activeOrg = localStorage.getItem('active_org_role');
    const functionalRole = activeOrg.split(',', 2)[1].split('"', 2)[1];
    return functionalRole;
  }

}
