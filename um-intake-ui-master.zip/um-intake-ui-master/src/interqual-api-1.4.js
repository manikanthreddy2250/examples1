/* jshint ignore:start */
/**
 * InterQual Alliance Partner JavaScript API
 *
 */

var InterQualOnline = (InterQualOnline || (function()
{
    var globals =
    {
        iqFrameOrigin: '',
        apiVersionAction: 'API_VERSION',
        apiVersion: '1.4',
        defaultIframeId: 'iqConnect',
        defaultHeadlessIframeId: 'iqConnectHeadless'
    };

    var e = (typeof window !== 'undefined' ? window : exports);

    function format(str)
    {
        var args = typeof arguments[1] === 'object' ? arguments[1] : arguments;
        var formatted = decodeURI(str);
        for (var i = 1; i < args.length; i++)
        {
            var regexp = new RegExp('\\{' + (i - 1) + '\\}', 'gi');
            formatted = formatted.replace(regexp, args[i]);
        }
        return formatted;
    }

    function logInfo(message)
    {
        if (message)
        {
            e.console.log('InterQualOnline: ' + format(message, arguments));
        }
    }

    function logClientSideError(errorMessage)
    {
        e.console.error('InterQualOnline Error: ' + (errorMessage ? format(errorMessage, arguments) : 'Unknown error'));
    }

    logInfo('Self-Executing mck-interqualonline-api main function');
    var isInitialized = false;
    var nextRequestId = 0;
    var iqConfig =
    {
        frameElementId: 'iqconnect',
        errorHandler: function(errorMessage)
        {
            e.alert('(Default Error Handler, Please Register Your Own) \nError occurred :\n' + errorMessage);
        }
    };
    var iqFrameElement;

    var requestMap = {};

    function getRequestKey(requestId)
    {
        return 'r' + requestId;
    }

    function addRequest(fullRequest)
    {
        var key = getRequestKey(fullRequest.request.id);
        if (!requestMap[key])
        {
            requestMap[key] = fullRequest;
        }
        else
        {
            logClientSideError('Internal Error - Trying to add request ID ' + fullRequest.request.id + ' that already exists.');
        }
        return fullRequest;
    }

    function removeRequest(requestId)
    {
        var key = getRequestKey(requestId);
        if (requestMap[key])
        {
            var found = requestMap[key];
            delete requestMap[key];
            return found;
        }
        return null;
    }

    function removeExistingIframe()
    {
        var iframes = document.querySelectorAll('iframe[src*="index-ap.html"]');
        for (var i = 0; i < iframes.length; i++)
        {
            logInfo('Removing existing iframe (id={0})', iframes[i].id);
            iframes[i].parentNode.removeChild(iframes[i]);
        }
    }

    function initializeIQ(config)
    {
        iqFrameElement = undefined;
        if (!config)
        {
            logClientSideError('In InterQualOnline.initialize(config): config is required but empty');
            throw new Error('InterQual Configuration Parameter Required');
        }
        else if (!config.interqualFrameElementId)
        {
            logClientSideError('In InterQualOnline.initialize(config): config.interqualFrameElementId is required but empty');
            throw new Error('InterQual IFrame Element ID Required');
        }
        iqConfig.frameElementId = config.interqualFrameElementId;
        iqConfig.guidelineRestricted = config.guidelineRestricted;
        iqConfig.errorHandler   = config.errorHandler;
        iqConfig.newReviewStartedHandler = config.newReviewStartedHandler;
        iqConfig.reviewSavedHandler      = config.reviewSavedHandler;
        iqConfig.reviewOpenedHandler      = config.reviewOpenedHandler;
        iqConfig.reviewSharedHandler = config.reviewSharedHandler;
        iqConfig.reviewUnsharedHandler = config.reviewUnsharedHandler;
        iqConfig.reviewSummaryPdfHandler = config.reviewSummaryPdfHandler;
        iqConfig.reviewStateChangedHandler = config.reviewStateChangedHandler;
        iqConfig.timeoutHandler = config.timeoutHandler;
        iqConfig.applicationLogoutHandler = config.applicationLogoutHandler;
        iqConfig.initializedHandler = config.initializedHandler;
        iqConfig.applicationReadyHandler = config.applicationReadyHandler;
        iqConfig.guidelineSearchHandler = config.guidelineSearchHandler;

        e.addEventListener('message', receiveMessage, false);

        isInitialized = true;

        sendMessage(globals.apiVersionAction,
            {
                apiVersion: globals.apiVersion,
                guidelineRestricted: config.guidelineRestricted,
                selectedFacilityId: config.selectedFacilityId,
                customSettings: config.customSettings
            },
            function(result)
            {
                invokeSuccessHandler(iqConfig.initializedHandler, {apiVersion: result.apiVersion}, 'Initialization');
                logInfo('Successfully set ' + globals.apiVersionAction + ' to ' + result.apiVersion);

                if (isIframeHidden())
                {
                    logInfo('Warning: IFrame ' + iqConfig.frameElementId  + ' is not visible');
                }
            },
            function(errorMessage)
            {
                invokeFailureHandler(iqConfig.errorHandler, {apiVersion:result.apiVersion}, 'Initialization');
                logClientSideError('Failed to set ' + globals.apiVersionAction + ' - ' + errorMessage);
            }
        );
    }

    function isIframeHidden()
    {
        var iqFrameElement = getIQFrameElement();
        var hidden = false;

        try
        {
            if (iqFrameElement)
            {
                var rect = iqFrameElement.getBoundingClientRect();
                if (rect != null)
                {
                    hidden = (rect.height === 0 && rect.width === 0);
                }
            }
        }
        catch (exception)
        {
            var errorMsg = 'Unexpected error checking whether iFrame hidden: ' + exception;
            logClientSideError(errorMsg);
            iqConfig.errorHandler(errorMsg);
        }

        return hidden;
    }

    function receiveMessage(event)
    {
        var message = event.data;

        if (message.action === globals.apiVersionAction)
        {
            globals.iqFrameOrigin = event.origin;
        }

        if (event.origin !== globals.iqFrameOrigin)
        {
            return;
        }

        var request = removeRequest(message.request.id);
        var response = message.request.response;
        var action = message.action;
        if (request)
        {
            // Solicited Events - The response was initiated by a host frame request
            if (response.status === 'SUCCESS')
            {
                invokeSuccessHandler(request.successHandler, response.success, action);
            }
            else
            {
                invokeFailureHandler(request.failureHandler, response.error, action);
            }
        }
        else
        {
            // Unsolicited Events - Something triggered these from actions directly in the framed IQ client.
            // Handle events initiated within the framed client app, sending to registered callbacks
            // based on the action type
            switch (action)
            {
                case 'SAVE_REVIEW':
                    invokeSuccessHandler(iqConfig.reviewSavedHandler, response.success, action);
                    break;
                case 'SHARE_REVIEW':
                    invokeSuccessHandler(iqConfig.reviewSharedHandler, response.success, action);
                    break;
                case 'UNSHARE_REVIEW':
                    invokeSuccessHandler(iqConfig.reviewUnsharedHandler, response.success, action);
                    break;
                case 'REVIEW_SUMMARY':
                    invokeSuccessHandler(iqConfig.reviewSummaryPdfHandler, response.success, action);
                    break;
                case 'OPEN_REVIEW':
                    invokeSuccessHandler(iqConfig.reviewOpenedHandler, response.success, action);
                    break;
                case 'NEW_REVIEW':
                case 'SUBSET_SEARCH':
                    // don't handle these if unsolicited
                    break;
                case 'REVIEW_STATE_CHANGED':
                    invokeSuccessHandler(iqConfig.reviewStateChangedHandler, message.request, action);
                    break;
                case 'SIGNOUT':
                case 'TIMEOUT':
                    var isTimeout = (action === 'TIMEOUT');
                    if (iqConfig.applicationLogoutHandler)
                    {
                        response.timeout = isTimeout;
                        invokeFailureHandler(iqConfig.applicationLogoutHandler, response, action);
                    }
                    else
                    {
                        // timeoutHandler and errorHandler are only called for timeouts for versions 0.x
                        if (isTimeout)
                        {
                            invokeFailureHandler(iqConfig.timeoutHandler || iqConfig.errorHandler, response.error, action);
                        }
                    }
                    break;
                case 'APPLICATION_READY':
                    invokeSuccessHandler(iqConfig.applicationReadyHandler, response.success, action);
                    break;
                case 'GUIDELINE_SEARCH':
                    invokeSuccessHandler(iqConfig.guidelineSearchHandler, response.success, action);
                    break;
                default:
                    logClientSideError('Unknown action: ' + action);
                    break;
            }
        }
    }

    function invokeSuccessHandler(handler, data, actionName)
    {
        if (typeof handler === 'function') {
            handler(data);
        }
        else {
            logInfo('No successHandler for ' + actionName);
        }
    }

    function invokeFailureHandler(handler, data, actionName)
    {
        if (typeof handler === 'function') {
            handler(data);
        }
        else {
            logInfo('No failureHandler for ' + actionName);
        }
    }

    function getIQFrameElement()
    {
        if (iqFrameElement === undefined)
        {
            iqFrameElement = document.getElementById(iqConfig.frameElementId);
            if (!iqFrameElement)
            {
                logClientSideError('In InterQualOnline.getIQFrameElement(): Could not find InterQual IFrame by element id: ' + iqConfig.frameElementId);
                throw new Error('Could not find InterQual IFrame by element id: ' + iqConfig.frameElementId);
            }
        }
        return iqFrameElement;
    }

    function getMessage(action, request)
    {
        return {
            action: action,
            request: request,
            response: null
        };
    }

    function objectToString(obj)
    {
        if (obj === null || obj === undefined)
        {
            return 'null';
        }
        var msgString = '{ ';
        var first = true;
        for (var propName in obj)
        {
            if (obj.hasOwnProperty(propName))
            {
                if (!first)
                {
                    msgString += ', ';
                }
                msgString += propName + '=';
                var prop = obj[propName];
                if (typeof prop === 'object')
                {
                    msgString += objectToString(prop);
                }
                else
                {
                    if (propName === 'firstName' ||
                        propName === 'middleName' ||
                        propName === 'lastName' ||
                        propName === 'dob' ||
                        propName === 'gender' ||
                        propName === 'externalID' ||
                        propName === 'externalIDType')
                    {
                        msgString += '***';
                    }
                    else
                    {
                        msgString += prop;
                    }
                }
                first = false;
            }
        }
        msgString += '}';
        return msgString;
    }

    function newReviewCompositeAction(params, success, failure)
    {
        sendMessage('NEW_REVIEW', params,
            function (result) {
                if( (!params.guidelineId & !params.productId)&&(result.uuid == null))
                {
                    sendMessage('SUBSET_SEARCH', params,
                                (success || iqConfig.newReviewStartedHandler), (failure || iqConfig.errorHandler)
                    );
                }
                else
                {
                    invokeSuccessHandler(success || iqConfig.newReviewStartedHandler, params, 'NEW_REVIEW');
                }
            }, (failure || iqConfig.errorHandler)
        );
    }

    function sendMessage(action, clientParams, successHandler, failureHandler)
    {
        if (!isInitialized)
        {
            logClientSideError('InterQualOnline has not been initialized.');
            throw new Error('InterQualOnline has not been initialized.');
        }

        var iqconnectFrame = getIQFrameElement();

        try
        {
            var request =
            {
                id: ++nextRequestId,
                params: clientParams,
                response:
                {
                    status: null,
                    success: null,
                    error: null
                }
            };

            addRequest(
                {
                    request:        request,
                    successHandler: successHandler,
                    failureHandler: failureHandler
                }
            );

            var message = getMessage(action, request);

            var origin = message.action === globals.apiVersionAction ? '*' : globals.iqFrameOrigin;
            if (!origin)
            {
                logClientSideError('In InterQualOnline.sendMessage(): Frame origin not known.');
                throw new Error('Unknown iqFrameOrigin');
            }
            logInfo('Sending "{0}" message (origin="{1}"): {2}', message.action, origin, objectToString(message));
            iqconnectFrame.contentWindow.postMessage(message, origin);
        }
        catch (exception)
        {
            logClientSideError(exception.toString());
            iqConfig.errorHandler(exception.toString());
        }
    }

    function getCurrentScriptHost()
    {
        var scripts = [].slice.call(document.querySelectorAll( 'script[src]' ));
        var currentScript = scripts.filter(function (script)
        {
            return script.src.indexOf('/caas/js/ap/interqual-api') !== -1;
        });
        var link = document.createElement('a');
        link.href = currentScript[0].src;
        return link.protocol + '//' + link.host;
    }

    function getIframeContainer(o)
    {
        var container = o instanceof Element ? o : null;
        if (!container)
        {
            if (o === 'body')
            {
                container = document.body;
            }
            else
            {
                container = document.getElementById(o);
            }
        }
        if (!container)
        {
            throw new Error(format('Failed to locate existing IFRAME or parent container for IFRAME (container={0})', o));
        }
        return container;
    }

    function createIframe(config, src)
    {
        var iframe = document.createElement('iframe');
        if (config.css)
        {
            iframe.className = config.css;
        }
        // IE won't render iframe.style = 'styles'
        var styles = config.style ? config.style : !config.css ? 'height: 100%; width:100%' : '';
        styles.split(';').forEach(function(astyle) {
            var arr = astyle.split(':');
            if (arr.length === 2)
            {
                iframe.style[arr[0].trim()] = arr[1].trim();
            }
        });
        iframe.id = config.interqualFrameElementId ? config.interqualFrameElementId : globals.defaultIframeId;
        iframe.src = src;
        logInfo('Creating iframe (id={0}, src={1})', iframe.id, iframe.src);
        return iframe;
    }

    function validateConfig(where, config, props)
    {
        var logMsg = 'In InterQualOnline.{0}(): {1}';
        var error = 'InterQual Configuration Parameter [{0}] Required';
        if (!config)
        {
            logClientSideError(logMsg, where, 'config is required but empty');
            throw new Error('InterQual Configuration Parameter Required');
        }
        if (!config.samlAssertion || !config.samlAssertion.trim())
        {
            logClientSideError(logMsg, where, '"samlAssertion" param is required but empty');
            throw new Error(format(error, 'samlAssertion'));
        }
        if (!config.container)
        {
            logClientSideError(logMsg, where, '"container" param is required but missing');
            throw new Error(format(error, 'container'));
        }
        (props || []).forEach(function(p) {
            if (!config[p])
            {
                logClientSideError(logMsg, where, format('"{0}" param is required but missing', p));
                throw new Error(format(error, p));
            }
        });
    }

    function getEnvironmentBaseUrl(config)
    {
        if (config.environmentBaseUrl && config.environmentBaseUrl.trim())
        {
            var envBaseUrl =  config.environmentBaseUrl.trim();
            logInfo('Using environmentBaseUrl ' + envBaseUrl);
            return envBaseUrl;
        }

        return null;
    }

    function authenticateAndLoadIFrame(config)
    {
        var hostUrl = getEnvironmentBaseUrl(config);

        if (!hostUrl)
        {
            hostUrl = getCurrentScriptHost();
            logInfo('Using script host url ' + hostUrl);
        }

        var samlProxyUrl =  hostUrl + '/caas/ap/saml2/proxy';
        logInfo('Authenticating with SAML at ' + samlProxyUrl);
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == xhttp.DONE)
            {
                var redirectUrl = ('response' in this) ? this.response : this.responseText;
                if (this.status !== 200)
                {
                    logClientSideError('Error authenticating via SAML: ({0}) {1}', this.status, redirectUrl);
                    var msg = format('Failed to authenticate (status {0})', this.status);
                    if (config.errorHandler)
                    {
                        config.errorHandler(msg);
                    }
                    throw Error(msg);
                }
                else
                {
                    if (config.headless)
                    {
                        redirectUrl = redirectUrl.replace('index-ap.html', 'headless-index-ap.html');
                    }
                    removeExistingIframe();
                    var container = getIframeContainer(config.container);
                    var iframe;
                    if (container.tagName.toLowerCase() === 'iframe')
                    {
                        iframe = container;
                        iframe.src = redirectUrl;
                        logInfo('Using existing iframe (id={0}) and setting src={1})', iframe.id, iframe.src);
                    }
                    else
                    {
                        iframe = createIframe(config, redirectUrl);
                        container.appendChild(iframe);
                    }
                    iframe.onload = function()
                    {
                        config.interqualFrameElementId = iframe.id;
                        initializeIQ(config);
                        if (config.onload)
                        {
                            config.onload();
                        }
                    }
                }
            }
        };
        try
        {
            xhttp.open('POST', samlProxyUrl, true);
            xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
            xhttp.send('samlAssertion=' + encodeURIComponent(config.samlAssertion));
        }
        catch(e)
        {
            logClientSideError(objectToString(e));
            if (config.errorHandler)
            {
                config.errorHandler(e.toString());
            }
        }
    }

    function initHeadless(config)
    {
        config.container = 'body';
        config.interqualFrameElementId = globals.defaultHeadlessIframeId;
        config.style = 'display:none';
        var appReady = false;
        var applicationReadyHandlerCallback = config.applicationReadyHandler;
        config.applicationReadyHandler = function (data)
        {
            appReady = true;
            logInfo('APP {0}/{1} Ready', data.apiVersion, data.appVersion);
            if (applicationReadyHandlerCallback)
            {
                applicationReadyHandlerCallback(data);
            }
        };
        var onloadCallback = config.onload;
        config.onload = function()
        {
            var stop = new Date();
            stop.setTime(stop.getTime() + ((config.timeout > 0 ? config.timeout : 30) * 1000));
            var intv = setInterval(function() {
                var currentTime = new Date().getTime();
                if (!appReady && stop.getTime() > currentTime)
                {
                    logInfo('Waiting for app to initialize...');
                }
                else if (!appReady && stop.getTime() < currentTime)
                {
                    var msg = 'Timed out waiting for App to initialize.  Make sure user belongs to a licensed facility and has signed end-user license.';
                    logInfo(msg);
                    config.errorHandler(msg);
                }
                if (appReady || stop.getTime() < currentTime)
                {
                    clearInterval(intv);
                }
            }, 5000);
            if (onloadCallback)
            {
                onloadCallback();
            }
        };
    }

    return {
        /*
         Example if your "iframe" element looks something like this:
         <iframe id="iqconnectFrame" src='https://prod.cue4.com/caas/ap-index.html?oneTimeToken=abcd1234' height="650" width="100%"></iframe>
         You would initialize like this:
         InterQualOnline.initialize( {
         interqualFrameElementId: 'iqconnectFrame',
         errorHandler:            myErrorFunction
         }
         );
         */
        ReviewStatus:
        {
            IN_PRIMARY:  2,
            COMPLETED:   6,
            IN_PROGRESS: 8
        },

        GenderType:
        {
            MALE: 'MALE',
            FEMALE: 'FEMALE',
            OTHER: 'OTHER'
        },

        initialize: function(config)
        {
            initializeIQ(config);
        },
        newReview: function (params, success, failure)
        {
            newReviewCompositeAction(params, success, failure);
        },
        saveReview: function (params, success, failure)
        {
            sendMessage('SAVE_REVIEW', params, (success || iqConfig.reviewSavedHandler),
                (failure || iqConfig.errorHandler)
            );
        },
        completeReview: function (params, success, failure)
        {
            sendMessage('COMPLETE_REVIEW', params, success, (failure || iqConfig.errorHandler));
        },
        openReview: function (params, success, failure)
        {
            sendMessage('OPEN_REVIEW', params, (success || iqConfig.reviewOpenedHandler),
                (failure || iqConfig.errorHandler)
            );
        },
        shareReview: function (params, success, failure) {
            sendMessage('SHARE_REVIEW', params, (success || iqConfig.reviewSharedHandler),
                        (failure || iqConfig.errorHandler));
        },
        unshareReview: function (params, success, failure) {
            sendMessage('UNSHARE_REVIEW', params, (success || iqConfig.reviewUnsharedHandler),
                        (failure || iqConfig.errorHandler)
            );
        },
        reviewSummaryPdf: function (params, success, failure)
        {
            sendMessage('REVIEW_SUMMARY', params,
                (success || iqConfig.reviewSummaryPdfHandler), (failure || iqConfig.errorHandler)
            );
        },
        setupApp: function ()
        {
            sendMessage('SETUP', null, function (){}, iqConfig.errorHandler);
        },
        loadIQFrame: function(config)
        {
            if (config.headless)
            {
                initHeadless(config);
            }
            validateConfig('loadIQFrame', config);
            authenticateAndLoadIFrame(config);
        },
        guidelineSearch: function(params, success, failure)
        {
            sendMessage('GUIDELINE_SEARCH', params, (success || iqConfig.guidelineSearchHandler),
                (failure || iqConfig.errorHandler)
            );
        }
    };
})());
/* jshint ignore:end */
