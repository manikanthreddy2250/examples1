import { Module } from '@nestjs/common';
import { LoggerModule } from 'nestjs-pino';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { GraphQLModule } from '@nestjs/graphql';
import { GraphQLJSON } from 'graphql-type-json';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { GraphQLError, GraphQLFormattedError } from 'graphql';
import { AuthModule } from './auth/auth.module';
import { JwtStrategy } from './auth/jwt.strategy';
import { AuthGuard } from './auth/auth.guard';
import { RolesGuard } from './auth/roles.guard';
import { PassportModule } from '@nestjs/passport';
import { JwtModule } from '@nestjs/jwt';
import {HscModule} from "./hsc/hsc.module";
import {ProviderGuard} from './auth/provider.guard';


@Module({
  imports: [
    LoggerModule.forRoot(),
    ConfigModule.forRoot({
      isGlobal: true,
      ignoreEnvFile: true
    }),
    GraphQLModule.forRoot({
      buildSchemaOptions: {
        numberScalarMode: 'integer',
      },
      resolvers: { JSON: GraphQLJSON },
      introspection: true,
      playground: true,
      installSubscriptionHandlers: false,
      context: ({ req }) => ({ req }),
      autoSchemaFile: 'schema.gql',
      useGlobalPrefix: true,
      formatError: (error: GraphQLError) => {
         const graphQLFormattedError: GraphQLFormattedError = {
           message: error.message,
         };
         return graphQLFormattedError;
       },
    }),
    PassportModule,
    JwtModule.register({}),
    AuthModule,
    HscModule,
  ],
  controllers: [AppController],
  providers: [AppService, ConfigService, JwtStrategy, AuthGuard, RolesGuard, ProviderGuard],
})
export class AppModule {}
