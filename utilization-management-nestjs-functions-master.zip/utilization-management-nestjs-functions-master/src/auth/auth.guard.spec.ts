import { createMock } from '@golevelup/ts-jest';
import { ExecutionContext, HttpModule, Logger } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { Reflector } from '@nestjs/core';
import { PassportModule } from '@nestjs/passport';
import { Test, TestingModule } from '@nestjs/testing';
import { LoggerModule } from 'nestjs-pino';
import { Role } from '../decorators/roles';
import { AuthGuard } from './auth.guard';
import { AuthModule } from './auth.module';
import { JwtStrategy } from './jwt.strategy';
import { RolesGuard } from './roles.guard';

describe('Auth Guard', () => {
  let authGuard: AuthGuard;
  let roelsGuard: RolesGuard;
  let jwtStrategy: JwtStrategy;
  let reflactor: Reflector;

  beforeEach(async () => {
    const app: TestingModule = await Test.createTestingModule({
      imports: [
        HttpModule,
        AuthModule,
        PassportModule,
        ConfigModule.forRoot({
          isGlobal: true,
          ignoreEnvFile: true,
        }),
        LoggerModule.forRoot(),
        PassportModule,
        AuthModule,
      ],
      providers: [
        ConfigService,
        RolesGuard,
        AuthGuard,
        JwtStrategy,
        Reflector,
        RolesGuard,
      ],
    }).compile();
    authGuard = app.get<AuthGuard>(AuthGuard);
    roelsGuard = app.get<RolesGuard>(RolesGuard);
    jwtStrategy = app.get<JwtStrategy>(JwtStrategy);
    reflactor = app.get<Reflector>(Reflector);
  });

  describe('Auth Guard', () => {
    it('Header with secret key', () => {
      const gqlMockFactory = (
        context: Record<string, any>,
        info: Record<string, any>,
      ) =>
        createMock<ExecutionContext>({
          getType: () => 'graphql',
          getHandler: () => 'query',
          getClass: () => 'Test',
          getArgs: () => [{}, {}, context, info],
        });

      const gqlContextMockFactory = (contextMock: any) =>
        gqlMockFactory(contextMock, {});

      const gqlInfoMockFactory = (infoMock: any) =>
        gqlMockFactory({}, infoMock);
      const reqMock = createMock<Request>();
      const gqlCtx = gqlContextMockFactory({
        req: {
          headers: {
            'x-hasura-admin-secret': 'ovcprovidersecretkey',
          },
          rawBody:
            '{"query":"query getAppointments {\\r\\n  operationalQuestions(npi: \\"1316233547\\", reasonId: \\"53387\\", locationId:\\"232797\\") {\\r\\n  id \\r\\n  questions {\\r\\n    id\\r\\n    text\\r\\n  } \\r\\n  }\\r\\n}"}',
        },
      });

      expect(authGuard.canActivate(gqlCtx)).toBeTruthy();
    });

    it('Header with userrole and auth token', () => {
      const gqlMockFactory = (
        context: Record<string, any>,
        info: Record<string, any>,
      ) =>
        createMock<ExecutionContext>({
          getType: () => 'graphql',
          getHandler: () => 'query',
          getClass: () => 'Test',
          getArgs: () => [{}, {}, context, info],
        });

      const gqlContextMockFactory = (contextMock: any) =>
        gqlMockFactory(contextMock, {});

      const gqlInfoMockFactory = (infoMock: any) =>
        gqlMockFactory({}, infoMock);
      const reqMock = createMock<Request>();
      const gqlCtx = gqlContextMockFactory({
        req: {
          headers: {
            'x-hasura-admin-secret': 'test',
            'x-hasura-role': 'system_mgmt_admin',
          },
          rawBody:
            '{"query":"query getAppointments {\\r\\n  operationalQuestions(npi: \\"1316233547\\", reasonId: \\"53387\\", locationId:\\"232797\\") {\\r\\n  id \\r\\n  questions {\\r\\n    id\\r\\n    text\\r\\n  } \\r\\n  }\\r\\n}"}',
        },
      });

      expect(authGuard.canActivate(gqlCtx)).toBeTruthy();
    });

    it('Header with userrole and auth token', () => {
      const gqlMockFactory = (
        context: Record<string, any>,
        info: Record<string, any>,
      ) =>
        createMock<ExecutionContext>({
          getType: () => 'graphql',
          getHandler: () => 'query',
          getClass: () => 'Test',
          getArgs: () => [{}, {}, context, info],
        });

      const gqlContextMockFactory = (contextMock: any) =>
        gqlMockFactory(contextMock, {});

      const gqlInfoMockFactory = (infoMock: any) =>
        gqlMockFactory({}, infoMock);
      const reqMock = createMock<Request>();
      const gqlCtx = gqlContextMockFactory({
        req: {
          headers: {
            authorization: 'auth',
            'x-hasura-admin-secret': 'test',
            'x-hasura-role': 'system_mgmt_admin',
          },
          rawBody:
            '{"query":"query getAppointments {\\r\\n  operationalQuestions(npi: \\"1316233547\\", reasonId: \\"53387\\", locationId:\\"232797\\") {\\r\\n  id \\r\\n  questions {\\r\\n    id\\r\\n    text\\r\\n  } \\r\\n  }\\r\\n}"}',
        },
      });
      expect(function () {
        authGuard.canActivate(gqlCtx);
      }).toBeTruthy();
    });

    it('Header with userrole and and without token and invalid key', () => {
      const gqlMockFactory = (
        context: Record<string, any>,
        info: Record<string, any>,
      ) =>
        createMock<ExecutionContext>({
          getType: () => 'graphql',
          getHandler: () => 'query',
          getClass: () => 'Test',
          getArgs: () => [{}, {}, context, info],
        });

      const gqlContextMockFactory = (contextMock: any) =>
        gqlMockFactory(contextMock, {});

      const gqlInfoMockFactory = (infoMock: any) =>
        gqlMockFactory({}, infoMock);
      const reqMock = createMock<Request>();
      const gqlCtx = gqlContextMockFactory({
        req: {
          headers: {
            authorization: 'auth',
            'x-hasura-admin-secret': 'test',
            'x-hasura-role': 'system_mgmt_admin',
          },
          rawBody:
            '{"query":"query getAppointments {\\r\\n  operationalQuestions(npi: \\"1316233547\\", reasonId: \\"53387\\", locationId:\\"232797\\") {\\r\\n  id \\r\\n  questions {\\r\\n    id\\r\\n    text\\r\\n  } \\r\\n  }\\r\\n}"}',
        },
      });
      expect(function () {
        authGuard.canActivate(gqlCtx);
      }).toBeTruthy();
    });
  });

  describe('Mocked Execution Context', () => {
    it('should have a fully mocked Execution Context', () => {
      const mockExecutionContext = createMock<ExecutionContext>({
        switchToHttp: () => ({
          getRequest: () => ({
            headers: {
              authorization: 'auth',
              'x-hasura-admin-secret': 'ovcprovidersecretkey',
            },
          }),
        }),
      });
      // expect(mockExecutionContext.switchToHttp().getRequest()).toBeDefined();
      expect(authGuard.getRequest(mockExecutionContext)).toBeTruthy();
      expect(function () {
        authGuard.handleRequest(0, 0, 'Dhruvin');
      }).toThrow();
      expect(authGuard.handleRequest(0, 1, 'Dhruvin')).toBeTruthy;
    });

    it('roles guard Success with user role', () => {
      const gqlMockFactory = (
        context: Record<string, any>,
        info: Record<string, any>,
      ) =>
        createMock<ExecutionContext>({
          getType: () => 'graphql',
          getHandler: () => 'query',
          getClass: () => 'Test',
          getArgs: () => [{}, {}, context, info],
        });

      const gqlContextMockFactory = (contextMock: any) =>
        gqlMockFactory(contextMock, {});

      const gqlInfoMockFactory = (infoMock: any) =>
        gqlMockFactory({}, infoMock);
      const reqMock = createMock<Request>();
      const gqlCtx = gqlContextMockFactory({
        req: {
          headers: {
            authorization: 'auth',
            'x-hasura-admin-secret': 'test',
            'x-hasura-role': 'system_mgmt_admin',
          },
          rawBody:
            '{"query":"query getAppointments {\\r\\n  operationalQuestions(npi: \\"1316233547\\", reasonId: \\"53387\\", locationId:\\"232797\\") {\\r\\n  id \\r\\n  questions {\\r\\n    id\\r\\n    text\\r\\n  } \\r\\n  }\\r\\n}"}',
        },
      });
      const roles: any[] = [Role.UM_INTAKE_CLINICIAN, Role.UM_INTAKE_PROVIDER, Role.UM_INTAKE_SYSTEM];
      const logger = new Logger();
      const configService = new ConfigService();
      roelsGuard = new RolesGuard(reflactor, logger, configService);
      const privateSpy = spyOn<any>(
        reflactor,
        'getAllAndOverride',
      ).and.returnValue(roles);

      expect(roelsGuard.canActivate(gqlCtx)).toBeTruthy();
      expect(roelsGuard.getRequest(gqlCtx)).toBeTruthy();
    });

    it('roles guard without user role', () => {
      const mockExecutionContext = createMock<ExecutionContext>({
        switchToHttp: () => ({
          getRequest: () => ({
            headers: {
              authorization: 'auth',
              'x-hasura-admin-secret': 'ovcprovidersecretkey',
            },
          }),
        }),
      });
      expect(roelsGuard.canActivate(mockExecutionContext)).toBeTruthy();
    });

    it('Jwt strategy exception', () => {
      const mockExecutionContext = createMock<ExecutionContext>({
        switchToHttp: () => ({
          getRequest: () => ({
            headers: {
              authorization: 'auth',
              'x-hasura-admin-secret': 'ovcprovidersecretkey',
            },
          }),
        }),
      });
      expect(jwtStrategy.getRequest(mockExecutionContext)).toBeTruthy();
      expect(jwtStrategy.validate(1)).toBeTruthy();
      let invalidToken = false;
      jwtStrategy.validate(0).catch(error => invalidToken = true);
      expect(invalidToken);
    });
  });
});
