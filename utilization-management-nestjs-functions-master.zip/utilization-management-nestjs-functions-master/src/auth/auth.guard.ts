import {
  ExecutionContext,
  Injectable,
  UnauthorizedException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Reflector } from '@nestjs/core';
import { GqlExecutionContext } from '@nestjs/graphql';
import { AuthGuard as PassportAuthGuard } from '@nestjs/passport';
import { Observable } from 'rxjs';

@Injectable()
export class AuthGuard extends PassportAuthGuard('jwt') {
  constructor(
    private configService: ConfigService,
    private reflector: Reflector,
  ) {
    super();
  }

  canActivate(
    context: ExecutionContext,
  ): boolean | Promise<boolean> | Observable<boolean> {
    const ctx = GqlExecutionContext.create(context);
    const { req } = ctx.getContext();
    if (
      ctx.getContext().req.headers['x-hasura-admin-secret'] ||
      JSON.parse(ctx.getContext().req.rawBody).operationName ===
        'IntrospectionQuery'
    ) {
      return true;
    }
    if (req.headers && !req.headers.authorization) {
      return false;
    }
    //return super.canActivate(new ExecutionContextHost([req]));
    return super.canActivate(context);
  }

  getRequest(context: ExecutionContext) {
    return (
      context.switchToHttp().getRequest() ||
      GqlExecutionContext.create(context).getContext().req
    );
  }

  public handleRequest(error: any, user: any, info: any): any {
    if (error || !user) {
      console.log('AuthGuard.handleRequest.error::' + JSON.stringify(error));
      console.log('AuthGuard.handleRequest.user::' + JSON.stringify(user));
      throw error || new UnauthorizedException('Token is Invalid.');
    }
    return user;
  }
}
