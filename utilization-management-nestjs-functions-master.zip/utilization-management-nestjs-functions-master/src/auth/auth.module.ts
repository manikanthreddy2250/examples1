import { Module } from '@nestjs/common';
import { PassportModule } from '@nestjs/passport';
import { ConfigModule, ConfigService } from '@nestjs/config'
import { JwtStrategy } from './jwt.strategy'
import { AuthGuard } from './auth.guard';
import { RolesGuard } from './roles.guard';
import { ProviderGuard } from './provider.guard';
import { HscModule } from '../hsc/hsc.module';
import { HealthServiceClient } from '../shared/graphql/healthservicedomain/healthServiceClient';

@Module({
  imports: [PassportModule, ConfigModule, HscModule],
  providers: [JwtStrategy, AuthGuard, RolesGuard, ConfigService, ProviderGuard, HealthServiceClient],
  exports: [JwtStrategy, AuthGuard, RolesGuard, ProviderGuard],
})
export class AuthModule {}
