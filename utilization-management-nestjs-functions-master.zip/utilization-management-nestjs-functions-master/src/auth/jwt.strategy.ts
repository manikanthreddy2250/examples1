import {
  ExecutionContext,
  Injectable,
  UnauthorizedException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { PassportStrategy } from '@nestjs/passport';
import { ExtractJwt, Strategy } from 'passport-jwt';

import { GqlExecutionContext } from '@nestjs/graphql';

import * as jwksClient from 'jwks-rsa';
import * as jwt from 'jsonwebtoken';

/**
 * Singleton class.
 * Provides static properties to persist in memory
 * so jwks cache can live somewhere.
 */
class KeyProviderWithJwksCache {
  static jwksClient: jwksClient.JwksClient;
  static validationCounter = 0;

  constructor(private configService: ConfigService) {
    KeyProviderWithJwksCache.jwksClient = jwksClient({
      jwksUri: this.configService.get<string>('JWK_URI'),
      cache: true,
      cacheMaxEntries: 5,
      cacheMaxAge: 36000000, // 10 hours, milliseconds
      rateLimit: true,
      jwksRequestsPerMinute: 10,
    });
  }

  async handler(req, rawJwtToken, done) {
    try {
      console.log('Singleton Test: ', {
        jwtsValidatedSoFar: KeyProviderWithJwksCache.validationCounter,
      });
      KeyProviderWithJwksCache.validationCounter += 1;

      const jwtTokenKeyId = (() => {
        const decoded: any = jwt.decode(rawJwtToken as string, {
          complete: true,
        });
        return decoded.header.kid;
      })();

      const signingKey = await new Promise((resolve, reject) => {
        //console.time('Time taken to retrieve signing key');
        KeyProviderWithJwksCache.jwksClient.getSigningKey(
          jwtTokenKeyId,
          (err: Error, jwk: jwksClient.RsaSigningKey) => {
            if (err) {
              return reject(err);
            }
            //console.timeEnd('Time taken to retrieve signing key');
            return resolve(jwk.rsaPublicKey);
          },
        );
      });
      //console.log('PEM key for signature validation: ', { signingKey });
      done(null, signingKey);
    } catch (err) {
      console.error('Error logged:', JSON.stringify({ err }, null, 2));
      done(err, null);
    }
  }
}

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  constructor(private configService: ConfigService) {
    super({
      jwtFromRequest: ExtractJwt.fromExtractors([
        ExtractJwt.fromAuthHeaderAsBearerToken(),
        ExtractJwt.fromAuthHeaderWithScheme('Bearer'),
      ]),
      secretOrKeyProvider: new KeyProviderWithJwksCache(configService).handler,
      audience: '',
      issuer: configService.get<string>('ISSUER'),
      algorithms: ['RS512'],
    });
    //console.log('constructor in JwtStrategy called');
  }

  async validate(payload: any) {
    console.log('payload===' + payload);
    if (!payload) {
      throw new UnauthorizedException('Invalid JWT Token');
    }
    return payload;
  }

  getRequest(context: ExecutionContext) {
    return (
      context.switchToHttp().getRequest() ||
      GqlExecutionContext.create(context).getContext().req
    );
  }
}
