import { createMock } from '@golevelup/ts-jest';
import { ExecutionContext, HttpModule, Logger } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { Reflector } from '@nestjs/core';
import { PassportModule } from '@nestjs/passport';
import { Test, TestingModule } from '@nestjs/testing';
import { LoggerModule } from 'nestjs-pino';
import { AuthModule } from './auth.module';
import {ProviderGuard} from './provider.guard';
import {HealthServiceClient} from '../shared/graphql/healthservicedomain/healthServiceClient';
import {HttpRequest} from '@azure/functions';
import {GraphQLClient} from 'graphql-request/dist';
import {RequestDocument} from 'graphql-request/dist/types';
import {of} from 'rxjs';
import {HscModule} from '../hsc/hsc.module';


class MockGraphQLClient extends GraphQLClient{
  request(document: RequestDocument, variables?: any, requestHeaders?: any): Promise<any>{
    if (variables.hscId === "9999") {
      return of({
        "hsc_prov": []
      }).toPromise();
    } else {
      return of({
        "hsc_prov": [
          {
            "hsc_prov_id": 5457,
            "prov_loc_affil_dtl": {
              "providerDetails": {
                "prov_id": 998877,
                "prov_adr": {
                  "cty_nm": "Santa Monica",
                  "st_ref_id": 1067,
                  "zip_cd_txt": "904043414",
                  "adr_ln_1_txt": "1920 Colorado Ave",
                  "adr_ln_2_txt": null
                },
                "prov_keys": [
                  {
                    "prov_key_val": "1851525091",
                    "prov_key_typ_ref_id": 2782
                  },
                  {
                    "prov_key_val": "288158608",
                    "prov_key_typ_ref_id": 16333
                  },
                  {
                    "prov_key_val": "1710081369",
                    "prov_key_typ_ref_id": 2783
                  }
                ]
              }
            }
          }
        ]
      }).toPromise();
    }
  }
}

class MockHealthServiceClient {

  healthServiceClient;

  constructor(private readonly configService: ConfigService) {
  }

  public getGraphqlClient(httpRequest: HttpRequest): GraphQLClient {
    return new MockGraphQLClient('testurl');
  }
}


describe('Provider Guard', () => {
  let providerGuard: ProviderGuard;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      imports: [
        HttpModule,
        AuthModule,
        PassportModule,
        ConfigModule.forRoot({
          isGlobal: true,
          ignoreEnvFile: true,
        }),
        LoggerModule.forRoot(),
        PassportModule,
        AuthModule,
          HscModule
      ],
      providers: [
        ProviderGuard,
        { provide: HealthServiceClient, useClass: MockHealthServiceClient },
      ],
    }).compile();

    providerGuard = module.get<ProviderGuard>(ProviderGuard);
    providerGuard.setHealthServiceClient(new MockHealthServiceClient(null)); // hack - healthservice client was not getting set as a mock

  });

  it('should have a fully mocked Execution Context', () => {
    const mockExecutionContext = createMock<ExecutionContext>({
      switchToHttp: () => ({
        getRequest: () => ({
          headers: {
            authorization: 'auth',
            'x-hasura-admin-secret': 'ovcprovidersecretkey',
          },
        }),
      }),
    });
    expect(providerGuard.getRequest(mockExecutionContext)).toBeTruthy();
    expect(function () {
      providerGuard.handleRequest(0, 0, 'Dhruvin');
    }).toThrow();
    expect(providerGuard.handleRequest(0, 1, 'Dhruvin')).toBeTruthy;
  });

    it('Header With Provider and HSC Ids', () => {
      const gqlMockFactory = (
        context: Record<string, any>,
        info: Record<string, any>,
      ) =>
        createMock<ExecutionContext>({
          getType: () => 'graphql',
          getHandler: () => 'query',
          getClass: () => 'Test',
          getArgs: () => [{}, {}, context, info],
        });

      const gqlContextMockFactory = (contextMock: any) =>
        gqlMockFactory(contextMock, {});

      const gqlCtx = gqlContextMockFactory({
        req: {
          headers: {
            'submittingprovider': '998877',
            'hscid': '112233'
          },
          rawBody:
            '{""}',
        },
      });

      //expect(providerGuard.canActivate(gqlCtx)).toBeTruthy();
      let result = providerGuard.canActivate(gqlCtx);
      return result
          .then(rslt => expect(rslt).toBe(true))
    });



  it('Header With Provider and HSC Ids - no match on submittingProvider', () => {
    const gqlMockFactory = (
        context: Record<string, any>,
        info: Record<string, any>,
    ) =>
        createMock<ExecutionContext>({
          getType: () => 'graphql',
          getHandler: () => 'query',
          getClass: () => 'Test',
          getArgs: () => [{}, {}, context, info],
        });

    const gqlContextMockFactory = (contextMock: any) =>
        gqlMockFactory(contextMock, {});

    const gqlCtx = gqlContextMockFactory({
      req: {
        headers: {
          'submittingprovider': '111111',
          'hscid': '112233'
        },
        rawBody:
            '{""}',
      },
    });

    let result = providerGuard.canActivate(gqlCtx);
    return result
        .then(rslt => expect(rslt).toBe(false))
  });

  it('Header With Provider and HSC Ids - HSC Not Found', () => {
    const gqlMockFactory = (
        context: Record<string, any>,
        info: Record<string, any>,
    ) =>
        createMock<ExecutionContext>({
          getType: () => 'graphql',
          getHandler: () => 'query',
          getClass: () => 'Test',
          getArgs: () => [{}, {}, context, info],
        });

    const gqlContextMockFactory = (contextMock: any) =>
        gqlMockFactory(contextMock, {});

    const gqlCtx = gqlContextMockFactory({
      req: {
        headers: {
          'submittingprovider': '111111',
          'hscid': '9999'
        },
        rawBody:
            '{""}',
      },
    });

    let result = providerGuard.canActivate(gqlCtx);
    return result
        .then(rslt => expect(rslt).toBe(true))
  });


  it('Header Without Provider and HSC Ids', () => {
      const gqlMockFactory = (
          context: Record<string, any>,
          info: Record<string, any>,
      ) =>
          createMock<ExecutionContext>({
            getType: () => 'graphql',
            getHandler: () => 'query',
            getClass: () => 'Test',
            getArgs: () => [{}, {}, context, info],
          });

      const gqlContextMockFactory = (contextMock: any) =>
          gqlMockFactory(contextMock, {});

      const gqlCtx = gqlContextMockFactory({
        req: {
          headers: {
            'notsubmittingprovider': '998877',
            'nothscid': '112233'
          },
          rawBody:
              '{""}',
        },
      });

      // expect(providerGuard.canActivate(gqlCtx)).toBeTruthy();
      let result = providerGuard.canActivate(gqlCtx);
      return result
          .then(rslt => expect(rslt).toBe(true))
    });
});
