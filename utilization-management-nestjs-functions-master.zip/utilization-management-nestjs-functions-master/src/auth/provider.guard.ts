import {
  CanActivate,
  ExecutionContext,
  Injectable,
  UnauthorizedException,
} from '@nestjs/common';
import { GqlExecutionContext } from '@nestjs/graphql';
import {GraphQLClient} from 'graphql-request/dist';
import {HealthServiceClient} from '../shared/graphql/healthservicedomain/healthServiceClient';
import {getHscProvider} from '../shared/graphql/healthservicedomain/healthServiceQuery';

@Injectable()
export class ProviderGuard implements CanActivate {

  constructor(private healthServiceClient: HealthServiceClient) {
    console.log(healthServiceClient);
  }

  public setHealthServiceClient(healthServiceClient: any) {
    this.healthServiceClient = healthServiceClient;
  }

  async canActivate(
    context: ExecutionContext,
  ): Promise<boolean> {

    const ctx = GqlExecutionContext.create(context);
    const { req } = ctx.getContext();

    // should check to see if the user is operating in a provider role (userSessionService.getActiveOrgRole)

    const submittingProvider = req.headers['submittingprovider'];
    const hscId = req.headers['hscid'];
    let providerAssociatedToHsc = true;

    if (submittingProvider != null && submittingProvider != ''  && hscId != null && hscId != '') {

      providerAssociatedToHsc = false;
      try {

        const hscGraphqlClient: GraphQLClient = this.healthServiceClient.getGraphqlClient(ctx.getContext().req);
        const hscProviderResponse = await hscGraphqlClient.request(getHscProvider, {hscId});
        // console.log('hscProviderResponse::', JSON.stringify(hscProviderResponse));

        if (hscProviderResponse) {
          if (hscProviderResponse.hsc_prov.length === 0) {
            return true;
          }
          providerAssociatedToHsc = this.determineHscProviderAssociation(hscProviderResponse, submittingProvider, providerAssociatedToHsc);
        }
      } catch (e) {
        console.error('ProviderGuard::' + JSON.stringify(e));
      }

    }
    return providerAssociatedToHsc;
  }


  private determineHscProviderAssociation(hscProviderResponse, submittingProvider, providerAssociatedToHsc: boolean) {
    // let currentDateTime = new Date();
    for (var i = 0; i < hscProviderResponse.hsc_prov.length; i++) {
      const hscProvRecord = hscProviderResponse.hsc_prov[i];
      const provId = hscProvRecord.prov_loc_affil_dtl.providerDetails.prov_id;
      if (provId != null && submittingProvider === provId.toString()) {
        // start and end date are not populated
        // if (hscProvRecord.strt_dt != null && hscProvRecord.strt_dt > currentDateTime && hscProvRecord.end_dt != null && hscProvRecord.end_dt < currentDateTime) {
        //   providerAssociatedToHsc = true;
        //   break;
        // }
        // if (hscProvRecord.strt_dt != null && hscProvRecord.strt_dt > currentDateTime && hscProvRecord.end_dt === null) {
        //   providerAssociatedToHsc = true;
        //   break;
        // }
        providerAssociatedToHsc = true;
        if (providerAssociatedToHsc) {
          break;
        }
      }
    }
    return providerAssociatedToHsc;
  }

  getRequest(context: ExecutionContext) {
    return (
      context.switchToHttp().getRequest() ||
      GqlExecutionContext.create(context).getContext().req
    );
  }

  public handleRequest(error: any, user: any, info: any): any {
    if (error || !user) {
      console.log('ProviderGuard.handleRequest.error::' + JSON.stringify(error));
      console.log('ProviderGuard.handleRequest.user::' + JSON.stringify(user));
      throw error || new UnauthorizedException('Token is Invalid.');
    }
    return user;
  }
}
