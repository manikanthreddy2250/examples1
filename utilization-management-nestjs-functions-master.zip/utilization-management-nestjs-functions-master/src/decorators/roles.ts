export enum Role {
  UM_INTAKE_CLINICIAN = 'um_intake_ui_clinician',
  UM_INTAKE_PROVIDER = 'um_intake_ui_provider',
  UM_INTAKE_SYSTEM = 'um_intake_ui_system',
  UM_INTAKE_ADMIN = 'um_intake_ui_admin',
  CASE_MGMT_ADMIN = 'case_wf_mgmt_ui_admin',
  CASE_MGMT_CDU = 'case_wf_mgmt_ui_cdu',
  CASE_MGMT_MD = 'case_wf_mgmt_ui_md',
  CASE_MGMT_NURSE = 'case_wf_mgmt_ui_nurse',
  CASE_MGMT_SYSTEM = 'case_wf_mgmt_ui_system',
}

