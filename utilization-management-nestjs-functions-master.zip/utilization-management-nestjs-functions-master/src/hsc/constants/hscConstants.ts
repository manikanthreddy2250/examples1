export const HscConstants = {
  HSC_CREATE_BUS_EVENT_NAME: 'um_intake_case_create',
  HSC_BUS_EVENT_API_CHANNEL: 'api',
  HSC_BUS_EVENT_WEB_CHANNEL: 'web',

};
