import { HttpModule, Module } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { HscResolver } from './resolver/hsc.resolver';
import { HealthServiceClient } from '../shared/graphql/healthservicedomain/healthServiceClient';
import { GetHscAuthService } from './service/getHscAuth/getHscAuth.service';
import { ReferenceClient } from '../shared/graphql/referencedomain/referenceClient';
import { HscService } from './service/createHsc/hsc.service';
import { ProviderClient } from '../shared/graphql/providerdomain/providerClient';
import { ProviderService } from './service/provider.service';
import { CreateHscMapper } from './mapper/createHsc.mapper';
import { MemberClient } from '../shared/graphql/memberdomain/memberClient';
import { IndividualClient } from '../shared/graphql/individualdomain/individualClient';
import { UpdateHscService } from './service/updateHsc/updateHsc.service';
import { DmnService } from './service/dmn/dmn.service';
import { DuplicateCheckService } from './service/duplicate-check/duplicate-check.service';
import { HscHistoryService } from './service/hscHistory/hscHistory.service';
import { MemberService } from './service/member/member.service';
import { HscBusinessEventService } from './service/businessEvents/hsc-bus-event/hsc-bus-event.service';
import { ProviderBaasClient } from '../shared/graphql/providerbaas/providerBaasClient';
import { LoggerModule } from "nestjs-pino/dist";
import { HscActivityService } from './service/activity-service/hsc.activity.service';
import { MemberCommunicationClient } from '../shared/graphql/communication-domain/memberCommunicationClient';


@Module({
  imports: [HttpModule],
  providers: [
    HscResolver,
    ConfigService,
    ProviderService,
    MemberService,
    HealthServiceClient,
    ReferenceClient,
    IndividualClient,
    ProviderClient,
    MemberClient,
    GetHscAuthService,
    HscService,
    UpdateHscService,
    CreateHscMapper,
    DmnService,
    DuplicateCheckService,
    HscHistoryService,
    HscBusinessEventService,
    ProviderBaasClient,
    LoggerModule,
    HscActivityService,
    MemberCommunicationClient
  ],
  exports: [HealthServiceClient],
})
export class HscModule {}
