import { Test, TestingModule } from '@nestjs/testing';
import { GraphQLClient } from 'graphql-request/dist';
import { RequestDocument } from 'graphql-request/dist/types';
import { of } from 'rxjs';
import { HttpRequest } from '@azure/functions';
import { CreateHscMapper } from './createHsc.mapper';
import { MemberClient } from '../../shared/graphql/memberdomain/memberClient';
import { CreateHscInput } from '../models/createHsc.input';
import { ProviderService } from '../service/provider.service';
import {ConfigService,ConfigModule} from '@nestjs/config';
import {Logger} from "@nestjs/common";
import {HealthServiceClient} from "../../shared/graphql/healthservicedomain/healthServiceClient";
import {HscProvInput} from "../models/hscProv.input";
import { AuthorizationService } from '@ecp/func-tk/dist';
import { AxiosResponse } from 'axios';
import {IndividualClient} from "../../shared/graphql/individualdomain/individualClient";
import {MemberService} from "../service/member/member.service";
import {LoggerModule, PinoLogger} from "nestjs-pino/dist";
import {MemberCommunicationClient} from "../../shared/graphql/communication-domain/memberCommunicationClient";

jest.mock("axios");

class MockGraphQLClient extends GraphQLClient {
  request(
    document: RequestDocument,
    variables?: any,
    requestHeaders?: any,
  ): Promise<any> {
    return of({
      indv_id: 511941903,
      pol_nbr: null,
      cov_eff_dt: '0001-01-01',
      cov_end_dt: '9999-12-31',
      mbr_cov_id: 90881974,
      productCode: null,
      indv_key_val: '07007340001078331402002',
      productCatgyTpe: null,
      coverageTypeDesc: 'Medical',
      indv_key_typ_ref_id: 2757,
      claim_platform_ref_Id: null,
        lob_ref_id:19973
    }).toPromise();
  }
}

class MockMemberGraphQLClient extends GraphQLClient{
    request(document: RequestDocument, variables?: any, requestHeaders?: any): Promise<any>{
        return of({
                "mbrshp": [
                    {
                        "mbr_covs": [
                            {
                                "mbr_cov_id": 90881959,
                                "cov_end_dt": "9999-12-31",
                                "cov_eff_dt": "2020-02-01",
                                "pol_nbr": "0752023",
                                "lob_ref_id":"19973",
                                "prdct_typ_ref_cd": {
                                    "ref_desc": "POS"
                                },
                                "clm_pltfm_ref_id": 363,
                                "prdct_catgy_ref_cd": null,
                                "prdct_catgy_ref_id": null,
                                "cov_typ_ref_id": 182,
                                "cov_typ_ref_cd": {
                                    "ref_desc": "Medical"
                                }
                            }]}]}).toPromise();
    }
}


class MockMemberClient {
    public getGraphqlClient(httpRequest: HttpRequest): GraphQLClient {
        return new MockMemberGraphQLClient('testurl');
    }
}
class MockIndividualGraphQLClient extends GraphQLClient{
    request(document: RequestDocument, variables?: any, requestHeaders?: any): Promise<any>{
      if(variables.indvkeyId){
        return of({
          "indv_key": [
            {
                "indv":{
                    "fst_nm": "Matt",
                    "lst_nm": "Meyer"
                },
              "indv_id": 503926748,
              "indv_key_val": "16440436900",

            }
          ]}).toPromise();
      }
      else if(variables.orig_sys_mbr_id){
        return of({
          "mbrshp": [{
              "mbr_covs": [
                {
                  "cov_eff_dt": "2020-02-01",
                  "cov_end_dt": "9999-12-31",
                  "mbr_cov_id": 90881959,
                  "pol_nbr": "0752023",
                    "lob_Ref_id":"19973",
                  "cov_typ_ref_cd": {
                    "ref_desc": "Medical"
                  },
                  "prdct_catgy_ref_cd": null,
                  "clm_pltfm_ref_id": 363,
                  "prdct_ref_id": 226
                }
              ],
              "orig_sys_cd": "CDB_CS",
              "orig_sys_mbr_id": "16440436900",
              "orig_sys_ref_id": 2043,
              "src_mbr_id": "30830290",
              "src_mbr_partn_id": "10"
            }]
        }).toPromise();
      }
    }
}


class MockIndividualClient {
    public getGraphqlClient(httpRequest: HttpRequest): GraphQLClient {
        return new MockIndividualGraphQLClient('testurl');
    }
}


class MockHealthServiceGraphQLClient extends GraphQLClient{
  request(document: RequestDocument, variables?: any, requestHeaders?: any): Promise<any>{
    return of({
      "insert_hsc_srvc": {
      "affected_rows": 5,
          "returning": [
        {
          "hsc_id": 14700,
          "hsc_srvc_id": 12689,
          "inac_ind": 0,
          "proc_cd": "81099",
          "proc_cd_schm_ref_id": 2,
          "proc_othr_txt": null,
          "srvc_hsc_prov_id": 5509,
          "hsc_srvc_non_facls": [
            {
              "init_trt_dt": null,
              "plsrv_ref_id": 3741,
              "plsrv_ref_cd": {
                "ref_id": 3741,
                "ref_desc": "Home",
                "ref_dspl": "Home"
              },
              "proc_freq_ref_id": 3913,
              "proc_freq_ref_cd": {
                "ref_id": 3913,
                "ref_desc": "Daily",
                "ref_dspl": "Daily"
              },
              "proc_mod_1_cd": "00",
              "proc_mod_2_cd": "00",
              "proc_mod_3_cd": "0A",
              "proc_mod_4_cd": "0A",
              "proc_unit_cnt": 1,
              "proc_uom_ref_id": 19884,
              "proc_uom_ref_cd": {
                "ref_id": 19884,
                "ref_desc": "Days",
                "ref_dspl": "Days"
              },
              "srvc_desc_ref_id": 4347,
              "srvc_desc_ref_cd": {
                "ref_id": 4347,
                "ref_desc": "Scheduled",
                "ref_dspl": "Scheduled"
              },
              "srvc_dtl_ref_id": 3771,
              "srvc_dtl_ref_cd": {
                "ref_id": 3771,
                "ref_desc": "Medical Care",
                "ref_dspl": "Medical Care"
              },
              "srvc_end_dt": "2021-03-20",
              "srvc_strt_dt": "2021-03-19",
              "unit_per_freq_cnt": 1,
              "hsc_srvc_non_facl_dmes": [
                {
                  "clin_ill_desc_txt": null,
                  "dme_procrmnt_typ_id": null,
                  "dme_tot_cst_amt": null,
                  "ental_fd_sngl_src_nutritn_ind": null,
                  "fml_nm_txt": null,
                  "hsc_srvc_id": 12689,
                  "med_cond_txt": null,
                  "spl_desc_txt": null,
                  "srvc_desc_txt": null
                }
              ]
            }
          ]
        }
      ]
    }}).toPromise();
  }
}


class MockHealthServiceClient {
  public getGraphqlClient(httpRequest: HttpRequest): GraphQLClient {
    return new MockHealthServiceGraphQLClient('testurl');
  }
}
class ProviderServiceMock {
  getProvData(provKeyVal, provKeyTypeRefId, context: any) {
    return of({
      v_prov_srch: [{ prov_loc_affil_id: 1, prov_id: 23, prov_adr_id: 321,add_seq_num:4, prov_catgy_ref_id: 16309 }],
    }).toPromise();
  }

  getProviderId(hscProvInput: HscProvInput, hsc_id, httpRequest) : Promise<any>{
    return of({
      "hsc_prov": [
        {
          "hsc_prov_id": 5457,
          "prov_loc_affil_dtl": {
            "providerDetails": {
              "prov_adr": {
                "cty_nm": "Santa Monica",
                "st_ref_id": 1067,
                "zip_cd_txt": "904043414",
                "adr_ln_1_txt": "1920 Colorado Ave",
                "adr_ln_2_txt": null
              },
              "prov_keys": [
                {
                  "prov_key_val": "1851525091",
                  "prov_key_typ_ref_id": 2782
                },
                {
                  "prov_key_val": "288158608",
                  "prov_key_typ_ref_id": 16333
                },
                {
                  "prov_key_val": "1710081369",
                  "prov_key_typ_ref_id": 2783
                }
              ]
            }
          }
        }
      ]}).toPromise();
  }
  getPesFacilityContractData(prov, mpin ,tin,mbr_cov_mrk, httpRequest: any) {
    const contractResponse = [
      {
        contractPaperType: "",
        medNecClauseData: ""
      }
    ];
    return of({contractResponse}).toPromise();
  }

  getMedNecTypeDataForEnI(mpin ,tin,lob_ref_id,add_seq_num,httpRequest: any) {
    const medNecResponse:any = {"prov_contr": [{"med_nec_rev_claus_ref_cd": {"ref_desc": "test"}}]};
    return of({medNecResponse}).toPromise();
  }
  getAddressSequenceNumber(prov, mpin, httpRequest) {
      return of('0001').toPromise();
  }
}

class MemberServiceMock {
  getMemberCoverageDetails(indvKeyVal, mbr_cov, orgSysCd, context: any) {
    return of({
      indv_id: 511941903,
      pol_nbr: null,
      cov_eff_dt: '0001-01-01',
      cov_end_dt: '9999-12-31',
      mbr_cov_id: 90881974,
      productCode: null,
      indv_key_val: '07007340001078331402002',
      productCatgyTpe: null,
      coverageTypeDesc: 'Medical',
      indv_key_typ_ref_id: 2757,
      claim_platform_ref_Id: null,
      lob_ref_id:19973
    }).toPromise();
  }
}

class MockMemberCommunicationGraphQLClient extends GraphQLClient{
    request(document: RequestDocument, variables?: any, requestHeaders?: any): Promise<any>{
        return of({
            "insert_mbr_cmnct_one": {
                "mbr_cmnct_id": 56452,
                "creat_user_id": "SYSTEM",
                "creat_dttm": "2021-07-14T12:49:19.551",
                "chg_user_id": "SYSTEM",
                "chg_dttm": "2021-07-14T12:49:19.551",
                "commt_txt": "ovc_mbr_appt_confirmation_template.html",
                "cmnct_adr_dtl": "{\"address\":\"viswanath_c@optum.com\"}",
                "dsclmr_cnsnt_desc": null,
                "mbr_cmnct_catgy_ref_id": 2563,
                "mbr_cmnct_chnl_ref_id": 17272,
                "mbr_cmnct_dir_ref_id": 20087,
                "mbr_cmnct_prr_ref_id": 2515,
                "mbr_cmnct_rsn_ref_id": 20090,
                "mbr_cmnct_sts_ref_id": 20066,
                "mbr_cmnct_sts_rsn_ref_id": null,
                "mbr_cmnct_typ_ref_id": 20089,
                "sts_dttm": "2021-07-14T12:49:19.551",
                "updt_ver_nbr": 0,
                "mbr_cmnct_prtcps": [
                    {
                        "mbr_cmnct_id": 56452,
                        "mbr_cmnct_prtcp_id": 39778,
                        "fst_nm": "undefined",
                        "lst_nm": "undefined",
                        "mbr_cmnct_prtcp_engage_lvl_ref_id": null,
                        "mbr_cmnct_prtcp_role_ref_id": null,
                        "prtcp_desc": null,
                        "prtcp_key_typ_ref_id": null,
                        "prtcp_key_val": "undefined"
                    }
                ]
            }
        }).toPromise();
    }
}

class MockMemberCommunicationClient {
    public getGraphqlClient(httpRequest: HttpRequest): GraphQLClient {
        return new MockMemberCommunicationGraphQLClient('testurl');
    }
}

describe('CreateHscMapper', () => {
  let mapper: CreateHscMapper;
  let config: ConfigService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      imports: [ConfigModule, LoggerModule.forRoot()],
      providers: [
        CreateHscMapper, AuthorizationService,
        { provide: MemberClient, useClass: MockMemberClient },
        { provide: IndividualClient, useClass: MockIndividualClient },
        { provide: ProviderService, useClass: ProviderServiceMock },
        { provide: MemberService, useClass: MemberServiceMock },
        { provide: HealthServiceClient, useClass: MockHealthServiceClient },
        { provide: MemberCommunicationClient, useClass: MockMemberCommunicationClient },
      ],
    }).compile();

    mapper = module.get<CreateHscMapper>(CreateHscMapper);
    config = module.get<ConfigService>(ConfigService);
  });

  it('should be defined', () => {
    expect(mapper).toBeDefined();
  });

  it('should map hsc request', async () => {
    const context: HttpRequest = {
      method: null,
      url: '/api/graphql',
      headers: {
        authorization:
            'eyJraWQiOiIzMTRjOGJhMi0zZTZmLTQzYjItODVmOS1iOGMyMTNhNzZjMGUiLCJhbGciOiJSUzUxMiJ9.eyJ4LWVjcC1jbGFpbXMiOnsieC1lY3AtYXR0cnMiOnt9LCJ4LWVjcC1hbHQtdXNlci1pZCI6ImVjcF9lbmdpbmVlciIsIngtZWNwLWNsaS1vcmdzIjpbeyJvcmctaWQiOiJlY3AiLCJmdW5jLXJvbGVzIjpbeyJyb2xlLW5hbWUiOiJlbmdpbmVlciIsImFwcGwtcm9sZXMiOlsiYXNtdF9tZ210X2RlbW9fd3JpdGUiLCJhc3Nlc3NtZW50X2J1aWxkZXJfd3JpdGUiLCJhc3Nlc3NtZW50X21nbXRfd3JpdGUiLCJiYXNlX3Byb2R1Y3RfYnBtX2dycF9kZXBsb3kiLCJiYXNlX3Byb2R1Y3RfZG1uX2dycF9kZXBsb3kiLCJiaF9kZW1vX3VzZXIiLCJjYXJlX3BsYW5fZGVtb193cml0ZSIsImNhc2Vfd2ZfbWdtdF91aV9hZG1pbiIsImNsaW5pY2FsX2d1aWRlbGluZXNfdWhjX2Rtbl9ncnBfZGVwbG95IiwiY2xpbmljYWxfZ3VpZGVsaW5lc191c2VyIiwiZGFzaGJvYXJkX3JlYWQiLCJkaXN0YW5jZV9tYXRyaXhfdXNlciIsImRtc19kZWxldGUiLCJpbmR2X2NhcmVfcGxhbl91c2VyIiwibWJyX21nbXRfZGVtb193cml0ZSIsIm1icl9tZ210X3dyaXRlIiwibWVkX21nbXRfd3JpdGUiLCJwZ21fYnVpbGRlcl91c2VyIiwicGxhbl9vZl9jYXJlX3VzZXIiLCJwcmFjdGljZV9tZ210X3JlYWQiLCJwcm9ncmFtX3JlZmVycmFsc190aGlyZF9wYXJ0eV9yZWFkIiwicHJvZ3JhbV9yZWZlcnJhbHNfdXNlciIsInByb3ZpZGVyX21hbmFnZW1lbnRfdXNlciIsInJlYWNoX3VpX3N0YXJ0ZXJfdXNlciIsInJ1bGVzX2F1dGhvcmluZ193cml0ZSIsInNjaGVkdWxpbmdfcGF0aWVudCIsInN5c3RlbV9tZ210X3VzZXIiLCJ0ZW1wbGF0ZV9hdXRoX3VpX3VzZXIiLCJ1bV9jYXNlX21nbXRfYmFzZV9icG1fZ3JwX2RlcGxveSIsInVtX2Nhc2VfbWdtdF9iYXNlX2Rtbl9ncnBfZGVwbG95IiwidW1faW50YWtlX2Jhc2VfcHJvZHVjdF9icG1fZ3JwX2RlcGxveSIsInVtX2ludGFrZV9iYXNlX3Byb2R1Y3RfZG1uX2dycF9kZXBsb3kiLCJ1bV9pbnRha2VfdWlfY2xpbmljaWFuIiwidmlydHVhbF92aXNpdF9wcmFjdGl0aW9uZXIiXX1dfV0sIngtZWNwLXR5cGUiOiJDTElFTlRfQ1JFREVOVElBTFMiLCJ4LWVjcC11c2VyLWlkIjoiZWNwX2VuZ2luZWVyIn0sImh0dHBzOlwvXC9oYXN1cmEuaW9cL2p3dFwvY2xhaW1zIjp7IngtaGFzdXJhLWRlZmF1bHQtcm9sZSI6ImFzbXRfbWdtdF9kZW1vX3dyaXRlIiwieC1oYXN1cmEtYXR0cnMiOiJ7IH0iLCJ4LWhhc3VyYS1jbGktb3JnIjoiZWNwIiwieC1oYXN1cmEtdXNlci1pZCI6ImVjcF9lbmdpbmVlciIsIngtaGFzdXJhLWZ1bmMtcm9sZSI6ImVuZ2luZWVyIiwieC1oYXN1cmEtYWxsb3dlZC1yb2xlcyI6WyJhc210X21nbXRfZGVtb193cml0ZSIsImFzc2Vzc21lbnRfYnVpbGRlcl93cml0ZSIsImFzc2Vzc21lbnRfbWdtdF93cml0ZSIsImJhc2VfcHJvZHVjdF9icG1fZ3JwX2RlcGxveSIsImJhc2VfcHJvZHVjdF9kbW5fZ3JwX2RlcGxveSIsImJoX2RlbW9fdXNlciIsImNhcmVfcGxhbl9kZW1vX3dyaXRlIiwiY2FzZV93Zl9tZ210X3VpX2FkbWluIiwiY2xpbmljYWxfZ3VpZGVsaW5lc191aGNfZG1uX2dycF9kZXBsb3kiLCJjbGluaWNhbF9ndWlkZWxpbmVzX3VzZXIiLCJkYXNoYm9hcmRfcmVhZCIsImRpc3RhbmNlX21hdHJpeF91c2VyIiwiZG1zX2RlbGV0ZSIsImluZHZfY2FyZV9wbGFuX3VzZXIiLCJtYnJfbWdtdF9kZW1vX3dyaXRlIiwibWJyX21nbXRfd3JpdGUiLCJtZWRfbWdtdF93cml0ZSIsInBnbV9idWlsZGVyX3VzZXIiLCJwbGFuX29mX2NhcmVfdXNlciIsInByYWN0aWNlX21nbXRfcmVhZCIsInByb2dyYW1fcmVmZXJyYWxzX3RoaXJkX3BhcnR5X3JlYWQiLCJwcm9ncmFtX3JlZmVycmFsc191c2VyIiwicHJvdmlkZXJfbWFuYWdlbWVudF91c2VyIiwicmVhY2hfdWlfc3RhcnRlcl91c2VyIiwicnVsZXNfYXV0aG9yaW5nX3dyaXRlIiwic2NoZWR1bGluZ19wYXRpZW50Iiwic3lzdGVtX21nbXRfdXNlciIsInRlbXBsYXRlX2F1dGhfdWlfdXNlciIsInVtX2Nhc2VfbWdtdF9iYXNlX2JwbV9ncnBfZGVwbG95IiwidW1fY2FzZV9tZ210X2Jhc2VfZG1uX2dycF9kZXBsb3kiLCJ1bV9pbnRha2VfYmFzZV9wcm9kdWN0X2JwbV9ncnBfZGVwbG95IiwidW1faW50YWtlX2Jhc2VfcHJvZHVjdF9kbW5fZ3JwX2RlcGxveSIsInVtX2ludGFrZV91aV9jbGluaWNpYW4iLCJ2aXJ0dWFsX3Zpc2l0X3ByYWN0aXRpb25lciJdfSwic2NvcGUiOiJvcGVuaWQiLCJpc3MiOiJlY3AtZGV2IiwiZXhwIjoxNjE1MjQ3ODg0LCJjbGllbnRfaWQiOiJlY3BfZW5naW5lZXIifQ.Ztfla2urwUwW4V5pEnX2v0AouMUzY7fh6FD_znfA4plbv4cYgTHs_tOx9-bQhP0bc-u-7TjzZlKliLHTE4QwsAR4vGgjYc6PVZqDkHolgatmbEduwc08XOZtsJip7wleZEaLZPEkChkqDOK2mxp8hpDJVYm6KOVdNrTqfz9b0EHGdNxkJBWFaNDbG9aL9rp6Vy3NdzPEdg5MJYcJbrJGuge8bkE15nXhPrn7E_YIy0wWymzKg4eTgmZ3c5acEK1kNQQbtU3RWhv_9uZvrKRMc04WGAiv6fRTEbAQSrCSJrb96QwrtLe3kNCgjsKjn6aO7sLTlMTw1QSsOXsIVUSXVQ',
        'x-hasura-role': 'um_intake_ui_clinician',
      },
      query: { test: 'test' },
      params: { test: 'test' },
    };
    const hscInputRequest: CreateHscInput = {
      "indv_key_typ_ref_id": 2757,
      "indv_key_val": "16440436900",
      "srvc_set_ref_id": 3737,
      "rev_prr_ref_id": 3754,
      "mbr_cov": {
        "fst_nm": "Matt",
        "lst_nm": "Meyer",
        "bth_dt": new Date("1978-07-26"),
        "gdr_ref_id": 2109,
        "orig_sys_cd": "CDB_CS",
        "cov_eff_dt": new Date("2013-01-01"),
        "cov_end_dt": new Date("9999-12-31"),
        "src_mbr_id": "30830290",
        "src_mbr_partn_id": "10",
        "pol_nbr": "0128855",
        "cov_typ_ref_id": null,
        "clm_pltfm_ref_id": 363
      },
      "flwup_cntc_dtl": [{
          "name": "test",
          "role": null,
          "department": null,
          "phone": "111-111-1111",
          "fax": null,
          "email": null,
          "primaryContact": true,
        },
        {
          "name": "secondary contact name",
          "role": null,
          "department": null,
          "phone": "111-111-1111",
          "fax": null,
          "email": null,
          "primaryContact": false,
        }],
        "hsc_keys":[{
            "hsc_key_val": "1234",
            "hsc_key_typ_ref_id": 19217
        }],
      "hsc_facl": {
        "plsrv_ref_id": 3743,
        "srvc_desc_ref_id": 4347,
        "srvc_dtl_ref_id": 4296,
        "actul_admis_dttm": null,
        "actul_dschrg_dttm": null,
        "expt_admis_dt": new Date(),
        "expt_dschrg_dt": new Date(),
        "admis_ntfy_dttm": new Date(),
        "admis_ntfy_trans_id": 1,
        "adv_ntfy_dttm": new Date(),
        "adv_ntfy_trans_id": 1,
        "ctp_nom_sts_ref_id": 1,
        "dschrg_disp_ref_id": 1,
        "dschrg_ntfy_dttm": new Date(),
        "dschrg_ntfy_trans_id": 1,
        "goal_los_day_cnt": 1,
        "ipcm_typ_ref_id": 1,
        "rem_snf_day_cnt": 1,
        "snf_day_xhst_ind": 1,
        "tat_due_dttm": new Date(),
      },
      "hsc_diags": [
        {
          "diag_cd": "L02.52",
          "pri_ind": 1,
          "diag_othr_txt": "test"
        },
        {
          "diag_cd": "L02.51",
          "pri_ind": 0,
          "diag_othr_txt": "test"
        }
      ],
      "hsc_srvcs": [
        {
          "proc_cd": "80346",
          "proc_cd_schm_ref_id": 2,
          "srvc_hsc_prov_id": 1,
          "hsc_decn":
            {
               "hsc_decn_id":1,
              "decn_otcome_ref_id": 1,
              "decn_typ_ref_id": 2,
              "decn_rsn_ref_id": 3,
              "clm_note_txt": "test",
              "ovrd_clm_rmrk_ref_id": 1,
              "sys_clm_rmrk_ref_id": 1,
              "decn_src_desc": {
                "test": "test"
              },
              "wrt_decn_cmnct_dttm": new Date(),
              "decn_rndr_dttm": new Date(),
              "decn_mbr_cmnct_dttm": new Date(),
              "decn_prov_cmnct_dttm": new Date(),
              "gap_rev_otcome_ref_id": 2,
              "negot_rt": 1,
              "actul_nxt_rev_dt": new Date(),
              "decn_bed_day_cnt": 1,
              "aprv_proc_unit_cnt": 1,
              "aprv_unit_per_freq_cnt": 1,
              "ben_lvl_ref_id": 1,
              "ben_xcpt_ref_id": 1,
              "decn_clin_rsn_txt": "test",
              "decn_ent_by_user_id": "1",
              "decn_ent_rsn_ref_id": 1,
              "decn_hsc_prov_id": 1,
              "decn_made_by_user_id": '1',
              "decn_made_by_user_org_desc": "test",
              "decn_mbr_cmnct_to_role_ref_id": 1,
              "decn_prov_cmnct_to_role_ref_id": 1,
              "decn_ur_jurdc_ref_id": 1,
              "ltr_atr_list": {"test": "test"},
              "mbr_cov_dtl": {"test": "test"},
              "negot_rt_typ_ref_id": 1,
              "ovrd_rsn_ref_id": 1,
              "ovrd_rsn_txt": "test",
              "peer_to_peer_rev_dt": new Date(),
              "sched_nxt_rev_dt": new Date(),
              "site_of_care_pref_ref_id": 1,
              "hsc_decn_bed_days": [
                {
                  "strt_bed_dt": new Date(),
                  "rvnu_cd": "test",
                  "bed_typ_ref_id": 1,
                  "accum_bed_day_cnt": 1,
                  "decn_facl_cmnct_dttm": new Date(),
                  "decn_rndr_dttm_facl_lcl_txt": "test",
                  "questnr_rspn_id": 1
                }
              ]
            }
        }
      ],
      "hsr_notes": [
        {
          "note_txt_lobj": "test",
          "note_titl_txt": "test",
          "src_user_nm": "provider",
          "note_typ_ref_id": 321,
          "note_catgy_ref_id": 123,
            "note_sts_ref_id":null,
            "hsr_note_sbjs":[{
                "note_sbj_rec_id":"123",
                "note_sbj_typ_ref_id":234,
            }]

        },
        {
          "note_txt_lobj": "test1",
          "note_titl_txt": "test1",
          "src_user_nm": "provider",
          "note_typ_ref_id": 321,
          "note_catgy_ref_id": 123,
            "note_sts_ref_id":null,
            "hsr_note_sbjs":[{
                "note_sbj_rec_id":"123",
                "note_sbj_typ_ref_id":234,
            }]
        }
      ],
      "hsc_provs": [
        {
          "id": 1,
          "prov_keys": [
            {
              "prov_key_typ_ref_id": 2782,
              "prov_key_val": "1710081369"
            },
            {
              "prov_key_typ_ref_id": 16333,
              "prov_key_val": "288158608"
            },
            {
              "prov_key_typ_ref_id": 2783,
              "prov_key_val": "1710081369"
            }
          ],
          "hsc_prov_roles": [
            {
              "prov_role_ref_id": 3761
            }
          ],
            "prov_adr": {
                "adr_ln_1_txt": "1920 Colorado Ave",
                "adr_ln_2_txt": null,
                "zip_cd_txt": "904043414",
                "cty_nm": "Santa Monica",
                "st_ref_id": 1067
            }

        },
        {
          "id": 2,
          "prov_keys": [
            {
              "prov_key_typ_ref_id": 2782,
              "prov_key_val": "1255539573"
            },
            {
              "prov_key_typ_ref_id": 16333,
              "prov_key_val": "288158608"
            },
            {
              "prov_key_typ_ref_id": 2783,
              "prov_key_val": "1255539573"
            }
          ],
          "hsc_prov_roles": [
            {
              "prov_role_ref_id": 3759
            }
          ],
            "prov_adr": {
                "adr_ln_1_txt": "1920 Colorado Ave",
                "adr_ln_2_txt": null,
                "zip_cd_txt": "904043414",
                "cty_nm": "Santa Monica",
                "st_ref_id": 1067
            }
        }
      ],
      "hsr_actvs": [
        {
          "creat_user_id": "SYSTEM_PAAN",
          "chg_user_id": "SYSTEM_PAAN",
          "actv_strt_dttm": new Date(),
          "actv_typ_ref_id": 17292,
          "dur_mn_nbr": 0,
          "rslv_rsn_typ_id": 65,
          "rslv_otcome_typ_id": 151,
          "init_by_func_role_ref_id": null,
          "cntc_role_ref_id": 17292,
          "creatr_func_role_ref_id": 17292,
          "actv_prtn_ref_id": 17292,
          "cntc_user_id": null,
          "commt_txt": "user actv",
          "extr_ref_trans_id": "0",
          "mbr_cmnct": {
            "creat_user_id": "SYSTEM",
            "chg_user_id": "SYSTEM",
            "commt_txt": "ovc_mbr_appt_confirmation_template.html",
            "cmnct_adr_dtl": "{\"address\":\"viswanath_c@optum.com\"}",
            "dsclmr_cnsnt_desc": null,
            "mbr_cmnct_catgy_ref_id": 2563,
            "mbr_cmnct_chnl_ref_id": 17272,
            "mbr_cmnct_dir_ref_id": 20087,
            "mbr_cmnct_prr_ref_id": 2515,
            "mbr_cmnct_rsn_ref_id": 20090,
            "mbr_cmnct_sts_ref_id": 20066,
            "mbr_cmnct_sts_rsn_ref_id": null,
            "mbr_cmnct_typ_ref_id": 20089,
            "sts_dttm": new Date(),
            "mbr_cmnct_prtcps": [
               {
                 "fst_nm": "undefined",
                 "lst_nm": "undefined",
                 "mbr_cmnct_prtcp_engage_lvl_ref_id": null,
                 "mbr_cmnct_prtcp_role_ref_id": null,
                 "prtcp_desc": null,
                 "prtcp_key_typ_ref_id": null,
                 "prtcp_key_val": "undefined"
               }
             ]
          }
        }
      ]
    };
    const result2: AxiosResponse = { data: "https://dev-ecp-api.optum.com/auth/oauth/jwks", status: 200, statusText: 'OK', headers: {}, config: {}, };
    const result3: AxiosResponse = { data: "ecp", status: 200, statusText: 'OK', headers: {}, config: {}, };

    jest.spyOn(config, 'get').mockImplementationOnce(() => of(result2));
    jest.spyOn(config, 'get').mockImplementationOnce(() => of(result3));
    spyOn<any>(AuthorizationService, 'getEcpAuthencatedUser').and.returnValue({"userId": "00136607"})
    mapper.createHscRequestMapping(hscInputRequest, context).then((hsc) => {
      expect(hsc.hsc_diags.data.length).toEqual(2);
      expect(hsc.hsr_notes.data.length).toEqual(2);
      expect(hsc.hsc_keys.data.length).toEqual(1);
    });
  });
  it('should call mapProviderContractData', async () => {
    const context: HttpRequest = {
      method: null,
      url: '/api/graphql',
      headers: {
        authorization:
            'eyJraWQiOiIzMTRjOGJhMi0zZTZmLTQzYjItODVmOS1iOGMyMTNhNzZjMGUiLCJhbGciOiJSUzUxMiJ9.eyJ4LWVjcC1jbGFpbXMiOnsieC1lY3AtYXR0cnMiOnt9LCJ4LWVjcC1hbHQtdXNlci1pZCI6ImVjcF9lbmdpbmVlciIsIngtZWNwLWNsaS1vcmdzIjpbeyJvcmctaWQiOiJlY3AiLCJmdW5jLXJvbGVzIjpbeyJyb2xlLW5hbWUiOiJlbmdpbmVlciIsImFwcGwtcm9sZXMiOlsiYXNtdF9tZ210X2RlbW9fd3JpdGUiLCJhc3Nlc3NtZW50X2J1aWxkZXJfd3JpdGUiLCJhc3Nlc3NtZW50X21nbXRfd3JpdGUiLCJiYXNlX3Byb2R1Y3RfYnBtX2dycF9kZXBsb3kiLCJiYXNlX3Byb2R1Y3RfZG1uX2dycF9kZXBsb3kiLCJiaF9kZW1vX3VzZXIiLCJjYXJlX3BsYW5fZGVtb193cml0ZSIsImNhc2Vfd2ZfbWdtdF91aV9hZG1pbiIsImNsaW5pY2FsX2d1aWRlbGluZXNfdWhjX2Rtbl9ncnBfZGVwbG95IiwiY2xpbmljYWxfZ3VpZGVsaW5lc191c2VyIiwiZGFzaGJvYXJkX3JlYWQiLCJkaXN0YW5jZV9tYXRyaXhfdXNlciIsImRtc19kZWxldGUiLCJpbmR2X2NhcmVfcGxhbl91c2VyIiwibWJyX21nbXRfZGVtb193cml0ZSIsIm1icl9tZ210X3dyaXRlIiwibWVkX21nbXRfd3JpdGUiLCJwZ21fYnVpbGRlcl91c2VyIiwicGxhbl9vZl9jYXJlX3VzZXIiLCJwcmFjdGljZV9tZ210X3JlYWQiLCJwcm9ncmFtX3JlZmVycmFsc190aGlyZF9wYXJ0eV9yZWFkIiwicHJvZ3JhbV9yZWZlcnJhbHNfdXNlciIsInByb3ZpZGVyX21hbmFnZW1lbnRfdXNlciIsInJlYWNoX3VpX3N0YXJ0ZXJfdXNlciIsInJ1bGVzX2F1dGhvcmluZ193cml0ZSIsInNjaGVkdWxpbmdfcGF0aWVudCIsInN5c3RlbV9tZ210X3VzZXIiLCJ0ZW1wbGF0ZV9hdXRoX3VpX3VzZXIiLCJ1bV9jYXNlX21nbXRfYmFzZV9icG1fZ3JwX2RlcGxveSIsInVtX2Nhc2VfbWdtdF9iYXNlX2Rtbl9ncnBfZGVwbG95IiwidW1faW50YWtlX2Jhc2VfcHJvZHVjdF9icG1fZ3JwX2RlcGxveSIsInVtX2ludGFrZV9iYXNlX3Byb2R1Y3RfZG1uX2dycF9kZXBsb3kiLCJ1bV9pbnRha2VfdWlfY2xpbmljaWFuIiwidmlydHVhbF92aXNpdF9wcmFjdGl0aW9uZXIiXX1dfV0sIngtZWNwLXR5cGUiOiJDTElFTlRfQ1JFREVOVElBTFMiLCJ4LWVjcC11c2VyLWlkIjoiZWNwX2VuZ2luZWVyIn0sImh0dHBzOlwvXC9oYXN1cmEuaW9cL2p3dFwvY2xhaW1zIjp7IngtaGFzdXJhLWRlZmF1bHQtcm9sZSI6ImFzbXRfbWdtdF9kZW1vX3dyaXRlIiwieC1oYXN1cmEtYXR0cnMiOiJ7IH0iLCJ4LWhhc3VyYS1jbGktb3JnIjoiZWNwIiwieC1oYXN1cmEtdXNlci1pZCI6ImVjcF9lbmdpbmVlciIsIngtaGFzdXJhLWZ1bmMtcm9sZSI6ImVuZ2luZWVyIiwieC1oYXN1cmEtYWxsb3dlZC1yb2xlcyI6WyJhc210X21nbXRfZGVtb193cml0ZSIsImFzc2Vzc21lbnRfYnVpbGRlcl93cml0ZSIsImFzc2Vzc21lbnRfbWdtdF93cml0ZSIsImJhc2VfcHJvZHVjdF9icG1fZ3JwX2RlcGxveSIsImJhc2VfcHJvZHVjdF9kbW5fZ3JwX2RlcGxveSIsImJoX2RlbW9fdXNlciIsImNhcmVfcGxhbl9kZW1vX3dyaXRlIiwiY2FzZV93Zl9tZ210X3VpX2FkbWluIiwiY2xpbmljYWxfZ3VpZGVsaW5lc191aGNfZG1uX2dycF9kZXBsb3kiLCJjbGluaWNhbF9ndWlkZWxpbmVzX3VzZXIiLCJkYXNoYm9hcmRfcmVhZCIsImRpc3RhbmNlX21hdHJpeF91c2VyIiwiZG1zX2RlbGV0ZSIsImluZHZfY2FyZV9wbGFuX3VzZXIiLCJtYnJfbWdtdF9kZW1vX3dyaXRlIiwibWJyX21nbXRfd3JpdGUiLCJtZWRfbWdtdF93cml0ZSIsInBnbV9idWlsZGVyX3VzZXIiLCJwbGFuX29mX2NhcmVfdXNlciIsInByYWN0aWNlX21nbXRfcmVhZCIsInByb2dyYW1fcmVmZXJyYWxzX3RoaXJkX3BhcnR5X3JlYWQiLCJwcm9ncmFtX3JlZmVycmFsc191c2VyIiwicHJvdmlkZXJfbWFuYWdlbWVudF91c2VyIiwicmVhY2hfdWlfc3RhcnRlcl91c2VyIiwicnVsZXNfYXV0aG9yaW5nX3dyaXRlIiwic2NoZWR1bGluZ19wYXRpZW50Iiwic3lzdGVtX21nbXRfdXNlciIsInRlbXBsYXRlX2F1dGhfdWlfdXNlciIsInVtX2Nhc2VfbWdtdF9iYXNlX2JwbV9ncnBfZGVwbG95IiwidW1fY2FzZV9tZ210X2Jhc2VfZG1uX2dycF9kZXBsb3kiLCJ1bV9pbnRha2VfYmFzZV9wcm9kdWN0X2JwbV9ncnBfZGVwbG95IiwidW1faW50YWtlX2Jhc2VfcHJvZHVjdF9kbW5fZ3JwX2RlcGxveSIsInVtX2ludGFrZV91aV9jbGluaWNpYW4iLCJ2aXJ0dWFsX3Zpc2l0X3ByYWN0aXRpb25lciJdfSwic2NvcGUiOiJvcGVuaWQiLCJpc3MiOiJlY3AtZGV2IiwiZXhwIjoxNjE1MjQ3ODg0LCJjbGllbnRfaWQiOiJlY3BfZW5naW5lZXIifQ.Ztfla2urwUwW4V5pEnX2v0AouMUzY7fh6FD_znfA4plbv4cYgTHs_tOx9-bQhP0bc-u-7TjzZlKliLHTE4QwsAR4vGgjYc6PVZqDkHolgatmbEduwc08XOZtsJip7wleZEaLZPEkChkqDOK2mxp8hpDJVYm6KOVdNrTqfz9b0EHGdNxkJBWFaNDbG9aL9rp6Vy3NdzPEdg5MJYcJbrJGuge8bkE15nXhPrn7E_YIy0wWymzKg4eTgmZ3c5acEK1kNQQbtU3RWhv_9uZvrKRMc04WGAiv6fRTEbAQSrCSJrb96QwrtLe3kNCgjsKjn6aO7sLTlMTw1QSsOXsIVUSXVQ',
        'x-hasura-role': 'um_intake_ui_clinician',
      },
      query: { test: 'test' },
      params: { test: 'test' },
    };
    const prov =
    {
      "id": 1,
      "prov_keys": [
        {
          "prov_key_typ_ref_id": 2782,
          "prov_key_val": "1710081369"
        },
        {
          "prov_key_typ_ref_id": 16333,
          "prov_key_val": "288158608"
        },
        {
          "prov_key_typ_ref_id": 2783,
          "prov_key_val": "1710081369"
        }
      ],
      "hsc_prov_roles": [
        {
          "prov_role_ref_id": 3761
        }
      ],
      "prov_adr": {
        "adr_ln_1_txt": "1920 Colorado Ave",
        "adr_ln_2_txt": null,
        "zip_cd_txt": "904043414",
        "cty_nm": "Santa Monica",
        "st_ref_id": 1067
      }

    };
    const provResp = "";
    const mbr_cov_mrk ="";
    mapper.mapProviderContractData(provResp,prov, 473,4,mbr_cov_mrk,context).then((hsc) => {
      expect(hsc).toBeDefined();
    });
  });
});
