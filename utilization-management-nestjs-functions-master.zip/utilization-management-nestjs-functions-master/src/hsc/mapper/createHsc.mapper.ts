import {CreateHscInput} from "../models/createHsc.input";
import {ProviderService} from "../service/provider.service";
import {Injectable, Logger} from "@nestjs/common";
import {MemberClient} from "../../shared/graphql/memberdomain/memberClient";
import {GlobalConstants} from "../../shared/constants/globalConstants";
import { AuthorizationService } from '@ecp/func-tk/dist';
import { ConfigService } from '@nestjs/config';
import {ReferenceConstants} from "../../shared/constants/referenceConstants";
import {GraphQLClient} from "graphql-request/dist";
import {insertProc} from "../../shared/graphql/healthservicedomain/healthServiceQuery";
import {HealthServiceClient} from "../../shared/graphql/healthservicedomain/healthServiceClient";
import {HscSrvc} from "../models/hscSrvc";
import {HttpRequest} from "@azure/functions";
import {IndividualClient} from "../../shared/graphql/individualdomain/individualClient";
import {MemberService} from "../service/member/member.service";
import {InjectPinoLogger, PinoLogger} from "nestjs-pino/dist";
import * as moment from "moment";
import {insertCommunicationMutation} from "../../shared/graphql/communication-domain/memberCommunicationQuery";
import {MemberCommunicationClient} from "../../shared/graphql/communication-domain/memberCommunicationClient";
import {HsrActvSbjInput} from "../models/hsrActvSbj.input";
import {HsrActvInput} from "../models/hsrActv.input";
import {HscMemberCommInput} from "../models/hscMemberComm.input";
let getUserId;

let currentDate;
@Injectable()
export class CreateHscMapper {

    constructor(private providerService: ProviderService,
                private memberService: MemberService,
                private memberClient:MemberClient,
                private individualGraphqlClient: IndividualClient,
                @InjectPinoLogger(CreateHscMapper.name) private readonly logger: PinoLogger,
                private readonly configService: ConfigService,
                private readonly healthServiceClient: HealthServiceClient,
                private readonly memberCommunicationClient: MemberCommunicationClient) {}

    async createHscRequestMapping(createHscRequest: CreateHscInput, context: HttpRequest) {

        let hsc: any;
         currentDate = (moment(new Date())).format('DD-MMM-YYYY HH:mm:ss');
         getUserId = await AuthorizationService.getEcpAuthencatedUser(context.headers.authorization,
            this.configService.get<string>('JWK_URI'), this.configService.get<string>('ISSUER'));
         let hsc_keys = [];
         let hsr_notes = [];

        try {

            // createHscRequest.flwup_cntc_dtl.primary_cntct['creat_user_id'] = getUserId.userId;

            const hsc_diags = createHscRequest.hsc_diags.map((diag) => {
                return {
                    ...diag,
                    creat_user_id: diag.creat_user_id? diag.creat_user_id: getUserId.userId,
                    chg_user_id: diag.chg_user_id? diag.chg_user_id: getUserId.userId,
                    creat_dttm: currentDate,
                    chg_dttm: currentDate,
                }
            });

            if(createHscRequest.hsc_keys && createHscRequest.hsc_keys.length > 0){
                hsc_keys = createHscRequest.hsc_keys.map((key) => {
                    return {
                        ...key,
                        creat_user_id: key.creat_user_id? key.creat_user_id: getUserId.userId,
                        chg_user_id: key.chg_user_id? key.chg_user_id: getUserId.userId,
                        creat_dttm: currentDate,
                        chg_dttm: currentDate,
                    }
                });
            }
            if(createHscRequest.hsr_notes && createHscRequest.hsr_notes.length > 0){
                hsr_notes = createHscRequest.hsr_notes.map((note) => {
                    return {
                        creat_dttm: note.creat_dttm?note.creat_dttm:currentDate,
                        chg_dttm: currentDate,
                        creat_user_id: note.creat_user_id? note.creat_user_id: getUserId.userId,
                        chg_user_id: note.chg_user_id? note.chg_user_id: getUserId.userId,
                        note_txt_lobj: note.note_txt_lobj,
                        note_titl_txt: note.note_titl_txt,
                        src_user_nm: note.src_user_nm,
                        note_typ_ref_id: note.note_typ_ref_id,
                        note_catgy_ref_id: note.note_catgy_ref_id,
                    }
            });
            }
            const mbr_cov_dtl_res = await this.memberService.getMemberCoverageDetails(createHscRequest.indv_key_val, createHscRequest.indv_key_typ_ref_id, createHscRequest.mbr_cov, context);
            const lob_ref_id= mbr_cov_dtl_res.lob_ref_id;
            let memberCovMarketDetails: any;
            memberCovMarketDetails= {
                marketNumber:mbr_cov_dtl_res.marketNumber,
                marketType: mbr_cov_dtl_res.marketType,
                product_code:mbr_cov_dtl_res.product_code
            }
            const hsc_provs = await this.mapProviderDetails(createHscRequest,lob_ref_id,memberCovMarketDetails, context);
            if (hsc_provs) {
                hsc_provs.forEach((item) => {
                    item.hsc_prov_roles = item.hsc_prov_roles;
                })
            }

            const hsr_actvs = await this.mapActivitiesAndMbrComms(createHscRequest, context);

                hsc = {
                  indv_key_val: createHscRequest.indv_key_val,
                  indv_key_typ_ref_id: createHscRequest.indv_key_typ_ref_id,
                  creat_user_id: createHscRequest.creat_user_id? createHscRequest.creat_user_id: getUserId.userId,
                  chg_user_id: createHscRequest.chg_user_id? createHscRequest.chg_user_id: getUserId.userId,
                    creat_dttm: currentDate,
                    chg_dttm: currentDate,
                  srvc_set_ref_id: createHscRequest.srvc_set_ref_id,
                  rev_prr_ref_id: createHscRequest.rev_prr_ref_id,
                  hsc_rev_typ_ref_id: createHscRequest.hsc_rev_typ_ref_id,
                  hsc_sts_ref_id: createHscRequest.hsc_sts_ref_id,
                  hsc_sts_rsn_ref_id: createHscRequest.hsc_sts_rsn_ref_id,
                  auth_typ_ref_id: createHscRequest.auth_typ_ref_id,
                  creat_sys_ref_id: createHscRequest.creat_sys_ref_id,
                  mbr_cov_dtl: mbr_cov_dtl_res,
                  flwup_cntc_dtl: createHscRequest.flwup_cntc_dtl,
                  hsc_diags : {"data": hsc_diags},
                  hsr_notes : {"data": hsr_notes},
                  hsc_provs : {"data": hsc_provs},
                  hsc_keys : {"data": hsc_keys},
                  hsr_actvs: {"data": hsr_actvs},
            };
            hsc.indv_id = hsc.mbr_cov_dtl.indv_id;
            if(createHscRequest.srvc_set_ref_id != ReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_REFID){
                if(createHscRequest.hsc_facl.hsc_decn){
                    let hsc_decns: any = createHscRequest.hsc_facl.hsc_decn;
                    if (createHscRequest.hsc_facl.hsc_decn.hsc_decn_bed_days && createHscRequest.hsc_facl.hsc_decn.hsc_decn_bed_days.length > 0) {
                       const hsc_decn_bed_days =  {"data": createHscRequest.hsc_facl.hsc_decn.hsc_decn_bed_days};
                        hsc_decns.hsc_decn_bed_days = hsc_decn_bed_days;
                    }
                    hsc.hsc_decns = {"data": [hsc_decns]};
                    delete createHscRequest.hsc_facl.hsc_decn;
                }
                hsc.hsc_facls = {"data": createHscRequest.hsc_facl};
            }

            return hsc
        } catch (e) {
           this.logger.error("Internal error while processing createHscRequestMapping" + e);
            throw e;
        }
    }

   async mapProviderDetails (createHscRequest: CreateHscInput,lob_ref_id:number ,memberCovMarketDetails, httpRequest: HttpRequest) {
        let provResponse: any;
        let addressSeqNumber: any;
        let provContrResponse:any;
        let hscProvs: any = [];
        try {
          // for (const file of files) {
          for( const prov of createHscRequest.hsc_provs){
            // hscProvs = await Promise.all(createHscRequest.hsc_provs.map(async (prov) => {
                provResponse = await this.providerService.getProvData(prov.prov_keys[0]?.prov_key_val, prov.prov_keys[0]?.prov_key_typ_ref_id, prov.prov_adr.adr_ln_1_txt,
                    prov.prov_adr.adr_ln_2_txt, prov.prov_adr.zip_cd_txt, prov.prov_adr.cty_nm, prov.prov_adr.st_ref_id, prov.fst_nm, prov.lst_nm,
                    prov.bus_nm, httpRequest);
                const provMpinValue = prov.prov_keys.find((provKey) => provKey.prov_key_typ_ref_id === ReferenceConstants.PROVIDER_KEY_VALUE_TYP_REF_ID_MPIN)?.prov_key_val;
                addressSeqNumber=await this.providerService.getAddressSequenceNumber(prov,provMpinValue,httpRequest);
                //Temop - Disable contract fetching logic to fix 504 timeout issues
                //TODO find a permanant solution
                //provContrResponse = await this.mapProviderContractData(provResponse,prov,lob_ref_id,addressSeqNumber,httpRequest);
                const hscProv =  {
                        creat_user_id: prov.creat_user_id? prov.creat_user_id: getUserId.userId,
                        chg_user_id: prov.chg_user_id? prov.chg_user_id: getUserId.userId,
                        creat_dttm: currentDate,
                        chg_dttm: currentDate,
                        prov_loc_affil_id: provResponse?.v_prov_srch[0]?.prov_loc_affil_id,
                        prov_key_val: prov.prov_keys[0]?.prov_key_val,
                        prov_key_typ_ref_id: prov.prov_keys[0]?.prov_key_typ_ref_id,
                        spcl_ref_id: provResponse?.v_prov_srch[0]?.spcl_ref_id,
                        telcom_adr_id: provResponse?.v_prov_srch[0]?.telcom_adr_id,
                        prov_loc_affil_dtl:{ "providerDetails": {prov_keys: prov.prov_keys,  prov_adr: {...prov.prov_adr, st_ref_cd: provResponse?.v_prov_srch[0]?.st_ref_cd},
                                fst_nm: prov.fst_nm,
                                lst_nm: prov.lst_nm,
                                bus_nm: prov.bus_nm,
                                prov_id: provResponse?.v_prov_srch[0]?.prov_id,
                                prov_adr_id: provResponse?.v_prov_srch[0]?.prov_adr_id,
                                add_seq_num: addressSeqNumber,
                                prov_catgy_ref_id: provResponse?.v_prov_srch[0]?.prov_catgy_ref_id,
                                prov_catgy_ref_cd: provResponse?.v_prov_srch[0]?.prov_catgy_ref_cd,
                                "facilityContracts": []
                        }},
                        hsc_prov_roles: {
                            "data": prov.hsc_prov_roles.map((provRole) => {
                                return {
                                    prov_role_ref_id: provRole.prov_role_ref_id
                                }
                            })
                        }
                    };
                  hscProvs.push(hscProv);
                };
        } catch (e) {
            this.logger.error("Internal error while processing mapProviderDetails : " + e);
            throw e;
        }
        return hscProvs;
    }
    async mapProviderContractData (provResponse,prov,lob_ref_id, addressSeqNumber,memberCovMarketDetails,httpRequest){
        let facilityContractsResponse: any;

        const facilityProvider = prov.hsc_prov_roles.find((provRole) => provRole.prov_role_ref_id === ReferenceConstants.PROVIDER_ROLE_REF_ID_FACILITY);
        const provMpinValue = prov.prov_keys.find((provKey) => provKey.prov_key_typ_ref_id === ReferenceConstants.PROVIDER_KEY_VALUE_TYP_REF_ID_MPIN)?.prov_key_val;
        const provTinValue = prov.prov_keys.find((provKey) => provKey.prov_key_typ_ref_id === ReferenceConstants.PROVIDER_KEY_VALUE_TYP_REF_ID_TIN)?.prov_key_val;
        if (facilityProvider && lob_ref_id) {
            if (ReferenceConstants.LOB_TYPE_EnI.indexOf(lob_ref_id) != -1) {
                console.log("LOB -> E&I");
                const contractResponse =  await this.providerService.getPesFacilityContractData(prov, provMpinValue, provTinValue,memberCovMarketDetails,httpRequest);
                const medNecResponse = await this.providerService.getMedNecTypeDataForEnI(provMpinValue,provTinValue,lob_ref_id,addressSeqNumber,httpRequest);
                facilityContractsResponse =  contractResponse;
                facilityContractsResponse.push({
                    medNecRestrictionType:this.mapMedNecTypeData(medNecResponse)
                });
            }
            else if (ReferenceConstants.LOB_TYPE_MnR.indexOf(lob_ref_id) != -1 || ReferenceConstants.LOB_TYPE_CnS.indexOf(lob_ref_id) != -1) {
                console.log("LOB -> M&R || C&S");
                const provContrResponse = await this.providerService.getNrtFacilityContractData(provMpinValue, provTinValue,lob_ref_id,addressSeqNumber,httpRequest);
                facilityContractsResponse = [{
                    "contractPaperType":   this.mapNRTFacilityContractData(provContrResponse),
                    "medNecClauseData":   this.mapNRTFacilityMedNecData(provContrResponse)
                }];
            }
        } else {
                console.log("LOB -> not found " + lob_ref_id);
        }
        return facilityContractsResponse;
    }

     mapNRTFacilityContractData (nrtContractDataResponse: any) {
        const contractData = [];
        if(nrtContractDataResponse) {
            nrtContractDataResponse.prov_contr.forEach((provcontr) => {
                contractData.push({
                    contractPaperTypeCode: provcontr.prov_reim_typ_ref_cd.ref_dspl,
                    contractPaperTypeDescription: provcontr.prov_reim_typ_ref_cd.ref_desc
                });
            });
        }
        return contractData;
    }

     mapNRTFacilityMedNecData (nrtContractDataResponse: any) {
        const medNeckData = [];
        if(nrtContractDataResponse) {
            nrtContractDataResponse.prov_contr.forEach((provcontr) => {
                medNeckData.push({
                    clauseCode: provcontr.med_nec_rev_claus_ref_cd.ref_desc
                });
            });
        }
        return medNeckData;
    }

    mapMedNecTypeData(medNecTypeDataRes: any){
        const medNecTypeData = [];
        if(medNecTypeDataRes){
            medNecTypeDataRes.prov_contr.forEach((provcontr) => {
                medNecTypeData.push({
                    medNecRestrictionType: provcontr.med_nec_rev_claus_ref_cd.ref_desc
                });
            });
        }
        return medNecTypeData;
    }

    async insertHscSrvc(hsc, hsc_id,  httpRequest):  Promise<[HscSrvc]> {
        const hscGraphqlClient: GraphQLClient = this.healthServiceClient.getGraphqlClient(httpRequest);
        try {
            const hsc_srvcs = await Promise.all(hsc.hsc_srvcs.map(async (srvc) => {
                const hsc_srvc: any = {
                    proc_cd: srvc.proc_cd,
                    proc_cd_schm_ref_id: srvc.proc_cd_schm_ref_id,
                    proc_othr_txt: srvc.proc_othr_txt,
                    hsc_srvc_non_facls: srvc.hsc_srvc_non_facls,
                    hsc_decns: srvc.hsc_decn? [srvc.hsc_decn] : [],
                    creat_user_id: hsc.creat_user_id? hsc.creat_user_id : getUserId.userId,
                    chg_user_id: hsc.chg_user_id? hsc.chg_user_id : getUserId.userId,
                    creat_dttm: currentDate,
                    chg_dttm: currentDate,
                    hsc_id: hsc_id,
                    srvc_hsc_prov_id: await this.providerService.getProviderId(srvc.hsc_prov, hsc_id, httpRequest),
                    expmt_proc_ind: srvc.expmt_proc_ind,
                    hsc_srvc_rev_typ_ref_id: srvc.hsc_srvc_rev_typ_ref_id,
                    adv_ntfy_trans_id: srvc.adv_ntfy_trans_id,
                    ben_chk_sts_ref_id: srvc.ben_chk_sts_ref_id,
                    adv_ntfy_dttm: srvc.adv_ntfy_dttm,
                    expt_proc_dt: srvc.expt_proc_dt

            };

                hsc_srvc.hsc_decns.forEach((hscDecn) => {
                  hscDecn.hsc_id = hsc_id;
                  if (hscDecn.hsc_decn_bed_days && hscDecn.hsc_decn_bed_days.length > 0) {
                    hscDecn.hsc_decn_bed_days = {"data": hscDecn.hsc_decn_bed_days};
                  }
                });
                hsc_srvc.hsc_decns = {"data": hsc_srvc.hsc_decns};

                if (hsc.srvc_set_ref_id == ReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_REFID) {
                    hsc_srvc.hsc_srvc_non_facls.forEach((hscSrvcNonFacl) => {
                    if (hscSrvcNonFacl.hsc_srvc_non_facl_dmes && hscSrvcNonFacl.hsc_srvc_non_facl_dmes.length) {
                        hscSrvcNonFacl.hsc_srvc_non_facl_dmes = {"data": hscSrvcNonFacl?.hsc_srvc_non_facl_dmes};
                    }});
                    hsc_srvc.hsc_srvc_non_facls = {"data": hsc_srvc.hsc_srvc_non_facls};
                }
                return hsc_srvc;
            }));
            const hscSrvcVariables = {
                hscSrvcs: hsc_srvcs
            };
            this.logger.info("Before mutation (insertProc) to health service domain : " + new Date());
            const hscSrvcData = await hscGraphqlClient.request(insertProc, hscSrvcVariables);
            this.logger.info("After mutation (insertProc) to health service domain : "+ new Date());
            return hscSrvcData.insert_hsc_srvc.returning;
        }catch (e) {
            this.logger.error("Internal error while processing insertHscSrvc : " + e)
            throw e;
        }
    }

    private async mapActivitiesAndMbrComms(createHscRequest: CreateHscInput, httpRequest: HttpRequest) {
        let hsr_actvs: any[] = [];
        try {
            // Activities and mbr comm
            if (createHscRequest.hsr_actvs && createHscRequest.hsr_actvs.length > 0) {
                hsr_actvs = await Promise.all(createHscRequest.hsr_actvs.map(async (actv: HsrActvInput) => {
                    // calling mbr_cmnct and sending mbr_cmnct_id in hsr_actv_sbj

                    let hsrActvSbjs: HsrActvSbjInput[] = await this.insertMemberCommunications(actv, httpRequest);
                    return {
                        ...actv,
                        creat_user_id: actv.creat_user_id ? actv.creat_user_id : getUserId.userId,
                        chg_user_id: actv.chg_user_id ? actv.chg_user_id : getUserId.userId,
                        hsr_actv_sbjs: {"data": hsrActvSbjs}
                    }
                }));
            }
        } catch (e) {
            this.logger.error("Internal error while processing mapActivitiesAndMbrComms : " + e);
            throw e;
        }
        return hsr_actvs;
    }

    private async insertMemberCommunications(activity: HsrActvInput, httpRequest: HttpRequest): Promise<HsrActvSbjInput[]> {
        let mbrCmnct: any = activity.mbr_cmnct;
        let hsrActvSbjs: HsrActvSbjInput[] = [];
        if (mbrCmnct) {
            const mbrCmnctGraphQLClient: GraphQLClient = this.memberCommunicationClient.getGraphqlClient(httpRequest);

            mbrCmnct.mbr_cmnct_prtcps = mbrCmnct.mbr_cmnct_prtcps ? {"data": mbrCmnct.mbr_cmnct_prtcps} : [];
            const mbrCmnctVariables = {
                mbr_cmnct: mbrCmnct
            };
            this.logger.info("Before mutation (insertMbrCmnct) to Member Communication domain : " + new Date());
            const mbrCmnctsData = await mbrCmnctGraphQLClient.request(insertCommunicationMutation, mbrCmnctVariables);
            this.logger.info("After mutation (insertMbrCmnct) to Member Communication domain : " + new Date());

            hsrActvSbjs = [{
                hsr_sbj_rec_id: mbrCmnctsData.insert_mbr_cmnct_one.mbr_cmnct_id,
                hsr_sbj_typ_ref_id: ReferenceConstants.SBJ_TYP_REF_ID_MBR_CMNCT_ID
            }];
            delete activity.mbr_cmnct;
        }
        return hsrActvSbjs;
    }
}
