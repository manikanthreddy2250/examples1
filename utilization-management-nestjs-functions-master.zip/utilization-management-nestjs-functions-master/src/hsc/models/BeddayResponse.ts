import GraphQLJSON from "graphql-type-json";
import {Field, ObjectType} from "@nestjs/graphql";

@ObjectType()
export class BeddayResponse {
    @Field((type) => GraphQLJSON, { nullable: true })
    beddayRes: any;
}
