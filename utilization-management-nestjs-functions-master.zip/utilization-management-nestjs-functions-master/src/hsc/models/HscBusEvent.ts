import { HscBusEventName } from './HscBusEventName';

export interface HscBusEvent {
  eventName: HscBusEventName;
  payload: any;
}
