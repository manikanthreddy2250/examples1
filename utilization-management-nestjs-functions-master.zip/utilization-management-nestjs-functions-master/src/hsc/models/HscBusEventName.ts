export const enum HscBusEventName {
  HSC_CREATE = 'ocm.um.healthservice.hsc.create',
  HSC_UPDATE = 'ocm.um.healthservice.hsc.update',
  HSC_CASE_TYPE_UPDATE = 'ocm.um.healthservice.hsc.casetype.update',
  HSC_PROCEDURE_UPDATE = 'ocm.um.healthservice.hsc.procedure.update',
  HSC_DIAGNOSIS_UPDATE = 'ocm.um.healthservice.hsc.diagnosis.update',
  HSC_NOTES_UPDATE = 'ocm.um.healthservice.hsc.note.update',
  HSC_PROVIDER_UPDATE = 'ocm.um.healthservice.hsc.provider.update',
  HSC_CONTACT_UPDATE = 'ocm.um.healthservice.hsc.contact.update',
  HSC_FOLLOWUP_CONTACT_UPDATE = 'ocm.um.healthservice.hsc.contact.update',
  HSC_DECISION_UPDATE = 'ocm.um.healthservice.hsc.facility.decision.update',
  HSC_ADMISSION_DATE_UPDATE = 'ocm.um.healthservice.hsc.facility.admission.update',
  HSC_DISCHARGE_DATE_UPDATE = 'ocm.um.healthservice.hsc.facility.discharge.update',
  HSC_EXPT_ADMISSION_DATE_UPDATE = 'ocm.um.healthservice.hsc.facility.expt.admission.update',
  HSC_EXPT_DISCHARGE_DATE_UPDATE = 'ocm.um.healthservice.hsc.facility.expt.discharge.update'
}

