export const enum HscEntityActionType {
  CREATE = 'Create',
  UPDATE = 'Update',
}
