import {Field, InputType, Int} from "@nestjs/graphql";

@InputType()
export class HsrNoteSbjInput {
    @Field({nullable : true})
    note_sbj_rec_id?: string;

    @Field(type => Int, {nullable : true})
    note_sbj_typ_ref_id?: number

    @Field({nullable : true})
    creat_dttm? : Date;

    @Field({nullable : true})
    creat_user_id? :  string

    @Field({nullable : true})
    chg_dttm? : Date;

    @Field({nullable : true})
    chg_user_id? :  string
}