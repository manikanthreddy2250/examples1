import { Field, InputType } from "@nestjs/graphql";
import { HsrActivityDataInput } from "./hscActivityData.input";
import { HscMemberCommInput } from "./hscMemberComm.input";

@InputType()
export class ActivityRequest {
  @Field((type) => HsrActivityDataInput)
  activity: HsrActivityDataInput;

  @Field((type) => HscMemberCommInput, { nullable: true })
  communication?: HscMemberCommInput;

}