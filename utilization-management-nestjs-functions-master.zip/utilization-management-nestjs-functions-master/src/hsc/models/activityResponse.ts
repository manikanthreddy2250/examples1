import { Field, ObjectType, Int} from "@nestjs/graphql";

@ObjectType()
export class ActivityResponse {
    @Field(type => Int)
    hsr_actv_id: number;
}