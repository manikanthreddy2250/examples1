import { Field, InputType, Int } from "@nestjs/graphql";

@InputType()
export class BaseInputRequest {
    @Field((type) => Int, { nullable: true })
    creat_sys_ref_id?: number;

    @Field((type) => Int, { nullable: true })
    chg_sys_ref_id?: number;

    @Field(type => String, { nullable: true })
    creat_user_id?: string;

    @Field(type => String, { nullable: true })
    chg_user_id?: string;

    @Field({ nullable: true })
    creat_dttm?: Date;

    @Field({ nullable: true })
    chg_dttm?: Date;

}