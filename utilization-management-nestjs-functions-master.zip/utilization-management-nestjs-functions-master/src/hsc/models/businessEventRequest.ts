
export class BusinessEventRequest {
    event_name: string;
    event_date_time: string;
    event_source: string;
    event_channel: string;
    app_id: string;
    payload: any;
}
