import {Field, ObjectType, Int } from "@nestjs/graphql";
import {ReferenceData} from "./referenceData";
import {HscFacl} from "./hscFacl";
import {HscSrvcNonFacl} from "./hscSrvcNonFacl";
import {HscSrvc} from "./hscSrvc";

@ObjectType()
export class CaseTypeDetailsResponse {
    @Field((type) => Int, { nullable: true })
    hsc_id: number;

    @Field((type) => Int, { nullable: true })
    hsc_sts_ref_id?: number;

    @Field({ nullable: true })
    hsc_sts_ref_cd?: ReferenceData;

    @Field((type) => Int, { nullable: true })
    rev_prr_ref_id?: number;

    @Field({ nullable: true })
    rev_prr_ref_cd?: ReferenceData;

    @Field((type) => Int, { nullable: true })
    srvc_set_ref_id?: number;

    @Field({ nullable: true })
    srvc_set_ref_cd?: ReferenceData;

    @Field(type => [HscFacl], { nullable: true })
    hsc_facls?: HscFacl[];

    @Field((type) => [HscSrvc], { nullable: true })
    hsc_srvcs?: HscSrvc[];
}

