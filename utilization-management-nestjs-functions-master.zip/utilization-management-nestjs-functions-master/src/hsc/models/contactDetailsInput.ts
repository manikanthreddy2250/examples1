import {Field, InputType, Int} from "@nestjs/graphql";

@InputType()
export class ContactDetailsInput {
    @Field()
    name : string;
    @Field({nullable: true})
    role?: string;
    @Field({nullable: true})
    department?: string;
    @Field({nullable: true})
    phone? : string;
    @Field({nullable: true})
    fax?: string;
    @Field({nullable: true})
    email?: string;
    @Field({nullable: true})
    primaryContact?: boolean;
}
