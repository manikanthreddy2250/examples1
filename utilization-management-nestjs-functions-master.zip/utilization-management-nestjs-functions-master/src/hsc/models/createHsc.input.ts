import {Field, InputType, Int} from "@nestjs/graphql";
import {HscFaclInput} from "./hscFacl.input";
import {HscSrvcInput} from "./hscSrvc.input";
import {HscProvInput} from "./hscProv.input";
import {HscDiagnosisInput} from "./hscDiagnosisInput";
import {HsrNotesInput} from "./hscNote.input";
import {MemberCovInput} from "./memberCov.input";
import {HscKeyInput} from "./hscKey.input";
import {ContactDetailsInput} from "./contactDetailsInput";
import {HsrActvInput} from "./hsrActv.input";

@InputType()
export class CreateHscInput {

    @Field({nullable:true})
    creat_user_id?: string;

    @Field({nullable:true})
    chg_user_id?: string;

    @Field(type => Int)
    indv_key_typ_ref_id: number;

    @Field()
    indv_key_val: string;

    @Field(type => Int, {nullable: true})
    srvc_set_ref_id?: number;

    @Field(type => Int, {nullable: true})
    rev_prr_ref_id?: number;

    @Field(type => Int, {nullable: true})
    hsc_rev_typ_ref_id?: number;

    @Field(type => Int, {nullable: true})
    hsc_sts_ref_id?: number;

    @Field(type => Int, {nullable: true})
    hsc_sts_rsn_ref_id?: number;

    @Field(type => Int, {nullable: true})
    auth_typ_ref_id?: number;

    @Field(type => Int, {nullable: true})
    creat_sys_ref_id?: number;

    @Field()
    mbr_cov: MemberCovInput;

    @Field(type => [ContactDetailsInput],{nullable: true})
    flwup_cntc_dtl: ContactDetailsInput[];

    @Field({nullable: true})
    hsc_facl?: HscFaclInput;

    @Field(type => [HscDiagnosisInput])
    hsc_diags: HscDiagnosisInput[];

    @Field(type => [HscSrvcInput])
    hsc_srvcs: HscSrvcInput[];

    @Field(type => [HsrNotesInput], {nullable: true})
    hsr_notes?: HsrNotesInput[];

    @Field(type => [HscProvInput])
    hsc_provs: HscProvInput[];

    @Field(type => [HscKeyInput], {nullable: true})
    hsc_keys?: HscKeyInput[];

    @Field(type => [HsrActvInput], {nullable: true})
    hsr_actvs?: HsrActvInput[];

    //todo add attachments
}
