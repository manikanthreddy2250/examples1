import {Field, InputType, Int} from "@nestjs/graphql";
import {CreateHscInput} from "./createHsc.input";

@InputType()
export class CreateHscRequestInput {
    @Field()
    hsc: CreateHscInput;

}
