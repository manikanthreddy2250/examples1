import {Field, ObjectType } from "@nestjs/graphql";
import {Hsc} from "./hsc";

@ObjectType()
export class CreateHscResponse {
    @Field()
    data: Hsc;
}
