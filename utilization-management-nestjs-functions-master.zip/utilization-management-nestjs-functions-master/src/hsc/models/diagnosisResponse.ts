import {Field, Int, ObjectType} from "@nestjs/graphql";

@ObjectType()
export class DiagnosisResponse {
    @Field()
    action: string;
    @Field(type => Int)
    hsc_diag_id: number;
}