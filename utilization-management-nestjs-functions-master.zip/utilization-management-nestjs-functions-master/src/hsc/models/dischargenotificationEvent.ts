import { HscFacl } from "./hscFacl";


export class HscFacilityDischargeNotificationEvent extends HscFacl{
    action: string;
    hsc_id: number;
    chg_dttm:Date;
 }
 
 
 
