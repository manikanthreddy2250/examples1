import { Field, InputType, Int } from '@nestjs/graphql';
import { HscFaclInput } from './hscFacl.input';
import { HscProvInput } from './hscProv.input';
import { HscSrvcInput } from './hscSrvc.input';

@InputType({
  description:
    'Hsc input object. All fields are optional. hsc_id takes precedence in finding the saved hsc details. If hsc status is open hsc information is read from hsc domain else read from request fields',
})
export class DuplicateCheckHscInput {
  @Field((type) => Int, { nullable: true })
  hsc_id?: number;

  @Field((type) => Int, { nullable: true })
  indv_key_typ_ref_id?: number;

  @Field({ nullable: true })
  indv_key_val?: string;

  @Field((type) => Int, { nullable: true })
  srvc_set_ref_id?: number;

  @Field((type) => HscFaclInput, { nullable: true })
  hsc_facl?: HscFaclInput;

  @Field((type) => [HscProvInput], { nullable: true })
  hsc_provs?: HscProvInput[];

  @Field((type) => [HscSrvcInput], { nullable: true })
  hsc_srvcs?: HscSrvcInput[];
}
