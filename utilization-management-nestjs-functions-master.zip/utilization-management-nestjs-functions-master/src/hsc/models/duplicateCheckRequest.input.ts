import { Field, InputType } from '@nestjs/graphql';
import {DuplicateCheckHscInput} from "./duplicateCheckHsc.input";

@InputType()
export class DuplicateCheckRequestInput {
  @Field()
  hsc: DuplicateCheckHscInput;
}
