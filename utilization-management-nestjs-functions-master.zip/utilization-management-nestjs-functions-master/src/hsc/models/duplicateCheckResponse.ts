import { Field, Int, ObjectType } from '@nestjs/graphql';
import { Hsc } from './hsc';

@ObjectType()
export class DuplicateCheckResponse {
  @Field((type) => [Hsc])
  hsc_duplicates: Hsc[];
}
