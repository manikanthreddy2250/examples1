import {Field, InputType} from "@nestjs/graphql";
import {HscInput} from "./hsc.input";

@InputType()
export class GetHscAuthRequest {
    @Field()
    hsc: HscInput;
}
