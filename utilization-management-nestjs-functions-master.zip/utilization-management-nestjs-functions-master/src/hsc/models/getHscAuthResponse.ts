import {Field, Int, ObjectType} from "@nestjs/graphql";
import {Hsc} from "./hsc";

@ObjectType()
export class GetHscAuthResponse {
    @Field(type => [Hsc])
    hsc: Hsc[];
}
