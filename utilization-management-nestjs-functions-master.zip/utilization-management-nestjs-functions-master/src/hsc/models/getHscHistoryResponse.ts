import {Field, Int, ObjectType} from "@nestjs/graphql";
import { HistoryResponseObject } from "./historyResponse";

@ObjectType()
export class HscHistoryResponse {

    @Field(type => [HistoryResponseObject])
    hsc: HistoryResponseObject[];

}
