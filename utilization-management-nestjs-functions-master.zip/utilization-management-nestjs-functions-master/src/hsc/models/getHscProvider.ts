import {Field, Int, ObjectType} from "@nestjs/graphql";
import {HscProv} from "./hscProv";

@ObjectType()
export class GetHscProviderResponse {
    @Field(type => [HscProv])
    hscProv: HscProv[];
}
