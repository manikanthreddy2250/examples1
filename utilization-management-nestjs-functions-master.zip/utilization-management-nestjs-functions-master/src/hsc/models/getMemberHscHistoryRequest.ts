import {Field, InputType} from "@nestjs/graphql";

@InputType()
export class GetMemberHscHistoryRequest {

    @Field()
    indv_key_val : String;
}