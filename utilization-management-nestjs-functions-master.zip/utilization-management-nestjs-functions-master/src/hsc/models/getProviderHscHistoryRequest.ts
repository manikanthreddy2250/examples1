import { Field, InputType, Int } from '@nestjs/graphql';

@InputType()
export class GetProviderHscHistoryRequest {
  @Field()
  prov_key_val: string;

  @Field((type) => Int)
  prov_key_typ_ref_id: number;
}
