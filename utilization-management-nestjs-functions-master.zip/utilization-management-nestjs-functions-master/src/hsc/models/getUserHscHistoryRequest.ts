import {Field, InputType} from "@nestjs/graphql";

@InputType()
export class GetUserHscHistoryRequest {

    @Field()
    creat_user_id : String;
}