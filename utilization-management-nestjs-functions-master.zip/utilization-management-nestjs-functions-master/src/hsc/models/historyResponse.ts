import {Field, Int, ObjectType} from "@nestjs/graphql";
import { Transform } from 'class-transformer';


@ObjectType()
export class HistoryResponseObject {
    @Field(type => Int)
    hscId: number;

    @Field({nullable: true})
    memberName : String;

    @Field({nullable: true})
    providerName?: String;

    @Field()
    placeOfService : String;

    @Transform(x => new Date('DD/MM/YY'))
    @Field({nullable: true})
    createDate?: Date;

    @Field()
    status : String;

}
