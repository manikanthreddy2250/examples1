import {Field, InputType, Int} from "@nestjs/graphql";

@InputType()
export class HscInput {
    @Field(type => Int)
    hsc_id : number;

}
