import {Field,Int,ObjectType} from '@nestjs/graphql';
import GraphQLJSON from 'graphql-type-json';
import { HscKey } from './hscKey';
import { HscFacl } from './hscFacl';
import { HscDiag } from './hscDiag';
import { HsrNote } from './hscNote';
import { HscProv } from './hscProv';
import { ReferenceData } from './referenceData';
import { HscSrvc } from './hscSrvc';
import { IndividualData } from './individualData';
import { HscDecn } from './hscDecn'
import { HsrActv } from "./hsrActv";

@ObjectType()
export class Hsc {
  @Field((type) => Int)
  hsc_id: number;

  @Field((type) => Int, { nullable: true })
  state_ref_id?: number;

  @Field({nullable: true})
  state_ref_cd?: string;

  @Field({ nullable: true })
  state_ref_dspl_nm?: string;

  @Field() // TODO - temporary fix as date type is not returning
  creat_dttm: string;

  @Field({ nullable: true })
  creat_user_id?: string;

  @Field({ nullable: true })
  creat_sys_ref_id?: number;

  @Field((type) => Int, { nullable: true })
  indv_id?: number;

  @Field((type) => Int, { nullable: true })
  indv_key_typ_ref_id?: number;

  @Field({ nullable: true })
  indv_key_typ_ref_cd?: ReferenceData;

  @Field({ nullable: true })
  indv_key_val?: string;

  @Field((type) => GraphQLJSON, { nullable: true })
  mbr_cov_dtl?: any;

  @Field((type) => Int, { nullable: true })
  hsc_sts_ref_id?: number;

  @Field({ nullable: true })
  hsc_sts_ref_cd?: ReferenceData;

  @Field((type) => Int, { nullable: true })
  hsc_rev_typ_ref_id?: number;

  @Field({ nullable: true })
  hsc_rev_typ_ref_cd?: ReferenceData;

  @Field((type) => GraphQLJSON, { nullable: true })
  flwup_cntc_dtl?: any;

  @Field(type => [IndividualData], {nullable: true})
  individual?: IndividualData[];

  @Field((type) => Int, { nullable: true })
  rev_prr_ref_id?: number;

  @Field({ nullable: true })
  rev_prr_ref_cd?: ReferenceData;

  @Field((type) => Int, { nullable: true })
  srvc_set_ref_id?: number;

  @Field({ nullable: true })
  srvc_set_ref_cd?: ReferenceData;

  @Field(type => [HscKey], { nullable: true })
  hsc_keys?: HscKey[];

  @Field(type => [HscSrvc], { nullable: true })
  hsc_srvcs?: HscSrvc[];

  @Field(type => [HscFacl], { nullable: true })
  hsc_facls?: HscFacl[];

  @Field(type => [HscDiag], { nullable: true })
  hsc_diags?: HscDiag[];

  @Field(type => [HsrNote], { nullable: true })
  hsr_notes?: HsrNote[];

  @Field(type => [HscProv], { nullable: true })
  hsc_provs?: HscProv[];

  @Field({nullable:true})
  chg_user_id?: string;

  @Field(type => Int, {nullable: true})
  hsc_sts_rsn_ref_id?: number;

  @Field({ nullable: true })
  hsc_sts_rsn_ref_cd?: ReferenceData;

  @Field(type => Int, {nullable: true})
  auth_typ_ref_id?: number;

  @Field({ nullable: true })
  auth_typ_ref_cd?: ReferenceData;

  @Field(type => [HscDecn], {nullable: true})
  hsc_decns?: HscDecn[];

  @Field(type => [HsrActv], {nullable: true})
  hsr_actvs?: HsrActv[];

}
