import { Field, InputType, Int } from "@nestjs/graphql";
import { BaseInputRequest } from "./baseInputRequest";
@InputType()
export class HsrActivityDataInput extends BaseInputRequest {
    @Field(type => Int)
    actv_typ_ref_id: number;
    @Field(type => Int)
    hsc_id: number;
    @Field(type => Int)
    rslv_otcome_typ_id: number;
    @Field(type => Int, {nullable:true})
    hsr_sbj_rec_id?: number;
    @Field(type => Int, {nullable:true})
    hsr_sbj_typ_ref_id?: number;

}