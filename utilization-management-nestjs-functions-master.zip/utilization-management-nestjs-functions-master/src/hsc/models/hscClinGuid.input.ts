import {Field, ObjectType, Int, InputType} from "@nestjs/graphql";

@InputType()
export class HscClinGuidInput {

    @Field(type => Int, {nullable: true})
    hsc_clin_guid_id?: number;

    @Field({nullable : true})
    clin_rev_desc : string;

    @Field(type => Int, {nullable : true})
    clin_rev_otcome_ref_id : number;

    @Field(type => Int)
    clin_rev_sts_ref_id : number;

}