import {Field, InputType, Int} from "@nestjs/graphql";
import {ContactDetailsInput} from "./contactDetailsInput";

@InputType()
export class HscContactDetailsInput {
    @Field()
    primary_cntct : ContactDetailsInput;
    @Field({nullable: true})
    secondary_cntct?: ContactDetailsInput;
}
