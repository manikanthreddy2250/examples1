import {Field, Int, Float, ObjectType} from "@nestjs/graphql";
import {HscDecnBedDay} from "./hscDecnBedDay";
import GraphQLJSON from "graphql-type-json";
import { ReferenceData } from "./referenceData";

@ObjectType()
export class HscDecn {
    @Field(type => Int, { nullable: true })
    decn_otcome_ref_id? : number;

    @Field({ nullable: true })
    decn_otcome_ref_cd?: ReferenceData;

    @Field(type => Int, { nullable: true })
    decn_typ_ref_id? : number;

    @Field({ nullable: true })
    decn_typ_ref_cd?: ReferenceData;

    @Field(type => Int, { nullable: true })
    decn_rsn_ref_id? : number;

    @Field({ nullable: true })
    decn_rsn_ref_cd?: ReferenceData;

    @Field({nullable: true})
    actul_nxt_rev_dt?: Date;

    @Field(type => Int, {nullable: true})
    decn_bed_day_cnt?: number;

    @Field(type => Int, {nullable: true})
    aprv_proc_unit_cnt?: number;

    @Field(type => Int, {nullable: true})
    aprv_unit_per_freq_cnt?: number;

    @Field(type => Int, {nullable: true})
    ben_lvl_ref_id?: number;

    @Field({ nullable: true })
    ben_lvl_ref_cd?: ReferenceData;

    @Field(type => Int, {nullable: true})
    ben_xcpt_ref_id?: number;

    @Field({ nullable: true })
    ben_xcpt_ref_cd?: ReferenceData;

    @Field({nullable: true})
    clm_note_txt?: string;

    @Field({nullable: true})
    decn_clin_rsn_txt?: string;

    @Field({nullable: true})
    decn_ent_by_user_id?: string;

    @Field(type => Int, {nullable: true})
    decn_ent_rsn_ref_id?: number;

    @Field({ nullable: true })
    decn_ent_rsn_ref_cd?: ReferenceData;

    @Field(type => Int, {nullable: true})
    decn_hsc_prov_id?: number;

    @Field({nullable: true})
    decn_made_by_user_id?: string;

    @Field(type => GraphQLJSON, {nullable: true})
    decn_made_by_user_org_desc?: any;

    @Field({nullable: true})
    decn_mbr_cmnct_dttm?: Date;

    @Field(type => Int, {nullable: true})
    decn_mbr_cmnct_to_role_ref_id?: number;

    @Field({ nullable: true })
    decn_mbr_cmnct_to_role_ref_cd?: ReferenceData;

    @Field({nullable: true})
    decn_prov_cmnct_dttm?: Date;

    @Field(type => Int, {nullable: true})
    decn_prov_cmnct_to_role_ref_id?: number;

    @Field({ nullable: true })
    decn_prov_cmnct_to_role_ref_cd?: ReferenceData;

    @Field({nullable: true})
    decn_rndr_dttm?: string;

    @Field(type => GraphQLJSON, {nullable: true})
    decn_src_desc?: any;

    @Field(type => Int, {nullable: true})
    decn_ur_jurdc_ref_id?: number;

    @Field({ nullable: true })
    decn_ur_jurdc_ref_cd?: ReferenceData;

    @Field(type => Int, {nullable: true})
    gap_rev_otcome_ref_id?: number;

    @Field({ nullable: true })
    gap_rev_otcome_ref_cd?: ReferenceData;

    @Field(type => GraphQLJSON, {nullable: true})
    ltr_atr_list?: any;

    @Field(type => GraphQLJSON, {nullable: true})
    mbr_cov_dtl?: any;

    @Field(type => Float ,{nullable: true})
    negot_rt?: number;

    @Field(type => Int, {nullable: true})
    negot_rt_typ_ref_id?: number;

    @Field({ nullable: true })
    negot_rt_typ_ref_cd?: ReferenceData;

    @Field(type => Int, {nullable: true})
    ovrd_clm_rmrk_ref_id?: number;

    @Field({ nullable: true })
    ovrd_clm_rmrk_ref_cd?: ReferenceData;

    @Field(type => Int, {nullable: true})
    ovrd_rsn_ref_id?: number;

    @Field({ nullable: true })
    ovrd_rsn_ref_cd?: ReferenceData;

    @Field({nullable: true})
    ovrd_rsn_txt?: string;

    @Field({nullable: true})
    peer_to_peer_rev_dt?: Date;

    @Field({nullable: true})
    sched_nxt_rev_dt?: Date;

    @Field(type => Int, {nullable: true})
    site_of_care_pref_ref_id?: number;

    @Field({ nullable: true })
    site_of_care_pref_ref_cd?: ReferenceData;

    @Field(type => Int, {nullable: true})
    sys_clm_rmrk_ref_id?: number;

    @Field({ nullable: true })
    sys_clm_rmrk_ref_cd?: ReferenceData;

    @Field({nullable: true})
    wrt_decn_cmnct_dttm?: Date;

    @Field(type => [HscDecnBedDay], {nullable: true})
    hsc_decn_bed_days?: HscDecnBedDay[];

    @Field(type => Int, {nullable: true})
    inac_ind?: number;

    @Field(type => Int, {nullable: true})
    hsc_decn_id?: number;

    @Field(type => Int, {nullable: true})
    hsc_srvc_id?: number;

    @Field({nullable: true})
    chg_dttm?: string
}
