import {Field, InputType, Int} from "@nestjs/graphql";

@InputType()
export class HscDecnBedDayInput {
    @Field({nullable: true})
    rvnu_cd?: string;

    @Field(type => Int,{nullable: true})
    bed_typ_ref_id?: number;

    @Field(type => Int, {nullable: true})
    accum_bed_day_cnt?: number;

    @Field({nullable: true})
    decn_facl_cmnct_dttm?: Date;

    @Field({nullable: true})
    decn_rndr_dttm_facl_lcl_txt?: string;

    @Field(type => Int, {nullable: true})
    questnr_rspn_id?: number;

    @Field({nullable: true},)
    strt_bed_dt?: Date;

    @Field(type => Int,{nullable: true},)
    hsc_clin_guid_id?:number;
}
