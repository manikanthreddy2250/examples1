import {Field, Int, ObjectType} from "@nestjs/graphql";
import { ReferenceData } from "./referenceData";

@ObjectType()
export class HscDecnBedDay {
    @Field(type => Int, {nullable: true})
    hsc_decn_id?: number;

    @Field({nullable: true})
    rvnu_cd?: string;

    @Field(type => Int, {nullable: true})
    bed_typ_ref_id?: number;

    @Field({ nullable: true })
    bed_typ_ref_cd?: ReferenceData;

    @Field(type => Int, {nullable: true})
    accum_bed_day_cnt?: number;

    @Field({nullable: true})
    decn_facl_cmnct_dttm?: Date;

    @Field({nullable: true})
    decn_rndr_dttm_facl_lcl_txt?: string;

    @Field({nullable: true})
    strt_bed_dt?: string;

    @Field(type => Int,{nullable: true})
    hsc_clin_guid_id?: number;
}
