import {Field, InputType, Int} from "@nestjs/graphql";
import {HscEntityActionType} from "./HscEntityActionType";

@InputType()
export class HscDiagnosisInput {
    @Field(type => Int, {nullable: true})
    hsc_diag_id?: number;
    @Field({nullable: true})
    diag_cd?: string;
    @Field(type => Int, {nullable: true})
    pri_ind?: number;
    @Field({nullable: true})
    diag_othr_txt?: string;
    @Field(type => Int, {nullable: true})
    diag_cd_schm_ref_id?: number;
    @Field(type => Int, {nullable: true})
    admit_ind?: number;
    @Field(type => Int, {nullable: true})
    inac_ind?: number;
    @Field({nullable : true})
    creat_user_id? :  string;
    @Field({nullable : true})
    chg_user_id? :  string;
    @Field({nullable: true})
    action?: HscEntityActionType;
}
