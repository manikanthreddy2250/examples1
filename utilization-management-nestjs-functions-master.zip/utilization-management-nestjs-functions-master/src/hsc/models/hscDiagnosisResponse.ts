import {Field, Int, ObjectType} from "@nestjs/graphql";
import {DiagnosisResponse} from "./diagnosisResponse";

@ObjectType()
export class HscDiagnosisResponse {
    @Field(type => [DiagnosisResponse])
    diagnosisResponse: DiagnosisResponse[];
}
