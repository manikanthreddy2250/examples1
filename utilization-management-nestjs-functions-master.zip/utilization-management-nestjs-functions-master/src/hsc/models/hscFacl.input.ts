import {Field, InputType, Int} from "@nestjs/graphql";
import {HscDecnInput} from "./hscDecn.input";

@InputType()
export class HscFaclInput {
    @Field(type => Int)
    plsrv_ref_id: number;

    @Field(type => Int)
    srvc_desc_ref_id: number;

    @Field(type => Int)
    srvc_dtl_ref_id: number;

    @Field({nullable : true})
    actul_admis_dttm?: Date;

    @Field({nullable : true})
    actul_dschrg_dttm?: Date;

    @Field({nullable : true})
    expt_admis_dt? : Date;

    @Field({nullable : true})
    expt_dschrg_dt?: Date;

    @Field({nullable : true})
    admis_ntfy_dttm?: Date;

    @Field(type => Int, {nullable : true})
    admis_ntfy_trans_id?: number;

    @Field({nullable : true})
    adv_ntfy_dttm?: Date;

    @Field(type => Int, {nullable : true})
    adv_ntfy_trans_id?: number;

    @Field(type => Int, {nullable : true})
    ctp_nom_sts_ref_id?: number;

    @Field(type => Int, {nullable : true})
    dschrg_disp_ref_id?: number;

    @Field({nullable : true})
    dschrg_ntfy_dttm?: Date;

    @Field(type => Int, {nullable : true})
    dschrg_ntfy_trans_id?: number;

    @Field(type => Int, {nullable : true})
    goal_los_day_cnt?: number;

    @Field(type => Int, {nullable : true})
    ipcm_typ_ref_id?: number;

    @Field(type => Int, {nullable : true})
    rem_snf_day_cnt?: number;

    @Field(type => Int, {nullable : true})
    snf_day_xhst_ind?: number;

    @Field({nullable : true})
    tat_due_dttm?: Date;

    @Field({nullable: true})
    hsc_decn?: HscDecnInput;

}
