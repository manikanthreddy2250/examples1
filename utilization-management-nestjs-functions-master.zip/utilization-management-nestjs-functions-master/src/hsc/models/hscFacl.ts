import { Field, ObjectType, Int, GraphQLISODateTime } from '@nestjs/graphql';
import { ReferenceData } from './referenceData';
import GraphQLJSON from 'graphql-type-json';
import { HscDecn } from './hscDecn';

@ObjectType()
export class HscFacl {
  @Field({ nullable: true })// TODO - temporary fix as date type is not returning
  actul_admis_dttm?: string;

  @Field({ nullable: true })// TODO - temporary fix as date type is not returning
  actul_dschrg_dttm?: string;

  @Field({ nullable: true })// TODO - temporary fix as date type is not returning
  expt_admis_dt?: string;

  @Field({ nullable: true })// TODO - temporary fix as date type is not returning
  expt_dschrg_dt?: string;

  @Field((type) => Int, { nullable: true })
  plsrv_ref_id?: number;

  @Field({ nullable: true })
  plsrv_ref_cd?: ReferenceData;

  @Field((type) => Int, { nullable: true })
  srvc_desc_ref_id?: number;

  @Field({ nullable: true })
  srvc_desc_ref_cd?: ReferenceData;

  @Field((type) => Int, { nullable: true })
  srvc_dtl_ref_id?: number;

  @Field({ nullable: true })
  srvc_dtl_ref_cd?: ReferenceData;
  
  @Field(type => GraphQLJSON, {nullable: true})
  data_secur_rule_list?:any;

  @Field(type => GraphQLJSON, {nullable: true})
    data_qlty_iss_list?:any;

   @Field(type => GraphQLJSON, {nullable: true})
    tat_rqr_crit_list?:any;

    @Field({nullable : true})
    admis_ntfy_dttm?: Date;

    @Field(type => Int, {nullable : true})
    admis_ntfy_trans_id?: number;

    @Field({nullable : true})
    adv_ntfy_dttm?: Date;

    @Field(type => Int, {nullable : true})
    adv_ntfy_trans_id?: number;

    @Field(type => Int, {nullable : true})
    ctp_nom_sts_ref_id?: number;

    @Field({ nullable: true })
    ctp_nom_sts_ref_cd?: ReferenceData;

    @Field(type => Int, {nullable : true})
    dschrg_disp_ref_id?: number;

    @Field({ nullable: true })
    dschrg_disp_ref_cd?: ReferenceData;

    @Field({nullable : true})
    dschrg_ntfy_dttm?: Date;

    @Field(type => Int, {nullable : true})
    dschrg_ntfy_trans_id?: number;

    @Field(type => Int, {nullable : true})
    goal_los_day_cnt?: number;

    @Field(type => Int, {nullable : true})
    ipcm_typ_ref_id?: number;
    
    @Field({ nullable: true })
    ipcm_typ_ref_cd?: ReferenceData;

    @Field(type => Int, {nullable : true})
    rem_snf_day_cnt?: number;

    @Field(type => Int, {nullable : true})
    snf_day_xhst_ind?: number;

    @Field({nullable : true})
    tat_due_dttm?: Date;
}
