import {Field, ObjectType, Int, InputType} from "@nestjs/graphql";

@InputType()
export class HscKeyInput {
    @Field({nullable : true})
    creat_user_id? :  string;

    @Field({nullable : true})
    chg_user_id? :  string;

    @Field()
    hsc_key_val : string;

    @Field(type => Int)
    hsc_key_typ_ref_id : number;

    @Field(type => Int, {nullable: true})
    inac_ind? : number;


}
