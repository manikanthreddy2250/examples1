import {Field, ObjectType, Int} from "@nestjs/graphql";
import { ReferenceData } from "./referenceData";

@ObjectType()
export class HscKey {
    @Field(type => Int)
    hsc_id : number;

    @Field({ nullable: true })
    hsc_key_val? : string;

    @Field(type => Int, { nullable: true })
    inac_ind? : number;

    @Field(type => Int, { nullable: true })
    hsc_key_typ_ref_id? : number;

    @Field({ nullable: true })
    hsc_key_typ_ref_cd?: ReferenceData;

    @Field({nullable : true})
    creat_user_id? :  string;

    @Field({nullable : true})
    chg_user_id? :  string;


}
