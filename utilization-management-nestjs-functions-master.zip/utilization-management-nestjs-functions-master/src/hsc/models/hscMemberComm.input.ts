import {Field, InputType, Int} from "@nestjs/graphql";
import GraphQLJSON from "graphql-type-json";
import {MbrCmnctPrtcpInput} from "./mbrCmnctPrtcp.input";
import {BaseInputRequest} from "./baseInputRequest";

@InputType()
export class HscMemberCommInput extends BaseInputRequest {

    @Field(type => Int, {nullable: true})
    mbr_cmnct_id?: number;

    @Field(type => Int, {nullable: true})
    mbr_cmnct_catgy_ref_id?: number;

    @Field(type => Int, {nullable: true})
    mbr_cmnct_chnl_ref_id?: number;

    @Field(type => Int, {nullable: true})
    mbr_cmnct_dir_ref_id?: number;

    @Field(type => Int, {nullable: true})
    mbr_cmnct_prr_ref_id?: number;

    @Field(type => Int, {nullable: true})
    mbr_cmnct_rsn_ref_id: number;

    @Field(type => Int, {nullable: true})
    mbr_cmnct_typ_ref_id: number;

    @Field(type => Int, {nullable: true})
    mbr_cmnct_sts_ref_id: number;

    @Field(type => Int, {nullable: true})
    mbr_cmnct_sts_rsn_ref_id: number;

    @Field({nullable: true})
    sts_dttm?: Date;

    @Field({nullable: true})
    commt_txt?: string;

    @Field(type => GraphQLJSON, {nullable: true})
    cmnct_adr_dtl?: any;

    @Field(type => GraphQLJSON, {nullable: true})
    dsclmr_cnsnt_desc?: any;

    @Field(type => [MbrCmnctPrtcpInput], {nullable: true})
    mbr_cmnct_prtcps?: MbrCmnctPrtcpInput[];
}