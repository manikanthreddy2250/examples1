import {InputType, Field, Int} from "@nestjs/graphql";
import {HscEntityActionType} from "./HscEntityActionType";
import {HscDecnBedDayInput} from "./hscDecnBedDay.input";
import {HsrNoteSbjInput} from "./HsrNoteSbj.input";

@InputType()
export class HsrNotesInput {
    @Field(type => Int, {nullable: true})
    hsr_note_id?: number;

    @Field({nullable : true})
    note_txt_lobj?: string;

    @Field({nullable : true})
    note_titl_txt?: string;

    @Field({nullable : true})
    src_user_nm?: string;

    @Field(type => Int, {nullable : true})
    note_typ_ref_id?: number;

    @Field(type => Int, {nullable : true})
    note_catgy_ref_id?: number;

    @Field({nullable : true})
    creat_dttm? : Date;

    @Field({nullable : true})
    creat_user_id? :  string;

    @Field({nullable : true})
    chg_user_id? :  string;

    @Field({nullable: true})
    action?: HscEntityActionType;

    @Field(type => Int, {nullable : true})
    note_sts_ref_id?: number;

    @Field(type => [HsrNoteSbjInput], {nullable: true})
    hsr_note_sbjs?: HsrNoteSbjInput[];
}
