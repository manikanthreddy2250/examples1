import { Field, ObjectType, Int, GraphQLISODateTime } from '@nestjs/graphql';
import { ReferenceData } from './referenceData';

@ObjectType()
export class HsrNote {
  @Field((type) => Int)
  hsr_note_id: number;

  @Field({ nullable: true })
  note_titl_txt?: string;

  @Field({ nullable: true })
  note_txt_lobj?: string;

  @Field({ nullable: true })
  creat_user_id?: string;

  @Field((type) => Int)
  note_typ_ref_id?: number;
  
  @Field({ nullable: true })
  note_typ_ref_cd?: ReferenceData;

  @Field({ nullable: true })
  src_user_nm?: string;

  @Field({ nullable: true })// TODO - temporary fix as date type is not returning
  creat_dttm?: string;

  @Field(type => Int, {nullable : true})
  note_catgy_ref_id?: number;

  @Field({ nullable: true })
  note_catgy_ref_cd?: ReferenceData;
}
