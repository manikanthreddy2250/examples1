import {InputType, Field, Int} from "@nestjs/graphql";
import {HscProvRoleInput} from "./hscProvRole.input";
import {ProvKeyInput} from "./provKey.input";
import {ProvAdrInput} from "./provAdr.input";
import GraphQLJSON from "graphql-type-json";
import {HscEntityActionType} from "./HscEntityActionType";

@InputType()
export class HscProvInput {
    @Field({nullable : true})
    creat_user_id? :  string;

    @Field({nullable : true})
    chg_user_id? :  string;

    @Field(type => Int, {nullable: true})
    id?: number;

    @Field(type => Int, {nullable: true})
    hsc_prov_id?: number;

    @Field(type => Int, {nullable: true})
    delete_ind?: number;

    @Field({nullable: true})
    fst_nm?: string;

    @Field({nullable: true})
    midl_nm?: string;

    @Field({nullable: true})
    lst_nm?: string;

    @Field({nullable: true})
    bus_nm?: string;

    @Field(type => [ProvKeyInput])
    prov_keys : ProvKeyInput[];

    @Field(type => [HscProvRoleInput], {nullable: true})
    hsc_prov_roles? : HscProvRoleInput[];

    @Field({nullable : true})
    strt_dt?: Date;

    @Field({nullable : true})
    end_dt?: Date;

    @Field()
    prov_adr: ProvAdrInput;

    @Field(type => GraphQLJSON, {nullable: true})
    prov_loc_affil_dtl?: any;

    @Field({nullable: true})
    action?: HscEntityActionType;



}
