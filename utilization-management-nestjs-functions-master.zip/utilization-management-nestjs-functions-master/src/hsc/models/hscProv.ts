import { Field, ObjectType, Int } from '@nestjs/graphql';
import GraphQLJSON from 'graphql-type-json';
import { HscProvRole } from './hscProvRole';
import { ReferenceData } from './referenceData';

@ObjectType()
export class HscProv {
  @Field((type) => Int, { nullable: true })
  auto_aprv_ltr_ind?: number;

  @Field((type) => Int, { nullable: true })
  hsc_prov_id?: number;

  @Field((type) => Int, { nullable: true })
  chg_sys_ref_id?: number;

  @Field({ nullable: true })
  chg_user_id?: string;

  @Field((type) => Int, { nullable: true })
  creat_sys_ref_id?: number;

  @Field({ nullable: true })
  creat_user_id?: string;

  @Field((type) => GraphQLJSON, { nullable: true })
  data_qlty_iss_list?: any;

  @Field((type) => GraphQLJSON, { nullable: true })
  data_secur_rule_list?: any;

  @Field({ nullable: true })// TODO - temporary fix as date type is not returning
  end_dt?: string;

  @Field((type) => Int, { nullable: true })
  hsc_prov_end_rsn_ref_id?: number;

  @Field({ nullable: true })
  hsc_prov_end_rsn_ref_cd?: ReferenceData;

  @Field((type) => Int, { nullable: true })
  ltr_opt_out_cc_ind?: number;

  @Field({ nullable: true })
  med_rec_nbr?: string;

  @Field((type) => Int, { nullable: true })
  ntwk_strg_rsn_ref_id?: number;
  
  @Field({ nullable: true })
  ntwk_strg_rsn_ref_cd?: ReferenceData;

  @Field((type) => Int, { nullable: true })
  ntwk_sts_ref_id?: number;

  @Field({ nullable: true })
  ntwk_sts_ref_cd?: ReferenceData;

  @Field((type) => GraphQLJSON, { nullable: true })
  prov_loc_affil_dtl?: any;

  @Field((type) => Int, { nullable: true })
  prov_loc_affil_id?: number;

  @Field((type) => Int, { nullable: true })
  spcl_ref_id?: number;

  @Field({ nullable: true })// TODO - temporary fix as date type is not returning
  strt_dt?: string;

  @Field({ nullable: true })
  telcom_adr_id?: string;

  @Field((type) => Int, { nullable: true })
  updt_ver_nbr?: number;

  @Field((type) => [HscProvRole], { nullable: true })
  hsc_prov_roles?: HscProvRole[];

  @Field((type) => Int, { nullable: true })
  prov_key_typ_ref_id?: number;

  @Field({ nullable: true })
  prov_key_typ_ref_cd?: ReferenceData;

  @Field({ nullable: true })
  prov_key_val?: string;

  @Field({ nullable: true })
  spcl_ref_cd?: ReferenceData;
}
