import {InputType, Field, Int} from "@nestjs/graphql";

@InputType()
export class HscProvRoleInput {
    @Field(type => Int)
    prov_role_ref_id : number;
}
