import {Field, ObjectType, Int} from "@nestjs/graphql";
import { ReferenceData } from './referenceData';

@ObjectType()
export class HscProvRole {
  @Field(type => Int, { nullable: true })
  hsc_prov_id? : number;

  @Field(type => Int, { nullable: true })
  prov_role_ref_id? : number;

  @Field({ nullable: true })
  prov_role_ref_cd?: ReferenceData;
}
