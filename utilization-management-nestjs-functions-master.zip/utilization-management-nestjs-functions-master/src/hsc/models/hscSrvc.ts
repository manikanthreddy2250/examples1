import { Field, ObjectType, Int } from '@nestjs/graphql';
import { HscSrvcNonFacl } from './hscSrvcNonFacl';
import { HscDecn } from './hscDecn';
import { HscProv } from './hscProv';
import { ReferenceData } from './referenceData';
import {HscEntityActionType} from './HscEntityActionType';

@ObjectType()
export class HscSrvc {
  @Field({ nullable: true })
  creat_dttm?: string;

  @Field({ nullable: true })
  chg_dttm?: string;

  @Field((type) => Int, { nullable: true })
  hsc_id?: number;

  @Field((type) => Int, { nullable: true })
  hsc_srvc_id?: number;

  @Field(type => Int, { nullable: true })
  inac_ind? : number;

  @Field({ nullable: true })
  proc_cd?: string;

  @Field((type) => Int, { nullable: true })
  proc_cd_schm_ref_id?: number;
  
  @Field({ nullable: true })
  proc_cd_schm_ref_cd?: ReferenceData;

  @Field({ nullable: true })
  proc_othr_txt?: string;

  @Field((type) => Int, { nullable: true })
  srvc_hsc_prov_id?: number;

  @Field((type) => [HscSrvcNonFacl], { nullable: true })
  hsc_srvc_non_facls?: HscSrvcNonFacl[];

  @Field({nullable : true})
  chg_user_id? :  string;

  @Field(type => Int, {nullable : true})
  expmt_proc_ind?: number;

  @Field(type => Int, {nullable : true})
  hsc_srvc_rev_typ_ref_id?: number;

  @Field({ nullable: true })
  hsc_srvc_rev_typ_ref_cd?: ReferenceData;

  @Field(type => Int, {nullable : true})
  adv_ntfy_trans_id?: number;

  @Field(type => Int, {nullable : true})
  ben_chk_sts_ref_id?: number;

  @Field({ nullable: true })
  ben_chk_sts_ref_cd?: ReferenceData;

  @Field({nullable : true})
  adv_ntfy_dttm?: Date;

  @Field({nullable : true})
  expt_proc_dt?: string;

  @Field({nullable: true})
  action?: HscEntityActionType;


}
