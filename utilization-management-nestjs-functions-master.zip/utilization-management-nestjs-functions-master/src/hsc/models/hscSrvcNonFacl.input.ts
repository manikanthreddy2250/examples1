import {InputType, Field, Int} from "@nestjs/graphql";
import {HscSrvcNonFaclDmeInput} from "./hscSrvcNonFaclDme.input";

@InputType()
export class HscSrvcNonFaclInput {

    @Field(type => Int, {nullable: true})
    hsc_srvc_id? : number;

    @Field()
    srvc_strt_dt: Date;

    @Field()
    srvc_end_dt: Date;

    @Field({nullable: true})
    proc_mod_1_cd? : string;

    @Field({nullable: true})
    proc_mod_2_cd? : string;

    @Field({nullable: true})
    proc_mod_3_cd? : string;

    @Field({nullable: true})
    proc_mod_4_cd? : string;

    @Field(type => Int)
    proc_uom_ref_id : number;

    @Field(type => Int)
    proc_unit_cnt : number;

    @Field(type => Int)
    unit_per_freq_cnt : number;

    @Field({nullable: true})
    init_trt_dt?: Date;

    @Field(type => Int)
    plsrv_ref_id : number;

    @Field(type => Int)
    proc_freq_ref_id : number;

    @Field(type => Int)
    srvc_desc_ref_id : number;

    @Field(type => Int)
    srvc_dtl_ref_id : number;

    @Field(type => [HscSrvcNonFaclDmeInput],{nullable: true})
    hsc_srvc_non_facl_dmes?: HscSrvcNonFaclDmeInput[];
}
