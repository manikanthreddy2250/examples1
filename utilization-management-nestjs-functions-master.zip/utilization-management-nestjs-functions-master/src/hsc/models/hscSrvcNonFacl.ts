import { Field, ObjectType, Int } from '@nestjs/graphql';
import { ReferenceData } from './referenceData';
import { HscSrvcNonFaclDme } from './hscSrvcNonFaclDme';

@ObjectType()
export class HscSrvcNonFacl {
  @Field({ nullable: true })// TODO - temporary fix as date type is not returning
  init_trt_dt?: string;

  @Field((type) => Int, { nullable: true })
  plsrv_ref_id?: number;

  @Field({ nullable: true })
  plsrv_ref_cd?: ReferenceData;

  @Field((type) => Int, { nullable: true })
  proc_freq_ref_id?: number;

  @Field({ nullable: true })
  proc_freq_ref_cd?: ReferenceData;

  @Field({ nullable: true })
  proc_mod_1_cd?: string;

  @Field({ nullable: true })
  proc_mod_2_cd?: string;

  @Field({ nullable: true })
  proc_mod_3_cd?: string;

  @Field({ nullable: true })
  proc_mod_4_cd?: string;

  @Field((type) => Int, { nullable: true })
  proc_unit_cnt?: number;

  @Field((type) => Int, { nullable: true })
  proc_uom_ref_id?: number;

  @Field({ nullable: true })
  proc_uom_ref_cd?: ReferenceData;

  @Field((type) => Int, { nullable: true })
  srvc_desc_ref_id?: number;

  @Field({ nullable: true })
  srvc_desc_ref_cd?: ReferenceData;

  @Field((type) => Int, { nullable: true })
  srvc_dtl_ref_id?: number;

  @Field({ nullable: true })
  srvc_dtl_ref_cd?: ReferenceData;

  @Field({ nullable: true })// TODO - temporary fix as date type is not returning
  srvc_end_dt?: string;

  @Field({ nullable: true })// TODO - temporary fix as date type is not returning
  srvc_strt_dt?: string;

  @Field((type) => Int, { nullable: true })
  unit_per_freq_cnt?: number;

  @Field((type) => [HscSrvcNonFaclDme], { nullable: true })
  hsc_srvc_non_facl_dmes?: HscSrvcNonFaclDme[];
}
