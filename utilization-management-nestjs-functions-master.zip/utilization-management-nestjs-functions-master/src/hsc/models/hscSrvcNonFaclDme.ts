import { Field, ObjectType, Int } from '@nestjs/graphql';

@ObjectType()
export class HscSrvcNonFaclDme {
  @Field({ nullable: true })
  clin_ill_desc_txt?: string;

  @Field((type) => Int, { nullable: true })
  dme_procrmnt_typ_id?: number;

  @Field((type) => Int, { nullable: true })
  dme_tot_cst_amt?: number;

  @Field((type) => Int, { nullable: true })
  ental_fd_sngl_src_nutritn_ind?: number;

  @Field({ nullable: true })
  fml_nm_txt?: string;

  @Field({ nullable: true })
  med_cond_txt?: string;

  @Field({ nullable: true })
  spl_desc_txt?: string;

  @Field({ nullable: true })
  srvc_desc_txt?: string;
}
