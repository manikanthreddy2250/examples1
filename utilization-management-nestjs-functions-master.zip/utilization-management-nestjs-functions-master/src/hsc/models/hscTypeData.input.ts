import {Field, InputType, Int} from "@nestjs/graphql";
import {MemberCovInput} from "./memberCov.input";

@InputType()
export class HSCTypeData {

    @Field(type => Int, {nullable: true})
    indv_id?: number;

    @Field(type => Int, {nullable: true})
    hsc_rev_typ_ref_id?: number;

    @Field(type => Int, {nullable: true})
    hsc_sts_ref_id?: number;

    @Field(type => Int, {nullable: true})
    hsc_sts_rsn_ref_id?: number;

    @Field(type => Int, {nullable: true})
    auth_typ_ref_id?: number;

    @Field(type => Int, {nullable: true})
    creat_sys_ref_id?: number;

    @Field(type => Int, {nullable: true})
    chg_sys_ref_id?: number;

    @Field(type => Int, {nullable: true})
    rev_prr_ref_id?: number;

}
