import {Field, InputType, Int} from "@nestjs/graphql";
import {HscMemberCommInput} from "./hscMemberComm.input";

@InputType()
export class HsrActvInput {

    @Field(type => Int, {nullable: true})
    hsr_actv_id?: number;

    @Field({nullable: true})
    creat_user_id?: string;

    @Field({nullable: true})
    chg_user_id?: string;

    @Field(type => Int, {nullable: true})
    actv_typ_ref_id?: number;

    @Field({nullable: true})
    actv_strt_dttm?: Date;

    @Field(type => Int, {nullable: true})
    dur_mn_nbr?: number;

    @Field(type => Int, {nullable: true})
    rslv_rsn_typ_id?: number;

    @Field(type => Int, {nullable: true})
    rslv_otcome_typ_id?: number;

    @Field(type => Int, {nullable: true})
    init_by_func_role_ref_id: number;

    @Field(type => Int, {nullable: true})
    cntc_role_ref_id: number;

    @Field(type => Int, {nullable: true})
    creatr_func_role_ref_id: number;

    @Field(type => Int, {nullable: true})
    actv_prtn_ref_id: number;

    @Field({nullable: true})
    cntc_user_id?: string;

    @Field({nullable: true})
    commt_txt?: string;

    @Field({nullable: true})
    extr_ref_trans_id?: string;

    @Field({nullable: true})
    mbr_cmnct?: HscMemberCommInput;

}