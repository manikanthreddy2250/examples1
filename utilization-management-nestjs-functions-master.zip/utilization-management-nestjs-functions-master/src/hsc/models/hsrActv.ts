import {Field, Int, ObjectType} from "@nestjs/graphql";
import {ReferenceData} from "./referenceData";
import {HsrActvSbj} from "./hsrActvSbj";
import {MbrCmnct} from "./mbrCmnct";

@ObjectType()
export class HsrActv {

    @Field(type => Int)
    hsr_actv_id: number;

    @Field({nullable: true})
    creat_user_id?: string;

    @Field({nullable: true})
    chg_user_id?: string;

    @Field({nullable: true})
    creat_dttm?: String;

    @Field({nullable: true})
    chg_dttm?: String;

    @Field(type => Int, {nullable: true})
    actv_typ_ref_id?: number;

    @Field({nullable: true})
    actv_typ_ref_cd?: ReferenceData;

    @Field({nullable: true})
    actv_strt_dttm?: String;

    @Field(type => Int, {nullable: true})
    dur_mn_nbr?: number;

    @Field(type => Int, {nullable: true})
    rslv_rsn_typ_id?: number;

    @Field(type => Int, {nullable: true})
    rslv_otcome_typ_id?: number;

    @Field(type => Int, {nullable: true})
    init_by_func_role_ref_id: number;

    @Field({nullable: true})
    init_by_func_role_ref_cd?: ReferenceData;

    @Field(type => Int, {nullable: true})
    cntc_role_ref_id: number;

    @Field({nullable: true})
    cntc_role_ref_cd?: ReferenceData;

    @Field(type => Int, {nullable: true})
    creatr_func_role_ref_id: number;

    @Field({nullable: true})
    creatr_func_role_ref_cd?: ReferenceData;

    @Field(type => Int, {nullable: true})
    actv_prtn_ref_id: number;

    @Field({nullable: true})
    actv_prtn_ref_cd?: ReferenceData;

    @Field({nullable: true})
    cntc_user_id?: string;

    @Field({nullable: true})
    commt_txt?: string;

    @Field({nullable: true})
    extr_ref_trans_id?: string;

    @Field(type => [HsrActvSbj], {nullable: true})
    hsr_actv_sbjs?: HsrActvSbj[];

    @Field({nullable: true})
    mbr_cmnct?: MbrCmnct;

}