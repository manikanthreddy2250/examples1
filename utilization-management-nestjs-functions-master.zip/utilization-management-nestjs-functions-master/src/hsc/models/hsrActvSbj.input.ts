import {Field, InputType, Int} from "@nestjs/graphql";

@InputType()
export class HsrActvSbjInput {
    @Field(type => Int, {nullable: true})
    hsr_sbj_rec_id?: number;

    @Field(type => Int, {nullable: true})
    hsr_sbj_typ_ref_id?: number
}