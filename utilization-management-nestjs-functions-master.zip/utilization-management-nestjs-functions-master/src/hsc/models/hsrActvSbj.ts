import {Field, Int, ObjectType} from "@nestjs/graphql";
import {ReferenceData} from "./referenceData";

@ObjectType()
export class HsrActvSbj {
    @Field(type => Int)
    hsr_actv_id: number;

    @Field(type => Int, {nullable: true})
    hsr_sbj_rec_id?: number;

    @Field(type => Int, {nullable: true})
    hsr_sbj_typ_ref_id?: number;

    @Field({nullable: true})
    hsr_sbj_typ_ref_cd?: ReferenceData;
}