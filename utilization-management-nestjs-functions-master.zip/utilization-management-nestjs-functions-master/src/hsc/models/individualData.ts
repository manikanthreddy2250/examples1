import { Field, ObjectType, Int } from "@nestjs/graphql";
import { ReferenceData } from './referenceData';

@ObjectType()
export class IndividualData {
    @Field(type => Int, {nullable: true})
    indv_id? : number;

    @Field({nullable: true})
    fst_nm? : string;

    @Field({nullable: true})
    lst_nm? : string;

    @Field({nullable: true})
    bth_dt? : string;

    @Field({nullable: true})
    gdr_ref_cd? : ReferenceData;
}
