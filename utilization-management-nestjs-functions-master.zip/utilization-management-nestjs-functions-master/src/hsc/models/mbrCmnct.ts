import {Field, Int, ObjectType} from "@nestjs/graphql";
import GraphQLJSON from "graphql-type-json";
import {MbrCmnctPrtcp} from "./mbrCmnctPrtcp";

@ObjectType()
export class MbrCmnct {

    @Field(type => Int)
    mbr_cmnct_id?: number;

    @Field({nullable: true})
    creat_user_id?: string;

    @Field({nullable: true})
    chg_user_id?: string;

    @Field({nullable: true})
    creat_dttm?: String;

    @Field({nullable: true})
    chg_dttm?: String;

    @Field(type => Int, {nullable: true})
    mbr_cmnct_catgy_ref_id?: number;

    @Field(type => Int, {nullable: true})
    mbr_cmnct_chnl_ref_id?: number;

    @Field(type => Int, {nullable: true})
    mbr_cmnct_dir_ref_id?: number;

    @Field(type => Int, {nullable: true})
    mbr_cmnct_prr_ref_id?: number;

    @Field(type => Int, {nullable: true})
    mbr_cmnct_rsn_ref_id: number;

    @Field(type => Int, {nullable: true})
    mbr_cmnct_typ_ref_id: number;

    @Field(type => Int, {nullable: true})
    mbr_cmnct_sts_ref_id: number;

    @Field(type => Int, {nullable: true})
    mbr_cmnct_sts_rsn_ref_id: number;

    @Field({nullable: true})
    sts_dttm?: Date;

    @Field({nullable: true})
    commt_txt?: string;

    @Field(type => GraphQLJSON, {nullable: true})
    cmnct_adr_dtl?: any;

    @Field(type => GraphQLJSON, {nullable: true})
    dsclmr_cnsnt_desc?: any;

    @Field(type => [MbrCmnctPrtcp], {nullable: true})
    mbr_cmnct_prtcps?: MbrCmnctPrtcp[];

}