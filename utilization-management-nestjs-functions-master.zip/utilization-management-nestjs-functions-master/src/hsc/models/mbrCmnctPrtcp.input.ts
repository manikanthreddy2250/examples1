import {Field, InputType, Int} from "@nestjs/graphql";
import GraphQLJSON from "graphql-type-json";

@InputType()
export class MbrCmnctPrtcpInput {

    @Field({nullable: true})
    fst_nm?: string;

    @Field({nullable: true})
    lst_nm?: string;

    @Field(type => Int, {nullable: true})
    mbr_cmnct_prtcp_engage_lvl_ref_id?: number;

    @Field(type => Int, {nullable: true})
    mbr_cmnct_prtcp_role_ref_id?: number;

    @Field(type => Int, {nullable: true})
    prtcp_key_typ_ref_id?: number;

    @Field({nullable: true})
    prtcp_key_val: string;

    @Field(type => GraphQLJSON, {nullable: true})
    prtcp_desc?: any;

}
