import {Field, InputType, Int} from "@nestjs/graphql";

@InputType()
export class MemberCovInput {

    @Field()
    fst_nm: string;

    @Field()
    lst_nm: string;

    @Field({nullable: true})
    midl_nm?: string;

    @Field({nullable: true})
    sufx_nm?: string;

    @Field()
    bth_dt: Date;

    @Field(type => Int)
    gdr_ref_id: number;

    @Field()
    orig_sys_cd: string;

    @Field()
    src_mbr_id: string;

    @Field()
    src_mbr_partn_id: string;

    @Field()
    cov_eff_dt: Date;

    @Field()
    cov_end_dt: Date;

    @Field()
    pol_nbr: string;

    @Field(type => Int)
    cov_typ_ref_id: number;

    @Field(type => Int)
    clm_pltfm_ref_id: number;

    @Field({nullable: true})
    sbscr_lst_nm?: string;

    @Field({nullable: true})
    sbscr_fst_nm?: string;

    @Field(type => Int, {nullable: true})
    elig_sys_ref_id?: string;
}
