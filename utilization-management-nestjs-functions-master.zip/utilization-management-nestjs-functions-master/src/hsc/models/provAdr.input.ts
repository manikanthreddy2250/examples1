import {InputType, Field, Int} from "@nestjs/graphql";

@InputType()
export class ProvAdrInput {
    @Field()
    adr_ln_1_txt : string;

    @Field({nullable: true})
    adr_ln_2_txt?: string;

    @Field()
    zip_cd_txt : string;

    @Field()
    cty_nm : string;

    @Field(type => Int)
    st_ref_id : number;
}
