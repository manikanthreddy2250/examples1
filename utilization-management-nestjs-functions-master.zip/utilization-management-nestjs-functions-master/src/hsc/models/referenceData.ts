import {Field, ObjectType, Int} from "@nestjs/graphql";

@ObjectType()
export class ReferenceData {
    @Field(type => Int, { nullable: true })
    ref_id : number;

    @Field({ nullable: true })
    ref_cd : string;

    @Field({ nullable: true })
    ref_desc : string;

    @Field({ nullable: true })
    ref_dspl : string;

}
