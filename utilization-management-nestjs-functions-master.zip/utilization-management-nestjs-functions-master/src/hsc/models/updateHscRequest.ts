import {Field, Int, InputType} from "@nestjs/graphql";
import {HscProvInput} from "./hscProv.input";
import {HscSrvcInput} from "./hscSrvc.input";
import {HscFaclInput} from "./hscFacl.input";
import {HscDiagnosisInput} from "./hscDiagnosisInput";
import {MemberCovInput} from "./memberCov.input";
import {HscKeyInput} from "./hscKey.input";
import {HsrNotesInput} from "./hscNote.input";
import {ContactDetailsInput} from "./contactDetailsInput";
import {HSCTypeData} from "./hscTypeData.input";
import {HscDecnInput} from "./hscDecn.input";
import {HscClinGuidInput} from "./hscClinGuid.input";

@InputType()
export class UpdateHscRequest {

    @Field(type => Int)
    hsc_id: number;

    @Field({nullable:true})
    creat_user_id?: string;

    @Field({nullable:true})
    chg_user_id?: string;

    @Field(type => Int,{nullable: true})
    indv_key_typ_ref_id?: number;

    @Field({nullable: true})
    indv_key_val?: string;

    @Field({nullable: true})
    mbr_cov?: MemberCovInput;

    @Field(type => Int, {nullable: true})
    srvc_set_ref_id?: number;

    @Field(type => HSCTypeData, {nullable: true} )
    hsc?: HSCTypeData;

    @Field(type => [HsrNotesInput], {nullable: true})
    hsr_notes?: HsrNotesInput[];

    @Field(type => [HscDiagnosisInput], {nullable: true})
    hsc_diags?: HscDiagnosisInput[];

    @Field(type => [ContactDetailsInput],{nullable: true})
    flwup_cntc_dtl?: ContactDetailsInput[];

    @Field(type => [HscProvInput], {nullable: true})
    hsc_provs?: HscProvInput[];

    @Field({nullable: true})
    hsc_facl?: HscFaclInput;

    @Field(type => [HscSrvcInput], {nullable: true})
    hsc_srvcs?: HscSrvcInput[];

    @Field(type => [HscKeyInput], {nullable: true})
    hsc_keys?: HscKeyInput[];

    @Field({nullable: true})
    hsc_decn?: HscDecnInput;

    @Field({nullable: true})
    hsc_clin_guid?: HscClinGuidInput;

}
