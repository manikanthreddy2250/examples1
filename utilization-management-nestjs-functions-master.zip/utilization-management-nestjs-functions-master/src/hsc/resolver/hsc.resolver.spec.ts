import { Test, TestingModule } from '@nestjs/testing';
import { HscResolver } from './hsc.resolver';
import {GetHscAuthRequest} from "../models/getHscAuthRequest";
import {GetHscAuthService} from "../service/getHscAuth/getHscAuth.service";
import {Injectable, Logger} from "@nestjs/common";
import {GetHscAuthResponse} from "../models/getHscAuthResponse";
import {of} from "rxjs";
import {HscService} from "../service/createHsc/hsc.service";
import {ProviderService} from "../service/provider.service";
import { GetMemberHscHistoryRequest } from '../models/getMemberHscHistoryRequest';
import { HscHistoryResponse } from '../models/getHscHistoryResponse';
import {CreateHscRequestInput} from "../models/createHscRequest.input";
import {CreateHscResponse} from "../models/createHscResponse";
import {UpdateHscRequest} from "../models/updateHscRequest";
import {UpdateHscService} from "../service/updateHsc/updateHsc.service";
import {DuplicateCheckRequestInput} from "../models/duplicateCheckRequest.input";
import {HttpRequest} from "@azure/functions";
import {DuplicateCheckResponse} from "../models/duplicateCheckResponse";
import { GetUserHscHistoryRequest } from '../models/getUserHscHistoryRequest';
import {DuplicateCheckService} from "../service/duplicate-check/duplicate-check.service";
import {ConfigService} from "@nestjs/config";
import {HscHistoryService} from "../service/hscHistory/hscHistory.service";
import {GetProviderHscHistoryRequest} from "../models/getProviderHscHistoryRequest";
import {HscInput} from "../models/hsc.input";
import {CaseTypeDetailsResponse} from "../models/caseTypeDetailsResponse";
import {HealthServiceClient} from '../../shared/graphql/healthservicedomain/healthServiceClient';
import {GraphQLClient} from 'graphql-request/dist';
import {RequestDocument} from 'graphql-request/dist/types';
import { HscActivityService } from '../service/activity-service/hsc.activity.service';
import { MemberCommunicationClient } from '../../shared/graphql/communication-domain/memberCommunicationClient';
import { ActivityRequest } from '../models/activityRequest';
import { LoggerModule } from 'nestjs-pino';

@Injectable()
class MockUpdateHscService{
    updateHscDetails(updateHscRequest: UpdateHscRequest, httpRequest: HttpRequest): Promise<GetHscAuthResponse> {
        const sampleRes: any  = {
                "hsc": [
                    {
                        "hsc_id": 13611,
                        "creat_dttm": new Date(),
                        "creat_user_id": "001456440",
                        "indv_id": 503926748,
                        "indv_key_typ_ref_id": 2757,
                        "indv_key_val": "16440436900",
                        "mbr_cov_dtl": {
                            "indv_id": 503926748,
                            "pol_nbr": "0128855",
                            "cov_eff_dt": "2013-01-01",
                            "cov_end_dt": "9999-12-31",
                            "mbr_cov_id": 96963692,
                            "productCode": 214,
                            "indv_key_val": "16440436900",
                            "productCatgyTpe": null,
                            "coverageTypeDesc": "Medical",
                            "indv_key_typ_ref_id": 2757,
                            "claim_platform_ref_Id": 363
                        },
                        "hsc_sts_ref_id": 19275,
                        "flwup_cntc_dtl": null,
                        "rev_prr_ref_id": 3755,
                        "rev_prr_ref_cd": {
                            "ref_id": 3755,
                            "ref_cd": "2",
                            "ref_desc": "Urgent",
                            "ref_dspl": "Urgent"
                        },
                        "srvc_set_ref_id": 3737,
                        "srvc_set_ref_cd": {
                            "ref_id": 3737,
                            "ref_cd": "1",
                            "ref_desc": "Inpatient",
                            "ref_dspl": "Inpatient"
                        },
                        "hsc_keys": [
                            {
                                "hsc_id": 13237,
                                "hsc_key_val": "ff46448e-7515-11eb-908f-1ef9496236e0",
                                "inac_ind": 0,
                                "hsc_key_typ_ref_id": 19517
                            }
                        ],
                        "hsc_srvcs": [],
                        "hsc_srvc_facls": [
                            {
                                "actul_admis_dttm": null,
                                "actul_dschrg_dttm": null,
                                "expt_admis_dt": new Date("2021-04-01"),
                                "expt_dschrg_dt": new Date("2021-04-20"),
                                "plsrv_ref_id": 3743,
                                "plsrv_ref_cd": {
                                    "ref_id": 3743,
                                    "ref_cd": "21",
                                    "ref_desc": "Acute Hospital",
                                    "ref_dspl": "Acute Hospital"
                                },
                                "srvc_desc_ref_id": 4349,
                                "srvc_desc_ref_cd": {
                                    "ref_id": 4349,
                                    "ref_cd": "3",
                                    "ref_desc": "Emergent",
                                    "ref_dspl": "Emergent"
                                },
                                "srvc_dtl_ref_id": 4296,
                                "srvc_dtl_ref_cd": {
                                    "ref_id": 4296,
                                    "ref_cd": "1",
                                    "ref_desc": "Medical",
                                    "ref_dspl": "Medical"
                                }
                            }
                        ],
                        "hsc_diags": [],
                        "hsr_notes": [],
                        "hsc_provs": [
                            {
                                "auto_aprv_ltr_ind": null,
                                "chg_sys_ref_id": null,
                                "chg_user_id": "001456440",
                                "creat_sys_ref_id": null,
                                "creat_user_id": "001456440",
                                "data_qlty_iss_list": null,
                                "data_secur_rule_list": null,
                                "end_dt": null,
                                "hsc_prov_end_rsn_ref_id": null,
                                "ltr_opt_out_cc_ind": null,
                                "med_rec_nbr": null,
                                "ntwk_strg_rsn_ref_id": null,
                                "ntwk_sts_ref_id": null,
                                "prov_loc_affil_dtl": {
                                    "providerDetails": {
                                        "prov_id": 9748974,
                                        "prov_key": [
                                            {
                                                "prov_key_val": "1699734293",
                                                "prov_key_typ_ref_id": 2782
                                            },
                                            {
                                                "prov_key_val": null,
                                                "prov_key_typ_ref_id": 16333
                                            },
                                            {
                                                "prov_key_val": "1699734293",
                                                "prov_key_typ_ref_id": 2783
                                            }
                                        ],
                                        "prov_adr_id": 109644999,
                                        "prov_cat_typ_ref_id": 16309
                                    }
                                },
                                "prov_loc_affil_id": null,
                                "spcl_ref_id": 16646,
                                "strt_dt": null,
                                "telcom_adr_id": "4102258991",
                                "updt_ver_nbr": 0,
                                "hsc_prov_roles": [
                                    {
                                        "hsc_prov_id": 4548,
                                        "prov_role_ref_id": 3758
                                    }
                                ]
                            }
                        ],
                        "hsr_doc_procs": []
                    }
                ]
                }
            ;
        return of(sampleRes).toPromise();
    }
}

@Injectable()
class MockProviderService{
    getProvData(provKeyVal, provKeyTypeRefId, context: any): Promise<any> {
        const sampleRes  ={
            "data": {
            "mbrshp": [
                {
                    "mbr_covs": [
                        {
                            "mbr_cov_id": 90881959,
                            "cov_end_dt": "9999-12-31",
                            "cov_eff_dt": "2020-02-01",
                            "pol_nbr": "0752023",
                            "prdct_typ_ref_cd": {
                                "ref_desc": "POS"
                            },
                            "clm_pltfm_ref_id": 363,
                            "prdct_catgy_ref_cd": null,
                            "prdct_catgy_ref_id": null,
                            "cov_typ_ref_id": 182,
                            "cov_typ_ref_cd": {
                                "ref_desc": "Medical"
                            }
                        }]}]}};
        return of(sampleRes).toPromise();
    }
}

@Injectable()
class MockGetHscAuthService {

hscAuthDetails(getHscAuthRequest: GetHscAuthRequest, httpRequest: HttpRequest): Promise<GetHscAuthResponse> {
        const sampleRes: any  = {hsc:[{
                "hsc_id": 13237,
                "creat_dttm": new Date(),
                "creat_user_id": "001456440",
                "indv_id": 503926748,
                "indv_key_typ_ref_id": 2757,
                "indv_key_val": "16440436900",
                "mbr_cov_dtl": {
                    "indv_id": 503926748,
                    "pol_nbr": "0128855",
                    "cov_eff_dt": "2013-01-01",
                    "cov_end_dt": "9999-12-31",
                    "mbr_cov_id": 96963692,
                    "productCode": 214,
                    "indv_key_val": "16440436900",
                    "productCatgyTpe": null,
                    "coverageTypeDesc": "Medical",
                    "indv_key_typ_ref_id": 2757,
                    "claim_platform_ref_Id": 363
                },
                "hsc_sts_ref_id": 19275,
                "flwup_cntc_dtl": null,
                "rev_prr_ref_id": 3755,
                "rev_prr_ref_cd": {
                    "ref_id": 3755,
                    "ref_cd": "2",
                    "ref_desc": "Urgent",
                    "ref_dspl": "Urgent"
                },
                "srvc_set_ref_id": 3737,
                "srvc_set_ref_cd": {
                    "ref_id": 3737,
                    "ref_cd": "1",
                    "ref_desc": "Inpatient",
                    "ref_dspl": "Inpatient"
                },
                "hsc_keys": [
                    {
                        "hsc_id": 13237,
                        "hsc_key_val": "ff46448e-7515-11eb-908f-1ef9496236e0",
                        "inac_ind": 0,
                        "hsc_key_typ_ref_id": 19517
                    }
                ],
                "hsc_srvcs": [],
                "hsc_srvc_facls": [
                    {
                        "actul_admis_dttm": null,
                        "actul_dschrg_dttm": null,
                        "expt_admis_dt": new Date("2021-04-01"),
                        "expt_dschrg_dt": new Date("2021-04-20"),
                        "plsrv_ref_id": 3743,
                        "plsrv_ref_cd": {
                            "ref_id": 3743,
                            "ref_cd": "21",
                            "ref_desc": "Acute Hospital",
                            "ref_dspl": "Acute Hospital"
                        },
                        "srvc_desc_ref_id": 4349,
                        "srvc_desc_ref_cd": {
                            "ref_id": 4349,
                            "ref_cd": "3",
                            "ref_desc": "Emergent",
                            "ref_dspl": "Emergent"
                        },
                        "srvc_dtl_ref_id": 4296,
                        "srvc_dtl_ref_cd": {
                            "ref_id": 4296,
                            "ref_cd": "1",
                            "ref_desc": "Medical",
                            "ref_dspl": "Medical"
                        }
                    }
                ],
                "hsc_diags": [],
                "hsr_notes": [],
                "hsc_provs": [
                    {
                        "auto_aprv_ltr_ind": null,
                        "chg_sys_ref_id": null,
                        "chg_user_id": "001456440",
                        "creat_sys_ref_id": null,
                        "creat_user_id": "001456440",
                        "data_qlty_iss_list": null,
                        "data_secur_rule_list": null,
                        "end_dt": null,
                        "hsc_prov_end_rsn_ref_id": null,
                        "ltr_opt_out_cc_ind": null,
                        "med_rec_nbr": null,
                        "ntwk_strg_rsn_ref_id": null,
                        "ntwk_sts_ref_id": null,
                        "prov_loc_affil_dtl": {
                            "providerDetails": {
                                "prov_id": 9748974,
                                "prov_key": [
                                    {
                                        "prov_key_val": "1699734293",
                                        "prov_key_typ_ref_id": 2782
                                    },
                                    {
                                        "prov_key_val": null,
                                        "prov_key_typ_ref_id": 16333
                                    },
                                    {
                                        "prov_key_val": "1699734293",
                                        "prov_key_typ_ref_id": 2783
                                    }
                                ],
                                "prov_adr_id": 109644999,
                                "prov_cat_typ_ref_id": 16309
                            }
                        },
                        "prov_loc_affil_id": null,
                        "spcl_ref_id": 16646,
                        "strt_dt": null,
                        "telcom_adr_id": "4102258991",
                        "updt_ver_nbr": 0,
                        "hsc_prov_roles": [
                            {
                                "hsc_prov_id": 4548,
                                "prov_role_ref_id": 3758
                            }
                        ]
                    }
                ],
                "hsr_doc_procs": []
            }
    ]
    };
        return of(sampleRes).toPromise();
    }
}

@Injectable()
class MockCreateHscAuthService {

    createHsc(createHscRequestInput: CreateHscRequestInput): Promise<CreateHscResponse> {
        const sampleRes: any  = {
                    "data": {
                        "hsc_id": 13469,
                        "creat_user_id": "",
                        "hsc_sts_ref_id": 19275,
                        "srvc_set_ref_id": 3737,
                        "rev_prr_ref_id": 3754,
                        "hsc_sts_ref_cd": {
                            "ref_desc": "Open"
                        },
                        "srvc_set_ref_cd": {
                            "ref_desc": "Inpatient"
                        },
                        "rev_prr_ref_cd": {
                            "ref_desc": "Routine"
                        },
                        "mbr_cov_dtl": {
                            "pol_nbr": "0752023",
                            "cov_eff_dt": "2020-02-01",
                            "cov_end_dt": "9999-12-31",
                            "mbr_cov_id": 90881959,
                            "cov_typ_ref_cd": {
                                "ref_desc": "Medical"
                            },
                            "cov_typ_ref_id": 182,
                            "clm_pltfm_ref_id": 363,
                            "prdct_typ_ref_cd": {
                                "ref_desc": "POS"
                            },
                            "prdct_catgy_ref_cd": null,
                            "prdct_catgy_ref_id": null
                        },
                        "flwup_cntc_dtl": [{
                                "department": null,
                                "email": null,
                                "phone": "111-111-1111",
                                "fax": null,
                                "creat_dttm": "2021-03-02T20:17:51.490Z",
                                "chg_dttm": "2021-03-02T20:39:24.142Z",
                                "creat_user_id": "001559434",
                                "role": null,
                                "name": "test",
                                "primaryContact": true,
                            }],
                        "hsc_facls": [
                            {
                                "hsc_id": 13469,
                                "plsrv_ref_id": 3743,
                                "srvc_desc_ref_id": 4347,
                                "srvc_dtl_ref_id": 4296,
                                "actul_admis_dttm": null,
                                "actul_dschrg_dttm": null,
                                "expt_admis_dt": "2021-03-02",
                                "expt_dschrg_dt": "2021-03-04"
                            }
                        ],
                        "hsc_diags": [
                            {
                                "hsc_id": 13469,
                                "diag_cd": "L02.52",
                                "inac_ind": 0,
                                "pri_ind": 1,
                                "creat_user_id": "",
                                "chg_user_id": ""
                            },
                            {
                                "hsc_id": 13469,
                                "diag_cd": "L02.51",
                                "inac_ind": 0,
                                "pri_ind": 0,
                                "creat_user_id": "",
                                "chg_user_id": ""
                            }
                        ],
                        "hsc_srvcs": [
                            {
                                "hsc_id": 13469,
                                "chg_user_id": "",
                                "creat_user_id": "",
                                "proc_cd": "80346",
                                "proc_cd_schm_ref_id": 2,
                                "srvc_hsc_prov_id": null
                            }
                        ],
                        "hsc_provs": [
                            {
                                "hsc_id": 13469,
                                "prov_loc_affil_dtl": {
                                    "prov_id": 10455660,
                                    "prov_key": [
                                        {
                                            "provKeyVal": "1710081369",
                                            "provKeyTypeRefId": 2782
                                        },
                                        {
                                            "provKeyVal": "288158608",
                                            "provKeyTypeRefId": 16333
                                        },
                                        {
                                            "provKeyVal": "1710081369",
                                            "provKeyTypeRefId": 2783
                                        }
                                    ],
                                    "prov_adr_id": 117625650,
                                    "prov_cat_typ_ref_id": 16310
                                },
                                "creat_user_id": "",
                                "chg_user_id": "",
                                "telcom_adr_id": "2288674000",
                                "spcl_ref_id": 16567,
                                "prov_loc_affil_id": null,
                                "hsc_prov_roles": [
                                    {
                                        "prov_role_ref_id": 3761
                                    }
                                ]
                            },
                            {
                                "hsc_id": 13469,
                                "prov_loc_affil_dtl": {
                                    "prov_id": 6675410,
                                    "prov_key": [
                                        {
                                            "provKeyVal": "1255539573",
                                            "provKeyTypeRefId": 2782
                                        },
                                        {
                                            "provKeyVal": null,
                                            "provKeyTypeRefId": 16333
                                        },
                                        {
                                            "provKeyVal": "1255539573",
                                            "provKeyTypeRefId": 2783
                                        }
                                    ],
                                    "prov_adr_id": 98265067,
                                    "prov_cat_typ_ref_id": 16309
                                },
                                "creat_user_id": "",
                                "chg_user_id": "",
                                "telcom_adr_id": "7186222000",
                                "spcl_ref_id": 16536,
                                "prov_loc_affil_id": null,
                                "hsc_prov_roles": [
                                    {
                                        "prov_role_ref_id": 3759
                                    }
                                ]
                            }
                        ],
                        "hsr_notes": [
                            {
                                "hsc_id": 13469,
                                "note_titl_txt": "test",
                                "creat_user_id": "",
                                "note_txt_lobj": "test",
                                "src_user_nm": "provider",
                                "hsr_note_sbjs": [
                                    {
                                        "note_sbj_rec_id": "rec_id",
                                        "note_sbj_typ_ref_id": 12,
                                        "inac_ind": 0
                                    }
                                ]
                            },
                            {
                                "hsc_id": 13469,
                                "note_titl_txt": "test1",
                                "creat_user_id": "",
                                "note_txt_lobj": "test1",
                                "src_user_nm": "provider",
                                "hsr_note_sbjs": [
                                    {
                                        "note_sbj_rec_id": "rec_id",
                                        "note_sbj_typ_ref_id": 12,
                                        "inac_ind": 0
                                    }
                                ]
                            }
                        ]
                    }
        };
        return of(sampleRes).toPromise();
    }

    getCaseTypeDetails(getCaseTypeDetailsRequest: HscInput): Promise<CaseTypeDetailsResponse> {
        return of({
            "hsc_id": 14254,
            "hsc_sts_ref_id": 19274,
            "hsc_sts_ref_cd": {
                "ref_id": 19274,
                "ref_cd": "0",
                "ref_desc": "Draft",
                "ref_dspl": "Draft"
            },
            "rev_prr_ref_id": 3754,
            "rev_prr_ref_cd": {
                "ref_id": 3754,
                "ref_cd": "1",
                "ref_desc": "Routine",
                "ref_dspl": "Routine"
            },
            "srvc_set_ref_id": 3738,
            "srvc_set_ref_cd": {
                "ref_id": 3738,
                "ref_cd": "2",
                "ref_desc": "Outpatient",
                "ref_dspl": "Outpatient"
            }
        }).toPromise();
    }

}

@Injectable()
class MockDuplicateCheckService {
    async getHscDuplicates(
        duplicateCheckRequestInput: DuplicateCheckRequestInput,
        httpRequest: HttpRequest,
    ): Promise<DuplicateCheckResponse> {
        return of({ hsc_duplicates: [] }).toPromise();
    }
}

@Injectable()
class MockHscHistoryService {
    getHscHistoryByMemberId(getMemberHscHistoryRequestRequest : GetMemberHscHistoryRequest, httpRequest: HttpRequest): Promise<HscHistoryResponse>  {
        let hscHistorResponse: HscHistoryResponse = {"hsc":[{
                hscId : 1234,
                memberName: 'Mary',
                providerName: "Mike",
                status:"Open",
                placeOfService: "Outpatinet",
                createDate: null}]}
        return of(hscHistorResponse).toPromise();
    }

    getHscHistoryByUserId(getUserHscHistoryRequest : GetUserHscHistoryRequest, httpRequest: HttpRequest): Promise<HscHistoryResponse>  {
        let hscHistorResponse: HscHistoryResponse = {"hsc":[{
                hscId : 1234,
                memberName: 'Mary',
                providerName: "Mike",
                status:"Open",
                placeOfService: "Outpatinet",
                createDate: null}]}
        return of(hscHistorResponse).toPromise();
    }

    getHscHistoryByProvider(getProviderHscHistoryRequest: GetProviderHscHistoryRequest, httpRequest: HttpRequest): Promise<HscHistoryResponse>  {
        const hscHistorResponse: HscHistoryResponse = {"hsc":[{
                hscId : 1234,
                memberName: 'Mary',
                providerName: "Mike",
                status:"Open",
                placeOfService: "Outpatinet",
                createDate: null}]}
        return of(hscHistorResponse).toPromise();
    }
}

class MockGraphQLClient extends GraphQLClient{
    request(document: RequestDocument, variables?: any, requestHeaders?: any): Promise<any>{
        if(variables.provRoleId){
            return of({
                "hsc_prov": [
                    {
                        "hsc_prov_id": 5457,
                        "prov_loc_affil_dtl": {
                            "providerDetails": {
                                "prov_adr": {
                                    "cty_nm": "Santa Monica",
                                    "st_ref_id": 1067,
                                    "zip_cd_txt": "904043414",
                                    "adr_ln_1_txt": "1920 Colorado Ave",
                                    "adr_ln_2_txt": null
                                },
                                "prov_keys": [
                                    {
                                        "prov_key_val": "1851525091",
                                        "prov_key_typ_ref_id": 2782
                                    },
                                    {
                                        "prov_key_val": "288158608",
                                        "prov_key_typ_ref_id": 16333
                                    },
                                    {
                                        "prov_key_val": "1710081369",
                                        "prov_key_typ_ref_id": 2783
                                    }
                                ]
                            }
                        }
                    }
                ]
            }).toPromise();
        }else{
            return of({
                v_prov_srch: [{ prov_loc_affil_id: 1, prov_id: 23, prov_adr_id: 321, prov_catgy_ref_id: 16309}]
            }).toPromise();
        }

    }
}

class MockHealthServiceClient {
    public getGraphqlClient(httpRequest: HttpRequest): GraphQLClient {
        return new MockGraphQLClient('testurl');
    }
}


describe('HscResolver', () => {
  let resolver: HscResolver;
  let context = {req: {headers: {}}};
  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      imports: [LoggerModule.forRoot()],
      providers: [HscResolver, Logger, ConfigService, HscActivityService, HealthServiceClient, MemberCommunicationClient, { provide: GetHscAuthService, useClass: MockGetHscAuthService },
          { provide: UpdateHscService, useClass: MockUpdateHscService },  { provide: HscService , useClass: MockCreateHscAuthService },
          { provide: ProviderService , useClass: MockProviderService }, {provide: DuplicateCheckService , useClass: MockDuplicateCheckService },
          {provide: HscHistoryService , useClass: MockHscHistoryService }, {provide: HealthServiceClient, useClass: MockHealthServiceClient}],
    }).compile();
   resolver = module.get<HscResolver>(HscResolver);
  });

  it('should be defined', () => {
    expect(resolver).toBeDefined();
  });

  it('query should be defined', () => {
    expect(resolver.sayHello()).toBeDefined();
  });

    it('should call hsc AuthDetails', () => {
        const getHscAuthRequest: GetHscAuthRequest = {hsc:{hsc_id : 13237}};
        resolver.getHscAuthDetails(getHscAuthRequest, context.req).then((res) => {
            expect(res.hsc[0].hsc_id).toEqual(13237);
        });
    });

    it('should call get Hsc Member Auth History', () => {
        const getMemberHscHistoryRequest: GetMemberHscHistoryRequest = {"indv_key_val":"16440436900"};
        resolver.getHscMemberHistory(getMemberHscHistoryRequest, context.req).then((res) => {
            expect(res.hsc[0].hscId).toEqual(1234);
        });
    });

    it('should call get Hsc User Auth History', () => {
        const getUserHscHistoryRequest: GetUserHscHistoryRequest = {"creat_user_id":"16440436900"};
        resolver.getHscUserHistory(getUserHscHistoryRequest, context.req).then((res) => {
            expect(res.hsc[0].hscId).toEqual(1234);
        });
    });

    it('should call update Auth', () => {
        const updateHscRequest: UpdateHscRequest = {
            "hsc_id": 13611,
            "indv_key_typ_ref_id": 2757,
            "indv_key_val": "16440436900",
            "srvc_set_ref_id": 3737,
            "hsc":{
                "rev_prr_ref_id": 3754,
                "creat_sys_ref_id": 1234,
            },
            "mbr_cov": {
                "fst_nm": "Matt",
                "lst_nm": "Meyer",
                "bth_dt": new Date("1978-07-26"),
                "gdr_ref_id": 2109,
                "orig_sys_cd": "CDB_CS",
                "cov_eff_dt": new Date("2013-01-01"),
                "cov_end_dt": new Date("9999-12-31"),
                "src_mbr_id": "30830290",
                "src_mbr_partn_id": "10",
                "pol_nbr": "0128855",
                "cov_typ_ref_id": null,
                "clm_pltfm_ref_id": 363
            },
            "hsc_diags": [
                {
                    "diag_cd": "M21.51",
                    "pri_ind": 1,
                    "inac_ind": 0
                },
                {
                    "diag_cd": "L02.51",
                    "pri_ind": 0,
                    "inac_ind": 1
                },
                {
                    "diag_cd": "L02.52",
                    "pri_ind": 0,
                    "inac_ind": 0
                }
            ],
            "hsr_notes":  [
                {
                    "note_txt_lobj": "testing",
                    "note_titl_txt": "title",
                    "src_user_nm": "clinician",
                    "note_typ_ref_id": 12,
                    "note_catgy_ref_id": null,
                    "note_sts_ref_id":null,
                    "hsr_note_sbjs":[{
                        "note_sbj_rec_id":"123",
                        "note_sbj_typ_ref_id":234,
                    }]
                }
            ],
            "flwup_cntc_dtl": [{
                    "department": null,
                    "email": null,
                    "phone": "234-456-4666",
                    "fax": null,
                    "role": null,
                    "name": "demo",
                    "primaryContact": true,
                },
                {
                    "department": null,
                    "email": null,
                    "phone": "234-456-4666",
                    "fax": null,
                    "role": null,
                    "name": "wffwf",
                    "primaryContact": false,
                }],
            "hsc_provs": [
                {
                    "prov_keys": [
                        {
                            "prov_key_typ_ref_id": 2782,
                            "prov_key_val": "1851525091"
                        },
                        {
                            "prov_key_typ_ref_id": 16333,
                            "prov_key_val": "288158608"
                        },
                        {
                            "prov_key_typ_ref_id": 2783,
                            "prov_key_val": "1710081369"
                        }
                    ],
                    "hsc_prov_roles": [
                        {
                            "prov_role_ref_id": 3765
                        }
                    ],
                    "prov_adr": {
                        "adr_ln_1_txt": "1920 Colorado Ave",
                        "adr_ln_2_txt": null,
                        "zip_cd_txt": "904043414",
                        "cty_nm": "Santa Monica",
                        "st_ref_id": 1067
                    }
                }
            ],
            "hsc_facl": {
                "plsrv_ref_id": 3743,
                "srvc_desc_ref_id": 4347,
                "srvc_dtl_ref_id": 4296,
                "actul_admis_dttm": null,
                "actul_dschrg_dttm": null,
                "expt_admis_dt": new Date("2021-03-02"),
                "expt_dschrg_dt": new Date("2021-03-04")
            },
            "hsc_srvcs": [
                {
                    "proc_cd": "81099",
                    "proc_cd_schm_ref_id": 2,
                    "srvc_hsc_prov_id": null,
                    "inac_ind": 1,
                    "hsc_prov": {
                        "prov_keys": [
                            {
                                "prov_key_typ_ref_id": 2782,
                                "prov_key_val": "1851525091"
                            },
                            {
                                "prov_key_typ_ref_id": 16333,
                                "prov_key_val": "288158608"
                            },
                            {
                                "prov_key_typ_ref_id": 2783,
                                "prov_key_val": "1710081369"
                            }
                        ],
                        "hsc_prov_roles": [
                            {
                                "prov_role_ref_id": 3765
                            }
                        ],
                        "prov_adr": {
                            "adr_ln_1_txt": "1920 Colorado Ave",
                            "adr_ln_2_txt": null,
                            "zip_cd_txt": "904043414",
                            "cty_nm": "Santa Monica",
                            "st_ref_id": 1067
                        }
                    },
                    "hsc_decn": {
                        "hsc_decn_id":1,
                        "decn_otcome_ref_id": 1,
                        "decn_typ_ref_id": 2,
                        "decn_rsn_ref_id": 3,
                        "clm_note_txt": "test",
                        "ovrd_clm_rmrk_ref_id": 1,
                        "sys_clm_rmrk_ref_id": 1,
                        "wrt_decn_cmnct_dttm": new Date("12-03-2021"),
                        "decn_rndr_dttm": new Date("12-03-2021"),
                        "decn_mbr_cmnct_dttm": new Date("12-03-2021"),
                        "decn_prov_cmnct_dttm": new Date("12-03-2021"),
                        "gap_rev_otcome_ref_id": 2,
                        "negot_rt": 1,
                        "hsc_decn_bed_days": [
                            {
                                "strt_bed_dt": new Date("12-03-2021"),
                                "rvnu_cd": "test",
                                "bed_typ_ref_id": 1
                            }
                        ]
                    }
                },
                {
                    "proc_cd": "71830",
                    "proc_cd_schm_ref_id": 2,
                    "srvc_hsc_prov_id": null,
                    "inac_ind": 0,
                    "hsc_prov": {
                        "prov_keys": [
                            {
                                "prov_key_typ_ref_id": 2782,
                                "prov_key_val": "1851525091"
                            },
                            {
                                "prov_key_typ_ref_id": 16333,
                                "prov_key_val": "288158608"
                            },
                            {
                                "prov_key_typ_ref_id": 2783,
                                "prov_key_val": "1710081369"
                            }
                        ],
                        "hsc_prov_roles": [
                            {
                                "prov_role_ref_id": 3765
                            }
                        ],
                        "prov_adr": {
                            "adr_ln_1_txt": "1920 Colorado Ave",
                            "adr_ln_2_txt": null,
                            "zip_cd_txt": "904043414",
                            "cty_nm": "Santa Monica",
                            "st_ref_id": 1067
                        }
                    },
                    "hsc_decn": {
                        "hsc_decn_id":1,
                        "decn_otcome_ref_id": 1,
                        "decn_typ_ref_id": 2,
                        "decn_rsn_ref_id": 3,
                        "clm_note_txt": "test",
                        "ovrd_clm_rmrk_ref_id": 1,
                        "sys_clm_rmrk_ref_id": 1,
                        "wrt_decn_cmnct_dttm": new Date("12-03-2021"),
                        "decn_rndr_dttm": new Date("12-03-2021"),
                        "decn_mbr_cmnct_dttm": new Date("12-03-2021"),
                        "decn_prov_cmnct_dttm": new Date("12-03-2021"),
                        "gap_rev_otcome_ref_id": 2,
                        "negot_rt": 1,
                        "hsc_decn_bed_days": [
                            {
                                "strt_bed_dt": new Date("12-03-2021"),
                                "rvnu_cd": "test",
                                "bed_typ_ref_id": 1
                            }
                        ]
                    },
                    "hsc_srvc_non_facls": [
                        {
                            "srvc_dtl_ref_id": 3771,
                            "proc_freq_ref_id": 3913,
                            "proc_uom_ref_id": 19884,
                            "proc_unit_cnt": 1,
                            "unit_per_freq_cnt": 1,
                            "proc_mod_1_cd": "00",
                            "proc_mod_2_cd": "00",
                            "proc_mod_3_cd": "0A",
                            "proc_mod_4_cd": "0A",
                            "srvc_end_dt": new Date("2021-03-20"),
                            "srvc_strt_dt": new Date("2021-03-19"),
                            "init_trt_dt": null,
                            "plsrv_ref_id": 3741,
                            "srvc_desc_ref_id": 4347,
                            "hsc_srvc_non_facl_dmes": [
                                {}
                            ]
                        }
                    ]
                }
            ]
        };
        resolver.updateHsc(updateHscRequest, context.req).then((res) => {
            expect(res.hsc[0].hsc_id).toEqual(13611);
        });
    });


    it('should call create Auth', () => {
        const createHscRequestInput: CreateHscRequestInput = {
            "hsc": {
                "indv_key_typ_ref_id": 2757,
                "indv_key_val": "16440436900",
                "srvc_set_ref_id": 3737,
                "rev_prr_ref_id": 3754,
                "mbr_cov": {
                    "fst_nm": "Matt",
                    "lst_nm": "Meyer",
                    "bth_dt": new Date("1978-07-26"),
                    "gdr_ref_id": 2109,
                    "orig_sys_cd": "CDB_CS",
                    "cov_eff_dt": new Date("2013-01-01"),
                    "cov_end_dt": new Date("9999-12-31"),
                    "src_mbr_id": "30830290",
                    "src_mbr_partn_id": "10",
                    "pol_nbr": "0128855",
                    "cov_typ_ref_id": null,
                    "clm_pltfm_ref_id": 363
                },
                "flwup_cntc_dtl": [{
                        "name": "test",
                        "role": null,
                        "department": null,
                        "phone": "111-111-1111",
                        "fax": null,
                        "email": null,
                        "primaryContact": true
                    },
                    {
                        "name": "secondary contact name",
                        "role": null,
                        "department": null,
                        "phone": "111-111-1111",
                        "fax": null,
                        "email": null,
                        "primaryContact": false,
                    }],
                "hsc_facl": {
                    "plsrv_ref_id": 3743,
                    "srvc_desc_ref_id": 4347,
                    "srvc_dtl_ref_id": 4296,
                    "actul_admis_dttm": null,
                    "actul_dschrg_dttm": null,
                    "expt_admis_dt": new Date(),
                    "expt_dschrg_dt": new Date(),
                    "admis_ntfy_dttm": new Date(),
                    "admis_ntfy_trans_id": 1,
                    "adv_ntfy_dttm": new Date(),
                    "adv_ntfy_trans_id": 1,
                    "ctp_nom_sts_ref_id": 1,
                    "dschrg_disp_ref_id": 1,
                    "dschrg_ntfy_dttm": new Date(),
                    "dschrg_ntfy_trans_id": 1,
                    "goal_los_day_cnt": 1,
                    "ipcm_typ_ref_id": 1,
                    "rem_snf_day_cnt": 1,
                    "snf_day_xhst_ind": 1,
                    "tat_due_dttm": new Date(),
                },
                "hsc_diags": [
                    {
                        "diag_cd": "L02.52",
                        "pri_ind": 1,
                        "diag_othr_txt": "test"
                    },
                    {
                        "diag_cd": "L02.51",
                        "pri_ind": 0,
                        "diag_othr_txt": "test"
                    }
                ],
                "hsc_srvcs": [
                    {
                        "proc_cd": "80346",
                        "proc_cd_schm_ref_id": 2,
                        "srvc_hsc_prov_id": 1,
                        "hsc_decn":{
                                "hsc_decn_id":1,
                                "decn_otcome_ref_id": 1,
                                "decn_typ_ref_id": 2,
                                "decn_rsn_ref_id": 3,
                                "clm_note_txt": "test",
                                "ovrd_clm_rmrk_ref_id": 1,
                                "sys_clm_rmrk_ref_id": 1,
                                "decn_src_desc": {
                                    "test": "test"
                                },
                                "wrt_decn_cmnct_dttm": new Date(),
                                "decn_rndr_dttm": new Date(),
                                "decn_mbr_cmnct_dttm": new Date(),
                                "decn_prov_cmnct_dttm": new Date(),
                                "gap_rev_otcome_ref_id": 2,
                                "negot_rt": 1,
                                "actul_nxt_rev_dt": new Date(),
                                "decn_bed_day_cnt": 1,
                                "aprv_proc_unit_cnt": 1,
                                "aprv_unit_per_freq_cnt": 1,
                                "ben_lvl_ref_id": 1,
                                "ben_xcpt_ref_id": 1,
                                "decn_clin_rsn_txt": "test",
                                "decn_ent_by_user_id": "1",
                                "decn_ent_rsn_ref_id": 1,
                                "decn_hsc_prov_id": 1,
                                "decn_made_by_user_id": '1',
                                "decn_made_by_user_org_desc": "test",
                                "decn_mbr_cmnct_to_role_ref_id": 1,
                                "decn_prov_cmnct_to_role_ref_id": 1,
                                "decn_ur_jurdc_ref_id": 1,
                                "ltr_atr_list": {"test": "test"},
                                "mbr_cov_dtl": {"test": "test"},
                                "negot_rt_typ_ref_id": 1,
                                "ovrd_rsn_ref_id": 1,
                                "ovrd_rsn_txt": "test",
                                "peer_to_peer_rev_dt": new Date(),
                                "sched_nxt_rev_dt": new Date(),
                                "site_of_care_pref_ref_id": 1,
                                "hsc_decn_bed_days": [
                                    {
                                        "strt_bed_dt": new Date(),
                                        "rvnu_cd": "test",
                                        "bed_typ_ref_id": 1,
                                        "accum_bed_day_cnt": 1,
                                        "decn_facl_cmnct_dttm": new Date(),
                                        "decn_rndr_dttm_facl_lcl_txt": "test",
                                        "questnr_rspn_id": 1
                                    }
                                ]
                            }
                    }
                ],
                "hsr_notes": [
                    {
                        "note_txt_lobj": "test",
                        "note_titl_txt": "test",
                        "src_user_nm": "provider",
                        "note_typ_ref_id": 321,
                        "note_catgy_ref_id": 123,
                        "note_sts_ref_id":null,
                        "hsr_note_sbjs":[{
                            "note_sbj_rec_id":"123",
                            "note_sbj_typ_ref_id":234,
                        }]
                    },
                    {
                        "note_txt_lobj": "test1",
                        "note_titl_txt": "test1",
                        "src_user_nm": "provider",
                        "note_typ_ref_id": 321,
                        "note_catgy_ref_id": 123,
                        "note_sts_ref_id":null,
                        "hsr_note_sbjs":[{
                            "note_sbj_rec_id":"123",
                            "note_sbj_typ_ref_id":234,
                        }]
                    }
                ],
                "hsc_provs": [
                    {
                        "prov_keys": [
                            {
                                "prov_key_typ_ref_id": 2782,
                                "prov_key_val": "1710081369"
                            },
                            {
                                "prov_key_typ_ref_id": 16333,
                                "prov_key_val": "288158608"
                            },
                            {
                                "prov_key_typ_ref_id": 2783,
                                "prov_key_val": "1710081369"
                            }
                        ],
                        "hsc_prov_roles": [
                            {
                                "prov_role_ref_id": 3761
                            }
                        ],
                        "prov_adr": {
                            "adr_ln_1_txt": "1920 Colorado Ave",
                            "adr_ln_2_txt": null,
                            "zip_cd_txt": "904043414",
                            "cty_nm": "Santa Monica",
                            "st_ref_id": 1067
                        }
                    },
                    {
                        "prov_keys": [
                            {
                                "prov_key_typ_ref_id": 2782,
                                "prov_key_val": "1255539573"
                            },
                            {
                                "prov_key_typ_ref_id": 16333,
                                "prov_key_val": "288158608"
                            },
                            {
                                "prov_key_typ_ref_id": 2783,
                                "prov_key_val": "1255539573"
                            }
                        ],
                        "hsc_prov_roles": [
                            {
                                "prov_role_ref_id": 3759
                            }
                        ],
                        "prov_adr": {
                            "adr_ln_1_txt": "1920 Colorado Ave",
                            "adr_ln_2_txt": null,
                            "zip_cd_txt": "904043414",
                            "cty_nm": "Santa Monica",
                            "st_ref_id": 1067
                        }
                    }
                ]
            }
        } ;
        resolver.createHsc(createHscRequestInput, context.req).then((res) => {
            expect(res.data.hsc_id).toEqual(13469);
        });
    });

  it('duplicateCheck should return duplicates', () => {
    const duplicateCheckRequestInput: DuplicateCheckRequestInput = {
      hsc: {
        indv_key_typ_ref_id: 2,
        indv_key_val: '123',
        srvc_set_ref_id: 321,
        hsc_provs: [
          {
            id: 2,
            prov_keys: [
              {
                prov_key_typ_ref_id: 2782,
                prov_key_val: '1255539573',
              },
              {
                prov_key_typ_ref_id: 16333,
                prov_key_val: '288158608',
              },
              {
                prov_key_typ_ref_id: 2783,
                prov_key_val: '1255539573',
              },
            ],
            hsc_prov_roles: [
              {
                prov_role_ref_id: 3759,
              },
            ],
              prov_adr: {
                  adr_ln_1_txt: "1920 Colorado Ave",
                  adr_ln_2_txt: null,
                  zip_cd_txt: "904043414",
                  cty_nm: "Santa Monica",
                  st_ref_id: 1067
              }
          },
          ,
        ],
      },
    };
    resolver.duplicateCheck(duplicateCheckRequestInput, context.req).then((res) => {
          expect(res.hsc_duplicates.length).toEqual(0);
        });
  });

    it('getProviderHscHistory should return requesting provider Hsc History', () => {
        const getProviderHscHistoryRequest: GetProviderHscHistoryRequest = {"prov_key_val":"16440436900", "prov_key_typ_ref_id": 16333};
        resolver.getProviderHscHistory(getProviderHscHistoryRequest, context.req).then((res) => {
            expect(res.hsc[0].hscId).toEqual(1234);
        });
    });

    it('should call getCaseTypeDetails', () => {
        const getCaseTypeDetailsRequest: HscInput = {hsc_id : 13237};
        resolver.getCaseTypeDetails(getCaseTypeDetailsRequest, context.req).then((res) => {
            expect(res.hsc_id).toEqual(13237);
        });
    });

    it('should call saveCommunicationActivity', () => {
        const activityRequest: ActivityRequest = {
            "activity": {
                "hsc_id" : 3232,
                 "creat_user_id": "SYSTEM",
                 "actv_typ_ref_id": 17777,
                  "rslv_otcome_typ_id": 999,
                  "hsr_sbj_rec_id": 111,
                  "hsr_sbj_typ_ref_id": 222
            },
            "communication" : {
                "mbr_cmnct_chnl_ref_id" : 27777,
                "mbr_cmnct_sts_ref_id" : 2911,
                "mbr_cmnct_dir_ref_id" : 4555,
                "mbr_cmnct_typ_ref_id" : 5555,
                "mbr_cmnct_catgy_ref_id" : 7689,
                "mbr_cmnct_rsn_ref_id": 20090,
                "mbr_cmnct_sts_rsn_ref_id": 20066
            }
        }
        resolver.saveActivity(activityRequest, context.req).then((res) => {
            expect(res.hsr_actv_id).toEqual(56);
        });
    });
});
