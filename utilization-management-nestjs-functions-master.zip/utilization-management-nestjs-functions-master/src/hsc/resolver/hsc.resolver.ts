import {Args, Context, Int, Mutation, Query, Resolver} from "@nestjs/graphql";
import {GetHscAuthService} from "../service/getHscAuth/getHscAuth.service";
import {GetHscAuthResponse} from "../models/getHscAuthResponse";
import {GetHscAuthRequest} from "../models/getHscAuthRequest";
import {UseFilters, UseGuards} from "@nestjs/common";
import {AuthGuard} from "../../auth/auth.guard";
import {AllExceptionsFilter} from "../../filters/graphql-exception.filter";
import {HscService} from "../service/createHsc/hsc.service";
import { GetMemberHscHistoryRequest } from "../models/getMemberHscHistoryRequest";
import { HscHistoryResponse } from "../models/getHscHistoryResponse";
import {CreateHscResponse} from "../models/createHscResponse";
import {CreateHscRequestInput} from "../models/createHscRequest.input";
import {UpdateHscService} from "../service/updateHsc/updateHsc.service";
import {UpdateHscRequest} from "../models/updateHscRequest";
import {DuplicateCheckResponse} from "../models/duplicateCheckResponse";
import {DuplicateCheckRequestInput} from "../models/duplicateCheckRequest.input";
import { GetUserHscHistoryRequest } from "../models/getUserHscHistoryRequest";
import {RolesGuard} from "../../auth/roles.guard";
import {Role} from "../../decorators/roles";
import {Roles} from "../../decorators/roles.decorator";
import {DuplicateCheckService} from "../service/duplicate-check/duplicate-check.service";
import {GetProviderHscHistoryRequest} from "../models/getProviderHscHistoryRequest";
import {HscHistoryService} from "../service/hscHistory/hscHistory.service";
import {HscInput} from "../models/hsc.input";
import {CaseTypeDetailsResponse} from "../models/caseTypeDetailsResponse";
import { ActivityResponse } from "../models/activityResponse";
import { HscActivityService } from "../service/activity-service/hsc.activity.service";
import { ActivityRequest } from "../models/activityRequest";
import {ProviderGuard} from '../../auth/provider.guard';


@Resolver()
export class HscResolver {
    constructor(
        private getHscAuthService: GetHscAuthService,
        private updateHscService: UpdateHscService,
        private hscService: HscService,
        private duplicateCheckService: DuplicateCheckService,
        private hscHistoryService: HscHistoryService,
        private hscActivityService: HscActivityService
    ) {}

    /*
         All servers running with GraphQL must have at least one @Query() to be considered a valid GraphQL server.
         TODO - Remove this once this Repository has any queries implemented
       */
  @Query(() => String)
  sayHello(): string {
    return 'Hello World!';
  }
  @Query(returns => GetHscAuthResponse, {description: "Query to get existing hsc details"})
  @UseGuards(AuthGuard, ProviderGuard)
  @UseFilters(new AllExceptionsFilter())
  async getHscAuthDetails(@Args('getHscAuthRequest') getHscAuthRequest : GetHscAuthRequest, @Context() context){
    return this.getHscAuthService.hscAuthDetails(getHscAuthRequest, context.req);
  }


  @Query(returns => HscHistoryResponse, {description: "Query to get Hsc History details using MemberID"})
  @UseGuards(AuthGuard)
  @UseFilters(new AllExceptionsFilter())
  async getHscMemberHistory(@Args('getMemberHscHistoryRequest') getMemberHscHistoryRequest : GetMemberHscHistoryRequest, @Context() context){
    return this.hscHistoryService.getHscHistoryByMemberId(getMemberHscHistoryRequest, context.req);
  }

  @Query(returns => HscHistoryResponse, {description: "Query to get Hsc History details using UserID"})
  @UseGuards(AuthGuard)
  @UseFilters(new AllExceptionsFilter())
  async getHscUserHistory(@Args('getUserHscHistoryRequest') getUserHscHistoryRequest : GetUserHscHistoryRequest, @Context() context){
    return this.hscHistoryService.getHscHistoryByUserId(getUserHscHistoryRequest, context.req);
  }

  @Mutation(returns => GetHscAuthResponse, {description: "Update existing hsc details"})
  @UseGuards(AuthGuard)
  @UseFilters(new AllExceptionsFilter())
  async updateHsc(@Args('updateHscRequest') updateHscRequest : UpdateHscRequest, @Context() context){
      return this.updateHscService.updateHscDetails(updateHscRequest, context.req);
  }

  @Mutation(returns => CreateHscResponse)
  @UseGuards(AuthGuard)
  @UseFilters(new AllExceptionsFilter())
  async createHsc(@Args('createHscRequestInput') createHscRequestInput : CreateHscRequestInput, @Context() context){
      return this.hscService.createHsc(createHscRequestInput, context.req);
  }

    @Mutation((returns) => DuplicateCheckResponse, {description: "Returns potential duplicates which satisfies the criteria defined in AuthDuplicateChecking.dmn. DMN is evaluated based on client and tenant passed in request headers"})
    @UseGuards(AuthGuard, RolesGuard)
    @Roles(Role.UM_INTAKE_CLINICIAN, Role.UM_INTAKE_PROVIDER, Role.UM_INTAKE_SYSTEM)
    @UseFilters(new AllExceptionsFilter())
    async duplicateCheck(@Args('duplicateCheckRequestInput')duplicateCheckRequestInput: DuplicateCheckRequestInput, @Context() context,) {
        return this.duplicateCheckService.getHscDuplicates(duplicateCheckRequestInput, context.req);
    }

  @Query(returns => HscHistoryResponse, {description: "Returns Hsc's which has the given Provider as Requesting role"})
  @UseGuards(AuthGuard, RolesGuard)
  @UseFilters(new AllExceptionsFilter())
  async getProviderHscHistory(@Args('getProviderHscHistoryRequest') getProviderHscHistoryRequest : GetProviderHscHistoryRequest, @Context() context){
    return this.hscHistoryService.getHscHistoryByProvider(getProviderHscHistoryRequest, context.req);
  }

  @Query(returns => CaseTypeDetailsResponse, {description: "Query to get existing CaseType details"})
  @UseGuards(AuthGuard, RolesGuard)
  @UseFilters(new AllExceptionsFilter())
  async getCaseTypeDetails(@Args('getCaseTypeDetailsRequest') getCaseTypeDetailsRequest : HscInput, @Context() context){
      return this.hscService.getCaseTypeDetails(getCaseTypeDetailsRequest, context.req);
  }

  @Mutation(returns => ActivityResponse, {description: "Save activity"})
  @UseGuards(AuthGuard, RolesGuard)
  @Roles(Role.CASE_MGMT_ADMIN, Role.UM_INTAKE_SYSTEM, Role.CASE_MGMT_CDU, Role.CASE_MGMT_MD, Role.CASE_MGMT_NURSE, Role.CASE_MGMT_SYSTEM)
  @UseFilters(new AllExceptionsFilter())
  async saveActivity(@Args({
      name: 'activityRequest',
      type: () => ActivityRequest
  }) activityRequest: ActivityRequest, @Context() context) {
      return this.hscActivityService.saveActivity(activityRequest, context.req);
  }
}
