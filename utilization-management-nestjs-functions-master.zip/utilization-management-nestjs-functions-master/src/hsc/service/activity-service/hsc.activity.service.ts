import { HttpRequest } from "@azure/functions"
import { Injectable } from '@nestjs/common';
import { GraphQLClient } from "graphql-request/dist";
import { insertActivityMutation, insertActivitySubjMutation } from "../../../shared/graphql/healthservicedomain/healthServiceQuery";
import { insertCommunicationMutation, insertCommunicationSubjMutation } from "../../../shared/graphql/communication-domain/memberCommunicationQuery";
import { ActivityRequest } from "../../models/activityRequest";
import { HealthServiceClient } from "../../../shared/graphql/healthservicedomain/healthServiceClient";
import { HsrActivityDataInput } from "../../models/hscActivityData.input";
import { HscMemberCommInput } from "../../models/hscMemberComm.input";
import { MemberCommunicationClient } from "../../../shared/graphql/communication-domain/memberCommunicationClient";
import { ActivityResponse } from "../../models/activityResponse";
import { InjectPinoLogger, PinoLogger } from "nestjs-pino/dist";

@Injectable()
export class HscActivityService {
    activityClient: GraphQLClient;
    communicationClient: GraphQLClient;

    constructor(private readonly healthServiceClient: HealthServiceClient,
        private readonly memberCommunicationClient: MemberCommunicationClient,
        @InjectPinoLogger(HscActivityService.name) private readonly logger: PinoLogger
    ) { }

    async saveActivity(activityRequest: ActivityRequest, httpRequest: HttpRequest): Promise<ActivityResponse> {
        this.activityClient = this.healthServiceClient.getGraphqlClient(httpRequest);
        this.communicationClient = this.memberCommunicationClient.getGraphqlClient(httpRequest);
        try {
            var response = new ActivityResponse();
            //step-1 insert into  hsr_actv table
            this.logger.info("Before mutation (insertActivity) to health service domain : " + "at:" + new Date());
            const hrsActvData = await this.insertHsrActv(activityRequest.activity);
            const hsr_actv_id = hrsActvData?.insert_hsr_actv_one?.hsr_actv_id;
            this.logger.info("After mutation (insertHsrActv) to health service domain : hsr_actv_id: " + hsr_actv_id + "at:" + new Date());

            //step-2 Check for hsr_sbj_ref_id in request, if present then insert to hsr_actv_sbj table
            if (activityRequest.activity.hsr_sbj_typ_ref_id) {
                this.logger.info("Before mutation (insertActivityToHsrActvSubj) to health service domain : " + "at:" + new Date());
                await this.insertActivityToHsrActvSubj(activityRequest.activity, hsr_actv_id);
                this.logger.info("After mutation (insertActivityToHsrActvSubj) to health service domain : " + "at:" + new Date());
            }

            //step-3 Check if request has communication
            this.checkCommunication(activityRequest, hsr_actv_id);
            response.hsr_actv_id = hsr_actv_id;
            return response;
        } catch (e) {
            this.logger.error("Error while saving Activity ActivityService  saveActivity (ActivityRequest: " + ActivityRequest + ", httpRequest: " + httpRequest + ") " + e);
        }
    }

    async checkCommunication(activityRequest: ActivityRequest, hsr_actv_id: number) {
        //Check if request has member communication data and insert into mbr_cmnct table
        if (activityRequest.communication) {
            this.logger.info("Before mutation (insertMemberComm) to communication domain : " +"at:"+ new Date());
            const mbrCommData = await this.insertMemberComm(activityRequest.communication, activityRequest.activity);
            const mbr_cmnct_id = mbrCommData?.insert_mbr_cmnct_one?.mbr_cmnct_id;
            this.logger.info("After mutation (insertMemberComm) to communication domain : mbr_cmnct_id: " + mbr_cmnct_id+ "at:" + new Date());
            this.associateActivityandCommunication(activityRequest, mbr_cmnct_id, hsr_actv_id);
        }
    }

    async associateActivityandCommunication(activityRequest: ActivityRequest, mbr_cmnct_id: number, hsr_actv_id: number) {
        this.logger.info("Before mutation (insertActivityDataMemberCommSubj) to communication domain : " +"at:"+ new Date());
        await this.insertActivityDataMemberCommSubj(activityRequest.activity, mbr_cmnct_id, hsr_actv_id);
        this.logger.info("After mutation (insertActivityDataMemberCommSubj) to communication domain : " + "at:" + new Date());
        this.logger.info("Before mutation (insertCommDataHsrActvSubj) to health service domain : " +"at:"+ new Date());
        await this.insertCommDataHsrActvSubj(activityRequest.communication, mbr_cmnct_id, hsr_actv_id);
        this.logger.info("After mutation (insertCommDataHsrActvSubj) to health service domain : " +"at:"+ new Date());
    }

    async insertHsrActv(activity: HsrActivityDataInput): Promise<any> {
        const activityVariables = {
            hsr_actv: {
                hsc_id: activity.hsc_id,
                actv_typ_ref_id: activity.actv_typ_ref_id,
                creat_user_id: activity.creat_user_id,
                rslv_otcome_typ_id: activity.rslv_otcome_typ_id,
                creat_dttm: new Date().toISOString(),
                actv_strt_dttm: new Date().toISOString(),
                chg_dttm: new Date().toISOString(),
                chg_user_id: activity.creat_user_id,
                creat_sys_ref_id: activity.creat_sys_ref_id,
                chg_sys_ref_id: activity.chg_sys_ref_id

            }
        };
        return await this.activityClient.request(insertActivityMutation, activityVariables);
    }

    async insertActivityToHsrActvSubj(activity: HsrActivityDataInput, hsr_actv_id: number): Promise<any> {
        const taskActivitySubjVariables = {
            hsr_actv_sbj: {
                hsr_actv_id: hsr_actv_id,
                hsr_sbj_rec_id: activity.hsr_sbj_rec_id,
                hsr_sbj_typ_ref_id: activity.hsr_sbj_typ_ref_id
            }
        };
        return await this.activityClient.request(insertActivitySubjMutation, taskActivitySubjVariables);
    }

    async insertMemberComm(communication: HscMemberCommInput, activity: HsrActivityDataInput): Promise<any> {
        const communicationVariables = {
            mbr_cmnct: {
                mbr_cmnct_chnl_ref_id: communication.mbr_cmnct_chnl_ref_id,
                mbr_cmnct_sts_ref_id: communication.mbr_cmnct_sts_ref_id,
                mbr_cmnct_dir_ref_id: communication.mbr_cmnct_dir_ref_id,
                mbr_cmnct_typ_ref_id: communication.mbr_cmnct_typ_ref_id,
                mbr_cmnct_catgy_ref_id: communication.mbr_cmnct_catgy_ref_id,
                creat_user_id: activity.creat_user_id,
                creat_dttm: new Date().toISOString(),
                chg_dttm: new Date().toISOString(),
                chg_user_id: activity.creat_user_id,
                creat_sys_ref_id: activity.creat_sys_ref_id,
                chg_sys_ref_id: activity.chg_sys_ref_id
            }
        };
        return await this.communicationClient.request(insertCommunicationMutation, communicationVariables);
    }

    async insertActivityDataMemberCommSubj(activity: HsrActivityDataInput, mbr_cmnct_id: number, hsr_actv_id: number): Promise<any> {
        const communicationSubjVariables = {
            mbr_cmnct_sbj: {
                mbr_cmnct_id: mbr_cmnct_id,
                mbr_cmnct_sbj_id: hsr_actv_id.toString(),
                mbr_cmnct_sbj_typ_ref_id: activity.actv_typ_ref_id
            }
        };
        return await this.communicationClient.request(insertCommunicationSubjMutation, communicationSubjVariables);
    }

    async insertCommDataHsrActvSubj(communication: HscMemberCommInput, mbr_cmnct_id: number, hsr_actv_id: number): Promise<any> {
        const activitySubjVariables = {
            hsr_actv_sbj: {
                hsr_actv_id: hsr_actv_id,
                hsr_sbj_rec_id: mbr_cmnct_id,
                hsr_sbj_typ_ref_id: communication.mbr_cmnct_typ_ref_id
            }
        };
        return await this.activityClient.request(insertActivitySubjMutation, activitySubjVariables);
    }

}
