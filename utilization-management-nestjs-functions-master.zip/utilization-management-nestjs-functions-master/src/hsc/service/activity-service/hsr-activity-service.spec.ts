import { Test, TestingModule } from '@nestjs/testing';
import { ConfigService, ConfigModule } from "@nestjs/config";
import { HttpRequest } from "@azure/functions";
import { of } from "rxjs";
import { HealthServiceClient } from "../../../shared/graphql/healthservicedomain/healthServiceClient";
import { HttpModule, HttpService } from "@nestjs/common";
import { AuthorizationService } from '@ecp/func-tk/dist';
import { LoggerModule } from "nestjs-pino/dist";
import { HscActivityService } from './hsc.activity.service';
import { MemberCommunicationClient } from '../../../shared/graphql/communication-domain/memberCommunicationClient';
import { ActivityRequest } from 'src/hsc/models/activityRequest';
import { GraphQLClient } from 'graphql-request';
import { RequestDocument } from 'graphql-request/dist/types';


class MockGraphQLClient extends GraphQLClient {
    request(document: RequestDocument, variables?: any, requestHeaders?: any): Promise<any> {
        if (variables.hsr_actv) {
            return of({
                "insert_hsr_actv_one": {
                    "hsr_actv_id": 123456
                }
            }).toPromise();
        } else if (variables.hsr_actv_sbj) {
            return of({
                "insert_hsr_actv_sbj_one": {
                    "hsr_actv_id": 123456
                }
            }).toPromise();
        } else if (variables.mbr_cmnct) {
            return of({
                "insert_mbr_cmnct_one": {
                    "mbr_cmnct_id": 123456,
                    "mbr_cmnct_typ_ref_id": 789123
                }
            }).toPromise();
        } else if (variables.mbr_cmnct_sbj) {
            return of({
                "insert_mbr_cmnct_sbj_one": {
                    "mbr_cmnct_id": 123456
                }
            }).toPromise();
        }
    }
}
class MockHealthServiceClient {
    public getGraphqlClient(httpRequest: HttpRequest): GraphQLClient {
        return new MockGraphQLClient('testurl');
    }
}

class MockMemberCommunicationClient {
    public getGraphqlClient(httpRequest: HttpRequest): GraphQLClient {
        return new MockGraphQLClient('testurl');
    }
}

describe('HscActivityService', () => {
    let service: HscActivityService;
    let config: ConfigService;
    let httpService: HttpService;
    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            imports: [ConfigModule, HttpModule, LoggerModule.forRoot()],
            providers: [HscActivityService, AuthorizationService,
                { provide: HealthServiceClient, useClass: MockHealthServiceClient },
                { provide: MemberCommunicationClient, useClass: MockMemberCommunicationClient },
            ]
        }).compile();

        service = module.get<HscActivityService>(HscActivityService);
        config = module.get<ConfigService>(ConfigService);
        httpService = module.get<HttpService>(HttpService);
    });

    it('should be defined', () => {
        expect(service).toBeDefined();
    });

    it('should call saveActivity', () => {
        let httpRequest: HttpRequest = { method: null, url: '/test?session_id=encryptedid', headers: { authorization: 'test token', 'x-hasura-role': 'testrole' }, query: { 'test': 'test' }, params: { 'test': 'test' } };
        const activityRequest: ActivityRequest = {
            "activity": {
                "hsc_id": 4567,
                "creat_user_id": "SYSTEM",
                "actv_typ_ref_id": 17777,
                "rslv_otcome_typ_id": 999,
                "hsr_sbj_rec_id": 111,
                "hsr_sbj_typ_ref_id": 222
            },
            "communication": {
                "mbr_cmnct_chnl_ref_id": 3244,
                "mbr_cmnct_sts_ref_id": 3456,
                "mbr_cmnct_dir_ref_id": 7654,
                "mbr_cmnct_typ_ref_id": 6787,
                "mbr_cmnct_catgy_ref_id": 8799,
                "mbr_cmnct_rsn_ref_id": 20090,
                "mbr_cmnct_sts_rsn_ref_id": 20066
            }
        };
        service.saveActivity(activityRequest, httpRequest).then((res) => {
            expect(res.hsr_actv_id).toEqual(45);
        });
    });

});

