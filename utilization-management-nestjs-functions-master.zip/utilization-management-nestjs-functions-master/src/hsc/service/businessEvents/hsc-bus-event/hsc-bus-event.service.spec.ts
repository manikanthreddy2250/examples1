import { Test, TestingModule } from '@nestjs/testing';
import { HttpRequest } from '@azure/functions';
import { HscConstants } from '../../../constants/hscConstants';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { GraphQLClient } from 'graphql-request/dist';
import { RequestDocument } from 'graphql-request/dist/types';
import { of } from 'rxjs';
import { HealthServiceClient } from '../../../../shared/graphql/healthservicedomain/healthServiceClient';
import { HttpModule, HttpService } from '@nestjs/common';
import { AxiosResponse } from 'axios';
import { HscBusinessEventService } from './hsc-bus-event.service';
import { HscBusEventName } from '../../../models/HscBusEventName';
import { BusinessEventRequest } from '../../../models/businessEventRequest';
import { HscBusEvent } from '../../../models/HscBusEvent';
import { AuthorizationService } from '@ecp/func-tk/dist';
import { EcpAuthenticatedUser } from '@ecp/func-tk/src/lib/authorization-services/models/EcpAuthenticatedUser';
import { GlobalConstants } from '../../../../shared/constants/globalConstants';
import {LoggerModule} from "nestjs-pino/dist";
import * as moment from 'moment';


jest.mock('axios');
jest.mock('@ecp/func-tk/dist');
class MockConfigService extends ConfigService {
  get(propertyPath: any) {
    if ('JWK_URI' == propertyPath) {
      return 'https://dev-ecp-api.optum.com/auth/oauth/jwks';
    } else if ('ISSUER' == propertyPath) {
      return 'ecp-dev';
    } else if ('BUS_EVENT_PUBLISH_API' == propertyPath) {
      return 'http://businesseventapiurl';
    } else if ('BUSINESS_EVENT_APPLICATION_ID' == propertyPath) {
      return 'applicationId';
    }
  }
}
class MockGraphQLClient extends GraphQLClient {
  request(
    document: RequestDocument,
    variables?: any,
    requestHeaders?: any,
  ): Promise<any> {
    if (variables.hscId == 1234) {
      return of({
        keys: {
          hsc_keys: [
            {
              hsc_key_val: '133fa864-a0d1-11eb-ad27-8e8a4e4bd3ec',
              hsc_key_typ_ref_id: 19517,
              hsc_key_typ_ref_cd: {
                ref_cd: 'BPMID',
                ref_dspl: 'BPM Work Flow Case ID',
              },
            },
            {
              hsc_key_val: '9a85062b-a0d1-11eb-a9bb-6ad13105d477',
              hsc_key_typ_ref_id: 72093,
              hsc_key_typ_ref_cd: {
                ref_cd: null,
                ref_dspl: 'Automated Clinical Case Validations',
              },
            },
          ],
        },
        data: {
          hsc_id: 17012,
          creat_dttm: '2021-04-18T18:05:31.419',
          creat_user_id: 'ecp_engineer',
          creat_sys_ref_id: null,
          chg_dttm: '2021-04-18T18:05:31.419',
          chg_user_id: 'ecp_engineer',
          chg_sys_ref_id: null,
          indv_key_typ_ref_id: 2757,
          indv_key_val: '16440436900',
          orig_sys_ref_id: null,
          hsc_sts_ref_id: 19275,
          hsc_sts_ref_cd: {
            ref_cd: '1',
            ref_dspl: 'Open',
          },
          hsc_sts_rsn_ref_id: null,
          hsc_sts_rsn_ref_cd: null,
          srvc_set_ref_id: 3737,
          srvc_set_ref_cd: {
            ref_cd: '1',
            ref_dspl: 'Inpatient',
          },
          rev_prr_ref_id: 3754,
          rev_prr_ref_cd: {
            ref_cd: '1',
            ref_dspl: 'Routine',
          },
          auth_typ_ref_id: null,
          auth_typ_ref_cd: null,
          hsc_rev_typ_ref_id: 20402,
          hsc_rev_typ_ref_cd: {
            ref_cd: 'generic',
            ref_dspl: 'Generic',
          },
          cont_of_care_ind: null,
          rev_prr_rsn_txt: null,
          auth_strt_dt: null,
          auth_end_dt: null,
          flwup_cntc_dtl: [
            {
              department: null,
              email: null,
              phone: '888-888-8888',
              fax: null,
              role: null,
              name: 'test',
              primaryContact: true,
            },
          ],
          mbr_cov_dtl: {
            indv_id: 503926748,
            pol_nbr: '0752023',
            cov_eff_dt: '2020-02-01',
            cov_end_dt: '9999-12-31',
            mbr_cov_id: 90881959,
            productCode: 226,
            indv_key_val: '16440436900',
            productCatgyTpe: null,
            coverageTypeDesc: 'Medical',
            indv_key_typ_ref_id: 2757,
            claim_platform_ref_Id: 363,
          },
          hsc_facls: [
            {
              adv_ntfy_trans_id: null,
              admis_ntfy_trans_id: null,
              dschrg_ntfy_trans_id: null,
              adv_ntfy_dttm: null,
              admis_ntfy_dttm: null,
              dschrg_ntfy_dttm: null,
              plsrv_ref_id: 3743,
              plsrv_ref_cd: {
                ref_cd: '21',
                ref_dspl: 'Acute Hospital',
              },
              srvc_dtl_ref_id: 4307,
              srvc_dtl_ref_cd: {
                ref_cd: '2',
                ref_dspl: 'Surgical',
              },
              srvc_desc_ref_id: 4347,
              srvc_desc_ref_cd: {
                ref_cd: '1',
                ref_dspl: 'Scheduled',
              },
              expt_admis_dt: '2021-04-19',
              expt_dschrg_dt: '2021-04-21',
              actul_admis_dttm: null,
              actul_dschrg_dttm: null,
              goal_los_day_cnt: null,
              dschrg_disp_ref_id: null,
              dschrg_disp_ref_cd: null,
              rem_snf_day_cnt: null,
              snf_day_xhst_ind: null,
              ipcm_typ_ref_id: null,
              ipcm_typ_ref_cd: null,
              ctp_nom_sts_ref_id: null,
              ctp_nom_sts_ref_cd: null,
              tat_due_dttm: null,
            },
          ],
          hsc_decns: [],
          hsc_provs: [
            {
              creat_dttm: '2021-04-18T18:06:02.435',
              creat_user_id: 'ecp_engineer',
              chg_dttm: '2021-04-18T18:06:02.435',
              chg_user_id: 'ecp_engineer',
              prov_loc_affil_dtl: {
                providerDetails: {
                  prov_id: 37697,
                  prov_keys: [
                    {
                      prov_key_val: null,
                      prov_key_typ_ref_id: 2782,
                    },
                    {
                      prov_key_val: '256556261',
                      prov_key_typ_ref_id: 16333,
                    },
                    {
                      prov_key_val: '2082298',
                      prov_key_typ_ref_id: 2783,
                    },
                  ],
                  prov_adr_id: 4004,
                  prov_cat_typ_ref_id: 16310,
                },
              },
              hsc_prov_roles: [
                {
                  prov_role_ref_cd: {
                    ref_cd: 'RF',
                    ref_dspl: 'Requesting',
                  },
                },
              ],
              provider: [
                {
                  prov_id: 37697,
                  prov_catgy_ref_id: 16310,
                  prov_keys: [
                    {
                      prov_key_val: '2082298',
                      prov_key_typ_ref_id: 2783,
                    },
                    {
                      prov_key_val: '256556261',
                      prov_key_typ_ref_id: 16333,
                    },
                    {
                      prov_key_val: 'EPIM7VZDVUEA5D5S7H8O',
                      prov_key_typ_ref_id: 16342,
                    },
                  ],
                  prov_indvs: [],
                  prov_orgs: [
                    {
                      bus_nm: 'DIVERSICARE GOOD SAMARITAN',
                      prov_org_typ_ref_id: null,
                    },
                  ],
                  prov_adrs: [
                    {
                      prov_adr_id: 4004,
                      adr_typ_ref_id: 16312,
                      adr_ln_1_txt: '3127 57th Ave N',
                      adr_ln_2_txt: null,
                      cty_nm: 'Saint Petersburg',
                      zip_cd_txt: '33714',
                      zip_sufx_cd_txt: '1320',
                      st_ref_id: 1072,
                    },
                    {
                      prov_adr_id: 4003,
                      adr_typ_ref_id: 16318,
                      adr_ln_1_txt: '3127 57th Ave N',
                      adr_ln_2_txt: null,
                      cty_nm: 'Saint Petersburg',
                      zip_cd_txt: '33714',
                      zip_sufx_cd_txt: '1320',
                      st_ref_id: 1072,
                    },
                  ],
                },
              ],
            },
            {
              creat_dttm: '2021-04-18T18:07:12.967',
              creat_user_id: 'ecp_engineer',
              chg_dttm: '2021-04-18T18:07:12.967',
              chg_user_id: 'ecp_engineer',
              prov_loc_affil_dtl: {
                providerDetails: {
                  prov_id: 37697,
                  prov_keys: [
                    {
                      prov_key_val: null,
                      prov_key_typ_ref_id: 2782,
                    },
                    {
                      prov_key_val: '256556261',
                      prov_key_typ_ref_id: 16333,
                    },
                    {
                      prov_key_val: '2082298',
                      prov_key_typ_ref_id: 2783,
                    },
                  ],
                  prov_adr_id: 4004,
                  prov_cat_typ_ref_id: 16310,
                },
              },
              hsc_prov_roles: [
                {
                  prov_role_ref_cd: {
                    ref_cd: 'SJ',
                    ref_dspl: 'Servicing',
                  },
                },
              ],
              provider: [
                {
                  prov_id: 37697,
                  prov_catgy_ref_id: 16310,
                  prov_keys: [
                    {
                      prov_key_val: '2082298',
                      prov_key_typ_ref_id: 2783,
                    },
                    {
                      prov_key_val: '256556261',
                      prov_key_typ_ref_id: 16333,
                    },
                    {
                      prov_key_val: 'EPIM7VZDVUEA5D5S7H8O',
                      prov_key_typ_ref_id: 16342,
                    },
                  ],
                  prov_indvs: [],
                  prov_orgs: [
                    {
                      bus_nm: 'DIVERSICARE GOOD SAMARITAN',
                      prov_org_typ_ref_id: null,
                    },
                  ],
                  prov_adrs: [
                    {
                      prov_adr_id: 4004,
                      adr_typ_ref_id: 16312,
                      adr_ln_1_txt: '3127 57th Ave N',
                      adr_ln_2_txt: null,
                      cty_nm: 'Saint Petersburg',
                      zip_cd_txt: '33714',
                      zip_sufx_cd_txt: '1320',
                      st_ref_id: 1072,
                    },
                    {
                      prov_adr_id: 4003,
                      adr_typ_ref_id: 16318,
                      adr_ln_1_txt: '3127 57th Ave N',
                      adr_ln_2_txt: null,
                      cty_nm: 'Saint Petersburg',
                      zip_cd_txt: '33714',
                      zip_sufx_cd_txt: '1320',
                      st_ref_id: 1072,
                    },
                  ],
                },
              ],
            },
          ],
          individual: [
            {
              indv_id: 503926748,
              fst_nm: 'Matt',
              lst_nm: 'Meyer',
              midl_nm: null,
              sufx_nm: null,
              bth_dt: '1978-07-26',
              gdr_ref_id: 2109,
              gdr_ref_cd: {
                ref_cd: 'M',
                ref_dspl: 'Male',
              },
              indv_keys: [
                {
                  indv_key_val: '503926748',
                  indv_key_typ_ref_id: 968,
                  indv_key_typ_ref_cd: {
                    ref_cd: 'SCR',
                    ref_dspl: 'subscriberId',
                  },
                },
                {
                  indv_key_val: '355749905',
                  indv_key_typ_ref_id: 973,
                  indv_key_typ_ref_cd: {
                    ref_cd: 'SSN',
                    ref_dspl: 'SSN',
                  },
                },
                {
                  indv_key_val: 'JAEGER_TEST_v3_16440436900',
                  indv_key_typ_ref_id: 2757,
                  indv_key_typ_ref_cd: {
                    ref_cd: null,
                    ref_dspl: 'SourceSysID',
                  },
                },
                {
                  indv_key_val: '16440436900',
                  indv_key_typ_ref_id: 2757,
                  indv_key_typ_ref_cd: {
                    ref_cd: null,
                    ref_dspl: 'SourceSysID',
                  },
                },
              ],
            },
          ],
          hsc_diags: [
            {
              creat_dttm: '2021-04-18T18:07:09.295',
              creat_user_id: 'ecp_engineer',
              chg_dttm: '2021-04-18T18:07:09.295',
              chg_user_id: 'ecp_engineer',
              diag_cd: 'B71.1',
              diag_othr_txt: null,
              diag_cd_schm_ref_id: null,
              diag_cd_schm_ref_cd: null,
              inac_ind: 0,
              pri_ind: 0,
            },
          ],
          hsc_srvcs: [],
          hsr_notes: [],
        },
      }).toPromise();
    } else if(variables.hscId == 123){
      return of({
        hsc: [{
          hsc_id: 123,
          creat_dttm: '2021-04-18T18:05:31.419',
          creat_user_id: 'ecp_engineer',
          creat_sys_ref_id: null,
          chg_dttm: '2021-04-18T18:05:31.419',
          chg_user_id: 'ecp_engineer',
          chg_sys_ref_id: null,
          indv_key_typ_ref_id: 2757,
          indv_key_val: '16440436900',
          orig_sys_ref_id: null,
          hsc_sts_ref_id: 19275,
          hsc_sts_ref_cd: {
            ref_cd: '1',
            ref_dspl: 'Open',
          },
          hsc_sts_rsn_ref_id: null,
          hsc_sts_rsn_ref_cd: null,
          srvc_set_ref_id: 3737,
          srvc_set_ref_cd: {
            ref_cd: '1',
            ref_dspl: 'Inpatient',
          },
          rev_prr_ref_id: 3754,
          rev_prr_ref_cd: {
            ref_cd: '1',
            ref_dspl: 'Routine',
          },
          auth_typ_ref_id: null,
          auth_typ_ref_cd: null,
          hsc_rev_typ_ref_id: 20402,
          hsc_rev_typ_ref_cd: {
            ref_cd: 'generic',
            ref_dspl: 'Generic',
          },
          cont_of_care_ind: null,
          rev_prr_rsn_txt: null,
          auth_strt_dt: null,
          auth_end_dt: null,
          flwup_cntc_dtl: [
            {
              department: null,
              email: null,
              phone: '888-888-8888',
              fax: null,
              role: null,
              name: 'test',
              primaryContact: true,
            },
          ],
          mbr_cov_dtl: {
            indv_id: 503926748,
            pol_nbr: '0752023',
            cov_eff_dt: '2020-02-01',
            cov_end_dt: '9999-12-31',
            mbr_cov_id: 90881959,
            productCode: 226,
            indv_key_val: '16440436900',
            productCatgyTpe: null,
            coverageTypeDesc: 'Medical',
            indv_key_typ_ref_id: 2757,
            claim_platform_ref_Id: 363,
          },
          hsc_facls: [
            {
              adv_ntfy_trans_id: null,
              admis_ntfy_trans_id: null,
              dschrg_ntfy_trans_id: null,
              adv_ntfy_dttm: null,
              admis_ntfy_dttm: null,
              dschrg_ntfy_dttm: null,
              plsrv_ref_id: 3743,
              plsrv_ref_cd: {
                ref_cd: '21',
                ref_dspl: 'Acute Hospital',
              },
              srvc_dtl_ref_id: 4307,
              srvc_dtl_ref_cd: {
                ref_cd: '2',
                ref_dspl: 'Surgical',
              },
              srvc_desc_ref_id: 4347,
              srvc_desc_ref_cd: {
                ref_cd: '1',
                ref_dspl: 'Scheduled',
              },
              expt_admis_dt: '2021-04-19',
              expt_dschrg_dt: '2021-04-21',
              actul_admis_dttm: null,
              actul_dschrg_dttm: null,
              goal_los_day_cnt: null,
              dschrg_disp_ref_id: null,
              dschrg_disp_ref_cd: null,
              rem_snf_day_cnt: null,
              snf_day_xhst_ind: null,
              ipcm_typ_ref_id: null,
              ipcm_typ_ref_cd: null,
              ctp_nom_sts_ref_id: null,
              ctp_nom_sts_ref_cd: null,
              tat_due_dttm: null,
            },
          ],
          hsc_decns: [],
          hsc_provs: [
            {
              creat_dttm: '2021-04-18T18:06:02.435',
              creat_user_id: 'ecp_engineer',
              chg_dttm: '2021-04-18T18:06:02.435',
              chg_user_id: 'ecp_engineer',
              prov_loc_affil_dtl: {
                providerDetails: {
                  prov_id: 37697,
                  prov_keys: [
                    {
                      prov_key_val: null,
                      prov_key_typ_ref_id: 2782,
                    },
                    {
                      prov_key_val: '256556261',
                      prov_key_typ_ref_id: 16333,
                    },
                    {
                      prov_key_val: '2082298',
                      prov_key_typ_ref_id: 2783,
                    },
                  ],
                  prov_adr_id: 4004,
                  prov_cat_typ_ref_id: 16310,
                },
              },
              hsc_prov_roles: [
                {
                  prov_role_ref_cd: {
                    ref_cd: 'RF',
                    ref_dspl: 'Requesting',
                  },
                },
              ],
              provider: [
                {
                  prov_id: 37697,
                  prov_catgy_ref_id: 16310,
                  prov_keys: [
                    {
                      prov_key_val: '2082298',
                      prov_key_typ_ref_id: 2783,
                    },
                    {
                      prov_key_val: '256556261',
                      prov_key_typ_ref_id: 16333,
                    },
                    {
                      prov_key_val: 'EPIM7VZDVUEA5D5S7H8O',
                      prov_key_typ_ref_id: 16342,
                    },
                  ],
                  prov_indvs: [],
                  prov_orgs: [
                    {
                      bus_nm: 'DIVERSICARE GOOD SAMARITAN',
                      prov_org_typ_ref_id: null,
                    },
                  ],
                  prov_adrs: [
                    {
                      prov_adr_id: 4004,
                      adr_typ_ref_id: 16312,
                      adr_ln_1_txt: '3127 57th Ave N',
                      adr_ln_2_txt: null,
                      cty_nm: 'Saint Petersburg',
                      zip_cd_txt: '33714',
                      zip_sufx_cd_txt: '1320',
                      st_ref_id: 1072,
                    },
                    {
                      prov_adr_id: 4003,
                      adr_typ_ref_id: 16318,
                      adr_ln_1_txt: '3127 57th Ave N',
                      adr_ln_2_txt: null,
                      cty_nm: 'Saint Petersburg',
                      zip_cd_txt: '33714',
                      zip_sufx_cd_txt: '1320',
                      st_ref_id: 1072,
                    },
                  ],
                },
              ],
            },
            {
              creat_dttm: '2021-04-18T18:07:12.967',
              creat_user_id: 'ecp_engineer',
              chg_dttm: '2021-04-18T18:07:12.967',
              chg_user_id: 'ecp_engineer',
              prov_loc_affil_dtl: {
                providerDetails: {
                  prov_id: 37697,
                  prov_keys: [
                    {
                      prov_key_val: null,
                      prov_key_typ_ref_id: 2782,
                    },
                    {
                      prov_key_val: '256556261',
                      prov_key_typ_ref_id: 16333,
                    },
                    {
                      prov_key_val: '2082298',
                      prov_key_typ_ref_id: 2783,
                    },
                  ],
                  prov_adr_id: 4004,
                  prov_cat_typ_ref_id: 16310,
                },
              },
              hsc_prov_roles: [
                {
                  prov_role_ref_cd: {
                    ref_cd: 'SJ',
                    ref_dspl: 'Servicing',
                  },
                },
              ],
              provider: [
                {
                  prov_id: 37697,
                  prov_catgy_ref_id: 16310,
                  prov_keys: [
                    {
                      prov_key_val: '2082298',
                      prov_key_typ_ref_id: 2783,
                    },
                    {
                      prov_key_val: '256556261',
                      prov_key_typ_ref_id: 16333,
                    },
                    {
                      prov_key_val: 'EPIM7VZDVUEA5D5S7H8O',
                      prov_key_typ_ref_id: 16342,
                    },
                  ],
                  prov_indvs: [],
                  prov_orgs: [
                    {
                      bus_nm: 'DIVERSICARE GOOD SAMARITAN',
                      prov_org_typ_ref_id: null,
                    },
                  ],
                  prov_adrs: [
                    {
                      prov_adr_id: 4004,
                      adr_typ_ref_id: 16312,
                      adr_ln_1_txt: '3127 57th Ave N',
                      adr_ln_2_txt: null,
                      cty_nm: 'Saint Petersburg',
                      zip_cd_txt: '33714',
                      zip_sufx_cd_txt: '1320',
                      st_ref_id: 1072,
                    },
                    {
                      prov_adr_id: 4003,
                      adr_typ_ref_id: 16318,
                      adr_ln_1_txt: '3127 57th Ave N',
                      adr_ln_2_txt: null,
                      cty_nm: 'Saint Petersburg',
                      zip_cd_txt: '33714',
                      zip_sufx_cd_txt: '1320',
                      st_ref_id: 1072,
                    },
                  ],
                },
              ],
            },
          ],
          individual: [
            {
              indv_id: 503926748,
              fst_nm: 'Matt',
              lst_nm: 'Meyer',
              midl_nm: null,
              sufx_nm: null,
              bth_dt: '1978-07-26',
              gdr_ref_id: 2109,
              gdr_ref_cd: {
                ref_cd: 'M',
                ref_dspl: 'Male',
              },
              indv_keys: [
                {
                  indv_key_val: '503926748',
                  indv_key_typ_ref_id: 968,
                  indv_key_typ_ref_cd: {
                    ref_cd: 'SCR',
                    ref_dspl: 'subscriberId',
                  },
                },
                {
                  indv_key_val: '355749905',
                  indv_key_typ_ref_id: 973,
                  indv_key_typ_ref_cd: {
                    ref_cd: 'SSN',
                    ref_dspl: 'SSN',
                  },
                },
                {
                  indv_key_val: 'JAEGER_TEST_v3_16440436900',
                  indv_key_typ_ref_id: 2757,
                  indv_key_typ_ref_cd: {
                    ref_cd: null,
                    ref_dspl: 'SourceSysID',
                  },
                },
                {
                  indv_key_val: '16440436900',
                  indv_key_typ_ref_id: 2757,
                  indv_key_typ_ref_cd: {
                    ref_cd: null,
                    ref_dspl: 'SourceSysID',
                  },
                },
              ],
            },
          ],
          hsc_diags: [
            {
              creat_dttm: '2021-04-18T18:07:09.295',
              creat_user_id: 'ecp_engineer',
              chg_dttm: '2021-04-18T18:07:09.295',
              chg_user_id: 'ecp_engineer',
              diag_cd: 'B71.1',
              diag_othr_txt: null,
              diag_cd_schm_ref_id: null,
              diag_cd_schm_ref_cd: null,
              inac_ind: 0,
              pri_ind: 0,
            },
          ],
          hsc_srvcs: [],
          hsr_notes: [],
        }]
      }).toPromise();
    } else {
      return of({
      }).toPromise();
    }
  }
}

class MockHealthServiceClient {
  public getGraphqlClient(httpRequest: HttpRequest): GraphQLClient {
    return new MockGraphQLClient('testurl');
  }
}
describe('HscBusinessEventService', () => {
  let service: HscBusinessEventService;
  let httpService: HttpService;
  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      imports: [LoggerModule.forRoot(), ConfigModule, HttpModule],
      providers: [
        HscBusinessEventService,
        { provide: ConfigService, useClass: MockConfigService },
        { provide: HealthServiceClient, useClass: MockHealthServiceClient },
      ],
    }).compile();

    service = module.get<HscBusinessEventService>(HscBusinessEventService);
    httpService = module.get<HttpService>(HttpService);
  });

  const ecpMockAuthenticatedUser: EcpAuthenticatedUser = {
    anonymous: false,
    firstName: 'mockuser',
    grantType: GlobalConstants.GRANT_TYPE_CLIENT,
  };

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('prepareHscBusinessEventRequest should return BusinessEventRequest', async () => {
    const createHscResponse: any = { hsc: { hsc_data: { hsc_id: 123 } } };
    // const currentDate = moment.utc().format();
    // const businessEventApplicationID = MockConfigService.get<string>('BUSINESS_EVENT_APPLICATION_ID');
    // const payloadTemp = JSON.parse(JSON.stringify(payload));
    // payloadTemp.hsc.event_name = eventName;
    // payloadTemp.hsc.event_squence_number = sequenceNumber;
    // ecp_engineer token with um_intake_uiclinician role
    const httpRequest: HttpRequest = {
      method: null,
      url: '/api/graphql',
      headers: {
        authorization:
          'eyJraWQiOiIzMTRjOGJhMi0zZTZmLTQzYjItODVmOS1iOGMyMTNhNzZjMGUiLCJhbGciOiJSUzUxMiJ9.eyJ4LWVjcC1jbGFpbXMiOnsieC1lY3AtYXR0cnMiOnt9LCJ4LWVjcC1hbHQtdXNlci1pZCI6ImVjcF9lbmdpbmVlciIsIngtZWNwLWNsaS1vcmdzIjpbeyJvcmctaWQiOiJlY3AiLCJmdW5jLXJvbGVzIjpbeyJyb2xlLW5hbWUiOiJlbmdpbmVlciIsImFwcGwtcm9sZXMiOlsiYXNtdF9tZ210X2RlbW9fd3JpdGUiLCJhc3Nlc3NtZW50X2J1aWxkZXJfd3JpdGUiLCJhc3Nlc3NtZW50X21nbXRfd3JpdGUiLCJiYXNlX3Byb2R1Y3RfYnBtX2dycF9kZXBsb3kiLCJiYXNlX3Byb2R1Y3RfZG1uX2dycF9kZXBsb3kiLCJiaF9kZW1vX3VzZXIiLCJjYXJlX3BsYW5fZGVtb193cml0ZSIsImNhc2Vfd2ZfbWdtdF91aV9hZG1pbiIsImNsaW5pY2FsX2d1aWRlbGluZXNfdWhjX2Rtbl9ncnBfZGVwbG95IiwiY2xpbmljYWxfZ3VpZGVsaW5lc191c2VyIiwiZGFzaGJvYXJkX3JlYWQiLCJkaXN0YW5jZV9tYXRyaXhfdXNlciIsImRtc19kZWxldGUiLCJpbmR2X2NhcmVfcGxhbl91c2VyIiwibWJyX21nbXRfZGVtb193cml0ZSIsIm1icl9tZ210X3dyaXRlIiwibWVkX21nbXRfd3JpdGUiLCJwZ21fYnVpbGRlcl91c2VyIiwicGxhbl9vZl9jYXJlX3VzZXIiLCJwcmFjdGljZV9tZ210X3JlYWQiLCJwcm9ncmFtX3JlZmVycmFsc190aGlyZF9wYXJ0eV9yZWFkIiwicHJvZ3JhbV9yZWZlcnJhbHNfdXNlciIsInByb3ZpZGVyX21hbmFnZW1lbnRfdXNlciIsInJlYWNoX3VpX3N0YXJ0ZXJfdXNlciIsInJ1bGVzX2F1dGhvcmluZ193cml0ZSIsInNjaGVkdWxpbmdfcGF0aWVudCIsInN5c3RlbV9tZ210X3VzZXIiLCJ0ZW1wbGF0ZV9hdXRoX3VpX3VzZXIiLCJ1bV9jYXNlX21nbXRfYmFzZV9icG1fZ3JwX2RlcGxveSIsInVtX2Nhc2VfbWdtdF9iYXNlX2Rtbl9ncnBfZGVwbG95IiwidW1faW50YWtlX2Jhc2VfcHJvZHVjdF9icG1fZ3JwX2RlcGxveSIsInVtX2ludGFrZV9iYXNlX3Byb2R1Y3RfZG1uX2dycF9kZXBsb3kiLCJ1bV9pbnRha2VfdWlfY2xpbmljaWFuIiwidmlydHVhbF92aXNpdF9wcmFjdGl0aW9uZXIiXX1dfV0sIngtZWNwLXR5cGUiOiJDTElFTlRfQ1JFREVOVElBTFMiLCJ4LWVjcC11c2VyLWlkIjoiZWNwX2VuZ2luZWVyIn0sImh0dHBzOlwvXC9oYXN1cmEuaW9cL2p3dFwvY2xhaW1zIjp7IngtaGFzdXJhLWRlZmF1bHQtcm9sZSI6ImFzbXRfbWdtdF9kZW1vX3dyaXRlIiwieC1oYXN1cmEtYXR0cnMiOiJ7IH0iLCJ4LWhhc3VyYS1jbGktb3JnIjoiZWNwIiwieC1oYXN1cmEtdXNlci1pZCI6ImVjcF9lbmdpbmVlciIsIngtaGFzdXJhLWZ1bmMtcm9sZSI6ImVuZ2luZWVyIiwieC1oYXN1cmEtYWxsb3dlZC1yb2xlcyI6WyJhc210X21nbXRfZGVtb193cml0ZSIsImFzc2Vzc21lbnRfYnVpbGRlcl93cml0ZSIsImFzc2Vzc21lbnRfbWdtdF93cml0ZSIsImJhc2VfcHJvZHVjdF9icG1fZ3JwX2RlcGxveSIsImJhc2VfcHJvZHVjdF9kbW5fZ3JwX2RlcGxveSIsImJoX2RlbW9fdXNlciIsImNhcmVfcGxhbl9kZW1vX3dyaXRlIiwiY2FzZV93Zl9tZ210X3VpX2FkbWluIiwiY2xpbmljYWxfZ3VpZGVsaW5lc191aGNfZG1uX2dycF9kZXBsb3kiLCJjbGluaWNhbF9ndWlkZWxpbmVzX3VzZXIiLCJkYXNoYm9hcmRfcmVhZCIsImRpc3RhbmNlX21hdHJpeF91c2VyIiwiZG1zX2RlbGV0ZSIsImluZHZfY2FyZV9wbGFuX3VzZXIiLCJtYnJfbWdtdF9kZW1vX3dyaXRlIiwibWJyX21nbXRfd3JpdGUiLCJtZWRfbWdtdF93cml0ZSIsInBnbV9idWlsZGVyX3VzZXIiLCJwbGFuX29mX2NhcmVfdXNlciIsInByYWN0aWNlX21nbXRfcmVhZCIsInByb2dyYW1fcmVmZXJyYWxzX3RoaXJkX3BhcnR5X3JlYWQiLCJwcm9ncmFtX3JlZmVycmFsc191c2VyIiwicHJvdmlkZXJfbWFuYWdlbWVudF91c2VyIiwicmVhY2hfdWlfc3RhcnRlcl91c2VyIiwicnVsZXNfYXV0aG9yaW5nX3dyaXRlIiwic2NoZWR1bGluZ19wYXRpZW50Iiwic3lzdGVtX21nbXRfdXNlciIsInRlbXBsYXRlX2F1dGhfdWlfdXNlciIsInVtX2Nhc2VfbWdtdF9iYXNlX2JwbV9ncnBfZGVwbG95IiwidW1fY2FzZV9tZ210X2Jhc2VfZG1uX2dycF9kZXBsb3kiLCJ1bV9pbnRha2VfYmFzZV9wcm9kdWN0X2JwbV9ncnBfZGVwbG95IiwidW1faW50YWtlX2Jhc2VfcHJvZHVjdF9kbW5fZ3JwX2RlcGxveSIsInVtX2ludGFrZV91aV9jbGluaWNpYW4iLCJ2aXJ0dWFsX3Zpc2l0X3ByYWN0aXRpb25lciJdfSwic2NvcGUiOiJvcGVuaWQiLCJpc3MiOiJlY3AtZGV2IiwiZXhwIjoxNjE1MjQ3ODg0LCJjbGllbnRfaWQiOiJlY3BfZW5naW5lZXIifQ.Ztfla2urwUwW4V5pEnX2v0AouMUzY7fh6FD_znfA4plbv4cYgTHs_tOx9-bQhP0bc-u-7TjzZlKliLHTE4QwsAR4vGgjYc6PVZqDkHolgatmbEduwc08XOZtsJip7wleZEaLZPEkChkqDOK2mxp8hpDJVYm6KOVdNrTqfz9b0EHGdNxkJBWFaNDbG9aL9rp6Vy3NdzPEdg5MJYcJbrJGuge8bkE15nXhPrn7E_YIy0wWymzKg4eTgmZ3c5acEK1kNQQbtU3RWhv_9uZvrKRMc04WGAiv6fRTEbAQSrCSJrb96QwrtLe3kNCgjsKjn6aO7sLTlMTw1QSsOXsIVUSXVQ',
        'x-hasura-role': 'um_intake_ui_clinician',
      },
      query: { test: 'test' },
      params: { test: 'test' },
    };
    jest
      .spyOn(AuthorizationService, 'getEcpAuthencatedUser')
      .mockImplementationOnce(() => of(ecpMockAuthenticatedUser).toPromise());
    const businessEventRequest: BusinessEventRequest = await service.prepareHscBusinessEventRequest(
      HscBusEventName.HSC_CREATE,
      createHscResponse,
      httpRequest,
        999
    );
    expect(businessEventRequest.event_name).toEqual(HscBusEventName.HSC_CREATE);
    expect(businessEventRequest.event_channel).toEqual(
      HscConstants.HSC_BUS_EVENT_API_CHANNEL,
    );
    expect(businessEventRequest.app_id).toEqual('applicationId');
    expect(businessEventRequest.payload[0].hsc.hsc_data.hsc_id).toEqual(123);
    expect(businessEventRequest.payload[0].hsc.event_name).toEqual(HscBusEventName.HSC_CREATE);
    expect(businessEventRequest.payload[0].hsc.event_squence_number).toEqual(999);
  });


  it('should prepare buildBaseHscPayload', async () => {
    const httpRequest: HttpRequest = {
      method: null,
      url: '/api/graphql',
      headers: {
        authorization:
          'eyJraWQiOiIzMTRjOGJhMi0zZTZmLTQzYjItODVmOS1iOGMyMTNhNzZjMGUiLCJhbGciOiJSUzUxMiJ9.eyJ4LWVjcC1jbGFpbXMiOnsieC1lY3AtYXR0cnMiOnt9LCJ4LWVjcC1hbHQtdXNlci1pZCI6ImVjcF9lbmdpbmVlciIsIngtZWNwLWNsaS1vcmdzIjpbeyJvcmctaWQiOiJlY3AiLCJmdW5jLXJvbGVzIjpbeyJyb2xlLW5hbWUiOiJlbmdpbmVlciIsImFwcGwtcm9sZXMiOlsiYXNtdF9tZ210X2RlbW9fd3JpdGUiLCJhc3Nlc3NtZW50X2J1aWxkZXJfd3JpdGUiLCJhc3Nlc3NtZW50X21nbXRfd3JpdGUiLCJiYXNlX3Byb2R1Y3RfYnBtX2dycF9kZXBsb3kiLCJiYXNlX3Byb2R1Y3RfZG1uX2dycF9kZXBsb3kiLCJiaF9kZW1vX3VzZXIiLCJjYXJlX3BsYW5fZGVtb193cml0ZSIsImNhc2Vfd2ZfbWdtdF91aV9hZG1pbiIsImNsaW5pY2FsX2d1aWRlbGluZXNfdWhjX2Rtbl9ncnBfZGVwbG95IiwiY2xpbmljYWxfZ3VpZGVsaW5lc191c2VyIiwiZGFzaGJvYXJkX3JlYWQiLCJkaXN0YW5jZV9tYXRyaXhfdXNlciIsImRtc19kZWxldGUiLCJpbmR2X2NhcmVfcGxhbl91c2VyIiwibWJyX21nbXRfZGVtb193cml0ZSIsIm1icl9tZ210X3dyaXRlIiwibWVkX21nbXRfd3JpdGUiLCJwZ21fYnVpbGRlcl91c2VyIiwicGxhbl9vZl9jYXJlX3VzZXIiLCJwcmFjdGljZV9tZ210X3JlYWQiLCJwcm9ncmFtX3JlZmVycmFsc190aGlyZF9wYXJ0eV9yZWFkIiwicHJvZ3JhbV9yZWZlcnJhbHNfdXNlciIsInByb3ZpZGVyX21hbmFnZW1lbnRfdXNlciIsInJlYWNoX3VpX3N0YXJ0ZXJfdXNlciIsInJ1bGVzX2F1dGhvcmluZ193cml0ZSIsInNjaGVkdWxpbmdfcGF0aWVudCIsInN5c3RlbV9tZ210X3VzZXIiLCJ0ZW1wbGF0ZV9hdXRoX3VpX3VzZXIiLCJ1bV9jYXNlX21nbXRfYmFzZV9icG1fZ3JwX2RlcGxveSIsInVtX2Nhc2VfbWdtdF9iYXNlX2Rtbl9ncnBfZGVwbG95IiwidW1faW50YWtlX2Jhc2VfcHJvZHVjdF9icG1fZ3JwX2RlcGxveSIsInVtX2ludGFrZV9iYXNlX3Byb2R1Y3RfZG1uX2dycF9kZXBsb3kiLCJ1bV9pbnRha2VfdWlfY2xpbmljaWFuIiwidmlydHVhbF92aXNpdF9wcmFjdGl0aW9uZXIiXX1dfV0sIngtZWNwLXR5cGUiOiJDTElFTlRfQ1JFREVOVElBTFMiLCJ4LWVjcC11c2VyLWlkIjoiZWNwX2VuZ2luZWVyIn0sImh0dHBzOlwvXC9oYXN1cmEuaW9cL2p3dFwvY2xhaW1zIjp7IngtaGFzdXJhLWRlZmF1bHQtcm9sZSI6ImFzbXRfbWdtdF9kZW1vX3dyaXRlIiwieC1oYXN1cmEtYXR0cnMiOiJ7IH0iLCJ4LWhhc3VyYS1jbGktb3JnIjoiZWNwIiwieC1oYXN1cmEtdXNlci1pZCI6ImVjcF9lbmdpbmVlciIsIngtaGFzdXJhLWZ1bmMtcm9sZSI6ImVuZ2luZWVyIiwieC1oYXN1cmEtYWxsb3dlZC1yb2xlcyI6WyJhc210X21nbXRfZGVtb193cml0ZSIsImFzc2Vzc21lbnRfYnVpbGRlcl93cml0ZSIsImFzc2Vzc21lbnRfbWdtdF93cml0ZSIsImJhc2VfcHJvZHVjdF9icG1fZ3JwX2RlcGxveSIsImJhc2VfcHJvZHVjdF9kbW5fZ3JwX2RlcGxveSIsImJoX2RlbW9fdXNlciIsImNhcmVfcGxhbl9kZW1vX3dyaXRlIiwiY2FzZV93Zl9tZ210X3VpX2FkbWluIiwiY2xpbmljYWxfZ3VpZGVsaW5lc191aGNfZG1uX2dycF9kZXBsb3kiLCJjbGluaWNhbF9ndWlkZWxpbmVzX3VzZXIiLCJkYXNoYm9hcmRfcmVhZCIsImRpc3RhbmNlX21hdHJpeF91c2VyIiwiZG1zX2RlbGV0ZSIsImluZHZfY2FyZV9wbGFuX3VzZXIiLCJtYnJfbWdtdF9kZW1vX3dyaXRlIiwibWJyX21nbXRfd3JpdGUiLCJtZWRfbWdtdF93cml0ZSIsInBnbV9idWlsZGVyX3VzZXIiLCJwbGFuX29mX2NhcmVfdXNlciIsInByYWN0aWNlX21nbXRfcmVhZCIsInByb2dyYW1fcmVmZXJyYWxzX3RoaXJkX3BhcnR5X3JlYWQiLCJwcm9ncmFtX3JlZmVycmFsc191c2VyIiwicHJvdmlkZXJfbWFuYWdlbWVudF91c2VyIiwicmVhY2hfdWlfc3RhcnRlcl91c2VyIiwicnVsZXNfYXV0aG9yaW5nX3dyaXRlIiwic2NoZWR1bGluZ19wYXRpZW50Iiwic3lzdGVtX21nbXRfdXNlciIsInRlbXBsYXRlX2F1dGhfdWlfdXNlciIsInVtX2Nhc2VfbWdtdF9iYXNlX2JwbV9ncnBfZGVwbG95IiwidW1fY2FzZV9tZ210X2Jhc2VfZG1uX2dycF9kZXBsb3kiLCJ1bV9pbnRha2VfYmFzZV9wcm9kdWN0X2JwbV9ncnBfZGVwbG95IiwidW1faW50YWtlX2Jhc2VfcHJvZHVjdF9kbW5fZ3JwX2RlcGxveSIsInVtX2ludGFrZV91aV9jbGluaWNpYW4iLCJ2aXJ0dWFsX3Zpc2l0X3ByYWN0aXRpb25lciJdfSwic2NvcGUiOiJvcGVuaWQiLCJpc3MiOiJlY3AtZGV2IiwiZXhwIjoxNjE1MjQ3ODg0LCJjbGllbnRfaWQiOiJlY3BfZW5naW5lZXIifQ.Ztfla2urwUwW4V5pEnX2v0AouMUzY7fh6FD_znfA4plbv4cYgTHs_tOx9-bQhP0bc-u-7TjzZlKliLHTE4QwsAR4vGgjYc6PVZqDkHolgatmbEduwc08XOZtsJip7wleZEaLZPEkChkqDOK2mxp8hpDJVYm6KOVdNrTqfz9b0EHGdNxkJBWFaNDbG9aL9rp6Vy3NdzPEdg5MJYcJbrJGuge8bkE15nXhPrn7E_YIy0wWymzKg4eTgmZ3c5acEK1kNQQbtU3RWhv_9uZvrKRMc04WGAiv6fRTEbAQSrCSJrb96QwrtLe3kNCgjsKjn6aO7sLTlMTw1QSsOXsIVUSXVQ',
        'x-hasura-role': 'um_intake_ui_clinician',
      },
      query: { test: 'test' },
      params: { test: 'test' },
    };

    service.buildBaseHscPayload(123, httpRequest).then((res) => {
      expect(res.hsc[0].hsc_id).toEqual(123);
    });
  });

  it('should call buildErrorMessage', async () => {
    const error = {
      message: "error",
      response: {
        status: "fail",
        statusText: "failed builPayload",
        data: {
          message: "failed data"
        }
      }
    };
    service.buildErrorMessage(error);
  });


  it('publishHscCreateBusinessEvent should call BUS_EVENT_PUBLISH_API', async () => {
    const axiosResponse: AxiosResponse = {
      data: [],
      status: 200,
      statusText: 'OK',
      headers: {},
      config: {},
    };
    jest
      .spyOn(httpService, 'post')
      .mockImplementationOnce(() => of(axiosResponse));
    jest
      .spyOn(AuthorizationService, 'getEcpAuthencatedUser')
      .mockImplementationOnce(() => of(ecpMockAuthenticatedUser).toPromise());
    const httpRequest: HttpRequest = {
      method: null,
      url: '/test?session_id=encryptedid',
      headers: { authorization: 'test token', 'x-hasura-role': 'testrole' },
      query: { test: 'test' },
      params: { test: 'test' },
    };
    const eventList: HscBusEvent[] = [
      {
        eventName: HscBusEventName.HSC_UPDATE,
        payload: { hsc: { hsc_data: { hsc_id: 123 } } },
      },
      {
        eventName: HscBusEventName.HSC_DIAGNOSIS_UPDATE,
        payload: { hsc: { hsc_data: { hsc_id: 123 } } },
      },
    ];
    service.pushHscBusinessEvents(eventList, httpRequest).then((res) => {
      expect(
        AuthorizationService.getEcpAuthencatedUser('token', 'uri', 'issuer'),
      ).toBeCalledTimes(eventList.length);
      expect(httpService.post('http://businesseventapiurl')).toBeCalledTimes(
        eventList.length,
      );
    });
  });
});
