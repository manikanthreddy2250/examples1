import { HttpService, Injectable } from '@nestjs/common';
import { HttpRequest } from '@azure/functions';
import { AuthorizationService } from '@ecp/func-tk/dist';
import { ConfigService } from '@nestjs/config';
import { HscConstants } from '../../../constants/hscConstants';
import { GlobalConstants } from '../../../../shared/constants/globalConstants';
import { getHscDetails } from '../../../../shared/graphql/healthservicedomain/healthServiceQuery';
import { BusinessEventRequest } from '../../../models/businessEventRequest';
import { HealthServiceClient } from '../../../../shared/graphql/healthservicedomain/healthServiceClient';
import { GraphQLClient } from 'graphql-request/dist';
import { HscBusEventName } from '../../../models/HscBusEventName';
import { HscBusEvent } from '../../../models/HscBusEvent';
import {InjectPinoLogger, PinoLogger} from 'nestjs-pino/dist';
import * as moment from 'moment';
import {err} from "pino-std-serializers";

@Injectable()
export class HscBusinessEventService {
  constructor(
      @InjectPinoLogger(HscBusinessEventService.name) private readonly logger: PinoLogger,
    private readonly configService: ConfigService,
    private readonly healthServiceClient: HealthServiceClient,
    private readonly httpService: HttpService,
  ) {}

  async pushHscBusinessEvents(
      eventList: HscBusEvent[],
      httpRequest: HttpRequest,
  ) {
    if (eventList.length > 0) {
      let eventSequenceNumber = 0;
      for (const event of eventList) {
        const businessEventRequest: BusinessEventRequest = await this.prepareHscBusinessEventRequest(
            event.eventName,
            event.payload,
            httpRequest,
            eventSequenceNumber
        );
        //this.logger.error('pushHscBusinessEvents.post.start::' + event.eventName);
        // this.logger.error('pushHscBusinessEvents.post.requestContent.' + event.eventName + '::' + JSON.stringify(businessEventRequest));
        await this.httpService
            .post(
                this.configService.get<string>('BUS_EVENT_PUBLISH_API'),
                businessEventRequest,
                {
                  headers: { Authorization: httpRequest.headers['authorization'] },
                },
            ).toPromise().catch((err : any)=> {
              // note that the event service returns a 400 response when they receive a request with a duplicative payload
              const statusMessage = this.buildErrorMessage(err);
              // this.logger.error('pushHscBusinessEvents.post.error.message::' + statusMessage);
              // this.logger.error('pushHscBusinessEvents.post.error.requestContent.' + event.eventName + '::' + JSON.stringify(businessEventRequest));
            });
        // this.logger.error('pushHscBusinessEvents.post.end::' + event.eventName);
        eventSequenceNumber++;
      }
    }
  }

  async prepareHscBusinessEventRequest(
    eventName: HscBusEventName,
    payload: any,
    httpRequest: HttpRequest,
    sequenceNumber: number
  ): Promise<BusinessEventRequest> {
    const ecpAuthenticatedUser = await AuthorizationService.getEcpAuthencatedUser(
      httpRequest.headers.authorization,
      this.configService.get<string>('JWK_URI'),
      this.configService.get<string>('ISSUER'),
    );
    const currentDate = moment.utc().format();
    const businessEventApplicationID = this.configService.get<string>('BUSINESS_EVENT_APPLICATION_ID');
    const payloadTemp = JSON.parse(JSON.stringify(payload));
    payloadTemp.hsc.event_name = eventName;
    payloadTemp.hsc.event_squence_number = sequenceNumber;
    const businessEventRequest: BusinessEventRequest = {
      event_name: eventName,
      // event_date_time: payload.hsc.hsc_data.chg_dttm,
      event_date_time: currentDate,
      event_source: 'OCM', // TODO review
      event_channel:
        GlobalConstants.GRANT_TYPE_CLIENT === ecpAuthenticatedUser.grantType
          ? HscConstants.HSC_BUS_EVENT_API_CHANNEL
          : HscConstants.HSC_BUS_EVENT_WEB_CHANNEL,
      app_id: businessEventApplicationID,
      payload: [payloadTemp],
    };
    return businessEventRequest;
  }

  async buildBaseHscPayload(
    hsc_id: number,
    httpRequest: HttpRequest,
  ): Promise<any> {
    const hscGraphqlClient: GraphQLClient = this.healthServiceClient.getGraphqlClient(
      httpRequest,
    );
    this.logger.info("Before query (getHscAuthorization) to health service domain from buildBaseHscPayload for hsc_id : " +hsc_id+ " at: "+ new Date());
    const hscResponse = await hscGraphqlClient.request(getHscDetails, {
      hscId: hsc_id,
    });
    this.logger.info("After query (getHscAuthorization) to health service domain from buildBaseHscPayload for hsc_id : " +hsc_id+ " at: "+ new Date());
    const hsc = hscResponse.hsc[0];
    const individualData = hsc.individual.find(
      (indv) => indv.indv_id == hsc.indv_id,
    );
    const hscPayload: any = {
      ...hsc,
      individual: { ...individualData },
    };
    hscPayload.individual.mbr_cov_dtl = hscPayload.mbr_cov_dtl;
    const hsc_keys: [] = hscPayload.hsc_keys;
    delete hscPayload.hsc_keys;
    delete hscPayload.mbr_cov_dtl;
    const hscBasePayload: any = {
      hsc: {
        hsc_keys: [...hsc_keys],
        hsc_data: {
          ...hscPayload,
        },
      },
    };
    return hscBasePayload;
  }

  buildErrorMessage(error: any) {
    let errorMessage = '';
    if (error != null) {
      if (error.message != null) {
        errorMessage = errorMessage + 'Message::' + error.message;
      }
      if (error.response != null) {
        if (error.response.status != null) {
          if (errorMessage.length > 0) {
            errorMessage = errorMessage + '  /  ';
          }
          errorMessage = errorMessage + 'Status::' + error.response.status;
        }
        if (error.response.statusText != null) {
          if (errorMessage.length > 0) {
            errorMessage = errorMessage + '  /  ';
          }
          errorMessage = errorMessage + 'Status Text::' + error.response.statusText;
        }
        if (error.response.data != null) {
          if (errorMessage.length > 0) {
            errorMessage = errorMessage + '  /  ';
          }
          errorMessage = errorMessage + 'Response Data::' + error.response.data.message;
        }
      }
    }
    return errorMessage;
  }

}
