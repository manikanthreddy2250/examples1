import { Test, TestingModule } from '@nestjs/testing';
import { HscService } from './hsc.service';
import {ConfigService,ConfigModule} from "@nestjs/config";
import {CreateHscMapper} from "../../mapper/createHsc.mapper";
import {HttpRequest} from "@azure/functions";
import {GraphQLClient} from "graphql-request/dist";
import {RequestDocument} from "graphql-request/dist/types";
import {of} from "rxjs";
import {HealthServiceClient} from "../../../shared/graphql/healthservicedomain/healthServiceClient";
import {ProviderService} from "../provider.service";
import {MemberClient} from "../../../shared/graphql/memberdomain/memberClient";
import {HttpModule, HttpService, Logger} from "@nestjs/common";
import {ProviderClient} from "../../../shared/graphql/providerdomain/providerClient";
import {CreateHscRequestInput} from "../../models/createHscRequest.input";
import {HscProvInput} from "../../models/hscProv.input";
import { AuthorizationService } from '@ecp/func-tk/dist';
import { AxiosResponse } from 'axios';
import {IndividualClient} from "../../../shared/graphql/individualdomain/individualClient";
import {MemberService} from "../member/member.service";
import {HscInput} from "../../models/hsc.input";
import {HscBusEvent} from "../../models/HscBusEvent";
import {HscBusinessEventService} from "../businessEvents/hsc-bus-event/hsc-bus-event.service";
import {LoggerModule, PinoLogger} from "nestjs-pino/dist";
import {MemberCommunicationClient} from "../../../shared/graphql/communication-domain/memberCommunicationClient";

jest.mock("axios");

class MockGraphQLClient extends GraphQLClient {
    request(document: RequestDocument, variables?: any, requestHeaders?: any): Promise<any> {
        if (variables.hscSrvcs) {
            return of({
                "insert_hsc_srvc": {
                    "affected_rows": 5,
                    "returning": [
                        {
                            "hsc_id": 13469,
                            "hsc_srvc_id": 12689,
                            "inac_ind": 0,
                            "proc_cd": "81099",
                            "proc_cd_schm_ref_id": 2,
                            "proc_othr_txt": null,
                            "srvc_hsc_prov_id": 5509,
                        }
                    ]
                }
            }).toPromise();
        } else if (variables.hscId) {
            return of({
                "hsc": [
                    {
                        "hsc_id": 17012,
                        "creat_dttm": "2021-04-18T18:05:31.419",
                        "creat_user_id": "ecp_engineer",
                        "creat_sys_ref_id": null,
                        "chg_dttm": "2021-04-18T18:05:31.419",
                        "chg_user_id": "ecp_engineer",
                        "chg_sys_ref_id": null,
                        "hsc_sts_ref_id": 19275,
                        "hsc_sts_ref_cd": {
                            "ref_cd": "1",
                            "ref_dspl": "Open"
                        },
                        "hsc_sts_rsn_ref_id": null,
                        "hsc_sts_rsn_ref_cd": null,
                        "srvc_set_ref_id": 3737,
                        "srvc_set_ref_cd": {
                            "ref_cd": "1",
                            "ref_dspl": "Inpatient"
                        },
                        "rev_prr_ref_id": 3754,
                        "rev_prr_ref_cd": {
                            "ref_cd": "1",
                            "ref_dspl": "Routine"
                        },
                        "auth_typ_ref_id": null,
                        "auth_typ_ref_cd": null,
                        "hsc_rev_typ_ref_id": 20402,
                        "hsc_rev_typ_ref_cd": {
                            "ref_cd": "generic",
                            "ref_dspl": "Generic"
                        },
                        "cont_of_care_ind": null,
                        "rev_prr_rsn_txt": null,
                        "auth_strt_dt": null,
                        "auth_end_dt": null,
                        "flwup_cntc_dtl": [{
                                "department": null,
                                "email": null,
                                "phone": "888-888-8888",
                                "fax": null,
                                "role": null,
                                "name": "test",
                                "primaryContact": true,
                            }],
                        "mbr_cov_dtl": {
                            "indv_id": 503926748,
                            "pol_nbr": "0752023",
                            "cov_eff_dt": "2020-02-01",
                            "cov_end_dt": "9999-12-31",
                            "mbr_cov_id": 90881959,
                            "productCode": 226,
                            "indv_key_val": "16440436900",
                            "productCatgyTpe": null,
                            "coverageTypeDesc": "Medical",
                            "indv_key_typ_ref_id": 2757,
                            "claim_platform_ref_Id": 363
                        },
                        "hsc_facls": [
                            {
                                "adv_ntfy_trans_id": null,
                                "admis_ntfy_trans_id": null,
                                "dschrg_ntfy_trans_id": null,
                                "adv_ntfy_dttm": null,
                                "admis_ntfy_dttm": null,
                                "dschrg_ntfy_dttm": null,
                                "plsrv_ref_id": 3743,
                                "plsrv_ref_cd": {
                                    "ref_cd": "21",
                                    "ref_dspl": "Acute Hospital"
                                },
                                "srvc_dtl_ref_id": 4307,
                                "srvc_dtl_ref_cd": {
                                    "ref_cd": "2",
                                    "ref_dspl": "Surgical"
                                },
                                "srvc_desc_ref_id": 4347,
                                "srvc_desc_ref_cd": {
                                    "ref_cd": "1",
                                    "ref_dspl": "Scheduled"
                                },
                                "expt_admis_dt": "2021-04-19",
                                "expt_dschrg_dt": "2021-04-21",
                                "actul_admis_dttm": null,
                                "actul_dschrg_dttm": null,
                                "goal_los_day_cnt": null,
                                "dschrg_disp_ref_id": null,
                                "dschrg_disp_ref_cd": null,
                                "rem_snf_day_cnt": null,
                                "snf_day_xhst_ind": null,
                                "ipcm_typ_ref_id": null,
                                "ipcm_typ_ref_cd": null,
                                "ctp_nom_sts_ref_id": null,
                                "ctp_nom_sts_ref_cd": null,
                                "tat_due_dttm": null
                            }
                        ],
                        "hsc_decns": [],
                        "hsc_provs": [
                            {
                                "creat_dttm": "2021-04-18T18:06:02.435",
                                "creat_user_id": "ecp_engineer",
                                "chg_dttm": "2021-04-18T18:06:02.435",
                                "chg_user_id": "ecp_engineer",
                                "prov_loc_affil_dtl": {
                                    "providerDetails": {
                                        "prov_id": 37697,
                                        "prov_keys": [
                                            {
                                                "prov_key_val": null,
                                                "prov_key_typ_ref_id": 2782
                                            },
                                            {
                                                "prov_key_val": "256556261",
                                                "prov_key_typ_ref_id": 16333
                                            },
                                            {
                                                "prov_key_val": "2082298",
                                                "prov_key_typ_ref_id": 2783
                                            }
                                        ],
                                        "prov_adr_id": 4004,
                                        "prov_cat_typ_ref_id": 16310
                                    }
                                },
                                "hsc_prov_roles": [
                                    {
                                        "prov_role_ref_cd": {
                                            "ref_cd": "RF",
                                            "ref_dspl": "Requesting"
                                        }
                                    }
                                ],
                                "provider": [
                                    {
                                        "prov_id": 37697,
                                        "prov_catgy_ref_id": 16310,
                                        "prov_keys": [
                                            {
                                                "prov_key_val": "2082298",
                                                "prov_key_typ_ref_id": 2783
                                            },
                                            {
                                                "prov_key_val": "256556261",
                                                "prov_key_typ_ref_id": 16333
                                            },
                                            {
                                                "prov_key_val": "EPIM7VZDVUEA5D5S7H8O",
                                                "prov_key_typ_ref_id": 16342
                                            }
                                        ],
                                        "prov_indvs": [],
                                        "prov_orgs": [
                                            {
                                                "bus_nm": "DIVERSICARE GOOD SAMARITAN",
                                                "prov_org_typ_ref_id": null
                                            }
                                        ],
                                        "prov_adrs": [
                                            {
                                                "prov_adr_id": 4004,
                                                "adr_typ_ref_id": 16312,
                                                "adr_ln_1_txt": "3127 57th Ave N",
                                                "adr_ln_2_txt": null,
                                                "cty_nm": "Saint Petersburg",
                                                "zip_cd_txt": "33714",
                                                "zip_sufx_cd_txt": "1320",
                                                "st_ref_id": 1072
                                            },
                                            {
                                                "prov_adr_id": 4003,
                                                "adr_typ_ref_id": 16318,
                                                "adr_ln_1_txt": "3127 57th Ave N",
                                                "adr_ln_2_txt": null,
                                                "cty_nm": "Saint Petersburg",
                                                "zip_cd_txt": "33714",
                                                "zip_sufx_cd_txt": "1320",
                                                "st_ref_id": 1072
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "creat_dttm": "2021-04-18T18:07:12.967",
                                "creat_user_id": "ecp_engineer",
                                "chg_dttm": "2021-04-18T18:07:12.967",
                                "chg_user_id": "ecp_engineer",
                                "prov_loc_affil_dtl": {
                                    "providerDetails": {
                                        "prov_id": 37697,
                                        "prov_keys": [
                                            {
                                                "prov_key_val": null,
                                                "prov_key_typ_ref_id": 2782
                                            },
                                            {
                                                "prov_key_val": "256556261",
                                                "prov_key_typ_ref_id": 16333
                                            },
                                            {
                                                "prov_key_val": "2082298",
                                                "prov_key_typ_ref_id": 2783
                                            }
                                        ],
                                        "prov_adr_id": 4004,
                                        "prov_cat_typ_ref_id": 16310
                                    }
                                },
                                "hsc_prov_roles": [
                                    {
                                        "prov_role_ref_cd": {
                                            "ref_cd": "SJ",
                                            "ref_dspl": "Servicing"
                                        }
                                    }
                                ],
                                "provider": [
                                    {
                                        "prov_id": 37697,
                                        "prov_catgy_ref_id": 16310,
                                        "prov_keys": [
                                            {
                                                "prov_key_val": "2082298",
                                                "prov_key_typ_ref_id": 2783
                                            },
                                            {
                                                "prov_key_val": "256556261",
                                                "prov_key_typ_ref_id": 16333
                                            },
                                            {
                                                "prov_key_val": "EPIM7VZDVUEA5D5S7H8O",
                                                "prov_key_typ_ref_id": 16342
                                            }
                                        ],
                                        "prov_indvs": [],
                                        "prov_orgs": [
                                            {
                                                "bus_nm": "DIVERSICARE GOOD SAMARITAN",
                                                "prov_org_typ_ref_id": null
                                            }
                                        ],
                                        "prov_adrs": [
                                            {
                                                "prov_adr_id": 4004,
                                                "adr_typ_ref_id": 16312,
                                                "adr_ln_1_txt": "3127 57th Ave N",
                                                "adr_ln_2_txt": null,
                                                "cty_nm": "Saint Petersburg",
                                                "zip_cd_txt": "33714",
                                                "zip_sufx_cd_txt": "1320",
                                                "st_ref_id": 1072
                                            },
                                            {
                                                "prov_adr_id": 4003,
                                                "adr_typ_ref_id": 16318,
                                                "adr_ln_1_txt": "3127 57th Ave N",
                                                "adr_ln_2_txt": null,
                                                "cty_nm": "Saint Petersburg",
                                                "zip_cd_txt": "33714",
                                                "zip_sufx_cd_txt": "1320",
                                                "st_ref_id": 1072
                                            }
                                        ]
                                    }
                                ]
                            }
                        ],
                        "individual": [
                            {
                                "indv_id": 503926748,
                                "fst_nm": "Matt",
                                "lst_nm": "Meyer",
                                "midl_nm": null,
                                "sufx_nm": null,
                                "bth_dt": "1978-07-26",
                                "gdr_ref_id": 2109,
                                "gdr_ref_cd": {
                                    "ref_cd": "M",
                                    "ref_dspl": "Male"
                                },
                                "indv_keys": [
                                    {
                                        "indv_key_val": "503926748",
                                        "indv_key_typ_ref_id": 968,
                                        "indv_key_typ_ref_cd": {
                                            "ref_cd": "SCR",
                                            "ref_dspl": "subscriberId"
                                        }
                                    },
                                    {
                                        "indv_key_val": "355749905",
                                        "indv_key_typ_ref_id": 973,
                                        "indv_key_typ_ref_cd": {
                                            "ref_cd": "SSN",
                                            "ref_dspl": "SSN"
                                        }
                                    },
                                    {
                                        "indv_key_val": "JAEGER_TEST_v3_16440436900",
                                        "indv_key_typ_ref_id": 2757,
                                        "indv_key_typ_ref_cd": {
                                            "ref_cd": null,
                                            "ref_dspl": "SourceSysID"
                                        }
                                    },
                                    {
                                        "indv_key_val": "16440436900",
                                        "indv_key_typ_ref_id": 2757,
                                        "indv_key_typ_ref_cd": {
                                            "ref_cd": null,
                                            "ref_dspl": "SourceSysID"
                                        }
                                    }
                                ]
                            }
                        ],
                        "hsc_diags": [
                            {
                                "creat_dttm": "2021-04-18T18:07:09.295",
                                "creat_user_id": "ecp_engineer",
                                "chg_dttm": "2021-04-18T18:07:09.295",
                                "chg_user_id": "ecp_engineer",
                                "diag_cd": "B71.1",
                                "diag_othr_txt": null,
                                "diag_cd_schm_ref_id": null,
                                "diag_cd_schm_ref_cd": null,
                                "inac_ind": 0,
                                "pri_ind": 0
                            }
                        ],
                        "hsc_srvcs": [],
                        "hsc_keys": [
                            {
                                "hsc_key_val": "a9204e66-a070-11eb-ad27-8e8a4e4bd3ec",
                                "hsc_key_typ_ref_id": 19517,
                                "hsc_key_typ_ref_cd": {
                                    "ref_cd": "BPMID",
                                    "ref_dspl": "BPM Work Flow Case ID"
                                }
                            },
                            {
                                "hsc_key_val": "f4481d67-a070-11eb-a9bb-6ad13105d477",
                                "hsc_key_typ_ref_id": 72093,
                                "hsc_key_typ_ref_cd": {
                                    "ref_cd": null,
                                    "ref_dspl": "Automated Clinical Case Validations"
                                }
                            }
                        ],
                        "hsr_notes": []
                    }
                ]
            }).toPromise();
        } else if(variables.hsc_id) {
            return of({
                "hsc": [
                    {
                        "hsc_id": 14254,
                        "hsc_sts_ref_id": 19274,
                        "hsc_sts_ref_cd": {
                            "ref_dspl": "Draft"
                        },
                        "rev_prr_ref_id": 3754,
                        "rev_prr_ref_cd": {
                            "ref_dspl": "Routine"
                        },
                        "srvc_set_ref_id": 3738,
                        "srvc_set_ref_cd": {
                            "ref_dspl": "Outpatient"
                        },
                        "plsrv_ref_id": 3743,
                        "plsrv_ref_cd": {
                            "ref_dspl": "Acute Hospital"
                        },
                        "srvc_desc_ref_id": 4347,
                        "srvc_desc_ref_cd": {
                            "ref_dspl": "Scheduled"
                        },
                        "srvc_dtl_ref_id": 4296,
                        "srvc_dtl_ref_cd": {
                            "ref_dspl": "Medical"
                        },
                        "actul_admis_dttm": null,
                        "actul_dschrg_dttm": null,
                        "expt_admis_dt": "2021-03-02",
                        "expt_dschrg_dt": "2021-03-04"
                    }

                ]
            }).toPromise();
        }else {
            return of({"insert_hsc_one": {"hsc_id": 13469}}).toPromise();
        }
    }
}

class MockHealthServiceClient {
    public getGraphqlClient(httpRequest: HttpRequest): GraphQLClient {
        return new MockGraphQLClient('testurl');
    }
}


class MockProvGraphQLClient extends GraphQLClient{
    request(document: RequestDocument, variables?: any, requestHeaders?: any): Promise<any>{
        return of({
            v_prov_srch: [{ prov_loc_affil_id: 1, prov_id: 23, prov_adr_id: 321, prov_catgy_ref_id: 16309}]
        }).toPromise();
    }
}


class MockProviderClient {
    public getGraphqlClient(httpRequest: HttpRequest): GraphQLClient {
        return new MockProvGraphQLClient('testurl');
    }
}

class MockMemberGraphQLClient extends GraphQLClient{
    request(document: RequestDocument, variables?: any, requestHeaders?: any): Promise<any>{
        return of({
                "mbrshp": [
                    {
                        "mbr_covs": [
                            {
                                "mbr_cov_id": 90881959,
                                "cov_end_dt": "9999-12-31",
                                "cov_eff_dt": "2020-02-01",
                                "pol_nbr": "0752023",
                                "prdct_typ_ref_cd": {
                                    "ref_desc": "POS"
                                },
                                "clm_pltfm_ref_id": 363,
                                "prdct_catgy_ref_cd": null,
                                "prdct_catgy_ref_id": null,
                                "cov_typ_ref_id": 182,
                                "cov_typ_ref_cd": {
                                    "ref_desc": "Medical"
                                }
                            }]}]}).toPromise();
    }
}


class MockMemberClient {
    public getGraphqlClient(httpRequest: HttpRequest): GraphQLClient {
        return new MockMemberGraphQLClient('testurl');
    }
}

class MockIndividualGraphQLClient extends GraphQLClient{
    request(document: RequestDocument, variables?: any, requestHeaders?: any): Promise<any>{
        if(variables.indvkeyId){
            return of({
                "indv_key": [
                    {
                        "indv":{
                            "fst_nm": "Matt",
                            "lst_nm": "Meyer",
                        },
                        "indv_id": 503926748,
                        "indv_key_val": "16440436900",

                    }
                ]}).toPromise();
        }
        else if(variables.orig_sys_mbr_id){
            return of({
                "mbrshp": [{
                    "mbr_covs": [
                        {
                            "cov_eff_dt": "2020-02-01",
                            "cov_end_dt": "9999-12-31",
                            "mbr_cov_id": 90881959,
                            "pol_nbr": "0752023",
                            "cov_typ_ref_cd": {
                                "ref_desc": "Medical"
                            },
                            "prdct_catgy_ref_cd": null,
                            "clm_pltfm_ref_id": 363,
                            "prdct_ref_id": 226
                        }
                    ],
                    "orig_sys_cd": "CDB_CS",
                    "orig_sys_mbr_id": "16440436900",
                    "orig_sys_ref_id": 2043,
                    "src_mbr_id": "30830290",
                    "src_mbr_partn_id": "10"
                }]
            }).toPromise();
        }
    }
}


class MockIndividualClient {
    public getGraphqlClient(httpRequest: HttpRequest): GraphQLClient {
        return new MockIndividualGraphQLClient('testurl');
    }
}

class MemberServiceMock {
    getMemberCoverageDetails(indvKeyVal, mbr_cov, orgSysCd, context: any) {
        return of({
            indv_id: 511941903,
            pol_nbr: null,
            cov_eff_dt: '0001-01-01',
            cov_end_dt: '9999-12-31',
            mbr_cov_id: 90881974,
            productCode: null,
            indv_key_val: '07007340001078331402002',
            productCatgyTpe: null,
            coverageTypeDesc: 'Medical',
            indv_key_typ_ref_id: 2757,
            claim_platform_ref_Id: null,
        }).toPromise();
    }
}

class MockProvService {
    getProvData(provKeyVal, provKeyTypeRefId) {
        return of({
            v_prov_srch: [{ prov_loc_affil_id: 1, prov_id: 23, prov_adr_id: 321, prov_catgy_ref_id: 16309}]
        }).toPromise();
    }
    getProviderId(hscProvInput: HscProvInput, hsc_id, httpRequest) : Promise<any>{
        return of({
            "hsc_prov": [
                {
                    "hsc_prov_id": 5457,
                    "prov_loc_affil_dtl": {
                        "providerDetails": {
                            "prov_adr": {
                                "cty_nm": "Santa Monica",
                                "st_ref_id": 1067,
                                "zip_cd_txt": "904043414",
                                "adr_ln_1_txt": "1920 Colorado Ave",
                                "adr_ln_2_txt": null
                            },
                            "prov_key": [
                                {
                                    "prov_key_val": "1851525091",
                                    "prov_key_typ_ref_id": 2782
                                },
                                {
                                    "prov_key_val": "288158608",
                                    "prov_key_typ_ref_id": 16333
                                },
                                {
                                    "prov_key_val": "1710081369",
                                    "prov_key_typ_ref_id": 2783
                                }
                            ]
                        }
                    }
                }
            ]}).toPromise();
    }
}

class MockHscBusinessEventService {
    async publishHscCreateBusinessEvent(hsc_id, httpRequest: HttpRequest) {
        return of({}).toPromise();
    }

    async pushHscBusinessEvents(eventList: HscBusEvent[], httpRequest: HttpRequest) {
        return of({}).toPromise();
    }
}

class MockMemberCommunicationGraphQLClient extends GraphQLClient {
    request(document: RequestDocument, variables?: any, requestHeaders?: any): Promise<any> {
        return of({
            "insert_mbr_cmnct_one": {
                "mbr_cmnct_id": 56452,
                "creat_user_id": "SYSTEM",
                "creat_dttm": "2021-07-14T12:49:19.551",
                "chg_user_id": "SYSTEM",
                "chg_dttm": "2021-07-14T12:49:19.551",
                "commt_txt": "ovc_mbr_appt_confirmation_template.html",
                "cmnct_adr_dtl": "{\"address\":\"viswanath_c@optum.com\"}",
                "dsclmr_cnsnt_desc": null,
                "mbr_cmnct_catgy_ref_id": 2563,
                "mbr_cmnct_chnl_ref_id": 17272,
                "mbr_cmnct_dir_ref_id": 20087,
                "mbr_cmnct_prr_ref_id": 2515,
                "mbr_cmnct_rsn_ref_id": 20090,
                "mbr_cmnct_sts_ref_id": 20066,
                "mbr_cmnct_sts_rsn_ref_id": null,
                "mbr_cmnct_typ_ref_id": 20089,
                "sts_dttm": "2021-07-14T12:49:19.551",
                "updt_ver_nbr": 0,
                "mbr_cmnct_prtcps": [
                    {
                        "mbr_cmnct_id": 56452,
                        "mbr_cmnct_prtcp_id": 39778,
                        "fst_nm": "undefined",
                        "lst_nm": "undefined",
                        "mbr_cmnct_prtcp_engage_lvl_ref_id": null,
                        "mbr_cmnct_prtcp_role_ref_id": null,
                        "prtcp_desc": null,
                        "prtcp_key_typ_ref_id": null,
                        "prtcp_key_val": "undefined"
                    }
                ]
            }
        }).toPromise();
    }
}

class MockMemberCommunicationClient {
    public getGraphqlClient(httpRequest: HttpRequest): GraphQLClient {
        return new MockMemberCommunicationGraphQLClient('testurl');
    }
}

describe('HscService', () => {
  let service: HscService;
  let context = {req: {headers: {}}};
  let config: ConfigService;
  let httpService: HttpService;
  beforeEach(async () => {
      const module: TestingModule = await Test.createTestingModule({
        imports: [ConfigModule, HttpModule, LoggerModule.forRoot()],
        providers: [HscService,AuthorizationService,{provide: HealthServiceClient, useClass: MockHealthServiceClient}, {provide: ProviderService, useClass: MockProvService},
            {provide: MemberClient, useClass: MockMemberClient},{ provide: IndividualClient, useClass: MockIndividualClient }, { provide: MemberService, useClass: MemberServiceMock },
            {provide: ProviderClient, useClass: MockProviderClient}, CreateHscMapper, {provide: HscBusinessEventService, useClass: MockHscBusinessEventService},
            {provide: MemberCommunicationClient, useClass: MockMemberCommunicationClient}],
      }).compile();

      service = module.get<HscService>(HscService);
      config = module.get<ConfigService>(ConfigService);
      httpService = module.get<HttpService>(HttpService);
    });

    it('should be defined', () => {
      expect(service).toBeDefined();
    });

    it('should create the new case data in HSC domain', () => {
        const createHscRequestInput: CreateHscRequestInput = {
                "hsc": {
                    "indv_key_typ_ref_id": 2757,
                    "indv_key_val": "16440436900",
                    "srvc_set_ref_id": 3737,
                    "rev_prr_ref_id": 3754,
                    "mbr_cov": {
                        "fst_nm": "Matt",
                        "lst_nm": "Meyer",
                        "bth_dt": new Date("1978-07-26"),
                        "gdr_ref_id": 2109,
                        "orig_sys_cd": "CDB_CS",
                        "cov_eff_dt": new Date("2013-01-01"),
                        "cov_end_dt": new Date("9999-12-31"),
                        "src_mbr_id": "30830290",
                        "src_mbr_partn_id": "10",
                        "pol_nbr": "0128855",
                        "cov_typ_ref_id": null,
                        "clm_pltfm_ref_id": 363
                    },
                    "flwup_cntc_dtl": [{
                            "name": "test",
                            "role": null,
                            "department": null,
                            "phone": "111-111-1111",
                            "fax": null,
                            "email": null,
                            "primaryContact": true,
                        },
                        {
                            "name": "secondary contact name",
                            "role": null,
                            "department": null,
                            "phone": "111-111-1111",
                            "fax": null,
                            "email": null,
                            "primaryContact": false,
                        }],
                    "hsc_facl": {
                        "plsrv_ref_id": 3743,
                        "srvc_desc_ref_id": 4347,
                        "srvc_dtl_ref_id": 4296,
                        "actul_admis_dttm": null,
                        "actul_dschrg_dttm": null,
                        "expt_admis_dt": new Date(),
                        "expt_dschrg_dt": new Date(),
                        "admis_ntfy_dttm": new Date(),
                        "admis_ntfy_trans_id": 1,
                        "adv_ntfy_dttm": new Date(),
                        "adv_ntfy_trans_id": 1,
                        "ctp_nom_sts_ref_id": 1,
                        "dschrg_disp_ref_id": 1,
                        "dschrg_ntfy_dttm": new Date(),
                        "dschrg_ntfy_trans_id": 1,
                        "goal_los_day_cnt": 1,
                        "ipcm_typ_ref_id": 1,
                        "rem_snf_day_cnt": 1,
                        "snf_day_xhst_ind": 1,
                        "tat_due_dttm": new Date(),
                    },
                    "hsc_diags": [
                        {
                            "diag_cd": "L02.52",
                            "pri_ind": 1,
                            "diag_othr_txt": "test"
                        },
                        {
                            "diag_cd": "L02.51",
                            "pri_ind": 0,
                            "diag_othr_txt": "test"
                        }
                    ],
                    "hsc_srvcs": [
                        {
                            "proc_cd": "80346",
                            "proc_cd_schm_ref_id": 2,
                            "srvc_hsc_prov_id": 1,
                            "hsc_decn":{
                                    "hsc_decn_id":1,
                                    "decn_otcome_ref_id": 1,
                                    "decn_typ_ref_id": 2,
                                    "decn_rsn_ref_id": 3,
                                    "clm_note_txt": "test",
                                    "ovrd_clm_rmrk_ref_id": 1,
                                    "sys_clm_rmrk_ref_id": 1,
                                    "decn_src_desc": {
                                        "test": "test"
                                    },
                                    "wrt_decn_cmnct_dttm": new Date(),
                                    "decn_rndr_dttm": new Date(),
                                    "decn_mbr_cmnct_dttm": new Date(),
                                    "decn_prov_cmnct_dttm": new Date(),
                                    "gap_rev_otcome_ref_id": 2,
                                    "negot_rt": 1,
                                    "actul_nxt_rev_dt": new Date(),
                                    "decn_bed_day_cnt": 1,
                                    "aprv_proc_unit_cnt": 1,
                                    "aprv_unit_per_freq_cnt": 1,
                                    "ben_lvl_ref_id": 1,
                                    "ben_xcpt_ref_id": 1,
                                    "decn_clin_rsn_txt": "test",
                                    "decn_ent_by_user_id": "1",
                                    "decn_ent_rsn_ref_id": 1,
                                    "decn_hsc_prov_id": 1,
                                    "decn_made_by_user_id": '1',
                                    "decn_made_by_user_org_desc": "test",
                                    "decn_mbr_cmnct_to_role_ref_id": 1,
                                    "decn_prov_cmnct_to_role_ref_id": 1,
                                    "decn_ur_jurdc_ref_id": 1,
                                    "ltr_atr_list": {"test": "test"},
                                    "mbr_cov_dtl": {"test": "test"},
                                    "negot_rt_typ_ref_id": 1,
                                    "ovrd_rsn_ref_id": 1,
                                    "ovrd_rsn_txt": "test",
                                    "peer_to_peer_rev_dt": new Date(),
                                    "sched_nxt_rev_dt": new Date(),
                                    "site_of_care_pref_ref_id": 1,
                                    "hsc_decn_bed_days": [
                                        {
                                            "strt_bed_dt": new Date(),
                                            "rvnu_cd": "test",
                                            "bed_typ_ref_id": 1,
                                            "accum_bed_day_cnt": 1,
                                            "decn_facl_cmnct_dttm": new Date(),
                                            "decn_rndr_dttm_facl_lcl_txt": "test",
                                            "questnr_rspn_id": 1
                                        }
                                    ]
                                }
                        }
                    ],
                    "hsr_notes": [
                        {
                            "note_txt_lobj": "test",
                            "note_titl_txt": "test",
                            "src_user_nm": "provider",
                            "note_typ_ref_id": 321,
                            "note_catgy_ref_id": 123,
                            "note_sts_ref_id":null,
                            "hsr_note_sbjs":[{
                                "note_sbj_rec_id":"123",
                                "note_sbj_typ_ref_id":234,
                            }]
                        },
                        {
                            "note_txt_lobj": "test1",
                            "note_titl_txt": "test1",
                            "src_user_nm": "provider",
                            "note_typ_ref_id": 321,
                            "note_catgy_ref_id": 123,
                            "note_sts_ref_id":null,
                            "hsr_note_sbjs":[{
                                "note_sbj_rec_id":"123",
                                "note_sbj_typ_ref_id":234,
                            }]
                        }
                    ],
                    "hsc_provs": [
                        {
                            "id": 1,
                            "prov_keys": [
                                {
                                    "prov_key_typ_ref_id": 2782,
                                    "prov_key_val": "1710081369"
                                },
                                {
                                    "prov_key_typ_ref_id": 16333,
                                    "prov_key_val": "288158608"
                                },
                                {
                                    "prov_key_typ_ref_id": 2783,
                                    "prov_key_val": "1710081369"
                                }
                            ],
                            "hsc_prov_roles": [
                                {
                                    "prov_role_ref_id": 3761
                                }
                            ],
                            "prov_adr": {
                                "adr_ln_1_txt": "1920 Colorado Ave",
                                "adr_ln_2_txt": null,
                                "zip_cd_txt": "904043414",
                                "cty_nm": "Santa Monica",
                                "st_ref_id": 1067
                            }
                        },
                        {
                            "id": 2,
                            "prov_keys": [
                                {
                                    "prov_key_typ_ref_id": 2782,
                                    "prov_key_val": "1255539573"
                                },
                                {
                                    "prov_key_typ_ref_id": 16333,
                                    "prov_key_val": "288158608"
                                },
                                {
                                    "prov_key_typ_ref_id": 2783,
                                    "prov_key_val": "1255539573"
                                }
                            ],
                            "hsc_prov_roles": [
                                {
                                    "prov_role_ref_id": 3759
                                }
                            ],
                            "prov_adr": {
                                "adr_ln_1_txt": "1920 Colorado Ave",
                                "adr_ln_2_txt": null,
                                "zip_cd_txt": "904043414",
                                "cty_nm": "Santa Monica",
                                "st_ref_id": 1067
                            }

                        }
                    ],
                    "hsr_actvs": [
                        {
                            "creat_user_id": "SYSTEM_PAAN",
                            "chg_user_id": "SYSTEM_PAAN",
                            "actv_strt_dttm": new Date(),
                            "actv_typ_ref_id": 17292,
                            "dur_mn_nbr": 0,
                            "rslv_rsn_typ_id": 65,
                            "rslv_otcome_typ_id": 151,
                            "init_by_func_role_ref_id": null,
                            "cntc_role_ref_id": 17292,
                            "creatr_func_role_ref_id": 17292,
                            "actv_prtn_ref_id": 17292,
                            "cntc_user_id": null,
                            "commt_txt": "user actv",
                            "extr_ref_trans_id": "0",
                            "mbr_cmnct": {
                                "creat_user_id": "SYSTEM",
                                "chg_user_id": "SYSTEM",
                                "commt_txt": "ovc_mbr_appt_confirmation_template.html",
                                "cmnct_adr_dtl": "{\"address\":\"viswanath_c@optum.com\"}",
                                "dsclmr_cnsnt_desc": null,
                                "mbr_cmnct_catgy_ref_id": 2563,
                                "mbr_cmnct_chnl_ref_id": 17272,
                                "mbr_cmnct_dir_ref_id": 20087,
                                "mbr_cmnct_prr_ref_id": 2515,
                                "mbr_cmnct_rsn_ref_id": 20090,
                                "mbr_cmnct_sts_ref_id": 20066,
                                "mbr_cmnct_sts_rsn_ref_id": null,
                                "mbr_cmnct_typ_ref_id": 20089,
                                "sts_dttm": new Date(),
                                "mbr_cmnct_prtcps": [
                                    {
                                        "fst_nm": "undefined",
                                        "lst_nm": "undefined",
                                        "mbr_cmnct_prtcp_engage_lvl_ref_id": null,
                                        "mbr_cmnct_prtcp_role_ref_id": null,
                                        "prtcp_desc": null,
                                        "prtcp_key_typ_ref_id": null,
                                        "prtcp_key_val": "undefined"
                                    }
                                ]
                            }
                        }
                    ]
                }
        };
        const result2: AxiosResponse = { data: "https://dev-ecp-api.optum.com/auth/oauth/jwks", status: 200, statusText: 'OK', headers: {}, config: {}, };
        const result3: AxiosResponse = { data: "ecp", status: 200, statusText: 'OK', headers: {}, config: {}, };

        jest.spyOn(config, 'get').mockImplementationOnce(() => of(result2));
        jest.spyOn(config, 'get').mockImplementationOnce(() => of(result3));
        spyOn<any>(AuthorizationService, 'getEcpAuthencatedUser').and.returnValue({"userId": "00136607"})
        const axiosResponse: AxiosResponse = { data: [], status: 200, statusText: 'OK', headers: {}, config: {}, };
        jest.spyOn(httpService, 'post').mockImplementationOnce(() => of(axiosResponse));
        let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
        service.createHsc(createHscRequestInput, httpRequest).then((res) => {
            expect(res.data.hsc_id).toEqual(13469);
        });
      });

    it('should call getCaseTypeDetails', () => {
        const axiosResponse: AxiosResponse = { data: [], status: 200, statusText: 'OK', headers: {}, config: {}, };
        jest.spyOn(httpService, 'post').mockImplementationOnce(() => of(axiosResponse));
        let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
        const getCaseTypeDetailsRequest: HscInput = {hsc_id : 14254};
        service.getCaseTypeDetails(getCaseTypeDetailsRequest, httpRequest).then((res) => {
            expect(res.hsc_id).toEqual(14254);
        });
    });
});
