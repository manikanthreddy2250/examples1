import {Injectable, Logger} from '@nestjs/common';
import {HealthServiceClient} from "../../../shared/graphql/healthservicedomain/healthServiceClient";
import {createHscCase, getCaseTypeDetails} from "../../../shared/graphql/healthservicedomain/healthServiceQuery";
import {HttpRequest} from "@azure/functions";
import {GraphQLClient} from "graphql-request/dist";
import {CreateHscMapper} from "../../mapper/createHsc.mapper";
import {CreateHscRequestInput} from "../../models/createHscRequest.input";
import {CreateHscResponse} from "../../models/createHscResponse";
import {HscInput} from "../../models/hsc.input";
import {CaseTypeDetailsResponse} from "../../models/caseTypeDetailsResponse";
import {ReferenceConstants} from '../../../shared/constants/referenceConstants';
import {HscBusinessEventService} from "../businessEvents/hsc-bus-event/hsc-bus-event.service";
import {HscBusEvent} from "../../models/HscBusEvent";
import {HscBusEventName} from "../../models/HscBusEventName";
import {HscEntityActionType} from "../../models/HscEntityActionType";
import {InjectPinoLogger, PinoLogger} from "nestjs-pino/dist";

@Injectable()
export class HscService {

    constructor(private readonly healthServiceClient: HealthServiceClient,
                private readonly createHscMapper: CreateHscMapper,
                @InjectPinoLogger(HscService.name) private readonly logger: PinoLogger, private readonly hscBusinessEventService:HscBusinessEventService
                ) {
    }

    async createHsc(createHscRequest: CreateHscRequestInput, httpRequest: HttpRequest): Promise<CreateHscResponse> {
        const hscGraphqlClient: GraphQLClient = this.healthServiceClient.getGraphqlClient(httpRequest);
        let response;
        try {
            if (createHscRequest.hsc) {
                const request = await this.createHscMapper.createHscRequestMapping(createHscRequest.hsc, httpRequest);
                const healthServiceVariables = {hsc: request};
                this.logger.info("Before mutation (MyMutation) to health service domain : " + new Date());
                response = await hscGraphqlClient.request(createHscCase, healthServiceVariables);
                this.logger.info("After mutation (MyMutation) to health service domain : " + new Date());
                response.insert_hsc_one.hsc_srvcs = await this.createHscMapper.insertHscSrvc(createHscRequest.hsc, response.insert_hsc_one.hsc_id, httpRequest);
                response.insert_hsc_one.hsc_srvcs.forEach((hscSrvc) =>{
                    response.insert_hsc_one.hsc_decns.push(...hscSrvc.hsc_decns);
                });
                const createHscResponse: CreateHscResponse = {data: response.insert_hsc_one};
                //Publish payload to event hub table when hsc case is in open state
                if(response.insert_hsc_one.hsc_sts_ref_id && response.insert_hsc_one.hsc_sts_ref_id==ReferenceConstants.HSCSTATUSTYPE_OPEN_REFID){
                    const hscBasePayload = await this.hscBusinessEventService.buildBaseHscPayload(response.insert_hsc_one.hsc_id, httpRequest);
                    hscBasePayload.hsc.hsc_data.action = HscEntityActionType.CREATE;
                    const eventList: HscBusEvent[] = [{eventName: HscBusEventName.HSC_CREATE, payload: hscBasePayload}];
                    this.hscBusinessEventService.pushHscBusinessEvents(eventList, httpRequest);
                }
                return createHscResponse;
            }
        } catch (e) {
            this.logger.error("Exception occured in createHsc method ===== " + e);
            throw e;
        }
    }

    async getCaseTypeDetails(getCaseTypeDetailsRequest: HscInput, httpRequest: HttpRequest): Promise<CaseTypeDetailsResponse> {
        const hscGraphqlClient: GraphQLClient = this.healthServiceClient.getGraphqlClient(httpRequest);
        let response;
        try {
            if (getCaseTypeDetailsRequest) {
                const healthServiceVariables = {hsc_id: getCaseTypeDetailsRequest.hsc_id};
                response = await hscGraphqlClient.request(getCaseTypeDetails, healthServiceVariables);
                const caseTypeDetailsResponse: CaseTypeDetailsResponse = response.hsc[0];
                return caseTypeDetailsResponse;
            }
        } catch (e) {
            this.logger.error("Exception Occurred while retrieving the CaseType Details Data ===== " + e);
        }
    }
}

