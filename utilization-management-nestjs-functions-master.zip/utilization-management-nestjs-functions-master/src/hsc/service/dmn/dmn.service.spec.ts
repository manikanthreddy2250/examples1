import { Test, TestingModule } from '@nestjs/testing';
import { DmnService } from './dmn.service';
import {ConfigService} from "@nestjs/config";
import {HttpModule, HttpService} from "@nestjs/common";
import {HttpRequest} from "@azure/functions";
import {of} from "rxjs";
class MockConfigService extends ConfigService {
  get(propertyPath: any){
    return 'testvalue';
  };
}
jest.mock('axios');
describe('DmnService', () => {
  let service: DmnService;
  let httpService: HttpService;
  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      imports: [HttpModule],
      providers: [DmnService, {provide: ConfigService, useClass: MockConfigService}],
    }).compile();

    service = module.get<DmnService>(DmnService);
    httpService = module.get<HttpService>(HttpService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('evaluateDmn should evaluate and return response', async () => {
    const httpRequest: HttpRequest = {method: null, url: '', headers: {'authorization': 'test', 'x-bpm-func-role': 'test_role', 'x-bpm-tenant-id': 'test_tenant_id', 'x-bpm-cli-org-id': 'ecp'}, query: {}, params: {}};
    const result1: any = { data: [{duplicateCheckCriteria: "hscStatus", duplicateCheckValues: [123]}]};
    jest.spyOn(httpService, 'post').mockImplementationOnce(() => of(result1));
    const response = await service.evaluateDmn('dmnName', {}, httpRequest);
    expect(response.data.length).toEqual(1);
  });
});
