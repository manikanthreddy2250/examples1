import { HttpService, Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { HttpRequest } from '@azure/functions';

@Injectable()
export class DmnService {
  constructor(
    private readonly configService: ConfigService,
    private readonly httpService: HttpService,
  ) {}

  async evaluateDmn(
    dmnName: string,
    body: any,
    httpRequest: HttpRequest,
  ): Promise<any> {
    const dmnHeaders = {
      Authorization: httpRequest.headers['authorization'],
      'x-bpm-cli-org-id': httpRequest.headers['x-bpm-cli-org-id'],
      'x-bpm-func-role': httpRequest.headers['x-bpm-func-role'],
      'x-bpm-tenant-id': httpRequest.headers['x-bpm-tenant-id'],
    };
    return await this.httpService
      .post(
        this.configService.get('UM_RULES_SERVICE_BASE_URL') +
          '/' +
          dmnName +
          '/evaluate',
        body,
        { headers: dmnHeaders },
      )
      .toPromise();
  }
}
