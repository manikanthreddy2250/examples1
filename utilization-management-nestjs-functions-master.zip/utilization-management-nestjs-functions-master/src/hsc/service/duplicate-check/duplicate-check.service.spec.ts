import { Test, TestingModule } from '@nestjs/testing';
import { DuplicateCheckService } from './duplicate-check.service';
import { DuplicateCheckRequestInput } from '../../models/duplicateCheckRequest.input';
import { HttpRequest } from '@azure/functions';
import { DmnService } from '../dmn/dmn.service';
import { ConfigService } from '@nestjs/config';
import { of } from 'rxjs';
import { HttpModule, HttpService, Logger } from '@nestjs/common';
import { GraphQLClient } from 'graphql-request/dist';
import { RequestDocument } from 'graphql-request/dist/types';
import { HealthServiceClient } from '../../../shared/graphql/healthservicedomain/healthServiceClient';
import { ReferenceClient } from '../../../shared/graphql/referencedomain/referenceClient';

class MockGraphQLClient extends GraphQLClient {
  request(
    document: RequestDocument,
    variables?: any,
    requestHeaders?: any,
  ): Promise<any> {
    if (variables.hscId == 2) {
      return of({
        hsc: [
          {
            hsc_id: 2,
            hsc_sts_ref_id: 123,
            srvc_set_ref_id: 3738,
            hsc_provs: [
              {
                prov_loc_affil_dtl: {
                  providerDetails: {
                    prov_keys: [
                      { prov_key_typ_ref_id: 2, prov_key_val: '123' },
                    ],
                  },
                },
                hsc_prov_roles: [{ prov_role_ref_id: 3764 }],
              },
            ],
            hsc_facls: [{ plsrv_ref_id: 333 }],
            hsc_keys: [{ hsc_key_val: '222', hsc_key_typ_ref_id: 111 }],
          },
        ],
      }).toPromise();
    } else if (variables.hscId == 3) {
      return of({
        hsc: [
          {
            hsc_id: 3,
            hsc_sts_ref_id: 123,
            srvc_set_ref_id: 3738,
            hsc_provs: [
              {
                prov_loc_affil_dtl: {
                  providerDetails: {
                    prov_keys: [
                      { prov_key_typ_ref_id: 2, prov_key_val: '123' },
                    ],
                  },
                },
                hsc_prov_roles: [{ prov_role_ref_id: 3764 }],
              },
            ],
            hsc_facls: [],
            hsc_srvcs: [
              { proc_cd: 123, hsc_srvc_non_facls: [{ plsrv_ref_id: 333 }] },
            ],
            hsc_keys: [{ hsc_key_val: '222', hsc_key_typ_ref_id: 111 }],
          },
        ],
      }).toPromise();
    } else if (variables.diag_cds) {
      return of({
        icd10: [{ diag_cd: 'M51.21', cd_desc: 'mydiag' }],
      }).toPromise();
    } else if (variables.procCodes) {
      return of([
        {
          cpt4: {
            proc_cd: '81099',
            cd_desc: 'Mydiag',
            proc_cd_schm_ref_id: '4',
          },
        },
        {
          hcpcs: {
            proc_cd: '81098',
            cd_desc: 'Mydiag',
            proc_cd_schm_ref_id: '2',
          },
        },
      ]).toPromise();
    } else {
      return of({
        hsc: [
          {
            hsc_id: 17183,
            srvc_set_ref_id: 3737,
            hsc_sts_ref_id: 3738,
            srvc_set_ref_cd: {
              ref_cd: '1',
              ref_desc: 'Inpatient',
              ref_dspl: 'Inpatient',
            },
            hsc_diags: [
              {
                diag_cd: 'M91.10',
                diag_desc: 'JUVENILE OSTEOCHONDROSIS HEAD OF FEMUR UNS LEG',
              },
              {
                diag_cd: 'C12',
                diag_desc: 'MALIGNANT NEOPLASM OF PYRIFORM SINUS',
              },
            ],
            hsc_srvcs: [
              { proc_cd: 81099, proc_cd_schm_ref_id: 4 , hsc_srvc_non_facls: [
                  {  srvc_strt_dt: new Date('03-29-2021'),
                    srvc_end_dt: new Date('03-29-2021'),
                    proc_uom_ref_id: 10,
                    proc_unit_cnt: 10,
                    unit_per_freq_cnt: 10,
                    plsrv_ref_id: 10,
                    proc_freq_ref_id: 10,
                    srvc_desc_ref_id: 10,
                    srvc_dtl_ref_id: 10
                  }
                ]},
              { proc_cd: 81098, proc_cd_schm_ref_id: 2, hsc_srvc_non_facls: [
                  {  srvc_strt_dt: new Date('03-29-2021'),
                    srvc_end_dt: new Date('03-29-2021'),
                    proc_uom_ref_id: 10,
                    proc_unit_cnt: 10,
                    unit_per_freq_cnt: 10,
                    plsrv_ref_id: 10,
                    proc_freq_ref_id: 10,
                    srvc_desc_ref_id: 10,
                    srvc_dtl_ref_id: 10
                  }
                ] },
            ],
            hsc_provs: [
              {
                prov_loc_affil_dtl: {
                  providerDetails: {
                    bus_nm: 'AIRPORT HEALTHCARE MEDICAL GROUP',
                    prov_adr: {
                      cty_nm: 'LOS ANGELES',
                      st_ref_id: 1084,
                      zip_cd_txt: '90045',
                      adr_ln_1_txt: '6033 W CENTURY BLVD STE 200',
                    },
                    prov_keys: [
                      {
                        prov_key_val: '000001000',
                        prov_key_typ_ref_id: 2783,
                      },
                      {
                        prov_key_val: '4',
                        prov_key_typ_ref_id: 0,
                      },
                      {
                        prov_key_val: '954279185',
                        prov_key_typ_ref_id: 2784,
                      },
                    ],
                  },
                },
                hsc_prov_roles: [
                  {
                    hsc_prov_id: 7340,
                    prov_role_ref_id: 3758,
                  },
                  {
                    hsc_prov_id: 7340,
                    prov_role_ref_id: 3759,
                  },
                  {
                    hsc_prov_id: 7340,
                    prov_role_ref_id: 3761,
                  },
                  {
                    hsc_prov_id: 7340,
                    prov_role_ref_id: 3765,
                  },
                ],
              },
            ],
            hsc_facls: [
              {
                actul_admis_dttm: '2021-04-06T06:30:00',
                actul_dschrg_dttm: '2021-04-12T06:30:00',
                expt_admis_dt: '2021-03-29',
                expt_dschrg_dt: '2021-04-05',
                plsrv_ref_id: 333,
                srvc_desc_ref_id: 111,
                srvc_dtl_ref_id: 199,
              },
            ],
            hsc_keys: [
              {
                hsc_key_val: 'A004609516',
                hsc_key_typ_ref_id: 19971,
              },
            ],
          },
        ],
      }).toPromise();
    }
  }
}

class MockHealthServiceClient {
  public getGraphqlClient(httpRequest: HttpRequest): GraphQLClient {
    return new MockGraphQLClient('testurl');
  }
}

class MockDmnService extends ConfigService {
  async evaluateDmn(
    dmnName: string,
    body: any,
    httpRequest: HttpRequest,
  ): Promise<any> {
    return of({
      data: [
        {
          duplicateCheckCriteria: 'hscStatus',
          duplicateCheckValues: [123, 19274, 3737, 3738],
        },
        { duplicateCheckCriteria: 'submittingProvider' },
        { duplicateCheckCriteria: 'procedureServiceStartDate' },
        { duplicateCheckCriteria: 'facilityType' },
        {
          duplicateCheckCriteria: 'actualAdmitDate',
          duplicateCheckValues: [0],
        },
      ],
    }).toPromise();
  }
}

class MockReferenceClient {
  public getGraphqlClient(): GraphQLClient {
    return new MockGraphQLClient('testurl');
  }
}

class MockConfigService extends ConfigService {
  get(propertyPath: any) {
    return 'testvalue';
  }
}

jest.mock('axios');
describe('DuplicateCheckService', () => {
  let service: DuplicateCheckService;
  let httpService: HttpService;
  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      imports: [HttpModule],
      providers: [
        DuplicateCheckService,
        Logger,
        { provide: DmnService, useClass: MockDmnService },
        { provide: ConfigService, useClass: MockConfigService },
        { provide: ReferenceClient, useClass: MockReferenceClient },
        { provide: HealthServiceClient, useClass: MockHealthServiceClient },
      ],
    }).compile();

    service = module.get<DuplicateCheckService>(DuplicateCheckService);
    httpService = module.get<HttpService>(HttpService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('getHscDuplicates should return duplicates for request with hsc information', async () => {
    const duplicateCheckRequestInput: DuplicateCheckRequestInput = {
      hsc: {
        indv_key_typ_ref_id: 2,
        indv_key_val: '123',
        srvc_set_ref_id: 3737,
        hsc_facl: {
          plsrv_ref_id: 333,
          srvc_desc_ref_id: 111,
          srvc_dtl_ref_id: 199,
          expt_admis_dt: new Date('03-29-2021'),
          expt_dschrg_dt: new Date('03-30-2021'),
        },
        hsc_srvcs: [
                { proc_cd: '81099', proc_cd_schm_ref_id: 4 ,
                  hsc_srvc_non_facls: [
                    {  srvc_strt_dt: new Date('03-29-2021'),
                      srvc_end_dt: new Date('03-29-2021'),
                      proc_uom_ref_id: 10,
                      proc_unit_cnt: 10,
                      unit_per_freq_cnt: 10,
                      plsrv_ref_id: 10,
                      proc_freq_ref_id: 10,
                      srvc_desc_ref_id: 10,
                      srvc_dtl_ref_id: 10
                    }
                  ]
                },
                  { proc_cd: '81098', proc_cd_schm_ref_id: 2 }
        ],
        hsc_provs: [
          {
            id: 2,
            prov_keys: [
              {
                prov_key_typ_ref_id: 2782,
                prov_key_val: '123',
              },
              {
                prov_key_typ_ref_id: 16333,
                prov_key_val: '288158608',
              },
              {
                prov_key_typ_ref_id: 2783,
                prov_key_val: '1255539573',
              },
            ],
            hsc_prov_roles: [
              {
                prov_role_ref_id: 3764,
              },
            ],
            prov_adr: {
              adr_ln_1_txt: '1920 Colorado Ave',
              adr_ln_2_txt: null,
              zip_cd_txt: '904043414',
              cty_nm: 'Santa Monica',
              st_ref_id: 1067,
            },
            prov_loc_affil_dtl: {
              providerDetails: {
                bus_nm: 'AIRPORT HEALTHCARE MEDICAL GROUP',
                prov_keys: [
                  { prov_key_val: '000001000', prov_key_typ_ref_id: 2783 },
                  { prov_key_val: '4', prov_key_typ_ref_id: 0 },
                  { prov_key_val: '954279185', prov_key_typ_ref_id: 2784 },
                ],
              },
            },
          },
        ],
      },
    };
    const httpRequest: HttpRequest = {
      method: null,
      url: '/test?session_id=encryptedid',
      headers: { authorization: 'test token', 'x-hasura-role': 'testrole' },
      query: { test: 'test' },
      params: { test: 'test' },
    };
    const response = await service.getHscDuplicates(
      duplicateCheckRequestInput,
      httpRequest,
    );
    expect(response.hsc_duplicates.length).toEqual(1);
  });
  it('getHscDuplicates should return duplicates for request with hsc id', async () => {
    const duplicateCheckRequestInput: DuplicateCheckRequestInput = {
      hsc: {
        hsc_id: 2,
      },
    };
    const httpRequest: HttpRequest = {
      method: null,
      url: '/test?session_id=encryptedid',
      headers: { authorization: 'test token', 'x-hasura-role': 'testrole' },
      query: { test: 'test' },
      params: { test: 'test' },
    };
    const response = await service.getHscDuplicates(
      duplicateCheckRequestInput,
      httpRequest,
    );
    expect(response.hsc_duplicates.length).toEqual(0);
  });

  it('getOPDuplicateCriteria should return duplicateCheckCriteria from bpmn variables', async () => {
    const httpRequest: HttpRequest = {
      method: null,
      url: '/test?session_id=encryptedid',
      headers: { authorization: 'test token', 'x-hasura-role': 'testrole' },
      query: { test: 'test' },
      params: { test: 'test' },
    };
    const baseProcessRes: any = { data: [{ id: 123 }] };
    const subProcessRes: any = { data: [{ id: 456 }] };
    const variableRes: any = {
      data: {
        dupcheck: {
          value: [
            {
              duplicateCheckCriteria: 'hscStatus',
              duplicateCheckValues: ['19274', '3737', '3738'],
            },
            {
              duplicateCheckCriteria: 'procedureServiceStartDate',
              duplicateCheckValues: [7],
            },
          ],
        },
      },
    };
    jest
      .spyOn(httpService, 'get')
      .mockImplementationOnce(() => of(baseProcessRes))
      .mockImplementationOnce(() => of(subProcessRes))
      .mockImplementationOnce(() => of(variableRes));
    const response = await service.getOPDuplicateCriteria('33333', httpRequest);
    expect(response.length).toEqual(2);
  });

  it('getIPOPFDuplicateCriteria should return duplicateCheckCriteria from bpmn variables', async () => {
    const httpRequest: HttpRequest = {
      method: null,
      url: '/test?session_id=encryptedid',
      headers: { authorization: 'test token', 'x-hasura-role': 'testrole' },
      query: { test: 'test' },
      params: { test: 'test' },
    };
    const baseProcessRes: any = { data: [{ id: 123 }] };
    const variableRes: any = {
      data: {
        dupcheck: {
          value: [
            {
              duplicateCheckCriteria: 'hscStatus',
              duplicateCheckValues: ['19274', '3737', '3738'],
            },
            {
              duplicateCheckCriteria: 'actualAdmitDate',
              duplicateCheckValues: [7],
            },
            {
              duplicateCheckCriteria: 'serviceStartDate',
              duplicateCheckValues: [7],
            },
            {
              duplicateCheckCriteria: 'procedureServiceStartDate',
              duplicateCheckValues: [7],
            }
          ],
        },
      },
    };
    jest
      .spyOn(httpService, 'get')
      .mockImplementationOnce(() => of(baseProcessRes))
      .mockImplementationOnce(() => of(variableRes));
    const response = await service.getIPOPFDuplicateCriteria(
      '11111',
      httpRequest,
    );
    expect(response.length).toEqual(4);
  });

  it('getHscDuplicates should return duplicates for outpatient request with hsc id ', async () => {
    const duplicateCheckRequestInput: DuplicateCheckRequestInput = {
      hsc: {
        hsc_id: 3,
      },
    };
    const httpRequest: HttpRequest = {
      method: null,
      url: '/test?session_id=encryptedid',
      headers: { authorization: 'test token', 'x-hasura-role': 'testrole' },
      query: { test: 'test' },
      params: { test: 'test' },
    };
    const response = await service.getHscDuplicates(
      duplicateCheckRequestInput,
      httpRequest,
    );
    expect(response.hsc_duplicates.length).toEqual(0);
  });

  it('getHscDuplicates should return duplicates without hsc id ', async () => {
    const duplicateCheckRequestInput: DuplicateCheckRequestInput = {
      hsc: {
        srvc_set_ref_id: 3738,
        indv_key_typ_ref_id: 2757,
        indv_key_val: '16440436900',
        hsc_facl: {
          plsrv_ref_id: 3746,
          srvc_desc_ref_id: 4347,
          srvc_dtl_ref_id: 4307,
        },
      },
    };
    const httpRequest: HttpRequest = {
      method: null,
      url: '/test?session_id=encryptedid',
      headers: { authorization: 'test token', 'x-hasura-role': 'testrole' },
      query: { test: 'test' },
      params: { test: 'test' },
    };

    const duplicateCheckResponse: any = {
      hsc_duplicates: [
        {
          hsc_id: 17183,
          srvc_set_ref_id: 3738,
          hsc_sts_ref_id: 3738,
          srvc_set_ref_cd: {
            ref_cd: '1',
            ref_desc: 'Inpatient',
            ref_dspl: 'Inpatient',
          },
          hsc_facl: [
            {
              plsrv_ref_id: 333,
              srvc_desc_ref_id: 111,
              srvc_dtl_ref_id: 199,
            },
          ],
          hsc_diags: [
            {
              diag_cd: 'M91.10',
              diag_desc: 'JUVENILE OSTEOCHONDROSIS HEAD OF FEMUR UNS LEG',
            },
            {
              diag_cd: 'C12',
              diag_desc: 'MALIGNANT NEOPLASM OF PYRIFORM SINUS',
            },
          ],
          hsc_srvcs: [
            { proc_cd: 81099, proc_cd_schm_ref_id: 4, hsc_srvc_non_facls: [
                {  srvc_strt_dt: new Date('03-29-2021'),
                  srvc_end_dt: new Date('03-29-2021'),
                  proc_uom_ref_id: 10,
                  proc_unit_cnt: 10,
                  unit_per_freq_cnt: 10,
                  plsrv_ref_id: 10,
                  proc_freq_ref_id: 10,
                  srvc_desc_ref_id: 10,
                  srvc_dtl_ref_id: 10
                }
              ] },
            { proc_cd: 81098, proc_cd_schm_ref_id: 2 , hsc_srvc_non_facls: [
                {  srvc_strt_dt: new Date('03-29-2021'),
                  srvc_end_dt: new Date('03-29-2021'),
                  proc_uom_ref_id: 10,
                  proc_unit_cnt: 10,
                  unit_per_freq_cnt: 10,
                  plsrv_ref_id: 10,
                  proc_freq_ref_id: 10,
                  srvc_desc_ref_id: 10,
                  srvc_dtl_ref_id: 10
                }
              ]},
          ],
          hsc_provs: [
            {
              prov_loc_affil_dtl: {
                providerDetails: {
                  bus_nm: 'AIRPORT HEALTHCARE MEDICAL GROUP',
                  prov_adr: {
                    cty_nm: 'LOS ANGELES',
                    st_ref_id: 1084,
                    zip_cd_txt: '90045',
                    adr_ln_1_txt: '6033 W CENTURY BLVD STE 200',
                  },
                  prov_keys: [
                    {
                      prov_key_val: '000001000',
                      prov_key_typ_ref_id: 2783,
                    },
                    {
                      prov_key_val: '4',
                      prov_key_typ_ref_id: 0,
                    },
                    {
                      prov_key_val: '954279185',
                      prov_key_typ_ref_id: 2784,
                    },
                  ],
                },
              },
              hsc_prov_roles: [
                {
                  hsc_prov_id: 7340,
                  prov_role_ref_id: 3758,
                },
                {
                  hsc_prov_id: 7340,
                  prov_role_ref_id: 3759,
                },
                {
                  hsc_prov_id: 7340,
                  prov_role_ref_id: 3761,
                },
                {
                  hsc_prov_id: 7340,
                  prov_role_ref_id: 3765,
                },
              ],
            },
          ],
          hsc_facls: [
            {
              actul_admis_dttm: '2021-04-06T06:30:00',
              actul_dschrg_dttm: '2021-04-12T06:30:00',
              expt_admis_dt: '2021-03-29',
              expt_dschrg_dt: '2021-04-05',
            },
          ],
          hsc_keys: [
            {
              hsc_key_val: 'A004609516',
              hsc_key_typ_ref_id: 19971,
            },
          ],
        },
      ],
    };
    spyOn(service, 'getHscDuplicates').and.returnValue(
      of(duplicateCheckResponse).toPromise(),
    );
    const response = await service.getHscDuplicates(
      duplicateCheckRequestInput,
      httpRequest,
    );
    expect(duplicateCheckResponse.hsc_duplicates.length).toEqual(1);
  });
});
