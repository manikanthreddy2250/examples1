import { HttpService, Injectable, Logger } from '@nestjs/common';
import { DuplicateCheckRequestInput } from '../../models/duplicateCheckRequest.input';
import { HttpRequest } from '@azure/functions';
import { DuplicateCheckResponse } from '../../models/duplicateCheckResponse';
import { GraphQLClient } from 'graphql-request/dist';
import { ReferenceConstants } from '../../../shared/constants/referenceConstants';
import {
  getFacilityHscListByIndvId,
  getHscAuthorization,
  getNonFacilityHscListByIndvId,
} from '../../../shared/graphql/healthservicedomain/healthServiceQuery';
import { HealthServiceClient } from '../../../shared/graphql/healthservicedomain/healthServiceClient';
import { ConfigService } from '@nestjs/config';
import moment = require('moment');
import { DmnService } from '../dmn/dmn.service';
import { RulesConstants } from '../../../shared/constants/rulesConstants';
import { DuplicateCheckHscInput } from '../../models/duplicateCheckHsc.input';
import {
  diagCdRefQuery,
  ProceduresByCodesCpt4Query,
  ProceduresByCodesHCPCSQuery,
} from '../../../shared/graphql/referencedomain/referenceQuery';
import { ReferenceClient } from '../../../shared/graphql/referencedomain/referenceClient';

@Injectable()
export class DuplicateCheckService {
  constructor(
    private readonly healthServiceClient: HealthServiceClient,
    private readonly referenceClient: ReferenceClient,
    private readonly logger: Logger,
    private readonly configService: ConfigService,
    private readonly dmnService: DmnService,
    private readonly httpService: HttpService,
  ) {}

  async getHscDuplicates(
    duplicateCheckRequestInput: DuplicateCheckRequestInput,
    httpRequest: HttpRequest,
  ): Promise<DuplicateCheckResponse> {
    const hscGraphqlClient: GraphQLClient = this.healthServiceClient.getGraphqlClient(
      httpRequest,
    );
    let hscDuplicates = [];
    let dmnResponse;
    let dmnResponseData;
    try {
      if (duplicateCheckRequestInput.hsc.hsc_id) {
        // query hsc domain to get case details and set hsc fields in req
        const hscResponse = await hscGraphqlClient.request(getHscAuthorization, {
          hscId: duplicateCheckRequestInput.hsc.hsc_id,
        });

        if (hscResponse.hsc.length > 0) {
          const hsc = hscResponse.hsc[0];
          duplicateCheckRequestInput.hsc = hsc;
          duplicateCheckRequestInput.hsc.hsc_facl = hsc.hsc_facls.find(
            (facl) =>
              facl.expt_admis_dt != null || facl.actul_admis_dttm != null,
          );
          dmnResponseData = await this.fetchDuplicateCheckCriteriaFromBpmn(
            hsc,
            duplicateCheckRequestInput,
            httpRequest,
          );
        } else {
          return { hsc_duplicates: hscDuplicates };
        }
      }
      if (!dmnResponseData) {
        //evaluate DMN directly - external clients without bpmn workflows
        dmnResponse = await this.evaluateDMN(
          duplicateCheckRequestInput,
          httpRequest,
        );
        dmnResponseData = dmnResponse.data;
      }
      let existingHscListResponse;
      if (
        duplicateCheckRequestInput.hsc.srvc_set_ref_id ===
          ReferenceConstants.SERVICESETTINGTYPE_INPATIENT_REFID ||
        duplicateCheckRequestInput.hsc.srvc_set_ref_id ===
          ReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY_REFID
      ) {
        existingHscListResponse = await hscGraphqlClient.request(
          getFacilityHscListByIndvId,
          {
            indv_key_typ_ref_id:
              duplicateCheckRequestInput.hsc.indv_key_typ_ref_id,
            indv_key_val: duplicateCheckRequestInput.hsc.indv_key_val,
            inpatientRefID:
              ReferenceConstants.SERVICESETTINGTYPE_INPATIENT_REFID,
            outpatientFacilityRefID:
              ReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY_REFID,
          },
        );
      } else {
        existingHscListResponse = await hscGraphqlClient.request(
          getNonFacilityHscListByIndvId,
          {
            indv_key_typ_ref_id:
              duplicateCheckRequestInput.hsc.indv_key_typ_ref_id,
            indv_key_val: duplicateCheckRequestInput.hsc.indv_key_val,
            outpatientRefID:
              ReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_REFID,
          },
        );
      }
      if (
        existingHscListResponse.hsc.length > 0 &&
        dmnResponseData.length > 0
      ) {
        hscDuplicates = existingHscListResponse.hsc.filter((existingHsc) => {
          const incomingHsc = duplicateCheckRequestInput.hsc;
          return (
            incomingHsc.hsc_id !== existingHsc.hsc_id &&
            incomingHsc.srvc_set_ref_id === existingHsc.srvc_set_ref_id &&
            this.checkDuplicateCriteria(
              duplicateCheckRequestInput,
              existingHsc,
              dmnResponseData,
            )
          );
        });
        /*if (hscDuplicates.length > 0) {
          for (const hscValue of hscDuplicates) {
            const referenceGraphqlClient: GraphQLClient = this.referenceClient.getGraphqlClient(
              httpRequest,
            );
            await this.prepareHscServiceResponse(
              hscValue,
              referenceGraphqlClient,
            );
            await this.prepareHscDiagResponse(referenceGraphqlClient, hscValue);
          }
        }*/
        hscDuplicates = await this.buildDiagProcDescription(hscDuplicates, httpRequest);
      }
    } catch (e) {
      this.logger.error(
        'Exception occured while getting hsc duplicates ===== ' + e,
      );
    }
    return { hsc_duplicates: hscDuplicates };
  }

  private async buildDiagProcDescription(hscDuplicates, httpRequest){
    if (hscDuplicates.length > 0) {
      for (const hscValue of hscDuplicates) {
        const referenceGraphqlClient: GraphQLClient = this.referenceClient.getGraphqlClient(
                httpRequest,
        );
        await this.prepareHscServiceResponse(
                hscValue,
                referenceGraphqlClient,
        );
        await this.prepareHscDiagResponse(referenceGraphqlClient, hscValue);
      }
    }
    return hscDuplicates;
  }

  private async prepareHscServiceResponse(hscValue, referenceGraphqlClient) {
    const cpt4Codes = [];
    const hcpcsCodes = [];
    const procListResult: any = [];

    for (const item of hscValue.hsc_srvcs) {
      if (item.proc_othr_txt == null) {
        switch (item.proc_cd_schm_ref_id) {
          case ReferenceConstants.PROCEDURE_TYPE_CPT4_REF_ID:
            cpt4Codes.push(item.proc_cd);
            break;
          case ReferenceConstants.PROCEDURE_TYPE_HCPCS_REF_ID:
            hcpcsCodes.push(item.proc_cd);
            break;
        }
      }
    }

    if (cpt4Codes.length > 0) {
      const cpt4ProcList = await referenceGraphqlClient.request(
        ProceduresByCodesCpt4Query,
        { procCodes: cpt4Codes },
      );
      procListResult.push.apply(procListResult, cpt4ProcList.cpt4);
    }
    if (hcpcsCodes.length > 0) {
      const hscpcProcList = await referenceGraphqlClient.request(
        ProceduresByCodesHCPCSQuery,
        { procCodes: hcpcsCodes },
      );
      procListResult.push.apply(procListResult, hscpcProcList.hcpcs);
    }
    for (const item of hscValue.hsc_srvcs) {
      if (item.proc_cd) {
        const procRecord = procListResult.find(
          (proc) => proc.proc_cd === item.proc_cd,
        );
        item.proc_othr_txt = procRecord ? procRecord.cd_desc : null;
      }
    }
  }

  private async prepareHscDiagResponse(referenceGraphqlClient, hscValue) {
    const diagCodes = [];
    hscValue.hsc_diags.forEach((data) => {
      diagCodes.push(data.diag_cd);
    });
    const hscDiagRefDataList = await referenceGraphqlClient.request(
      diagCdRefQuery,
      { diag_cds: diagCodes },
    );
    hscValue.hsc_diags.forEach((item) => {
      if (item.diag_cd) {
        const diagRecord = hscDiagRefDataList.icd10.find(
          (element) => element.diag_cd === item.diag_cd,
        );
        item.diag_desc = diagRecord ? diagRecord.cd_desc : null;
      }
    });
  }

  private async fetchDuplicateCheckCriteriaFromBpmn(
    hsc,
    duplicateCheckRequestInput: DuplicateCheckRequestInput,
    httpRequest: HttpRequest,
  ) {
    let dmnResponseData;
    if (hsc.hsc_keys && hsc.hsc_keys.length > 0) {
      const hscKeyBPMProcessId = hsc.hsc_keys.find(
        (hsc_key) =>
          ReferenceConstants.HSC_KEY_TYP_REF_ID_BPMID ===
          hsc_key.hsc_key_typ_ref_id,
      )?.hsc_key_val;
      if (hscKeyBPMProcessId) {
        //get DMN Response from BPMN - web intake workflow
        if (
          duplicateCheckRequestInput.hsc.srvc_set_ref_id ===
          ReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_REFID
        ) {
          dmnResponseData = await this.getOPDuplicateCriteria(
            hscKeyBPMProcessId,
            httpRequest,
          );
        } else {
          dmnResponseData = await this.getIPOPFDuplicateCriteria(
            hscKeyBPMProcessId,
            httpRequest,
          );
        }
      }
    }
    return dmnResponseData;
  }

  private async evaluateDMN(
    duplicateCheckRequestInput: DuplicateCheckRequestInput,
    httpRequest: HttpRequest,
  ) {
    //TODO derive serviceType and currentStep dynamically. include in request? or remove from DMN input columns for clients without bpmn workflow?
    const duplicateCheckDmnRequest = {
      hsc: {
        serviceType: 'Generic',
        serviceSettingRefId: duplicateCheckRequestInput.hsc.srvc_set_ref_id,
      },
      currentStep: 0,
    };
    return await this.dmnService.evaluateDmn(
      RulesConstants.DUPLICATE_CHECK_DMN_NAME,
      duplicateCheckDmnRequest,
      httpRequest,
    );
  }

  checkDuplicateCriteria(
    duplicateCheckRequestInput: DuplicateCheckRequestInput,
    existingHsc,
    dmnResponseData,
  ): boolean {
    let isDuplicate = true;
    const incomingHsc = duplicateCheckRequestInput.hsc;
    for (let j = 0; j < dmnResponseData.length; j++) {
      if (dmnResponseData[j].duplicateCheckCriteria) {
        switch (dmnResponseData[j].duplicateCheckCriteria) {
          case RulesConstants.DUP_CHECK_CRITERIA_HSC_STATUS:
            isDuplicate = dmnResponseData[j].duplicateCheckValues.includes(
              existingHsc.hsc_sts_ref_id,
            );
            break;
          case RulesConstants.DUP_CHECK_CRITERIA_SUBMITTING_PROV:
            isDuplicate = this.doesSubmittingProviderMatch(
              incomingHsc,
              existingHsc,
            );
            break;
          case RulesConstants.DUP_CHECK_CRITERIA_FACILITY_TYPE:
            isDuplicate = this.facilityCheck(existingHsc, incomingHsc);
            break;
          case RulesConstants.DUP_CHECK_CRITERIA_ACTUAL_ADMIT_DT:
          case RulesConstants.DUP_CHECK_CRITERIA_SERVICE_START_DT:
            isDuplicate = this.facilityDatesInRange(
              existingHsc,
              incomingHsc,
              dmnResponseData[j].duplicateCheckValues,
            );
            break;
          case RulesConstants.DUP_CHECK_CRITERIA_PROCEDUCRE_START_DT:
            isDuplicate = this.nonFacilityDatesInRange(
              existingHsc,
              incomingHsc,
              dmnResponseData[j].duplicateCheckValues,
            );
            break;
        }
        if (!isDuplicate) {
          return false; // return if any one of the criteria doesn't meet
        }
      }
    }
    return isDuplicate;
  }

  private facilityCheck(existingHsc, incomingHsc) {
    let facilityMatch = false;
    if (
      existingHsc.srvc_set_ref_id ===
        ReferenceConstants.SERVICESETTINGTYPE_INPATIENT_REFID ||
      existingHsc.srvc_set_ref_id ===
        ReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY_REFID
    ) {
      if (existingHsc.hsc_facls.length > 0 && incomingHsc.hsc_facl) {
        facilityMatch =
          existingHsc.hsc_facls[0].plsrv_ref_id ===
          incomingHsc.hsc_facl.plsrv_ref_id;
      }
    } else if (
      existingHsc.srvc_set_ref_id ===
      ReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_REFID
    ) {
      facilityMatch = this.OPFacilityCheck(existingHsc, incomingHsc);
    }
    return facilityMatch;
  }

  private OPFacilityCheck(existingHsc, incomingHsc) {
    let facilityMatch = false;
    if (
      existingHsc.hsc_srvcs &&
      existingHsc.hsc_srvcs.length > 0 &&
      existingHsc.hsc_srvcs &&
      existingHsc.hsc_srvcs.length > 0
    ) {
      const existingHscValidSrvc = existingHsc.hsc_srvcs.find(
        (item) => item.proc_cd != null,
      );
      const incomingHscValidSrvc = incomingHsc.hsc_srvcs.find(
        (item) => item.proc_cd != null,
      );
      const existingHscNonFacl =
        existingHscValidSrvc &&
        existingHscValidSrvc.hsc_srvc_non_facls &&
        existingHscValidSrvc.hsc_srvc_non_facls.length > 0
          ? existingHscValidSrvc.hsc_srvc_non_facls[0]
          : null;
      const incomingHscNonFacl =
        incomingHscValidSrvc &&
        incomingHscValidSrvc.hsc_srvc_non_facls &&
        incomingHscValidSrvc.hsc_srvc_non_facls.length > 0
          ? incomingHscValidSrvc.hsc_srvc_non_facls[0]
          : null;
      if (existingHscNonFacl && incomingHscNonFacl) {
        facilityMatch =
          existingHscNonFacl.plsrv_ref_id === incomingHscNonFacl.plsrv_ref_id;
      }
    }
    return facilityMatch;
  }

  private doesSubmittingProviderMatch(
    incomingHsc: DuplicateCheckHscInput,
    existingHsc,
  ) {
    if (
      existingHsc.hsc_provs &&
      incomingHsc.hsc_provs &&
      incomingHsc.hsc_provs.length > 0
    ) {
      const submittingProv = incomingHsc.hsc_provs.find(
        (input_prov) =>
          input_prov.hsc_prov_roles.find(
            (role) =>
              role.prov_role_ref_id ===
              ReferenceConstants.PROVIDER_ROLE_REF_ID_REQUESTING,
          ) != null,
      );
      const submittingProvKeys =
        submittingProv &&
        submittingProv.prov_loc_affil_dtl &&
        submittingProv.prov_loc_affil_dtl.providerDetails
          ? submittingProv.prov_loc_affil_dtl.providerDetails.prov_keys
          : null;
      return (
        submittingProvKeys &&
        existingHsc.hsc_provs.some(
          (prov) =>
            prov.prov_loc_affil_dtl &&
            prov.prov_loc_affil_dtl.providerDetails &&
            prov.prov_loc_affil_dtl.providerDetails.prov_keys &&
            prov.prov_loc_affil_dtl.providerDetails.prov_keys.some(
              (provKey) =>
                submittingProvKeys.find(
                  (subProvkey) =>
                    subProvkey.prov_key_val === provKey.prov_key_val,
                ) != null,
            ),
        )
      );
    } else {
      return false;
    }
  }

  isInBetween(incomingHscDt, submittedHscDt, range) {
    return moment(incomingHscDt).isBetween(
      moment(submittedHscDt).subtract(range, 'day'),
      moment(submittedHscDt).add(range, 'day'),
      'days',
      '[]',
    );
  }

  facilityDatesInRange(
    existingHsc: any,
    incomingHsc: DuplicateCheckHscInput,
    range,
  ) {
    const existingHscFacl = existingHsc.hsc_facls.find(
      (facl) => facl.expt_admis_dt != null || facl.actul_admis_dttm != null,
    );
    const incomingHscFacl = incomingHsc.hsc_facl;
    if (incomingHscFacl && existingHscFacl) {
      if (
        existingHsc.srvc_set_ref_id ===
        ReferenceConstants.SERVICESETTINGTYPE_INPATIENT_REFID
      ) {
        const existingCaseActualAdmDt = existingHscFacl?.actul_admis_dttm;
        const existingCaseExpectedAdmDt = existingHscFacl?.expt_admis_dt;
        const incomingCaseActualAdmDt = incomingHscFacl.actul_admis_dttm;
        const incomingCaseExpectedAdmDt = incomingHscFacl.expt_admis_dt;

        return incomingCaseActualAdmDt
          ? this.isInBetween(
              incomingCaseActualAdmDt,
              existingCaseActualAdmDt,
              range,
            )
          : this.isInBetween(
              incomingCaseExpectedAdmDt,
              existingCaseExpectedAdmDt,
              range,
            );
      } else {
        const existingCaseActualAdmDt = existingHscFacl?.actul_admis_dttm;
        const incomingCaseActualAdmDt = incomingHscFacl.actul_admis_dttm;
        return existingCaseActualAdmDt
          ? this.isInBetween(
              incomingCaseActualAdmDt,
              existingCaseActualAdmDt,
              range,
            )
          : false;
      }
    } else {
      return false;
    }
  }

  nonFacilityDatesInRange(
    existingHsc: any,
    incomingHsc: DuplicateCheckHscInput,
    range,
  ) {
    const hscServices = incomingHsc.hsc_srvcs;
    if (hscServices.length > 0 && existingHsc.hsc_srvcs.length > 0) {
      const validServices = [...hscServices].filter(
        (service) =>
          service.hsc_srvc_non_facls &&
          service.hsc_srvc_non_facls.length > 0 &&
          service.hsc_srvc_non_facls[0].srvc_strt_dt != null,
      );
      const sortedServicesByStartDate = [...validServices].sort(
        (a, b) =>
          a.hsc_srvc_non_facls[0].srvc_strt_dt.valueOf() -
          b.hsc_srvc_non_facls[0].srvc_strt_dt.valueOf(),
      );
      let earliestStartDate =
        sortedServicesByStartDate[0].hsc_srvc_non_facls[0].srvc_strt_dt;
      const primaryService = existingHsc.hsc_srvcs.find(
        (service) =>
          service.proc_cd != null && service.hsc_srvc_non_facls.length > 0,
      );
      const primaryServiceStartDate = primaryService
        ? primaryService.hsc_srvc_non_facls[0].srvc_strt_dt
        : null;
      for (const hscService of validServices) {
        const currentServiceStartDate =
          hscService.hsc_srvc_non_facls[0].srvc_strt_dt;
        if (moment(currentServiceStartDate).isBefore(earliestStartDate)) {
          earliestStartDate = currentServiceStartDate;
        }
      }
      return primaryServiceStartDate
        ? this.isInBetween(earliestStartDate, primaryServiceStartDate, range)
        : false;
    } else {
      return false;
    }
  }

  async getIPOPFDuplicateCriteria(
    baseProcessInstanceId: string,
    httpRequest: HttpRequest,
  ) {
    const queryParameter = '?superProcessInstance=';
    let duplicateCheckCretiria = [];
    const bpmnHeaders = this.getBpmnHeaders(httpRequest);
    const processInstanceResponse = await this.httpService
      .get(
        this.configService.get('PROCESS_INSTANCE_BASE_URL') +
          queryParameter +
          baseProcessInstanceId,
        {
          headers: bpmnHeaders,
        },
      )
      .toPromise();
    const processInstanceId = processInstanceResponse.data[0].id;
    const variableResponse = await this.httpService
      .get(
        this.configService.get('PROCESS_INSTANCE_BASE_URL') +
          `${processInstanceId}/variables`,
        {
          headers: bpmnHeaders,
        },
      )
      .toPromise();
    if (
      variableResponse &&
      variableResponse.data.dupcheck &&
      variableResponse.data.dupcheck.value
    ) {
      duplicateCheckCretiria = variableResponse.data.dupcheck.value;
    }
    return duplicateCheckCretiria;
  }

  async getOPDuplicateCriteria(
    baseProcessInstanceId: string,
    httpRequest: HttpRequest,
  ) {
    const queryParameter = '?superProcessInstance=';
    let duplicateCheckCretiria = [];
    const bpmnHeaders = this.getBpmnHeaders(httpRequest);
    const processInstanceResponse = await this.httpService
      .get(
        this.configService.get('PROCESS_INSTANCE_BASE_URL') +
          queryParameter +
          baseProcessInstanceId,
        {
          headers: bpmnHeaders,
        },
      )
      .toPromise();
    const processInstanceId = processInstanceResponse.data[0].id;
    const subProcessInstanceResponse = await this.httpService
      .get(
        this.configService.get('PROCESS_INSTANCE_BASE_URL') +
          queryParameter +
          processInstanceId,
        {
          headers: bpmnHeaders,
        },
      )
      .toPromise();
    const subprocessInstanceId = subProcessInstanceResponse.data[0].id;
    const variableResponse = await this.httpService
      .get(
        this.configService.get('PROCESS_INSTANCE_BASE_URL') +
          `${subprocessInstanceId}/variables`,
        {
          headers: bpmnHeaders,
        },
      )
      .toPromise();
    if (variableResponse && variableResponse.data.dupcheck) {
      duplicateCheckCretiria = variableResponse.data.dupcheck.value;
    }
    return duplicateCheckCretiria;
  }

  private getBpmnHeaders(httpRequest: HttpRequest) {
    const bpmnHeaders = {
      Authorization: httpRequest.headers['authorization'],
      'x-bpm-cli-org-id': httpRequest.headers['x-bpm-cli-org-id'],
      'x-bpm-func-role': httpRequest.headers['x-bpm-func-role'],
      'x-bpm-tenant-id': httpRequest.headers['x-bpm-tenant-id'],
    };
    return bpmnHeaders;
  }
}
