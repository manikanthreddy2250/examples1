import { Test, TestingModule } from '@nestjs/testing';
import {HealthServiceClient} from "../../../shared/graphql/healthservicedomain/healthServiceClient";
import {ConfigService} from "@nestjs/config";
import {GetHscAuthService} from "./getHscAuth.service";
import {GetHscAuthRequest} from "../../models/getHscAuthRequest";
import {GraphQLClient} from "graphql-request/dist";
import {RequestDocument} from "graphql-request/dist/types";
import {of} from "rxjs";
import {HttpRequest} from "@azure/functions";
import {ProviderClient} from "../../../shared/graphql/providerdomain/providerClient";
import { IndividualClient } from "../../../shared/graphql/individualdomain/individualClient";
import {ReferenceClient} from "../../../shared/graphql/referencedomain/referenceClient";
import { LoggerModule } from 'nestjs-pino';
import {MemberCommunicationClient} from "../../../shared/graphql/communication-domain/memberCommunicationClient";

class MockGraphQLClient extends GraphQLClient{
    request(document: RequestDocument, variables?: any, requestHeaders?: any): Promise<any>{
      if(variables.hscId) {
        return of({"hsc": [{"hsc_id": 13237, "hsc_diags": [ {"diag_cd":"M51.21"},{"diag_cd":"M21.53"}], "indv_id":503926748,
                    "hsc_srvcs": [
                        {
                            "hsc_id": 13469,
                            "chg_user_id": "",
                            "creat_user_id": "",
                            "proc_cd": "80346",
                            "proc_cd_schm_ref_id": 2,
                            "srvc_hsc_prov_id": null
                        },
                        {
                            "hsc_id": 13460,
                            "chg_user_id": "",
                            "creat_user_id": "",
                            "proc_cd": "80346",
                            "proc_cd_schm_ref_id": 4,
                            "srvc_hsc_prov_id": null
                        }
                    ],
                    "hsr_actvs": [
                        {
                            "hsr_actv_id": 18,
                            "creat_user_id": "",
                            "chg_user_id": "",
                            "actv_typ_ref_id": 17292,
                            "hsr_actv_sbjs": [
                                {
                                    "hsr_actv_id": 18,
                                    "hsr_sbj_rec_id": 71199,
                                    "hsr_sbj_typ_ref_id": 25863,
                                    "hsr_sbj_typ_ref_cd": null
                                }
                            ]
                        }
                    ]}]}
      ).toPromise();
      }else if(variables.diag_cds){
        return of({"icd10" : [{"diag_cd":"M51.21","cd_desc":"mydiag"}]}).toPromise();
      }else if(variables.procCodes){
        return of({"cpt4":{"proc_cd":"80346","cd_desc":"Mydiag"}}).toPromise();
      }else if(variables.indvKeyVal || variables.userName){
        return of({"hsc": [{
          creat_dttm:'2021-03-07T10:22:53.328',
          creat_user_id:'SYSTEM',
          hsc_id:13237,
          indv_id:503926748,
          state_ref_id: 1098,
          state_ref_dspl_nm: "ILLINOIS",
          state_ref_cd:"IL",
          hsc_sts_ref_id:19274,
          indv_key_val:'16440436900',
          hsc_provs:[{prov_loc_affil_dtl :{providerDetails:{prov_id: 6675410, prov_adr_id: 98265064, prov_cat_typ_ref_id: 16309}}}],
          hsc_sts_ref_cd:{ref_desc: 'Draft'},
          srvc_set_ref_cd:{ref_desc: 'Outpatient'},
          mbr_cov_dtl:{indv_id: 503926748, pol_nbr: '0752023', cov_eff_dt: '2020-02-01', cov_end_dt: '9999-12-31', mbr_cov_id: 90881933}
        }]}).toPromise();
      }
    }
}

class MockHealthServiceClient {
    public getGraphqlClient(httpRequest: HttpRequest): GraphQLClient {
        return new MockGraphQLClient('testurl');
    }
}

class MockIndvGraphQLClient extends GraphQLClient{
  request(document: RequestDocument, variables?: any, requestHeaders?: any): Promise<any>{
    if(variables.indvId)    {
      return of({"indv_adr":[{adr_typ_ref_id:2131, indv_id: 503926748,indv_adr_id:7,st_ref_id:1079,st_ref_cd :{ref_dspl: 'test',ref_cd: 'IL'}}]}).toPromise();
    }
    else{
      return of({"indv_key":[{indv_key_val:"16440436900",indv:{fst_nm: 'Matt', lst_nm: 'Meyer'}}]}).toPromise();
    }
     
  }
}

class MockIndividualServiceClient {
  public getGraphqlClient(httpRequest: HttpRequest): GraphQLClient {
      return new MockIndvGraphQLClient('testurl');
  }
}

class MockProviderServiceClient {
    public getGraphqlClient(httpRequest: HttpRequest): GraphQLClient {
        return new MockProviderGraphQLClient('testurl');
    }
}

class MockProviderGraphQLClient extends GraphQLClient{
    request(document: RequestDocument, variables?: any, requestHeaders?: any): Promise<any>{
        return of({"v_prov_srch":[{fst_nm: 'ProvFirstName', lst_nm: 'ProvLastName', "bus_nm": "ProvBusinessName", "prov_id": 6675410, "prov_adr_id": 98265064}]}).toPromise();
    }
}


class MockReferenceClient {
    public getGraphqlClient(): GraphQLClient {
        return new MockGraphQLClient('testurl');
    }
}

class MockMemberCommunicationClient {
    public getGraphqlClient(httpRequest: HttpRequest): GraphQLClient {
        return new MockMemberCommunicationGraphQLClient('testurl');
    }
}

class MockMemberCommunicationGraphQLClient extends GraphQLClient{
    request(document: RequestDocument, variables?: any, requestHeaders?: any): Promise<any>{
        return of({
            "mbr_cmnct": [
                {
                    "mbr_cmnct_id": 71199,
                    "creat_user_id": "SYSTEM",
                    "creat_dttm": "2021-07-20T17:23:26.002",
                    "chg_user_id": "SYSTEM",
                    "chg_dttm": "2021-07-20T17:23:26.002",
                    "commt_txt": "ovc_mbr_appt_confirmation_template.html",
                    "cmnct_adr_dtl": "{\"address\":\"viswanath_c@optum.com\"}",
                    "dsclmr_cnsnt_desc": null,
                    "mbr_cmnct_catgy_ref_id": 2563,
                    "mbr_cmnct_chnl_ref_id": 17272,
                    "mbr_cmnct_dir_ref_id": 20087,
                    "mbr_cmnct_prr_ref_id": 2515,
                    "mbr_cmnct_rsn_ref_id": 20090,
                    "mbr_cmnct_sts_ref_id": 20066,
                    "mbr_cmnct_sts_rsn_ref_id": null,
                    "mbr_cmnct_typ_ref_id": 20089,
                    "sts_dttm": "2021-07-20T00:00:00",
                    "updt_ver_nbr": 0,
                    "mbr_cmnct_prtcps": [
                        {
                            "mbr_cmnct_id": 71199,
                            "mbr_cmnct_prtcp_id": 40490,
                            "fst_nm": "HOS",
                            "lst_nm": "User",
                            "mbr_cmnct_prtcp_engage_lvl_ref_id": null,
                            "mbr_cmnct_prtcp_role_ref_id": 1052,
                            "prtcp_desc": "Video Chat",
                            "prtcp_key_typ_ref_id": 1052,
                            "prtcp_key_val": "001007131"
                        }
                    ]
                }
            ]
        }).toPromise();
    }
}

describe('GetHscAuthService', () => {
  let service: GetHscAuthService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
        imports: [LoggerModule.forRoot()],
      providers: [GetHscAuthService, ProviderClient,
          {provide: IndividualClient, useClass: MockIndividualServiceClient},
          {provide: ReferenceClient, useClass: MockReferenceClient},
          {provide: HealthServiceClient, useClass: MockHealthServiceClient},
          {provide: ProviderClient, useClass: MockProviderServiceClient},
          {provide: MemberCommunicationClient, useClass: MockMemberCommunicationClient},
          ConfigService],
    }).compile();

    service = module.get<GetHscAuthService>(GetHscAuthService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('should call hsc AuthDetails', () => {
      let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
      const getHscAuthRequest: GetHscAuthRequest = {hsc:{hsc_id : 13237}};
      service.hscAuthDetails(getHscAuthRequest, httpRequest).then((res) => {
          expect(res.hsc[0].hsc_id).toEqual(13237);
      });
  });
});
