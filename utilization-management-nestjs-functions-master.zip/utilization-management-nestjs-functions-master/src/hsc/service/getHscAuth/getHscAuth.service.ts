import { Injectable } from '@nestjs/common';
import { HealthServiceClient } from '../../../shared/graphql/healthservicedomain/healthServiceClient';
import {GetHscAuthRequest} from "../../models/getHscAuthRequest";
import {GetHscAuthResponse} from "../../models/getHscAuthResponse";
import {getHscAuthorization} from "../../../shared/graphql/healthservicedomain/healthServiceQuery";
import {ReferenceConstants} from "../../../shared/constants/referenceConstants";
import {GraphQLClient} from "graphql-request/dist";
import {HttpRequest} from "@azure/functions";
import {ReferenceClient} from "../../../shared/graphql/referencedomain/referenceClient";
import {diagCdRefQuery, ProceduresByCodesCpt4Query, ProceduresByCodesHCPCSQuery} from "../../../shared/graphql/referencedomain/referenceQuery";
import {getPermAdrByIndvId} from "../../../shared/graphql/individualdomain/individualQuery";
import {IndividualClient} from "../../../shared/graphql/individualdomain/individualClient";
import {InjectPinoLogger, PinoLogger} from "nestjs-pino/dist";
import {HsrActv} from "../../models/hsrActv";
import {HsrActvSbj} from "../../models/hsrActvSbj";
import {getMbrCmnctQuery} from "../../../shared/graphql/communication-domain/memberCommunicationQuery";
import {MemberCommunicationClient} from "../../../shared/graphql/communication-domain/memberCommunicationClient";

@Injectable()
export class GetHscAuthService {

    constructor(private readonly healthServiceClient: HealthServiceClient,
                private readonly referenceClient: ReferenceClient, private readonly individualClient: IndividualClient,
                private readonly memberCommunicationClient: MemberCommunicationClient,
                @InjectPinoLogger(GetHscAuthService.name) private readonly logger: PinoLogger) {}

    async hscAuthDetails(getHscAuthRequest : GetHscAuthRequest, httpRequest: HttpRequest): Promise<GetHscAuthResponse> {
        let response: GetHscAuthResponse = null;
        try {
            const hscGraphqlClient: GraphQLClient = this.healthServiceClient.getGraphqlClient(httpRequest);
            const referenceGraphqlClient: GraphQLClient = this.referenceClient.getGraphqlClient(httpRequest);
            const mbrCmnctGraphQLClient: GraphQLClient = this.memberCommunicationClient.getGraphqlClient(httpRequest);
            const hscId = getHscAuthRequest.hsc.hsc_id;
            const cpt4Codes = [];
            const  hcpcsCodes = [];
            const  procListResult: any = [];
            let hscResponse = await hscGraphqlClient.request(getHscAuthorization, {hscId});
            console.log("hscResponse", JSON.stringify(hscResponse));
            const diagCodes = [];
            hscResponse.hsc[0].hsc_diags.forEach((data) => {
                if(data.diag_cd !== null) {
                    diagCodes.push(data.diag_cd);
                }
            });
            const hscDiagRefDataList = await referenceGraphqlClient.request(diagCdRefQuery, {"diag_cds": diagCodes});
            hscResponse.hsc[0].hsc_diags.forEach((item) => {
                if(item.diag_cd) {
                    const diagRecord = hscDiagRefDataList.icd10.find(element => element.diag_cd === item.diag_cd);
                    item.diag_desc = diagRecord ? diagRecord.cd_desc: null;
                }
            });

            hscResponse.hsc[0].hsc_srvcs.forEach((item) => {

                if(item.proc_othr_txt == null){
                    switch (item.proc_cd_schm_ref_id) {
                        case ReferenceConstants.PROCEDURE_TYPE_CPT4_REF_ID:
                            cpt4Codes.push(item.proc_cd);
                            break;
                        case ReferenceConstants.PROCEDURE_TYPE_HCPCS_REF_ID:
                            hcpcsCodes.push(item.proc_cd);
                            break;
                    }
                }
            });
            hscResponse=await this.prepareHscResponseforstateofresidence( httpRequest,hscResponse);
            hscResponse=await this.prepareHscResponse(procListResult,referenceGraphqlClient,hcpcsCodes,cpt4Codes ,hscResponse);
            hscResponse = await this.getMemberCommsByActvId(hscResponse, mbrCmnctGraphQLClient, httpRequest);

            // migrate business logic from utilization-mgmnt functions
            response = {
                "hsc": hscResponse.hsc
            };
        } catch (e) {
            this.logger.error("Exception occurred in hscAuthDetails method for hscId: " +getHscAuthRequest.hsc.hsc_id +" Exception: " + e);
            throw e;
        }
        return response;
    }
    async prepareHscResponseforstateofresidence( httpRequest, hscResponse){

            if (hscResponse.hsc[0].indv_id){
                const indvAdr = await this.getIndvAdrByIndvId(hscResponse.hsc[0].indv_id, httpRequest);
                let homeAdrExists:boolean=false;
                if(indvAdr.indv_adr){
                    indvAdr.indv_adr.forEach((item) => {
                        if(!homeAdrExists)   {
                            hscResponse.hsc[0].state_ref_id = item.st_ref_id;
                            hscResponse.hsc[0].state_ref_dspl_nm =  item.st_ref_cd.ref_dspl;
                            hscResponse.hsc[0].state_ref_cd = item.st_ref_cd.ref_cd;
                        }
                        if(item.adr_typ_ref_id==2131)   {
                            homeAdrExists=true;
                        }
                    });
                }
            }
            return hscResponse;
        }

    async prepareHscResponse(procListResult,referenceGraphqlClient,hcpcsCodes,cpt4Codes ,hscResponse){
            if (cpt4Codes.length > 0) {
                const cpt4ProcList = await referenceGraphqlClient.request(ProceduresByCodesCpt4Query, {"procCodes": cpt4Codes});
                procListResult.push.apply(procListResult, cpt4ProcList.cpt4);
            }

            if (hcpcsCodes.length > 0) {
                const hscpcProcList = await referenceGraphqlClient.request(ProceduresByCodesHCPCSQuery, {"procCodes": hcpcsCodes});
                procListResult.push.apply(procListResult, hscpcProcList.hcpcs);
            }



            hscResponse.hsc[0].hsc_srvcs.forEach((item) => {
                if (item.proc_cd) {
                    const procRecord = procListResult.find((proc) => proc.proc_cd === item.proc_cd);
                    if(item.proc_othr_txt == null){
                        item.proc_othr_txt = procRecord ? procRecord.cd_desc: null;
                    }
                }
            });
        return hscResponse;
    }

    private async getIndvAdrByIndvId(indvId:bigint,httpRequest:HttpRequest){
        const individualGraphqlClient: GraphQLClient = this.individualClient.getGraphqlClient(httpRequest);
        const indServiceVariable = {indvId: indvId};
        let indvData;
        try {
            indvData = await individualGraphqlClient.request(getPermAdrByIndvId, indServiceVariable);
        } catch (e) {
            console.error("Unable to get data from Individual domain");}
        return indvData;
    }

    private async getMemberCommsByActvId(hscResponse: any, mbrCmnctGraphQLClient: GraphQLClient, httpRequest: HttpRequest) {
        if (hscResponse.hsc[0].hsr_actvs) {

            // await Promise.all(hscResponse.hsc[0].hsr_actvs.forEach(async (activity) => {
            //     const hsrActvSbj: HsrActvSbj = activity.hsr_actv_sbjs.find((actvSbj: HsrActvSbj) => actvSbj.hsr_sbj_typ_ref_id === ReferenceConstants.SBJ_TYP_REF_ID_MBR_CMNCT_ID);
            //
            //     const mbrCmnctsData = await mbrCmnctGraphQLClient.request(getMbrCmnctQuery, {mbrCmnctId: hsrActvSbj.hsr_sbj_rec_id});
            //     activity.mbr_cmnct = mbrCmnctsData.mbr_cmnct[0];
            //     console.log('Fetched Member Communications for hsrActvId - ' + activity.hsr_actv_id);
            // }));
            for await (const activity of hscResponse.hsc[0].hsr_actvs) {
                const hsrActvSbj: HsrActvSbj = activity.hsr_actv_sbjs.find((actvSbj: HsrActvSbj) => actvSbj.hsr_sbj_typ_ref_id === ReferenceConstants.SBJ_TYP_REF_ID_MBR_CMNCT_ID);

                if (hsrActvSbj) {
                    const mbrCmnctsData = await mbrCmnctGraphQLClient.request(getMbrCmnctQuery, {mbrCmnctId: hsrActvSbj.hsr_sbj_rec_id});
                    activity.mbr_cmnct = mbrCmnctsData.mbr_cmnct[0];
                    console.log('Fetched Member Communications for hsrActvId - ' + activity.hsr_actv_id);
                }
            }
        }
        return hscResponse;
    }

}
