import { Test, TestingModule } from '@nestjs/testing';
import { HealthServiceClient } from '../../../shared/graphql/healthservicedomain/healthServiceClient';
import { ConfigService } from '@nestjs/config';
import { GraphQLClient } from 'graphql-request/dist';
import { RequestDocument } from 'graphql-request/dist/types';
import { of } from 'rxjs';
import { HttpRequest } from '@azure/functions';
import { GetMemberHscHistoryRequest } from '../../models/getMemberHscHistoryRequest';
import { ProviderClient } from '../../../shared/graphql/providerdomain/providerClient';
import { IndividualClient } from '../../../shared/graphql/individualdomain/individualClient';
import { ReferenceClient } from '../../../shared/graphql/referencedomain/referenceClient';
import { GetUserHscHistoryRequest } from 'src/hsc/models/getUserHscHistoryRequest';
import { HscHistoryService } from './hscHistory.service';
import { GetProviderHscHistoryRequest } from '../../models/getProviderHscHistoryRequest';

class MockGraphQLClient extends GraphQLClient {
  request(
    document: RequestDocument,
    variables?: any,
    requestHeaders?: any,
  ): Promise<any> {
    return of({
      hsc: [
        {
          creat_dttm: '2021-03-07T10:22:53.328',
          creat_user_id: 'SYSTEM',
          hsc_id: 13237,
          hsc_sts_ref_id: 19274,
          indv_id: 503926748,
          indv_key_val: '16440436900',
          hsc_provs: [
            {
              prov_loc_affil_dtl: {
                providerDetails: {
                  prov_id: 6675410,
                  prov_adr_id: 98265064,
                  prov_cat_typ_ref_id: 16309,
                },
              },
            },
          ],
          hsc_sts_ref_cd: { ref_desc: 'Draft' },
          srvc_set_ref_cd: { ref_desc: 'Outpatient' },
          mbr_cov_dtl: {
            indv_id: 503926748,
            pol_nbr: '0752023',
            cov_eff_dt: '2020-02-01',
            cov_end_dt: '9999-12-31',
            mbr_cov_id: 90881933,
          },
        },
      ],
    }).toPromise();
  }
}

class MockHealthServiceClient {
  public getGraphqlClient(httpRequest: HttpRequest): GraphQLClient {
    return new MockGraphQLClient('testurl');
  }
}

class MockIndvGraphQLClient extends GraphQLClient {
  request(
    document: RequestDocument,
    variables?: any,
    requestHeaders?: any,
  ): Promise<any> {
    return of({
      indv_key: [
        { indv_key_val: '16440436900', indv:{fst_nm: 'Matt', lst_nm: 'Meyer' }}
      ],
    }).toPromise();
  }
}

class MockIndividualServiceClient {
  public getGraphqlClient(httpRequest: HttpRequest): GraphQLClient {
    return new MockIndvGraphQLClient('testurl');
  }
}

class MockProviderServiceClient {
  public getGraphqlClient(httpRequest: HttpRequest): GraphQLClient {
    return new MockProviderGraphQLClient('testurl');
  }
}

class MockProviderGraphQLClient extends GraphQLClient {
  request(
    document: RequestDocument,
    variables?: any,
    requestHeaders?: any,
  ): Promise<any> {
    return of({
      v_prov_srch: [
        {
          fst_nm: 'ProvFirstName',
          lst_nm: 'ProvLastName',
          bus_nm: 'ProvBusinessName',
          prov_id: 6675410,
          prov_adr_id: 98265064,
        },
      ],
    }).toPromise();
  }
}

class MockReferenceClient {
  public getGraphqlClient(): GraphQLClient {
    return new MockGraphQLClient('testurl');
  }
}

describe('HscHistoryService', () => {
  let service: HscHistoryService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        HscHistoryService,
        ProviderClient,
        { provide: IndividualClient, useClass: MockIndividualServiceClient },
        { provide: ReferenceClient, useClass: MockReferenceClient },
        { provide: HealthServiceClient, useClass: MockHealthServiceClient },
        { provide: ProviderClient, useClass: MockProviderServiceClient },
        ConfigService,
      ],
    }).compile();

    service = module.get<HscHistoryService>(HscHistoryService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('getHscHistoryByMemberId should return Hscs for a given member in request', () => {
    const httpRequest: HttpRequest = {
      method: null,
      url: '/test?session_id=encryptedid',
      headers: { authorization: 'test token', 'x-hasura-role': 'testrole' },
      query: { test: 'test' },
      params: { test: 'test' },
    };
    const getMemberHscHistoryRequest: GetMemberHscHistoryRequest = {
      indv_key_val: '16440436900',
    };
    service
      .getHscHistoryByMemberId(getMemberHscHistoryRequest, httpRequest)
      .then((res) => {
        expect(res.hsc.length).toEqual(1);
      });
  });

  it('getHscHistoryByMemberId should return Hscs created by UserId in request', () => {
    const httpRequest: HttpRequest = {
      method: null,
      url: '/test?session_id=encryptedid',
      headers: { authorization: 'test token', 'x-hasura-role': 'testrole' },
      query: { test: 'test' },
      params: { test: 'test' },
    };
    const getUserHscHistoryRequest: GetUserHscHistoryRequest = {
      creat_user_id: '16440436900',
    };
    service
      .getHscHistoryByUserId(getUserHscHistoryRequest, httpRequest)
      .then((res) => {
        expect(res.hsc.length).toEqual(1);
      });
  });

  it('getHscHistoryByProvider should return Hscs with Provider in request as Requesting role', () => {
    const httpRequest: HttpRequest = {
      method: null,
      url: '/test?session_id=encryptedid',
      headers: { authorization: 'test token', 'x-hasura-role': 'testrole' },
      query: { test: 'test' },
      params: { test: 'test' },
    };
    const getProviderHscHistoryRequest: GetProviderHscHistoryRequest = {
      prov_key_val: '288158608',
      prov_key_typ_ref_id: 16333,
    };
    service
      .getHscHistoryByProvider(getProviderHscHistoryRequest, httpRequest)
      .then((res) => {
        expect(res.hsc.length).toEqual(1);
      });
  });
});
