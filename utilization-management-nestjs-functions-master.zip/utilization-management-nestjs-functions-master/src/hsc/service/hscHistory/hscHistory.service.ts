import { Injectable } from '@nestjs/common';
import { HealthServiceClient } from '../../../shared/graphql/healthservicedomain/healthServiceClient';
import {
    getHscDataByMemberIdQuery, getHscDatabyUserNameQuery, getHscHistoryByProvider
} from "../../../shared/graphql/healthservicedomain/healthServiceQuery";
import {GraphQLClient} from "graphql-request/dist";
import {HttpRequest} from "@azure/functions";
import { GetMemberHscHistoryRequest } from '../../models/getMemberHscHistoryRequest';
import { HscHistoryResponse } from '../../models/getHscHistoryResponse';
import { GetUserHscHistoryRequest } from 'src/hsc/models/getUserHscHistoryRequest';
import {GetProviderHscHistoryRequest} from "../../models/getProviderHscHistoryRequest";
import {getProviderbyProvIDAdrIdQuery} from "../../../shared/graphql/providerdomain/providerQuery";
import {getIndvDetailByIndvKeyVal, getPermAdrByIndvId} from "../../../shared/graphql/individualdomain/individualQuery";
import {ProviderClient} from "../../../shared/graphql/providerdomain/providerClient";
import {IndividualClient} from "../../../shared/graphql/individualdomain/individualClient";

@Injectable()
export class HscHistoryService {

    constructor(private readonly healthServiceClient: HealthServiceClient,private readonly providerClient: ProviderClient, private individualClient: IndividualClient) {}

    async getHscHistoryByMemberId(getMemberHscHistoryRequest: GetMemberHscHistoryRequest, httpRequest: HttpRequest): Promise<HscHistoryResponse>  {
        const indv_key_val = getMemberHscHistoryRequest.indv_key_val;
        const hscGraphqlClient: GraphQLClient = this.healthServiceClient.getGraphqlClient(httpRequest);
        let hscHistorResponse: HscHistoryResponse;

        if (indv_key_val) {
            try{
                const memberAuthHistoryRecords = await hscGraphqlClient.request(getHscDataByMemberIdQuery, {"indvKeyVal": indv_key_val});
                if (memberAuthHistoryRecords.hsc.length > 0) {
                    const memberAuthHistoryValues: any = await this.populateHscRecords(memberAuthHistoryRecords.hsc, httpRequest);
                    hscHistorResponse = { hsc:memberAuthHistoryValues}
                }
                return hscHistorResponse;
            }
            catch(e){
                console.log("Error While processing HSC Member Details",e);
            }
        }
    }

    async getHscHistoryByUserId(getUserHscHistoryRequest: GetUserHscHistoryRequest, httpRequest: HttpRequest): Promise<HscHistoryResponse>  {
        const userName = getUserHscHistoryRequest.creat_user_id;
        const hscGraphqlClient: GraphQLClient = this.healthServiceClient.getGraphqlClient(httpRequest);
        let hscHistorResponse: HscHistoryResponse;

        if(userName){
            try{
                const userAuthHistoryRecords = await hscGraphqlClient.request(getHscDatabyUserNameQuery, {"userName": userName});
                if (userAuthHistoryRecords.hsc.length > 0) {
                    const userAuthHistoryValues: any = await this.populateHscRecords(userAuthHistoryRecords.hsc, httpRequest);
                    hscHistorResponse = { hsc:userAuthHistoryValues}
                }
                return hscHistorResponse;
            }
            catch(e){
                console.error(e);
            }
        }
    }

    async getHscHistoryByProvider(getProviderHscHistoryRequest: GetProviderHscHistoryRequest, httpRequest: HttpRequest): Promise<HscHistoryResponse>  {
        const hscGraphqlClient: GraphQLClient = this.healthServiceClient.getGraphqlClient(httpRequest);
        let hscHistorResponse: HscHistoryResponse;
        try{
            const providerHscHistoryRecords = await hscGraphqlClient.request(getHscHistoryByProvider, getProviderHscHistoryRequest);
            if (providerHscHistoryRecords.hsc.length > 0) {
                const providerHscHistory: any = await this.populateHscRecords(providerHscHistoryRecords.hsc, httpRequest);
                hscHistorResponse = { hsc:providerHscHistory}
            }
            return hscHistorResponse;
        }
        catch(e){
            console.error(e);
        }
    }

    private async populateHscRecords(hscRecords: any, httpRequest: HttpRequest) {
        let authHistoryValues = [];
        const provIds = [];
        const provAdrIds = [];
        const indvDetails = await this.getIndvDetails(hscRecords,httpRequest);
        if(hscRecords.length > 0) {
            for (var i = 0; i < hscRecords.length; i++) {
                const provId = hscRecords[i].hsc_provs[0] ? hscRecords[i].hsc_provs[0]?.prov_loc_affil_dtl.providerDetails.prov_id : 0;
                const provAdrId = hscRecords[i].hsc_provs[0] ? hscRecords[i].hsc_provs[0]?.prov_loc_affil_dtl.providerDetails.prov_adr_id : 0;
                authHistoryValues.push({
                    hscId: hscRecords[i].hsc_id,
                    // Unable to add indv into hsc as remote schema. Temp fix to avoid long loading time
                    indv_key_val: hscRecords[i].indv_key_val,
                    memberName: null,
                    placeOfService: hscRecords[i].srvc_set_ref_cd ? hscRecords[i].srvc_set_ref_cd.ref_desc: "",
                    createDate: hscRecords[i].creat_dttm,
                    status: hscRecords[i].hsc_sts_ref_cd ? hscRecords[i].hsc_sts_ref_cd.ref_desc: "",
                    prov_id: provId,
                    prov_adr_id: provAdrId,
                });
                provIds.push(provId);
                provAdrIds.push(provAdrId);
            }

            const providerRes = await this.getProviderName(provIds, provAdrIds, httpRequest);
            authHistoryValues = await this.buildMemberData(authHistoryValues,indvDetails);
            authHistoryValues = await this.buildProviderData(authHistoryValues,providerRes);
        }
        return authHistoryValues;
    };

    /**
     * returns provider Name from provider graphql based on prov_id and prov_adr_id
     */
    private async getProviderName(provIds: any, provAdrIds: any, httpRequest: HttpRequest) {
        const providerServiceVariable = {provIds:provIds, provAdrIds:provAdrIds};
        const provGraphqlClient: GraphQLClient = this.providerClient.getGraphqlClient(httpRequest);

        let providerData: any;
        try {
            providerData = await provGraphqlClient.request(getProviderbyProvIDAdrIdQuery, providerServiceVariable);
        } catch (e) {
            console.error("Provider Query Error ");
        }
        return providerData;
    };

    private async buildProviderData(authHistoryValues: any,providerRes : any){
        authHistoryValues.forEach(async (record) => {
            record.createDate = new Date(record.createDate);

            if(record.prov_id === 0){
                record.providerName = null;
            }
            const providerDetails = providerRes.v_prov_srch.find(element => element.prov_id === record.prov_id && element.prov_adr_id === record.prov_adr_id)
            if (providerDetails.fst_nm != null) {
                record.providerName = providerDetails.lst_nm + ',' + providerDetails.fst_nm;
            } else{
                record.providerName = providerDetails.bus_nm;
            }
        });
        return authHistoryValues;
    }

    private async getIndvDetails(hscRecords:any,httpRequest:HttpRequest){
        const individualGraphqlClient: GraphQLClient = this.individualClient.getGraphqlClient(httpRequest);
        const result = await hscRecords.map(a => a.indv_key_val);
        const records = result.filter(function(v,i) { return result.indexOf(v) == i; });
        const indvkeyId = records.filter(function(el) { return el; });
        const indServiceVariable = {indvkeyId: indvkeyId};
        let indvData;
        try {
            indvData = await individualGraphqlClient.request(getIndvDetailByIndvKeyVal, indServiceVariable);
        } catch (e) { console.error("Unable to get data from Individual domain")}

        return indvData;
    }

    private async buildMemberData(authHistoryValues: any,indvDetails : any){
        authHistoryValues.forEach(async (record) => {
            if(record.indv_key_val){
                indvDetails.indv_key.forEach((item) => {
                    if(record.indv_key_val === item.indv_key_val){
                        record.memberName = item.indv.lst_nm + ', ' + item.indv.fst_nm
                    }
                })
            }
        });
        return authHistoryValues;
    }
}
