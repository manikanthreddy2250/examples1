import { Test, TestingModule } from '@nestjs/testing';
import {ConfigModule, ConfigService} from "@nestjs/config";
import {HttpRequest} from "@azure/functions";
import {GraphQLClient} from "graphql-request/dist";
import {RequestDocument} from "graphql-request/dist/types";
import {of} from "rxjs";
import {HttpModule, Logger} from "@nestjs/common";
import {MemberService} from "./member.service";
import {IndividualClient} from "../../../shared/graphql/individualdomain/individualClient";
import {MemberClient} from "../../../shared/graphql/memberdomain/memberClient";
import {LoggerModule, PinoLogger} from "nestjs-pino/dist";
import {LoggerCoreModule} from "nestjs-pino/dist/LoggerCoreModule";

class MockIndividualGraphQLClient extends GraphQLClient{
    request(document: RequestDocument, variables?: any, requestHeaders?: any): Promise<any>{
        if(variables.indvkeyId){
            return of({
                "indv_key": [
                    {
                        "indv":{
                            "fst_nm": "Matt",
                            "lst_nm": "Meyer",
                        },
                        "indv_id": 503926748,
                        "indv_key_val": "16440436900",

                    }
                ]}).toPromise();
        }
        else if(variables.orig_sys_mbr_id){
            return of({
                "mbrshp": [{
                    "mbr_covs": [
                        {
                            "cov_eff_dt": "2020-02-01",
                            "cov_end_dt": "9999-12-31",
                            "mbr_cov_id": 90881959,
                            "pol_nbr": "0752023",
                            "cov_typ_ref_cd": {
                                "ref_desc": "Medical"
                            },
                            "prdct_catgy_ref_cd": null,
                            "clm_pltfm_ref_id": 363,
                            "prdct_ref_id": 226
                        }
                    ],
                    "orig_sys_cd": "CDB_CS",
                    "orig_sys_mbr_id": "16440436900",
                    "orig_sys_ref_id": 2043,
                    "src_mbr_id": "30830290",
                    "src_mbr_partn_id": "10"
                }]
            }).toPromise();
        }
    }
}


class MockIndividualClient {
    public getGraphqlClient(httpRequest: HttpRequest): GraphQLClient {
        return new MockIndividualGraphQLClient('testurl');
    }
}

class MockMembershipGraphQLClient extends GraphQLClient{
    request(document: RequestDocument, variables?: any, requestHeaders?: any): Promise<any>{
        return of({
            "mbrshp": [{
                "mbr_covs": [
                    {
                        "cov_eff_dt": "2020-02-01",
                        "cov_end_dt": "9999-12-31",
                        "mbr_cov_id": 90881959,
                        "pol_nbr": "0752023",
                        "cov_typ_ref_cd": {
                            "ref_desc": "Medical"
                        },
                        "prdct_catgy_ref_cd": null,
                        "clm_pltfm_ref_id": 363,
                        "prdct_ref_id": 226
                    }
                ],
                "orig_sys_cd": "CDB_CS",
                "orig_sys_mbr_id": "16440436900",
                "orig_sys_ref_id": 2043,
                "src_mbr_id": "30830290",
                "src_mbr_partn_id": "10"
            }]
        }).toPromise();
    }
}

class MockMembershipClient {
    public getGraphqlClient(httpRequest: HttpRequest): GraphQLClient {
        return new MockMembershipGraphQLClient('testurl');
    }
}



describe('MemberService', () => {
    let service: MemberService;
    const context = {req: {headers: {}}};
    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({ imports: [ LoggerModule.forRoot()],
            providers: [MemberService, ConfigService,
                { provide: IndividualClient, useClass: MockIndividualClient }, { provide: MemberClient, useClass: MockMembershipClient }],
        }).compile();

        service = module.get<MemberService>(MemberService);
    });

    it('should be defined', () => {
        expect(service).toBeDefined();
    });

    it('should call get Member Data', () => {
        const mbr_cov = {
                "fst_nm": "Matt",
                "lst_nm": "Meyer",
                "bth_dt": new Date("1978-07-26"),
                "gdr_ref_id": 2109,
                "orig_sys_cd": "CDB_CS",
                "cov_eff_dt": new Date("2013-01-01"),
                "cov_end_dt": new Date("9999-12-31"),
                "src_mbr_id": "30830290",
                "src_mbr_partn_id": "10",
                "pol_nbr": "0128855",
                "cov_typ_ref_id": null,
                "clm_pltfm_ref_id": 363
        }
        const httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
        service.getMemberCoverageDetails('1234', 2757, mbr_cov,httpRequest).then((res) => {
            expect(res.v_prov_srch[0].indv_id).toEqual(503926748);
        });
    });
});
