import {Injectable, Logger} from "@nestjs/common";
import {HttpRequest} from "@azure/functions";
import {
    getIndvByIndvKeyVal,
    getMemberCoveDetails
} from "../../../shared/graphql/individualdomain/individualQuery";
import {IndividualClient} from "../../../shared/graphql/individualdomain/individualClient";
import {MemberCovInput} from "../../models/memberCov.input";
import {MemberClient} from "../../../shared/graphql/memberdomain/memberClient";
import {InjectPinoLogger, PinoLogger} from "nestjs-pino/dist";

@Injectable()
export class MemberService {
    constructor( @InjectPinoLogger(MemberService.name) private readonly logger: PinoLogger,
                private individualGraphqlClient: IndividualClient, private membershipClient: MemberClient) {
    }

    async getMemberCoverageDetails(indv_key_val: string, indv_key_typ_ref_id: number, mbr_cov: MemberCovInput, httpRequest: HttpRequest){
        let memberResponse: any;
        let memberCovResponse: any;
        let indvData;
        const indServiceVariable = {indvkeyId: indv_key_val};
        try {
            const memberVariables = {
                orig_sys_mbr_id : indv_key_val,
                orig_sys_cd : mbr_cov.orig_sys_cd,
                src_mbr_id : mbr_cov.src_mbr_id,
                src_mbr_partn_id : mbr_cov.src_mbr_partn_id,
                cov_eff_dt : mbr_cov.cov_eff_dt,
                cov_end_dt : mbr_cov.cov_end_dt,
                pol_nbr : mbr_cov.pol_nbr,
                cov_typ_ref_id : mbr_cov.cov_typ_ref_id
            };
            this.logger.info("Before Query(IDSearch) to individual domain for indv_key_val: " +indv_key_val +" at " + new Date());
            indvData = await this.individualGraphqlClient.getGraphqlClient(httpRequest).request(getIndvByIndvKeyVal, indServiceVariable);
            this.logger.info("After Query(IDSearch) to individual domain for indv_key_val: " +indv_key_val +" at " + new Date());
            this.logger.info("Before Query(getMemberCovDetails) to membership domain for indv_key_val: " +indv_key_val +" at " +new Date());
            memberResponse = await this.membershipClient.getGraphqlClient(httpRequest).request(getMemberCoveDetails, memberVariables);
            this.logger.info("After Query(getMemberCovDetails) to membership domain for indv_key_val: " +indv_key_val +" at " +new Date());
             memberCovResponse = {
                indv_key_val: indv_key_val,
                indv_key_typ_ref_id: indv_key_typ_ref_id,
                indv_id: indvData.indv_key[0].indv_id,
                mbr_cov_id: memberResponse.mbrshp[0].mbr_covs[0].mbr_cov_id,
                cov_eff_dt: memberResponse.mbrshp[0].mbr_covs[0].cov_eff_dt,
                cov_end_dt: memberResponse.mbrshp[0].mbr_covs[0].cov_end_dt,
                pol_nbr: memberResponse.mbrshp[0].mbr_covs[0].pol_nbr,
                 lob_ref_id:memberResponse.mbrshp[0].mbr_covs[0].lob_ref_id,
                 marketNumber:memberResponse.mbrshp[0].mbr_covs[0].mbr_cov_unets[0].mkt_nbr_ref_cd ? memberResponse.mbrshp[0].mbr_covs[0].mbr_cov_unets[0].mkt_nbr_ref_cd.ref_cd : null,
                 marketType: memberResponse.mbrshp[0].mbr_covs[0].mbr_cov_unets[0].mkt_typ_ref_cd ? memberResponse.mbrshp[0].mbr_covs[0].mbr_cov_unets[0].mkt_typ_ref_cd.ref_cd : null,
                 product_code: memberResponse.mbrshp[0].mbr_covs[0].prdct_ref_cd ? memberResponse.mbrshp[0].mbr_covs[0].prdct_ref_cd.ref_cd : null,
                 pol_iss_st_ref_cd:memberResponse.mbrshp[0].mbr_covs[0].pol_iss_st_ref_cd ? memberResponse.mbrshp[0].mbr_covs[0].pol_iss_st_ref_cd.ref_cd : null,
                coverageTypeDesc: memberResponse.mbrshp[0].mbr_covs[0].cov_typ_ref_cd ? memberResponse.mbrshp[0].mbr_covs[0].cov_typ_ref_cd.ref_desc : null,
                productCatgyTpe: memberResponse.mbrshp[0].mbr_covs[0].prdct_catgy_ref_cd ? memberResponse.mbrshp[0].mbr_covs[0].prdct_catgy_ref_cd.ref_desc : null,
                claim_platform_ref_Id: memberResponse.mbrshp[0].mbr_covs[0].clm_pltfm_ref_id,
                claim_platform_ref_cd: memberResponse.mbrshp[0].mbr_covs[0].clm_pltfrm_ref_cd ? memberResponse.mbrshp[0].mbr_covs[0].clm_pltfrm_ref_cd : null,
                productCode: memberResponse.mbrshp[0].mbr_covs[0].prdct_ref_id,
                orig_sys_mbr_id : indv_key_val,
                orig_sys_cd : mbr_cov.orig_sys_cd,
                src_mbr_id : mbr_cov.src_mbr_id,
                src_mbr_partn_id : mbr_cov.src_mbr_partn_id,
            }
        } catch (e) {
            this.logger.error("Exception Occurred in while fetching individual/member coverage details : " + e)
            throw e;
        }
        return memberCovResponse;
    }

}




