import { Test, TestingModule } from '@nestjs/testing';
import {ConfigModule, ConfigService} from "@nestjs/config";
import {HttpRequest} from "@azure/functions";
import {GraphQLClient} from "graphql-request/dist";
import {RequestDocument} from "graphql-request/dist/types";
import {of} from "rxjs";
import {ProviderClient} from "../../shared/graphql/providerdomain/providerClient";
import {ProviderService} from "./provider.service";
import {HttpModule, Logger} from "@nestjs/common";
import {HealthServiceClient} from "../../shared/graphql/healthservicedomain/healthServiceClient";
import {ProviderBaasClient} from "../../shared/graphql/providerbaas/providerBaasClient";
import {LoggerModule, PinoLogger} from "nestjs-pino/dist";

class MockGraphQLClient extends GraphQLClient{
    request(document: RequestDocument, variables?: any, requestHeaders?: any): Promise<any>{
        if(variables.provRoleId){
            return of({
                "hsc_prov": [
                {
                    "hsc_prov_id": 5457,
                    "prov_loc_affil_dtl": {
                        "providerDetails": {
                            "prov_adr": {
                                "cty_nm": "Santa Monica",
                                "st_ref_id": 1067,
                                "zip_cd_txt": "904043414",
                                "adr_ln_1_txt": "1920 Colorado Ave",
                                "adr_ln_2_txt": null
                            },
                            "prov_keys": [
                                {
                                    "prov_key_val": "1851525091",
                                    "prov_key_typ_ref_id": 2782
                                },
                                {
                                    "prov_key_val": "288158608",
                                    "prov_key_typ_ref_id": 16333
                                },
                                {
                                    "prov_key_val": "1710081369",
                                    "prov_key_typ_ref_id": 2783
                                }
                            ]
                        }
                    }
                }
            ]
            }).toPromise();
        }else{
            return of({
                v_prov_srch: [{ prov_loc_affil_id: 1, prov_id: 23, prov_adr_id: 321, prov_catgy_ref_id: 16309}]
            }).toPromise();
        }

    }
}

class MockProviderBaasGraphQLClient extends GraphQLClient {
    request(document: RequestDocument, variables?: any, requestHeaders?: any): Promise<any> {
        return of({
            facilitySummary0002: {FacilitySummary0002Response: []}
        }).toPromise();
    }
}

class MockProviderClient {
    public getGraphqlClient(httpRequest: HttpRequest): GraphQLClient {
        return new MockGraphQLClient('testurl');
    }
}

class MockHealthServiceClient {
    public getGraphqlClient(httpRequest: HttpRequest): GraphQLClient {
        return new MockGraphQLClient('testurl');
    }
}

class MockProviderBaasClient {
    public getGraphqlClient(httpRequest: HttpRequest): GraphQLClient {
        return new MockProviderBaasGraphQLClient('testurl');
    }
}


describe('ProviderService', () => {
    let service: ProviderService;
    let context = {req: {headers: {}}};
    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({imports: [LoggerModule.forRoot()],
          providers: [ProviderService, ConfigService,{provide: ProviderClient, useClass: MockProviderClient},{provide: HealthServiceClient, useClass: MockHealthServiceClient},
              {provide: ProviderBaasClient, useClass: MockProviderBaasClient}],
        }).compile();
  
        service = module.get<ProviderService>(ProviderService);
      });
  
    it('should be defined', () => {
    expect(service).toBeDefined();
    });

    it('should call get Provider Data', () => {
        let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
        service.getProvData('1234','3456', "test", null, "test", "test", 12, '', '', '',httpRequest).then((res) => {
            expect(res.v_prov_srch[0].prov_catgy_ref_id).toEqual(16309);
        });
    });

    it('should call get Provider Id', () => {
        let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
        const hscProvInput = {"prov_keys": [
                {
                    "prov_key_typ_ref_id": 2782,
                    "prov_key_val": "1851525091"
                },
                {
                    "prov_key_typ_ref_id": 16333,
                    "prov_key_val": "288158608"
                },
                {
                    "prov_key_typ_ref_id": 2783,
                    "prov_key_val": "1710081369"
                }
            ],
            "hsc_prov_roles": [
                {
                    "prov_role_ref_id": 3765
                }
            ],
            "prov_adr": {
                "adr_ln_1_txt": "1920 Colorado Ave",
                "adr_ln_2_txt": null,
                "zip_cd_txt": "904043414",
                "cty_nm": "Santa Monica",
                "st_ref_id": 1067
            }
        };
        service.getProviderId(hscProvInput,'3456', httpRequest).then((res) => {
            expect(res).toEqual(5457);
        });
    });
    it('should call get Nrt Facility Contract Data', () => {
        let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
        service.getNrtFacilityContractData('1234','3456',473,4,httpRequest).then((res) => {
            expect(res.prov_contr[0].prov_contr_id).toEqual(147);
        });
    });

    it('should call get PES Facility Contract Data', () => {
        let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
        const hscProvInput = {"prov_keys": [
                {
                    "prov_key_typ_ref_id": 2782,
                    "prov_key_val": "1851525091"
                },
                {
                    "prov_key_typ_ref_id": 16333,
                    "prov_key_val": "288158608"
                },
                {
                    "prov_key_typ_ref_id": 2783,
                    "prov_key_val": "1710081369"
                }
            ],
            "hsc_prov_roles": [
                {
                    "prov_role_ref_id": 3765
                }
            ],
            "prov_adr": {
                "adr_ln_1_txt": "1920 Colorado Ave",
                "adr_ln_2_txt": null,
                "zip_cd_txt": "904043414",
                "cty_nm": "Santa Monica",
                "st_ref_id": 1067
            }
        };
        const mbr_cov_mrk="";
        service.getPesFacilityContractData(hscProvInput,'1234','3456',mbr_cov_mrk, httpRequest).then((res) => {
            expect(res).toBeDefined();
        });
    });
    it('should call get getAddressSequenceNumber', () => {
            let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
            const hscProvInput = {"prov_keys": [
                    {
                        "prov_key_typ_ref_id": 2782,
                        "prov_key_val": "1851525091"
                    },
                    {
                        "prov_key_typ_ref_id": 16333,
                        "prov_key_val": "288158608"
                    },
                    {
                        "prov_key_typ_ref_id": 2783,
                        "prov_key_val": "1710081369"
                    }
                ],
                "hsc_prov_roles": [
                    {
                        "prov_role_ref_id": 3765
                    }
                ],
                "prov_adr": {
                    "adr_ln_1_txt": "1920 Colorado Ave",
                    "adr_ln_2_txt": null,
                    "zip_cd_txt": "904043414",
                    "cty_nm": "Santa Monica",
                    "st_ref_id": 1067
                }
            };
            service.getAddressSequenceNumber(hscProvInput,'1234', httpRequest).then((res) => {
                expect(res).toBeDefined();
            });
        });
    it('should call getMedNecTypeDataForEnI', () => {
        let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
        service.getMedNecTypeDataForEnI('1234','3456',473,4, httpRequest).then((res) => {
            expect(res).toBeDefined();
        });
    });
 });
