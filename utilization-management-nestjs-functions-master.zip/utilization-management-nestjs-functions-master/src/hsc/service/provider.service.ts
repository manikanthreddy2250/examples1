import {Injectable, Logger} from "@nestjs/common";
import {nrtFacilityContractQuery, provDetailsQuery, facilitySummaryQueryForAddress, medNecTypeDataQuery} from "../../shared/graphql/providerdomain/providerQuery";
import {GraphQLClient} from "graphql-request/dist";
import {ProviderClient} from "../../shared/graphql/providerdomain/providerClient";
import {HscProvInput} from "../models/hscProv.input";
import {ReferenceConstants} from "../../shared/constants/referenceConstants";
import {getHscProviderId} from "../../shared/graphql/healthservicedomain/healthServiceQuery";
import {HealthServiceClient} from "../../shared/graphql/healthservicedomain/healthServiceClient";
import {HttpRequest} from "@azure/functions";
import {ConfigService} from "@nestjs/config";
import {ProviderBaasClient} from "../../shared/graphql/providerbaas/providerBaasClient";
import {InjectPinoLogger, PinoLogger} from "nestjs-pino/dist";

@Injectable()
export class ProviderService {
    constructor(private readonly providerClient: ProviderClient,
                @InjectPinoLogger(ProviderService.name) private readonly logger: PinoLogger,
                private readonly healthServiceClient: HealthServiceClient, private readonly providerBaasClient: ProviderBaasClient) {
    }

    async getProvData(provKeyVal, provKeyTypeRefId, adrLn1Txt,adrLn2Txt,zipCd, cityNm, stRefId, fstNm, lstNm,
                      busNm, httpRequest: HttpRequest) {
        const provGraphqlClient: GraphQLClient = this.providerClient.getGraphqlClient(httpRequest);
        let provData: any;
        try {
            const healthServiceVariables = {
                prov_key_val: provKeyVal,
                prov_key_typ_ref_id: provKeyTypeRefId,
                adr_ln_1_txt: adrLn1Txt,
                adr_ln_2_txt: adrLn2Txt,
                zip_cd_txt: zipCd,
                cty_nm: cityNm,
                st_ref_id: stRefId,
                fst_nm: fstNm,
                lst_nm: lstNm,
                bus_nm: busNm

            };
            this.logger.info("Before Query(provDetailsQuery) to provider domain for Provider : " +provKeyVal +" at:"+ new Date());
            provData = await provGraphqlClient.request(provDetailsQuery, healthServiceVariables);
            this.logger.info("After Query(provDetailsQuery) to provider domain for Provider : " +provKeyVal +" at:"+ new Date());
        } catch (e) {
            this.logger.error("Internal error while processing getProvData" + e)
            throw e;
        }
        return provData
    }

    async getProviderId (hscProvInput: HscProvInput, hsc_id, httpRequest) {
        const hscGraphqlClient: GraphQLClient = this.healthServiceClient.getGraphqlClient(httpRequest);
        let hscProvId: any = null;
        try {
            const getHscProvIdVariable = {
                "provRoleId": ReferenceConstants.PROVIDER_ROLE_REF_ID_SERVICING,
                "hscId": hsc_id
            };
            if(hscProvInput?.prov_keys?.length > 0 && hscProvInput.prov_adr) {
                this.logger.info("Before query (getHscProvId) to health service domain : "+ new Date());
                const hscProvData = await hscGraphqlClient.request(getHscProviderId, getHscProvIdVariable);
                this.logger.info("Before query (getHscProvId) to health service domain : "+ new Date());
                hscProvData.hsc_prov.forEach((prov) => {
                    if (prov.prov_loc_affil_dtl.providerDetails.prov_keys && prov.prov_loc_affil_dtl.providerDetails.prov_adr) {
                        if (hscProvInput.prov_keys[0].prov_key_typ_ref_id == prov.prov_loc_affil_dtl.providerDetails.prov_keys[0].prov_key_typ_ref_id &&
                            hscProvInput.prov_keys[0].prov_key_val == prov.prov_loc_affil_dtl.providerDetails.prov_keys[0].prov_key_val &&
                            hscProvInput.prov_adr.adr_ln_1_txt == prov.prov_loc_affil_dtl.providerDetails.prov_adr.adr_ln_1_txt &&
                            hscProvInput.prov_adr.adr_ln_2_txt == prov.prov_loc_affil_dtl.providerDetails.prov_adr.adr_ln_2_txt &&
                            hscProvInput.prov_adr.cty_nm == prov.prov_loc_affil_dtl.providerDetails.prov_adr.cty_nm &&
                            hscProvInput.prov_adr.zip_cd_txt == prov.prov_loc_affil_dtl.providerDetails.prov_adr.zip_cd_txt &&
                            hscProvInput.prov_adr.st_ref_id == prov.prov_loc_affil_dtl.providerDetails.prov_adr.st_ref_id) {
                            hscProvId = prov.hsc_prov_id;
                        }
                    }
                });
            }
        } catch (e) {
            this.logger.error("Internal error while processing getProviderId : " + e)
            throw e;
        }
        return hscProvId;
    }

    async getNrtFacilityContractData(mpin ,tin, lob_ref_id,addressSeqNumber,httpRequest: HttpRequest) {
        const provGraphqlClient: GraphQLClient = this.providerClient.getGraphqlClient(httpRequest);
        const src_rec_guid="mpin:" + mpin + "|" + "tin:" + tin +  "|" + "addSeqNum:" + addressSeqNumber + "|%";
        let nrtContractResponse: any;
        try {
            const contractVariables = {
                src_rec_guid:src_rec_guid,
                lob_ref_id:lob_ref_id
            };
           nrtContractResponse = await provGraphqlClient.request(nrtFacilityContractQuery, contractVariables);
        } catch (e) {
            this.logger.error("Internal error while processing getNrtFacilityContractData" + e)
        }
        return nrtContractResponse;
    }

    async getMedNecTypeDataForEnI(mpin ,tin,lob_ref_id,addressSeqNumber,httpRequest: HttpRequest) {
        const provGraphqlClient: GraphQLClient = this.providerClient.getGraphqlClient(httpRequest);
        const src_rec_guid="mpin:" + mpin + "|" + "tin:" + tin +   "|" + "addSeqNum:" + addressSeqNumber + "|%";
        let medNecTypeResponse: any;
        try {
                    const contractVariables = {
                        src_rec_guid:src_rec_guid,
                        lob_ref_id:lob_ref_id
            };
        medNecTypeResponse = await provGraphqlClient.request(medNecTypeDataQuery, contractVariables);
        }catch(e){
            this.logger.error("Internal error while processing getMedNecTypeDataForEnI" + e)
        }

        return medNecTypeResponse;
    }

    async getPesFacilityContractData(prov,mpin ,tin,memberCovMarketDetails, httpRequest: HttpRequest){
        let facilitySummaryResponse:any;
        let pesContractResponse: any;
        let pesMednecResponse: any;
        let add_seq_nm:any;
        const resp : any[] = [];
        const provGraphqlClient: GraphQLClient = this.providerClient.getGraphqlClient(httpRequest);
        try {
            if(prov.prov_adr) {
                 const requestBody = {
                    "prov_id" : mpin,
                    "city_nm" : prov.prov_adr.cty_nm,
                    "zip" : prov.prov_adr.zip_cd_txt
                }
                facilitySummaryResponse = await provGraphqlClient.request(facilitySummaryQueryForAddress, requestBody);
                for (const facilityInformation of facilitySummaryResponse.facilitySummary0002.FacilitySummary0002Response) {
                    const postalAddress=facilityInformation.facilityInformation.address.postalAddress;
                    if(postalAddress && postalAddress.addressLine1.toUpperCase() === prov.prov_adr.adr_ln_1_txt.toUpperCase()
                                && postalAddress.city.toUpperCase() === prov.prov_adr.cty_nm.toUpperCase()
                                && postalAddress.zip === prov.prov_adr.zip_cd_txt) {
                        add_seq_nm=facilityInformation.facilityInformation.address.epdAddressSequenceId;
                        console.log("add_seq_nm :"+add_seq_nm);
                        break;
                    }
                }
                await this.isMpinAndAddress(mpin, add_seq_nm, pesContractResponse, provGraphqlClient, pesMednecResponse,memberCovMarketDetails, resp);
            }
        } catch (e) {
            this.logger.error("Internal error while processing getPesFacilityContractData" + e)
        }
        return resp;
    }

    async getAddressSequenceNumber(prov, mpin, httpRequest:HttpRequest){
            let add_seq_nm : any;
            let facilitySummaryResponse : any;
         try {
            if(prov.prov_adr) {
                const requestBody = {
                    "prov_id" : mpin,
                    "city_nm" : prov.prov_adr.cty_nm,
                    "zip" : prov.prov_adr.zip_cd_txt
                }
                const provBaasGraphqlClient: GraphQLClient = this.providerBaasClient.getGraphqlClient(httpRequest);
                this.logger.info("Before Query(getFacilitySummary) to provider baas functions for Provider mpin: " +mpin +" timestamp: "+ new Date());
                facilitySummaryResponse = await provBaasGraphqlClient.request(facilitySummaryQueryForAddress, requestBody);
                this.logger.info("After Query(getFacilitySummary) to provider baas functions for Provider mpin : " +mpin +" timestamp: "+ new Date());
                if(facilitySummaryResponse?.facilitySummary0002?.FacilitySummary0002Response){
                    for (const facilityInformation of facilitySummaryResponse.facilitySummary0002.FacilitySummary0002Response) {
                        const postalAddress=facilityInformation?.facilityInformation?.address?.postalAddress;
                        if(postalAddress && postalAddress?.addressLine1?.toUpperCase() === prov.prov_adr.adr_ln_1_txt?.toUpperCase()
                            && postalAddress?.city?.toUpperCase() === prov.prov_adr.cty_nm?.toUpperCase()
                            && postalAddress?.zip === prov.prov_adr?.zip_cd_txt) {
                            add_seq_nm=facilityInformation?.facilityInformation?.address?.epdAddressSequenceId;
                            break;
                        }
                    }
                }
            }
         }catch (e) {
              this.logger.error("Internal error while processing getAddressSequenceNumber" + e)
         }
         console.log(add_seq_nm);
         return add_seq_nm;
    }

    private async isMpinAndAddress(mpin, add_seq_nm: any, pesContractResponse: any, provGraphqlClient: GraphQLClient, pesMednecResponse: any,memberCovMarketDetails, resp: any[]) {
        if (mpin && add_seq_nm && memberCovMarketDetails.marketNumber && memberCovMarketDetails.marketType && memberCovMarketDetails.product_code) {
            const marketNumber=memberCovMarketDetails.marketNumber;
            const marketType=memberCovMarketDetails.marketType;
            const productCode=memberCovMarketDetails.product_code;
            const gquery: string = 'query getFacilityDetail {facilityDetail0001(facilityDetail0001: {prov_id:"' + mpin + '", adr_seq: "' + add_seq_nm + '",mkt_nbr:"' + marketNumber + '", mkt_typ_cdv: "' + marketType + '",prdct_grp_cd:"' + productCode + '")}';
            pesContractResponse = await provGraphqlClient.request(gquery);
            if (pesContractResponse) {
                const unetContracts = pesContractResponse.facilityDetail0001.FacilityDetail0001Response[0].facilityInformation.commonProviderDetailInformation.unetContract;
                for (const provcontr of unetContracts) {
                    if(provcontr.marketNumber === marketNumber &&  provcontr.marketTypeCode === marketType && provcontr.productGroupCode === productCode) {
                        pesMednecResponse = await this.queryFacility(provcontr, pesMednecResponse, provGraphqlClient, resp);
                    }
                }
            }
        }
    }

    private async queryFacility(provcontr, pesMednecResponse: any, provGraphqlClient: GraphQLClient, resp: any[]) {
        if (provcontr.contractId) {
            const contractPaperTypeTemp = {
                "contractPaperTypeCode": provcontr.contractPaperTypeCode,
                "contractPaperTypeDescription": provcontr.contractPaperTypeDescription,
                "medicalNecessityIndicator": provcontr.medicalNecessityAgreement[0]?.medicalNecessityIndicator
            };
            const gquery: string = 'query getFacilityDetail {facilityDetail0002(facilityDetail0002: {contract_id:"' + provcontr.contractId + '"})}';
            pesMednecResponse = await provGraphqlClient.request(gquery);
            const medNecClause = pesMednecResponse?.facilityDetail0002?.FacilityDetail0002Response[0]?.medNecData;
            resp.push({
                contractPaperType: contractPaperTypeTemp,
                medNecClauseData: this.mapPesFacilityMedNeckData(medNecClause)
            });
        }
        return pesMednecResponse;
    }

    mapPesFacilityMedNeckData(medNecData: any) {
        const medNeckData = [];
        if(medNecData) {
            for (const record of medNecData.medNecClauseData) {
                medNeckData.push(
                    {
                        clauseCode: record?.clauseCode,
                        clinicalDescription: record?.clinicalDescription,
                        provision: record?.provision,
                        standardModifiedIndicator: record?.standardModifiedIndicator
                    }
                );
            }
        }
        return medNeckData.length > 0 ? medNeckData : "";
    }

}




