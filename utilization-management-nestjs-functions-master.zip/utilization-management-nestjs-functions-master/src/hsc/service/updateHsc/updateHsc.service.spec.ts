import {Test, TestingModule} from '@nestjs/testing';
import {HealthServiceClient} from "../../../shared/graphql/healthservicedomain/healthServiceClient";
import {ConfigModule, ConfigService} from "@nestjs/config";
import {GraphQLClient} from "graphql-request/dist";
import {RequestDocument} from "graphql-request/dist/types";
import {of} from "rxjs";
import {UpdateHscRequest} from "../../models/updateHscRequest";
import {updateHscProvider, UpdateHscService} from "./updateHsc.service";
import {HttpRequest} from "@azure/functions";
import {GetHscAuthService} from "../getHscAuth/getHscAuth.service";
import {GetHscAuthResponse} from "../../models/getHscAuthResponse";
import {GetHscAuthRequest} from "../../models/getHscAuthRequest";
import {ProviderService} from "../provider.service";
import {HttpModule} from "@nestjs/common";
import {MemberClient} from "../../../shared/graphql/memberdomain/memberClient";
import {AuthorizationService} from '@ecp/func-tk/dist';
import {AxiosResponse} from 'axios';
import {HscProvInput} from "../../models/hscProv.input";
import {MemberService} from "../member/member.service";
import {HscBusinessEventService} from "../businessEvents/hsc-bus-event/hsc-bus-event.service";
import {HscBusEvent} from "../../models/HscBusEvent";
import {LoggerModule} from "nestjs-pino/dist";
import {HscBusEventName} from "../../models/HscBusEventName";


class MockGraphQLClient extends GraphQLClient{
    request(document: RequestDocument, variables?: any, requestHeaders?: any): Promise<any>{
        if(variables.provRoleId && variables.hscId){
            return of({"hsc_prov": [{"hsc_prov_id":1234}]} ).toPromise();
        }

        if(variables.provKeyTypeRefId && variables.provKeyValue){
            return of({"hsc_prov": [{"hsc_prov_id":1234}]} ).toPromise();
        }

        if(variables.prov){
            return of({"insert_hsc_prov_one":{"hsc_id":13611,"creat_user_id":null,"chg_user_id":null,"telcom_adr_id":null,"prov_loc_affil_dtl":{"providerDetails":{"prov_id":10455660,"prov_keys":[{"prov_key_val":"288158608","prov_key_typ_ref_id":16333},{"prov_key_val":"1710081369","prov_key_typ_ref_id":2782},{"prov_key_val":"1710081369","prov_key_typ_ref_id":2783}],"prov_adr_id":117625650,"prov_cat_typ_ref_id":16310}},"spcl_ref_id":null,"hsc_prov_id":5139,"hsc_prov_roles":[]}}
            ).toPromise();
        }
        else if(variables.prov_role){
            return of({"insert_hsc_prov_role_one":{"hsc_prov_id":5140,"prov_role_ref_id":3759}}
            ).toPromise();
        }
        else if(variables.hscId){
            if(variables.hscId == 13612){
                return of({"hsc":[{"hsc_sts_ref_id": 19274,"hsc_diags":[{"diag_cd": "M21.51", "hsc_diag_id": 12}], "hsc_srvcs": [{"proc_cd":"80346", "hsc_srvc_id": "1", "proc_cd_schm_ref_id": 2}]}]}
                ).toPromise();
            } else if(variables.hscId == 13237){
                return of({"hsc":[{"hsc_sts_ref_id": 19275,"hsc_diags":[{"diag_cd": "M21.51", "hsc_diag_id": 12}], "hsc_srvcs": [{"proc_cd":"80346", "hsc_srvc_id": "1", "proc_cd_schm_ref_id": 2}]}]}
                ).toPromise();
            }else{
                return of({"hsc":[{"hsc_diags":[], "hsc_srvcs": []}]}
                ).toPromise();
            }

        }else if(variables.key){
            return of({"insert_hsc_key":{"hsc_id":13611}}
            ).toPromise();
        }else if(variables.hsc_diag_id){
            return of({"update_hsc_diag_by_pk":{"hsc_diag_id":7385}}
            ).toPromise();
        }else if(variables.hsc_srvc_id){
            return of({"update_hsc_srvc_by_pk":{"hsc_srvc_id":1}}
            ).toPromise();
        }else if(variables.hscFaclInput){
            return of({"update_hsc_facl_by_pk":{"hsc_id":20450}}
            ).toPromise();
        }else if(variables.hsc_prov_id){
            return of({"insert_hsc_prov_role_one":{"hsc_prov_id":13082}}
            ).toPromise();
        }else if(variables.hsc_prov_id && variables.hscProvInput){
            return of({"update_hsc_prov_by_pk":{"hsc_id":21279}}
            ).toPromise();
        }else if(variables.hsr_note_id){
            return of({"update_hsr_note_by_pk":{"hsr_note_id":1234}}
            ).toPromise();
        }
        else if(variables.note){
            return of({"insert_hsr_note_one":{"hsr_note_id":1234}}
            ).toPromise();
        }
        else if(variables.inputArray){
            return of({}
            ).toPromise();
        }
        else if(variables.hsr_asgn_sbj){
            return of({}).toPromise();
        }
        else{
            return of({"hsc_prov": [{"hsc_prov_id":1234}]} ).toPromise();
        }
    }
}


class MockHealthServiceClient {
    public getGraphqlClient(): GraphQLClient {
        return new MockGraphQLClient('testurl');
    }
}

class MockGetHscService {
    hscAuthDetails(getHscAuthRequest: GetHscAuthRequest): Promise<GetHscAuthResponse> {
        const sampleRes: any = {
            hsc: [{
                "hsc_id": 13237,
                "creat_dttm": new Date(),
                "creat_user_id": "001456440",
                "indv_id": 503926748,
                "indv_key_typ_ref_id": 2757,
                "indv_key_val": "16440436900",
                "mbr_cov_dtl": {
                    "indv_id": 503926748,
                    "pol_nbr": "0128855",
                    "cov_eff_dt": "2013-01-01",
                    "cov_end_dt": "9999-12-31",
                    "mbr_cov_id": 96963692,
                    "productCode": 214,
                    "indv_key_val": "16440436900",
                    "productCatgyTpe": null,
                    "coverageTypeDesc": "Medical",
                    "indv_key_typ_ref_id": 2757,
                    "claim_platform_ref_Id": 363
                },
                "hsc_sts_ref_id": 19275,
                "flwup_cntc_dtl": null,
                "rev_prr_ref_id": 3755,
                "rev_prr_ref_cd": {
                    "ref_id": 3755,
                    "ref_cd": "2",
                    "ref_desc": "Urgent",
                    "ref_dspl": "Urgent"
                },
                "srvc_set_ref_id": 3737,
                "srvc_set_ref_cd": {
                    "ref_id": 3737,
                    "ref_cd": "1",
                    "ref_desc": "Inpatient",
                    "ref_dspl": "Inpatient"
                },
                "hsc_keys": [
                    {
                        "hsc_id": 13237,
                        "hsc_key_val": "ff46448e-7515-11eb-908f-1ef9496236e0",
                        "inac_ind": 0,
                        "hsc_key_typ_ref_id": 19517
                    }
                ],
                "hsc_srvcs": [],
                "hsc_srvc_facls": [
                    {
                        "actul_admis_dttm": null,
                        "actul_dschrg_dttm": null,
                        "expt_admis_dt": new Date("2021-04-01"),
                        "expt_dschrg_dt": new Date("2021-04-20"),
                        "plsrv_ref_id": 3743,
                        "plsrv_ref_cd": {
                            "ref_id": 3743,
                            "ref_cd": "21",
                            "ref_desc": "Acute Hospital",
                            "ref_dspl": "Acute Hospital"
                        },
                        "srvc_desc_ref_id": 4349,
                        "srvc_desc_ref_cd": {
                            "ref_id": 4349,
                            "ref_cd": "3",
                            "ref_desc": "Emergent",
                            "ref_dspl": "Emergent"
                        },
                        "srvc_dtl_ref_id": 4296,
                        "srvc_dtl_ref_cd": {
                            "ref_id": 4296,
                            "ref_cd": "1",
                            "ref_desc": "Medical",
                            "ref_dspl": "Medical"
                        }
                    }
                ],
                "hsc_diags": [],
                "hsr_notes":  [
                    {
                        "note_txt_lobj": "testing",
                        "note_titl_txt": "title",
                        "src_user_nm": "clinician",
                        "note_typ_ref_id": 12,
                        "note_catgy_ref_id": null,
                        "note_sts_ref_id":null,
                        "hsr_note_sbjs":[{
                            "note_sbj_rec_id":"123",
                            "note_sbj_typ_ref_id":234,
                        }]
                    }
                ],
                "hsc_provs": [
                    {
                        "auto_aprv_ltr_ind": null,
                        "chg_sys_ref_id": null,
                        "chg_user_id": "001456440",
                        "creat_sys_ref_id": null,
                        "creat_user_id": "001456440",
                        "data_qlty_iss_list": null,
                        "data_secur_rule_list": null,
                        "end_dt": null,
                        "hsc_prov_end_rsn_ref_id": null,
                        "ltr_opt_out_cc_ind": null,
                        "med_rec_nbr": null,
                        "ntwk_strg_rsn_ref_id": null,
                        "ntwk_sts_ref_id": null,
                        "prov_loc_affil_dtl": {
                            "providerDetails": {
                                "prov_id": 9748974,
                                "prov_keys": [
                                    {
                                        "prov_key_val": "1699734293",
                                        "prov_key_typ_ref_id": 2782
                                    },
                                    {
                                        "prov_key_val": null,
                                        "prov_key_typ_ref_id": 16333
                                    },
                                    {
                                        "prov_key_val": "1699734293",
                                        "prov_key_typ_ref_id": 2783
                                    }
                                ],
                                "prov_adr_id": 109644999,
                                "prov_cat_typ_ref_id": 16309
                            }
                        },
                        "prov_loc_affil_id": null,
                        "spcl_ref_id": 16646,
                        "strt_dt": null,
                        "telcom_adr_id": "4102258991",
                        "updt_ver_nbr": 0,
                        "hsc_prov_roles": [
                            {
                                "hsc_prov_id": 4548,
                                "prov_role_ref_id": 3758
                            }
                        ]
                    }
                ],
                "hsr_doc_procs": []
            }
            ]
        };
        return of(sampleRes).toPromise();
    }
}

class ProviderServiceMock {
    getProvData(provKeyVal:any, provKeyTypeRefId:any) : Promise<any>{
        return of({
            v_prov_srch: [{ prov_loc_affil_id: 1, prov_id: 23, prov_adr_id: 321, prov_catgy_ref_id: 16309 }],
        }).toPromise();
    }
    getProviderId (hscProvInput: HscProvInput, hsc_id, httpRequest) {
        return of(1234).toPromise()
    }
    getAddressSequenceNumber(prov, mpin, httpRequest) {
        return of('0001').toPromise();
    }
}

class MockMemberGraphQLClient extends GraphQLClient{
    request(document: RequestDocument, variables?: any, requestHeaders?: any): Promise<any>{
        return of({
            "mbrshp": [
                {
                    "mbr_covs": [
                        {
                            "mbr_cov_id": 90881959,
                            "cov_end_dt": "9999-12-31",
                            "cov_eff_dt": "2020-02-01",
                            "pol_nbr": "0752023",
                            "prdct_typ_ref_cd": {
                                "ref_desc": "POS"
                            },
                            "clm_pltfm_ref_id": 363,
                            "prdct_catgy_ref_cd": null,
                            "prdct_catgy_ref_id": null,
                            "cov_typ_ref_id": 182,
                            "cov_typ_ref_cd": {
                                "ref_desc": "Medical"
                            }
                        }]}]}).toPromise();
    }
}

class MockMemberClient {
    public getGraphqlClient(httpRequest: HttpRequest): GraphQLClient {
        return new MockMemberGraphQLClient('testurl');
    }
}

class MemberServiceMock {
    getMemberCoverageDetails(indvKeyVal, mbr_cov, orgSysCd, context: any) {
        return of({
            indv_id: 511941903,
            pol_nbr: null,
            cov_eff_dt: '0001-01-01',
            cov_end_dt: '9999-12-31',
            mbr_cov_id: 90881974,
            productCode: null,
            indv_key_val: '07007340001078331402002',
            productCatgyTpe: null,
            coverageTypeDesc: 'Medical',
            indv_key_typ_ref_id: 2757,
            claim_platform_ref_Id: null,
        }).toPromise();
    }
}

class MockHscBusinessEventService {
    async publishHscCreateBusinessEvent(hsc_id, httpRequest: HttpRequest) {
        return of({}).toPromise();
    }
    async pushHscBusinessEvents(eventList: HscBusEvent[], httpRequest: HttpRequest) {
        return of({}).toPromise();
    }

    async buildBaseHscPayload(hsc_id: number, httpRequest: HttpRequest,): Promise<any> {
        return of({
            hsc: {hsc_data: {hsc_id:13237}}
        }).toPromise();
    }

}


describe('UpdateHscService', () => {
  let service: UpdateHscService;
  let config: ConfigService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
        imports: [HttpModule,ConfigModule, LoggerModule.forRoot()],
      providers: [UpdateHscService,
          {provide: HealthServiceClient, useClass: MockHealthServiceClient},
          AuthorizationService,
          {provide: GetHscAuthService, useClass: MockGetHscService},
          { provide: MemberService, useClass: MemberServiceMock },
          {provide: ProviderService, useClass: ProviderServiceMock},
          {provide: MemberClient, useClass: MockMemberClient }, {provide: HscBusinessEventService, useClass: MockHscBusinessEventService}],
    }).compile();

    service = module.get<UpdateHscService>(UpdateHscService);
      config = module.get<ConfigService>(ConfigService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('should call update HSC notes and Hsc Decn' ,() =>{
      let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
      const result2: AxiosResponse = { data: "https://dev-ecp-api.optum.com/auth/oauth/jwks", status: 200, statusText: 'OK', headers: {}, config: {}, };
      const result3: AxiosResponse = { data: "ecp", status: 200, statusText: 'OK', headers: {}, config: {}, };
      jest.spyOn(config, 'get').mockImplementationOnce(() => of(result2));
      jest.spyOn(config, 'get').mockImplementationOnce(() => of(result3));
      spyOn<any>(AuthorizationService, 'getEcpAuthencatedUser').and.returnValue({"userId": "00136607"});
      const updateHscRequest: UpdateHscRequest = {
          "hsc_id": 13612,
          "indv_key_typ_ref_id": 2757,
          "indv_key_val": "16440436900",
          "srvc_set_ref_id": 3738,
          "hsc": {
              "rev_prr_ref_id": 3754,
          },
          "hsr_notes":  [
              {
                  "note_txt_lobj": "testing",
                  "note_titl_txt": "title",
                  "src_user_nm": "clinician",
                  "note_typ_ref_id": 12,
                  "note_catgy_ref_id": null,
                  "note_sts_ref_id":null,
                  "hsr_note_sbjs":[{
                      "note_sbj_rec_id":"123",
                      "note_sbj_typ_ref_id":234,
                  }]
              }
          ],
          "hsc_decn": {
              "hsc_decn_id":2,
              "decn_otcome_ref_id": 1,
              "decn_typ_ref_id": 2,
              "decn_rsn_ref_id": 3,
              "clm_note_txt": "test",
              "ovrd_clm_rmrk_ref_id": 1,
              "sys_clm_rmrk_ref_id": 1,
              "wrt_decn_cmnct_dttm": new Date("12-03-2021"),
              "decn_rndr_dttm": new Date("12-03-2021"),
              "decn_mbr_cmnct_dttm": new Date("12-03-2021"),
              "decn_prov_cmnct_dttm": new Date("12-03-2021"),
              "gap_rev_otcome_ref_id": 2,
              "negot_rt": 1,
              "hsc_decn_bed_days": [
                  {
                      "strt_bed_dt": new Date("12-03-2021"),
                      "rvnu_cd": "test",
                      "bed_typ_ref_id": 1
                  }
              ]
          }
      };
      service.updateHscDetails(updateHscRequest, httpRequest).then((res) => {
          expect(res.hsc[0].hsc_id).toEqual(13237);
      });
  })


    it('should call update  Hsc Decn' ,() =>{
        let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
        const result2: AxiosResponse = { data: "https://dev-ecp-api.optum.com/auth/oauth/jwks", status: 200, statusText: 'OK', headers: {}, config: {}, };
        const result3: AxiosResponse = { data: "ecp", status: 200, statusText: 'OK', headers: {}, config: {}, };
        jest.spyOn(config, 'get').mockImplementationOnce(() => of(result2));
        jest.spyOn(config, 'get').mockImplementationOnce(() => of(result3));
        spyOn<any>(AuthorizationService, 'getEcpAuthencatedUser').and.returnValue({"userId": "00136607"});
        const updateHscRequest: UpdateHscRequest = {
            "hsc_id": 13612,
            "indv_key_typ_ref_id": 2757,
            "indv_key_val": "16440436900",
            "srvc_set_ref_id": 3738,
            "hsc": {
                "rev_prr_ref_id": 3754,
            },
            "hsc_decn": {
                "hsr_asgn_id":1,
                "decn_otcome_ref_id": 1,
                "decn_typ_ref_id": 2,
                "decn_rsn_ref_id": 3,
                "clm_note_txt": "test",
                "ovrd_clm_rmrk_ref_id": 1,
                "sys_clm_rmrk_ref_id": 1,
                "wrt_decn_cmnct_dttm": new Date("12-03-2021"),
                "decn_rndr_dttm": new Date("12-03-2021"),
                "decn_mbr_cmnct_dttm": new Date("12-03-2021"),
                "decn_prov_cmnct_dttm": new Date("12-03-2021"),
                "gap_rev_otcome_ref_id": 2,
                "negot_rt": 1,
                "hsc_decn_bed_days": [
                    {
                        "strt_bed_dt": new Date("12-03-2021"),
                        "rvnu_cd": "test",
                        "bed_typ_ref_id": 1
                    }
                ]
            }
        };
        service.updateHscDetails(updateHscRequest, httpRequest).then((res) => {
            expect(res.hsc[0].hsc_id).toEqual(13237);
        });
    })

    it('should call Update Requesting Provider', () => {
        let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
        const result2: AxiosResponse = { data: "https://dev-ecp-api.optum.com/auth/oauth/jwks", status: 200, statusText: 'OK', headers: {}, config: {}, };
        const result3: AxiosResponse = { data: "ecp", status: 200, statusText: 'OK', headers: {}, config: {}, };
        jest.spyOn(config, 'get').mockImplementationOnce(() => of(result2));
        jest.spyOn(config, 'get').mockImplementationOnce(() => of(result3));
        spyOn<any>(AuthorizationService, 'getEcpAuthencatedUser').and.returnValue({"userId": "00136607"})
        const updateHscRequest: UpdateHscRequest = {
            "hsc_id": 13612,
            "indv_key_typ_ref_id": 2757,
            "indv_key_val": "16440436900",
            "srvc_set_ref_id": 3738,
            "hsc": {
                "rev_prr_ref_id": 3754,
            },
            "hsc_provs": [
                {
                    "fst_nm": null,
                    "lst_nm": null,
                    "bus_nm": "HOGUE CHIROPRACTIC CENTER PLLC",
                    "prov_keys": [
                        {
                            "prov_key_typ_ref_id": 16333,
                            "prov_key_val": "288158608"
                        },
                        {
                            "prov_key_typ_ref_id": 2783,
                            "prov_key_val": "112233445566"
                        }
                    ],
                    "hsc_prov_roles": [
                        {
                            "prov_role_ref_id": 3764
                        }
                    ],
                    "prov_adr": {
                        "adr_ln_1_txt": "1920 Colorado Ave",
                        "adr_ln_2_txt": null,
                        "zip_cd_txt": "904043414",
                        "cty_nm": "Santa Monica",
                        "st_ref_id": 1067
                    }
                }
            ],
        };
        service.updateHscDetails(updateHscRequest, httpRequest).then((res) => {
            expect(res.hsc[0].hsc_id).toEqual(13237);
        });
    });


    it('should call Update Submitting Provider', () => {
        let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
        const result2: AxiosResponse = { data: "https://dev-ecp-api.optum.com/auth/oauth/jwks", status: 200, statusText: 'OK', headers: {}, config: {}, };
        const result3: AxiosResponse = { data: "ecp", status: 200, statusText: 'OK', headers: {}, config: {}, };
        jest.spyOn(config, 'get').mockImplementationOnce(() => of(result2));
        jest.spyOn(config, 'get').mockImplementationOnce(() => of(result3));
        spyOn<any>(AuthorizationService, 'getEcpAuthencatedUser').and.returnValue({"userId": "00136607"})
        const updateHscRequest: UpdateHscRequest = {
            "hsc_id": 13612,
            "indv_key_typ_ref_id": 2757,
            "indv_key_val": "16440436900",
            "srvc_set_ref_id": 3738,
            "hsc": {
                "rev_prr_ref_id": 3754,
            },
            "hsc_provs": [
                {
                    "fst_nm": null,
                    "lst_nm": null,
                    "bus_nm": "HOGUE CHIROPRACTIC CENTER PLLC",
                    "prov_keys": [
                        {
                            "prov_key_typ_ref_id": 16333,
                            "prov_key_val": "288158608"
                        }
                    ],
                    "hsc_prov_roles": [
                        {
                            "prov_role_ref_id": 3765
                        }
                    ],
                    "prov_adr": {
                        "adr_ln_1_txt": "1920 Colorado Ave",
                        "adr_ln_2_txt": null,
                        "zip_cd_txt": "904043414",
                        "cty_nm": "Santa Monica",
                        "st_ref_id": 1067
                    }
                }
            ],
        };
        service.updateHscDetails(updateHscRequest, httpRequest).then((res) => {
            expect(res.hsc[0].hsc_id).toEqual(13237);
        });
    });

 it('should call hsc AuthDetails', () => {
    let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
    const result2: AxiosResponse = { data: "https://dev-ecp-api.optum.com/auth/oauth/jwks", status: 200, statusText: 'OK', headers: {}, config: {}, };
    const result3: AxiosResponse = { data: "ecp", status: 200, statusText: 'OK', headers: {}, config: {}, };
    jest.spyOn(config, 'get').mockImplementationOnce(() => of(result2));
    jest.spyOn(config, 'get').mockImplementationOnce(() => of(result3));
    spyOn<any>(AuthorizationService, 'getEcpAuthencatedUser').and.returnValue({"userId": "00136607"})
    const updateHscRequest: UpdateHscRequest = {
        "hsc_id": 13611,
        "indv_key_typ_ref_id": 2757,
        "indv_key_val": "16440436900",
        "srvc_set_ref_id": 3737,
        "hsc": {
            "rev_prr_ref_id": 3754,
        },
        "mbr_cov": {
            "fst_nm": "Matt",
            "lst_nm": "Meyer",
            "bth_dt": new Date("1978-07-26"),
            "gdr_ref_id": 2109,
            "orig_sys_cd": "CDB_CS",
            "cov_eff_dt": new Date("2013-01-01"),
            "cov_end_dt": new Date("9999-12-31"),
            "src_mbr_id": "30830290",
            "src_mbr_partn_id": "10",
            "pol_nbr": "0128855",
            "cov_typ_ref_id": null,
            "clm_pltfm_ref_id": 363
        },
        "hsc_diags": [
            {
                "diag_cd": "M21.51",
                "pri_ind": 1,
                "inac_ind": 0
            },
            {
                "diag_cd": "L02.51",
                "pri_ind": 0,
                "inac_ind": 1
            },
            {
                "diag_cd": "L02.52",
                "pri_ind": 0,
                "inac_ind": 0
            }
        ],
        "hsr_notes":  [
            {
                "note_txt_lobj": "testing",
                "note_titl_txt": "title",
                "src_user_nm": "clinician",
                "note_typ_ref_id": 12,
                "note_catgy_ref_id": null,
                "note_sts_ref_id":null,
                "hsr_note_sbjs":[{
                    "note_sbj_rec_id":"123",
                    "note_sbj_typ_ref_id":234,
                }]
            }
        ],
        "flwup_cntc_dtl": [{
                "department": null,
                "email": null,
                "phone": "234-456-4666",
                "fax": null,
                "role": null,
                "name": "demo",
                "primaryContact": true,
            },
            {
                "department": null,
                "email": null,
                "phone": "234-456-4666",
                "fax": null,
                "role": null,
                "name": "wffwf",
                "primaryContact": false,
            }],
        "hsc_provs": [
            {
                "prov_keys": [
                    {
                        "prov_key_typ_ref_id": 16333,
                        "prov_key_val": "288158608"
                    }
                ],
                "hsc_prov_roles": [
                    {
                        "prov_role_ref_id": 3765
                    }
                ],
                "prov_adr": {
                    "adr_ln_1_txt": "1920 Colorado Ave",
                    "adr_ln_2_txt": null,
                    "zip_cd_txt": "904043414",
                    "cty_nm": "Santa Monica",
                    "st_ref_id": 1067
                },
                "fst_nm": null,
                "lst_nm": null,
                "bus_nm": "HOGUE CHIROPRACTIC CENTER PLLC"
            }
        ],
        "hsc_facl": {
            "plsrv_ref_id": 3743,
            "srvc_desc_ref_id": 4347,
            "srvc_dtl_ref_id": 4296,
            "actul_admis_dttm": null,
            "actul_dschrg_dttm": null,
            "expt_admis_dt": new Date("2021-03-02"),
            "expt_dschrg_dt": new Date("2021-03-04")
        },
        "hsc_srvcs": [
            {
                "proc_cd": "81099",
                "proc_cd_schm_ref_id": 2,
                "srvc_hsc_prov_id": null,
                "inac_ind": 1,
                "hsc_prov": {
                    "prov_keys": [
                        {
                            "prov_key_typ_ref_id": 2782,
                            "prov_key_val": "1851525091"
                        },
                        {
                            "prov_key_typ_ref_id": 16333,
                            "prov_key_val": "288158608"
                        },
                        {
                            "prov_key_typ_ref_id": 2783,
                            "prov_key_val": "1710081369"
                        }
                    ],
                    "hsc_prov_roles": [
                        {
                            "prov_role_ref_id": 3765
                        }
                    ],
                    "prov_adr": {
                        "adr_ln_1_txt": "1920 Colorado Ave",
                        "adr_ln_2_txt": null,
                        "zip_cd_txt": "904043414",
                        "cty_nm": "Santa Monica",
                        "st_ref_id": 1067
                    }
                },
                "hsc_decn": {
                    "hsc_decn_id":2,
                    "decn_otcome_ref_id": 1,
                    "decn_typ_ref_id": 2,
                    "decn_rsn_ref_id": 3,
                    "clm_note_txt": "test",
                    "ovrd_clm_rmrk_ref_id": 1,
                    "sys_clm_rmrk_ref_id": 1,
                    "wrt_decn_cmnct_dttm": new Date("12-03-2021"),
                    "decn_rndr_dttm": new Date("12-03-2021"),
                    "decn_mbr_cmnct_dttm": new Date("12-03-2021"),
                    "decn_prov_cmnct_dttm": new Date("12-03-2021"),
                    "gap_rev_otcome_ref_id": 2,
                    "negot_rt": 1,
                    "hsc_decn_bed_days": [
                        {
                            "strt_bed_dt": new Date("12-03-2021"),
                            "rvnu_cd": "test",
                            "bed_typ_ref_id": 1
                        }
                    ]
                }
            },
            {
                "proc_cd": "71830",
                "proc_cd_schm_ref_id": 2,
                "srvc_hsc_prov_id": null,
                "inac_ind": 0,
                "hsc_prov": {
                    "fst_nm": null,
                    "lst_nm": null,
                    "bus_nm": "HOGUE CHIROPRACTIC CENTER PLLC",
                    "prov_keys": [
                        {
                            "prov_key_typ_ref_id": 16333,
                            "prov_key_val": "288158608"
                        }
                    ],
                    "hsc_prov_roles": [
                        {
                            "prov_role_ref_id": 3765
                        }
                    ],
                    "prov_adr": {
                        "adr_ln_1_txt": "1920 Colorado Ave",
                        "adr_ln_2_txt": null,
                        "zip_cd_txt": "904043414",
                        "cty_nm": "Santa Monica",
                        "st_ref_id": 1067
                    }
                },
                "hsc_decn": {
                    "hsc_decn_id":2,
                    "decn_otcome_ref_id": 1,
                    "decn_typ_ref_id": 2,
                    "decn_rsn_ref_id": 3,
                    "clm_note_txt": "test",
                    "ovrd_clm_rmrk_ref_id": 1,
                    "sys_clm_rmrk_ref_id": 1,
                    "wrt_decn_cmnct_dttm": new Date("12-03-2021"),
                    "decn_rndr_dttm": new Date("12-03-2021"),
                    "decn_mbr_cmnct_dttm": new Date("12-03-2021"),
                    "decn_prov_cmnct_dttm": new Date("12-03-2021"),
                    "gap_rev_otcome_ref_id": 2,
                    "negot_rt": 1,
                    "hsc_decn_bed_days": [
                        {
                            "strt_bed_dt": new Date("12-03-2021"),
                            "rvnu_cd": "test",
                            "bed_typ_ref_id": 1
                        }
                    ]
                },
                "hsc_srvc_non_facls": [
                    {
                        "srvc_dtl_ref_id": 3771,
                        "proc_freq_ref_id": 3913,
                        "proc_uom_ref_id": 19884,
                        "proc_unit_cnt": 1,
                        "unit_per_freq_cnt": 1,
                        "proc_mod_1_cd": "00",
                        "proc_mod_2_cd": "00",
                        "proc_mod_3_cd": "0A",
                        "proc_mod_4_cd": "0A",
                        "srvc_end_dt": new Date("2021-03-20"),
                        "srvc_strt_dt": new Date("2021-03-19"),
                        "init_trt_dt": null,
                        "plsrv_ref_id": 3741,
                        "srvc_desc_ref_id": 4347,
                        "hsc_srvc_non_facl_dmes": [
                            {}
                        ]
                    }
                ]
            }
        ]
    };
    service.updateHscDetails(updateHscRequest, httpRequest).then((res) => {
        // expect(res.hsc[0].hsc_id).toEqual(13611);
        expect(res.hsc[0].hsc_id).toEqual(13237);
    });
});

it('should call hsc diagnosis delete', () => {
    let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
    const result2: AxiosResponse = { data: "https://dev-ecp-api.optum.com/auth/oauth/jwks", status: 200, statusText: 'OK', headers: {}, config: {}, };
    const result3: AxiosResponse = { data: "ecp", status: 200, statusText: 'OK', headers: {}, config: {}, };
    jest.spyOn(config, 'get').mockImplementationOnce(() => of(result2));
    jest.spyOn(config, 'get').mockImplementationOnce(() => of(result3));
    spyOn<any>(AuthorizationService, 'getEcpAuthencatedUser').and.returnValue({"userId": "00136607"})
    const updateHscRequest: UpdateHscRequest = {
        "hsc_id": 13611,
        "indv_key_typ_ref_id": 2757,
        "indv_key_val": "16440436900",
        "srvc_set_ref_id": 3737,
        "hsc":{ "rev_prr_ref_id": 3754},
        "mbr_cov": {
            "fst_nm": "Matt",
            "lst_nm": "Meyer",
            "bth_dt": new Date("1978-07-26"),
            "gdr_ref_id": 2109,
            "orig_sys_cd": "CDB_CS",
            "cov_eff_dt": new Date("2013-01-01"),
            "cov_end_dt": new Date("9999-12-31"),
            "src_mbr_id": "30830290",
            "src_mbr_partn_id": "10",
            "pol_nbr": "0128855",
            "cov_typ_ref_id": null,
            "clm_pltfm_ref_id": 363
        },
        "hsc_keys":[{
            "hsc_key_val": "1234",
            "hsc_key_typ_ref_id": 19217
        }],
        "hsc_diags": [
            {
                "diag_cd": "M21.51",
                "pri_ind": 1,
                "inac_ind": 0
            },
            {
                "diag_cd": "L02.51",
                "pri_ind": 0,
                "inac_ind": 1
            },
            {
                "diag_cd": "L02.52",
                "pri_ind": 0,
                "inac_ind": 0
            }
        ],
        "hsr_notes":  [
            {
                "hsr_note_id": 1234,
                "note_txt_lobj": "testing",
                "note_titl_txt": "title",
                "src_user_nm": "clinician",
                "note_typ_ref_id": 12,
                "note_catgy_ref_id": null,
                "note_sts_ref_id":null,
                "hsr_note_sbjs":[{
                    "note_sbj_rec_id":"123",
                    "note_sbj_typ_ref_id":234,
                }]
            }
        ],
        "flwup_cntc_dtl": [{
                    "department": null,
                "email": null,
                "phone": "234-456-4666",
                "fax": null,
                "role": null,
                "name": "demo",
                    "primaryContact": true,
            },
                {
                    "department": null,
                    "email": null,
                    "phone": "234-456-4666",
                    "fax": null,
                    "role": null,
                    "name": "wffwf",
                    "primaryContact": false,
                }],
        "hsc_provs": [
            {
                "fst_nm": null,
                "lst_nm": null,
                "bus_nm": "HOGUE CHIROPRACTIC CENTER PLLC",
                "prov_keys": [
                    {
                        "prov_key_typ_ref_id": 16333,
                        "prov_key_val": "288158608"
                    }
                ],
                "hsc_prov_roles": [
                    {
                        "prov_role_ref_id": 3765
                    }
                ],
                "prov_adr": {
                    "adr_ln_1_txt": "1920 Colorado Ave",
                    "adr_ln_2_txt": null,
                    "zip_cd_txt": "904043414",
                    "cty_nm": "Santa Monica",
                    "st_ref_id": 1067
                }
            }
        ],
        "hsc_facl": {
            "plsrv_ref_id": 3743,
            "srvc_desc_ref_id": 4347,
            "srvc_dtl_ref_id": 4296,
            "actul_admis_dttm": null,
            "actul_dschrg_dttm": null,
            "expt_admis_dt": new Date("2021-03-02"),
            "expt_dschrg_dt": new Date("2021-03-04")
        },
        "hsc_srvcs": [{
                    "proc_cd": "80346",
                    "proc_cd_schm_ref_id": 2,
                    "srvc_hsc_prov_id": null,
                    "hsc_decn":
                        {
                            "hsc_decn_id":2,
                            "decn_otcome_ref_id": 1,
                            "decn_typ_ref_id": 2,
                            "decn_rsn_ref_id": 3,
                            "clm_note_txt": "test",
                            "ovrd_clm_rmrk_ref_id": 1,
                            "sys_clm_rmrk_ref_id": 1,
                            "decn_src_desc": {
                                "test": "test"
                            },
                            "wrt_decn_cmnct_dttm": new Date(),
                            "decn_rndr_dttm": new Date(),
                            "decn_mbr_cmnct_dttm": new Date(),
                            "decn_prov_cmnct_dttm": new Date(),
                            "gap_rev_otcome_ref_id": 2,
                            "negot_rt": 1,
                            "actul_nxt_rev_dt": new Date(),
                            "decn_bed_day_cnt": 1,
                            "aprv_proc_unit_cnt": 1,
                            "aprv_unit_per_freq_cnt": 1,
                            "ben_lvl_ref_id": 1,
                            "ben_xcpt_ref_id": 1,
                            "decn_clin_rsn_txt": "test",
                            "decn_ent_by_user_id": "1",
                            "decn_ent_rsn_ref_id": 1,
                            "decn_hsc_prov_id": 1,
                            "decn_made_by_user_id": '1',
                            "decn_made_by_user_org_desc": "test",
                            "decn_mbr_cmnct_to_role_ref_id": 1,
                            "decn_prov_cmnct_to_role_ref_id": 1,
                            "decn_ur_jurdc_ref_id": 1,
                            "ltr_atr_list": {"test": "test"},
                            "mbr_cov_dtl": {"test": "test"},
                            "negot_rt_typ_ref_id": 1,
                            "ovrd_rsn_ref_id": 1,
                            "ovrd_rsn_txt": "test",
                            "peer_to_peer_rev_dt": new Date(),
                            "sched_nxt_rev_dt": new Date(),
                            "site_of_care_pref_ref_id": 1,
                            "hsc_decn_bed_days": [
                                {
                                    "strt_bed_dt": new Date(),
                                    "rvnu_cd": "test",
                                    "bed_typ_ref_id": 1,
                                    "accum_bed_day_cnt": 1,
                                    "decn_facl_cmnct_dttm": new Date(),
                                    "decn_rndr_dttm_facl_lcl_txt": "test",
                                    "questnr_rspn_id": 1
                                }
                            ]
                        }
        }
        ]
    };
    service.updateHscDetails(updateHscRequest, httpRequest).then((res) => {
        // expect(res.hsc[0].hsc_id).toEqual(13611);
        expect(res.hsc[0].hsc_id).toEqual(13237);
    });
});

it('should call hsc diagnosis update', () => {
    let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
    const result2: AxiosResponse = { data: "https://dev-ecp-api.optum.com/auth/oauth/jwks", status: 200, statusText: 'OK', headers: {}, config: {}, };
    const result3: AxiosResponse = { data: "ecp", status: 200, statusText: 'OK', headers: {}, config: {}, };
    jest.spyOn(config, 'get').mockImplementationOnce(() => of(result2));
    jest.spyOn(config, 'get').mockImplementationOnce(() => of(result3));
    spyOn<any>(AuthorizationService, 'getEcpAuthencatedUser').and.returnValue({"userId": "00136607"})
    const updateHscRequest: UpdateHscRequest = {
        "hsc_id": 13611,
        "indv_key_typ_ref_id": 2757,
        "indv_key_val": "16440436900",
        "srvc_set_ref_id": 3737,
        "hsc": {
            "rev_prr_ref_id": 3754},
        "mbr_cov": {
            "fst_nm": "Matt",
            "lst_nm": "Meyer",
            "bth_dt": new Date("1978-07-26"),
            "gdr_ref_id": 2109,
            "orig_sys_cd": "CDB_CS",
            "cov_eff_dt": new Date("2013-01-01"),
            "cov_end_dt": new Date("9999-12-31"),
            "src_mbr_id": "30830290",
            "src_mbr_partn_id": "10",
            "pol_nbr": "0128855",
            "cov_typ_ref_id": null,
            "clm_pltfm_ref_id": 363
        },
        "hsc_keys":[{
            "hsc_key_val": "1234",
            "hsc_key_typ_ref_id": 19217
        }],
        "hsc_diags": [
            {
                "diag_cd": "M21.51",
                "pri_ind": 1,
                "inac_ind": 0
            },
            {
                "diag_cd": "L02.51",
                "pri_ind": 0,
                "inac_ind": 1
            },
            {
                "diag_cd": "L02.52",
                "pri_ind": 0,
                "inac_ind": 0
            }
        ],
        "hsr_notes":  [
            {
                "note_txt_lobj": "testing",
                "note_titl_txt": "title",
                "src_user_nm": "clinician",
                "note_typ_ref_id": 12,
                "note_catgy_ref_id": null,
                "note_sts_ref_id":null,
                "hsr_note_sbjs":[{
                    "note_sbj_rec_id":"123",
                    "note_sbj_typ_ref_id":234,
                }]
            }
        ],
        "flwup_cntc_dtl": [{
                    "department": null,
                "email": null,
                "phone": "234-456-4666",
                "fax": null,
                "role": null,
                "name": "demo",
                    "primaryContact": true,
            },
                {
                    "department": null,
                    "email": null,
                    "phone": "234-456-4666",
                    "fax": null,
                    "role": null,
                    "name": "wffwf",
                    "primaryContact": false,
                }],
        "hsc_provs": [
            {
                "fst_nm": null,
                "lst_nm": null,
                "bus_nm": "HOGUE CHIROPRACTIC CENTER PLLC",
                "prov_keys": [
                    {
                        "prov_key_typ_ref_id": 16333,
                        "prov_key_val": "288158608"
                    }
                ],
                "hsc_prov_roles": [
                    {
                        "prov_role_ref_id": 3765
                    },
                    {
                        "prov_role_ref_id": 3764
                    }
                ],
                "prov_adr": {
                    "adr_ln_1_txt": "1920 Colorado Ave",
                    "adr_ln_2_txt": null,
                    "zip_cd_txt": "904043414",
                    "cty_nm": "Santa Monica",
                    "st_ref_id": 1067
                }
            }
        ],
        "hsc_facl": {
            "plsrv_ref_id": 3743,
            "srvc_desc_ref_id": 4347,
            "srvc_dtl_ref_id": 4296,
            "actul_admis_dttm": null,
            "actul_dschrg_dttm": null,
            "expt_admis_dt": new Date("2021-03-02"),
            "expt_dschrg_dt": new Date("2021-03-04")
        },
        "hsc_srvcs": [{
                    "proc_cd": "80346",
                    "proc_cd_schm_ref_id": 2,
                    "srvc_hsc_prov_id": null,
                    "hsc_decn":
                        {
                            "hsc_decn_id":2,
                            "decn_otcome_ref_id": 1,
                            "decn_typ_ref_id": 2,
                            "decn_rsn_ref_id": 3,
                            "clm_note_txt": "test",
                            "ovrd_clm_rmrk_ref_id": 1,
                            "sys_clm_rmrk_ref_id": 1,
                            "decn_src_desc": {
                                "test": "test"
                            },
                            "wrt_decn_cmnct_dttm": new Date(),
                            "decn_rndr_dttm": new Date(),
                            "decn_mbr_cmnct_dttm": new Date(),
                            "decn_prov_cmnct_dttm": new Date(),
                            "gap_rev_otcome_ref_id": 2,
                            "negot_rt": 1,
                            "actul_nxt_rev_dt": new Date(),
                            "decn_bed_day_cnt": 1,
                            "aprv_proc_unit_cnt": 1,
                            "aprv_unit_per_freq_cnt": 1,
                            "ben_lvl_ref_id": 1,
                            "ben_xcpt_ref_id": 1,
                            "decn_clin_rsn_txt": "test",
                            "decn_ent_by_user_id": "1",
                            "decn_ent_rsn_ref_id": 1,
                            "decn_hsc_prov_id": 1,
                            "decn_made_by_user_id": '1',
                            "decn_made_by_user_org_desc": "test",
                            "decn_mbr_cmnct_to_role_ref_id": 1,
                            "decn_prov_cmnct_to_role_ref_id": 1,
                            "decn_ur_jurdc_ref_id": 1,
                            "ltr_atr_list": {"test": "test"},
                            "mbr_cov_dtl": {"test": "test"},
                            "negot_rt_typ_ref_id": 1,
                            "ovrd_rsn_ref_id": 1,
                            "ovrd_rsn_txt": "test",
                            "peer_to_peer_rev_dt": new Date(),
                            "sched_nxt_rev_dt": new Date(),
                            "site_of_care_pref_ref_id": 1,
                            "hsc_decn_bed_days": [
                                {
                                    "strt_bed_dt": new Date(),
                                    "rvnu_cd": "test",
                                    "bed_typ_ref_id": 1,
                                    "accum_bed_day_cnt": 1,
                                    "decn_facl_cmnct_dttm": new Date(),
                                    "decn_rndr_dttm_facl_lcl_txt": "test",
                                    "questnr_rspn_id": 1
                                }
                            ]
                        }
        }
        ]
    };
    service.updateHscDetails(updateHscRequest, httpRequest).then((res) => {
        // expect(res.hsc[0].hsc_id).toEqual(13611);
        expect(res.hsc[0].hsc_id).toEqual(13237);
    });
});

    it('should call hsc diagnosis update with hscDiagId', () => {
        let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
        const result2: AxiosResponse = { data: "https://dev-ecp-api.optum.com/auth/oauth/jwks", status: 200, statusText: 'OK', headers: {}, config: {}, };
        const result3: AxiosResponse = { data: "ecp", status: 200, statusText: 'OK', headers: {}, config: {}, };
        jest.spyOn(config, 'get').mockImplementationOnce(() => of(result2));
        jest.spyOn(config, 'get').mockImplementationOnce(() => of(result3));
        spyOn<any>(AuthorizationService, 'getEcpAuthencatedUser').and.returnValue({"userId": "00136607"})
        const updateHscRequest: UpdateHscRequest = {
                "hsc_id": 20126,
                "hsc_diags": [{
                    "hsc_diag_id": 7385,
                    "diag_cd" : "M60.811",
                    "inac_ind" : 1
                },
                    {
                        "hsc_diag_id": 7387,
                        "diag_cd" : "S83.213A",
                        "pri_ind" : 1
                    },
                    {
                        "diag_cd" : "S83.224A",
                        "pri_ind" : 0
                    },
                    {
                        "diag_cd" : "S83.227A",
                        "pri_ind" : 0
                    }
                ]
            };
        service.updateHscDetails(updateHscRequest, httpRequest).then((res) => {
            // expect(res.hsc[0].hsc_id).toEqual(13611);
            expect(res.hsc[0].hsc_id).toEqual(20126);
        });
    });

it('should call mapHscNonFaclSrvcs for OP update', () => {
    let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
    const result2: AxiosResponse = { data: "https://dev-ecp-api.optum.com/auth/oauth/jwks", status: 200, statusText: 'OK', headers: {}, config: {}, };
    const result3: AxiosResponse = { data: "ecp", status: 200, statusText: 'OK', headers: {}, config: {}, };
    jest.spyOn(config, 'get').mockImplementationOnce(() => of(result2));
    jest.spyOn(config, 'get').mockImplementationOnce(() => of(result3));
    spyOn<any>(AuthorizationService, 'getEcpAuthencatedUser').and.returnValue({"userId": "00136607"})
    const updateHscRequest: UpdateHscRequest = {
        "hsc_id": 13612,
        "indv_key_typ_ref_id": 2757,
        "indv_key_val": "16440436900",
        "srvc_set_ref_id": 3738,
        "hsc":{
            "rev_prr_ref_id": 3754,
        },
        "mbr_cov": {
            "fst_nm": "Matt",
            "lst_nm": "Meyer",
            "bth_dt": new Date("1978-07-26"),
            "gdr_ref_id": 2109,
            "orig_sys_cd": "CDB_CS",
            "cov_eff_dt": new Date("2013-01-01"),
            "cov_end_dt": new Date("9999-12-31"),
            "src_mbr_id": "30830290",
            "src_mbr_partn_id": "10",
            "pol_nbr": "0128855",
            "cov_typ_ref_id": null,
            "clm_pltfm_ref_id": 363
        },
        "hsc_keys":[{
            "hsc_key_val": "1234",
            "hsc_key_typ_ref_id": 19217
        }],
        "hsc_diags": [
            {
                "diag_cd": "M21.51",
                "pri_ind": 1,
                "inac_ind": 0
            },
            {
                "diag_cd": "L02.51",
                "pri_ind": 0,
                "inac_ind": 1
            },
            {
                "diag_cd": "L02.52",
                "pri_ind": 0,
                "inac_ind": 0
            }
        ],
        "hsr_notes":  [
            {
                "note_txt_lobj": "testing",
                "note_titl_txt": "title",
                "src_user_nm": "clinician",
                "note_typ_ref_id": 12,
                "note_catgy_ref_id": null,
                "note_sts_ref_id":null,
                "hsr_note_sbjs":[{
                    "note_sbj_rec_id":"123",
                    "note_sbj_typ_ref_id":234,
                }]
            }
        ],
        "hsc_decn":
            {
                "hsc_decn_id":2,
                "decn_otcome_ref_id": 1,
                "decn_typ_ref_id": 2,
                "decn_bed_day_cnt": 1,
                "aprv_proc_unit_cnt": 1,
                "mbr_cov_dtl": {"test": "test"},
                "negot_rt_typ_ref_id": 1,
                "decn_rsn_ref_id" :1,
                "hsc_decn_bed_days": [{"strt_bed_dt": new Date(),
                    "rvnu_cd": "test",
                    "bed_typ_ref_id": null,
                }
                ]
            },
        "flwup_cntc_dtl": [{
                    "department": null,
                "email": null,
                "phone": "234-456-4666",
                "fax": null,
                "role": null,
                "name": "demo",
                    "primaryContact": true,
            },
                {
                    "department": null,
                    "email": null,
                    "phone": "234-456-4666",
                    "fax": null,
                    "role": null,
                    "name": "wffwf",
                    "primaryContact": false,
                }],
        "hsc_provs": [
            {
                "hsc_prov_id": 13082,
                "fst_nm": null,
                "lst_nm": null,
                "bus_nm": "HOGUE CHIROPRACTIC CENTER PLLC",
                "prov_keys": [
                    {
                        "prov_key_typ_ref_id": 16333,
                        "prov_key_val": "288158608"
                    }
                ],
                "hsc_prov_roles": [
                    {
                        "prov_role_ref_id": 3765
                    },
                    {
                        "prov_role_ref_id": 3764
                    }
                ],
                "prov_adr": {
                    "adr_ln_1_txt": "1920 Colorado Ave",
                    "adr_ln_2_txt": null,
                    "zip_cd_txt": "904043414",
                    "cty_nm": "Santa Monica",
                    "st_ref_id": 1067
                }
            }
        ],
        "hsc_srvcs": [{
            "proc_cd": "80346",
            "proc_cd_schm_ref_id": 2,
            "srvc_hsc_prov_id": null,
            "hsc_srvc_non_facls": [{
                "plsrv_ref_id": 1,
                "srvc_strt_dt":  new Date(),
                "srvc_end_dt": new Date(),
                "proc_uom_ref_id": 22,
                "proc_unit_cnt": 3,
                "unit_per_freq_cnt": 4,
                "proc_freq_ref_id": 4,
                "srvc_desc_ref_id": 4,
                "srvc_dtl_ref_id": 4,
                "hsc_srvc_non_facl_dmes": [{"clin_ill_desc_txt": "test"}]
            }],
            "hsc_decn":
                {
                    "hsc_decn_id":2,
                    "decn_otcome_ref_id": 1,
                    "decn_typ_ref_id": 2,
                    "decn_rsn_ref_id": 3,
                    "clm_note_txt": "test",
                    "ovrd_clm_rmrk_ref_id": 1,
                    "sys_clm_rmrk_ref_id": 1,
                    "decn_src_desc": {
                        "test": "test"
                    },
                    "wrt_decn_cmnct_dttm": new Date(),
                    "decn_rndr_dttm": new Date(),
                    "decn_mbr_cmnct_dttm": new Date(),
                    "decn_prov_cmnct_dttm": new Date(),
                    "gap_rev_otcome_ref_id": 2,
                    "negot_rt": 1,
                    "actul_nxt_rev_dt": new Date(),
                    "decn_bed_day_cnt": 1,
                    "aprv_proc_unit_cnt": 1,
                    "aprv_unit_per_freq_cnt": 1,
                    "ben_lvl_ref_id": 1,
                    "ben_xcpt_ref_id": 1,
                    "decn_clin_rsn_txt": "test",
                    "decn_ent_by_user_id": "1",
                    "decn_ent_rsn_ref_id": 1,
                    "decn_hsc_prov_id": 1,
                    "decn_made_by_user_id": '1',
                    "decn_made_by_user_org_desc": "test",
                    "decn_mbr_cmnct_to_role_ref_id": 1,
                    "decn_prov_cmnct_to_role_ref_id": 1,
                    "decn_ur_jurdc_ref_id": 1,
                    "ltr_atr_list": {"test": "test"},
                    "mbr_cov_dtl": {"test": "test"},
                    "negot_rt_typ_ref_id": 1,
                    "ovrd_rsn_ref_id": 1,
                    "ovrd_rsn_txt": "test",
                    "peer_to_peer_rev_dt": new Date(),
                    "sched_nxt_rev_dt": new Date(),
                    "site_of_care_pref_ref_id": 1,
                    "hsc_decn_bed_days": [
                        {
                            "strt_bed_dt": new Date(),
                            "rvnu_cd": "test",
                            "bed_typ_ref_id": 1,
                            "accum_bed_day_cnt": 1,
                            "decn_facl_cmnct_dttm": new Date(),
                            "decn_rndr_dttm_facl_lcl_txt": "test",
                            "questnr_rspn_id": 1
                        }
                    ]
                }
        }
        ]
    };
    service.updateHscDetails(updateHscRequest, httpRequest).then((res) => {
        expect(res.hsc[0].hsc_id).toEqual(13237);
    });
  });

    it('should call insert hsc facility', () => {
        let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
        const result2: AxiosResponse = { data: "https://dev-ecp-api.optum.com/auth/oauth/jwks", status: 200, statusText: 'OK', headers: {}, config: {}, };
        const result3: AxiosResponse = { data: "ecp", status: 200, statusText: 'OK', headers: {}, config: {}, };
        jest.spyOn(config, 'get').mockImplementationOnce(() => of(result2));
        jest.spyOn(config, 'get').mockImplementationOnce(() => of(result3));
        spyOn<any>(AuthorizationService, 'getEcpAuthencatedUser').and.returnValue({"userId": "00136607"})
        const updateHscRequest: UpdateHscRequest = {
            "hsc_id": 20450,
            "indv_key_typ_ref_id": 2757,
            "indv_key_val": "16440436900",
            "srvc_set_ref_id": 3737,
            "mbr_cov": {
                "fst_nm": "Matt",
                "lst_nm": "Meyer",
                "midl_nm": "",
                "sufx_nm": "",
                "bth_dt": new Date("1978-07-26"),
                "gdr_ref_id": 2109,
                "orig_sys_cd": "CDB_CS",
                "src_mbr_id": "30830290",
                "src_mbr_partn_id": "10",
                "cov_eff_dt": new Date("2020-02-01"),
                "cov_end_dt": new Date("9999-12-31"),
                "pol_nbr": "0752023",
                "cov_typ_ref_id": 182,
                "clm_pltfm_ref_id": 363
            },
            "hsc_facl": {
                "plsrv_ref_id": 3743,
                "srvc_desc_ref_id": 4347,
                "srvc_dtl_ref_id": 4296,
                "actul_admis_dttm": null,
                "actul_dschrg_dttm": null,
                "expt_admis_dt": new Date("2021-06-06"),
                "expt_dschrg_dt": new Date("2021-06-08")
            }
        };
        service.updateHscDetails(updateHscRequest, httpRequest).then((res) => {
            // expect(res.hsc[0].hsc_id).toEqual(13611);
            expect(res.hsc[0].hsc_id).toEqual(20450);
        });
    });

    it('should call update hsc_srvc', () => {
        let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
        const result2: AxiosResponse = { data: "https://dev-ecp-api.optum.com/auth/oauth/jwks", status: 200, statusText: 'OK', headers: {}, config: {}, };
        const result3: AxiosResponse = { data: "ecp", status: 200, statusText: 'OK', headers: {}, config: {}, };
        jest.spyOn(config, 'get').mockImplementationOnce(() => of(result2));
        jest.spyOn(config, 'get').mockImplementationOnce(() => of(result3));
        spyOn<any>(AuthorizationService, 'getEcpAuthencatedUser').and.returnValue({"userId": "00136607"})
        const updateHscRequest: UpdateHscRequest = {
            "hsc_id": 13237,
            "indv_key_typ_ref_id": 2757,
            "indv_key_val": "16440436900",
            "srvc_set_ref_id": 3737,
            "hsc":{
               "hsc_sts_ref_id": 19275
            },
            "hsc_srvcs": [
                {
                    "hsc_srvc_id": 1,
                    "proc_cd": "78130",
                    "proc_cd_schm_ref_id": 2,
                    "srvc_hsc_prov_id": null,
                    "hsc_prov": {
                        "fst_nm": "IMRAN",
                        "lst_nm": "ABASSI",
                        "prov_keys": [
                            {
                                "prov_key_typ_ref_id": 2782,
                                "prov_key_val": "1003875014"
                            },
                            {
                                "prov_key_typ_ref_id": 16333,
                                "prov_key_val": "288158608"
                            },
                            {
                                "prov_key_typ_ref_id": 2783,
                                "prov_key_val": "1710081369"
                            }
                        ],
                        "hsc_prov_roles": [
                            {
                                "prov_role_ref_id": 3765
                            }
                        ],
                        "prov_adr": {
                            "adr_ln_1_txt": "8221 Willow Oaks Corporate Dr Ste 4-420",
                            "adr_ln_2_txt": null,
                            "zip_cd_txt": "22031",
                            "cty_nm": "Fairfax",
                            "st_ref_id": 1114
                        }
                    },
                    "hsc_decn": {
                        "hsc_decn_id":2,
                        "decn_otcome_ref_id": 1,
                        "decn_typ_ref_id": 2,
                        "decn_rsn_ref_id": 3,
                        "clm_note_txt": "test",
                        "ovrd_clm_rmrk_ref_id": 1,
                        "sys_clm_rmrk_ref_id": 1,
                        "decn_src_desc": {
                            "test": "test"
                        },
                        "gap_rev_otcome_ref_id": 2,
                        "negot_rt": 1
                    }
                }
            ]
        };
        service.updateHscDetails(updateHscRequest, httpRequest).then((res) => {
            expect(res.hsc[0].hsc_id).toEqual(13237);
        });
    });

const hsc_keys = [
        {
            hsc_key_val: '133fa864-a0d1-11eb-ad27-8e8a4e4bd3ec',
            hsc_key_typ_ref_id: 19517,
            hsc_key_typ_ref_cd: {
                ref_cd: 'BPMID',
                ref_dspl: 'BPM Work Flow Case ID',
            },
        },
        {
            hsc_key_val: '9a85062b-a0d1-11eb-a9bb-6ad13105d477',
            hsc_key_typ_ref_id: 72093,
            hsc_key_typ_ref_cd: {
                ref_cd: null,
                ref_dspl: 'Automated Clinical Case Validations',
            },
        },
    ];


const hscPayload = {
        hsc_id: 17012,
        creat_dttm: '2021-04-18T18:05:31.419',
        creat_user_id: 'ecp_engineer',
        creat_sys_ref_id: null,
        chg_dttm: '2021-04-18T18:05:31.419',
        chg_user_id: 'ecp_engineer',
        chg_sys_ref_id: null,
        indv_key_typ_ref_id: 2757,
        indv_key_val: '16440436900',
        orig_sys_ref_id: null,
        hsc_sts_ref_id: 19275,
        hsc_sts_ref_cd: {
            ref_cd: '1',
            ref_dspl: 'Open',
        },
        hsc_sts_rsn_ref_id: null,
        hsc_sts_rsn_ref_cd: null,
        // srvc_set_ref_id: 3737,
        // srvc_set_ref_cd: {
        //     ref_cd: '1',
        //     ref_dspl: 'Inpatient',
        // },
        rev_prr_ref_id: 3754,
        rev_prr_ref_cd: {
            ref_cd: '1',
            ref_dspl: 'Routine',
        },
        auth_typ_ref_id: null,
        auth_typ_ref_cd: null,
        hsc_rev_typ_ref_id: 20402,
        hsc_rev_typ_ref_cd: {
            ref_cd: 'generic',
            ref_dspl: 'Generic',
        },
        cont_of_care_ind: null,
        rev_prr_rsn_txt: null,
        auth_strt_dt: null,
        auth_end_dt: null,
        flwup_cntc_dtl: [
            {
                department: null,
                email: null,
                phone: '888-888-8888',
                fax: null,
                role: null,
                name: 'test',
                primaryContact: true,
            },
        ],
        hsc_facls: [
            {
                adv_ntfy_trans_id: null,
                admis_ntfy_trans_id: null,
                dschrg_ntfy_trans_id: null,
                adv_ntfy_dttm: null,
                admis_ntfy_dttm: null,
                dschrg_ntfy_dttm: null,
                plsrv_ref_id: 3743,
                plsrv_ref_cd: {
                    ref_cd: '21',
                    ref_dspl: 'Acute Hospital',
                },
                srvc_dtl_ref_id: 4307,
                srvc_dtl_ref_cd: {
                    ref_cd: '2',
                    ref_dspl: 'Surgical',
                },
                srvc_desc_ref_id: 4347,
                srvc_desc_ref_cd: {
                    ref_cd: '1',
                    ref_dspl: 'Scheduled',
                },
                expt_admis_dt: '2021-04-19',
                expt_dschrg_dt: '2021-04-21',
                actul_admis_dttm: null,
                actul_dschrg_dttm: null,
                goal_los_day_cnt: null,
                dschrg_disp_ref_id: null,
                dschrg_disp_ref_cd: null,
                rem_snf_day_cnt: null,
                snf_day_xhst_ind: null,
                ipcm_typ_ref_id: null,
                ipcm_typ_ref_cd: null,
                ctp_nom_sts_ref_id: null,
                ctp_nom_sts_ref_cd: null,
                tat_due_dttm: null
            },
        ],
        hsc_decns: [{
            hsc_decn_id: 123,
            decn_otcome_ref_id: 1,
            decn_typ_ref_id: 2,
            decn_rsn_ref_id: 3,
            clm_note_txt: "test",
            decn_made_by_user_id: "SYSTEM_PAAN",
            decn_made_by_user_org_desc: "Test_desc",
            ovrd_clm_rmrk_ref_id: 1,
            sys_clm_rmrk_ref_id: 1,
            decn_src_desc: {
                test: "test"
            },
            site_of_care_pref_ref_id: 2,
            wrt_decn_cmnct_dttm: new Date(),
            decn_rndr_dttm: new Date(),
            decn_mbr_cmnct_dttm: new Date(),
            decn_prov_cmnct_dttm: new Date(),
            gap_rev_otcome_ref_id: 2,
            negot_rt: 1
             }],
        hsc_provs: [
            {
                creat_dttm: '2021-04-18T18:06:02.435',
                creat_user_id: 'ecp_engineer',
                chg_dttm: '2021-04-18T18:06:02.435',
                chg_user_id: 'ecp_engineer',
                hsc_prov_id: 12662,
                prov_loc_affil_dtl: {
                    providerDetails: {
                        prov_id: 37697,
                        prov_keys: [
                            {
                                prov_key_val: null,
                                prov_key_typ_ref_id: 2782,
                            },
                            {
                                prov_key_val: '256556261',
                                prov_key_typ_ref_id: 16333,
                            },
                            {
                                prov_key_val: '2082298',
                                prov_key_typ_ref_id: 2783,
                            },
                        ],
                        prov_adr_id: 4004,
                        prov_cat_typ_ref_id: 16310,
                    },
                },
                hsc_prov_roles: [
                    {
                        prov_role_ref_cd: {
                            ref_cd: 'RF',
                            ref_dspl: 'Requesting',
                        },
                    },
                ],
                provider: [
                    {
                        prov_id: 37697,
                        prov_catgy_ref_id: 16310,
                        prov_keys: [
                            {
                                prov_key_val: '2082298',
                                prov_key_typ_ref_id: 2783,
                            },
                            {
                                prov_key_val: '256556261',
                                prov_key_typ_ref_id: 16333,
                            },
                            {
                                prov_key_val: 'EPIM7VZDVUEA5D5S7H8O',
                                prov_key_typ_ref_id: 16342,
                            },
                        ],
                        prov_indvs: [],
                        prov_orgs: [
                            {
                                bus_nm: 'DIVERSICARE GOOD SAMARITAN',
                                prov_org_typ_ref_id: null,
                            },
                        ],
                        prov_adrs: [
                            {
                                prov_adr_id: 4004,
                                adr_typ_ref_id: 16312,
                                adr_ln_1_txt: '3127 57th Ave N',
                                adr_ln_2_txt: null,
                                cty_nm: 'Saint Petersburg',
                                zip_cd_txt: '33714',
                                zip_sufx_cd_txt: '1320',
                                st_ref_id: 1072,
                            },
                            {
                                prov_adr_id: 4003,
                                adr_typ_ref_id: 16318,
                                adr_ln_1_txt: '3127 57th Ave N',
                                adr_ln_2_txt: null,
                                cty_nm: 'Saint Petersburg',
                                zip_cd_txt: '33714',
                                zip_sufx_cd_txt: '1320',
                                st_ref_id: 1072,
                            },
                        ],
                    },
                ],
            },
            {
                creat_dttm: '2021-04-18T18:07:12.967',
                creat_user_id: 'ecp_engineer',
                chg_dttm: '2021-04-18T18:07:12.967',
                chg_user_id: 'ecp_engineer',
                prov_loc_affil_dtl: {
                    providerDetails: {
                        prov_id: 37697,
                        prov_keys: [
                            {
                                prov_key_val: null,
                                prov_key_typ_ref_id: 2782,
                            },
                            {
                                prov_key_val: '256556261',
                                prov_key_typ_ref_id: 16333,
                            },
                            {
                                prov_key_val: '2082298',
                                prov_key_typ_ref_id: 2783,
                            },
                        ],
                        prov_adr_id: 4004,
                        prov_cat_typ_ref_id: 16310,
                    },
                },
                hsc_prov_roles: [
                    {
                        prov_role_ref_cd: {
                            ref_cd: 'SJ',
                            ref_dspl: 'Servicing',
                        },
                    },
                ],
                provider: [
                    {
                        prov_id: 37697,
                        prov_catgy_ref_id: 16310,
                        prov_keys: [
                            {
                                prov_key_val: '2082298',
                                prov_key_typ_ref_id: 2783,
                            },
                            {
                                prov_key_val: '256556261',
                                prov_key_typ_ref_id: 16333,
                            },
                            {
                                prov_key_val: 'EPIM7VZDVUEA5D5S7H8O',
                                prov_key_typ_ref_id: 16342,
                            },
                        ],
                        prov_indvs: [],
                        prov_orgs: [
                            {
                                bus_nm: 'DIVERSICARE GOOD SAMARITAN',
                                prov_org_typ_ref_id: null,
                            },
                        ],
                        prov_adrs: [
                            {
                                prov_adr_id: 4004,
                                adr_typ_ref_id: 16312,
                                adr_ln_1_txt: '3127 57th Ave N',
                                adr_ln_2_txt: null,
                                cty_nm: 'Saint Petersburg',
                                zip_cd_txt: '33714',
                                zip_sufx_cd_txt: '1320',
                                st_ref_id: 1072,
                            },
                            {
                                prov_adr_id: 4003,
                                adr_typ_ref_id: 16318,
                                adr_ln_1_txt: '3127 57th Ave N',
                                adr_ln_2_txt: null,
                                cty_nm: 'Saint Petersburg',
                                zip_cd_txt: '33714',
                                zip_sufx_cd_txt: '1320',
                                st_ref_id: 1072,
                            },
                        ],
                    },
                ],
            },
        ],
        individual: [
            {
                indv_id: 503926748,
                fst_nm: 'Matt',
                lst_nm: 'Meyer',
                midl_nm: null,
                sufx_nm: null,
                bth_dt: '1978-07-26',
                gdr_ref_id: 2109,
                gdr_ref_cd: {
                    ref_cd: 'M',
                    ref_dspl: 'Male',
                },
                indv_keys: [
                    {
                        indv_key_val: '503926748',
                        indv_key_typ_ref_id: 968,
                        indv_key_typ_ref_cd: {
                            ref_cd: 'SCR',
                            ref_dspl: 'subscriberId',
                        },
                    },
                    {
                        indv_key_val: '355749905',
                        indv_key_typ_ref_id: 973,
                        indv_key_typ_ref_cd: {
                            ref_cd: 'SSN',
                            ref_dspl: 'SSN',
                        },
                    },
                    {
                        indv_key_val: 'JAEGER_TEST_v3_16440436900',
                        indv_key_typ_ref_id: 2757,
                        indv_key_typ_ref_cd: {
                            ref_cd: null,
                            ref_dspl: 'SourceSysID',
                        },
                    },
                    {
                        indv_key_val: '16440436900',
                        indv_key_typ_ref_id: 2757,
                        indv_key_typ_ref_cd: {
                            ref_cd: null,
                            ref_dspl: 'SourceSysID',
                        },
                    },
                ],
            },
        ],
        hsc_diags: [
            {
                creat_dttm: '2021-04-18T18:07:09.295',
                creat_user_id: 'ecp_engineer',
                chg_dttm: '2021-04-18T18:07:09.295',
                chg_user_id: 'ecp_engineer',
                diag_cd: 'B71.1',
                diag_othr_txt: null,
                diag_cd_schm_ref_id: null,
                diag_cd_schm_ref_cd: null,
                inac_ind: 0,
                pri_ind: 0,
            },
        ],
        hsc_srvcs: [{
            hsc_srvc_id: 1,
            proc_cd: "78130",
            proc_cd_schm_ref_id: 2,
            srvc_hsc_prov_id: null,
            hsc_srvc_non_facls: [
                {
                    hsc_srvc_id: 1,
                    srvc_dtl_ref_id: 3772,
                    proc_freq_ref_id: 3913,
                    proc_uom_ref_id: 19884,
                    proc_unit_cnt: 1,
                    unit_per_freq_cnt: 1,
                    proc_mod_1_cd: "01",
                    proc_mod_2_cd: "01",
                    proc_mod_3_cd: "0A",
                    proc_mod_4_cd: "0A",
                    srvc_end_dt: new Date("2021-03-20"),
                    srvc_strt_dt: new Date("2021-03-19"),
                    init_trt_dt: null,
                    plsrv_ref_id: 3741,
                    srvc_desc_ref_id: 4347,
                    hsc_srvc_non_facl_dmes: [
                        {}
                    ]
                }
            ],
            hsc_prov: {
                fst_nm: "IMRAN",
                lst_nm: "ABASSI",
                prov_keys: [
                    {
                        prov_key_typ_ref_id: 2782,
                        prov_key_val: "1003875014"
                    },
                    {
                        prov_key_typ_ref_id: 16333,
                        prov_key_val: "288158608"
                    },
                    {
                        prov_key_typ_ref_id: 2783,
                        prov_key_val: "1710081369"
                    }
                ],
                hsc_prov_roles: [
                    {
                        prov_role_ref_id: 3765
                    }
                ],
                prov_adr: {
                    adr_ln_1_txt: "8221 Willow Oaks Corporate Dr Ste 4-420",
                    adr_ln_2_txt: null,
                    zip_cd_txt: "22031",
                    cty_nm: "Fairfax",
                    st_ref_id: 1114
                }
            }
        }],
        hsr_notes: [
        {
            "note_txt_lobj": "testing",
            "note_titl_txt": "title",
            "src_user_nm": "clinician",
            "note_typ_ref_id": 12,
            "note_catgy_ref_id": null
        },
        {
            "hsr_note_id": 8906,
            "note_txt_lobj": "testing4",
            "note_titl_txt": "title34"
        }
    ]
};
    const hscBasePayload: any = {
        hsc: {
            hsc_keys: [...hsc_keys],
            hsc_data: {
                ...hscPayload,
            },
        },
    };

    it('should call updateProcedureChildBusinessEvent', () => {
        let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
        const result2: AxiosResponse = { data: "https://dev-ecp-api.optum.com/auth/oauth/jwks", status: 200, statusText: 'OK', headers: {}, config: {}, };
        const result3: AxiosResponse = { data: "ecp", status: 200, statusText: 'OK', headers: {}, config: {}, };
        jest.spyOn(config, 'get').mockImplementationOnce(() => of(result2));
        jest.spyOn(config, 'get').mockImplementationOnce(() => of(result3));
        spyOn<any>(AuthorizationService, 'getEcpAuthencatedUser').and.returnValue({"userId": "00136607"})
        const updateHscRequest: UpdateHscRequest = {
            "hsc_id": 13612,
            "indv_key_typ_ref_id": 2757,
            "indv_key_val": "16440436900",
            "srvc_set_ref_id": 3737,
            "hsc_srvcs": [
                {
                    "hsc_srvc_id": 1,
                    "proc_cd": "78130",
                    "proc_cd_schm_ref_id": 2,
                    "srvc_hsc_prov_id": null,
                    "hsc_prov": {
                        "fst_nm": "IMRAN",
                        "lst_nm": "ABASSI",
                        "prov_keys": [
                            {
                                "prov_key_typ_ref_id": 2782,
                                "prov_key_val": "1003875014"
                            },
                            {
                                "prov_key_typ_ref_id": 16333,
                                "prov_key_val": "288158608"
                            },
                            {
                                "prov_key_typ_ref_id": 2783,
                                "prov_key_val": "1710081369"
                            }
                        ],
                        "hsc_prov_roles": [
                            {
                                "prov_role_ref_id": 3765
                            }
                        ],
                        "prov_adr": {
                            "adr_ln_1_txt": "8221 Willow Oaks Corporate Dr Ste 4-420",
                            "adr_ln_2_txt": null,
                            "zip_cd_txt": "22031",
                            "cty_nm": "Fairfax",
                            "st_ref_id": 1114
                        }
                    }
                },
                {
                    "proc_cd": "78132",
                    "proc_cd_schm_ref_id": 2,
                    "srvc_hsc_prov_id": null,
                    "hsc_prov": {
                        "fst_nm": "IMRAN2",
                        "lst_nm": "ABASSI2",
                        "prov_keys": [
                            {
                                "prov_key_typ_ref_id": 2782,
                                "prov_key_val": "1003875014"
                            },
                            {
                                "prov_key_typ_ref_id": 16333,
                                "prov_key_val": "288158608"
                            },
                            {
                                "prov_key_typ_ref_id": 2783,
                                "prov_key_val": "1710081369"
                            }
                        ],
                        "hsc_prov_roles": [
                            {
                                "prov_role_ref_id": 3765
                            }
                        ],
                        "prov_adr": {
                            "adr_ln_1_txt": "8221 Willow Oaks Corporate Dr Ste 4-420",
                            "adr_ln_2_txt": null,
                            "zip_cd_txt": "22031",
                            "cty_nm": "Fairfax",
                            "st_ref_id": 1114
                        }
                    }
                }
            ]
        };

        const eventList: HscBusEvent[] = [];
        const payload = JSON.parse(JSON.stringify(hscBasePayload));

        // createChildBusinessEvents(updateHscRequest: UpdateHscRequest, hscBasePayload, payload, eventList: HscBusEvent[], currentHsc) {
        service.createChildBusinessEvents(updateHscRequest, hscBasePayload, payload, eventList, null);
        expect(eventList.length > 0);
        const procedureUpdateEvent = eventList.find(
            (event) => event.eventName == HscBusEventName.HSC_PROCEDURE_UPDATE
        );
        expect(procedureUpdateEvent != null);

        //     .then((res) => {
        //     expect(res.hsc[0].hsc_id).toEqual(13612);
        // });
    });

    it('should call updateProviderChildBusinessEvent', () => {
        let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
        const result2: AxiosResponse = { data: "https://dev-ecp-api.optum.com/auth/oauth/jwks", status: 200, statusText: 'OK', headers: {}, config: {}, };
        const result3: AxiosResponse = { data: "ecp", status: 200, statusText: 'OK', headers: {}, config: {}, };
        jest.spyOn(config, 'get').mockImplementationOnce(() => of(result2));
        jest.spyOn(config, 'get').mockImplementationOnce(() => of(result3));
        spyOn<any>(AuthorizationService, 'getEcpAuthencatedUser').and.returnValue({"userId": "00136607"})
        const updateHscRequest: UpdateHscRequest = {
            "hsc_id": 13612,
            "indv_key_typ_ref_id": 2757,
            "indv_key_val": "16440436900",
            "srvc_set_ref_id": 3737,
            "hsc_provs": [
                {
                    "hsc_prov_id": 12662,
                    "fst_nm": "IMRAN",
                    "lst_nm": "ABASSI",
                    "prov_keys": [
                        {
                            "prov_key_typ_ref_id": 2782,
                            "prov_key_val": "1003875014"
                        },
                        {
                            "prov_key_typ_ref_id": 16333,
                            "prov_key_val": "288158608"
                        },
                        {
                            "prov_key_typ_ref_id": 2783,
                            "prov_key_val": "1710081369"
                        }
                    ],
                    "hsc_prov_roles": [
                        {
                            "prov_role_ref_id": 3765
                        },
                        {
                            "prov_role_ref_id": 3761
                        }
                    ],
                    "prov_adr": {
                        "adr_ln_1_txt": "8221 Willow Oaks Corporate Dr Ste 4-420",
                        "adr_ln_2_txt": null,
                        "zip_cd_txt": "22031",
                        "cty_nm": "Fairfax",
                        "st_ref_id": 1114
                    }
                }
            ]

        };

        const eventList: HscBusEvent[] = [];
        const payload = JSON.parse(JSON.stringify(hscBasePayload));

        service.createChildBusinessEvents(updateHscRequest, hscBasePayload, payload, eventList, null);
        expect(eventList.length > 0);
        const providerUpdateEvent = eventList.find(
          (event) => event.eventName == HscBusEventName.HSC_PROVIDER_UPDATE
        );
        expect(providerUpdateEvent != null);
    });

    it('should call updateContactChildBusinessEvent', () => {
        let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
        const result2: AxiosResponse = { data: "https://dev-ecp-api.optum.com/auth/oauth/jwks", status: 200, statusText: 'OK', headers: {}, config: {}, };
        const result3: AxiosResponse = { data: "ecp", status: 200, statusText: 'OK', headers: {}, config: {}, };
        jest.spyOn(config, 'get').mockImplementationOnce(() => of(result2));
        jest.spyOn(config, 'get').mockImplementationOnce(() => of(result3));
        spyOn<any>(AuthorizationService, 'getEcpAuthencatedUser').and.returnValue({"userId": "00136607"})
        const updateHscRequest: UpdateHscRequest = {
            "hsc_id": 13612,
            "indv_key_typ_ref_id": 2757,
            "indv_key_val": "16440436900",
            "srvc_set_ref_id": 3737,
            "flwup_cntc_dtl": [
                {
                    "name": "Paanthree Attd",
                    "role": "1",
                    "department": "Admitting",
                    "phone": "999-999-9999 9999",
                    "fax": "999-999-9992",
                    "primaryContact": true,
                    "email": "jason@xyz.com"
                },
                {
                    "name": "Ejain",
                    "role": "Facility",
                    "department": "Admitting",
                    "phone": "999-999-9999 9999",
                    "fax": "999-999-9993",
                    "primaryContact": false,
                    "email": "jason@xyz.com"
                }
            ],
        };

        const eventList: HscBusEvent[] = [];
        const payload = JSON.parse(JSON.stringify(hscBasePayload));

        service.createChildBusinessEvents(updateHscRequest, hscBasePayload, payload, eventList, null);
        expect(eventList.length > 0);
        const contactsUpdateEvent = eventList.find(
          (event) => event.eventName == HscBusEventName.HSC_CONTACT_UPDATE
        );
        expect(contactsUpdateEvent != null);
    });

    it('should call updateDiagnosisChildBusinessEvent', () => {
        let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
        const result2: AxiosResponse = { data: "https://dev-ecp-api.optum.com/auth/oauth/jwks", status: 200, statusText: 'OK', headers: {}, config: {}, };
        const result3: AxiosResponse = { data: "ecp", status: 200, statusText: 'OK', headers: {}, config: {}, };
        jest.spyOn(config, 'get').mockImplementationOnce(() => of(result2));
        jest.spyOn(config, 'get').mockImplementationOnce(() => of(result3));
        spyOn<any>(AuthorizationService, 'getEcpAuthencatedUser').and.returnValue({"userId": "00136607"})
        const updateHscRequest: UpdateHscRequest = {
            "hsc_id": 13612,
            "indv_key_typ_ref_id": 2757,
            "indv_key_val": "16440436900",
            "srvc_set_ref_id": 3737,
            "hsc_diags": [
                {
                    "diag_cd": "S83.226A",
                    "pri_ind": 0
                },
                {
                    "hsc_diag_id": 11057,
                    "pri_ind": 1
                }
            ]
        };
        const eventList: HscBusEvent[] = [];
        const payload = JSON.parse(JSON.stringify(hscBasePayload));
        service.createChildBusinessEvents(updateHscRequest, hscBasePayload, payload, eventList, null);
        expect(eventList.length > 0);
        const diagnosisUpdateEvent = eventList.find(
          (event) => event.eventName == HscBusEventName.HSC_DIAGNOSIS_UPDATE
        );
        expect(diagnosisUpdateEvent != null);
    });

    it('should call updateHsrNotesChildBusinessEvent', () => {
        let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
        const result2: AxiosResponse = { data: "https://dev-ecp-api.optum.com/auth/oauth/jwks", status: 200, statusText: 'OK', headers: {}, config: {}, };
        const result3: AxiosResponse = { data: "ecp", status: 200, statusText: 'OK', headers: {}, config: {}, };
        jest.spyOn(config, 'get').mockImplementationOnce(() => of(result2));
        jest.spyOn(config, 'get').mockImplementationOnce(() => of(result3));
        spyOn<any>(AuthorizationService, 'getEcpAuthencatedUser').and.returnValue({"userId": "00136607"})
        const updateHscRequest: UpdateHscRequest = {
            "hsc_id": 13612,
            "indv_key_typ_ref_id": 2757,
            "indv_key_val": "16440436900",
            "srvc_set_ref_id": 3737,
            "hsr_notes": [
                {
                    "note_txt_lobj": "testing",
                    "note_titl_txt": "title",
                    "src_user_nm": "clinician",
                    "note_typ_ref_id": 12,
                    "note_catgy_ref_id": null
                },
                {
                    "hsr_note_id": 8906,
                    "note_txt_lobj": "testing4",
                    "note_titl_txt": "title34"
                }
            ]
        };
        const eventList: HscBusEvent[] = [];
        const payload = JSON.parse(JSON.stringify(hscBasePayload));
        service.createChildBusinessEvents(updateHscRequest, hscBasePayload, payload, eventList, null);
        expect(eventList.length > 0);
        const notesUpdateEvent = eventList.find(
          (event) => event.eventName == HscBusEventName.HSC_NOTES_UPDATE
        );
        expect(notesUpdateEvent != null);
    });

    it('should call updateFacilityDecnChildBusinessEvent', () => {
        let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
        const result2: AxiosResponse = { data: "https://dev-ecp-api.optum.com/auth/oauth/jwks", status: 200, statusText: 'OK', headers: {}, config: {}, };
        const result3: AxiosResponse = { data: "ecp", status: 200, statusText: 'OK', headers: {}, config: {}, };
        jest.spyOn(config, 'get').mockImplementationOnce(() => of(result2));
        jest.spyOn(config, 'get').mockImplementationOnce(() => of(result3));
        spyOn<any>(AuthorizationService, 'getEcpAuthencatedUser').and.returnValue({"userId": "00136607"});
        const currentHsc: any = {
                        "hsc_sts_ref_id": 19275,
                        "rev_prr_ref_id": 3754,
                        "srvc_set_ref_id": 3737,
                        "hsc_facls": [
                            {
                                "plsrv_ref_id": 3743,
                                "srvc_desc_ref_id": 4347,
                                "srvc_dtl_ref_id": 4296,
                                "actul_admis_dttm": "2021-03-01",
                                "actul_dschrg_dttm": "2021-03-02",
                                "expt_admis_dt": "2021-03-03",
                                "expt_dschrg_dt": "2021-03-04",
                                "hsc_decns": [{
                                    "hsc_decn_id":123,
                                    "decn_otcome_ref_id": 1,
                                    "decn_typ_ref_id": 2,
                                    "decn_rsn_ref_id": 3,
                                    "clm_note_txt": "test",
                                    "decn_made_by_user_id": "SYSTEM_PAAN",
                                    "decn_made_by_user_org_desc": "Test_desc",
                                    "ovrd_clm_rmrk_ref_id": 1,
                                    "sys_clm_rmrk_ref_id": 1,
                                    "decn_src_desc": {
                                        "test": "test"
                                    },
                                    "site_of_care_pref_ref_id": 2,
                                    "wrt_decn_cmnct_dttm": new Date("12-03-2021"),
                                    "decn_rndr_dttm": new Date("12-03-2021"),
                                    "decn_mbr_cmnct_dttm": new Date("12-03-2021"),
                                    "decn_prov_cmnct_dttm": new Date("12-03-2021"),
                                    "gap_rev_otcome_ref_id": 2,
                                    "negot_rt": 1
                                }]
                            }
                        ],
                        "hsc_srvcs": [
                            {
                                "hsc_srvc_id": 11915,
                                "hsc_srvc_non_facls": []
                            }
                        ]
        };
        const updateHscRequest: UpdateHscRequest = {
            "hsc_id": 13612,
            "indv_key_typ_ref_id": 2757,
            "indv_key_val": "16440436900",
            "srvc_set_ref_id": 3737,
            "hsc_facl": {
                "plsrv_ref_id": 3744,
                "srvc_desc_ref_id": 4346,
                "srvc_dtl_ref_id": 4295,
                "actul_admis_dttm": new Date("2021-04-01"),
                "actul_dschrg_dttm": new Date("2021-04-02"),
                "expt_admis_dt": new Date("2021-03-02"),
                "expt_dschrg_dt": new Date("2021-03-04"),
                "ipcm_typ_ref_id": 72238,
                "hsc_decn": {
                    "hsc_decn_id":123,
                    "decn_otcome_ref_id": 1,
                    "decn_typ_ref_id": 2,
                    "decn_rsn_ref_id": 3,
                    "clm_note_txt": "test",
                    "decn_made_by_user_id": "SYSTEM_PAAN",
                    "decn_made_by_user_org_desc": "Test_desc",
                    "ovrd_clm_rmrk_ref_id": 1,
                    "sys_clm_rmrk_ref_id": 1,
                    "decn_src_desc": {
                        "test": "test"
                    },
                    "site_of_care_pref_ref_id": 2,
                    "wrt_decn_cmnct_dttm": new Date("12-03-2021"),
                    "decn_rndr_dttm": new Date("12-03-2021"),
                    "decn_mbr_cmnct_dttm": new Date("12-03-2021"),
                    "decn_prov_cmnct_dttm": new Date("12-03-2021"),
                    "gap_rev_otcome_ref_id": 2,
                    "negot_rt": 1
                }
            }
        };
        const eventList: HscBusEvent[] = [];
        const payload = JSON.parse(JSON.stringify(hscBasePayload));
        service.createChildBusinessEvents(updateHscRequest, hscBasePayload, payload, eventList, currentHsc);
        expect(eventList.length > 0);
        const caseTypeUpdateEvent = eventList.find(
          (event) => event.eventName == HscBusEventName.HSC_CASE_TYPE_UPDATE
        );
        expect(caseTypeUpdateEvent != null);
    });

    it('should call updateOPCaseTypeChildEvent', () => {
        let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
        const result2: AxiosResponse = { data: "https://dev-ecp-api.optum.com/auth/oauth/jwks", status: 200, statusText: 'OK', headers: {}, config: {}, };
        const result3: AxiosResponse = { data: "ecp", status: 200, statusText: 'OK', headers: {}, config: {}, };
        jest.spyOn(config, 'get').mockImplementationOnce(() => of(result2));
        jest.spyOn(config, 'get').mockImplementationOnce(() => of(result3));
        spyOn<any>(AuthorizationService, 'getEcpAuthencatedUser').and.returnValue({"userId": "00136607"});
        const currentHsc: any = {
                    "hsc_sts_ref_id": 19275,
                    "rev_prr_ref_id": 3754,
                    "srvc_set_ref_id": 3738,
                    "hsc_facls": [
                        {
                            "plsrv_ref_id": 3745,
                            "srvc_desc_ref_id": 4345,
                            "srvc_dtl_ref_id": 4295,
                            "actul_admis_dttm": "2021-04-02T00:00:00",
                            "actul_dschrg_dttm": "2021-04-03T00:00:00",
                            "expt_admis_dt": "2021-03-03",
                            "expt_dschrg_dt": "2021-03-04"
                        }
                    ],
                    "hsc_srvcs": [
                        {
                            "hsc_srvc_id": 1,
                            "hsc_srvc_non_facls": [
                                {
                                    "hsc_srvc_id": 1,
                                    "plsrv_ref_id": 3741,
                                    "srvc_desc_ref_id": 4347
                                }
                            ]
                        }
                    ]
        };
        const updateHscRequest: UpdateHscRequest = {
            "hsc_id": 20126,
            "indv_key_typ_ref_id": 2757,
            "indv_key_val": "16440436900",
            "srvc_set_ref_id": 3738,
            "hsc_srvcs": [
                {
                    "hsc_srvc_id": 1,
                    "proc_cd": "78130",
                    "proc_cd_schm_ref_id": 2,
                    "srvc_hsc_prov_id": null,
                    "hsc_prov": {
                        "fst_nm": "IMRAN",
                        "lst_nm": "ABASSI",
                        "prov_keys": [
                            {
                                "prov_key_typ_ref_id": 2782,
                                "prov_key_val": "1003875014"
                            },
                            {
                                "prov_key_typ_ref_id": 16333,
                                "prov_key_val": "288158608"
                            },
                            {
                                "prov_key_typ_ref_id": 2783,
                                "prov_key_val": "1710081369"
                            }
                        ],
                        "hsc_prov_roles": [
                            {
                                "prov_role_ref_id": 3765
                            }
                        ],
                        "prov_adr": {
                            "adr_ln_1_txt": "8221 Willow Oaks Corporate Dr Ste 4-420",
                            "adr_ln_2_txt": null,
                            "zip_cd_txt": "22031",
                            "cty_nm": "Fairfax",
                            "st_ref_id": 1114
                        }
                    },
                    "hsc_srvc_non_facls": [
                        {
                            "hsc_srvc_id": 1,
                            "srvc_dtl_ref_id": 3772,
                            "proc_freq_ref_id": 3913,
                            "proc_uom_ref_id": 19884,
                            "proc_unit_cnt": 1,
                            "unit_per_freq_cnt": 1,
                            "proc_mod_1_cd": "01",
                            "proc_mod_2_cd": "01",
                            "proc_mod_3_cd": "0A",
                            "proc_mod_4_cd": "0A",
                            "srvc_end_dt": new Date("2021-03-20"),
                            "srvc_strt_dt": new Date("2021-03-19"),
                            "init_trt_dt": null,
                            "plsrv_ref_id": 3741,
                            "srvc_desc_ref_id": 4347,
                            "hsc_srvc_non_facl_dmes": [
                                {}
                            ]
                        }
                    ]
                }
            ]
        };
        const eventList: HscBusEvent[] = [];
        const payload = JSON.parse(JSON.stringify(hscBasePayload));
        service.createChildBusinessEvents(updateHscRequest, hscBasePayload, payload, eventList, currentHsc);
        expect(eventList.length > 0);
        const caseTypeUpdateEvent = eventList.find(
          (event) => event.eventName == HscBusEventName.HSC_CASE_TYPE_UPDATE
        );
        expect(caseTypeUpdateEvent != null);
    });

    it('should call update hsc_srvc for OP', () => {
        let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
        const result2: AxiosResponse = { data: "https://dev-ecp-api.optum.com/auth/oauth/jwks", status: 200, statusText: 'OK', headers: {}, config: {}, };
        const result3: AxiosResponse = { data: "ecp", status: 200, statusText: 'OK', headers: {}, config: {}, };
        jest.spyOn(config, 'get').mockImplementationOnce(() => of(result2));
        jest.spyOn(config, 'get').mockImplementationOnce(() => of(result3));
        spyOn<any>(AuthorizationService, 'getEcpAuthencatedUser').and.returnValue({"userId": "00136607"})
        const updateHscRequest: UpdateHscRequest = {
            "hsc_id": 13612,
            "indv_key_typ_ref_id": 2757,
            "indv_key_val": "16440436900",
            "srvc_set_ref_id": 3737,
            "hsc_srvcs": [
                {
                    "hsc_srvc_id": 1,
                    "proc_cd": "78130",
                    "proc_cd_schm_ref_id": 2,
                    "srvc_hsc_prov_id": null,
                    "hsc_prov": {
                        "fst_nm": "IMRAN",
                        "lst_nm": "ABASSI",
                        "prov_keys": [
                            {
                                "prov_key_typ_ref_id": 2782,
                                "prov_key_val": "1003875014"
                            },
                            {
                                "prov_key_typ_ref_id": 16333,
                                "prov_key_val": "288158608"
                            },
                            {
                                "prov_key_typ_ref_id": 2783,
                                "prov_key_val": "1710081369"
                            }
                        ],
                        "hsc_prov_roles": [
                            {
                                "prov_role_ref_id": 3765
                            }
                        ],
                        "prov_adr": {
                            "adr_ln_1_txt": "8221 Willow Oaks Corporate Dr Ste 4-420",
                            "adr_ln_2_txt": null,
                            "zip_cd_txt": "22031",
                            "cty_nm": "Fairfax",
                            "st_ref_id": 1114
                        }
                    },
                    "hsc_decn": {
                        "hsc_decn_id":2,
                        "decn_otcome_ref_id": 1,
                        "decn_typ_ref_id": 2,
                        "decn_rsn_ref_id": 3,
                        "clm_note_txt": "test",
                        "ovrd_clm_rmrk_ref_id": 1,
                        "sys_clm_rmrk_ref_id": 1,
                        "decn_src_desc": {
                            "test": "test"
                        },
                        "gap_rev_otcome_ref_id": 2,
                        "negot_rt": 1
                    },
                    "hsc_srvc_non_facls": [
                        {
                            "hsc_srvc_id": 1,
                            "srvc_dtl_ref_id": 3771,
                            "proc_freq_ref_id": 3913,
                            "proc_uom_ref_id": 19884,
                            "proc_unit_cnt": 1,
                            "unit_per_freq_cnt": 1,
                            "proc_mod_1_cd": "00",
                            "proc_mod_2_cd": "00",
                            "proc_mod_3_cd": "0A",
                            "proc_mod_4_cd": "0A",
                            "srvc_end_dt": new Date("2021-03-20"),
                            "srvc_strt_dt": new Date("2021-03-19"),
                            "init_trt_dt": null,
                            "plsrv_ref_id": 3741,
                            "srvc_desc_ref_id": 4347,
                            "hsc_srvc_non_facl_dmes": [
                                {}
                            ]
                        }
                    ]
                }
            ]
        };
        service.updateHscDetails(updateHscRequest, httpRequest).then((res) => {
            expect(res.hsc[0].hsc_id).toEqual(13612);
        });
    });

    it('should call update hsc_srvc for OP', () => {
        let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
        const result2: AxiosResponse = { data: "https://dev-ecp-api.optum.com/auth/oauth/jwks", status: 200, statusText: 'OK', headers: {}, config: {}, };
        const result3: AxiosResponse = { data: "ecp", status: 200, statusText: 'OK', headers: {}, config: {}, };
        jest.spyOn(config, 'get').mockImplementationOnce(() => of(result2));
        jest.spyOn(config, 'get').mockImplementationOnce(() => of(result3));
        spyOn<any>(AuthorizationService, 'getEcpAuthencatedUser').and.returnValue({"userId": "00136607"})
        const updateHscRequest: UpdateHscRequest = {
            "hsc_id": 13612,
            "indv_key_typ_ref_id": 2757,
            "indv_key_val": "16440436900",
            "srvc_set_ref_id": 3737,
            "hsc_srvcs": [
                {
                    "hsc_srvc_id": 1,
                    "proc_cd": "78130",
                    "proc_cd_schm_ref_id": 2,
                    "srvc_hsc_prov_id": null,
                    "hsc_prov": {
                        "fst_nm": "IMRAN",
                        "lst_nm": "ABASSI",
                        "prov_keys": [
                            {
                                "prov_key_typ_ref_id": 2782,
                                "prov_key_val": "1003875014"
                            },
                            {
                                "prov_key_typ_ref_id": 16333,
                                "prov_key_val": "288158608"
                            },
                            {
                                "prov_key_typ_ref_id": 2783,
                                "prov_key_val": "1710081369"
                            }
                        ],
                        "hsc_prov_roles": [
                            {
                                "prov_role_ref_id": 3765
                            }
                        ],
                        "prov_adr": {
                            "adr_ln_1_txt": "8221 Willow Oaks Corporate Dr Ste 4-420",
                            "adr_ln_2_txt": null,
                            "zip_cd_txt": "22031",
                            "cty_nm": "Fairfax",
                            "st_ref_id": 1114
                        }
                    },
                    "hsc_decn": {
                        "hsc_decn_id":2,
                        "decn_otcome_ref_id": 1,
                        "decn_typ_ref_id": 2,
                        "decn_rsn_ref_id": 3,
                        "clm_note_txt": "test",
                        "ovrd_clm_rmrk_ref_id": 1,
                        "sys_clm_rmrk_ref_id": 1,
                        "decn_src_desc": {
                            "test": "test"
                        },
                        "gap_rev_otcome_ref_id": 2,
                        "negot_rt": 1
                    },
                    "hsc_srvc_non_facls": [
                        {
                            "srvc_dtl_ref_id": 3771,
                            "proc_freq_ref_id": 3913,
                            "proc_uom_ref_id": 19884,
                            "proc_unit_cnt": 1,
                            "unit_per_freq_cnt": 1,
                            "proc_mod_1_cd": "00",
                            "proc_mod_2_cd": "00",
                            "proc_mod_3_cd": "0A",
                            "proc_mod_4_cd": "0A",
                            "srvc_end_dt": new Date("2021-03-20"),
                            "srvc_strt_dt": new Date("2021-03-19"),
                            "init_trt_dt": null,
                            "plsrv_ref_id": 3741,
                            "srvc_desc_ref_id": 4347,
                            "hsc_srvc_non_facl_dmes": [
                                {}
                            ]
                        }
                    ]
                }
            ]
        };
        service.updateHscDetails(updateHscRequest, httpRequest).then((res) => {
            expect(res.hsc[0].hsc_id).toEqual(13612);
        });
    });

    it('should call soft delete hsc_prov', () => {
        let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',  headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
        const result2: AxiosResponse = { data: "https://dev-ecp-api.optum.com/auth/oauth/jwks", status: 200, statusText: 'OK', headers: {}, config: {}, };
        const result3: AxiosResponse = { data: "ecp", status: 200, statusText: 'OK', headers: {}, config: {}, };
        jest.spyOn(config, 'get').mockImplementationOnce(() => of(result2));
        jest.spyOn(config, 'get').mockImplementationOnce(() => of(result3));
        spyOn<any>(AuthorizationService, 'getEcpAuthencatedUser').and.returnValue({"userId": "00136607"})
        const updateHscRequest: UpdateHscRequest = {
            "hsc_id": 21279,
                "indv_key_typ_ref_id": 2757,
                "indv_key_val": "16440436900",
                "srvc_set_ref_id": 3737,
                "hsc": {
                "hsc_sts_ref_id": 19275
            },
            "hsc_provs": [
                {
                    "hsc_prov_id": 10382,
                    "end_dt": new Date("2021-05-31"),
                    "fst_nm": "IMRAN",
                    "lst_nm": "ABASSI",
                    "prov_keys": [
                        {
                            "prov_key_typ_ref_id": 2782,
                            "prov_key_val": "1003875014"
                        },
                        {
                            "prov_key_typ_ref_id": 16333,
                            "prov_key_val": "288158608"
                        },
                        {
                            "prov_key_typ_ref_id": 2783,
                            "prov_key_val": "1710081369"
                        }
                    ],
                    "hsc_prov_roles": [
                        {
                            "prov_role_ref_id": 3765
                        },
                        {
                            "prov_role_ref_id": 3764
                        }
                    ],
                    "prov_adr": {
                        "adr_ln_1_txt": "8221 Willow Oaks Corporate Dr Ste 4-420",
                        "adr_ln_2_txt": null,
                        "zip_cd_txt": "22031",
                        "cty_nm": "Fairfax",
                        "st_ref_id": 1114
                    }
                }
            ]
    };
        service.updateHscDetails(updateHscRequest, httpRequest).then((res) => {
            expect(res.hsc[0].hsc_id).toEqual(21279);
        });
    });

});

