import {HttpException, Injectable, Logger} from '@nestjs/common';
import {HealthServiceClient} from '../../../shared/graphql/healthservicedomain/healthServiceClient';
import {
    getAccmulatedBedDayQuery,
    getHscDiagnosisAndProcedure,
    getHscStatus,
    insertDecision,
    insertNote,
    insertProvider,
    insertProviderRole,
    updateHscMutation,
    insertDiagnosis,
    updateDiagnosis,
    upsertKey,
    insertProc,
    updateProc,
    updateHscSrvcNonFacl,
    updateHscSrvcNonFaclDme,
    insertHscServiceNonFacility,
    getHscFacility,
    insertHscFaclMutation,
    updateHscFacl,
    deleteHscProvRoles,
    deleteHscProv,
    updateProvider,
    updateNotes,
    hscDecnBedDayMutation,
    updatehscDecnMutation, insertHscDecnMutation,
    getHscClinGuid,
    updateHscClinGuidMutation,
    insertHscClinGuidMutation, insertProcSingle, getMemCovDtlByHscId, insertHsrAsgnSbjMutation
} from "../../../shared/graphql/healthservicedomain/healthServiceQuery";
import {UpdateHscRequest} from "../../models/updateHscRequest";
import {HttpRequest} from "@azure/functions";
import {GraphQLClient} from "graphql-request/dist";
import {AuthorizationService} from "@ecp/func-tk/dist";
import {ConfigService} from "@nestjs/config";
import {GetHscAuthService} from "../getHscAuth/getHscAuth.service";
import {GetHscAuthRequest} from "../../models/getHscAuthRequest";
import {GetHscAuthResponse} from "../../models/getHscAuthResponse";
import {ProviderService} from "../provider.service";
import {ReferenceConstants} from "../../../shared/constants/referenceConstants";
import {MemberClient} from "../../../shared/graphql/memberdomain/memberClient";
import * as moment from 'moment';
import {MemberService} from "../member/member.service";
import {BeddayResponse} from "../../models/BeddayResponse";
import {HscBusinessEventService} from "../businessEvents/hsc-bus-event/hsc-bus-event.service";
import {HscEntityActionType} from "../../models/HscEntityActionType";
import {HscBusEvent} from "../../models/HscBusEvent";
import {HscBusEventName} from "../../models/HscBusEventName";
import {InjectPinoLogger, PinoLogger} from "nestjs-pino/dist";


let currentDate;

async function updateHscKeys(updateHscRequest: UpdateHscRequest, ecpAuthenticatedUser, hscGraphqlClient: GraphQLClient) {
    const hscKeys = [];
    for (let i = 0; i < updateHscRequest.hsc_keys.length; i++) {
        hscKeys.push({
            hsc_id: updateHscRequest.hsc_id,
            hsc_key_typ_ref_id: updateHscRequest.hsc_keys[i].hsc_key_typ_ref_id,
            hsc_key_val: updateHscRequest.hsc_keys[i].hsc_key_val,
            creat_user_id: updateHscRequest.hsc_keys[i].creat_user_id ? updateHscRequest.hsc_keys[i].creat_user_id : ecpAuthenticatedUser,
            creat_dttm: currentDate,
            chg_dttm: currentDate,
            inac_ind: updateHscRequest.hsc_keys[i].inac_ind? updateHscRequest.hsc_keys[i].inac_ind : 0
        })
    }
    const hcsKeysVariables = {key: hscKeys,
        "upsertHsckeys": [
            "inac_ind"
        ]};
    await hscGraphqlClient.request(upsertKey, hcsKeysVariables);
}

function procedureChildEventAction(service, hscService) {
    if (service.hsc_srvc_id == hscService.hsc_srvc_id) {
        hscService.action = service.action;
        return;
    }
}

function updateProcedureChildBusinessEvent(updateHscRequest: UpdateHscRequest, hscBasePayload, payload, eventList: HscBusEvent[]) {
    if (updateHscRequest.hsc_srvcs && updateHscRequest.hsc_srvcs.length > 0) {
        const basePayload = payload;
        updateHscRequest.hsc_srvcs.forEach(async ( service) => {
            basePayload.hsc.hsc_data.hsc_srvcs.map(hscService => {
                procedureChildEventAction(service, hscService);
            });
            hscBasePayload.hsc.hsc_data.hsc_srvcs.forEach(hscService => {
                procedureChildEventAction(service, hscService);
            });

        });
        eventList.push({eventName: HscBusEventName.HSC_PROCEDURE_UPDATE, payload: basePayload});
    }
}

function updateProviderChildBusinessEvent(updateHscRequest: UpdateHscRequest, hscBasePayload, payload, eventList: HscBusEvent[]) {
    if (updateHscRequest.hsc_provs && updateHscRequest.hsc_provs.length > 0) {
        const indHscBasePayload = JSON.parse(JSON.stringify(payload));
        updateHscRequest.hsc_provs.forEach(async (prov) => {
            indHscBasePayload.hsc.hsc_data.hsc_provs.map(hscProv => {
                if (prov.hsc_prov_id == hscProv.hsc_prov_id) {
                    hscProv.action = prov.action;
                    return;
                }
            });
            hscBasePayload.hsc.hsc_data.hsc_provs.map(hscProv => {
                if (prov.hsc_prov_id == hscProv.hsc_prov_id) {
                    hscProv.action = prov.action;
                    return;
                }
            });

        });
        eventList.push({eventName: HscBusEventName.HSC_PROVIDER_UPDATE, payload: indHscBasePayload});
    }
}

function updateContactChildBusinessEvent(updateHscRequest: UpdateHscRequest, hscBasePayload, payload, eventList: HscBusEvent[]) {
    const indHscBasePayload = payload;
    if(updateHscRequest.flwup_cntc_dtl) {
        if(hscBasePayload.hsc.hsc_data.flwup_cntc_dtl!=null){
        hscBasePayload.hsc.hsc_data.flwup_cntc_dtl.map(cntctDtl => {
                cntctDtl.action = HscEntityActionType.UPDATE;
                return;
        })
    };
    if(indHscBasePayload.hsc.hsc_data.flwup_cntc_dtl != null){
        indHscBasePayload.hsc.hsc_data.flwup_cntc_dtl.map(cntctDtl => {
                cntctDtl.action = HscEntityActionType.UPDATE;
                return;
        })
    };
        eventList.push({ eventName: HscBusEventName.HSC_CONTACT_UPDATE, payload: indHscBasePayload });
    }
    
}

function updateDiagnosisChildBusinessEvent(updateHscRequest: UpdateHscRequest, hscBasePayload, payload, eventList: HscBusEvent[]) {
    if (updateHscRequest.hsc_diags && updateHscRequest.hsc_diags.length > 0) {
        const indHscBasePayload = JSON.parse(JSON.stringify(payload));
        updateHscRequest.hsc_diags.forEach(async (diag) => {
            indHscBasePayload.hsc.hsc_data.hsc_diags.map(hscDiag => {
                if (diag.hsc_diag_id == hscDiag.hsc_diag_id) {
                    hscDiag.action = diag.action;
                    return;
                }
            });
            hscBasePayload.hsc.hsc_data.hsc_diags.map(hscDiag => {
                if (diag.hsc_diag_id == hscDiag.hsc_diag_id) {
                    hscDiag.action = diag.action;
                    return;
                }
            });

        });
        eventList.push({eventName: HscBusEventName.HSC_DIAGNOSIS_UPDATE, payload: indHscBasePayload});
    }
}

function updateHsrNotesChildBusinessEvent(updateHscRequest: UpdateHscRequest, payload, hscBasePayload, eventList: HscBusEvent[]) {
    if (updateHscRequest.hsr_notes && updateHscRequest.hsr_notes.length > 0) {
        const indHscBasePayload = JSON.parse(JSON.stringify(payload));
        updateHscRequest.hsr_notes.forEach(async (note) => {
            indHscBasePayload.hsc.hsc_data.hsr_notes.map(hscNote => {
                if (note.hsr_note_id == hscNote.hsr_note_id) {
                    hscNote.action = note.action;
                    return;
                }
            });
            hscBasePayload.hsc.hsc_data.hsr_notes.map(hscNote => {
                if (note.hsr_note_id == hscNote.hsr_note_id) {
                    hscNote.action = note.action;
                    return;
                }
            });

        });
        eventList.push({eventName: HscBusEventName.HSC_NOTES_UPDATE, payload: indHscBasePayload});
    }
}

function updateFacilityDecnChildBusinessEvent(updateHscRequest: UpdateHscRequest, hscBasePayload, payload, eventList: HscBusEvent[]) {
    if (updateHscRequest.hsc_facl?.hsc_decn) {
        const indHscBasePayload = JSON.parse(JSON.stringify(payload));
        hscBasePayload.hsc.hsc_data.hsc_decns.map(hscDecn => {
            if (updateHscRequest.hsc_facl.hsc_decn.hsc_decn_id == hscDecn.hsc_decn_id) {
                hscDecn.action = HscEntityActionType.CREATE;
                return;
            }
        });
        indHscBasePayload.hsc.hsc_data.hsc_decns.map(hscDecn => {
            if (updateHscRequest.hsc_facl.hsc_decn.hsc_decn_id == hscDecn.hsc_decn_id) {
                hscDecn.action = HscEntityActionType.CREATE;
                return;
            }
        });
        eventList.push({ eventName: HscBusEventName.HSC_DECISION_UPDATE, payload: indHscBasePayload });
    }
}

function updateActualAdmsnDateChildEvent(currentHsc, updateHscRequest: UpdateHscRequest, eventList: HscBusEvent[], indHscBasePayload) {
    if (updateHscRequest.hsc_facl?.actul_admis_dttm && updateHscRequest.hsc_facl?.actul_admis_dttm != currentHsc.hsc_facls[0]?.actul_admis_dttm ) {
        eventList.push({ eventName: HscBusEventName.HSC_ADMISSION_DATE_UPDATE, payload: indHscBasePayload });
    }
}

function updateActualDschrgDateChildEvent(currentHsc, updateHscRequest: UpdateHscRequest, eventList: HscBusEvent[], indHscBasePayload) {
    if (updateHscRequest.hsc_facl?.actul_dschrg_dttm && updateHscRequest.hsc_facl?.actul_dschrg_dttm != currentHsc.hsc_facls[0]?.actul_dschrg_dttm) {
        eventList.push({ eventName: HscBusEventName.HSC_DISCHARGE_DATE_UPDATE, payload: indHscBasePayload });
    }
}

function updateExptAdmsnDateChildEvent(currentHsc, updateHscRequest: UpdateHscRequest, eventList: HscBusEvent[], indHscBasePayload) {
    if (updateHscRequest.hsc_facl?.expt_admis_dt && updateHscRequest.hsc_facl?.expt_admis_dt != currentHsc.hsc_facls[0]?.expt_admis_dt) {
        eventList.push({ eventName: HscBusEventName.HSC_EXPT_ADMISSION_DATE_UPDATE, payload: indHscBasePayload });
    }
}

function updateExptDschrgDateChildEvent(currentHsc, updateHscRequest: UpdateHscRequest, eventList: HscBusEvent[], indHscBasePayload) {
    if (updateHscRequest.hsc_facl?.expt_dschrg_dt && updateHscRequest.hsc_facl?.expt_dschrg_dt != currentHsc.hsc_facls[0]?.expt_dschrg_dt) {
        eventList.push({ eventName: HscBusEventName.HSC_EXPT_DISCHARGE_DATE_UPDATE, payload: indHscBasePayload });
    }
}

function updateHscSrvcNonFaclsAction(srvc, hscSrvc) {
    if (srvc.hsc_srvc_non_facls[0].hsc_srvc_id == hscSrvc.hsc_srvc_id) {
        hscSrvc.hsc_srvc_non_facls[0].action = HscEntityActionType.UPDATE;
        return;
    }
}

function updateOPCaseTypeChildEvent(updateHscRequest: UpdateHscRequest, currentHsc, indHscBasePayload, hscBasePayload, eventList: HscBusEvent[]) {
    updateHscRequest.hsc_srvcs.forEach(async (srvc) => {
        currentHsc.hsc_srvcs.forEach((currentSrvc) => {
            if (srvc.hsc_srvc_non_facls[0].hsc_srvc_id && srvc.hsc_srvc_id == currentSrvc.hsc_srvc_id) {
                if (srvc.hsc_srvc_non_facls[0].plsrv_ref_id != currentSrvc.hsc_srvc_non_facls[0].plsrv_ref_id || srvc.hsc_srvc_non_facls[0].srvc_desc_ref_id != currentSrvc.hsc_srvc_non_facls[0].srvc_desc_ref_id
                     || updateHscRequest.hsc?.rev_prr_ref_id != currentHsc.rev_prr_ref_id) {
                            indHscBasePayload.hsc.hsc_data.hsc_srvcs.map(hscSrvc => {
                                updateHscSrvcNonFaclsAction(srvc, hscSrvc);
                            });
                            hscBasePayload.hsc.hsc_data.hsc_srvcs.map(hscSrvc => {
                                updateHscSrvcNonFaclsAction(srvc, hscSrvc);
                            });
                            eventList.push({eventName: HscBusEventName.HSC_CASE_TYPE_UPDATE,payload: indHscBasePayload });
                }
            }
        });
    });
}

function updateCaseTypeChildBusinessEvent(currentHsc, updateHscRequest: UpdateHscRequest, hscBasePayload, payload, eventList: HscBusEvent[]) {
     const indHscBasePayload = JSON.parse(JSON.stringify(payload));
     if(currentHsc != null && updateHscRequest.srvc_set_ref_id) {
         if (updateHscRequest.srvc_set_ref_id != ReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_REFID) {
             hscBasePayload.hsc.hsc_data.hsc_facls[0].action = HscEntityActionType.UPDATE;
             indHscBasePayload.hsc.hsc_data.hsc_facls[0].action = HscEntityActionType.UPDATE;
             if (updateHscRequest.srvc_set_ref_id != currentHsc.srvc_set_ref_id || updateHscRequest.hsc?.rev_prr_ref_id != currentHsc.rev_prr_ref_id ||
                 updateHscRequest.hsc_facl?.plsrv_ref_id != currentHsc.hsc_facls[0].plsrv_ref_id || updateHscRequest.hsc_facl?.srvc_dtl_ref_id != currentHsc.hsc_facls[0].srvc_dtl_ref_id ||
                 updateHscRequest.hsc_facl?.srvc_desc_ref_id != currentHsc.hsc_facls[0].srvc_desc_ref_id) {
                     indHscBasePayload.hsc.hsc_data.action = HscEntityActionType.UPDATE;
                     eventList.push({ eventName: HscBusEventName.HSC_CASE_TYPE_UPDATE, payload: indHscBasePayload });
             }
             updateActualAdmsnDateChildEvent(currentHsc, updateHscRequest, eventList, indHscBasePayload);
             updateActualDschrgDateChildEvent(currentHsc, updateHscRequest, eventList, indHscBasePayload);
         } else {
             if(updateHscRequest.hsc_srvcs && updateHscRequest.hsc_srvcs.length > 0) {
                 updateOPCaseTypeChildEvent(updateHscRequest, currentHsc, indHscBasePayload, hscBasePayload, eventList);
             }
         }
         /*for inpatient hsc_facl expected dates*/
         if (updateHscRequest.srvc_set_ref_id == ReferenceConstants.SERVICESETTINGTYPE_INPATIENT_REFID) {
                 hscBasePayload.hsc.hsc_data.hsc_facls[0].action = HscEntityActionType.UPDATE;
                 indHscBasePayload.hsc.hsc_data.hsc_facls[0].action = HscEntityActionType.UPDATE;
                 updateExptAdmsnDateChildEvent(currentHsc, updateHscRequest, eventList, indHscBasePayload);
                 updateExptDschrgDateChildEvent(currentHsc, updateHscRequest, eventList, indHscBasePayload);
         }
     }
}


@Injectable()
export class UpdateHscService {
    constructor(private readonly healthServiceClient: HealthServiceClient,
                private configService: ConfigService,
                private memberClient:MemberClient,
                private memberService: MemberService,
                private getHscAuthService: GetHscAuthService,
                private providerService: ProviderService,
                @InjectPinoLogger(UpdateHscService.name) private readonly logger: PinoLogger, private readonly hscBusinessEventService:HscBusinessEventService) {}

    async updateHscDetails(updateHscRequest : UpdateHscRequest, httpRequest: HttpRequest): Promise<GetHscAuthResponse> {
        currentDate = (moment(new Date())).format('DD-MMM-YYYY HH:mm:ss');
        const getUserId = await AuthorizationService.getEcpAuthencatedUser(httpRequest.headers.authorization,
        this.configService.get<string>('JWK_URI'), this.configService.get<string>('ISSUER'));
        const ecpAuthenticatedUser = getUserId.userId;
        const hscGraphqlClient: GraphQLClient = this.healthServiceClient.getGraphqlClient(httpRequest);
        const mbrGraphqlClient: GraphQLClient = this.memberClient.getGraphqlClient(httpRequest);
        try{
            this.logger.info("Before query (getHscStatus) to health service domain for hsc_id : " +updateHscRequest.hsc_id+ " at: "+ new Date());
            const currentHscResponse  = await hscGraphqlClient.request(getHscStatus, {hscId: updateHscRequest.hsc_id});
            this.logger.info("After query (getHscStatus) to health service domain for hsc_id : " +updateHscRequest.hsc_id+ " at: "+ new Date());
            const currentHsc = currentHscResponse.hsc.length > 0 ? currentHscResponse.hsc[0] : null;
            await this.updateCompleteHsc(updateHscRequest, ecpAuthenticatedUser, hscGraphqlClient, mbrGraphqlClient, httpRequest, currentHsc);
            const getHscAuthRequest : GetHscAuthRequest = {hsc:{hsc_id: updateHscRequest.hsc_id}};
            const getHscAuthResponse: GetHscAuthResponse = await this.getHscAuthService.hscAuthDetails(getHscAuthRequest, httpRequest);
            const hscBasePayload = await this.hscBusinessEventService.buildBaseHscPayload(updateHscRequest.hsc_id, httpRequest);
            const payload = JSON.parse(JSON.stringify(hscBasePayload));
            if(currentHsc && currentHsc.hsc_sts_ref_id === ReferenceConstants.HSCSTATUSTYPE_DRAFT_REFID && getHscAuthResponse.hsc[0].hsc_sts_ref_id != ReferenceConstants.HSCSTATUSTYPE_DRAFT_REFID){
                hscBasePayload.hsc.hsc_data.action = HscEntityActionType.CREATE;
                const eventList: HscBusEvent[] = [{eventName: HscBusEventName.HSC_CREATE, payload: hscBasePayload}];
                this.hscBusinessEventService.pushHscBusinessEvents(eventList, httpRequest);
            }else if(currentHsc &&  getHscAuthResponse.hsc[0].hsc_sts_ref_id  != ReferenceConstants.HSCSTATUSTYPE_DRAFT_REFID){
                hscBasePayload.hsc.hsc_data.action = HscEntityActionType.UPDATE;
                const eventList: HscBusEvent[] = [];
                this.createChildBusinessEvents(updateHscRequest, hscBasePayload, payload, eventList, currentHsc);
                eventList.push({eventName: HscBusEventName.HSC_UPDATE, payload: hscBasePayload});
                this.hscBusinessEventService.pushHscBusinessEvents(eventList, httpRequest);
            }
            return getHscAuthResponse;
        }catch(e){
            this.logger.error("Exception occurred in updateHscDetails for hscId: " +updateHscRequest.hsc_id + "Exception: " + e);
            throw e;
        }
    }

    createChildBusinessEvents(updateHscRequest: UpdateHscRequest, hscBasePayload, payload, eventList: HscBusEvent[], currentHsc) {
        updateCaseTypeChildBusinessEvent(currentHsc,updateHscRequest, hscBasePayload, payload, eventList);
        updateFacilityDecnChildBusinessEvent(updateHscRequest, hscBasePayload, payload, eventList);
        updateProviderChildBusinessEvent(updateHscRequest, hscBasePayload, payload, eventList);
        updateDiagnosisChildBusinessEvent(updateHscRequest, hscBasePayload, payload, eventList);
        updateHsrNotesChildBusinessEvent(updateHscRequest, payload, hscBasePayload, eventList);
        updateProcedureChildBusinessEvent(updateHscRequest, hscBasePayload, payload, eventList);
        updateContactChildBusinessEvent(updateHscRequest, hscBasePayload, payload, eventList);

    }

    private async updateCompleteHsc(updateHscRequest: UpdateHscRequest, ecpAuthenticatedUser, hscGraphqlClient: GraphQLClient, mbrGraphqlClient: GraphQLClient, httpRequest: HttpRequest, currentHsc: any) {
        if (updateHscRequest.hsc || updateHscRequest.flwup_cntc_dtl) {
            this.logger.info("Before updateHsc for hsc_id : " +updateHscRequest.hsc_id+ " at: "+ new Date());
            await updateHsc(updateHscRequest, ecpAuthenticatedUser, hscGraphqlClient, mbrGraphqlClient, this.memberService, httpRequest);
            this.logger.info("After updateHsc for hsc_id : " +updateHscRequest.hsc_id+ " at: "+ new Date());
        }
        if (updateHscRequest.hsc_diags && updateHscRequest.hsc_diags.length > 0) {
            this.logger.info("Before updateHscDiagnosis for hsc_id : " +updateHscRequest.hsc_id+ " at: "+ new Date());
            await updateHscDiagnosis(updateHscRequest, ecpAuthenticatedUser, hscGraphqlClient);
            this.logger.info("After updateHscDiagnosis for hsc_id : " +updateHscRequest.hsc_id+ " at: "+ new Date());
        }
        if (updateHscRequest.hsr_notes && updateHscRequest.hsr_notes.length > 0) {
            this.logger.info("Before updateHscNotes for hsc_id : " +updateHscRequest.hsc_id+ " at: "+ new Date());
            await updateHscNotes(updateHscRequest, ecpAuthenticatedUser, hscGraphqlClient);
            this.logger.info("After updateHscNotes for hsc_id : " +updateHscRequest.hsc_id+ " at: "+ new Date());
        }
        if (updateHscRequest.hsc_provs && updateHscRequest.hsc_provs.length > 0) {
            this.logger.info("Before updateHscProvider for hsc_id : " +updateHscRequest.hsc_id+ " at: "+ new Date());
            await updateHscProvider(updateHscRequest, hscGraphqlClient, ecpAuthenticatedUser, this.providerService, httpRequest, currentHsc);
            this.logger.info("After updateHscProvider for hsc_id : " +updateHscRequest.hsc_id+ " at: "+ new Date());
        }
        if (updateHscRequest.hsc_facl) {
            this.logger.info("Before updateFacility for hsc_id : " +updateHscRequest.hsc_id+ " at: "+ new Date());
            await updateFacility(updateHscRequest, hscGraphqlClient, ecpAuthenticatedUser);
            this.logger.info("After updateFacility for hsc_id : " +updateHscRequest.hsc_id+ " at: "+ new Date());
        }
        if (updateHscRequest.hsc_srvcs && updateHscRequest.hsc_srvcs.length > 0) {
            this.logger.info("Before updateHscServices for hsc_id : " +updateHscRequest.hsc_id+ " at: "+ new Date());
            await updateHscServices(updateHscRequest, hscGraphqlClient, ecpAuthenticatedUser, this.providerService, httpRequest);
            this.logger.info("After updateHscServices for hsc_id : " +updateHscRequest.hsc_id+ " at: "+ new Date());
        }

        if (updateHscRequest.hsc_keys && updateHscRequest.hsc_keys.length > 0) {
            this.logger.info("Before updateHscKeys for hsc_id : " +updateHscRequest.hsc_id+ " at: "+ new Date());
            await updateHscKeys(updateHscRequest, ecpAuthenticatedUser, hscGraphqlClient);
            this.logger.info("After updateHscKeys for hsc_id : " +updateHscRequest.hsc_id+ " at: "+ new Date());
        }

        if (updateHscRequest.hsc_decn) {
            this.logger.info("Before updateHscDecision for hsc_id : " +updateHscRequest.hsc_id+ " at: "+ new Date());
            await this.updateHscDecision(updateHscRequest, ecpAuthenticatedUser, hscGraphqlClient, httpRequest);
            this.logger.info("After updateHscDecision for hsc_id : " +updateHscRequest.hsc_id+ " at: "+ new Date());
        }

        if (updateHscRequest.hsc_clin_guid) {
            this.logger.info("Before updateHscClinGuid for hsc_id : " +updateHscRequest.hsc_id+ " at: "+ new Date());
            await updateHscClinGuid(updateHscRequest, hscGraphqlClient, ecpAuthenticatedUser);
            this.logger.info("After updateHscClinGuid for hsc_id : " +updateHscRequest.hsc_id+ " at: "+ new Date());
        }
    }

    async updateHscDecision(updateHscRequest: UpdateHscRequest, ecpAuthenticatedUser, hscGraphqlClient: GraphQLClient, httpRequest: HttpRequest) {
        try {
            let hscDecnResponse: BeddayResponse = {beddayRes: {}};
            hscDecnResponse = await this.saveHscDecn(updateHscRequest, hscGraphqlClient,ecpAuthenticatedUser);
            if(updateHscRequest.hsc_decn?.hsc_decn_bed_days && updateHscRequest.hsc_decn.hsc_decn_bed_days.length>0){
                await this.saveHscDecnBedDay(updateHscRequest, hscGraphqlClient, updateHscRequest?.hsc_decn?.hsc_decn_id?updateHscRequest?.hsc_decn?.hsc_decn_id:hscDecnResponse?.['res']?.insert_hsc_decn?.returning[0]?.hsc_decn_id,ecpAuthenticatedUser);
            }
        } catch (e) {
            this.logger.error("updateHscDecision:exception while saving bedday decision (updateHscRequest: " +updateHscRequest+") " + e)
        }
    }

    async saveHscDecn(updateHscRequest, hscGraphqlClient, ecpAuthenticatedUser) {
        try {
            const hscDescInputRows: any[] = [];
            hscDescInputRows.push({
                decn_bed_day_cnt: updateHscRequest?.hsc_decn?.decn_bed_day_cnt,
                decn_otcome_ref_id: updateHscRequest?.hsc_decn?.decn_otcome_ref_id,
                creat_user_id : updateHscRequest?.hsc_decn?.creat_user_id? updateHscRequest?.hsc_decn?.creat_user_id : ecpAuthenticatedUser,
                chg_user_id: updateHscRequest?.hsc_decn?.chg_user_id ? updateHscRequest?.hsc_decn?.chg_user_id: ecpAuthenticatedUser,
                decn_made_by_user_id: updateHscRequest?.hsc_decn?.decn_made_by_user_id ? updateHscRequest?.hsc_decn?.decn_made_by_user_id : ecpAuthenticatedUser,
                hsc_id: updateHscRequest?.hsc_id,
                decn_typ_ref_id:updateHscRequest?.hsc_decn?.decn_typ_ref_id,
                mbr_cov_dtl: await this.getMbrCovDtlByHscId(updateHscRequest?.hsc_id,hscGraphqlClient)
            });
            let hscDecisionResponse: any;
            if(updateHscRequest?.hsc_decn?.hsc_decn_id){
                const hscDescVariables = {
                    hsc_decn_id: updateHscRequest?.hsc_decn?.hsc_decn_id,
                    inputArray: hscDescInputRows[0],
                };
                await hscGraphqlClient.request(updatehscDecnMutation, hscDescVariables).then((res) => {
                    hscDecisionResponse = {
                        res
                    };
                });
            }
            else{
                const hscDescVariables = {
                    inputArray: hscDescInputRows,
                };
                await hscGraphqlClient.request(insertHscDecnMutation, hscDescVariables).then((res) => {
                    hscDecisionResponse = {
                        res
                    };
                });
            }
            return hscDecisionResponse;
        } catch (e) {
            this.logger.error("saveHscDecn:Exception Occurred in while saving Hsc Decision (updateHscRequest: " +updateHscRequest+") " + e)
        }
    }

    async getMbrCovDtlByHscId(hscId, hscGraphqlClient){
        try{
            let memCovDtl;
            const requestBody = {
                hsc_id:hscId
            }
            await hscGraphqlClient.request(getMemCovDtlByHscId,requestBody).then((res) => {
                memCovDtl = res?.hsc[0]?.mbr_cov_dtl
            });
            return memCovDtl;
        }
        catch(e){
            this.logger.error("getMbrCovDtlByHscId:Exception Occurred geeting memCovDtl " + e)
        }
    }
    async saveHscDecnBedDay(updateHscRequest, hscGraphqlClient, hscDecisionId, ecpAuthenticatedUser) {
        try {
                const hscDescBedDayInputRows: any[] = [];
                hscDescBedDayInputRows.push({
                    hsc_decn_id: hscDecisionId,
                    strt_bed_dt: updateHscRequest?.hsc_decn?.hsc_decn_bed_days[0]?.strt_bed_dt,
                    hsc_clin_guid_id: updateHscRequest?.hsc_decn?.hsc_decn_bed_days[0]?.hsc_clin_guid_id,
                    accum_bed_day_cnt: await this.getAccumuledBedDays( updateHscRequest?.hsc_id, hscGraphqlClient),
                    bed_typ_ref_id:updateHscRequest?.hsc_decn?.hsc_decn_bed_days[0]?.bed_typ_ref_id,
                });
                const hscDescBedDayVariables = {
                    inputArray: hscDescBedDayInputRows,
                };
                await hscGraphqlClient.request(hscDecnBedDayMutation, hscDescBedDayVariables);
                await this.saveHsrAsgnSBj(updateHscRequest,hscDecisionId,hscGraphqlClient);

        } catch (e) {
            this.logger.error("saveHscDecnBedDay:Exception Occurred in while saving Hsc Bed Day Decision (updateHscRequest: " +updateHscRequest+") " + e)
        }
    }

    async saveHsrAsgnSBj(updateHscRequest,hscDecisionId,hscGraphqlClient){
        try{
            if(updateHscRequest?.hsc_decn?.hsr_asgn_id){
                const hsrAsgnSbjVariables = {
                    hsr_asgn_sbj: {
                        hsr_asgn_id: updateHscRequest.hsc_decn?.hsr_asgn_id,
                        asgn_sbj_rec_id: hscDecisionId?.toString(),
                        asgn_sbj_typ_ref_id: ReferenceConstants.SUBJECT_TYPE_CLINICAL_DECISION_REF_ID
                    }
                };
                await hscGraphqlClient.request(insertHsrAsgnSbjMutation,hsrAsgnSbjVariables)
            }
        }
        catch(e){
            this.logger.error("saveHsrAsgnSBj:Exception Occurred in while saving Hsr_asgn_sbj (updateHscRequest: " +updateHscRequest+") " + e)
        }
    }

    async getAccumuledBedDays(hsc_id, hscGraphqlClient) {
        try {
            let accumulatedBedDay = 0;
            const accumulatedBedDayVariables = {
                hsc_id: hsc_id
            };
            await hscGraphqlClient.request(getAccmulatedBedDayQuery, accumulatedBedDayVariables).then((res) => {
                accumulatedBedDay = res?.hsc_decn_aggregate?.aggregate?.sum?.decn_bed_day_cnt;
            });
            return accumulatedBedDay;
        } catch (e) {
            this.logger.error("getAccumuledBedDays:Exception Occurred in getting accumulated bed days:" + e)
        }
    }

}

async function getHscInput(updateHscRequest: UpdateHscRequest, ecpAuthenticatedUser, memberService: MemberService, httpRequest) {
    const hscInput: any = {
        creat_user_id: updateHscRequest.creat_user_id ? updateHscRequest.creat_user_id : ecpAuthenticatedUser,
        chg_user_id: updateHscRequest.chg_user_id ? updateHscRequest.chg_user_id : ecpAuthenticatedUser,
        srvc_set_ref_id: updateHscRequest.srvc_set_ref_id,
        rev_prr_ref_id: updateHscRequest.hsc?.rev_prr_ref_id ? updateHscRequest.hsc?.rev_prr_ref_id : undefined,
        hsc_rev_typ_ref_id: updateHscRequest.hsc?.hsc_rev_typ_ref_id ? updateHscRequest.hsc?.hsc_rev_typ_ref_id : undefined,
        hsc_sts_ref_id: updateHscRequest.hsc?.hsc_sts_ref_id ? updateHscRequest.hsc?.hsc_sts_ref_id : undefined,
        hsc_sts_rsn_ref_id: updateHscRequest.hsc?.hsc_sts_rsn_ref_id ? updateHscRequest.hsc?.hsc_sts_rsn_ref_id : undefined,
        auth_typ_ref_id: updateHscRequest.hsc?.auth_typ_ref_id ? updateHscRequest.hsc?.auth_typ_ref_id : undefined,
        creat_sys_ref_id: updateHscRequest.hsc?.creat_sys_ref_id ? updateHscRequest.hsc?.creat_sys_ref_id : undefined,
        chg_sys_ref_id: updateHscRequest.hsc?.chg_sys_ref_id ? updateHscRequest.hsc?.chg_sys_ref_id : undefined,
        mbr_cov_dtl: updateHscRequest.mbr_cov && updateHscRequest.indv_key_val && updateHscRequest.indv_key_typ_ref_id ? await memberService.getMemberCoverageDetails(updateHscRequest.indv_key_val, updateHscRequest.indv_key_typ_ref_id, updateHscRequest.mbr_cov, httpRequest) : undefined,
    };
    return hscInput;
}

async function updateHsc(updateHscRequest: UpdateHscRequest, ecpAuthenticatedUser, hscGraphqlClient: GraphQLClient,
                         mbrGraphqlClient: GraphQLClient, memberService: MemberService, httpRequest) {
    const hscInput = await getHscInput(updateHscRequest, ecpAuthenticatedUser, memberService, httpRequest);
    if(updateHscRequest.hsc?.indv_id || (hscInput.mbr_cov_dtl && hscInput.mbr_cov_dtl.indv_id)) {
        hscInput.indv_id = updateHscRequest.hsc?.indv_id ? updateHscRequest.hsc.indv_id : hscInput.mbr_cov_dtl.indv_id;
    }
    hscInput.flwup_cntc_dtl =  updateHscRequest.flwup_cntc_dtl ? updateHscRequest.flwup_cntc_dtl : undefined;
        const hscVariables = {
        hsc_id: updateHscRequest.hsc_id, updateHsc: hscInput
    };
    await hscGraphqlClient.request(updateHscMutation, hscVariables);
}

function getHscNotesUpdateObj(updateHscRequest: UpdateHscRequest, i: number) {
    return {
        note_txt_lobj: updateHscRequest.hsr_notes[i]?.note_txt_lobj ? updateHscRequest.hsr_notes[i]?.note_txt_lobj : undefined,
        creat_user_id: updateHscRequest.hsr_notes[i]?.creat_user_id ? updateHscRequest.hsr_notes[i]?.creat_user_id : undefined,
        note_titl_txt: updateHscRequest.hsr_notes[i]?.note_titl_txt ? updateHscRequest.hsr_notes[i]?.note_titl_txt : undefined,
        note_typ_ref_id: updateHscRequest.hsr_notes[i]?.note_typ_ref_id ? updateHscRequest.hsr_notes[i]?.note_typ_ref_id : undefined,
        note_catgy_ref_id: updateHscRequest.hsr_notes[i]?.note_catgy_ref_id ? updateHscRequest.hsr_notes[i]?.note_catgy_ref_id : undefined,
    };
}

async function insertHsrNotes(updateHscRequest: UpdateHscRequest, i: number, ecpAuthenticatedUser, hscGraphqlClient: GraphQLClient) {
    const hsrNote: any = {
        ...updateHscRequest.hsr_notes[i],
        hsc_id: updateHscRequest.hsc_id,
        note_txt_lobj: updateHscRequest.hsr_notes[i].note_txt_lobj,
        creat_user_id: updateHscRequest.hsr_notes[i].creat_user_id ? updateHscRequest.hsr_notes[i].creat_user_id : ecpAuthenticatedUser,
        creat_dttm: currentDate,
        chg_dttm: currentDate,
    };
    for (let i = 0; i < hsrNote.hsr_note_sbjs?.length; i++) {
        hsrNote.hsr_note_sbjs[i].creat_user_id = hsrNote.hsr_note_sbjs[i]?.creat_user_id ? hsrNote.hsr_note_sbjs[i]?.creat_user_id : ecpAuthenticatedUser;
    }
    hsrNote.hsr_note_sbjs = hsrNote.hsr_note_sbjs?.length ? { 'data': hsrNote.hsr_note_sbjs } : {
        data: {
            note_sbj_rec_id: 'rec_id',
            note_sbj_typ_ref_id: 12,
            inac_ind: 0,
        },
    };
    const healthServiceVariables = { note: hsrNote };
    const notesResponse = await hscGraphqlClient.request(insertNote, healthServiceVariables);
    const hsr_note_id = notesResponse.insert_hsr_note_one.hsr_note_id;
    updateHscRequest.hsr_notes[i].hsr_note_id = hsr_note_id;
    updateHscRequest.hsr_notes[i].action = HscEntityActionType.CREATE;
}

async function updateHscNotes(updateHscRequest: UpdateHscRequest, ecpAuthenticatedUser, hscGraphqlClient: GraphQLClient) {
    for (let i = 0; i < updateHscRequest.hsr_notes.length; i++) {
        if(updateHscRequest.hsr_notes[i].hsr_note_id){
            const hscNotesUpdateObj :any = getHscNotesUpdateObj(updateHscRequest, i);

            const hscNotesVariables = {
                hsr_note_id: updateHscRequest.hsr_notes[i].hsr_note_id, hsrNoteInput: hscNotesUpdateObj
            };
            await hscGraphqlClient.request(updateNotes, hscNotesVariables);
            updateHscRequest.hsr_notes[i].action = HscEntityActionType.UPDATE;
        }else{
           await insertHsrNotes(updateHscRequest, i, ecpAuthenticatedUser, hscGraphqlClient);
        }
    }
}

function mapHscNonFaclSrvcs(updateHscRequest: UpdateHscRequest, hsc_srvc: any) {
    if (updateHscRequest.srvc_set_ref_id == ReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_REFID) {
        hsc_srvc.hsc_srvc_non_facls.forEach(function (nonFaclSrvc) {
            if (nonFaclSrvc.hsc_srvc_non_facl_dmes && nonFaclSrvc.hsc_srvc_non_facl_dmes.length > 0) {
                nonFaclSrvc.hsc_srvc_non_facl_dmes = {"data": nonFaclSrvc?.hsc_srvc_non_facl_dmes};
            }
        });
        hsc_srvc.hsc_srvc_non_facls = {"data": hsc_srvc.hsc_srvc_non_facls};
    }
}

async function insertServices(hsc_srvc: any, updateHscRequest: UpdateHscRequest, srvcHscProvId, srvc, ecpAuthenticatedUser, hscGraphqlClient) {
    hsc_srvc = {
        hsc_id: updateHscRequest.hsc_id,
        srvc_hsc_prov_id: srvcHscProvId,
        proc_cd: srvc.proc_cd,
        proc_cd_schm_ref_id: srvc.proc_cd_schm_ref_id,
        proc_othr_txt: srvc.proc_othr_txt,
        inac_ind: srvc.inac_ind,
        hsc_srvc_non_facls: srvc.hsc_srvc_non_facls,
        creat_user_id: updateHscRequest.creat_user_id ? updateHscRequest.creat_user_id : ecpAuthenticatedUser,
        chg_user_id: updateHscRequest.chg_user_id ? updateHscRequest.chg_user_id : ecpAuthenticatedUser,
        creat_dttm: currentDate,
        chg_dttm: currentDate,
        expmt_proc_ind: srvc.expmt_proc_ind,
        hsc_srvc_rev_typ_ref_id: srvc.hsc_srvc_rev_typ_ref_id,
        adv_ntfy_trans_id: srvc.adv_ntfy_trans_id,
        ben_chk_sts_ref_id: srvc.ben_chk_sts_ref_id,
        adv_ntfy_dttm: srvc.adv_ntfy_dttm,
        expt_proc_dt: srvc.expt_proc_dt
    };

    if(srvc.hsc_decn){
        srvc.hsc_decn.hsc_id = updateHscRequest.hsc_id;
        hsc_srvc.hsc_decns= [srvc.hsc_decn];
        hsc_srvc.hsc_decns.forEach((hscDecn) => {
            if (hscDecn.hsc_decn_bed_days) {
                hscDecn.hsc_id = updateHscRequest.hsc_id;
                hscDecn.hsc_decn_bed_days = {"data": hscDecn.hsc_decn_bed_days};
            }
        });
        hsc_srvc.hsc_decns = {"data": hsc_srvc.hsc_decns};
    }
    if(hsc_srvc.hsc_srvc_non_facls){
         mapHscNonFaclSrvcs(updateHscRequest, hsc_srvc);
    }

    const serviceVariables = {hscSrvc: hsc_srvc};
    const serviceData = await hscGraphqlClient.request(insertProcSingle, serviceVariables);

    const hsc_srvc_id = serviceData.insert_hsc_srvc_one.hsc_srvc_id;
    hsc_srvc.hsc_srvc_id = hsc_srvc_id;
    hsc_srvc.action = HscEntityActionType.CREATE;

}


async function updateHscSrvcNonFaclDmes(hscSrvcNonFaclDme, srvc, hscGraphqlClient: GraphQLClient) {
    const hsc_srvc_non_facl_dme = {
        clin_ill_desc_txt: hscSrvcNonFaclDme.clin_ill_desc_txt ? hscSrvcNonFaclDme.clin_ill_desc_txt : undefined,
        dme_procrmnt_typ_id: hscSrvcNonFaclDme.dme_procrmnt_typ_id ? hscSrvcNonFaclDme.dme_procrmnt_typ_id : undefined,
        dme_tot_cst_amt: hscSrvcNonFaclDme.dme_tot_cst_amt ? hscSrvcNonFaclDme.dme_tot_cst_amt : undefined,
        ental_fd_sngl_src_nutritn_ind: hscSrvcNonFaclDme.ental_fd_sngl_src_nutritn_ind ? hscSrvcNonFaclDme.ental_fd_sngl_src_nutritn_ind : undefined,
        fml_nm_txt: hscSrvcNonFaclDme.fml_nm_txt ? hscSrvcNonFaclDme.fml_nm_txt : undefined,
        med_cond_txt: hscSrvcNonFaclDme.med_cond_txt ? hscSrvcNonFaclDme.med_cond_txt : undefined,
        spl_desc_txt: hscSrvcNonFaclDme.spl_desc_txt ? hscSrvcNonFaclDme.spl_desc_txt : undefined,
        srvc_desc_txt: hscSrvcNonFaclDme.srvc_desc_txt ? hscSrvcNonFaclDme.srvc_desc_txt : undefined
    };

    const hscSrvcNonFaclDmeVariables = {
        hsc_srvc_id: srvc.hsc_srvc_id, hscSrvcNonFaclDmeInput: hsc_srvc_non_facl_dme
    };
    await hscGraphqlClient.request(updateHscSrvcNonFaclDme, hscSrvcNonFaclDmeVariables);
}

function getHscSrvcNonFacl(hscSrvcNonFacl) {
    return {
        srvc_strt_dt: hscSrvcNonFacl.srvc_strt_dt ? hscSrvcNonFacl.srvc_strt_dt : undefined,
        srvc_end_dt: hscSrvcNonFacl.srvc_end_dt ? hscSrvcNonFacl.srvc_end_dt : undefined,
        proc_mod_1_cd: hscSrvcNonFacl.proc_mod_1_cd ? hscSrvcNonFacl.proc_mod_1_cd : undefined,
        proc_mod_2_cd: hscSrvcNonFacl.proc_mod_2_cd ? hscSrvcNonFacl.proc_mod_2_cd : undefined,
        proc_mod_3_cd: hscSrvcNonFacl.proc_mod_3_cd ? hscSrvcNonFacl.proc_mod_3_cd : undefined,
        proc_mod_4_cd: hscSrvcNonFacl.proc_mod_4_cd ? hscSrvcNonFacl.proc_mod_4_cd : undefined,
        proc_uom_ref_id: hscSrvcNonFacl.proc_uom_ref_id ? hscSrvcNonFacl.proc_uom_ref_id : undefined,
        proc_unit_cnt: hscSrvcNonFacl.proc_unit_cnt ? hscSrvcNonFacl.proc_unit_cnt : undefined,
        unit_per_freq_cnt: hscSrvcNonFacl.unit_per_freq_cnt ? hscSrvcNonFacl.unit_per_freq_cnt : undefined,
        init_trt_dt: hscSrvcNonFacl.init_trt_dt ? hscSrvcNonFacl.init_trt_dt : undefined,
        plsrv_ref_id: hscSrvcNonFacl.plsrv_ref_id ? hscSrvcNonFacl.plsrv_ref_id : undefined,
        proc_freq_ref_id: hscSrvcNonFacl.proc_freq_ref_id ? hscSrvcNonFacl.proc_freq_ref_id : undefined,
        srvc_desc_ref_id: hscSrvcNonFacl.srvc_desc_ref_id ? hscSrvcNonFacl.srvc_desc_ref_id : undefined,
        srvc_dtl_ref_id: hscSrvcNonFacl.srvc_dtl_ref_id ? hscSrvcNonFacl.srvc_dtl_ref_id : undefined

    };
}

async function updateHscSrvcNonFacls(hscSrvcNonFacl, srvc, hscGraphqlClient: GraphQLClient) {
    const hsc_srvc_non_facl = getHscSrvcNonFacl(hscSrvcNonFacl);

    const hscSrvcNonFaclVariables = {
        hsc_srvc_id: srvc.hsc_srvc_id, hscSrvcNonFaclInput: hsc_srvc_non_facl
    };
    await hscGraphqlClient.request(updateHscSrvcNonFacl, hscSrvcNonFaclVariables);

    if (hscSrvcNonFacl.hsc_srvc_non_facl_dmes && hscSrvcNonFacl.hsc_srvc_non_facl_dmes.length > 0) {
        hscSrvcNonFacl.hsc_srvc_non_facl_dmes.forEach(async (hscSrvcNonFaclDme) => {
            await updateHscSrvcNonFaclDmes(hscSrvcNonFaclDme, srvc, hscGraphqlClient);
        });
    }
}

function getHscSrvc(srvcHscProvId, srvc, ecpAuthenticatedUser) {
    return {
        srvc_hsc_prov_id: srvcHscProvId,
        proc_othr_txt: srvc.proc_othr_txt ? srvc.proc_othr_txt : undefined,
        inac_ind: srvc.inac_ind ? srvc.inac_ind : undefined,
        chg_user_id: srvc.chg_user_id ? srvc.chg_user_id : ecpAuthenticatedUser,
        expmt_proc_ind: srvc.expmt_proc_ind ? srvc.expmt_proc_ind : undefined,
        hsc_srvc_rev_typ_ref_id: srvc.hsc_srvc_rev_typ_ref_id ? srvc.hsc_srvc_rev_typ_ref_id : undefined,
        adv_ntfy_trans_id: srvc.adv_ntfy_trans_id ? srvc.adv_ntfy_trans_id : undefined,
        ben_chk_sts_ref_id: srvc.ben_chk_sts_ref_id ? srvc.ben_chk_sts_ref_id : undefined,
        adv_ntfy_dttm: srvc.adv_ntfy_dttm ? srvc.adv_ntfy_dttm : undefined,
        expt_proc_dt: srvc.expt_proc_dt ? srvc.expt_proc_dt : undefined
    };
}

async function updateHscSrvcForOP(srvc, hscGraphqlClient: GraphQLClient, hscServicesId) {
    if (srvc.hsc_srvc_non_facls && srvc.hsc_srvc_non_facls.length > 0) {
        srvc.hsc_srvc_non_facls.forEach(async (hscSrvcNonFacl) => {
            if (hscSrvcNonFacl.hsc_srvc_id) {
                await updateHscSrvcNonFacls(hscSrvcNonFacl, srvc, hscGraphqlClient);
            } else {
                const nonFacl = {
                    ...hscSrvcNonFacl,
                    hsc_srvc_id: hscServicesId
                };
                if (nonFacl.hsc_srvc_non_facl_dmes && nonFacl.hsc_srvc_non_facl_dmes.length > 0) {
                    nonFacl.hsc_srvc_non_facl_dmes = {"data": nonFacl.hsc_srvc_non_facl_dmes};
                }
                const hscSrvcNonFaclsVariables = {hsc_srvc_non_facl: nonFacl};
                await hscGraphqlClient.request(insertHscServiceNonFacility, hscSrvcNonFaclsVariables);
            }

        });
    }
}

async function mapHscSrvcs(srvc, providerService: ProviderService, updateHscRequest: UpdateHscRequest, httpRequest: HttpRequest, hscGraphqlClient: GraphQLClient, ecpAuthenticatedUser, hscServicesInput, hscServicesId) {
    const srvcHscProvId = srvc.srvc_hsc_prov_id != null ? srvc.srvc_hsc_prov_id : await providerService.getProviderId(srvc.hsc_prov, updateHscRequest.hsc_id, httpRequest);
    let hsc_srvc: any = {};
    if(hscServicesId){
        hsc_srvc = getHscSrvc(srvcHscProvId, srvc, ecpAuthenticatedUser);

        const hscProcVariables = {
            hsc_srvc_id: hscServicesId, hscSrvcInput: hsc_srvc
        };
        await hscGraphqlClient.request(updateProc, hscProcVariables);

        if(srvc.hsc_decn) {
            const decn = {
                ...srvc.hsc_decn,
                hsc_srvc_id: hscServicesId,
                hsc_id: updateHscRequest.hsc_id,
                creat_user_id: updateHscRequest.creat_user_id ? updateHscRequest.creat_user_id : ecpAuthenticatedUser,
                chg_user_id: updateHscRequest.chg_user_id ? updateHscRequest.chg_user_id : ecpAuthenticatedUser,
            };
            if (decn.hsc_decn_bed_days && decn.hsc_decn_bed_days.length > 0) {
                decn.hsc_decn_bed_days = {"data": decn.hsc_decn_bed_days};
            }
            const decisionsVariables = {hsc_decn: decn};
            await hscGraphqlClient.request(insertDecision, decisionsVariables);
        }
        await updateHscSrvcForOP(srvc, hscGraphqlClient, hscServicesId);
        hsc_srvc.action = HscEntityActionType.UPDATE;
    } else{

        insertServices(hsc_srvc, updateHscRequest, srvcHscProvId, srvc, ecpAuthenticatedUser, hscGraphqlClient);
    }

}

function getHscFacl(updateHscRequest: UpdateHscRequest) {
    return {
        plsrv_ref_id: updateHscRequest.hsc_facl?.plsrv_ref_id ? updateHscRequest.hsc_facl?.plsrv_ref_id : undefined,
        srvc_desc_ref_id: updateHscRequest.hsc_facl?.srvc_desc_ref_id ? updateHscRequest.hsc_facl?.srvc_desc_ref_id : undefined,
        srvc_dtl_ref_id: updateHscRequest.hsc_facl?.srvc_dtl_ref_id ? updateHscRequest.hsc_facl?.srvc_dtl_ref_id : undefined,
        actul_admis_dttm: updateHscRequest.hsc_facl?.actul_admis_dttm ? updateHscRequest.hsc_facl?.actul_admis_dttm : undefined,
        actul_dschrg_dttm: updateHscRequest.hsc_facl?.actul_dschrg_dttm ? updateHscRequest.hsc_facl?.actul_dschrg_dttm : undefined,
        expt_admis_dt: updateHscRequest.hsc_facl?.expt_admis_dt ? updateHscRequest.hsc_facl?.expt_admis_dt : undefined,
        expt_dschrg_dt: updateHscRequest.hsc_facl?.expt_dschrg_dt ? updateHscRequest.hsc_facl?.expt_dschrg_dt : undefined,
        ipcm_typ_ref_id: updateHscRequest.hsc_facl?.ipcm_typ_ref_id ? updateHscRequest.hsc_facl?.ipcm_typ_ref_id : undefined,
        dschrg_ntfy_trans_id: updateHscRequest.hsc_facl?.dschrg_ntfy_trans_id ? updateHscRequest.hsc_facl?.dschrg_ntfy_trans_id : undefined,
        dschrg_ntfy_dttm: updateHscRequest.hsc_facl?.dschrg_ntfy_dttm ? updateHscRequest.hsc_facl?.dschrg_ntfy_dttm : undefined,
        goal_los_day_cnt: updateHscRequest.hsc_facl?.goal_los_day_cnt ? updateHscRequest.hsc_facl?.goal_los_day_cnt : undefined,
        dschrg_disp_ref_id: updateHscRequest.hsc_facl?.dschrg_disp_ref_id ? updateHscRequest.hsc_facl?.dschrg_disp_ref_id : undefined,
        admis_ntfy_dttm: updateHscRequest.hsc_facl?.admis_ntfy_dttm ? updateHscRequest.hsc_facl?.admis_ntfy_dttm : undefined

    };
}

async function updateFacility(updateHscRequest: UpdateHscRequest, hscGraphqlClient: GraphQLClient, ecpAuthenticatedUser) {
    if (updateHscRequest.srvc_set_ref_id == ReferenceConstants.SERVICESETTINGTYPE_INPATIENT_REFID || updateHscRequest.srvc_set_ref_id == ReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY_REFID) {
        const getHscFacilityVariable = {
            "hscId": updateHscRequest.hsc_id
        };
        const hscFacData = await hscGraphqlClient.request(getHscFacility, getHscFacilityVariable);
        if(hscFacData && hscFacData.hsc_facl.length > 0){
            const hsc_facl = getHscFacl(updateHscRequest);

            const hscFaclVariables = {
                hsc_id: updateHscRequest.hsc_id, hscFaclInput: hsc_facl
            };
            await hscGraphqlClient.request(updateHscFacl, hscFaclVariables);
        }else{
            const facilityVariables = {
                hsc_facl: {
                    hsc_id: updateHscRequest.hsc_id,
                    plsrv_ref_id: updateHscRequest.hsc_facl.plsrv_ref_id,
                    srvc_desc_ref_id: updateHscRequest.hsc_facl.srvc_desc_ref_id,
                    srvc_dtl_ref_id: updateHscRequest.hsc_facl.srvc_dtl_ref_id,
                    actul_admis_dttm: updateHscRequest.hsc_facl.actul_admis_dttm,
                    actul_dschrg_dttm: updateHscRequest.hsc_facl.actul_dschrg_dttm,
                    expt_admis_dt: updateHscRequest.hsc_facl.expt_admis_dt,
                    expt_dschrg_dt: updateHscRequest.hsc_facl.expt_dschrg_dt,
                    ipcm_typ_ref_id: updateHscRequest.hsc_facl.ipcm_typ_ref_id,
                    dschrg_ntfy_trans_id: updateHscRequest.hsc_facl.dschrg_ntfy_trans_id,
                    dschrg_ntfy_dttm: updateHscRequest.hsc_facl.dschrg_ntfy_dttm,
                    goal_los_day_cnt: updateHscRequest.hsc_facl.goal_los_day_cnt,
                    dschrg_disp_ref_id: updateHscRequest.hsc_facl.dschrg_disp_ref_id,
                    admis_ntfy_dttm: updateHscRequest.hsc_facl.admis_ntfy_dttm
                }
            };
            await hscGraphqlClient.request(insertHscFaclMutation, facilityVariables);

        }
        if(updateHscRequest.hsc_facl.hsc_decn){
            const decn = {
                ...updateHscRequest.hsc_facl.hsc_decn,
                hsc_id: updateHscRequest.hsc_id,
                creat_user_id: updateHscRequest.hsc_facl.hsc_decn.creat_user_id ? updateHscRequest.hsc_facl.hsc_decn.creat_user_id : ecpAuthenticatedUser,
                chg_user_id: updateHscRequest.hsc_facl.hsc_decn.chg_user_id ? updateHscRequest.hsc_facl.hsc_decn.chg_user_id : ecpAuthenticatedUser,
            };
            const decisionsVariables = {hsc_decn: decn};
            const hscDecnData =await hscGraphqlClient.request(insertDecision, decisionsVariables);
            const hsc_decn_id = hscDecnData.insert_hsc_decn_one.hsc_decn_id;
            updateHscRequest.hsc_facl.hsc_decn.hsc_decn_id = hsc_decn_id;
        }

    }

}

async function updateHscServices(updateHscRequest: UpdateHscRequest, hscGraphqlClient: GraphQLClient, ecpAuthenticatedUser, providerService: ProviderService, httpRequest: HttpRequest) {
    const hscServicesInput = [];
        const hscDiagAndProcData = await getHscDiagAndProcData(updateHscRequest, hscGraphqlClient);
        const hscServicesData = hscDiagAndProcData.hsc[0].hsc_srvcs;
        await Promise.all(updateHscRequest.hsc_srvcs.map(async function (srvc) {
            const hscServices =  hscServicesData.find(element => element.hsc_srvc_id === srvc.hsc_srvc_id);
            const hscServiceId = srvc.hsc_srvc_id;

            await mapHscSrvcs(srvc, providerService, updateHscRequest, httpRequest, hscGraphqlClient,  ecpAuthenticatedUser, hscServicesInput, hscServiceId);

        }));
         const serviceVariables = {hscSrvcs: hscServicesInput};
         await hscGraphqlClient.request(insertProc, serviceVariables);
}

async function getHscDiagAndProcData(updateHscRequest: UpdateHscRequest, hscGraphqlClient: GraphQLClient) {
    const getHscDiagAndProcVariable = {
        "hscId": updateHscRequest.hsc_id
    };
    const hscDiagAndProcData = await hscGraphqlClient.request(getHscDiagnosisAndProcedure, getHscDiagAndProcVariable);
    return hscDiagAndProcData;
}

function getHscDiagnosisUpdateObj(chguser_id, updateHscRequest: UpdateHscRequest, j: number) {
    return {
        chg_user_id: chguser_id,
        chg_dttm: currentDate,
        pri_ind: updateHscRequest.hsc_diags[j].pri_ind ? updateHscRequest.hsc_diags[j].pri_ind : undefined,
        inac_ind: updateHscRequest.hsc_diags[j].inac_ind ? updateHscRequest.hsc_diags[j].inac_ind : undefined,
        diag_othr_txt: updateHscRequest.hsc_diags[j].diag_othr_txt ? updateHscRequest.hsc_diags[j].diag_othr_txt : undefined,
        admit_ind: updateHscRequest.hsc_diags[j].admit_ind ? updateHscRequest.hsc_diags[j].admit_ind : undefined
    };
}

async function updateHscDiagnosis(updateHscRequest: UpdateHscRequest, ecpAuthenticatedUser, hscGraphqlClient: GraphQLClient) {

    for (let j = 0; j < updateHscRequest.hsc_diags.length; j++) {
        const createuser_id= updateHscRequest.hsc_diags[j].creat_user_id? updateHscRequest.hsc_diags[j].creat_user_id: ecpAuthenticatedUser;
        const chguser_id= updateHscRequest.hsc_diags[j].chg_user_id? updateHscRequest.hsc_diags[j].chg_user_id : ecpAuthenticatedUser;

        if(updateHscRequest.hsc_diags[j].hsc_diag_id) {

            const hscDiagnosisUpdateObj :any = getHscDiagnosisUpdateObj(chguser_id, updateHscRequest, j);

            const hscDiagVariables = {
                hsc_diag_id: updateHscRequest.hsc_diags[j].hsc_diag_id, hscDiagInput: hscDiagnosisUpdateObj
            };
            await hscGraphqlClient.request(updateDiagnosis, hscDiagVariables);
            updateHscRequest.hsc_diags[j].action = HscEntityActionType.UPDATE;
        }
        else {

            const hscDiagnosisInputObj :any = {
                hsc_id: updateHscRequest.hsc_id,
                diag_cd: updateHscRequest.hsc_diags[j].diag_cd,
                creat_user_id: createuser_id,
                chg_user_id: chguser_id,
                creat_dttm: currentDate,
                chg_dttm: currentDate,
                pri_ind: updateHscRequest.hsc_diags[j].pri_ind,
                inac_ind: updateHscRequest.hsc_diags[j].inac_ind,
                diag_othr_txt:updateHscRequest.hsc_diags[j].diag_othr_txt,
                diag_cd_schm_ref_id: updateHscRequest.hsc_diags[j].diag_cd_schm_ref_id,
                admit_ind: updateHscRequest.hsc_diags[j].admit_ind
            };

            const diagnosisVariables = {diag: hscDiagnosisInputObj};
            const diagData = await hscGraphqlClient.request(insertDiagnosis, diagnosisVariables);
            const hsc_diag_id = diagData.insert_hsc_diag_one.hsc_diag_id;
            updateHscRequest.hsc_diags[j].hsc_diag_id = hsc_diag_id;
            updateHscRequest.hsc_diags[j].action = HscEntityActionType.CREATE;

        }
    }
}

async function updateHscProviderRoles(prov, hscGraphqlClient: GraphQLClient) {
//deleting existing provider roles
    const deleteHscProvRoleVariable = {
        "hsc_prov_id": prov.hsc_prov_id
    };
    await hscGraphqlClient.request(deleteHscProvRoles, deleteHscProvRoleVariable);
    // inserting all provider roles
    prov.hsc_prov_roles.forEach(async function (provRole) {
        const hscProviderRoleVariables = {
            "prov_role": {
                hsc_prov_id: prov.hsc_prov_id,
                prov_role_ref_id: provRole.prov_role_ref_id
            }
        };
        await hscGraphqlClient.request(insertProviderRole, hscProviderRoleVariables);
    });
}

async function updateOrDeleteDraftProv(prov, hscGraphqlClient: GraphQLClient) {
    if (prov.delete_ind || (!prov.hsc_prov_roles)) {
        const deleteHscProvRoleVariable = {
            "hsc_prov_id": prov.hsc_prov_id
        };
        await hscGraphqlClient.request(deleteHscProvRoles, deleteHscProvRoleVariable);

        const deleteHscProvVariable = {
            "hsc_prov_id": prov.hsc_prov_id
        };
        await hscGraphqlClient.request(deleteHscProv, deleteHscProvVariable);
    } else {
        await updateHscProviderRoles(prov, hscGraphqlClient);
    }
}

async function updateOrDeleteOpenProv(prov, hscGraphqlClient: GraphQLClient) {
    if (prov.end_dt) {
        const hscProvVariables = {
            hsc_prov_id: prov.hsc_prov_id, hscProvInput: {end_dt: prov.end_dt}
        };
        await hscGraphqlClient.request(updateProvider, hscProvVariables);

    } else {
        await updateHscProviderRoles(prov, hscGraphqlClient);
    }
}

async function updateExistingProvider(updateHscRequest: UpdateHscRequest, prov, hscGraphqlClient: GraphQLClient, currentHsc: any) {
    if (currentHsc.hsc_sts_ref_id == ReferenceConstants.HSCSTATUSTYPE_DRAFT_REFID) {
        await updateOrDeleteDraftProv(prov, hscGraphqlClient);
    }
    else {
        await updateOrDeleteOpenProv(prov, hscGraphqlClient);
    }
}

export async function updateHscProvider(updateHscRequest: UpdateHscRequest, hscGraphqlClient: GraphQLClient, ecpAuthenticatedUser, providerService: ProviderService, httpRequest: HttpRequest, currentHsc: any) {
    let provResponse: any;

    updateHscRequest.hsc_provs.forEach(async (prov) => {

        const creat_user_id = ecpAuthenticatedUser;
        const chg_user_id = ecpAuthenticatedUser;

        provResponse = await providerService.getProvData(prov.prov_keys[0]?.prov_key_val, prov.prov_keys[0]?.prov_key_typ_ref_id, prov.prov_adr.adr_ln_1_txt,
            prov.prov_adr.adr_ln_2_txt, prov.prov_adr.zip_cd_txt, prov.prov_adr.cty_nm , prov.prov_adr.st_ref_id, prov.fst_nm, prov.lst_nm,
            prov.bus_nm, httpRequest);

        const provMpinValue = prov.prov_keys.find((provKey) => provKey.prov_key_typ_ref_id === ReferenceConstants.PROVIDER_KEY_VALUE_TYP_REF_ID_MPIN)?.prov_key_val;
        const addressSeqNumber = await providerService.getAddressSequenceNumber(prov, provMpinValue, httpRequest);

        if(prov.hsc_prov_id){
            await updateExistingProvider(updateHscRequest, prov, hscGraphqlClient, currentHsc);
            prov.action = HscEntityActionType.UPDATE;

        }else{

            const hscProviderInput: any = {
                hsc_id: updateHscRequest.hsc_id,
                creat_user_id,
                chg_user_id,
                creat_dttm: currentDate,
                chg_dttm: currentDate,
                prov_loc_affil_id: provResponse?.v_prov_srch[0]?.prov_loc_affil_id,
                prov_key_val: prov.prov_keys[0]?.prov_key_val,
                prov_key_typ_ref_id: prov.prov_keys[0]?.prov_key_typ_ref_id,
                spcl_ref_id: provResponse?.v_prov_srch[0]?.spcl_ref_id,
                telcom_adr_id: provResponse?.v_prov_srch[0]?.telcom_adr_id,
                strt_dt: prov.strt_dt? prov.strt_dt : null,
                end_dt: prov.end_dt? prov.end_dt: null,
                prov_loc_affil_dtl: {
                    "providerDetails": {
                        fst_nm: prov.fst_nm,
                        lst_nm: prov.lst_nm,
                        bus_nm: prov.bus_nm,
                        prov_keys: prov.prov_keys, prov_id: provResponse?.v_prov_srch[0]?.prov_id,
                        prov_adr_id: provResponse?.v_prov_srch[0]?.prov_adr_id,
                        add_seq_num: addressSeqNumber,
                        prov_catgy_ref_id: provResponse?.v_prov_srch[0]?.prov_catgy_ref_id,
                        prov_catgy_ref_cd: provResponse?.v_prov_srch[0]?.prov_catgy_ref_cd,
                        prov_adr: { "adr_ln_1_txt": prov.prov_adr.adr_ln_1_txt,
                            "adr_ln_2_txt": prov.prov_adr.adr_ln_2_txt,
                            "zip_cd_txt": prov.prov_adr.zip_cd_txt,
                            "cty_nm": prov.prov_adr.cty_nm,
                            "st_ref_id": prov.prov_adr.st_ref_id}
                    }
                }
            };

            const hscProviderVariables = {prov: hscProviderInput};

            const provData = await hscGraphqlClient.request(insertProvider, hscProviderVariables);
            console.log("provData", provData);
            const hsc_prov_id = provData.insert_hsc_prov_one.hsc_prov_id;
            prov.hsc_prov_id = hsc_prov_id;

            prov.hsc_prov_roles.forEach(async function (provRole) {
                const hscProviderRoleVariables = {
                    "prov_role": {
                        hsc_prov_id: hsc_prov_id,
                        prov_role_ref_id: provRole.prov_role_ref_id
                    }
                };
                await hscGraphqlClient.request(insertProviderRole, hscProviderRoleVariables);
            });
            prov.action = HscEntityActionType.CREATE;
        }
    });
}

function getHscClinGuidObject(updateHscRequest: UpdateHscRequest) {
    return {
        clin_rev_desc: updateHscRequest.hsc_clin_guid?.clin_rev_desc ? updateHscRequest.hsc_clin_guid?.clin_rev_desc : undefined,
        clin_rev_otcome_ref_id: updateHscRequest.hsc_clin_guid?.clin_rev_otcome_ref_id ? updateHscRequest.hsc_clin_guid?.clin_rev_otcome_ref_id : undefined
    };
}

async function updateHscClinGuid(updateHscRequest: UpdateHscRequest, hscGraphqlClient: GraphQLClient, ecpAuthenticatedUser) {
    const getHscClinGuidVariable = {
        "hscId": updateHscRequest.hsc_id,
        "hsc_clin_guid_id": updateHscRequest.hsc_clin_guid.hsc_clin_guid_id != null ? updateHscRequest.hsc_clin_guid.hsc_clin_guid_id : 0
    };
    const hscClinGuidData = await hscGraphqlClient.request(getHscClinGuid, getHscClinGuidVariable);

    if (hscClinGuidData && hscClinGuidData.hsc_clin_guid.length > 0) {
        const hsc_clin_guid = getHscClinGuidObject(updateHscRequest);
        const hscClinGuidVariables = {
            hsc_clin_guid_id: hscClinGuidData.hsc_clin_guid.hsc_clin_guid_id, hscClinGuidInput: hsc_clin_guid
        };
        await hscGraphqlClient.request(updateHscClinGuidMutation, hscClinGuidVariables);
    } else {
        const createHscClinGuidVariables = {
            hsc_clin_guid: {
                hsc_id: updateHscRequest.hsc_id,
                clin_rev_desc: updateHscRequest.hsc_clin_guid.clin_rev_desc != null ? updateHscRequest.hsc_clin_guid.clin_rev_desc : null,
                clin_rev_otcome_ref_id: updateHscRequest.hsc_clin_guid.clin_rev_otcome_ref_id != null ? updateHscRequest.hsc_clin_guid.clin_rev_otcome_ref_id : null,
                clin_rev_sts_ref_id: updateHscRequest.hsc_clin_guid.clin_rev_sts_ref_id,
            }
        };
        await hscGraphqlClient.request(insertHscClinGuidMutation, createHscClinGuidVariables);
    }
}

function isDischargeNotification(updateHSCActualDischargeDate, currentHscActualDischargeDate) {
    if (currentHscActualDischargeDate != updateHSCActualDischargeDate) {
        return true;
    }
    return false;
 }
