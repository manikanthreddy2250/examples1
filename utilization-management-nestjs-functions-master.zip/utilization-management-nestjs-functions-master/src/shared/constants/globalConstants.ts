export const GlobalConstants = {
  UM_INTAKE_APP_NAME: 'um_intake_ui',
  ORIG_SYS_CODE: 'CDB_CS',
  GRANT_TYPE_CLIENT: 'CLIENT_CREDENTIALS',
  UM_CASE_CREATE_EVENT_NAME: 'ocm.um.healthservice.hsc.create',
  UM_CASE_UPDATE_EVENT_NAME: 'ocm.um.healthservice.hsc.update',
  UM_CASE_FACILITY_DISCHARGE_UPDATE_EVENT_NAME: 'ocm.um.healthservice.hsc.facility.discharge.update',
  HSC_ENTITY_ACTION_CREATE: 'Created',
  HSC_ENTITY_ACTION_UPDATE: 'Updated',
};



