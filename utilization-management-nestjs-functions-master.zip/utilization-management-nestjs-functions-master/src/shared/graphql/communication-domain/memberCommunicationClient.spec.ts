import {GraphQLClient} from "graphql-request/dist";
import {ConfigService} from "@nestjs/config";
import {MemberCommunicationClient} from "./memberCommunicationClient";
import {HttpRequest} from "@azure/functions";

class MockConfigService extends ConfigService {
    get(propertyPath: any){
        return 'testvalue';
    };
}

describe('MemberCommunicationClient', () => {
    let memberCommunicationClient: MemberCommunicationClient;

    beforeEach(async () => {
        memberCommunicationClient = new MemberCommunicationClient(new MockConfigService());
    });

    it('should be defined', () => {
        expect(memberCommunicationClient).toBeDefined();
    });

    it('should return a Member Communication GraphQLClient', () => {
        let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid', headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
        const client = memberCommunicationClient.getGraphqlClient(httpRequest);
        expect(client).toBeInstanceOf(GraphQLClient);
    });
});
