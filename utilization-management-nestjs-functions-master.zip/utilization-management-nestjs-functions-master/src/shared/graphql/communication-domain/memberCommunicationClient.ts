import { GraphQLClient } from 'graphql-request/dist';
import { ConfigService } from '@nestjs/config';
import { Injectable } from '@nestjs/common';
import { HttpRequest } from '@azure/functions';

@Injectable()
export class MemberCommunicationClient {
  private memberCommunicationClient;

  constructor(private readonly configService: ConfigService) {
    this.memberCommunicationClient = new GraphQLClient(
      configService.get<string>('MEMBER_COMMUNICATION_API_ENDPOINT'),
    );
  }

  public getGraphqlClient(req: HttpRequest): GraphQLClient {
    const headers = {
      'content-type': req.headers['content-type'],
      Authorization: req.headers['authorization'],
      'x-hasura-role': req.headers['x-hasura-role'],
    };
    this.memberCommunicationClient.setHeaders(headers);
    return this.memberCommunicationClient;
  }
}
