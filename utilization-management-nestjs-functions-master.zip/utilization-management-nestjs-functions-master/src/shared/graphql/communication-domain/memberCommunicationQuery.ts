import {ReferenceConstants} from "../../constants/referenceConstants";


const returnMbrCmnctData = `
    mbr_cmnct_id
    creat_user_id
    creat_dttm
    chg_user_id
    chg_dttm
    commt_txt
    cmnct_adr_dtl
    dsclmr_cnsnt_desc
    mbr_cmnct_catgy_ref_id
    mbr_cmnct_chnl_ref_id
    mbr_cmnct_dir_ref_id
    mbr_cmnct_prr_ref_id
    mbr_cmnct_rsn_ref_id
    mbr_cmnct_sts_ref_id
    mbr_cmnct_sts_rsn_ref_id
    mbr_cmnct_typ_ref_id
    sts_dttm
    mbr_cmnct_prtcps {
      mbr_cmnct_id
      mbr_cmnct_prtcp_id
      fst_nm
      lst_nm
      mbr_cmnct_prtcp_engage_lvl_ref_id
      mbr_cmnct_prtcp_role_ref_id
      prtcp_desc
      prtcp_key_typ_ref_id
      prtcp_key_val
    }`;


export const insertCommunicationMutation = `
mutation insertCommunication($mbr_cmnct:mbr_cmnct_insert_input!) {
  insert_mbr_cmnct_one(object: $mbr_cmnct) {` +
    returnMbrCmnctData +
    `  }
}
`;

export const insertCommunicationSubjMutation = `
  mutation insertCommunicationSubj($mbr_cmnct_sbj:mbr_cmnct_sbj_insert_input!) {
       insert_mbr_cmnct_sbj_one(object: $mbr_cmnct_sbj) {
        mbr_cmnct_id
        }
      }
    `;

export const getMbrCmnctQuery = 'query MyQuery($mbrCmnctId: bigint!) {\n' +
    '  mbr_cmnct(where: {mbr_cmnct_id: {_eq: $mbrCmnctId}}) {\n' +
    returnMbrCmnctData +
    '  }\n' +
    '}\n';
