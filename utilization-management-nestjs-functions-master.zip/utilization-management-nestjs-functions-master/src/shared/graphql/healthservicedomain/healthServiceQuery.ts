import {ReferenceConstants} from "../../constants/referenceConstants";

const hscReturnColumns = '    hsc_id\n' +
  '    creat_user_id\n' +
  '    indv_key_val\n' +
  '    indv_id\n' +
  '    creat_dttm\n' +
  '    mbr_cov_dtl\n' +
  '    hsc_sts_ref_id\n' +
  '    hsc_provs {\n' +
  '       prov_loc_affil_dtl\n' +
  '       }\n ' +
  '    srvc_set_ref_cd {\n' +
  '       ref_desc\n' +
  '       }\n ' +
  '      hsc_sts_ref_cd{\n' +
  '      ref_desc\n'+
  '       } \n '
  '    hsc_keys {\n' +
  '       hsc_key_val\n' +
  '       } \n ';

const returnHscData = `
                          hsc_id
                           creat_dttm
                           chg_user_id
                           creat_user_id
                           creat_sys_ref_id
                           indv_id
                           individual(limit:5){
                            fst_nm
                            indv_id
                            lst_nm
                            bth_dt
                            gdr_ref_cd{
                              ref_id
                              ref_cd
                              ref_desc
                              ref_dspl
                             }
                         }
                           indv_key_typ_ref_id
                           indv_key_typ_ref_cd{
                            ref_id
                            ref_cd
                            ref_desc
                            ref_dspl
                           }
                           indv_key_val
                           mbr_cov_dtl
                           hsc_sts_ref_id
                           hsc_sts_ref_cd{
                            ref_id
                            ref_cd
                            ref_desc
                            ref_dspl
                           }
                           hsc_rev_typ_ref_id
                           hsc_rev_typ_ref_cd{
                            ref_id
                            ref_cd
                            ref_desc
                            ref_dspl
                           }
                          flwup_cntc_dtl
                          rev_prr_ref_id
                          rev_prr_ref_cd {
                              ref_id
                              ref_cd
                              ref_desc
                              ref_dspl
                            }
                          srvc_set_ref_id
                          srvc_set_ref_cd {
                              ref_id
                              ref_cd
                              ref_desc
                              ref_dspl
                          }
                          hsc_sts_rsn_ref_id
                          hsc_sts_rsn_ref_cd{
                            ref_id
                            ref_cd
                            ref_desc
                            ref_dspl
                            }
                          auth_typ_ref_id
                          auth_typ_ref_cd{
                            ref_id
                            ref_cd
                            ref_desc
                            ref_dspl
                            }
                        hsc_keys {
                            hsc_id
                            hsc_key_val
                            inac_ind
                            hsc_key_typ_ref_id
                            hsc_key_typ_ref_cd{
                              ref_id
                              ref_cd
                              ref_desc
                              ref_dspl
                              }
                            creat_user_id
                            chg_user_id
                         }
                        hsc_srvcs {
                          hsc_id
                          creat_dttm
                          chg_dttm
                          hsc_srvc_id
                          inac_ind
                          proc_cd
                          proc_cd_schm_ref_id
                          proc_cd_schm_ref_cd{
                            ref_id
                            ref_cd
                            ref_desc
                            ref_dspl
                          }
                          proc_othr_txt
                          srvc_hsc_prov_id
                          chg_user_id
                          expmt_proc_ind
                          hsc_srvc_rev_typ_ref_id
                          hsc_srvc_rev_typ_ref_cd{
                              ref_id
                              ref_cd
                              ref_desc
                              ref_dspl
                            }
                          adv_ntfy_trans_id
                          ben_chk_sts_ref_id
                          ben_chk_sts_ref_cd{
                              ref_id
                              ref_cd
                              ref_desc
                              ref_dspl
                            }
                          adv_ntfy_dttm
                          expt_proc_dt
                          hsc_srvc_non_facls {
                            init_trt_dt
                            plsrv_ref_id
                            plsrv_ref_cd {
                              ref_id
                              ref_cd
                              ref_desc
                              ref_dspl
                            }
                            proc_freq_ref_id
                            proc_freq_ref_cd {
                              ref_id
                              ref_cd
                              ref_desc
                              ref_dspl
                            }
                            proc_mod_1_cd
                            proc_mod_2_cd
                            proc_mod_3_cd
                            proc_mod_4_cd
                            proc_unit_cnt
                            proc_uom_ref_id
                            proc_uom_ref_cd {
                              ref_id
                              ref_cd
                              ref_desc
                              ref_dspl
                            }
                            srvc_desc_ref_id
                            srvc_desc_ref_cd{
                              ref_id
                              ref_cd
                              ref_desc
                              ref_dspl
                            }
                            srvc_dtl_ref_id
                            srvc_dtl_ref_cd{
                              ref_id
                              ref_cd
                              ref_desc
                              ref_dspl
                            }
                            srvc_end_dt
                            srvc_strt_dt
                            unit_per_freq_cnt
                            hsc_srvc_non_facl_dmes {
                              clin_ill_desc_txt
                              dme_procrmnt_typ_id
                              dme_tot_cst_amt
                              ental_fd_sngl_src_nutritn_ind
                              fml_nm_txt
                              med_cond_txt
                              spl_desc_txt
                              srvc_desc_txt
                            }
                          }
                        }
                        hsc_facls {
                          data_qlty_iss_list
                          data_secur_rule_list
                          adv_ntfy_trans_id
                          admis_ntfy_trans_id
                          dschrg_ntfy_trans_id
                          adv_ntfy_dttm
                          admis_ntfy_dttm
                          dschrg_ntfy_dttm
                          plsrv_ref_id
                          plsrv_ref_cd{
                              ref_id
                              ref_cd
                              ref_desc
                              ref_dspl
                            }
                          srvc_dtl_ref_id
                          srvc_dtl_ref_cd{
                              ref_id
                              ref_cd
                              ref_desc
                              ref_dspl
                            }
                          srvc_desc_ref_id
                          srvc_desc_ref_cd{
                              ref_id
                              ref_cd
                              ref_desc
                              ref_dspl
                            }
                          expt_admis_dt
                          expt_dschrg_dt
                          actul_admis_dttm
                          actul_dschrg_dttm
                          goal_los_day_cnt
                          dschrg_disp_ref_id
                          dschrg_disp_ref_cd{
                              ref_id
                              ref_cd
                              ref_desc
                              ref_dspl
                            }
                          rem_snf_day_cnt
                          snf_day_xhst_ind
                          ipcm_typ_ref_id
                          ipcm_typ_ref_cd{
                              ref_id
                              ref_cd
                              ref_desc
                              ref_dspl
                            }
                          ctp_nom_sts_ref_id
                          ctp_nom_sts_ref_cd{
                              ref_id
                              ref_cd
                              ref_desc
                              ref_dspl
                            }
                          tat_due_dttm
                          tat_rqr_crit_list
                          
                        }
                     hsc_diags{
                          hsc_diag_id
                          diag_cd
                          inac_ind
                          pri_ind
                          creat_dttm
                          chg_dttm
                          diag_othr_txt
                          diag_cd_schm_ref_id
                          diag_cd_schm_ref_cd{
                              ref_id
                              ref_cd
                              ref_desc
                              ref_dspl
                            }
                          admit_ind
                          creat_user_id
                          chg_user_id
                     }
                     hsr_notes{
                          hsr_note_id
                          note_titl_txt
                          note_txt_lobj
                          creat_user_id
                          note_typ_ref_id
                          note_typ_ref_cd{
                              ref_id
                              ref_cd
                              ref_desc
                              ref_dspl
                            }
                          src_user_nm
                          creat_dttm
                          note_catgy_ref_id
                          note_catgy_ref_cd{
                            ref_id
                            ref_cd
                            ref_desc
                            ref_dspl
                          }
                    }
               	    hsc_provs {
                          auto_aprv_ltr_ind
                          chg_sys_ref_id
                          chg_user_id
                          creat_sys_ref_id
                          creat_user_id
                          data_qlty_iss_list
                          data_secur_rule_list
                          end_dt
                          hsc_prov_end_rsn_ref_id
                          hsc_prov_end_rsn_ref_cd{
                            ref_id
                            ref_cd
                            ref_desc
                            ref_dspl
                          }
                          ltr_opt_out_cc_ind
                          med_rec_nbr
                          ntwk_strg_rsn_ref_id
                          ntwk_strg_rsn_ref_cd{
                            ref_id
                            ref_cd
                            ref_desc
                            ref_dspl
                          }
                          ntwk_sts_ref_id
                          ntwk_sts_ref_cd{
                            ref_id
                            ref_cd
                            ref_desc
                            ref_dspl
                          }
                          prov_loc_affil_dtl
                          prov_loc_affil_id
                          spcl_ref_id
                          strt_dt
                          telcom_adr_id
                          updt_ver_nbr
                          hsc_prov_id
                          hsc_prov_roles {
                             hsc_prov_id
                             prov_role_ref_id
                             prov_role_ref_cd{
                              ref_id
                              ref_cd
                              ref_desc
                              ref_dspl
                            }
                          }
                          prov_key_typ_ref_id
                          prov_key_typ_ref_cd{
                            ref_id
                            ref_cd
                            ref_desc
                            ref_dspl
                          }
                          prov_key_val
                          spcl_ref_cd {
                            ref_id
                            ref_cd
                            ref_desc
                            ref_dspl
                          }
               		}
               	    hsc_decns{
                          hsc_decn_id
                          hsc_srvc_id
                          chg_dttm
                          inac_ind
                          mbr_cov_dtl
                          decn_typ_ref_id
                          decn_typ_ref_cd{
                            ref_id
                            ref_cd
                            ref_desc
                            ref_dspl
                          }
                          decn_otcome_ref_id
                          decn_otcome_ref_cd{
                            ref_id
                            ref_cd
                            ref_desc
                            ref_dspl
                          }
                          decn_rsn_ref_id
                          decn_rsn_ref_cd{
                            ref_id
                            ref_cd
                            ref_desc
                            ref_dspl
                          }
                          sys_clm_rmrk_ref_id
                          sys_clm_rmrk_ref_cd{
                            ref_id
                            ref_cd
                            ref_desc
                            ref_dspl
                          }
                          ovrd_clm_rmrk_ref_id
                          ovrd_clm_rmrk_ref_cd{
                            ref_id
                            ref_cd
                            ref_desc
                            ref_dspl
                          }
                          ovrd_rsn_ref_id
                          ovrd_rsn_ref_cd{
                            ref_id
                            ref_cd
                            ref_desc
                            ref_dspl
                          }
                          ovrd_rsn_txt
                          site_of_care_pref_ref_id
                          site_of_care_pref_ref_cd{
                            ref_id
                            ref_cd
                            ref_desc
                            ref_dspl
                          }
                          ben_lvl_ref_id
                          ben_lvl_ref_cd{
                            ref_id
                            ref_cd
                            ref_desc
                            ref_dspl
                          }
                          ben_xcpt_ref_id
                          ben_xcpt_ref_cd{
                            ref_id
                            ref_cd
                            ref_desc
                            ref_dspl
                          }
                          aprv_proc_unit_cnt
                          decn_bed_day_cnt
                          aprv_unit_per_freq_cnt
                          negot_rt
                          negot_rt_typ_ref_id
                          negot_rt_typ_ref_cd{
                            ref_id
                            ref_cd
                            ref_desc
                            ref_dspl
                          }
                          decn_rndr_dttm
                          decn_made_by_user_id
                          decn_made_by_user_org_desc
                          decn_ent_by_user_id
                          decn_ent_rsn_ref_id
                          decn_ent_rsn_ref_cd{
                            ref_id
                            ref_cd
                            ref_desc
                            ref_dspl
                          }
                          decn_prov_cmnct_dttm
                          decn_prov_cmnct_to_role_ref_id
                          decn_prov_cmnct_to_role_ref_cd{
                            ref_id
                            ref_cd
                            ref_desc
                            ref_dspl
                          }
                          decn_mbr_cmnct_dttm
                          decn_mbr_cmnct_to_role_ref_id
                          decn_mbr_cmnct_to_role_ref_cd{
                            ref_id
                            ref_cd
                            ref_desc
                            ref_dspl
                          }
                          wrt_decn_cmnct_dttm
                          decn_src_desc
                          decn_clin_rsn_txt
                          decn_ur_jurdc_ref_id
                          decn_ur_jurdc_ref_cd{
                            ref_id
                            ref_cd
                            ref_desc
                            ref_dspl
                          }
                          clm_note_txt
                          gap_rev_otcome_ref_id
                          gap_rev_otcome_ref_cd{
                            ref_id
                            ref_cd
                            ref_desc
                            ref_dspl
                          }
                          peer_to_peer_rev_dt
                          sched_nxt_rev_dt
                          actul_nxt_rev_dt
                          ltr_atr_list
                          decn_hsc_prov_id
                          hsc_decn_bed_days{
                            hsc_decn_id
                            bed_typ_ref_id
                            bed_typ_ref_cd{
                              ref_id
                              ref_cd
                              ref_desc
                              ref_dspl
                            }
                            rvnu_cd
                            accum_bed_day_cnt
                            decn_facl_cmnct_dttm
                            decn_rndr_dttm_facl_lcl_txt
                            strt_bed_dt
                            hsc_clin_guid_id
                          }              
                        }
                        hsr_actvs {
                          hsr_actv_id
                          creat_user_id
                          chg_user_id
                          creat_dttm
                          chg_dttm
                          actv_typ_ref_id
                          actv_typ_ref_cd {
                            ref_id
                            ref_cd
                            ref_desc
                            ref_dspl
                          }
                          actv_strt_dttm
                          actv_prtn_ref_id
                          actv_prtn_ref_cd {
                            ref_id
                            ref_cd
                            ref_desc
                            ref_dspl
                          }
                          cntc_role_ref_id
                          cntc_role_ref_cd {
                            ref_id
                            ref_cd
                            ref_desc
                            ref_dspl
                          }
                          cntc_user_id
                          commt_txt
                          creatr_func_role_ref_id
                          creatr_func_role_ref_cd {
                            ref_id
                            ref_cd
                            ref_desc
                            ref_dspl
                          }
                          dur_mn_nbr
                          extr_ref_trans_id
                          init_by_func_role_ref_id
                          init_by_func_role_ref_cd {
                            ref_id
                            ref_cd
                            ref_desc
                            ref_dspl
                          }
                          rslv_otcome_typ_id
                          rslv_rsn_typ_id
                          hsr_actv_sbjs {
                            hsr_actv_id
                            hsr_sbj_rec_id
                            hsr_sbj_typ_ref_id
                            hsr_sbj_typ_ref_cd {
                              ref_id
                              ref_cd
                              ref_desc
                              ref_dspl
                            }
                          }
                        }
                 `;
export const getHscAuthorization = 'query getHscAuthorization($hscId:bigint!) {\n' +
                ' hsc(where: {hsc_id: {_eq:$hscId}}) {\n' +
                         returnHscData +
            ' } \n' +
'}\n';


export const getHscFacility = `query getHscFacility($hscId:bigint!) {
        hsc_facl(where: {hsc_id: {_eq:$hscId}}) {
            hsc_id
        }
        }`;


export const getHscDataByMemberIdQuery = 'query getHscDetailbyMember( $indvKeyVal: String) {\n' +
            '    hsc(where: {indv_key_val: {_eq: $indvKeyVal}}, order_by: {hsc_id: desc}, limit: 30) {\n' +
             hscReturnColumns +
            '  } \n' +
'}\n';

export const getHscDatabyUserNameQuery = 'query getHscDetailbyUserName($userName: String) {\n' +
                             'hsc(where: {creat_user_id: {_eq: $userName}},order_by: {chg_dttm: desc}, limit: 30) {\n' +
                              hscReturnColumns +
                             '  } \n' +
                             '}\n';
export const insertNote = `
             mutation insertNote($note:hsr_note_insert_input!) {
                 insert_hsr_note_one(object:$note) {
                       hsr_note_id
                       hsc_id
                       note_typ_ref_id
                       note_txt_lobj
                       creat_user_id
                       src_rec_guid
                       src_user_nm,
                       creat_dttm,
                       note_titl_txt,
                       note_sts_ref_id,
                       hsr_note_sbjs{
                         hsr_note_id
                         }
                 }
             }`;

export const upsertKey = `
             mutation upsertKeys($key:[hsc_key_insert_input!]!, $upsertHsckeys: [hsc_key_update_column!]!) {
                 insert_hsc_key(objects:$key,
                 on_conflict: {constraint: hsc_key_pk, update_columns: $upsertHsckeys}) {
                      affected_rows
                       returning {
                       hsc_id
                       }
                 }
             }`;

export const insertDiagnosis = `
            mutation insertDiagnosis($diag: hsc_diag_insert_input!) {
                    insert_hsc_diag_one(object: $diag) {
                        hsc_diag_id
                        hsc_id
                        diag_cd
                        inac_ind
                        pri_ind
                    }
            }`;

export const updateDiagnosis = `
           mutation updateHscDiagnosis( $hsc_diag_id: bigint!,$hscDiagInput: hsc_diag_set_input!) {
               update_hsc_diag_by_pk(pk_columns: {hsc_diag_id: $hsc_diag_id}
              _set: $hscDiagInput){
                       hsc_diag_id
                       }
            }`;

export const updateNotes = `
           mutation updateHsrNotes( $hsr_note_id: bigint!,$hsrNoteInput: hsr_note_set_input!) {
               update_hsr_note_by_pk(pk_columns: {hsr_note_id: $hsr_note_id}
              _set: $hsrNoteInput){
                       hsr_note_id
                       }
            }`;

export const updateProvider = `
           mutation updateHscProvider( $hsc_prov_id: bigint!,$hscProvInput: hsc_prov_set_input!) {
               update_hsc_prov_by_pk(pk_columns: {hsc_prov_id: $hsc_prov_id}
              _set: $hscProvInput){
                       hsc_prov_id
                       }
            }`;

export const updateProc = `
           mutation updateHscProcedure( $hsc_srvc_id: bigint!,$hscSrvcInput: hsc_srvc_set_input!) {
               update_hsc_srvc_by_pk(pk_columns: {hsc_srvc_id: $hsc_srvc_id}
              _set: $hscSrvcInput){
                       hsc_srvc_id
                       }
            }`;

export const updateHscSrvcNonFacl = `
           mutation updateHscSrvcNonFacl( $hsc_srvc_id: bigint!,$hscSrvcNonFaclInput: hsc_srvc_non_facl_set_input!) {
               update_hsc_srvc_non_facl_by_pk(pk_columns: {hsc_srvc_id: $hsc_srvc_id}
              _set: $hscSrvcNonFaclInput){
                       hsc_srvc_id
                       }
            }`;

export const updateHscFacl = `
           mutation updateHscFacl( $hsc_id: bigint!,$hscFaclInput: hsc_facl_set_input!) {
               update_hsc_facl_by_pk(pk_columns: {hsc_id: $hsc_id}
              _set: $hscFaclInput){
                       hsc_id
                       }
            }`;

export const updateHscSrvcNonFaclDme = `
           mutation updateHscSrvcNonFaclDme( $hsc_srvc_id: bigint!,$hscSrvcNonFaclDmeInput: hsc_srvc_non_facl_dme_set_input!) {
               update_hsc_srvc_non_facl_dme_by_pk(pk_columns: {hsc_srvc_id: $hsc_srvc_id}
              _set: $hscSrvcNonFaclDmeInput){
                       hsc_srvc_id
                       }
            }`;

export const deleteInactiveIndMutation= `
            mutation deleteInactiveInd($hscId:bigint!,$diagCodes:[String!]) {
                 delete_hsc_diag(where: {hsc_id: {_eq: $hscId},
                   _and:
                   {diag_cd: {_in: $diagCodes}}}){
                    affected_rows
                           returning {
                            hsc_diag_id
                            hsc_id
                            diag_cd
                            pri_ind
                            inac_ind
                     }
                 }
            }`;

export const updatePrimaryIndMutation= `
            mutation updatePrimaryInd($hscId:bigint!,$diagCode:String,$priInd:smallint!) {
               update_hsc_diag(where: {hsc_id: {_eq: $hscId},
                        _and:
                        {diag_cd: {_eq: $diagCode}}},
                        _inc: {updt_ver_nbr: 1},
                        _set: {pri_ind: $priInd}){
                         affected_rows
                         returning {
                                 hsc_diag_id
                                 hsc_id
                                 diag_cd
                                 pri_ind
                                 inac_ind
                         }
               }
            }`;

export const getPrimaryDiagnosis= `
            query getPrimaryDiagcd($hscId: bigint!) {
  hsc_diag(where: {hsc_id: {_eq: $hscId}, _and: {pri_ind: {_eq: 1}}}){
    hsc_diag_id
    diag_cd
  }
}
`;



export const updateContactDetailsMutation = `
            mutation UpdateHsc($hsc_id: bigint!, $flwup_cntc_dtl: json) {
                    update_hsc_by_pk(pk_columns: {hsc_id: $hsc_id}, _inc: {updt_ver_nbr: 1}, _set: {flwup_cntc_dtl: $flwup_cntc_dtl}) {
                    hsc_id
                 }
               }
            `;

export const updateHscSrvMutation = `
          mutation UpdateHscSrvc($hsc_srvc_id: bigint!, $srvc_hsc_prov_id: bigint!) {
            update_hsc_srvc_by_pk( pk_columns: {hsc_srvc_id: {_eq: $hsc_srvc_id}}, _inc: {updt_ver_nbr: 1}, _set: {srvc_hsc_prov_id: $srvc_hsc_prov_id}) {
              hsc_id
              srvc_hsc_prov_id
            }
          }
         `;


export const createHscCase = 'mutation MyMutation($hsc: hsc_insert_input!) {\n' +
    'insert_hsc_one(object: $hsc) {\n' +
        returnHscData +
    '}\n' +
'}\n';

export const insertProvider = `
         mutation insertProvider($prov: hsc_prov_insert_input!) {
         insert_hsc_prov_one(object: $prov) {
	         hsc_id,
	         creat_user_id,
	         chg_user_id,
	         telcom_adr_id,
	         prov_loc_affil_dtl,
	         spcl_ref_id,
	         hsc_prov_id,
	         hsc_prov_roles {
	            prov_role_ref_id
	         }
            }
        }
            `;

export const insertProviderRole = `
    mutation insertProvider($prov_role: hsc_prov_role_insert_input!) {
         insert_hsc_prov_role_one(object: $prov_role) {
	         hsc_prov_id,
	         prov_role_ref_id
            }
        }
          `;

export const upsertProvider = `
         mutation insertProvider($prov: hsc_prov_insert_input!, $upsertHscprov: [hsc_prov_update_column!]!) {
         insert_hsc_prov_one(object: $prov,
                   on_conflict: {constraint: hsc_prov_pk, update_columns: $upsertHscprov}) {
	         hsc_id,
	         creat_user_id,
	         chg_user_id,
	         telcom_adr_id,
	         prov_loc_affil_dtl,
	         spcl_ref_id,
	         hsc_prov_id,
	         hsc_prov_roles {
	            prov_role_ref_id
	         }
            }
        }
            `;

export const upsertProviderRole = `
    mutation insertProvider($prov_role: hsc_prov_role_insert_input!, $upsertHscprovrole: [hsc_prov_role_update_column!]!) {
         insert_hsc_prov_role_one(object: $prov_role,
                   on_conflict: {constraint: hsc_prov_role_pk, update_columns: $upsertHscprovrole}) {
	         hsc_prov_id,
	         prov_role_ref_id
            }
        }
          `;

export const getHscProviderId =`
    query getHscProvId($provRoleId: [Int!], $hscId: bigint) {
  hsc_prov(where: {hsc_prov_roles: {prov_role_ref_id: {_in: $provRoleId}}, hsc_id: {_eq: $hscId}}) {
    hsc_prov_id
    prov_loc_affil_dtl
  }
}
    `;

export const getHscProviderIdByKey =`
    query getHscProviderIdByKey($provKeyTypeRefId: Int!, $provKeyValue: String!, $hscId: bigint! ) {
  hsc_prov(where: {prov_key_typ_ref_id: {_eq: $provKeyTypeRefId}, prov_key_val: {_eq: $provKeyValue}, hsc_id: {_eq: $hscId}}) {
    hsc_prov_id
  }
}
    `;

export const getHscProvider =`
    query getHscProviderId($hscId: bigint! ) {
  hsc_prov(where: {hsc_id: {_eq: $hscId}}) {
    hsc_prov_id
    prov_key_typ_ref_id
    prov_key_val
    prov_loc_affil_dtl
  }
}
    `;


export const getHscDiagnosisAndProcedure =`
    query getHscDiagnosisAndProc($hscId: bigint) {
  hsc(where: {hsc_id: {_eq: $hscId}}) {
    hsc_id
    hsc_diags {
      diag_cd
      hsc_diag_id
      inac_ind
      pri_ind
    }
    hsc_srvcs {
      hsc_srvc_id
      proc_cd
      proc_cd_schm_ref_id
    }
  }
}
    `;

export const getFacilityHscListByIndvId = `
            query getFacilityHscListByIndvId($indv_key_typ_ref_id: Int!, $indv_key_val: String!, $inpatientRefID: Int!, $outpatientFacilityRefID: Int!) {
                hsc(where: {indv_key_typ_ref_id: {_eq: $indv_key_typ_ref_id},indv_key_val: {_eq: $indv_key_val}, srvc_set_ref_id: {_in: [$inpatientRefID, $outpatientFacilityRefID]}}) {
                    ` + returnHscData +`
                }
            }
            `;

export const getNonFacilityHscListByIndvId = `
            query getNonFacilityHscListByIndvId($indv_key_typ_ref_id: Int!, $indv_key_val: String!, $outpatientRefID: Int!) {
                hsc(where: {indv_key_typ_ref_id: {_eq: $indv_key_typ_ref_id},indv_key_val: {_eq: $indv_key_val}, srvc_set_ref_id: {_in: [$outpatientRefID]}}) {    
                        ` + returnHscData +`
                }
            }
            `;

export const insertProc = `
     mutation insertProc($hscSrvcs: [hsc_srvc_insert_input!]!) {
        insert_hsc_srvc(objects: $hscSrvcs) {
          affected_rows
          returning {
                  hsc_id
                  hsc_srvc_id
                  inac_ind
                  proc_cd
                  proc_cd_schm_ref_id
                  proc_othr_txt
                  srvc_hsc_prov_id
                  hsc_decns {
                    creat_dttm
                    creat_user_id
                    creat_sys_ref_id
                    hsc_decn_id
                    hsc_srvc_id
                    chg_dttm
                    chg_user_id
                    chg_sys_ref_id
                    decn_typ_ref_id
                    decn_typ_ref_cd {
                      ref_cd
                      ref_dspl
                    }
                    decn_otcome_ref_id
                    decn_otcome_ref_cd {
                      ref_cd
                      ref_dspl
                    }
                    decn_rsn_ref_id
                    decn_rsn_ref_cd {
                      ref_cd
                      ref_dspl
                    }
                    sys_clm_rmrk_ref_id
                    sys_clm_rmrk_ref_cd {
                      ref_cd
                      ref_dspl
                    }
                    ovrd_clm_rmrk_ref_id
                    ovrd_clm_rmrk_ref_cd {
                      ref_cd
                      ref_dspl
                    }
                    ovrd_rsn_ref_id
                    ovrd_rsn_ref_cd {
                      ref_cd
                      ref_dspl
                    }
                    ovrd_rsn_txt
                    site_of_care_pref_ref_id
                    site_of_care_pref_ref_cd {
                      ref_cd
                      ref_dspl
                    }
                    ben_lvl_ref_id
                    ben_lvl_ref_cd {
                      ref_cd
                      ref_dspl
                    }
                    ben_xcpt_ref_id
                    ben_xcpt_ref_cd {
                      ref_cd
                      ref_dspl
                    }
                    aprv_proc_unit_cnt
                    decn_bed_day_cnt
                    aprv_unit_per_freq_cnt
                    negot_rt
                    negot_rt_typ_ref_id
                    negot_rt_typ_ref_cd {
                      ref_cd
                      ref_dspl
                    }
                    decn_rndr_dttm
                    decn_made_by_user_id
                    decn_made_by_user_org_desc
                    decn_ent_by_user_id
                    decn_ent_rsn_ref_id
                    decn_ent_rsn_ref_cd {
                      ref_cd
                      ref_dspl
                    }
                    decn_prov_cmnct_dttm
                    decn_prov_cmnct_to_role_ref_id
                    decn_prov_cmnct_to_role_ref_cd {
                      ref_cd
                      ref_dspl
                    }
                    decn_mbr_cmnct_dttm
                    decn_mbr_cmnct_to_role_ref_id
                    decn_mbr_cmnct_to_role_ref_cd {
                      ref_cd
                      ref_dspl
                    }
                    wrt_decn_cmnct_dttm
                    decn_src_desc
                    decn_clin_rsn_txt
                    decn_ur_jurdc_ref_id
                    decn_ur_jurdc_ref_cd {
                      ref_cd
                      ref_dspl
                    }
                    clm_note_txt
                    gap_rev_otcome_ref_id
                    gap_rev_otcome_ref_cd {
                      ref_cd
                      ref_dspl
                    }
                    peer_to_peer_rev_dt
                    sched_nxt_rev_dt
                    actul_nxt_rev_dt
                    ltr_atr_list
                    decn_hsc_prov_id
                    hsc_decn_bed_days {
                      strt_bed_dt
                      bed_typ_ref_id
                      bed_typ_ref_cd {
                        ref_cd
                        ref_dspl
                      }
                      rvnu_cd
                      accum_bed_day_cnt
                      decn_rndr_dttm_facl_lcl_txt
                      decn_facl_cmnct_dttm
                    }
                  }
                  hsc_srvc_non_facls {
                    init_trt_dt
                    plsrv_ref_id
                    plsrv_ref_cd {
                      ref_id
                      ref_desc
                      ref_dspl
                    }
                    proc_freq_ref_id
                    proc_freq_ref_cd {
                      ref_id
                      ref_desc
                      ref_dspl
                    }
                    proc_mod_1_cd
                    proc_mod_2_cd
                    proc_mod_3_cd
                    proc_mod_4_cd
                    proc_unit_cnt
                    proc_uom_ref_id
                    proc_uom_ref_cd {
                      ref_id
                      ref_desc
                      ref_dspl
                    }
                    srvc_desc_ref_id
                    srvc_desc_ref_cd {
                      ref_id
                      ref_desc
                      ref_dspl
                    }
                    srvc_dtl_ref_id
                    srvc_dtl_ref_cd {
                      ref_id
                      ref_desc
                      ref_dspl
                    }
                    srvc_end_dt
                    srvc_strt_dt
                    unit_per_freq_cnt
                    hsc_srvc_non_facl_dmes {
                      clin_ill_desc_txt
                      dme_procrmnt_typ_id
                      dme_tot_cst_amt
                      ental_fd_sngl_src_nutritn_ind
                      fml_nm_txt
                      hsc_srvc_id
                      med_cond_txt
                      spl_desc_txt
                      srvc_desc_txt
                    }
                  }
          }
        }
      }
   `;

export const insertProcSingle = `
     mutation insertProc($hscSrvc: hsc_srvc_insert_input!) {
        insert_hsc_srvc_one(object: $hscSrvc) {
                  hsc_id
                  hsc_srvc_id
                  inac_ind
                  proc_cd
                  proc_cd_schm_ref_id
                  proc_othr_txt
                  srvc_hsc_prov_id
                  hsc_decns {
                    creat_dttm
                    creat_user_id
                    creat_sys_ref_id
                    hsc_decn_id
                    hsc_srvc_id
                    chg_dttm
                    chg_user_id
                    chg_sys_ref_id
                    decn_typ_ref_id
                    decn_typ_ref_cd {
                      ref_cd
                      ref_dspl
                    }
                    decn_otcome_ref_id
                    decn_otcome_ref_cd {
                      ref_cd
                      ref_dspl
                    }
                    decn_rsn_ref_id
                    decn_rsn_ref_cd {
                      ref_cd
                      ref_dspl
                    }
                    sys_clm_rmrk_ref_id
                    sys_clm_rmrk_ref_cd {
                      ref_cd
                      ref_dspl
                    }
                    ovrd_clm_rmrk_ref_id
                    ovrd_clm_rmrk_ref_cd {
                      ref_cd
                      ref_dspl
                    }
                    ovrd_rsn_ref_id
                    ovrd_rsn_ref_cd {
                      ref_cd
                      ref_dspl
                    }
                    ovrd_rsn_txt
                    site_of_care_pref_ref_id
                    site_of_care_pref_ref_cd {
                      ref_cd
                      ref_dspl
                    }
                    ben_lvl_ref_id
                    ben_lvl_ref_cd {
                      ref_cd
                      ref_dspl
                    }
                    ben_xcpt_ref_id
                    ben_xcpt_ref_cd {
                      ref_cd
                      ref_dspl
                    }
                    aprv_proc_unit_cnt
                    decn_bed_day_cnt
                    aprv_unit_per_freq_cnt
                    negot_rt
                    negot_rt_typ_ref_id
                    negot_rt_typ_ref_cd {
                      ref_cd
                      ref_dspl
                    }
                    decn_rndr_dttm
                    decn_made_by_user_id
                    decn_made_by_user_org_desc
                    decn_ent_by_user_id
                    decn_ent_rsn_ref_id
                    decn_ent_rsn_ref_cd {
                      ref_cd
                      ref_dspl
                    }
                    decn_prov_cmnct_dttm
                    decn_prov_cmnct_to_role_ref_id
                    decn_prov_cmnct_to_role_ref_cd {
                      ref_cd
                      ref_dspl
                    }
                    decn_mbr_cmnct_dttm
                    decn_mbr_cmnct_to_role_ref_id
                    decn_mbr_cmnct_to_role_ref_cd {
                      ref_cd
                      ref_dspl
                    }
                    wrt_decn_cmnct_dttm
                    decn_src_desc
                    decn_clin_rsn_txt
                    decn_ur_jurdc_ref_id
                    decn_ur_jurdc_ref_cd {
                      ref_cd
                      ref_dspl
                    }
                    clm_note_txt
                    gap_rev_otcome_ref_id
                    gap_rev_otcome_ref_cd {
                      ref_cd
                      ref_dspl
                    }
                    peer_to_peer_rev_dt
                    sched_nxt_rev_dt
                    actul_nxt_rev_dt
                    ltr_atr_list
                    decn_hsc_prov_id
                    hsc_decn_bed_days {
                      strt_bed_dt
                      bed_typ_ref_id
                      bed_typ_ref_cd {
                        ref_cd
                        ref_dspl
                      }
                      rvnu_cd
                      accum_bed_day_cnt
                      decn_rndr_dttm_facl_lcl_txt
                      decn_facl_cmnct_dttm
                    }
                  }
                  hsc_srvc_non_facls {
                    init_trt_dt
                    plsrv_ref_id
                    plsrv_ref_cd {
                      ref_id
                      ref_desc
                      ref_dspl
                    }
                    proc_freq_ref_id
                    proc_freq_ref_cd {
                      ref_id
                      ref_desc
                      ref_dspl
                    }
                    proc_mod_1_cd
                    proc_mod_2_cd
                    proc_mod_3_cd
                    proc_mod_4_cd
                    proc_unit_cnt
                    proc_uom_ref_id
                    proc_uom_ref_cd {
                      ref_id
                      ref_desc
                      ref_dspl
                    }
                    srvc_desc_ref_id
                    srvc_desc_ref_cd {
                      ref_id
                      ref_desc
                      ref_dspl
                    }
                    srvc_dtl_ref_id
                    srvc_dtl_ref_cd {
                      ref_id
                      ref_desc
                      ref_dspl
                    }
                    srvc_end_dt
                    srvc_strt_dt
                    unit_per_freq_cnt
                    hsc_srvc_non_facl_dmes {
                      clin_ill_desc_txt
                      dme_procrmnt_typ_id
                      dme_tot_cst_amt
                      ental_fd_sngl_src_nutritn_ind
                      fml_nm_txt
                      hsc_srvc_id
                      med_cond_txt
                      spl_desc_txt
                      srvc_desc_txt
                    }
                  }
        }
      }
   `;

export const insertHscFaclMutation = `
           mutation insertHscFacl($hsc_facl: hsc_facl_insert_input!) {
               insert_hsc_facl_one(object: $hsc_facl) {
                 plsrv_ref_id
                 hsc_id
                 }
              }
           `;

export const delMutationHscSrvcs = `
             mutation delMutation($proc_cds: [String!],$hsc_id: bigint) {
                delete_hsc_srvc(where: {hsc_id: {_eq: $hsc_id}, proc_cd: {_in: $proc_cds}}) {
                  affected_rows
                      returning {
                        hsc_srvc_id
                        proc_cd
                      }
                    }
                  }
               `;


export const updateHscMutation = `
           mutation updateHsc( $hsc_id: bigint!,$updateHsc: hsc_set_input!) {
               update_hsc_by_pk(pk_columns: {hsc_id: $hsc_id}
              _set: $updateHsc){
                       hsc_id
                       }
            }
           `;

export const getHscHistoryByProvider = `query getHscHistoryByProvider($prov_key_val: String,$prov_key_typ_ref_id: Int  ) {
                        hsc(where: {hsc_provs: {prov_key_val: {_eq: $prov_key_val}, prov_key_typ_ref_id: {_eq: $prov_key_typ_ref_id}, hsc_prov_roles: {prov_role_ref_id: {_eq: ` + ReferenceConstants.PROVIDER_ROLE_REF_ID_REQUESTING + `}}}},order_by: {hsc_id: desc}, limit: 30) {
                          `+ hscReturnColumns + `
                           } 
                        }`;

export const insertDecision = `
    mutation insertDecision($hsc_decn: hsc_decn_insert_input!) {
         insert_hsc_decn_one(object: $hsc_decn) {
	         hsc_decn_id
            }
        }
          `;

export const insertSrvcDecision = `
    mutation insertSrvcDecision($hsc_decns: [hsc_decn_insert_input]!) {
         insert_hsc_decn(object: $hsc_decns) {
	         hsc_decn_id
            }
        }
          `;

export const insertHscServiceNonFacility = `
    mutation insertHscSrvcNonFacl($hsc_srvc_non_facl: hsc_srvc_non_facl_insert_input!) {
         insert_hsc_srvc_non_facl_one(object: $hsc_srvc_non_facl) {
	         hsc_srvc_id
            }
        }
          `;

// export const insertHscServiceNonFacility = `
//     mutation insertHscSrvcNonFacl($hsc_srvc_non_facl: hsc_srvc_non_facl_insert_input!) {
//          insert_hsc_srvc_non_facl_one(object: $hsc_srvc_non_facl) {
// 	         hsc_srvc_non_facls {
//                 hsc_srvc_id
//                 plsrv_ref_id
//                 srvc_dtl_ref_id
//                 srvc_desc_ref_id
//                 proc_unit_cnt
//                 proc_uom_ref_id
//                 unit_per_freq_cnt
//                 proc_freq_ref_id
//                 proc_mod_1_cd
//                 proc_mod_2_cd
//                 proc_mod_3_cd
//                 proc_mod_4_cd
//                 srvc_end_dt
//                 srvc_strt_dt
//                 init_trt_dt
//              }
//          }
//       }
//     `;






export const deleteHscProvRoles = `
    mutation deleteHscProvRole($hsc_prov_id: bigint!) {
        delete_hsc_prov_role(where: {hsc_prov_id: {_eq: $hsc_prov_id}}) {
            affected_rows
        }
    }
          `;

export const deleteHscProv = `
    mutation deleteHscProv($hsc_prov_id: bigint!) {
        delete_hsc_prov_by_pk(hsc_prov_id: $hsc_prov_id) {
            hsc_prov_id
        }
    }
          `;


export const getHscDetails = `query getHscAuthorization($hscId:bigint!) {
     hsc(where: {hsc_id: {_eq:$hscId}}) {
     hsc_id
    creat_dttm
    creat_user_id
    creat_sys_ref_id
    chg_dttm
    chg_user_id
    chg_sys_ref_id
    hsc_sts_ref_id
    indv_id
    indv_key_typ_ref_id
    indv_key_val
    orig_sys_ref_id
    orig_sys_ref_cd{
      ref_id
      ref_cd
      ref_desc
      ref_dspl
    }
    hsc_sts_ref_cd{
      ref_id
      ref_cd
      ref_desc
      ref_dspl
    }
    hsc_sts_rsn_ref_id
    hsc_sts_rsn_ref_cd{
      ref_id
      ref_cd
      ref_desc
      ref_dspl
    }
    srvc_set_ref_id
    srvc_set_ref_cd{
      ref_id
      ref_cd
      ref_desc
      ref_dspl
    }
    rev_prr_ref_id
    rev_prr_ref_cd{
      ref_id
      ref_cd
      ref_desc
      ref_dspl
    }
    auth_typ_ref_id
    auth_typ_ref_cd{
      ref_id
      ref_cd
      ref_desc
      ref_dspl
    }
    hsc_rev_typ_ref_id
    hsc_rev_typ_ref_cd{
      ref_id
      ref_cd
      ref_desc
      ref_dspl
    }
    cont_of_care_ind
    rev_prr_rsn_txt
    auth_strt_dt
    auth_end_dt
    flwup_cntc_dtl
    mbr_cov_dtl
    hsc_facls{
      data_qlty_iss_list
      data_secur_rule_list
      adv_ntfy_trans_id
      admis_ntfy_trans_id
      dschrg_ntfy_trans_id
      adv_ntfy_dttm
      admis_ntfy_dttm
      dschrg_disp_ref_id
      dschrg_ntfy_dttm
      plsrv_ref_id
      plsrv_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      srvc_dtl_ref_id
      srvc_dtl_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      srvc_desc_ref_id
      srvc_desc_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      expt_admis_dt
      expt_dschrg_dt
      actul_admis_dttm
      actul_dschrg_dttm
      goal_los_day_cnt
      dschrg_disp_ref_id
      dschrg_disp_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      rem_snf_day_cnt
      snf_day_xhst_ind
      ipcm_typ_ref_id
      ipcm_typ_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      ctp_nom_sts_ref_id
      ctp_nom_sts_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      tat_due_dttm
      tat_rqr_crit_list
    }
    hsc_decns{
      creat_dttm
      creat_user_id
      creat_sys_ref_id
      hsc_decn_id
      chg_dttm
      chg_user_id
      chg_sys_ref_id
      decn_typ_ref_id
      decn_typ_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      decn_otcome_ref_id
      decn_otcome_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      decn_rsn_ref_id
      decn_rsn_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      sys_clm_rmrk_ref_id
      sys_clm_rmrk_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      ovrd_clm_rmrk_ref_id
      ovrd_clm_rmrk_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      ovrd_rsn_ref_id
      ovrd_rsn_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      ovrd_rsn_txt
      site_of_care_pref_ref_id
      site_of_care_pref_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      ben_lvl_ref_id
      ben_lvl_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      ben_xcpt_ref_id
      ben_xcpt_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      aprv_proc_unit_cnt
      decn_bed_day_cnt
      aprv_unit_per_freq_cnt
      negot_rt
      negot_rt_typ_ref_id
      negot_rt_typ_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      decn_rndr_dttm
      decn_made_by_user_id
      decn_made_by_user_org_desc
      decn_ent_by_user_id
      decn_ent_rsn_ref_id
      decn_ent_rsn_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      decn_prov_cmnct_dttm
      decn_prov_cmnct_to_role_ref_id
      decn_prov_cmnct_to_role_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      decn_mbr_cmnct_dttm
      decn_mbr_cmnct_to_role_ref_id
      decn_mbr_cmnct_to_role_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      wrt_decn_cmnct_dttm
      decn_src_desc
      decn_clin_rsn_txt
      decn_ur_jurdc_ref_id
      decn_ur_jurdc_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      clm_note_txt
      gap_rev_otcome_ref_id
      gap_rev_otcome_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      peer_to_peer_rev_dt
      sched_nxt_rev_dt
      actul_nxt_rev_dt
      ltr_atr_list
      decn_hsc_prov_id
    }
    hsc_provs {
      hsc_prov_id
      creat_dttm
      creat_user_id
      chg_dttm
      chg_user_id
      prov_loc_affil_dtl
      hsc_prov_roles{
        prov_role_ref_cd{
          ref_id
          ref_cd
          ref_desc
          ref_dspl
        }
      }
    }
    individual(limit:5) {
      indv_id
      fst_nm
      lst_nm
      midl_nm
      sufx_nm
      bth_dt
      gdr_ref_id
      gdr_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      indv_keys{
        indv_key_val
        indv_key_typ_ref_id
        indv_key_typ_ref_cd{
          ref_id
          ref_cd
          ref_desc
          ref_dspl
        }
      }
    }
    hsc_diags{
      hsc_diag_id
      admit_ind
      creat_dttm
      creat_user_id
      chg_dttm
      chg_user_id
      diag_cd
      diag_othr_txt
      diag_cd_schm_ref_id
      diag_cd_schm_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      inac_ind
      pri_ind
    }
    hsc_srvcs{
      hsc_srvc_id
      creat_dttm
      creat_user_id
      chg_dttm
      chg_user_id
      proc_cd
      proc_othr_txt
      proc_cd_schm_ref_id
      proc_cd_schm_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      inac_ind
      expmt_proc_ind
      expt_proc_dt
      hsc_srvc_rev_typ_ref_id
      hsc_srvc_rev_typ_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      srvc_hsc_prov_id
      adv_ntfy_trans_id
      adv_ntfy_dttm
      tat_due_dttm
      ben_chk_sts_ref_id
      ben_chk_sts_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      expt_proc_dt
      hsc_srvc_non_facls{
        plsrv_ref_id
        plsrv_ref_cd{
          ref_id
          ref_cd
          ref_desc
          ref_dspl
        }
        srvc_dtl_ref_id
        srvc_dtl_ref_cd{
          ref_id
          ref_cd
          ref_desc
          ref_dspl
        }
        srvc_desc_ref_id
        srvc_desc_ref_cd{
          ref_id
          ref_cd
          ref_desc
          ref_dspl
        }
        proc_unit_cnt
        proc_uom_ref_id
        proc_uom_ref_cd{
          ref_id
          ref_cd
          ref_desc
          ref_dspl
        }
        unit_per_freq_cnt
        proc_freq_ref_id
        proc_freq_ref_cd{
          ref_id
          ref_cd
          ref_desc
          ref_dspl
        }
        proc_mod_1_cd
        proc_mod_2_cd
        proc_mod_3_cd
        proc_mod_4_cd
        srvc_strt_dt
        srvc_end_dt
        init_trt_dt
        hsc_srvc_non_facl_dmes{
          dme_procrmnt_typ_id
          spl_desc_txt
          clin_ill_desc_txt
          ental_fd_sngl_src_nutritn_ind
          med_cond_txt
          fml_nm_txt
          dme_tot_cst_amt
          srvc_desc_txt
        }
      }
      hsc_decns{
      hsc_decn_id
      creat_dttm
      creat_user_id
      creat_sys_ref_id
      chg_dttm
      chg_user_id
      chg_sys_ref_id
      decn_typ_ref_id
      decn_typ_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      decn_otcome_ref_id
      decn_otcome_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      decn_rsn_ref_id
      decn_rsn_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      sys_clm_rmrk_ref_id
      sys_clm_rmrk_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      ovrd_clm_rmrk_ref_id
      ovrd_clm_rmrk_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      ovrd_rsn_ref_id
      ovrd_rsn_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      ovrd_rsn_txt
      site_of_care_pref_ref_id
      site_of_care_pref_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      ben_lvl_ref_id
      ben_lvl_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      ben_xcpt_ref_id
      ben_xcpt_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      aprv_proc_unit_cnt
      decn_bed_day_cnt
      aprv_unit_per_freq_cnt
      negot_rt
      negot_rt_typ_ref_id
      negot_rt_typ_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      decn_rndr_dttm
      decn_made_by_user_id
      decn_made_by_user_org_desc
      decn_ent_by_user_id
      decn_ent_rsn_ref_id
      decn_ent_rsn_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      decn_prov_cmnct_dttm
      decn_prov_cmnct_to_role_ref_id
      decn_prov_cmnct_to_role_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      decn_mbr_cmnct_dttm
      decn_mbr_cmnct_to_role_ref_id
      decn_mbr_cmnct_to_role_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      wrt_decn_cmnct_dttm
      decn_src_desc
      decn_clin_rsn_txt
      decn_ur_jurdc_ref_id
      decn_ur_jurdc_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      clm_note_txt
      gap_rev_otcome_ref_id
      gap_rev_otcome_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      peer_to_peer_rev_dt
      sched_nxt_rev_dt
      actul_nxt_rev_dt
      ltr_atr_list
      decn_hsc_prov_id
      hsc_decn_bed_days{
        strt_bed_dt
        bed_typ_ref_id
        bed_typ_ref_cd{
          ref_id
          ref_cd
          ref_desc
          ref_dspl
        }
        rvnu_cd
        accum_bed_day_cnt
        decn_rndr_dttm_facl_lcl_txt
        decn_facl_cmnct_dttm
      }
    }
    }
    hsc_keys{
      hsc_key_val
      hsc_key_typ_ref_id
      hsc_key_typ_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
    }
    hsr_notes{
      hsr_note_id
      creat_dttm
      creat_user_id
      chg_dttm
      chg_user_id
      src_user_nm
      note_txt_lobj
      creatr_func_role_ref_id
      creatr_func_role_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      grd_lvl_scor
      note_typ_ref_id
      note_typ_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      note_catgy_ref_id
      note_catgy_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      note_titl_txt
      note_sts_ref_id
      note_sts_ref_cd{
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
    }
  }
  }`;

export const getHscStatus = `query getHscStatus($hscId:bigint!) {
     hsc(where: {hsc_id: {_eq:$hscId}}) {
      hsc_sts_ref_id
      rev_prr_ref_id
      srvc_set_ref_id
      hsc_facls {
        plsrv_ref_id
        srvc_desc_ref_id
        srvc_dtl_ref_id
        actul_admis_dttm
        actul_dschrg_dttm
        expt_admis_dt
        expt_dschrg_dt
      }
      hsc_srvcs {
      hsc_srvc_id
        hsc_srvc_non_facls {
          hsc_srvc_id
          plsrv_ref_id
          srvc_desc_ref_id
        }
      }
  }}`;

export const getCaseTypeDetails = `query getCaseTypeDetails($hsc_id: bigint!) {
  hsc(where: {hsc_id: {_eq: $hsc_id}}) {
    hsc_id
    hsc_sts_ref_id
    hsc_sts_ref_cd {
      ref_id
      ref_cd
      ref_desc
      ref_dspl
    }
    rev_prr_ref_id
    rev_prr_ref_cd {
      ref_id
      ref_cd
      ref_desc
      ref_dspl
    }
    srvc_set_ref_id
    srvc_set_ref_cd {
      ref_id
      ref_cd
      ref_desc
      ref_dspl
    }
    hsc_facls {
      plsrv_ref_id
      plsrv_ref_cd {
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      srvc_desc_ref_id
      srvc_desc_ref_cd {
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      srvc_dtl_ref_id
      srvc_dtl_ref_cd {
        ref_id
        ref_cd
        ref_desc
        ref_dspl
      }
      actul_admis_dttm
      actul_dschrg_dttm
      expt_admis_dt
      expt_dschrg_dt
    }
    hsc_srvcs {
      hsc_srvc_non_facls {
        plsrv_ref_id
        plsrv_ref_cd {
          ref_id
          ref_cd
          ref_desc
          ref_dspl
        }
        srvc_desc_ref_id
        srvc_desc_ref_cd {
          ref_id
          ref_cd
          ref_desc
          ref_dspl
        }
      }
    }
  }
}
`;

export const hscDecnBedDayMutation = `
  mutation MyMutation($inputArray: [hsc_decn_bed_day_insert_input!]!) {
  insert_hsc_decn_bed_day(objects: $inputArray,on_conflict: {constraint: hsc_decn_bed_day_pk, update_columns: accum_bed_day_cnt}) {
    returning {
      hsc_decn_id
      strt_bed_dt
      bed_typ_ref_id
      accum_bed_day_cnt
      decn_rndr_dttm_facl_lcl_txt
      decn_facl_cmnct_dttm
      hsc_clin_guid_id
    }
    affected_rows
  }
}`;

export const insertHscDecnMutation = `
    mutation MyMutation ($inputArray: [hsc_decn_insert_input!]!){
        insert_hsc_decn(objects: $inputArray) {
          affected_rows
          returning {
            hsc_decn_id
            creat_dttm
            decn_typ_ref_id
            decn_otcome_ref_id
            decn_rsn_ref_id
            decn_made_by_user_id
            decn_made_by_user_org_desc
            decn_bed_day_cnt
            hsc_id
          }
        }
      }`;

export const updatehscDecnMutation = `
    mutation updateHscDec ($hsc_decn_id: bigint!,$inputArray:hsc_decn_set_input!){
        update_hsc_decn_by_pk(pk_columns: {hsc_decn_id: $hsc_decn_id}
        _set: $inputArray) {
            hsc_decn_id
            decn_bed_day_cnt
        }
      }`;
export const getMemCovDtlByHscId =`
query getMemCovDtlByHsc($hsc_id: bigint!){
  hsc(where: {hsc_id: {_eq: $hsc_id}}) {
    mbr_cov_dtl
  }
}
`;

export const insertHsrAsgnSbjMutation = `
mutation insertHsrAsignSbj($hsr_asgn_sbj:hsr_asgn_sbj_insert_input!){
  insert_hsr_asgn_sbj_one(object: $hsr_asgn_sbj ) {
    hsr_asgn_id
  }
}
`;

    export const getAccmulatedBedDayQuery =
    `query MyQuery ($hsc_id:bigint!){
     hsc_decn_aggregate(where: {hsc_id: {_eq: $hsc_id}}) {
      aggregate {
      sum {
        decn_bed_day_cnt
          }
        }
      }
    }`;

export const insertBedDayNotes = `
            mutation insertNote($note:[hsr_note_sbj_insert_input!]!) {
                 insert_hsr_note_sbj(objects:$note) {
                      affected_rows
                         returning {
                         hsr_note {
                          hsc_id
                          note_txt_lobj
                          hsr_note_id
                          }
                     }
                }
             }`;

export const getHscClinGuid = `query getHscClinGuid($hscId:bigint!, $hsc_clin_guid_id:bigint!) {
        hsc_clin_guid(where: {hsc_id: {_eq:$hscId}, hsc_clin_guid_id: {_eq: $hsc_clin_guid_id}}) {
            hsc_id
            hsc_clin_guid_id
        }
}`;

export const updateHscClinGuidMutation = `
           mutation updateHscClinGuid( $hsc_clin_guid_id: bigint!,$hscClinGuidInput: hsc_clin_guid_set_input!) {
               update_hsc_clin_guid_by_pk(pk_columns: {hsc_clin_guid_id: $hsc_clin_guid_id}
              _set: $hscClinGuidInput){
                       hsc_id
                       }
            }`;

export const insertHscClinGuidMutation = `
           mutation insertHscClinGuid($hsc_clin_guid: hsc_clin_guid_insert_input!) {
               insert_hsc_clin_guid_one(object: $hsc_clin_guid) {              
                 hsc_id
    						 hsc_clin_guid_id
    						 clin_rev_desc
    						 clin_rev_otcome_ref_id
    						 clin_rev_sts_ref_id
    						 clin_guid_id
                 }
              }
           `;

export const insertActivityMutation = `
    mutation insertActivity($hsr_actv:hsr_actv_insert_input!) {
     insert_hsr_actv_one(object: $hsr_actv) {
        hsr_actv_id
      }
    }
  `;

export const insertActivitySubjMutation = `
    mutation insertActivitySubj($hsr_actv_sbj:hsr_actv_sbj_insert_input!) {
      insert_hsr_actv_sbj_one(object: $hsr_actv_sbj) {
        hsr_actv_id 
        }
      }
    `;
