import {GraphQLClient} from "graphql-request/dist";
import {ConfigService} from "@nestjs/config";
import {IndividualClient} from "./individualClient";
import {HttpRequest} from "@azure/functions";

class MockConfigService extends ConfigService {
    get(propertyPath: any){
        return 'testvalue';
    };
}

describe('MemberClient', () => {
    let individualClient: IndividualClient;

    beforeEach(async () => {
        individualClient = new IndividualClient(new MockConfigService());
    });

    it('should be defined', () => {
        expect(individualClient).toBeDefined();
    });

    it('should return a Member GraphQLClient', () => {
        let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid', headers: {authorization: 'test token', 'x-hasura-role': 'testrole'}, query: {'test':'test'}, params: {'test':'test'}};
        const client = individualClient.getGraphqlClient(httpRequest);
        expect(client).toBeInstanceOf(GraphQLClient);
    });
});
