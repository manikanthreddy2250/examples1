export const getIndvDetailByIndvKeyVal = 'query IDSearch($indvkeyId: [String!]) {\n' +
                         '  indv_key(where: {indv_key_val: {_in: $indvkeyId}, indv_key_typ_ref_id: {_eq: 2757}}) {\n' +
                         '    indv_id\n' +
                         '    indv_key_val\n' +
                         '    indv{\n' +
                         '    fst_nm\n' +
                         '    lst_nm\n' +
                         '    }\n' +
                         '  } \n' +
                         '}\n';

export const getIndvByIndvKeyVal = 'query IDSearch($indvkeyId: String!) {\n' +
    '  indv_key(where: {indv_key_val: {_eq: $indvkeyId}, indv_key_typ_ref_id: {_eq: 2757}}) {\n' +
    '    indv_id\n' +
    '    indv_key_val\n' +
    '    indv{\n' +
    '    fst_nm\n' +
    '    lst_nm\n' +
    '    }\n' +
    '  } \n' +
    '}\n';

export const getPermAdrByIndvId = 'query PermAdrByIndvId($indvId: bigint!) {\n' +
                         'indv_adr(where: {adr_typ_ref_id: {_in: [2118, 2131]}, indv_id: {_eq: $indvId}}) {\n'+
                         'adr_typ_ref_id\n'+
                         'adr_typ_ref_cd {\n'+
                         '   ref_dspl\n'+
                         '}\n'+
                         'indv_id\n'+
                         'indv_adr_id\n'+
                         'st_ref_cd {\n'+
                         '    ref_cd\n'+
                         '    ref_dspl\n'+
                         '}\n'+
                         'st_ref_id\n'+
                         'end_dt\n'+
                         '}\n'+
                     '}\n';

export const getMemberCoveDetails = `query getMemberCovDetails($orig_sys_mbr_id: String, $orig_sys_cd: String, $src_mbr_id: String, $src_mbr_partn_id: String, 
      $cov_eff_dt: date, $cov_end_dt: date, $cov_typ_ref_id: Int, $pol_nbr: String, $sbscr_lst_nm: String, $sbscr_fst_nm: String,
			$elig_sys_ref_id: Int) {
    mbrshp(where: {orig_sys_mbr_id: {_eq: $orig_sys_mbr_id}, orig_sys_cd: {_eq: $orig_sys_cd}, 
        src_mbr_id: {_eq: $src_mbr_id}, src_mbr_partn_id: {_eq: $src_mbr_partn_id}, sbscr_fst_nm:{_eq: $sbscr_fst_nm},
    		sbscr_lst_nm: {_eq: $sbscr_lst_nm}}) {
       mbr_covs(where: {cov_eff_dt: {_eq: $cov_eff_dt}, cov_end_dt: {_eq: $cov_end_dt},
          cov_typ_ref_id: {_eq: $cov_typ_ref_id}, pol_nbr: {_eq: $pol_nbr}, elig_sys_ref_id: {_eq: $elig_sys_ref_id}}) {
          cov_eff_dt
          cov_end_dt
          mbr_cov_id
          pol_nbr
          lob_ref_id
          pol_iss_st_ref_cd {
          ref_cd
          }
          cov_typ_ref_cd {
            ref_desc
          }
          prdct_catgy_ref_cd {
            ref_desc
          }
          prdct_ref_cd {
            ref_cd
          }
          mbr_cov_unets{
            mbr_cov_id
          mkt_nbr_ref_cd{
                    ref_id
                    ref_cd
                 }
           mkt_typ_ref_cd{
                    ref_id
                    ref_cd
                }
          }
          clm_pltfm_ref_id
          clm_pltfrm_ref_cd{
                ref_id
                ref_cd
                ref_desc
                ref_dspl
          }
          prdct_ref_id
        }
        orig_sys_cd
        orig_sys_mbr_id
        orig_sys_ref_id
        src_mbr_id
        src_mbr_partn_id
      }
    }`;
