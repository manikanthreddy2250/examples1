import {GraphQLClient} from "graphql-request/dist";
import { ConfigService } from '@nestjs/config';
import { Injectable } from '@nestjs/common';
import {HttpRequest} from "@azure/functions";

@Injectable()
export class MemberClient {

    private memberClient;

    constructor(private readonly configService: ConfigService) {
        this.memberClient = new GraphQLClient(
            configService.get<string>('MEMBERSHIP_API_ENDPOINT'),
        );
    }

    public getGraphqlClient(req: HttpRequest): GraphQLClient {
        const headers = {
            'content-type': req.headers['content-type'],
            Authorization: req.headers['authorization'],
            'x-hasura-role': req.headers['x-hasura-role'],
        };
        this.memberClient.setHeaders(headers);
        return this.memberClient;
    }
}
