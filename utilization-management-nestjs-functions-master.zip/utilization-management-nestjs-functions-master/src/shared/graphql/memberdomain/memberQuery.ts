export const memberCovDetailsQuery = `
query memberCovDetailsQuery($memberId: String, $TodaysDate: date, $origSysCode: String) {
  mbrshp(where: {orig_sys_mbr_id: {_eq: $memberId}, orig_sys_cd: {_eq: $origSysCode}}) {
    mbr_covs(where: {cov_end_dt: {_gt: $TodaysDate}}) {
      mbr_cov_id
      cov_end_dt
      cov_eff_dt
      pol_nbr
      lob_ref_id
      prdct_typ_ref_cd {
        ref_desc
      }
      clm_pltfm_ref_id
      prdct_catgy_ref_cd {
        ref_desc
      }
      prdct_catgy_ref_id
      cov_typ_ref_id
      cov_typ_ref_cd {
        ref_desc
      }
    }
  }
}
`;
