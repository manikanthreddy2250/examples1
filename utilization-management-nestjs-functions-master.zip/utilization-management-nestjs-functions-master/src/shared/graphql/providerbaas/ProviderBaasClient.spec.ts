import { GraphQLClient } from 'graphql-request/dist';
import { ConfigService } from '@nestjs/config';
import { ProviderBaasClient } from './providerBaasClient';
import { HttpRequest } from '@azure/functions';

class MockConfigService extends ConfigService {
  get(propertyPath: any) {
    return 'testvalue';
  }
}

describe('ProviderBaasClient', () => {
  let providerBaasClient: ProviderBaasClient;

  beforeEach(async () => {
    providerBaasClient = new ProviderBaasClient(new MockConfigService());
  });

  it('should be defined', () => {
    expect(providerBaasClient).toBeDefined();
  });

  it('should return a Health Service GraphQLClient', () => {
    const httpRequest: HttpRequest = {
      method: null,
      url: '/test?session_id=encryptedid',
      headers: { authorization: 'test token', 'x-hasura-role': 'testrole' },
      query: { test: 'test' },
      params: { test: 'test' },
    };
    const client = providerBaasClient.getGraphqlClient(httpRequest);
    expect(client).toBeInstanceOf(GraphQLClient);
  });
});
