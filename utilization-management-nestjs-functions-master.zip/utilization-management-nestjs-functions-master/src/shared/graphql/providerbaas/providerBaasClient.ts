import { GraphQLClient } from 'graphql-request/dist';
import { ConfigService } from '@nestjs/config';
import { Injectable } from '@nestjs/common';
import { HttpRequest } from '@azure/functions';

@Injectable()
export class ProviderBaasClient {
  private providerBaasClient;

  constructor(private readonly configService: ConfigService) {
    this.providerBaasClient = new GraphQLClient(
      configService.get<string>('PROVIDER_BAAS_ENDPOINT'),
    );
  }

  public getGraphqlClient(req: HttpRequest): GraphQLClient {
    const headers = {
      'content-type': req.headers['content-type'],
      Authorization: req.headers['authorization'],
      'x-hasura-role': req.headers['x-hasura-role'],
    };
    this.providerBaasClient.setHeaders(headers);
    return this.providerBaasClient;
  }
}
