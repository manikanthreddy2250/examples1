export const facilitySummaryQueryForAddress = `query getFacilitySummary($city_nm: String = "", $prov_id: String = "", $zip: String = "") {
  facilitySummary0002(facilitySummary0002: {city_nm: $city_nm, prov_id: $prov_id, zip: $zip})
}
`;
