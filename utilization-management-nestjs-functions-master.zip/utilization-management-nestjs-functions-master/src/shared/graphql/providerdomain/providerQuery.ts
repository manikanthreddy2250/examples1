export const provDetailsQuery = `query provDetailsQuery($prov_key_val: String, $prov_key_typ_ref_id: Int,
  $adr_ln_1_txt: String, $adr_ln_2_txt: String, $zip_cd_txt: String, $cty_nm: String, $st_ref_id: Int, $fst_nm: String, $lst_nm: String,
  $bus_nm: String){
  v_prov_srch(where: {prov_key_val: {_eq: $prov_key_val},
  prov_key_typ_ref_id: {_eq: $prov_key_typ_ref_id},
  adr_ln_1_txt: {_ilike: $adr_ln_1_txt},
  adr_ln_2_txt: {_ilike: $adr_ln_2_txt},
  zip_cd_txt: {_eq: $zip_cd_txt},
  cty_nm: {_ilike: $cty_nm},
  st_ref_id: {_eq: $st_ref_id},
  fst_nm: {_eq: $fst_nm},
  lst_nm: {_eq: $lst_nm},
  bus_nm: {_eq: $bus_nm}
},
distinct_on: prov_key_typ_ref_id) {
prov_id
prov_adr_id
prov_catgy_ref_id
prov_catgy_ref_cd{
      ref_id
      ref_cd
      ref_desc
      ref_dspl
}
st_ref_cd{
      ref_id
      ref_cd
      ref_desc
      ref_dspl
 }
prov_loc_affil_id
adr_ln_1_txt
adr_ln_2_txt
fst_nm
lst_nm
}
}`;

export const getProviderbyProvIDAdrIdQuery =  `query ProviderbyProvIDAdrIdQuery($provIds: [bigint!], $provAdrIds: [bigint!]) {
  v_prov_srch(where: {prov_id: {_in: $provIds }, prov_adr_id: {_in: $provAdrIds }}, distinct_on: prov_adr_id) {
      fst_nm
      lst_nm
      bus_nm
      prov_id
      prov_adr_id
     }
  }`;

  export const nrtFacilityContractQuery =  `query getNrtContractData($src_rec_guid: String,$lob_ref_id:Int) {
   prov_contr(
          where: {
                      src_rec_guid: {_like: $src_rec_guid},prov_ntwk: {lob_ref_id: {_eq: $lob_ref_id}}
              }
  ){
      prov_contr_id
      prov_id
      prov_loc_affil_id
      prov_ntwk_id
      prov_ntwk_prr_ref_id
      prov_reim_typ_ref_id
    prov_reim_typ_ref_cd{
      bas_ref_nm
      ref_dspl
      ref_desc
    }
      med_nec_rev_claus_ref_id
    med_nec_rev_claus_ref_cd{
       bas_ref_nm
       ref_dspl
      ref_desc
    }
      prov_ntwk {
        carr_nm
        bus_seg_nm
        lob_ref_id
      }
    }
  }
  `;

  export const medNecTypeDataQuery =  `query getMedNecTypeData($src_rec_guid: String,$lob_ref_id:Int) {
   prov_contr(
          where: {
                      src_rec_guid: {_like: $src_rec_guid},prov_ntwk: {lob_ref_id: {_eq: $lob_ref_id}}
              }
  ){
      med_nec_rev_claus_ref_id
    med_nec_rev_claus_ref_cd{
       bas_ref_nm
       ref_dspl
      ref_desc
    }
      prov_ntwk {
        carr_nm
        bus_seg_nm
        lob_ref_id
      }
    }
  }
  `;

export const facilitySummaryQueryForAddress = `query getFacilitySummary($city_nm: String = "", $prov_id: String = "", $zip: String = "") {
  facilitySummary0002(facilitySummary0002: {city_nm: $city_nm, prov_id: $prov_id, zip: $zip})
}
`;
