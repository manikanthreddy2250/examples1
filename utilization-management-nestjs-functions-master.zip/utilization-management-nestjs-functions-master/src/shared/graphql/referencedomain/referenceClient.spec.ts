import { Test, TestingModule } from '@nestjs/testing';
import {GraphQLClient} from "graphql-request/dist";
import {ConfigService} from "@nestjs/config";
import {ReferenceClient} from "./referenceClient";
import {HttpRequest} from "@azure/functions";

class MockConfigService extends ConfigService {
    get(propertyPath: any){
        return 'testvalue';
    };
}

describe('ReferenceClient', () => {
    let referenceClient: ReferenceClient;

    beforeEach(async () => {
        referenceClient = new ReferenceClient(new MockConfigService());
    });

    it('should be defined', () => {
        expect(referenceClient).toBeDefined();
    });

    it('should return a Health Service GraphQLClient', () => {
        let httpRequest: HttpRequest = {method: null, url: '/test?session_id=encryptedid',
            headers: {authorization: 'test token', 'x-hasura-role': 'testrole', 'content-type': 'application/json'},
            query: {'test':'test'},
            params: {'test':'test'}};

        const client = referenceClient.getGraphqlClient(httpRequest);
        expect(client).toBeInstanceOf(GraphQLClient);
    });
});
