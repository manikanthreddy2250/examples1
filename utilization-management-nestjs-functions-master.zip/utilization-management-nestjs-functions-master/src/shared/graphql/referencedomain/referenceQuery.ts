export const diagCdRefQuery = `query icd10($diag_cds: [String!]) {
                          icd10(where: {diag_cd: {_in:$diag_cds}}) {
                            diag_cd
                            full_desc
                            shrt_desc
                            cd_desc
                          }
                        }`;
export const ProceduresByCodesHCPCSQuery = `query ProceduresByCodesHCPCS ( $procCodes: [String!] ){
    hcpcs(where: {proc_cd: {_in: $procCodes}}){
        proc_cd
        cd_desc
         }
    }`;

export const ProceduresByCodesCpt4Query = `query ProceduresByCodesCpt4 ( $procCodes: [String!] ){
     cpt4(where: {proc_cd: {_in: $procCodes}}){
        proc_cd
        cd_desc
      }
    }`;